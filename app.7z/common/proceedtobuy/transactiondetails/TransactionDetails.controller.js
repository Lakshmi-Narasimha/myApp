/**
 * @ngdoc property
 * @name TransactionDetailsController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display Transaction details for sip and lumpsum
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function TransactionDetailsController($scope,$state,fticLoggerMessage, loggerConstants,transactModel) {  
    
    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;

    $state.go($scope.transactionDtls.transactionDtlsState);

    if(transactModel.getTransactType()==="Lumpsum")
    {
      $scope.showLumpsum = true;
    }
    else if(transactModel.getTransactType()==="SIP")
    {
      $scope.showSip = true;
    }
    else if(transactModel.getTransactType()==="Combo")
    {
      $scope.showBoth = true;
    }

}
TransactionDetailsController.$inject = ['$scope','$state','fticLoggerMessage', 'loggerConstants','transactModel'];
module.exports = TransactionDetailsController;