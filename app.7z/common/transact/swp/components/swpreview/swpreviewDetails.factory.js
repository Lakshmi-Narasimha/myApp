/**
 * @ngdoc factory
 * @name selectFundGrid factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var swpReviewDetailsFactory = function ($filter) {

    var swpReviewDetailsFactory = {
        getFormattedSwpDetails: function (userType) {
            var _swpDetails = [];
            if (userType && (userType.toString() === '10')) {
                _swpDetails = [{
                        text: 'Withdrawal Type',
                        value: (this.selectedType === 'capital') ? 'Capital Appreciation' : 'Fixed Amount'
                    }, {
                        text: 'Amount',
                        value: (this.selectedType === 'capital') ? this.swpAmount : '<span class="icon-fti_rupee"></span>' + this.swpAmount
                    }, {
                        text: 'Frequency',
                        value: this.frequency
                    }, {
                        text: 'SWP Start Date',
                        value: this.startDate
                    }, {
                        text: 'SWP End Date',
                        value: this.endDate
                    }, {
                        text: 'No. of Installments',
                        value: this.noofInstallments
                    }, {
                        text: 'Bank Details',
                        value: this.bankDetails
                    }, {
                        text: 'Mode of Payment',
                        value: $filter('paymentMode')(this.selectedMode)
                    }

                ];
            } else {
                _swpDetails = [{
                        text: 'Amount',
                        value: this.swpAmount
                    }, {
                        text: 'Frequency',
                        value: this.frequency
                    }, {
                        text: 'SWP Start Date',
                        value: this.startDate
                    }, {
                        text: 'SWP End Date',
                        value: this.endDate
                    }, {
                        text: 'No. of Installments',
                        value: this.noofInstallments
                    }, {
                        text: 'Mode of Bank Details',
                        value: this.bankDetails
                    }, {
                        text: 'Mode of Payment',
                        value: $filter('paymentMode')(this.selectedMode)
                    }

                ];
            }
            return _swpDetails;

        },
        getCurrentToState: function(userType) {
             if (userType && (userType.toString() === '10')) {
                 return 'invTransact.base.swp';
             }else {
                 return 'transact.base.swp';
             }
        },
        getCurrentTxnToState: function(userType) {
            if (userType && (userType.toString() === '10')) {
                 return 'invTransact.txnDetails';
             }else {
                 return 'transact.txnDetails.swp';
             }
        },
         getExactSelectedDate: function (day, monthYear, flag) {
            var exactDate;
            var _day = day.key;
            var _month = new Date(monthYear).getMonth();
            var _year = new Date(monthYear).getFullYear();

            if (_day.toString().toLowerCase() === 'lbd') {

                if(flag) {
                    exactDate = 'LBD'+'/'+this.getMonthOfLbd(_month + 1)+'/'+_year;
                } else {
                    var _lastDay = new Date(_year, _month + 1, 0).getDate();
                    exactDate = new Date(_year, _month, _lastDay);
                } 
                return exactDate;
            } else {
                exactDate = new Date(_year, _month, _day);
                return exactDate;
            }
        },
        getMonthOfLbd: function(month) {
            return month < 10 ? '0' + month : '' + month;
        }
    };
    return swpReviewDetailsFactory;

};

swpReviewDetailsFactory.$inject = ['$filter'];
module.exports = swpReviewDetailsFactory;
