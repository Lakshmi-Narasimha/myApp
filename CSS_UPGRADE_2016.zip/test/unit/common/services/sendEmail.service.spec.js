(function() {

    'use strict';

    describe('send Email service', function() {
        var resultData, timeout, $httpBackend, service;

        var successCallback = function(data) {
            resultData = data;
        };

        var errorObj = {
            'errorMessageCode': 500,
            'transactionStatus': 'Error',
            'errorDescription': 'Something went wrong...',
        };
        
        var emailObject = [{
            "functionName": "SendPaymentConfirmationEmail",
            "emailDetails": {  
               "uiErrorDisplayMessage":null,
               "transactionStatus":"S",
               "transactionDescription":"Success",
               "transactionCode":null
            }
        }]

        beforeEach(module('CSS.common'));

        beforeEach(inject(function(sendEmailService, $timeout, $injector) {
            service = sendEmailService;
            timeout = $timeout;
            $httpBackend = $injector.get('$httpBackend');
        }));

        it('service should be defined...', function() {
            expect(service).toBeDefined();
        });

        it('should sendEmail service to be called, then should respond with success object ...', function() {
            var obj = {
                functionName: null,
                emailDetails: {}
            };

            $httpBackend.expectPOST('http://localhost:9900/sendEmail/sendEmail', obj.functionName).respond(emailObject);
            service.sendEmail(obj.functionName).then(function(data) {
                expect(data.transactionStatus).not.toEqual("E");
            });
            timeout.flush();
            $httpBackend.flush();
        });

        it('should sendEmail service to be called, then should respond with with failure object ...', function() {
            var obj = {
                functionName: null
            };

            var errorCallback = function(data) {
                expect(data.transactionStatus).toBe('Error');
            };

            $httpBackend.expectPOST('http://localhost:9900/sendEmail/sendEmail', obj.functionName).respond(404, errorObj);
            service.sendEmail(obj.functionName).then(successCallback, errorCallback);

            timeout.flush();
            $httpBackend.flush();
        });

    });

})();
