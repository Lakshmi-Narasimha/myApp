/**
 * @ngdoc property
 * @name TransactionDetailsSIPController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display Transaction details for sip and lumpsum
 *
 **/


 'use strict';
// Controller naming conventions should start with an uppercase letter
//function TransactionDetailsSIPController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService,fundDetails) {
	function TransactionDetailsSIPController($scope, $state,buildPlanModelService,buildPlanInitialLoader,fundDetailsModel) {
		console.log('TransactionDetailsSIPController');

		buildPlanInitialLoader.loadAllServices($scope); 
		$scope.SIPkeyValueList = [
		{key:"Folio. No.",value:buildPlanModelService.getInvestorSearch().folioId},  
		{key:"First Holder",value:buildPlanModelService.getInvestorSearch().custName}		     
		];
	//$scope.tileDetails = fundDetails.getFundDetails();

	$scope.folioNumber = "1234567-NS";
	$scope.holderName = "Shankar Narayan";

	// $scope.tileDetails = {};

	// $scope.tileDetails.fundDetailsSIP = fundDetailsModel.getFundDetails();

	//console.log("the fund details",$scope.tileDetails.fundDetailsSIP);
	$scope.tileDetails = {

		fundDetailsSIP : [ {
			fundName: "Franklin India Bluechip Fund",
			accountNumber : 2123334,
			sipAmount : 800,
			dividend : "Re-Investment",
			sipFirstInstallment : "1 Jan 2016",
			sipFutureInstallment: "15th day Aug 2016",
			sipEndDate: "1 Jan 2020",
			frequency: "Monthly"
		},
		{
			fundName: "Franklin India Cash Management Account Fund",
			accountNumber : 2123334,
			sipAmount : 550,
			dividend : "Re-Investment",
			sipFirstInstallment : "1 Jan 2016",
			sipFutureInstallment: "15th day Aug 2016",
			sipEndDate: "1 Jan 2020",
			frequency: "Monthly"
		},
		{
			fundName: "Franklin India Cash Management Account Fund",
			accountNumber : 2123334,
			sipAmount : 550,
			dividend : "Re-Investment",
			sipFirstInstallment : "1 Jan 2016",
			sipFutureInstallment: "15th day Aug 2016",
			sipEndDate: "1 Jan 2020",
			frequency: "Annualy"
		},
		{
			fundName: "Franklin India Cash Management -Direct Growth",
			accountNumber : 2123334,
			sipAmount : 4550,
			dividend : "Re-Investment",
			sipFirstInstallment : "1 Jan 2016",
			sipFutureInstallment: "15th day Aug 2016",
			sipEndDate: "1 Jan 2016",
			frequency: "Annualy"
		}]
	};


	$scope.infoObj=[];
	angular.forEach($scope.tileDetails.fundDetailsSIP, function(obj, key){
		$scope.infoObj.push([
		{
			text: "Fund",
			value: $scope.tileDetails.fundDetailsSIP[key].fundName
		},
		{
			text: "Amount",
			value: $scope.tileDetails.fundDetailsSIP[key].sipAmount
		},
		{
			text: "Dividend Option",
			value: $scope.tileDetails.fundDetailsSIP[key].dividend
		},
		{
			text: "SIP First Installment",
			value: $scope.tileDetails.fundDetailsSIP[key].sipFirstInstallment
		},
		{
			text: "SIP Future Installment",
			value: $scope.tileDetails.fundDetailsSIP[key].sipFutureInstallment
		},
		{
			text: "SIP End Date",
			value: $scope.tileDetails.fundDetailsSIP[key].sipEndDate
		},
		{
			text: "Frequency",
			value: $scope.tileDetails.fundDetailsSIP[key].frequency
		}
		]);
	});

	// $scope.transactionDetails = {
	// 	transactionRefNo : "FUL17077",
	// 	reqDateTime : "30 April 2016, 11:08 AM",
	// 	totalInvestedAmount: 1350
	// };
	$scope.keyValueList = [
	{key:'Transaction Reference Number',value:"FUL17077"},
	{key:'Request Date and Time',value:"30 April 2016, 11:08 AM"},
	{key:'Total Invested Amount',value:1350}
	];
	

	$scope.sipFundDetails = [];
	//$scope.sipcolumnDefs = keyValueGridConfig.fundGridConfig[TransactConstant.guest.SIPINV];

	$scope.continue = function(){
		$state.go('');
	}

}

//TransactionDetailsController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','fundDetails'];
TransactionDetailsSIPController.$inject = ['$scope', '$state','buildPlanModelService','buildPlanInitialLoader','fundDetailsModel'];
module.exports = TransactionDetailsSIPController;