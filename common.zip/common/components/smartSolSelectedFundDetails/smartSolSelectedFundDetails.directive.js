/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolSelectedFundDetails = function ($state, $timeout) {
    return {
        template: require('./smartSolSelectedFundDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
            selectedFundData: "="
        },
        controller:['$scope', function ($scope) {
            //$scope.annualizedGrowthVal = $scope.selectedFundData[0].returnSlabs;

            $scope.annulizedObj = {};
            $scope.annulizedObj.annulizedType = [];
            $scope.annulizedObj.annulizedReturnValue = [];
            $scope.fundCardDetails = {
                annualReturn : []
            };
            $scope.$on('slectedOptionValue', function (event, obj) {
                $scope.anuualizedGrowth = obj.value;
            });
            $scope.showFundCardModal = function (fundId) {
                $scope.$emit('openFundCardModelPlan', fundId);
            };

            $scope.setFundCardReturns = function (data, ind) {
                console.log(data);
                //$scope.annulizedObj.annulizedType[ind] = null;
                $timeout(function () {
                    $scope.annulizedObj.annulizedType[ind] = data.title;
                    $scope.annulizedObj.annulizedReturnValue[ind] = data.value;
                }, 0);

            }
        }],
        link: function (scope) {
            $('[data-toggle="popover"]').popover();
        }
    };
};

smartSolSelectedFundDetails.$inject = ['$state', '$timeout'];
module.exports = smartSolSelectedFundDetails;