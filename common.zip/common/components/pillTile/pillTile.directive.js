'use strict';

var pillTile = function() {
    return {
            template: require('./pillTile.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                tileData: '=tileData',              
                type: '=type',
                dType: '='               
            }
        };
};

pillTile.$inject = [];
module.exports = pillTile;