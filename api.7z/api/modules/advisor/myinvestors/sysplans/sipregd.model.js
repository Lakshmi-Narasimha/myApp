// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SIPRegdModelSchema = new mongoose.Schema({
    sipRegdResp: {
        type: Array,
        "default": []
    }
});

var SIPRegdModelLookUp = mongoose.model('SIPRegdModelLookUp', SIPRegdModelSchema);

var SIPRegdModel = new SIPRegdModelLookUp({
    sipRegdResp : {
      "sipDetails": {
        "fundWiseData": [
          {
            "folioNo": "1141621",
            "fund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "10,000"
          },
          {
            "folioNo": "1142621",
            "fund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Monthly",
            "amount": "15,000"
          },
          {
            "folioNo": "1143621",
            "fund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "18,000"
          }
        ],
        "grandTotal": "43,000"
      }
    }
}
);

SIPRegdModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SIPRegdModelLookUp table, please contact admin...');
    } else {
        SIPRegdModelLookUp.remove({}, function(err) {
            console.log('SIPRegdModelLookUp collection removed');
            SIPRegdModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SIPRegdModelLookUp table, please contact admin...');
                }
                console.log('SIPRegdModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SIPRegdModelLookUp;
