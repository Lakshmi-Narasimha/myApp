/**
* @ngdoc service
* @name paymentDetailsUtility
* @description
*
* - It will hit the restangular(network service) call and resolve the data to wrapper.
*
*/

'use strict';

var paymentDetailsUtility = function (bankDtlsModel, transactModel, TransactConstant, sipDetailsModel, fundDetails, authenticationService, buildPlanModelService, $stateParams, $filter, transactNowModel, profileDetailsModel, paperlessModel, $state, investorRegistrationModel, $location) {
    var paymentDetailsUtility = {
        populateBanks : function(type, bankOptions, optionsArray) {
            if(bankOptions) {
                for(var i=0; i<bankOptions.length; i++) {
                    optionsArray.push({title: bankOptions[i].pbBankName + '-' + bankOptions[i].pbPersonalAccountNumber, key : bankOptions[i].pbPersonalAccountNumber, refNo : bankOptions[i].achRefNo, bankName : bankOptions[i].pbBankName});
                }
                if(type === 'newEmandates') {
                	optionsArray.push({title: TransactConstant.transact.NEW_ACCOUNT, key: 'newAccount'});
                }
            }
        },

        saveSelectedBank : function(optionsArray) {
        	var selectedBank = bankDtlsModel.getSelectedBank();
        	for(var i=0; i<optionsArray.length; i++) {
                if(optionsArray[i].title === selectedBank) {
                	return optionsArray[i];
                }
            }
        },

        checkFormValidity : function(scope) {
            scope.showBankError = false;
            var isMultiMode = bankDtlsModel.getIsMultiPayMode(),
                payMethod = bankDtlsModel.getPaymentMethod();

            if(!isMultiMode && !scope.isModifySIP) {
                switch(payMethod) {
                    case TransactConstant.transact.EXISTING_PAY_MANDATE :                        
                        scope.showBankError = scope.method.eMandateSel.key === 'select' ? true : false;
                        break;
                    case TransactConstant.transact.NET_BANKING :                        
                        scope.showBankError = scope.method.netBankSel.key === 'select' ? true : false;
                        break;
                    case TransactConstant.transact.DEBIT_CARD :
                        scope.showBankError = scope.method.debitBankSel.key === 'select' ? true : false;
                        break;
                    case TransactConstant.transact.SETUP_NEW_MANDATE :                        
                        scope.showBankError = scope.method.newMandateSel.key === 'select' ? true : false;                      
                        break;
                    case TransactConstant.transact.NEFT_RTGS :                        
                        scope.showBankError = scope.method.neftSel.key === 'select' ? true : false;
                };               
            } else if(scope.isModifySIP) {
                switch(payMethod) {
                    case TransactConstant.transact.EXISTING_PAY_MANDATE :                        
                        scope.showBankError = scope.method.eMandateSel.key === 'select' ? true : false;
                        break;
                    case TransactConstant.transact.NET_BANKING :                        
                        scope.showBankError = scope.method.netBankSel.key === 'select' ? true : false;
                        break;                                     
                    case TransactConstant.transact.SETUP_NEW_MANDATE :                        
                    scope.showBankError = scope.method.newMandateSel.key === 'select' ? true : false;
                }
            }            

        	var isAmountError = bankDtlsModel.getIsFundAmountError() || bankDtlsModel.getIsFixedAmountError(),
            	isBankError = scope.showBankError || bankDtlsModel.getIsMultiBankError() || bankDtlsModel.getIsAutoBankError(),
            	isSipFreqError = bankDtlsModel.getIsSipFreqError(),
            	isExhausted = bankDtlsModel.getIsExhausted(),
                isAccTypeError = bankDtlsModel.getIsAccTypeError(),
                isNoBankError = bankDtlsModel.getIsNoBankError(),
                isInvalidAmtError = bankDtlsModel.getIsInvalidAmtError();
        	return !isAmountError && !isBankError && !isSipFreqError && !isExhausted && !isAccTypeError && !isNoBankError && !isInvalidAmtError;
        },

        isEmptyBankList : function(bankList) {
            var showNoBankError = false;
            if(bankList.length === 0) {
                showNoBankError = true;
            }
            return showNoBankError;
        },

        setPayment : function(bankDtls, data) {
        	var i = 0;
            var payMethod = bankDtlsModel.getPaymentMethod();
            if(bankDtls !== undefined && data.key !== 'select') {
                while(bankDtls[i].pbPersonalAccountNumber !== data.key) {
                    i++;
                }
                bankDtlsModel.setSelectedBank(data.title);
                bankDtlsModel.setAccountNo(data.key);
                bankDtlsModel.setPaymentMode(bankDtls[i].paymentType);
                if(transactModel.getIsModifySIP() && payMethod === TransactConstant.transact.AUTO_DEBIT) {
                    bankDtlsModel.setPaymentMode(TransactConstant.common.AUTO_DEBIT_CODE);
                }
                bankDtlsModel.setBankName(data.bankName);
                bankDtlsModel.setIfscCode(bankDtls[i].ifscCode);
                bankDtlsModel.setAccountType(bankDtls[i].pbAccountType);

                if(payMethod !== TransactConstant.transact.SETUP_NEW_MANDATE && payMethod !== TransactConstant.transact.AUTO_DEBIT) {
                    if(transactModel.getIsSip()) {
                        bankDtlsModel.setTotalAmount(sipDetailsModel.getSipTotalAmount());
                    } else if(transactModel.getIsBuy()) {
                        bankDtlsModel.setTotalAmount(fundDetails.getBuyTotalAmount());
                    }
                }
            }
            return i;
        },

        getNEFTPayeeDetails : function(txnType) {
        	var pymntBnkLstParams = {
                "trxnType" : txnType,
                "guId" : authenticationService.getUser() !== null ? authenticationService.getUser().guId : ""  
            };
            bankDtlsModel.fetchNewInvBanks(pymntBnkLstParams).then(function (data) {
                bankDtlsModel.setneftDetails(data.neftDetails);
            }, function (data) {
                console.log("Failure", data)
            });
        },

        getTxnType : function() {
        	var transactType = transactModel.getTransactType(),
                isSip = false,
                isBuy = false,
                isModifySIP = false,
                txnType = null;
            
        	switch(transactType) {
        		case TransactConstant.sip.SIP:
        		case TransactConstant.sip.FUNDSIP:
        		case TransactConstant.renewSip.RENEWSIP:
        			isSip = true;
        			txnType = TransactConstant.sip.SIP;
                    break;                   
        		case TransactConstant.buy.BUY:
        		case TransactConstant.buy.BUYFUND:
        			isBuy = true;
        			txnType = TransactConstant.buy.PURCHASE;
                    break;                  
        		case TransactConstant.modifySip.MODIFYSIP:
        			isModifySIP = true;
        			txnType = TransactConstant.sip.SIP;                  
        	};
            transactModel.setIsSip(isSip);
            transactModel.setIsBuy(isBuy);
            transactModel.setIsModifySIP(isModifySIP); 
            return txnType;    	
        },

        setCustBankParams : function() {
            var accType = bankDtlsModel.getAccountType(),
                custBankParams = {};

            custBankParams.bankName = bankDtlsModel.getBankName() || "";
            custBankParams.bankCode = bankDtlsModel.getIfscCode() || "";
            if(accType === TransactConstant.transact.SAVINGS) {
                custBankParams.bankAccountType = 'SA';
            } else if(accType === TransactConstant.transact.CURRENT) {
                custBankParams.bankAccountType = 'CA';
            }
            custBankParams.bankAccountNumber = bankDtlsModel.getAccountNo() ? bankDtlsModel.getAccountNo().toString() : "";
            custBankParams.bankBranchName = bankDtlsModel.getBranchName() || "";
            custBankParams.bankBranchCity = bankDtlsModel.getBranchAddress() || "";
            custBankParams.accountNo = 'NEW';
            custBankParams.bankPaymentType = bankDtlsModel.getPaymentMode() || "";
            custBankParams.webRefNo =  transactModel.getWebRefNo() || "";

            return custBankParams;
        },   

        setValidateParams : function() {
        	var validateParams = {},
                accType = bankDtlsModel.getAccountType(),
                flowType = transactModel.getFlowType();
            /*if(transactModel.getWebRefNo()){
                validateParams.webRefNo = transactModel.getWebRefNo();
            }*/

            if($stateParams.from === TransactConstant.transact.INVESTOR_LEG){
                validateParams.webRefNo = transactModel.getWebRefNo();
            }
            
            this.getTxnType();

        	validateParams.folioId = transactModel.getInvestorDetails() !== null ? transactModel.getInvestorDetails().folioId : "" || buildPlanModelService.getInvestorSearch() !== null ? buildPlanModelService.getInvestorSearch().folioId : "" || transactModel.getSelectedFolioDts() !== null ? transactModel.getSelectedFolioDts().folioId : "";
            validateParams.bankAccountNumber = bankDtlsModel.getAccountNo() ? bankDtlsModel.getAccountNo().toString() : "";
            validateParams.bankName = bankDtlsModel.getBankName() || "";
            validateParams.ifscCode = bankDtlsModel.getIfscCode() || "";
            
            if(accType === TransactConstant.transact.SAVINGS) {
                validateParams.bankAccountType = 'SA';
            } else if(accType === TransactConstant.transact.CURRENT) {
                validateParams.bankAccountType = 'CA';
            } else {
                validateParams.bankAccountType = accType || "";
            }
            validateParams.refNo = bankDtlsModel.getAchRefNo() || "";
            validateParams.batchCode = TransactConstant.common.BATCH_CODE;
            validateParams.txnFlag = "C";
            
            if(flowType === "advisor") {
                validateParams.source = TransactConstant.common.USER_TYPE_ADVISOR;                
            } else { // For Transact Now, Paperless, Investor leg
                validateParams.source = TransactConstant.common.USER_TYPE_INVESTOR;
            }
            
            validateParams.mfCode = "";

            validateParams.paymentMode = bankDtlsModel.getPaymentMode() || "";
            validateParams.nextPaymentMode = bankDtlsModel.getNextPaymentMode() || "";

            this.setFreqAmtTypeParams(validateParams);
            this.setAdvDetParams(validateParams);

            validateParams.urnNo = "";
            validateParams.umrnNo = bankDtlsModel.getAchRefNo() || "";
            validateParams.renewal = "N";

            validateParams.panNo = authenticationService.getUser().pan || transactModel.getInvestorDetails().pan;

            if(transactModel.getIsSip() || transactModel.getIsModifySIP()){
                validateParams.txnSource = TransactConstant.sip.SIP;
                this.setSipParams(validateParams);
            } else if(transactModel.getIsBuy()){
                validateParams.txnSource = TransactConstant.buy.PURCHASE;
                this.setBuyParams(validateParams);                
            }
            transactModel.setReqParams(validateParams);
            return validateParams;
        },

        setFreqAmtTypeParams : function(validateParams) {
            var datefilter = $filter('date')
        	if(validateParams.paymentMode === TransactConstant.common.EMANDATE_CODE || validateParams.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE || validateParams.nextPaymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                validateParams.emAmount = bankDtlsModel.getTotalAmount() ? bankDtlsModel.getTotalAmount().toString() : "";
                var paramFrequency = bankDtlsModel.getFrequency();
                switch(paramFrequency) {
                  case TransactConstant.transact.MONTHLY:
                  case  TransactConstant.transact.MNTHLY:
                        validateParams.emFrequency = "M";
                        break;
                  case TransactConstant.transact.QUARTERLY:
                  case TransactConstant.transact.QUATERLY:
                        validateParams.emFrequency = "Q";
                        break;
                  case TransactConstant.transact.AS_AND_WHEN:
                        validateParams.emFrequency = "A";
                        break;
                }
                var paramDebitType = bankDtlsModel.getAmountType();
                if(paramDebitType) {
                    switch(paramDebitType) {
                      case TransactConstant.transact.MAXIMUM:
                            validateParams.debitType = "U";
                            break;
                      case TransactConstant.transact.FIXED:
                            validateParams.debitType = "F";
                            break;
                    }
                }
                validateParams.emFromDate = datefilter(new Date(bankDtlsModel.getStartDate()), 'dd/MM/yyyy');
                validateParams.emToDate =  datefilter(new Date(bankDtlsModel.getEndDate()), 'dd/MM/yyyy');
                if(validateParams.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE || validateParams.nextPaymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                    var autoDebitPeriod = bankDtlsModel.getPeriod() || "";
                    validateParams.emFromDate =  "";
                    validateParams.emToDate =  "";
                    validateParams.untillCancel = "Y";
                    if(autoDebitPeriod === TransactConstant.transact.DATE_RANGE) {
                        validateParams.emFromDate =  datefilter(bankDtlsModel.getStartDate(), 'dd/MM/yyyy');
                        validateParams.emToDate =  datefilter(new Date(bankDtlsModel.getEndDate()), 'dd/MM/yyyy');
                        validateParams.untillCancel = "N";
                    }
                }
            }
        },

        setAdvDetParams : function(validateParams) {
        	var advisorDetails = transactModel.getAdvDetails(),
                investorPref = transactNowModel.getInvestPrefer(),
                advisorProfile = profileDetailsModel.getProfileDtls();
            validateParams.distId = "";
            
            if(investorPref) {
                if(investorPref.investorMode === "direct"){
                  validateParams.distId = "0000000000";
                } else if(investorPref.investorMode === "financial"){              
                  validateParams.distId = investorPref.code; //Proxy team will split this and set arn code as distId
                }
            } else if(advisorProfile) {
                validateParams.distId = advisorProfile.profileDetails.ARN;
            } else{
                validateParams.distId = authenticationService.getUser().distId;
            }

            validateParams.subBrokerARN = "";
            validateParams.euin = "";
            validateParams.euinFlag = "N";
            if(advisorDetails){
                validateParams.subBrokerARN = advisorDetails.subBrokerArn;
                if(advisorDetails.euin && advisorDetails.euin !== 'NO EUIN'){
                  validateParams.euinFlag = "Y";
                  validateParams.euin = advisorDetails.euin;
                }
            }
        },

        setSipParams : function(validateParams) {
        	var fundObj = {},
        		fundArr = fundDetails.getFundDetails();
        	if(transactModel.getInvestorDetails()){
               validateParams.customerName = transactModel.getInvestorDetails().custName; 
            } else if(transactModel.getSelectedFolioDts().firstHolderName){
                validateParams.customerName = transactModel.getSelectedFolioDts().firstHolderName;
            }

            if($stateParams.from === TransactConstant.transact.INVESTOR_LEG){
                validateParams.distId = bankDtlsModel.getDistId();
            }
            
            validateParams.fundOptions = [];            
            for(var i in fundArr) {
                fundObj = {};
                fundObj.fundOption = fundArr[i].fundOption;
                fundObj.perpetualFlag = fundArr[i].perpetualFlag;
                if(bankDtlsModel.getIsNewAccount()) {
                    fundObj.txnType = "NEW";
                    fundObj.accNo = "NEW";
                } else {
                    fundObj.txnType = fundArr[i].accNo !== "NEW" ? "ADD" : "NEW";
                    fundObj.accNo = fundArr[i].accNo;
                }
                if($stateParams.from === TransactConstant.transact.INVESTOR_LEG){
                    fundObj.amount = fundArr[i].amount;
                } else {
                    fundObj.amount = transactModel.getIsModifySIP() ? fundArr[i].amount : fundArr[i].sipAmount.toString();
                }

                fundObj.dividendFlag = fundArr[i].dividendFlag;                
                fundObj.frequency = fundArr[i].frequency ==='Monthly' ? "M" :(fundArr[i].frequency === "Annually" ? "A" : (fundArr[i].frequency === "Quaterly" ? "Q" : fundArr[i].frequency));
                fundObj.startDate = fundArr[i].startDateSS || fundArr[i].startDate;
                fundObj.endDate = fundArr[i].endDate === "Until Cancelled" ? "" : fundArr[i].endDate;;
                fundObj.stepUpFrequency = fundArr[i].stepUpSip === "NA" ? "" : "A";
                fundObj.stepUpType = fundArr[i].stepUpType || "";
                if(fundArr[i].stepUpValue){
                    fundObj.stepUpValue = fundArr[i].stepUpValue.toString();
                } else {
                    fundObj.stepUpValue = '';
                }                
                validateParams.fundOptions.push(fundObj);
            }
            validateParams.urnNo = "";
            validateParams.umrnNo = bankDtlsModel.getAchRefNo() || "";
            validateParams.renewal = "N";
            validateParams.euinFlag= "N";

            transactModel.setSipReqParams(validateParams);
        },

        setBuyParams : function(validateParams) {
        	if($stateParams.from === TransactConstant.transact.INVESTOR_LEG){
                validateParams.distId = bankDtlsModel.getDistId();
            } 
         	var fundObj = {},
         		fundArr = fundDetails.getFundDetails();
            validateParams.fundOptions = [];           

            for(var i in fundArr){
                fundObj = {};
                fundObj.fundOption = fundArr[i].fundOption;
                if($stateParams.from === TransactConstant.transact.INVESTOR_LEG){
                    fundObj.amount = fundArr[i].amount;
                } else{
                       fundObj.amount = fundArr[i].amount.toString();
                } 
                fundObj.dividendFlag = fundArr[i].dividendFlag;
                fundObj.nfoFlag = fundArr[i].nfoFlag;                
                if(bankDtlsModel.getIsNewAccount()) {
                    fundObj.txnType = "NEW";
                    fundObj.accNo = "NEW";
                } else {
                    fundObj.txnType = fundArr[i].accNo !== "NEW" ? "ADD" : "NEW";
                    fundObj.accNo = fundArr[i].accNo;
                }
                fundObj.perpetualFlag = "N";                
                fundObj.fundType = fundArr[i].fundType;
                validateParams.fundOptions.push(fundObj);
            }
            transactModel.setBuyReqParams(validateParams);
        },

        showSelectedBank : function(scope) {
            var payMethod = bankDtlsModel.getPaymentMethod();
            var isMultiMode = bankDtlsModel.getIsMultiPayMode();                        
            if(!isMultiMode) {
                switch(payMethod) {
                    case TransactConstant.transact.EXISTING_PAY_MANDATE:
                        scope.existingMandate.disable = false;
                        scope.showMandateDetails = true;
                        scope.method.eMandateSel = this.saveSelectedBank(scope.eMandateOptions);                                    
                        break;
                    case TransactConstant.transact.NET_BANKING:
                        scope.netBanking.disable = false;
                        scope.method.netBankSel = this.saveSelectedBank(scope.netBankOptions);
                        break;
                    case TransactConstant.transact.DEBIT_CARD:
                        scope.debitCard.disable = false;
                        scope.method.debitBankSel = this.saveSelectedBank(scope.debitBankOptions);
                        break;
                    case TransactConstant.transact.AUTO_DEBIT:
                        scope.showAutoDebit = true;
                        scope.method.autoDebitSel = this.saveSelectedBank(scope.newMandateOptions); 
                        break;
                    case TransactConstant.transact.SETUP_NEW_MANDATE:
                        scope.newMandate.disable = false;
                        scope.showNewMandate = true;
                        var isNewAct = bankDtlsModel.getIsNewAccount(),
                            length = scope.newMandateOptions.length;
                        if(isNewAct) {
                            scope.method.newMandateSel = scope.newMandateOptions[length - 1];
                        } else {
                            scope.method.newMandateSel = this.saveSelectedBank(scope.newMandateOptions);                                        
                        }
                        break;
                    case TransactConstant.transact.NEFT_RTGS:
                        scope.neft.disable = false;
                        scope.showPayeeDetails = true;
                        scope.method.neftSel = this.saveSelectedBank(scope.neftBankOptions);
                };
            } else if(isMultiMode) {
                scope.showMultiPayMode = true;
                scope.mode.selectedVal = TransactConstant.transact.MULTIPLE_PAY_MODE;
            }
        },

        setPaymentRedirectDtls : function(scope) {
                var txnSource = "",
                    custDtls = {},
                    holderDtls = null,
                    investorDetails = {},
                    folioDtls = {},
                    personalDtls = {},
                    advisorDtls = {},
                    investorMode = "",
                    investPref = {},
                    profileDtls = {},
                    paperlessInvestorDetails,
                    paperlessholderDtls,
                    dataReady,
                    fundObj,
                    totalInvAmount = 0,
                    mfCode = "";

            transactModel.fetchTxnDetails(scope.params).then(txnDtlsSuccess, txnDtlsFailure);

            function txnDtlsSuccess(data) {

                

                //To be fetched from cookie  
                scope.isNewInvestor = transactModel.isNewInvestor;
                scope.isNewFolio = false;
                transactModel.setTxnDetails(data);
                transactModel.setWebRefNo(data.web_refno);

                txnSource = data.txn_source;
                mfCode = data.mf_code;

                transactModel.setIsBuy(false);
                transactModel.setIsSip(false);
                
                switch(txnSource) {
                    case TransactConstant.sip.SIP:          
                        transactModel.setIsSip(true);
                        transactModel.setTransactType(TransactConstant.sip.SIP);
                        paperlessModel.invType.setInvType('SIP');
                        transactModel.setSipWebRefNo(data.web_refno);
                        break;
                    case TransactConstant.buy.PURCHASE:
                        transactModel.setIsBuy(true);
                        transactModel.setTransactType(TransactConstant.buy.BUY);
                        paperlessModel.invType.setInvType('LumpsumInv');
                        transactModel.setLumpsumWebRefNo(data.web_refno);
                        break;
                    case TransactConstant.investorleg.TXN_SOURCE_SIPSUP:
                    case TransactConstant.investorleg.TXN_SOURCE_SIPDTC:
                    case TransactConstant.investorleg.TXN_SOURCE_SIPFLX:
                    case TransactConstant.investorleg.TXN_SOURCE_SIPAMC:
                    case TransactConstant.investorleg.TXN_SOURCE_SIPPAS:
                    case TransactConstant.investorleg.TXN_SOURCE_SIPCAN:
                    case TransactConstant.investorleg.TXN_SOURCE_SIPSUC:
                        transactModel.setIsModifySIP(true);
                        transactModel.setTransactType(TransactConstant.sip.SIP);
                        break;
                };

                transactModel.isNewInvestor = false;
                transactModel.setIsNewFolio(false);
                if(mfCode === "WSOLNACC") {
                    transactModel.isNewInvestor = true;
                    transactModel.setIsNewFolio(true);
                }

                //Investor Details
                custDtls = data.customerInfoVo;            
                if(transactModel.isRetryPaymentInvestorLeg){
                    holderDtls = [{                                                                                                                                            
                                    "name": custDtls.firstHolderName
                                },
                                {                                                                        
                                    "name": custDtls.secondHolderName
                                },
                                {                                                                                                           
                                    "name": custDtls.thirdHolderName
                                }];
                }else{
                    holderDtls = [{
                            "name" : custDtls.secondHolderName ? custDtls.secondHolderName : 'NA'
                        }, {
                            "name" : custDtls.thirdHolderName ? custDtls.thirdHolderName : 'NA'
                        }];
                }        

                investorDetails = {
                    "folioId" : data.folioId,
                    "custName" : custDtls.custName,
                    "pan" : custDtls.firstHolderPanNo,
                    "emailId" : custDtls.email,
                    "mobile" : custDtls.mobile,
                    "holders" : holderDtls,
                    "batch_code" : data.batch_code,
                    "renewal_flag" : data.renewal_flag,
                    "source" : data.source,
                    "euin_flag":data.euin_flag
                };   
                paperlessInvestorDetails = {
                    "fullName" : custDtls.custName,
                    "appPanNo" : custDtls.firstHolderPanNo,
                    "email" : custDtls.email,
                    "mobile" : custDtls.mobile
                }
                paperlessholderDtls = [{
                            "fullName" : custDtls.secondHolderName ? custDtls.secondHolderName : 'NA'
                        }, {
                            "fullName" : custDtls.thirdHolderName ? custDtls.thirdHolderName : 'NA'
                        }];
                transactModel.setInvestorDetails(investorDetails);
                transactModel.setTransactDetails(investorDetails);
                paperlessModel.invDetails.setFirstHolderDetails(paperlessInvestorDetails);
                paperlessModel.invDetails.setHolderDetails(paperlessholderDtls);
                paperlessModel.modeOfHolding = custDtls.holdingType;
                investorRegistrationModel.setNewInvestorFolioId(data.folioId);
                //Folio Details    
                folioDtls = {
                    "folioId" : data.folioId,
                    "firstHolder" : custDtls.custName,          
                    "secondHolder" : custDtls.secondHolderName ? custDtls.secondHolderName : 'NA',
                    "thirdHolder" : custDtls.thirdHolderName ? custDtls.thirdHolderName : 'NA'
                };
                transactModel.setFolioDetailsObj(folioDtls);

                //Set Pan, Email, Mobile
                personalDtls = {
                    "pan" : custDtls.firstHolderPanNo,
                    "emailId" : custDtls.email,
                    "mobile" : custDtls.mobile,
                    "guId" : authenticationService.getUser().guId
                };
                authenticationService.setUser(personalDtls);

                // Fund Details
                fundObj = {};
                fundDetails.removeFundDetails();
                angular.forEach(data.fundOptions, function(obj, ind) {
                    totalInvAmount = totalInvAmount+parseInt(obj.amount);
                    if(transactModel.getIsSip()) {
                        fundObj = obj;
                        fundObj.fundName = obj.fundOptDesc;
                        fundObj.sipAmount = obj.amount;
                        fundObj.dividend = obj.dividendFlag === "R" ? "Re-Investment" : (obj.dividendFlag === "P" ? "Payout" : "NA");
                        fundObj.firstInstallment = 'Current Business Day';
                        fundObj.futureInstallment = $filter('date')(obj.startDate, "dd/MM/yyyy");
                        fundObj.startDate = $filter('date')(obj.startDate, "dd/MM/yyyy");
                        fundObj.endDate = obj.perpetualFlag === "Y" ? "Until Cancelled" : $filter('date')(obj.endDate, "dd/MM/yyyy");
                        fundObj.frequency = obj.frequency === "M" ? "Monthly" : (obj.frequency === "Q" ? "Quaterly" : obj.frequency === "A" ? "Annually": "");
                        fundObj.stepUpSip = obj.stepUpType === "P" ? obj.stepUpValue+"% Annually" : (obj.stepUpType === "A" ? ("<span class='icon-fti_rupee'></span>"+obj.stepUpValue+" Annually") : "NA");
                        if(transactModel.isRetryPaymentInvestorLeg){
                            fundObj.futureDate = $filter('date')(obj.startDate, "dd/MM/yyyy");
                        }                        
                        fundDetails.setFundDetails(fundObj);                         
                    } else {
                        fundObj = obj;
                        fundObj.fundName = obj.fundOptDesc;
                        fundObj.amount = obj.amount;
                        fundObj.dividend = obj.dividendFlag === "R" ? "Re-Investment" : (obj.dividendFlag === "P" ? "Payout" : "NA");
                        fundDetails.setFundDetails(fundObj);                        
                    }
                });
                transactModel.setFundDetails(data.fundOptions);    
                
                var reqParams = {
                    "paymentMode":data.paymentOption,
                    "fundOptions":data.fundOptions,
                    "bankName":data.invPaymentBank,
                    "bankAccountNumber":data.paymentBankAccNo
                };

                if(transactModel.getIsBuy()){
                    reqParams.txnSource = TransactConstant.buy.PURCHASE;
                    if(!transactModel.getBuyReqParams())
                    {
                        transactModel.setBuyReqParams(reqParams);    
                    }                    
                    transactModel.setLumpsumFundDtls(fundDetails.getFundDetails());
                }                

                if(transactModel.getIsSip())
                {
                    reqParams.txnSource = TransactConstant.sip.SIP;
                    if(!transactModel.getSipReqParams())
                    {
                        transactModel.setSipReqParams(reqParams);    
                    }                    
                    transactModel.setSipFundDtls(fundDetails.getFundDetails())
                }                

                //Payment Details
                bankDtlsModel.setSelectedBank(data.invPaymentBank + '-' + data.paymentBankAccNo);                
                bankDtlsModel.setTotalAmount(totalInvAmount);  
                fundDetails.setBuyTotalAmount(totalInvAmount);   
                sipDetailsModel.setSipTotalAmount(totalInvAmount);
                bankDtlsModel.setAccountType(data.accountType);
                bankDtlsModel.setBankAccNumber(data.paymentBankAccNo);
                bankDtlsModel.setBankName(data.invPaymentBank);
                bankDtlsModel.setAccountNo(data.paymentBankAccNo);
                bankDtlsModel.setAchRefNo(data.invAmount);
                bankDtlsModel.setIfscCode(data.ifscCode);
                bankDtlsModel.setFrequency(data.frequency);
                bankDtlsModel.setPeriod()
                bankDtlsModel.setStartDate(data.start_date);
                bankDtlsModel.setEndDate(data.end_date);
                bankDtlsModel.setDistId(data.brokerCode); //Only for Investor Leg
                bankDtlsModel.setBankDetails(data.customerInfoVo.bankdetails); //Only for Investor Leg
                bankDtlsModel.setPaymentMode(data.paymentOption);
                switch(data.paymentOption) {
                    case TransactConstant.common.NET_BANKING_CODE:
                        bankDtlsModel.setPaymentMethod(TransactConstant.transact.NET_BANKING);
                        break;
                    case TransactConstant.common.DEBIT_CARD_CODE:
                        bankDtlsModel.setPaymentMethod(TransactConstant.transact.DEBIT_CARD);
                        break;
                    case TransactConstant.common.EMANDATE_CODE:
                        bankDtlsModel.setPaymentMethod(TransactConstant.transact.SETUP_NEW_MANDATE);
                        break;
                    case TransactConstant.common.BILL_PAY_CODE:
                        bankDtlsModel.setPaymentMethod(TransactConstant.transact.BILL_PAY);
                        break;
                    case TransactConstant.common.NEFT_CODE:
                        bankDtlsModel.setPaymentMethod(TransactConstant.transact.NEFT_RTGS);
                        break;
                    case TransactConstant.common.AUTO_DEBIT_CODE:
                        bankDtlsModel.setPaymentMethod(TransactConstant.transact.AUTO_DEBIT);
                };

                //Investment Preference / Advisor Details

                if(data.brokerCode === TransactConstant.common.DIRECT_INVESTOR_CODE) {
                    investorMode = "direct";
                    paperlessModel.investorPreferenceOption = "direct";
                } else {
                    investorMode = "financial";
                    paperlessModel.investorPreferenceOption = "financial";
                }

                investPref = {
                    "code" : data.brokerCode,
                    "subBrokerCode" : "",
                    "subBrokerArn" : data.brokerCode,
                    "euin" : data.euin_flag === 'Y' ? data.euin : TransactConstant.transact.NO_EUIN,
                    "investorMode" : investorMode
                };
                transactNowModel.setInvestPrefer(investPref);
                transactModel.setAdvDetails(investPref);

                profileDtls = {
                    "profileDetails" : {
                        "ARN" : data.brokerCode
                    }
                };
                profileDetailsModel.setProfileDtls(profileDtls);

                //Nominee Details
                if(scope.flow === "transactnow") {                    
                    if(transactModel.getTransactType()==="BUY") {
                        transactModel.paymentRedirectState = "transactnow.reviewNow.buy";
                    } else if(transactModel.getTransactType()==="SIP"){
                        transactModel.paymentRedirectState = "transactnow.reviewNow.sip";
                    }
                } else if(scope.flow === "advisor") {                    
                    if(transactModel.getTransactType()==="BUY") {
                        transactModel.paymentRedirectState = "txnmaster.review.reviewDetailsBuy";
                    } else if(transactModel.getTransactType()==="SIP"){
                        transactModel.paymentRedirectState = "txnmaster.review.reviewDetailsSIP";
                    } else if(transactModel.getIsModifySIP()) {
                        transactModel.paymentRedirectState = "txnmaster.review.reviewDetailsModifySip";
                    }
                }

                if(transactModel.paymentRedirectState && scope.flow !=="advisor")
                {
                    $state.go(transactModel.paymentRedirectState);    
                }else{

                    //if(transactModel.isRetryPaymentInvestorLeg){
                    var txnDetailsResponseObject = data;                    
                    var advisorDetails = {
                        distValue: data.brokerCode,
                        distFlag: "NC",
                        guId: $location.search().guId
                    }

                    var postAdvisorDetailsSuccess = function(data) {

                        var det = data.distName[0].split('~');
                        var typeHeader = "";
                        switch (txnDetailsResponseObject.txn_source) {
                            case TransactConstant.investorleg.TXN_SOURCE_P:
                                typeHeader = TransactConstant.investorleg.BUY;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIP:
                                typeHeader = TransactConstant.investorleg.SIP;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_S:
                                typeHeader = TransactConstant.investorleg.SWITCH;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_R:
                                typeHeader = TransactConstant.investorleg.REDEEM;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPDTC:
                                typeHeader = TransactConstant.investorleg.SIP_DATE_CHANGE;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPFLX:
                                typeHeader = TransactConstant.investorleg.FLEXIBLE_SIP;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPAMC:
                                typeHeader = TransactConstant.investorleg.CHANGE_SIP_AMOUNT;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPPAS:
                                typeHeader = TransactConstant.investorleg.PAUSE_SIP;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPCAN:
                                typeHeader = TransactConstant.investorleg.SIP_CANCELLATION;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPSUC:
                                typeHeader = TransactConstant.investorleg.STEPUP_CANCELLATION;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPSUP:
                                typeHeader = TransactConstant.investorleg.STEPUP_SIP;
                                break;
                            default:
                                typeHeader = txnDetailsResponseObject.txn_source
                                break;
                    }

                    var trasactionHeader = [{
                        key: TransactConstant.investorleg.TRANSACTIONS,
                        value: typeHeader
                    }, {
                        key: TransactConstant.investorleg.INITIATED_BY,
                        value: det[0] + " | " + det[1] + " | " + det[2]
                    }];

                    transactModel.setTransactHeader(trasactionHeader);
                    $state.go(transactModel.paymentRedirectState); 
                }

                var postAdvisorDetailsFailure = function(data) {

                }

                transactModel.fetchGuestAdvisorDetails(advisorDetails).then(postAdvisorDetailsSuccess, postAdvisorDetailsFailure);

                //}                
                }                
                scope.$broadcast("txnDetailsCompleted",{"transactType":transactModel.getTransactType()});
            }

            function txnDtlsFailure(data) {
                console.log("error");
            }
        },

        getPayDetails : function(scope) {
        	var payDetails = {};

            if(scope.isNewMandate) {
                if(scope.isNewAccount) { //New Mandate - New Account
                    payDetails = {
                        'paymentMethod' : bankDtlsModel.getPaymentMethod(),
                        'futureInstPayMethod' : bankDtlsModel.getFutureInstPayMethod(),
                        'selectedBank' : bankDtlsModel.getSelectedBank(),
                        'futureInstBank' : bankDtlsModel.getFutureInstBank(),
                        'accountType' : bankDtlsModel.getAccountType(),
                        'accountNo' : bankDtlsModel.getAccountNo(),
                        'ifscCode' : bankDtlsModel.getIfscCode(),
                        'branchName' : bankDtlsModel.getBranchName(),
                        'branchAddress' : bankDtlsModel.getBranchAddress(),
                        'amountType' : bankDtlsModel.getAmountType(),
                        'totalAmount' : bankDtlsModel.getTotalAmount(),
                        'frequency' : bankDtlsModel.getFrequency(),
                        'period' : bankDtlsModel.getPeriod(),
                        'startDate' : bankDtlsModel.getStartDate(),
                        'endDate' : bankDtlsModel.getEndDate()
                    };
                } else {  // New Mandate - Existing account
                    payDetails = {
                        'paymentMethod' : bankDtlsModel.getPaymentMethod(),
                        'futureInstPayMethod' : bankDtlsModel.getFutureInstPayMethod(),
                        'selectedBank' : bankDtlsModel.getSelectedBank(),
                        'futureInstBank' : bankDtlsModel.getFutureInstBank(),
                        'totalAmount' : bankDtlsModel.getTotalAmount(),
                        'amountType' : bankDtlsModel.getAmountType(),
                        'frequency' : bankDtlsModel.getFrequency(),
                        'period' : bankDtlsModel.getPeriod(),
                        'startDate' : bankDtlsModel.getStartDate(),
                        'endDate' : bankDtlsModel.getEndDate()
                    };
                }
            } else {  // For all other payment options
                payDetails = {
                    'paymentMethod' : bankDtlsModel.getPaymentMethod(),
                    'selectedBank' : bankDtlsModel.getSelectedBank(),
                    'totalAmount' : bankDtlsModel.getTotalAmount()
                };
            }
            return payDetails;     	
        }
    };
    return paymentDetailsUtility;
};

paymentDetailsUtility.$inject = ['bankDtlsModel', 'transactModel', 'TransactConstant', 'sipDetailsModel', 'fundDetails', 'authenticationService', 'buildPlanModelService', '$stateParams', '$filter', 'transactNowModel', 'profileDetailsModel', 'paperlessModel', '$state', 'investorRegistrationModel', '$location'];
module.exports = paymentDetailsUtility;