// getCgFolio.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var InvCgPortFolioModelSchema = new mongoose.Schema({
    portFolioResp: {
        type: Object,
        'default': {}
    }
});

var InvCgPortFolioModelLookUp = mongoose.model('InvCgPortFolioModelLookUp', InvCgPortFolioModelSchema);

var InvCgPortFolioModel = new InvCgPortFolioModelLookUp({
    portFolioResp: {
        'unitHolderDetails': {
            'invname': 'Deepit Manish Banode Dholkia Motiram Umalkar',
            'address': {
                'address1': 'B-34 Acrot Street No 161 Yerapalli street',
                'address2': 'Vadapallani',
                'address3': 'Yerapalli street',
                'address4': 'Acrot Street No',
                'city': 'Chennai',
                'pinCode': '763001',
                'line1': null,
                'line2': null,
                'line3': null
            },
            "socialStatus": "MINOR THROUGH GUARDIAN"
        },
        'foliodet': [
            {
                'fundName': 'Franklin India Pension Plan-GROWTH',
                'accountNo': '0100007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-24 00:00:00.0',
                    'indexedVal': '8797.27'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '16 dec 2014',
                    'amount': '9791.1'
                },
                'capital': {
                    'shorterm': '993.83',
                    'longterm': '4791.089025'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-24 00:00:00.0',
                    'indexedVal': '8797.26'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '5795.55'
                },
                'capital': {
                    'shorterm': '-3001.71',
                    'longterm': '795.547104'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2008-12-19 00:00:00.0',
                    'indexedVal': '17393.43'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '13919.85'
                },
                'capital': {
                    'shorterm': '-3473.58',
                    'longterm': '4034.1140259'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2009-03-12 00:00:00.0',
                    'indexedVal': '17594.49'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '14712.73'
                },
                'capital': {
                    'shorterm': '-2881.76',
                    'longterm': '4712.7258188'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2009-12-18 00:00:00.0',
                    'indexedVal': '19169.99'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '14450.07'
                },
                'capital': {
                    'shorterm': '-4719.91',
                    'longterm': '2618.6194293'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2010-12-20 00:00:00.0',
                    'indexedVal': '19992.04'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '17026.72'
                },
                'capital': {
                    'shorterm': '-2965.32',
                    'longterm': '3145.5292338'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2011-12-26 00:00:00.0',
                    'indexedVal': '14552.71'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '19915.01'
                },
                'capital': {
                    'shorterm': '5362.31',
                    'longterm': '0'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2012-12-24 00:00:00.0',
                    'indexedVal': '12769.81'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '16246.36'
                },
                'capital': {
                    'shorterm': '3476.55',
                    'longterm': '0'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2014-01-06 00:00:00.0',
                    'indexedVal': '10951.86'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '14383.75'
                },
                'capital': {
                    'shorterm': '3431.89',
                    'longterm': '0'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-GROWTH',
                'accountNo': '0340007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-03-14 00:00:00.0',
                    'indexedVal': '1424.67'
                },
                'redemption': {
                    'txType': 'Redemption',
                    'txDate': '20 apr 2011',
                    'amount': '1459.39'
                },
                'capital': {
                    'shorterm': '34.72',
                    'longterm': '459.3994096'
                },
                'taxded': {
                    'total': '',
                    'stt': '3.64'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-GROWTH',
                'accountNo': '0340007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-11 00:00:00.0',
                    'indexedVal': '17325.24'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '27000.04'
                },
                'capital': {
                    'shorterm': '9674.8',
                    'longterm': '17153.0805204'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007393171',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-24 00:00:00.0',
                    'indexedVal': '17594.49'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '15623.08'
                },
                'capital': {
                    'shorterm': '-1971.41',
                    'longterm': '5623.0836585'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007393171',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2008-12-19 00:00:00.0',
                    'indexedVal': '5156.65'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '6898.76'
                },
                'capital': {
                    'shorterm': '1742.1',
                    'longterm': '3967.9236049'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007393171',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2010-01-18 00:00:00.0',
                    'indexedVal': '5523.85'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '4862.82'
                },
                'capital': {
                    'shorterm': '-661.03',
                    'longterm': '1453.5686391'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007393171',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2011-01-17 00:00:00.0',
                    'indexedVal': '7129.05'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '7115.32'
                },
                'capital': {
                    'shorterm': '-13.73',
                    'longterm': '2165.3627175'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007393171',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2011-01-17 00:00:00.0',
                    'indexedVal': '65.32'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '16 feb 2015',
                    'amount': '66.42'
                },
                'capital': {
                    'shorterm': '1.1',
                    'longterm': '21.0619827'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007393171',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2012-02-06 00:00:00.0',
                    'indexedVal': '2792.59'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '16 feb 2015',
                    'amount': '3433.57'
                },
                'capital': {
                    'shorterm': '640.99',
                    'longterm': '1292.7752006'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-03-07 00:00:00.0',
                    'indexedVal': '7123.41'
                },
                'redemption': {
                    'txType': 'Redemption',
                    'txDate': '20 apr 2011',
                    'amount': '4936.75'
                },
                'capital': {
                    'shorterm': '-2186.66',
                    'longterm': '-63.253113'
                },
                'taxded': {
                    'total': '',
                    'stt': '12.29'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-23 00:00:00.0',
                    'indexedVal': '8797.24'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '7685.8'
                },
                'capital': {
                    'shorterm': '-1111.44',
                    'longterm': '2685.805285'
                },
                'taxded': {
                    'total': '',
                    'stt': '0.12'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-07-01 00:00:00.0',
                    'indexedVal': '17594.53'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '16944.3'
                },
                'capital': {
                    'shorterm': '-650.22',
                    'longterm': '6944.2942688'
                },
                'taxded': {
                    'total': '',
                    'stt': '0.26'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2008-12-19 00:00:00.0',
                    'indexedVal': '11236.54'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '15032.65'
                },
                'capital': {
                    'shorterm': '3796.11',
                    'longterm': '8646.2560469'
                },
                'taxded': {
                    'total': '',
                    'stt': '0.23'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2010-01-18 00:00:00.0',
                    'indexedVal': '12036.62'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '10596.21'
                },
                'capital': {
                    'shorterm': '-1440.41',
                    'longterm': '3167.3667594'
                },
                'taxded': {
                    'total': '',
                    'stt': '0.16'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2011-01-17 00:00:00.0',
                    'indexedVal': '15271.45'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '15242.03'
                },
                'capital': {
                    'shorterm': '-29.42',
                    'longterm': '4638.5169837'
                },
                'taxded': {
                    'total': '',
                    'stt': '0.23'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2011-01-17 00:00:00.0',
                    'indexedVal': '405.27'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '16 feb 2015',
                    'amount': '412.07'
                },
                'capital': {
                    'shorterm': '6.8',
                    'longterm': '130.676535'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India TAXSHIELD-DIVIDEND',
                'accountNo': '0350007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Dividend Reinv.',
                    'txDate': '2012-02-06 00:00:00.0',
                    'indexedVal': '5764.75'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '16 feb 2015',
                    'amount': '7087.95'
                },
                'capital': {
                    'shorterm': '1323.2',
                    'longterm': '2668.6833352'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India High Growth Companies Fund-GROWTH',
                'accountNo': '2730007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2009-03-09 00:00:00.0',
                    'indexedVal': '6743.99'
                },
                'redemption': {
                    'txType': 'Redemption',
                    'txDate': '20 apr 2011',
                    'amount': '13890.16'
                },
                'capital': {
                    'shorterm': '7146.17',
                    'longterm': '8890.161372'
                },
                'taxded': {
                    'total': '',
                    'stt': '34.64'
                }
            }, {
                'fundName': 'Franklin India High Growth Companies Fund-GROWTH',
                'accountNo': '2730007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2009-03-12 00:00:00.0',
                    'indexedVal': '13488'
                },
                'redemption': {
                    'txType': 'Redemption',
                    'txDate': '20 apr 2011',
                    'amount': '27483.39'
                },
                'capital': {
                    'shorterm': '13995.39',
                    'longterm': '17483.3908894'
                },
                'taxded': {
                    'total': '',
                    'stt': '68.53'
                }
            }, {
                'fundName': 'Franklin India High Growth Companies Fund-GROWTH',
                'accountNo': '2730007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2009-05-19 00:00:00.0',
                    'indexedVal': '6210.41'
                },
                'redemption': {
                    'txType': 'Redemption',
                    'txDate': '20 apr 2011',
                    'amount': '7952.03'
                },
                'capital': {
                    'shorterm': '1741.62',
                    'longterm': '2952.0326662'
                },
                'taxded': {
                    'total': '',
                    'stt': '19.83'
                }
            }
        ],
        "accdetails": [{
        "fundName": "Franklin India PRIMA FUND-DIVIDEND",
        "accountNo": "0010000181939",
        "purchase": {
            "txType": "Purchase",
            "txDate": "1993-11-30 00:00:00.0",
            "indexedVal": "514.63"
        },
        "redemption": {
            "txType": "STP Out",
            "txDate": "10 jul 2015",
            "amount": "999.97"
        },
        "capital": {
            "shorterm": "485.34",
            "longterm": "883.8080064"
        },
        "taxded": {
            "total": "11.54",
            "stt": "0"
        }
    }, {
        "fundName": "Franklin India PRIMA FUND-DIVIDEND",
        "accountNo": "0010000181939",
        "purchase": {
            "txType": "Purchase",
            "txDate": "1993-11-30 00:00:00.0",
            "indexedVal": "514.63"
        },
        "redemption": {
            "txType": "STP Out",
            "txDate": "20 aug 2015",
            "amount": "999.97"
        },
        "capital": {
            "shorterm": "485.34",
            "longterm": "883.8080064"
        },
        "taxded": {
            "total": "11.54",
            "stt": "0"
        }
    }, {
        "fundName": "Franklin India PRIMA FUND-DIVIDEND",
        "accountNo": "0010000181939",
        "purchase": {
            "txType": "Purchase",
            "txDate": "1993-11-30 00:00:00.0",
            "indexedVal": "816.07"
        },
        "redemption": {
            "txType": "STP Out",
            "txDate": "01 sep 2015",
            "amount": "1000.02"
        },
        "capital": {
            "shorterm": "183.95",
            "longterm": "815.818116"
        },
        "taxded": {
            "total": "11.54",
            "stt": "0"
        }
    }, {
        "fundName": "Franklin India PRIMA FUND-DIVIDEND",
        "accountNo": "0010000181939",
        "purchase": {
            "txType": "Purchase",
            "txDate": "1993-11-30 00:00:00.0",
            "indexedVal": "771.72"
        },
        "redemption": {
            "txType": "STP Out",
            "txDate": "01 oct 2015",
            "amount": "1000.01"
        },
        "capital": {
            "shorterm": "228.29",
            "longterm": "825.8191129"
        },
        "taxded": {
            "total": "11.54",
            "stt": "0"
        }
    }, {
        "fundName": "Franklin India PRIMA FUND-DIVIDEND",
        "accountNo": "0010000181939",
        "purchase": {
            "txType": "Purchase",
            "txDate": "1993-11-30 00:00:00.0",
            "indexedVal": "688.47"
        },
        "redemption": {
            "txType": "STP Out",
            "txDate": "06 nov 2015",
            "amount": "999.97"
        },
        "capital": {
            "shorterm": "311.49",
            "longterm": "844.56792"
        },
        "taxded": {
            "total": "11.54",
            "stt": "0"
        }
    }, {
        "fundName": "Franklin India PRIMA FUND-DIVIDEND",
        "accountNo": "0010000181939",
        "purchase": {
            "txType": "Purchase",
            "txDate": "1993-11-30 00:00:00.0",
            "indexedVal": "657.82"
        },
        "redemption": {
            "txType": "STP Out",
            "txDate": "10 dec 2015",
            "amount": "999.98"
        },
        "capital": {
            "shorterm": "342.17",
            "longterm": "851.503104"
        },
        "taxded": {
            "total": "11.54",
            "stt": "0"
        }
    }]
    }
});

InvCgPortFolioModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvCgPortFolioModelLookUp table, please contact admin...');
    } else {
        InvCgPortFolioModelLookUp.remove({}, function(err) {
            console.log('InvCgPortFolioModelLookUp collection removed');
            InvCgPortFolioModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvCgPortFolioModelLookUp table, please contact admin...');
                }
                console.log('InvCgPortFolioModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvCgPortFolioModelLookUp;
