var log4js = require('log4js');
var winston = require('winston');
var expressWinston = require('express-winston');
var fs = require('fs');
var path = require('path');

var logDirectory = path.join(__dirname, '../../log');
// ensure log directory exists
var logDir = fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

var now = new Date();
var month = now.getMonth() + 1;
month = (month < 10 ? "0" : "") + month;
var day = now.getDate();
day = (day < 10 ? "0" : "") + day;


log4js.configure({
    "appenders": [{
            "category": "access",
            "type": "dateFile",
            "filename": path.join(logDirectory, 'log4js-access-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            "pattern": "-yyyy-MM-dd",
            "backups": 10
        }, {
            "category": "inbounddata",
            "type": "dateFile",
            "filename": path.join(logDirectory, 'log4js-inbound-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            "pattern": "-yyyy-MM-dd",
            "backups": 10
        }, {
            "category": "outbounddata",
            "type": "dateFile",
            "filename": path.join(logDirectory, 'log4js-outbound-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            "pattern": "-yyyy-MM-dd",
            "backups": 10
        }, {
            "category": "error",
            "type": "dateFile",
            "filename": path.join(logDirectory, 'log4js-error-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            "pattern": "-yyyy-MM-dd",
            "backups": 10
        }, {
            "category": "conversation",
            "type": "dateFile",
            "filename": path.join(logDirectory, 'log4js-conversation-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            "pattern": "-yyyy-MM-dd",
            "backups": 10
        }
        /*, {
                "type": "console"
            }*/
    ],
    "levels": {
        "access": "ALL",
        "inbounddata": "ALL",
        "outbounddata": "ALL",
        "conversation": "ALL",
        "error": "ERROR"
    }
});

var winstonLogConfig = {
    transports: [
        new winston.transports.File({
            level: 'info',
            name: 'info-file',
            filename: path.join(logDirectory, 'all-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            handleExceptions: true,
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: false
        }),
        new winston.transports.File({
            level: 'error',
            name: 'error-file',
            filename: path.join(logDirectory, 'err-logs_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            handleExceptions: true,
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: false
        })
    ],
    msg: "HTTP {{req.method}} {{req.url}}",
    exitOnError: false
};

module.exports = {
    access: log4js.getLogger('access'),
    inBoundData: log4js.getLogger('inbounddata'),
    outBoundData: log4js.getLogger('outbounddata'),
    error: log4js.getLogger('error'),
    conversation: log4js.getLogger('conversation'),
    express: log4js.connectLogger(log4js.getLogger('access'), { level: log4js.levels.INFO }),
    winstonExpress: expressWinston.logger(winstonLogConfig),
    formatReqMsg: function(req, res) {
        req.session = req.session || {};
        return 'Session Id: ' + req.session.id + ' HTTP ' + req.method + " " + req.url + '\n Req Params: ' + JSON.stringify(req.params) + ' Req Body: ' + JSON.stringify(req.body);
    },
    formatResMsg: function(req, res) {
        req.session = req.session || {};
        res = res || {};
        return 'Session Id: ' + req.session.id + ' HTTP ' + req.method + " " + req.url + ' Response: ' + JSON.stringify(res);
    },
    formatInBoundReqMsg: function(req, res, data, sessionId) {
        data = data || '{}';
        return 'Session Id: ' + sessionId + ' HTTP ' + req.method + " " + req.host + ' ' + req.path + ' Req: ' + JSON.stringify(req) + ' Req Body: ' + JSON.stringify(data);
    },
    formatInBoundResMsg: function(req, res, sessionId) {
        res = res || {};
        return 'Session Id: ' + sessionId + ' HTTP ' + req.method + " " + req.host + ' ' + req.path + ' Response: ' + JSON.stringify(res);
    },
    formatConvsStrtMsg: function(req, sessionId) {
        req.session = req.session || {};
        req.body.RequestParams = req.body.RequestParams || {};
        this.conversation.info('/******************* Initiated Conversation With Session Id(' + req.session.id + ') *******************/');
        this.conversation.info('Nick Name: ' + req.session.nickName);
        this.conversation.info('Agent Group ID: ' + req.session.agentGroupID);
        this.conversation.info('Acc Role: ' + req.session.accRole);
        this.conversation.info('MDN: ' + req.session.MDN);
        this.conversation.info('Initial Message: ' + req.body.RequestParams.InitialMessage);
        this.conversation.info('============================================================================================');
    }

};
