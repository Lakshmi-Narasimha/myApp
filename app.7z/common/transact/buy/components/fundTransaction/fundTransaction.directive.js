



    /**
 * @ngdoc property
 * @name Switch Form Directive
 * @requires $state
 * @requires $timeout
 * @requires 
 * @description
 *
 * - Switch form directive will represent the form details of switch module in transact controller.
 *
 **/
 'use strict';

 var fundReviewConfirm = function(sipDetailsModel) {
 	return {
 		template: require('./fundTransaction.html'),
 		restrict: 'E',
        scope: {
        },
 		controller:['$scope', function($scope){  	
 			$scope.tileDetails = sipDetailsModel.getSipDetails();
            $scope.infoObj=[];
            angular.forEach($scope.tileDetails, function(obj, key){
                $scope.infoObj.push([
                    {
                        text: "Fund Name",
                        value: $scope.tileDetails[key].fundOptDesc
                    },
                    {
                        text: "Amount",
                        value: "<span class='icon-fti_rupee'></span>"+$scope.tileDetails[key].amount
                    },
                    {
                        text: "Dividend",
                        value: $scope.tileDetails[key].dividendFlag === "R" ? "Re-Investment" : ($scope.tileDetails[key].dividendFlag === "P" ? "Payout" : "NA")
                    }
                ]);
            })
 		}]
 	};

 };

 fundReviewConfirm.$inject = ['sipDetailsModel'];
 module.exports = fundReviewConfirm;