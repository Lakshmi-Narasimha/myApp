/**
 * @ngdoc property
 * @name fticFolioDetReviewConfirm Directive
 *
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Details.
 *
 **/
'use strict';

var fticFolioDetReviewConfirm = function (eventConstants, TransactConstant,transactModel,authenticationService) {
    return {
        template: require('./FolioDetReview.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            if(transactModel.getFolioDetailsObj() !== null) {
                $scope.keyValuePairs = [
                    {
                        text: 'Folio No',
                        value: transactModel.getFolioDetailsObj().folioId
                    },
                    {
                        text: 'First Holder',
                        value: transactModel.getFolioDetailsObj().firstHolder
                    },
                    {
                        text: 'PAN',
                        value: authenticationService.getUser().pan
                    },
                    {
                        text: 'Email',
                        value: authenticationService.getUser().emailId
                    },
                    {
                        text: 'Mobile',
                        value: authenticationService.getUser().mobile
                    },
                    {
                        text: 'Second Holder',
                        value: transactModel.getFolioDetailsObj().secondHolder || "NA"
                    },
                    {
                        text: 'Third Holder',
                        value: transactModel.getFolioDetailsObj().thirdHolder || "NA"
                    }
                ];
            }

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event){            
                $scope.$emit('NAVIGATE_TO_TRANSACTNOW', {key: 'Folio'});
                $event.stopPropagation(); 
            }); 
        }]
    };
};

fticFolioDetReviewConfirm.$inject = ['eventConstants', 'TransactConstant','transactModel','authenticationService'];
module.exports = fticFolioDetReviewConfirm;