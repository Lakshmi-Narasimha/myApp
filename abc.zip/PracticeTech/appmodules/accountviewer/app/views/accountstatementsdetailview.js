﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'config',
  'text!appmodules/accountviewer/app/templates/acstatementtemplate.html',
], function ($, _, Backbone, Spinner, Config, AccountStatementTemplate) {
    var globalCv = null;
    var accountstatementsDetailView = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
        },
        initialize: function () {
            var self = this;
        },
        render: function (options) {
            var _that = this;
            console.log('Coming Here');
        }
    });
    return accountstatementsDetailView;
});