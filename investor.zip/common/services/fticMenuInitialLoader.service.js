/**
 * @ngdoc service
 * @name recommendations inital loader service
 * @requires recommendationsModel
 * @requires guestEvents
 * @requires guestEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Recommendations inital loader will set the data and braodcast an event on success and consoles error on failure.
 *
 */
'use strict';

var globalMenuInitLoader = function (events, fticMenuModel, fticLoggerMessage, loggerConstants, $timeout) {
    
    var globalMenuInitLoader = {
        _isServicesData: false,     
        loadAllServices : function (scope) {
           
            fticMenuModel.fetchMenuData()
                .then(menuDataSuccess, menuDataFailure);
            function menuDataSuccess(data) {
                globalMenuInitLoader._isServicesData = true;
                fticMenuModel.setHeaderData(data);
                fticMenuModel.setFooterData(data);
                events.publishMenuDetails(scope);    
            };

            function menuDataFailure (data) {
                console.error('handleFailure');
                globalMenuInitLoader._isServicesData = false;
            };
        }
    };
    return globalMenuInitLoader;
};

globalMenuInitLoader.$inject = ['events','fticMenuModel', 'fticLoggerMessage', 'loggerConstants', '$timeout'];

module.exports = globalMenuInitLoader;

