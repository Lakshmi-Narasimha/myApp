'use strict';

var recommendedPlanInitialLoader = function (recommendedPlanModelService, investorEvents, authenticationService, $loader) {

    var recommendedPlanInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope) {

            recommendedPlanModelService.fetchRecommendedPlan()
                .then(recommendedPlanSuccess, handleFailure);

            function recommendedPlanSuccess(data) {
                recommendedPlanModelService.setRecommendedPlanDtls(data[0]);
                investorEvents.smartSolutions.publishRecommendedPlan(scope,recommendedPlanModelService.getRecommendedPlanDtls());

            }

            function handleFailure(data){
                console.error('handleFailure');
                recommendedPlanInitialLoader._isServicesData = false;
            }
        },
        loadPanlLevelServices : function (pan, $scope) {
            function stopLoader() {
                $loader.stop();
            }
            $loader.start();

            var params = {
                "folioPanAccNo" : pan,//"COFQI1209M",//investorGoalModelService.setSelectedInvestorDetails().pan or $scope.selectedInvestor.pan
                "fsFlag" : "Y",
                "guId" : authenticationService.getUser() ? authenticationService.getUser().guId : null
            };
            recommendedPlanModelService.getPanLevelSummary(params)
                .then (function (data) {                
                recommendedPlanModelService.setpanLevelSummaryFS(data.investmentSummary);
                $scope.$broadcast('panLevelInvModalEvent', 'FS');
            }, function (data) {
                console.log("ERROR");
            }).finally(stopLoader);

            var params1 = {
                "folioPanAccNo" : pan,//"COFQI1209M",//investorGoalModelService.setSelectedInvestorDetails().pan or $scope.selectedInvestor.pan
                "fsFlag" : "N",
                "guId" : authenticationService.getUser() ? authenticationService.getUser().guId : null
            };
            recommendedPlanModelService.getPanLevelSummary(params1)
                .then (function (data) {
                recommendedPlanModelService.setpanLevelSummaryNFS(data.investmentSummary);
                var fsFlag = 'N';
                $scope.$broadcast('panLevelInvModalEvent');
            }, function (data) {
                console.log("ERROR");
            });
        }

    };
    return recommendedPlanInitialLoader;
};

recommendedPlanInitialLoader.$inject = ['recommendedPlanModelService', 'investorEvents', 'authenticationService','$loader'];

module.exports = recommendedPlanInitialLoader;