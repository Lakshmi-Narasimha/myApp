/**
 * @ngdoc property
 * @name  FamilyPortfolioAccessController Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function FamilyPortfolioAccessController($scope,fticFTUserAccessDetailsLoadInitialService,familyPortfolioUserAccessModel,investorEvents,investorEventConstants,toaster,$loader,$filter,investorConstants) {
    $scope.init = function(){
		$scope.userAccessTemplate = false;
		var FPGA_USER_ADDED_SUCC_MSG = $filter('translate')(investorConstants.accountsettings['FPGA_USER_ADDED_SUCC_MSG']);
		$scope.$on(investorEventConstants.accountSettings.USER_ACCESS_LIST,function(){
			$scope.userAccessDataList = familyPortfolioUserAccessModel.getFamilyUserAccessPFList().getUserAccessDetails;
			fticFTUserAccessDetailsLoadInitialService._isServicesData = true;
			$scope.userAccessTemplate = true;
		});
		if(!fticFTUserAccessDetailsLoadInitialService._isServicesData){
			fticFTUserAccessDetailsLoadInitialService.loadAllServices($scope);
		}else{
			investorEvents.accountSettings.getUserAccessDetailsList($scope);
		}
		$scope.$on(investorEventConstants.accountSettings.USER_ACCESS_DELETE,function(){
			fticFTUserAccessDetailsLoadInitialService._isServicesData = false;
			fticFTUserAccessDetailsLoadInitialService.loadAllServices($scope);
		});
		$scope.userName = {
            text: 'User Name',
            type:'text',
            value: '',
            isRequired: true,
            errorMessage:''
        };
		$scope.onNew = function(){
			$scope.userAccessTemplate = !$scope.userAccessTemplate;
		};
		$scope.onSubmit = function(){
			$loader.start();
			$scope.params = {
				accessType:'AD',
				userId:$scope.userName.value
			};
	        familyPortfolioUserAccessModel.removeOrAddGrantAccess($scope.params).then(function () {
				$scope.userAccessTemplate = !$scope.userAccessTemplate;
				$scope.userName.errorMessage = '';
				toaster.success($scope.userName.value + " " + FPGA_USER_ADDED_SUCC_MSG);
				fticFTUserAccessDetailsLoadInitialService._isServicesData = false;
				fticFTUserAccessDetailsLoadInitialService.loadAllServices($scope);
				$scope.userName.value = '';
	        },function(error){
				if(error && error.data && error.data.length > 0) {
					//toaster.error(error.data[0].errorDescription);
					$scope.userName.errorMessage = 'Please enter a valid username.';
				}
				
	        }).finally(function(){
                $loader.stop();
            });
		};
		$scope.cancel = function(){
			$scope.userName.errorMessage = '';
			$scope.userName.value = '';
			$scope.userAccessTemplate = !$scope.userAccessTemplate;

		};
    };
    $scope.init();
}
FamilyPortfolioAccessController.$inject = ['$scope','fticFTUserAccessDetailsLoadInitialService','familyPortfolioUserAccessModel','investorEvents','investorEventConstants','toaster','$loader','$filter','investorConstants'];
module.exports = FamilyPortfolioAccessController;