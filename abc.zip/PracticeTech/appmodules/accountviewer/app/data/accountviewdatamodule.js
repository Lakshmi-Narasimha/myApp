﻿define(['jquery', 'underscore', 'backbone', 'services/dataservice', 'errorLog', 'appcommon/globalcontext', 'spinner', 'appcommon/commonutility', ],
		function ($, _, Backbone, DataService, ErrorLog, GlobalContext, Spinner, CommonUtility) {
		    var loadModule = function () {
		        var self = this;
		        this.getAccountViewData = function (callback) {
		            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
		            var callbackresponseObject = { "accountingDateResp": null, "accountViewResp": null },
                        _groupId = _gContext.GroupId,
                        _fmId = CommonUtility.readCookie('FMID'),
                        _clientId = _gContext.ContactId;
		            DataService.promiseToGetAccountingDates([400, 401, 404, 500])
                            .then(function (response) {
                                callbackresponseObject.accountingDateResp = response;
                                loadAccountList();
                            })
                            .fail(function (error) {
                                loadAccountList();
                            });
		            function loadAccountList() {
		                DataService.getAccountView(_groupId, _fmId, _clientId).then(function (response) {
		                    callbackresponseObject.accountViewResp = response;
		                    callback(callbackresponseObject);
		                }).fail(function (xhr) {
		                    ErrorLog.ErrorUtils.myError(xhr);
		                });
		            };
		        }
		       
		    }
		    return new loadModule();
		});