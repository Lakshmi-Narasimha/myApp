/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
//function planSmartSolutionController($scope, $state,buildPlanModelService,$http) {
    function planSmartSolutionController($scope, $state,$http) {
    $scope.paymentDtls = {};
    $scope.fundDtls ={};
    $scope.reviewDtls = {};
    $scope.transactionDtls = {};

    // $scope.paymentDtls.paymentDtlsState = "smartSol.planSmartSolution.paymentdetailsSS.investment";
    // $scope.fundDtls.fundDtlsState = "smartSol.planSmartSolution.fundDetailsSS.investment";
    // $scope.reviewDtls.reviewDtlsState = "smartSol.planSmartSolution.reviewnconfirm.investment";
    // $scope.transactionDtls.transactionDtlsState = "smartSol.planSmartSolution.transactionDetailsSS.investment";
	// $state.go("smartSol.planSmartSolution.selectSS");

    $scope.$on('customizeDetailsApply',function(event, data){
        console.log("customizeDetailsApply",data);
        if(data.currentState.indexOf('bcustomizeplan') !==-1) {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.buildplan.bmycustomizeplan');   
        }
        else {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rmycustomplan');      
        }
         
    }); 
    $scope.$on('kycEvent', function(){
        $state.go("smartSol.planSmartSolution.ssBase.planInputDetails");
      // $state.go("smartSol.planSmartSolution.ssBase");
    })             

}
planSmartSolutionController.$inject = ['$scope', '$state','$http'];
//planSmartSolutionController.$inject = ['$scope', '$state','buildPlanModelService','$http'];
module.exports = planSmartSolutionController;