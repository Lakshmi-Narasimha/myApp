'use strict';
describe('Directive: fticRedemptionReviewDetails', function() {
	var compile,scope,directiveElement,isolatedScope,redeemModel,authenticationService,$window;
	
	var advisor = false;

	beforeEach(angular.mock.module('advisor'));	    

	var getCompiledElement = function(){
		var element = angular.element('<ftic-redemption-review-details></ftic-redemption-review-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope,_$compile_,$window,_$filter_,_toaster_,_authenticationService_,_TransactConstant_,_fundDetailsModel_,_$stateParams_,_$timeout_,_transactEventConstants_,_transactModel_,_$state_,$httpBackend,_RegisteredBankInitLoader_,_RegisteredBankModel_,_frequencyOptionsModel_,_ifscModel_,_reviewSwpDetailsModel_,_redeemModel_,_transactEvents_,_populateUnitsModel_,_redeemInitialLoader_) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};
          
            authenticationService = _authenticationService_;            
            redeemModel = _redeemModel_;            
            
            if(advisor){
            	authenticationService.setUser({                                        
        			"userId" : "test123"        
        		});	
            }

            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();      
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variable keyValuePairs on load and show NA if data not available',function(){
    	expect(isolatedScope.keyValuePairs[0].text).toBe('Type');
    	expect(isolatedScope.keyValuePairs[1].text).toBe('Amount');
    	expect(isolatedScope.keyValuePairs[2].text).toBe('Units');
    	expect(isolatedScope.keyValuePairs[3].text).toBe('Bank Details');
    	expect(isolatedScope.keyValuePairs[4].text).toBe('Mode of Payment');

    	expect(isolatedScope.keyValuePairs[0].value).toBe('NA');
    	expect(isolatedScope.keyValuePairs[1].value).toBe('NA');
    	expect(isolatedScope.keyValuePairs[2].value).toBe('NA');
    	expect(isolatedScope.keyValuePairs[3].value).toBe('NA');
    	expect(isolatedScope.keyValuePairs[4].value).toBe('NA');
    });

    it('should define the variable keyValuePairs on load if investor logged in(if redemption type selected is full)',function(){
    	redeemModel.setType('Full');
        redeemModel.setAmount('');
        redeemModel.setUnits('8371.015');
        redeemModel.setMode('Cheque');
        redeemModel.setBank('CITI BANK - 7335300411');

     	directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();

    	expect(isolatedScope.keyValuePairs[0].text).toBe('Type');
    	expect(isolatedScope.keyValuePairs[1].text).toBe('Amount');
    	expect(isolatedScope.keyValuePairs[2].text).toBe('Units');
    	expect(isolatedScope.keyValuePairs[3].text).toBe('Bank Details');
    	expect(isolatedScope.keyValuePairs[4].text).toBe('Mode of Payment');

    	expect(isolatedScope.keyValuePairs[0].value).toBe('Full');
    	expect(isolatedScope.keyValuePairs[1].value).toBe('NA');
    	expect(isolatedScope.keyValuePairs[2].value).toBe('8371.015');
    	expect(isolatedScope.keyValuePairs[3].value).toBe('CITI BANK - 7335300411');
    	expect(isolatedScope.keyValuePairs[4].value).toBe('Cheque');    	
    });

    it('should define the variable keyValuePairs on load if investor logged in(if redemption type selected is Units)',function(){
    	redeemModel.setType('Units');
        redeemModel.setAmount('');
        redeemModel.setUnits('8371.015');
        redeemModel.setMode('Direct Credit');
        redeemModel.setBank('CITI BANK - 7335300411');

     	directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();

    	expect(isolatedScope.keyValuePairs[0].value).toBe('Partial');
    	expect(isolatedScope.keyValuePairs[1].value).toBe('NA');
    	expect(isolatedScope.keyValuePairs[2].value).toBe('8371.015');
    	expect(isolatedScope.keyValuePairs[3].value).toBe('CITI BANK - 7335300411');
    	expect(isolatedScope.keyValuePairs[4].value).toBe('Direct Credit');    	
    	advisor = true;
    });

	it('should define the variable keyValuePairs on load if advisor logged in(if redemption type selected is full)',function(){
    	redeemModel.setType('Full');
        redeemModel.setAmount('');
        redeemModel.setUnits('8371.015');
        redeemModel.setMode('Cheque');
        redeemModel.setBank('CITI BANK - 7335300411');

     	directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();

    	expect(isolatedScope.keyValuePairs[0].text).toBe('Type');
    	expect(isolatedScope.keyValuePairs[1].text).toBe('Amount');
    	expect(isolatedScope.keyValuePairs[2].text).toBe('Units');
    	expect(isolatedScope.keyValuePairs[3].text).toBe('Bank Details');
    	expect(isolatedScope.keyValuePairs[4].text).toBe('Mode of Payment');

    	expect(isolatedScope.keyValuePairs[0].value).toBe('Full');
    	expect(isolatedScope.keyValuePairs[1].value).toBe('');
    	expect(isolatedScope.keyValuePairs[2].value).toBe('8371.015');
    	expect(isolatedScope.keyValuePairs[3].value).toBe('CITI BANK - 7335300411');
    	expect(isolatedScope.keyValuePairs[4].value).toBe('Cheque');    	
    });    
});  