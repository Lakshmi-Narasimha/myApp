// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetTxnSipModelSchema = new mongoose.Schema({
    GetTxnSipResp: {
        type: Array,
        "default": []
    }
});

var GetTxnSipModelLookUp = mongoose.model('GetTxnSipModelLookUp', GetTxnSipModelSchema);

var GetTxnSipModel = new GetTxnSipModelLookUp({
    GetTxnSipResp : {
  "customerInfoVo": {
    "custName": "APARNA THANDAVAN UDAY KANAKIA SOFTA",
    "address1": "214 - A HAMILTON COURT",
    "address2": "12TH FLOOR 1201 DALAMAL TOWERS",
    "address3": "DUGRI LUDHIANA",
    "address4": "NEAR MALVIYA NAGAR",
    "city": "HONG KKONG",
    "pinCode": "400097",
    "firstHolderName": "APARNA THANDAVAN UDAY KANAKIA SOFTA",
    "secondHolderName": "",
    "thirdHolderName": "",
    "guardian": "",
    "firstHolderPanNo": "CIPQF5143I",
    "secondHolderPanNo": "",
    "thirdHolderPanNo": "",
    "guardianPanNo": "",
    "firstHolderKycStatus": "KYC - Registered",
    "secondHolderKycStatus": "KYC - Registered",
    "thirdHolderKycStatus": "KYC - Registered",
    "guardianKycStatus": "",
    "socialStatus": "Individual",
    "holdingType": "Single",
    "bankdetails": "328186545006566/BANK OF INDIA/MUMBAI",
    "paymentType": "",
    "paymentMode": "Directly To Bank"
  },
  "retrieveSipVo": null,
  "fundOptions": [
    {
      "accNo": "0389905405842",
      "amount": "0",
      "direct": "",
      "dividendFlag": null,
      "endDate": "",
      "frequency": "",
      "fundCategory": "",
      "fundOptDesc": "",
      "fundOption": "614",
      "fundType": "",
      "minAddPurAmt": "",
      "minNewPurAmt": "",
      "minSipAmt": "",
      "multiples": "",
      "nfoFlag": null,
      "payoutFlag": "",
      "perpetualFlag": "",
      "reinvestmentFlag": "",
      "startDate": "",
      "stepUpFrequency": "",
      "stepUpType": "",
      "stepUpValue": "",
      "txnType": ""
    }
  ],
  "invPaymentBank": "BANK OF INDIA",
  "paymentMode": "",
  "folioId": "18158116",
  "accountType": null,
  "paymentBankAccNo": "328186545006566",
  "invAmount": "",
  "subBrokerCode": "ARN-75320",
  "subBrokerARN": null,
  "euin": null,
  "txn_no": "SIP000078",
  "seq_no": "1",
  "account_number": "",
  "fund_option": "",
  "batch_code": "web",
  "trxn_requested_date": "2016-08-01 00:00:00.0",
  "trxn_requested_time": "10:00",
  "txn_source": "SIPSUP",
  "sub_distributor_id": null,
  "ref_txn_no": "PT22512011",
  "application_sr_no": null,
  "remarks": null,
  "maker_id": "Mobile",
  "maker_date": "2016-03-15 00:00:00.0",
  "auth_id": "Mobile",
  "auth_date": "2016-03-15 00:00:00.0",
  "acc_ref_no": null,
  "transferflag": "1",
  "trtype": null,
  "web_refno": "SIP000078",
  "transaction_flag": "C",
  "mode_of_txn": null,
  "euin_flag": null,
  "trxn_units": null,
  "all_units_flag": null,
  "start_date": "",
  "end_date": "",
  "frequency": null,
  "perpetual_flag": null,
  "mf_code": null,
  "destination_account_number": null,
  "destination_fund_option": null,
  "sip_txn_status": null,
  "urn_no": null,
  "nfo_flag": "",
  "priority_batch_flag": null,
  "trxn_effective_date": "2016-08-01 00:00:00.0",
  "amount_unit_flag": null,
  "dc_last_xdigits": null,
  "dc_name_on_card": null,
  "check_no": null,
  "dividend_option": "",
  "account_source": "RWD",
  "branch_code": "BR0105",
  "no_of_installments": null,
  "lbd_flag": null,
  "umrn_no": null,
  "source": "10",
  "renewal_flag": null,
  "paymentOption": "O",
  "aadhaar": "",
  "pepFlag": "",
  "stepUpType": "A",
  "stepUpValue": "1000",
  "emandateDebitType": null,
  "emandateFrequency": null,
  "emandateAmount": null,
  "untillCancel": null,
  "emandateFromdate": null,
  "emandateTodate": null,
  "stepUpFrequency": null
}
});

GetTxnSipModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetTxnSipModelLookUp table, please contact admin...');
    } else {
        GetTxnSipModelLookUp.remove({}, function(err) {
            console.log('GetTxnSipModelLookUp collection removed');
            GetTxnSipModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetTxnSipModelLookUp table, please contact admin...');
                }
                console.log('GetTxnSipModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GetTxnSipModelLookUp;