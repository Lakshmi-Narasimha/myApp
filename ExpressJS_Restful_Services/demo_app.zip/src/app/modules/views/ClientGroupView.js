define([
    'jquery',
    'lodash',
    'backbone',
    'bootstraptypeahead',
    'q',
    'config',
    'app/common/spinner',
    'app/common/shadowLayer',
    'app/common/util',
    'app/common/constants',
    'app/common/validate.js',
    'app/common/views/AbstractView',
    'app/application/router',
    'app/application/app',
    'app/services/awmService',
    'app/modules/models/ClientListModel',
    'app/modules/models/clientHouseholdGroupModel',
    'app/services/currentContext',
    'text!app/modules/templates/ClientGroupView.html'
], function ($, _, Backbone, BootstrapTypeahead, Q, config, Spinner, shadow, util, constants, Validator, AbstractView, router, app, awmService, ClientListModel, ClientHouseholdGroupModel, currentContext, ClientGroupViewTemplate) {

    return AbstractView.extend({
        el: '#sem-app-primary-view',
        template: _.template(ClientGroupViewTemplate),
        initialize: function(){
            let self = this;
            self.householdGroupData = [];
            self.primaryClName = '';
            self.clientData = {};
            $(document).off('click', '#cs-shadow-box').on('click', '#cs-shadow-box', function (e) {
                self.showHideShadow();
            });

            $(document).off('click', '.group-list input[name=optradio]').on('click', '.group-list input[name=optradio]', function (e) {
                $(self).blur();
            });
        },
        events: {
            "click #cl-btn-cancel": "cancel",
            "click #cs-household-component li a.group": "householdChanged",
            "click #submit-client-group":"validateForm"
        },
        render: function () {
            this.clientHouseholdGroupModel = new ClientHouseholdGroupModel();
			var clientId = currentContext.context.get('clientIds')[0];
			this.selectedClientId = clientId;
			this.callClientService(clientId);
        },
        cancel: function() {
            router.routeTo('clientSearchView');
        },
        householdChanged: function (event) {
            const selHouseholdId = this.$(event.currentTarget).attr('id');
            this.selHouseholdGroupName = selHouseholdId;
            const selHouseholdGroup = this.clientHouseholdGroupModel.filterByFmtId(selHouseholdId);
            const id = (selHouseholdGroup && selHouseholdGroup.value) ? selHouseholdGroup.value.id: '';
            this.callPlanningGroupDetails(selHouseholdGroup);
            window.scrollTo(0,0);
        },
        callClientService: function(clientId){
            const self = this;
            Spinner.show({
                parentElement: "sem-app-primary-view",
            });
            awmService.promiseToGetClienDetails(clientId).then((data) => {
                let activeGroups = data.activeGroups.results|| [];
                activeGroups.sort(function(a, b) { return Number(b.id) - Number(a.id); });
                self.clientActiveGroups = activeGroups.reverse();
                let groupId = activeGroups[0]? activeGroups[0].id : '';
                groupId = groupId.slice(5,groupId.length);
                self.clientData = data || {};
                self.clientData.fmtName = self.clientData.personClient ? (self.clientData.personClient.clFirstNm+' '+self.clientData.personClient.clLastNm) : '';
                self.clientData.fmtName = _.startCase(_.toLower(self.clientData.fmtName));
                self.populateClientGroup();
            }).fail(error=>this.handlerServiceError(error));
        },
        isHouseholdGroup: function(group){
            return group ? group.id.slice(0,3) === '001' : false;
        },
        populateClientGroup: function(){
            const self = this;
            let modifgroup= [];
            let pensionGrp = [];
            let asyncGrpMembCallList = [];
            this.clientActiveGroups.forEach((srtGroup, i) => {
                if(self.isHouseholdGroup(srtGroup)){
                    asyncGrpMembCallList.push(awmService.promiseToGetListActiveClientsByGroup(srtGroup.id));
                }
            });
            Spinner.show({
                msg: "Loading search results"
            });
            Q.allSettled(asyncGrpMembCallList).then(gotoclientGroupActiveMembers, this.handleServiceError);
            function gotoclientGroupActiveMembers(groupmem) {
                self.householdGroupData = groupmem;
                self.clientHouseholdGroupModel.setHouseholdGroups(groupmem);
                self.primaryClName = self.clientData.personClient ? (self.clientData.personClient.clFirstNm +' ' +self.clientData.personClient.clLastNm) : '';
                self.clientData.groupId = groupmem[0].value.fmtId;
                self.callPlanningGroupDetails(groupmem[0]);
                Spinner.hide();
            }

        },
        showHideShadow: function(){
            let $targetId = $("#cs-household-component");
            if($targetId.css("display") != 'block'){
                shadow.show({
                    parentElement: this.$el
                });
            }else{
                shadow.hide({
                    parentElement: this.$el
                });
            }
        },
        callPlanningGroupDetails: function (groupmem) {
            let self = this;
            const group = (groupmem && groupmem.value) ? groupmem.value : {};
            //awmService.promiseToGetFinancialPlanningGroupDetails(group).then(function(planningGroupDetails) {
            let planningGroupDetails = {
                "value": [
                    {
                        "finPlnGrpId": "812590b7-8f36-4741-bc4f-ba14e29533c9",
                        "finPlnGrpCtx": "FPH.PLNGRP",
                        "prmClId": "00100000000000014945606",
                        "prmClCtx": "COLA.CL",
                        "coClId": "00100000000000014945618",
                        "coClCtx": "COLA.CL",
                        "grpId": "00100004339121",
                        "grpCtx": "COLA.GRP",
                        "finPlnGrpStatCd": "ACTIVE",
                        "finPlnGrpSttDt": "2017-08-23 14:05:06.0",
                        "finPlnGrpEndDt": "9999-12-31 00:00:00.0",
                        "plnSysCd": "MGP"
                    }
                ]
            };
                planningGroupDetails = planningGroupDetails ? planningGroupDetails.value : [];
                self.selectedHouseholdGroup = self.clientHouseholdGroupModel.planningGroupDetails(groupmem, self.primaryClName, planningGroupDetails);
                self.populateUI();
            //});
        },
        handlerServiceError: function(){
            Spinner.hide();
            this.populateUI();
        },
        validateForm: function(){
            let $userErrorNote = $('#userErrorNote');
            if (Validator.validateInputs('client-group-form', true)) {
                $userErrorNote.addClass('hidden');
                $('.has-error').removeClass('has-error');
                app.selClientId = null;
                router.routeTo('clientSearchView');
                window.open(config.launchMgpUrl, '_blank');
            }else{
                $userErrorNote.removeClass('hidden');
            }
        },
        populateUI: function () {
            const responseData = {
                clientInfo: this.clientData,
                groupData: this.householdGroupData,
                formattedGroupInfo: this.selectedHouseholdGroup,
                launchMgpUrl : config.launchMgpUrl
            };
            this.$el.html(this.template(responseData));
            this.$('#cs-householdgrp-btn').text(this.selHouseholdGroupName);

            $("#cs-householdgrp-btn").on("show.bs.dropdown", function(event){
                Shadow.show({
                    parentElement: '#sem-app-primary-view'
                });
            });

            $("#cs-householdgrp-btn").on("hide.bs.dropdown", function(event){
                Shadow.hide({
                    parentElement: '#sem-app-primary-view'
                });
            });
        }
    });

});
