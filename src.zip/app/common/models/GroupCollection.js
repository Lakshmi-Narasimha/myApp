define(['jquery', 'lodash', 'backbone', 'app/common/models/Group'
], function ($, _, Backbone, Group) {
    var GroupCollection = Backbone.Collection.extend({
        model: Group,
        populateFromGroupListResponse: function (groupListRes) {
            if (groupListRes && groupListRes.length > 0) {
                var self = this;
                _.each(groupListRes, function (group) {
                    self.add(group.toJSON());
                });
            }
            return this;
        },
        filterByFmtId: function (fmtId) {
            const result = _.filter(this.models, (groupModel) => {
                return groupModel.get('fmtId') == fmtId;
            })[0];
            return result;
        },
        sortFun: function(a,b){
            a = a.groupMemNames.toLowerCase();
            b = b.groupMemNames.toLowerCase();
            if (b < a) return 1;
            if (b > a) return -1;
            return 0;
        },
        planningGroupDetails: function (householdGroupData, priClient, planningGroupData) {
            let data = [];
            let mgpGroupArr = [];
            let nonMgpGroupArr = [];
            let group = householdGroupData;
            let activeClients = group.activeClients || [];
            let mgpClient = null;
            let nonMgpClient = null;
            let priClName = priClient.personClient ? (priClient.personClient.clFirstNm+' '+priClient.personClient.clLastNm) : '';
            if (group && activeClients) {
                _.each(group.activeClients.results, (client) => {
                    let person = client.personClient;
                    if (person) {
                        let coClientName = person.clFirstNm + ' ' + person.clLastNm;
                        coClientName = _.startCase(_.toLower(coClientName));
                        priClName = _.startCase(_.toLower(priClName));
                        let fmtName = (priClName === coClientName) ? priClName : (priClName + ', ' + coClientName);
                        let temp = {
                            groupMemNames: fmtName
                        };
                        let mgpGroup ;
                        mgpGroup = _.find(planningGroupData, (mGroup) => {
                            return mGroup.get('coClId') == client.id || mGroup.get('prmClId') == client.id;
                        });
                        // if( fmtName.indexOf(',') === -1){
                        //     mgpGroup = _.find(planningGroupData, (mGroup) => {
                        //         return mGroup.get('prmClId') == client.id;
                        //     });
                        // }
                        temp.plnSysName = (mgpGroup && mgpGroup.get('plnSysCd') === 'MGP') ? 'MoneyGuidePro Group' : 'Create MoneyGuidePro Group';
                        //fmtName.indexOf(',') === -1 ? data.unshift(temp) : data.push(temp);
                        temp.priClient = priClient;
                        temp.coClient = client;
                        if(temp.plnSysName == 'MoneyGuidePro Group'){
                            fmtName.indexOf(',') === -1 ? mgpClient= temp : mgpGroupArr.push(temp);
                        } else{
                            fmtName.indexOf(',') === -1 ? nonMgpClient =temp : nonMgpGroupArr.push(temp);
                        }
                    }
                });
            }
            mgpGroupArr = mgpGroupArr.sort(this.sortFun);
            nonMgpGroupArr = nonMgpGroupArr.sort(this.sortFun);
            mgpClient ? mgpGroupArr.unshift(mgpClient) :  null;
            nonMgpClient ? nonMgpGroupArr.unshift(nonMgpClient) : null;
            data = mgpGroupArr.concat(nonMgpGroupArr);
            return data;
        }
    });

    return GroupCollection;
});