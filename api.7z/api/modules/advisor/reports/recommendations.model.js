// getRecommendationsReport.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RecommendationReportModelSchema = new mongoose.Schema({
    recommendationReportResp: {
        type: Array,
        "default": []
    }
});

var RecommendationReportModelLookUp = mongoose.model('RecommendationReportModelLookUp', RecommendationReportModelSchema);

var RecommendationReportModel = new RecommendationReportModelLookUp({
    recommendationReportResp : {
      "recommendations": [
                {
                    "dateOfRecommendation":"16 may 2016",
                    "Title": "Brokrage Paid out report",
                    "type" : "excel",
                    "data" : "https://rouskmportal.cognizant.com/sites/rouskmportal/Customers/Cognizant%40FT/ProjectArtifacts/User%20Stories/Advisor%20User%20Stories/Reports/User%20Story_Custom%20Reports_v0.5%20-%20Sign%20Off.doc"
                },
                {
                    "dateOfRecommendation":"17 may 2015",
                    "Title": "Brokrage Paid out report",
                    "type" : "pdf",
                    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA=="
                },
                {
                    "dateOfRecommendation":"18 may 2016",
                    "Title": "Brokrage Paid out report",
                    "type" : "excel",
                    "data" : "https://rouskmportal.cognizant.com/sites/rouskmportal/Customers/Cognizant%40FT/ProjectArtifacts/User%20Stories/Advisor%20User%20Stories/Reports/User%20Story_Custom%20Reports_v0.5%20-%20Sign%20Off.doc"
                },
                {
                    "dateOfRecommendation":"16 may 2016",
                    "Title": "Brokrage Paid out report",
                    "type" : "pdf",
                    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA=="
                }
        ]
        
    }
});

RecommendationReportModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating RecommendationReportModelLookUp table, please contact admin...');
    } else {
        RecommendationReportModelLookUp.remove({}, function(err) {
            console.log('RecommendationReportModelLookUp collection removed');
            RecommendationReportModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RecommendationReportModelLookUp table, please contact admin...');
                }
                console.log('RecommendationReportModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RecommendationReportModelLookUp;