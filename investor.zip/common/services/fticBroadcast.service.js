/**
 * @ngdoc service
 * @name Common FTIC Broadcast
 * @description
 *
 * - Common method for broadcasting events for app level
 *
 */


'use strict';

var fticBroadcast = function(eventConstants) {
	return {
		eventBroadcast : function (scope, eventName, eventData, paramName) {
			var data = {};
			data[paramName] = eventData;
			scope.$broadcast(eventName, data);
		},
		fticLoader : function (scope, data) {
			var message = data.msg || "Please Wait...";
        	scope.$emit(eventConstants.LOADER_MESSAGE, data);
		}
	};
	
};

fticBroadcast.$inject = ['eventConstants'];
module.exports = fticBroadcast;
