/**
 * @ngdoc property
 * @name Dashboard Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function DashboardController($scope, $timeout, investorEvents, dashboardConstants, investorEventConstants, authenticationService, investorDashboardInitialServices, investorDashboardDetailsModel, appConfig, loggerConstants, fticLoggerMessage, configUrlModel, investorDashboardInvestServices, $state, toaster, investorConstants) {
    $scope.init = function() {

        var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_CONTROLLER + ' | init' /* Function Name */ ;
        fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
        $scope.quickLinks = dashboardConstants.dashboard.QUICK_LINKS;
        $scope.imgClass = 'img-responsive mb';
        $scope.recommendations = [];
        if (authenticationService.getUser()) {
            if (investorDashboardInitialServices._isServicesData) {
                $timeout(function() {

                    investorEvents.dashboard.investorDashboardInformation($scope);
                    investorEvents.dashboard.investorSmartSaveAccAndOneTouch($scope);
                    investorEvents.dashboard.investorSmartSolutions($scope);
                }, 0);
            } else {
                // To Load the initial services
                investorDashboardInitialServices.loadAllServices($scope);
                investorDashboardInitialServices._isServicesData = true;
            }
        }

        $scope.$on(investorEventConstants.Dashboard.INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH, function() {
            $scope.imageData = investorDashboardDetailsModel.getSmartSaveAccAndOneTouchData().banner;
            var configURL = configUrlModel.getEnvUrl('MARKETING_URL');
            $scope.absURL = $scope.imageData.image.indexOf('http') !== -1 ? (investorConstants.investorImageRoot + $scope.imageData.image) : (appConfig[configURL] + investorConstants.investorImageRoot + $scope.imageData.image);
            $scope.link = $scope.imageData.link.indexOf('http') !== -1 ? $scope.imageData.link : appConfig[configURL] + $scope.imageData.link;
        });

        $scope.$on('showConfirm', function(event, confirmObj) {
            $scope.confirmObj = confirmObj;
        });
        $scope.$on('hideConfirm', function(event, confirmObj) {
            $scope.confirmObj.showConfirm = false;
        });
        $scope.$on('submitConfirm', function(event, confirmObj) {
            $scope.confirmObj.showConfirm = false;
            var validateParams = {};
            investorDashboardInvestServices.investConfirmCall(validateParams);
            $timeout(function() {
                var isConfirm = investorDashboardDetailsModel.getConfirmData();
                if (!isConfirm) {
                    if ($scope.confirmObj.popUpBody.labelText === 'Purchase') {
                        toaster.error('Sorry! Your Purchase was unsuccessful, Please check Purchase Instructions or contact Franklin Templeton customer service for assistance.');
                    } else {
                        toaster.error('Sorry! Your Redemption was unsuccessful, Please check Redeem Instructions or contact Franklin Templeton customer service for assistance.');
                    }

                } else if (isConfirm.transactionValidated === 'true') {
                    investorDashboardInitialServices.loadAllServices($scope);
                }
            }, 0);
        });

        $scope.$on('setInstruction', function(event, confirmObj) {
            $scope.confirmObj.showConfirm = false;
            $state.transitionTo('smartsavingsaccount');

        });
    };
    $scope.init();
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.

DashboardController.$inject = ['$scope', '$timeout', 'investorEvents', 'dashboardConstants', 'investorEventConstants', 'authenticationService', 'investorDashboardInitialServices', 'investorDashboardDetailsModel', 'appConfig', 'loggerConstants', 'fticLoggerMessage', 'configUrlModel', 'investorDashboardInvestServices', '$state', 'toaster', 'investorConstants'];
module.exports = DashboardController;
