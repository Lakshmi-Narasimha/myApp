/**
+ * @ngdoc property
+ * @name SWP Controller
+ * @requires $scope
+ * @requires fticLoggerMessage
+ * @requires loggerConstants
+ * @description
+ *
+ * - Pull the information while calling the services.
Add a comment to this line
+ *
+ **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function RenewSipController($scope, fticLoggerMessage, loggerConstants, transactModel) {
    $scope.header.title = 'Renew a SIP';
    $scope.config.txnFormDetails.title = 'SIP Renewal Details';
    console.log("renew sip");
    //console.info("SWP Controller!!"+$scope.header);
    
    // swpInitialLoader.loadAllServices($scope);
    // transactModel.isSWP = true;
}
RenewSipController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants',  'transactModel'];
module.exports = RenewSipController;