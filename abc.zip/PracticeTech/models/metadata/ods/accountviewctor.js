﻿define(['jquery', 'backbone', 'breeze'
], function ($, Backbone, Breeze) {
    var DT = Breeze.DataType; // alias 
    function initialize(metadataStore) {
        metadataStore.addEntityType({
            shortName: "overviewAccount",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,          
            //defaultResourceName: "overviewAccount",
            dataProperties: {
                id: { dataType: DT.String, isNullable: false, isPartOfKey: true },
                ctx: { dataType: DT.String, isNullable: false, isPartOfKey: true },
                fmtId: { dataType: DT.String },
                statusCd: { dataType: DT.String },
                adminCd: { dataType: DT.String },
                productCd: { dataType: DT.String },
                subProductCd: { dataType: DT.String },
                taxQualCd: { dataType: DT.String },
                acctTypCd: { dataType: DT.String },
                iraTypeCd: { dataType: DT.String },
                iraStatCd: { dataType: DT.String },
                carrierNm: { dataType: DT.String },
                planId: { dataType: DT.String },
                setlCd: { dataType: DT.String },
                ownshpCd: { dataType: DT.String },
                ownshpDesc: { dataType: DT.String },
                oldOwnshpCd: { dataType: DT.String },
                openDt: { dataType: DT.String },
                closeDt: { dataType: DT.String },
                accountProduct: { name: "accountProduct", complexTypeName: "accountProduct:#com.ameriprise.awm.api", isScalar: true },
                accountBalance: { name: "accountBalance", complexTypeName: "accountBalance:#com.ameriprise.awm.api", isScalar: true },
                accountRegistration: { name: "accountRegistration", complexTypeName: "accountRegistration:#com.ameriprise.awm.api", isScalar: true },
                qualifiedPlan: { name: "qualifiedPlan", complexTypeName: "qualifiedPlan:#com.ameriprise.awm.api", isScalar: true },
                accountIdentifier:{ isNullable:true,name: "accountIdentifier", complexTypeName: "accountIdentifier:#com.ameriprise.awm.api"},
            }
        });
        metadataStore.addEntityType({
            shortName: "accountProduct",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            //defaultResourceName: "accountProduct",
            dataProperties: {
                acctId: { dataType: DT.String },
                acctCtx: { dataType: DT.String },
                longNm: { dataType: DT.String },
                mediumNm: { dataType: DT.String },
                shortNm: { dataType: DT.String },
                strategyCd: { dataType: DT.String },
                strategyNm: { dataType: DT.String },
                brkgProdClsNm: { dataType: DT.String },
                brkgProdClsCd:{ dataType: DT.String },
                invSecrShrtDesc: { dataType: DT.String },
                invSecrLongDesc: { dataType: DT.String },
                invSecrCusipNbrTxt: { dataType: DT.String },
            }
        });
        metadataStore.addEntityType({
            shortName: "accountBalance",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            dataProperties: {
            	availCashForTran: { dataType: DT.String },
            	availCredForTran: { dataType: DT.String },
            	ctx: { dataType: DT.String },
            	dthBenfAmt: { dataType: DT.String },
            	id: { dataType: DT.String },
            	totAcctBal: { dataType: DT.String },
            	valueDt: { dataType: DT.String }
            }
        });
        metadataStore.addEntityType({
            shortName: "accountRegistration",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            dataProperties: {
            	acctCtx: { dataType: DT.String },
            	acctId: { dataType: DT.String },
            	legalTitle1Txt: { dataType: DT.String },
            	legalTitle2Txt: { dataType: DT.String },
            	legalTitle3Txt: { dataType: DT.String },
            	legalTitle4Txt: { dataType: DT.String },
            	legalTitle5Txt: { dataType: DT.String }
            }
        });
        metadataStore.addEntityType({
            shortName: "qualifiedPlan",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            dataProperties: {
            	acctCtx: { dataType: DT.String },
            	acctId: { dataType: DT.String },
            	planTypCd: { dataType: DT.String },
            	planTypLngDesc: { dataType: DT.String },
            	planTypShrtDesc: { dataType: DT.String }
            }
        });
        metadataStore.addEntityType({
            shortName: "dstrOverviewProcessingStatus",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            dataProperties: {
                statCd: { dataType: DT.String },
                statDesc: { dataType: DT.String },              
            },
        });
        metadataStore.addEntityType({
            shortName: "accountIdentifier",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            //defaultResourceName: "accountIdentifier",
            dataProperties: {
            	acctCtx: { dataType: DT.String,isNullable:true},
            	acctId: { dataType: DT.String,isPartOfKey: true,isNullable:true  },
            	//altAcctId:{ dataType: DT.String,isPartOfKey: false,isNullable:true  },
            	alternateAccountIdentifiers:{name: "alternateAccountIdentifiers", complexTypeName: "alternateAccountIdentifiers:#com.ameriprise.awm.api" },
            }
            
            
                 
        }); 
        metadataStore.addEntityType({
            shortName: "alternateAccountIdentifiers",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            dataProperties: {
            results:{name: "results", complexTypeName: "results:#com.ameriprise.awm.api", isScalar: false },
           
            }   
                 
        }); metadataStore.addEntityType({
            shortName: "results",
            namespace: "com.ameriprise.awm.api",
            isComplexType: true,
            dataProperties: {
            altAcctId: { dataType: DT.String },
            altAcctCtx: { dataType: DT.String },
            }   
                 
        }); 
        metadataStore.addEntityType({
            shortName: "getDistributorOverview",
            namespace: "com.ameriprise.awm.api",
            defaultResourceName: "getDistributorOverview",
            autoGeneratedKeyType: breeze.AutoGeneratedKeyType.Identity,
            dataProperties: {
                grpId: { dataType: DT.String, isNullable: false, isPartOfKey: true },
                grpCtx: { dataType: DT.String, isNullable: false, isPartOfKey: true },                             
                overviewAccount: { name: "overviewAccount", complexTypeName: "overviewAccount:#com.ameriprise.awm.api", isScalar: false },
                dstrOverviewProcessingStatus: { name: "dstrOverviewProcessingStatus", complexTypeName: "dstrOverviewProcessingStatus:#com.ameriprise.awm.api" },              
            },           
        });  
    }  
    var accountviewctor = {
        initialize: initialize        
    };
    return accountviewctor;
});
