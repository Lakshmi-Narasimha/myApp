﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'config',
  'appcommon/constants',
  'appcommon/data',
  'appcommon/analytics',
  'text!appmodules/accountviewer/app/templates/acstatementtemplate.html',
  'text!appmodules/accountviewer/app/templates/accountconsolidatedstmts.html',
  'appmodules/accountviewer/app/views/accountportfolioView',
  'appcommon/commonutility',
  'services/dataservice',
  'appcommon/globalcontext',
  'errorLog',
   'text!appmodules/accountviewer/app/templates/accountdelvrysettingandstatmntarrgmnt.html',
'apipublic/navapi',
'appcommon/applauncher/device',

'appcommon/commonutility',
'appmodules/contactprofile/app/models/cpviewmodel',
'appmodules/contactprofile/app/models/preferenceviewmodel',
'text!appmodules/accountviewer/app/templates/accounttaxstatements.html',
'appcommon/nativeadaptor',
'commonjqueryplugins'
], function ($, _, Backbone, Spinner, Config, Constants, StatementsDummyData, Analytics, AccountStatementTemplate, AccountConsolidatedStmtsTemplate, accountportfolioView, CommonUtils, DataService, GlobalContext, ErrorLog, DeliverySettingsTemplate, NavApi, Device, CommonUtilis, CPViewModel, PreferenceViewModel, TaxStatementsList, NativeAdaptor) {
	var self = null;
	var storeAmeriReg = '', storePriEmail = '', storePriEmailUnReg = false;
	var accountstatementsView = Backbone.View.extend({
		el: $("#practicetech-subapp"),
		id: 'practicetech-subapp',
		events: {
		},
		initialize: function () {
			var that = this;
			self = this;
			this.hasOnly147Accts;
			this.recentActivityCollection = [];
			this.deliverySettingsAndStatementsData = null;
			this.statementListModel = [];
			this.taxStatmntObj = {
			    "taxStatementsData": null,
			    "processingTaxStatements": false,
			    "errorOccured": false
			};
			this.statementsDescListSortValue = {
			    "CONSOLIDATED STATEMENTS ANNUAL": 1,
			    "ANNUAL INSURANCE REPORT": 2,
			    "CONSOLIDATED STATEMENTS MONTHEND": 3,
			    "CONSOLIDATED STATEMENTS": 4,
			};
			
			this.deliverySettings = {
				"name": null,
				"filteredClients": [],
				"admnCd": null,
				"grpId": null,
				"grpData": null,
				"delivMethod": null,
				"servExecuteFlag" : false,
			};
			$(document).off('click', '.acc-tmp-conatiner .pl-drawer .expand-collapse').on('click', '.acc-tmp-conatiner .pl-drawer .expand-collapse', function (e) {
			    var _$target= $(e.currentTarget), $drawerTrgtId = $(e.currentTarget).attr('data-id'), _clId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
			    if ($drawerTrgtId == "delivery-settings-stmts") {
			        if (self.deliverySettingsAndStatementsData == null && _$target.hasClass("closed")) {
			    		if (self.deliverySettings.servExecuteFlag == true) {
			    			self.finalNoServiceCallhandler();
			    		} else {
			            self.getDeliverySettingAndStatementsDate(_clId);
			        }
			        }
			        self.customToggleHeader(e);
			        if (_$target.hasClass('closed')) {
			            Analytics.analytics.recordAction('AccountStatements:View Statement delivery and arrangement settings:clicked');
			        }
			    } else if ($drawerTrgtId == "tax-stmts") {
			        if (self.taxStatmntObj.taxStatementsData === null && self.taxStatmntObj.processingTaxStatements == false && _$target.hasClass("closed")) {
			            self.taxStatmntObj.processingTaxStatements = true;
			            self.getTaxStatementsList(GlobalContext.getInstance().getGlobalContext().Context.GroupId, _clId);
			        }
			        if (_$target.hasClass('closed')) {
			            Analytics.analytics.recordAction('AccountStatements:Expand Of Tax Statements:clicked');
			        }
			    }
			    
                CommonUtils.plDrawerToggle(e);
			});

			$(document).off("click", ".sorting").on("click", ".sorting", function (e) {
			    self.plSortLists(e);
			});

			$(document).off('click', "[data-toggle='plToggleViewEdit'] .plViewDetails, [data-toggle='plToggleViewEdit'] .plEditDetails").on('click', "[data-toggle='plToggleViewEdit'] .plViewDetails, [data-toggle='plToggleViewEdit'] .plEditDetails", function (e) {
			    CommonUtils.toggleViewEdit(e);

			});
			$(document).off('click', ".eforms-linkout").on('click', ".eforms-linkout", self.linkoutToEform);
			$(document).off('click', ".linkOFM").on('click', ".linkOFM", this.linkoutToOFM);
			$(document).off('click', ".statements-internal-link").on('click', ".statements-internal-link", self.launchInternalLinks);
			$(document).off("click", "#SecureSiteRegLink").on("click", "#SecureSiteRegLink", function (e){that.routeToSecureSite(e);});
			$(document).off('click', ".statements-pdf-doc-link").on('click', ".statements-pdf-doc-link", this.getDocumentBase64Dta);
			window.onafterprint = function () {
				if (window.location.hash === '#accountviewer/accountstatements') {
					Analytics.analytics.recordAction('Print:StatementsTab');
				}
			};
		},
		validate147Accounts: function (callback, data) {
		    if (this.hasOnly147Accts === undefined) {
		        var _gContext = GlobalContext.getInstance().getGlobalContext().Context,
		        _grpId = this.grpId,
                _clientId = _gContext.ContactId,
                _fmId = CommonUtils.readCookie('FMID'),
                _acctsList,
                _countOf147Accts = 0,
                _hasOnly147Accts = false;
		        DataService.getAccountView(_grpId, _fmId, _clientId).then(function (response) {
		            if (response && response.results && response.results[0] && response.results[0].get("overviewAccount")) {
		                _acctsList = response.results[0].get("overviewAccount");
		            }
		            if (_acctsList && _acctsList.length > 0) {
		                _hasOnly147Accts = self.get147OnlyAccountsFlag(_acctsList);
		                self.hasOnly147Accts = _hasOnly147Accts;
		                if (_hasOnly147Accts) {
		                    self.show147AccountDialog(callback, data);
		                } else {
		                    callback(data);
		                }
		            } else {
		                callback(data);
		            }
		        }).fail(function (xhr) {
		            callback(data);
		            ErrorLog.ErrorUtils.myError(xhr,true);
		        });
		    } else {
		        if (this.hasOnly147Accts) {
		            self.show147AccountDialog(callback, data);
		        } else {
		            callback(data);
		        }
		    }
		    
		},
		get147OnlyAccountsFlag: function (acctsList) {
		    var _countOf147Accts = 0, _hasOnly147Accts = false;
		    acctsList.forEach(function (acct) {
		        if (acct.get("adminCd") == 147 && acct.get("statusCd") == "ACTIVE") {
		            _countOf147Accts++;
		        }
		    });
		    if (acctsList.length === _countOf147Accts) {
		        _hasOnly147Accts = true;
		    }
		    return _hasOnly147Accts;
		},
		show147AccountDialog: function (callback, data) {
		    var _dialogBody = "The client does not have any statements generated at this time. If you complete this request, it will be processed when the first statement is issued." +
                              "<br><br>" +
                              "Do you wish to set up this request?"
		    BootstrapDialog.show({
		        title: 'Edit',
		        message: _dialogBody,
		        closeByBackdrop: true,
		        buttons: [
                        {
                            label: 'Yes',
                            cssClass: 'btn pt-btn-yes generic-button btn-primary',
                            action: function (dialog) {
                                dialog.close();
                                callback(data);
                            }
                        },
                        {
                            label: 'No',
                            cssClass: 'btn pt-btn-yes generic-button btn-primary',
                            action: function (dialog) {
                                dialog.close();
                            }
                        }]
		    });

		},
		renderDataInTempalte: function (collection) {
			collection = (!collection) ? this.recentActivityCollection : collection;
			var accountstatementTemplate = _.template(AccountStatementTemplate);
			$(".acc-tmp-conatiner").html(accountstatementTemplate({ data: collection }));
		},
		render: function (options) {
		    window.scrollTo(0, 0);
			emailSendValdRules = undefined;
			var _that = this;
			this.hasOnly147Accts = undefined;
			this.grpId = options.groupId;
			if (options.groupId == undefined || options.groupId == null) {
				var accountstatementTemplate = _.template(AccountStatementTemplate);
				$(".acc-tmp-conatiner").html(accountstatementTemplate({ data: options.groupId }));
			} else {
				_that.renderDataInTempalte();
				self.getStatementsList();
			}   
			$(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
			$(".hdr-tab-buttons-wrap .av-statements").addClass("hdr-tab-active");
		},
		afterRender: function () {

		},
		plSortLists: function (e) {
		    var _$this = $(e.currentTarget);
		    var _$thisSpan = _$this.find("span.sorticons");
		    var _desc = false;
		    var sortField = _$this.data('sort-key');
		    _$thisSpan.addClass('active');
		    $('.sorting').find('.sorticons:not(.active)').removeClass('asc-icon desc-icon');
		    $('.sorticons').removeClass('active');
		    if (_$thisSpan.hasClass("desc-icon")) {
		        _$thisSpan.removeClass("desc-icon").addClass("asc-icon");
		        _desc = false;
		    }
		    else if (_$thisSpan.hasClass("asc-icon")) {
		        _$thisSpan.removeClass("asc-icon").addClass("desc-icon");
		        _desc = true;
		    }
		    else {
		        _$thisSpan.addClass("asc-icon");
		        _desc = false;
		    }
		    var _sortKey = _$this.data("sort")

		    if (_$this.hasClass("cons-st-sorticons")) {
		        if (self.statementListModel && self.statementListModel.length > 1) {
		            self.statementListModel.sort(CommonUtilis.sortMultiColumn({
		                name: _sortKey,
		                reverse: _desc
		            }, "docTypeSortVal", "combinedAddressLine"));
		            self.reRenderConsolidatedStatementsList(self.statementListModel);
		        }
		    } else if (_$this.hasClass("tax-st-sorticons")) {
		        if (self.taxStatmntObj.taxStatementsData && self.taxStatmntObj.taxStatementsData.length > 1) {
		            self.taxStatmntObj.taxStatementsData.sort(CommonUtilis.sortMultiColumn({
		                name: _sortKey,
		                reverse: _desc
		            }, "clientSortingIndex"));
		            self.reRenderTaxStatementsList(self.taxStatmntObj.taxStatementsData);
		        }
		    }
		},
		customToggleHeader: function (obj) {
		    var $drawerTrgt = $(obj.currentTarget);
		    var $drawerTrgtId = $(obj.currentTarget).attr('data-id');
		    var $drawerTrgtDataCont = $("[data-content=" + $drawerTrgtId + "]");
		    var isCollapsed = $drawerTrgtDataCont.css('display') == 'none';

		    //Special custom condition for Delivery Setting Statements Section
		    if ($drawerTrgtId == "delivery-settings-stmts") {
		        var $trgtParent = $drawerTrgt.parent();
		        if (!isCollapsed) {
		            $trgtParent.addClass('col-xs-12').removeClass('col-xs-7');
		            $trgtParent.next().addClass('hidden-xs');
		        } else {
		            $trgtParent.addClass('col-xs-7').removeClass('col-xs-12');
		            $trgtParent.next().removeClass('hidden-xs');
		        }
		    }
		},
		getDeliverySettingAndStatementsDate: function (clId) {
			var _self = this;
		    var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
		    var _grpId = _gContext.GroupId, _activeClients = [], _admnCd = "", _filteredClients = [], _clientList = [];
		    var _pinnedClient = NavApi.getSelecetdContactdetails(_gContext.AdvisorFMID, _gContext.ContactId);
		    var _name = _pinnedClient.orgNm !== undefined ? _pinnedClient.orgNm : (_pinnedClient.firstNm + " " + _pinnedClient.lastNm);
		    var delivMethod = "", _grpData = "";
			
		    var grpStmtDone = false;
		    var clientServPrefDone = false;
		    var clientGrpLocalDone = false;
		    var clientGrpCounter = 0;
		    var clientDelivCounter = 0;
		    var clientGrpDoneCounter = 0;
		    var clientDelivDoneCounter = 0;
			var clientDelivDoneCounterForOnline = 0;			
			
		    DataService.getClientgroupLocal(clId)
				.then(getGroupClients)
				.fail(function (xhr) {
					_filteredClients = "servicefails";
					ErrorLog.ErrorUtils.myError(xhr, true);
					clientGrpLocalDone = true;
					whenAlways();
				});

		    function getGroupClients(clientGroups) {
		        var _activeGroups = clientGroups.results[0].get("activeGroups");
		        var _selectedGroup = _activeGroups.find(function (group) {
		            return _grpId == group.get("id");
		        }); 
		        _admnCd = _selectedGroup.get("adminCode");		        

		        if (_admnCd == "002") {
		        	var _currClient = _selectedGroup.get("currClient");
		        	DataService.getClientServPref(_currClient).done(function (response) {
		        		getDeliveryMethod(response);
		        	}).fail(function (xhr) {
		        		delivMethod = "servicefails";
		        		ErrorLog.ErrorUtils.myError(xhr, true);
		        	}).always(function () {
		        		clientServPrefDone = true;
		        		whenAlways();
		        	});

		        	clientGrpLocalDone = true;
		        	whenAlways();
		        } else {
		        	_activeClients = _selectedGroup.get("activeClients");
		        	_clientList = _selectedGroup.get("activeClients");
		        	if (!Array.isArray(_activeClients)) {
		        		_activeClients = []; _filteredClients = [];
		        		clientGrpLocalDone = true;
		        		whenAlways();
		        	} else {
		        		gotoClientPersonalDetails(_activeClients);
		        		gotoClientServPref(_activeClients);
		        	}
		        }

		    }
		    function gotoClientServPref(_activeClients) {
		    	clientDelivCounter = _activeClients.length;
		    	_.each(_activeClients, function (list, keys) {		    		
		    		DataService.getClientServPref(list.id).done(function (response) {
		    			getDeliveryMethod(response);
		    		}).fail(function (xhr) {
		    			delivMethod = "servicefails";
		    			ErrorLog.ErrorUtils.myError(xhr, true);
		    		}).always(function () {
		    			clientDelivDoneCounter++;
		    			if (clientDelivCounter === clientDelivDoneCounter) {
							if (delivMethod == "U.S. mail" && (clientDelivDoneCounterForOnline !== clientDelivCounter)) {
								delivMethod = "Unknown";
							}
		    				clientServPrefDone = true;
		    				whenAlways();
		    			}
		    		});
		    	});
		    };
		    function getDeliveryMethod(response) {
		    	var delivResult = response.d.results;
		    	if(delivResult.length != 0 || delivResult != "") {
					clientDelivDoneCounterForOnline++;
		    		if (delivMethod == "Online") {
		    			delivMethod = "Online";
		    		} else {
		    			delivMethod = "";
		    			_.each(delivResult, function (list, keys) {
		    				if (list.typCd == "Paper Suppression" && list.subTypCd == "Consolidated Statement" && list.valCd == "Yes") {
		    					delivMethod = "Online";
		    				} else if (list.typCd == "Paper Suppression" && list.subTypCd == "Consolidated Statement" && list.valCd == "No") {
		    					delivMethod = "U.S. mail";
		    				}
		    			});
		    		}
		    		if (delivMethod != "Online" && delivMethod != "U.S. mail") {
		    			delivMethod = "Unknown";
		    		}
		    	} else {
		    		delivMethod = "";
		    	}
		    };
		    function gotoClientPersonalDetails(_activeClients) {
		    	clientGrpCounter = _activeClients.length;
		    	_.each(_activeClients, function (list, keys) {
		    		DataService.getClientPersonalDetails(list.id).done(function (response) {
		    			var dob = response.d.bthDt;
		    			if (dob != null && dob != " " && dob != "" && dob.length != 0) {
		    				var year = Number(dob.substr(0, 4));
		    				var month = Number(dob.substr(5, 2)) - 1;
		    				var day = Number(dob.substr(9, 2));
		    				var today = new Date();
		    				var age = today.getFullYear() - year;
		    				if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) { age--; }
		    				if ((age != null && age >= 18) && (response.d.decsdInd != 'Y')) {
		    					_filteredClients.push(_clientList[keys]);
		    				}
		    			} else {
		    				if (response.d.decsdInd != 'Y') { _filteredClients.push(_clientList[keys]); }
		    			}
		    		}).fail(function (xhr) {
		    			_filteredClients.push(_clientList[keys]);
		    			ErrorLog.ErrorUtils.myError(xhr, true);
		    		}).always(function () {
		    			clientGrpDoneCounter++;
		    			if (clientGrpCounter === clientGrpDoneCounter) {
		    				clientGrpLocalDone = true;
		    				whenAlways();
		    			}
		    		});
		    	});
		    };
		    DataService.getGrpStatementInst(_grpId)
				.done(function (response) {
					_grpData = response.d;
					if (_grpData.length == 0 || _grpData == "") {
						_grpData = "";
					}
				})
				.fail(function (xhr) {
					_grpData = "servicefails";
					ErrorLog.ErrorUtils.myError(xhr, true);
				})
				.always(function () {
					grpStmtDone = true;
					whenAlways();
			});
		    function whenAlways() {
		    	if (grpStmtDone && clientServPrefDone && clientGrpLocalDone) {
		    		finalServiceCallhandler();
		    	}
		    };
		    function finalServiceCallhandler() {
				_self.deliverySettings.servExecuteFlag = true;
		    	_self.deliverySettings.name = _name;
		    	_self.deliverySettings.filteredClients = _filteredClients;
		    	_self.deliverySettings.admnCd = _admnCd;
		    	_self.deliverySettings.grpId = _grpId;
		    	_self.deliverySettings.grpData = _grpData;
		    	_self.deliverySettings.delivMethod = delivMethod;

		    	var _template = _.template(DeliverySettingsTemplate);
		    	var _dataCompiledTemplate = _template({ "clientName": _name, "activeCclients": _filteredClients, "admnCd": _admnCd, "groupId": _grpId, "groupData": _grpData, "delivMethod": delivMethod });
		    	$('#delivery-settings-stmts').html(_dataCompiledTemplate);
		        $("#stmtOnlineDelivery").invokeInfoPopup();
		    }
		},
		finalNoServiceCallhandler: function () {
			var _template = _.template(DeliverySettingsTemplate);
			var _dataCompiledTemplate = _template({ "clientName": this.deliverySettings.name, "activeCclients": this.deliverySettings.filteredClients, "admnCd": this.deliverySettings.admnCd, "groupId": this.deliverySettings.grpId, "groupData": this.deliverySettings.grpData, "delivMethod": this.deliverySettings.delivMethod });
			$('#delivery-settings-stmts').html(_dataCompiledTemplate);
		    $("#stmtOnlineDelivery").invokeInfoPopup();
		},
		linkoutToOFM: function (e) {
			var _el = $(e.currentTarget);
			if (_el.data('tax-ofm') == "tax-stmt-ofm") {
				Analytics.analytics.recordAction('Tax Statements:Older statements in Online File Manager:clicked');
			}
			if (_el.data('consolidated-ofm') == "consolidated-stmt-ofm") {
				Analytics.analytics.recordAction('Financial Statements:Older statements in Online File Manager:clicked');
			}

			Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
				Spinner.show();
                var _url = Config.getConfigProperty("beneOFMLink");
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async: true).then(function (response) {
					Spinner.hide();
					if (response && response.d) {
					_contextId = response.d.cntxId;
					_url = _url +_contextId;
					window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                    }
                }).fail(self.genericServiceErrorHandler);
					e.preventDefault();
				} else {
					BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
					e.preventDefault();
					return;
				}
		},
		linkoutToEform: function (event) {
		    var _$el = $(event.currentTarget), _gContext = GlobalContext.getInstance().getGlobalContext().Context;
		    var _selectedGrpId = _$el.data('group-id'), _editType = _$el.data('edit-type'), _oboId = _gContext.AdvisorFMID, _loggedInFmId = CommonUtils.readCookie('FMID');
		    var _grpContxt = true,_donotPassAdvsrId = false;
		    if (_editType == "createCsg") {
		        _grpContxt = false;
		    }
		    if (_gContext.GroupId.substr(0, 3) == "002") {
		        Device.operatingSystem();
		        Device.physicalDevice();
		        Device.browser();
		        var _deviceInfo = Device.info;
		        var _deviceType = _deviceInfo.hardware.make;
		        if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
		            _url = Config.eformNavTreeLink;
		            BootstrapDialog.alert("This workflow is under construction; the Duplicate Statement Request form (402239) found in <a href=" + _url + " target='_blank'> eforms Manager </a> can be used to submit requests for Pension groups.", "", "Function unavailable");
		        } else {
		            BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
		        }
		    } else {
		        switch (_editType) {
		            case "frequency":
		            case "arrangements":
		            case "changeName":
		            case "createCsg":
		                self.validate147Accounts(launchWofkflow);
		                break;
		            default:
		                launchWofkflow();
		                break;
                }
		        
		    }
		    function launchWofkflow() {
		        var _putContextPaylod = CommonUtils.preparePutAdvContextPayLoad(false, GlobalContext, _grpContxt, _donotPassAdvsrId);
		        Spinner.show();
		        DataService.putAdvisorSessionContext(_putContextPaylod, false).done(function (response, status, xhr) {
		            Spinner.hide();
		            var _url = Config.getConfigProperty("eformsUrl"),
                        _workflow = "",
                        _action;
		            if (response && response.d) {
		            	_contextId = response.d.cntxId;
		                switch (_editType) {
		                    case "groupMembers":
		                    	_workflow = _contextId+ '&formCategory=household#grouping/';
		                        _action = 'Statements:Group Member:Pencil clicked'
		                        break;
		                    case "createCsg":
		                    	_workflow = _contextId + '&formCategory=clientstatements&formName=cst#grouping/';
		                        var groupType = _$el.attr("id");
		                        if (groupType == "statement-creation-csg") {
		                            _action = 'Statements:Create new statement for select accounts or accounts across groups:clicked';
		                        }
		                        if (groupType == "statement-creation-csg-003") {
		                            _action = 'Statements:Stop consolidated statement group:clicked';
		                        }
		                        break;
		                    case "frequency":
		                    	_workflow = _contextId + '&formCategory=clientstatements&formName=statementFreq#grouping/';
		                        _action = 'Statements:Scheduled frequency:Pencil clicked';
		                        break;
		                    case "changeName":
		                    	_workflow = _contextId + '&formCategory=clientstatements&formName=nameOrder#grouping/';
		                        _action = 'Statements:Request change of name order on statement:clicked';
		                        break;
		                    case "arrangements":
		                    	_workflow = _contextId + '&formCategory=clientstatements&formName=duplicateStatements#grouping/';
		                        _action = 'Statements:Arrangements:Pencil clicked';
		                        break;
		                    case "archived":
		                    	_workflow = _contextId + '&formCategory=clientstatements&formName=reprint#grouping/';
		                        if (_$el.data('consolidated-reprint') == "consolidated-reprint") {
		                            _action = 'Consolidated:Reprint of archived statement:clicked';
		                        }
		                        if (_$el.data('tax-reprint') == "tax-reprint") {
		                            _action = 'Tax:Reprint of archived statement:clicked';
		                        }
		                        break;
		                    default:
		                        break;

		                }
		                if (_action) {
		                    Analytics.analytics.recordAction(_action);
		                }
		                _url = _url + _workflow;
		                window.open(_url);
		            } else {
		                ErrorLog.ErrorUtils.prepareAndLogError(xhr);
		            }
		        }).fail(function (xhr) {
		            ErrorLog.ErrorUtils.myError(xhr);
		        });
		    }
		},
		launchInternalLinks: function (event) {
		    var _$el = $(event.currentTarget);
		    var _href = _$el.data("href");
		    if (_href == "coa/") {
		    	Analytics.analytics.recordAction('Statements:Address:Pencil clicked');
		    	Backbone.history.navigate(_href, true);
		    }
		    if (_href == "gpm/update/documentDelivery") {
		    	Analytics.analytics.recordAction('Statements:Delivery Method Edit:Pencil clicked');
		    	self.validateDocDelivAndShowMsg();
			}
		},
		validateDocDelivAndShowMsg: function () {
			var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
			var _colaData = CPViewModel.getInstance().getData().cola;
			var _clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
			storeAmeriReg = ""; storePriEmail = ""; storePriEmailUnReg = false;
			for (var i = 0; i < _colaData.clientEmails.length; i++) {
				if (_colaData.clientEmails[i].get("emlUseCd") === 'Primary') {
					storePriEmail = _colaData.clientEmails[i].get("emlAddr");
				}
				if (_colaData.clientEmails[i].get("emlVldStatCd") !== 'Valid' || _colaData.clientEmails[i].get("emlFuncStatCd") !== 'Functional') {
					storePriEmailUnReg = true;
				}
			}
			DataService.getClientOnlineAccessPreference(_clientId).then(function (result) {
				Spinner.hide();
				var collection = result[0].results;
				if (collection && collection.length > 0) {
					$.each(collection, function (key, row) {
						if (row.status == "Active" && row.rsrcCd == "MYFA") {
							storeAmeriReg = "Yes";
						}
					});
				}
				if (storeAmeriReg == null || storeAmeriReg == "") {
					storeAmeriReg = 'No';
				}
				if (CPData != null) { 
					BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
					}, "Information");
					return false;
				} else if (storePriEmail == "") { 
					BootstrapDialog.alert("<div class='box-with pt-error-icon'> Your request can not be completed because the client is missing a primary email address.  To add an email address, click the Edit button under Email addresses and complete the workflow.</div>", function () {
					}, "Information");
					return false;
				} else if (storeAmeriReg == "No") { 
					BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is not registered on the Secure Site on ameriprise.com</div>", function () {
					}, "Information");
					return false;
				} else if (storeAmeriReg == "" || storeAmeriReg == null) { 
					BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because we are unable to determine if the client is registered on the Secure Site on ameriprise.com Please try again at a later time.</div>", function () {
					}, "Information");
					return false;
				} else if (storePriEmailUnReg == true) { 
					BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client’s email address on file is undeliverable. You must make necessary corrections before proceeding.</div>", function () {
					}, "Information");
					return false;
				} else {
				    self.validate147Accounts(self.preferenceDeliveryMethod);
					return true;
				}
			}).fail(function (xhr) {
				Spinner.hide();
				ErrorLog.ErrorUtils.myError(xhr, true);
			});
		},
		preferenceDeliveryMethod: function () {
		    	var clientServData = null;
		    	clientServData = CPViewModel.getInstance().getData().cola.clientServPreferences;
		    	var tmpClintDocDelivery = {
		    		prfrcServEmailDeliveredTo: null,
		    		prefrcSerEmailShow: false,
		    		prfrcShareHolderDocs: null,
		    		prfrcAccountStatements: null,
		    		prfrcFinancialConfirms: null,
		    		prfrcAddsnlDocumentType: null
		    	};
		    	if (clientServData.length == 0 || clientServData == []) {
					var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
		    		DataService.getClientServPref(_gContext.ContactId).done(function (response) {
		    			Spinner.hide();
		    			getDocDelivery(response.d.results);
		    		}).fail(function (xhr) {
		    			Spinner.hide();
		    			ErrorLog.ErrorUtils.myError(xhr, true);
		    		});
		    	} else {
		    		getDocDelivery(clientServData);
		    	}
		    	function getDocDelivery(clientServData) {
					$.each(clientServData, function (key, row) {
					if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Shareholder Communication") {
							tmpClintDocDelivery.prfrcShareHolderDocs = "Online";
							tmpClintDocDelivery.prefrcSerEmailShow = true;
					} else if (row.typCd === "Paper Suppression" && row.subTypCd === "Shareholder Communication") {
                			tmpClintDocDelivery.prfrcShareHolderDocs = "U.S. mail";
						}
					if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Consolidated Statement") {
							tmpClintDocDelivery.prfrcAccountStatements = "Online";
							tmpClintDocDelivery.prefrcSerEmailShow = true;
					} else if (row.typCd === "Paper Suppression" && row.subTypCd === "Consolidated Statement") {
                    		tmpClintDocDelivery.prfrcAccountStatements = "U.S. mail";
						}
					if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Financial Confirmations") {
							tmpClintDocDelivery.prfrcFinancialConfirms = "Online";
							tmpClintDocDelivery.prefrcSerEmailShow = true;
					} else if (row.typCd === "Paper Suppression" && row.subTypCd === "Financial Confirmations") {
                			tmpClintDocDelivery.prfrcFinancialConfirms = "U.S. mail";
						}
					if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Other Documents") {
							tmpClintDocDelivery.prfrcAddsnlDocumentType = "Online";
                			tmpClintDocDelivery.prefrcSerEmailShow = true;
					} else if (row.typCd === "Paper Suppression" && row.subTypCd === "Other Documents") {
							tmpClintDocDelivery.prfrcAddsnlDocumentType = "U.S. mail";
						}
					});
				if (tmpClintDocDelivery.prefrcSerEmailShow) {
                		tmpClintDocDelivery.prfrcServEmailDeliveredTo = "Primary email";
					}
				PreferenceViewModel.setData("documentDelivery", tmpClintDocDelivery);
				Backbone.history.navigate('gpm/update/documentDelivery', true);
				}		    	
		    	
		},
		getStatementsList: function () {
		    Spinner.show();
		    var _gContext = GlobalContext.getInstance().getGlobalContext().Context, _serviceFailure = false;
		    var _grpId = _gContext.GroupId,_today = new Date();

		    var options = {
		        "groupId": _grpId,
		        "valFrm": moment(_today).add(-2,"years").format("MM/DD/YYYY"),
		        "valTo": moment(_today).format("MM/DD/YYYY")
		    }
		    var _payload = self.createStatementsPayload(options);
		    //getStatementsList
		    DataService.getStatementsList(_payload).done(function (resp, status, xhr) {
		        if (resp && resp.d && resp.d.statCd == "0000") {
		            Spinner.hide();
		            self.renderStatementsList(resp);
		        } else {
		            _serviceFailure = true;
		            self.renderStatementsList({}, true);
                    Spinner.hide();
		            ErrorLog.ErrorUtils.myError(xhr,true);
		        }
		        
		    }).fail(function (xhr) {
               self.renderStatementsList({}, true);
                Spinner.hide();
		        ErrorLog.ErrorUtils.myError(xhr,true);
		    });
		},
		renderStatementsList: function (resp,serviceFailure) {
		    var _docDesc = "", _statmntsListResp = (resp.d && resp.d.documentList) ? resp.d.documentList.results : [], _statementListModel = [], _statement = {}, _respProperties = [], _addressLine = "", _propVal="";
		    _statmntsListResp.forEach(function (doc, i) {
		        _addressLine = []; _respProperties = []; _addressLine = ""; _propVal = "", _docDesc = "";
		        _docDesc = doc.docTypDesc;
		        if (doc.docTypDesc == "CONSOLIDATED STATEMENTS MONTHEND") {
		            _docDesc = "CONSOLIDATED STATEMENTS MONTH END";
		        }
		        _statement = {
                    "effectiveDate":"",
		            "docId": doc.docId,
		            "docTypDesc": _docDesc,
		            "docSrcSysNm": doc.docSrcSysNm,
		            "docTypeSortVal": self.statementsDescListSortValue[doc.docTypDesc],
		            "address1": "",
		            "address2": "",
		            "address3": "",
		            "address4": "",
		            "combinedAddressLine": "",
                    "effectiveDateSortKey": ""
		        }
		         _respProperties = doc.respProperties.results;
		         _respProperties.forEach(function (respProperty, j) {
		             try {
		                 _propVal = respProperty.values.results[0].respDocPropVal;
		             } catch (a) {
		                 _propVal = "";
		             }
		             switch (respProperty.respDocPropNm) {
		                 case "effective_date":
		                     _statement.effectiveDate = _propVal;
		                     _statement.effectiveDateSortKey = moment(_propVal, 'MM-DD-YYYY').format('YYYY-MM-DD');
		                     break;

		                 case "address1":
		                     _statement.address1 = _propVal;
		                     break;
		                 case "address2":
		                     _statement.address2 = _propVal;
		                     break;
		                 case "address3":
		                     _statement.address3 = _propVal;
		                     break;
		                 case "address4":
		                     _statement.address4 = _propVal;
		                     break;
		                 default:
		                     break;
		             }
		         });
		         _addressLine = _statement.address1;
		         if (_statement.address2) {
		             _addressLine += ", " + _statement.address2;
		}
		         if (_statement.address3) {
		             _addressLine += ", " + _statement.address3;
		         }
		         if (_statement.address4) {
		             _addressLine += ", " + _statement.address4;
		         }
		         _statement.combinedAddressLine = _addressLine;
		         _statementListModel.push(_statement);

		    });
		    var _consolidatedStmtsTemplate = _.template(AccountConsolidatedStmtsTemplate);
		    self.statementListModel = _statementListModel;
		    self.statementListModel.sort(CommonUtilis.sortMultiColumn({
		        name: "effectiveDateSortKey",
		        reverse: true
		    }, "docTypeSortVal", "combinedAddressLine"));
		    $('#account-consolidated-stmts').html(_consolidatedStmtsTemplate({ 'statementsList': self.statementListModel, "serviceFailure": serviceFailure}));
		    
		},
		getTaxStatementsList: function (grpId, clId) {
		    var _taxStatmntList = [], _serviceCompleteCounter = 0, _taxStatmntsListResp = [], _activeClientsInfo = [], _taxStatmntsPartialFailure = false;
		    DataService.getClientgroupLocal(clId).then(processTaxStatementsListCall).fail(function (xhr) {
                   ErrorLog.ErrorUtils.myError(xhr);
               });
		    function processTaxStatementsListCall(clientGroups) {
		        var _activeGroups = clientGroups.results[0].get("activeGroups");
		        var _selectedGroup = _activeGroups.find(function (group) {
		            return grpId == group.get("id");
		        }), _pinnedClient, _pinnedClientName;
		        _admnCd = _selectedGroup.get("adminCode");
		        if (_admnCd == "002") {
		            _pinnedClient = NavApi.getSelecetdContactdetails(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID, _selectedGroup.get("currClient"));
		            _pinnedClientName = _pinnedClient.orgNm != null ? _pinnedClient.orgNm : _pinnedClient.firstNm + " " + _pinnedClient.lastNm;
		            _activeClientsInfo = [{ "clName": _pinnedClientName, "id": _selectedGroup.get("currClient"), "clientSortingIndex": 1 }];
		        } else {
		            _activeClients = _selectedGroup.get("activeClients");
		            if (!Array.isArray(_activeClients)) {
		                _pinnedClient = NavApi.getSelecetdContactdetails(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID, _selectedGroup.get("currClient"));
		                _pinnedClientName = _pinnedClient.orgNm != null ? _pinnedClient.orgNm : _pinnedClient.firstNm + " " + _pinnedClient.lastNm;
		                _activeClientsInfo = [{ "clName": _pinnedClientName, "id": _selectedGroup.get("currClient"), "clientSortingIndex": 1 }];
		            } else {
		                _activeClients.forEach(function (clientInfo, i) {
		                    var _name = "", _orgClient = clientInfo.get("orgClient"), _personClient = clientInfo.get("personClient")
		                    if (_orgClient.get("orgNm")) {
		                        _name = _orgClient.get("orgNm");
		                    } else {
		                        _name = _personClient.get("clFirstNm") + " " + _personClient.get("clLastNm");
		                    }
		                    _activeClientsInfo.push({
		                        "clName": _name,
		                        "id": clientInfo.get("id"),
		                        "clientSortingIndex": _selectedGroup.get("currClient") == clientInfo.get("id")?1:2
		                    });
		                });
		            }
		        }
		        if (_activeClientsInfo.length != 0) {
		            _activeClientsInfo.forEach(function (clId, j) {
		                callGetTaxStatementsServiceForClient(clId)
		            });
		        }
		    }
		    
		    function callGetTaxStatementsServiceForClient(clientIfno) {
		        var _currYear = new Date().getFullYear();
		        var options = {
		            "clId": clientIfno.id,
		            "docPropVal": [(_currYear - 2).toString(), (_currYear - 1).toString(), _currYear.toString()]
		        };
		        var _payload = self.creatTaxStatementsPayload(options), _statement = {};
		        DataService.getStatementsList(_payload).done(function (resp, status, xhr) {
		            if (resp && resp.d && resp.d.statCd == "0000") {
		                try {
		                    var _clientTaxSttmntList = (resp.d && resp.d.documentList) ? resp.d.documentList.results : [];
		                    _clientTaxSttmntList.forEach(function (doc,k) {
		                        _statement = {
		                            "effectiveDateSortKey": "",
		                            "effectiveDate": "",
		                            "docId": doc.docId,
		                            "docTypDesc": doc.docTypDesc,
		                            "docSrcSysNm": doc.docSrcSysNm,
		                            "address1": "",
		                            "address2": "",
		                            "address3": "",
		                            "address4": "",
		                            "clName": clientIfno.clName,
		                        }
		                        _respProperties = doc.respProperties.results;
		                        _respProperties.forEach(function (respProperty, j) {
		                            try {
		                                _propVal = respProperty.values.results[0].respDocPropVal;
		                            } catch (a) {
		                                _propVal = "";
		                            }
		                            switch (respProperty.respDocPropNm) {
		                                case "effective_date":
		                                    _statement.effectiveDate = _propVal;
		                                    _statement.effectiveDateSortKey = moment(_propVal, 'MM-DD-YYYY').format('YYYY-MM-DD');
		                                    break;
		                                case "address1":
		                                    _statement.address1 = _propVal;
		                                    break;
		                                case "address2":
		                                    _statement.address2 = _propVal;
		                                    break;
		                                case "address3":
		                                    _statement.address3 = _propVal;
		                                    break;
		                                case "address4":
		                                    _statement.address4 = _propVal;
		                                    break;
		                                default:
		                                    break;
		                            }
		                        });
		                        _taxStatmntsListResp.push(_statement);
		                    });
		                    
		                    
		                    taxStatementsListFinalServiceCompletehandler();
		                } catch (e) {
                             taxStatementsListFinalServiceCompletehandler();
                             ErrorLog.ErrorUtils.myError(e,true);
		                }

		            } else {
		                _taxStatmntsPartialFailure = true;
                        taxStatementsListFinalServiceCompletehandler();
		                ErrorLog.ErrorUtils.myError(xhr, true);
		            }
		        }).fail(function (xhr) {
		            _taxStatmntsPartialFailure = true;
		            taxStatementsListFinalServiceCompletehandler();
		            ErrorLog.ErrorUtils.myError(xhr, true);
		        });
		    }
		    function taxStatementsListFinalServiceCompletehandler() {
		        _serviceCompleteCounter++;
		        if (_serviceCompleteCounter == _activeClientsInfo.length) {
		            self.taxStatmntObj.processingTaxStatements = false;
		            var _taxStmtsTemplate = _.template(TaxStatementsList);
		            _taxStatmntsListResp.sort(CommonUtilis.sortMultiColumn({
		                name: "effectiveDateSortKey",
		                reverse: true
		            }, "clientSortingIndex"));
		            self.taxStatmntObj.taxStatementsData = _taxStatmntsListResp;
		            $('#tax-statements-list').html(_taxStmtsTemplate({ 'statementsList': _taxStatmntsListResp, 'taxStatmntsPartialFailure': _taxStatmntsPartialFailure}));
		            if (_taxStatmntsPartialFailure) {
		                $('#tax-statements-partial-resp-message').removeClass("hidden");
                    }
		        }
		    }
		},
		createStatementsPayload: function (options) {
		    var _payload = {
		        "docCtgCd": "STMTS",
		        "identifiers": [{
                      "id": options.groupId,
                      "ctx": "COLA.GRP"
                  }],
		        "properties": [{
                      "docPropNm": "effective_date",
                      "range": [ {
                          "valFrm": options.valFrm,
                          "valTo": options.valTo
                        }]
                  }],
		        "respMetaData": [{
                      "respPropNm": "effective_date"
                  }, {
                      "respPropNm": "address1"
                  }, {
                      "respPropNm": "address2"
                  },{
                      "respPropNm": "address3"
                  }, {
                      "respPropNm": "address4"
                  }]
		    }
		    return _payload;
		},
		creatTaxStatementsPayload: function (options) {
		    var _payload = {
		        "docCtgCd": "TAX",
		        "identifiers": [{
		            "id": options.clId,
		            "ctx": "COLA.CL"
		        }],
		        "properties": [{
		            "docPropNm": "tax_year",
		            "values": [{
		                "docPropVal": options.docPropVal[0]
		            }

                    , {
		                "docPropVal": options.docPropVal[1]
		            }, {
		                "docPropVal": options.docPropVal[2]
		            }

		            ]
		        }],
		        "respMetaData": [{
		            "respPropNm": "effective_date"
		        }, {
		            "respPropNm": "address1"
		        }, {
		            "respPropNm": "address2"
		        }, {
		            "respPropNm": "address3"
		        }, {
		            "respPropNm": "address4"
		        }]
		    }
		    return _payload;

		},
		reRenderConsolidatedStatementsList: function (statementListModel) {
		    var _consolidatedStmtsTemplate = _.template(AccountConsolidatedStmtsTemplate);
		    $('#account-consolidated-stmts').html(_consolidatedStmtsTemplate({ 'statementsList': statementListModel }));
		},
		reRenderTaxStatementsList: function (taxStatmntsListResp) {
		    var _taxStmtsTemplate = _.template(TaxStatementsList);
		    $('#tax-statements-list').html(_taxStmtsTemplate({ 'statementsList': taxStatmntsListResp }));
		},
		getDocumentBase64Dta: function (e) {
		    var _el = $(e.currentTarget);
		    var statementType = _el.closest('.panel-group').attr("id");
		    if (statementType == "tax-statements-list") {
				Analytics.analytics.recordAction('Tax Statements:View Statement Details:clicked');
			}
		    if (statementType == "account-consolidated-stmts") {
				Analytics.analytics.recordAction('Financial Statements:View Statement Details:clicked');
		    }

            e.preventDefault();
		    if (!CommonUtilis.isWindows()) {
		        BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable");
		        return;
		    }
		    Spinner.show();
		    var _$target = $(e.currentTarget);
		    var _docId = _$target.data("docid").toString(), _docSystem = _$target.data("docsystem"), _fmid = CommonUtilis.readCookie('FMID');
            var _data = {
                "docId": _docId,
                "docSrcSysNm": _docSystem,
                "docRepositoryNm": "ClientFiles",
                "respMetaData": [{
                                    "respPropNm": "client_id"
                                }]
                        }
		    DataService.retrieveClientFacingDocument(_data).done(function (response, status, xhr) {
		        var _base64Data = "";
		        if (response && response.d && response.d.statCd == "0000") {
		            Spinner.hide();
		            _base64Data = response.d.ctnt.docImg;
		            self.convertAndLaunchPDF(_base64Data, _fmid, _docId);
		        } else {
		            ErrorLog.ErrorUtils.myError(xhr);
                }
		    }).fail(function (xhr) {
                ErrorLog.ErrorUtils.myError(xhr);
		    });
		},
		routeToSecureSite: function (e) {
			NativeAdaptor.notifyContactUpdated();
			var targetRoute = null;
			var that = this;
           
            switch (e.target.id) {
                case 'SecureSiteRegLink':
                    var _el = $(e.currentTarget);
                    var statementType = _el.parents('.pl-drawer-details-container').attr("data-content");
                    if (statementType == "tax-stmts") {
                        Analytics.analytics.recordAction('Tax Statements:SecureSiteRegistration:clicked');
                    }
                    if (statementType == "consolidated-stmts") {
                        Analytics.analytics.recordAction('Financial Statements:SecureSiteRegistration:clicked');
                    }
                    if (this.validateSecureSiteRegg()) {
                        that.SecureSiteReg();
                    }
                    break;
                default:
                    console.log("error: edit field operator error")
                    alert('link not yet available')
                    break;
            }            
            return false;
        },

        validateSecureSiteRegg: function () {
            var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            var _colaData = CPViewModel.getInstance().getData().cola; 
            var _clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;           
            var dob = CPViewModel.getInstance().getData().cola.clientPersonal.attributes.bthDt;
            var year=Number(dob.substr(0,4));
            var month=Number(dob.substr(5,2))-1;
            var day=Number(dob.substr(9,2));
            var today=new Date();
            var age=today.getFullYear()-year;
            storeAmeriReg = ""; storePriEmail= ""; storePriEmailUnReg = false;
            for (var i = 0; i < _colaData.clientEmails.length; i++) {
            	if (_colaData.clientEmails[i].get("emlUseCd") === 'Primary') {
            		storePriEmail= _colaData.clientEmails[i].get("emlAddr");
            	}
            	if (_colaData.clientEmails[i].get("emlVldStatCd") !== 'Valid' || _colaData.clientEmails[i].get("emlFuncStatCd") !== 'Functional') {
				   storePriEmailUnReg = true;
				}			  
			}

			DataService.getClientOnlineAccessPreference(_clientId).done(function (result) {
        		var collection = result[0].results;
        		if (collection && collection.length > 0) {
        			$.each(collection, function (key, row) {
        				if(row.status == "Active" && row.rsrcCd == "MYFA" && storeAmeriReg == "") {
        					storeAmeriReg = "Yes";
        				}
        			});
        		}
	        	if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) { age--; }
	            if (CPData == null && _colaData.clientPersonal.attributes.decsdInd === "Y") {
	                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because deceased clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
	                }, "Invitation email not sent");
	                return false;
	            }
	            if (age != null && age<18) {
	                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because clients must be 18 or older to register for the Secure Site on ameriprise.com</div>", function () {
	                }, "Invitation email not sent");
	                return false;
	            } 
	            if (CPData != null) {
	                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
	                }, "Invitation email not sent");
	                return false;
	            } else if (storePriEmail == "") {
	                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", function () {
	                }, "Invitation email not sent");
	                return false;
	               } else if (storeAmeriReg == "Yes") {
	                   BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is already registered on the Secure Site on ameriprise.com</div>", function () {
	                }, "Invitation email not sent");
	                return false;
	            } else if (storeAmeriReg == null) {
	                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Service fails</div>", function () {
	                }, "Invitation email not sent");
	                return false;
	            } else if (storePriEmailUnReg == true) {
	                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", function () { }, " Invitation email not sent ");
	                return false;
	           }
	                return true;
			})
			return true;           
        },

        SecureSiteReg: function () {
        	var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            var _colaData = CPViewModel.getInstance().getData().cola; 
            var _clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;           
            var dob = CPViewModel.getInstance().getData().cola.clientPersonal.attributes.bthDt;
            var year=Number(dob.substr(0,4));
            var month=Number(dob.substr(5,2))-1;
            var day=Number(dob.substr(9,2));
            var today=new Date();
            var age=today.getFullYear()-year; 
            var undeliverable = false;
            for (var i = 0; i < _colaData.clientEmails.length; i++) {
            	if (_colaData.clientEmails[i].get("emlVldStatCd") !== 'Valid' || _colaData.clientEmails[i].get("emlFuncStatCd") !== 'Functional') {
				   undeliverable = true;
				}			  
			}
            if (age > 18 && undeliverable != true && _colaData.clientPersonal.attributes.decsdInd != "Y") {
	        	var payload = { "regTypCd":"NEW" };
	            var globalClid = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
	            Spinner.show();
	        	DataService.SecureSiteService(globalClid, payload).then(function (status, result, xhr) {
	        		var tokenId = status.d.results[0].tokenId;
	        		if (tokenId != null && tokenId != "") {
	        			var tokenPayload = {
	        				"actnCd": "Registration Reminder",
	        				"cmunTypCd": "Notification",
	        				"EMSApplCd": "ADVISORMOBILE",
	        				"token": {
	        					"tokenId": tokenId
	        				}
	        			}
	        			DataService.getTotalViewDelvPrefService(globalClid, tokenPayload).then(function (status, result, xhr) {
	        				Spinner.hide();
	        				if (result == "success") {
	        					BootstrapDialog.alert('<div>'
								   + '<div class="left-box right-tick pull-left"></div>'
								  + '<div class="row right-box pull-left">'
									  + '<div>The client will be sent an email to register with the Secure Site on ameriprise.com within the next business day.</div><br/>'
									  + '<div class="pt-action-icon-header">Client Next Steps</div>'
									  + '<div>They will need to go online the Secure Site on ameriprise.com and complete registration.</div><br/>'
									  + '<div class="pt-action-icon-header">Advisor Next Steps</div>'
									  + '<div> Let the client know to expect the email and encourage them to sign up for eDelivery.</div>'
									  + '<div class="clearfix"></div>'
								  + '</div>'
								  + '<div class="clearfix"></div>'
								+ '</div>', function () { }, "Invitation email sent");
	        				}
	        			}).fail(function (xhr) {
	        				Spinner.hide();
	        			});
	        		} else {
	        			Spinner.hide();
	        		}
	            }).fail(function(err){
	                Spinner.hide();
	            });
	        }
        },
		convertAndLaunchPDF: function (b64Data,fmid,docid) {
		    var _form = document.createElement("form"), _windowName = "pdfwindow" +new Date().getTime(), _url = Config.ebixServiceName+'GetPDF';
				_form.setAttribute("method", "post");
                _form.setAttribute("action",_url );
                _form.setAttribute("target", _windowName);
                var _hiddenB64Field = document.createElement("input"),_hiddenFmidField = document.createElement("input"),_hiddenDocIdField = document.createElement("input");
                _hiddenB64Field.setAttribute("type", "hidden");
                _hiddenB64Field.setAttribute("name", "binary64PDF");
                _hiddenB64Field.setAttribute("value", b64Data);

                _hiddenFmidField.setAttribute("type", "hidden");
                _hiddenFmidField.setAttribute("name", "fmId");
                _hiddenFmidField.setAttribute("value", fmid);

                _hiddenDocIdField.setAttribute("type", "hidden");
                _hiddenDocIdField.setAttribute("name", "docId");
                _hiddenDocIdField.setAttribute("value", docid);
                _form.appendChild(_hiddenB64Field);
                _form.appendChild(_hiddenFmidField);
                _form.appendChild(_hiddenDocIdField);
                document.body.appendChild(_form);
                window.open('', _windowName);
                _form.submit();
                document.body.removeChild(_form);

	    }
    });
	return accountstatementsView;
});