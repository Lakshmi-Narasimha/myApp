define([
  'jquery',  
  'backbone',  
], function ($,Backbone) {
    var groupMemberModel = Backbone.Model.extend({
        defaults: {                        
            selectedcontact: undefined,            
            selectedgroup: undefined,
            triggeredevent: undefined
        }
    });
    var eventNames = {
        ContactChanged: "ContactChanged",
        GroupChanged: "GroupChanged",
        GroupPinnedFromContext: "GroupPinnedFromContext"
    };
    var groupContext = {
        groupMemberModel: groupMemberModel,
        eventNames: eventNames
    };
    return groupContext;
});
