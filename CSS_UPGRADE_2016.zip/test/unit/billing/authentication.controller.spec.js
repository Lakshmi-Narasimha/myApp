(function() {
    'use strict';
    describe('authentication controller', function() {
        beforeEach(module('CSS.billing'));
        beforeEach(module('CSS.components'));
        var authCtrl, $controller, billingVM, scope, timeout;
        var getPaymentDetailsSrv, $loader, $state, $stateParams, $httpBackend, deferred, resultObj;
        beforeEach(function() {
            module(function($provide) {
                var $window = {
                    // now, $window.location.path will update that empty object
                    location: {},
                    // we keep the reference to window.document
                    document: window.document
                };

                // We register our new $window instead of the old
                $provide.constant('$window', $window);
            });
        });
        beforeEach(inject(function($controller, $q, $rootScope, getPaymentDetailsSevice, errorDefaultConstant, billingUtils, $timeout, $injector, $state, $stateParams, $loader) {

            scope = $rootScope.$new();

            timeout = $timeout;
            $httpBackend = $injector.get('$httpBackend');
            $state = $state;
            $stateParams = $stateParams;

            resultObj = {
                "uiErrorDisplayMessage": "",
                "transactionStatus": "S",
                "transactionDescription": "",
                "policies": [{
                    "policyContractNumber": "900500520",
                    "lineOfBusiness": "HOME"
                }],
                "paymentPlanCode": "MT",
                "paymentPlanCodeDesc": "MONTHLY",
                "billingScheduledMaintenance": "N",
                "estimatedDowntime": null,
                "systemDateTime": "2016-01-01T11:59:04.159Z",
                "paymentDueDate": "2016-01-03",
                "outStandingAmountCurrency": "USD",
                "outStandingAmount": "50000.00",
                "minPaymentDueAmountCurrency": "USD",
                "minPaymentDueAmount": "23000.00",
                "billingAccountNumber": "T718142962",
                "accountStatus": "Active",
                "loginURL": "https://csstw.farmers.com/",
                "registerURL": null
            };

            $loader = $loader;

            authCtrl = $controller('authCtrl', {
                $scope: scope,
                getPaymentDetailsSevice: getPaymentDetailsSevice,
                errorDefaultConstant: errorDefaultConstant,
                $state: $state,
                billingUtils: billingUtils,
                $stateParams: $stateParams,
                $loader: $loader,
                $rootScope: $rootScope
            });
            scope.$$listeners.$locationChangeStart = [];
        }));

        describe('billingCtrl', function() {
            it('should expect billing.billingCtrl to be defined...', function() {
                expect(authCtrl).toBeDefined();
            })

            it('should expect billing.billingCtrl...', function() {
                expect(authCtrl.authResponse).toBeDefined();
            })
        });

        describe('isValidating function to be tested', function() {
            var dataObj = {
                "zipCode": 12345,
                "billingAccountNumber": null,
                "policyContractNumber": 123456789
            };


            it('should validate the isValidating function', function() {

                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj).respond(resultObj);
                authCtrl.user = {
                    accountNumber: 123456789,
                    zipCode: 12345
                };

                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                expect(authCtrl.authResponse.isError).toBeFalsy();
            })

            it('should validate the three attempts of authentication', function() {
                resultObj = {
                    transactionStatus: 'e'
                };

                var dataObj = {
                    "zipCode": 12345,
                    "billingAccountNumber": "BA123456",
                    "policyContractNumber": null
                };
                var dataObj1 = {
                    "zipCode": null,
                    "billingAccountNumber": null,
                    "policyContractNumber": null
                };
                var dataObj2 = {
                    "zipCode": null,
                    "billingAccountNumber": null,
                    "policyContractNumber": null
                }

                authCtrl.user = {
                    accountNumber: "BA123456",
                    zipCode: 12345
                };

                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj).respond(resultObj);
                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                $httpBackend.flush();
                expect(authCtrl.authResponse.isError).toBeTruthy();

                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj1).respond(resultObj);

                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                $httpBackend.flush();
                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj2).respond(resultObj);
                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                $httpBackend.flush();
                expect(authCtrl.authResponse.isAuthMax).toBeTruthy();
                expect(authCtrl.authResponse.errorTitle).toEqual('We were unable to locate your account.');
            })

            it('should get the success response', function() {
                resultObj = {
                    transactionStatus: 'S',
                    billingScheduledMaintenance: 'y'
                };

                var dataObj = {
                    "zipCode": 12345,
                    "billingAccountNumber": "BA123456",
                    "policyContractNumber": null
                };

                authCtrl.user = {
                    accountNumber: "BA123456",
                    zipCode: 12345
                };

                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj).respond(resultObj);
                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                $httpBackend.flush();
                expect(authCtrl.authResponse.isError).toBeTruthy();

            });

            it('should get the success response where the accountStatus is validated', function() {
                resultObj = {
                    transactionStatus: 'S',
                    billingScheduledMaintenance: 'N',
                    accountStatus: 'active'
                };

                var dataObj = {
                    "zipCode": 12345,
                    "billingAccountNumber": "BA123456",
                    "policyContractNumber": null
                };

                authCtrl.user = {
                    accountNumber: "BA123456",
                    zipCode: 12345
                };

                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj).respond(resultObj);
                $httpBackend.expectGET('modules/billing/billing.html').respond();
                $httpBackend.expectGET('modules/billing/partials/makeapayment.html').respond();
                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                $httpBackend.flush();
                expect(authCtrl.authResponse.isError).toBeFalsy();
                // expect(authCtrl.authResponse.errorTitle).toEqual('Your account is cancelled');

            });

            it('should get the success response where the accountStatus failure is validated', function() {
                resultObj = {
                    transactionStatus: 'S',
                    billingScheduledMaintenance: 'N',
                    accountStatus: 'null'
                };

                var dataObj = {
                    "zipCode": 12345,
                    "billingAccountNumber": "BA123456",
                    "policyContractNumber": null
                };

                authCtrl.user = {
                    accountNumber: "BA123456",
                    zipCode: 12345
                };

                $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', dataObj).respond(resultObj);
                authCtrl.isValidating({ $valid: true });
                timeout.flush();
                $httpBackend.flush();
                expect(authCtrl.authResponse.errorTitle).toEqual('Your account is cancelled');

            });
        });
    })
})();