"use strict";
var TypeaheadOptions = (function () {
    function TypeaheadOptions(options) {
        Object.assign(this, options);
    }
    return TypeaheadOptions;
}());
exports.TypeaheadOptions = TypeaheadOptions;
