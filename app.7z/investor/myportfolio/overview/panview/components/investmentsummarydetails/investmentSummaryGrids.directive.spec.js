'use strict';

describe('Directive : Investment Summary Grid', function() {
    var rootScope, scope, compile, directiveElem, $window, isolatedScope, panViewModel, investmentSummaryGridsModelDataObj;
    var folioObjs = {
        'investmentSummary': [{
            'folioId': '17877097',
            'rows': [{
                'accountNo': '1349904865101',
                'scheme': 'Franklin India Taxshield - Growth',
                'totalUnits': '219.347',
                'currentCost': '59998.89',
                'currentValue': '92755.57',
                'returns': '20.46%',
                'goal': null
            }, {
                'accountNo': '2389904865101',
                'scheme': 'Franklin India Bluechip Fund - Growth',
                'totalUnits': '0.000',
                'currentCost': '0.00',
                'currentValue': '0.00',
                'returns': '0%',
                'goal': null
            }, {
                'accountNo': '4379904865101',
                'scheme': 'Franklin India Prima Plus - Growth',
                'totalUnits': '66.411',
                'currentCost': '22499.85',
                'currentValue': '29408.34',
                'returns': '16.81%',
                'goal': null
            }],
            'modeofHolding': 'Single',
            'holders': [{
                'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'grandTotal': {
                'totalUnits': '285.758',
                'folioId': null,
                'account': 'GRAND TOTAL',
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        },{
            'folioId': '27877097',
            'rows': [{
                'accountNo': '1134990486511',
                'scheme': 'Franklin India Taxshield - Growth',
                'totalUnits': '219.347',
                'currentCost': '59998.89',
                'currentValue': '92755.57',
                'returns': '20.46%',
                'goal': null
            }, {
                'accountNo': '11389904865101',
                'scheme': 'Franklin India Bluechip Fund - Growth',
                'totalUnits': '0.000',
                'currentCost': '0.00',
                'currentValue': '0.00',
                'returns': '0%',
                'goal': null
            }, {
                'accountNo': '11379904865101',
                'scheme': 'Franklin India Prima Plus - Growth',
                'totalUnits': '66.411',
                'currentCost': '22499.85',
                'currentValue': '29408.34',
                'returns': '16.81%',
                'goal': null
            }],
            'modeofHolding': 'Married',
            'holders': [{
                'name': 'JASMINE POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'grandTotal': {
                'totalUnits': '285.758',
                'folioId': null,
                'account': 'GRAND TOTAL',
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        }]
    };
    var statusTemplate = '<div uib-popover-template="\'accountViewTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                '<script type="text/ng-template" id="accountViewTemplate.html">' +
                '<div><button type="button" ng-click="grid.appScope.$emit(\'showAccountView\', {accontNumber : row.entity.Account,folioNumber:COL_FIELD} )" class="btn panel-orange-btn m0">Account Statement</button></div></script>';
    var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti_Info"></span></div>' +
                '<script type="text/ng-template" id="returnTemplate.html">' +
                '<div class="overview-tool-tip">Returns calculation will be displayed</div></script>';
    
    var columnDefs = [{ field: 'folioNo', displayName: ' ', width: '48', cellTemplate: statusTemplate, enableSorting: false, pinnedLeft: true },
                { field: 'Account', displayName: 'Account', width: '139', pinnedLeft: true, footerCellTemplate: '<div class="ui-grid-cell-contents">GRAND TOTAL</div>' },
                { field: 'Scheme', displayName: 'Scheme', width: '175' },
                { field: 'TotalUnits', displayName: 'Total Units', width: '120' },
                { field: 'CurrentCost', displayName: 'Current Cost',cellClass:'text-right', width: '125', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'CurrentValue', displayName: 'Current Value',cellClass:'text-right', width: '125', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'Return', displayName: '', width: '103', headerCellTemplate: returnsTemplate }
            ];

    var getCompiledElement = function() {
        var element = angular.element('<ftic-investment-summary-grids></ftic-investment-summary-grids>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };
    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.inject(function(_$compile_, _$rootScope_, _panViewModel_, _$window_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            panViewModel = _panViewModel_; 
            $window = _$window_;
            $window.ga = function() {};
            
            panViewModel.setPanViewDtls({
                'investmentSummary': folioObjs.investmentSummary
            })
        })
            directiveElem = getCompiledElement();
            isolatedScope = directiveElem.isolateScope();

    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should have separate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have columnDefs with status and returns tempalte as cellTemplate and headerCellTemplate', function() {
        expect(isolatedScope.columnDefs).toBeDefined();
        expect(isolatedScope.columnDefs[0].cellTemplate).toBe(statusTemplate);
        expect(isolatedScope.columnDefs[6].headerCellTemplate).toBe(returnsTemplate);
        expect(isolatedScope.columnDefs[0].field).toBe('folioNo');
        expect(isolatedScope.columnDefs[0].displayName).toBe(' ');
        expect(isolatedScope.columnDefs[0].width).toBe('48');
        expect(isolatedScope.columnDefs[0].enableSorting).toBe(false);
        expect(isolatedScope.columnDefs[0].pinnedLeft).toBe(true);
    });

    it('should be isolatedScope data rendered in template', function() {
        expect(isolatedScope.folioObjs).toBeDefined();
        expect(isolatedScope.folioObjs[0].folioNumber).toBe('17877097');
        expect(isolatedScope.folioObjs[0].modeofHolding).toBe('Single');
        expect(isolatedScope.folioObjs[0].pocontent[0].text).toBe('First Holder');
        expect(isolatedScope.folioObjs[0].pocontent[0].value).toBe('YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED');
        expect(isolatedScope.folioObjs[0].grandTotal.account).toBe('GRAND TOTAL');
        expect(isolatedScope.folioObjs[0].grandTotal.currentCost).toBe('82498.74');
        expect(isolatedScope.folioObjs[0].grandTotal.currentValue).toBe('122163.91');
        expect(isolatedScope.folioObjs[0].gridData[0].Account).toBe('1349904865101');
        expect(isolatedScope.folioObjs[0].gridData[0].CurrentCost).toBe('59998.89');
        expect(isolatedScope.folioObjs[0].gridData[0].CurrentValue).toBe('92755.57');
        expect(isolatedScope.folioObjs[0].gridData[0].Return).toBe('20.46%');
        expect(isolatedScope.folioObjs[0].gridData[0].Scheme).toBe('Franklin India Taxshield - Growth');
        expect(isolatedScope.folioObjs[0].gridData[0].TotalUnits).toBe('219.347');
        expect(isolatedScope.folioObjs[0].gridData[0].folioNo).toBe('17877097');

    });

    it('should emit showFolioView on showFolioViewTemplate function call', function() {
        expect(isolatedScope.showFolioViewTemplate).toBeDefined();
        expect(typeof(isolatedScope.showFolioViewTemplate)).toEqual('function');
        spyOn(isolatedScope, 'showFolioViewTemplate').and.callThrough();
        spyOn(isolatedScope, '$emit');
        isolatedScope.showFolioViewTemplate(folioObjs.investmentSummary[0].folioId);
        expect(isolatedScope.showFolioViewTemplate).toHaveBeenCalled();
        expect(isolatedScope.$emit).toHaveBeenCalledWith('showFolioView', folioObjs.investmentSummary[0].folioId);
    });
});