define(['jquery', 'underscore', 'backbone','appmodules/contactprofile/app/models/cpviewmodel', 'appmodules/gpm/app/js/utils', 'text!appmodules/gpm/app/templates/gpmclientgreeting.html',
		], function ($, _, Backbone, CPViewModel, Utils, greetingsTemplate) {
		    var greetingsView = Backbone.View.extend({
		        el: "#gpm-form-update-field-container",
		        id: 'gpm-form-update-field-container',
		        events: {
		            'keypress #editContactGreet': 'limitEditContactGreet',
		        },
		        template: _.template (greetingsTemplate),
		        initialize: function (data) {
		        	this.data = data;
		        	
		        },
		        render: function (updateMode) {
		        	try{
		        		var self = this;
		        		if(!this.model.get('currentItemSet')){
		        			var CPData = CPViewModel.getInstance().getData();
				        	this.data.fieldsInfo = {clGreeting: ((CPData.ebix && CPData.ebix.PersonContact && CPData.ebix.PersonContact.get('clGreeting')) ? CPData.ebix.PersonContact.get('clGreeting').trim() : "")};
				        	this.model.setCurrentValue(updateMode,{data:this.data});
		        		}
		        		var _dataSet = this.model.get('items');
		        		$("#"+this.id).html(this.template({data:_dataSet}));
		        		
		        	}
		        	catch(error){
		        		console.log(error);
		        	}
		        	
		        },
		        validateAndNavigateFromStep1:function(){
		        	if(this.model.validate('gpm-update-form',true)){
		        		this.model.setChangedValue();
		        		if(this.model.getChangedItems().length>0){
		        			$('.gpm-step.step1').addClass("finished").removeClass("active");
				        	$('.gpm-step.step2').addClass("active");
				        	Backbone.history.navigate('gpm/verification/'+this.model.get('updateMode'), true);
		        		}else{
		        			Utils.showNoChangesMessageToUser();
		        		}
			        	
		        	}
		        },
		        limitEditContactGreet: function (e) {
		            if ($('#editContactGreet').val().length >= 40) {
		                e.stopPropagation();
		                e.preventDefault();
		                return false;
		            }
		        }
		        
		    });
		    return greetingsView;
		});