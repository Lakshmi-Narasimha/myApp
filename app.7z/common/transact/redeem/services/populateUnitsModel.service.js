/**
 * @ngdoc service
 * @name unitsModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var unitsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _units = null;
    
    var unitsModel = {
        fetchUnitsValue : function () {

            var deferred = $q.defer();
            Restangular.all('/getUnitsValue').getList().then(function (units) {
                deferred.resolve(units);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setUnits : function(units) {
            _units = units;
        },

        getUnits : function() {
            return _units;
        }
    };
    return unitsModel;
};

unitsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];

module.exports = unitsModel;