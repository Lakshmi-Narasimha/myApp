var express = require('express');
var https = require('https');
var http = require('http');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var router = express.Router();
var engagementModel = require('./engagement.model');
var getMessageModel = require('../getMessage/getMessage.model');
var dataPassModel = require('../dataPass/dataPass.model');

var apiUtils = require('../../common/apiUtils');

/* Trigerring the Engagement API on request from Client */
// API Route
router.route('/mfchat/rest/engagement')
    .post(function(req, res) {
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID];
        req.session.agentGroupID = req.body.RequestParams.agentGroupID;
        req.session.nickName = req.body.RequestParams.nickName;
        req.session.accRole = req.body.RequestParams.accRole;
        req.session.MDN = req.body.RequestParams.MDN;

        /* Trigerring the Engagement API internally to TC */
        var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
        var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path + '&InitialMessage=' + initialMessage,
            headers: {
                'Cookie': req.sessionCookie,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            proxyResponse.on('data', function(chunk) {
                logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk));
                chunk = JSON.parse(chunk);
                console.log('EngmntResponse:', chunk.engagementID);

                if (chunk.engagementID) {
                    engagementModel.response.Page.status = (chunk.status === "queued" ? "accepted" : chunk.status);
                    engagementModel.response.Page.engagementID = req.engagementID = req.session.engagementID = chunk.engagementID; /// storing engagementID into the session
                    engagementModel.response.Page.customerID = req.session.customerID = chunk.customerID; /// storing customerID into the session

                    /* After three times GET Call */
                    apiUtils.getMsgMultiCall(req, res, function(chunk) {
                        chunk = JSON.parse(chunk);
                        //console.log("FinalResponse:", chunk);
                        //console.log('GetMessageResponse:',engagementModel.response.ModuleMap.Support.msgList[0].messageType);
                        //console.log("chunk.messages[0]",chunk.messages[0]);
                        if (chunk.messages[0] && chunk.messages[0].agentID || req.session.agentID) {
                            engagementModel.response.Page.agentName = req.session.agentName = (req.session.agentName || chunk.messages[0]['agent.alias']); /// storing agentName into the session
                            engagementModel.response.Page.agentID = req.session.agentID = (req.session.agentID || chunk.messages[0].agentID); /// storing agentID into the session
                            //console.log('session contains:', req.session);
                            engagementModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                            engagementModel.response.ModuleMap.Support.msgList[0].agentGroupID = chunk.messages[0].agentGroupID;
                            engagementModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                            engagementModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                            engagementModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['agent.alias'] + " joined the conversation";
                            engagementModel.response.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0]['agent.alias'];
                            engagementModel.response.ModuleMap.Support.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0]['agent.alias'];
                        }
                        /* Condition to make the DataPass call */
                        if (req.session.agentGroupID !== 'WirelessSales') {
                            apiUtils.dataPass(req, res, function(res) {
                                //logger.access.info(req.body);
                                console.log("Data Pass Call Trigerred");
                                apiUtils.generateToken(req, res, function(tokenResponse) {
                                    //  logger.access.info(req.body);
                                    console.log("generateToken Call Trigerred");
                                    var url;
                                    var port;
                                    if (tokenResponse.data.primaryMS && tokenResponse.data.primaryMS !== null) {
                                        var primaryMS = {
                                            //url: 'dev1ms.sdc.vzwcorp.com',
                                            port: tokenResponse.data.primaryMS.slice(-4),
                                            url: tokenResponse.data.primaryMS.slice(0, -5)
                                                //port: '1885'
                                        };
                                        engagementModel.response.Page.primaryMS = primaryMS;
                                        console.log("engagementModel.response.Page.primaryMS", engagementModel.response.Page.primaryMS);
                                    } else {
                                        engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                                    }
                                    if (tokenResponse.data.secondaryMS && tokenResponse.data.secondaryMS !== null) {
                                        var secondaryMS = {
                                            //url: 'dev1ms.sdc.vzwcorp.com',
                                            port: tokenResponse.data.secondaryMS.slice(-4),
                                            url: tokenResponse.data.secondaryMS.slice(0, -5)
                                                //port: '1885'
                                        };
                                        engagementModel.response.Page.secondaryMS = secondaryMS;
                                        console.log("engagementModel.response.Page.secondaryMS", engagementModel.response.Page.secondaryMS);
                                    } else {
                                        engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                                    }
                                    engagementModel.response.Page.token = tokenResponse.data.token;
                                    engagementModel.response.Page.deviceId = tokenResponse.data.deviceId;
                                    engagementModel.response.Page.topic = tokenResponse.data.topic;
                                    logger.outBoundData.info(logger.formatResMsg(req, engagementModel.response));
                                    res.send(engagementModel.response);
                                });
                                //res.send(engagementModel.response);
                            });
                        } else {
                            apiUtils.generateToken(req, res, function(tokenResponse) {
                                var url;
                                var port;
                                if (tokenResponse.data.primaryMS !== null) {
                                    var primaryMS = {
                                        port: tokenResponse.data.primaryMS.slice(-4),
                                        url: tokenResponse.data.primaryMS.slice(0, -5)
                                    };
                                    engagementModel.response.Page.primaryMS = primaryMS;
                                    console.log("engagementModel.response.Page.primaryMS", engagementModel.response.Page.primaryMS);
                                } else {
                                    engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                                }
                                if (tokenResponse.data.secondaryMS !== null) {
                                    var secondaryMS = {
                                        port: tokenResponse.data.secondaryMS.slice(-4),
                                        url: tokenResponse.data.secondaryMS.slice(0, -5)
                                    };
                                    engagementModel.response.Page.secondaryMS = secondaryMS;
                                    console.log("engagementModel.response.Page.secondaryMS", engagementModel.response.Page.secondaryMS);
                                } else {
                                    engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                                }
                                engagementModel.response.Page.token = tokenResponse.data.token;
                                engagementModel.response.Page.deviceId = tokenResponse.data.deviceId;
                                engagementModel.response.Page.topic = tokenResponse.data.topic;
                                logger.outBoundData.info(logger.formatResMsg(req, engagementModel.response));
                                res.send(engagementModel.response);
                            });
                        }
                    });


                } else {
                    var errObj = {
                        message: 'ERROR!!! Something went wrong while retrieving data.',
                        statusCode: res.statusCode
                    };
                    res.send(errObj);
                    logger.error.error(logger.formatResMsg(req, errObj));
                }
            });
            proxyResponse.on('error', function(err) {
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
                logger.error.error(logger.formatResMsg(req, err));
            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
