/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var fticSearch = function(eventConstants,searchResultModel) {
	return {
            template: require('./basicSearch.html'),
            restrict: 'E',
            replace: true,
            scope: {
              
            },
            controller: function($scope, $element, $attrs){
                $scope.searchOption = "";

                $scope.searchData ={
                    searchText: ""                     
                };

                $scope.investorSearch = function(){
                  if(typeof($scope.searchData.searchText)=='object'){
                   $scope.searchData.searchText = $scope.searchData.searchText.first_name;
                  }                 
                    
                  if ($scope.searchData.searchText.length > 2) {
                      console.log("listen to 'eventConstants.SHOW_SEARCH_RESULT' to show the search result");
                      searchResultModel.setSearchParam({searchText: $scope.searchData.searchText, searchOption: $scope.searchOption});
                      $scope.$emit(eventConstants.SHOW_SEARCH_RESULT, searchResultModel.getSearchParam());
                     
                  }
                  else{
                      //$scope.searchTextChanged()
                      console.log("enter 3 character to get search result");

                  }               
                }

                $scope.searchTextChanged = function(){
                    //if string length<3 hide the search result;                 
                    if($scope.searchData.searchText.length<2){
                      console.log("listen to 'eventConstants.HIDE_SEARCH_RESULT' to hide the search result");
                      $scope.$emit(eventConstants.HIDE_SEARCH_RESULT, {});
                      $scope.suggestions = [];                                       
                    }else{
                      console.log("emit "+ eventConstants.GET_SUGGESTIONS)
                      $scope.$emit(eventConstants.GET_SUGGESTIONS, {searchText: $scope.searchData.searchText, searchOption: $scope.searchOption});
                    }
                }

                $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, function (event, args) {                  
                  $scope.searchOption = args.req.lable;
                  $scope.searchData.searchText="";
                });

                $scope.$on(eventConstants.SET_SUGGESTIONS, function (event, args) {
                  $scope.suggestions = args.suggestions;
                });

                $scope.$on('RESET_SEARCH_OPTION',function(event, data){
                  $scope.searchData.searchText="";
                });
              
            },
            link: function(scope, iElement, iAttrs, controller){                    
                scope.searchedText = "";
                scope.results = [];
                scope.suggestions = [];
            }
        };
};

fticSearch.$inject = ['eventConstants','searchResultModel'];
module.exports = fticSearch;