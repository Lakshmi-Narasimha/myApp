var config = require('../../../config/config');

var sendMessageModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [

                ],
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "fe225440-2751-4314-a8f4-4f2aeb02d104",
                    "type": "Success"
                }
            }
        },
        "Page": {
            "showChatHistory": false,
            "parentPageType": "myData",
            "agentBusy": false,
            "callType": "sendMessage",
            "timeToWait": null,
            "pageType": "livechat"
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "fe225440-2751-4314-a8f4-4f2aeb02d104",
            "type": "Success"
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_SEND_MSG_URI
    }
};

module.exports = sendMessageModelConfig;
