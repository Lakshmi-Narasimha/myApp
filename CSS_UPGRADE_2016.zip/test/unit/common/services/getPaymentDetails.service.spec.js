(function() {

    'use strict';

    describe('get Payment details service', function() {
        var resultData, timeout, $httpBackend, service;

        var successCallback = function(data) {
            resultData = data;
        };

        var errorObj = {
            'errorMessageCode': 500,
            'transactionStatus': 'Error',
            'errorDescription': 'Something went wrong...',
        };

        var PaymentDetails = {
            "uiErrorDisplayMessage": "",
            "transactionStatus": "S",
            "transactionDescription": "",
            "transactionCode": "",
            "region": "",
            "postalCode": "60606",
            "policies": [{
                "policyContractNumber": "900500520",
                "lineOfBusiness": "HOME"
            }, {
                "policyContractNumber": "230500520",
                "lineOfBusiness": "AUTO"
            }, {
                "policyContractNumber": "560500520",
                "lineOfBusiness": "UMBRELLA"
            }, {
                "policyContractNumber": "140500520",
                "lineOfBusiness": "AUTO"
            }],
            "paymentPlanCode": "2-Pay-12 Months",
            "billingScheduledMaintenance": "N",
            "estimatedDowntime": "01:56:07",
            "systemDateTime": "2016-01-01T11:59:04.159Z",
            "paymentDueDate": "2016-01-03",
            "outStandingAmountCurrency": "USD",
            "outStandingAmount": "50000.00",
            "minPaymentDueAmountCurrency": "USD",
            "minPaymentDueAmount": "23000.00",
            "isMultiPolicyAccount": "N",
            "fullName": "GAYLE JOHNSON",
            "city": "Princeton",
            "billingAccountNumber": "T718142962",
            "agentOfRecord": "13053T",
            "addressLine1": "1119 Fairway Dr",
            "accountStatus": "Active",
            "loginURL": "https://csstw.farmers.com/",
            "registerURL": null
        };

        beforeEach(module('CSS.common'));

        beforeEach(inject(function(getPaymentDetailsSevice, $timeout, $injector) {
            service = getPaymentDetailsSevice;
            timeout = $timeout;
            $httpBackend = $injector.get('$httpBackend');
        }));

        it('service should be defined...', function() {
            expect(service).toBeDefined();
        });

        it('should getPaymentDetails service to be called, then should respond with success object ...', function() {
            var obj = {
                policyContractNumber: null,
                zipCode: "null"
            };

            $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', obj.zipCode).respond(PaymentDetails);
            service.getPaymentDetails(obj.zipCode).then(function(data) {
                expect(data.transactionStatus).not.toEqual("E");
            });
            timeout.flush();
            $httpBackend.flush();
        });

        it('should getPaymentDetails service to be called, then should respond with with failure object ...', function() {
            var obj = {
                policyContractNumber: null,
                zipCode: "null"
            };

            var errorCallback = function(data) {
                expect(data.transactionStatus).toBe('Error');
            };

            $httpBackend.expectPOST('http://localhost:9900/getPaymentDetails/getPaymentDetails', obj.zipCode).respond(404, errorObj);
            service.getPaymentDetails(obj.zipCode).then(successCallback, errorCallback);

            timeout.flush();
            $httpBackend.flush();
        });

    });

})();
