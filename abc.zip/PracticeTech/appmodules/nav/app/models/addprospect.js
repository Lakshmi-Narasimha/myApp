define(['jquery', 'backbone', 'breeze'
], function ($, Backbone, Breeze) {
    var Prospect = Backbone.Model.extend({
        defaults: {
        	contactType: undefined,
        	marketSource: undefined,
        	Phones: undefined,
        	Addresses: undefined,
        	WebAddresses :undefined,
        	PersonContact:undefined
        }
    });
    var Phones = Backbone.Model.extend({
        defaults: {
        	CountryCode: undefined,
        	ElectronicDownload: "0",
        	type: "Phone",
        	PhoneType: undefined,
        	PhoneTypeDesc:undefined,
        	AreaCode:undefined,
        	Number:undefined,
        	Extension:undefined
        }
    });    

    var Addresses = Backbone.Model.extend({
        defaults: {
        	type: "Address",
        	AddressType: undefined,
        	AddressTypeDesc: undefined,
        	Line1: undefined,
        	Line2:undefined,
        	City:undefined,
        	State:undefined,
        	Postal:undefined,
        	Country:undefined,
        	ElectronicDownload:"0"
        }
    });
    
    var WebAddresses = Backbone.Model.extend({
        defaults: {
        	type: "WebAddresses",
        	WebAddressType: "1",
        	WebAddressTypeDesc: "Email",
        	Address: undefined,
        	ElectronicDownload:"0"
        }
    });
    
    var PersonContact = Backbone.Model.extend({
        defaults: {
        	type: "PersonContact",
        	clTitle: undefined,
        	clGreeting: undefined,
        	clSuffix: undefined,
        	clFirstNm:undefined,
        	clMidNm:undefined,
        	clLastNm:undefined,
        	clSfxTxt:undefined,
        	clHnrfNm:undefined,
        	clTaxId:undefined,
        	
        	clCitizenShip:undefined,
        	clDob:undefined,
        	clGender:undefined,
        	clMarital:undefined,
        	clNoOfChildren:undefined,
        	clOccupation:undefined,
        	clJobTitle:undefined
        }
    });
    
    return EventsCollection = {
		Prospect:Prospect,
		Phones:Phones,
    	Addresses:Addresses,
        WebAddresses: WebAddresses,
        PersonContact: PersonContact
    };
});
