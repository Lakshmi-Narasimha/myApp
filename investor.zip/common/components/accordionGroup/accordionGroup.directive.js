/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @requires $timeout
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accordionGroup = function($state, $timeout, $stateParams) {
	return {
            template: require('./accordionGroup.html'),
            restrict: 'E',
            replace: true,
            scope: {
              accordionData: "=",
              showTab :'=?',
              tabActive:'='
            },
            controller: function($scope, $element, $attrs){  
            },
            link: function(scope, iElement, iAttrs, controller){                                

                scope.openStatus = [];
                angular.forEach(scope.accordionData,function(v,i){                    
                    scope.openStatus.push(false);
                })                
                if(scope.showTab!=null || scope.showTab!=undefined)
                {
                    scope.$on("showTabView",function(event,tabNo){       
                        // scope.showTab = tabNo; 
                        scope.openStatus[tabNo] = true;
                        if(tabNo > -1 && tabNo < 4)                
                        {   
                            if(scope.showTab == tabNo) { 
                                scope.pan = $stateParams.xParam == 1 ? 0 : 1;
                                $state.go(scope.accordionData[tabNo].uiref, {'xParam': scope.pan});
                                scope.$emit("updateKeyValueListPan");
                            }
                            else {
                                $state.go(scope.accordionData[tabNo].uiref);                                                                  
                            }
                        }
                        else
                        {
                            $state.go(scope.accordionData[0].uiref);
                        }                    
                    })

                }                    
                else
                {
                    $state.go(scope.accordionData[0].uiref);
                };
                scope.navigateToState = function($event, state, $index){
                    if(scope.showTab === -1){                     
                        $event.stopPropagation();
                        $event.preventDefault();
                    }
                    $state.go(state);
                };                
            }
        };
};

accordionGroup.$inject = ["$state", "$timeout", "$stateParams"];
module.exports = accordionGroup;