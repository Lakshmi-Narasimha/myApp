/**
 * @ngdoc filter
 * @name fticCommaDigitsFilter
 * @description
 *
 * - This common filter is used to display Commas for number.
 *
 */
'use strict';

var fticAddComma = function() {
    return function(value) {

        var n = value,
            parts, val;
        if (n !== 0 && !n) {
            return '';
        } else {
            parts = (n).toFixed(2).split('.'),
                val = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            return val;
        }

    };
};

fticAddComma.$inject = [];
module.exports = fticAddComma;