﻿﻿define([
], function () {
    //Modules are defined as such
    var clientContext = function () {
    }
    clientContext.prototype.global = {

    }
    clientContext.prototype.setCaplistFullName = function (arg) {
        practicetech.clientContext.data.clSfxTxt = arg;
       
        if (/JR|SR|Senior|Junior/i.test(practicetech.clientContext.data.clSfxTxt))
        {
            practicetech.clientContext.data.clSfxTxt = practicetech.clientContext.data.clSfxTxt.toLowerCase();
            practicetech.clientContext.data.clSfxTxt = practicetech.clientContext.data.clSfxTxt.charAt(0).toUpperCase() + practicetech.clientContext.data.clSfxTxt.slice(1);
        }
        return practicetech.clientContext.data.clSfxTxt;
    }
    clientContext.prototype.getCaplistFullName = function () {
        var contactProfileId = $("#groupDivClientName");
        if (typeof practicetech.clientContext.data.clSfxTxt !== 'undefined' && practicetech.clientContext.data.clSfxTxt !== "null" && practicetech.clientContext.data.clSfxTxt !== null) {
           if (practicetech.clientContext.data.clSfxTxt.indexOf(':')!=-1) {
            var fullName=null,sfxName=null,result=null,fName=null,mName=null,lName=null,sufName=null,finFirMidLLastSufName=null,trimResult=null; 
            sfxName = practicetech.clientContext.data.clSfxTxt.trim();
            trimResult = sfxName.split(":");
            fName= trimResult[0], mName= trimResult[1], lName= trimResult[2], sufName= trimResult[3];
            fName=capitalizeFirstLetterEachWordSplitBySpace(fName);
            mName=mName.substring(0,1).toUpperCase();
            lName=capitalizeFirstLetterEachWordSplitBySpace(lName);
            if (sufName.toUpperCase()=='JR' || sufName.toUpperCase()=='SR'|| sufName.toUpperCase()=='JUNIOR' || sufName.toUpperCase()=='SENIOR' ) {
                sufName=capitalizeFirstLetterEachWordSplitBySpace(sufName);
            } if (sufName !== "null" && sufName !== null && sufName !== 'undefined'){
                finFirMidLLastSufName = fName+" "+mName+" "+lName+" "+sufName;
            } else {
                finFirMidLLastSufName = fName+" "+mName+" "+lName;
            }            
            contactProfileId.text(finFirMidLLastSufName);
            } else {
                contactProfileId.text(contactProfileId.text() + " " + practicetech.clientContext.data.clSfxTxt);
            } 
            function capitalizeFirstLetterEachWordSplitBySpace(string){
                var words = string.split(" ");
                var output = "";
                    for (i = 0 ; i < words.length; i ++){
                    lowerWord = words[i].toLowerCase();
                    lowerWord = lowerWord.trim();
                    capitalizedWord = lowerWord.slice(0,1).toUpperCase() + lowerWord.slice(1);
                    output += capitalizedWord;
                        if (i != words.length-1){
                        output+=" ";
                        }
                    }
            output[output.length-1] = '';
            return output;
            }           
        }
    }
    clientContext.prototype.data = {
        contactProfileId: null,
        clSfxTxt : null,
    }
    return clientContext;
})