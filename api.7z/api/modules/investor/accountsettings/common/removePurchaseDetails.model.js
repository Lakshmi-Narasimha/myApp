// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var RemovePurchaseDetailsSchema = new mongoose.Schema({
    removePurchaseResp: {
        type: Object,
        "default": {}
    }
});

var RemovePurchaseLookUp = mongoose.model('RemovePurchaseLookUp', RemovePurchaseDetailsSchema);

var RemovePurchaseModel = new RemovePurchaseLookUp({
      removePurchaseResp: {
      "status": "true",
      "webRefNo": "EM00001025"
    }
});

RemovePurchaseLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating RemovePurchaseLookUp table, please contact admin...');
    } else {
        RemovePurchaseLookUp.remove({}, function(err) {
            console.log('RemovePurchaseModel collection removed');
            RemovePurchaseModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RemovePurchaseLookUp table, please contact admin...');
                }
                console.log('RemovePurchaseLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RemovePurchaseLookUp;
