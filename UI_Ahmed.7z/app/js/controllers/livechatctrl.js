module.exports = function($scope, $window, $timeout, chatServices) {
    var endChatWindow = null;
    $scope.ChatLineMsgs = [];
    $scope.viewModel = {
        isAgentTyping: false
    };
    $scope.isTyping = [];
    $scope.userQuery = {
        name: 'John Doe',
        messageText: '',
        chatTime: new Date(),
        isUser: true,
        image: '././assets/customer.png'
    };
    $scope.openWindow = function() {
        if (endChatWindow) {
            endChatWindow.close();
        }
        endChatWindow = $window.open('#/endchat', 'end-chat', 'toolbar=0,status=1,width=1100,height=900,left=10%,top=10%', "_blank");
    };
    $scope.sendQuery = function() {
        var query = {
            userInput: $scope.userQuery.messageText
        };
        $scope.userQuery.chatTime = new Date();
        $scope.ChatLineMsgs.push(angular.copy($scope.userQuery));
        $scope.userQuery.messageText = '';
        $scope.viewModel.isAgentTyping = true;
        $scope.isTyping.push($scope.viewModel);
        $timeout(function() {
        $scope.viewModel.isAgentTyping = false;
        chatServices.liveChat(query).then(function(data){
          console.log(data);
         var agentReply = data.ModuleMap.Support.msgList[0].messageList[0];
          //$scope.userQuery.messageText = '';
          agentReply.name = 'Lucy Doe';
          agentReply.chatTime = new Date();
          agentReply.image = '././assets/contactus.png';
          $scope.ChatLineMsgs.push(agentReply);
          console.log(agentReply.content);
        }, function(err){
          console.log(err);
        });
        }, 3000);
        // chatServices.liveChat(query).then(function(data) {
        //     $scope.viewModel.isAgentTyping = false;
        //     console.log(data);
        //     data.name = 'Lucy Doe';
        //     data.chatTime = new Date();
        //     data.image = 'http://bootdey.com/img/Content/avatar/avatar1.png';
        //     $scope.ChatLineMsgs.push(data);
        // }, function(err) {
        //     console.log(err);
        // });
    };

};
