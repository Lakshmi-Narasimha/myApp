'use strict';

var fticbreadcrumbs = function (fticLoggerMessage, loggerConstants, fticStateChange) {
    return {
        template: require('./breadcrumbs.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            $scope.breadcrumbs = [];
            /*
				breadcrumb = {
					text : '',
					state : ''
				}
            */

            $scope.on('addBreadCrumb',function(){
            	$scope.breadcrumbs.push(breadcrumb)
            })
            $scope.goState = function(breadcrumb) {
                fticStateChange.stateChange($state, breadcrumb.state);
                //$state.go(breadcrumb.state)
            }
            	
        }]
        
    }
};
fticbreadcrumbs.$inject = ['fticLoggerMessage', 'loggerConstants', 'fticStateChange'];
module.exports = fticbreadcrumbs;