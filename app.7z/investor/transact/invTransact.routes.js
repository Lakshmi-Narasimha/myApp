'use strict';

function transactRoutes($stateProvider) {
    // Transact
    var invTransactMasterState = {
        parent: 'home',
        name: 'invTransact', // state name
        url: 'invTransact', // url path that activates this state
        views: {
            'dashboard@home': {
                template: require('./invTransactMaster.html'),
                controller: 'invTransactMasterCtrl'
            }
        }
    };

    // Transact
    var invTransactState = {
        parent: 'invTransact',
        name: 'invTransact.base', // state name,
        abstract: true,
        url: '/base', // url path that activates this state,

        views: {
            'masterView': {
                template: require('./invTransact.html'),
                controller: 'invTransactCtrl'
            }
        }
    };

    var invReviewState = {
        parent: 'invTransact',
        name: 'invTransact.review', // state name
        abstract: true,
        url: '/review', // url path that activates this state
        views: {
            'masterView': {
                template: require('../../common/transact/review/review.html'),
                controller: 'ReviewCtrl'
            }
        }
    };

    var invTxnDetailsState = {
        parent: 'invTransact',
        name: 'invTransact.txnDetails', // state name
        url: '/txnDetails', // url path that activates this state
        views: {
            'masterView': {
                template: require('./invtransactiondetails/invTransactionDetails.html'),
                controller: 'invTransactionDetailsCtrl'
            }
        },
        params: {
            stateType: null
        }
    };

    var switchState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.switch', // state name
        url: '/switch', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/switch/switch.html'),
                controller: 'SwitchCtrl'
            }
        }
    };



    // SWPState
    var swpState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.swp', // state name
        url: '/swp', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/swp/swp.html'),
                controller: 'SwpController'
            }
        }
    };
    
    
    
    var invSwpReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.swp', // state name
        url: '/swp', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/swp/reviewswp.html'),
                controller: 'ReviewSwpCtrl'
            }
        }
    };

    var invSwpTxnDetailsState = {
        parent: 'invTransact.txnDetails',
        name: 'invTransact.txnDetails.swp', // state name
        url: '/swp', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('../../common/transact/swp/swptxndetails.html'),
                controller: 'SwpTxnController'
            }
        }
    };

  
    var invCstpReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.cancelStp', // state name
        url: '/cancelStp', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/cancelStp/components/cstpReview/cstpReview.html'),
                controller: 'cstpDetailsReviewController'
            }
        }
    };

    var invSwitchReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.switch', // state name
        url: '/switch', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/switch/reviewSwitch.html'),
                controller: 'ReviewSwitchCtrl'
            }
        }
    };

    //DTP Review state
    var invDtpReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.dtp', // state name
        url: '/dtp', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/dtp/reviewDTP.html'),
                controller: 'ReviewDTPCtrl'
            }
        }
    };
    //DTP Trasnaction Details
    var invDtpTxnDetailsState = {
        parent: 'invTransact.txnDetails',
        name: 'invTransact.txnDetails.dtp', // state name
        url: '/dtp', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('../../common/transact/dtp/dtpTxndetails.html'),
                controller: 'DtpTxnController'
            }
        }
    };
    //cancel STP state

    var cancelStpState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.cancelStp', // state name
        url: '/cancelStp', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/cancelStp/cancelStp.html'),
                controller: 'cancelStpController'
            },
            'selectFundView': {
                template: require('../../common/transact/selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            },
            'selectInvFolioTransactView': {
                template: require('../../common/transact/selectInvFolioTransact.html'),
                controller: 'selectInvFolioTransactCtrl'
            }
        }
    };
    //DTP State
    var dtpState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.dtp', // state name
        url: '/dtp', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/dtp/dtp.html'),
                controller: 'dtpController'
            }/*,
            'selectFundView': {
                template: require('../../common/transact/selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            },
            'selectInvFolioTransactView': {
                template: require('../../common/transact/selectInvFolioTransact.html'),
                controller: 'selectInvFolioTransactCtrl'
            }*/
        }
    };
    // Stp base State
    var stpState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.stp', // state name
        url: '/stp', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/stp/stp.html'),
                controller: 'StpController'
            }
        }
    };
    // Stp review State
    var invStpReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.stp', // state name
        url: '/stp', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/stp/stpdetailsreview/stpDetailsReview.html'),
                controller: 'stpDetailsReviewController'
            }
        }
    };
    // Stp Transaction Details State
    var invStpTxnDetailsState = {
        parent: 'invTransact.txnDetails',
        name: 'invTransact.txnDetails.stp', // state name
        url: '/stp', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('../../common/transact/stp/stptransactiondetails/stpTransactionDetails.html'),
                controller: 'stpTransactionDetailsController'
            }
        }
    };
    var redeemState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.redeem',
        url: '/redeem',
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/redeem/redeem.html'),
                controller: 'RedeemCtrl'
            }
        }
    };

    var invRedeemReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.redeem',
        url: '/redeem',
        views: {
            'review': {
                template: require('../../common/transact/redeem/reviewRedeem.html'),
                controller: 'ReviewRedeemCtrl'
            }
        }
    };
    // RenewSipState
    
    var renewSipState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.renewsip', // state name
        url: '/renewsip', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/renewsip/renewsip.html'),
                controller: 'RenewSipCtrl'
            },
            'payDetView': {
                template: require('../../common/transact/renewsip/payDetails.html'),
                controller: 'PayDetailsCtrl'
            }
        }

    };

     var renewReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.renewsip', // state name
        url: '/renewsip', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/renewsip/renewSipReview.html'),
                controller: 'ReviewSipCtrl'
            }
        }
    };

     //Buy State
    var invBuyState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.buy',
        url: '/buy',
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/buy/buy.html'),
                controller: 'buyController'
            },
            'nomineeDetailsView': {
                template: require('../../common/transact/addNominee.html'),
                controller: 'addNomineeCtrl'
            }

        }
    };
    // Buy review State
    var invBuyReviewState = {
        parent: 'invTransact.review',
        name: 'invTransact.review.buy', // state name
        url: '/buy', // url path that activates this state
        views: {
            'review': {
                template: require('../../common/transact/buy/reviewBuy.html'),
                controller: 'ReviewBuyCtrl'
            }
        }
    };    


    var invNewFolioRNewInvestor = {
        parent: 'invTransact',
        name: 'invTransact.base.newFolioNnewInvestor',
        url: '/newFolioNnewInvestor',
        views: {
            'masterView': {
                template: require('../../common/transact/newFolioNNewInvestor/newFolioNnewInvestor.html'),
                controller: 'newFolioNnewInvestorCtrl'
            }
        }
    };

        //Modify a SIP
    var invModifySipState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.modifysip', // state name
        url: '/modifysip', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/modifysip/modifysip.html'),
                controller: 'modifySipController'
            },
            'payDetView': {
                template: require('../../common/transact/modifysip/payDet.html'),
                controller: 'PayDetController'
            }
        }
    };

    var invModifySipTxnDetailsState = {
        parent: 'invTransact.txnDetails',
        name: 'invTransact.txnDetails.modifysip', // state name
        url: '/modifysip', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('../../common/transact/modifysip/modifysipTxnDetails.html'),
                controller: 'ModifySipTxnDetController'
            }
        }
    };

    var kycAdditionalDtlsState = {
        parent: 'invTransact',
        name: 'invTransact.base.kycForm',
        url: '/kycForm',
        views: {
            'masterView': {
                template: require('../../common/transact/kycAdditionalDetails/kycAdditionalDetails.html'),
                controller: 'kycAdditionalDetailsCtrl'
            }
        }
    };

    // SIP State
    var sipState = {
        parent: 'invTransact.base',
        name: 'invTransact.base.sip', // state name
        url: '/sip', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'transactView': {
                template: require('../../common/transact/sip/sip.html'),
                controller: 'sipController'
            },
            'selectFundView': {
                template: require('../../common/transact/selectFundBuy.html'),
                controller: 'SelectFundBuyCtrl'
            }
        }
    };


    $stateProvider
        .state(invTransactMasterState)
        .state(invTransactState)
        .state(invTxnDetailsState)
        .state(switchState)
        .state(invReviewState)
        .state(swpState)
        .state(invSwpReviewState)
        .state(invSwpTxnDetailsState)
        .state(stpState)
        .state(dtpState)
        .state(redeemState)
        .state(cancelStpState)
        .state(invStpReviewState)
        .state(invCstpReviewState)
        .state(invRedeemReviewState)
        .state(invStpTxnDetailsState)
        .state(invSwitchReviewState)
        .state(invDtpReviewState)
        .state(invDtpTxnDetailsState)    
        .state(invNewFolioRNewInvestor)
        .state(renewSipState)
        .state(invBuyState)
        .state(invBuyReviewState)
        .state(invModifySipState)
        .state(invModifySipTxnDetailsState)
        .state(kycAdditionalDtlsState)
        .state(sipState)
        .state(renewReviewState)
        ;

}

transactRoutes.$inject = ['$stateProvider'];
module.exports = transactRoutes;
