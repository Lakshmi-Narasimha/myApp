'use strict';

var recommendation = function($state,fticRecommAndNotifiModel,constants,$filter,$window,eventConstants, $cookies) {
    return {
            template: require('./recommendation.html'),
            restrict: 'E',
            replace: true,
            scope: {                
                
            },
            controller: ['$scope', function($scope){
                $scope.recommendationsToDisplay = [];
                $scope.$on(eventConstants.RECOMM_AND_NOTIFI_DATA,function(event,data){
                    $scope.recommendationCount = 0;
                    $scope.recommendationsWRSN = [];
                    $scope.recommandNotifiData = fticRecommAndNotifiModel.getRecommAndNotifiReport();
                    $scope.recommendations = $scope.recommandNotifiData.recommendations;
                    if($scope.recommendations !='' && $scope.recommendations != null){
                        for(var i=0;i<$scope.recommendations.length;i++){
                            if($scope.recommendations[i].readStatus === 'N'){
                                $scope.recommendationCount = $scope.recommendationCount+1;
                                $scope.recommendationsWRSN.push($scope.recommendations[i]);
                            }
                        }  
                    }
                    
                    //$scope.recommendationCount = $scope.recommendations.length;
                });
                var redirectAdvisorApp = $cookies.get('userRedirectURI');
                $scope.allRecmmondations = function(){
                    $scope.$emit(eventConstants.NAVIGATE_CHECK, redirectAdvisorApp+'#/recommendationsreport');
                    // $state.go('recommendationsreport');
                    //$window.location.href=redirectAdvisorApp+"/#/recommendationsreport";
                    $scope.closePop=false;
                };
                $scope.recommendationClick = function(index){
                    //$state.go('recommendationsreport');
                    //$window.location.href=redirectAdvisorApp+"/#/recommendationsreport";
                    $scope.$emit(eventConstants.NAVIGATE_CHECK, redirectAdvisorApp+'#/recommendationsreport');
                    $scope.closePop=false;
                $scope.$emit($filter('translate')(constants.RECOM_CLICKED_TEXT),$scope.recommendationsWRSN[index]);
                };
                    
            }]
        };
};

recommendation.$inject = ['$state','fticRecommAndNotifiModel','constants','$filter','$window','eventConstants', '$cookies'];
module.exports = recommendation;