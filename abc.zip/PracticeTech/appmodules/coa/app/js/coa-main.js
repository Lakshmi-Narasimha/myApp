coa = coa || {};
if (typeof console == "undefined" || typeof console == undefined) {
	console = {};
	console.log = function() {
	};
}

define(
		[ 'jquery', 'underscore', 'backbone', 'backbonesubroute',
				'appcommon/memmorymgr', 'config',
				'appmodules/coa/app/js/utils', 'appcommon/globalcontext',
			    'appcommon/analytics'],
		function($, _, Backbone, backbonesubroute, Memorymanger, Config, Utils,
				GlobalContext, Analytics) {

			requirejs(
					[ 'Base64',],
					function(Base64) {

						var FM_ID = Utils.readCookie('FMID');
						_sync = Backbone.sync;
						Backbone.sync = function(method, model, options) {
							options.beforeSend = function(xhr) {
								if (options.maxAge == "none"
										|| options.maxAge == undefined) {
								} else {
									try {
										xhr.setRequestHeader('cache-control',
												'max-age=' + options.maxAge);
									} catch (e) {
										xhr.setRequestHeader('cache-control',
												'max-age=0');
									}
								}

							};
							_sync.call(this, method, model, options);
						};
						// plugin for custom select//
						$.fn.customizeSelect = function () {
							$(this).trigger('change');
						}					    
						document.addEventListener("touchstart", function() {
						}, true);
						initStepnavLinksCoa();
						function initStepnavLinksCoa() {
							$(document).off('click',
									'.coa-btn-next,.coa-btn-back').on('click',
									'.coa-btn-next,.coa-btn-back',
									doStepNaviagationCoa);
						}
						function doStepNaviagationCoa() {
							var _clickedStep = parseInt($(
									'.coa-step.active .coa-step-no').text());
							var _$wrapper = $('.stepPanel-steps-wrapper'), _$step = $('.coa-step.step'
									+ _clickedStep), _toScrollLeft;
							var _wrapper = _$wrapper[0], _stepWdth = _$step
									.width(), _stepOffLeft = _$step.offset().left, _scrollWdth = ($(
									'.coa-steps-container').width() - _$wrapper
									.width());
							_toScrollLeft = (_wrapper.scrollLeft + _stepOffLeft
									+ _stepWdth / 2 - _scrollWdth / 2);
							_wrapper.scrollLeft = _toScrollLeft;

						}
						coa.numer = "number";
						coa.text = "text";
						coa.isMobile = Utils.isMobile();
						coa.initialServiceCounter = 0;
					});
			function calGetUserProfile() {
				var _data = {};
				var _url = 'js/data/mockGetUserProfile.json';
				Utils.getJson(_url, {}, function(resp) {
					var _advisorName = resp.fName + ' '
							+ (resp.mName ? (resp.mName + ' ') : '')
							+ resp.lName;
					coa.user.set('advisorName', _advisorName);
				}, function() {
					// for dev purpose only
					coa.user.set('advisorName', "Mathew Dotty");
				});
			}
		});