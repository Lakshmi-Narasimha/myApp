/**
 * @ngdoc factory
 * @name Investor Dashboard chart factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */

'use strict';

var purchasesDetailsFactory = function() {
    var purchasesDetailsFactory = {
        getPurchaseValues: function (investorData) {
            var keyValueList = [
                { key: 'First Holder', value: investorData.selectFolio.holders[0].name },
                { key: 'Folio No.', value: investorData.selectFolio.folioId },
                { key: 'Mode Of Holding', value: investorData.selectFolio.holdingType },
                { key: 'Invest Into', value: investorData.fundName.fundName },
                { key: 'Instruction Amount', value: investorData.amount },
                { key: 'Payment Method', value: investorData.paymentDtls.paymentMethod }
            ];
            return keyValueList;
        },
        getPurchaseGetValues: function (investorData) {
            var keyValueList = [
                { key: 'First Holder', value: investorData.firstHolder },
                { key: 'Folio No.', value: investorData.folioNo },
                { key: 'Mode Of Holding', value: investorData.modeOfHolding },
                { key: 'Invest Into', value: investorData.investInto },
                { key: 'Instruction Amount', value: investorData.instructionAmount },
                { key: 'Payment Method', value: investorData.paymentMethod }
            ];
            return keyValueList;
        },
        getRedeemValues: function (redeemInstructions) {
            var keyRedeemList = [
                { key: 'Instruction Amount', value: redeemInstructions.amount },
                { key: 'Bank Details', value: redeemInstructions.bankDetails },
                { key: 'Mode of Payment', value: redeemInstructions.modeOfPayment }
            ];
            return keyRedeemList;
        }
    };
    return purchasesDetailsFactory;
};

purchasesDetailsFactory.$inject = [];
module.exports = purchasesDetailsFactory;
