import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'chatbot-editor',
  templateUrl: './chatbot-editor.component.html',
  styleUrls: ['./chatbot-editor.component.css']
})
export class ChatbotEditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
