// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var EformsDetailsSchema = new mongoose.Schema({
    download: {
        type: Object,
        'default': {}
    }
});

var EformsDetailsLookUp = mongoose.model('EformsDetailsLookUp', EformsDetailsSchema);

var EformsDetailsModel = new EformsDetailsLookUp({
    'download':{
        'strDocBase64':'JVBERi0xLjUNJeLjz9MNCjgzMSAwIG9iajw8L0hbNDUzNiA0MTk4XS9MaW5lYXJpemVkIDEvRSAxNTA5NTAvTCAyODYwNDE5L04gOC9PIDg0NC9UIDI4NDM3NTE+Pg1lbmRvYmoNICAgICAgICAgICAgDQp4cmVmDQo4MzEgMjEyDQowMDAwMDAwMDE2IDAwMDAwIG4NCjAwMDAwMDg3MzQgMDAwMDAgbg0KMDAwMDAwNDUzNiAwMDAwMCBuDQowMDAwMDA5MDg5IDAwMDAwIG4NCjAwMDAwMTI0MTIgMDAwMDAgbg0KMDAwMDAxMjQ2NSAwMDAwMCBuDQowMDAwMDEyNTE4IDAwMDAwIG4NCjAwMDAwMTI1NzEgMDAwMDAgbg0KMDAwMDAxMjYyNCAwMDAwMCBuDQowMDAwMDEyNjc3IDAwMDAwIG4NCjAwMDAwMTI3MzAgMDAwMDAgbg0KMDAwMDAxMjc4MyAwMDAwMCBuDQowMDAwMDEyODM2IDAwMDAwIG4NCjAwMDAwMTI4ODkgMDAwMDAgbg0KMDAwMDAxMzM0NiAwMDAwMCBuDQowMDAwMDEzODIyIDAwMDAwIG4NCjAwMDAwMTM5NzIgMDAwMDAgbg0KMDAwMDAxNDEyNCAwMDAwMCBuDQowMDAwMDE0Mjc1IDAwMDAwIG4NCjAwMDAwMTQ0MjYgMDAwMDAgbg0KMDAwMDAxNDU3OCAwMDAwMCBuDQowMDAwMDE0NzMwIDAwMDAwIG4NCjAwMDAwMTQ4ODIg'
    }
});

EformsDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating EformsDetailsLookUp table, please contact admin...' + err);
    } else {
        EformsDetailsLookUp.remove({}, function(err) {
            console.log('EformsDetailsLookUp collection removed' + err);
            EformsDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating EformsDetailsLookUp table, please contact admin...');
                }
                console.log('EformsDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = EformsDetailsLookUp;
