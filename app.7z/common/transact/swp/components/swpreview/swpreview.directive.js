/**
 * @ngdoc property
 * @name fticSwpReview Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the SWP Review Status.
 *
 **/
'use strict';

var fticSwpReview = function (reviewSwpDetailsModel, eventConstants, $filter, swpReviewDetailsFactory, authenticationService) {
    return {
        template: require('./swpreview.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            var swpObj;
            var _userType = authenticationService.getUser().userType;
            var _isInvestor = authenticationService.isInvestorLoggedIn();
            swpObj = reviewSwpDetailsModel.getReviewSwpObj();
            var datefilter = $filter('date');
            $scope.swpAmount = swpObj.swpAmtValue;
            $scope.frequency = swpObj.frequency;
            /**
             * Code Changes Added for SWP Investor - CR - Start
             */
            if (_isInvestor) {

                $scope.startMonth = datefilter(swpObj.startMonth, 'MMMM yyyy');
                $scope.endMonth = datefilter(swpObj.endMonth, 'MMMM yyyy');
                $scope.startDate = swpObj.freqStartDaySelected.title + ' ' + $scope.startMonth;
                $scope.endDate = swpObj.freqEndDaySelected.title + ' ' +$scope.endMonth;
            } else {
                $scope.startDate = datefilter(swpObj.startDate, 'dd MMM yyyy');
                $scope.endDate = datefilter(swpObj.endDate, 'dd MMM yyyy');
            }
            /**
             * Code Changes Added for SWP Investor - CR - End
             */
            $scope.noofInstallments = swpObj.noofInstallments;
            $scope.bankDetails = swpObj.bankDetails;
            $scope.selectedMode = swpObj.selectedMode;
            $scope.selectedType = swpObj.selectedType;
            $scope.swpObj = swpReviewDetailsFactory.getFormattedSwpDetails.call($scope, _userType); 
        }]
    };
};

fticSwpReview.$inject = ['reviewSwpDetailsModel', 'eventConstants', '$filter', 'swpReviewDetailsFactory', 'authenticationService'];
module.exports = fticSwpReview;
