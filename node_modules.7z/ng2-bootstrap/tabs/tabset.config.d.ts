export declare class TabsetConfig {
    /** provides default navigation context class: 'tabs' or 'pills' */
    type: string;
}
