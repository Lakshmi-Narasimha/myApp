﻿define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
	'errorLog',
	'config',
    'services/dataservice',
    'appcommon/analytics',
    'text!appmodules/contactprofile/app/templates/contactbank.html',
	'appmodules/hoc/app/js/utils',
    'appcommon/commonutility',
    'appcommon/globalcontext',
    'appcommon/applauncher/device'
], function ($, _, Backbone, Spinner, ErrorLog, Config, Dataservice, Analytics, bankTemplate, HOCUtils, CommonUtilis, GlobalContext, Device) {
	var bankView = Backbone.View.extend({
		template: _.template(bankTemplate),
		el: $("#cp-content-container"),
		id: 'cp-content-container',
		events: {
		},
		initialize: function () {
			var that = this;
			$(document).off("click", ".exp-col-sm-bank").on("click", ".exp-col-sm-bank", function (e) {
				that.toggleExpColBank(e);
			});
			$(document).off("click", "#addBankAcc").on("click", "#addBankAcc", function (e) {
				that.addBankAccount(e);
			});
			$(document).off("click", ".bankupdate").on("click", ".bankupdate", function (e) {
				that.updateBankAccount(e);
				});
		},
		render: function (clId) {
			window.scroll(0, 0);
			var that = this;
			try {
			    Spinner.show();

                //Device Aware
			    Device.operatingSystem();
			    Device.physicalDevice();
			    Device.browser();
			    var _deviceInfo = Device.info;
			    var _deviceType = _deviceInfo.hardware.make;
			    var isDesktop = false;
			    if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface"))) {
			        isDesktop = true;
			    } else {
			        isDesktop = false;
			    }

				Dataservice.getClientInstructionSet(clId).then(function (result) {
					var bankResult = result.d.instructions.results;
					if(bankResult && result) {
					    $('#cp-content-container').html(that.template({ data: bankResult, isDesktop: isDesktop }));
						Spinner.hide();
					}
				}).fail(function (error) {
					Spinner.hide();
					ErrorLog.ErrorUtils.myError(error);
					});
				$(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
				$(".hdr-tab-buttons-wrap .bt-bank").addClass("hdr-tab-active");
			} catch (err) {
				ErrorLog.ErrorUtils.myError(err);
			} finally {}
		},
		addBankAccount: function (e) {
		    Analytics.analytics.recordAction("AddBankAccount:clicked");
		    var _link = Config.addBank;
		    this.contextPayLoad(_link, e);
        },
		updateBankAccount: function (e) {
		    Analytics.analytics.recordAction("UpdateBankAccount:clicked");
		    var _link = Config.updateBank;
			this.contextPayLoad(_link, e);
		},
		genericServiceErrorHandler: function (err) {
			Spinner.hide();
			HOCUtils.showServiceError(err);
		},
		contextPayLoad: function (linkName, e) {
			Spinner.show();
			var self = this;
			var _url = linkName;
        	var _contextId = null;
        	var _v2Compatible = true;
        	var async = false;
			var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
		    Dataservice.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
            	Spinner.hide();
            	if (response && response.d) {
            		_contextId = response.d.cntxId;
            		_url = _url +_contextId;
            		window.open(_url);
            		} else {
            		ErrorLog.ErrorUtils.myError(response);
			}
			}).fail(self.genericServiceErrorHandler);
			e.preventDefault();
		},
		toggleExpColBank: function (e) {
			var that = this;
			var targetBtn = $(e.target).attr('id') || $(e.currentTarget).attr('id');
			var targetContainer = targetBtn + '-desc';

			if ($('#' + targetBtn).hasClass('collapse-icon') == true) {
				$('#' + targetBtn).removeClass('collapse-icon').addClass('expand-icon');
				$('#' + targetContainer).addClass('hidden-xs').slideUp("slow");
			} else {
				$('#' + targetBtn).addClass('collapse-icon').removeClass('expand-icon');
				$('#' + targetContainer).removeClass('hidden-xs').slideDown("slow");
			}

		}
	});
	return bankView;
});
