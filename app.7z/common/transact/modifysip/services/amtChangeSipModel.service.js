/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var AmntChangeSipModel= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _newSipDet = null;
	var AmntChangeSipModel = {        
        fetchAmtChangeSipDet : function () {
            
            var deferred = $q.defer();
            Restangular.all('/getAmtChangeSipDet').getList().then(function (modSipDetails) {
                deferred.resolve(modSipDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setAmtChangeSipDetails : function (modSipDetails) {
            _newSipDet = modSipDetails;
        },
        getAmtChangeSipDetails : function () {
            if (!angular.isDefined(_newSipDet)) {
                return null;
            }
            return _newSipDet;
        }


        
        
        
       

    };
    return AmntChangeSipModel;

};

AmntChangeSipModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = AmntChangeSipModel;
