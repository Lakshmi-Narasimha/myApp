var coa = coa || {};
coa.models = coa.models || {};
coa.views = coa.views || {};
coa.Router = coa.Router || {};
coa.collections = coa.collections || {};
define([ 'jquery', 'underscore', 'backbone', 'backbonesubroute',
		'appcommon/memmorymgr',
		'appmodules/coa/app/js/views/view-coa-container',
		'appcommon/globalcontext', 'appmodules/coa/app/js/utils',
		'appmodules/coa/app/js/coa-main', 'services/dataservice', 'appcommon/commonutility', 'appmodules/contactprofile/app/models/cpviewmodel'], function ($, _, Backbone,
		backbonesubroute, MemmoryMgr, CoaContainerView, GlobalContext, Utils, CoaMain, DataService, CommonUtils, CPViewModel) {
	var globalContxt = GlobalContext.getInstance().getGlobalContext().Context;
	var queryString = globalContxt.QueryString;
	var _lastLaunchTime = undefined, _currentLaunchTime = undefined;
	var coaRouter = Backbone.SubRoute.extend({
		routes : {
			'home' : 'showHome',
			'validation' : 'showValidation',
			'verify' : 'showVerify',
			'confirm' : 'showConfirm',
			'*path(/:caseId)': 'defaultACtion'
		},
		initialize : function() {
			coa.Router = this;
		},
		defaultRoute : function(path) {},

		defaultACtion: function (caseId) {
		    var _caseId = (caseId != null && caseId != undefined) ? caseId : null;
			if(_currentLaunchTime != undefined){
        		_lastLaunchTime = _currentLaunchTime;
        	}
        	_currentLaunchTime = new Date().getTime();
        	setTimeout(function(){
        		_lastLaunchTime = undefined, _currentLaunchTime = undefined;
        	}, 1000);
        	if(_currentLaunchTime - _lastLaunchTime > 0  ){
        		return;
        	}
			Utils.lockForm();
			var _contextualRoute = "";
			if(!globalContxt.IsStandalone){
				_contextualRoute =CommonUtils.getReferrer(-1);
			}
			requirejs([ 'appmodules/coa/app/js/models/address',
					'appmodules/coa/app/js/collections/address',
					'appmodules/coa/app/js/models/client',
					'appmodules/coa/app/js/models/account',
					'appmodules/coa/app/js/data/country-list' ], function() {
				requirejs([ 'appmodules/coa/app/js/collections/accounts',
						'appmodules/coa/app/js/models/user' ], function() {
					requirejs([ 'appmodules/coa/app/js/views/client',
							'appmodules/coa/app/js/views/app',
							'appmodules/coa/app/js/views/validation',
							'appmodules/coa/app/js/views/verification',
							'appmodules/coa/app/js/views/confirmation',
							'appmodules/coa/app/js/views/account' ],
							function() {
							    coa.user.set('submitterId', Utils.readCookie('FMID'));
							    coa.user.set('fromBackButton', false);
							    coa.user.erase();
							    coa.user.set('caseId', _caseId);
							    coa.user.set('isStandalone', globalContxt.IsStandalone);
							    if (!globalContxt.IsStandalone && _caseId) {
							        var _cpData = CPViewModel.getInstance().getData();
							        var _scheduledCases = _cpData.scheduledAddress, _editingCase = null;
							        if (_scheduledCases && _scheduledCases.length > 0) {
							            _editingCase = _scheduledCases.find(function (coaCase) {
							                return coaCase.caseId == _caseId;
							            });
							        }
							        console.log(_editingCase, "_editingCase_editingCase");
							        if (_editingCase) {
							            var _poCd = _editingCase.newPoCdTxt;
							            if (_poCd) {
							                _poCd = _poCd.replace("-", "").substr(0, 5);
                                        }
							            coa.user.set({
							                "changeType": "Mailing",
							                "mailingType": "new",
							                "futureStartEndate": "yes",
							                "futureStartDate": _editingCase.StartDate,
							                "futureEndDate": _editingCase.EndDate,
							                "editCaseDetails": _editingCase,
							                "eAddressLine1": _editingCase.newAddrLn1Txt,
							                "eAddressLine2": _editingCase.newAddrLn2Txt,
							                "eAddressLine3": _editingCase.newAddrLn3Txt,
							                "eNewCIty": _editingCase.newPostTownNm,
							                "eNewState": _editingCase.newRegnAreaCd,
							                "eNewZip": _poCd,
							            });
							        }

							    }
								if(globalContxt.IsStandalone){
									coa.user.set('contextualRoute',"");
									coa.user.set('contextualRouteTitle',"");
								}else{
									coa.user.set('contextualRoute',_contextualRoute.referer);
									coa.user.set('contextualRouteTitle',"Back to "+_contextualRoute.context);
								}
								
								var coaContainerView = new CoaContainerView({
									model : coa.user
								});
								MemmoryMgr.setcurrentview(coaContainerView);
								coaContainerView.render();
								coaContainerView.afterRender();
							});
				});
			});

		},
		showLogin : function() {
		},
		showHome: function () {
			if(this.validateUserModel()){
			    var _advisorName = "";
			    var _globalContxt = GlobalContext.getInstance();
			    var _context = _globalContxt.getGlobalContext().Context;
			    if (_context.IsStandalone) {
			        var asyncCalls = [];
			        asyncCalls[0] = DataService.getAdvisorInfo();
			        Q.allSettled(asyncCalls).then(
	                        function (response) {
	                            if (response[0]['value']) {
	                                var _oboModel = response[0]['value'].toJSON();
	                                if (_oboModel.length > 0) {
	                                    _advisorName = _oboModel[0].name;
	                                    $('#advisor-name').text(_advisorName);
	                                }                                
	                            }
	                        }).fail(function () {
	                            _errorCounter++;
	                        });
			    }
				$('#user-home-view').removeClass('hidden');
				coa.initialServiceCounter = 3;
				coa.initialServiceErrorCounter = 0;
				if (coa.appView) {
					coa.appView.clearView();
				}
				coa.appView = new coa.views.AppView({
					model : coa.user
				});
				if (!coa.user.get('fromBackButton')) {

					coa.appView.readContext();
				} else {
					coa.appView.render();
					coa.appView.initCustom();
				}
				$(window).scrollTop(0);
			}
		    
		},
		showValidation : function() {
			if(this.validateUserModel()){
				coa.user.set('fromBackButton', true);
				if (coa.validationView) {
					coa.validationView.clearView();
				}
				coa.validationView = new coa.views.Validation({
					model : coa.user
				});
				coa.validationView.render();
				$(window).scrollTop(0);
			}
			
		},
		showVerify : function() {
			if(this.validateUserModel()){
				if (!coa.user.get('fromBackButton')) {
					coa.Router.navigate('confirm'+queryString?queryString:'', {
						trigger : false
					});
					return;
				}
				if (coa.verificationView) {
					coa.verificationView.clearView();
				}
				coa.verificationView = new coa.views.Verification({
					model : coa.user
				});
				coa.verificationView.render();

				$(window).scrollTop(0);
			}
		},
		showConfirm : function() {
			if(this.validateUserModel()){
				coa.user.set('fromBackButton', false);
				if (coa.confirmationView) {
					coa.confirmationView.clearView();
				}
				coa.confirmationView = new coa.views.Confirmation({
					model : coa.user
				});
				coa.confirmationView.render();
				$(window).scrollTop(0);
			}
		},
		validateUserModel : function(){
			if(coa && !coa.user){
				Backbone.history.navigate("coa/"+queryString?queryString:'', true);
				return false;
			}
			return true;
		}
	});
	return {
		coaRouter : coaRouter
	};
});
