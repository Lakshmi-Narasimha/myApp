'use strict';
/**
 *@ngdoc object
 *@name investor.module:Dashboard
 *@description
 * <p>
 * It has all linkup of the components, services and initial wrapper
 * </p>
 */
console.log('dashboard console');

// Home View
module.exports = angular.module('investor.transact', [])
    .config(require('./invTransact.routes'))
    .controller('invTransactMasterCtrl', require('./invTransactMaster.controller'))
    .controller('invTransactCtrl', require('./invTransact.controller'))
    .controller('invTransactionDetailsCtrl', require('./invtransactiondetails/invTransactionDetails.controller'))
    .factory('invTransactionDetailsFactory', require('./invtransactiondetails/invTransactionDetails.factory'))
    ;
