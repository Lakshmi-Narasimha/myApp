define(function () {
	
	function spinner(){
		this.defaultOptions = {
				msg : "Loading...",
				inline:false,
				parentElement:undefined,
				serachBox:false,
				height:undefined,
			};
		
		this.show = function(options){
			if(!options) var options = {};
			options = this.extend(this.defaultOptions, options);
			if(options.inline){
				var parent = $("#"+options.parentElement);
				parent.find(".spinner-inline-container").remove();
				var _inlineSPinner = "<p class='spinner-inline-container'><span class='spinner-inline scraper-msg pt-dropdown-client-name'></span></p>";
				if(options.serachBox){
					parent.prepend(_inlineSPinner);
				}else{
					parent.append(_inlineSPinner);
				}
				
			}else{
				var _$spinnerOverlay = $("#spinner-overlay");
				if (_$spinnerOverlay.is(":visible")) {
					return;
				}
				_$spinnerOverlay.height($(document).height());
				_$spinnerOverlay.show();
			}
			var _$scraperBox = $(".scraper-box");
				_$scraperBox.removeAttr('style');
			_$scraperBox.find(".scraper-msg").html(options.msg);
			if(options.height){
				_$scraperBox.css({'height':options.height,'top':'calc(50% - '+(options.height)/2+'px)'});
			}
			
			//Condition for serachbox
			if(options.serachBox){
				$(".spinner-inline").addClass("search-box");
			}
			
		};
		this.hide = function(options){
			if(!options) options = {};
			options = this.extend(this.defaultOptions, options);
			if(options.inline){
				var parent = $("#"+options.parentElement);
				parent.find(".spinner-inline-container").fadeOut("slow",function(){
					$(this).remove();
				});
			}else{
				if ($("#spinner-overlay").is(":visible")) {
					
					$('#spinner-overlay').fadeOut("slow", function() {
						$('#spinner-overlay').hide();
					});
				}
			}
			
		};
		this.extend = function(parentObj, chileObj) {
			if(typeof parentObj != "object" && typeof parentObj != "object"){
				return {};
			}
		     var _tmpObj = {};  
		     for(var key in parentObj)_tmpObj[key] = (chileObj[key] == null) ? parentObj[key] : chileObj[key];
		     return _tmpObj;
	    };
	}
	
	return new spinner();
});