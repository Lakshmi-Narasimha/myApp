/**
 * @ngdoc service
 * @name ifscInitialLoader
 * @description
 *
 * - Initial Loader for IFSC Search service
 *
 */
'use strict';

var ifscInitialLoader = function (ifscModel, transactEventConstants, transactEvents, $loader) {
    
    var ifscInitialLoader = {
        loadAllServices : function (scope, params) {
            $loader.start();
            ifscModel.fetchIfscDetails(params).then(ifscSuccess, handleFailure).finally(function(){
                $loader.stop();
            });
            // ifscModel.fetchIfscSearchDetails().then(ifscGridSuccess, handleFailure);

            function ifscSuccess (data) {
                if(data && data.cities) {
                    ifscModel.setIfscCityDetails(data.cities);    
                }
                else if(data && data.branches) {
                    ifscModel.setIfscBrnDetails(data.branches);   
                }
                else if(data && data.bankDetails) {
                    ifscModel.setIfscBankDetails(data.bankDetails);
                    // transactEvents.transact.publishIfscGridDetails(scope, data.bankDetails);  
                }

                // ifscModel.setIfscDetails(data);
                transactEvents.transact.publishIfscDetails(scope, ifscModel.getIfscDetails());
            }
            function ifscGridSuccess (data) {
                ifscModel.setIfscGridDetails(data[0]);
                transactEvents.transact.publishIfscGridDetails(scope, ifscModel.getIfscGridDetails());
            }
            function handleFailure (data) {
                console.log('handleFailure');
                scope.$broadcast(transactEventConstants.transact.IFSC_SEARCH_FAIL, data);
            }
        }
    };
    return ifscInitialLoader;
};

ifscInitialLoader.$inject = ['ifscModel', 'transactEventConstants', 'transactEvents', '$loader'];
module.exports = ifscInitialLoader;
