(function() {
    'use strict';

    require('angular');
    require('angular-route');
    require('angular-animate');
    require('angular-ui-bootstrap');

    var mainCtrl = require('./controllers/mainctrl');
    var liveChatCtrl = require('./controllers/livechatctrl');
    var scrollDownDirective = require('./directives/scrolldown.directive');
    var chatServices = require('./services/chatservices');
    angular.module('AskVerizonApp', ['ngRoute', 'ngAnimate', 'ui.bootstrap'])
        .config([
            '$locationProvider',
            '$routeProvider',
            function($locationProvider, $routeProvider) {
                $routeProvider
                    .when("/", {
                        templateUrl: "./partials/main.html",
                        controller: "mainCtrl"
                    })
                    .when("/livechat", {
                        templateUrl: "./partials/livechat.html",
                        controller: "liveChatCtrl"
                    })
                    .when("/endchat", {
                        templateUrl: "./partials/enddchat.html",
                    })
                    .otherwise({
                        redirectTo: '/'
                    });
            }
        ])
        //Load controllers
        .controller('mainCtrl', ['$scope', '$window', mainCtrl])
        .controller('liveChatCtrl', ['$scope', '$window', '$timeout', 'chatServices', liveChatCtrl])

        //Load services
        .service('chatServices', ['$q', '$http', chatServices])

        //Load directives
        .directive('schrollBottom', [scrollDownDirective]);

}());
