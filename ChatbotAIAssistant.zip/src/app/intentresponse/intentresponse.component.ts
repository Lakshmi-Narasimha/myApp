import { Component, OnInit } from '@angular/core';
//import { LocalDataSource  } from 'ng2-smart-table';

@Component({
  selector: 'intentresponse',
  templateUrl: './intentresponse.component.html',
  styleUrls: ['./intentresponse.component.css']
})
export class IntentresponseComponent implements OnInit {
/*

   settings = {
  columns: {
    usersays: {
      title: 'String'
    }
  },
        hideSubHeader: true
};
        data =[
            {usersays:"Response #1"},
            {usersays:"Response #1"},
            {usersays:"Response #1"},
            {usersays:"Response #1"},
            {usersays:"Response #1"}
        ];

    source: LocalDataSource; // add a property to the component
*/

constructor() {
  //this.source = new LocalDataSource(this.data); // create the source
}

  ngOnInit() {
  }

     /* onAddInputKeyEnter(event:any) { // without type info
          console.log(this.source.getElements());
          console.log("event triggered");
          console.log("event.target.value " + event.target.value);
          console.log(this.data);
        this.source.add({usersays:event.target.value});
    //this.data.push({usersays:event.target.value});// += event.target.value + ' | ';
          console.log(this.data);
          console.log(this.source);
          console.log(this.source.getElements());
          event.target.value = null;
  }
*/



}
