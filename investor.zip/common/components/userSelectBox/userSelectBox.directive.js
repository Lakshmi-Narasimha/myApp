/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var userInputFld = function($timeout) {
	return {
            template: require('./userSelectBox.html'),
            restrict: 'E',
            replace: true,
            scope: {
                inputObject: "=",
                sectionOptions: "=",
                eventName : '@'
            },
            controller: function($scope, $element, $attrs){
                $scope.$input = $element[0].querySelector('select');
                $scope.toggleLabel = function($event){
                    angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || ($scope.selected)));
                };

                $scope.eventName = $scope.eventName || 'selectedOption';
                if($scope.sectionOptions.length > 0)
                {
                    $scope.selected = $scope.sectionOptions[0];                 
                }
                $scope.changed = function() {
                    if ($scope.selected) 
                    {
                        $scope.$emit($scope.eventName, $scope.selected);                       
                    }
                }
            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

userInputFld.$inject = ['$timeout'];
module.exports = userInputFld;