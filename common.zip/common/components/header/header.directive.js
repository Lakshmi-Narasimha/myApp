var fticHeader = function() {
    return {
        template: require('./fticHeader.html'),
        restrict: 'EA',
        replace: true,
        link: function($scope) {
            $scope.isCollapsed = true;
        }
    };
};

fticHeader.$inject = [];
module.exports = fticHeader;
