'use strict';
describe('Directive: dtpDividendForm', function() {
	var compile,scope,$rootScope,directiveElement,isolatedScope,$window,$filter,TransactConstant,fundDetailsModel,$stateParams,$timeout,transactEventConstants,transactModel,$state,httpBackend,transactEvents,newFundDetailsModel,toaster,authenticationService,dtpModel;

	var ValidateDtpResp = {
		'accountNo': '0389906480558',
		'folioId': '18556824',
		'webRefNo': 'STP000693'
    };

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': 520965.095916
        }]
    };

    var existingFundSelectedObject = {
        "accNo": "0060007818365",
        "amount": "800",
        "direct": null,
        "dividendFlag": "R",
        "endDate": "4 aug 2020",
        "frequency": "monthly",
        "fundCategory": "EQUITY",
        "fundOptDesc": "Franklin India BLUECHIP FUND",
        "fundOption": "006",
        "fundType": "E",
        "minAddPurAmt": "1000",
        "minNewPurAmt": "5000",
        "minSipAmt": "1",
        "multiples": "1",
        "nfoFlag": "N",
        "payoutFlag": "N",
        "reinvestmentFlag": "N",
        "startDate": "12 apr 2014",
        "stepUpType": "",
        "nextInstlDate": "5 sep 2016",
        "nextAnnualDate": "12 apr 2017",
        "stepUpValue": "NA",
        "leadDays": "15",
        "paymentDet":{
        	"payModeEmand": "false",
	        "eMandateType":"",
	        "eMandateVal": "",
	        "eMandateExpiryDate": "" 
		}		       
	};

    var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var dtpObjectWithReInvestmentDividendType = {
		"destinationFund" : existingFundSelectedObject,
        "switchType" : "Re-Investment",
        "type": ""
	};

	var dtpModelObject = {
		"investorDetails" : investorDetails,
		"fundDetails" : selectedFundObject,
		"switchDetails" : dtpObjectWithReInvestmentDividendType
	};

	var taxShieldFund = {
	    "accNo": "0350008800577",
	    "amount": "",
	    "direct": null,
	    "dividendFlag": "P",
	    "endDate": "",
	    "frequency": "",
	    "fundCategory": "ELSS",
	    "fundOptDesc": "Franklin India Taxshield",
	    "fundOption": "035",
	    "fundType": "E",
	    "minAddPurAmt": "500",
	    "minNewPurAmt": "500",
	    "minSipAmt": "500",
	    "multiples": "1",
	    "nfoFlag": "N",
	    "payoutFlag": "Y",
	    "reinvestmentFlag": "N",
	    "startDate": "",
	    "stepUpType": "",
	    "stepUpValue": ""
	};

	var growthFund = {
		"accNo": null,
		"amount": "",
		"direct": null,
		"dividendFlag": "R",
		"endDate": "",
		"frequency": "",
		"fundCategory": "EQUITY",
		"fundOptDesc": "Templeton India Growth FUND",
		"fundOption": "154",
		"fundType": "N",
		"minAddPurAmt": "1000",
		"minNewPurAmt": "5000",
		"minSipAmt": "500",
		"multiples": "1",
		"nfoFlag": "N",
		"payoutFlag": "N",
		"reinvestmentFlag": "Y",
		"startDate": "",
		"stepUpType": "",
		"stepUpValue": ""
	};

	var advisor = false;

	beforeEach(angular.mock.module('advisor'));	
	beforeEach(angular.mock.module('investor.transact'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-dtp-dividend-details-form></ftic-dtp-dividend-details-form>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function(_$rootScope_,_$compile_,$window,_dtpModel_,_$filter_,_TransactConstant_,_fundDetailsModel_,_$stateParams_,_$timeout_,_transactEventConstants_,_transactModel_,_$state_,$httpBackend,_frequencyOptionsModel_,_transactEvents_,_newFundDetailsModel_,_toaster_,_stpDetailsModel_,_authenticationService_) {            
            compile = _$compile_;
            scope = _$rootScope_.$new();    

            $window = $window;
            $window.ga = function() {};

            $rootScope = _$rootScope_;
            $timeout = _$timeout_;
            $state = _$state_;
            $stateParams = _$stateParams_;
            $filter = _$filter_;
            httpBackend = $httpBackend;
            transactEvents = _transactEvents_;
            TransactConstant = _TransactConstant_;
            transactEventConstants = _transactEventConstants_;
            transactModel = _transactModel_;            
			dtpModel = _dtpModel_;

			authenticationService = _authenticationService_;
			toaster = _toaster_;			
			newFundDetailsModel = _newFundDetailsModel_;
            fundDetailsModel = _fundDetailsModel_;
            fundDetailsModel.setFundDetails(fundDetailsResponse);
            transactModel.setInvestorDetails(investorDetails);
            transactModel.setFundDetails(selectedFundObject);
            httpBackend = $httpBackend;

            if(advisor){
            	authenticationService.setUser({                                        
        			"userId" : "test123"        
        		});	
            }
            
            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();    
            isolatedScope.inputObjs = [{"value":""},{"value":""}];            
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variables on load',function(){
    	expect(isolatedScope.reinvestmentDisable).toBe(false);
    	expect(isolatedScope.payoutDisable).toBe(false);
    	expect(isolatedScope.continueBtn).toBe(true);
    	expect(isolatedScope.config.showNotification).toBe(false);
    	expect(isolatedScope.dividendOptns[0]).toBe("Re-Investment");
    	expect(isolatedScope.dividendOptns[1]).toBe("Payout");
    	expect(isolatedScope.radios.selectedVal).toBe("Re-Investment");
    	expect(dtpModel.getType()).toBe("Re-Investment");
    	expect(isolatedScope.types).toBe("Re-Investment");
    });

    it('should call the function typeChanged on change of dividend option radio button',function(){
    	isolatedScope.typeChanged("Payout");
    	expect(dtpModel.getType()).toBe("Payout");
    });

    it('should listen the event transactEventConstants.transact.SWITCH_FORM_RESET when triggered',function(){
    	isolatedScope.$broadcast(transactEventConstants.transact.SWITCH_FORM_RESET);
    	expect(isolatedScope.radios.selectedVal).toBe("");    	
    	expect(dtpModel.getType()).not.toBeDefined();
    });

    it('should listen the event disableDividendOption when the fund drop down changes(if user selects taxshield fund)',function(){
    	isolatedScope.$broadcast("disableDividendOption",taxShieldFund);    	
    	expect(isolatedScope.reinvestmentDisable).toBe(true);
    	expect(dtpModel.getType()).toBe("Payout");
    });

    it('should listen the event disableDividendOption when the fund drop down changes(if user selects growth fund)',function(){
    	isolatedScope.$broadcast("disableDividendOption",growthFund);    	    	
    	expect(isolatedScope.reinvestmentDisable).toBe(true);
    	expect(isolatedScope.payoutDisable).toBe(true);
    	expect(isolatedScope.radios.selectedVal).toBe("");    	
    	expect(dtpModel.getType()).toBe("NA");
    });

    it('should listen the event disableDividendOption when the fund drop down changes(if user selects other than growth or taxshield fund)',function(){
    	isolatedScope.$broadcast("disableDividendOption",existingFundSelectedObject);    	    	
    	expect(isolatedScope.reinvestmentDisable).toBe(false);
    	expect(isolatedScope.payoutDisable).toBe(false);
    });

	it('should listen the event transactEventConstants.transact.FUND_UPDATED when triggered)',function(){
    	isolatedScope.$broadcast(transactEventConstants.transact.FUND_UPDATED);
    	expect(isolatedScope.reinvestmentDisable).toBe(false);
    	expect(isolatedScope.reinvestmentDisable).toBe(false);
    });

	it('should call the postStpDetails on click of continue button(and navigate to invTransact.review.dtp if investor logged in when api returns success)',function(){
		spyOn(isolatedScope,"$emit");		
		spyOn($state,"go");
		isolatedScope.dtpForm.$valid = true;
		isolatedScope.destinationFund = existingFundSelectedObject;
		isolatedScope.radios.selectedVal = "Re-Investment";
		isolatedScope.postStpDetails();
		
		expect(isolatedScope.config.showNotification).toBe(false);
		expect(isolatedScope.$emit).toHaveBeenCalledWith("dtpFormSubmit");		
		expect(dtpModel.getDataObj()).toEqual(dtpObjectWithReInvestmentDividendType);
		expect(transactModel.getTransactDetails()).toEqual(dtpModelObject);
		expect(transactModel.getTransactDetails().fundDetails.dividendType).toEqual("Re-Investment");
		httpBackend.expectPOST("http://localhost:3030/transact/registerDtp?guId=878").respond(200,ValidateDtpResp);
		$rootScope.$digest();
		httpBackend.flush();
		expect($state.go).toHaveBeenCalledWith("invTransact.review.dtp");
		expect(transactModel.getvalidateSWITCHDetails().accountNo).toEqual(ValidateDtpResp.accountNo);
		expect(transactModel.getWebRefNo()).toEqual(ValidateDtpResp.webRefNo); 
		advisor = true;    
	});
	
	it('should call the postStpDetails on click of continue button(and navigate to transact.review.dtp if advisor logged in when api returns success)',function(){		
		spyOn($state,"go");		        
		isolatedScope.dtpForm.$valid = true;
		isolatedScope.destinationFund = existingFundSelectedObject;
		isolatedScope.radios.selectedVal = "Re-Investment";
		isolatedScope.postStpDetails();
		httpBackend.expectPOST("http://localhost:3030/transact/registerDtp").respond(200,ValidateDtpResp);
		$rootScope.$digest();

		expect(isolatedScope.config.showNotification).toBe(false);						
		httpBackend.flush();
		expect($state.go).toHaveBeenCalledWith("transact.review.swp");
	});

	it('should call the postStpDetails on click of continue button(and show error if the api fails)',function(){				
		spyOn(toaster,"error");
		isolatedScope.dtpForm.$valid = true;
		isolatedScope.destinationFund = existingFundSelectedObject;
		isolatedScope.radios.selectedVal = "Re-Investment";
		isolatedScope.postStpDetails();
		httpBackend.expectPOST("http://localhost:3030/transact/registerDtp").respond(400,failureResponse);

		httpBackend.flush();
		expect(toaster.error).toHaveBeenCalledWith(failureResponse[0].errorDescription);
	});

	it('should show the notification popup when the form data changed by the user',function(){
		$stateParams.key = "dtp";
		isolatedScope.radios.selectedVal = "Payout";
		isolatedScope.dtpForm.$valid = true;
		isolatedScope.destinationFund = existingFundSelectedObject;
		transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"switchDetails" : dtpObjectWithReInvestmentDividendType
		});	

		isolatedScope.postStpDetails();
		
		expect(isolatedScope.config.showNotification).toBe(true);
	});

	it('should listen the event yes after clicking on yes in the pop up',function(){		
		$stateParams.key = "dtp";
		isolatedScope.radios.selectedVal = "Re-Investment";
		isolatedScope.dtpForm.$valid = true;
		isolatedScope.destinationFund = existingFundSelectedObject;
		transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"switchDetails" : dtpObjectWithReInvestmentDividendType
		});	

		isolatedScope.postStpDetails();

		httpBackend.expectPOST("http://localhost:3030/transact/registerDtp").respond(200,ValidateDtpResp);
		$rootScope.$digest();		
		isolatedScope.$broadcast("yes");

		httpBackend.flush();
		expect(isolatedScope.config.showNotification).toBe(false);		
    	expect(transactModel.getTransactDetails().switchDetails.switchType).toEqual("Re-Investment");
	});

	it('should listen the event no after clicking on no in the pop up',function(){		
		$stateParams.key = "dtp";
		isolatedScope.radios.selectedVal = "Payout";
		isolatedScope.dtpForm.$valid = true;
		isolatedScope.destinationFund = existingFundSelectedObject;
		transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"switchDetails" : dtpObjectWithReInvestmentDividendType
		});	

		isolatedScope.postStpDetails();

		isolatedScope.$broadcast("no");

		$timeout.flush();
		expect(isolatedScope.config.showNotification).toBe(false);		
   		expect(isolatedScope.switchValues).toEqual(dtpObjectWithReInvestmentDividendType);
   		expect(isolatedScope.fundObj).toEqual(dtpObjectWithReInvestmentDividendType.destinationFund); 	
		expect(isolatedScope.radios.selectedVal).toBe(isolatedScope.switchValues.switchType);   		
	});	
});