'use strict';

var swpInitialLoader = function (swpModel, transactEventConstants, transactEvents) {
    
    var swpInitialLoader = {
         loadAllServices : function (scope) {                    	

            // swpModel.fetchSwpDetails().then(swpSuccess, handleFailure);

            function swpSuccess (data) {
                swpModel.setSwpDetails(data[0].swp);
                transactEvents.transact.publishSwpDetails(scope);
                console.log('setData');
            }
            function handleFailure (data) {
                console.log('handleFailure');
            }
        }
    };
    return swpInitialLoader;
};

swpInitialLoader.$inject = ['swpModel', 'transactEventConstants', 'transactEvents'];
module.exports = swpInitialLoader;
