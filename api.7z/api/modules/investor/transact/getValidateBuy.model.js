// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetValidateBuyModelSchema = new mongoose.Schema({
    GetValidateBuyResp: {
        type: Array,
        "default": []
    }
});

var GetValidateBuyModelLookUp = mongoose.model('GetValidateBuyModelLookUp', GetValidateBuyModelSchema);

var GetValidateBuyModel = new GetValidateBuyModelLookUp({
        GetValidateBuyResp : {
      "accountNo": "0389904892196",
      "folioId": "17894993",
      "transactionValidated": "true",
      "webRefNo": "BUY001712"
    }
});

GetValidateBuyModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetValidateBuyModelLookUp table, please contact admin...');
    } else {
        GetValidateBuyModelLookUp.remove({}, function(err) {
            console.log('GetValidateBuyModelLookUp collection removed');
            GetValidateBuyModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetValidateBuyModelLookUp table, please contact admin...');
                }
                console.log('GetValidateBuyModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});


module.exports = GetValidateBuyModelLookUp;