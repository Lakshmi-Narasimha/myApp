/**
 * @ngdoc factory
 * @name Investor Dashboard chart factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var invTransactionDetailsFactory = function(transactModel, $filter, transDetailsModel, $loader, toaster, TransactConstant, fticCancelStpFundDetailsModel, fticCommonUtils, FileSaver, fundDetails, $timeout, $state) {
    var _invDetails = transactModel.getInvestorDetails();
    var _fundDetails = transactModel.getFundDetails();
    console.log(_fundDetails);
    // var folioDetails = transactModel.getTransactDetails().investorDetails;
    var _transConf = transactModel.getTransactConfirm();
    var datefilter = $filter('date');
    // console.log(_transConf)
    var _dataObject = {
        modifysip: function() {
            var _sipDetails = transactModel.getTransactDetails().modifySipDetail;
            console.log(_sipDetails);
            var stepUpPerc = ' ';
            var sipTransactDetails = [{
                key: 'folioId',
                text: 'Folio No.',
                value: _invDetails.folioId
            }, {
                key: 'fundOptionDesc',
                text: 'Fund Name',
                value: _fundDetails.fundOptionDesc + ' ' + _fundDetails.accountNumber
            }, {
                key: 'transactionRefNo',
                text: 'Transaction Reference Number',
                value: _transConf.transactionRefNo
            }, {
                key: 'transDateTime',
                text: 'Request Date and Time',
                value: _transConf.transDateTime
            }];

            if (_sipDetails.sipModifyType === 'Sip_Amt_Change') {
                var sipAmtObject = {
                    key: 'sipAmountChange',
                    text: 'SIP Amount Changed to',
                    value: "<span class='icon - fti_rupee '></span>" + ' ' + _sipDetails.newSipAmount + ' ' + $filter('translate')(TransactConstant.modifySip.EFF_FOR_INST_FROM) + ' ' + _sipDetails.strtDate
                };
                sipTransactDetails.push(sipAmtObject);

            } else if (_sipDetails.sipModifyType === 'Step_Up_Sip') {
                var sipStepUpObj = {
                    key: 'stepupsip',
                    text: $filter('translate')(TransactConstant.modifySip.EFF_FROM),
                    value: _sipDetails.strtDate + ' -' + _sipDetails.stepUpDateDesc
                };
                if (_sipDetails.stepUpType === 'P') {
                    stepUpPerc = "(<span class='icon - fti_rupee '></span> ' + _sipDetails.stepUpValAmnt + ' )";
                }
                $timeout(function() {
                    sipTransactDetails.push({
                        text: 'Step-up SIP by',
                        value: _sipDetails.stepUpVal + ' Annually ' + stepUpPerc
                    });
                }, 0);
                sipTransactDetails.push(sipStepUpObj);
            } else if (_sipDetails.sipModifyType === 'Flexi_Sip') {
                var flexiObj = {
                    key: 'FlexiSip',
                    text: $filter('translate')(TransactConstant.modifySip.New_SIP_Amount),
                    value: "<span class='icon - fti_rupee '></span>" + _sipDetails.newSipAmount + ' ' + $filter('translate')(TransactConstant.modifySip.EFF_ONLY_FOR_INST) + ' ' + _sipDetails.strtDate
                };
                sipTransactDetails.push(flexiObj);
            } else if (_sipDetails.sipModifyType === 'Sip_Date_Change') {
                var sipDateObj = {
                    key: 'sipDateChange',
                    text: $filter('translate')(TransactConstant.modifySip.New_SIP_Date),
                    value: _sipDetails.strtDate
                };
                sipTransactDetails.push(sipDateObj);
            } else if (_sipDetails.sipModifyType === 'Sip_Pause') {
                var sipPauseObj = {
                    key: 'sipPause',
                    text: 'SIP Pause Date',
                    value: _sipDetails.strtDate
                };
                sipTransactDetails.push(sipPauseObj);
            } else if (_sipDetails.sipModifyType === 'Sip_Cancel') {
                var sipCancelObj = {
                    key: 'sipCancel',
                    text: 'SIP Cancellation Effective Date',
                    value: _sipDetails.strtDate
                };
                sipTransactDetails.push(sipCancelObj);
            } else if (_sipDetails.sipModifyType === 'Step_Up_Cancel') {
                var stepUpCancelObj = {
                    key: 'stepUpCancel',
                    text: 'Step Up Cancellation Effective Date',
                    value: _sipDetails.strtDate
                };
                sipTransactDetails.push(stepUpCancelObj);
            }

            return sipTransactDetails;
        },
        swp: function() {
            var _swpDetails = transactModel.getTransactDetails().swpDetails;
            return [{
                key: 'folioId',
                text: 'Folio No.',
                value: _invDetails.folioId
            }, {
                key: 'fmDescription',
                text: 'Fund name',
                value: _fundDetails.fmDescription
            }, {
                key: 'tschvalAccno',
                text: 'Account Number',
                value: _fundDetails.tschvalAccno
            }, {
                key: 'transactionRefNo',
                text: 'Transaction Reference No.',
                value: _transConf.transactionRefNo
            }, {
                key: 'requestDateTime',
                text: 'Request Date and Time ',
                value: _transConf.transDateTime
            }, {
                key: 'selectedType',
                text: 'Withdrawal Type',
                value: (_swpDetails.selectedType === 'capital') ? 'Capital Appreciation' : 'Fixed Amount'
            }, {
                key: 'amt',
                text: 'Amount',
                value: _swpDetails.swpAmtValue
            }, {
                key: 'freq',
                text: 'Frequency',
                value: _swpDetails.frequency
            }, {
                key: 'swpStrtDate',
                text: 'SWP Start Date',
                value: datefilter(_swpDetails.startDate, 'dd MMMM yyyy, hh:mm a')
            }, {
                key: 'swpEndDate',
                text: 'SWP End Date',
                value: datefilter(_swpDetails.endDate, 'dd MMMM yyyy, hh:mm a')
            }];
        },
        buy: function() {
            var tileDetails = fundDetails.getFundDetails();
            var paymentDetails = transactModel.getTransactDetails().paymentDetails;
            var infoObj = [];
            infoObj.push({
                key: 'folioId',
                text: 'Folio No.',
                value: _invDetails.folioId
            });
            angular.forEach(tileDetails, function(obj, key) {
                var Fund_num = 'Fund ' + (key + 1) + ' Details';
                infoObj.push.apply(infoObj, [{
                    key: 'Fund Number',
                    text: Fund_num,
                    value: ''
                }, {
                    key: 'Fund Name',
                    text: 'Fund Name',
                    value: tileDetails[key].fundName
                }, {
                    key: 'Investment Amount',
                    text: 'Investment Amount',
                    value: tileDetails[key].amount
                }, {
                    key: 'Dividend',
                    text: 'Dividend',
                    value: tileDetails[key].dividend
                }]);
            });
            infoObj.push({
                key: 'totalInvestmentAmount',
                text: TransactConstant.transact.TOTAL_INVSTMNT_AMT,
                value: paymentDetails.totalAmount
            }, {
                key: 'paymentMethod',
                text: TransactConstant.transact.MODE_OF_PAYMENT,
                value: paymentDetails.paymentMethod
            }, {
                key: 'bankDetails',
                text: TransactConstant.transact.BANK_DETAILS,
                value: paymentDetails.selectedBank
            }, {
                key: 'transactionRefNo',
                text: TransactConstant.transact.TRANS_REF_NO,
                value: _transConf.transactionRefNo
            }, {
                key: 'dateAndTime',
                text: TransactConstant.transact.ADV_REQ_DATE,
                value: _transConf.transDateTime
            });
            console.log(infoObj);
            return infoObj;
        },
        stp: function() {
            var _stpDetails = transactModel.getTransactDetails().stpDetails,
                startDate = $filter('date')(new Date(_stpDetails.startDate), 'dd MMMM yyyy'),
                endDate = $filter('date')(new Date(_stpDetails.endDate), 'dd MMMM yyyy');
            return [{
                key: 'FolioNo',
                text: $filter('translate')(TransactConstant.transact.FOLIO_NUM),
                value: _invDetails.folioId
            }, {
                key: 'sourceFund',
                text: $filter('translate')(TransactConstant.transact.SOURCE_FUND),
                value: _fundDetails.fmDescription
            }, {
                key: 'sfAccountNumber',
                text: 'Account Number',
                value: _fundDetails.tschvalAccno
            }, {
                key: 'destinationFund',
                text: $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
                value: _stpDetails.destinationFund.fundName
            }, {
                key: 'dfAccountNumber',
                text: 'Account Number',
                value: _stpDetails.destinationFund.accNo
            }, {
                key: 'transactionRefNo',
                text: $filter('translate')(TransactConstant.common.TRANSACTION_REF_NO),
                value: _transConf.transactionRefNo
            }, {
                key: 'requestDateTime',
                text: $filter('translate')(TransactConstant.transact.REQ_DATE_AND_TIME),
                value: _transConf.transDateTime
            }, {
                key: 'stpType',
                text: $filter('translate')(TransactConstant.transact.STP_TYPE),
                value: _stpDetails.stpAmount.type
            }, {
                key: 'stpAmount',
                text: $filter('translate')(TransactConstant.stp.STP_AMOUNT),
                value: _stpDetails.stpAmount.amount
            }];
        },
        cancelStp: function() {
            var transConf = fticCancelStpFundDetailsModel.getTransactConfirm();
            var _fundDetails = transactModel.getFundDetails();
            var _invDetails = transactModel.getInvestorDetails();
            return [{
                key: 'FolioNo',
                text: $filter('translate')(TransactConstant.transact.FOLIO_NUM),
                value: _invDetails.folioId
            }, {
                key: 'sourceFund',
                text: $filter('translate')(TransactConstant.transact.SOURCE_FUND),
                value: _fundDetails.sourceFundDesc
            }, {
                key: 'sfAccountNumber',
                text: 'Account Number',
                value: _fundDetails.sourceAccNo
            }, {
                key: 'destinationFund',
                text: $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
                value: _fundDetails.destFundDesc
            }, {
                key: 'dfAccountNumber',
                text: 'Account Number',
                value: _fundDetails.destAccNo
            }, {
                key: 'transactionRefNo',
                text: $filter('translate')(TransactConstant.common.TRANSACTION_REF_NO),
                value: transConf.transactionRefNo
            }, {
                key: 'requestDateTime',
                text: $filter('translate')(TransactConstant.transact.REQ_DATE_AND_TIME),
                value: transConf.transDateTime
            }, {
                key: 'stpAmount',
                text: 'Amount',
                value: _fundDetails.amount
            }, {
                key: 'frequency',
                text: $filter('translate')(TransactConstant.transact.FREQUENCY),
                value: _fundDetails.frequency
            }, {
                key: 'startDate',
                text: $filter('translate')(TransactConstant.stp.STP_START_DATE),
                value: datefilter(_fundDetails.startDate, 'dd MMMM yyyy, hh:mm a')
            }, {
                key: 'endDate',
                text: $filter('translate')(TransactConstant.stp.STP_END_DATE),
                value: datefilter(_fundDetails.endDate, 'dd MMMM yyyy, hh:mm a')
            }, {
                key: 'cancellationEffectiveDate',
                text: 'Cancellation Effective Date',
                value: datefilter(_fundDetails.nextTiggerDate, 'dd MMMM yyyy, hh:mm a')
            }];

        },
        redeem: function() {
            var redeemDetails = transactModel.getTransactDetails().transactDetails;
            var transDetailsObj = [{
                key: 'folioNo',
                text: 'Folio No ',
                value: _invDetails.folioId
            }, {
                key: 'fund',
                text: 'Fund ',
                value: _fundDetails.fmDescription
            }, {
                key: 'accNum',
                text: 'Account Number ',
                value: _fundDetails.tschvalAccno
            }, {
                key: 'transactionRefNo',
                text: 'Transaction Reference No.',
                value: _transConf.transactionRefNo
            }, {
                key: 'requestDateTime',
                text: 'Request Date and Time ',
                value: _transConf.transDateTime
            }, {
                key: 'redemptionType',
                text: 'Redemption Type ',
                value: (redeemDetails.type === 'Amount' || redeemDetails.type === 'Units' ? 'Partial' : redeemDetails.type)
            }];

            if (redeemDetails.amount && redeemDetails.amount !== '') {
                var amountObj = {
                    key: 'redemptionAmount',
                    text: 'Redemption Amount',
                    value: redeemDetails.amount
                };
                transDetailsObj.push(amountObj);
            } else if (redeemDetails.units && redeemDetails.units !== '') {
                var unitObj = {
                    key: 'redemptionUnits',
                    text: 'Redemption Units',
                    value: redeemDetails.units
                };
                transDetailsObj.push(unitObj);
            }
            return transDetailsObj;
        },
        dtp: function() {
            var dtpDetails = transactModel.getTransactDetails().investorDetails;
            var sourceDetails = transactModel.getTransactDetails().fundDetails;
            var destinationDetails = transactModel.getTransactDetails().switchDetails;


            return [{
                    key: 'FolioNo',
                    text: 'Folio No.',
                    value: dtpDetails.folioId
                }, {
                    key: 'SourceFund',
                    text: 'Source Fund',
                    value: sourceDetails.fmDescription
                }, {
                    key: 'SourceAccountNo',
                    text: 'Account Number',
                    value: sourceDetails.tschvalAccno
                }, {
                    key: 'TransactionRefNo',
                    text: 'Transaction Reference No',
                    value: _transConf.transactionRefNo
                },

                {
                    key: 'ReqDateAndTime',
                    text: 'Request Date and Time',
                    value: datefilter(_transConf.transDateTime, 'dd MMMM yyyy, hh:mm a')
                }, {
                    key: 'DestinationFund',
                    text: 'Destination Fund',
                    value: destinationDetails.destinationFund.fundName
                }, {
                    key: 'DestinationAccountNo',
                    text: 'Account Number',
                    value: destinationDetails.destinationFund.accNo
                }, {
                    key: 'DividendOption',
                    text: 'Dividend Option',
                    value: sourceDetails.dividendType
                }

            ];
        },
        switch: function() {
            var _switchDetails = transactModel.getTransactDetails().switchDetails;
            return [{
                key: 'FolioNo',
                text: $filter('translate')(TransactConstant.transact.FOLIO_NUM),
                value: _invDetails.folioId
            }, {
                key: 'sourceFund',
                text: $filter('translate')(TransactConstant.transact.SOURCE_FUND),
                value: _fundDetails.fmDescription
            }, {
                key: 'sourceAcc',
                text: $filter('translate')(TransactConstant.transact.ACC_NUM),
                value: _fundDetails.tschvalAccno
            }, {
                key: 'destinationFund',
                text: $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
                value: _switchDetails.destinationFund.fundName
            }, {
                key: 'destinationAcc',
                text: $filter('translate')(TransactConstant.transact.ACC_NUM),
                value: _switchDetails.destinationFund.accNo
            }, {
                key: 'transactionRefNo',
                text: $filter('translate')(TransactConstant.common.TRANSACTION_REF_NO),
                value: _transConf.transactionRefNo
            }, {
                key: 'requestDateTime',
                text: $filter('translate')(TransactConstant.transact.REQ_DATE_AND_TIME),
                value: _transConf.transDateTime
            }, {
                key: 'switchType',
                text: $filter('translate')(TransactConstant.transact.SWITCH_TYPE),
                value: _switchDetails.switchType
            }, {
                key: 'switchAmount',
                text: _switchDetails.type === 'Amount' ? $filter('translate')(TransactConstant.transact.SWITCH_AMT) : $filter('translate')(TransactConstant.transact.SWITCH_UNIT),
                value: _switchDetails.type === 'Amount' ? _switchDetails.amount : _switchDetails.units
            }];
        }
    };

    var _paramsObject = {
        swp: function() {
            var _swpDetails = transactModel.getTransactDetails().swpDetails;
            return {
                'strTrxnType': 'SWP',
                'strJsonObj': {
                    'swpTxnDetailsReq': {
                        'txnType': 'SWP',
                        'advisorDetails': {
                            'name': '',
                            'arnCode': '',
                            'company': ''
                        },
                        'investorDetails': {
                            'firstHolderName': _invDetails.custName
                        },
                        'fundDetails': {
                            'folioNo': _invDetails.folioId,
                            'accNo': _fundDetails.tschvalAccno,
                            'fund': _fundDetails.fmDescription
                        },
                        'swpDetails': {
                            'amount': _swpDetails.swpAmtValue,
                            'txnRefNo': _transConf.transactionRefNo,
                            'reqDateTime': _transConf.transDateTime,
                            'frequency': _swpDetails.frequency,
                            'swpStartDate': _swpDetails.startDate,
                            'swpEndDate': _swpDetails.endDate,
                            'noOfInstallments': _swpDetails.noofInstallments
                        }
                    }
                }
            };
        },
        stp: function() {
            var _stpDetails = transactModel.getTransactDetails().stpDetails;
            return {
                'strTrxnType': 'STP',
                'strJsonObj': {
                    'stpTxnDetailsReq': {
                        'txnType': 'STP',
                        'advisorDetails': {
                            'name': 'Vikram Vansal',
                            'arnCode': 'ARN-001',
                            'company': 'XYZ Investment Ltd.'
                        },
                        'investorDetails': {
                            'firstHolderName': 'Shankar Narayan'
                        },
                        'srcFundDetails': {
                            'folioNo': '123222',
                            'srcAccNo': '123456789',
                            'srcFund': 'Franklin India Equity Fund'
                        },
                        'stpDetails': {
                            'destFund': 'Franklin India Prima Plus',
                            'destAccNo': '3879904021220',
                            'stpAmount': '4000',
                            'stpType': 'fixed Amount',
                            'txnRefNo': 'SWI170777',
                            'reqDateTime': '30 Apr 2016, 11:08 AM'
                        }
                    }
                }

            };
        },
        modifysip: function() {
            var _sipDetails = transactModel.getTransactDetails().modifySipDetail;
            var sipTransactData;
            /*var sipTransactData = {};*/

            if (_sipDetails.sipModifyType === 'Sip_Amt_Change') {
                sipTransactData = {
                    key: 'sipAmountChange',
                    text: 'SIP Amount Changed to',
                    value: "<span class='icon - fti_rupee '></span>" + ' ' + _sipDetails.newSipAmount + ' ' + $filter('translate')(TransactConstant.modifySip.EFF_FOR_INST_FROM) + ' ' + _sipDetails.strtDate
                };
            } else if (_sipDetails.sipModifyType === 'Step_Up_Sip') {
                sipTransactData = {
                    key: 'stepupsip',
                    text: $filter('translate')(TransactConstant.modifySip.EFF_FROM),
                    value: _sipDetails.strtDate + ' -' + _sipDetails.stepUpDateDesc
                };

            } else if (_sipDetails.sipModifyType === 'Flexi_Sip') {
                sipTransactData = {
                    key: 'FlexiSip',
                    text: $filter('translate')(TransactConstant.modifySip.New_SIP_Amount),
                    value: "<span class='icon - fti_rupee '></span>" + _sipDetails.newSipAmount + ' ' + $filter('translate')(TransactConstant.modifySip.EFF_ONLY_FOR_INST) + ' ' + _sipDetails.strtDate
                };
            } else if (_sipDetails.sipModifyType === 'Sip_Date_Change') {
                sipTransactData = {
                    key: 'sipDateChange',
                    text: $filter('translate')(TransactConstant.modifySip.New_SIP_Date),
                    value: _sipDetails.strtDate
                };

            } else if (_sipDetails.sipModifyType === 'Sip_Pause') {
                sipTransactData = {
                    key: 'sipPause',
                    text: 'SIP Pause Date',
                    value: _sipDetails.strtDate
                };

            } else if (_sipDetails.sipModifyType === 'Sip_Cancel') {
                sipTransactData = {
                    key: 'sipCancel',
                    text: 'SIP Cancellation Effective Date',
                    value: _sipDetails.strtDate
                };

            } else if (_sipDetails.sipModifyType === 'Step_Up_Cancel') {
                sipTransactData = {
                    key: 'stepUpCancel',
                    text: 'Step Up Cancellation Effective Date',
                    value: _sipDetails.strtDate
                };
            }
            console.log('sipTransactData', sipTransactData);

            return {
                'strTrxnType': 'modifysip',
                'strJsonObj': {
                    'modifysipTxnDetailsReq': {
                        'txnType': 'MODIFYSIP',
                        'advisorDetails': {
                            'name': '',
                            'arnCode': '',
                            'company': ''
                        },
                        'investorDetails': {
                            'firstHolderName': _invDetails.firstHolderName
                        },
                        'fundDetails': {
                            'folioNo': _invDetails.folioId,
                            'accNo': _fundDetails.accountNumber,
                            'fund': _fundDetails.fundOptionDesc
                        },
                        'modifySipDetails': sipTransactData
                    }
                }
            };
        },
        redeem: function() {
            var redeemDetails = transactModel.getTransactDetails().transactDetails;
            var redemptionDetailsObj = {
                'txnRefNo': _transConf.transactionRefNo,
                'reqDateTime': _transConf.transDateTime
            };

            if (redeemDetails.amount) {
                redemptionDetailsObj.amount = redeemDetails.amount;
            } else if (redeemDetails.units) {
                redemptionDetailsObj.unit = redeemDetails.units;
            }

            return {
                'strTrxnType': 'RED',
                'strJsonObj': {
                    'redeemTxnDetailsReq': {
                        'txnType': 'REDEEM',
                        'advisorDetails': {
                            'name': '',
                            'arnCode': '',
                            'company': ''
                        },
                        'investorDetails': {
                            'firstHolderName': _invDetails.custName
                        },
                        'fundDetails': {
                            'folioNo': _invDetails.folioId,
                            'accNo': _fundDetails.tschvalAccno,
                            'fund': _fundDetails.fmDescription
                        },
                        'redemptionDetails': redemptionDetailsObj
                    }
                }
            };
        },
        switch: function() {
            var switchDetails = transactModel.getTransactDetails().switchDetails;
            var advisorDetails = transactModel.getAdvDetails();
            return {
                'strTrxnType': 'SWIN',
                'strJsonObj': {
                    'switchTxnDetailsReq': {
                        'txnType': 'SWITCH',
                        'advisorDetails': {
                            'name': advisorDetails.code || '',
                            'arnCode': advisorDetails.advisorArnCode || '',
                            'company': ''
                        },
                        'investorDetails': {
                            'firstHolderName': _invDetails.custName
                        },
                        'fundDetails': {
                            'folioNo': _invDetails.folioId,
                            'accNo': _fundDetails.tschvalAccno,
                            'srcFund': _fundDetails.fmDescription
                        },
                        'switchDetails': {
                            'destFund': switchDetails.destinationFund.fundName,
                            'destAccNo': switchDetails.destinationFund.accNo,
                            'txnRefNo': _transConf.transactionRefNo,
                            'reqDateTime': _transConf.transDateTime,
                            'switchAmount': switchDetails.units || switchDetails.amount
                        }
                    }
                }
            };
        },
        cancelStp: function() {
            var transConf = fticCancelStpFundDetailsModel.getTransactConfirm();
            var _fundDetails = transactModel.getFundDetails();
            var _invDetails = transactModel.getInvestorDetails();
            return {
                'strTrxnType': 'STPC',
                'strJsonObj': {
                    'stpCancelTxnDetailsReq': {
                        'txnType': 'STPC',
                        'advisorDetails': {
                            'name': '',
                            'arnCode': '',
                            'company': ''
                        },
                        'investorDetails': {
                            'firstHolderName': _invDetails.custName
                        },
                        'srcFundDetails': {
                            'folioNo': _invDetails.folioId,
                            'accNo': _fundDetails.sourceAccNo,
                            'srcFund': _fundDetails.sourceFundDesc
                        },
                        'stpCancelDetails': {
                            'destFund': _fundDetails.destFundDesc,
                            'destAccNo': _fundDetails.destAccNo,
                            'txnRefNo': transConf.transactionRefNo,
                            'reqDateTime': transConf.transDateTime,
                            'amount': _fundDetails.amount,
                            'units': _fundDetails.amount,
                            'frequency': _fundDetails.frequency,
                            'stpStartDate': datefilter(_fundDetails.startDate, 'dd MMMM yyyy, hh:mm a'),
                            'stpEndDate': datefilter(_fundDetails.endDate, 'dd MMMM yyyy, hh:mm a'),
                            'cancellationEffectiveDate': datefilter(_fundDetails.nextTiggerDate, 'dd MMMM yyyy, hh:mm a')
                        }
                    }
                }
            };

        },
        dtp: function() {
            var dtpDetails = transactModel.getTransactDetails().investorDetails;
            var sourceDetails = transactModel.getTransactDetails().fundDetails;
            var destinationDetails = transactModel.getTransactDetails().switchDetails;
            return {

                'strTrxnType': 'DTP',
                'strJsonObj': {
                    'dtpDetailsReq': {
                        'txnType': 'DTP',
                        'advisorDetails': {
                            'name': '',
                            'arnCode': '',
                            'company': ''
                        },
                        'investorDetails': {
                            'firstHolderName': dtpDetails.firstHolderName
                        },
                        'fundDetails': {
                            'folioNo': dtpDetails.folioId,
                            'accNo': sourceDetails.tschvalAccno,
                            'srcFund': sourceDetails.fmDescription,
                        },
                        'dtpCancelDetails': {
                            'destFund': destinationDetails.destinationFund.fundName,
                            'destAccNo': destinationDetails.destinationFund.accNo,
                            'txnRefNo': _transConf.transactionRefNo,
                            'reqDateTime': datefilter(_transConf.transDateTime, 'dd MMMM yyyy, hh:mm a'),
                            'dividendOption': sourceDetails.dividendType
                        }
                    }
                }
            };
        },
        buy: function() {
            var tileDetails = fundDetails.getFundDetails();
            var paymentDetails = transactModel.getTransactDetails().paymentDetails;
            var infoObj = [];
            angular.forEach(tileDetails, function(obj, key) {
                infoObj.push.apply(infoObj, [{
                    'fund': tileDetails[key].fundName,
                    'invAmount': tileDetails[key].amount,
                    'dividend': tileDetails[key].dividend,
                }]);
            });
            return {
                'buyTxnDetailsReq': {
                    'txnType': 'Buy',
                    'advisorDetails': {
                        'name': '',
                        'arnCode': '',
                        'company': ''
                    },
                    'investorDetails': {
                        'firstHolderName': _invDetails.custName,
                        'folioNo': _invDetails.folioId
                    },
                    'fundDetails': infoObj,
                    'paymentDetails': {
                        'bankDetails': paymentDetails.selectedBank,
                        'modeOfPayment': paymentDetails.paymentMethod,
                        'txnRefNo': _transConf.transactionRefNo,
                        'reqDateTime': _transConf.transDateTime
                    }
                }
            };
        }
    };

    var invTransactionDetailsFactory = {

        dataSetter: function(type) {
            this.type = type;
            this.headerText = type.toString().toUpperCase() + ' Details';
            transDetailsModel.setTransactionDetails(type, _dataObject[type]());
        },
        callPDFService: function(type) {
            $loader.start();
            transactModel.downloadTransactDetails(_paramsObject[type]()).then(function(details) {

                //fticCommonUtils.downloadPdf(details.download.strDocBase64);
                details = angular.isArray(details) ? details[0] : details;
                var _details = details.download ? details.download : {};
                var blobData = fticCommonUtils.convertBase64ToBlob(_details.strDocBase64, 'application/pdf');
                FileSaver.saveAs(blobData, type + '.pdf');
            }, function(error) {
                if (error && error.data[0]) {

                    toaster.error(error.data[0].errorDescription);
                }
            }).finally(function() {
                $loader.stop();
            });
        },
        dtpDateSetter: function(type) {
            this.type = type;
            transDetailsModel.setTransactionDetails(type, _dataObject[type]());
        },
        setBuyNewFolioDetails: function(queryParams) {
            //authenticationService.setUser({'guId' : queryParams.guId});
            // transactModel.paymentRedirectState = 'invTransact.review.buy';
            $state.go('invTransact.review.buy');

            transactModel.setIsNewFolio(true);
            transactModel.isRetryPayment = true;
            // paymentDetailsUtility.setPaymentRedirectDtls($scope);
            transactModel.setRetryCount(queryParams.retryCount);
        }

    };

    return invTransactionDetailsFactory;
};

invTransactionDetailsFactory.$inject = ['transactModel', '$filter', 'transDetailsModel', '$loader', 'toaster', 'TransactConstant', 'fticCancelStpFundDetailsModel', 'fticCommonUtils', 'FileSaver', 'fundDetails', '$timeout', '$state'];
module.exports = invTransactionDetailsFactory;
