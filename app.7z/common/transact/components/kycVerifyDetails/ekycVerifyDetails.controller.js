'use strict';
function ekycVerifyDetailsCtrl($scope,$state,transactModel){
	
	$scope.holderDetails = transactModel.getInstantKyc();
 
	transactModel.setInstantKyc($scope.holderDetails);
    
}

ekycVerifyDetailsCtrl.$inject = ['$scope','$state','transactModel'];
module.exports = ekycVerifyDetailsCtrl;