// getGrantAccessDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GrantAccessSubUserDetailsSchema = new mongoose.Schema({
    grantAccessSubUserDetailsArray: {
        type: Array,
        "default": []
    }
});

var GrantAccessSubUserDetailsLookUp = mongoose.model('GrantAccessSubUserDetailsLookUp', GrantAccessSubUserDetailsSchema);

var GrantAccessSubUserDetailsModel = new GrantAccessSubUserDetailsLookUp({
	"grantAccessSubUserDetailsArray":[
						  {
						    "name": "Rajesh Kantu",
						    "username": "rkantu9",
						    "password": "password",
						    "email": "rkantu@abc.com",
						    "accessRights": [
						      "myinvestors",
						      "mylearning",
						      "smartsolutions",
						      "reports"
						    ]
						  },
						  {
						    "name": "Raja",
						    "username": "raj1",
						    "password": "password",
						    "email": "raj@abc.com",
						    "accessRights": [
						      "myinvestors",
						      "mylearning",
						      "smartsolutions",
						      "reports"
						    ]
						  },
						  {
						    "name": "Bharadwaj",
						    "username": "bharad10",
						    "password": "password",
						    "email": "bhardwj@abc.com",
						    "accessRights": [
						      "myinvestors",
						      "mylearning",
						      "smartsolutions",
						      "reports"
						    ]
						  }
	]
});


GrantAccessSubUserDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GrantAccessSubUserDetailsLookUp table, please contact admin...');
    } else {
        GrantAccessSubUserDetailsLookUp.remove({}, function(err) {
            console.log('GrantAccessSubUserDetailsLookUp collection removed');
            GrantAccessSubUserDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GrantAccessSubUserDetailsLookUp table, please contact admin...');
                }
                console.log('GrantAccessSubUserDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GrantAccessSubUserDetailsLookUp;