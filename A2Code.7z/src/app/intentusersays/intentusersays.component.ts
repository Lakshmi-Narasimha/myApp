import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';

import { UserExpression } from '../_models/userexpression';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Ng2PaginationModule } from 'ng2-pagination';

@Component({
  selector: 'intentusersays',
  templateUrl: './intentusersays.component.html',
  styleUrls: ['./intentusersays.component.css']
})

export class IntentusersaysComponent implements OnInit, OnDestroy  {

  userExpressions: Array<UserExpression> = [];
  rows: Array<UserExpression> = [];
  editMode: boolean = true;
  showhidePagination: boolean = false;
  userExpressionText: string = null;
  userExpressionSubscription: any;


  public totalItems: number = this.userExpressions.length;
  public currentPage: number = 1;
  public itemsPerPage: number = 10;

  public maxSize: number = 5;
  public bigTotalItems: number = 175;
  public bigCurrentPage: number = 1;

  constructor(private aiAssistCacheService: AIAssistCacheService, private cd: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.subscribefordata();
  }

  ngOnDestroy() {
    if (this.userExpressionSubscription) {
          this.userExpressionSubscription.unsubscribe();
    }
  }

  public setPage(pageNo: number): void {
    this.currentPage = pageNo;
  }

  onPageChange(page: any): void {
    let start = (page.page - 1) * page.itemsPerPage;
    let end = page.itemsPerPage > -1 ? (start + page.itemsPerPage) : this.userExpressions.length;
    this.rows = this.userExpressions.slice(start, end);
    this.cd.detectChanges();
  }

  public pageChanged(pevent: any) {
  }

  private subscribefordata() {
    this.userExpressionSubscription = this.aiAssistCacheService.activeUserExpressionsObservable.subscribe((data) => {
      this.userExpressions = data;
      this.totalItems = this.userExpressions.length;
      this.updatePaginationVisibility();
      this.onPageChange({ page: 1, itemsPerPage: this.itemsPerPage });
    });
    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });
  }

  onAddUserExpression() {
    if (this.userExpressionText)
      this.aiAssistCacheService.addUserExpression(this.userExpressionText);
    this.userExpressionText = null;
  }

  removeExpression(pUserExpression: UserExpression) {
    this.aiAssistCacheService.removeUserExpression(pUserExpression);
  }

  updatePaginationVisibility() {
    if (this.userExpressions != null && this.userExpressions.length > 0)
      this.showhidePagination = false;
    else
      this.showhidePagination = true;
  }

}
