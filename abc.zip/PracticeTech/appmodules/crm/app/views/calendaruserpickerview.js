define([
    'jquery',
    'underscore',
    'backbone',
    'appcommon/commonutility',
    'appmodules/crm/app/views/calendarview',
    'text!appmodules/crm/app/templates/calendaruserpickerview.html',
    'appcommon/analytics'
], function ($, _, Backbone, Util, CalendarView, CalendarUserPickerViewHtml, Analytics) {
    /*
        Renders the list of user calendars the signed on user can view and allows user to pick one
     */
    var CalendarUserPickerView = Backbone.View.extend({
        userList: [],  // [{name: String, fmid: String}]
        selectedUserFmid: null,
        userSelected: null,  // callback with 1 parameter (String, user's FMID)
        template: _.template(CalendarUserPickerViewHtml),
        initializeElementVars: function() {
            this.$userList = this.$('#pt-calendar-user-picker-list');
        },
        events: {
            "click [pt-calendar-user-choice]": "handleUserPicked",
            "mouseover [pt-calendar-user-choice]": "handleMouseOver"
        },
        initialize: function (options) {
            _.bindAll(this, 'renderView', 'handleKeyDown');
        },
        beforeClose: function() {
            this.hidePageOverlay();
        },
        render: function () {
            if (this.userList.length > 0) {
                // sort....signed on user must be first
                var signedOnFMID = Util.userFMID();
                this.userList.sort(function(a, b) {
                    if (a.fmid == signedOnFMID) {
                        return -1;
                    } else if (b.fmid == signedOnFMID) {
                        return 1;
                    } else {
                        return a.name.localeCompare(b.name);
                    }
                });
                this.renderView();
            }
        },
        renderView: function() {
            this.$el.html(this.template({users: this.userList, selectedFmid: this.selectedUserFmid}));
            this.initializeElementVars();
            this.showPageOverlay();
            this.$userList.slideDown();
        },
        handleKeyDown: function(e) {
            if (e.which == 13) {
                this.handleEnter(e)
            } else if (e.which == 27) { // escape
                this.handleEscape(e);
            }
        },
        handleEnter: function(r) {
            this.handleSelection();
        },
        handleEscape: function(e) {
            this.dismiss();
        },
        handleUserPicked: function (e) {
            e.preventDefault();
            if (!this.$(e.target).closest('li').hasClass('pt-default')) {
                var $selectedUserElement = e.target.nodeName == "LI" ? this.$(e.target) : this.$(e.target).closest('li');
                this.selectedUserFmid = $selectedUserElement.attr('pt-calendar-user-choice');
                this.handleSelection();
                Analytics.analytics.recordAction('ProxyCalendar:switchedUser:clicked');
            } else {
                this.refreshSelection();
                this.dismiss();
            }
        },
        handleSelection: function () {
            this.refreshSelection();
            this.userSelected(this.selectedUserFmid);
            ////console.log("CalendarView" + CalendarView);
            this.dismiss();
        },
        handleMouseOver: function(e) {
            var $selectedUserElement = e.target.nodeName == "LI" ? this.$(e.target) : this.$(e.target).closest('li');
            this.$('li').removeClass('active');
            $selectedUserElement.addClass('active');
            this.selectedUserFmid = $selectedUserElement.attr('pt-calendar-user-choice');
        },
        dismiss: function() {
            this.$userList.slideUp();
            this.hidePageOverlay();
            this.close();
        },
        showPageOverlay: function() { // adds a transparent div that listens for any tap on page outside of the picker
            var self = this;
            self.hidePageOverlay();
            $('body').append('<div id="pt-calendar-user-picker-overlay" class="pt-transparent-overlay"></div>');
            $('#pt-calendar-user-picker-overlay').on('click', function() {
                self.dismiss();
            });
            $('body').on('keydown', self.handleKeyDown);
        },
        hidePageOverlay: function() {
            var $overlay = $('#pt-calendar-user-picker-overlay');
            if ($overlay.length > 0) {
                this.$el.css('z-index', 'auto');
                $overlay.remove();
                $('body').off('keydown', self.handleKeyDown);
            }
        },
        refreshSelection: function() {
            this.$userList.find('[pt-calendar-user-choice]').removeClass('pt-default');
            this.$userList.find('[pt-calendar-user-choice="' + this.selectedUserFmid + '"]').addClass('pt-default');
        }
    });

    return CalendarUserPickerView;

});
