// getinvestordetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InvestorDetailsSchema = new mongoose.Schema({
    investorDetailsObject: {
        type: Array,
        "default": []
    }
});

var InvestorDetailsLookUp = mongoose.model('InvestorDetailsLookUp', InvestorDetailsSchema);
/*json order: investor book-*/
var InvestorDetailsModel = new InvestorDetailsLookUp({
    "investorDetailsObject": [{
    "investorDetails": {
        "attritionAnalysisObject": [{
            "purchase": {
                "year": "2012",
                "NoOfUnits": "0.00"
            },
            "redemption": {
                "year1": {
                    "key": "2012",
                    "value": "0%"
                },
                "year2": {
                    "key": "2013",
                    "value": "0%"
                },
                "year3": {
                    "key": "2014",
                    "value": "0%"
                },
                "year4": {
                    "key": "2015",
                    "value": "0%"
                },
                "year5": {
                    "key": "2016",
                    "value": "0%"
                },
                "total": "0.00"
            }
        }, {
            "purchase": {
                "year": "2013",
                "NoOfUnits": "0.00"
            },
            "redemption": {
                "year1": {
                    "key": "2012",
                    "value": ""
                },
                "year2": {
                    "key": "2013",
                    "value": "0%"
                },
                "year3": {
                    "key": "2014",
                    "value": "0%"
                },
                "year4": {
                    "key": "2015",
                    "value": "0%"
                },
                "year5": {
                    "key": "2016",
                    "value": "0%"
                },
                "total": "0.00"
            }
        }, {
            "purchase": {
                "year": "2014",
                "NoOfUnits": "0.00"
            },
            "redemption": {
                "year1": {
                    "key": "2012",
                    "value": ""
                },
                "year2": {
                    "key": "2013",
                    "value": ""
                },
                "year3": {
                    "key": "2014",
                    "value": "0%"
                },
                "year4": {
                    "key": "2015",
                    "value": "0%"
                },
                "year5": {
                    "key": "2016",
                    "value": "0%"
                },
                "total": "0.00"
            }
        }, {
            "purchase": {
                "year": "2015",
                "NoOfUnits": "0.00"
            },
            "redemption": {
                "year1": {
                    "key": "2012",
                    "value": ""
                },
                "year2": {
                    "key": "2013",
                    "value": ""
                },
                "year3": {
                    "key": "2014",
                    "value": ""
                },
                "year4": {
                    "key": "2015",
                    "value": "0%"
                },
                "year5": {
                    "key": "2016",
                    "value": "0%"
                },
                "total": "0.00"
            }
        }],
        "AUMGrowth": [{
            "fyYear": "Apr'15-Mar'16",
            "openingAUM": "1328472286.86",
            "netSales": "-55594323.10",
            "marketAppreciation": "10159090.95",
            "closingAUM": "1283037054.71"
        }, {
            "fyYear": "Apr'14-Mar'15",
            "openingAUM": "946175186.26",
            "netSales": "95844640.31",
            "marketAppreciation": "286452460.29",
            "closingAUM": "1328472286.86"
        }, {
            "fyYear": "Apr'13-Mar'14",
            "openingAUM": "0",
            "netSales": "54653823.01",
            "marketAppreciation": "891521363.25",
            "closingAUM": "946175186.26"
        }],
        "AUMGrowthGraph": [{
            "fyYear": "Apr'15-Mar'16",
            "netSales": "-55594323.10",
            "marketAppreciation": "10159090.95"
        }, {
            "fyYear": "Apr'14-Mar'15",
            "netSales": "95844640.31",
            "marketAppreciation": "286452460.29"
        }, {
            "fyYear": "Apr'13-Mar'14",
            "netSales": "54653823.01",
            "marketAppreciation": "891521363.25"
        }],
        "InverstorFoliosShares": [{
            "range": "Below 1 Lakh",
            "folioShares": "6379"
        }, {
            "range": "1 Lakh - 5 Lakh",
            "folioShares": "1557"
        }, {
            "range": "5 Lakh - 50 Lakhs",
            "folioShares": "284"
        }, {
            "range": "Above 50 Lakhs",
            "folioShares": "21"
        }],
        "investorBookDetails": {
            "purchaseType": [{
                "type": "SIP",
                "shares": "1804"
            }, {
                "type": "Lumpsum",
                "shares": "5819"
            }, {
                "type": "Multiple",
                "shares": "618"
            }],
            "assetCategory": [{
                "type": "Multiple",
                "shares": "7950"
            }, {
                "type": "ELSS",
                "shares": "132"
            }, {
                "type": "LIQUID",
                "shares": "22"
            }, {
                "type": "EQUITY",
                "shares": "248"
            }, {
                "type": "FEEDER",
                "shares": "15"
            }, {
                "type": "FIXED INCOME",
                "shares": "135"
            }, {
                "type": "FOF",
                "shares": "21"
            }, {
                "type": "BALANCED",
                "shares": "28"
            }]
        }
    }
}]

});

InvestorDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorDetailsLookUp table, please contact admin...');
    } else {
        InvestorDetailsLookUp.remove({}, function(err) {
            console.log('InvestorDetailsLookUp collection removed');
           InvestorDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InvestorDetailsLookUp table, please contact admin...');
                }
                console.log('InvestorDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorDetailsLookUp;
