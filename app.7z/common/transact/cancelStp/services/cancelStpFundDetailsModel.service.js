//getSelectFundDtls
'use strict';

var CancelStpFundDetailsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, $state) {
	 var _sfDtls = null;
	 var _selectedFundDtls = null;
	 var _cstpDetails=null;
	 var _ReferenceNo=null;
	 var _transConfirm=[];
	 var _cancelStpSelectedFundDtls = null;
	 var CancelStpFundDetailsModel = {
		fetchSelectFundDetails : function (selectedInv) {
			var params = {};
			params.folioId = selectedInv.folioId;			
			//params.folioId = "14486433";			
			//params.folioId = "17922528";			
			params.guId = authenticationService.getUser().guId;		    	           
		    var deferred = $q.defer();
		     Restangular.one('clients/stpSummary').get(params).then(function (sfdetails) {		     
		        deferred.resolve(sfdetails);
		    }, function (resp) {
		        deferred.reject(resp);
		        console.log('error');
		    });
		    return deferred.promise;
		},

		getSelectFundGridDtls: function() {
			return _sfDtls;
		},
		setSelectFundGridDtls: function(sfdetails) {
			if(sfdetails.stpSummary[0] != undefined){
				_sfDtls = sfdetails.stpSummary;
			}else{
				_sfDtls = [];
				_sfDtls.push(sfdetails.stpSummary);
			}
		},
		getSelectFundDtls: function() {            
			return _selectedFundDtls;
		},
		setSelectFundDtls: function(selectedFundDtls) {            
			_selectedFundDtls = selectedFundDtls;
		},
		setCstpDetails : function(cstpDetails) {
            _cstpDetails = cstpDetails;
        },

        getCstpDetails : function() {
            return _cstpDetails;
        },
        setRefNum : function(ReferenceNo) {
            _ReferenceNo = ReferenceNo;
        },
        getRefNum : function() {
            return _ReferenceNo;
        },
        getTransactConfirm : function() {
            return _transConfirm;
        },
        setTransactConfirm : function(transConfirm) {
            _transConfirm = transConfirm;
        },
        
		validateCSTP : function(body,params){
		  var end = "";
          end = "transact/cancelStp";
          var params = {};
          params.guId = authenticationService.getUser().guId;
          var deferred = $q.defer();
          Restangular.one(end).customPOST(body, "", params, {}).then(function (data) {
              console.log(data);
              deferred.resolve(data);
          }, function (resp) {
              deferred.reject(resp);
              console.log('error');
          });
          return deferred.promise;
		   
        },

    };				
	  return CancelStpFundDetailsModel;

};

CancelStpFundDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', '$state'];
module.exports = CancelStpFundDetailsModel;