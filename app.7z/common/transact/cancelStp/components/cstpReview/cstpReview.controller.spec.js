'use strict';
describe('Controller: cstpDetailsReviewController', function() {
    var $controller,$scope,cstpDetailsReviewController,transactModel;

    var fundDetailsResponse =  {
        "trxnNo": "SS000176",
        "totalInsallNo": "155",
        "startDate": "28/11/2010",
        "sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
        "sourceAccNo": "1689900886175",
        "nextTiggerDate": "28/04/2017",
        "frequency": "Monthly",
        "endDate": "28/10/2019",
        "destFundDesc": "Franklin India Savings Plus Fund Retail Option",
        "destAccNo": "1729900886175",
        "cancelDate": "28/04/2017",
        "balInsallNo": "31",
        "amount": "2000",
        "alertFlag": "Y",
        "alertDays": "7"
    };

    beforeEach(angular.mock.module('advisor'));             

    beforeEach(inject(function($rootScope,_$controller_,_transactModel_){  
        $controller = _$controller_;
        $scope = $rootScope.$new(); 
        
        transactModel = _transactModel_;
        transactModel.setFundDetails(fundDetailsResponse);
        $scope.config = {};
        loadController();           
    }));    

    function loadController(){
        cstpDetailsReviewController = $controller('cstpDetailsReviewController', { $scope: $scope });
    }

    it('should be defined',function(){
        expect(cstpDetailsReviewController).toBeDefined();
    });

    it('should define the variables headerText,fundDetails,cstpKeyValuePairs',function(){
        expect($scope.headerText).toBe('STP Cancellation Details');
        expect($scope.fundDetails).toEqual(fundDetailsResponse);  
        expect($scope.cstpKeyValuePairs[0].text).toBe('Cancellation Effective Date');
        expect($scope.cstpKeyValuePairs[0].value).toBe(fundDetailsResponse.nextTiggerDate);
        expect($scope.config.toState).toBe('invTransact.base.cancelStp');
    });
});


