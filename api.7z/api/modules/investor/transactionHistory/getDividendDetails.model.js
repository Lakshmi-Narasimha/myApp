// getDividendDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var DividendDetailsModelSchema = new mongoose.Schema({
    dividendDetailsResp: {
        type: Array,
        "default": []
    }
});

var TransDividendDetailsModelLookUp = mongoose.model('TransDividendDetailsModelLookUp', DividendDetailsModelSchema);

var DividendDetailsModel = new TransDividendDetailsModelLookUp({
    dividendDetailsResp : {
  "divHistory": [{
      "trDate": "24 dec 2012",
      "paidDate": "24 dec 2014",
      "trType": "Payout",
      "amount": "5,307.64",
      "bankName": "",
      "bankAccountNo": "",
      "modeOfPayment": "",
      "schemeCode": "",
      "planCode": "",
      "accountNo": "",
      "schemeDesc": "",
      "planDesc": "",
      "fundDesc": "",
      "divPercentage": ""
    }, {

      "trDate": "24 dec 2013",
      "paidDate": "24 dec 2016",
      "trType": "Reinvestment",
      "amount": "5,307.64",
      "bankName": "",
      "bankAccountNo": "",
      "modeOfPayment": "",
      "schemeCode": "",
      "planCode": "",
      "accountNo": "",
      "schemeDesc": "",
      "planDesc": "",
      "fundDesc": "",
      "divPercentage": "",
    }, {
      "trDate": "24 dec 2011",
      "paidDate": "24 dec 2014",
      "trType": "Reinvestment",
      "amount": "5,307.64",
      "bankName": "",
      "bankAccountNo": "",
      "modeOfPayment": "",
      "schemeCode": "",
      "planCode": "",
      "accountNo": "",
      "schemeDesc": "",
      "planDesc": "",
      "fundDesc": "",
      "divPercentage": ""
    }, {
      "trDate": "24 dec 2010",
      "paidDate": "24 dec 2012",
      "trType": "Payout",
      "amount": "5,307.64",
      "bankName": "",
      "bankAccountNo": "",
      "modeOfPayment": "",
      "schemeCode": "",
      "planCode": "",
      "accountNo": "",
      "schemeDesc": "",
      "planDesc": "",
      "fundDesc": "",
      "divPercentage": ""
    }, {
      "trDate": "24 dec 2009",
      "paidDate": "24 dec 2010",
      "trType": "Payout",
      "amount": "5,307.64",
      "bankName": "",
      "bankAccountNo": "",
      "modeOfPayment": "",
      "schemeCode": "",
      "planCode": "",
      "accountNo": "",
      "schemeDesc": "",
      "planDesc": "",
      "fundDesc": "",
      "divPercentage": ""
    }]
}
});

TransDividendDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating TransDividendDetailsModelLookUp table, please contact admin...');
    } else {
        TransDividendDetailsModelLookUp.remove({}, function(err) {
            console.log('TransDividendDetailsModelLookUp collection removed');
            DividendDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransDividendDetailsModelLookUp table, please contact admin...');
                }
                console.log('TransDividendDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransDividendDetailsModelLookUp;
