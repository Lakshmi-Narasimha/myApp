/**
 * @ngdoc property
 * @name Forgot Password controller
  * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function forgotUsernameController ($scope, $state, constants,advisorRegistrationModelService) {
	  $scope.forgotType="username";
   advisorRegistrationModelService.setUserForgotTypeDetails($scope.forgotType);
			$scope.headingObj = {
			 	text : constants.login.FORGOTTEN_USERNAME//'Forgotten Password'
			 }
       $scope.$on('investorfpSelected',function(event){
           $state.go("loginmaster.forgotusername.investor");

      });
       $scope.$on('distributorSelected',function(event){ 
         $state.go("loginmaster.forgotusername.distributor"); 
      });
       $scope.$emit("setBreadCrumb",{
        cat : "forgotusername",
        breadCrumb :{
            label:'Forgot Username',
            state : ''
        }       
    });

 
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
forgotUsernameController.$inject = ['$scope', '$state' , 'constants','advisorRegistrationModelService'];
module.exports = forgotUsernameController;