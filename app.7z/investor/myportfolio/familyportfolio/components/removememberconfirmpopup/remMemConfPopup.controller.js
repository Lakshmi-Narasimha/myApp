/**
 * @ngdoc property
 * @name RemMenConfPopupController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function RemMenConfPopupController($scope, $uibModalStack,investorEventConstants) {
    $scope.onCancel = function(){
        $uibModalStack.dismissAll();
    };
    $scope.onSubmit=function(){
        $uibModalStack.dismissAll();
        $scope.$emit(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_REMOVE_CONF_EVENT);
    };
}
RemMenConfPopupController.$inject = ['$scope', '$uibModalStack','investorEventConstants'];
module.exports = RemMenConfPopupController;