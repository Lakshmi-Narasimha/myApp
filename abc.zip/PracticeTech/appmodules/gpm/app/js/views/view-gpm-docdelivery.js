﻿define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'appmodules/contactprofile/app/models/cpviewmodel', 'text!appmodules/gpm/app/templates/gpmdocdelivery.html', 'appmodules/contactprofile/app/models/preferenceviewmodel'
], function ($, _, Backbone, Utils, CPViewModel, DocDeliveryTemplate, PreferenceViewModel) {
    var self;
    var docDeliveryView = Backbone.View.extend({
        el: "#gpm-form-update-field-container",
        id: 'gpm-form-update-field-container',
        events: {
            'change input[type="radio"]': 'toggleRadioClassActive',
        },
        template: _.template(DocDeliveryTemplate),
        initialize: function (data) {
            self = this;
            this.data = data;
        },
        render: function (updateMode) {

           if (!this.model.get('currentItemSet')) {
                this.data = this.getDocDelivData();
                this.model.setCurrentValue(updateMode, { data: this.data });
            }
            var self = this;
            try {
                var _compiledTemplate = this.template({ data: this.model, documentDelivery: PreferenceViewModel.getData().documentDelivery
                });
                $("#" + this.id).html(_compiledTemplate);
                if (this.model.attributes.items[0].attributes.changedItemValue == "true") {
                    $('#pt-doc-consent').prop("checked", true);
                    }
                }
            catch (error) {
                console.log(error);
                }

        },
        getDocDelivData: function () {
            var _prefViewModelData = PreferenceViewModel.getData();
            var _prefDocDelivData = _prefViewModelData.documentDelivery;
            var _gpmDocDelivModel = {
                prefrcEmailShow: "",
                prefrcAccount: "",
                prefrcDocType: "",
                prefrcFinConfirm: "",
                prefrcShareHolder: ""
            }
            _gpmDocDelivModel.prefrcEmailShow = _prefDocDelivData.prefrcSerEmailShow;
            _gpmDocDelivModel.prefrcAccount = _prefDocDelivData.prfrcAccountStatements;
            _gpmDocDelivModel.prefrcDocType = _prefDocDelivData.prfrcAddsnlDocumentType;
            _gpmDocDelivModel.prefrcFinConfirm = _prefDocDelivData.prfrcFinancialConfirms;
            _gpmDocDelivModel.prefrcShareHolder = _prefDocDelivData.prfrcShareHolderDocs;

            return _gpmDocDelivModel;
        },
        toggleRadioClassActive: function (event) {
            var _radio = $(event.target);
            var _radioHolder = _radio.parents('div.radio-grp');
            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
            _radio.parents('div.radio-group-conatiner').addClass('active');
        },
        validateAndNavigateFromStep1: function () {

            var _self = this;
            function valuesModified() {
                var _isModified = true;
                var _items = _self.model.get('items');
                var _prfrdShareHolder = _items.find(function (row) { return row.get("itemType") == "prefrcShareHolder" }),
                    _prfrdAccount = _items.find(function (row) { return row.get("itemType") == "prefrcAccount" }),
                    _prfrdFinConfirm = _items.find(function (row) { return row.get("itemType") == "prefrcFinConfirm" }),
                    _prfrdDocType = _items.find(function (row) { return row.get("itemType") == "prefrcDocType" }),
                    _prfrdEmailShow = _items.find(function (row) { return row.get("itemType") == "prefrcEmailShow" });

                if (_prfrdShareHolder.get('valueChanged') == false && _prfrdAccount.get('valueChanged') == false && _prfrdFinConfirm.get('valueChanged') == false && _prfrdDocType.get('valueChanged') == false ) {
                    _isModified = false;
                }
                return _isModified;
            }
           
            if (this.model.validate('gpm-update-form', true)) {
                var finCheck = $('input[name=financialOnlineMail]:checked').val().toLowerCase();
                var shareholderCheck = $('input[name=shareholderOnlineMail]:checked').val().toLowerCase();

                if (finCheck == "online" &&  shareholderCheck == "u.s. mail") {
                    $('#communication-frm-advisor div.shareholderDiv').addClass('error');
                    $('#shareData label').removeClass('hidden');
                    $('html, body').animate({
                        scrollTop: $(".shareholderDiv").offset().top
                    }, 0);
                    return;
                }

                /* I Agree checkbox condition */
                var iAgreeCondition = $('#section-docdelivery .chkbox-agreed:visible');
                if (iAgreeCondition.attr('type') == 'checkbox') {
                    if ($.trim($('[name=' + iAgreeCondition.attr('name') + ']:checked').val()).length <= 0) {
                        BootstrapDialog.show({
                            title: 'Important information',
                            message: "You must complete that you've received client consent to update document delivery preferences.",
                            //closeByBackdrop: false,
                            cssClass: 'esig-mobile-unavailablity',
                            buttons: [
                                    {
                                        label: 'OK',
                                        cssClass: 'btn pt-btn-yes generic-button btn-primary',
                                        action: function (dialog) {
                                            dialog.close();
                                        }
                                    }]
                        });
                        return;
                    }
                }
                /* Close */

                this.model.setChangedValue();
                if (valuesModified()) {
                    $('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                } else {
                    Utils.showNoChangesMessageToUser();
                }

            }



        }
    });
    return docDeliveryView;
});