
define([ 'text!appmodules/ncst/app/templates/confirmation.html',
		'appmodules/ncst/app/js/lib/validate-4.2',
		'appmodules/ncst/app/js/utils','config','appmodules/ncst/app/js/models/model-client','appcommon/globalcontext', 'appcommon/analytics', 'appcommon/globalcontext' ,'appcommon/commonutility',"errorLog"],
		function(Template, Validator,Utils,Config,ClientModel,GlobalContext, Analytics, GlobalContext,CommonUtils,ErrorLog ) {
	 var context = GlobalContext.getInstance().getGlobalContext().Context;
	 var self = null,ClientInfoModel = ClientModel.get('clientInfo'), BASE_URL = Config.odataServiceName, contextInfo = null, NBSTUrl = Config.NBSTUrl, NBSTCtx = {}
	 var confirmationView = Backbone.View.extend({
		el : '#ncst-app',
		statsTemplate : _.template(Template),
		initialize : function() {
			self = this;
			contextInfo = null;
			NBSTCtx = {
				 	clientAuthCheckTimeInterval : 5000,
				 	clientCreatedTime : null,
					putCtxAuthorizedTime : null,
					putCtxFirstHitTime : null,
					putCtxTimedOutTimer : null,
					putCtxClearTimer : null,
					putCtxIntervalActiveFlag:false,
					putCtxIntervalInitiated:false,
					putCtxIntervalTimedOut:false,
					clientCreatedTime:new Date()
					
			}
			this.nigoopnReviewInSM = Config.getConfigProperty("hocExtrnlActnLinks").nigoopnReviewInSM;
			this.$main = this.$('#client-info');

		},
		events : {
			'change input[type="checkbox"]' : 'toggleCheckboxClassActive',
			'click #new-business-link' : 'handleNewBusinessLanuch',
			'click #new-client-without-address':'lanchNewClient',
			'click #new-client-with-address':'lanchNewClientWithAddress',
			'click #register-client': 'registerClient',
		},
		render : function(obj) {
			clientCreatedTime = new Date();
			contextInfo = null;
			obj.privacyUrl = Config.getConfigProperty("ncstprivacyNotcieUrl");
			obj.authUrl = Config.eSigConfig.serviceUrl + "gtcforms/402203.pdf";
			obj.prmUrl = Config.getConfigProperty("practiceRelationshipManagerUrl");
		    // save the context sharing info
			if(obj.clId){
				contextInfo = {
						clId :obj.fullclId ,
						advId: obj.advId,
						servcAdvsrId: obj.servcAdvsrId
				}
			}
			
			var _data = obj;
			_data.ClientModel = ClientModel;
			_data.nigoopnReviewInSM = this.nigoopnReviewInSM;
			Utils.unlockForm();
			this.$main.html(this.statsTemplate(_data));
			var clientType = ClientInfoModel.get('clientType');
			// Deciding if Person or entity
			if (clientType == "P") {
				$('.entity-field').addClass('hidden');
				$('.person-field').removeClass('hidden');
			} else {
				$('.entity-field').removeClass('hidden');
				$('.person-field').addClass('hidden');
			}
			if(_data.ClientModel.get('clientCreated') == 'yes') {
				Analytics.analytics.recordSharedSuiteAction('ncstConfirmation:newClientCreated');
			}
		},
		clearView : function() {
			this.undelegateEvents();// Unbind all local event bindings
		},
		afterRender : function() {
			
		},
		lanchNewClient:function(){
			 $("#client-info").css({'border-top': 'solid 3px #7db742', 'padding': '0'});
			 var _queryString = context.QueryString?context.QueryString:'';
			// ClientModel.set('newClient',true);
			Analytics.analytics.recordSharedSuiteAction('ncstConfirmation:setupNewClientClicked');
			CommonUtils.writeCookie('nocontextlaunch',true);
			// Backbone.history.navigate('ncst/client-info'+_queryString, {
			// trigger : true });
			var _queryParams = Utils.getUrlParams();
			var _redirectUrl = 'ncst/',_urlParamString = "";
			if(_queryParams && _queryParams['mode'] && _queryParams['mode'] == "standalone"){
				_urlParamString = "", _paramCounter = 0;
				for(key in _queryParams){
					if(key != "draftID" && key != "ProspectID"){
						if(_paramCounter == 0 ){
							_urlParamString+="?";
						}
						if(_paramCounter != 0 ){
							_urlParamString+="&";
						}
						_paramCounter++;
						_urlParamString+=key+"="+_queryParams[key];
					}
				}
				_redirectUrl = 'ncst/'+_urlParamString;
				var _context = {
	    				queryString:_urlParamString
	    		};
				setGlobalContext(_context);
			}
			Backbone.history.navigate(_redirectUrl,true); 
			
			function setGlobalContext(context){
				 var gContext = GlobalContext.getInstance();
			    	var _context = {
			    			advisorFMID:context.advisorFMID, 
			    			isAdvisorOBO:context.isAdvisorOBO, 
			    			contactId:context.contactId, 
			    			contactType:context.contactType, 
			    			contactSource:context.contactSource, 
			    			groupId:context.groupId,
			    			isStandalone:context.isStandalone,
			    			queryString:context.queryString,
			    			contextId:context.contextId
			    		};
			    	gContext.setContext(_context.advisorFMID,_context.isAdvisorOBO,_context.contactId,_context.contactType,
			    			_context.contactSource,_context.groupId,_context.isStandalone,_context.queryString,_context.contextId);
			    	
			    }
		},
		lanchNewClientWithAddress:function(){
			$("#client-info").css({'border-top': 'solid 3px #7db742', 'padding': '0'});
			var _queryString = context.QueryString?context.QueryString:'';
			ClientModel.set('newClientWithAddress',true);
			Analytics.analytics.recordSharedSuiteAction('ncstConfirmation:setupNewClientWithAddressClicked');
			Backbone.history.navigate('ncst/client-info'+_queryString, { trigger : true }); 
		},
		registerClient:function(){
			Analytics.analytics.recordSharedSuiteAction('ncstConfirmation:registerClientClicked'); 
		},
		handleNewBusinessLanuch : function() {
			NBSTCtx.putCtxFirstHitTime = new Date();
			//reset flags
			NBSTCtx.putCtxIntervalInitiated = false;
			NBSTCtx.putCtxIntervalTimedOut = false;
			if (!(/window/i.test(GlobalContext.getInstance().getGlobalContext().Context.Device.operatingSystem()))) {
				BootstrapDialog.alert("New Business Setup is only available on Windows devices (desktop or Surface)",null,"Function unavailable");
				return;
			}
			var _url = BASE_URL+"putAdvisorSessionContext";
			var _data = {
					putAdvsSessCntxAcctIds:null,
					putAdvsSessCntxClIds:null,
					putAdvsSessCntxDstrIds:null,
					putAdvsSessCntxGrpIds:null
		              
			};
			if(contextInfo != null && contextInfo.clId){
				// launch ncst with context
				// clId context
				var _spinnerOptions = {"msg":"<br><div>Loading...</div><br><div class='nbst-custom-spinner'>Please wait while we transfer your client's information across our systems.</div><br><div  class='nbst-custom-spinner'>It may take up to a minute to complete.</div>","height":200};
					Utils.lockForm(_spinnerOptions);
					var _clientCtx = {
							clId:contextInfo.clId,
							clCtx:"COLA.CL",
							clRole:"PrimaryClient"
					};
					_data.putAdvsSessCntxClIds = [_clientCtx];
				// distributor context
					var _dstrCtx = {
					        dstrId:ClientModel.get('isAACUser') ? contextInfo.advId : contextInfo.servcAdvsrId,
							dstrCtx:"DMU.DIST"
					};
					_data.putAdvsSessCntxDstrIds = [_dstrCtx];
			
				this.callPutContextService(_url, _data);
			}else{
				// launch ncst without context
				launchNBST();
			}
			
		},
		callPutContextService : function(url, data) {
			var _self = this;
			Utils.post(url, JSON.stringify(data),
					_self.putContextServiceSuccess, function(xhr) {

				//Utils.unlockForm();
				if(xhr.status == 401 || xhr.status == 0){
					if(!NBSTCtx.putCtxIntervalInitiated){
						NBSTCtx.putCtxIntervalInitiated = true;
						//call the put ctx service after 5 seconds 
						setTimeout(function(){
							_self.callPutContextService(url, data);
						}, Config.NBSTCtxSrvcTimeIntrvl);
						NBSTCtx.putCtxTimedOutTimer = setTimeout(_self.showNBSTTimeoutMessage, Config.NBSTMaxWaitTime)
					}else{
						if(!NBSTCtx.putCtxIntervalTimedOut){
							var _currentTime  = new Date();
							//do not call the service again if it is already 57 seconds or more since the user clicked NBST link
							if((_currentTime - NBSTCtx.putCtxFirstHitTime) >= 57000){
								return;
							}
							setTimeout(function(){
								_self.callPutContextService(url, data);
							}, Config.NBSTCtxSrvcTimeIntrvl);
						}
					}
				}else{
					launchNBST();
					Utils.logError(xhr);
				}
				
			});
		},
		showNBSTTimeoutMessage:function(){
			//set timeout flag to true
			NBSTCtx.putCtxIntervalTimedOut = true;
			Utils.unlockForm();
			self.logNBSTTimeoutMessage();
			BootstrapDialog.show({
				title : 'System timeout',
				message : "<div>Our systems are unable to transfer your client’s information at this time.</div><br><div>Please try again later.</div>",
				closeByBackdrop: false,
				cssClass : '',
				buttons : [
						{
							label : 'OK',
							cssClass : 'generic-button accept-button',
							id : '',
							action : function(dialog) {
								dialog.close();
							}
						} ]
			});
		
		},
		putContextServiceSuccess : function(response) {
			clearTimeout(NBSTCtx.putCtxTimedOutTimer);
			Utils.unlockForm();
			//self.logNBSTSuccessMessage();
			var _contextId = null;
			if(response && response.d){
				_contextId = response.d.cntxId;
			}else{
				 Utils.logError(response);
			}
			launchNBST(_contextId);
		},
		
		toggleCheckboxClassActive : function(event) {
			var _checkbox = $(event.target);
			if (_checkbox.is(':checked')) {
				_checkbox.parents('div.radio-group-conatiner').addClass(
						'active');
			} else {
				_checkbox.parents('div.radio-group-conatiner').removeClass(
						'active');
			}
		},
		logNBSTSuccessMessage:function(){
			var _ctxSuccessTime = new Date();
			var _logData = {
					message:"NBST Context Success - This is not an error log: this is just for tracking purpose",
					stack:{
						createdTime:NBSTCtx.clientCreatedTime.toTimeString(),
						contextSuccessTime:_ctxSuccessTime.toTimeString(),
						delayInSeconds : (_ctxSuccessTime - NBSTCtx.clientCreatedTime)/1000,
						timeTakenServiceToRespond : (_ctxSuccessTime - NBSTCtx.putCtxFirstHitTime)/1000
						
					}
			}
			ErrorLog.ErrorUtils.myError(_logData,true);
		},
		logNBSTTimeoutMessage:function(){
			var _logData = {
					message:"NBST Context Timedout",
					stack:{
						"message":"NBST delay link Timedout"
					}
			}
			ErrorLog.ErrorUtils.myError(_logData,true);
		},
	});
	 function launchNBST (_contextId){
			if(_contextId){
				window.open(NBSTUrl+"&contextid="+_contextId);
			}else{
				window.open(NBSTUrl);
			}
		}
	return confirmationView;

});
