// getUserAccessDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');
var FPUerAccessDetailsSchema = new mongoose.Schema({
    userAccessDetails: {
        type: Object,
        'default': {}
    }
});
var FPUerAccessDetailsLookUp = mongoose.model('FPUerAccessDetailsLookUp', FPUerAccessDetailsSchema);
var FPUerAccessDetailsModel = new FPUerAccessDetailsLookUp({
    userAccessDetails : {
        'getUserAccessDetails': [
            {
                'userName':'Skumar'
            },
            {
                'userName':'Raja'
            },{
                'userName':'Giri'
            },
            {
                'userName':'Babu'
            },{
                'userName':'Kishore'
            },
            {
                'userName':'dhar'
            }
        ]
    }
});

FPUerAccessDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating FPUerAccessDetailsLookUp table, please contact admin...');
    } else {
        FPUerAccessDetailsLookUp.remove({}, function() {
            console.log('FPUerAccessDetailsLookUp collection removed');
            FPUerAccessDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating FPUerAccessDetailsLookUp table, please contact admin...');
                }
                console.log('FPUerAccessDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FPUerAccessDetailsLookUp;
