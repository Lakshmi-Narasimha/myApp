/**
 * @ngdoc property
 * @name Checkbox directive
 * @requires $state
 * @description
 *
 * - Checkbox is a component directive which can be resused across different forms in the application.
 *
 **/
'use strict';

var customLoader = function(authenticationService) {
    return {
            template: require('./customLoader.html'),
            restrict: 'AE',
            scope: false,
            controller:['$scope', function($scope){   

               if(authenticationService.getAppName() == "guest") {
                 $scope.imgLoaderSrc = "../guest/images/ajax-loader.gif";
            }else{
                $scope.imgLoaderSrc = "../advisor/images/ajax-loader.gif";
            }
                          
                
            }],
            link:function ($scope,element) {
                $scope.showLoader = false;
                //alert("in directive")
                $scope.$on("loader_show", function () {
                    //alert("show")
                    $scope.showLoader = true;
                });
                $scope.$on("loader_hide", function () {
                    //alert("hide");
                    $scope.showLoader = false;
                });
        }
            
    }
};

customLoader.$inject = ['authenticationService'];
module.exports = customLoader;


/*.directive("loader", function ($rootScope) {
    return function ($scope, element, attrs) {
        $scope.$on("loader_show", function () {
            return element.show();
        });
        return $scope.$on("loader_hide", function () {
            return element.hide();
        });
    };
}
)*/


/*var customLoader = function() {
    return {
            template: require('./customLoader.html'),
            restrict: 'AE',
            link:  function ($scope,element,attrs) {
                alert("in directive")
                $scope.$on("loader_show1", function () {
                    alert("show1")
                    return element.show();
                });
                $scope.$on("loader_hide", function () {
                    alert("hide");
                    return element.hide();
                });
        }
            
    }
};*/