define([ 'jquery', 'underscore', 'backbone','backbonesubroute',
		'appmodules/eSig/app/js/views/customer-list-view',
		'appmodules/eSig/app/js/views/sign-document-view',
		'appmodules/eSig/app/js/views/sign-submitted-view',
		'appmodules/eSig/app/js/utils', 'appmodules/eSig/app/js/audit' ], function ($, _, Backbone, Backbonesubroute, CustListView,
		SigView, SignSubmitView, Utils, AuditLog) {
	var _docId = null;
	var views = {
		"custListView" : null,
		"signDocView" : null,
		"signSubmitView" : null
	}

	var eSigRouter = Backbone.SubRoute.extend({
		routes : {
			'req-signers-list/:docid' : 'showClientList',
			'sign-submitted' : 'showSignSubmitted',
			'sign-document-view/:cid/:docid' : 'showSignDocument',
			'*path' : 'showDocList'
		},

		initialize: function () {
		    console.log("inside router inial");
		    AuditLog.initialise();
		    AuditLog.initialiseBrowserClose();
		},
		showSignSubmitted : function() {
			if (views.signSubmitView == null) {
				views.signSubmitView = new SignSubmitView();
			}
			views.signSubmitView.render(_docId);
			//views.signSubmitView.afterRender();
		},
		showClientList :function(docId) {
			if (views.custListView == null) {
				views.custListView = new CustListView();
			}
			views.custListView.render(docId);
		},
		showSignDocument :function(cid, docid) {
			if (views.signDocView == null) {
				views.signDocView = new SigView();
			}
			_docId  = docid;
			views.signDocView.render(cid,docid);
			
		},
		showDocList : function() {
			/*Default path*/
		}

	});

	var setAppVersion = function() {
		// add the version num and date // in footer only for e1
		var _versDateStng = APP_VERSION + '-' + new Date().toDateString();
		$('#version-display').html(_versDateStng);
	};

	var endOrientation = function(handler) {
		$(window).off("orientationchange", handler);
	};
	var startOrientation = function(handler) {
		$(window).on("orientationchange", handler);
	};

	function startResize(handler) {
		$(window).resize(handler);
	}
	;

	function endResize(handler) {
		$(window).off("resize", handler);
	}
	;

	var orientationChangeHandler = function() {
		var _that = this;
		endOrientation();
		startOrientation(function() {
			setTimeout(function() {
				Utils.setBodySectionHt(true);
			}, 100);
		});
	};

	var resizeHandler = function() {
		var _that = this;
		endResize();
		startResize(function() {
			setTimeout(function() {
				if (Utils.getPrevWidth() !== window.innerWidth) { /*
																	 * To avoid
																	 * the
																	 * keyboard
																	 * opening
																	 * issue
																	 */
					Utils.setBodySectionHt(true);
				}

			}, 100);
		});
	};

	var initialiseRouter = function () {
	    Utils.setBodySectionHt(true);
		setAppVersion();
		if (Utils.isMobile()) {
			if (Utils.isWindowsPlatform()) {
				resizeHandler();
			} else {
				orientationChangeHandler();
			}
		}

		//eSigRouter = new eSigRouter();
		var _hash = window.location.hash;
		if (_hash == '#signList') {
		} else {
			window.location.hash = '';
		}

	};
	

	return {
		initialiseRouter : initialiseRouter,		
		eSigRouter : eSigRouter
	};
});