﻿define(['jquery', 'underscore', 'backbone', 'appmodules/contactprofile/app/models/cpviewmodel', 'appmodules/gpm/app/js/utils', 'text!appmodules/gpm/app/templates/gpmclientremarks.html',
], function ($, _, Backbone, CPViewModel, Utils, remarksTemplate) {
    var remarksView = Backbone.View.extend({
        el: "#gpm-form-update-field-container",
        id: 'gpm-form-update-field-container',
        events: {
            'blur #editContactRemarks': 'editableTextBox'
        },
        template: _.template(remarksTemplate),
        initialize: function (data) {
            this.data = data;
            //For Auto Link URL
            var str = "";
        },
        render: function (updateMode) {
            try {
                var self = this;
                if (!this.model.get('currentItemSet')) {
                    var CPData = CPViewModel.getInstance().getData();
                    this.data.fieldsInfo = { remarks: ((CPData.ebix && CPData.ebix.remarks) ? CPData.ebix.remarks.trim() : "") };
                    this.model.setCurrentValue(updateMode, { data: this.data });
                }
                var _dataSet = this.model.get('items');
                $("#" + this.id).html(this.template({ data: _dataSet }));
            }
            catch (error) {
                console.log(error);
            }
        },
        validateAndNavigateFromStep1: function () {
            if (this.model.validate('gpm-update-form', true)) {
                this.model.setChangedValue();
                if (this.model.getChangedItems().length > 0) {
                    $('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                } else {
                    Utils.showNoChangesMessageToUser();
                }
            }
        },
        /*editableTextBox: function () {
            var that = this;
            //Auto Link
            str = $('#editContactRemarks').html();
            str = that.autolink(str, { "target": "_blank" });
            $('#editContactRemarks').html(str);
        },
        autolink: function (str, attributes) {
            attributes = attributes || {};
            // force http: on www.
            str = str.replace("www\.", "http://www.");
            // eliminate duplicates after force
            str = str.replace("http://http://www\.", "http://www.");
            str = str.replace("https://http://www\.", "https://www.");

            var attrs = "";
            for (name in attributes)
                attrs += " " + name + '="' + attributes[name] + '"';

            var reg = new RegExp("(\\s?)((http|https|ftp)://[^\\s<]+[^\\s<\.)])", "gim");
            str = str.toString().replace(reg, '$1<a href="$2"' + attrs + '>$2</a>');

            return str;
        }*/
        editableTextBox: function () {
            var that = this;
            //Auto Link
            str = $('#editContactRemarks').html();
            str = that.autolink(str);
            $('#editContactRemarks').html(str);
        },
        autolink: function (str) {
            var url = /(http|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/gi;
            var mailto = /(mailto:[a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/gi;
            var isWWW = /(^|\A|\s)((www\.)[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,4}(\/\S*)?)/gi;

            return $('<div>').html(str).contents().each(function () {
                if (this.nodeType === 3) { // if node is a textNode
                    $(this).replaceWith(function () {
                        return this.nodeValue.replace(url, function (m) {
                            return '<a href="' + m + '" target="_blank">' + m + '</a>';
                        }).replace(mailto, function (m) {
                            return '<a href="' + m + '" target="_blank">' + m + '</a>';
                        }).replace(isWWW, function (m) {
                            return '<a href="http://' + m + '" target="_blank">' + m + '</a>';
                        });
                    })
                }
            }).end().html();
        } //autolink close

    });
    return remarksView;
});