/**
 * @ngdoc property
 * @name Sales CapitalGainsController Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires unitHolderModel
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function CapitalGainsController($scope, fticLoggerMessage, loggerConstants, $state, investorEvents,fticgAccDetLoadInitialService, myportfolioConstants, $loader, invInstantMailback, toaster, eventConstants, investorDashboardDetailsModel, $filter, investorConstants) {

    investorEvents.myPortfolio.capitalgainsfoliodetails($scope);
    fticgAccDetLoadInitialService._isInitialLoad = false;
    $scope.appName = myportfolioConstants.overview.INV_APP_NAME;
    var $translate = $filter('translate');
    //var userProfileData = investorDashboardDetailsModel.getDashboardData().profileDetails;
    $scope.navPillsOptions = [
        {
            btnName : 'Folio View',
            uibValue : 'folioview'
        },
        {
            btnName : 'Account View',
            uibValue : 'accountview'
        }
    ];
    $scope.btnColor = 'btn-group-sm green-btn-group pull-left';
    $scope.modelVal = 'folioview';
    $scope.viewFlag = $state.$current.data.viewFlag;
    $scope.$on('changeNavCgPill',function(event,modelVal){
        $scope.modelVal = modelVal;
    });
    $scope.pillSelect = function ($event,param) {
        $scope.modelVal = param;
        if(param === 'folioview'){
            fticgAccDetLoadInitialService._isInitialLoad = false;
            $scope.viewFlag = myportfolioConstants.flagOptions.FOLIO_FLAG;
            console.log('in capitalgains folioview');
            $state.go('capitalgains.folioview');
        }
        else if(param === 'accountview'){
            fticgAccDetLoadInitialService._isInitialLoad = false;
            $scope.viewFlag = myportfolioConstants.flagOptions.ACCOUNT_FLAG;
            $state.go('capitalgains.accountview');
        }
        $event.stopPropagation();
    };
    $scope.$on(eventConstants.INV_MAILBACK_CLICKED_SUC, function(event, data) {


            var params = {};
            var mailBackModel = invInstantMailback.getMailBackData();
            params.options = [myportfolioConstants.capitalGains.optionCode];
            params.formats = [data.type];
            params.flag = $scope.viewFlag;
            params.folioPanAcc = mailBackModel.folioPanAcc;
            params.dateRanges = invInstantMailback.getDateRangeForCurrentCapitalGain();
            params.emailId = '';
            $loader.start();
            invInstantMailback.postInstantMailBackDetails(params).then(function(details) {
                
                console.log(details);
                toaster.success($translate(investorConstants.myportfolio.ACC_MAILBACK_SUCC));
            }, function(error) {
                if(error && error.data && error.data.length > 0) {
                    //toaster.error(error.data[0].errorDescription);
                }
                toaster.error($translate(investorConstants.myportfolio.ACC_MAILBACK_FAIL));
            }).finally(function(){
                $loader.stop();
            });
        });
}


CapitalGainsController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'investorEvents','fticgAccDetLoadInitialService', 'myportfolioConstants', '$loader', 'invInstantMailback', 'toaster', 'eventConstants', 'investorDashboardDetailsModel', '$filter', 'investorConstants'];
module.exports = CapitalGainsController;