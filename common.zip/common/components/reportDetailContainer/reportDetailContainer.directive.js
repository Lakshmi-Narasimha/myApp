'use strict';
var reportDetailContainer = function (selectedInstantReportsModel, $filter, constants,instantReportsDetailsModel,validateUserModel,toaster) {
    return {
        template: require('./reportDetailContainer.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            report: '='
        },
        controller: ['$scope', function ($scope) {
            $scope.navPillsOptions = [];
            $scope.reportFormat = [];
            $scope.submitAll = {};
            $scope.btnColor = 'btn-group-sm green-btn-group';
            var allowSubmit = true;
            $scope.IsRecommendedTemplate = false;
            
            $scope.obj = {
                key: "value",
                text: $filter('translate')(constants.instantreports.VALUE),
                value: "",
                name: "value",
                type: "number",
                isRequired: false
            };

            //Function related to value.
            $scope.reportValueChange = function(data, id){
                console.log("Value changed - ",data);
                $scope.$emit('reportTextValueChange', data,id);
                // Value change function.
                // Validate value and assign it to value in post object.
            };
            //Getting selected reports from the "selectedInstantReportsModel" service.
            $scope.selectedReports = selectedInstantReportsModel.getSelectedInstantReps();
            for (var i = 0; i < $scope.selectedReports.length; i++) {
                $scope.submitAll[$scope.selectedReports[i].reportId] = {
                    reportPeriod: null,
                    reportType: $scope.selectedReports[i].availableFormat[$scope.selectedReports[i].availableFormat.length - 1],
                    data: null
                };
            }
            $scope.pillSelect = function (param, param1) {
                var data = {};
                for (var i = 0; i < $scope.selectedReports.length; i++) {
                    if ($scope.selectedReports[i].reportId == param1) {
                        data.reportId = param1;
                        data.pillValue = param;
                         $scope.$emit('reportPillValue', data);
                    }
                }
            }
            $scope.cmpOption = function (reportId, ranges, report) {
                $scope.cmpFilter = [];
                var cmpFilterTemp = [];
                // var rangeTypes = ranges[ranges.TemplateName][0];
                if (ranges) {
                    cmpFilterTemp = Object.keys(ranges).map(function (key, rangeValue) {
                        return {
                            index: reportId,
                            label: mapKeyToValue(key, ranges[key]),
                            type: key,
                            value: ranges[key]
                        };
                    });
                }
                if ( report.type !== 'AsOnDateFreqTemplate' && report.period !== null && report.period !== 'false') {
                    cmpFilterTemp.push({
                        index: reportId,
                        label: "Period",
                        type: report.period
                    });
                }
                $scope.cmpFilter = cmpFilterTemp;
                return $scope.cmpFilter;
            }

            function mapKeyToValue(key, value) {
                var monthRange = '';
                switch (key) {
                case "L1W":
                    return "Last 1 Week";
                case "L1M":
                    return "Last 1 Month";
                case "L3M":
                    return "Last 3 Months";
                case "L6M":
                    return "Last 6 Months";
                case "L1Y":
                    return "Last 1 Year";
                case 'Q1M':
                    monthRange = defineMonth(value);
                    return monthRange;
                case 'Q2M':
                    monthRange = defineMonth(value);
                    return monthRange;
                case 'Q3M':
                    monthRange = defineMonth(value);
                    return monthRange;
                case 'Q4M':
                    monthRange = defineMonth(value);
                    return monthRange;
                case 'Q4Y':
                    monthRange = defineMonth(value);
                    return monthRange;
                case "N1M":
                    return "Next One Month";
                case "N2M":
                    return "Next Two Months";
                case "N3M":
                    return "Next Three Months";
                default:
                    return key;
                }
            };

            function defineMonth(range){
                var fromDate = '', toDate = '';
                var monthRanges = range.split("to");
                fromDate = $filter('date')(new Date(monthRanges[0].trim()), "MMM");
                toDate = $filter('date')(new Date(monthRanges[1].trim()), "MMM yyyy");
                return fromDate + ' - ' + toDate;
            };
            $scope.pillOptions = function (accIndex, reportId, availableFormat) {
                $scope.navOption = availableFormat.map(function (value) {
                    $scope.reportFormat[accIndex] = value;
                    return {
                        report: reportId,
                        btnName: value,
                        uibValue: value
                    };
                });
                return $scope.navOption;
            }
            $scope.cmpoptions = [];
            //Listening event to update the tile data based on selection
            $scope.selectedType = [];
            $scope.selectedRange = [];
            $scope.showDateComponent = false;

            // Event related to filter component.
            $scope.$on('showFilterValue', function (event, data) {
                $scope.selectedType[data.index] = data.type;
                if ((data.label === 'Period' || getIsRecommendedTemplate(data.type)) && data.period !== 'false') {
                    $scope.showDateComponent = true;
                } else {
                    $scope.showDateComponent = false;
                      
                }
            });
            function getIsRecommendedTemplate(option){

                if(option === 'Weekly' || option === 'Monthly' || option === 'Quaterly'){
                    $scope.IsRecommendedTemplate = true;
                    return true;
                }
                $scope.IsRecommendedTemplate = false;
                return false;
            }
            
        }]
    };
};
reportDetailContainer.$inject = ['selectedInstantReportsModel', '$filter', 'constants','instantReportsDetailsModel','validateUserModel','toaster'];
module.exports = reportDetailContainer;