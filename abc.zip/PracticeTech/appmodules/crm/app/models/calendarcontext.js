define(['appcommon/commonutility', 'Base64'], function (Util, Base64) {

    CalendarContext = function () {

        // private instvars
        var currentCalendarFMID = null;
        var userList = [];
        var viewType = 'agendaWeek';
        var choosenDate = new Date();

        // public methods
        this.getCalenderFMID = function () {
            if (currentCalendarFMID) {
                return currentCalendarFMID;
            } else {
                return Util.userFMID();
            }
        }

        this.saveLastCalendarFMID = function (fmid) {
            currentCalendarFMID = fmid;
        }

        this.setUserList = function(users) {
            userList = users;
            var signedUserFMID = Util.userFMID();
            // safety....if signed on user is missing from the list add a user to represent him/her
            var signedUser = _.find(users, function(user) { return user.fmid == signedUserFMID; })
            if (!signedUser) {
                userList.push({
                    fmid: signedUserFMID,
                    name: "SignedOn User",
                    firstName: "SignedOn",
                    lastName: "User"
                });
            }
            // validate that the "current" user is still valid
            if (currentCalendarFMID) {
                if (!(_.contains(_.pluck(self.calendarUsers, 'fmid'), contextFMID))) {
                    CalendarContext.saveLastCalendarFMID(signedUserFMID);
                }
            }
        }

        this.isCalendarSignedOnUser = function() {
            return this.getCalenderFMID() == Util.userFMID();
        }

        this.getUserList = function() {
            return userList;
        }

        /* Set View Type */
        this.setViewType = function (viewTyp) {
            viewType = viewTyp;
        }

        this.getViewType = function () {
            return viewType;
        }

        /* Set Choosen Date */
        this.setChoosenDate = function (choosenDt) {
            choosenDate = choosenDt;
        }

        this.getChoosenDate = function () {
            return choosenDate;
        }

    }

    return new CalendarContext();

});