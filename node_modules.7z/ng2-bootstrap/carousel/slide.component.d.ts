/***
 * todo:
 * direction (?string) (not yet supported)
 actual (not yet supported) (?any) - will be bind to slider context, to be used from template
 */
import { OnDestroy, OnInit } from '@angular/core';
import { CarouselComponent, Direction } from './carousel.component';
/** Wrap your content with `slide` component  */
export declare class SlideComponent implements OnInit, OnDestroy {
    /** index of slide in carousel's slides */
    index: number;
    direction: Direction;
    /** does current slide is active */
    active: boolean;
    addClass: boolean;
    protected carousel: CarouselComponent;
    constructor(carousel: CarouselComponent);
    ngOnInit(): void;
    ngOnDestroy(): void;
}
