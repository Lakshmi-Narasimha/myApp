// ftMenu.model.js
// grab the mongoose module
// define our ftMenu.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FTMenuSchema = new mongoose.Schema({
    ftMenuObject: {
        type: Object,
        "default": {}
    }
});

var FTMenuLookUp = mongoose.model('FTMenuLookup', FTMenuSchema);

var FTMenuModel = new FTMenuLookUp({

  "ftMenuObject": {
  "framework": {
    "header": {
      "utility-links": {
        "dropdown": [
          {
            "type": [
              "menu",
              "marketing"
            ],
            "url": "#",
            "text": "About Us",
            "link": [
              {
                "url": "\/investor\/about-us#tab_tab0",
                "text": "Franklin Templeton Investments",
                "type": "marketing"
              },
              {
                "url": "\/investor\/about-us#tab_tab1",
                "text": "Franklin Templeton India",
                "type": "marketing"
              },
              {
                "url": "\/investor\/about-us#tab_tab2",
                "text": "Global Office",
                "type": "marketing"
              },
              {
                "url": "\/investor\/about-us#tab_tab3",
                "text": "CSR Initiatives India",
                "type": "marketing"
              }
            ]
          },
          {
            "type": [
              "menu",
              "marketing"
            ],
            "url": "\/investor\/resources",
            "text": "Resources",
            "link": [
              {
                "url": "\/investor\/resources",
                "text": "Fund Documents",
                "type": "marketing"
              },
              {
                "url": "\/investor\/resources",
                "text": "Fund Literature",
                "type": "marketing"
              },
              {
                "url": "\/investor\/resources",
                "text": "Forms & Instructions",
                "type": "marketing"
              },
              {
                "url": "\/investor\/resources",
                "text": "Updates",
                "type": "marketing"
              }
            ]
          },
          {
            "type": [
              "link",
              "marketing"
            ],
            "url": "\/investor\/feedback",
            "text": "Feedback"
          },
          {
            "type": "country",
            "country-image-alt-text": "India, click to change location",
            "country-name": "India",
            "choose-country-label": "CHOOSE COUNTRY",
            "choose-country-link": "http:\/\/www.franklinresources.com\/corp\/home"
          }
        ]
      },
      "header-common": {
        "logo": {
          "img": "\/assets\/images\/fti_logo.png",
          "url": "\/investor\/"
        },
        "search": {
          "enabled": "on",
          "placeholder": "Search"
        }
      },
      "nav-bar": {
        "nav-links": {
          "first-level-link": [
            {
              "text": "Funds & Solutions",
              "second-level-link": {
                "nav-link": [
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Family Solutions",
                      "type": "guest"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Child",
                          "target": "",
                          "text": "Child's Education",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Retire",
                          "target": "",
                          "text": "Retirement",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Holiday",
                          "target": "",
                          "text": "Holiday",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Cash",
                          "target": "",
                          "text": "Cash Management",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Dream",
                          "target": "",
                          "text": "Dream Home",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Wealth",
                          "target": "",
                          "text": "Wealth Creation",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Tax",
                          "target": "",
                          "text": "Tax Planning",
                          "type": "guest"
                        },
                        {
                          "url": "\/smartsolutions\/planSmartSolution\/Customized",
                          "target": "",
                          "text": "Customized Plan",
                          "type": "guest"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Funds Explorer",
                      "type": "marketing"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/funds-and-solutions\/funds-explorer\/funds-explorer",
                          "target": "",
                          "text": "All Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/funds-and-solutions\/funds-explorer\/funds-explorer#secondFilter-2",
                          "target": "",
                          "text": "Equity Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/funds-and-solutions\/funds-explorer\/funds-explorer#secondFilter-1",
                          "target": "",
                          "text": "Fixed Income Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/funds-and-solutions\/funds-explorer\/funds-explorer",
                          "target": "",
                          "text": "Liquid Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/funds-and-solutions\/funds-explorer\/funds-explorer",
                          "target": "",
                          "text": "Hybrid Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/internationalfunds",
                          "target": "",
                          "text": "International Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/elss",
                          "target": "",
                          "text": "ELSS",
                          "type": "marketing"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "NAVs and Dividends",
                      "type": "marketing"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/funds-and-solutions\/navs-and-dividends\/navs-dividends",
                          "target": "",
                          "text": "Latest NAVs & Dividends",
                          "type": "marketing"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Tools",
                      "type": "marketing"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/funds-and-solutions\/tools\/funds-watchlist",
                          "target": "",
                          "text": "Watchlist",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/funds-and-solutions\/tools\/funds-comparator",
                          "target": "",
                          "text": "Fund Comparator",
                          "type": "marketing"
                        },
                        {
                          "url": "\/sipcalculators",
                          "target": "",
                          "text": "SIP Calculator",
                          "type": "guest"
                        },
                        {
                          "url": "\/lumpsumcalculators",
                          "target": "",
                          "text": "Lumpsum Calculator",
                          "type": "guest"
                        },
                        {
                          "url": "\/comparissioncalculators\/sip",
                          "target": "",
                          "text": "SIP vs Lumpsum Calculator",
                          "type": "guest"
                        },
                        {
                          "url": "\/taxadvantagecalculators",
                          "target": "",
                          "text": "Tax Advantage Calculator",
                          "type": "guest"
                        },
                        {
                          "url": "\/commissioncalculators\/sip",
                          "target": "",
                          "text": "Brokerage Calculator",
                          "type": "guest"
                        }
                      ]
                    }
                  }
                ]
              }
            },
            {
              "text": "Investor Education",
              "second-level-link": {
                "nav-link": [
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": ""
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/investor-education\/new-to-investing",
                          "target": "",
                          "text": "New to Investing",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/new-to-mutual-funds",
                          "target": "",
                          "text": "New to Mutual Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/more-about-mutual-funds",
                          "target": "",
                          "text": "More about Mutual Funds",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/women-and-investing",
                          "target": "",
                          "text": "Women and Investing",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/planning-for-retirement",
                          "target": "",
                          "text": "Planning for Retirement",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/your-childs-future",
                          "target": "",
                          "text": "Your Child?s Future",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/smart-tax-planning",
                          "target": "",
                          "text": "Smart Tax Planning",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/investor-education\/playandlearn",
                          "target": "",
                          "text": "Play & Learn",
                          "type": "marketing"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": ""
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/investor-education\/investment-glossary",
                          "target": "",
                          "text": "Investment Glossary",
                          "type": "marketing"
                        }
                      ]
                    }
                  }
                ]
              }
            },
            {
              "text": "Distributor Zone",
              "second-level-link": {
                "nav-link": [
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Distributor Services",
                      "type": "marketing"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/distributor-zone\/distributor-services\/why-ft",
                          "target": "",
                          "text": "Why Franklin Templeton?",
                          "type": "marketing"
                        },
                        {
                          "url": "\/distributorServices\/usertype",
                          "target": "",
                          "text": "Become an Adviser\/Empanel with us",
                          "type": "guest"
                        },
                        {
                          "url": "\/loginmaster\/register",
                          "target": "",
                          "text": "Register for Online access",
                          "type": "guest"
                        },
                        {
                          "url": "\/investor\/resources#firstFilter-3&secondFilter-2",
                          "target": "",
                          "text": "Forms for Distributor",
                          "type": "marketing"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Mail back Services",
                      "type": "guest"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/mailbackservices\/instantreports",
                          "target": "",
                          "text": "Instant Reports",
                          "type": "guest"
                        },
                        {
                          "url": "\/mailbackservices\/accountStatement",
                          "target": "",
                          "text": "Account Statements",
                          "type": "guest"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Adviser Education",
                      "type": "adviser"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/distributor-zone\/adviser-education\/investment-concepts",
                          "target": "",
                          "text": "Investment Concepts",
                          "type": "adviser"
                        },
                        {
                          "url": "\/investor\/distributor-zone\/adviser-education\/client-management",
                          "target": "",
                          "text": "Client Management",
                          "type": "adviser"
                        },
                        {
                          "url": "\/investor\/distributor-zone\/adviser-education\/professional-development",
                          "target": "",
                          "text": "Professional Development",
                          "type": "adviser"
                        }
                      ]
                    }
                  }
                ]
              }
            },
            {
              "text": "Market Insights",
              "second-level-link": {
                "nav-link": [
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": ""
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/market-insights\/market-outlook",
                          "target": "",
                          "text": "Latest Commentaries",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/market-insights\/blogs",
                          "target": "",
                          "text": "Blogs",
                          "type": "marketing"
                        }
                      ]
                    }
                  }
                ]
              }
            },
            {
              "text": "Customer Services",
              "second-level-link": {
                "nav-link": [
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Instant Services",
                      "type": "guest"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/customerservices\/instantservices\/instantmailback",
                          "target": "",
                          "text": "Instant Mailback",
                          "type": "guest"
                        },
                        {
                          "url": "\/customerservices\/instantservices\/consolidatedaccstatement",
                          "target": "",
                          "text": "Consolidated Account Statement",
                          "type": "guest"
                        },
                        {
                          "url": "\/customerservices\/instantservices\/certifyfatca\/step1",
                          "target": "",
                          "text": "Certify FATCA\/Update KYC Details",
                          "type": "guest"
                        },
                        {
                          "url": "\/customerservices\/instantservices\/historicnav",
                          "target": "",
                          "text": "Request for Historic NAVs",
                          "type": "guest"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Account Subscriptions",
                      "type": "guest"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/customerservices\/accountsubscriptions\/valuationaccstatement",
                          "target": "",
                          "text": "Valuation\/Account Statement",
                          "type": "guest"
                        },
                        {
                          "url": "\/customerservices\/accountsubscriptions\/smsnavs\/smsnavalerts",
                          "target": "",
                          "text": "SMS NAVs",
                          "type": "guest"
                        },
                        {
                          "url": "\/customerservices\/accountsubscriptions\/easyservices\/step1",
                          "target": "",
                          "text": "Easy Services",
                          "type": "guest"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Account Services",
                      "type": "marketing"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/customer-services\/account-services\/way-to-transact-with-us",
                          "target": "",
                          "text": "Ways to Transact with Us",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/customer-services\/account-services\/sms-services",
                          "target": "",
                          "text": "SMS Services",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/customer-services\/account-services\/online-services",
                          "target": "",
                          "text": "Online Services",
                          "type": "marketing"
                        },
                        {
                          "url": "\/customerservices\/accountservices\/unclaimedinvestments\/userdetails",
                          "target": "",
                          "text": "Unclaimed Investments",
                          "type": "guest"
                        },
                        {
                          "url": "\/investor\/resources#firstFilter-3&secondFilter-9",
                          "target": "",
                          "text": "Transmission Policy",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/resources#firstFilter-3",
                          "target": "",
                          "text": "Forms",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/help#heading8",
                          "target": "",
                          "text": "FAQs",
                          "type": "marketing"
                        }
                      ]
                    }
                  },
                  {
                    "type": "links",
                    "link": {
                      "url": "",
                      "target": "",
                      "text": "Find Franklin Templeton",
                      "type": "marketing"
                    },
                    "third-level-link": {
                      "link": [
                        {
                          "url": "\/investor\/customer-services\/find-franklin-templeton\/locate-us",
                          "target": "",
                          "text": "Locate Us",
                          "type": "marketing"
                        },
                        {
                          "url": "\/investor\/customer-services\/find-franklin-templeton\/grievance-redressal",
                          "target": "",
                          "text": "Grievance Redressal",
                          "type": "marketing"
                        },
                        {
                          "url": "#requestcallback",
                          "target": "",
                          "text": "Request Callback",
                          "type": "marketing"
                        },
                        {
                          "url": "#ftiChat_chatwindow",
                          "target": "",
                          "text": "Start a Chat",
                          "type": "marketing"
                        },
                        {
                          "url": "#speaktous",
                          "target": "",
                          "text": "Speak to Us",
                          "type": "marketing"
                        },
                        {
                          "url": "#advisor",
                          "target": "",
                          "text": "Ask for an Advisor",
                          "type": "marketing"
                        }
                      ]
                    }
                  }
                ]
              }
            }
          ]
        },
        "login": {
          "signin-label": "Login \/ Registration",
          "signin-form-header": "Investor \/ Distributor Login",
          "username-placeholder": "Username",
          "password-placeholder": "Password",
          "remember-me-label": "Remember me",
          "login-label": "Login",
          "register-now-label": "Register Now",
          "forgot-username-label": "Forgot Username",
          "forgot-username-url": "#",
          "or-seperator": "OR",
          "forgot-password-label": "Password",
          "forgot-password-url": "#"
        }
      },
      "header-mobile-logo": {
        "url": "\/investor\/",
        "img": "\/assets\/images\/fti_logo_white.png"
      }
    },
    "footer": {
      "footer-links": {
        "link": [
          {
            "url": "http:\/\/www.franklintempletoncareers.com\/?title=careers",
            "name": "Careers",
            "target": "_blank",
            "type": "marketing"
          },
          {
            "url": "\/investor\/media",
            "name": "Media",
            "type": "marketing"
          },
          {
            "url": "\/investor\/reports",
            "name": "Reports",
            "type": "marketing"
          },
          {
            "url": "\/investor\/risk-factors",
            "name": "Risk Factors",
            "type": "marketing"
          },
          {
            "url": "\/investor\/terms-and-conditions",
            "name": "Terms & Conditions",
            "type": "marketing"
          },
          {
            "url": "\/investor\/disclaimer",
            "name": "Disclaimer",
            "type": "marketing"
          },
          {
            "url": "\/investor\/security-and-privacy",
            "name": "Security & Privacy",
            "type": "marketing"
          },
          {
            "url": "\/investor\/help",
            "name": "Help",
            "type": "marketing"
          },
          {
            "url": "\/investor\/anti-corruption-policy",
            "name": "Anti-Corruption Policy",
            "type": "marketing"
          },
          {
            "url": "http:\/\/www.franklintempletonindia.com\/downloadsServlet?docid=h9fyrj6r",
            "name": "Voting Policy",
            "target": "_blank",
            "type": "marketing"
          },
          {
            "url": "http:\/\/www.franklintempletonindia.com\/downloadsServlet?docid=ic0c1p3l",
            "name": "Disclosure of Voting",
            "type": "marketing"
          }
        ]
      },
      "socialmedia": "<a href=\"#\"><span class=\"icon circle icon-fti_facebook\"><\/span><\/a>\n<a href=\"#\"><span class=\"icon circle icon-fti_twitter\"><\/span><\/a>\n<a href=\"#\"><span class=\"icon circle icon-fti_youtubeLogo\"><\/span><\/a>\n<a href=\"#\"><span class=\"icon circle icon-fti_linkedin\"><\/span><\/a>",
      "footer-logo": "\/assets\/images\/fti_footer_logo.jpg",
      "copyright-info": {
        "copyright-label": "Copyright &copy;",
        "from-year": "1999",
        "year-seperator": "-",
        "to-year": "2016",
        "home-page": {
          "url": "\/investor\/",
          "link-text": "Franklin Templeton Investments",
          "type": "marketing"
        },
        "copyright-text": "All Rights Reserved."
      }
    }
  }
}


});

FTMenuLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FTMenuLookUp table, please contact admin...');
    } else {
        FTMenuLookUp.remove({}, function(err) {
            console.log('FTMenuLookUp collection removed');
            FTMenuModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FTMenuLookUp table, please contact admin...');
                }
                console.log('FTMenuLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FTMenuLookUp;