/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function invVideoModalController($scope, $uibModalStack) {
    
    $scope.closeModal = function() {

        $uibModalStack.dismissAll();
    };
}


invVideoModalController.$inject = ['$scope', '$uibModalStack'];

module.exports = invVideoModalController;