/**
 * @ngdoc filter
 * @name fticNACheckFilter
 * @description
 *
 * - This common filter is used to display NA  instead of null/space/empty.
 *
 */

'use strict';

var fticKycStatus = function(kycRegisterStatusModel) {
    return function(flag) {
        if(flag === true) {
            return 'KYC Registered';
        } else if(flag === false) {
            return 'KYC Not registered';
        } else {
            return '';
        }
    };
};

fticKycStatus.$inject = ['kycRegisterStatusModel'];
module.exports = fticKycStatus;
