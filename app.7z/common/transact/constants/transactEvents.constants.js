'use strict';

var transactEventConstants = (function() {
    return {
        transact : {
            TRSCT_RED_SF : 'sfDtls',
            REDEEM_DETAILS: 'publishRedemptionDetails',
            SWP_DETAILS:'publishSwpDetails',
            NEW_FUND_DETAILS : 'newFundDetails',
            FUND_DETAILS: 'publishFundDetails',
            REDEMPTION_DETAILS : 'publishRedeemDetails',
            BUYSELECTEDINVESTOR_DETAILS : 'publishBuySIDetails',
            REGISTERED_BANK : 'publishRegisteredBank',
            AMOUNT_VALUE: 'publishAmountDetails',
            UNITS_VALUE: 'publishUnitsDetails',
            IFSC_DETAILS : 'ifsc',
            IFSC_GRID_DETAILS : 'ifscgrid',
            Select_Investor : 'selectInvestorDetails',
            New_Folio:'NewFolioDtlsResp',
            Check_Kyc:'CheckKycResp',
            Folio_Validation:'FolioValidationResp',
            Investor_Details : "getInvestorDetails",
            Selected_Investor:"getInvestorDataBroad",
            Open_Grid : "openFundDetailGrid",
            Show_Fund : "getData",
            Show_Fund_Tile : "getDataBroad",
            Fund_Edit_Clicked : "selectFundIconClicked",
            Nominee_Edit_Clicked : "NomineeIconClicked",
            Inv_Edit_Clicked : "selectInvestorIconClicked",
            Edit_Fund_Button_Clicked : "isEditFundButtonClicked",
            Edit_Button_Clicked : "isEditButtonClicked",
            Trans_Select_Option_Changed : "isOptionChanged",
            MOD_SIP_AMT_CHNG : "sipamtchange",
            FREQUENCY_OPTIONS : 'frequencyOptions',
            RESET_FUND : 'Reset Fund',
            RESET_REDEEM_FORM : 'Reset Redeem Form',
            RESET_SWP_FORM : 'Reset Swp Form',
            RESET_STP_FORM:'Reset stp form',
            REDEEM_FORM_RESET : 'Redeem Form Reset',
            SWP_FORM_RESET : 'Swp Form Reset',
            FREQUENCY_FORM_RESET : 'Frequency Form Reset',
            KYC_NOT_REG_FLOW:'kyc not registered flow',
            EDIT_FUND : 'Edit Fund',
            EDIT_STEP_UP_SIP : 'Edit Step up SIP',
            EUIN_DTLS : "Euin details",
            FUND_UPDATED : 'Fund Updated',
            FUND_CHANGED : 'Fund Changed',
            TRANS_SELECT_FUND : "selectFund",
            TRANS_SELECT_INVESTOR : "selectInvestor",
            INSTANT_KYC:"instantKycDetails",
            Intl_Modify_Ctrl: "intlModifyCtrl",
            Pay_Detail_Show: "payDetShow",
            Set_Key_Value_Object: "setKeyValueObject",
            Set_Key_Value_Transact: "setKeyValueTransact",
            Set_Modify_Sip_Details: "setModifySipDetails",
            Payment_Detail: "payDet",
            MODE_OF_KYC_SELECTED : 'Physical KYC Selected',
            PAPERLESS_NOMINEE_CONTINUE: 'paperlessNomineeContinue',
            SHOW_PAPERLESS_BTNS : 'SHOW_PAPERLESS_BTNS',
            HIDE_PAPERLESS_BTNS : 'HIDE_PAPERLESS_BTNS',
            FATCA_DETAILS : 'FATCA_DATA',
            guest : {
                  SIP_CONTINUE_ACTIVATED : 'SIP continue activated',
                  PAPERLESS_REVIEW_EDIT_TRIGGERED : 'PAPERLESS_REVIEW_EDIT_TRIGGERED',
                  invPref : {
                        ADVISOR_NAME_CHANGED : 'Advisor Name Changed',
                        NEW_ADVISOR_SELECTED : 'New Advisor Selected'
                  }
            },
            AMOUNT_SELECTED : 'amountselectedforfreq',         
            Go_To_Payment_Dtls : 'Go_To_Payment_Dtls',
            EMANDATE_CHANGED : 'existMandateChanged',
            NETBANK_CHANGED : 'netBankChanged',
            DEBITBANK_CHANGED : 'debitBankChanged',
            NEWMANDATE_CHANGED : 'newMandateChanged',
            NEFTBANK_CHANGED : 'neftBankChanged',
            INV_FUND_DETAILS : 'invfunddetails',
            IFSC_SEARCH_FAIL : 'Ifsc Search Failed',
            RESET_SWITCH_FORM : 'Reset_Switch_Form',
            SWITCH_FORM_RESET: 'Switch_Form_Reset',
            //Investor-Flow
            INV_FOLIO_SELECTED_CON: 'Inv_Folio_Selected',
            INV_TRANSACT_CSTP_REVIEW: 'Review&ConfirmSelected',              
            KYC_ADTNL_DETAILS: 'KYC_ADTNL_DETAILS',
            KYC_ADTNL_DETAILS_SET : 'KYC Additional Details Setted'
        }
    }        
 
}());

transactEventConstants.$inject = [];
module.exports = transactEventConstants;