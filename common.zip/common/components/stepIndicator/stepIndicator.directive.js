/**
 * @ngdoc directive
 * @name stepIndicator
 * @description
 *
 * - stepIndicator component will display the no of steps.
 * 
 *
 **/
 'use strict';

var stepIndicator = function() {

	return {
            template: require('./stepIndicator.html'),
            restrict: 'E',
            replace: true,
            scope: {  
                noOfSteps: "=",
                activeStep: "=",
                stepTextObj:'=?',
                stepClass:'@?',
                imgObj: '='
            },
            controller:['$scope', function($scope){
                $scope.noOfStepsArray = [];
                for(var i=1;i<=$scope.noOfSteps;i++){
                    $scope.noOfStepsArray.push(i);
                }
            }]
        };
};

stepIndicator.$inject = [];
module.exports = stepIndicator;