module.exports = function($q, $http) {
    this.liveChat = function(queryData) {
        var deferred = $q.defer();
        var config;
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/livechat',
            data: queryData,
        };

        $http(config)
            .success(function(data, status, headers, config) {
                deferred.resolve(data);
            })
            .error(function(data) {
                deferred.reject(data);
            });

        return deferred.promise;
    };

    this.endChat = function(queryData) {
        var deferred = $q.defer();
        var config;
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/endchat',
            data: queryData,
        };

        $http(config)
            .success(function(data, status, headers, config) {
                deferred.resolve(data);
            })
            .error(function(data) {
                deferred.reject(data);
            });

        return deferred.promise;
    };
};
