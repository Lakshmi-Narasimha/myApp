
/**
* @ngdoc property
* @name fticModifySipForm Directive
* @requires advisorConstants
* @description
*
* - Form concludes radio button with specific panel and validations
*
**/
'use strict';

var fticModifySipForm = function (TransactConstant,$filter,SipModifyDetailModel,transactModel,transactEventConstants,ftiModifySipInitialLoader,fundDetails) {
    return {
        template: require('./modifySipForm.html'),
        restrict: 'E',
        scope: {},
        controller:['$scope', function ($scope) { 
            $scope.showStepCancel = false;
            var datefilter = $filter('date');
            $scope.radios = {};
            $scope.radios.selectedVal = "";
            var keyValueList = [];
            $scope.sipActionsObj = [
                {
                    title:$filter('translate')(TransactConstant.modifySip.Step_Up_Sip),
                    value:"Step_Up_Sip",
                    description:$filter('translate')(TransactConstant.modifySip.Step_Up_Sip_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Step_Up_Trans_Heading)
                },
                {
                    title:$filter('translate')(TransactConstant.modifySip.Sip_Date_Change),
                    value:"Sip_Date_Change",
                    description:$filter('translate')(TransactConstant.modifySip.Sip_Date_Change_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Sip_DateChnge_Trans_Heading)
                },
                {
                    title:$filter('translate')(TransactConstant.modifySip.Flexi_Sip),
                    value:"Flexi_Sip",
                    description:$filter('translate')(TransactConstant.modifySip.Flexi_Sip_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Flexi_Sip_Trans_Heading)
                },
                {
                    title:$filter('translate')(TransactConstant.modifySip.Sip_Amt_Change),
                    value:"Sip_Amt_Change",
                    description:$filter('translate')(TransactConstant.modifySip.Sip_Amt_Change_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Sip_AmtChnge_Trans_Heading)
                },
                {
                    title:$filter('translate')(TransactConstant.modifySip.Sip_Pause),
                    value:"Sip_Pause",
                    description:$filter('translate')(TransactConstant.modifySip.Sip_Pause_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Sip_Pause_Trans_Heading)
                },
                {
                    title:$filter('translate')(TransactConstant.modifySip.Sip_Cancel),
                    value:"Sip_Cancel",
                    description:$filter('translate')(TransactConstant.modifySip.Sip_Cancel_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Sip_Cancel_Trans_Heading)
                },
                {
                    title:$filter('translate')(TransactConstant.modifySip.Step_Up_Cancel),
                    value:"Step_Up_Cancel",
                    description:$filter('translate')(TransactConstant.modifySip.Step_Up_Cancel_desc),
                    selected:false,
                    transactionHeading: $filter('translate')(TransactConstant.modifySip.Sip_StepCancel_Trans_Heading)
                },
            ];

            $scope.$on(transactEventConstants.transact.Intl_Modify_Ctrl,function(event,data){
                var stepUpType = transactModel.getFundDetails().isStepUpActive;
                
                if(stepUpType === "N" || stepUpType === ""){
                    $scope.showStepCancel = true;
                }else{
                    $scope.showStepCancel = false;
                }
                angular.forEach($scope.sipActionsObj,function(value,key){
                    $scope.sipActionsObj[key].selected = false;
                })
                $scope.radios.selectedVal = "";

                //setting all date fields in format
                var dateSplit = [];
                dateSplit= transactModel.getFundDetails().sipStartDate.split("/");
                transactModel.getFundDetails().sipStartDate = new Date(dateSplit[2],dateSplit[1]-1,dateSplit[0]);
                dateSplit= transactModel.getFundDetails().sipEndDate.split("/");
                transactModel.getFundDetails().sipEndDate = new Date(dateSplit[2],dateSplit[1]-1,dateSplit[0]);
                dateSplit= transactModel.getFundDetails().nextTriggerDate.split("/");
                transactModel.getFundDetails().nextTriggerDate = new Date(dateSplit[2],dateSplit[1]-1,dateSplit[0]);
                dateSplit= transactModel.getFundDetails().sipAnnualCycle.split("/");
                transactModel.getFundDetails().sipAnnualCycle = new Date(dateSplit[2],dateSplit[1]-1,dateSplit[0]);

                // setting values for validate sip post call
                var fundDetailsObj = {};
                fundDetailsObj.fundOption = transactModel.getFundDetails().fundOption;
                fundDetailsObj.perpetualFlag = transactModel.getFundDetails().perpetualFlag;
                fundDetailsObj.dividendFlag = transactModel.getFundDetails().dividendFlag;
                fundDetailsObj.frequency = transactModel.getFundDetails().frequency;
                fundDetailsObj.amount = transactModel.getFundDetails().amount;
                fundDetailsObj.accNo = transactModel.getFundDetails().accountNumber;
                fundDetailsObj.startDate = datefilter(transactModel.getFundDetails().nextTriggerDate, 'dd/MM/yyyy');
                fundDetailsObj.endDate = datefilter(transactModel.getFundDetails().sipEndDate, 'dd/MM/yyyy');
                fundDetailsObj.stepUpSip = "NA";
                fundDetailsObj.stepUpType = "";
                fundDetailsObj.stepUpValue = "";
                fundDetails.setFundDetails(fundDetailsObj);
            })
           
            $scope.listenChange = function(sipObject){
                if (sipObject.value === "Step_Up_Sip" || sipObject.value === "Sip_Date_Change" || sipObject.value === "Flexi_Sip" || sipObject.value === "Sip_Amt_Change"){
                    $scope.$emit(transactEventConstants.transact.Pay_Detail_Show);
                }
                angular.forEach($scope.sipActionsObj,function(value,key){
                    $scope.sipActionsObj[key].selected = false;
                })
                if(sipObject.value !== "Step_Up_Sip"){
                    // setting step up values for validate sip
                        var fundDetailsObj = fundDetails.getFundDetails();
                        fundDetailsObj[0].stepUpSip = "NA";
                        fundDetailsObj[0].stepUpType = "";
                        fundDetailsObj[0].stepUpValue = "";
                }
                 sipObject.selected = true; 
                 transactModel.setSipTransactionHeading(sipObject.transactionHeading);
            }

            $scope.$on(transactEventConstants.transact.Set_Key_Value_Object,function(event,data){
                var modifySipData = SipModifyDetailModel.getModifySipDetails();
                if(modifySipData.sipModifyType === "Flexi_Sip"){
                    keyValueList = [
                            {key:$filter('translate')(TransactConstant.modifySip.SIP_Modification),value:modifySipData.sipOptionName},
                            {key:$filter('translate')(TransactConstant.modifySip.New_SIP_Amount),value:"<i class='icon-fti_rupee'></i>" + modifySipData.newSipAmount}
                        ];
                    
                }
                else if(modifySipData.sipModifyType === "Step_Up_Sip"){
                    keyValueList = [
                            {key:$filter('translate')(TransactConstant.modifySip.SIP_Modification),value:modifySipData.sipOptionName},
                            {key:$filter('translate')(TransactConstant.modifySip.Effect_Month),value:modifySipData.efctvMnth},
                            {key:$filter('translate')(TransactConstant.modifySip.Step_Up_perc),value:modifySipData.stepUpVal}
                        ];
                }
                else if(modifySipData.sipModifyType === "Sip_Amt_Change"){
                    keyValueList = [
                            {key:$filter('translate')(TransactConstant.modifySip.SIP_Modification),value:modifySipData.sipOptionName},
                            {key:$filter('translate')(TransactConstant.modifySip.New_SIP_Amount),value:"<i class='icon-fti_rupee'></i>" + modifySipData.newSipAmount}
                        ];
                }
                else if(modifySipData.sipModifyType === "Sip_Date_Change"){
                    keyValueList = [
                            {key:$filter('translate')(TransactConstant.modifySip.SIP_Modification),value:modifySipData.sipOptionName},
                            {key:$filter('translate')(TransactConstant.modifySip.New_SIP_Date),value:modifySipData.strtDate}
                        ];
                }
                 
                $scope.$emit(transactEventConstants.transact.Set_Key_Value_Transact,keyValueList);
            });

           /* $scope.$on($scope.eventName,function(event,data){
                keyValueList = [];
            })*/
                
            $scope.getSelections = function(sipObject){
                console.log("getSelections");
            }
           
        }]
    };
};

fticModifySipForm.$inject = ['TransactConstant','$filter','SipModifyDetailModel','transactModel','transactEventConstants','ftiModifySipInitialLoader','fundDetails'];
module.exports = fticModifySipForm;