var express = require('express');
var https = require('https');
var config = require('../../../config/config');

var router = express.Router();
var getMessageModel = require('./getMessage.model');
//var engagementModel = require('../engagement/engagement.model');
//var sendMessageModel = require('../sendMessage/sendMessage.model');
var apiUtils = require('../../common/apiUtils');

// api route
/* Trigerring the Get Message API on request from Client */
router.route('/mfchat/rest/message/:engagementID')
    .post(function(req, res) {
        console.log("Get Message API is trigerred");
        apiUtils.formattedGetMsg(req, res, function(response){
            res.send(response);
        });
    });
module.exports = router;
