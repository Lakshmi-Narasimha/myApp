'use strict';
describe('Directive: fticPendingFamilyPortfolio', function() {
	var compile,scope,directiveElement,isolatedScope,$window,familyPortfolioInitialLoader,familyPortfolioModel,httpBackend,iScope;

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.myportfolio'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-pending-family-portfolio></ftic-pending-family-portfolio>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope, _$compile_,$window,familyPortfolioModel,_familyPortfolioInitialLoader_,_$httpBackend_) {            
            compile = _$compile_;
            scope = $rootScope.$new();            
            $window = $window;
            $window.ga = function() {};
            familyPortfolioModel = familyPortfolioModel;
            familyPortfolioInitialLoader = _familyPortfolioInitialLoader_;
            httpBackend = _$httpBackend_;

            scope.pending = {"custName":"Priya Venkatesh","refId":"345"};
            scope.userName = [{"value":"Hari","errorMessage":"The entered Username is incorrect, Please try again."}];
            directiveElement = getCompiledElement();
            isolatedScope = directiveElement.isolateScope();
            iScope = directiveElement.scope();
        });
    });

    it('should be defined', function() {    	
        expect(directiveElement).toBeDefined();        
    });

    it('should use the parent scope', function() {
        expect(isolatedScope).not.toBeDefined();
        expect(scope.pending.custName).toEqual("Priya Venkatesh");
    });

    it("should trigger onSubmit on click of submit button and received success response from the service",function(){    	    	
    	httpBackend.expectGET('http://localhost:3030/profile/accessFamilyPortfolio?guId=878&pan=ABAPL1235D&status=AP&userId=Hari').respond(200,"success");
    	iScope.onSubmit(0,"ABAPL1235D");
    	expect(familyPortfolioInitialLoader._isServicesData).toBeFalsy();
    	httpBackend.expectGET('http://localhost:3030/profile/familyPortfolio?guId=878').respond(200);    	    	
 		httpBackend.flush();
    });

    it("should trigger onSubmit on click of submit button and received error response from the service",function(){    	    	
    	httpBackend.expectGET('http://localhost:3030/profile/accessFamilyPortfolio?guId=878&pan=ABAPL1235D&status=AP&userId=Hari').respond(400,"error");
    	iScope.onSubmit(0,"ABAPL1235D");
		expect(scope.userName[0].errorMessage).toBe("The entered Username is incorrect, Please try again.");    	
		httpBackend.flush();
    });

    it("should trigger onReject on click of reject button and received success response from the service",function(){
    	httpBackend.expectGET('http://localhost:3030/profile/accessFamilyPortfolio?guId=878&pan=ABAPL1235D&status=AP&userId=Hari').respond(200,"success");
    	iScope.onSubmit(0,"ABAPL1235D");
    	expect(familyPortfolioInitialLoader._isServicesData).toBeFalsy();
    	httpBackend.expectGET('http://localhost:3030/profile/familyPortfolio?guId=878').respond(200);    	    	
 		httpBackend.flush();
    });    

    it('should trigger onReject on click of reject button and received error response from the service', function() {
    	httpBackend.expectGET('http://localhost:3030/profile/accessFamilyPortfolio?guId=878&pan=ABAPL1235D&status=AP&userId=Hari').respond(400,"error");
    	iScope.onSubmit(0,"ABAPL1235D");
		expect(scope.userName[0].errorMessage).toBe("The entered Username is incorrect, Please try again.");    		
		httpBackend.flush();
    });
});