// getSwitchSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SwitchSummaryModelSchema = new mongoose.Schema({
    switchSummaryResp: {
        type: Array,
        "default": []
    }
});

var SwitchSummaryModelLookUp = mongoose.model('SwitchSummaryModelLookUp', SwitchSummaryModelSchema);

var SwitchSummaryModel = new SwitchSummaryModelLookUp({
    switchSummaryResp : {
    	"switch": {
			"fundWiseData": [
				{
					"folioNo": "2341621",
					"sourceFund": "Frnklin India equity fund-growth",
					"destinationFund": "Frnklin India Prima Plus",
					"familySolutions": "yes",
					"switchAmount": "12,345"
				}, 
				{
					"folioNo": "3456432",
					"sourceFund": "Frnklin India equity fund-growth",
					"destinationFund": "Frnklin India equity fund-growth",
					"familySolutions": "no",
					"switchAmount": "11,678"
				}, 
				{
					"folioNo": "1995059",
					"sourceFund": "Frnklin India Prima Plus",
					"destinationFund": "Frnklin India Bluechip Fund",
					"familySolutions": "no",
					"switchAmount": "12,678"
				}

			],
			"grandTotal": "44,678"
		}
	}
});

SwitchSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SwitchSummaryModelLookUp table, please contact admin...');
    } else {
        SwitchSummaryModelLookUp.remove({}, function(err) {
            console.log('SwitchSummaryModelLookUp collection removed');
            SwitchSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SwitchSummaryModelLookUp table, please contact admin...');
                }
                console.log('SwitchSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SwitchSummaryModelLookUp;
