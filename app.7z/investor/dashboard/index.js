'use strict';
/**
 *@ngdoc object
 *@name investor.module:Dashboard
 *@description
 * <p>
 * It has all linkup of the components, services and initial wrapper
 * </p>
 */
console.log('dashboard console');

// Home View
module.exports = angular.module('investor.dashboard', [])
    .config(require('./dashboard.routes'))
    .controller('DashboardController', require('./dashboard.controller'))
    .directive('fticInvDbSmartSavingsAccount', require('./components/invdbsmartsavingsaccount/invDbSmartSavingsAccount.directive'))
    .directive('fticInvDbOneTouchInvest', require('./components/invdbonetouchinvest/invDbOneTouchInvest.directive'))
    .constant('dashboardConstants', require('./constants/dashboard.constants'))
    //.factory('fticinvDbSmartSavingsAccount', require('./components/invdbsmartsavingsaccount/invDbSmartSavingsAccount.factory'))
    .directive('fticInvDbUserInformation', require('./components/invDbUserInformation/invDbUserInformation.directive'))
    .directive('fticInvMyInvestments', require('./components/invdbmyinvestments/invDbmyInvestments.directive'))
    .factory('investorDashboardConfig', require('./components/invdbmyinvestments/invDbmyInvestments.factory'))
    .directive('fticInvMySips', require('./components/invdbmysips/invDbMySips.directive'))
    .directive('fticInvDbSmartSolutions', require('./components/invdbsmartsolutions/invdbsmartsolutions.directive'))
    .factory('investorDashboardInitialServices', require('./services/investorDashboardInitialLoader.service'))
    .factory('investorDashboardDetailsModel', require('./services/investorDashbordDetailsModel.service'))
    .directive('fticInvDbNotifications', require('./components/invdbnotifications/invDbNotifications.directive'))
    .directive('fticInvDbRecommendations', require('./components/invdbrecommendations/invDbRecommendations.directive'))
    .directive('fticUnclaimedAmount', require('./components/unclaimedAndDividendHisAmount/unclaimedAndDividendHisAmount.directive'))
    .directive('fticInvDbSsTile', require('./components/imageTextTile/imageTextTile.directive'))
    .directive('fticSmartSolutionsGrid', require('./components/smartsolutionsgrid/smartSolutionsGrid.directive'))
    .factory('investorDashboardInvestServices', require('./services/investorDashboardInvestLoader.service'))

    ;
