// getPostalReturnsSummaryData.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PostalReturnsSummaryModelSchema = new mongoose.Schema({
    PostalReturnsSummaryResp: {
        type: Array,
        "default": []
    }
});

var PostalReturnsSummaryLookUp = mongoose.model('PostalReturnsSummaryLookUp', PostalReturnsSummaryModelSchema);

var PostalReturnsSummaryModel = new PostalReturnsSummaryLookUp({
  PostalReturnsSummaryResp: {
    "postalReturns": {
        "fundWiseData": [
         {
              "folioNo": "2341621",
              "accountNumber": "1000110191",
              "fund": "Franklin India Equity Fund",
              "transactionType": "Redemption",
              "amount": "23,967",
              "postalReturns": "Post Returned",
              "unclaimedFund": "Franklin India Balanced Fund - Dividend",
              "familySolution": "Yes",
              "unclaimedUnits": 200
         },
         {
              "folioNo": "2341621",
              "accountNumber": "1000110191",
              "fund": "Franklin India Equity Fund",
              "transactionType": "Dividend",
              "amount": "67,890",
              "postalReturns": "No",
              "unclaimedFund": "Franklin India Balanced Fund - Dividend",
              "familySolution": "No",
              "unclaimedUnits": 500
          },
          {
              "folioNo": "2341621",
              "accountNumber": "1000110191",
              "fund": "Franklin India Equity Fund",
              "transactionType": "Redemption",
              "amount": "78,000",
              "postalReturns": "No",
              "unclaimedFund": "Franklin India Cost Management Account - Growth",
              "familySolution": "No",
              "unclaimedUnits": 120
          }
      ]
      }
    }
  });

PostalReturnsSummaryLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PostalReturnsSummaryLookUp table, please contact admin...');
    } else {
        PostalReturnsSummaryLookUp.remove({}, function(err) {
            console.log('PostalReturnsSummaryLookUp collection removed');
            PostalReturnsSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PostalReturnsSummaryLookUp table, please contact admin...');
                }
                console.log('PostalReturnsSummaryLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PostalReturnsSummaryLookUp;