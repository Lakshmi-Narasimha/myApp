/**
 * @ngdoc property
 * @name accountViewInitialLoader
 * @requires accountViewModel
 * @requires investorEvents
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - accountViewInitialLoader loads all the initial services for Account statements in 
 *   Statements tab of my investors page.
 *
 **/

'use strict';

var accountViewInitialLoader = function(accountViewModel, investorEvents, fticLoggerMessage, loggerConstants, toaster, $loader) {
    var accountViewInitialLoadService = {
        _isServicesData: false,
        loadAllServices: function(scope, accountFilter) {
            function accountViewDataSuccess(data) {
                accountViewModel.setAccountViewObj(data);
                investorEvents.myPortfolio.accountStmtsAccountView(scope);
            }

            function promiseFailure(data) {
                accountViewInitialLoadService._isServicesData = false;
                toaster.error(data.data[0].errorDescription);
                console.log(data); // Need to handle this for all service methods called
            }

            function stopLoader() {
                $loader.stop();
            }

            $loader.start();
            accountViewModel.getAccountViewDetails(accountFilter)
                .then(accountViewDataSuccess, promiseFailure).finally(stopLoader);
        }
    };
    return accountViewInitialLoadService;
};

accountViewInitialLoader.$inject = ['accountViewModel', 'investorEvents', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader'];
module.exports = accountViewInitialLoader;
