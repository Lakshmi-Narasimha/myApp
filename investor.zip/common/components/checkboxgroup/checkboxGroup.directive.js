/**
 * @ngdoc property
 * @name Checkbox Group directive
 * @requires $state
 * @description
 *
 * - Checkbox group directive will control the set of checkboxes, selecting all at once, deselecting all at once and resturns the selected items as an array.
 *
 **/
'use strict';

var checkBoxGroup = function($state, eventConstants, advisorEventConstants) {
	return {
            template: require('./checkboxGroup.html'),
            restrict: 'E',
            replace: true,
            scope: {
              checkboxes: '=',
              headerText: "@?",
              sectionOptionsEmail: '='
            },
            controller: function($scope, $element, $attrs){  
            },
            link: function(scope, iElement, iAttrs, controller){
              var updateCheckboxes = function(value){
                  angular.forEach(scope.checkboxes, function(checkbox){
                      checkbox.value = value;
                  });
              };
              scope.disable = false;
              scope.selectAllObj = {
                label: "SELECT ALL", // Needs a replace with constant file
                value: false,
                key: "selectall" // Needs a replace with constant file
              };
              scope.replicateObj = {
                label: "Replicate the access rights of ",
                value: false,
                key: "replicate" // Needs a replace with constant file
              }

              scope.$on(advisorEventConstants.MyProfile.ENABLE_SELECT_ALL, function($event){
                  scope.disable = true;
                  scope.selectAllObj.value = true;
                  
              });

              scope.$on(eventConstants.CHECKBOX_CHECKED, function($event, checkObj){
                var key = checkObj.key;
                if(key === "replicate"){
                  if(checkObj.value){
                    updateCheckboxes(false);
                    scope.$emit('REPLICATE_USER',checkObj.value,2);
                  }else{
                    scope.$emit('REPLICATE_USER',checkObj.value,1);
                  }
                  
                }
                if(key === "selectall"){
                  scope.replicateObj.value = false;
                  if(checkObj.value){
                      scope.disable = true;
                      updateCheckboxes(true);
                      scope.replicateObj.disabled = true;
                      // scope.$emit('REPLICATE_USER',false,2);
                  } else {
                      scope.$emit('REPLICATE_USER',false,1);
                      updateCheckboxes(false);
                      scope.disable = false;
                      scope.replicateObj.disabled = false;
                  }
                } else {
                  var isAnyUnchecked = false;
                  angular.forEach(scope.checkboxes, function(checkbox){
                      if(!checkbox.value) {
                          isAnyUnchecked = true;
                          scope.disable = false;
                      }
                  });
                  scope.selectAllObj.value = !isAnyUnchecked;
                  if(scope.selectAllObj.value){
                    scope.replicateObj.value = false;
                    scope.disable = true;
                    scope.$emit('REPLICATE_USER',false,2);  
                  }
                  //scope.$emit('CHECKBOXES_UPDATED');
                }
              });

              scope.eventName = advisorEventConstants.reports.ADV_REPORTS_SELECTED_EMAIL_ID;
              
              scope.$on(scope.eventName, function (event,selectedOption) {
                  scope.selectedOption = selectedOption.title;
                  if((scope.selectedOption == 'Select Previously added sub user') && (scope.replicateObj.value)){
                    updateCheckboxes(false);
                  }
                  scope.$emit('personalInformationUserEmailSelected',scope.selectedOption);
              });

            }
        };
};

checkBoxGroup.$inject = ["$state", "eventConstants", "advisorEventConstants"];
module.exports = checkBoxGroup;