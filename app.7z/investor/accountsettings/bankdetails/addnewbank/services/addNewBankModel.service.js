/**
 * @ngdoc service
 * @name eform model service
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Eform Model deals with the fetching data from the service and returning the promise object as well as setting and getting the data. 
 *
 */

'use strict';

var addNewBankModel = function (Restangular, $q, authenticationService, investorConstants, loggerConstants, fticLoggerMessage) {
    
    var _folioNumbersList = null;
    var _invBanksList = null;
    var invBankDetails = {};
    var params;
    var addNewBankModel = {
        getFolioAccountDetails: function() {
            var deferred = $q.defer();
            var params = {};                   
            params.guId = authenticationService.getUser().guId;
            params.flag = 'P';
            Restangular.one('clients/folioAccounts').get(params).then(function(response) {                 
                deferred.resolve(response);             
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setFolioNumbersList : function (folioNumbersList) {
            _folioNumbersList = folioNumbersList;
        },
        getFolioNumbersList : function () {
            if (!angular.isDefined(_folioNumbersList)) {
                return null;
            }
            return _folioNumbersList;
        },         
        getBankDetails: function() {
            invBankDetails.guId = authenticationService.getUser().guId;
            var deferred = $q.defer(); 
            Restangular.one('/accountSettings/bankDetails').get(invBankDetails).then(function(BankDetails) {
                deferred.resolve(BankDetails);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        setBasisBankDetails: function(bankdetails){
            _invBanksList = bankdetails; 
        },
        getBasisBankDetails: function(){
            return _invBanksList;
        }
    };
    return addNewBankModel;
};

addNewBankModel.$inject = ['Restangular', '$q', 'authenticationService', 'investorConstants', 'loggerConstants', 'fticLoggerMessage'];

module.exports = addNewBankModel;
