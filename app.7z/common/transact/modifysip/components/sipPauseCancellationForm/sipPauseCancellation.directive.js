/**
* @ngdoc property
* @name fticModifySipForm Directive
* @description
*
* - Form concludes sip effective date for specific actions
*
**/
'use strict';

var fticSipPauseCancellation = function (eventConstants,SipModifyDetailModel,transactModel,transactEventConstants,$filter,fundDetails) {
    return {
        template: require('./sipPauseCancellation.html'),
        restrict: 'E',
        scope: {
            sipType:"@"
        },
        controller:['$scope', function ($scope) { 
        	console.log("SIP pause and cancellation");
            var datefilter = $filter('date');
            var susObj = transactModel.getFundDetails();
            $scope.sipPauseCancel = {};
            $scope.strtDate= datefilter(susObj.nextTriggerDate, 'dd MMM yyyy');;
            $scope.EnableConfirm = false;
            $scope.$on(eventConstants.CHECKBOX_CHECKED, function($event, checkboxObject){
                if (checkboxObject.value) {
                    $scope.EnableConfirm = true;
                } else {
                	$scope.EnableConfirm = false;
                }
            });  
            $scope.sipPauseCancel = {};
            $scope.getSelections = function() {
                $scope.sipPauseCancel.sipModifyType = $scope.sipType;
                if($scope.sipType === "Sip_Pause"){
                    $scope.sipPauseCancel.txnSource = "SIPPAS"
                } else if($scope.sipType === "Sip_Cancel"){
                    $scope.sipPauseCancel.txnSource = "SIPCAN"
                }else if($scope.sipType === "Step_Up_Cancel"){
                    $scope.sipPauseCancel.txnSource = "SIPSUC"
                }
                $scope.sipPauseCancel.strtDate = $scope.strtDate;
                SipModifyDetailModel.setModifySipDetails($scope.sipPauseCancel);
               
                $scope.$emit(transactEventConstants.transact.Set_Modify_Sip_Details);  
            } 
        }]
    };
};

fticSipPauseCancellation.$inject = ['eventConstants','SipModifyDetailModel','transactModel','transactEventConstants','$filter','fundDetails'];
module.exports = fticSipPauseCancellation;