'use strict';

var express = require('express');
var router = express.Router();
var InvCgFolioModel = require('./getCgPortfolio.model');

// api route
router.route('/clients/capitalGain')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvCgFolioModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].portFolioResp.length === 0) {
                res.send(err);
            } else {
                res.json(data[0].portFolioResp);
            }

        });
    });

module.exports = router;
