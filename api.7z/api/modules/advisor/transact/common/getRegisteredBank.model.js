// RegisteredBankDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RegisteredBankModelSchema = new mongoose.Schema({
    RegisteredBankResp: {
        type: Array,
        "default": []
    }
});

var RegisteredBankModelLookUp = mongoose.model('RegisteredBankModelLookUp', RegisteredBankModelSchema);

var RegisteredBankModel = new RegisteredBankModelLookUp({
    RegisteredBankResp : {
        'registeredBank' : {
            'bankDetails': [
                {
                    'bankName' :'Dena Bank',
                    'accountNo' : '001234567890'
                }
            ]
        }
    }
});

RegisteredBankModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating RegisteredBankModelLookUp table, please contact admin...');
    } else {
        RegisteredBankModelLookUp.remove({}, function(err) {
            console.log('RegisteredBankModelLookUp collection removed');
            RegisteredBankModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RegisteredBankModelLookUp table, please contact admin...');
                }
                console.log('RegisteredBankModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RegisteredBankModelLookUp;