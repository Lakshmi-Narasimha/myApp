/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { IntentparameterComponent } from './intentparameter.component';

describe('IntentparameterComponent', () => {
  let component: IntentparameterComponent;
  let fixture: ComponentFixture<IntentparameterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntentparameterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentparameterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
