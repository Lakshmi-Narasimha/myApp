'use strict';

var savedSmartSolModelService = function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _sssDtls,
        _selectedSmartSol,
        _adjustedGoalAmt = null;

    var savedSmartSolModel = {
        fetchSavedSmartSol: function() {
            var params = {
                'guId': authenticationService.getUser().guId
            };

            var deferred = $q.defer();
            Restangular.one('smartsolution/retrieveSmartSolutions').get(params).then(function(savedSmartSolDtls) {
                deferred.resolve(savedSmartSolDtls);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        postDeleteSmartSolDtls: function(body) {
            var params = {};
            params.guId = authenticationService.getUser().guId;

            var deferred = $q.defer();
            Restangular.one('smartsolution/savedSmartSolutions').customPOST(body, '', params, {}).then(function(deleteSmartSolDtls) {
                console.log(deleteSmartSolDtls);
                deferred.resolve(deleteSmartSolDtls);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postSavedSmartSolDtls: function(body) {
            var params = {};
            params.guId = authenticationService.getUser().guId;

            var deferred = $q.defer();
            Restangular.one('smartsolution/savedSmartSolutions').customPOST(body, '', params, {}).then(function(savedSmartSolDtls) {
                console.log(savedSmartSolDtls);
                deferred.resolve(savedSmartSolDtls);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postEmailSmartSolDtls: function(body) {
            var params = {};
            params.guId = authenticationService.getUser().guId;

            var deferred = $q.defer();
            Restangular.one('smartsolution/goalSheetEmail').customPOST(body, '', params, {}).then(function(emailSmartSolDtls) {
                console.log(emailSmartSolDtls);
                deferred.resolve(emailSmartSolDtls);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getSavedSmartSolDtls: function() {
            return _sssDtls;
        },
        setSavedSmartSolDtls: function(savedSmartSolData) {
            _sssDtls = savedSmartSolData;
        },
        setSelectedSavedSmartSolData: function(selectedSmartSol) {
            _selectedSmartSol = selectedSmartSol;
        },
        getSelectedSavedSmartSolData: function() {
            return _selectedSmartSol;
        }

    };
    return savedSmartSolModel;

};

savedSmartSolModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = savedSmartSolModelService;
