'use strict'; 
describe('Filter: String to Number', function () {
    
    var $filter;
    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {

        angular.mock.inject(function(_$filter_) {
          $filter = _$filter_;
        });
        
    });

  it('should Convert a string to Number - When input is valid & with comma', function () {

        var stringNumber = '5,000', result;
        result = $filter('fticInvStringToNumber')(stringNumber);
        expect(result).toEqual(5000);
  });

  it('should Convert a string to Number - When input is valid & without comma', function () {

        var stringNumber = '500', result;
        result = $filter('fticInvStringToNumber')(stringNumber);
        expect(result).toEqual(500);
  });

  it('should Convert a string to Number - When input is undefined', function () {

        var stringNumber, result;
        result = $filter('fticInvStringToNumber')(stringNumber);
        expect(result).toEqual(0);
  });

   it('should Convert a string to Number - When input is null', function () {

        var stringNumber = null, result;
        result = $filter('fticInvStringToNumber')(stringNumber);
        expect(result).toEqual(0);
  });

  it('should Convert a string to Number - When input is empty string', function () {

        var stringNumber = '', result;
        result = $filter('fticInvStringToNumber')(stringNumber);
        expect(result).toEqual(0);
  });
});