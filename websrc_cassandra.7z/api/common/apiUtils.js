var getMessageModel = require('../modules/getMessage/getMessage.model');
var dataPassModel = require('../modules/dataPass/dataPass.model');
var https = require('https');
var http = require('http');
var config = require('../../config/config');
var querystring = require('querystring');

var apiUtils = {
    customerInfo: {
        phoneNo: '',
        loggedInTimeStamp: new Date(),
        engagementCounter: 0,
        chatSendMsgCounter: 0,
        chatGetMsgCounter: 0,
        chatEndTime: new Date(),
        pastChatEndTime: new Date(),
        agentId: ''
    },
    setCustomerInfo: function(key, val) {
        if (val) {
            this.customerInfo[key] = val;
        } else {
            this.customerInfo = key;
        }
    },
    getCustomerInfo: function(key) {
        return key ? this.customerInfo[key] : this.customerInfo;
    },
    checkSurveyStatus: function(date1, date2) {
        // the following is to handle cases where the times are on the opposite side of
        // midnight e.g. when you want to get the difference between 9:00 PM and 5:00 AM

        if (date2 < date1) {
            date2.setDate(date2.getDate() + 1);
        }

        return date2 - date1;
    },
    dataPass: function(req, res, dataPassCallback) {

        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": req.session.agentID,
            "Role": req.session.accRole,
            "Mobile Number": req.session.MDN,
            "Greeting Name": req.session.nickName
        };

        req.uri = dataPassModel.createRequestUri;
        console.log("requestURI:", req.uri);

        var postBody = querystring.stringify(post_data);
        console.log(postBody);

        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'POST',
                path: req.uri.path,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Cookie': req.sessionCookie,
                    'Content-Length': Buffer.byteLength(postBody)
                },
                rejectUnauthorized: true
            },
            function(proxyResponse) {
                console.log("statusCode: ", proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                    dataPassCallback(res);
                    //res.status(200).end();
                } else {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(postBody);
        proxyRequest.end();
    },
    getMsg: function(req, res, callBack) {
        req.uri = getMessageModel.createRequestUri;
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + req.engagementID,
                headers: {
                    'Cookie': req.sessionCookie
                }
            },
            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    console.log('response in increments', chunk);
                    callBack(chunk);
                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();

    },
    getMsgMultiCall: function(req, res, callBack) {
        for (var i = 0; i < 3; i++) {
            (function(i) {
                apiUtils.getMsg(req, res, function(chunk) {
                    if (i === 2) {
                        callBack(chunk);
                    }
                });
            })(i);
        }
    },
    generateToken: function(req, res, callBackToken) {
        var postBody = { "deviceId": req.session.MDN };
        console.log(postBody);
        var proxyRequest = http.request({
                // host: 'sclmdm03wsi.sdc.vzwcorp.com',
                host: 'udm-dev.vzwcorp.com',
                //port: '6001',
                port: '80',
                method: 'POST',
                path: '/udmmw/udmapi/saveToken',
                headers: {
                    'Content-Type': 'application/json'
                }
            },

            function(proxyResponse) {

                console.log("req:", proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                    proxyResponse.on('data', function(chunk) {
                        chunk = JSON.parse(chunk);
                        console.log("chunk:", chunk);
                        callBackToken(chunk);
                    });
                } else {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });

                });
            });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    sendCmd: function(req, res, callBackSendCmd) {
        var postBody = {
            "castType": "multicast",
            "cmd": "DROP_MSG",
            "requestor": "chartServer",
            "deviceList": [{
                "deviceId": req.session.MDN
            }],
            "data": req.session.getMsgRes
        }
        console.log("send commmand post body", postBody);
        var proxyRequest = http.request({
                // host: 'sclmdm03wsi.sdc.vzwcorp.com',
                host: 'udm-dev.vzwcorp.com',
                //port: '6001',
                port: '80',
                method: 'POST',
                path: '/udmmw/udmapi/sendCommand',
                headers: {
                    'Content-Type': 'application/json'
                }
            },

            function(proxyResponse) {

                console.log("sendCmd:", proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                    proxyResponse.on('data', function(chunk) {
                        chunk = JSON.parse(chunk);
                        console.log("send commnad chunk", chunk);
                        callBackSendCmd(chunk);
                    });
                } else {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });

                });
            });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    formattedGetMsg: function(req, res, getMsgCallback, isSendCallback) {
        req.uri = getMessageModel.createRequestUri;
        console.log("Get Message API is trigerred", req.session.engagementID);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + req.session.engagementID,
                headers: {
                    'Cookie': req.sessionCookie
                }
            },
            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                console.log(proxyResponse.statusCode);
                console.log('res.statusCode' + res.statusCode);
                if (res.statusCode === 200) {
                    if (proxyResponse.statusCode === (200 || 204)) {
                        console.log("after the proxyResponse");
                        proxyResponse.on('data', function(chunk) {
                            chunk = JSON.parse(chunk);
                            console.log("Get Message API Response:", chunk);
                            getMessageModel.response.Page.engagementID = req.session.engagementID;
                            //getMessageModel.response.Page.status = engagementModel.response.Page.status;
                            if (chunk.messages[0] && chunk.messages[0].state) {
                                // console.log("if state exist:", chunk);
                                getMessageModel.response.Page.agentID = (chunk.messages[0]['user.id'] || req.session.agentID);
                                getMessageModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['display.text'];
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                            } else if (chunk.messages[0]) {
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                            }
                            //console.log(getMessageModel.response.ModuleMap.Support.msgList[0].messageType);
                            var counter = getMessageModel.response.ModuleMap.Support.msgList[0].messageType === 'chatLine' ? apiUtils.customerInfo.chatGetMsgCounter++ : apiUtils.customerInfo.chatGetMsgCounter;
                            //console.log(apiUtils.customerInfo.chatGetMsgCounter);
                            //console.log(apiUtils.customerInfo.chatSendMsgCounter);
                            if (chunk.messages[0].messageText === 'login needed') {
                                getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                                getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                                getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;
                                getMsgCallback(getMessageModel.loginNeededResponse);
                            } else if (chunk.messages[0] && chunk.messages[0].state === "closed") {
                                //  console.log("The chat state is now:", chunk.messages[0].state);

                                /*Calculating the time difference between the last end chat Date&time and the current date&Time*/
                                var timeDiff = apiUtils.checkSurveyStatus(apiUtils.customerInfo.pastChatEndTime, new Date());

                                /*Fixing the conditions of 2/2  for the Get/Send messages to initiate the Survey API */
                                var checkSurveyEligible = (apiUtils.customerInfo.chatGetMsgCounter >= 2 && apiUtils.customerInfo.chatSendMsgCounter >= 2);
                                console.log("apiUtils.customerInfo.chatGetMsgCounter", apiUtils.customerInfo.chatGetMsgCounter);
                                console.log("apiUtils.customerInfo.chatSendMsgCounter ", apiUtils.customerInfo.chatSendMsgCounter);
                                /*Checking the time and 2/2 condition*/
                                //if (checkSurveyEligible && (apiUtils.customerInfo.pastChatEndTime || (timeDiff > 86400000))) {
                                if (checkSurveyEligible) {
                                    //  console.log('Send survey url');
                                    var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                    //var surveyUrlEncoded = encodeURI(surveyUrl);
                                    //  console.log('surveyURL:', surveyUrl);
                                    var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                    //    console.log('surveyMsg:', surveyMsg);

                                    getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                    //    console.log('page.surveyUrl:', surveyUrl);
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                    //    console.log('FeedLink.browserUrl:', surveyUrl);
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                    //    console.log('messageList[0].messageText:', surveyMsg);

                                    apiUtils.customerInfo.pastChatEndTime = new Date();

                                    /*Sending the Thank you and Survey in the Response on End Chat*/
                                    getMsgCallback(getMessageModel.surveyResponse);
                                    req.session.getMsgRes = getMessageModel.surveyResponse;
                                    console.log('req.session.mqtt' + req.session.mqtt);
                                    apiUtils.sendCmd(req, res, function(response) {
                                        console.log("Send Command CAll");
                                        // apiUtils.formattedGetMsg(req, res, function() {
                                        //   res.status(200).end();
                                        // });
                                    });
                                    req.session.destroy();
                                    //console.log("the repsosne not on survey end:", getMessageModel.surveyResponse);
                                } else {
                                    console.log("this is hte point where end msg sent");
                                    /* Sending the Thank You response on End Chat*/
                                    getMsgCallback(getMessageModel.endResponse);
                                    req.session.getMsgRes = getMessageModel.endResponse;
                                    console.log('req.session.mqtt' + req.session.mqtt);
                                    apiUtils.sendCmd(req, res, function(response) {
                                        console.log("Send Command CAll");
                                        // apiUtils.formattedGetMsg(req, res, function() {
                                        //   res.status(200).end();
                                        // });
                                    });
                                    req.session.destroy();
                                    //console.log("the repsosne not on non-servey end:", getMessageModel.endResponse);
                                }
                            } else {
                                /*Sending the message sent form the TC to the Client*/
                                getMsgCallback(getMessageModel.response);
                            }
                            
                        });

                        if(req.session.mqtt && proxyResponse.statusCode === 200 && !isSendCallback){
                            req.session.getMsgRes = getMessageModel.response;
                            console.log('req.session.mqtt'+req.session.mqtt);
                            apiUtils.sendCmd(req, res, function(response) {
                              console.log("Send Command CAll");
                                apiUtils.formattedGetMsg(req, res, function() {
                                  res.status(200).end();
                                });
                            });
                        } else{
                            apiUtils.formattedGetMsg(req, res, function() {
                                res.status(200).end();
                            });
                        }
                    } else {
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }
                } else {
                    res.send({
                        message: 'ERROR!!! Something went wrong while retrieving data.',
                        statusCode: res.statusCode
                    });
                }
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    }
};

module.exports = apiUtils;
