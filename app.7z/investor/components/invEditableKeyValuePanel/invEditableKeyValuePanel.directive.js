/**
 * @ngdoc directive
 * @name fticKeyValueTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticKeyValueTile will display the kye value tiles for "My profile - Grant Access" .
 * 
 *
 **/

'use strict';

var InvEditableKeyValuePanel = function(eventConstants) {
    return {
        template: require('./invEditableKeyValuePanel.html'),
        restrict: 'E',
        replace: true,         
        scope: {
            info:'=',
            eventName:'@?',
            actionClass:'@?',
            verticalTileObj: '=',
            buttonName:'='
        },
        controller: function($scope, $element, $attrs){
            $scope.onButtonClick =  function($event){
                $scope.$emit(eventConstants.ACTION_BUTTON_CLICKED, $scope.buttonName.source);
            };  
        }
    };
};

InvEditableKeyValuePanel.$inject = ['eventConstants'];
module.exports = InvEditableKeyValuePanel;