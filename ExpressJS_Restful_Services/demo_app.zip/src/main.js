// Filename: main.js
// Require.js allows us to configure shortcut alias
require.config({
    waitSeconds: 200,
    paths: {
        jquery: 'lib/jquery.min-2.2.4',
        lodash: 'lib/lodash.min-4.13.0',
        backbone: 'lib/backbone.min-1.3.3',
        backbonesubroute: 'lib/backbone.subroute.min-0.4.5',
        q: 'lib/q.min-1.4.1',
        text: 'lib/text.min-2.0.12',
        bootstrap: 'lib/bootstrap.min-3.3.6',
        bootstraptypeahead: 'lib/bootstrap3-typeahead.min',
        'bootstrap-dialog': 'lib/bootstrap-dialog.min-1.35.1',
        moment: 'lib/moment.min-2.13.0',
        momentTimezone: 'lib/moment-timezone.min-0.5.4',
        CryptoJS: 'lib/sha1.min-3.1.2',
        ampfComponents: 'lib/ampf-components',
        moment: 'lib/moment.min-2.13.0',
        page: 'lib/page-1.7.1'
    },
    map: {
        '*': {
            // backbone requires underscore...lodash is a superset of underscore
            underscore: 'lodash'
        }
    },
    shim: {
        backbone: {deps: ['underscore', 'jquery'], exports: 'Backbone'},
        bootstrap: {deps: ['jquery']},
        elementary: {deps: ['jquery']},
        CryptoJS: { exports: 'CryptoJS' }
    }
});
require(['app/application/app', 'bootstrap'], function (app) {  // bootstrap will load and attach itself to jquery
    app.start();
});