/**
 * @ngdoc property
 * @name OverviewController Controller
 * @requires $scope
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter


function OverviewController($scope, $state, myportfolioConstants, invInstantMailback, $loader, toaster, eventConstants, investorDashboardDetailsModel, $filter, investorConstants) {

    $scope.init = function() {
        $scope.navPillsOptions = myportfolioConstants.overview.NAV_PILLS_OPTIONS;
        $scope.appName = myportfolioConstants.overview.INV_APP_NAME;
        $scope.btnColor = 'btn-group-sm green-btn-group pull-left';
        var userProfileData = investorDashboardDetailsModel.getDashboardData().profileDetails;
        var $translate = $filter('translate');
        $scope.modelValues = {
            modelVal: 'panview'
        };
        
        $scope.viewFlag = $state.$current.data.viewFlag;

        //$scope.pillSelect({}, 'panview');

        $scope.$on('changeNavPill', function(event, modelVal) {
            $scope.modelValues.modelVal = modelVal;
        });

        $scope.pillSelect = function($event, param) {
            $scope.modelValues.modelVal = param;
            if (param === 'panview') {
                $scope.viewFlag = myportfolioConstants.flagOptions.PAN_FLAG;
                $state.go('overview.panview');
            } else if (param === 'folioview') {
                $scope.viewFlag = myportfolioConstants.flagOptions.FOLIO_FLAG;
                $state.go('overview.folioview');
            } else if (param === 'accview') {
                $scope.viewFlag = myportfolioConstants.flagOptions.ACCOUNT_FLAG;
                $state.go('overview.accview');
            }
            // $event.stopPropagation();

        };

        $scope.$on(eventConstants.INV_MAILBACK_CLICKED_SUC, function(event, data) {
            var params = {};
            var mailBackModel = invInstantMailback.getMailBackData();
            params.options = [myportfolioConstants.overview.optionCode];
            params.formats = [data.type];
            params.flag = $scope.viewFlag;
            params.folioPanAcc = mailBackModel.folioPanAcc ? mailBackModel.folioPanAcc : (userProfileData && userProfileData.emailId) ? userProfileData.emailId: '';
            params.periodType = mailBackModel.periodType;
            params.dateRanges = invInstantMailback.getDateRangeFromCurrentData();
            params.emailId = '';
            $loader.start();
            invInstantMailback.postInstantMailBackDetails(params).then(function(details) {
                
                console.log(details);
                toaster.success($translate(investorConstants.myportfolio.ACC_MAILBACK_SUCC));
            }, function(error) {

                if(error && error.data && error.data.length > 0) {
                    //toaster.error(error.data[0].errorDescription);
                }
                toaster.error($translate(investorConstants.myportfolio.ACC_MAILBACK_FAIL));
            }).finally(function(){
                $loader.stop();
            });
        });
    };
    $scope.init();
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.


OverviewController.$inject = ['$scope', '$state', 'myportfolioConstants', 'invInstantMailback', '$loader', 'toaster', 'eventConstants', 'investorDashboardDetailsModel', '$filter', 'investorConstants'];
module.exports = OverviewController;
