/**
 * @ngdoc factory
 * @name 
 * @requires 
 * @description
 *
 *
 */
'use strict';

var invSmartSolHolderInfoFactory = function () {

    var invSmartSolHolderInfoFactory = {
        getFormattedHolderInfo: function (investorDetails) {
            if(investorDetails && Object.keys(investorDetails).length > 0) {
                return [{
                        key: 'First Holder',
                        value: investorDetails.custName
                    }, {
                        key: 'Second Holder',
                        value: investorDetails.holders[1] ? investorDetails.holders[1].name : 'NA'
                    }, {
                        key: 'Third Holder',
                        value: investorDetails.holders[2] ? investorDetails.holders[2].name : 'NA'
                    }, {
                        key: 'Folio. No.',
                        value: investorDetails.folioId
                    }, {
                        key: 'Mode of Holding',
                        value: investorDetails.modeofHolding
                    }
                    // {key:$filter('translate')(advisorConstants.collaterals.CITY),value:eformModel.getSelectedUser().city},
                ];
            }else {
                return [];
            }
        }
    };
    return invSmartSolHolderInfoFactory;

};

invSmartSolHolderInfoFactory.$inject = [];
module.exports = invSmartSolHolderInfoFactory;