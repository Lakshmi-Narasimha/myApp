/**
 * @ngdoc property
 * @name eMandateController Controller
 * @requires $state
 * @requires $scope
 * @description
 *
 * - change password controller deals with calling the services to load to change the current password to required password.
 *
 **/


'use strict';

function eMandateController($state, $scope,$timeout, eMandateIntialLoadService, investorEventConstants, authenticationService, investorDashboardDetailsModel) {
	
	$scope.eMandate = {
        loadGetEmandate : false
    }

    $scope.$on(investorEventConstants.accountSettings.LOAD_EMANDATE_DATA_EVENT, function(){
        $scope.eMandate.loadGetEmandate = true;
    });

    $scope.$on('loadingWithNewEmandates', function() {
        $timeout(function() {
            $scope.eMandate.loadGetEmandate = true;
        });
    });
    
    eMandateIntialLoadService.getEmandatesList($scope, {});

    
    
}
// $inject is necessary for minification. 
eMandateController.$inject = ['$state','$scope','$timeout', 'eMandateIntialLoadService', 'investorEventConstants', 'authenticationService', 'investorDashboardDetailsModel'];
module.exports = eMandateController;