'use strict';
function smartSolsTopupWithSameFundsCtrl($scope, $state, overviewModel, buildPlanModelService, planSmartSolution, investorGoalModelService, currentPlanFundsService, sipCalculatorModel) {
    var planInputObj = {};
    $scope.init = function () {
        $scope.keyValueList = overviewModel.getHolderInformation();
        $scope.fundDetails = angular.copy(currentPlanFundsService.getCurrentPlanFunds()) ;
        var goalSummary = angular.copy(investorGoalModelService.getSelectedGoalData());
        planInputObj = {
            "age": "",
            "investmentTenure": 4,//goalSummary.pendingTimeFrame,
            "investmentAmount": goalSummary.targetAmount - ((goalSummary.achieved.split("%")[0] * goalSummary.targetAmount) /100),
            "equityPerc": 0
        };
        planInputObj.myFunds = [];
        angular.forEach(angular.copy(currentPlanFundsService.getCurrentPlanFunds()), function (fund, ind) {
            var fundList = {};
            fundList.fundCode = "002";//fund.fundOption;
            fundList.allocPer = 50;
            planInputObj.myFunds.push(fundList);
        });
        getSmartSolutionDetails(planInputObj);
    };

    $scope.init();


    $scope.$on("investmentType", function ($event, data) {
        buildPlanModelService.setInvestmentType(data);
    });

    $scope.$on("investmentValue", function ($event, data) {
        $scope.radioSelectedData = buildPlanModelService.setInvestmentValue(data);
        $scope.getFundDetails();
    });

    $scope.getFundDetails = function () {
        $scope.investmentType = buildPlanModelService.getInvestmentType();
        $scope.investmentValue = buildPlanModelService.getInvestmentValue();
        $scope.goalDetails = [];
        $scope.totalGoalDetails = {};
        $scope.instalMentDtls = {
            monthly: "",
            annually: "",
            oneTime: ""
        };

        if ($scope.investmentType == "Monthly" || $scope.investmentType == "Annually") {
            planSmartSolution.setTransactType("SIP");
        }
        else if ($scope.investmentType == "One time") {
            planSmartSolution.setTransactType("Lumpsum");
        }

        var fund = angular.copy(currentPlanFundsService.getCurrentPlanFunds());
        $scope.totalAllocation = 0;
        $scope.totalMonthly = null;
        $scope.totalAnnually = null;
        $scope.totalOneTime = null;
        for (var i = 0; i < planInputObj.myFunds.length; i++) {

            if ($scope.investmentType == "Monthly") {
                $scope.instalMentDtls.monthly = Math.round(($scope.investmentValue * planInputObj.myFunds[i].allocPer)/100);
                $scope.totalMonthly += parseInt($scope.instalMentDtls.monthly);
            }
            if ($scope.investmentType == "Annually") {
                $scope.instalMentDtls.annually = Math.round(($scope.investmentValue * planInputObj.myFunds[i].allocPer)/100);
                $scope.totalAnnually += parseInt($scope.instalMentDtls.annually);
            }
            if ($scope.investmentType == "One time") {
                $scope.instalMentDtls.oneTime = Math.round(($scope.investmentValue * planInputObj.myFunds[i].allocPer)/100);
                $scope.totalOneTime += parseInt($scope.instalMentDtls.oneTime);
            }

            $scope.goalDetails.push({
                "fundName": fund[i].funddesc,
                "allocation": planInputObj.myFunds[i].allocPer,
                "installmentDetails": angular.copy($scope.instalMentDtls),
                "dividendFlag": fund.dividendFlag,
                "fund" : fund[i],
                "nfoFlag" : fund[i].nfoFlag || '',
                "fundType": fund[i].fundType || '',
                "fundOption" : fund[i].fundOption || 'NA',
                "accNo" : fund[i].fundType == "N" ? "NEW" : 'NEW',
                "perpetualFlag" : 'N' || '',//fund[i].perpetualFlag
                "stepUpFrequency": fund[i].stepUpFrequency || '',
                "stepUpType" : fund[i].stepUpType || '',
                "stepUpValue" : fund[i].stepUpValue || '',
                "stepUpSip" : 0
            });

            $scope.totalAllocation += planInputObj.myFunds[i].allocPer;
        }
        $scope.totalGoalDetails["allocation"] = $scope.totalAllocation;
        $scope.totalGoalDetails["monthly"] = $scope.totalMonthly;
        $scope.totalGoalDetails["annually"] = $scope.totalAnnually;
        $scope.totalGoalDetails["oneTime"] = $scope.totalOneTime;
    };

    //recommendedPlanInitialLoader.loadAllServices($scope);


    /*$scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function($event) {
     $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
     $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
     $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
     $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
     //console.log($scope.goalChartData);

     });*/
    $scope.goBack = function () {
        $state.go('smartSol.investor.cp');
    };
    $scope.goalsheetBtn = function () {
        buildPlanModelService.setGoalPlanData($scope.goalDetails);
        buildPlanModelService.setGoalTotalPlanData($scope.totalGoalDetails);
        buildPlanModelService.setGoalSummaryFromState($state.current.name);
        $state.go('smartSol.investor.topupwithsf.topupwithsamefundsgoalsheet');
    };

    function loadInvestmentSimulation () {
        var calculatorReq = [{
            "investmentTenure": planInputObj.investmentTenure,//planInputDetails.investmentTenure,
            "annualizedReturn": null,
            "investmentAmount": planInputObj.investmentAmount,//planInputDetails.investmentAmount,
            "fundName": "406",//$scope.smartSolnDetials.rtCode,
            "frequency" : "Monthly",
            "calculatorType": "SIP",
            "trxnType": "SIP"
        }];
        sipCalculatorModel.callSipCalculatorData({"calculatorReq": calculatorReq}, false).then(function (data) {
            var investMentSimulation = angular.copy(data.calculatorResp[0].returnData[0].periodicReturnData);
            $scope.goalChartData = {
                "data": [],
                "goalAmount": null
            };
            angular.forEach(investMentSimulation, function (value, key) {
                var chart = {};
                chart.years = value.duration;
                chart.amount = value.valueOfAmount;
                $scope.goalChartData.data.push(chart);
            });
            $scope.goalChartData.goalAmount = planInputObj.investmentAmount;//planInputDetails.investmentAmount;
            planSmartSolution.setInvestmentSimulation($scope.goalChartData);
        }, function (data) {

        });
    };

    function loadRecommendedPlan() {
        $scope.smartSolnDetials = planSmartSolution.getSmartSolutionDetails();
        loadInvestmentSimulation();
        $scope.recommendationDetails =
        {
            installmentDetails: [
                {text: 'Monthly', value: parseInt($scope.smartSolnDetials.monthlySIP.replace(/,/g, ""))},
                {text: 'Annually', value: parseInt($scope.smartSolnDetials.annualSIP.replace(/,/g, ""))},
                {text: 'One time', value: parseInt($scope.smartSolnDetials.lumpsum.replace(/,/g, ""))}],
            details: {
                "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                "investmentAmount": $scope.smartSolnDetials.investmentAmount
            }
        };
        console.log($scope.recommendationDetails);
        planSmartSolution.setRecommendedDetails($scope.recommendationDetails);
    }

    function getSmartSolutionDetails (planInputObj) {

        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "BP", true).then(function (data) {
            planSmartSolution.setSmartSolutionDetails(data);
            loadRecommendedPlan();
        }, function (data) {
            console.log("Error")
        })
    };
}

smartSolsTopupWithSameFundsCtrl.$inject = ['$scope', '$state', 'overviewModel', 'buildPlanModelService', 'planSmartSolution', 'investorGoalModelService', 'currentPlanFundsService', 'sipCalculatorModel'];
module.exports = smartSolsTopupWithSameFundsCtrl;