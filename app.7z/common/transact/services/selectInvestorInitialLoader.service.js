/**
 * @ngdoc service
 * @name notifications inital loader service
 * @requires notificationsModel
 * @requires guestEvents
 * @requires guestEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Notifications inital loader will set the data and braodcast an event on success and consoles error on failure.
 *
 */
'use strict';

var selectInvestorInitLoader = function(selectInvestorModel,transactEventConstants,transactEvents, fticLoggerMessage, loggerConstants, transactModel, $state, toaster) {
    var selectInvestorInitLoader = {
        _isServicesData: false,
        _status: null,
        loadAllServices: function(scope,searchData,pageRange) {
            /*var message =  loggerConstants.GUEST_APP + ' | ' + loggerConstants.DISTRIBUTOR_ZONE_MODULE + ' | ' + loggerConstants.INSTANT_REPORTS_DETAILS_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name ;*/
            /* fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});*/
            selectInvestorModel.fetchInvestors(searchData,pageRange)
                .then(investorDtlsSuccess, handleFailure);
            function investorDtlsSuccess(data) {
                selectInvestorModel.setInvestors(data);
                selectInvestorModel.setDatabase(data.database);
                selectInvestorInitLoader._status = true;
                transactEvents.transact.publishinvestorDtls(scope);
                transactModel.setTransactionStatus(true);

            };

            function handleFailure(data) {
                selectInvestorInitLoader._isServicesData = false;
                selectInvestorInitLoader._status = false;
                if ($state.current.url === '/sip' || $state.current.url === '/buy') {
                    transactModel.isNewInvestor = true;
                };
                toaster.error(data.data[0].errorDescription);
            };
        }
    };
    return selectInvestorInitLoader;
};

selectInvestorInitLoader.$inject = ['selectInvestorModel', 'transactEventConstants','transactEvents', 'fticLoggerMessage', 'loggerConstants', 'transactModel','$state','toaster'];

module.exports = selectInvestorInitLoader;