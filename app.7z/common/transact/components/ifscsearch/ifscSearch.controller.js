/**
 * @ngdoc property
 * @name IfscSearchModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function IfscSearchModalController($scope, ifscModel, $uibModalStack, transactEventConstants, $uibModalInstance) {
      
    $scope.closeModal = function(){
    	$scope.ifsc.ifscCode = '';
        $uibModalInstance.dismiss('closeModal');
    }
    $scope.ifscApply = function(){
       $scope.$emit('ifscSrchRes',$scope.ifsc); 
       $uibModalInstance.dismiss('closeModal');
    }
};



IfscSearchModalController.$inject = ['$scope', 'ifscModel', '$uibModalStack', 'eventConstants', '$uibModalInstance'];

module.exports = IfscSearchModalController;