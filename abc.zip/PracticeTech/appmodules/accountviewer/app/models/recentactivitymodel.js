define(['jquery', 'backbone', 'breeze',  'appmodules/accountviewer/avcommon',
], function ($, Backbone, Breeze, accountviewCommon) {
	var DT = Breeze.DataType;
	var recentActivityModel = Backbone.Model.extend({
        defaults: {
        	adminCd:null,
        	acctCtx: null,            
        	acctId: null,
        	fmtAcctId: null,
        	tranAmt: null,
        	tranAmtFmtd : null,
        	tranDesc: null,
        	tranDt: null,
        	mediumNm : null,
        	longNm : null,
        	strategyNm : null,
        	brkgProdClsNm:null,
        	brkgProdClsCd:null,
        	defaultIndex : null
        	
            
        }
    }); 
	var fillRecentActivityData = function(activityCollection, serviceResponse){
		if(serviceResponse && serviceResponse.length>0){
			$.each(serviceResponse,function(key,row){
				activityCollection[key] = new recentActivityModel();
				activityCollection[key].attributes.acctCtx = serviceResponse[key].acctCtx;
				activityCollection[key].attributes.acctId = serviceResponse[key].acctId;
				activityCollection[key].attributes.fmtAcctId = serviceResponse[key].fmtAcctId;
				activityCollection[key].attributes.tranAmt = "";
				if(serviceResponse[key].tranAmt && parseFloat(serviceResponse[key].tranAmt)){
					activityCollection[key].attributes.tranAmt = parseFloat(serviceResponse[key].tranAmt);
					activityCollection[key].attributes.tranAmtFmtd = serviceResponse[key].tranAmt.toString().formatMoney();
				}
				
				activityCollection[key].attributes.tranDesc = serviceResponse[key].tranDesc;
				activityCollection[key].attributes.tranDt = serviceResponse[key].tranDt.formatDateWithSlashes();
				activityCollection[key].attributes.defaultIndex = key;
				
			});
		}
	};
	
	
	var applySortToRecentActivity = function(recentActivityArray,sortField,sortOrder){
		if(sortField && sortOrder){
			if(sortField == "tran-amt"){
				if(sortOrder == "asc"){
					recentActivityArray.sort(function (r1, r2) {
						
						  if(r1.attributes.tranAmt === ""){
							return -1;
						  }
    					  if (r1.attributes.tranAmt > r2.attributes.tranAmt) { 
    					    return 1;
    					  }
    					  if (r1.attributes.tranAmt < r2.attributes.tranAmt) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}else if(sortOrder == "desc"){
					recentActivityArray.sort(function (r1, r2) {
						  if(r2.attributes.tranAmt === ""){
							return -1;
						  }
						  if (r1.attributes.tranAmt < r2.attributes.tranAmt) { 
    					    return 1;
    					  }
    					  if (r1.attributes.tranAmt > r2.attributes.tranAmt) {
    					    return -1;
    					  }
    					  // r1 must be equal to r2
    					  return 0;
    					});
				}
				
			}else if(sortField == "tran-desc"){
				if(sortOrder == "asc"){
					recentActivityArray.sort(function (r1, r2) {
    					  if (r1.attributes.tranDesc > r2.attributes.tranDesc) { 
    					    return 1;
    					  }
    					  if (r1.attributes.tranDesc < r2.attributes.tranDesc) {
    					    return -1;
    					  }
    					  // r1 must be equal to r2
    					  return 0;
    					});
				}else if(sortOrder == "desc"){
					recentActivityArray.sort(function (r1, r2) {
    					  if (r1.attributes.tranDesc < r2.attributes.tranDesc) { 
    					    return 1;
    					  }
    					  if (r1.attributes.tranDesc > r2.attributes.tranDesc) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}
				
			}else if(sortField == "trans-date"){
				if(sortOrder == "asc"){
					recentActivityArray.sort(function (r1, r2) {
						r1 = new Date(r1.attributes.tranDt);
						r2 = new Date(r2.attributes.tranDt);
    					  if (r1 > r2) { 
    					    return 1;
    					  }
    					  if (r1 < r2) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}else if(sortOrder == "desc"){
					recentActivityArray.sort(function (r1, r2) {
						r1 = new Date(r1.attributes.tranDt);
						r2 = new Date(r2.attributes.tranDt);
    					  if (r1 < r2) { 
    					    return 1;
    					  }
    					  if (r1 > r2) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}
				
			}
		}else{
			recentActivityArray.sort(function (r1, r2) {
				r1 = new Date(r1.attributes.tranDt);
				r2 = new Date(r2.attributes.tranDt);
				  if (r1 < r2) { 
				    return 1;
				  }
				  if (r1 > r2) {
				    return -1;
				  }
				  return 0;
				});
		}
	};

    var recentActivity = {
    	fillRecentActivityData:fillRecentActivityData,
    	applySortToRecentActivity:applySortToRecentActivity
    };
    return recentActivity;
});
