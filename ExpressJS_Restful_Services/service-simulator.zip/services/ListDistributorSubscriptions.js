var fs = require('fs');
var path = require('path');
var _ = require('lodash');

var ListDistributorSubscriptionsService = function () {
    var initialDataFolder = '/initial-data/ListDistributorSubscriptions';

    // public function

    this.getListDistributorSubscriptions = function (requestData, success, error) {
        var dirPath = __dirname + initialDataFolder;
        var filePath = path.join(dirPath, 'subscription');
        // read the contents of the file specified in server.js and serve the response
        fs.readFile(filePath, 'utf8', function (err, data) {
            if (err) {
                // send error if file reading fails
                error(err);
            } else {
                success(JSON.parse(data));
            }
        });
    };

};

module.exports = new ListDistributorSubscriptionsService();