'use strict';
describe('Controller: investor transact master controller', function() {
	var $controller, $scope,invTransactMasterCtrl,$state,$timeout,$window,transactModel;

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.transact'));

	beforeEach(inject(function($rootScope,_$controller_,_$state_,_$timeout_,_transactModel_,$window){				
		$controller = _$controller_;
		$scope = $rootScope.$new();
		$state = _$state_;
		$timeout = _$timeout_;
		transactModel = _transactModel_;
		$window = $window;
		$window.ga = function(){};
		invTransactMasterCtrl = $controller('invTransactMasterCtrl', { $scope: $scope });
		$scope.config.fromState = $state.current.name;
        spyOn($state, 'go');
	}));	

	it('should be defined', function() {
        expect(invTransactMasterCtrl).toBeDefined();        
    });

	it('should define the video url and header text', function() {
        expect($scope.videoUrl).not.toBe('');
        expect($scope.header).toBeDefined();
    });    

    it('should listen NAVIGATE_TO_TRANSACT on trigger and redirects to corresponding state',function(){
        $scope.$broadcast('NAVIGATE_TO_TRANSACT',{key: 'switch'});
    	expect($scope.config.param.key).toBe('switch');    	
    	expect(transactModel.getStateValue().key).toBe('switch');    	
    	expect($state.go).toHaveBeenCalled();
        expect($state.go).toHaveBeenCalledWith($scope.config.toState,$scope.config.param);
    });

    it('should trigger Go_To_Payment_Dtls',function(){    	
        spyOn($scope, '$emit');     
        $scope.$broadcast('NAVIGATE_TO_TRANSACT',{key: 'PaymentDetails'});
    	expect($scope.config.param.key).toBe('PaymentDetails');
    	expect(transactModel.getStateValue().key).toBe('PaymentDetails');

    	$timeout.flush();
    	expect($scope.$emit).toHaveBeenCalledWith('Go_To_Payment_Dtls');	
    });
});