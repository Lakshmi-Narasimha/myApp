"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
console.warn('DEPRECATED: please replace import of `ng2-bootstrap/ng2-bootstrap` with `ng2-bootstrap`');
__export(require('./index'));
