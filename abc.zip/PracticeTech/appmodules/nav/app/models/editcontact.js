define(['jquery', 'backbone', 'breeze'
], function ($, Backbone, Breeze) {
    var Contact = Backbone.Model.extend({
        defaults: {
        	id: undefined,
        	ctx:"Ebix",
        	type:undefined,
        	contactType:undefined,
        	nextActivityOn:undefined,
        	remarks:undefined,
        	Phones: undefined,
        	Addresses: undefined,
        	WebAddresses :undefined,
        	DriverLicence:undefined,
        	PersonContact:[],
        	EmplyerInfo:undefined,
        	employerName:undefined,
        	TobeDeletedPhone:undefined,
        	EditedPhone:undefined,
        	TobeDeletedWebAddress:undefined,
        	EditedWebAddress:undefined,
        	TobeDeletedAddress:undefined,
        	EditedAddress:undefined,
        	BusinessContact:undefined
        	
        }
    });
    var Phones = Backbone.Model.extend({
        defaults: {
        	CountryCode: undefined,
        	ElectronicDownload: "0",
        	type: "Phone",
        	PhoneType: undefined,
        	PhoneTypeDesc:undefined,
        	AreaCode:undefined,
        	Number:undefined,
        	Extension:undefined
        }
    });    

    var Addresses = Backbone.Model.extend({
        defaults: {
        	type: "Address",
        	AddressType: undefined,
        	AddressTypeDesc: undefined,
        	Line1: undefined,
        	Line2:undefined,
        	City:undefined,
        	State:undefined,
        	Postal:undefined,
        	Country:undefined,
        	ElectronicDownload:"0"
        }
    });
    
    var WebAddresses = Backbone.Model.extend({
        defaults: {
        	type: "WebAddresses",
        	WebAddressType: undefined,
        	WebAddressTypeDesc: undefined,
        	Address: undefined,
        	ElectronicDownload:"0"
        }
    });
    
    var PersonContact = Backbone.Model.extend({
        defaults: {
        	type: undefined,
        	clTitle: undefined,
        	clGreeting: undefined,
        	clSuffix: undefined,
        	clFirstNm:undefined,
        	clMidNm:undefined,
        	clLastNm:undefined,
        	clSfxTxt:undefined,
        	clHnrfNm:undefined,
        	clTaxId:undefined,
        	clCitizenShip:undefined,
        	clDob:undefined,
        	clGender:undefined,
        	clMarital:undefined,
        	clNoOfChildren:undefined,
        	clOccupation:undefined,
        	clJobTitle:undefined
        }
    });
    var BusinessContact = Backbone.Model.extend({
        defaults: {
        	type: undefined,
        	orgNm: undefined,
        	clTaxId: undefined
        }
    }); 
    
    return EventsCollection = {
    	Contact:Contact,
		Phones:Phones,
    	Addresses:Addresses,
        WebAddresses: WebAddresses,
        PersonContact: PersonContact,
        BusinessContact:BusinessContact
    };
});
