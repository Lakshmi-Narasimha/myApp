
'use strict';
var fticVideo= function ($sce) {
   
return function(recordingUrl) {
    return $sce.trustAsResourceUrl(recordingUrl);
  };

};

// $inject is necessary for minification. 

fticVideo.$inject = ['$sce'];
module.exports = fticVideo;



