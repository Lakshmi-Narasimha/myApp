/**
 * @ngdoc service
 * @name FTI Dashboard Initial Load Service
 * @requires investorDashboardDetailsModel
 * @requires eventConstants
 * @requires toaster
 * @requires dashboardConstants
 * @requires $timeout
 * @description
 *
 * - Handles the services and model for investor content details & widgets
 *
 */
'use strict';

var investorDashboardInvestServices = function(eventConstants, toaster, fticLoggerMessage, loggerConstants, $cookies, investorDashboardDetailsModel, investorEvents, $loader) {

    var investorDashboardInvestServices = {
        // _isServicesData: false,
        getInvestDetails: function(scope) {

            var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });

            function validateSuccess(data) {
                investorDashboardDetailsModel.setInvestData(data);
            }

            function handleFailure(error) {

                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | promiseFailure' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'error', 'message': message });
                if (error.data.length > 0) {
                    toaster.error(error.data[0].errorDescription);
                }
                //investorDashboardInvestServices._isServicesData = false;
            }

            function stopLoader() {
                $loader.stop();
            }
            var params ={};
            $loader.start();
            investorDashboardDetailsModel.getInvestPopUpDetails(params).then(validateSuccess, handleFailure).finally(stopLoader);
        },
         investConfirmCall: function(validateParams) {

            var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });

            function validateSuccess(data) {
                investorDashboardDetailsModel.setConfirmData(data);
            }

            function handleFailure(error) {

                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | promiseFailure' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'error', 'message': message });
                if (error.data.length > 0) {
                    toaster.error(error.data[0].errorDescription);
                }
                //investorDashboardInvestServices._isServicesData = false;
            }

            function stopLoader() {
                $loader.stop();
            }
            var params ={};
            $loader.start();
            investorDashboardDetailsModel.postConfirmInvestDetails(validateParams).then(validateSuccess, handleFailure).finally(stopLoader);
        }
    };
    return investorDashboardInvestServices;
};

investorDashboardInvestServices.$inject = ['eventConstants', 'toaster', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'investorDashboardDetailsModel', 'investorEvents', '$loader'];
module.exports = investorDashboardInvestServices;
