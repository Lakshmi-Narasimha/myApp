// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GuestDetailsModelSchema = new mongoose.Schema({
    guestDetailsResp: {
        type: Array,
        "default": []
    }
});

var GuestDetailsModelLookUp = mongoose.model('GuestDetailsModelLookUp', GuestDetailsModelSchema);

var GetTxnStpModel = new GuestDetailsModelLookUp({
    guestDetailsResp : {
      "guId": "guId",
      "mobile": "mobile",
      "emailId": "emailId",
      "otpFlag": "otpFlag", 
      "otpType": "otpType", 
      "refNo": "refNo", 
      "accessToken": "accessToken"
    }
});

GuestDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GuestDetailsModelLookUp table, please contact admin...');
    } else {
        GuestDetailsModelLookUp.remove({}, function(err) {
            console.log('GuestDetailsModelLookUp collection removed');
            GetTxnStpModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GuestDetailsModelLookUp table, please contact admin...');
                }
                console.log('GuestDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GuestDetailsModelLookUp;