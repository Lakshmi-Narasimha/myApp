/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var panAndDOBDetails = function($timeout,constants,advisorRegistrationModelService,$filter) {
	return {
            template: require('./panAndDOBDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
                formObj:'='
            },
            controller: function($scope, $element, $attrs){
                $scope.dateOptions = {
                    yearRows: 3,
                    yearColumns: 4,
                    fulldatepickerMode:'year',
                    formatMonth: 'MMM',
                    formatYear: 'yyyy',
                    formatDayTitle: 'MMM yyyy',
                    monthColumns: 4,
                    datepickerMode: 'day',
                    showWeeks: false
                }
                $scope.formData={};
                $scope.panObject = {
                     key : 'pan',
                     text : 'Pan',
                     value : '',
                     name : 'pan',
                     isRequired: true,
                     type: 'text'
                }
                $scope.$on('panAndDobsubmitted',function(event){
                    /*alert("submitted")*/
                $scope.formData.panARN=$scope.panObject.value;
                $scope.formData.dobOrRegDate =$filter('date')($scope.startDate, "dd/MM/yyyy");
                advisorRegistrationModelService.setPanAndDOBData($scope.formData);
              });
                
            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

panAndDOBDetails.$inject = ['$timeout','constants','advisorRegistrationModelService','$filter'];
module.exports = panAndDOBDetails;