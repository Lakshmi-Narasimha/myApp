// getPanView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var PanViewSchema = new mongoose.Schema({
    viewData: {
        type: Array,
        'default': []
    }
});

var PanViewLookUp = mongoose.model('InvPanViewLookup', PanViewSchema);

var PanViewModel = new PanViewLookUp({
    'viewData': [{
        'unitHolderDetails': {
            'invName': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
            'address': {
                'address1': 'BUDHA VILLAGE PO ASANSOL',
                'address2': 'OPP SITE SAMTHAR PETROL PUMP',
                'address3': 'MAYUR VIHAR PHASE III',
                'address4': 'HYDERABAD AP 500028',
                'city': 'DOMEIVALI',
                'pinCode': '400062',
                'line1': null,
                'line2': null,
                'line3': null
            },
            'status': null,
            'modeofOperation': null,
            'bankDetails': null,
            'modeofpayment': null
        },
        'aumSplitDetails': {
            'chartData': [{
                'fund': '92755.57',
                'fundCategory': 'ELSS',
                'percentage': '75.93%'
            }, {
                'fund': '0',
                'fundCategory': 'EQUITY',
                'percentage': '0%'
            }, {
                'fund': '0',
                'fundCategory': 'FIXED INCOME',
                'percentage': '0%'
            }, {
                'fund': '0',
                'fundCategory': 'HYBRID',
                'percentage': '0%'
            }, {
                'fund': '0',
                'fundCategory': 'INTERNATIONAL',
                'percentage': '0%'
            }, {
                'fund': '29408.34',
                'fundCategory': 'LIQUID',
                'percentage': '24.07%'
            }],
            'totalAUM': '122163.91'
        },
        'portfolioDetails': {
            'rows': [{
                'folioId': '17877097',
                'holidingType': 'Single',
                'currentCost': '82498.74',
                'currentValue': '122163.91',
                'accessLevel': 'View',
                'returns': '25%'
            }, {
                'folioId': '27877097',
                'holidingType': 'Single',
                'currentCost': '82498.74',
                'currentValue': '122163.91',
                'accessLevel': 'View',
                'returns': '25%'
            }],
            'grandTotal': {
                'totalUnits': null,
                'folioId': 'GRAND TOTAL',
                'account': null,
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        },
        'investmentSummary': [{
            'folioId': '17877097',
            'rows': [{
                'accountNo': '1349904865101',
                'scheme': 'Franklin India Taxshield - Growth',
                'totalUnits': '219.347',
                'currentCost': '59998.89',
                'currentValue': '92755.57',
                'returns': '20.46%',
                'goal': null
            }, {
                'accountNo': '2389904865101',
                'scheme': 'Franklin India Bluechip Fund - Growth',
                'totalUnits': '0.000',
                'currentCost': '0.00',
                'currentValue': '0.00',
                'returns': '0%',
                'goal': null
            }, {
                'accountNo': '4379904865101',
                'scheme': 'Franklin India Prima Plus - Growth',
                'totalUnits': '66.411',
                'currentCost': '22499.85',
                'currentValue': '29408.34',
                'returns': '16.81%',
                'goal': null
            }],
            'modeofHolding': 'Single',
            'holders': [{
                'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'grandTotal': {
                'totalUnits': '285.758',
                'folioId': null,
                'account': 'GRAND TOTAL',
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        },{
            'folioId': '27877097',
            'rows': [{
                'accountNo': '1134990486511',
                'scheme': 'Franklin India Taxshield - Growth',
                'totalUnits': '219.347',
                'currentCost': '59998.89',
                'currentValue': '92755.57',
                'returns': '20.46%',
                'goal': null
            }, {
                'accountNo': '11389904865101',
                'scheme': 'Franklin India Bluechip Fund - Growth',
                'totalUnits': '0.000',
                'currentCost': '0.00',
                'currentValue': '0.00',
                'returns': '0%',
                'goal': null
            }, {
                'accountNo': '11379904865101',
                'scheme': 'Franklin India Prima Plus - Growth',
                'totalUnits': '66.411',
                'currentCost': '22499.85',
                'currentValue': '29408.34',
                'returns': '16.81%',
                'goal': null
            }],
            'modeofHolding': 'Married',
            'holders': [{
                'name': 'JASMINE POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'grandTotal': {
                'totalUnits': '285.758',
                'folioId': null,
                'account': 'GRAND TOTAL',
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        }]
    }]
});

PanViewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PanViewLookUp table, please contact admin...');
    } else {
        PanViewLookUp.remove({}, function() {
            console.log('PanViewLookUp collection removed');
            PanViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating PanViewLookUp table, please contact admin...');
                }
                console.log('PanViewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PanViewLookUp;
