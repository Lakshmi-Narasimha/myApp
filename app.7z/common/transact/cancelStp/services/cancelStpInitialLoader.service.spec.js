'use strict';
describe('Services: fticCancelStpInitialLoader', function() {
	var cancelSipInitialLoader,fticCancelStpFundDetailsModel,httpBackend,$window,selectInvestorModel,scope,transactEvents,toaster;

	var fundDetailsResponse = {
	"stpSummary": [
		{
			"trxnNo": "SS000176",
			"totalInsallNo": "155",
			"startDate": "28/11/2010",
			"sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
			"sourceAccNo": "1689900886175",
			"nextTiggerDate": "28/04/2017",
			"frequency": "Monthly",
			"endDate": "28/10/2019",
			"destFundDesc": "Franklin India Savings Plus Fund Retail Option",
			"destAccNo": "1729900886175",
			"cancelDate": "28/04/2017",
			"balInsallNo": "31",
			"amount": "2000",
			"alertFlag": "Y",
			"alertDays": "7"
		},
		{
			"trxnNo": "SS000976",
			"totalInsallNo": "90",
			"startDate": "07/12/2010",
			"sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
			"sourceAccNo": "1689900886175",
			"nextTiggerDate": "07/05/2017",
			"frequency": "Monthly",
			"endDate": "07/10/2019",
			"destFundDesc": "Franklin India Savings Plus Fund Retail Option",
			"destAccNo": "1729900886175",
			"cancelDate": "07/05/2017",
			"balInsallNo": "30",
			"amount": "2000",
			"alertFlag": "N",
			"alertDays": "7"
		},
		{
			"trxnNo": "SS000976",
			"totalInsallNo": "90",
			"startDate": "07/12/2010",
			"sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
			"sourceAccNo": "1689900886175",
			"nextTiggerDate": "07/05/2017",
			"frequency": "Monthly",
			"endDate": "07/10/2019",
			"destFundDesc": "Franklin India Savings Plus Fund Retail Option",
			"destAccNo": "1729900886175",
			"cancelDate": "07/05/2017",
			"balInsallNo": "30",
			"amount": "2000",
			"alertFlag": "N",
			"alertDays": "7"
		}
	],
	"folioId": "14512366"
	};

	var selectedInvestor = {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 14512366,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

    beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function(fticCancelStpInitialLoader,_fticCancelStpFundDetailsModel_,_toaster_,$httpBackend,_$window_,_transactEvents_){
		cancelSipInitialLoader = fticCancelStpInitialLoader;
		fticCancelStpFundDetailsModel = _fticCancelStpFundDetailsModel_;
		toaster = _toaster_;
		httpBackend = $httpBackend;						
		transactEvents = _transactEvents_;
		
		$window = _$window_;
        $window.ga = function() {};

		scope ={
			'$broadcast': function() {
	            return true;
	        }
	    };
	}));	

	it("loadAllServices should be defined",function(){
		expect(cancelSipInitialLoader.loadAllServices).toBeDefined();
	});

	it("should loadAllServices and check for success ",function(){
		spyOn(transactEvents.transact,"publishInvFundGrid");
		httpBackend.expectGET('http://localhost:3030/clients/stpSummary?folioId=14512366&guId=878').respond(200,fundDetailsResponse);

		cancelSipInitialLoader.loadAllServices(scope,selectedInvestor);
		httpBackend.flush();		
		expect(fticCancelStpFundDetailsModel.getSelectFundGridDtls()).toEqual(fundDetailsResponse.stpSummary);
		expect(fticCancelStpFundDetailsModel.getSelectFundDtls().stpSummary).toEqual(fundDetailsResponse.stpSummary);		
		expect(transactEvents.transact.publishInvFundGrid).toHaveBeenCalledWith(scope);
	});	

	it("should loadAllServices and check for failure ",function(){
		spyOn(toaster,"error");
		httpBackend.expectGET('http://localhost:3030/clients/stpSummary?folioId=14512366&guId=878').respond(400,failureResponse);

		cancelSipInitialLoader.loadAllServices(scope,selectedInvestor);

		httpBackend.flush();		
		expect(toaster.error).toHaveBeenCalledWith(failureResponse[0].errorDescription);
	});	
});