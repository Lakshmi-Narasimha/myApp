/**
 * @ngdoc service
 * @name eform model service
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Eform Model deals with the fetching data from the service and returning the promise object as well as setting and getting the data. 
 *
 */

'use strict';

var advisorRegistrationModel = function ($http,fticLoggerMessage, loggerConstants, Restangular, $q,appConfig, configUrlModel) {
    var _usertype=null;
    var _arndata = null;
    var _pananddobdata=null;
    var _securityansdata=null;
    var _unamedata=null;
    var _forgottypedata=null; 
    var _sendOTPCall = null;
    var _moduelType = null;
    var _userData = null;
    var _userDetails = null;
   
 
   
    var advisorRegistrationModel = {
       
        postArnDetails : function (param) {
           
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'validateARNDetails', param).then( function (data) {
                deferred.resolve(data); 
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
         
            return deferred.promise;
        },
        postRequestForSavingArnDetails : function (param) {
           
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'saveARNDetails', param).then( function (data) {
                deferred.resolve(data);
           
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });

          
            return deferred.promise;
        },


        loadAdviserDetails : function(param){
              var deferred = $q.defer();
              var configURL = configUrlModel.getEnvUrl('PROXY_URL');
              $http.post(appConfig[configURL] + 'loadAdvisorRegistrationDetails', param).then(function(data){
                    deferred.resolve(data);
              }, function(data){
                  deferred.reject(data);
              });

              return deferred.promise;
        },


         postRequestForOtpDetails : function (param) { 
            
            var deferred = $q.defer();
        
            Restangular.one('services/generateAndSendOTP').customPOST("","",param,{}).then(function (success) {
                deferred.resolve(success);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });

            return deferred.promise;
        },
         postOtpDetails : function (param) {
             var deferred = $q.defer();
            
            Restangular.one('services/validateOTP').get(param,"").then(function (validateOTP) {
                console.log(validateOTP);
                deferred.resolve(validateOTP);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });

            return deferred.promise;
        },
        postAnsForSecurityQn : function (param) {
             var deferred = $q.defer(); 
             Restangular.one("profile/forgotUsrPwd").get(param,"").then(function(data){
              deferred.resolve(data);
             },function(resp){
              deferred.reject(resp); 
             }); 
            return deferred.promise;
        },
         postArnOrDobForFUNameDetails : function (param) {
         
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'forgotUserName', param).then( function (data) {
                deferred.resolve(data);
           
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
         
            return deferred.promise;
        },
        postUNAndDobFUNameDetails : function (param) {
      
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'forgotPassword', param).then( function (data) {
                deferred.resolve(data);
           
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
        
            return deferred.promise;
        },

        postPassword : function (param){
           var deferred = $q.defer();
           var configURL = configUrlModel.getEnvUrl('PROXY_URL');
           $http.post(appConfig[configURL] + 'resetPassword', param).then( function(data) {
                 deferred.resolve(data);
           }, function(resp) {
               deferred.reject(resp);
           });
           return deferred.promise;
        },
 
        postAcknowledgeCall : function(){
            var deferred=$q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'invalidateForgotUserIdToken').then( function(data){
                 deferred.resolve(data);
            }, function(resp){
                 deferred.reject(resp);
            });
            return deferred.promise;
        },

        setUserData : function(data){
            _userData = data;
        },

        getUserData : function(){
            return _userData;
        },

        setUserDetails : function(data){
           _userDetails = data;
        },

        getUserDetails : function(){
          return _userDetails;
        },

        setUserType : function(data){ 
            _usertype = data;
         },
        getUserType : function(){
            return _usertype;
        },
 
         setArnData : function(data){ 
            _arndata = data;
         },
        getArnData : function(){
            return _arndata;
        },
         setPanAndDOBData : function(data){ 
            _pananddobdata = data;
         },
        getPanAndDOBData : function(){
            return _pananddobdata;
        },
         setSecurityAnsData : function(data){ 
            _securityansdata = data;
         },
        getSecurityAnsData : function(){
            return _securityansdata;
        },
        
        setUNameData : function(data){ 
            _unamedata = data;
        },
        getUNameData : function(){
            return _unamedata;
        },

        setUserForgotTypeDetails : function(data){ 
            _forgottypedata = data;
         },
        getUserForgotTypeDetails : function(){
            return _forgottypedata;
 
        } 


    };
    return advisorRegistrationModel;
};

advisorRegistrationModel.$inject = ['$http','fticLoggerMessage', 'loggerConstants', 'Restangular','$q','appConfig', 'configUrlModel'];

module.exports = advisorRegistrationModel;