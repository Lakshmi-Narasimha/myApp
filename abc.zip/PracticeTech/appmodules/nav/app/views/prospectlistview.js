define([
  'jquery',
  'underscore',
  'backbone',
  'config',
  'spinner',
  'services/dataservice',
  'appcommon/constants',
  'appcommon/globalcontext',
  'appcommon/commonutility',
  'appmodules/nav/app/models/contactdetails',
  'text!appmodules/nav/app/templates/contactlistshell.html',
   'text!appmodules/nav/app/templates/prospectlist.html',
   'text!appmodules/nav/app/templates/prospectlistdetails.html',
   'text!appmodules/nav/app/templates/prospectlistoverthousand.html',
   'text!appmodules/nav/app/templates/prospectdetailsoverthous.html',
   'appcommon/analytics',
   'errorLog',
   'apipublic/navapi',
], function ($, _, Backbone, Config, Spinner, Dataservice, Constants, GlobalContext, Utility, ContactDetailsModel, ContactlistShellTemplate, ProspectlistTemplate, ProspectlistDetailsTemplate, ProspectOverThouTemplate, ProspectDetailsOverThous, Analytics, ErrorLog, NavApi) {
    var prospectlist = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click .sorting": "sortContactList",
            "click .cl-actions": "showDetails",
            "click .vertical-div a": "showContactSubSection",
            "click .add-contact": "showAddContactPage",
            "click .edit-contact": "showEditContactPage",
            "click #cl-modal .modal-footer": "hideclmodal",
            "click #contactlist-nav": "clNavBtnClick",
            "click #ClientBtn": "clientBtnClick",
            "click #ProspectBtn": "prospectBtnClick"
        },

        initialize: function () {
            var _that = this;
            this.prospectList = [];
            this.globalContext = GlobalContext.getInstance();
            this.counter = 0;
            this.timer = null;
            this.eleId = 0;
            this.clLnks = undefined;
            $(window).on("scroll", this.adjustContactBar);
            $(window).on("orientationchange", function () {
                if ($("#cl-modal").is(":visible")) {
                    setTimeout(function () {
                        var clmaxheight = _that.adjustclmodal();
                        $("#cl-modal .modal-body").css({ "max-height": clmaxheight + "px" });
                    }, 300);
                }
            });
            $(window).resize(function () {
                if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
                    if ($("#cl-modal").is(":visible")) {
                        var clmaxheight = _that.adjustclmodal();
                        $("#cl-modal .modal-body").css({ "max-height": clmaxheight + "px" });
                    }
                }
            });
            $(document).off("click", ".cl-alpha-header").on("click", ".cl-alpha-header", function (e) { _that.toggleProspectList(e) });
        },

        clNavBtnClick: function (e) {
            $('#cl-btns-section').slideToggle('slow');
        },
        clientBtnClick: function (e) {
            //this.linkActive(this.clLnks, e.target.id);
            $('#cl-btns-section').slideToggle('slow');
            Backbone.history.navigate('navigator/contactlist', true);
        },

        prospectBtnClick: function (e) {
            //this.linkActive(this.clLnks, e.target.id);
            $('#cl-btns-section').slideToggle('slow');
            Backbone.history.navigate('navigator/prospectlist', true);
        },


        toggleProspectList: function (e) {
            var target = e.target || e.currentTarget;
            $(".cl-alpha-header").each(function (e) {
                var $that = this;
                if ($that !== target) {
                    if ($($that).hasClass("cl-opened")) {
                        $($that).parent().parent().next().slideUp(250);
                        $(".contact-list-wrapper div").remove();
                        $($that).removeClass("cl-opened").addClass("cl-closed");
                    }
                }
            });
            var data = $(target).data("target");
            var collapsable = $("#" + data);
            if ($(target).hasClass("cl-closed")) {

                // Integration code
                Spinner.show();
                var _that = this;
                var fmid = Utility.readCookie('FMID');
                var keyWord = data.slice(7);
                var lastLetter = keyWord;
                var firstLetter = String.fromCharCode(lastLetter.charCodeAt(0) + 1);

                if (lastLetter == 'Z') {
                    firstLetter = ']';
                }
                Dataservice.getNonClientsForMoreThanThou(fmid, firstLetter, lastLetter).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);

                function gotoAsyncCallSuccess(result) {
                    var _actualRow = result.Contact;
                    //Filling results to the common Navigator contact repository
                    ContactDetailsModel.advsiorContacts.AddContactDetailsFromContactList(fmid, _actualRow, Constants.contactType.NonClient, true);
                    if (_actualRow && _actualRow.length > 0) {
                        _actualRow.sort(Utility.sortMultiColumn({
                            name: 'lastNm',
                            reverse: false
                        }, 'firstNm'));
                    }

                    _that.prospectList = _actualRow;
                    var compiledDetailsTemplate = _.template(ProspectDetailsOverThous);
                    collapsable.html(compiledDetailsTemplate({ row: _actualRow }));
                    Spinner.hide();
                };
                function gotoAsyncCallError(Error) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.myError(Error);
                };
                collapsable.slideDown(250);
                $(target).removeClass("cl-closed");
                $(target).addClass("cl-opened");
                setTimeout(function () {
                    window.scrollTo(0, $(target).offset().top);
                }, 300);
            } else {
                collapsable.slideUp(250);
                $(".contact-list-wrapper div").remove();
                $(target).addClass("cl-closed");
                $(target).removeClass("cl-opened");
            }
        },
        showAddContactPage: function () {
            Analytics.analytics.processNavSubRouteChangeEvent('addContact');
            Backbone.history.navigate("navigator/addcontact", true);
        },
        showEditContactPage: function () {
            Analytics.analytics.processNavSubRouteChangeEvent('editContact');
            Backbone.history.navigate("navigator/editcontact", true);
        },
        hideclmodal: function (e) {
            $("#cl-modal").modal('hide');
            var _top = $("body").css("top");
            var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
            $('body').removeAttr('style');
            $(window).scrollTop(_bodytop);
            $($(".fc-agenda-divider.fc-widget-header").next()[0]).css({ "overflow-y": "auto", "-webkit-overflow-scrolling": "touch" });
            //$('html,body').animate({ scrollTop : $("#" +this.eleId).offset().top}, 0);
            //$(window).scrollTop(clmodaloffset);
        },

        adjustContactBar: function (e) {
            //var barHeight = $('.top-nav-header').height();
            //var navBarHeight = $('#afinav-navbar').height();
            //var offsetHeight = barHeight + navBarHeight;
            var offsetHeight = $('.top-nav-header').height() + $('#afinav-navbar').height();
            var scrollTopHeight = $(this).scrollTop();
            var totalOffset = scrollTopHeight - offsetHeight;
            if (scrollTopHeight >= offsetHeight) {
                $('.vertical-div').css("margin-top", -(offsetHeight - 10));
            }
            else {
                $('.vertical-div').css("margin-top", "10px");
            }
        },

        //Dynamic POPUP Height Calculations

        adjustclmodal: function (e) {
            var _ofsetheight = 0;
            var _clmodalheight = window.innerHeight;
            if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
                if ($(window).width() > $(window).height()) {
                    _offsetHeight = 84;
                }
                else if ($(window).height() > $(window).width()) {
                    _offsetHeight = 114;
                }
            }
            else {
                _offsetHeight = 84;
            }
            var reqmodalheight = _clmodalheight - _offsetHeight;
            return reqmodalheight;
        },

        showDetails: function (e) {
            try {
                var _that = this;
                var _target = e.target || e.currentTarget;
                _that.eleId = $(_target).parent().parent().attr("id");
                var _selectedClient = $(_target).parent().parent().data("clientid");
                var _selectedIndex = $(_target).parent().parent().data("index");
                var _selectedAction = $(_target).data("action");
                var _selectedClientname = $.trim($(_target).parent().parent().find("div:first").text());
                var _serviceCallsStack = [];
                function renderContactDetails(details) {
                    var compiledTemplate = _.template(ProspectlistDetailsTemplate);
                    $("#cl-modal-body").html(compiledTemplate({ name: _selectedClientname, details: details })).promise().done(function () {
                        $(".cl-pop-details").hide();
                        $("." + _selectedAction).show();
                        setTimeout(function () {
                            $("#cl-modal").modal('show');
                            var clmaxheight = _that.adjustclmodal();
                            $("#cl-modal .modal-body").css({ "max-height": clmaxheight + "px" });
                        }, 400);
                        var clmodaloffset = $(window).scrollTop();
                        $('body').css({
                            'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top': -(clmodaloffset)
                        });
                        $($(".fc-agenda-divider.fc-widget-header").next()[0]).css("overflow-y", "hidden");
                        //            			$('#cl-modal').on('hide.bs.modal', function (e) {
                        //            				var dialogName;
                        //            				if (_selectedAction == 'cl-email-details') {
                        //            					dialogName = 'email';
                        //            				} else if (_selectedAction == 'cl-tel-details') {
                        //            					dialogName = 'telephone';
                        //            				} else if (_selectedAction == 'cl-loc-details') {
                        //            					dialogName = 'location';
                        //            				};
                        //            				Analytics.analytics.recordAction('NavShowContactList:' + dialogName + 'DialogClosed');
                        //            			});
                        if (_selectedAction == 'cl-email-details') {
                            Analytics.analytics.recordAction('NavShowContactListEmail:clicked');
                        } else if (_selectedAction == 'cl-tel-details') {
                            Analytics.analytics.recordAction('NavShowContactListTelephone:clicked');
                        } else if (_selectedAction == 'cl-loc-details') {
                            Analytics.analytics.recordAction('NavShowContactListLocation:clicked');
                        }
                    });
                }

                function gototClientProfileSuccess(result) {
                    var ebixProfileInfo = result[0];

                    if (ebixProfileInfo) {
                        _that.prospectList[_selectedIndex].Phones = ebixProfileInfo['attributes']['Phones'];
                        //Sort on the basis of Preferred indicator
                        if (_that.prospectList[_selectedIndex].Phones && _that.prospectList[_selectedIndex].Phones.length > 0) {
                            _that.prospectList[_selectedIndex].Phones.sort(function (key, row) {
                                if (row.get("Preferred") == "1") {
                                    return 1;
                                }
                            });
                        }
                        _that.prospectList[_selectedIndex].WebAddresses = ebixProfileInfo['attributes']['WebAddresses'];
                        //Sort on the basis of Preferred indicator
                        if (_that.prospectList[_selectedIndex].WebAddresses && _that.prospectList[_selectedIndex].WebAddresses.length > 0) {
                            _that.prospectList[_selectedIndex].WebAddresses.sort(function (key, row) {
                                if (row.get("Preferred") == "1") {
                                    return 1;
                                }
                            });
                        }
                        _that.prospectList[_selectedIndex].Addresses = ebixProfileInfo['attributes']['Addresses'];
                        //Sort on the basis of Preferred indicator
                        if (_that.prospectList[_selectedIndex].Addresses && _that.prospectList[_selectedIndex].Addresses.length > 0) {
                            _that.prospectList[_selectedIndex].Addresses.sort(function (key, row) {
                                if (row.get("Preferred") == "1") {
                                    return 1;
                                }
                            });
                        }
                    }
                    renderContactDetails(_that.prospectList[_selectedIndex]);
                    Spinner.hide();
                }

                if (_selectedClient && _selectedIndex > -1) {
                    Spinner.show();
                    Dataservice.getNonClientsForContactList(Utility.readCookie('FMID'), false, Config.contactListLimit)
                        .then(function (response) {
                            Dataservice.getNonClientEbixDetails(Utility.readCookie('FMID'), _selectedClient)
                                .then(function (response) {
                                    if (response && response.length > 0) {
                                        gototClientProfileSuccess(response);
                                    }
                                })
                                .fail(function (error) {
                                    Spinner.hide();
                                    ErrorLog.ErrorUtils.myError(error);
                                })
                        })
                        .fail(function (error) {
                            Spinner.hide();
                            ErrorLog.ErrorUtils.myError(error);
                        })
                }
            } catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        },
        sortContactList: function (e) {
            try {
                var $this = $(e.currentTarget);
                var $thisSpan = $this.find("span.sorticons");
                var sortOrder = "";
                var sortField = $this.attr('data-sort');
                if (!$this.hasClass("reset-sorting")) {
                    if ($thisSpan.hasClass("desc-icon")) {
                        $thisSpan.removeClass("desc-icon").addClass("asc-icon").addClass("act");
                        sortOrder = "asc";
                    }
                    else if ($thisSpan.hasClass("asc-icon")) {
                        $thisSpan.removeClass("asc-icon").addClass("desc-icon").addClass("act");
                        sortOrder = "desc";
                    }
                    else {
                        $thisSpan.addClass("asc-icon").addClass("act");
                        sortOrder = "asc";
                    }
                }
                $(".sorting").each(function () {

                    var $innerThisSpan = $(this).find('span.sorticons');
                    if (!$thisSpan.is($innerThisSpan) && $innerThisSpan.hasClass("act")) {
                        if ($innerThisSpan.hasClass("asc-icon")) {
                            $innerThisSpan.removeClass("asc-icon").removeClass("act");
                        }
                        if ($innerThisSpan.hasClass("desc-icon")) {
                            $innerThisSpan.removeClass("desc-icon").removeClass("act");
                        }
                    }

                });
            } catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }

        },
        showContactSubSection: function (e) {
            try {
                var _target = e.target || e.currentTarget;
                var _subSecId = $(_target).data("sub-section");
                window.scrollTo(0, $('#' + _subSecId).offset().top);
            } catch (e) {
                ErrorLog.ErrorUtils.info({ msg: "No contact found for the selected section." });
            }

        },
        applyaSortToContacts: function (contacts) {
            if (contacts && contacts.length > 0) {
                contacts.sort(function (r1, r2) {
                    if (r1.lastNmFmtd === "") {
                        return -1;
                    }
                    if (r1.lastNmFmtd && r2.lastNmFmtd && r1.lastNmFmtd.toUpperCase() > r2.lastNmFmtd.toUpperCase()) {
                        return 1;
                    }
                    if (r1.lastNmFmtd && r2.lastNmFmtd && r1.lastNmFmtd.toUpperCase() < r2.lastNmFmtd.toUpperCase()) {
                        return -1;
                    }
                    // r1 must be equal to r2
                    return 0;
                });
            }
        },
        processProspectList: function (advisorId) {
            try {
                var _that = this;

                Dataservice.getNonClientsForContactList(advisorId, false, Config.contactListLimit).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);

                function gotoAsyncCallSuccess(result) {
                    var generalTemplate = _.template(ContactlistShellTemplate);
                    _that.$el.html(generalTemplate());
                    $("#cl-btns-section div").removeClass("hdr-tab-active");
                    $("#cl-btns-section .cl-prospectBtn-Cntr").addClass("hdr-tab-active");
                    _that.clLnks = $("#cl-menu-list > div > a");
                    var prospectRecordList = result.Contact;
                    //Filling results to the common Navigator contact repository
                    ContactDetailsModel.advsiorContacts.AddContactDetailsFromContactList(advisorId, prospectRecordList, Constants.contactType.NonClient, true);
                    var compiledProspectList = _.template(ProspectlistTemplate);
                    var compiledProspectOverThou = _.template(ProspectOverThouTemplate);
                    //Sort prospect list
                    if (prospectRecordList && prospectRecordList.length > 0) {
                        prospectRecordList.sort(Utility.sortMultiColumn({
                            name: 'lastNm',
                            reverse: false
                        }, 'firstNm'));
                    }

                    _that.prospectList = prospectRecordList;
                    if (result.count < 1000) {
                        $(".cl-list-container").html(compiledProspectList({ prospectList: prospectRecordList }));
                    } else {
                        $(".cl-list-container").html(compiledProspectOverThou({ prospectList: prospectRecordList }));
                    }

                    Spinner.hide();
                }

                function gotoAsyncCallError(err) {
                    Spinner.hide();
                }
            } catch (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.myError(error);
            }
        },
        render: function () {
            try {
                var advisorId = Utility.readCookie('FMID');
                var _that = this;
                Spinner.show();
                _that.processProspectList(advisorId);
            } catch (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.myError(error);
            }
        }
    });
    return prospectlist;
});