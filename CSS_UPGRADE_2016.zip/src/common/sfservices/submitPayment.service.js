/**
 * @ngdoc service
 * @name submitPaymentDetailsService
 * @description
 *
 * - SubmitPaymentDetails JSON  / Method
 */
/*global Visualforce*/
(function() {
    'use strict';

    angular.module('CSS.common').service('submitPaymentDetailsService', ['$http', '$q', function($http, $q) {

        this.submitPaymentDetails = function(queryData) {
            var deferred = $q.defer();
            Visualforce.remoting.Manager.invokeAction('CSS_SelfRegController.submitPaymentDetails', queryData,
                function(result, event) {
                    if (event.status) {
                        deferred.resolve(JSON.parse(result));
                    } else {
                        deferred.reject(event);
                    }
                }, {
                    escape: false
                });

            return deferred.promise;
        };        
        
    }]);

})();