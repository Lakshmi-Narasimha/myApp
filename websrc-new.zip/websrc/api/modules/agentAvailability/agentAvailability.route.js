var express = require('express');
var https = require('https');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var proxy = require('../../../config/proxy')
var router = express.Router();
var agentAvailabilityModel = require('./agentAvailability.model');
var apiLPUtils = require('../../common/apiLPUtils');
var apiUtils = require('../../common/apiUtils');

// api route
router.route('/mfchatnode/rest/agent')
    .post(function(req, res) { 
        logger.tag.info(logger.tagsInfo({"this":"ahmed"}));       
        if(req.session.statusCounter && req.session.statusCounter >= 6){
            req.session.statusCounter = 0;
        }
        if(req.session.statusCounter === 0){
             req.session = req.session.regenerate(function(err) {});
        }else{
            req.session = req.session;
        }
        //req.session.statusCounter = (req.session.statusCounter+1 || 1);
        req.session.statusCounter = (req.session.statusCounter+1 || 1);
        req.session.agentGroupIDNum = agentAvailabilityModel.agentGroupIDNum[req.body.RequestParams.agentGroupID];
        logger.general.info(logger.formatInfoMsg(req.session.id, "Agent Call #"+ req.session.statusCounter));
        logger.general.info(logger.formatInfoMsg(req.session.id, " #AgentRequest " + " #AgentGroupId: " +req.body.RequestParams.agentGroupID));        
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.body.RequestParams = req.body.RequestParams || {};
        req.uri = agentAvailabilityModel.createRequestUri[req.body.RequestParams.agentGroupID];
        req.session.tagBody = req.body.RequestParams.agentGroupID;
        req.session.channel = req.body.RequestParams.channel ? req.body.RequestParams.channel.toUpperCase().replace(/ /g, '') : '';
        if(req.session.channel){
            logger.general.info(logger.formatInfoMsg(req.session.id, "Channel#"+ req.session.channel));
        }else{
            logger.general.info(logger.formatInfoMsg(req.session.id, "Channel# Mobile_App"));
        }
        //req.session.channel = 'ASKVERIZON';
        if(req.body.RequestParams.agentGroupID === 'TMPCUST'){
            req.session.isTMP = true;
            if(req.session.statusCounter === 1){
                apiLPUtils.baseURLCall(req, res, function(chunk){
                    chunk = JSON.parse(chunk);
                    if(chunk && chunk.account && chunk.account.link){
                        var links = chunk.account.link;
                        for( var link of links){
                            if(link['@rel'] === 'chat-availability'){
                                req.session.chat_availability = link['@href']+'?v=1';
                                logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat_availability: "+ req.session.chat_availability));
                            }else if(link['@rel'] === 'chat-request'){
                                req.session.chat_request = link['@href']+'?v=1';
                                logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat-request: "+ req.session.chat_request));
                            }
                        }
                        if(req.session.chat_availability){
                            apiLPUtils.availabilityCall(req, res, function(chunk){
                                chunk = JSON.parse(chunk);
                                if(chunk.availability === true){
                                    agentAvailabilityModel.response.Page.availability = true;
                                    agentAvailabilityModel.response.Page.inHOP = true;
                                    agentAvailabilityModel.response.Page.status = "online";
                                    agentAvailabilityModel.response.Page.agentBusy = false;
                                    agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                                    req.session.statusCounter = 0;
                                }else {
                                    agentAvailabilityModel.response.Page.availability = false;
                                    agentAvailabilityModel.response.Page.inHOP = false;
                                    agentAvailabilityModel.response.Page.status = "offline";                                   
                                    agentAvailabilityModel.response.Page.agentBusy = false;
                                    agentAvailabilityModel.response.ModuleMap.Support.msgList = [];                                    
                                }
                                logger.general.info(logger.formatInBoundResMsg(req, agentAvailabilityModel.response));
                                res.send(agentAvailabilityModel.response);res.send(agentAvailabilityModel.response);
                            });
                        }else{
                            agentAvailabilityModel.response.Page.availability = false;
                            agentAvailabilityModel.response.Page.inHOP = false;
                            agentAvailabilityModel.response.Page.status = "offline";
                            agentAvailabilityModel.response.Page.agentBusy = false;
                            agentAvailabilityModel.response.ModuleMap.Support.msgList = [];                            
                            logger.general.info(logger.formatInBoundResMsg(req, agentAvailabilityModel.response));
                            res.send(agentAvailabilityModel.response);
                        }
                    }
                });
            }else{
                 apiLPUtils.availabilityCall(req, res, function(chunk){
                    try{
                    chunk = JSON.parse(chunk);    
                    }catch(e){                
                    logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json response for the agent availability request"));
                    agentAvailabilityModel.response.Page.availability = false;
                    agentAvailabilityModel.response.Page.inHOP = false;
                    agentAvailabilityModel.response.Page.status = "offline";
                    agentAvailabilityModel.msgList[0].messageType = "stateChange";
                    agentAvailabilityModel.msgList[0].state = "401";
                    agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.msgList;
                    res.send(agentAvailabilityModel.response);
                    req.session.destroy();
                    return;
                    }
                    if(chunk.availability === true){
                        agentAvailabilityModel.response.Page.availability = true;
                        agentAvailabilityModel.response.Page.inHOP = true;
                        agentAvailabilityModel.response.Page.status = "online";
                        agentAvailabilityModel.response.Page.agentBusy = false;
                        agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                        req.session.statusCounter = 0;
                    }else {
                        agentAvailabilityModel.response.Page.availability = false;
                        agentAvailabilityModel.response.Page.inHOP = false;
                        agentAvailabilityModel.response.Page.status = "offline";
                        if(req.session.statusCounter >= 6){
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Reached max retry times, all agents are still busy, stopped calling find agent API.")); 
                            req.session.statusCounter = 0;
                            agentAvailabilityModel.response.Page.agentBusy = true;
                            agentAvailabilityModel.msgList[0].messageType = "stateChange";
                            agentAvailabilityModel.msgList[0].state = "401";
                            agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.msgList;
                            res.send(agentAvailabilityModel.response);                      
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Reached max retry times, all agents are still busy, stopped calling find agent API."));
                            req.session.tagBody.event = "Find agent tried 6 times";
                            req.session.tagBody.retryTimes = 6;
                            logger.tag.info(logger.tagsInfo(req.session.tagBody));
                            req.session.destroy();
                            return;                     
                        }else{
                            agentAvailabilityModel.response.Page.agentBusy = false;
                            agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                        }
                    }
                    logger.general.info(logger.formatInBoundResMsg(req, agentAvailabilityModel.response));
                    res.send(agentAvailabilityModel.response);
                });
            }            
        }else{
            var reqObj = {
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path,
                agent: proxy.agent,
                ca:proxy.ca,
                headers: {
                    'Cookie': req.session.sessionCookie
                }
            };
            req.session.isTMP = false;
            logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
            var proxyRequest = https.request(reqObj, function(proxyResponse) {
                var resbody = [];
                var now = new Date();
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                resbody.push(chunk);
                }).on('end', function(){
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, resbody, req.session.id));
                    try{
                    chunk = JSON.parse(resbody);    
                    }catch(e){                
                    logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid response from the Touch Commerce"));
                    logger.general.info(logger.formatInfoMsg(req.session.id, " #AgentBadResponse " + " #AgentGroupId: " + req.body.RequestParams.agentGroupID));
                    logger.tag.info(logger.tagsInfo(req.body.RequestParams));
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, resbody, req.session.id));
                    agentAvailabilityModel.response.Page.availability = false;
                    agentAvailabilityModel.response.Page.inHOP = false;
                    agentAvailabilityModel.response.Page.status = "offline";
                    agentAvailabilityModel.response.Page.agentBusy = true;
                    agentAvailabilityModel.msgList[0].messageType = "stateChange";
                    agentAvailabilityModel.msgList[0].state = "401";
                    agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.msgList;
                    res.send(agentAvailabilityModel.response);
                    req.session.destroy();
                    return;
                    }
                    chunk = chunk || {};               
                    if(chunk.availability && (chunk.availability === 'true')) {
                        agentAvailabilityModel.response.Page.availability = true;
                        agentAvailabilityModel.response.Page.inHOP = true;
                        agentAvailabilityModel.response.Page.status = "online";
                        agentAvailabilityModel.response.Page.agentBusy = false;
                        agentAvailabilityModel.response.ModuleMap.Support.msgList = [];

                    }else {
                        agentAvailabilityModel.response.Page.availability = false;
                        agentAvailabilityModel.response.Page.inHOP = false;
                        agentAvailabilityModel.response.Page.status = "offline";
                        if(req.session.statusCounter >= 6){
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Reached max retry times, all agents are still busy, stopped calling find agent API."));
                            logger.general.info(logger.formatInfoMsg(req.session.id, " #AgentNotAvailable " + " #AgentGroupId: " + req.body.RequestParams.agentGroupID));
                            req.session.statusCounter = 0;
                            agentAvailabilityModel.response.Page.agentBusy = true;
                            agentAvailabilityModel.msgList[0].messageType = "stateChange";
                            agentAvailabilityModel.msgList[0].state = "401";
                            agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.msgList;
                            req.body.RequestParams.event = "Find agent tried 6 times";
                            logger.tag.info(logger.tagsInfo(req.body.RequestParams)); 
                            res.send(agentAvailabilityModel.response);
                            req.session.destroy();
                            return;                      
                        }else{
                            agentAvailabilityModel.response.Page.agentBusy = false;
                            agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                        }
                    }
                    logger.general.info(logger.formatInBoundResMsg(req, agentAvailabilityModel.response));
                    res.send(agentAvailabilityModel.response);
                    // apiUtils.mfcTagging(req, res, function(chunk){
                    //     console.log("hittting the nlp server", chunk)
                    //     res.sendStatus(200).end();
                    // })
                });
                proxyResponse.on('error', function(err) {
                    logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                    res.send(err);

                });
            });

            proxyRequest.write(res.body + '');
            proxyRequest.end();
        }
            
        
    });

module.exports = router;
///test
// else if(now.getHours()< 19 || now.getHours()>19 && req.body.RequestParams.agentGroupID === "English_Prepaid"){
//                             agentAvailabilityModel.response.Page.availability = false;
//                             agentAvailabilityModel.response.Page.inHOP = false;
//                             agentAvailabilityModel.response.Page.status = "offline";
//                             agentAvailabilityModel.response.Page.agentBusy = true;
//                             agentAvailabilityModel.msgList[0].messageType = "stateChange";
//                             agentAvailabilityModel.msgList[0].state = "401";
//                             //agentAvailabilityModel.msgList[0].messageList[0].messageText = "Sorry, Prepaid Chat is closed.  Our hours are 6am – 11pm Eastern, Mon – Sun.  Technical support is available after hours at (888) 294-6804."
//                             agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.agentOffMsg;
//                             agentAvailabilityModel.response.ModuleMap.Support.ResponseInfo.userMessage = "No Agents are available to join";
//                             agentAvailabilityModel.response.ModuleMap.Support.ResponseInfo.topMessage = "Prepaid Chat is closed now";
//                             res.send(agentAvailabilityModel.response);
//                             req.session.destroy();
//                             return;  
//                         }