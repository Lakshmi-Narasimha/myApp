(function() {
    'use strict';
    describe('makepayment controller', function() {
        beforeEach(module('CSS.billing'));
        beforeEach(module('CSS.components'));
        var makeapaymentCtrl, $controller, billingVM, scope, timeout;
        var submitPaymentDetailsService, sendEmailService, $loader, $state, $stateParams, $httpBackend, deferred, resultObj, dataObj, dataObj1, resultObj1, EmailObj;
        // beforeEach(function() {
        //     module(function($provide) {
        //        var $window = { 
        //         // now, $window.location.path will update that empty object
        //         location: {}, 
        //         // we keep the reference to window.document
        //         document: window.document
        //     };

        //     // We register our new $window instead of the old
        //     $provide.constant( '$window' , $window );
        //     });
        // });
        beforeEach(inject(function($controller, $q, $rootScope, submitPaymentDetailsService, sendEmailService, errorDefaultConstant, billingUtils, $timeout, $injector, $state, $stateParams, $loader) {

            scope = $rootScope.$new();

            timeout = $timeout;
            $httpBackend = $injector.get('$httpBackend');
            $state = $state;
            $stateParams = $stateParams;

            resultObj = {
                "billingScheduledMaintenance": "N",
                "confirmationNumber": "16589320",
                "estimatedDowntime": "01:56:07",
                "transactionCode": null,
                "transactionDescription": null,
                "transactionStatus": "S",
                "uiErrorDipslayMessage": null,
                "paymentListNow": {
                    "isCard": null
                }
            }

            resultObj1 = {
                "transactionCode": "",
                "transactionDescription": "Success",
                "transactionStatus": "S",
                "uiErrorDisplayMessage": "Thanks!!! Email has been successfully"
            }
            /*spyOn(getPaymentDetailsSevice, 'getPaymentDetails').and.callFake(function() {
                deferred = $q.defer();
                deferred.resolve(resultObj);
                return deferred.promise;
            });*/

            // getPaymentDetailsSrv = getPaymentDetailsSevice;
            $loader = $loader;

            makeapaymentCtrl = $controller('makeapaymentCtrl', {
                $scope: scope,
                submitPaymentDetailsService: submitPaymentDetailsService,
                sendEmailService: sendEmailService,
                errorDefaultConstant: errorDefaultConstant,
                $state: $state,
                billingUtils: billingUtils,
                $stateParams: $stateParams,
                $loader: $loader,
                $rootScope: $rootScope
            });
            scope.$$listeners.$locationChangeStart = [];
        }));

        describe('makeapaymentCtrl', function() {
            it('should expect billing.makeapaymentCtrl to be defined...', function() {
                expect(makeapaymentCtrl).toBeDefined();
            })

            it('should expect billing.billingCtrl...', function() {
                expect(makeapaymentCtrl.submitResObj).toBeDefined();
            })
        });

        describe('submitPayment function to be defined', function() {
            
            dataObj = {
                "agentOfRecord": "13053T",
                "bankAccountHolderName": null,
                "bankAccountNumber": null,
                "bankAccountType": null,
                "bankOrCreditCardIndicator": "CC",
                "bankRoutingNumber": null,
                "billingAccountNumber": "T718142962",
                "cardBrand": "MC",
                "cardExpirationdate": "2022-04-01",
                "cardHolderName": "RAGHU",
                "cardNumber": "5498358115833071",
                "cardType": null,
                "cardValidFrom": null,
                "cardZipCode": "12345",
                "functionName": "Prelogin",
                "lastFourDigitofCardNumber": "3071",
                "lastFourDigitsOfBankAccountNumber": null,
                "loginId": null,
                "paymentType": "DP",
                "postedDate": "01/01/2016",
                "transactionAmount": "23000.00",
                "transactionCurrency": "USD",
                "userId": null,
                "paymentListNow": {
                    "isCard": null
                }
            }

            dataObj1 = {
                "functionName": "Prelogin",
                "userId": null,
                "loginId": null,
                "agentOfRecord": "13053T",
                "billingAccountNumber": "T718142962",
                "paymentType": "DP",
                "transactionCurrency": "USD",
                //"postedDate": null,
                "bankOrCreditCardIndicator": "EFT",
                "cardType": null,
                "lastFourDigitofCardNumber": null,
                "cardNumber": null,
                //"cardBrand": null,
                "cardValidFrom": null,
                "cardExpirationdate": null,
                "cardHolderName": null,
                "cardZipCode": null,
                "bankAccountNumber": null,
                "bankRoutingNumber": null,
                "bankAccountType": 'C',
                "bankAccountHolderName": null,
                "lastFourDigitsOfBankAccountNumber": null,
                
            };



            it('should expect billing submitPayment function & successSubmitPayment to be defined...', function() {
                              
                makeapaymentCtrl.submitPayment(dataObj, function() {
                    return true;
                });
                $httpBackend.expectPOST('http://localhost:9900/submitPaymentDetails/submitPaymentDetails', dataObj1).respond(resultObj);
                $httpBackend.expectGET('modules/billing/billing.html').respond();
                $httpBackend.expectGET('modules/billing/partials/authentication.html').respond();
                $httpBackend.flush();
                timeout.flush();

                expect(makeapaymentCtrl.submitResObj.isSubmitSuccess).toBeTruthy();
            });

            it('should expect billing submitPayment function & successSubmitPayment to be defined...', function() {
                
                resultObj.transactionStatus = "E";

                
                makeapaymentCtrl.submitPayment(dataObj, function() {
                    return true;
                });
                $httpBackend.expectPOST('http://localhost:9900/submitPaymentDetails/submitPaymentDetails', dataObj1).respond(resultObj);
                $httpBackend.expectGET('modules/billing/billing.html').respond();
                $httpBackend.expectGET('modules/billing/partials/authentication.html').respond();
                $httpBackend.flush();
                timeout.flush();

                expect(makeapaymentCtrl.submitResObj.isSubmitSuccess).toBeUndefined();
            });

            it('should expect billing submitPayment function & failureSubmitPayment to be defined...', function() {
              
                makeapaymentCtrl.submitPayment(dataObj, function() {
                    return true;
                });
                $httpBackend.expectPOST('http://localhost:9900/submitPaymentDetails/submitPaymentDetails', dataObj1).respond(404);
                $httpBackend.expectGET('modules/billing/billing.html').respond();
                $httpBackend.expectGET('modules/billing/partials/authentication.html').respond();
                $httpBackend.flush();
                timeout.flush();

                expect(makeapaymentCtrl.submitResObj.isSubmitSuccess).toBeFalsy();
            });

            // it('should expect billing submitPayment function & failureSubmitPayment to be defined...', function() {
                
            //     scope.$emit('submit-paybill', function(data) {
            //         expect(makeapaymentCtrl.submitResObj.isSubmitSuccess).toBeTruthy();
            //     })

            //     // makeapaymentCtrl.submitPayment(dataObj, function() {
            //     //     return true;
            //     // });
            //     // $httpBackend.expectPOST('http://localhost:9900/submitPaymentDetails/submitPaymentDetails', dataObj1).respond(404);
            //     // $httpBackend.expectGET('modules/billing/billing.html').respond();
            //     // $httpBackend.expectGET('modules/billing/partials/authentication.html').respond();
            //     // $httpBackend.flush();
            //     // timeout.flush();

            //     // expect(makeapaymentCtrl.submitResObj.isSubmitSuccess).toBeFalsy();
            // });

            //TO DO ABOVE suite

        });

        describe('sendEmail function to be defined', function() {

            EmailObj = {
                "userType":null,
                "userId":null,
                "sourceSystem":null,
                "policyContractNumber":null,
                "paymentMethod":"Amex(..6171)",
                "paymentDate":"01/01/2016",
                "paymentConfirmationNumber":"16589320",
                "password":null,
                "loginId":null,
                "Link_URL":null,
                "lastName":null,
                "functionName":"SendPaymentConfirmationEmail",
                "firstName":null,
                "email":"abc@xyz.com",
                "ecn":null,
                "clientNumber":null,
                "billingAccountNumber":"T718142962",
                "amountPaid":"23000.00",
                "agentLastName":null,
                "agentFirstName":null
            }
        
            
            it('should expect billing SendEmail function to be defined...', function() {
                
                makeapaymentCtrl.paymentSuccessfullData = {
                    "accountStatus": "Active",
                    "agentOfRecord": "13053T",
                    "allowPayment": true,
                    "amountPayingNow": "23000.00",
                    "billingAccountNumber": "T718142962",
                    "billingScheduledMaintenance": "N",
                    "billingview": "confirm",
                    "city": "Princeton",
                    "confirmationNumber": "16589320",
                    "payingDateNow": "01/01/2016",
                    "paymentListNow": {
                        "cardDisplayType": null,
                        "creditCardCategoryDisplay": "Amex",
                        "digitsCardNum": "6171",
                        "isCard": true
                    }
        
                }

            $httpBackend.expectPOST('http://localhost:9900/sendEmail/sendEmail', EmailObj).respond(resultObj1);
            $httpBackend.expectGET('modules/billing/billing.html').respond();
            $httpBackend.expectGET('modules/billing/partials/authentication.html').respond();
                scope.$emit('send-email', 'abc@xyz.com');

                $httpBackend.flush();
                timeout.flush();

                scope.$on('submit-email', function(data){
                    expect(data.transactionStatus).toEqual('S');
                });
                // expect(makeapaymentCtrl.submitResObj.isSubmitSuccess).toBeTruthy();
            })

            
        });
       
    })
})();