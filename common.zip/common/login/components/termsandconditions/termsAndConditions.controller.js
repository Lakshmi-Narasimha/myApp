/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

<<<<<<< HEAD
function termsAndConditionsController($scope, $uibModalStack, loginModelService, constants, tcAndSTPopupModel) {
=======
function termsAndConditionsController($scope, $uibModalStack, loginModelService, constants, tcAndSTPopupModel, advisorRegistrationModelService) {
>>>>>>> ftic-inv-sprint6


    $scope.accpted = false;
    $scope.accept = function() {

        //loginModelService.setChoosenOptionData($scope.accpted);
        $scope.$emit('accptedTermsAndConditions');
        $scope.closeModal();
    };
    $scope.doNotAccept = function() {
        $scope.$emit('rejectedTermsAndConditions');
        $scope.closeModal();
    };
    $scope.closeModal = function() {
        $uibModalStack.dismissAll();
    };
<<<<<<< HEAD
    $scope.contentForTCObject = tcAndSTPopupModel.getPopUpContent();

    if (angular.isObject($scope.contentForTCObject)) {
        //if($scope.contentForTCObject && $scope.contentForTCObject !== 'null' && $scope.contentForTCObject !== 'undefined'){
        $scope.contentForTC = $scope.contentForTCObject['accounts-content']['tc-investor-online'].content;
    }

}


termsAndConditionsController.$inject = ['$scope', '$uibModalStack', 'loginModelService', 'constants', 'tcAndSTPopupModel'];
=======
    
    if(advisorRegistrationModelService.getUserType() == "Investor"){
        $scope.contentForTCObject = tcAndSTPopupModel.getPopUpContent();
        if (angular.isObject($scope.contentForTCObject)) {
            //if($scope.contentForTCObject && $scope.contentForTCObject !== 'null' && $scope.contentForTCObject !== 'undefined'){
            $scope.contentForTC = $scope.contentForTCObject['accounts-content']['tc-investor-online'].content;
        }
    }else{
        $scope.contentForTCObjectOther = tcAndSTPopupModel.getPopUpContentOther();
        if (angular.isObject($scope.contentForTCObjectOther)) {
            //if($scope.contentForTCObject && $scope.contentForTCObject !== 'null' && $scope.contentForTCObject !== 'undefined'){
            $scope.contentForTC = $scope.contentForTCObjectOther['accounts-content']['tc-advisor-online'].content;
        }
    }

    // if (angular.isObject($scope.contentForTCObject)) {
    //     //if($scope.contentForTCObject && $scope.contentForTCObject !== 'null' && $scope.contentForTCObject !== 'undefined'){
    //     $scope.contentForTC = $scope.contentForTCObject['accounts-content']['tc-investor-online'].content;
    // }

}


termsAndConditionsController.$inject = ['$scope', '$uibModalStack', 'loginModelService', 'constants', 'tcAndSTPopupModel', 'advisorRegistrationModelService'];
>>>>>>> ftic-inv-sprint6

module.exports = termsAndConditionsController;
