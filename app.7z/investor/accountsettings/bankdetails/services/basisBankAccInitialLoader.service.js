/**
 * @ngdoc property
 * @name fticChangePasswordIntialLoadService
 * @requires DetailsModel
 
 * @description
 *
 * - fticChangePasswordIntialLoadService loads all the initial services for change password page in my profile module.
 *
 **/

'use strict';

var fticBasisBankAccIntialLoadService = function(basisBankAccModel,basisBankListModel,investorEvents, fticLoggerMessage, loggerConstants, toaster) {

	var fticBasisBankAccIntialLoadService = {
		_isServicesData: false,
		editBankDetails : function(scope,queryObject){
			var editBankDetailsSuccess = function(data){								
				investorEvents.accountSettings.editBasisBankAccDetails(scope);
			};

			basisBankAccModel.editBasisBankDetails(queryObject)
			.then(editBankDetailsSuccess, promiseFailure);
		},		
		bankDetails : function(scope) {
			
			basisBankAccModel.getBankAccDetails()
			.then(bankAccDetailsSuccess, promiseFailure);

			function bankAccDetailsSuccess(data) {				
				basisBankAccModel.setBasisBankDetails(data.basisBankAccDetailsObject);				
				investorEvents.accountSettings.bankAccDetails(scope);
			};
			
		},
		bankNameList : function(scope) {

			basisBankListModel.getBankNamesList()
			.then(bankNamesListSuccess, promiseFailure);

			function bankNamesListSuccess(data) {				
				basisBankListModel.setBasisBankNames(data.bankNames);				
				investorEvents.accountSettings.bankNamesList(scope);
			};
		}
		
	};
			

	function promiseFailure(data, vel) {
		fticBasisBankAccIntialLoadService._isServicesData = false;
		toaster.error(data.data[0].errorDescription);
	}

	return fticBasisBankAccIntialLoadService;
};

fticBasisBankAccIntialLoadService.$inject = ['basisBankAccModel','basisBankListModel','investorEvents', 'fticLoggerMessage', 'loggerConstants', 'toaster'];
module.exports = fticBasisBankAccIntialLoadService;
