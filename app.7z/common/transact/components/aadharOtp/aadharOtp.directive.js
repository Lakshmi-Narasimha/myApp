/**
 * @ngdoc directive
 * @name investment preferences
 * @description
 *
 * - Investment preferences component will display the selection option for payments through financial advisor or direct.
 * 
 *
 **/
 'use strict';

var investmentPreferences = function(paperlessModel, $state, otpVerificationModel, authenticationService, ekycVerificationModel, transactModel,otpGenerationModel) {
	return {
            template: require('./aadharOtp.html'),
            restrict: 'E',
            replace: true,
            scope: {
                aadharDetails:"=",
                backState: "=?",
                aadharOtpForm : "="
            },
            controller: function($scope, $element, $attrs){
                $scope.isTransactNow = false;

                $scope.aadharObject = {
                    key :'Aadhaar',
                    text : 'Aadhaar',
                    isRequired : true,
                    name : 'aadhar',
                    type: "number",
                    value:$scope.aadharDetails.aadhar,
                    disable:true
                };
                $scope.otpObject = {
                    key :'One-time Password(OTP)',
                    text : 'One-time Password(OTP)',
                    name : 'otp',
                    isRequired : true,
                    type: "number",
                    value:"",
					maxlength:6
                };

                if ($state.current.name == 'transactnow.ekycVerification') {
                    $scope.isTransactNow = true;
                    $scope.otpObject = $scope.aadharDetails.otpObject;
                    $scope.aadharObject = $scope.aadharDetails.aadharObject;
                }

                $scope.handleSubmit = function(){
                    $state.go("invTransact.verifyDtls");
                }

                function aadharDtlsSuccess(data) {  
                    console.log("ekyc opt validation data is", data.eKYCOTPValidation);
                    if(data){
                        otpVerificationModel.setAadharDetails(data.eKYCOTPValidation);     
                    }
                    $scope.handleSubmit();
                };
                function aadharDtlsFailure(error){
                    console.log(error);
                }

                $scope.submitOTP = function(){
                    if ($scope.aadharOtpForm.$valid) {
                        transactModel.setOtp($scope.otpObject.value);
                        var requestObject = {
                              paramObj: {"guId" : authenticationService.getUser().guId},
                              bodyObj: {
                                "validateOTPeKYC":
                                [
                                  {"adrPANPkrn":$scope.aadharObject.value.toString(),"otp":$scope.otpObject.value.toString()}
                                ]
                              }
                        }
                        paperlessModel.aadharVerify.hasData = true;
                        ekycVerificationModel.validateEkycOtp(requestObject).then(aadharDtlsSuccess, aadharDtlsFailure);
                    }
                }

                $scope.redirectBack = function(){
                    $state.go($scope.backState);
                }

                //resend OTP
                $scope.resendOTP = function(){
                	transactModel.setOtp($scope.otpObject.value);
                        var requestObject = {
                              paramObj: {"guId" : authenticationService.getUser().guId},
                              bodyObj: {
                                "ekycoptpan":
                                [
                                  {"adrPANPkrn":$scope.aadharObject.value.toString()}
                                ]
                              }
                    }
                	ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpDtlsSuccess, otpDtlsFailure);
                }
                function otpDtlsSuccess(data) {   
                	otpGenerationModel.setOtpDetails(data);     

                };
                function otpDtlsFailure(error){
                	console.log(error);
                }

                //Back Functionality
                if(paperlessModel.aadharVerify.hasData){
                    $scope.otpObject.value = transactModel.getOtp();
                }
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

investmentPreferences.$inject = ['paperlessModel', '$state', 'otpVerificationModel', 'authenticationService', 'ekycVerificationModel', 'transactModel','otpGenerationModel'];
module.exports = investmentPreferences;