
'use strict';

function messages ($translateProvider) {
    $translateProvider.translations('en_US',{
        'SIP_CALC' : 'SIP Calculator',
        'LUMPSUM_CALC' : 'Lumpsum Calculator',
        'TAX_ADV_CALC' : 'Tax Advantage Calculator',
        'COMMISSION_TITLE' : 'COMMISSION CALCULATOR',
        'COMPARISSION_CALC' : 'SIP VS LUMPSUM CALCULATOR',
        'INVESTMENT_TYPE'    : 'Investment Type',
        'SIP_CAL' : 'SIP', 
        'LUMP_CAL' : 'Lumpsum',
        'COMPARISSION_DESC' : 'Enter SIP or Lumpsum Details, to view the comparison',
        'TAX_ADVANTAGE_MSG' : '*Assuming Tax bracket as 30%',
        'SCM_INF_DOC":"SCHEME INFORMATION DOCUMENTS',

        //Calculators Disclaimer 

        DISCLAIMER_TITLE : 'Disclaimer' ,

        DISCLAIMER_MESSAGE : 'Since Inception return of the benchmark is calculated from the scheme inception date. Past performance may or may not be sustained in the future and should not be used as a basis for comparison with other investments. While comparing the performance of investments made through SIPs with the respective benchmark of the scheme, the value of the Index on the days when investment is made is assumed to be the price of one unit. The “since inception” returns signify returns realized since the launch of the scheme. The returns calculated do not take into account Entry Load/ Exit Load. Hence actual “Returns” may be lower. Franklin Templeton India/Trustees do not endorse the authenticity or accuracy of the figures based on which the returns are calculated; nor shall they be held responsible or liable for any error or inaccuracy or for any losses suffered by any investor as a direct or indirect consequence of relying upon the data displayed by the calculator.' , 
        DISCLAIMER_MESSAGE_UPDATE1 : 'The ‘Select Fund Calculator’ is designed to display the past performance of the selected fund for a specified duration. Returns are calculated for growth plan and returns for 1 year are absolute and are compounded annualized for more than 1 year upto Since Inception. Past performance may or may not be sustained in the future and should not be used as a basis for comparison with other investments. The returns calculated do not take into account Entry Load/ Exit Load. Hence actual "Returns" may be lower. The SIP returns are calculated by XIRR approach assuming SIP installments received at different intervals across SIP period. The calculators are provided for reference and illustration on a best effort basis and hence, the accuracy, completeness or correctness may not be warranted.' ,
        DISCLAIMER_MESSAGE_UPDATE2 : 'The ‘Expected Rate of Return calculator’ is designed to assist you in determining the future value of your invested amount for a specified duration at the expected rate of return and is meant for illustration purpose only. There is no warranty about the accuracy of the calculators/ reckoners. The recipients are advised to consult their advisor/ tax consultant prior to arriving at any investment decision. ' ,  
    });

    /* Determine automatically the preferred language based on users window.navigator object */
    $translateProvider.determinePreferredLanguage();

    /*If a translation id is not present in the particular language translation table, angular-translate
    will search for it in the registered fallback language i.e english translation table */
    $translateProvider.fallbackLanguage('en_US');

    $translateProvider.useSanitizeValueStrategy();
}

messages.$inject = ['$translateProvider'];
module.exports = messages;