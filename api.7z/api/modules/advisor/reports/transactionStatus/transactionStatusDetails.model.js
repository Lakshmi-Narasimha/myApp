// TransactionStatusDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TransactionStatusDetailsModelSchema = new mongoose.Schema({
    transactionDetails: {
        type: Array,
        "default": []
    }
});

var TransactionStatusDetailsModelLookUp = mongoose.model('TransactionStatusDetailsModelLookUp', TransactionStatusDetailsModelSchema);

var TransactionStatusDetailsModel = new TransactionStatusDetailsModelLookUp({
    "transactionDetails" : [{
        "financialTransactions":{
            "reportCategories": {
                "dateOptions": [{
                    "category": "lastBusinessDay",
                    "title": "Last Business Day"
                }, {
                    "category": "date1",
                    "title": "01 Feb 2016"
                }, {
                    "category": "date2",
                    "title": "31 Jan 2016"
                }, {
                    "category": "date3",
                    "title": "30 Jan 2016"
                }, {
                    "category": "date4",
                    "title": "29 Jan 2016"
                }, {
                    "category": "date5",
                    "title": "25 Jan 2016"
                }, {
                    "category": "date6",
                    "title": "24 Jan 2016"
                }]
            }
        },
        "nonFinancialTransactions":{
            "reportCategories": {
                "dateOptions": [{
                    "category": "lastBusinessDay",
                    "title": "Last Business Day"
                }, {
                    "category": "date1",
                    "title": "03 Feb 2016"
                }, {
                    "category": "date2",
                    "title": "31 Jan 2016"
                }, {
                    "category": "date3",
                    "title": "30 Jan 2016"
                }, {
                    "category": "date4",
                    "title": "29 Jan 2016"
                }, {
                    "category": "date5",
                    "title": "25 Jan 2016"
                }, {
                    "category": "date6",
                    "title": "24 Jan 2016"
                }]
            }
        }
    }]    
});

TransactionStatusDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating TransactionStatusDetailsModelLookUp table, please contact admin...');
    } else {
        TransactionStatusDetailsModelLookUp.remove({}, function(err) {
            console.log('TransactionStatusDetailsModelLookUp collection removed');
            TransactionStatusDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransactionStatusDetailsModelLookUp table, please contact admin...');
                }
                console.log('TransactionStatusDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransactionStatusDetailsModelLookUp;