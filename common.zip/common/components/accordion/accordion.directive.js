/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accordion = function() {
	return {
            template: require('./accordion.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              accordionData: '=',
              lable: '=',
              count: '=',
              isToggleDisabled: '=',
              status: '=?allOpen',
              mgClick:'&?'
            },
            controller:function(){
              //$scope.status = $scope.allOpen;
            }
        };
};

accordion.$inject = [];
module.exports = accordion;