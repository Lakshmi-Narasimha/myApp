define([
    'jquery',
    'lodash',
    'app/common/views/AbstractView',
    'app/application/app',
    'text!app/application/templates/Header.html'
], function ($, _, AbstractView, app, HeaderTemplate) {

    return AbstractView.extend({
        el: '#sem-header',
        template: _.template(HeaderTemplate),
        events: {},
        render: function () {
            this.$el.html(this.template({'userName':  'JOE'}));
            //this.$el.html(this.template());
        }
    });

});
