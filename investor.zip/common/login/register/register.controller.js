/**
 * @ngdoc property
 * @name Forgot Password controller
  * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function registerController ($scope, $state,$filter,constants,$uibModal,advisorRegistrationModelService) {
	 $scope.headingObj = {
 		text : 'Register'
 	}
 	 $scope.chkTnCs=false;
   $scope.disable=true;
   $scope.accpted=false;
     $scope.bread=[];
   $scope.regType="Adviser"
    $scope.$on('investorSelected',function(event){

        $scope.regType="Investor"
       

   });
    $scope.$on('advisorSelected',function(event){

        $scope.regType="Adviser"
       

   });
   $scope.$on('accptedTermsAndConditions',function(event){

        $scope.accpted=true;
        if($scope.chkTnCs==true && $scope.accpted==true){
          $scope.disable=false;
          }

   });
   $scope.$on('rejectedTermsAndConditions',function(event){

        $scope.accpted=false;
        if($scope.chkTnCs==true && $scope.accpted==true){
          $scope.disable=false;
          }
          else{
            $scope.disable=true;
          }

   });
 
  console.log($scope.chkTnCs+"checkvalue");
  $scope.loginContinue=function(){
   
        advisorRegistrationModelService.setUserType($scope.regType);
        $state.go('loginmaster.arndetails');
  }
  var modalInstance; 
  $scope.termsAndConditions=function(){
  	modalInstance = $uibModal.open({
                    template : require('../components/termsandconditions/termsAndConditions.html'),
                    scope : $scope,
                    size: 'lg'
                });
  }
  $scope.checkBox=function(){
    if($scope.chkTnCs == true){
      $scope.chkTnCs == false;
    }
    else if($scope.chkTnCs == false){
      $scope.chkTnCs == true;
    }
    //$scope.chkTnCs = !($scope.chkTnCs);
    if($scope.chkTnCs==true && $scope.accpted==true){
      $scope.disable=false;
    }else{
      $scope.disable = true;
    }
    console.log($scope.chkTnCs+"onclick");
    
  }

  $scope.$emit("setBreadCrumb",{
        cat : "register",
        breadCrumb :{
            label:'Register',
            state : ''
        }       
    });

}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
registerController.$inject = ['$scope', '$state','$filter','constants','$uibModal','advisorRegistrationModelService'];
module.exports = registerController;