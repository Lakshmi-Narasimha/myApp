coa = coa || {};
define(
		[ 'jquery',
		  'underscore',
		  'backbone','text!appmodules/coa/app/templates/validation.html','appmodules/coa/app/js/utils','appcommon/globalcontext' ],
		function($,
				_, Backbone,Template,Utils,GlobalContext) {
			var queryString = GlobalContext.getInstance().getGlobalContext().Context.QueryString;
			queryString = queryString?queryString:'';
			coa.views.Validation = Backbone.View
					.extend({
						el : '#coa-app',
						template : _.template(Template),
						events : {
							'click #back-to-step1,#m-back-to-step1' : 'backToStep1',
							'click #coa-goto-verfiy-button,#m-step2-next-button' : 'gotoVerifyPage',
							'change #validate-adress-confirm-check' : 'display'
						},
						initialize : function() {
							$('.coa-step').removeClass('active finished');
							$('.coa-step.step2').addClass('active');
							$('.coa-step.step1').addClass('finished');
							this.$main = this.$('#user-info');
						},
						render : function() {
							
							return this.$main.html(this.template(this.model
									.toJSON()));
						},
						clearView : function() {
							this.undelegateEvents();							
							this.model.unbind('change', this.render, this);
						},

						backToStep1 : function() {
							$('.coa-step').removeClass('active finished');
							$('.coa-step.step1').addClass('active');
							coa.user.set('fromBackButton', true);
							coa.Router.navigate('coa/home'+queryString, {
								trigger : true
							});
							if (coa.user.get('accounts').length == 0) {
								$('#use-existing-address , #future-start-end-date-container , #unassign-mailing-address, #new-mailing-address-account-contnr, #msg-mailing , #unassign-mail-address-info' ).addClass('hidden');
							}	
						},

						display : function() {
							if ($('#validate-adress-confirm-check').prop(
									'checked') == true) {
								$('#validate-display').show();

								$(".coa-valid-label-value-check>label")
										.addClass("hidden");
								$(".coa-valid-label-value-check").removeClass(
										"error");
							}

							else {
								$('#validate-display').hide();
							}

						},
						gotoVerifyPage : function() {
							if ($('#validate-adress-confirm-check').prop(
									'checked') == false) {
								$(".coa-valid-label-value-check").addClass(
										"error");
								$(".coa-valid-label-value-check>label")
										.removeClass("hidden");
								coa.user.set('addressChecked',false);
								return false;
							} else {
								coa.user.set('addressChecked',true);
								$(".coa-valid-label-value-check>label")
										.addClass("hidden");
								$(".coa-valid-label-value-check").removeClass(
										"error");
							}

							$('.coa-step').removeClass('active');
							$('.coa-step.step2').addClass('finished');
							$('.coa-step.step3').addClass('active');

							coa.Router.navigate('coa/verify'+queryString, {
								trigger : true
							});
							if (coa.user.get('accounts').length == 0) {
								$('#verify-address-start-date, #verify-address-end-date, #verify-coa-accnt' ).addClass('hidden');
							}

						},
						handlerForCancel : function() {
							$('#coa-cancel-modal').modal('show');
						}
					});
		});