 /**
 * @ngdoc service
 * @name Common Logger
 * @requires constants
 * @requires appConfig
 * @description
 *
 * - It's able to write the logs to text file for respective modules.
 *
 */
'use strict';
 var fticLogger = function(constants, appConfig) {
    var loglevels = {
        'ALL'   : log4javascript.Level.ALL,
        'TRACE' : log4javascript.Level.TRACE,
        'DEBUG' : log4javascript.Level.DEBUG,
        'INFO'  : log4javascript.Level.INFO,
        'WARN'  : log4javascript.Level.WARN,
        'ERROR' : log4javascript.Level.ERROR,
        'FATAL' : log4javascript.Level.FATAL,
        'OFF'   : log4javascript.Level.OFF
    };
    return {
        $get: function () {
            return {
                getLogger : function (name) {
                    log4javascript.setEnabled(appConfig.IS_LOG_ENABLED);
                    if(name===undefined) {
                        name = 'defaultLogger';
                    }
                    var log = log4javascript.getLogger(name);

                    if(appConfig.IS_AJAXLOG_ENABLED) {
                        // Send logs to server                      
                        var ajaxAppender = new log4javascript.AjaxAppender(appConfig.LOGGING_URL_LOCAL);
                        var jsonLayout = new log4javascript.JsonLayout(true,true);
                        ajaxAppender.setSessionId('user@cts.com');
                        ajaxAppender.addHeader('Content-type', 'application/json');
                        ajaxAppender.setLayout(jsonLayout);
                        ajaxAppender.setThreshold(loglevels[appConfig.LOG_LEVEL]);
                        log.addAppender(ajaxAppender);
                    }
                    else {
                        var consoleAppender = new log4javascript.BrowserConsoleAppender();
                        consoleAppender.setThreshold(loglevels[appConfig.LOG_LEVEL]);
                        log.addAppender(consoleAppender);
                    }

                return log;
            }
        };

    }
};



};

fticLogger.$inject = ['constants', 'appConfig'];
module.exports = fticLogger;
