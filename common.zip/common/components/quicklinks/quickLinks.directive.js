/**
 * @ngdoc property
 * @name fticQuickLinks Directive
 * @requires advisorDashboardDetailsModel
 * @requires eventConstants
 * @requires advisorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Displays the Quick Actions section
 *
 **/


'use strict';

var fticQuickLinks = function() {
	return {
            template: require('./quickLinks.html'),
            restrict: 'E',
            replace: true,
            scope: {
                quicklinks : '=',
                moduletype : '@'
            },
            controller: ['$scope', function($scope){

                if($scope.moduletype === 'investor') {
                    $scope.imageSource = 'investor/images';
                } else {
                    $scope.imageSource = 'advisor/images';
                }
            }],
            link: function(){

            }
        };
};

fticQuickLinks.$inject = [];
module.exports = fticQuickLinks;