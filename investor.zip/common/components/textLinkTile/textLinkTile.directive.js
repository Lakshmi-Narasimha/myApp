/**
 * @ngdoc directive
 * @name text-tile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - It is used as a common directive for displaying the text in the panel's. This directive accepts the type of the tile
 *   data to be added in the tile and the limit to which the number of tiles is to be restricted to.
 * 
 *
 **/

'use strict';

var fticInvDbTextLinkTile  = function() {
	return {
            template: require('./textLinkTile.html'),
            restrict: 'E',
            replace: true,
            scope: {
                tileType  : '@',
                tileText  : '=',
                tileLimit : '='
            },
            link: function(scope){
            }
        };
};
fticInvDbTextLinkTile.$inject = [];
module.exports = fticInvDbTextLinkTile;