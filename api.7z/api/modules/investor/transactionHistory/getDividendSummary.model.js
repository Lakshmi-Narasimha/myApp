// getDividendSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TransDividendSummaryModelSchema = new mongoose.Schema({
    dividendSummaryResp: {
        type: Array,
        "default": []
    }
});

var TransDividendSummaryModelLookUp = mongoose.model('TransDividendSummaryModelLookUp', TransDividendSummaryModelSchema);

var TransDividendSummaryModel = new TransDividendSummaryModelLookUp({
    /*dividendSummaryResp: {
        "dividendSummary": [{
                "folioNo": "111111",
                "modeOfHolding": "Joint",
                "holderDetails": [{
                    "name": "Shankar S",
                    "type": "Firstholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }, {
                    "name": "Shankar Narayan",
                    "type": "Secondholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }],
                "fundDetails": [{
                    "fundName": "Franklin India Smaller Companies Fund",
                    "accountNo": "127891981",
                    "divAmount": "2,000.00",
                    "divOption": "Payout"
                }, {
                    "fundName": "Franklin India Prima Plus Fund",
                    "accountNo": "127891981",
                    "divAmount": "1,000.00",
                    "divOption": "Reinvestment"
                }]
            }, {
                "folioNo": "999999",
                "modeOfHolding": "Joint",
                "holderDetails": [{
                    "name": "Shankar S",
                    "type": "Firstholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }, {
                    "name": "Shankar Narayan",
                    "type": "Secondholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }],
                "fundDetails": [{
                    "fundName": "Franklin India Smaller Companies Fund",
                    "accountNo": "127891981",
                    "divAmount": "2,000.00",
                    "divOption": "Payout"
                }, {
                    "fundName": "Franklin India Prima Plus Fund",
                    "accountNo": "127891981",
                    "divAmount": "1,000.00",
                    "divOption": "Reinvestment"
                }]
            }]
    }*/
    dividendSummaryResp: {
        "invTrxnSummary": [{
            "folioId": "17259162",
            "modeofHolding": "Joint",
            "holders": {
                "firstHoldersName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
                "secondHoldersName": "Kishan ram kiran",
                "thirdHoldersName": " "
            },
            "rows": [{
                "accountNo": "0029903636631",
                "amount": "35,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "No",
                "fundDesc": "Franklin India Prima Plus - Dividend",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": "",
            }]
        }, {
            "folioId": "17024206",
            "modeofHolding": "Joint",
            "holders": {
                "firstHoldersName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
                "secondHoldersName": "Kishan ram kiran",
                "thirdHoldersName": " "
            },
            "rows": [{
                "accountNo": "0069903636631",
                "amount": "20,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "Yes",
                "fundDesc": "Franklin India Bluechip Fund - Dividend",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }, {
                "accountNo": "0359903636631",
                "amount": "149,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "Yes",
                "fundDesc": "Franklin India Taxshield - Dividend",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }, {
                "accountNo": "3049903636631",
                "amount": "110,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "No",
                "fundDesc": "Franklin Asian Equity Fund - Growth",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }]
        }]
    }
});

TransDividendSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating TransDividendSummaryModelLookUp table, please contact admin...');
    } else {
        TransDividendSummaryModelLookUp.remove({}, function(err) {
            console.log('TransDividendSummaryModelLookUp collection removed');
            TransDividendSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransDividendSummaryModelLookUp table, please contact admin...');
                }
                console.log('TransDividendSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransDividendSummaryModelLookUp;
