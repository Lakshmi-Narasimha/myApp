'use strict';
describe('Services: family portfolio initial loader service', function() {
	var fticFamilyPortfolioLoadInitialService,familyPortfolioModel,httpBackend,$window;

	var familyPFList = {
	  "pending": [
	    {
	      "custName": "Priya Venkatesh",
	      "refId": "345"
	    },
	    {
	      "custName": "GiriBabu",
	      "refId": "342"
	    }
	  ],
	  "approved": [
	    {
	      "currentValue": "6,50,000.00",
	      "currentCost": "2,50,000.00",
	      "pan": "ABAPL1235C",
	      "custName": "Shankar Narayan"
	    },
	    {
	      "currentValue": "6,50,000.00",
	      "currentCost": "2,50,000.00",
	      "pan": "ABAPL1235D",
	      "custName": "Gayatri Narayan"
	    }
	  ],
	  "primaryPan": "ABAPL1235D"
	};


	var failureResponse =  [{
                    'errorCode': 'E123',
                    'errorDescription': 'Something went wrong...'
                }];

    beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.myportfolio'));

	beforeEach(inject(function(familyPortfolioInitialLoader,_familyPortfolioModel_,$httpBackend,_$window_){
		fticFamilyPortfolioLoadInitialService = familyPortfolioInitialLoader;
		familyPortfolioModel = _familyPortfolioModel_;
		httpBackend = $httpBackend;				

		$window = _$window_;
        $window.ga = function() {};
	}));	

	it("loadAllServices should be defined",function(){
		expect(fticFamilyPortfolioLoadInitialService.loadAllServices).toBeDefined();
	});

	it("should _isServicesData  be false on load",function(){
		expect(fticFamilyPortfolioLoadInitialService._isServicesData).toBeFalsy();
	});	

	it("should loadAllServices and check for success ",function(){
		httpBackend.expectGET('http://localhost:3030/profile/familyPortfolio?guId=878').respond(familyPFList);

		fticFamilyPortfolioLoadInitialService.loadAllServices({'$broadcast': function() {
	                return true;
	            }
	        });
		httpBackend.flush();		
		expect(familyPortfolioModel.getFamilyPFList().primaryPan).toEqual("ABAPL1235D");
	});	

	it("should loadAllServices and check for failure ",function(){
		httpBackend.expectGET('http://localhost:3030/profile/familyPortfolio?guId=878').respond(400,failureResponse);

		fticFamilyPortfolioLoadInitialService.loadAllServices({'$broadcast': function() {
	                return true;
	            }    
	        });
		httpBackend.flush();		
		expect(familyPortfolioModel.getFamilyPFList()).toBe(null);
		expect(fticFamilyPortfolioLoadInitialService._isServicesData).toBeFalsy();		
	});	
});