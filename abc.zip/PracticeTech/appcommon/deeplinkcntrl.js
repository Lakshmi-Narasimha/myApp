define(
		['jquery',
  'underscore', 'services/dataservice',
		  'apipublic/navapi',
		  'appcommon/commonutility',
		  'appcommon/globalcontext',
		  'appcommon/constants',
		  'appcommon/nativeadaptor', 'errorLog', 'spinner'],
		function ($, _, DataService, NavApi, CommonUtils, GlobalContext, Constants, NativeAdaptor, ErrorLog, Spinner) {
		    var deepLinkParams = {};
		    $(document).on("obolistready", oboListReadyHandler);
		    $(document).on("oboretryready", deeplinkItWithOBOContext);

		    function deeplinkIt(deepLinkUrl) {
		        try {
		            console.debug("ItdeeplinkItdeeplinkItdeeplinkItdeeplinkItdeeplinkIt");
		            var _queryParams = CommonUtils.getUrlParams(GlobalContext
							.getInstance().getGlobalContext().Context.QueryString);
		            var _url = deepLinkUrl + (GlobalContext.getInstance().getGlobalContext().Context.QueryString ? GlobalContext.getInstance().getGlobalContext().Context.QueryString : "");
		            deepLinkParams.url = (deepLinkUrl ? deepLinkUrl : deepLinkParams.url);
		            console.debug("deepLinkUrldeepLinkUrldeepLinkUrl", deepLinkParams);
		            if (/contactprofile/i.test(_url) || /hoc/i.test(_url) || /gpm/i.test(_url)) {
		                if (_queryParams['ContextId'] || _queryParams['mode']) {
		                    //3rd parameter is to retry with obo context
		                    //adding a delay of 10ms to make sure home.js is ready to listen some events when sessionCOntext is ready
		                    setTimeout(function () {
		                        ContactProfileDeepLinkHandler(_queryParams, deepLinkUrl, false);
		                    }, 10);
		                    
		                }
		            } else if (/accountviewer/i.test(_url)) {
		                if (_queryParams['ContextId'] || _queryParams['mode']) {
		                    setTimeout(function () {
		                        ContactProfileDeepLinkHandler(_queryParams, deepLinkUrl);
		                    }, 10);
		                    
		                }
		            } else {
		                Backbone.history.navigate('crm/', true);
		            }
		        } catch (error) {
		            ErrorLog.ErrorUtils.myError(error);
		        }


		    };
		    function triggerOboListReadyEvent(advisors) {
		        advisors = (advisors && advisors.models) ? advisors : { models: {} };
		        $.event.trigger({
		            type: "obolistready",
		            message: advisors.models,
		            time: new Date()
		        });
		    }
		    //Handler for OBO list ready event triggering from Nav home js
		    function oboListReadyHandler(e) {
		        console.debug("Launch CP oboListReadyHandler deeplink control>>>>>>>>>>>>>>>>>>>>>>>>");
		        console.debug(deepLinkParams, "deepLinkParams>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		        if (deepLinkParams && deepLinkParams.oboId) {
		            console.debug("Launch CP oboListReadyHandler deeplink control111>>>>>>>>>>>>>>>>>>>>>>>>")
		            if (CommonUtils.readCookie('FMID') != deepLinkParams.oboId) {
		                console.debug("Launch CP oboListReadyHandler deeplink control2222>>>>>>>>>>>>>>>>>>>>>>>>")
		                setTimeout(function () {
		                    console.debug("Launch CP oboListReadyHandler deeplink control3333>>>>>>>>>>>>>>>>>>>>>>>>")
		                    $("#afinav-obo-menu li[id=" + deepLinkParams.oboId + "]").click();
		                    NavApi.changeContactAndLauchCP(deepLinkParams.clientId, deepLinkParams.ContactType);
		                    var _userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
		                    if (_userRoles && (_userRoles.indexOf("csr") > -1 || _userRoles.indexOf("csr") > -1)) {}
		                }, 0);

		            }
		        }
		    };
		    function ContactProfileDeepLinkHandler(_queryParams, deepLinkUrl, retry) {
		        var _deeplinkContext;
		        //If the URL has valid contextId in the case of clients
		        if (_queryParams['ContextId'] && _queryParams['ContextId'] != "") {
		            DataService.getAdvisorSession(_queryParams['ContextId']).then(
							function (result) {
							    _deeplinkContext = result;
							    var _clientId, ContactType;
							    try{
							        _clientId = result && result[0] && result[0].clIds && result[0].clIds[0] && result[0].clIds[0].clId ? result[0].clIds[0].clId : null;
							        if (_clientId) {
							            if (_clientId.indexOf("Contact.") > -1) {
							                ContactType = Constants.contactType.NonClient;
							            } else {
							                ContactType = Constants.contactType.Client;
							            }
							        } else {
							            //ErrorLog.ErrorUtils.myError(error);
							            logCustomError(_deeplinkContext,false);
							            return;							        }
							        
							    } catch (error) {
							        ErrorLog.ErrorUtils.myError(error);
							        logCustomError(_deeplinkContext, true);
							        return;
							    }
							   
							    deepLinkParams.oboId = result[0].dstrIds.dstrId;
							    deepLinkParams.clientId = _clientId;
							    deepLinkParams.ContactType = ContactType;
							    deepLinkParams.groupId = (result[0].grpIds && result[0].grpIds[0] && result[0].grpIds[0].grpId) ? result[0].grpIds[0].grpId : null;
							    var _gContext = GlobalContext.getInstance();
							    var _userRoles = _gContext.getGlobalContext().Context.Roles;
							    var _advId = deepLinkParams.oboId ? deepLinkParams.oboId : CommonUtils.readCookie('FMID');
							    $.event.trigger({
							        type: "contextReady",
							        message: _advId,
							        time: new Date()
							    });
							    if (deepLinkParams.groupId !== null) {
							        $.event.trigger({
							            type: "groupidfromcontext",
							            message: { "grpId": deepLinkParams.groupId },
							            time: new Date()
							        });
							    }
							    if (deepLinkParams.oboId && CommonUtils.readCookie('FMID') != deepLinkParams.oboId) {
							        console.debug("inside deeplink handler", "OBO Launch");
							        if (_userRoles && (_userRoles.indexOf("csr") > -1 || _userRoles.indexOf("aac") > -1 || _userRoles.indexOf("rp") > -1 || _userRoles.indexOf("rpdelegates") > -1)) {
							            NavApi.changeOBOAndLauchCP(deepLinkParams);
							            pinnOboForCSRandAAC(deepLinkParams.oboId);
							        } else {
							            NavApi.changeOBOAndLauchCP(deepLinkParams);
							            DataService.getAdvisorInfo().done(triggerOboListReadyEvent).fail(gotoErrorHandler);
							            function gotoErrorHandler(resp) {
							                if (resp.data) {
							                    triggerOboListReadyEvent(resp.data);
							                }
							            };
							        }


							    } else {
							        console.debug("inside deeplink handler", "CP Launch");
							        NavApi.changeContactAndLauchCP(_clientId, ContactType, deepLinkUrl, retry, deepLinkParams);
							    }


							})
							.fail(function (error) {
							    ErrorLog.ErrorUtils.myError(error);
							    logCustomError(_deeplinkContext);
							});
		        }
		            //Deeplinking for contactprofile from Native app with out contextId
		        else if (_queryParams['mode']) {
		            NativeAdaptor.getNativeContext(function (identifiers) {
		                var ebixId = identifiers.contactEbixId, clientId = identifiers.contactClientId, fmId = identifiers.userFMID, oboFmId = identifiers.clientOBOFMID;
		                deepLinkParams.oboId = oboFmId;
		                deepLinkParams.clientId = clientId;
		                deepLinkParams.ContactType = ((clientId != "" && clientId != null) ? Constants.contactType.Client : Constants.contactType.NonClient);
		                if (oboFmId && CommonUtils.readCookie('FMID') != oboFmId) {
		                    NavApi.changeOBOAndLauchCP(deepLinkParams);

		                } else {
		                    if (clientId && clientId != "") {
		                        NavApi.changeContactAndLauchCP(clientId, deepLinkParams.ContactType);
		                    }
		                    else if (ebixId && ebixId != "") {
		                        NavApi.changeContactAndLauchCP(ebixId, deepLinkParams.ContactType);
		                    } else {
		                        alert("Cannot proceed, Missing required informations");
		                    }
		                }

		            });

		        }

		    }
		    function logCustomError(context, hidePopup) {
		        var _customLog = {
		            "message": "CV Deeplink getContext - Error",
		            "stack": {
		                "description": "This log is related to the CV deeplink to AM eternal getContext issue.",
		                "context": context
		            }
		        }
		        ErrorLog.ErrorUtils.myError(_customLog, hidePopup);
		    }
		    function pinnOboForCSRandAAC(oboAdvisorId) {
		        DataService.getDistributorInfo(oboAdvisorId, [401, 404, 500]).then(function (response) {
		            if (response.status && (response.status == 401 || response.status == 404 || response.status == 500)) {
		                Spinner.hide();
		                BootstrapDialog.alert("You are not authorized to view advisor data.");
		            }
		            else{
		                if (response[0] && response[0].prefName && (response[0].prefName.firstNm || response[0].prefName.lastNm)) {
		                    $('.afinav-obo-user').text(response[0].prefName.firstNm + " " + response[0].prefName.lastNm);
		                }
		                else {
		                    $('.afinav-obo-user').text("");
		                }
		                triggerOboListReadyEvent();
		            } 
		        })
            .fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.myError(error);
            });
		    }
		    function deeplinkItWithOBOContext() {
		        DataService.getAdvisorInfo().done(function (oboadvisors) {
		            showOboOption(oboadvisors)
		        }).fail(gotoErrorHandler);
		        function showOboOption(oboadvisors) {
		            Spinner.hide();
		            var _dialogBody = "<div><select id='deeplink-obo-select'>";
		            var _oboadvisorArray = oboadvisors.models;
		            var _oboAdvisorsList = [];
		            for (var i = 0; i < _oboadvisorArray.length; i++) {
		                var _oboAdvisor = {}; _oboAdvisor.fmid = _oboadvisorArray[i].get("fmid"); _oboAdvisor.name = _oboadvisorArray[i].get("name");
		                _oboAdvisorsList.push(_oboAdvisor);
		                _dialogBody += "<option value='" + _oboAdvisor.fmid + "'>" + _oboAdvisor.name + "</option>";
		            }
		            _dialogBody += "</select></body>";
		            BootstrapDialog.show({
		                title: 'Select OBO',
		                message: _dialogBody,
		                closeByBackdrop: false,
		                cssClass: 'esig-sign-valdtn-contnr',
		                buttons: [
                                {
                                    label: 'Go',
                                    cssClass: 'generic-button accept-button',
                                    action: function (dialog) {
                                        dialog.close();
                                        retryWithOBO($('#deeplink-obo-select').val())
                                    }
                                },
                                {
                                    label: 'Cancel',
                                    cssClass: 'generic-button cancel-button',
                                    id: '',
                                    action: function (dialog) {
                                        dialog.close();
                                    }
                                }]
		            });
		        }
		        function gotoErrorHandler(resp) {
		            console.log(resp, "error>>>>>>>>>>>>>>");
		            if (resp.data) {
		                showOboOption(resp.data);
		            }
		        }
		        function retryWithOBO(oboId) {
		            Spinner.show();
		            deepLinkParams.oboId = oboId;
		            var _userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
		            if (deepLinkParams.oboId && CommonUtils.readCookie('FMID') != deepLinkParams.oboId) {
		                console.debug("inside deeplink handler", "OBO Launch OBO Retry................");
		                if (_userRoles && (_userRoles.indexOf("csr") > -1 || _userRoles.indexOf("aac") > -1)) {
		                    NavApi.changeOBOAndLauchCP(deepLinkParams);
		                    pinnOboForCSRandAAC(deepLinkParams.oboId);
		                } else {
		                    NavApi.changeOBOAndLauchCP(deepLinkParams);
		                    DataService.getAdvisorInfo().done(triggerOboListReadyEvent).fail(gotoErrorHandler);
		                    function gotoErrorHandler(resp) {
		                        if (resp.data) {
		                            triggerOboListReadyEvent(resp.data);
		                        }
		                    };
		                }


		            } else {
		                //console.debug("inside deeplink handler", "CP Launch OBO retry");
		                NavApi.changeContactAndLauchCP(deepLinkParams.clientId, ContactType, deepLinkParams.url, false);
		            }
		        }
                function getClientAdvisorrelationship (fmID,clientId){
    		        Spinner.show();
			        var _filter = "id eq '"+clientId+"' and ctx eq 'COLA.CL'";
                    DataService.getClients(fmID, Config.contactListLimit, _filter, [404]).then(function(result){
        		        var actualResult = (result[0] && result[0]['results']) ? result[0]['results'] : null;
        		        if(result.status == 404 || !actualResult || actualResult.length<1){
        		            alert("No association with client");
        		        } else {

        		        }
        	        })
        	        .fail(function(error){
        		        Spinner.hide();
        		        ErrorLog.ErrorUtils.myError(error);
        	        });
            }	
		    }
		    return {
		        deeplinkIt: deeplinkIt
		    }
		});