'use strict';
describe('Services: investor folio view initial loader services', function() {

    var mockFolioViewInitialLoaderService, folioViewModelData, httpBackend, Restangular, $window, folioAccountsResData, invFolioDetailsModelData, folioViewDetailsData;

    beforeEach(angular.mock.module('investor'));

    beforeEach(inject(function(_folioViewInitialLoader_, _folioViewModel_, _invFolioDetailsModel_, $injector, _$httpBackend_, _Restangular_) {
        mockFolioViewInitialLoaderService = _folioViewInitialLoader_;
        folioViewModelData = _folioViewModel_;
        invFolioDetailsModelData = _invFolioDetailsModel_;
        var $q = $injector.get('$q');
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;

        folioAccountsResData = {
           "panFolioAccounts":[
              {
                 "folioAccounts":[
                    "0539900759695"
                 ],
                 "latestFolio":"N",
                 "folioId":"13027781"
              },
              {
                 "folioAccounts":[
                    "2189901265437",
                    "2199900830298"
                 ],
                 "latestFolio":"Y",
                 "folioId":"14503662"
              }
           ],
           "panNo":"CMLQR5320A"
        };

        folioViewDetailsData = {
            'unitHolderDetails': {
                'invName': 'YASMIN'
            },
            'folioDetails': {
                'folioNumber': '17877097',
                'gridData': {
                    'rows': [{
                        'currentValue': '29408.34',
                        'currentCost': '22499.85',
                        'accno': '0379904865101',
                        'returns': '16.81%',
                        'fund': 'Franklin India Prima Plus - Growth',
                        'totalUnits': '66.411',
                        'divInvAmount': '0.00',
                        'purchaseAmount': '22499.85'
                    }],
                    'footer': {
                        'totalUnits': '285.758',
                        'currentCost': '82498.74',
                        'currentValue': '122163.91'
                    }
                }
            }
        };
    }));

    it('should loadAllServices to be defined', function() {
        expect(mockFolioViewInitialLoaderService.loadAllServices).toBeDefined();
    });

    it('should loadFolioAccountDetails to be defined', function() {
        expect(mockFolioViewInitialLoaderService.loadFolioAccountDetails).toBeDefined();
    });

    describe('Services: should be successfully load initial FolioAccountDetails service', function() {

        beforeEach(inject(function(_folioViewInitialLoader_, $injector, _$window_) {
            mockFolioViewInitialLoaderService = _folioViewInitialLoader_;
            var $q = $injector.get('$q');

            httpBackend.expectGET('http://localhost:3030/clients/folioAccounts?flag=P&guId=878').respond(folioAccountsResData);
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should respond with valid data for successfully loadFolioAccountDetails', function() {
            mockFolioViewInitialLoaderService.loadFolioAccountDetails({
                '$broadcast': function() {
                    return true;
                }
            });
            httpBackend.flush();
            expect(invFolioDetailsModelData.getFolioAccountData().length).toEqual(2);
        });
    });

    describe('Services: should be successfully load initial FolioViewDetails service', function() {
        
        beforeEach(inject(function(_folioViewInitialLoader_, $injector, _$window_) {
            mockFolioViewInitialLoaderService = _folioViewInitialLoader_;
            var $q = $injector.get('$q');

            httpBackend.expectGET('http://localhost:3030/clients/clientStatement?flag=F&guId=878').respond(folioViewDetailsData);
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should respond with valid data for successfully loadAllServices', function() {
            mockFolioViewInitialLoaderService.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            }, {});
            httpBackend.flush();
            expect(folioViewModelData.getFolioViewObj().folioDetails.gridData.rows.length).toEqual(1);
        });
    });
});
