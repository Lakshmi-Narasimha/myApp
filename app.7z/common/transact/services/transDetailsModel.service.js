/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';


var transDetailsModel = function() {
    
    var _transactionData = {};

    var transDetailsModel = {
        setTransactionDetails: function(type, data) {

            _transactionData[type] = data;
        },
        getTransactionDetails: function(type) {
            return _transactionData[type];
        }
    };

    return transDetailsModel;
};


transDetailsModel.$inject = [];

module.exports = transDetailsModel;
