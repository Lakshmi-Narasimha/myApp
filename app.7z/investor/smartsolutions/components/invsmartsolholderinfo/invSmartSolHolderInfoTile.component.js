/**
 * @ngdoc directive
 * @name invSmartSolHolderInfoTile
 * @description
 *
 * - Todo
 * 
 *
 **/
'use strict';

var invSmartSolHolderInfoTile = function ($state, invSmartSolHolderInfoFactory,transactModel) {
    return {
        template: require('./invSmartSolHolderInfoTile.html'),
        restrict: 'E',
        replace: true,
        scope: {
            investorDetails: '='
        },
        controller: function ($scope) {

            $scope.investorDetails = invSmartSolHolderInfoFactory.getFormattedHolderInfo($scope.investorDetails);
            // if($scope.investorDetails){
            //      $scope.investorDetails = transactModel.getInvestorDetails();
            //      $scope.investorDetails = invSmartSolHolderInfoFactory.getFormattedHolderInfo($scope.investorDetails);
            // }
            $scope.panLevelInv = function () {

                $scope.$emit('showPANLevelInvModal');
            };

            $scope.showInvestorSelection = function () {

                $state.go('smartSol.planSmartSolution.selectSS');
            };
        },
        link: function () {
        }
    };
};

invSmartSolHolderInfoTile.$inject = ['$state', 'invSmartSolHolderInfoFactory','transactModel'];
module.exports = invSmartSolHolderInfoTile;