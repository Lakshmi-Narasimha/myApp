(function() {
    'use strict';

    angular
        .module('CSS.billing')
        .controller('authCtrl', ['$scope', '$window', 'getPaymentDetailsSevice', 'errorDefaultConstant', '$state', 'billingUtils', '$stateParams', '$loader', '$rootScope', authCtrl]);


    function authCtrl($scope, $window, getPaymentDetailsSevice, errorDefaultConstant, $state, billingUtils, $stateParams, $loader, $rootScope) {
        var authVM = this;
        authVM.externallink = window.loginURL || 'https://www.farmers.com';
        authVM.user = {};
        authVM.authResponse = {};
        authVM.authResponse.isError = false;
        authVM.authResponse.isAuthFailure = false;
        authVM.authResponse.isAuthMax = false;
        authVM.authResponse.ismaintenance = {};
        authVM.authResponse.errorMsg = "";
        window.UIC.authResponseCount = 0;
        authVM.submitted = false;

        // authVM.user.accountNumber = 'T448894122';
        // authVM.user.zipCode = 94122;
        $rootScope.bgcolor=false;

        var resetValues = function() {

            authVM.user.accountNumber = null;
            authVM.user.zipCode = null;
            authVM.submitted = false;
        }
        var getPaymentDetailsService = function(dataQuery) {
            var errorHandling = function(data) {
                authVM.authResponse.isError = true;
                window.UIC.authResponseCount++;
                authVM.authResponse.isAuthFailure = true;
                var isMaxAttempts = window.UIC.authResponseCount >= 3 ? true : false;
                if(isMaxAttempts) {
                    authVM.authResponse.isAuthMax = true;
                    authVM.authResponse.errorTitle = 'We were unable to locate your account.';
                    authVM.authResponse.errorMsg = 'We could not locate your account with the information provided. Please call us at 888-327-6335 for assistance with your account.';
                    $window.location.href = window.loginURL + '/login/?flag=oneTimePaymentAuthFailure';

                }
                else {
                    authVM.authResponse.errorTitle = data.uiErrorDisplayTitleMessage || errorDefaultConstant.defaultTitleMessage;
                    authVM.authResponse.errorMsg = data.uiErrorDisplayMessage || errorDefaultConstant.fileNotFound.defaultMessage;
                }
                resetValues();

            };

            var success = function(data) {
                if(data.transactionStatus === 'S'){
                    if(angular.lowercase(data.billingScheduledMaintenance) === 'y') {
                        authVM.authResponse.isError = true;
                        authVM.authResponse.ismaintenance.isErr = true;
                        authVM.authResponse.ismaintenance.estimatedDowntime = data.estimatedDowntime;
                        authVM.authResponse.errorTitle = data.uiErrorDisplayTitleMessage || errorDefaultConstant.billingMaintenanceTitleMsg;
                    }
                    else {
                        if (angular.lowercase(data.accountStatus) === 'active') {
                            authVM.authResponse.isError = false;
                            billingUtils.setBillingData(data);
                            $state.transitionTo('billing.makeapayment');    
                        } else {
                            authVM.authResponse.isError = true;
                            authVM.authResponse.errorTitle = 'Your account is cancelled';
                            authVM.authResponse.errorMsg = 'Please contact your agent to make payment';
                            resetValues();
                        }                        
                    }
                } else{
                    errorHandling(data);
                }
            };

            var failure = function(data) {
                errorHandling(data);
            };
            
            $loader.start();
            getPaymentDetailsSevice.getPaymentDetails(dataQuery).then(success, failure).finally(function(){
                $loader.stop();
            });

            
        };

        var checkIsBillingAccNo = function(accountnumber) {
            var pattern = new RegExp("[a-zA-Z]{1}[0-9]+");
            return pattern.test(accountnumber);
        };
        
        if($stateParams.errorData || window.billingMaintenance === 'Y') {
            authVM.authResponse.isError = true;
            var errCode = $stateParams.errorData && $stateParams.errorData.transactionCode;
            if($stateParams.errorData) {
                if((errCode && (errCode >= 2000 && errCode <= 3000)) || ($stateParams.errorData && $stateParams.errorData.billingScheduledMaintenance === 'Y')) {
                    authVM.authResponse.ismaintenance.isErr = true;
                    authVM.authResponse.ismaintenance.estimatedDowntime = ($stateParams.errorData ? $stateParams.errorData.estimatedDowntime : window.estimatedDowntime);
                    authVM.authResponse.errorTitle = ($stateParams.errorData ? ($stateParams.errorData.uiErrorDisplayTitleMessage || errorDefaultConstant.billingMaintenanceTitleMsg) : errorDefaultConstant.billingMaintenanceTitleMsg);
                }
                else {
                    authVM.authResponse.errorTitle = 'Payment Unsuccessful';
                    authVM.authResponse.errorMsg = $stateParams.errorData.uiErrorDisplayMessage || errorDefaultConstant.fileNotFound.defaultMessage;
                }

            } else {
                authVM.authResponse.ismaintenance.isErr = true;
                authVM.authResponse.ismaintenance.estimatedDowntime = ($stateParams.errorData ? $stateParams.errorData.estimatedDowntime : window.estimatedDowntime);
                authVM.authResponse.errorTitle = ($stateParams.errorData ? ($stateParams.errorData.uiErrorDisplayTitleMessage || errorDefaultConstant.billingMaintenanceTitleMsg) : errorDefaultConstant.billingMaintenanceTitleMsg);
            }
        }

        authVM.isValidating = function(manageform) {
            authVM.submitted = true;

            var dataQuery = {
                "zipCode": authVM.user.zipCode,
                "billingAccountNumber": null,
                "policyContractNumber": null
            };

            // dataQuery = {};

            if (manageform.$valid === true) {
                var isBillingAccNo;
                if (authVM.user.accountNumber) {
                    isBillingAccNo = checkIsBillingAccNo(authVM.user.accountNumber);
                    if (isBillingAccNo) {
                        dataQuery.billingAccountNumber = authVM.user.accountNumber;
                    } else {
                        dataQuery.policyContractNumber = authVM.user.accountNumber;
                    }
                }

                getPaymentDetailsService(dataQuery);
            }
        };
    }

})();
