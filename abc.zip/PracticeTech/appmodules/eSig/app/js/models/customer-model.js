define(['backbone'], function(Backbone) {
    var customerModel = Backbone.Model.extend({
        idAttribute: "signerId",
        defaults: {
            "lastName": "",
            "firstName": "",
            "middleName":"",
            "signature": [],
            "images": [],
            "docid": "",
            "signerStatus":"",
            "signedSignerLastName":"",
                    // relations: [{
                    // type: Backbone.HasMany,
                    // key: 'signature',
                    // relatedModel: eSig.models.signatureModel,
                    // reverseRelation: {
                    // key: 'customer',
                    // includeInJSON: 'clientId'
                    // }
                    // }]

        },
        setModel: function() {

        }
    });
    return customerModel;
});
