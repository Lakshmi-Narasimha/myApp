/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function newFolioController($scope, transactModel,fticLoggerMessage, loggerConstants, $state,transactEventConstants,folioValidationInitialLoader,folioValidationModelService) {
    console.info("newfolio Controller!!");
    $scope.header.title = "New Folio";
    $scope.headerOnPopUp="The similar holding pattern is available for investor";
    $scope.noBtnTxt="Continue to Existing Folio";
    $scope.yesBtnTxt="Create new Folio";
    $scope.txtOnPopUp="Do you want to continue creating newfolio";
    $scope.popUpMainHeader="";
    $scope.config.showNotification = false; 
    $scope.isFolioExists=false; 
    folioValidationInitialLoader.loadAllServices($scope);
    $scope.holdingOptions= [
      {
            label:"Single",
            value:"single",
            selected: false
        },
        {
            label:"Either or Survivor",
            value:"eitherRSurvivor",
            selected: false
        } 
    ];
    $scope.newFolioInvObj = [];
    $scope.investorDetails=[];
    $scope.investorDetails = transactModel.getInvestorDetails();
     console.log("investorDetails123"+JSON.stringify($scope.investorDetails))
    $scope.newFolioInvObj=[
             {
              key : "PAN / PEKRN",
              text: "PAN/PEKRN",
              value:$scope.investorDetails.holders[0].pan
             },
             {
              key:"First Holder Name",
              text: "First Holder Name",
              value:$scope.investorDetails.holders[0].name
             },
             {
              key:"KYC Status",
              text: "KYC Status",
              value:"Not Registered"
                  //$scope.investorDetails.holders[0].kyc
             }
           ] ;
            $scope.radios = {}; 
   /* $scope.$on('holdingMode', function(event, selectedValue){ 
    console.log("selected value is "+selectedValue.title );                              
      $scope.selectedMode=selectedValue.title
  });*/
    $scope.listenChange = function () {             
            //$state.go($scope.radios.selectedVal);
            //$event.stopPropagation();
            $scope.selectedMode=$scope.radios.selectedVal;
            console.log("$scope.selectedMode"+$scope.selectedMode)
        }
   

      $scope.$on('yes', function () {
        console.log($scope.config.showNotification);
        $scope.config.showNotification = false;
        $state.go('transact.base.buy');
      });
     
      $scope.$on('no', function () {
        $scope.config.showNotification = false;
        $state.go('transact.base.buy');
      });
    $scope.$on("addJointHolderDetails",function(event,jointHolderDts){
       $scope.holderPattern=[];
       $scope.holderPattern.push($scope.investorDetails.holders[0]);
        $scope.holderPattern.push(jointHolderDts);
        console.log("investorDetails joint"+JSON.stringify($scope.holderPattern))
    })

      $scope.continue = function() {
        if($scope.selectedMode=="single"){
          $state.go('transact.base.buy')
        }
        else  if($scope.selectedMode=="eitherRSurvivor"){
          $scope.isFolioExists= folioValidationModelService.getFolioValidationDtls( $scope.holderPattern);
          if($scope.isFolioExists){
           $state.go('transact.base.buy',$scope.isFolioExists);
          }
          else
            $scope.config.showNotification = true;
        }
        else 
          $scope.ifError=true;
          return;
      };


   }

newFolioController.$inject = ['$scope', 'transactModel','fticLoggerMessage', 'loggerConstants', '$state','transactEventConstants','folioValidationInitialLoader','folioValidationModelService'];
module.exports = newFolioController;