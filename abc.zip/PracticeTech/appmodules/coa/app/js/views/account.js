coa = coa || {};
define(['jquery',
        'underscore',
        'backbone',
'text!appmodules/coa/app/templates/accountList.html'
], function($,
		_, Backbone,Template){
	coa.views.accountView = Backbone.View
		.extend({
			tagName : 'tr',
			className : 'account-view active',
			model : coa.models.Account,
			events : {
				
			},
			initialize : function() {
				this.render();
			},
			template : _.template(Template),

			render : function() {
				var _accountAvilable = coa.user.get("accounts").toJSON();
				if(_accountAvilable && _accountAvilable.length>0){
					this.$el.empty();
					this.$el.html(this.template({accounts:_accountAvilable}));
					$("#changeTypeMailing").prop("data-accounts-loaded",true);
					
					 $('.select-all').removeAttr("disabled");
				}
				else
					{
					$('.select-all').attr("disabled",true);
					}
				
				
				
			}
		});
});