// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var LumpsumBookModelSchema = new mongoose.Schema({
    lumpsumBookResp: {
        type: Array,
        "default": []
    }
});

var LumpsumBookModelLookUp = mongoose.model('LumpsumBookModelLookUp', LumpsumBookModelSchema);

var LumpsumBookModel = new LumpsumBookModelLookUp({
    lumpsumBookResp : {
  "AUMAgeing": {
    "fundWiseData_AUMAgeingResp": [{
      "assetCategory": "LIQUID",
      "ltOneYr": "5690990.96",
      "oneToThreeYrs": "5644.80",
      "threeToFiveYrs": "401103.74",
      "gtFiveYrs": "162889.78",
      "grandTotal": "6260629.28"
    }, {
      "assetCategory": "ELSS",
      "ltOneYr": "5324868.07",
      "oneToThreeYrs": "8929420.29",
      "threeToFiveYrs": "6627108.63",
      "gtFiveYrs": "31848301.75",
      "grandTotal": "52729698.74"
    }, {
      "assetCategory": "EQUITY",
      "ltOneYr": "112966502.21",
      "oneToThreeYrs": "69452905.83",
      "threeToFiveYrs": "54037722.72",
      "gtFiveYrs": "315684954.03",
      "grandTotal": "552142084.79"
    }, {
      "assetCategory": "FEEDER",
      "ltOneYr": "508657.91",
      "oneToThreeYrs": "4403793.59",
      "threeToFiveYrs": "0",
      "gtFiveYrs": "0",
      "grandTotal": "4912451.50"
    }, {
      "assetCategory": "FIXED INCOME",
      "ltOneYr": "105030448.45",
      "oneToThreeYrs": "145267360.70",
      "threeToFiveYrs": "12249826.35",
      "gtFiveYrs": "195057935.92",
      "grandTotal": "457605571.42"
    }, {
      "assetCategory": "FOF",
      "ltOneYr": "28918619.97",
      "oneToThreeYrs": "390639.27",
      "threeToFiveYrs": "531511.57",
      "gtFiveYrs": "2777456.54",
      "grandTotal": "32618227.35"
    }, {
      "assetCategory": "BALANCED",
      "ltOneYr": "1126403.55",
      "oneToThreeYrs": "2571056.59",
      "threeToFiveYrs": "2150356.82",
      "gtFiveYrs": "11167110.21",
      "grandTotal": "17014927.17"
    }],
    "total": {
      "assetCategory": "GRAND TOTAL",
      "ltOneYr": "259566491.12",
      "oneToThreeYrs": "231020821.07",
      "threeToFiveYrs": "75997629.83",
      "gtFiveYrs": "556698648.23",
      "grandTotal": "1123283590.25"
    }
  },
  "fundsPurchased": {
    "fundWiseData_purchased": [{
      "name": "Franklin India High Growth Companies Fund",
      "amount": "4760240.50"
    }, {
      "name": "Franklin India Income Builder Account",
      "amount": "3538434.50"
    }, {
      "name": "Franklin India Ultra Short Bond Fund",
      "amount": "1017216.63"
    }, {
      "name": "Franklin India Treasury Management Account",
      "amount": "678053.44"
    }, {
      "name": "Franklin India Prima Plus",
      "amount": "463137.48"
    }, {
      "name": "Franklin India Low Duration Fund",
      "amount": "461361.56"
    }, {
      "name": "Franklin India Monthly Income Plan",
      "amount": "200895.14"
    }, {
      "name": "Franklin India Smaller Companies Fund",
      "amount": "150000"
    }, {
      "name": "Franklin India Taxshield Openend",
      "amount": "100000"
    }, {
      "name": "Franklin India Income Fund",
      "amount": "50000"
    }],
    "total": {
      "name": "Total",
      "amount": "11419339.25"
    }
  },
  "fundsRedeemed": {
    "fundWiseData_fundsRedeemed": [{
      "name": "Franklin India Income Builder Account",
      "amount": "11532378.57"
    }, {
      "name": "Franklin India Income Opportunities Fund",
      "amount": "3392042.02"
    }, {
      "name": "Franklin India Corporate Bond Opportunities Fund",
      "amount": "1416244.34"
    }, {
      "name": "Franklin India Blue Chip Fund",
      "amount": "1064468.02"
    }, {
      "name": "Franklin India Prima Plus",
      "amount": "960949.52"
    }, {
      "name": "Franklin India Treasury Management Account",
      "amount": "690000.46"
    }, {
      "name": "Franklin India Flexi Cap Fund",
      "amount": "578798.11"
    }, {
      "name": "Franklin India Low Duration Fund",
      "amount": "529364.74"
    }, {
      "name": "Franklin India Ultra Short Bond Fund",
      "amount": "356155.79"
    }, {
      "name": "Franklin India High Growth Companies Fund",
      "amount": "314184.21"
    }],
    "total": {
      "name": "Total",
      "amount": "19743723.61"
    }
  }
}
}
);

LumpsumBookModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating LumpsumBookModelLookUp table, please contact admin...');
    } else {
        LumpsumBookModelLookUp.remove({}, function(err) {
            console.log('LumpsumBookModelLookUp collection removed');
            LumpsumBookModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating LumpsumBookModelLookUp table, please contact admin...');
                }
                console.log('LumpsumBookModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = LumpsumBookModelLookUp;
