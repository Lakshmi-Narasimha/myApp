(function() {
  'use strict';

  angular.module('CSS.common', ['CSS.commonconstants', 'CSS.commonfilter', 'CSS.commonconstants', 'CSS.commonimgcontants']);
})();
