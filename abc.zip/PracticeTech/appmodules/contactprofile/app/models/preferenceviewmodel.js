define([], function () {

    var instance = null;
    function init() {
        var data = {
            emails: undefined,
            onlineAccess: undefined,
            documentDelivery:undefined,
            alertsAndCommunication:undefined,
            communication:undefined,
        };
        return {
            setData: function (key,value) {
            	data[key] = value;
            },
            getData: function () {
                return data;
            },
            clearData: function () {
            	data = {
                        emails: undefined,
                        onlineAccess: undefined,
                        documentDelivery:undefined,
                        alertsAndCommunication:undefined,
                        communication:undefined,
                    }
            }
        };
    };
    
    if (!instance) {
        instance = init();
    }
    return instance;
    
    
});