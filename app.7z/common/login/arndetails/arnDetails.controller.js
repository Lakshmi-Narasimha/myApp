/**
 * @ngdoc property
 * @name Forgot Password controller
  * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function arnDetailsController ($scope, $state,$filter,TransactConstant,$uibModal,constants,advisorRegistrationModelService,$cookies,appConfig, toaster) {
    	 $scope.formData={};
       $scope.otpObj={};
       $scope.backBtn=function($event){
    	 	$event.preventDefault();
    	 	$state.go('loginmaster.register');
    	 }
    	 $scope.headingObj = {
     		text : 'Register'
     	}
     
      $scope.arnSubmit=function(){ 
              $scope.displayError = "";
        	 //if($scope.arnForm.$valid){
            //post call to validate arn details
              $scope.$broadcast(constants.login.ARN_SUBMTTED_TEXT);
              $scope.formData=advisorRegistrationModelService.getArnData();
              $scope.formData.regType = advisorRegistrationModelService.getUserType();
              if(!$scope.formData.panARN){
                $scope.displayError = "ARN field cannot be empty";
              }else if(!$scope.formData.dobOrRegDate){
                $scope.displayError = "Please enter ARN registration date";
              }else{
                /*var saveSuccess = function (response) {
                    $state.go('loginmaster.otpdetails');
              };

              var saveFailure = function (errResponse) {
                 toaster.error(errResponse.data[0].errorDescription);
              };*/ 
               var loadPostSuccess = function (successResponse){  
                  var otpdetails={};
                    otpdetails.mobileNo = successResponse.data.mobile;
                    otpdetails.emailId = successResponse.data.emailId;
                    otpdetails.guId=successResponse.data.guId;

                    advisorRegistrationModelService.setUserData(otpdetails);
                    advisorRegistrationModelService.setUserDetails(successResponse.data.panARN);
                    $cookies.remove('accessToken', {'domain': appConfig.DOMAIN_CONFIG});
                    $cookies.remove('guId', {'domain': appConfig.DOMAIN_CONFIG});
                    $cookies.put('accessToken',successResponse.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
                    $cookies.put('userType', successResponse.data.userType, {'domain': appConfig.DOMAIN_CONFIG});
                    /*advisorRegistrationModelService.postRequestForOtpDetails(otpdetails).then(saveSuccess,saveFailure);*/
                     $state.go('loginmaster.otpdetails');
                    
               };

               var loadPostFailure = function (errResponse){
                  $scope.displayError = "";
               };
                  
               var arnPostSuccess = function(successResponse){
                   var paramObj = {
                      guId : successResponse.data.guId,
                      userId:null,
                      password:null
                   };
                   advisorRegistrationModelService.loadAdviserDetails(paramObj).then(loadPostSuccess, loadPostFailure);
               };

                var arnPostFailure = function (errResponse) {
                    $scope.displayError = errResponse.data[0].errorDescription;
                };
                
                advisorRegistrationModelService.postArnDetails($scope.formData).then(arnPostSuccess, arnPostFailure);
              }
              
 
           //}
     }  

}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
arnDetailsController.$inject = ['$scope', '$state','$filter','TransactConstant','$uibModal','constants','advisorRegistrationModelService','$cookies','appConfig','toaster'];
module.exports = arnDetailsController;