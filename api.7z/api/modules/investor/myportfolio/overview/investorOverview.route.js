'use strict';

var express = require('express');
var router = express.Router();
var panViewModel = require('./getPanView.model');
var folioViewModel = require('./getFolioView.model');
var accViewModel = require('./getAccountView.model');

// api route
router.route('/clients/clientStatement')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        var findModel = {
            'F': folioViewModel,
            'PA': panViewModel,
            'A': accViewModel,
            'PF': panViewModel
        };
        
        findModel[req.query.flag].find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {
                res.json(data[0].viewData[0]);
                //res.send(500, error);
            }

        });
    });

module.exports = router;
