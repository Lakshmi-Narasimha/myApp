/**
 * @ngdoc service
 * @name Common Service
 * @requires submitPaymentDetailsService
 * @description
 *
 * - Submit Payment Details JSON  / Method
 */

(function() {
    'use strict';

    angular.module('CSS.common').service('submitPaymentDetailsService', ['$http', '$q', function($http, $q) {

        this.submitPaymentDetails = function(queryData) {
            var deferred = $q.defer();
            var config;
            config = {
                method: 'post',
                url: 'http://localhost:9900/submitPaymentDetails/submitPaymentDetails',
                data: queryData,
            };

            $http(config)
                .success(function(data, status, headers, config) {
                    deferred.resolve(data);
                })
                .error(function(data) {
                    deferred.reject(data);
                });

            return deferred.promise;
        };        
        
    }]);

})();