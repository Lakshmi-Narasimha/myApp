'use strict';

var fticbreadcrumbs = function (fticLoggerMessage, loggerConstants) {
    return {
        template: require('./breadcrumbs.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function ($scope, $element, $attrs) {
            $scope.breadcrumbs = [];
            /*
				breadcrumb = {
					text : '',
					state : ''
				}
            */

            $scope.on('addBreadCrumb',function(){
            	alert("added")
            	$scope.breadcrumbs.push(breadcrumb)
            })
            $scope.goState = function(breadcrumb) {
            	$state.go(breadcrumb.state)
            }
            	
        },
        
    }
};
fticbreadcrumbs.$inject = ['fticLoggerMessage', 'loggerConstants'];
module.exports = fticbreadcrumbs;