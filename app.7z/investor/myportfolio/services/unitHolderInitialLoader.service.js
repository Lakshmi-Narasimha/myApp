/**
 * @ngdoc property
 * @name unitHolderInitialLoader
 * @requires unitHolderModel
 * @requires investorEvents
 * @requires fticLoggerMessage
 * @description
 *
 * - unitHolderInitialLoader loads all the initial services for unit holder details in 
 *   Statements tab of my investors page.
 *
 **/

'use strict';

var unitHolderInitialLoader = function(unitHolderModel, investorEvents) {

    var unitHolderInitialLoadService = {
        _isServicesData: false,
        loadAllServices: function(scope) {
            function unitHolderDataSuccess(data) {
                unitHolderModel.setUnitHolderObj(data[0]);
                investorEvents.myPortfolio.accountStmtsUnitHolder(scope);
            }

            function promiseFailure(data) {
                unitHolderInitialLoadService._isServicesData = false;
                console.log(data); // Need to handle this for all service methods called
            }

            unitHolderModel.getUnitHolderDetails()
                .then(unitHolderDataSuccess, promiseFailure);

            
        }
    };
    return unitHolderInitialLoadService;
};

unitHolderInitialLoader.$inject = ['unitHolderModel', 'investorEvents'];
module.exports = unitHolderInitialLoader;
