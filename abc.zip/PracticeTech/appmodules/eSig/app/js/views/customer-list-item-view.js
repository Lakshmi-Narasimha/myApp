define(['backbone',
        'appmodules/eSig/app/js/audit',
        'text!appmodules/eSig/app/templates/customerListItem.html' ], 
        function (Backbone, AuditLog,TempView) {
	var customerListItemView = Backbone.View.extend({
		tagName : 'div',
		template : _.template(TempView),
		events : {
			  'click .sign-initiate': 'loadDocToSign',
		},
		initialize : function() {
			this.docid = null;
		},
		render : function(docid) {
			this.docid = docid;
			this.$el.html(this.template(this.model.attributes));
			return this;
		},
		loadDocToSign : function() {
		    var cid = this.model.get('signerId'), _route, _signerType, eventId;

		    _route = 'eSig/sign-document-view/' + cid + "/" + this.docid;
			_signerType = this.model.get("signerContextCd");
			
			if (_signerType == "DMU") {
				eventId = 101;
			}else if(_signerType=="COLA"){
				eventId = 100;
			}
			this.setlogAuditParams(eventId);
            this.logAudit();            
			Backbone.history.navigate(_route, true); 
		},
		setlogAuditParams: function (eventid) {
			var signerName,_self = this;
			signerName = _self.model.get('firstName')+" "+_self.model.get('middleName')+" "+_self.model.get('lastName');
			var params = {
				//"docid": _self.docid,
				"signerId": _self.model.get('signerId'),
				"signerName": signerName,
				"eventId": eventid
			}
			AuditLog.setAuditLogParams(params);
		},
		
		logAudit: function () {
		    AuditLog.sendAudit();
		},
		/* Function to change the index into words. Eg: 1 will be given as First, 2 as Second and so on.  */
		addListLabel: function(label){
//			var a = ['','First ','Second ','Third ','Fourth ', 'Fiveth ','Sixth ','Seventh ','Eighth ','Nineth ','Tenth ','Eleventh ','Twelveth ','Thirteenth ','Fourteenth ','Fifteenth ','Sixteenth ','Seventeenth ','Eighteenth ','Nineteenth '];
//			var b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            var cid = this.model.get('signerId');
            
            $("#"+cid+' .eSig-verify-field-label').text(label);	
//			var _indexInWords = inWords(index);
//			if(_indexInWords !== 'overflow'){
//				
//			}
//            			
//			function inWords (num) {
//			    if ((num = num.toString()).length > 2) return 'overflow';
//			    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
//			    if (!n) return; var str = '';
//			     str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
//			    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';
//			    return str;
//			}
		}

	});
	return customerListItemView;
});