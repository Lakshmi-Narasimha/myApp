/**
 * @ngdoc property
 * @name accountStmtInitialLoader
 * @requires folioViewModel
 * @requires investorEvents
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - accountStmtInitialLoader loads all the initial services for Account statements in 
 *   Statements tab of my investors page.
 *
 **/

'use strict';

var folioViewInitialLoader = function(folioViewModel, investorEvents, fticLoggerMessage, loggerConstants, toaster, invFolioDetailsModel, $loader, authenticationService) {
    var folioFilterObj;
    var folioViewInitialLoadService = {
        _isServicesData: false,
        loadAllServices: function(scope, folioFilter) {
 
            function folioViewDataSuccess(data) {
                // $timeout(function(){
                folioViewModel.setFolioViewObj(data);
                investorEvents.myPortfolio.accountStmtsFolioView(scope);
                // }, 5000);
            }

            function promiseFailure(error) {
                folioViewInitialLoadService._isServicesData = false;
                toaster.error(error.data[0].errorDescription);
                // console.log(data); // Need to handle this for all service methods called
            }

            function stopLoader(){
                $loader.stop();
            }

            $loader.start();
            folioViewModel.getFolioViewDetails(folioFilter)
                .then(folioViewDataSuccess, promiseFailure).finally(stopLoader);


        },
        loadFolioAccountDetails: function(scope) {
            function promiseFailure(error) {
                folioViewInitialLoadService._isServicesData = false;
                toaster.error(error.data[0].errorDescription);
                //console.log(data); // Need to handle this for all service methods called
            }

            function folioAccountsDataSuccess(data) {
                invFolioDetailsModel.setFolioAccountData(data);
                investorEvents.myPortfolio.folioAccountDetails(scope);
            }

            function stopLoader(){
                $loader.stop();
            }

            //get folio id for statement dropdown
            folioFilterObj = { 'flag': 'P', 'guId': authenticationService.getUser().guId};

            $loader.start();
            invFolioDetailsModel.getFolioAccountDetails(folioFilterObj)
                .then(folioAccountsDataSuccess, promiseFailure).finally(stopLoader);
        }
    };
    return folioViewInitialLoadService;
};

folioViewInitialLoader.$inject = ['folioViewModel', 'investorEvents', 'fticLoggerMessage', 'loggerConstants', 'toaster', 'invFolioDetailsModel', '$loader', 'authenticationService'];
module.exports = folioViewInitialLoader;
