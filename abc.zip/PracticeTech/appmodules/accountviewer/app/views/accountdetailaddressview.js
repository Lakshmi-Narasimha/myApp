define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailaddressview.html'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetAccountAddress(this.accountSummary.accountId)
                .then(function(addressData) {
                    self.renderSection(SectionTemplateHtml, {address: addressData});
                })
                .fail(this.handleServiceError);
        }
    });

    return SectionView;
});