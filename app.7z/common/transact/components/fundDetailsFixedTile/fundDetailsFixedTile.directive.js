'use strict';

var fundDetailsFixedTile = function(fundDetails, eventConstants) {
	return{
        template: require('./fixedTile.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function($scope){                                  
           
            $scope.data = fundDetails.getFundDetails();

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){

                // functionality here
                alert("Icon Clicked");

                });

            $scope.remove = function(index) {
                fundDetails.removeTile(index);
            };  
        }]
    }
}

fundDetailsFixedTile.$inject = ['fundDetails', 'eventConstants'];
module.exports = fundDetailsFixedTile;