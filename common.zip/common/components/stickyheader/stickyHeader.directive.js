/**
 * @ngdoc directive
 * @name sticky-header 
 * @requires eventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - It displays the count of recommendations and notifications in the transaction status bar 
 *   (sticky header) section of the advisor dashboard page.
 * 
 *
 **/

'use strict';

var stickyHeader = function( fticLoggerMessage, loggerConstants, eventConstants, constants, $cookies, authenticationService, $state,transactModel){
	return{
		template : require('./stickyHeader.html'),
		restrict : 'E',
		controller :['$scope', function($scope){	
			if(authenticationService.getAppName() == "guest") {
				$scope.isAdvisorApp = false;
			}else{
				$scope.isAdvInvApp = true;
			}

			$scope.redirectAdvisorApp = $cookies.get("userRedirectURI");

			if($scope.app){
				$scope.transactOptions = constants[$scope.app].TRANSACT_CONSTANTS;
			}

			// var recCount = $scope.$on(constants.Dashboard.ADV_RC_CNT,function(event,data){

			// 	var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.ADVISOR_COMPONENTS_MODULE + ' | ' + loggerConstants.STICKY_HEADER_DIRECTIVE + ' | on ' + advisorEventConstants.Dashboard.ADV_RC_CNT + ' event' /* Function Name */; 
   //                  fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

			// 	$scope.recommendationsCount = data.advisorRecommendationsCount;				
			// 	$scope.destroyEvent();								
			// })
			
			// $scope.$on(constants.Dashboard.ADV_NOT_CNT,function(event,data){							

			// 	var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.ADVISOR_COMPONENTS_MODULE + ' | ' + loggerConstants.STICKY_HEADER_DIRECTIVE + ' | on ' + advisorEventConstants.Dashboard.ADV_NOT_CNT + ' event' /* Function Name */; 
   //                  fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

			// 	$scope.notificationsCount = data.advisorNotificationsCount;
			// })

			$scope.destroyEvent = function () {
				recCount();
			}

			$scope.reset = function(transactType){
				if(authenticationService.isInvestorLoggedIn()) {
					
					$state.go(transactType);
					$scope.$emit('RESET_PREVIOUS_DATA');
					transactModel.setStateValue({key: null}); //Resetting state params for issue when navigating. 
				}else {
					var toStateVal = $cookies.get("userRedirectURI")+"#/transact/base/"+transactType;
					var transactState = "transact.base."+transactType;
					$scope.$emit(eventConstants.NAVIGATE_CHECK, toStateVal, transactState);
					$scope.$emit(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_RESET, {});
				}
			}

			   $scope.$on('RESET_PREVIOUS_DATA', function() {
                transactModel.setFundDetails('');
              });
		}]	
	}
}

stickyHeader.$inject = ['fticLoggerMessage', 'loggerConstants', 'eventConstants', 'constants', '$cookies', 'authenticationService', '$state','transactModel'];
module.exports = stickyHeader;