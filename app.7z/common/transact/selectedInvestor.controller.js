/**
 * @ngdoc property
 * @name selectedInvestorCtrl
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function selectedInvestorCtrl(transactModel, TransactConstant) {
    console.log('selectedInvestorCtrl');
    //transactModel.setTransactType(TransactConstant.transact.TRANSACT);
}
selectedInvestorCtrl.$inject = ['transactModel', 'TransactConstant'];
module.exports = selectedInvestorCtrl;