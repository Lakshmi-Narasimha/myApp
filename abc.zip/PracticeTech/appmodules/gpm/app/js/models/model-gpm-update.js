
define(['jquery', 'underscore', 'backbone', 'backboneRelational', 'appmodules/gpm/app/js/lib/validate.js', 'appcommon/commonutility',
'appmodules/contactprofile/app/models/cpviewmodel', 'appcommon/data', 'services/dataservice', 'appcommon/globalcontext', 'appcommon/constants'],
function ($, _, Backbone, backboneRelational, Validator, CommonUtil, CPViewModel, GPMdata, DataService, GlobalContext, Constants) {
	var ItemNameTypeMapping = {
			gender:"Gender"
	}
	var GPMFieldModel = Backbone.Model.extend({
		defaults : {
			itemType:null,
			itemLabel:null,
			currentItemValue:null,
			currentItemValueId:null,
			changedItemValue:null,
			changedItemValueId:null,
			orderIndex:null,
			dataSource : 'COLA',
			customValues:null,
			isComplexType:false,
			sectionId:null
		}
	});
	var ColaPhoneNumModel = Backbone.Model.extend({
		defaults : {
				NANPAreaCd: null,
				NANPExchCd: null,
				NANPSbscNbr:null,
				SMSEnrlStatCd: null,
				clTeleId: null,
				nonNANPPhnNbr:null,
				phnCtryCd: null,
				phnExtnNbr: null,
				phnLblTxt: null,
				phnPrfrCd:null,
				phnSubLblTxt:null,
				prefCode: "02",
				preferredPhone: false,
				textEnabled: false,
				phoneTypeCd:null,
				phnRemarks:""
		}
	});	 var EbixPhoneNumModel = Backbone.Model.extend({
		defaults : {
			AreaCode: null,
			BadPhoneNumber: null,
			CountryCode: null,
			ElectronicDownload: null,
			Extension: "",
			FullPhoneNumber: null,
			Id: null,
			Number: null,
			PhoneType: null,
			PhoneTypeDesc: null,
			Preferred: "0",
			type: null,
			phoneTypeCd:null,
			phnRemarks:""
	}
});	
	 var ColaEmailModel = Backbone.Model.extend({
			defaults : {
				clCtx: "COLA.CL",
				clId: null,
				emlAddr: null,
				emlFuncStatCd: null,
				emlUseCd: null,
				emlVldStatCd: "Valid",
				endTs: null,
				Preferred: false,
				preferredEmail: false,
				sttTs: null,
		}
	});
	 var EbixEmailModel = Backbone.Model.extend({
			defaults : {
				Address:null,
				ElectronicDownload: "0",
				Id: null,
				Preferred: false,
				WebAddressType: "1",
				WebAddressTypeDesc: "Email",
				preferredEmail: false,
				type: "WebAddresses",
		}
	});
	function checkIsDevice(){
        var _regxMob = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
        return _regxMob.test(navigator.userAgent);
    
	}
    //Conditional display based on Entity type            
	var industryOptionCode = ['1C', '1S', '02', '05', '6C', '6S', '10'];
	var operatingEntityCode = ['1C', '1S', '02', '05', '6C', '6S', '10'];
	var entityLocationCode = ['1C', '1S', '02', '04', '05', '6C', '6S', '09', '10'];
	
	var GPMUPdateModel = Backbone.Model.extend({
		defaults : {
			currentItemSet:false,
			isDevice:false,
			updateMode :null,
			completedSteps:[],
			stepsToComplete:2,
			submitStatus:"success",//cola, ebix
			items:[],
			itemSections:[],
			hasSections: false,
            referrer:{}
			
		},
		/*itemSections structure {"sectionId":"","sectionLabel":"","items":[] } */
		initialize : function(){
			this.data = {};
		},
		validate: function (formId, showError) {		  
			return Validator.validateInputs(formId,showError) ;
		},
		
		addAdditionalEbixDataToModel:function(updateMode){
			var CPData = CPViewModel.getInstance().getData();
	       	if(CPData.ebix){
	       		_ebixData = CPData.ebix.PersonContact.attributes;	
	       		var 	_greeting = (CPData.ebix && CPData.ebix.PersonContact && CPData.ebix.PersonContact.get('clGreeting')) ? CPData.ebix.PersonContact.get('clGreeting') : "",
	       				_remarks = (CPData.ebix && CPData.ebix.remarks) ? CPData.ebix.remarks : "",
	       				_subtype = (CPData.ebix && CPData.ebix.contactSubType) ? CPData.ebix.contactSubType : "",
	       				_jobTitle = _ebixData.clJobTitle;
	       		switch (updateMode) {
	       		case "greeting": 
	       			this.addItem({itemType:"remarks",itemLabel:"Remarks",currentItemValue:_remarks, currentItemValueId:_remarks,orderIndex:1});
	       			this.addItem({itemType:"contactSubType",itemLabel:"Sub-type",currentItemValue:_subtype, currentItemValueId:_subtype,orderIndex:1});
	       			this.addItem({itemType:"clJobTitle",itemLabel:"Job title",currentItemValue:_jobTitle, currentItemValueId:_jobTitle,orderIndex:1});
					break;
				case "remarks": 
	       			this.addItem({itemType:"contactSubType",itemLabel:"Sub-type",currentItemValue:_subtype, currentItemValueId:_subtype,orderIndex:1});
	       			this.addItem({itemType:"clGreeting",itemLabel:"Greeting",currentItemValue:_greeting, currentItemValueId:_greeting,orderIndex:1});
	       			this.addItem({itemType:"clJobTitle",itemLabel:"Job title",currentItemValue:_jobTitle, currentItemValueId:_jobTitle,orderIndex:1});
					break;
				case "subtype": 
				    this.addItem({ itemType: "remarks", itemLabel: "Remarks", currentItemValue: _remarks, currentItemValueId: _remarks, orderIndex: 1 });
	       			this.addItem({itemType:"clGreeting",itemLabel:"Greeting",currentItemValue:_greeting, currentItemValueId:_greeting,orderIndex:1});
	       			this.addItem({itemType:"clJobTitle",itemLabel:"Job title",currentItemValue:_jobTitle, currentItemValueId:_jobTitle,orderIndex:1});
					break;

				default:
					break;
				}
	       	}
		},
		setClientInfo : function(){
        	var CPData = CPViewModel.getInstance().getData();
        	var cliemtName = ""
        		if(CPData.cola.personClient.get("clLastNm")){
        			cliemtName = CPData.cola.personClient.get("clLastNm")+ ", "+CPData.cola.personClient.get("clFirstNm");
        		}else{
        			cliemtName = CPData.cola.orgClient.get("orgNm");
        		}
        	this.data.clientInfo = {id:CPData.cola.id, fmtId:CPData.cola.fmtId,name : cliemtName, contactId : ((CPData.ebix && CPData.ebix.id) ? CPData.ebix.id : null)};
        	
        	//Sel all require client& Advisor info to the model
        	this.set('submitterId', CommonUtil.readCookie('FMID'));
        	this.set('advisorId', GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID);
			this.set('clientName',this.data.clientInfo.name);
			this.set('clientId',this.data.clientInfo.id);
			this.set('clientFmtId',this.data.clientInfo.fmtId);
			this.set('contactId',this.data.clientInfo.contactId);
        	
        },
		setChangedValue : function(params){
			var _$formContainer = $('#gpm-update-form');
			var _updateMode = this.get('updateMode');
			var _items = this.get('items');
			switch (_updateMode) {
			case "gender":
				var _$gender = $('input[name=clientSex]:checked');
				var _gender = _items.find(function(row){return row.get("itemType") == "genderCd"});
				_gender.set('changedItemValue', _$gender.data('value'));
				_gender.set('changedItemValueId', _$gender.val());
				break;
			case "greeting": 
				var _greeting = _items.find(function(row){return row.get("itemType") == "clGreeting"});
				var _changedGreetings = $("#editContactGreet").val().trim();
				_greeting.set('changedItemValue', _changedGreetings);
				_greeting.set('changedItemValueId', _changedGreetings);
				break;
			case "remarks": 
				var _remarks = _items.find(function(row){return row.get("itemType") == "remarks"});
				var _changedRemarks = $("#editContactRemarks").html().trim();
				_remarks.set('changedItemValue', _changedRemarks);
				_remarks.set('changedItemValueId', _changedRemarks);
				break;
			case "honorific":
			    var _honorific = _items.find(function (row) { return row.get("itemType") == "honorific" });
			    var dropdownValue = $("#ci-client-honorific").val();
			    _honorific.set('changedItemValue', dropdownValue ==" "?"":dropdownValue);
			    _honorific.set('changedItemValueId', dropdownValue);
			    break;
		    case "maritalstatus":
		        var _maritalstatus = _items.find(function (row) { return row.get("itemType") == "maritalstatus" });
		        var value = $("#cd-marital-status")
		        var updateValue =   ( value.val() !== "" && value.find('option:selected').text() !== "Choose one") ? $("#cd-marital-status").find('option:selected').text() : "";
		        var updateValueId = ( value.val() !== "" && value.find('option:selected').text() !== "Choose one") ? $("#cd-marital-status").val() : "";
		        _maritalstatus.set('changedItemValue', updateValue);
		        _maritalstatus.set('changedItemValueId', updateValueId);
		        break;
			case "dependents":
			    var _dependents = _items.find(function (row) { return row.get("itemType") == "dependents" });
			    var updateValue = $("#cd-no-dependents").val();
			    _dependents.set('changedItemValue', updateValue);
			    _dependents.set('changedItemValueId', updateValue);
			break;
		    case "passport":
		        var _passport = _items.find(function (row) { return row.get("itemType") == "passport" });
		        var updateValue = $("#cd-passport-number").val().trim();
		        _passport.set('changedItemValue', updateValue);
		        _passport.set('changedItemValueId', updateValue);
			    break;
			case "subtype": 
			    var _subtype = _items.find(function(row){return row.get("itemType") == "contactSubType"});
			    var dropdownValue = $("#sub-contact-type").val();
			    _subtype.set('changedItemValue', dropdownValue ==" "?"":dropdownValue);
			    _subtype.set('changedItemValueId', dropdownValue)
				break;
			case "driverslicense": 
				var _driverslicense = _items.find(function(row){return row.get("itemType") == "driverslicense"});
				var _stateid = _items.find(function(row){return row.get("itemType") == "stateid"});
				var _driverLicenseChanged = $("#cd-driver-license").val().trim();
				_driverslicense.set('changedItemValue', _driverLicenseChanged);
				_driverslicense.set('changedItemValueId', _driverLicenseChanged);
			
					if(_driverLicenseChanged.length != 0){
						_stateid.set('changedItemValue',($("#us-states-list-details-page").val() != "" ? $("#us-states-list-details-page :selected").text() : ""));
						_stateid.set('changedItemValueId',$("#us-states-list-details-page").val());
					}else{
						_stateid.set('changedItemValue',"");
						_stateid.set('changedItemValueId',"");
					}
					break;
				case "reportclientsdeath":
					var $dateOfDeath = $('#pt-date-of-death');
					var dateOfDeath = "Unknown", _$dateOfDeathActiveOption = $('input[name="pt-deathdate-radio-grp"]:checked')
					var _clientDateOfDeath = _items.find(function (row) { return row.get("itemType") == "clientDateOfDeath" });
					var _clientContactName = _items.find(function (row) { return row.get("itemType") == "clientContactName" });
					var _clientAdditionalInfo = _items.find(function (row) { return row.get("itemType") == "clientAdditionalInfo" });

					((_$dateOfDeathActiveOption.attr("id") == "pt-clients-death-date" && $dateOfDeath.val() != '') ? dateOfDeath = $dateOfDeath.val() : dateOfDeath = 'Unknown');
					_clientDateOfDeath.set('changedItemValue', dateOfDeath);
					_clientDateOfDeath.set('changedItemValueId', dateOfDeath);

					var arrayLength = $('.contact-container').length;
					var containerLength = 0;
					var contactArray = [];

					var clientIdVal = '', fmtIdVal = '', fmcidVal = '', contactIdVal = '', contactNameVal = '', isContactClientVal = '', contactTypeVal = '', contactFirstNameVal = '', contactLastNameVal = '', addrLine1Val = '', addrLine2Val = '', addrLine3Val = '', contactCityVal = '', contactStateVal = '', contactZipVal = '', phoneNumberVal = '', relationTypeVal = '', clientIdVal = '', contactFmtIdVal = '', contactAddressVal = '', isContactAddedVal = '';

					isContactAddedVal = _$formContainer.find('button[name="iscontactNotify"].active').text();
					if (isContactAddedVal == "Yes") {
						isContactClientVal = _$formContainer.find('button[name="isContactClient"].active').text();
						if (isContactClientVal == 'Yes') {
							contactNameVal = $('.pt-cli-contact-name input').val();
							contactFirstNameVal = $('.pt-cli-contact-name input').attr('firstname');
							contactLastNameVal = $('.pt-cli-contact-name input').attr('lastname');
							clientIdVal = $('#pt-cli-contact-name input').attr('data-contactid');
							contactFmtIdVal = $('#pt-cli-contact-name input').attr('clientid');
							contactTypeVal = $('.clientTypeInd').text();
							var contactAddress = $('#contact-address').find('input[name="contact-address-radio-group"]:checked');
							var contactAddressId = contactAddress.attr('id');
							contactAddressVal = $.trim($('label[for="' + contactAddressId + '"]').text());
							addrLine1Val = contactAddress.data('line1');
							addrLine2Val = contactAddress.data('line2');
							addrLine3Val = contactAddress.data('line3');
							contactCityVal = contactAddress.data('city');
							contactStateVal = contactAddress.data('state');
							contactZipVal = contactAddress.data('zip').toString();
							phoneNumberVal = $('#contact-phoneNumber').find('input[name="contact-phone-radio-group"]:checked').val();
							relationTypeVal = $('#pt-relationship-opts-noInd option:selected').text();
						} else if (isContactClientVal == 'No') {
							contactTypeVal = _$formContainer.find('input[name="pt-contact-type-radio-group"]:checked').val();
							if (contactTypeVal == 'Individual') {
								contactFirstNameVal = _$formContainer.find('input[name="contactFirstName"]').val();
								contactLastNameVal = _$formContainer.find('input[name="contactLastName"]').val();
								contactNameVal = contactFirstNameVal + ' ' + contactLastNameVal;
							}
							if (contactTypeVal == 'Organization') {
								contactNameVal = _$formContainer.find('input[name="contactFullName"]').val();
							}
							addrLine1Val = _$formContainer.find('input[name="contactAddressLine1"]').val();
							addrLine2Val = _$formContainer.find('input[name="contactAddressLine2"]').val();
							addrLine3Val = _$formContainer.find('input[name="contactAddressLine3"]').val();
							contactCityVal = _$formContainer.find('input[name="contactCity"]').val();
							contactStateVal = $('#income-state-list-select option:selected').text();
							contactZipVal = _$formContainer.find('input[name="contactZipCode"]').val().toString();
							contactAddressVal = addrLine1Val + ' ' + addrLine2Val + ' ' + addrLine3Val + ' ' + contactCityVal + ' ' + contactStateVal + ' ' + contactZipVal;
							phoneNumberVal = $('.areaCd').val() + $('.exchCd').val() + $('.sbsNbr').val();
							relationTypeVal = $('#pt-relationship-opts option:selected').text();
						}
						relationTypeVal = ((relationTypeVal == "" || relationTypeVal == "Choose one") ? "" : relationTypeVal);

						contactArray.push({
							'clientId': clientIdVal,
							'fmtId': contactFmtIdVal,
							'fmcid': '',
							'contactId': '',
							'contactName': contactNameVal,
							'isContactAdded': isContactAddedVal,
							'isContactClient': isContactClientVal,
							'contactType': contactTypeVal,
							'contactFirstName': contactFirstNameVal,
							'contactLastName': contactLastNameVal,
							'contactAddress': contactAddressVal,
							'addrLine1': addrLine1Val,
							'addrLine2': addrLine2Val,
							'addrLine3': addrLine3Val,
							'contactCity': contactCityVal,
							'contactState': contactStateVal,
							'contactZip': contactZipVal,
							'phoneNumber': phoneNumberVal,
							'relationType': relationTypeVal
						});
						containerLength = 1;
					}
					
					

					for (i = 0; i < arrayLength; i++) {

						var clientIdVal = '', fmtIdVal = '', fmcidVal = '', contactIdVal = '', contactNameVal = '', isContactClientVal = '', contactTypeVal = '', contactFirstNameVal = '', contactLastNameVal = '', addrLine1Val = '', addrLine2Val = '', addrLine3Val = '', contactCityVal = '', contactStateVal = '', contactZipVal = '', phoneNumberVal = '', relationTypeVal = '', clientIdVal = '', contactFmtIdVal = '', contactAddressVal = '', isContactAddedVal = '';

						var contactNameVal = $('.contact-container .ctn-name-val:eq(' + i + ')').text();
						var contactFirstNameVal = $('.contact-container .ctn-name-val:eq(' + i + ')').attr('firstname');
						var contactLastNameVal = $('.contact-container .ctn-name-val:eq(' + i + ')').attr('lastname');

						var contactFmtIdVal = $('.contact-container .ctn-name-val:eq(' + i + ')').data('attr');
						var clientIdVal = $('.contact-container:eq(' + i + ')').data('clientid');
						var contactTypeVal = $('.contact-container .ctn-contant-info-val:eq(' + i + ')').text();
						var relationTypeVal = $('.contact-container .ctn-relation-info-val:eq(' + i + ')').text();
						relationTypeVal = ((relationTypeVal == "" || relationTypeVal == "Choose one") ? "" : relationTypeVal);
						var contactAddressVal = $('.contact-container .ctn-address-info-val:eq(' + i + ')').text();

						var addrLine1Val = $('.contact-container .ctn-address-info-val:eq(' + i + ')').data('line1');
						var addrLine2Val = $('.contact-container .ctn-address-info-val:eq(' + i + ')').data('line2');
						var addrLine3Val = $('.contact-container .ctn-address-info-val:eq(' + i + ')').data('line3');
						var contactCityVal = $('.contact-container .ctn-address-info-val:eq(' + i + ')').data('city');
						var contactStateVal = $('.contact-container .ctn-address-info-val:eq(' + i + ')').data('state');
						var contactZipVal = $('.contact-container .ctn-address-info-val:eq(' + i + ')').data('zip').toString();

						var phoneNumberVal = $('.contact-container .ctn-phone-info-val:eq(' + i + ')').text();

						var isContactAddedVal = $('.contact-container:eq(' + i + ')').data('contactadded');
						var isContactClientVal = $('.contact-container:eq(' + i + ')').data('isclient');

						contactArray.push({
						'clientId': clientIdVal,
						'fmtId': contactFmtIdVal,
						'fmcid': '',
						'contactId': '',
						'contactName': contactNameVal,
						'isContactAdded': isContactAddedVal,
						'isContactClient': isContactClientVal,
						'contactType': contactTypeVal,      			
						'contactFirstName': contactFirstNameVal,
						'contactLastName': contactLastNameVal,
						'contactAddress': contactAddressVal,
						'addrLine1': addrLine1Val,
						'addrLine2': addrLine2Val,
						'addrLine3': addrLine3Val,
						'contactCity': contactCityVal,
						'contactState': contactStateVal,
						'contactZip': contactZipVal,
						'phoneNumber': phoneNumberVal,
						'relationType': relationTypeVal
						});
					}
			        arrayLength = arrayLength +containerLength;
			        _clientContactName.set('changedItemValue', contactArray);
			        _clientContactName.set('changedItemValueId', contactArray);
			        _clientAdditionalInfo.set('countofArray', arrayLength);
			        break;
			    case "reportclientsdivorce":
			        var _divorcePartyArr = [];
			        var clientName = this.get('clientName');
			        clientName = clientName.replace(/\w\S*/g, function (clientName) { return clientName.charAt(0).toUpperCase() + clientName.substr(1).toLowerCase(); });
			        _divorcePartyArr.push(clientName+ " - " +this.get('clientFmtId'));

			        var _divorceParty = _items.find(function (row) { return row.get("itemType") == "divorcingParty" });
			        var _divorceReqLetter = _items.find(function (row) { return row.get("itemType") == "divorceReqLetter" });
			        var _displayContent = _items.find(function (row) { return row.get("itemType") == "displayContent" });
			        //var _divorcePartyClientID = _items.find(function (row) { return row.get("itemType") == "divorcingPartyClientID" });

			        var divorcePartyData = $('#pt-cli-divorce-contact input');			        
			        var isDivorce = _$formContainer.find('button[name="is-divorce"].active');
			        var divorceReqLetter = _$formContainer.find('input[name="pt-divorce-radio-group"]:checked');
			        
			        if (divorcePartyData.val() != '') {
			        		divorcePartyData = divorcePartyData.val();
			        		divorcePartyData = divorcePartyData.replace(/\w\S*/g, function (divorcePartyData) { return divorcePartyData.charAt(0).toUpperCase() + divorcePartyData.substr(1).toLowerCase(); });

			        		if ($("#pt-cli-divorce-contact input").data('contacttype') == 'nonclient' || $("#pt-cli-divorce-contact input").data('contacttype') == undefined && $("#pt-cli-divorce-contact input").data('contacttype') != null) {
			        			divorcePartyData = divorcePartyData;
			        		} else {
			        			var otherPartyID = "";
			        			if (_divorceParty.get('changedItemValue')[1] != null) {
			        				otherPartyID = _divorceParty.get('changedItemValue')[1].split(" - ");
			        				if (otherPartyID != null) {
			        					if (otherPartyID[1] == undefined) {
			        						divorcePartyData = divorcePartyData;
			        					} else {
			        						divorcePartyData = divorcePartyData + " - " + otherPartyID[1];
			        					}
			        				}
			        			}
			        		}
			        		
			        		_divorcePartyArr.push(divorcePartyData);
			            
			        }

			        _divorceParty.set('changedItemValue', _divorcePartyArr);
			        _divorceParty.set('changedItemValueId', _divorcePartyArr);

			        _divorceReqLetter.set('changedItemValue', divorceReqLetter.val());
			        _divorceReqLetter.set('changedItemValueId', divorceReqLetter.attr('data-value'));

			        _displayContent.set('changedItemValue', "displayContent");
			        _displayContent.set('changedItemValueId', "displayContent");
			        
			        //_divorcePartyClientID.set('changedItemValue', _divorcePartyClientID.get('customValues').clientId);
			        //_divorcePartyClientID.set('changedItemValueId', _divorcePartyClientID.get('customValues').clientId);

                    break;
			case "suitability": 
				var _fedTxBrktPct = _items.find(function(row){return row.get("itemType") == "fedTxBrktPct"});
				var _annlIncm = _items.find(function(row){return row.get("itemType") == "annlIncm"});
				var _netWorth = _items.find(function(row){return row.get("itemType") == "netWorth"});
				var _liqNetWorth = _items.find(function (row) { return row.get("itemType") == "liqNetWorth" });
				var _sourceOfIncome = _items.find(function (row) { return row.get("itemType") == "sourceOfIncome" });

				params.sourceOfIncomeCollecModel.sort(function (inc1, inc2) {
				    if (inc1.displayOrder > inc2.displayOrder) {
				        return 1;
				    }
				    if (inc1.displayOrder < inc2.displayOrder) {
				        return -1;
				    }
				    return 0;
				});
				_sourceOfIncome.set('changedItemValue', params.sourceOfIncomeCollecModel);
				_sourceOfIncome.set('changedItemValueId', params.sourceOfIncomeCollecModel);

				var _clientProductExpes = _items.find(function (row) { return row.get("itemType") == "clientProductExpes" });
				var _doesClientHaveAssets = _items.find(function (row) { return row.get("itemType") == "doesClientHaveAssets" });
				_doesClientHaveAssets.set('changedItemValue', params.doesClientHaveAssets.desc);
				_doesClientHaveAssets.set('changedItemValueId', params.doesClientHaveAssets.id);
				_doesClientHaveAssets.set('customValues', { "viewDisplay": true, "infotype": 'heldAwayAssets' });
				var _heldAwayAssets = _items.find(function (row) { return row.get("itemType") == "heldAwayAssets" });

				if (params.doesClientHaveAssets.id == "A") {
				    _heldAwayAssets.set('changedItemValue', params.assetTypesHeldCollecModel);
				    _heldAwayAssets.set('changedItemValueId', params.assetTypesHeldCollecModel);
				    _heldAwayAssets.set('customValues', { "viewDisplay": true, "infotype": 'heldAwayAssets' });
				} else {
				    _heldAwayAssets.set('changedItemValue', []);
				    _heldAwayAssets.set('changedItemValueId', []);
				    _heldAwayAssets.set('customValues', { "viewDisplay": false, "infotype": 'heldAwayAssets' });
				}
				_fedTxBrktPct.set('changedItemValue', ($("#income-fed-tax").val() != "" ? $("#income-fed-tax :selected").text() : ""));
				_fedTxBrktPct.set('changedItemValueId', $("#income-fed-tax").val());
				_annlIncm.set('changedItemValue', $("#income-indi-annual").val().formatCurrency());
				_annlIncm.set('changedItemValueId', $("#income-indi-annual").val().replace(/,/g, '').lpad("0",11));
				_netWorth.set('changedItemValue',$("#income-indi-net").val().formatCurrency());
				_netWorth.set('changedItemValueId',$("#income-indi-net").val().replace(/,/g, '').lpad("0",15));
				_liqNetWorth.set('changedItemValue',$("#income-indi-liquid").val().formatCurrency());
				_liqNetWorth.set('changedItemValueId',$("#income-indi-liquid").val().replace(/,/g, '').lpad("0",15));			

				var _incomeInvest = _items.find(function (row) {
				    return row.get("itemType") == "doesClientHaveInvestment"
				});

				if (params.doesClientHaveInvestmentModel == "Yes") {
				    _incomeInvest.set('changedItemValue', 'Yes');
				    _incomeInvest.set('changedItemValueId', 'Yes');
				    _incomeInvest.set('customValues', { "viewDisplay": false, "infotype": 'investment' });
				}else {
					_incomeInvest.set('changedItemValue', 'No');
					_incomeInvest.set('changedItemValueId', 'No');
					_incomeInvest.set('customValues', { "viewDisplay": false, "infotype": 'investment' });
				}
				
                //Investment Experiences
				var clientProductExpesVal = [];
				params.incomeInvestmentCollectionModel.sort(function (inc1, inc2) {
				    if (inc1.displayOrder > inc2.displayOrder) {
				        return 1;
				    }
				    if (inc1.displayOrder < inc2.displayOrder) {
				        return -1;
				    }
				    return 0;
				});

				_clientProductExpes.set('changedItemValue', params.incomeInvestmentCollectionModel);
				_clientProductExpes.set('changedItemValueId', params.incomeInvestmentCollectionModel);
				_clientProductExpes.set('customValues', { "viewDisplay": (params.doesClientHaveInvestmentModel == "Yes" ? true: false), "infotype": 'investment' });				
				break;
			case "employment":
			    var _isemployed = _items.find(function (row) { return row.get("itemType") == "finInstnEmplCd" }),
                    _isofficer = _items.find(function (row) { return row.get("itemType") == "ownrOfcrCd" }),
                    _employmentstatus = _items.find(function (row) { return row.get("itemType") == "emplStatCd" }),
                    _industryClassifyType = _items.find(function (row) { return row.get("itemType") == "industryClassifyType" }),
                    _industryFreeFormText = _items.find(function (row) { return row.get("itemType") == "industryFreeFormText" }),
                    _jobtitle = _items.find(function (row) { return row.get("itemType") == "clJobTitle" }),
                    _primaryOccupatn = _items.find(function (row) { return row.get("itemType") == "occpDesc" })
			        _primaryOccupatnText = _items.find(function (row) { return row.get("itemType") == "occpDescTxt" })
                    _employerAddressCollection = _items.find(function (row) { return row.get("itemType") == "employerAddressCollection" }),
                    _finraAddressCollection = _items.find(function (row) { return row.get("itemType") == "finraAddressCollection" }),
                    _shareholderAddressCollection = _items.find(function (row) { return row.get("itemType") == "shareholderAddressCollection" }),
                    _finraSectionArr = _items.find(function (row) { return row.get("itemType") == "finraSectionArr" }),
                    _sameAsCompanyArr = _items.find(function (row) { return row.get("itemType") == "sameAsCompanyArr" });
                    var empDetails = params.employmentDetails;

                    _employmentstatus.set({
                        "changedItemValue": empDetails.empStatus.description,
                        "changedItemValueId": empDetails.empStatus.serviceVal
                    });
                    _isemployed.set({
                        "changedItemValue": empDetails.isEmployed,
                        "changedItemValueId": empDetails.isEmployed == "Yes" ? "Y" : "N"
                    });
                    _isofficer.set({
                        "changedItemValue": empDetails.isShareHolder,
                        "changedItemValueId": empDetails.isShareHolder == "Yes" ? "Y" : "N"
                    });
			        //clearing employed related fields end
                    _shareholderAddressCollection.set({
                        "changedItemValue": empDetails.shareHolderAddrsColl,
                        "changedItemValueId": empDetails.shareHolderAddrsColl
                    });
                    if (empDetails.empStatus.serviceVal != "A" && empDetails.empStatus.serviceVal != "B") {
                        //clearing employed related fields start
                        _industryClassifyType.set({
                            "changedItemValue": "",
                            "changedItemValueId": "",
                            'customValues': { "viewDisplay": false }
                        });
                        _industryFreeFormText.set({
                            "changedItemValue": "",
                            "changedItemValueId": "",
                            'customValues': { "viewDisplay": false }
                        });
                        _jobtitle.set({
                            "changedItemValue": "",
                            "changedItemValueId": "",
                            'customValues': { "viewDisplay": false }
                        });
                        _primaryOccupatn.set({
                            "changedItemValue": "",
                            "changedItemValueId": "",
                            'customValues': { "viewDisplay": false }
                        });
                        _primaryOccupatnText.set({
                            "changedItemValue": "",
                            "changedItemValueId": "",
                            'customValues': { "viewDisplay": false }
                        });
                        _employerAddressCollection.set({
                            "changedItemValue": [],
                            "changedItemValueId": [],
                            'customValues': { "viewDisplay": false }
                        });
                        _finraAddressCollection.set({
                            "changedItemValue": [],
                            "changedItemValueId": [],
                            'customValues': { "viewDisplay": false }
                        });
                        _finraSectionArr.set({
                            "changedItemValue": [],
                            "changedItemValueId": [],
                            'customValues': { "viewDisplay": false }
                        });
                        _sameAsCompanyArr.set({
                            "changedItemValue": [],
                            "changedItemValueId": [],
                            'customValues': { "viewDisplay": false }
                        });
                         
				    } else {

                    //Industry Classification
                        if (empDetails.empStatus.serviceVal == "B") {
					    _industryClassifyType.set('changedItemValue', empDetails.industryClassification.indsClsDesc);
					    _industryClassifyType.set('changedItemValueId', empDetails.industryClassification.indsClsCd);
						_industryClassifyType.set('customValues', { "viewDisplay": true });
						if (empDetails.industryClassification.indsClsCd == "IC031") {
						    _industryFreeFormText.set('changedItemValue', empDetails.industryClassification.indsClsTxt);
						    _industryFreeFormText.set('changedItemValueId', empDetails.industryClassification.indsClsTxt);
							_industryFreeFormText.set('customValues', { "viewDisplay": true });
						}
						else {
						    _industryFreeFormText.set({
						        "changedItemValue": "",
						        "changedItemValueId": "",
						        'customValues': { "viewDisplay": false }
						    });
						}
					}
					else {
					    _industryClassifyType.set({
					        "changedItemValue": "",
					        "changedItemValueId": "",
					        'customValues': { "viewDisplay": false }

					    });
					    _industryFreeFormText.set({
					        "changedItemValue": "",
					        "changedItemValueId": "",
					        'customValues': { "viewDisplay": false }
					    });
						
					}
					_primaryOccupatn.set({
					    "changedItemValue": empDetails.primaryOccupation.desc,
					    "changedItemValueId": empDetails.primaryOccupation.code,
					    'customValues': { "viewDisplay": true }
					});
					_primaryOccupatnText.set({
					    "changedItemValue": empDetails.prmroccufreeText,
					    "changedItemValueId": empDetails.prmroccufreeText,
					    'customValues': { "viewDisplay": empDetails.primaryOccupation.code.toLowerCase() === "other" }
					});
					_employerAddressCollection.set({
					    "changedItemValue": empDetails.employmentAddrsColl,
					    "changedItemValueId": empDetails.employmentAddrsColl,
					    'customValues': { "viewDisplay": true }
					});
					_finraAddressCollection.set({
					    "changedItemValue": empDetails.finraAddrsColl,
					    "changedItemValueId": empDetails.finraAddrsColl,
					    'customValues': { "viewDisplay": true }
					});
					_finraSectionArr.set({
					    "changedItemValue": empDetails.finraCheckbox["finraSectionArr"],
					    "changedItemValueId": empDetails.finraCheckbox["finraSectionArr"],
					    'customValues': { "viewDisplay": false }
					});
					_sameAsCompanyArr.set({
					    "changedItemValue": empDetails.shareHolderCheckbox["sameAsCompanyArr"],
					    "changedItemValueId": empDetails.shareHolderCheckbox["sameAsCompanyArr"],
					    'customValues': { "viewDisplay": false }
					});
					if(!this.get('isNotInCM')){
					    _jobtitle.set('changedItemValue', empDetails.jobTitle);
					    _jobtitle.set('changedItemValueId', empDetails.jobTitle);
					    _jobtitle.set('customValues', { "viewDisplay": true });
					} else {
					    _jobtitle.set('changedItemValue', "");
					    _jobtitle.set('changedItemValueId', "");
					    _jobtitle.set('customValues', { "viewDisplay": false });
					}
					console.log(_industryClassifyType.toJSON(), "_industryClassifyType");
				}
								
			break;
            case "documentDelivery":
			    var _prfrdShareHolder = _items.find(function (row) { return row.get("itemType") == "prefrcShareHolder" }),
                    _prfrdAccount = _items.find(function (row) { return row.get("itemType") == "prefrcAccount" }),
                    _prfrdFinConfirm = _items.find(function (row) { return row.get("itemType") == "prefrcFinConfirm" }),
                    _prfrdDocType = _items.find(function (row) { return row.get("itemType") == "prefrcDocType" }),
                    _prfrdEmailShow = _items.find(function (row) { return row.get("itemType") == "prefrcEmailShow" });
                var _displayDocDeliContent = _items.find(function (row) { return row.get("itemType") == "displayDocDeliContent" });
                
                var _$pfShareHolder = $('input[name=shareholderOnlineMail]:checked'),
                    _$pfAccount = $('input[name=accountOnlineMail]:checked'),
                    _$pfFinConfirm = $('input[name=financialOnlineMail]:checked'),
                    _$pfDocType = $('input[name=documentOnlineMail]:checked'),
                    _$pfEmailShow = $('input[name=is-agreed]:checked');

                    if (_$pfShareHolder.length == 0) {
                        _prfrdShareHolder.set('valueChanged', false);
                    } else {
                        var _selectedShareVal = _$pfShareHolder.val();
                        if (_selectedShareVal == _prfrdShareHolder.get('currentItemValue')[0]) {
                            _prfrdShareHolder.set('valueChanged', false);
                        } else {
                            _prfrdShareHolder.set('valueChanged', true);
                        }
                        _prfrdShareHolder.set('changedItemValue', _selectedShareVal);
                        _prfrdShareHolder.set('changedItemValueId', _selectedShareVal);
                    }

				    if (_$pfAccount.length == 0) {
				        _prfrdAccount.set('valueChanged', false);
				    } else {
				        var _selectedAccVal = _$pfAccount.val();
				        if (_selectedAccVal == _prfrdAccount.get('currentItemValue')[0]) {
				            _prfrdAccount.set('valueChanged', false);
				        } else {
				            _prfrdAccount.set('valueChanged', true);
				        }
				        _prfrdAccount.set('changedItemValue', _selectedAccVal);
				        _prfrdAccount.set('changedItemValueId', _selectedAccVal);
				    }

                    if (_$pfFinConfirm.length == 0) {
                            _prfrdFinConfirm.set('valueChanged', false);
                        } else {
                            var _selectedFinVal = _$pfFinConfirm.val();
                            if(_selectedFinVal == _prfrdFinConfirm.get('currentItemValue')[0]) {
                                _prfrdFinConfirm.set('valueChanged', false);
                            } else {
                                _prfrdFinConfirm.set('valueChanged', true);
                            }
                            _prfrdFinConfirm.set('changedItemValue', _selectedFinVal);
                            _prfrdFinConfirm.set('changedItemValueId', _selectedFinVal);
                        }

                    if (_$pfDocType.length == 0) {
                        _prfrdDocType.set('valueChanged', false);
                    } else {
                        var _selectedDocTVal = _$pfDocType.val();
                        if (_selectedDocTVal == _prfrdDocType.get('currentItemValue')[0]) {
                            _prfrdDocType.set('valueChanged', false);
                        } else {
                            _prfrdDocType.set('valueChanged', true);
                        }
                        _prfrdDocType.set('changedItemValue', _selectedDocTVal);
                        _prfrdDocType.set('changedItemValueId', _selectedDocTVal);
                        }

                    if (_$pfEmailShow.length == 0) {
                        _prfrdEmailShow.set('valueChanged', false);
                    } else {
                        var _selectedEmailShow = _$pfEmailShow.val();
                        if (_selectedEmailShow == _prfrdEmailShow.get('currentItemValue')[0]) {
                            _prfrdEmailShow.set('valueChanged', false);
                        } else {
                            _prfrdEmailShow.set('valueChanged', true);
                        }
                        _prfrdEmailShow.set('changedItemValue', _selectedEmailShow);
                        _prfrdEmailShow.set('changedItemValueId', _selectedEmailShow);
                    }
			        break;
			case "alert":
				var _prfrdEmail = _items.find(function(row){return row.get("itemType") == "preferedEmail"}),
					_prfrdPhone = _items.find(function(row){return row.get("itemType") == "preferedPhone"}),
					_myProfile = _items.find(function (row) { return row.get("itemType") == "myProfile" }),
					_accountMgmt = _items.find(function (row) { return row.get("itemType") == "accountManagement" }),
					_workWithAdvsr = _items.find(function(row){return row.get("itemType") == "workingWithAdvisor"});
				_myProfile.set('emailAlertChanged',false);
				_myProfile.set('smsAlertChanged', false);
				_accountMgmt.set('emailAlertChanged', false);
				_accountMgmt.set('smsAlertChanged', false);
				_workWithAdvsr.set('emailAlertChanged',false);
				_workWithAdvsr.set('smsAlertChanged',false);
				var _$myProfile = $('#myprofile'), _$accountMgmt = $('#accountmanagement'), _$myAdvsr = $('#workingmyadvisor'); 
				saveEmailAlertChanges(_myProfile, _$myProfile, 1);
				saveEmailAlertChanges(_accountMgmt, _$accountMgmt, 0);
				saveEmailAlertChanges(_workWithAdvsr,_$myAdvsr,0);
				//set smsAlert chnage as false always, user cannot change it form UI
				_prfrdPhone.set('valueChanged', false);

				var _$emailAlert = $('input[name=alertEmail]:checked');
				//if only one email set the changed attribute as false
				if(_$emailAlert.length == 0){
					_prfrdEmail.set('valueChanged',false);
				}else{
					var _selecteEmailAlert = _$emailAlert.val();
					if(_selecteEmailAlert == _prfrdEmail.get('currentItemValue')[0]){
						_prfrdEmail.set('valueChanged',false);
					}else{
						_prfrdEmail.set('valueChanged',true);
					}
					_prfrdEmail.set('changedItemValue',[_selecteEmailAlert,_$emailAlert.data('email')])	;
					_prfrdEmail.set('changedItemValueId',[_selecteEmailAlert,_$emailAlert.data('email')]);
				}
				if(_prfrdPhone.get('changedItemValue').length != 0 ){
					saveSMSAlertChanges(_myProfile, _$myProfile);
					saveSMSAlertChanges(_accountMgmt, _$accountMgmt);
					saveSMSAlertChanges(_workWithAdvsr,_$myAdvsr);
				}else{
					_myProfile.set('valueChanged', false);
					_accountMgmt.set('valueChanged', false);
					_workWithAdvsr.set('valueChanged',false);
				}
				
				function saveEmailAlertChanges(itemModel,$container,startIndex){
					var _emailSectionChanged = false;
					$container.find('input[type=checkbox].emailchk').each(function(index,data){
						var _currentUserOption =itemModel.get('currentItemValue')[(index+startIndex)].values[0];
						var _currValues = itemModel.toJSON().changedItemValue,_currValIds = itemModel.toJSON().changedItemValueId;
						if($(this).is(':checked')){
							if(_currentUserOption == "Yes"){
								//itemModel.set('emailAlertChanged',false);
								itemModel.get('changedItemValue')[(index+startIndex)].emailValueChanged = false;
							}else{
								_emailSectionChanged = true;
								//itemModel.set('emailAlertChanged',true);
								itemModel.get('changedItemValue')[(index+startIndex)].emailValueChanged = true;
							}
							itemModel.get('changedItemValue')[(index+startIndex)].values[0] = "Yes";
							itemModel.get('changedItemValue')[(index+startIndex)].valueIds[0] = true;
							itemModel.get('changedItemValueId')[(index+startIndex)].values[0] = "Yes";
							itemModel.get('changedItemValueId')[(index+startIndex)].valueIds[0] = true;
						}else{
							if(_currentUserOption == "Yes"){
								_emailSectionChanged = true;
								itemModel.get('changedItemValue')[(index+startIndex)].emailValueChanged = true;
								//itemModel.set('emailAlertChanged',true);
							}else{
								itemModel.get('changedItemValue')[(index+startIndex)].emailValueChanged = false;
								//itemModel.set('emailAlertChanged',false);
							}
							itemModel.get('changedItemValue')[(index+startIndex)].values[0] = "No";
							itemModel.get('changedItemValue')[(index+startIndex)].valueIds[0] = false;
							itemModel.get('changedItemValueId')[(index+startIndex)].values[0] = "No";
							itemModel.get('changedItemValueId')[(index+startIndex)].valueIds[0] = false;
							
						}
					});
					itemModel.set('emailAlertChanged',_emailSectionChanged);
				}
				function saveSMSAlertChanges(itemModel,$container){
					var _smsAlertChanged = false;
					$container.find('input[type=checkbox].text-alert-check').each(function(index,data){
						var _currentUserOption =itemModel.get('currentItemValue')[(index)].values[1];
						if($(this).is(':checked')){
							if(_currentUserOption == "Yes"){
								itemModel.get('changedItemValue')[index].phoneValueChanged = false;
								//itemModel.set('textAlertChanged',false);
							}else{
								_smsAlertChanged = true;
								itemModel.get('changedItemValue')[index].phoneValueChanged = true;
							}
							itemModel.get('changedItemValue')[index].valueIds[1]	= true;
							itemModel.get('changedItemValue')[index].values[1]	= "Yes";
							itemModel.get('changedItemValueId')[index].valueIds[1]	= true;
							itemModel.get('changedItemValueId')[index].values[1]	= "Yes";
						}else{
							if(_currentUserOption == "Yes"){
								_smsAlertChanged = true;
								itemModel.get('changedItemValue')[index].phoneValueChanged = true;
								//itemModel.set('textAlertChanged',true);
							}else{
								itemModel.get('changedItemValue')[index].phoneValueChanged = false;
								//itemModel.set('textAlertChanged',false);
							}
							itemModel.get('changedItemValue')[index].valueIds[1]	= false;
							itemModel.get('changedItemValue')[index].values[1]	= "No";
							itemModel.get('changedItemValueId')[index].valueIds[1]	= false;
							itemModel.get('changedItemValueId')[index].values[1]	= "No";
						}
					});
					itemModel.set('smsAlertChanged',_smsAlertChanged);
					//itemModel.set('emailValueChanged',_smsAlertChanged);
				}
				
				
			break;
			case "phonenumbers":
				var self = this,_modelColaNumbers = [],_uiColaNumberTypes=[];
				var _$editedNumbers = $('.gpm-ph-edit-mode');
				//first mark edited items which needs to be deleted
				$(_$editedNumbers).each(function(k,el){
					var _$phnNumCtnr = $(this);
					var _launchMode = _$phnNumCtnr.data('launch-mode'),_teleId = $(this).data('identifier');
					var  _$selectBox = $(document.getElementById('phTypeDropDwnId-'+_teleId.replace(/\./g, "-")));
					var _slectedType = _$selectBox.find('option:selected').text(),_launchDataSrc = _$selectBox.data('source');
					if(_launchMode != "new"){
						
						var _item = _items.find(function(row){return row.get("itemType") == _teleId});
						var _custVal = _item.get('customValues');
						var _currentType = _custVal.dataSource == "COLA"?_item.get('currentItemValue').get('phnLblTxt'):_item.get('currentItemValue').get('PhoneTypeDesc');
						_currentType = _currentType?_currentType.toLowerCase():"";
						//if phone type changed for cola number delete that number
						if(_custVal.dataSource == "COLA" && _currentType != _slectedType.toLowerCase()){
							_custVal.deleted = true;
							_custVal.changed = true;
							//check the corresponding ebix num and mark it as deleted
							var _ebixNum = _items.find(function(row){return row.get("itemType") == _custVal.ebixRefId});
							if(_ebixNum){
								_ebixNum.get('customValues').deleted = true;
								_ebixNum.get('customValues').changed = true;
							}
							
						}
						//if phone type changed to EBix type 
						//from COLA type add new item to the model
						if(!isColaType(_slectedType) && _currentType != _slectedType.toLowerCase()){
							if(_custVal.dataSource == "COLA"){
								addEbixNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:null,phoneType:_slectedType});
							}else if(_custVal.dataSource == "EBIX"){
								//update corresponding model
								saveChangedValueFromUI({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId});
							}
						} else if(!isColaType(_slectedType) && _currentType == _slectedType.toLowerCase()){
							//phonetype not changed update corresponding model
							saveChangedValueFromUI({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId});
						}
					}else if(_launchMode == "new" && !isColaType(_slectedType)){
						addEbixNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId,phoneType:_slectedType});
					}
				});
				//loop through the modfied items to pick the cola numbers which are not marked as deleted
				$(_items).each(function(j,datum){
					if(datum.get('customValues').dataSource == "COLA" && datum.get('customValues').deleted != true ){
						_modelColaNumbers.push(datum);
						_uiColaNumberTypes.push(datum.get('currentItemValue').get('phnLblTxt').toLowerCase());
					}
				});
				$(_$editedNumbers).each(function(l,elemt){
					var _$phnNumCtnr = $(this);
					var _launchMode = _$phnNumCtnr.data('launch-mode'),_teleId = _$phnNumCtnr.data('identifier');
					var _$selectBox = $(document.getElementById('phTypeDropDwnId-'+_teleId.replace(/\./g, "-")));
					var _slectedType = _$selectBox.find('option:selected').text(),_launchDataSrc = _$selectBox.data('source');
					if(isColaType(_slectedType)){
						if(_launchMode == "new"){
							if(isExistingColaType(_slectedType)){
								//add it as ebix num only
								addEbixNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId,phoneType:_slectedType});
							}else{
								//add to cola, no need to add to EBIX as nightly batch will push that ebix
								addColaNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId,phoneType:_slectedType});
							}
						}else{
							var _item = _items.find(function(row){return row.get("itemType") == _teleId});
							var _custVal = _item.get('customValues')
							//edit mode case
							var _currentType = _custVal.dataSource == "COLA"?_item.get('currentItemValue').get('phnLblTxt'):_item.get('currentItemValue').get('PhoneTypeDesc');
							_currentType = _currentType?_currentType.toLowerCase():"";
							if((_custVal.dataSource == "COLA" ||_custVal.dataSource == "EBIX"  ) && _currentType == _slectedType.toLowerCase()){
								//phone type  existing update the existing model
								if(isExistingColaType(_slectedType) ){
									saveChangedValueFromUI({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId});
								}else{
									//add this as cola number and delete from ebix
									addColaNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:null,phoneType:_slectedType});
									_item.get('customValues').deleted = true;
									_item.get('customValues').changed = true;
								}
								
							}else if((_custVal.dataSource == "COLA" ||_custVal.dataSource == "EBIX"  )&& _currentType != _slectedType.toLowerCase()){
								if(isExistingColaType(_slectedType) ){
									//COLA phone changed to another COLA phoneType
									if(_custVal.dataSource == "COLA"){
										//already existing cola type, add it to ebix  only
										addEbixNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:null,phoneType:_slectedType});
									}else{
										//ebix number changed to existing cola  number just update
										saveChangedValueFromUI({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:_teleId});
									}
									
								}else{
										//not an existing cola type, add to cola, no need to add to EBIX as nightly batch will push that ebix
										addColaNumberToModel({phnNumCtnr:_$phnNumCtnr,uiTeleId:_teleId,modelTeleId:null,phoneType:_slectedType});
										//delete from ebix
										_item.get('customValues').deleted = true;
										_item.get('customValues').changed = true;
									
								}
							}
						}
						
					}
				});
				console.log(this,"model model");
				function addEbixNumberToModel(params){
					var _currentVal = new EbixPhoneNumModel(),_changeVal = new EbixPhoneNumModel();
					//add a reference to cola number and amrk the createMode as new
					var _custVals = {viewDispaly:false,dataSource:"EBIX",createMode:"new"};
					//if both teleId and model id is not not equal create a new model with cola reference as UI teleId
					if(params.uiTeleId != params.modelTeleId){
						var _newPhoneNumCount = self.get('newPhoneNumCount');
						_newPhoneNumCount++;
						self.set('newPhoneNumCount',_newPhoneNumCount);
						params.modelTeleId = 'new-phone-id-'+_newPhoneNumCount;
						_custVals.clTeleId = params.uiTeleId;
					}
					var _slectedType = $(document.getElementById('phTypeDropDwnId-'+params.uiTeleId.replace(/\./g, "-"))).find(' option:selected').val();
					self.addItem({customValues:_custVals,itemType:params.modelTeleId,itemLabel:_slectedType,isComplexType:true,currentItemValue:_currentVal, changedItemValue: _changeVal,currentItemValueId:_currentVal,changedItemValueId:_changeVal,orderIndex:1});
					saveChangedValueFromUI({phnNumCtnr:params.phnNumCtnr,uiTeleId:params.uiTeleId,modelTeleId:params.modelTeleId});
				}
				function addColaNumberToModel(params){
					var _currentVal = new ColaPhoneNumModel(),_changeVal = new ColaPhoneNumModel();
					//add a reference to cola number and amrk the createMode as new
					var _custVals = {viewDispaly:false,dataSource:"COLA",createMode:"new",changed:true};
					//if both teleId and model id is not not equal create a new model with cola reference as UI teleId
					if(params.uiTeleId != params.modelTeleId){
						var _newPhoneNumCount = self.get('newPhoneNumCount');
						_newPhoneNumCount++;
						self.set('newPhoneNumCount',_newPhoneNumCount);
						params.modelTeleId = 'new-phone-id-'+_newPhoneNumCount;
						_custVals.clTeleId = params.uiTeleId;
					}
					var _slectedType = $(document.getElementById('phTypeDropDwnId-'+params.uiTeleId.replace(/\./g, "-"))).find('option:selected').text();
					self.addItem({customValues:_custVals,itemType:params.modelTeleId,itemLabel:_slectedType,isComplexType:true,currentItemValue:_currentVal, changedItemValue: _changeVal,currentItemValueId:_currentVal,changedItemValueId:_changeVal,orderIndex:1});
					saveChangedValueFromUI({phnNumCtnr:params.phnNumCtnr,uiTeleId:params.uiTeleId,modelTeleId:params.modelTeleId});
				}
				function isExistingColaType(phoneType){
					var _isExisting = false;
					if(_uiColaNumberTypes.indexOf(phoneType) != -1 || _uiColaNumberTypes.indexOf(phoneType.toLowerCase())!= -1){
						_isExisting = true;
					}else{
						_isExisting = false;
						//push this type to _uiColaNumTypes
						_uiColaNumberTypes.push(phoneType.toLowerCase());
					}
					return _isExisting;
				}
				function saveChangedValueFromUI(params){
					var _$phnNumCtnr = params.phnNumCtnr,_uiTeleId=params.uiTeleId,_modelTeleId=params.modelTeleId;
					var _launchMode = _$phnNumCtnr.data('launch-mode'),_teleId = _$phnNumCtnr.data('identifier'),_item={}, _items = self.get('items');;
					_item = _items.find(function(row){return row.get("itemType") == _modelTeleId});
						var _customVal =  _item.get('customValues'),_changedItemVal = _item.get('changedItemValue'),_currItemVal = _item.get('currentItemValue');
						var _dataSrc = _customVal.dataSource;
						if(_dataSrc =="COLA"){
							var _selectedType =  $(document.getElementById('phTypeDropDwnId-'+_uiTeleId.replace(/\./g, "-"))).find('option:selected').text();
							_customVal.preffered = $(document.getElementById('gpm-preferred-'+_uiTeleId.replace(/\./g, "-"))).prop('checked');
							_changedItemVal.set('NANPAreaCd',$(document.getElementById('ph1-part-a-'+_uiTeleId.replace(/\./g, "-"))).val());
							_changedItemVal.set('NANPExchCd', $(document.getElementById('ph1-part-n1-'+_uiTeleId.replace(/\./g, "-"))).val());
							_changedItemVal.set('NANPSbscNbr',$(document.getElementById('ph1-part-n2-'+_uiTeleId.replace(/\./g, "-"))).val());
							//_changedItemVal.set('SMSEnrlStatCd',null);
							//_changedItemVal.set('clTeleId', null);
							_changedItemVal.set('nonNANPPhnNbr',$(document.getElementById('cd-homephone-int-number-1-'+_uiTeleId.replace(/\./g, "-"))).val());
							_changedItemVal.set('phnCtryCd', $(document.getElementById('cd-homephone-int-country-1-'+_uiTeleId.replace(/\./g, "-"))).val());
							_changedItemVal.set('phnExtnNbr',$(document.getElementById('ph1-part-e-'+_uiTeleId.replace(/\./g, "-"))).val());
							_changedItemVal.set('phnLblTxt',_selectedType.toUpperCase().replace(' ',''));
							_changedItemVal.set('phnPrfrCd',_$phnNumCtnr.find('.gpm-preferred-chkbox').prop('checked') == true?"01":"02");
							//_changedItemVal.set('phnSubLblTxt',$('#ph1-part-a-'+_uiTeleId.replace(/\./g, "-")).val());
							//_changedItemVal.set('prefCode',_customVal.preffered == true?"1":"0");
							//_changedItemVal.set('preferredPhone', _customVal.preffered);
							//_changedItemVal.set('textEnabled', false);
							_changedItemVal.set('phoneTypeCd', $(document.getElementById('phTypeDropDwnId-'+_uiTeleId.replace(/\./g, "-"))).find('option:selected').attr('value'));
							_changedItemVal.set('phnRemarks',_$phnNumCtnr.find('textarea').val());
							if(		(_changedItemVal.get('phnPrfrCd')!=_currItemVal.get('phnPrfrCd'))||(_changedItemVal.get('phnCtryCd')!=_currItemVal.get('phnCtryCd'))||
									(_changedItemVal.get('NANPAreaCd')!=_currItemVal.get('NANPAreaCd'))||(_changedItemVal.get('NANPExchCd')!=_currItemVal.get('NANPExchCd'))||
									(_changedItemVal.get('NANPSbscNbr')!=_currItemVal.get('NANPSbscNbr'))||(_changedItemVal.get('nonNANPPhnNbr')!=_currItemVal.get('nonNANPPhnNbr'))||
									(_changedItemVal.get('phnExtnNbr')!=_currItemVal.get('phnExtnNbr'))||(_changedItemVal.get('phnLblTxt').toUpperCase().replace(' ','')!=_currItemVal.get('phnLblTxt').toUpperCase().replace(' ',''))||
									(_changedItemVal.get('phnPrfrCd')!=_currItemVal.get('phnPrfrCd'))||(_changedItemVal.get('phoneTypeCd')!=_currItemVal.get('phoneTypeCd'))){
								_customVal.changed = true;
							}else{
								_customVal.changed = false;
							}
							_item.set('itemLabel',_selectedType);
						}else{
							var _isIntrnatnl = $(document.getElementById('gpm-ph-int-'+_teleId.replace(/\./g, "-"))).prop('checked');
							_customVal.preffered = $(document.getElementById('gpm-preferred-'+_teleId.replace(/\./g, "-"))).prop('checked');
							var _intrNatnlNum = $(document.getElementById('cd-homephone-int-number-1-'+_teleId.replace(/\./g, "-"))).val();
							if(_isIntrnatnl){
								_changedItemVal.set('AreaCode',_intrNatnlNum.substr(0,3));
								_changedItemVal.set('Number', _intrNatnlNum.substr(3,15).trim());
							}else{
								_changedItemVal.set('AreaCode',$(document.getElementById('ph1-part-a-'+_teleId.replace(/\./g, "-"))).val());
								_changedItemVal.set('Number', $(document.getElementById('ph1-part-n1-'+_teleId.replace(/\./g, "-"))).val()+' '+$(document.getElementById('ph1-part-n2-'+_uiTeleId.replace(/\./g, "-"))).val().trim());
							}
							_changedItemVal.set('CountryCode', $(document.getElementById('cd-homephone-int-country-1-'+_uiTeleId.replace(/\./g, "-"))).val());
							_changedItemVal.set('Extension',$(document.getElementById('ph1-part-e-'+_uiTeleId.replace(/\./g, "-"))).val());
							var _$selectedOption = $(document.getElementById('phTypeDropDwnId-'+_uiTeleId.replace(/\./g, "-"))).find('option:selected')
							_changedItemVal.set('PhoneTypeDesc', _$selectedOption.text());
							_changedItemVal.set('Preferred',_customVal.preffered == true?"1":"0");
							_changedItemVal.set('phoneTypeCd', _$selectedOption.attr('value'));
							var _number = _changedItemVal.get('Number');
							var _extN = _changedItemVal.get('Extension').length>0 ? (' x'+_changedItemVal.get('Extension')):''
							var _fullPhnMum = ('('+_changedItemVal.get('AreaCode')+') ' + _number.trim().replace(" ","-")) + _extN;
							_changedItemVal.set('FullPhoneNumber',_fullPhnMum);
							//remove the space from Number
							_changedItemVal.set('Number',_number.replace(" ",""));
							_changedItemVal.set('phnRemarks',_$phnNumCtnr.find('textarea').val());
							if(		(_changedItemVal.get('Preferred')!=_currItemVal.get('Preferred'))||(_changedItemVal.get('CountryCode')!=_currItemVal.get('CountryCode'))||
									(_changedItemVal.get('AreaCode')!=_currItemVal.get('AreaCode'))||(_changedItemVal.get('Number')!=_currItemVal.get('Number'))||
									(_changedItemVal.get('Extension')!=_currItemVal.get('Extension'))||(_changedItemVal.get('PhoneTypeDesc')!=_currItemVal.get('PhoneTypeDesc'))
									||(_changedItemVal.get('phoneTypeCd')!=_currItemVal.get('phoneTypeCd'))){
								_customVal.changed = true;
							}else{
								_customVal.changed = false;
							}
							_item.set('itemLabel',_changedItemVal.get('PhoneTypeDesc'));
						}
					
				}
				function isColaType(phoneType){
					var _colaPhoneTypes = ["home","business","mobile","other 1","other 2"];
					return phoneType && _colaPhoneTypes.indexOf(phoneType.toLowerCase())==-1?false:true;
				}
				console.log(this,"phone model");
				break;
			    case "email":
                    //all conditions handle email swap need to revisit if we make any additional changes to logic
				var self = this;
				var _items = self.get('items');
				var _$gpmChangeEmailBoxes = $('.gpm-email-change-box'), _$emailSectionContainer = $('#actual-email-container');
				var _totalEmailTypeChangedItems = _$emailSectionContainer.find('[type-changed="true"]').length;
				$(_$gpmChangeEmailBoxes).each(function(key,row){
					updateChangedEmails($(this), _items);
				});
				function updateChangedEmails($changedEmailBox, _items){
				    var _changeMode = $changedEmailBox.data("mode-type"), _typeChanged = $changedEmailBox.attr("type-changed") == "true";
					var _uid = $changedEmailBox.data("uid");
					var _itemType = $changedEmailBox.find("select").val();
					var _itemLabel = $changedEmailBox.find("select :selected").text();
					var _itemPreferredStatus = $changedEmailBox.find("input.preferredChkBox").is(":checked");
					var _itemEmail = $changedEmailBox.find("input.inputEmail").val();
					var _newEmailColaModel = new ColaEmailModel(),_changedEmailColaModel =new ColaEmailModel({emlUseCd:_itemType,emlAddr:_itemEmail,Preferred:_itemPreferredStatus}) ;
					var _newEmailEbixModel = new EbixEmailModel(),_changedEmailEbixModel =new EbixEmailModel({Address:_itemEmail,Preferred:_itemPreferredStatus}) ;
					var _existingItem = _items.find(function(row){return (row.get("customValues")['UID'] == _uid)})
					
					if(_changeMode === "addNew" && !_existingItem){
					    if (_itemType != "1") {
					        var _newEmailItemInModel = getModelItem(_items, "itemType", _itemType)
					            if (_newEmailItemInModel) {
					                updateModelItemByItem(_newEmailItemInModel, _itemEmail);
					            } else {
					                self.addItem({ customValues: { viewDispaly: true, srcSystem: "COLA", UID: _uid, isNew: true, changed: true }, itemType: _itemType, itemLabel: _itemLabel, isComplexType: true, currentItemValue: _newEmailColaModel, changedItemValue: _changedEmailColaModel, currentItemValueId: _newEmailColaModel, changedItemValueId: _changedEmailColaModel, orderIndex: 1 });
					            }   
							//self.addItem({customValues:{viewDispaly:false,srcSystem:"EBIX", UID:_uid, isNew:true,changed:true},itemType:_itemType,itemLabel:_itemLabel,isComplexType:true,currentItemValue:_newEmailEbixModel, changedItemValue: _changedEmailEbixModel,currentItemValueId:_newEmailEbixModel,changedItemValueId:_changedEmailEbixModel,orderIndex:1});
						}else{
							self.addItem({customValues:{viewDispaly:true,srcSystem:"EBIX", UID:_uid, isNew:true,changed:true},itemType:_itemType,itemLabel:_itemLabel,isComplexType:true,currentItemValue:_newEmailEbixModel, changedItemValue: _changedEmailEbixModel,currentItemValueId:_newEmailEbixModel,changedItemValueId:_changedEmailEbixModel,orderIndex:1});
						}
					}else{
						
						var _existingItemChangedItemValue = _existingItem.get("changedItemValue");
						var _existingItemChangedItemValueId = _existingItem.get("changedItemValueId");
						var _existingItemcurrentItemValueId = _existingItem.get("currentItemValueId");
                        //check if there are any email type changes 
						if (_totalEmailTypeChangedItems > 0 && _typeChanged) {

                                var _modifiedtype = $changedEmailBox.find("select>option:selected").attr("name");
						        if (_modifiedtype != "Other (Contact Manager)") {
						            //self.addItem({customValues:{viewDispaly:false,srcSystem:"EBIX", UID:_uid, isNew:true,changed:true},itemType:_itemType,itemLabel:_itemLabel,isComplexType:true,currentItemValue:_newEmailEbixModel, changedItemValue: _changedEmailEbixModel,currentItemValueId:_newEmailEbixModel,changedItemValueId:_changedEmailEbixModel,orderIndex:1});
						            var _changedExistingModelItem = getModelItem(_items, "itemType", _modifiedtype);
						            if (_changedExistingModelItem) {
						                updateModelItemByItem(_changedExistingModelItem, _itemEmail);
						            } else {
						                self.addItem({ customValues: { "addedBySwap": true, viewDispaly: true, srcSystem: "COLA", UID: Math.floor((Math.random() * Math.pow(10, 10)) + 1), isNew: true, changed: true }, itemType: _itemType, itemLabel: _itemLabel, isComplexType: true, currentItemValue: _newEmailColaModel, changedItemValue: _changedEmailColaModel, currentItemValueId: _newEmailColaModel, changedItemValueId: _changedEmailColaModel, orderIndex: 1 });
						            }
						            if (_existingItem.get('itemLabel') == "Other (Contact Manager)") {
						                markEmailItemAsDeleted(_existingItem);
						            } else {
						                if (isSameTypeInUI(_existingItem.get("itemType"))) {
						                    revertMarkAsDeleted(_existingItem);
						                } else {
						                    markEmailItemAsDeleted(_existingItem);
                                        }
                                    }
						        } else {
						            self.addItem({ customValues: { "addedBySwap": true, viewDispaly: true, srcSystem: "EBIX", UID: Math.floor((Math.random() * Math.pow(10, 10)) + 1), isNew: true, changed: true }, itemType: _itemType, itemLabel: _itemLabel, isComplexType: true, currentItemValue: _newEmailEbixModel, changedItemValue: _changedEmailEbixModel, currentItemValueId: _newEmailEbixModel, changedItemValueId: _changedEmailEbixModel, orderIndex: 1 });
						        }
						} else {
						    updateModelitem(_itemEmail)
						}
						function updateModelitem(emailId) {
						    if (_existingItem.get("customValues")['srcSystem'] == "COLA") {
						        if (_existingItemcurrentItemValueId.get("emlAddr") != emailId /*|| _existingItemcurrentItemValueId.get("preferredEmail") != _itemPreferredStatus*/) {
						            _existingItemChangedItemValue.set("emlAddr", emailId);
						            _existingItemChangedItemValueId.set("emlAddr", emailId);
						            _existingItemChangedItemValue.attributes.Preferred = _itemPreferredStatus;
						            _existingItemChangedItemValueId.attributes.Preferred = _itemPreferredStatus;
						            _existingItem.get("customValues")['changed'] = true;
						        } else {
						            _existingItemChangedItemValue.attributes.Preferred = _itemPreferredStatus;
						            _existingItemChangedItemValueId.attributes.Preferred = _itemPreferredStatus;
						            _existingItem.get("customValues")['changed'] = false;
						        }

						    } else {
						        if (_existingItemcurrentItemValueId.get("Address") != emailId /*|| _existingItemcurrentItemValueId.get("preferredEmail") != _itemPreferredStatus*/) {
						            _existingItemChangedItemValue.set("Address", emailId);
						            _existingItemChangedItemValueId.set("Address", emailId);
						            _existingItemChangedItemValue.set("Preferred", _itemPreferredStatus);
						            _existingItemChangedItemValueId.set("Preferred", _itemPreferredStatus);
						            _existingItem.get("customValues")['changed'] = true;
						        } else {
						            _existingItemChangedItemValue.set("Preferred", _itemPreferredStatus);
						            _existingItemChangedItemValueId.set("Preferred", _itemPreferredStatus);
						            _existingItem.get("customValues")['changed'] = false;
						        }

						    }
						}


                    }
						
				}
				function isSameTypeInUI(emailType) {
				    var _$emailTypes = $('.emailTypeDropDwn,.gpm-email-type-name:visible'), isInUI = false;
				    _$emailTypes.each(function () {
				        if ($(this).hasClass("emailTypeDropDwn")) {
				            if ($(this).find("option:selected").attr("name") == emailType) {
				                isInUI = true;
				            }
				        } else if ($(this).text() == emailType) {
				            isInUI = true;
				        }
				    });
				    return isInUI;
				}
				function markEmailItemAsDeleted(emailModel) {
				    //mark the existing item as deleted and create a new item
				    emailModel.get("customValues")['isDeleted'] = true;
				    emailModel.get("customValues")['changed'] = true;
				    emailModel.get("customValues")['deletedBySwap'] = true;
				}
				function revertMarkAsDeleted(emailModel) {
				    emailModel.get("customValues")['isDeleted'] = false;
				    emailModel.get("customValues")['changed'] = true;
				    emailModel.get("customValues")['deletedBySwap'] = false;
				}

				function getModelItem(modelItems, itemKey, itemValue) {
				    var _modelItem = modelItems.find(function (modelItem) {
				        return modelItem.get(itemKey) === itemValue;
				    });
				    return _modelItem;
				}
				function updateModelItemByItem(item, email) {
				    item.get("changedItemValue").set("emlAddr", email);
				    item.get("changedItemValueId").set("emlAddr", email);
				    revertMarkAsDeleted(item);
				}
				break;
			case "communicationPreference":
				var _sections = this.get('itemSections'), _$sectionAdvrPref = $('.section-200'),_$sectionAmerPref=$('.section-206'),_$sectionCommnctnIntrstPref=$('.section-4');
				var _advsrPrefSectn = _sections.find(function(row){return row.sectionId == "200"}),_amerPrefSectn = _sections.find(function(row){return row.sectionId == "206"}),_commctnIntrstPrefSectn = _sections.find(function(row){return row.sectionId == "4"});
				var	_advsrPrefSectnItems = _advsrPrefSectn.items,_amerPrefSectnItems = _amerPrefSectn.items,_commctnIntrstPrefSectnItems = _commctnIntrstPrefSectn.items;
				
//Advsr Pref update
				var _advsrEmailDelvry = _advsrPrefSectnItems.find(function(row){return row.get("itemType") == "emailType"});
				//update delivery type for adsvr pref
				if(_advsrEmailDelvry.get('customValues').emails.length>1){
					var _$advsrEmailDelivry = $('input[name="advisorEmail-200"]:checked');
					_advsrEmailDelvry.set('changedItemValue',_$advsrEmailDelivry.val());
					_advsrEmailDelvry.set('changedItemValueId',_$advsrEmailDelivry.val());
					if(_advsrEmailDelvry.get('changedItemValue') != _advsrEmailDelvry.get('currentItemValue')){
						_advsrPrefSectn.customValues.changed = true
					}
				}else{
					_advsrEmailDelvry.set('changedItemValue',_advsrEmailDelvry.get('customValues').emails[0].emlUseCd);
					_advsrEmailDelvry.set('changedItemValueId',_advsrEmailDelvry.get('customValues').emails[0].emlUseCd);
					if(_advsrEmailDelvry.get('changedItemValue') != _advsrEmailDelvry.get('currentItemValue')){
						_advsrPrefSectn.customValues.changed = true
					}
				}
				//update other infos for advsr pref
				var _$advsrprefInfos = _$sectionAdvrPref.find('.btn-group');
				$.each(_$advsrprefInfos,function(index,item){
					var _$item = $(item);
					var _itemModel = _advsrPrefSectnItems.find(function(row){return row.get("itemType") == _$item.data('itemtype')});
					var _selectedVal = _$item.find('.btn.active').data('value');
					_itemModel.set('changedItemValue',_selectedVal);
					_itemModel.set('changedItemValueId',_selectedVal == "Yes"?true:false);
					if(_itemModel.get('changedItemValue') != _itemModel.get('currentItemValue')){
						_advsrPrefSectn.customValues.changed = true
					}
				});
//Advsr Pref update	
				var _amerEmailDelivry = _amerPrefSectnItems.find(function(row){return row.get("itemType") == "emailType"});
				//update delivery type for amer pref
				
				if(_amerEmailDelivry.get('customValues').emails.length>1){
					var _$amerEmailDelivry = $('input[name="advisorEmail-206"]:checked');
					_amerEmailDelivry.set('changedItemValue',_$amerEmailDelivry.val());
					_amerEmailDelivry.set('changedItemValueId',_$amerEmailDelivry.val());
					if(_amerEmailDelivry.get('changedItemValue') != _amerEmailDelivry.get('currentItemValue')){
						_amerPrefSectn.customValues.changed = true
					}
				}else{
					_amerEmailDelivry.set('changedItemValue',_amerEmailDelivry.get('customValues').emails[0].emlUseCd);
					_amerEmailDelivry.set('changedItemValueId',_amerEmailDelivry.get('customValues').emails[0].emlUseCd);
					if(_amerEmailDelivry.get('changedItemValue') != _amerEmailDelivry.get('currentItemValue')){
						_amerPrefSectn.customValues.changed = true
					}
				}
				
				//update other infos for advsr pref
				var _$amerprefInfos = _$sectionAmerPref.find('.btn-group');
				$.each(_$amerprefInfos,function(index,item){
					var _$item = $(item);
					var _itemModel = _amerPrefSectnItems.find(function(row){return row.get("itemType") == _$item.data('itemtype')});
					var _selectedVal = _$item.find('.btn.active').data('value');
					_itemModel.set('changedItemValue',_selectedVal);
					_itemModel.set('changedItemValueId',_selectedVal == "Yes"?true:false);
					if(_itemModel.get('changedItemValue') != _itemModel.get('currentItemValue')){
						_amerPrefSectn.customValues.changed = true
					}
				});
//Communication Interest Pref update	
				if(_commctnIntrstPrefSectnItems.length>0){
					var _retirementType = _commctnIntrstPrefSectnItems.find(function(row){return row.get("itemType") == "Retirement stage"}),_$retirementStage = $('#retirement-stage');
					_retirementType.set('changedItemValue',_$retirementStage.find('option:selected').data('value'));
					_retirementType.set('changedItemValueId',_$retirementStage.val()?_$retirementStage.val():"");
					if(_retirementType.get('changedItemValue') != _retirementType.get('currentItemValue')){
						_commctnIntrstPrefSectn.customValues.changed = true
					}
					var _$communctnIntrstPrefInfos = _$sectionCommnctnIntrstPref.find('.communication-interest-rt-plns:not(.hidden) select');
					$.each(_$communctnIntrstPrefInfos,function(index,item){
						var _$item = $(item);
						var _itemModel = _commctnIntrstPrefSectnItems.find(function(row){return row.get("itemType") == _$item.data('itemtype')});
						var _selectedVal = _$item.find('.btn.active').data('value');
						_itemModel.set('changedItemValue',_$item.find('option:selected').data('value'));
						_itemModel.set('changedItemValueId',_$item.val()?_$item.val():"");
						if(_itemModel.get('changedItemValue') != _itemModel.get('currentItemValue')){
							_commctnIntrstPrefSectn.customValues.changed = true
						}
					});
				}
				break;
			case "entity":
			    var fieldValues = params.entityDetails;
			    var entityType = _items.find(function (row) { return row.get("itemType") == "entityType" });
			    var industryClassifyType = _items.find(function(row){return row.get("itemType") == "industryClassifyType"});
			    var industryFreeFormText = _items.find(function(row){return row.get("itemType") == "industryFreeFormText"});
			    var nonOperEntyCd = _items.find(function(row){return row.get("itemType") == "nonOperEntyCd"});
			    var addressType = _items.find(function(row){return row.get("itemType") == "addressType"});
			    var stateCd = _items.find(function (row) { return row.get("itemType") == "stateCd" });
			    var frgnCtryCd = _items.find(function (row) { return row.get("itemType") == "frgnCtryCd" });			  

			    var showIndsTyp = false, showIndFreeFrmTxt = false, showNonOperEnty = false, showAddrType = false, showState = false, showCntry = false;
			    if (_.contains(industryOptionCode, fieldValues.entityType.code)) {
			        showIndsTyp = true;
			        showNonOperEnty = true;
			    }

			    if (showIndsTyp && fieldValues.indsClsftcn.name == "Other") {
			        showIndFreeFrmTxt = true;
			    }

			    if (_.contains(entityLocationCode, fieldValues.entityType.code)) {
			        showAddrType = true;
			        if (showAddrType && fieldValues.entityEstablishedLocalityType == "US") {
			            showState = true;
			        }
			        if (showAddrType && fieldValues.entityEstablishedLocalityType !== "US") {
			            showCntry = true;
			        }
			    }			    
			   

			    entityType.set({
			        "changedItemValue": fieldValues.entityType.name,
			        "changedItemValueId": fieldValues.entityType.code
			    });
			    industryClassifyType.set({
			        "customValues": { "viewDisplay": showIndsTyp },
			        "changedItemValue": fieldValues.indsClsftcn ? fieldValues.indsClsftcn.name : '',
			        "changedItemValueId": fieldValues.indsClsftcn ? fieldValues.indsClsftcn.code : ''
			    });
			    industryFreeFormText.set({
			        "customValues": { "viewDisplay": showIndFreeFrmTxt },
			        "changedItemValue": fieldValues.indsClsTxt,
			        "changedItemValueId": fieldValues.indsClsTxt
			    });
			    nonOperEntyCd.set({
			        "customValues": { "viewDisplay": showNonOperEnty },
			        "changedItemValue": fieldValues.isOperatingEntity ? fieldValues.isOperatingEntity.description : '' ,
			        "changedItemValueId": fieldValues.isOperatingEntity ? fieldValues.isOperatingEntity.id : ''
			    });
			    addressType.set({
			        "customValues": { "viewDisplay": showAddrType },
			        "changedItemValue":  fieldValues.entityEstablishedLocalityType,
			        "changedItemValueId": fieldValues.entityEstablishedLocalityType
			    });
			    stateCd.set({
			        "customValues": { "viewDisplay": showState },
			        "changedItemValue": fieldValues.stateOfEntityOperationCd,
			        "changedItemValueId": fieldValues.stateOfEntityOperationCd
			    });
			    frgnCtryCd.set({
			        "customValues": { "viewDisplay": showCntry },
			        "changedItemValue": fieldValues.foreignCountryNm,
			        "changedItemValueId": fieldValues.foreignCountryCd
			    });
			    break;
			default:
				break;
			}
		},
		
		setCurrentValue:function(updateMode,params){
			var self = this;
			//this.clear();
			this.set('currentItemSet',true);
			this.set('isDevice',checkIsDevice());
			this.set('contactType',"");
			this.set('customerTypeCd',"");
			this.set('clientRole',"");
			this.set('submitStatus',"success");
			this.set('completedSteps',[]);
			this.set('stepsToComplete',2);
			this.set('updateMode',updateMode);
			this.set('items', []);
			
			switch (updateMode) {
			    case "gender":
			        var _genderCodeMapping = { "M": "Male", "F": "Female" };
			        var _genderCd = "", _genderValue = "", _data = params.data.fieldsInfo;
			        _genderCd = _data.genderCd ? _data.genderCd : "";
			        _genderValue = _genderCd ? _genderCodeMapping[_genderCd] : "";
			        this.addItem({ itemType: "genderCd", customValues: { "viewDisplay": true }, itemLabel: "Gender", currentItemValue: _genderValue, currentItemValueId: _genderCd, changedItemValue: _genderValue, changedItemValue: _genderCd, orderIndex: 1 });
			        break;
			    case "greeting":
			        this.addItem({ itemType: "clGreeting", customValues: { "viewDisplay": true }, itemLabel: "Greeting", currentItemValue: params.data.fieldsInfo.clGreeting, currentItemValueId: params.data.fieldsInfo.clGreeting, changedItemValue: params.data.fieldsInfo.clGreeting, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "remarks":
			        this.addItem({ itemType: "remarks", customValues: { "viewDisplay": true }, itemLabel: "Remarks", currentItemValue: params.data.fieldsInfo.remarks, currentItemValueId: params.data.fieldsInfo.remarks, changedItemValue: params.data.fieldsInfo.remarks, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "honorific":
			        this.addItem({ itemType: "honorific", customValues: { "viewDisplay": true }, itemLabel: "Honorific", currentItemValue: params.data.fieldsInfo.hnyName, currentItemValueId: params.data.fieldsInfo.hnyName, changedItemValue: params.data.fieldsInfo.hnyName, changedItemValueId: params.data.fieldsInfo.hnyName, orderIndex: 1 });
			        //this.addItem({ itemType: "hnyName", itemLabel: "hnyName", currentItemValue: params.data.fieldsInfo.hnyName, currentItemValueId: params.data.fieldsInfo.hnyName, changedItemValue: params.data.fieldsInfo.hnyName, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "maritalstatus":
			        this.addItem({ itemType: "maritalstatus", customValues: { "viewDisplay": true }, itemLabel: "Marital Status", currentItemValue: params.data.fieldsInfo.maritalStatusString, currentItemValueId: params.data.fieldsInfo.maritalstatus, changedItemValue: params.data.fieldsInfo.maritalStatusString, changedItemValueId: params.data.fieldsInfo.maritalstatus, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "dependents":
			        this.addItem({ itemType: "dependents", customValues: { "viewDisplay": true }, itemLabel: "Total dependents", currentItemValue: params.data.fieldsInfo.dependents, currentItemValueId: params.data.fieldsInfo.dependents, changedItemValue: params.data.fieldsInfo.dependents, changedItemValueId: params.data.fieldsInfo.dependents, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "passport":
			        this.addItem({ itemType: "passport", customValues: { "viewDisplay": true }, itemLabel: "Passport", currentItemValue: params.data.fieldsInfo.passport, currentItemValueId: params.data.fieldsInfo.passport, changedItemValue: params.data.fieldsInfo.passport, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "subtype":
			        this.addItem({ itemType: "contactSubType", customValues: { "viewDisplay": true }, itemLabel: "Sub-type", currentItemValue: params.data.fieldsInfo.contactSubType, currentItemValueId: params.data.fieldsInfo.contactSubType, changedItemValue: params.data.fieldsInfo.contactSubType, orderIndex: 1 });
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "reportclientsdeath":
			        var _data = params.data;
			        this.addItem({
			            itemType: "clientDateOfDeath",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Date of Death",
			            currentItemValue: "",
			            currentItemValueId: "",
			            orderIndex: 1
			        });
			        this.addItem({
			            itemType: "clientContactName",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Contact Name / Additional Information",
			            currentItemValue: "",
			            currentItemValueId: "",
			            orderIndex: 2
			        });
			        this.addItem({
			            itemType: "clientAdditionalInfo",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Additional Information",
			            currentItemValue: "",
			            currentItemValueId: "",
			            countofArray: "",
			            orderIndex: 3
			        });
			        break;
			    case "reportclientsdivorce":
			        var _data = params.data;
			        this.addItem({
			            itemType: "divorcingParty",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Divorcing parties",
			            currentItemValue: "",
			            currentItemValueId: "",
			            orderIndex: 1
			        });
			        this.addItem({
			            itemType: "divorceReqLetter",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Who should receive the initial requirements letter(s)?",
			            currentItemValue: "",
			            currentItemValueId: "",
			            orderIndex: 3
			        });
			        this.addItem({
			            itemType: "displayContent",
			            customValues: { "viewDisplay": false },
			            itemLabel: "display Content",
			            currentItemValue: "",
			            currentItemValueId: "",
			            orderIndex: 4
			        });
			        /*this.addItem({
                        itemType: "divorcingPartyClientID",
                        customValues: { "viewDisplay": false },
                        itemLabel: "",
                        currentItemValue: "",
                        currentItemValueId: "",
                        orderIndex: 5
                    });*/
			        break;
			    case "suitability":
                    var _doesClientHaveAssets = {
                            value: {
                                "A": "Yes",
                                "B": "Client declines to disclose",
                                "C": "No",
			                },
                            id: {
                                "A": "A",
                                "B": "B",
                                "C": "C",
                            }
                    };
			        this.addItem({ itemType: "fedTxBrktPct", itemLabel: "Federal tax bracket", currentItemValue: params.data.fieldsInfo.fedTxBrktPct.name, changedItemValue: params.data.fieldsInfo.fedTxBrktPct.name, currentItemValueId: params.data.fieldsInfo.fedTxBrktPct.code, changedItemValueId: params.data.fieldsInfo.fedTxBrktPct.code, orderIndex: 1, customValues: { viewDisplay: true, infotype: 'finance' } });
			        this.addItem({ itemType: "annlIncm", itemLabel: "Individual annual income", currentItemValue: params.data.fieldsInfo.annlIncm.formatCurrency(), changedItemValue: params.data.fieldsInfo.annlIncm.formatCurrency(), currentItemValueId: params.data.fieldsInfo.annlIncm, changedItemValueId: params.data.fieldsInfo.annlIncm, orderIndex: 2, customValues: { viewDisplay: true, infotype: 'finance' } });
			        this.addItem({ itemType: "netWorth", itemLabel: "Individual net worth", currentItemValue: params.data.fieldsInfo.netWorth.formatCurrency(), changedItemValue: params.data.fieldsInfo.netWorth.formatCurrency(), currentItemValueId: params.data.fieldsInfo.netWorth, changedItemValueId: params.data.fieldsInfo.netWorth, orderIndex: 3, customValues: { viewDisplay: true, infotype: 'finance' } });
			        this.addItem({ itemType: "liqNetWorth", itemLabel: "Individual liquid net worth", currentItemValue: params.data.fieldsInfo.liqNetWorth.formatCurrency(), changedItemValue: params.data.fieldsInfo.liqNetWorth.formatCurrency(), currentItemValueId: params.data.fieldsInfo.liqNetWorth, changedItemValueId: params.data.fieldsInfo.liqNetWorth, orderIndex: 4, customValues: { viewDisplay: true, infotype: 'finance' } });			      
			        this.addItem({ itemType: "sourceOfIncome", itemLabel: "Source of Income", currentItemValue: params.data.fieldsInfo.sourceOfIncome.names, changedItemValue: params.data.fieldsInfo.sourceOfIncome.names, currentItemValueId: params.data.fieldsInfo.sourceOfIncome.names, changedItemValueId: params.data.fieldsInfo.sourceOfIncome.names, orderIndex: 5, customValues: { viewDisplay: true, infotype: 'finance', isEntityClient: params.data.fieldsInfo.isEntityClient } });
			        this.addItem({ itemType: "doesClientHaveInvestment", itemLabel: "Investment experience", currentItemValue: params.data.fieldsInfo.doesClientHaveInvestment, changedItemValue: params.data.fieldsInfo.doesClientHaveInvestment, currentItemValueId: params.data.fieldsInfo.doesClientHaveInvestment, changedItemValueId: params.data.fieldsInfo.doesClientHaveInvestment, orderIndex: 6, customValues: { viewDisplay: true, infotype: 'investment' } });			        
			        var currentClientProductExpes = JSON.parse(JSON.stringify(params.data.fieldsInfo.clientProductExpes));
			        this.addItem({ itemType: "clientProductExpes", itemLabel: "Investment experience", currentItemValue: currentClientProductExpes.names, changedItemValue: currentClientProductExpes.names, currentItemValueId: currentClientProductExpes.names, changedItemValueId: currentClientProductExpes.names, orderIndex: 6, customValues: { viewDisplay: true, infotype: 'investment', isEntityClient: params.data.fieldsInfo.isEntityClient } });
			        this.addItem({ itemType: "doesClientHaveAssets", itemLabel: "Does this client have assets held outside of Ameriprise?", currentItemValue: _doesClientHaveAssets.value[params.data.fieldsInfo.doesClientHaveAssets], changedItemValue: _doesClientHaveAssets.value[params.data.fieldsInfo.doesClientHaveAssets], currentItemValueId: _doesClientHaveAssets.id[params.data.fieldsInfo.doesClientHaveAssets], changedItemValueId: _doesClientHaveAssets.id[params.data.fieldsInfo.doesClientHaveAssets], orderIndex: 7, customValues: { viewDisplay: true, infotype: 'heldAwayAssets'}});
			        var currentAssetTypesHeldCollec = JSON.parse(JSON.stringify(params.data.fieldsInfo.assetTypeHeldCollec));
			        this.addItem({ itemType: "heldAwayAssets", itemLabel: "Held away assets", currentItemValue: currentAssetTypesHeldCollec.names, changedItemValue: params.data.fieldsInfo.assetTypeHeldCollec.names, currentItemValueId: currentAssetTypesHeldCollec.names, changedItemValueId: params.data.fieldsInfo.assetTypeHeldCollec.names, orderIndex: 8, customValues: { viewDisplay: true, infotype: 'heldAwayAssets' } });			        
			        this.addAdditionalEbixDataToModel(updateMode);
			        break;
			    case "entity":
			        this.addItem({ itemType: "entityType", customValues: { "viewDisplay": true }, itemLabel: "Entity type", currentItemValue: params.data.fieldsInfo.entityType.name, changedItemValue: params.data.fieldsInfo.entityType.name, currentItemValueId: params.data.fieldsInfo.entityType.code, changedItemValueId: params.data.fieldsInfo.entityType.code, orderIndex: 1 });                   			       

			        var showIndsTyp = false, showIndFreeFrmTxt = false, showNonOperEnty = false, showAddrType = false, showState = false, showCntry = false;
			        if (_.contains(industryOptionCode, params.data.fieldsInfo.entityType.code)) {
			            showIndsTyp = true;
			            showNonOperEnty = true;
			        }

			        if (_.contains(entityLocationCode, params.data.fieldsInfo.entityType.code)) {
			            showAddrType = true;
			            if (showAddrType && params.data.fieldsInfo.addressType == "US") {
			                showState = true;
			            }
			            if (showAddrType && params.data.fieldsInfo.addressType !== "US") {
			                showCntry = true;
			            }
			        }
			        this.addItem({ itemType: "industryClassifyType", customValues: { "viewDisplay": showIndsTyp }, itemLabel: "Industry classification", currentItemValue: params.data.fieldsInfo.indsClsCd.name, currentItemValueId: params.data.fieldsInfo.indsClsCd.name, orderIndex: 2 });
			        if (showIndsTyp && params.data.fieldsInfo.indsClsCd.name == "Other") {
			            showIndFreeFrmTxt = true;
			        }
			        this.addItem({ itemType: "industryFreeFormText", customValues: { "viewDisplay": showIndFreeFrmTxt }, itemLabel: "", currentItemValue: params.data.fieldsInfo.indsFreeFormTxt, currentItemValueId: params.data.fieldsInfo.indsFreeFormTxt, orderIndex: 3 });
			        this.addItem({ itemType: "nonOperEntyCd", customValues: { "viewDisplay": showNonOperEnty }, itemLabel: "Is this an operating entity?", currentItemValue: params.data.fieldsInfo.nonOperEntyCd, changedItemValue: params.data.fieldsInfo.nonOperEntyCd, currentItemValueId: params.data.fieldsInfo.nonOperEntyCd, changedItemValueId: params.data.fieldsInfo.nonOperEntyCd, orderIndex: 4 });
			        this.addItem({ itemType: "addressType", customValues: { "viewDisplay": showAddrType }, itemLabel: "Where is the entity legally established?", currentItemValue: params.data.fieldsInfo.addressType, changedItemValue: params.data.fieldsInfo.addressType, currentItemValueId: params.data.fieldsInfo.addressType, changedItemValueId: params.data.fieldsInfo.addressType, orderIndex: 5 });
			        this.addItem({ itemType: "stateCd", customValues: { "viewDisplay": showState }, itemLabel: "State", currentItemValue: params.data.fieldsInfo.stateCd, changedItemValue: params.data.fieldsInfo.stateCd, currentItemValueId: params.data.fieldsInfo.stateCd, changedItemValueId: params.data.fieldsInfo.stateCd, orderIndex: 6 });
			        this.addItem({ itemType: "frgnCtryCd", customValues: { "viewDisplay": showCntry }, itemLabel: "Country", currentItemValue: params.data.fieldsInfo.frgnCtryCd, changedItemValue: params.data.fieldsInfo.frgnCtryCd, currentItemValueId: params.data.fieldsInfo.frgnCtryCd, changedItemValueId: params.data.fieldsInfo.frgnCtryCd, orderIndex: 7 });
			        break;
			    case "driverslicense":
			        self.get('items').push(new GPMFieldModel().set({
			            itemType: "driverslicense",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Driver's license #",
			            currentItemValue: params.data.fieldsInfo.drvLicNbr,
			            changedItemValue: params.data.fieldsInfo.drvLicNbr,
			            orderIndex: 1
			        }));
			        self.get('items').push(new GPMFieldModel().set({
			            itemType: "stateid",
			            customValues: { "viewDisplay": true },
			            itemLabel: "State",
			            currentItemValue: params.data.fieldsInfo.drvLicSt,
			            currentItemValueId: params.data.fieldsInfo.drvLicStCd,
			            changedItemValue: params.data.fieldsInfo.drvLicSt,
			            changedItemValueId: params.data.fieldsInfo.drvLicStCd,
			            orderIndex: 2
			        }));

			        break;
			    case "honorific":

			        break;
			    case "documentDelivery":
			        var _data = params.data;
			        this.addItem({
			            itemType: "prefrcEmailShow",
			            customValues: { "viewDisplay": false },
			            itemLabel: "Email show",
			            currentItemValue: "false",
			            currentItemValueId: "false",
			            orderIndex: 1
			        });
			        this.addItem({
			            itemType: "prefrcShareHolder",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Shareholder documents",
			            currentItemValue: _data.prefrcShareHolder,
			            currentItemValueId: _data.prefrcShareHolder,
			            orderIndex: 2
			        });
			        this.addItem({
			            itemType: "prefrcAccount",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Account statements",
			            currentItemValue: _data.prefrcAccount,
			            currentItemValueId: _data.prefrcAccount,
			            orderIndex: 3
			        });
			        this.addItem({
			            itemType: "prefrcFinConfirm",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Financial confirms",
			            currentItemValue: _data.prefrcFinConfirm,
			            currentItemValueId: _data.prefrcFinConfirm,
			            orderIndex: 4
			        });
			        this.addItem({
			            itemType: "prefrcDocType",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Additional document types",
			            currentItemValue: _data.prefrcDocType,
			            currentItemValueId: _data.prefrcDocType,
			            orderIndex: 5
			        });
			        this.addItem({
			            itemType: "displayDocDeliContent",
			            customValues: { "viewDisplay": false },
			            itemLabel: "displayDocDeliContent",
			            currentItemValue: "",
			            currentItemValueId: "",
			            orderIndex: 6
			        });
			        break;
			    case "employment":
			        //need to add more vaues 
			        var _data = params.data.fieldsInfo;
			        var _empStatus = _data.empStatus;
			       
			        this.addItem({ itemType: "emplStatCd", customValues: { "viewDisplay": true }, itemLabel: "Employment status", currentItemValue: _empStatus.value, currentItemValueId: _empStatus.serviceVal, orderIndex: 3 });

			        var _industryTypeDisplay = false;
			        if (_empStatus.value.toLowerCase() == "self employed") {
			            _industryTypeDisplay = true;
			        }
			        this.addItem({
			            itemType: "industryClassifyType",
			            customValues: { "viewDisplay": _industryTypeDisplay },
			            itemLabel: "Industry classification",
			            currentItemValue: _data.indsClsDesc,
			            currentItemValueId: _data.indsClsCd,
			            orderIndex: 4
			        });
			        var _industryFreeFormTextDisplay = false;
			        if (_industryTypeDisplay && _data.indsClsDesc == "Other") {
			            _industryFreeFormTextDisplay = true;
			        }
			        this.addItem({
			            itemType: "industryFreeFormText",
			            customValues: { "viewDisplay": _industryFreeFormTextDisplay },
			            itemLabel: "",
			            currentItemValue: _data.indsClsTxt,
			            currentItemValueId: _data.indsClsTxt,
			            orderIndex: 5
			        });

			        this.addItem({ itemType: "occpDesc", customValues: { "viewDisplay": true }, itemLabel: "Occupation", currentItemValue: (_data.primaryOccupation.desc), currentItemValueId: _data.primaryOccupation.code, orderIndex: 6 });
			        this.addItem({ itemType: "occpDescTxt", customValues: { "viewDisplay": true }, itemLabel: "Other occupation text", currentItemValue: (_data.occpDescTxt), currentItemValueId: _data.occpDescTxt, orderIndex: 6 });

			        var _jobTitleViewDisplay = true;
			        if (this.get("contactId") == "" || this.get("contactId") == null || this.get("contactId") == undefined) {
			            _jobTitleViewDisplay = false;
			        }
			        this.addItem({ itemType: "clJobTitle", customValues: { "viewDisplay": _jobTitleViewDisplay }, itemLabel: "Job title", currentItemValue: _data.clJobTitle, currentItemValueId: _data.clJobTitle, orderIndex: 7 });
			        this.addItem({
			            itemType: "employerAddressCollection",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Employer",
			            currentItemValue: _data.employerAddrrsColl,
			            currentItemValueId: _data.employerAddrrsColl,
			            orderIndex: 8
			        });
			        this.addItem({ itemType: "finInstnEmplCd", customValues: { "viewDisplay": true }, itemLabel: "Is the client employed by, or an associated person of, a registered broker-dealer, securities exchange, or the Financial Industry Regulatory Authority (FINRA)?", currentItemValue: (_data.finInstnEmplCd == "Y" ? "Yes" : (_data.finInstnEmplCd == "N" ? "No" : "")), currentItemValueId: _data.finInstnEmplCd, orderIndex: 1 });
			        this.addItem({
			            itemType: "finraAddressCollection",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Which employer",
			            currentItemValue: _data.finraAddrsColl,
			            currentItemValueId: _data.finraAddrsColl,
			            orderIndex: 9
			        });
			        this.addItem({ itemType: "ownrOfcrCd", customValues: { "viewDisplay": true }, itemLabel: "Is the client an officer, director, 10% shareholder or policymaker of a publicly traded company?", currentItemValue: (_data.ownrOfcrCd == "Y" ? "Yes" : (_data.ownrOfcrCd == "N" ? "No" : "")), currentItemValueId: _data.ownrOfcrCd, orderIndex: 2 });
			        this.addItem({
			            itemType: "shareholderAddressCollection",
			            customValues: { "viewDisplay": true },
			            itemLabel: "Company",
			            currentItemValue: _data.isOfficerAddrsCll,
			            currentItemValueId: _data.isOfficerAddrsCll,
			            orderIndex: 10
			        });
			        this.addItem({
			            itemType: "finraSectionArr",
			            customValues: { "viewDisplay": false, finraCheck: _data.finraCheckbox["finraCheck"] },
			            itemLabel: "Which employer?",
			            currentItemValue: _data.finraCheckbox["finraSectionArr"],
			            currentItemValueId: _data.finraCheckbox["finraSectionArr"],
			            orderIndex: 9
			        });
			        this.addItem({
			            itemType: "sameAsCompanyArr",
			            customValues: { "viewDisplay": false, sameAsCompanyCheck: _data.shareHolderCheckbox["sameAsCompanyCheck"] },
			            itemLabel: "Same as",
			            currentItemValue: _data.shareHolderCheckbox["sameAsCompanyArr"],
			            currentItemValueId: _data.shareHolderCheckbox["sameAsCompanyArr"],
			            orderIndex: 9
			        });
			        break;
			    case "alert":
			        var _data = params.data;
			        var _preferedEmailType = _data.prfrdEmail.type.split(" ")[0], _preferdEmail = "", _preferedPhoneType = _data.prfrdPhone.type, _preferdPhone = "", phServiceProperties = {};
			        for (var i = 0; i < _data.emails.length; i++) {
			            if (_data.emails[i].emlUseCd == _preferedEmailType) {
			                _preferdEmail = _data.emails[i].emailId;
			            }
			        }
			        var _phoneValues = [];
			        if (_data.prfrdPhone.type) {
			            _preferdPhone = _data.prfrdPhone.num;
			            _phoneValues = [_preferedPhoneType, _preferdPhone];
			            phServiceProperties = {
			                dlvDestId: _data.dlvDestId,
			                "viewDisplay": true
			            }
			        }
			        this.addItem({ customValues: { emails: _data.emails, "viewDisplay": true }, itemType: "preferedEmail", itemLabel: "Email alerts sent to", isComplexType: true, currentItemValue: [_preferedEmailType, _preferdEmail], changedItemValue: [_preferedEmailType, _preferdEmail], currentItemValueId: [_preferedEmailType, _preferdEmail], changedItemValueId: [_preferedEmailType, _preferdEmail], orderIndex: 1 });
			        this.addItem({ customValues: phServiceProperties, itemType: "preferedPhone", itemLabel: "Text alerts sent to", isComplexType: true, currentItemValue: _phoneValues, changedItemValue: _phoneValues, currentItemValueId: _phoneValues, changedItemValueId: _phoneValues, orderIndex: 1 });
			        var _myProfileValues = [], workWithMyAdvsrVals = [], _categories = _data.category;
			        var _catgryItemTypeMapping = {
			            "701": "myProfile",
			            "702": "accountManagement",
			            "703": "workingWithAdvisor",
			        }
			        for (var j = 0; j < _categories.length; j++) {
			            var _catgry = _categories[j];
			            var _catgryLbl = _catgry.label, _catgryValues = [];
			            var _ctagryItem = {
			                type: _catgryItemTypeMapping[_catgry.prfrId],
			                label: _catgryLbl,
			                values: [],
			                customValues: _catgry.customValues,
			            }
			            for (var k = 0; k < _catgry.values.length; k++) {
			                var _section = _catgry.values[k];
			                var _sctnItem = {
			                    itemType: _section.label,
			                    itemLabel: _section.label,
			                    values: ["No", "No"],
			                    customValues: _section.customValues,
			                    valueIds: [false, false],

			                }
			                for (var l = 0; l < _section.values.length; l++) {
			                    var _sectnItemVal = _section.values[l];
			                    if (_sectnItemVal.type == "email") {
			                        if (_sectnItemVal.isRequired) {
			                            _sctnItem.values[0] = "Required";
			                            _sctnItem.valueIds[0] = "Required";
			                        } else {
			                            _sctnItem.values[0] = _sectnItemVal.value;
			                            _sctnItem.valueIds[0] = _sectnItemVal.valueId;
			                        }
			                    } else if (_sectnItemVal.type == "SMS") {
			                        _sctnItem.values[1] = _sectnItemVal.value ? _sectnItemVal.value : "No";
			                        _sctnItem.valueIds[1] = _sectnItemVal.valueId;
			                    }
			                }
			                _ctagryItem.values.push(_sctnItem);
			            }
			            this.addItem({ customValues: _catgry.customValues, itemType: _ctagryItem.type, itemLabel: _ctagryItem.label, isComplexType: true, itemSubLabels: ["Email", "Text"], currentItemValue: JSON.parse(JSON.stringify(_ctagryItem.values)), changedItemValue: JSON.parse(JSON.stringify(_ctagryItem.values)), currentItemValueId: JSON.parse(JSON.stringify(_ctagryItem.values)), changedItemValueId: JSON.parse(JSON.stringify(_ctagryItem.values)), orderIndex: 1 });
			        }
			        break;
			    case "phonenumbers":
			        var _data = params.data, _colaPhones = params.data.colaPhones, _ebixPhones = params.data.ebixPhones;
			        $(_colaPhones).each(function (i, d) {
			            var _currentVal = new ColaPhoneNumModel(d.value.toJSON()), _changeVal = new ColaPhoneNumModel(d.value.toJSON());
			            self.addItem({ customValues: d.customValues, itemType: d.value.get('clTeleId'), itemLabel: d.value.get('phnLblTxt').substr(0, 1) + d.value.get('phnLblTxt').substr(1, d.value.get('phnLblTxt').lnegth).toLowerCase(), isComplexType: true, currentItemValue: _currentVal, changedItemValue: _changeVal, currentItemValueId: _currentVal, changedItemValueId: _changeVal, orderIndex: 1 });
			        });
			        $(_ebixPhones).each(function (j, datum) {
			            var _currentVal = new EbixPhoneNumModel(datum.value.toJSON()), _changeVal = new EbixPhoneNumModel(datum.value.toJSON());
			            self.addItem({ customValues: datum.customValues, itemType: datum.value.get('Id'), itemLabel: datum.value.get('PhoneTypeDesc') + ' (Contact Manager)', isComplexType: true, currentItemValue: _currentVal, changedItemValue: _changeVal, currentItemValueId: _currentVal, changedItemValueId: _changeVal, orderIndex: 1 });
			        });
			        var _items = self.get('items');
			        _items.sort(function (a, b) {
			            for (var i = 0; i < 2; i++) {
			                if (i == 1) {
			                    retval = a.get('itemLabel').toLowerCase() < b.get('itemLabel').toLowerCase() ? -1 : a.get('itemLabel').toLowerCase() > b.get('itemLabel').toLowerCase() ? 1 : 0;
			                } else {
			                    retval = a.get('customValues').prefferedNum < b.get('customValues').prefferedNum ? -1 : a.get('customValues').prefferedNum > b.get('customValues').prefferedNum ? 1 : 0;
			                }

			                if (retval !== 0) {
			                    return retval;
			                }
			            }

			        });

			        break;
			    case "email":
			        if (params.data) {
			            var _data = params.data, _colaEmails = params.data.colaEmails, _ebixEmails = params.data.ebixEmails;
			            $(_colaEmails).each(function (i, d) {
			                var _currentVal = new ColaEmailModel(d.value.toJSON()), _changeVal = new ColaEmailModel(d.value.toJSON());
			                self.addItem({ customValues: d.customValues, itemType: d.value.get('emlUseCd'), itemLabel: d.value.get('emlUseCd'), isComplexType: true, currentItemValue: _currentVal, changedItemValue: _changeVal, currentItemValueId: _currentVal, changedItemValueId: _changeVal, orderIndex: i });
			            });
			            $(_ebixEmails).each(function (j, d) {
			                var _currentVal = new EbixEmailModel(d.value.toJSON()), _changeVal = new EbixEmailModel(d.value.toJSON());
			                self.addItem({ customValues: d.customValues, itemType: d.value.get('Id'), itemLabel: d.value.get('WebAddressTypeDesc'), isComplexType: true, currentItemValue: _currentVal, changedItemValue: _changeVal, currentItemValueId: _currentVal, changedItemValueId: _changeVal, orderIndex: j });
			            });
			        }
			        break;
			    case "communicationPreference":
			        var _data = params.data;
			        var _emails = _data.advisorEmail.emails, _primaryEmail = "", _secondaryEmail = "";
			        //this is a special case, it has got 3 different sections
			        _primaryEmail = _emails.find(function (row) { return row.emlUseCd == "Primary" });
			        _secondaryEmail = _emails.find(function (row) { return row.emlUseCd == "Secondary" });
			        this.set('hasSections', true);
			        this.set('itemSections', []);
			        var _advsrEmailPref = _data.advisorEmail, _amerEmailPref = _data.ameripriseEmail, _commnCtnPref = _data.communicationInterests;
			        //add advsrcommntctn pref
			        var _advrEmailSectn = this.addSection({ "sectionId": _advsrEmailPref.prfrId, "sectionLabel": "Communication from advisor" });
			        //now add items to section
			        var _emailType = _advsrEmailPref.prfrdEmail.type.split(" ")[0];
			        self.addItem({ customValues: { "emails": _advsrEmailPref.emails }, itemType: "emailType", itemLabel: "Delivered to", isComplexType: true, currentItemValue: _emailType, changedItemValue: _emailType, currentItemValueId: _emailType, changedItemValueId: _emailType, orderIndex: 1 }, _advrEmailSectn.sectionId);
			        _.each(_advsrEmailPref.values, function (data, index) {
			            self.addItem({ customValues: data.customValues, itemType: data.prfrId, itemLabel: data.label, isComplexType: true, currentItemValue: data.value, changedItemValue: data.value, currentItemValueId: data.valueId, changedItemValueId: data.valueId, orderIndex: 1 }, _advrEmailSectn.sectionId);
			        });
			        //add amer commntctn pref
			        var _amerEmailSectn = this.addSection({ "sectionId": _amerEmailPref.prfrId, "sectionLabel": "Communication from Ameriprise" });
			        var _amerEmailType = _amerEmailPref.prfrdEmail.type.split(" ")[0];
			        //now add items to section
			        self.addItem({ customValues: { "emails": _amerEmailPref.emails }, itemType: "emailType", itemLabel: "Delivered to", isComplexType: true, currentItemValue: _amerEmailType, changedItemValue: _amerEmailType, currentItemValueId: _amerEmailType, changedItemValueId: _amerEmailType, orderIndex: 1 }, _amerEmailSectn.sectionId);
			        _.each(_amerEmailPref.values, function (data, index) {
			            self.addItem({ customValues: data.customValues, itemType: data.prfrId, itemLabel: data.label, isComplexType: true, currentItemValue: data.value, changedItemValue: data.value, currentItemValueId: data.value, changedItemValueId: data.value, orderIndex: 1 }, _amerEmailSectn.sectionId);
			        })
			        //add commnctn pref
			        var _sectionCustomval = {
			            "sectionDescription": "Client answers to these questions help inform the content Ameriprise provides through several channels, including email and newsletters. If a valid email address is on file but this section remains blank, your client has not yet made selections for this section."
			        }
			        var _commnctnPrefSectn = this.addSection({ "sectionId": _commnCtnPref.prfrId, "sectionLabel": "Communication interests", "customValues": _sectionCustomval });
			        var _data = _commnCtnPref.values[0];
			        if (_data != undefined) {
			            //now add items to section
			            self.addItem({ customValues: { "options": _commnCtnPref.customValues.retirementOptions }, itemType: "Retirement stage", itemLabel: _data.label, isComplexType: true, currentItemValue: _data.value, changedItemValue: _data.value, currentItemValueId: _data.valueId, changedItemValueId: _data.valueId, orderIndex: 1 }, _commnctnPrefSectn.sectionId);
			            var _prefChoices = _commnCtnPref.customValues.prfChoices;
			            for (var key in _prefChoices) {
			                var _viewDisplay = (key == _data.valueId) ? true : false;
			                var _subPrfrs = _prefChoices[key].subPrfrs;
			                _.each(_subPrfrs, function (data, index) {
			                    var _item = { customValues: { viewDisplay: _viewDisplay, refId: key, options: data.subPrefOptions }, itemType: data.labelId, itemLabel: data.label, isComplexType: true, currentItemValue: data.value, changedItemValue: data.value, currentItemValueId: data.valueId, changedItemValueId: data.valueId, orderIndex: 1 }
			                    self.addItem(_item, _commnctnPrefSectn.sectionId);
			                });
			            }
			        }
			        break;
			    default:
			        break;
			}			
		},
		addItem:function(data,sectionId){
			var _itemModel = new GPMFieldModel().set({
				isComplexType:data.isComplexType?data.isComplexType:false,
						itemSubLabels:data.itemSubLabels?data.itemSubLabels:[],
						customValues:data.customValues?data.customValues:{},
						itemType:data.itemType,
						itemLabel:data.itemLabel,
						itemLabelId:data.itemLabelId?data.itemLabelId:null,
						currentItemValue:data.currentItemValue,
						currentItemValueId:data.currentItemValueId,
						changedItemValue:data.changedItemValue?data.changedItemValue:data.currentItemValue,
						changedItemValueId:data.changedItemValueId?data.changedItemValueId:data.currentItemValueId,
						orderIndex:data.sectionId?data.sectionId:null,
						orderIndex:data.orderIndex});
			if(sectionId != null && sectionId !=undefined && sectionId != ""){
				var _sections = this.get('itemSections');
				var _section = _sections.find(function(row){return row.sectionId == sectionId});
				_section.items.push(_itemModel);
			}else{
				this.get('items').push(_itemModel);
			}
			
		},
		addSection:function(section){
			var _sections = this.get('itemSections');
			var _section = {"sectionId":section.sectionId,"sectionLabel":section.sectionLabel,"items":[],"customValues":section.customValues?section.customValues:{} };
				_sections.push(_section);
			return _section;
		},
		getChangedItems:function(){
		    var _items = this.get('items'), _changedItems = [];
		    var _that = this;
			if(this.get('updateMode') == "alert"){
				return _items;
			}
			/*if(this.get('updateMode') == "suitability"){
				return _items;
			}*/
			if(this.get('updateMode') == "phonenumbers"){
				$.each(_items,function(index,item){
					if(item.get('customValues').changed == true && item.get('currentItemValue').get('ElectronicDownload') !=1){
						_changedItems.push(item);
					}
				});
				return _changedItems;
			}
			if(this.get('updateMode') == "email"){
				$.each(_items,function(index,item){
					if(item.get('customValues').changed == true && item.get('customValues').viewDispaly == true){
						_changedItems.push(item);
					}
				});
				return _changedItems;
			}
			$.each(_items,function(index,item){
				var _currentItemvalue = item.get('currentItemValue'),_changedItemValue = item.get('changedItemValue');
				var _isItemModified = false;
				if(Array.isArray(_currentItemvalue) &&  !item.get('isComplexType')){
					if(_changedItemValue.length != _currentItemvalue.length){
					_isItemModified = true;
					} else {
					    if (item.get('itemType') == "clientProductExpes") {
					        _.each(_changedItemValue, function (cItem) {
					            var matchedItem = _.find(_currentItemvalue, function (currentInvList) {
					                return (cItem.code == currentInvList.code);
					            });
					            if (!matchedItem) {
					                _isItemModified = true;
					            }
					            _.find(_currentItemvalue, function (currentInvList) {
					                if (cItem.code == currentInvList.code) {
					                    if ((cItem.years.mapCode != currentInvList.years.mapCode)
					                        || (cItem.transaction.mapCode != currentInvList.transaction.mapCode)) {
					                        _isItemModified = true;
					                    }
					                }
					            });					           
					        });

					    } else if (item.get('itemType') == "heldAwayAssets") {
					        _.each(_changedItemValue, function (cItem) {
					            var matchedItem = _.find(_currentItemvalue, function (currentInvList) {
					                return (cItem.code == currentInvList.code);
					            });
					            if (!matchedItem) {
					                _isItemModified = true;
					            }
					            _.find(_currentItemvalue, function (currentHeldAwayAmt) {
					                if (cItem.code == currentHeldAwayAmt.code) {
					                    if (cItem.assetVal.enteredValue != currentHeldAwayAmt.assetVal.enteredValue){
					                        _isItemModified = true;
					                    }
					                }
					            });
					        });
					    } else if (item.get('itemType') == "sourceOfIncome") {
					        _.each(_changedItemValue, function (cItem) {
					            var matchedItem = _.find(_currentItemvalue, function (currentInvList) {
					                return (cItem.mapCode == currentInvList.mapCode);
					            });
					            if (!matchedItem) {
					                _isItemModified = true;
					            }					            
					        });
					    } else {
					        _.each(_changedItemValue, function (cItem) {
					            if (_currentItemvalue.indexOf(cItem) == -1) {
					                _isItemModified = true;
					            }
					        });
					    }
				}
					}	
				else{
					if(item.get('currentItemValue') == null || item.get('currentItemValue') == "" || item.get('currentItemValue') == undefined ){
						if( item.get('changedItemValue') != null && item.get('changedItemValue') != "" &&  item.get('changedItemValue') != undefined ) {
							_isItemModified = true;
						}
					}else if(item.get('currentItemValue').toString().toLowerCase() != item.get('changedItemValue').toString().toLowerCase() && !item.get('customValues').doNotCountForChange) {
						_isItemModified = true;
					}
				
				}
				if(_isItemModified){
					_changedItems.push(item);
				}
			});
			return _changedItems;
		},
		clearItems : function(){
			this.set('items',[]);
		}
	});
	return new GPMUPdateModel();
});