/**
    * @ngdoc property
    * @name selectFund Directive
    * @requires TransactConstant
    * @requires newFundDetailsModel
    * @requires newFundDetailsInitialLoader
    * @requires selectFundModel
    * @requires selectFundInitialLoader
    * @requires transactEventConstants
    * @requires fundDetails
    * @requires transactModel
    * @description
    *
    * - This directive is responsible for displaying the selectFund Form.
    *
**/
 'use strict';

 var selectFund = function ($uibModal, $filter, TransactConstant, newFundDetailsModel, newFundDetailsInitialLoader, selectFundModel, selectFundInitialLoader, transactEventConstants, $timeout, fundDetails, transactModel, $stateParams, paperlessModel, eventConstants, configUrlModel, $window, appConfig, $cookies, checkKycModelService, toaster, fundDetailsModel, $state, authenticationService) {
    return {

        template: require('./selectFund.html'),
        restrict: 'E',
        replace: true,
        scope: {
            kycState : "=?"
        },
        controller:['$scope', function($scope) {
            $scope.configDataLost = {};
            $scope.cancelAddFunds = false;
            $scope.configDataLost.showNotification = false;
            $scope.isPaperLess = transactModel.isPaperless;
            $scope.radios = {};
            $scope.fundConfigObj = {};
            $scope.showNotification = false;
            $scope.showKycDtlsNotif = false;
            $scope.showAddDiv = false;
            $scope.showContinue = false;
            $scope.isComingFromEdit = false;
            $scope.transactionLimit = 0;
            $scope.sameFund = false;
            $scope.noFundSelected = true;
            var translateFilter = $filter('translate'), buyTotalInvAmount = 0, isDataChanged = true;
            $scope.isEditTile =false;
            $scope.editIndex = null;
            $scope.isDirectInv = false;   
            $scope.invocationPoint; /*It will be '0'- onload, '1' - onclick of save, '2' - onclick of continue */
            $scope.isKycRegAadhar = false;        

            /*Service Integration For InvestmentAmount - Starts*/
            var requestObject = {}, returnedObj = {};
            requestObject.bodyObj = {};
            requestObject.bodyObj.fundOptions = [];

            function setRequestObject() {
                requestObject = {};
                requestObject.bodyObj = {};
                requestObject.bodyObj.fundOptions = [];
                returnedObj = fundDetailsModel.setCommonInvProperties();
                requestObject.bodyObj.folioId = returnedObj.folioId;
                requestObject.bodyObj.panNo = returnedObj.panNo;
                requestObject.bodyObj.webRefNo = returnedObj.webRefNo;

                if ($scope.invocationPoint === 1) {
                    var funds = [];
                    funds = fundDetails.getFundDetails();
                    funds.push({
                        amount : $scope.amountObject.value
                    });
                    setFundOptions(funds);
                } else if($scope.invocationPoint === 2){
                    setFundOptions(fundDetails.getFundDetails());
                } else {
                    requestObject.bodyObj.fundOptions = [];
                }
                //Calling service with requestObject
                if (requestObject.bodyObj.panNo && requestObject.bodyObj.folioId) {
                    fundDetails.fetchRvalidateInvFYLimit(requestObject).then(transactionLimitSuccess, transactionLimitFailure);
                }
            }

            function setFundOptions(fundDetailsArray) {
                angular.forEach(fundDetailsArray, function(value, key) {
                    var fundObj = {};
                    fundObj.amount = value.amount.toString();
                    fundObj.txnType = "P";
                    fundObj.startDate = "";
                    fundObj.endDate = "";
                    fundObj.frequency = "";
                    requestObject.bodyObj.fundOptions.push(fundObj);
                });
            }

            function transactionLimitSuccess(data) {
                $scope.showNotification = false;
                $scope.showKycDtlsNotif = false;
                if(!$scope.transactionLimit){
                    transactModel.setKycTransactionLimit(data.allowableTxnAmount);
                    $scope.transactionLimit = transactModel.getKycTransactionLimit();
                }

                if ($scope.invocationPoint === 1 && !$scope.onFundLoad) {
                    if (data.statusFlag === TransactConstant.transact.INVESTMENT_REJECTED_CODE) {
                        $scope.showNotification = true;
                    } else {
                        saveInvstmentDetails();
                    }
                } else if ($scope.invocationPoint === 2 && !$scope.onFundLoad) {
                    if (data.statusFlag === TransactConstant.transact.INVESTMENT_WARNING_CODE) {
                        $scope.showKycDtlsNotif = true;
                    } else {
                        $scope.$emit(transactEventConstants.transact.Show_Fund);
                        $scope.$emit("paymntDtls");
                        if ($scope.isPaperLess) {
                            redirectToPaymentDtls();
                        }
                    }
                }
            }

            function transactionLimitFailure(data) {
                toaster.error(data.data[0].errorDescription);
            }
            /*Service Integration For InvestmentAmount - Ends*/

            //For Transaction limit validation, if user is KYC-reg through Aadhar 
            $scope.isKycRegAadhar = transactModel.getKYCMode();           
            $scope.$on('checkKycMode', function() {
                $scope.isKycRegAadhar = transactModel.getKYCMode();
                // Fetch transaction limit from service
                if($scope.isKycRegAadhar){
                    $scope.invocationPoint = 0;
                    setRequestObject();
                }
            });

            //On BUYForm load
            function checkKycModeOnLoad() {
                $scope.onFundLoad = true;
                $scope.invocationPoint = 0
                setRequestObject();
            }
            if($scope.isKycRegAadhar){
                checkKycModeOnLoad();
            }
            

            /*If user comes from Review edit, reseting select fund - START */
            $scope.maximumFundNo;
            $scope.resettingDataOnEdit = function(){
                $scope.showAddDiv = true;
                $scope.showContinue = true;
                $scope.previousData = angular.copy(transactModel.getFundDetails());
                var detailsArr = fundDetails.getFundDetails();
                //var detailsArr = transactModel.getFundDetails();
                $timeout(function(){
                    $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
                },0); 
                $scope.maximumFundNo = parseInt(newFundDetailsModel.getMaxFundLimit());
                if(detailsArr.length < $scope.maximumFundNo){
                    $scope.showAddLink = true;
                }
            };

            //For Paperless Module
            if(paperlessModel.fundDtls.hasData){
                $scope.isComingFromEdit = true;
                $scope.resettingDataOnEdit();
            };

            //For Transact Module
            if(($stateParams.key === TransactConstant.transact.Fund_Key || $stateParams.key === TransactConstant.transact.Payment_Key) && !(transactModel.openFundTab)){
                $scope.isComingFromEdit = true;
                $scope.resettingDataOnEdit();
            }

            //This is added on for No functionality of InvestmentPreference
            if(transactModel.showFundsOnNo) {
                $scope.isComingFromEdit = true;
                $scope.resettingDataOnEdit();
            }
            /*If user comes from Review edit, reseting select fund - CLOSE*/


            /*If not edit, refreshing the funddetails*/
            if(!$scope.isComingFromEdit){
                fundDetails.removeFundDetails();
            }

            // setting Dividend option based on the selected Fund
            $scope.$on(transactEventConstants.transact.FUND_UPDATED, function(event){
                if(!$scope.maximumFundNo){
                    $scope.maximumFundNo = parseInt(newFundDetailsModel.getMaxFundLimit());
                }
                $scope.radios.modeSelectedDiv = "";
                $scope.dividendOptions[0].disable = false;
                $scope.dividendOptions[1].disable = false;
                $timeout(function(){
                    $scope.fundConfigObj.showDividendOptions = true;
                    if($scope.destinationFund){
                        if($scope.destinationFund.fundType === 'E'){
                            $scope.amountObject.min = parseInt($scope.destinationFund.minAddPurAmt);
                            if($scope.destinationFund.payoutFlag == 'Y' && $scope.destinationFund.reinvestmentFlag == 'Y'){
                                if($scope.destinationFund.dividendFlag == 'P'){
                                    $scope.radios.modeSelectedDiv = 'Payout';
                                    $scope.dividendOptions[0].disable = true;
                                    $scope.dividendOptions[1].disable = true;
                                }else if($scope.destinationFund.dividendFlag == 'R'){
                                    $scope.radios.modeSelectedDiv = 'Re-Investment';
                                    $scope.dividendOptions[0].disable = true;
                                    $scope.dividendOptions[1].disable = true;
                                }
                            }else if($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'N'){
                                $scope.radios.modeSelectedDiv = 'NA';
                                $scope.fundConfigObj.showDividendOptions = false;
                            }else if($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'Y'){
                                $scope.radios.modeSelectedDiv = 'Re-Investment';
                                $scope.dividendOptions[0].disable = true;
                                $scope.dividendOptions[1].disable = true;
                            }else{
                                $scope.radios.modeSelectedDiv = 'Payout';
                                $scope.dividendOptions[0].disable = true;
                                $scope.dividendOptions[1].disable = true;
                            }
                        }else if($scope.destinationFund.fundType === 'N'){
                            $scope.amountObject.min = parseInt($scope.destinationFund.minNewPurAmt);
                            if($scope.destinationFund.payoutFlag == 'Y' && $scope.destinationFund.reinvestmentFlag == 'Y'){
                                if($scope.destinationFund.dividendFlag == 'P'){
                                    $scope.radios.modeSelectedDiv = 'Payout';
                                }else if($scope.destinationFund.dividendFlag == 'R'){
                                    $scope.radios.modeSelectedDiv = 'Re-Investment';
                                }
                                }else if($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'N'){
                                    $scope.radios.modeSelectedDiv = 'NA';
                                    $scope.fundConfigObj.showDividendOptions = false;
                                }else if($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'Y'){
                                    $scope.radios.modeSelectedDiv = 'Re-Investment';
                                }else if($scope.destinationFund.payoutFlag == 'Y' && $scope.destinationFund.reinvestmentFlag == 'N'){
                                    $scope.radios.modeSelectedDiv = 'Payout';
                                    $scope.dividendOptions[0].disable = true;
                                }else{
                                    $scope.radios.modeSelectedDiv = 'Payout';
                                }
                        }
                        
                        $scope.amountObject.message = translateFilter(TransactConstant.common.MINIMUM) + " <span class='icon-fti_rupee'></span>" + $scope.amountObject.min;
                    }                  
                },0);  
            });

            // This is done to handle the reset fund in case of Direct.
            $scope.$on(transactEventConstants.transact.FUND_CHANGED, function (event) {
                $scope.isDirectInv = true;
            });

            $scope.amountObject = {

                key : "Amount",
                text : translateFilter(TransactConstant.common.AMT) +" <span class='icon-fti_rupee'></span>",
                value : "",
                name : "Amount",
                type : "number",
                min : "",
                message : "",
                isRequired : true,
                //pattern: /^(?!\.?$)\d{0,9}(\.\d{1,2})?$/
                //pattern: /^\d+$/  
                pattern: /^[0-9]*$/
            };

            $scope.dividendOptions = [
            {
                label: translateFilter(TransactConstant.common.DIVIDEND_RE_INVESTMENT),
                value: 'Re-Investment',
                selected: false,
                disable: true
            },
            {
                label: translateFilter(TransactConstant.common.DIVIDEND_PAYOUT), 
                value: 'Payout',
                selected: false,
                disable: true
            }
            ];


        // data setting for the Popup
        $scope.popUpHeader= $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_LIMIT);
        $scope.popUpText= $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_Desc);
        $scope.btnNo= $filter('translate')(TransactConstant.buy.CANCEL_BUTTON);
        $scope.btnYes= $filter('translate')(TransactConstant.buy.DOWNLOAD_KYC_FORM);
        $scope.noEventName = "FundLimitCancel";

        // KYC Additional Details Notification popup        
        $scope.kycDtlsText= $filter('translate')(TransactConstant.common.KYC_ADDITIONAL_DETAILS);
        $scope.kycDtlsBtnNo= $filter('translate')(TransactConstant.common.CANCEL);
        $scope.kycDtlsBtnYes= $filter('translate')(TransactConstant.common.CONTINUE);
        $scope.kycDtlsNoEventName = "kycDetailsCancel";


        //If user selects "Download E-KYC" in download kyc notification popup
        var configURL = configUrlModel.getEnvUrl('MARKETING_URL'),  
            transactNowUrl = appConfig[configURL]+"/#tab_tab2",
            pdfUrl = appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL; 

        $scope.$on('downloadKyc', function (event, resp) {
            $scope.showNotification = false;
            $window.open(pdfUrl, "_blank");
            if ($scope.isPaperLess || transactModel.isTransactNowModule) {
                location.href = transactNowUrl;
            }else {
                $state.go("transact.base.terminateEkyc");
            }
        });

        //If user selects "Cancel" in download kyc notification popup
        $scope.$on('FundLimitCancel', function(){
            $scope.showNotification = false;            
        });

        /* If user selects "Continue" in KYC Additional details popup */
        $scope.$on('showKycDtlsForm', function(event, data) {
            $scope.showKycDtlsNotif = false;
            paperlessModel.fundDtls.hasData = true;
            $state.go($scope.kycState);             
        });

        /*If user selects "Cancel" in KYC Additional details popup */
        $scope.$on('kycDetailsCancel', function(event, data) {
            $scope.showKycDtlsNotif = false;
        });

        $scope.$on('FundLimitCancel', function(){
            $scope.showNotification = false;
        });

        // edit of key value grid tile
        $scope.$on('editSipFund', function (event, resp) {
            $scope.isEditTile = true;
            $scope.editIndex = resp.index;
            $scope.editingObj = resp.data;
            $scope.responseFundDetails = resp.data;
            var fundArr = fundDetails.getFundArr();
            $scope.fundObj = fundArr[resp.index];
            $scope.$broadcast(transactEventConstants.transact.EDIT_FUND, {fundObj:$scope.fundObj});
            // $scope.$broadcast(transactEventConstants.transact.EDIT_FUND, {fundType:$scope.responseFundDetails.fundType, fundName: $scope.responseFundDetails.fundName, title: $scope.responseFundDetails.fundTitle});
            // $scope.destinationFund.fundName = $scope.responseFundDetails.fundName;
            $scope.amountObject.value = $scope.responseFundDetails.amount;
            $scope.radios.modeSelectedDiv = $scope.responseFundDetails.dividend;
            $scope.showAddDiv = false;
            $scope.showAddLink = false;
            $scope.showContinue = false;  
            $scope.$emit(transactEventConstants.transact.HIDE_PAPERLESS_BTNS);      
        });

        // for remapping the keyValueGrid configuration 
        $scope.$on(transactEventConstants.transact.Edit_Fund_Button_Clicked, function (event) {
            $scope.previousData = angular.copy(transactModel.getFundDetails());
            transactModel.fundDetailsEditClicked = true;
            transactModel.setTransactType(TransactConstant.buy.BUYFUND);
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            //for investor continue button and add more funds
            if ($state.current.name === 'invTransact.base.buy' && authenticationService.isInvestorLoggedIn()){
            $scope.showAddDiv = true;
             $scope.showContinue = true;
              var detailsArr = transactModel.getFundDetails();
                $scope.maximumFundNo = parseInt(newFundDetailsModel.getMaxFundLimit());
                if(detailsArr.length < $scope.maximumFundNo){
                    $scope.showAddLink = true;
                }
            }
        });

        // Remove of key value grid tile
        $scope.$on('RemoveFund', function (event, resp) {
            $scope.noFundSelected = true;
            fundDetails.removeTile(resp.index);
            fundDetails.removeFundArr(resp.index);
             $timeout(function(){
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            $scope.$broadcast(transactEventConstants.transact.RESET_FUND);
             },0); 
            var detailsArr = fundDetails.getFundDetails();
            if(detailsArr.length > 0 && detailsArr.length < $scope.maximumFundNo){
                $scope.showAddLink = true;
            }else if(detailsArr.length <= 0){
               $scope.Change();
            }
            transactModel.setFundDetails(detailsArr);
            $scope.sameFundError = false;    
            $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
        });

        // +ADD MORE FUNDS link functionality
        $scope.Change = function() {
            $scope.noFundSelected = true;
            $scope.cancelAddFunds = true;
            $scope.$broadcast(transactEventConstants.transact.RESET_FUND);
            $scope.showAddDiv = false;
            $scope.showAddLink = false;
            $scope.showContinue = false;
            $scope.sameFund = false;
            $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
        }

        // for resetting the form on click of "Cancel"
        $scope.reset = function(selectFundForm) {
            $scope.cancelAddFunds = false;
            $scope.noFundSelected = true;
            $scope.$broadcast(transactEventConstants.transact.RESET_FUND);
            $scope.amountObject.value = "";
            $scope.showAddDiv = false;
            $scope.showAddLink = false;
            $scope.showContinue = false;
            $scope.sameFund = false;
            //var detailsArr = fundDetails.getFundDetails();
            var detailsArr = fundDetails.getFundDetails() || transactModel.getFundDetails();
            if(detailsArr.length > 0){
                if(detailsArr.length < parseInt($scope.maximumFundNo)){
                    $scope.showAddLink = true;
                }
                $scope.showContinue = true;
                $scope.showAddDiv = true;
            }
            $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
        }

        // save button
        $scope.getSelections = function() {
            $scope.noFundSelected = true;
            $scope.sameFundError = false;
            //var fundDetailsArrObj = fundDetails.getFundDetails();
            var fundDetailsArrObj = fundDetails.getFundDetails() || transactModel.getFundDetails();

            //Validating if the same fund is selected
            if(!($scope.isEditTile && angular.equals(fundDetails.getFundArr()[$scope.editIndex], $scope.destinationFund))){
                var fundDetailsArrObj = fundDetails.getFundArr();
                if(fundDetailsArrObj.length > 0){
                    angular.forEach(fundDetailsArrObj, function(value, key) {
                        if(angular.equals(fundDetailsArrObj[key], $scope.destinationFund)){
                            $scope.sameFundError = true;
                            $scope.sameFund = true;
                        };
                    });
                }
            }            

            if(!$scope.sameFundError){
                // To show popup When the Transact limit exceeds 50000/-
                $scope.showNotification = false;
                $scope.showKycDtlsNotif = false;              
                fundDetails.setSelectedFund($scope.destinationFund.fundName);
                fundDetails.setFundType($scope.destinationFund.fundType);
                fundDetails.setFundOption($scope.destinationFund.fundOption);
                fundDetails.setNfoFlag($scope.destinationFund.nfoFlag);
                fundDetails.setDirectFlag($scope.destinationFund.direct);
                if($scope.destinationFund.fundType === 'E'){
                    fundDetails.setAccNo($scope.destinationFund.accNo);
                }else if($scope.destinationFund.fundType === 'N'){
                    fundDetails.setAccNo("NEW");
                }
                
                if($scope.radios.modeSelectedDiv === "Re-Investment"){
                    fundDetails.setDividendFlag("R");
                }else if($scope.radios.modeSelectedDiv === "Payout"){
                    fundDetails.setDividendFlag("P");
                }else{
                   fundDetails.setDividendFlag($scope.destinationFund.dividendFlag); 
                }
                fundDetails.setTxnType($scope.destinationFund.txnType);
                fundDetails.setTotalAmount($scope.amountObject.value);
                fundDetails.setAmountType($scope.radios.modeSelectedDiv);
                fundDetails.setFundType($scope.destinationFund.fundType);

                $scope.fundData = {};
                $scope.fundData.fundType = fundDetails.getFundType();
                $scope.fundData.fundName = fundDetails.getSelectedFund();
                $scope.fundData.amount = fundDetails.getTotalAmount();
                $scope.fundData.dividend = fundDetails.getAmountType();
                $scope.fundData.fundOption = fundDetails.getFundOption();
                $scope.fundData.nfoFlag = fundDetails.getNfoFlag();
                $scope.fundData.direct = fundDetails.getDirectFlag();
                $scope.fundData.accNo = fundDetails.getAccNo();
                $scope.fundData.dividendFlag = fundDetails.getDividendFlag();
                $scope.fundData.txnType = fundDetails.getTxnType();
                $scope.fundData.fundCategory = $scope.destinationFund.fundCategory;

                if($scope.isEditTile){
                    fundDetails.removeTile($scope.editIndex);
                    fundDetails.removeFundArr($scope.editIndex);
                    $scope.isEditTile = false;
                    $scope.editIndex = null;
                }
                //Transaction limit validation, if any of the user is kyc-red through aadhar
                if($scope.isKycRegAadhar){

                    $scope.showNotification = false;
                    $scope.onFundLoad = false;
                    $scope.invocationPoint = 1;
                    setRequestObject();
                    
                }else{
                    saveInvstmentDetails();
                }
            }
            
        }

        function saveInvstmentDetails(){
            $scope.showContinue = true;
            fundDetails.setFundDetails($scope.fundData);
            fundDetails.setFundArr($scope.destinationFund);

            var fundDetailsObj =  fundDetails.getFundDetails();
            transactModel.setFundDetails(fundDetailsObj);

            // to display ADD MORE FUNDS Link
            if (fundDetailsObj.length >= $scope.maximumFundNo) {
                $scope.showAddLink = false;
                $scope.showAddDiv = true;
                $scope.showContinue = true;
            } else {
                $scope.showAddLink = true;
                $scope.showAddDiv = true;
            };
            $scope.selectedFund = "";
            $scope.amountObject.value = "";
            $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
        }

        function goNexttab() {
            $scope.showKycDtlsNotif = false;
            $scope.noFundSelected = true;
            var detailsArr = transactModel.getFundDetails(); 
           // var detailsArr = fundDetails.getFundDetails();
            /*if ($state.current.name === 'invTransact.base.buy' && authenticationService.isInvestorLoggedIn()){
            var detailsArr = transactModel.getFundDetails();  
            }  */       
            if(detailsArr.length > 0){
                var totalBuyAmount = detailsArr.map(function(item) {
                    return item.amount;
                });
                if(totalBuyAmount.length > 0) {
                    var existingTotalAmount = totalBuyAmount.reduce(function(prev, curr) {
                        return prev + curr;
                    });
                    fundDetails.setBuyTotalAmount(existingTotalAmount);
                };
                transactModel.setTransactType(TransactConstant.buy.BUY);


                if ($scope.isKycRegAadhar || transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
                    $scope.onFundLoad = false;
                    $scope.invocationPoint = 2;
                    setRequestObject();
                }else{
                    $scope.$emit(transactEventConstants.transact.Show_Fund);
                    $scope.$emit("paymntDtls");
                    if ($scope.isPaperLess) {
                        redirectToPaymentDtls();
                    }
                }
            }else{
                $scope.noFundSelected = false;
            }
        }

        if($stateParams.key == "Folio" || $stateParams.key == "investorPreference"){
            $stateParams.key = TransactConstant.transact.Fund_Key;
        }

        // $scope.isValid = false;
        /*$scope.continue = function() {
            // $scope.shownPopup = false;
            $scope.sameFund = false;    
            isDataChanged = true;        
            if($stateParams.key === TransactConstant.transact.Fund_Key || transactModel.fundDetailsEditClicked || paperlessModel.fundDtls.hasData){
                transactModel.fundDetailsEditClicked = false;
                var result = _.isEqual(angular.copy(transactModel.getFundDetails()), angular.copy($scope.previousData));
                if (!result) {
                    $scope.configDataLost.showNotification = true;
                    var destroyHandler =  $scope.$on('yes', function () {
                        $scope.configDataLost.showNotification = false;
                        transactModel.showPaymentDtlsOnNo = false;
                        $scope.$emit("ChangePayment");
                        goNexttab();
                        destroyHandler();
                      });

                      $scope.$on('no', function () {
                        isDataChanged = false;
                        $scope.configDataLost.showNotification = false;
                      });
                } else {
                    transactModel.showPaymentDtlsOnNo = true;
                    isDataChanged = false;
                    goNexttab();
                }
            } else {
               goNexttab();
            }           
        }*/

        if($stateParams.key == "Folio" || $stateParams.key == "investorPreference"){
            $stateParams.key = TransactConstant.transact.Fund_Key;
        }

        $scope.continue = function() {
            $scope.shownPopup = false;
            $scope.sameFund = false;
            // var fundData = fundDetails.getFundDetails();
            if($stateParams.key === TransactConstant.transact.Fund_Key || transactModel.fundDetailsEditClicked || paperlessModel.fundDtls.hasData){
                transactModel.fundDetailsEditClicked = false;
                var result = _.isEqual(angular.copy(transactModel.getFundDetails()), $scope.previousData);
                    if (!result) {
                        $scope.isValid = false;
                        $scope.configDataLost.showNotification = true;
                        $scope.shownPopup = true;
                        var destroyHandler =  $scope.$on('yes', function () {
                            $scope.configDataLost.showNotification = false;
                            transactModel.showPaymentDtlsOnNo = false;
                            $scope.shownPopup = false;
                            $scope.isValid = goNexttab();
                            redirectToPaymentDtls(!($scope.isValid));
                            destroyHandler();
                          });

                          $scope.$on('no', function () {
                            $scope.isValid = true;
                            $scope.shownPopup = false;
                            $scope.configDataLost.showNotification = false;
                          });
                    }
                    else{
                            transactModel.showPaymentDtlsOnNo = true;
                            $scope.isValid = goNexttab();
                        }
            }else{
                    $scope.isValid = goNexttab();
                }
            // return $scope.isValid;
            if($scope.shownPopup){
                return true;
            }else{
                return $scope.isValid;
            }
        }

        //Paperless : BUY Continue clicked
        $scope.$on(eventConstants.PAPERLESS_CONTINUE_CLICKED, function (event){
            $scope.continue();
        });

        //Paperless : If form  valid
        function redirectToPaymentDtls(){
            paperlessModel.fundDtls.hasData = true;  
            if(!isDataChanged && paperlessModel.paymentDtls.hasData){
                paperlessModel.paymentDtls.hasData = true;
            }else{
                paperlessModel.paymentDtls.hasData = false;
            }            
            $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
        }
    }]
};
};

selectFund.$inject = ['$uibModal', '$filter', 'TransactConstant', 'newFundDetailsModel', 'newFundDetailsInitialLoader', 'selectFundModel', 'selectFundInitialLoader', 'transactEventConstants', '$timeout', 'fundDetails', 'transactModel', '$stateParams', 'paperlessModel', 'eventConstants', 'configUrlModel', '$window', 'appConfig', '$cookies', 'checkKycModelService', 'toaster', 'fundDetailsModel', '$state', 'authenticationService'];
module.exports = selectFund;