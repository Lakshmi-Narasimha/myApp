// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var InvPersonalInfoSchema = new mongoose.Schema({
    myProfileObject: {
        type: Object,
        "default": {}
    }
});

var InvPersonalInfoLookUp = mongoose.model('InvPersonalInfoLookup', InvPersonalInfoSchema);

var InvPersonalInfoModel = new InvPersonalInfoLookUp({



  // "myProfileObject": {
  //   "personalInfo": {
  //     "name": "AASHISH SADANAND NARKAR NARYAN SHANTA",
  //     "pan": "CGLQS6277F",
  //     "mobile": "4566081093",
  //     "phoneNo": " ",
  //     "emailId": " ",
  //     "kycStatus": "KYC - Registered",
  //     "dob": "1993-12-05 00:00:00.0",
  //     "address1": "OLD NO.21 NE NO.6",
  //     "address2": "H NO 35 BHOPAL 462016",
  //     "address3": "NR SATTADHAR BUS STOP ",
  //     "address4": "SANICHARA",
  //     "city": "DUBAI 16062008",
  //     "country": "INDIA",
  //     "nationality": "INDIAN",
  //     "socialStatus": "Individual",
  //     "aadharNo": " ",
  //     "doi": ""
  //   }
  // }


  'myProfileObject': {
      'personalInfo':{
        'name':'Shankar Narayan',
        'pan': 'AABPL1234K',
        'mobile': '+91 9867091787',
        'emailId': 'shankarn@abc.com',
        'aadharNo': '8888777676',        
        //'officeAddress': '13/B, Hill View, J.K. Synthia Road, Chennai - 300088',
        'kycStatus': 'KYC - Registered',
        'address1': 'OLD NO.21 NE NO.6',
        'address2': 'H NO 35 BHOPAL 462016',
        'address3': 'NR SATTADHAR BUS STOP ',
        'address4': 'SANICHARA',
        'city': 'DUBAI 16062008',
        'country': 'INDIA',
        'nationality': 'INDIAN'        
      }
    }

});

InvPersonalInfoLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating PersonalInfoLookUp table, please contact admin...');
    } else {
        InvPersonalInfoLookUp.remove({}, function(err) {
            console.log('PersonalInfoLookUp collection removed');
            InvPersonalInfoModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PersonalInfoLookUp table, please contact admin...');
                }
                console.log('PersonalInfoLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvPersonalInfoLookUp;
