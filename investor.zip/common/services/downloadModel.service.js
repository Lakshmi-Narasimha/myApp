/**
 * @ngdoc property
 * @name downloadModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - downloadModel is a service model which downloads the respective report.
 *
 **/
'use strict';


var downloadModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, appConfig, $http, authenticationService, $state) {   
    var queryParams = {};
	var downloadReport = {
        downloadReportService : function (queryObj, restUrl) {
            var deferred = $q.defer();
           // var end = '';
            var reportName = null;
            var params = {};
            var d = new Date();
            var month = new Array();
            month[0] = "Jan";
            month[1] = "Feb";
            month[2] = "Mar";
            month[3] = "Apr";
            month[4] = "May";
            month[5] = "June";
            month[6] = "July";
            month[7] = "Aug";
            month[8] = "Sep";
            month[9] = "Oct";
            month[10] = "Nov";
            month[11] = "Dec";
            var n = month[d.getMonth()];
            params.dtfmonth = n;
            params.dtfyear = d.getFullYear();
            if($state.current.name === "salesoverview"){
                reportName = "SOV";
            }else if($state.current.name === "portfolio.mb"){
                reportName = "MBOV";
            }
            else if($state.current.name === "portfolio.lb"){
                reportName = "LB";
            }
            else if($state.current.name === "portfolio.sb"){
                reportName = "SIPB";
            }
            else if($state.current.name === "portfolio.id"){
                reportName = "ID";
            }else if($state.current.name === 'eforms.eformstab'){
                reportName = "";
            }
            params.reportName = reportName;
            params.guId = authenticationService.getUser().guId;
// <<<<<<< HEAD
//             end = 'services/download';*/
//             queryObj.guId = authenticationService.getUser().guId;
//             Restangular.one(restUrl).get(queryObj).then(function (downloadDetails) {
// =======
            //end = 'services/download';
            Restangular.one(restUrl).get(params).then(function (downloadDetails) {
                deferred.resolve(downloadDetails);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        setQueryparams: function(params){
            queryParams = params;
        },
        getQueryparams: function(){
            return queryParams;
        }

    };

    return downloadReport;

};

downloadModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'appConfig', '$http', 'authenticationService', '$state'];
module.exports = downloadModel;
