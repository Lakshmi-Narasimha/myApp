'use strict';
var fticUnclaimedAndDividendHisAmount = function(investorEventConstants, investorDashboardDetailsModel, loggerConstants, fticLoggerMessage) {
    return {
        template: require('./unclaimedAndDividendHisAmount.html'),
        restrict: 'E',
        replace: 'true',
        scope: true,
        controller: function($scope) {
            $scope.$on(investorEventConstants.Dashboard.INV_DB_INFO, function() {

                var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_UNCLIAMED_AND_DIV_HIS_AMT_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_INFO + ' event' /* Function Name */; 
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
                $scope.unclaimedAmount = investorDashboardDetailsModel.getDashboardData().unclaimedAmount;
                $scope.dividendHisAmount = investorDashboardDetailsModel.getDashboardData().dividendHistory;
            });
        }
    };
};
fticUnclaimedAndDividendHisAmount.$inject = ['investorEventConstants', 'investorDashboardDetailsModel', 'loggerConstants', 'fticLoggerMessage'];
module.exports = fticUnclaimedAndDividendHisAmount;
