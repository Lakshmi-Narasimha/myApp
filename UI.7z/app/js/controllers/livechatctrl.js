module.exports = function($scope, $sce, $window, $timeout, chatServices, chatUtils) {
    var endChatWindow = null;
    $scope.chatLineMsgs = [];
    $scope.viewModel = {
        isAgentTyping: false,
        viewAgentWarnMSg: '',
        isFirstReq: true
    };
    $scope.isTyping = [];
    $scope.userQuery = {
        name: 'John Doe',
        messageText: '',
        chatTime: new Date(),
        isUser: true,
        image: '././assets/customer.png'
    };
    $scope.faq = {
        title: "FAQ's",
        isOpen: false,
        content: 'faqSuggestions.html',
        suggestions: []
    };
    $scope.openWindow = function() {
        if (endChatWindow) {
            endChatWindow.close();
        }
        endChatWindow = $window.open('#/endchat', 'end-chat', 'toolbar=0,status=1,width=1100,height=700,left=10%,top=10%', "_blank");
    };
    $scope.showFaqs = function() {
        var text = $scope.userQuery.messageText || '';
        if (text && text.length > 2) {
            chatServices.getTypeSearchSupport().then(function(data) {
                $scope.faq.isOpen = data ? true : false;
                $scope.faq.suggestions = data ? data.ModuleMap.TypeSearchSupport.TypeAhead : [];
            }, function(err) {
                $scope.faq.suggestions = [];
                $scope.faq.isOpen = false;
            });
        } else {
            $scope.faq.isOpen = false;
            $scope.faq.suggestions = [];
        }

    };

    $scope.onSelectFaq = function(linkText) {
        $scope.faq.isOpen = false;
        $scope.userQuery.messageText = linkText;
        $scope.sendQuery();
    };

    var searchCallback = function(data) {
        console.log(data);
    };

    var supportCallback = function(data) {
        console.log(data);
    };

    $scope.sendQuery = function() {
        if ($scope.viewModel.isFirstReq) {
            $scope.viewModel.isFirstReq = false;
            chatUtils.callInitServices(searchCallback, supportCallback);
        }

        var query = {
            "RequestParams": {
                "value": $scope.userQuery.messageText
            }
        };

        $scope.userQuery.chatTime = new Date();
        $scope.chatLineMsgs.push(angular.copy($scope.userQuery));
        $scope.userQuery.messageText = '';
        $scope.viewModel.isAgentTyping = true;
        $scope.isTyping.push($scope.viewModel);

        $timeout(function() {
            chatServices.search(query).then(function(data) {
                $scope.viewModel.isAgentTyping = false;
                var agentReply = data.ModuleMap.Support.msgList[0].messageList[0];
                agentReply.name = 'Lucy Doe';
                agentReply.chatTime = new Date();
                agentReply.image = '././assets/contactus.png';
                agentReply.messageText = "<a ng-click='openWindow()'> open window</a>";
                $scope.chatLineMsgs.push(agentReply);
                console.log(agentReply.content);
            }, function(err) {
                console.log(err);
            });
        }, 3000);
    };

};
