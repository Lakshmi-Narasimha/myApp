define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appcommon/constants',
  'services/dataservice',
  'appcommon/globalcontext',
  'appcommon/commonutility',
  'appmodules/crm/app/models/smarpadcollection',
  'moment',
  'appmodules/crm/crmvalidate',
  'text!appmodules/crm/app/templates/editsmartpad.html',
  'appcommon/analytics',
  'errorLog',
  'appcommon/globalcontext',
  'appcommon/constants',
  'apipublic/navapi'
], function ($, _, Backbone, Spinner, Constants, Dataservice, GlobalContext, CommonUtilis, SmartPadModel, Moment, Validator, EditsmartpadTemplate, Analytics, ErrorLog, GlobalContext, Constants, NavApi) {
	var smartPad = {},serviceCounter = 1,self;
    var editsmartpadview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
        'click #smedit-save-button':'updateSmartPad',
        'click #smedit-cancel-button':'handleCancel',
        'click #goto-smartpad-list':'handleBacktoSmartpadListClick'
        },
        datePickerPosition: function (e) {
            if ($.datepicker._datepickerShowing) {
                var datepicker = $.datepicker._curInst;
                dpInput = datepicker.input;
                dpEle = datepicker.dpDiv;
                dpEle.position({ my: 'left top', of: dpInput, at: 'left bottom' });

            }
        },

        initDatePicker: function (e) {
            var view = this;
            var dt = new Date();
            var minutes = moment().minutes();
            var seconds = moment().seconds();
            var hrs = moment().hours();

            $("#editnote-date").datepicker({
                showOn: "button",
                buttonImage: "images/cal-icon.png",
                buttonImageOnly: true,
                buttonText: "Select date"
            });
            $("#editnote-date").datepicker("setDate", dt);
            $("#ui-datepicker-div").addClass("myclassdoesntgo");
            this.datePickerPosition();
            //$.extend($.datepicker, { _checkOffset: function (inst, offset, isFixed) { return offset } });
        },

        initialize: function () {
            self = this;
            $(window).on('resize orientationchange', this.datePickerPosition);
        },

        render: function (options) {
        	 Spinner.show();
        	smartPad = {};
        	serviceCounter = 1;
            var _self = this;
        	this.fmId = options.fmId;

        	var pageHistory = Backbone.history.list.slice(-1)[0];
        	this.referer = pageHistory;
        	if (pageHistory.indexOf("contactprofile/") !== -1) {
        		_self.backContext = "Profile"
        	} else { //defaults for sanity purposes
        		_self.backContext = "SmartPad List"
        	}

            var compiledTemplate = _.template(EditsmartpadTemplate);
            this.$el.html(compiledTemplate({ backContext: _self.backContext}));
            this.initDatePicker();
            /*if (options.selectedContactType == Constants.contactType.NonClient) {
            	serviceCounter = 3;
             	contactId = options.selectedContactId;
            	Dataservice.getContactDetailsbyContactId(CommonUtilis.readCookie('FMID'), options.selectedContactId)
                .then(gotoContactSuccessCall).fail(gotoError);
             	//$('.sm-group-cont').hide();
             }else{
             	serviceCounter = 3;
             	contactId = options.selectedContactId;
                 Dataservice.getContactDetailsbyClientId(CommonUtilis.readCookie('FMID'), options.selectedContactId)
                   .then(gotoContactSuccessCall).fail(gotoError);
             
             }*/
            this.smartPadId = options.smartPadId;
            //call the smartpad detail service
        	Dataservice.getSmartPadDetails(CommonUtilis.readCookie('FMID'), options.smartPadId)
        	.then(smartpadDetailsGetSuccess).fail(function(Error){
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(Error);
        	});
        	function smartpadDetailsGetSuccess(response){
        	
        		//Dataservice.getHouseHoldGroup(CommonUtilis.readCookie('FMID'), options.selectedContactId).then(gotoHouseHoldGroupSuccess).fail(gotoError);
        		if(response){
        			smartPad = response[0].toJSON();

        		}
        		serviceCounter--;
        		  _self.populateSmartPadDetails();	
        	}
        	
             function gotoContactSuccessCall(contctDetails) {
            	 serviceCounter--;
                 var pinnedId = contctDetails[0].get("contactId");
                 /*if (pinnedId != undefined) {
                    // that.contactId = pinnedId;
                     Dataservice.getHouseHoldGroup(CommonUtilis.readCookie('FMID'), pinnedId).then(gotoHouseHoldGroupSuccess).fail(gotoError);
                     function gotoHouseHoldGroupSuccess(HouseHoldGroups) {
                         var houseHoldGroupOptions = "";
                         if (HouseHoldGroups[0] != null && HouseHoldGroups[0].attributes.HouseHoldGroupList != undefined) {
                        	 var _houholdGrps = HouseHoldGroups[0].get('HouseHoldGroupList');
                         	if(_houholdGrps.length < 1 ){
                         		 $(".sm-group-cont").hide();
                         	}else {
                         		$.each(HouseHoldGroups[0].attributes.HouseHoldGroupList, function (key, value) {
                                    houseHoldGroupOptions += "<option value=" + value.get('householdId') + ">" + value.get('householdName') + "</option>";
                                    });
                                $('#editnote-group-val').html(houseHoldGroupOptions);
                                houseHoldGroupOptions = null;
                         	}
                             
                            
                         }
                         else {
                             $(".sm-group-cont").hide();
                         }
                         serviceCounter--;
                         _self.populateSmartPadDetails();  
                     }
                 }
                 else {
                	 serviceCounter--;
                	 _self.populateSmartPadDetails();
                     alert("Pinned contact doesn't exist in Ebix system")
                 }*/
                 _self.populateSmartPadDetails();

             }
            function gotoError(Error) {
            	Spinner.hide();
            };
        },
        populateSmartPadDetails:function(){
        	
         	if(serviceCounter == 0){
             	Spinner.hide();
         	    var _memoDate = smartPad.MemoDate,
         	        _pinnedContactDisplayInfo = smartPad.ContactFirstName ? (smartPad.ContactFirstName + " " + smartPad.ContactLastName) : smartPad.ContactLastName;
             	var _localTime  = moment(_memoDate).format('YYYY-MM-DD HH:mm:ss');
                _localTime = moment(moment.utc(_localTime).toDate());
                var _min = _localTime.format('mm'), _minIntrvl = 15;
                var _minDiff = _min % _minIntrvl, _$minDiv = $('#editnote-min');
                if(_minDiff != 0){
                	var _newOption = '<option value="'+_min+'">'+_min+'</option>';
                	//_localTime.add('minutes',(_minIntrvl - _minDiff));
                	_$minDiv.prepend(_newOption)
                }
               // _localTime =  _localTime.format('MM/DD/YYYY HH:mm');
             	var _hh = _localTime.format('hh'),  _ampPm = _localTime.format('A');
             	_min = _localTime.format('mm');
             	$("#editnote-date").datepicker( "setDate", _localTime.format('MM/DD/YYYY'));
             	$('#editnote-hr').val(_hh);
             	_$minDiv.val(_min);
             	$('#editnote-ampm').val(_ampPm);
             	if(smartPad.HouseholdId == null || !smartPad.HouseholdId || smartPad.HouseholdId == undefined){
             		$('.sm-group-cont').hide();
             	}else{
             		//$('#editnote-group-val').html('<option>'+smartPad.HouseholdName+'<option>');
             		$('#editnote-group-val').html(smartPad.HouseholdName);
             		$('#editnote-group-val').attr('data-id',smartPad.HouseholdId);
             	}
             	
             	//$("#editnote-private option").removeAttr('selected');
             	$('#editnote-private-select').val(smartPad.Private);
             	$('#editnote-text-area').html(smartPad.Note);
             	$("#smartpad-client-info").text(_pinnedContactDisplayInfo);
         	    //$('#editnote-group-val').val(smartPad.HouseholdId);
             	
             }
        },
        updateSmartPad:function(){
        	 if (Validator.validateInputs('edit-smartpad-form')) {
        		 Spinner.show();
             	var _self = this;
             	var smdate = moment($("#editnote-date").datepicker('getDate')).format('YYYY/MM/DD');
                 var smtime = $("#editnote-hr option:selected").val() + ":" + $("#editnote-min option:selected").val() + " " + $("#editnote-ampm option:selected").val();
             	 var updatedSmartPad = {};
             	 updatedSmartPad['MemoDate'] = Moment.utc(smdate + " " + smtime).format('YYYY-MM-DD HH:mm:ss');
             	 //updatedSmartPad['HouseholdId'] = $("#editnote-group-val option:selected").val();
             	 updatedSmartPad['HouseholdId'] = $("#editnote-group-val").attr('data-id');
             	 updatedSmartPad['Private'] = $("#editnote-private-select option:selected").val();
             	 updatedSmartPad['Note'] = $("#editnote-text-area").html();
             	 updatedSmartPad['ContactId'] = this.contactId;
             	 updatedSmartPad['SmartPadId'] = this.smartPadId;
                 Dataservice.updateSmartPad(CommonUtilis.readCookie('FMID'), updatedSmartPad).then(gotoUpdateSmartPadSuccess).fail(gotoError);
        	 }
        	
             function gotoUpdateSmartPadSuccess(smartpad) {
            	 Analytics.analytics.recordAction('CrmEditSmartPadNoteSave:clicked');
            	 Spinner.hide();
                 var url = "crm/notedetail/"+_self.smartPadId;
             	 Backbone.history.navigate(url, true);
             };
             function gotoError(Error){
            	 Spinner.hide();
            	 ErrorLog.ErrorUtils.myError(Error);
             
             }
        },
        handleBacktoSmartpadListClick: function () {
        	this.handleSmartPadCancel(null);
        },
        handleCancel: function () {
        	this.handleSmartPadCancel(null);
        },
        handleSmartPadCancel: function (analyticAction) {
        	var self = this;
        	BootstrapDialog
                .confirm(
                "Cancel",
                "All your work will be lost.  Are you sure you want to continue?",
                function (confirm) {
                	if (confirm) {
                		self.goToReferer();
                	};
                });
        },
        goToReferer: function () {
            var _referer = self.referer;
        	switch (_referer) {
        		case 'contactprofile/':
        		case 'contactprofile/beneficiary':
        		case 'contactprofile/bank':
        		case 'contactprofile/ira':
        		case 'contactprofile/fiduciary':
        		case 'contactprofile/preferences':
        		case 'contactprofile/contributions':
        		case 'contactprofile/distributions':
        			location.hash = _referer;
        			break;
        		default:
        			location.hash = 'crm/smartpad';
        	}
        }

       /* handleCancel:function(){
        	var _self = this;
			BootstrapDialog
					.confirm(
							"Cancel",
							"All your work will be lost.  Are you sure you want to cancel?",
							function(confirm) {
								if (confirm) {
									Analytics.analytics.recordAction('CrmEditSmartPadNoteCancel:clicked');
									location.hash="crm/notedetail/"+_self.smartPadId;
								}

							}, 'edit-smartpad');
		
        },*/
       /* handleBacktoSmartpadListClick: function(){
			BootstrapDialog
					.confirm(
							"Cancel",
							"All your work will be lost.  Are you sure you want to continue?",
							function(confirm) {
								if (confirm) {
									location.hash="crm/smartpad";
								}

							}, 'edit-smartpad');
		
        
        }*/
    });
    return editsmartpadview;
});
