/**
 * @ngdoc property
 * @name fticSipCalculatorForm Directive
 * @description
 *
 * fticSipCalculatorForm directive 
 *
 **/
 'use strict';

 var fticTaxCalculatorForm = function($state,$timeout,eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, taxCalculatorInitialService, taxCalculatorModel, calculatorsEventConstants) {
     return {
        template: require('./taxCalculatorsForm.html'),
        restrict: 'E',
        replace: true,
        scope:{
            inputObject:'=',
            selectOptions:'=',
            userInput:'=',
        },
        controller:['$scope', function($scope){
            $scope.amountValue = function(){
                $scope.taxCalculatorForm.$submitted = false;
            };            
            $scope.init = function() {
              
             $scope.calculatorReq={};
             $scope.fundName = [];
           $scope.reload = true;
             $scope.formInvalid = true;
             $scope.$on('selectedFund', function(event, data){    
                $scope.taxCalculatorForm.$submitted = false;                
                $scope.fundName.title = data.title;
                $scope.fundName.code = data.category;
            });


             $scope.onSubmit = function() {
                $scope.$emit(calculatorsEventConstants.RESET_DATA);
                $scope.tenureErrorvalue = parseInt($scope.userInput.Tenure.value);
                if($scope.userInput.Amount.value < 500 || $scope.userInput.Amount.value > 999999999 || $scope.userInput.Tenure.value > 40 || $scope.userInput.Tenure.value < 1) {
                    return;
                }else if (!$scope.checkWholeNumPattern($scope.userInput.Tenure.value) || !$scope.checkWholeNumPattern($scope.userInput.Amount.value) ){
                        return;
                }else {
                    $scope.calculatorReq = [{'investmentTenure' : $scope.userInput.Tenure.value,
                    'investmentAmount' : $scope.userInput.Amount.value,
                    'fundName' : $scope.fundName.code
                }];
               // $scope.calculatorReq.annualizedReturn= $scope.userInput.Annual.value;            
               $scope.$emit(calculatorsEventConstants.TAX_CALCULATE, $scope.calculatorReq);
           }
       };

       $scope.resetForm = function () {
        $scope.$emit(calculatorsEventConstants.RESET_DATA);
        $scope.reload = false;
        $timeout(function () {
            $scope.reload = true;
            $scope.calculatorReq = {};
            $scope.fundName.code = '';
            $scope.userInput.Tenure.value = '';
            $scope.userInput.Amount.value = '';
            $scope.tenureErrorvalue = $scope.userInput.Tenure.value;
        }, 0);
    };      
    $scope.checkWholeNumPattern = function(field){
                var patt = /^[0-9]*$/;
                // var result = patt.test($scope.userInput.Tenure.value);
                var result = patt.test(field);                
                return result;
    };
    $scope.inputChanged = function(data){
        $scope.taxCalculatorForm.$submitted = false;
        $scope.tenureErrorvalue = parseInt(data.value);
    };    

};
$scope.init();
$scope.formInvalid = true;
}]
};
};

fticTaxCalculatorForm.$inject = ['$state','$timeout','eventConstants','fticLoggerMessage', 'loggerConstants', '$cookies','authenticationService','taxCalculatorInitialService','taxCalculatorModel', 'calculatorsEventConstants'];
module.exports = fticTaxCalculatorForm;