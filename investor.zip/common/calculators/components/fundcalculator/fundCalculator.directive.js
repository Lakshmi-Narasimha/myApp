/**
 * @ngdoc property
 * @name Fund Calculators Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Displays the Fund calculator options fot sip, lumpsum.
 *
 **/
'use strict';


var fticFundCalculator = function(fticLoggerMessage, loggerConstants) { 
  return {
    template: require('./fundCalculator.html'),
    restrict: 'E',
    replace: true,
    scope: {},
    controller: function($scope, $element, $attrs){
    },            
    link: function(scope, iElement, iAttrs, controller){

    }     
  };

};
fticFundCalculator.$inject = ['fticLoggerMessage', 'loggerConstants'];
module.exports = fticFundCalculator;   