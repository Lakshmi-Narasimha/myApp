angular.module('CSS.commonconstants', []).constant('errorDefaultConstant', {
    fileNotFound: {
        "policy": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        "billing": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        "policyAndBilling": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        // "defaultMessage": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        "defaultMessage": "We weren't able to process your request. Please try again. If you still need help, contact Farmers Consumer Solutions at 1-877-327-6392"

    },
    internalServerError: {
        "policy": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        "billing": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        "policyAndBilling": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157.",
        // "defaultMessage": "An error has occurred while requesting the data. Please try refreshing the page or call us at 1-855-878-3157."
        "defaultMessage": "We weren't able to process your request. Please try again. If you still need help, contact Farmers Consumer Solutions at 1-877-327-6392"
    },
    defaultTitleMessage: 'We were unable to locate your account.',
    noData:"No data available",
    billingMaintenanceTitleMsg: "One-time payment is not available"
});
