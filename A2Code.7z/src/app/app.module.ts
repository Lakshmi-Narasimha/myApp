import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ApplicationRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Ng2BootstrapModule, ButtonsModule, ModalModule, PaginationModule } from 'ng2-bootstrap';
import { SelectModule } from 'ng2-select/ng2-select';
import { ModalOptions } from 'ng2-bootstrap/ng2-bootstrap';
import { TabsModule } from 'ng2-bootstrap/ng2-bootstrap';
import { DragulaModule, DragulaService } from 'ng2-dragula/ng2-dragula';

import { AppComponent } from './app.component';
import { NavcomponentComponent } from './navcomponent/navcomponent.component';
import { AgentcomponentComponent } from './agentcomponent/agentcomponent.component';
import { IntentgroupcomponentComponent } from './intentgroupcomponent/intentgroupcomponent.component';
import { IntentdatacomponentComponent } from './intentdatacomponent/intentdatacomponent.component';
import { IntentusersaysComponent } from './intentusersays/intentusersays.component';
//import { IntentparameterComponent } from './intentparameter/intentparameter.component';
import { ResponseComponent } from './response/response.component';
import { EditabletableComponent } from './editabletable/editabletable.component';

import { AIAssistRestService  } from './_services/aiassistrest.service';
import { AIAssistCacheService  } from './_services/aiassistcache.service';
import { AIAssistAlertService } from './_services/aialert.service';
import { AuthenticationService } from './_services/authentication.service';
import { AuthGuard } from './_guards/auth.guard';
import { SearchPipe } from './_helpers/search.pipe';
import { BaseRequestOptions } from '@angular/http';
import { routes } from './app.router';
import { PublishComponent } from './publish/publish.component';
import { ChatbotEditorComponent } from './chatbot-editor/chatbot-editor.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { ParameditorComponent } from './parameditor/parameditor.component';
import { SearchComponent } from './search/search.component';
import { ShardaComponent } from './sharda/sharda.component';

@NgModule({
  declarations: [
    AppComponent,
    NavcomponentComponent,
    AgentcomponentComponent,
    IntentgroupcomponentComponent,
    IntentdatacomponentComponent,
    IntentusersaysComponent,
    //IntentparameterComponent,
    ResponseComponent,
    EditabletableComponent,
    SearchPipe,
    PublishComponent,
    ChatbotEditorComponent,
    LoginComponent,
    HomeComponent,
    LogoutComponent,
    ParameditorComponent,
    SearchComponent,
    ShardaComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpModule,
    Ng2BootstrapModule,
    SelectModule,
    ButtonsModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot(),
    DragulaModule,
    routes
  ],
  providers: [
    AIAssistRestService,
    AIAssistCacheService,
    AIAssistAlertService,
    AuthenticationService,
    AuthGuard,
    DragulaService,
    BaseRequestOptions
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
