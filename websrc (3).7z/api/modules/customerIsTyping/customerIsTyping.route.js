var express = require('express');
var https = require('https');
var querystring = require('querystring');
//var logger = require('../../../config/logger');

var router = express.Router();
var customerIsTypingModel = require('./customerIsTyping.model');

// api route
router.route('/mfchat/rest/customerIsTyping')
    .post(function(req, res) {
        //logger.access.info(req.body);
        req.uri = customerIsTypingModel.createRequestUri;
        var post_data = req.body.RequestParams;
        //console.log(post_data);
        //req.query = req.body.RequestParams.InitialMessage;
        var postBody = querystring.stringify(post_data);
        //console.log(postBody);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'POST',
                path: req.uri.path,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Cookie': req.sessionCookie,
                    'Content-Length': Buffer.byteLength(postBody)
                },
                rejectUnauthorized: true
            },

            function(proxyResponse) {
                //console.log("statusCode: ", proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                    res.status(200).end();
                } else {
                  //  //logger.error.error({
                  //      statusCode: proxyResponse.statusCode,
                  //      message: 'Something went wrong while retrieving data.'
                  //  });
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {
                  err.message = 'ERROR!!! Something went wrong while retrieving data.';
                  res.send(err);
                  //logger.error.error(err);
                });
            });
        // console.log(proxyRequest);
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
