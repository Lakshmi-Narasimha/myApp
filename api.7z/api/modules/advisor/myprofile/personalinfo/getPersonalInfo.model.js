// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PersonalInfoSchema = new mongoose.Schema({
    personalInfoObject: {
        type: Object,
        "default": {}
    }
});

var PersonalInfoLookUp = mongoose.model('PersonalInfoLookup', PersonalInfoSchema);

var PersonalInfoModel = new PersonalInfoLookUp({

  "personalInfoObject": {
      "personalinfo":{
        "ARNCode": "1267891AB9",
        "ARNRegdate": "12 Feb 2011",
        "KYDStatus": "Yes",
        "Primaryemail": "vikram.b@abc.com",
        "pan": "AABPL1234K",
        "Mobile": "+91 9867091787",
        "Bankdetails": "ICICI Bank -3560091871",
        "Officeaddress": "13/B, Hill View, J.K. Synthia Road, Chennai - 300088"
      },
      "cocdetails": [
        {
          "startdate": "01 April 2015",
          "enddate": "31 Mar 2016",
          "codeofconduct": "No"
        },
        {
          "startdate": "01 April 2014",
          "enddate": "31 Mar 2015",
          "codeofconduct": "Yes"
        },
        {
          "startdate": "01 April 2013 ",
          "enddate": "31 Mar 2014",
          "codeofconduct": "Yes"
        },
        {
          "startdate": "01 April 2012",
          "enddate": "31 Mar 2013",
          "codeofconduct": "No"
        }
      ]
    }

});

PersonalInfoLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PersonalInfoLookUp table, please contact admin...');
    } else {
        PersonalInfoLookUp.remove({}, function(err) {
            console.log('PersonalInfoLookUp collection removed');
            PersonalInfoModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PersonalInfoLookUp table, please contact admin...');
                }
                console.log('PersonalInfoLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PersonalInfoLookUp;
