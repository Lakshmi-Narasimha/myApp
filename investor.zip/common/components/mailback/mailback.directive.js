'use strict';

var mailback = function(mailBackPostService, events) {
	return {
            template: require('./mailback.html'),
            restrict: 'E',
            replace: true,
            scope: {
                placement : '@?',
                mailBackOptions : '=?',
                reportCode:'=?',
                moduleName:'@?'
            },
            controller: function($scope, $element, $attrs){   

                $scope.showPDF = true;
                $scope.showExcel = true;

                if ($scope.mailBackOptions && $scope.mailBackOptions.mailBackType) {

                    $scope.showExcel = $scope.showPDF = false;

                    if($scope.mailBackOptions.mailBackType === "excel" || $scope.mailBackOptions.mailBackType === "EXCEL") {

                        $scope.showExcel = true;

                    } else if ($scope.mailBackOptions.mailBackType === "pdf" || $scope.mailBackOptions.mailBackType === "PDF") {

                        $scope.showPDF = true;

                    }
                }  
                if($scope.reportCode == undefined) {
                    $scope.reportCode = " ";
                }    
                          
                
            },
            link: function(scope){
                scope.mailback = function(type,rc){
                    if(scope.moduleName === 'Investor') {
                        var data = {};
                        data.reportCode = rc;
                        data.type = type;
                        events.emitMailbackClick(scope, data);
                    }else {
                        mailBackPostService.postMailBackDetails(type,rc);
                    }
                };   
            }
        };
};

mailback.$inject = ['mailBackPostService', 'events'];
module.exports = mailback;