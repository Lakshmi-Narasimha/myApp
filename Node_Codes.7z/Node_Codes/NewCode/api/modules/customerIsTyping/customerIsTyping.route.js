var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var customerIsTypingModel = require('./customerIsTyping.model');
var proxy = require('../../../config/proxy')
// api route
router.route('/mfchatnode/rest/customerIsTyping')
    .post(function(req, res) {
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.uri = customerIsTypingModel.createRequestUri;
        var post_data = req.body.RequestParams || {};
        var postBody = querystring.stringify(post_data);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.session.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };

        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatOutBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
            // if (proxyResponse.statusCode === 200) {
            //     logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
            //     res.send(customerIsTypingModel.response);
            // } else {
            //    var errObj = {
            //         message: proxyResponse.statusMessage,
            //         statusCode: proxyResponse.statusCode
            //     };
            //     logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            //     logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
            //     res.send(errObj);
            // }
            logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
            res.send(customerIsTypingModel.response);

            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(customerIsTypingModel.response);
            });
        });
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
