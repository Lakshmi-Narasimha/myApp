// modSip.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ModifySipModelSchema = new mongoose.Schema({
    ModifySipResp: {
        type: Object,
        "default": {}
    }
});

var ModifySipModelLookUp = mongoose.model('ModifySipModelLookUp', ModifySipModelSchema);

var ModifySipModel = new ModifySipModelLookUp({
    ModifySipResp : {
  "retrieveSip": [{
    "accountNumber": "2019904729556",
    "achAmount": "5000",
    "achDebitType": "F",
    "achFrequency": "",
    "achFromDate": "",
    "achToDate": "",
    "additionalFundCode": "Franklin India FLEXI CAP FUND",
    "additionalFundOption": "201",
    "alertFlag": "N",
    "amount": "1000",
    "amountInMultiplesOf": "500",
    "balanceInstallmentNum": "15",
    "bankDetails": "INDIAN BANK/423956136",
    "checkNum": "SIP-ECS",
    "directPlan": "null",
    "distributor": "",
    "dividendFlag": "G",
    "euin": "",
    "existingAccNo": "2019904729556",
    "frequency": "Monthly",
    "fundCategory": "EQUITY",
    "fundOption": "201",
    "fundOptionDesc": "Franklin India FLEXI CAP FUND",
    "instrumentType": "ECS",
    "isStepUpActive": "N",
    "leadDays": "15",
    "minSipAmount": "500",
    "nextTriggerDate": "20/01/2021",
    "nfoFlag": "N",
    "paymentMode": "M",
    "payoutFlag": "Y",
    "perpetualFlag": "N",
    "referenceNo": "123",
    "reinvestFlag": "N",
    "sipAnnualCycle": "20/05/2021",
    "sipCancelDate": "20/01/2021",
    "sipEndDate": "20/03/2022",
    "sipStartDate": "16/04/2012",
    "sipStatusCode": "N",
    "sipStatusDesc": "Active",
    "stepUpAmount": "",
    "subBrokerARN": "",
    "subDistId": "",
    "totalInstallmentNum": "120",
    "transactionNum": "PT25134105"
  },
  {
    "accountNumber": "2019904729557",
    "achAmount": "",
    "achDebitType": "",
    "achFrequency": "",
    "achFromDate": "",
    "achToDate": "",
    "additionalFundCode": "Franklin India FLEXI CAP GROWTH",
    "additionalFundOption": "202",
    "alertFlag": "N",
    "amount": "1000",
    "amountInMultiplesOf": "500",
    "balanceInstallmentNum": "15",
    "bankDetails": "INDIAN BANK/423956136",
    "checkNum": "SIP-ECS",
    "directPlan": "null",
    "distributor": "",
    "dividendFlag": "G",
    "euin": "",
    "existingAccNo": "2019904729557",
    "frequency": "Monthly",
    "fundCategory": "EQUITY",
    "fundOption": "201",
    "fundOptionDesc": "Franklin India FLEXI CAP GROWTH",
    "instrumentType": "ECS",
    "isStepUpActive": "N",
    "leadDays": "15",
    "minSipAmount": "500",
    "nextTriggerDate": "20/01/2022",
    "nfoFlag": "N",
    "paymentMode": "E",
    "payoutFlag": "Y",
    "perpetualFlag": "N",
    "referenceNo": "456",
    "reinvestFlag": "Y",
    "sipAnnualCycle": "20/05/2022",
    "sipCancelDate": "20/01/2022",
    "sipEndDate": "20/03/2022",
    "sipStartDate": "16/04/2012",
    "sipStatusCode": "N",
    "sipStatusDesc": "Active",
    "stepUpAmount": "",
    "subBrokerARN": "",
    "subDistId": "",
    "totalInstallmentNum": "120",
    "transactionNum": "PT25134106"
  },
  {
    "accountNumber": "2019904729558",
    "achAmount": "",
    "achDebitType": "",
    "achFrequency": "",
    "achFromDate": "",
    "achToDate": "",
    "additionalFundCode": "Franklin India FLEXI CAP DIVIDEND",
    "additionalFundOption": "202",
    "alertFlag": "N",
    "amount": "2000",
    "amountInMultiplesOf": "500",
    "balanceInstallmentNum": "15",
    "bankDetails": "INDIAN BANK/423956136",
    "checkNum": "SIP-ECS",
    "directPlan": "null",
    "distributor": "",
    "dividendFlag": "G",
    "euin": "",
    "existingAccNo": "2019904729558",
    "frequency": "Monthly",
    "fundCategory": "EQUITY",
    "fundOption": "201",
    "fundOptionDesc": "Franklin India FLEXI CAP GROWTH",
    "instrumentType": "ECS",
    "isStepUpActive": "N",
    "leadDays": "15",
    "minSipAmount": "500",
    "nextTriggerDate": "20/01/2022",
    "nfoFlag": "N",
    "paymentMode": "E",
    "payoutFlag": "N",
    "perpetualFlag": "N",
    "referenceNo": "678",
    "reinvestFlag": "Y",
    "sipAnnualCycle": "20/05/2022",
    "sipCancelDate": "20/01/2022",
    "sipEndDate": "20/03/2022",
    "sipStartDate": "16/04/2012",
    "sipStatusCode": "N",
    "sipStatusDesc": "Active",
    "stepUpAmount": "",
    "subBrokerARN": "",
    "subDistId": "",
    "totalInstallmentNum": "120",
    "transactionNum": "PT25134107"
  }]
}

});

ModifySipModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ModifySipModelLookUp table, please contact admin...');
    } else {
        ModifySipModelLookUp.remove({}, function(err) {
            console.log('ModifySipModelLookUp collection removed');
            ModifySipModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating ModifySipModelLookUp table, please contact admin...');
                }
                console.log('ModifySipModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ModifySipModelLookUp;