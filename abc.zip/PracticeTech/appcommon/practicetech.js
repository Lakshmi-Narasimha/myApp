﻿define([
  'appcommon/core/core'
], function (Core) {

    console.log(Core);
    practicetech = new Core();
    practicetech.modules = {};
    practicetech.util = {};
    console.log(practicetech);
    return practicetech;
});