'use strict';

function accountSettingsRoutes($stateProvider) {

    var bankDetails = {
        parent: 'home',
        name: 'bankdetails', // state name
        url: 'accountsettings/bankdetails', // url path that activates this state
        views: {
            'dashboard@home': {
                controller: 'BankDetailsController',
                template: require('./bankdetails/bankAccountDetails.html')
            }
        }
    };
    
    var addNewBank = {
        parent: 'home',
        name: 'addnewbank', // state name
        url: 'accountsettings/addnewbank', // url path that activates this state
        views: {
            'dashboard@home': {
                template: require('./bankdetails/addnewbank/addNewBank.html')
            }
        }
    };

    var changeDividend = {
        parent: 'home',
        name: 'changedividend', // state name
        url: 'accountsettings/changedividend', // url path that activates this state
        views: {
            'dashboard@home': {
                controller: 'ChangeDividendController',
                template: require('./changedividend/changedividend.html')
            }
        }
    };

    var emandate = {
        parent: 'home',
        name: 'emandate', // state name
        url: 'accountsettings/emandate', // url path that activates this state
        views: {
            'dashboard@home': {
                controller: 'eMandateController',
                template: require('./emandate/emandate.html')
            }
        }
    };

    var newEmandate = {
        parent: 'home',
        name: 'newEmandate', // state name
        url: 'accountsettings/newEmandate', // url path that activates this state
        views: {
            'dashboard@home': {
                controller: 'newEmandateController',
                template: require('./emandate/newemandate.html')
            }
        }
    };

    var smartsavingsaccount = {
        parent: 'home',
        name: 'smartsavingsaccount',
        url: 'accountsettings/smartsavingsaccount',
        views: {
            'dashboard@home': {
                template: require('./smartsavingsaccount/smartSavingsAccount.html'),
                controller: 'SmartSavingsAccountController'
            },
            'selectInvPurchaseView@smartsavingsaccount': {
                template: require('./smartsavingsaccount/smartSavingsPurchases.html'),
                controller: 'PurchasesController'
            },
            'selectInvRedeemView@smartsavingsaccount': {
                template: require('./smartsavingsaccount/smartSavingsRedeem.html'),
                controller: 'RedeemController'
            }
        }
    };
    
    var nomineeDetails = {
        parent: 'home',
        name: 'nomineedetails', // state name
        url: 'accountsettings/nomineedetails', // url path that activates this state
        views: {
            'dashboard@home': {
                controller: 'NomineeDetailsController',
                template: require('./nomineedetails/nomineeDetails.html')
            }
        }
    };

    var onetouchinvest = {
        parent: 'home',
        name: 'onetouchinvest',
        url: 'accountsettings/onetouchinvest',
        views: {
            'dashboard@home': {
                template: require('./onetouchinvest/oneTouchInvest.html'),
                controller: 'OneTouchInvestController'
            },
            'standingInstructionsView@onetouchinvest': {
                template: require('./onetouchinvest/standingInstructions.html'),
                controller: 'StandingInstructionsController'
            }
        }
    };


    var familyportfolioaccess = {
        parent: 'home',
        name: 'familyportfolioaccess',
        url: 'accountsettings/familyportfolioaccess',
        views: {
            'dashboard@home': {
                template: require('./familyportfolioaccess/familyPortfolioAccess.html'),
                controller: 'FamilyPortfolioAccessController'
            }
        }
    };

    $stateProvider
        .state(bankDetails)
        .state(addNewBank)
        .state(changeDividend)
        .state(emandate)
        .state(newEmandate)
        .state(smartsavingsaccount)
        .state(onetouchinvest)
        .state(nomineeDetails)
        .state(familyportfolioaccess);
}

accountSettingsRoutes.$inject = ['$stateProvider'];
module.exports = accountSettingsRoutes;
