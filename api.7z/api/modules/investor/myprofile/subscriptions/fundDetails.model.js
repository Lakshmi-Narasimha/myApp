// getFundDtlsForNewFundSelection.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var FundDetailsSchema = new mongoose.Schema({
    FundDetails: {
        type: Array,
        'default': []
    }
});

var FundDetailsInvSchemaLookUp = mongoose.model('FundDetailsInvSchemaLookUp', FundDetailsSchema);

var FundDetailsModel = new FundDetailsInvSchemaLookUp({
    'FundDetails': {
        'allfunds': {
            'newFunds': [{
                'amount': '',
                'dividendFlag': 'R',
                'endDate': '',
                'frequency': '',
                'fundCategory': 'EQUITY',
                'fundOptDesc': 'Franklin India Prima Fund - Dividend',
                'fundOption': '001',
                'fundPerfAvailable': 'N',
                'fundType': 'N',
                'minAddPurAmt': '1000',
                'minNewPurAmt': '1000',
                'minSipAmt': '500',
                'multiples': '1',
                'nfoFlag': 'N',
                'payoutFlag': 'Y',
                'perpetualFlag': '',
                'productCode': '4615',
                'reinvestmentFlag': 'Y',
                'startDate': '',
                'stepUpFrequency': '',
                'stepUpType': '',
                'stepUpValue': '',
                'txnType': ''
            }, {
                'amount': '',
                'dividendFlag': 'R',
                'endDate': '',
                'frequency': '',
                'fundCategory': 'EQUITY',
                'fundOptDesc': 'Franklin India Prima Plus - Dividend',
                'fundOption': '002',
                'fundPerfAvailable': 'N',
                'fundType': 'N',
                'minAddPurAmt': '2',
                'minNewPurAmt': '5000',
                'minSipAmt': '1',
                'multiples': '1',
                'nfoFlag': 'N',
                'payoutFlag': 'Y',
                'perpetualFlag': '',
                'productCode': '4616',
                'reinvestmentFlag': 'Y',
                'startDate': '',
                'stepUpFrequency': '',
                'stepUpType': '',
                'stepUpValue': '',
                'txnType': ''
            }, {
                'amount': '',
                'dividendFlag': 'G',
                'endDate': '',
                'frequency': '',
                'fundCategory': 'FIXED INCOME',
                'fundOptDesc': 'Franklin India Ultra Short Bond Fund - Asset Segregation Plan-Direct - Growth',
                'fundOption': '787',
                'fundPerfAvailable': 'N',
                'fundType': 'N',
                'minAddPurAmt': '1000',
                'minNewPurAmt': '10000',
                'minSipAmt': '1000',
                'multiples': '1',
                'nfoFlag': 'N',
                'payoutFlag': 'N',
                'perpetualFlag': '',
                'productCode': '12119',
                'reinvestmentFlag': 'N',
                'startDate': '',
                'stepUpFrequency': '',
                'stepUpType': '',
                'stepUpValue': '',
                'txnType': ''
            }]
        },
        'folioId': '',
        'maxFundsLimit': '3'
    }
});

FundDetailsInvSchemaLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FundDetailsInvSchemaLookUp table, please contact admin...');
    } else {
        FundDetailsInvSchemaLookUp.remove({}, function(err) {
            console.log('FundDetailsInvSchemaLookUp collection removed');
            FundDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FundDetailsInvSchemaLookUp table, please contact admin...');
                }
                console.log('FundDetailsInvSchemaLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FundDetailsInvSchemaLookUp;
