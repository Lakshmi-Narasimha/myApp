define([
  
], function () {

    opeatingSystems = {

    },
     Whitelist = {

        Devices: {
            desktop: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            surface: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            ipad: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            iphone: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            iphone4s:{
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            iphone5s:{
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            iphone6: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            iphone6plus: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            unknowniphone: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            samsung: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            android: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            }
            
        },
        Browsers: {
            "unknown": {
                isSupported: false,
                isTested: false,
                supportLevel: 'unknown'
            },
            chrome: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            safari: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            ie: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            }
        },

        OSList: {
            
            windows7: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            windows8: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            windowsGeneric: {
                isSupported: true,
                isTested: true,
                supportLevel: true
            },
            windowsVista : {
                isSupported: true,
                isTested: true,
                supportLevel: true
                },
            windowsXP: {
                    isSupported: true,
                    isTested: true,
                    supportLevel: true
            },
            macOSgeneric : {
                isSupported: true,
                isTested: true,
                supportLevel: 'full'
            },
            macOSX : {
                isSupported: true,
                isTested: true,
                supportLevel: 'full'
            },
            ios: {
                    isSupported: true,
                    isTested: true,
                    supportLevel: 'full'
            },
            android: {
                isSupported: true,
                isTested: true,
                supportLevel: 'full'
            }
        },

        formFactor: {
            large: { isSupported: true, },
            medium: { isSupported: true, },
            small: { isSupported: true}
        }

    }

    return Whitelist;

})