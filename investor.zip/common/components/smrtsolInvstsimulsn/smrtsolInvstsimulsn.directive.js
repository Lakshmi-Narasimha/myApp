'use strict';

var smrtsolInvSimulation = function() {
	return {
        template: require('./smrtsolInvstsimulsn.html'),
        restrict: 'E',
        replace: true,
        scope:{
           goalChart : "=" ,
           title : "=?"

        },
        controller: function($scope, $element, $attrs){
           console.log($scope.goalChart);
            $scope.categories = [];
            $scope.categoriesValues = [];
        
               
                for(var i=0;i<$scope.goalChart.data.length;i++)
                {
                    
                    $scope.categories.push($scope.goalChart.data[i].years);
                    $scope.categoriesValues.push(parseInt($scope.goalChart.data[i].amount));
                };
                console.log($scope.categories);
                $scope.goalAmount = $scope.goalChart.goalAmount || "20,00,000";
              
        
                $scope.smrtSolChartSeriesConfig = {
                        chart: {
                            type: 'area',
                            width: 382,
                            height: 230
                        },
                        title: {
                            text: "Your Goal<span class='text-danger'>*</span> <i class='icon-fti_rupee'></i> "+$scope.goalAmount
                        },
                        subtitle: {
                            text: ''
                        },
                        xAxis: {
                           categories: $scope.categories,
                         

                            tickmarkPlacement: 'on',
                            title: {
                                text: 'Time',
                                align: 'low',
                                offset: 0,
                                x: -30,
                                y: 12
                            },
                            labels: {
                                rotation: 0,
                                y: 25,
                                align: 'center'
                            }/*,
                            plotLines: [{
                                color: '#C0D0E0',
                                width: 1,
                                // value: Date.UTC(profileDetailsDate.getFullYear(),profileDetailsDate.getMonth(),profileDetailsDate.getDate()),
                                value: 3,
                                zIndex: 999
                            }]*/
                        },
                        yAxis: [{
                            title: {
                                useHTML: true,
                                text: "<span class='custom-bold'><i class='icon-fti_rupee'></i></span>",
                                align: 'high',
                                rotation: 0,
                                x : 25,
                                y : -15

                            }
                        }
                        ],
                        tooltip: {
                            shared: true,
                            valueSuffix: ''
                        },
                        plotOptions: {
                            area: { 
                                stacking: 'normal',
                                lineWidth: 1,
                                fillColor: "#FFF",
                                marker: {
                                    symbol: 'circle' ,
                                    lineWidth: 0.5
                                }
                            }
                        },
                        series:[{
                            showInLegend: false, 
                            data :  $scope.categoriesValues,
                            color : "#96be8a"

                          
                        }] 
                    };
            
        }
    }
};

smrtsolInvSimulation.$inject = [];
module.exports = smrtsolInvSimulation;