// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var CommissionCalculatorSchema = new mongoose.Schema({
    commissionCalculatorObject: {
        type: Array,
        "default": []
    }
});

var CommissionCalculatorLookUp = mongoose.model('CommissionCalculatorLookup', CommissionCalculatorSchema);

var CommissionCalculatorModel = new CommissionCalculatorLookUp({

  "commissionCalculatorObject": [
  {
    "commissionCalculatorRes": {
        "fundName": "Franklin India BLUECHIP FUND",
        "grossSaleValue": "10000",
        "returnData": [{
            "commissionType": "Upfront",
            "commisionRate": "0.90",
            "commisionAmount": "2000"
        }, {
            "commissionType": "FirstYearTrail",
            "commisionRate": "0.90",
            "commisionAmount": "20000"
        }, {
            "commissionType": "LastYearTrail",
            "commisionRate": "0.90",
            "commisionAmount": "25000"
        }]
    }
}
    ]

});

CommissionCalculatorLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating CommissionCalculatorLookUp table, please contact admin...');
    } else {
        CommissionCalculatorLookUp.remove({}, function(err) {
            console.log('AdvisorContentLookUp collection removed');
            CommissionCalculatorModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating CommissionCalculatorLookUp table, please contact admin...');
                }
                console.log('CommissionCalculatorLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = CommissionCalculatorLookUp;
