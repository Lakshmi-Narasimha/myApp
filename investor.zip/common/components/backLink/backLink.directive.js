/**
 * @ngdoc directive
 * @name fticBackLink
 * @requires $state
 * @requires $window
 * @description
 *
 * - fticBackLink will redirect the page to the view specified in "state" attribute. 
    If "state" attribute is not defined, then it will redirect to the previous view.
 * 
 *
 **/
 'use strict';

var backLink = function($state,$window) {
	return {
            template: require('./backLink.html'),
            restrict: 'E',
            replace: true,
            scope: {
              state: "=",
              label: "@"
            },
            controller: function($scope, $element, $attrs){             
            },
            link: function(scope, iElement, iAttrs, controller){
                // if(angular.isUndefined(iAttrs.label)){
                //     iAttrs.label = "Back";
                // }
                scope.goBack = function(){
                    (angular.isDefined(iAttrs.state))? ($state.go(iAttrs.state)) : ($window.history.back());
                }

            }
        };
};

backLink.$inject = ['$state','$window'];
module.exports = backLink;