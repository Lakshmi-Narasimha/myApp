var express = require('express');
var https = require('https');
var config = require('../../../config/config');

var router = express.Router();
var getMessageModel = require('./getMessage.model');

// api route
router.route('/mfchat/rest/message/:engagementID')
    .post(function(req, res) {
        console.log(req.sessionCookie);
        var proxyRequest = https.request({
                host: config.TC_SERVER_NAME,
                method: 'GET',
                path: config.TC_GET_MSG_URI + req.params.engagementID + '&instantResponse=true',
                headers: {
                    'Cookie': req.sessionCookie
                },
                rejectUnauthorized: false
            },
            function(proxyResponse) {
                console.log(proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    res.send(chunk);
                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
