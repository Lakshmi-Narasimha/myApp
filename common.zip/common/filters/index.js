/**
 *@ngdoc object
 *@name common.module:filters
 *@description
 * <p>
 * In this we have the all global filters 
 * </p> 
 */

module.exports = angular.module('common.filters', [])
    .filter('fticTrim', require('./fticTrim.filter'))
    .filter('fticVideo', require('./fticVideo.filter'))
    .filter('fticRupee', require('./fticRupee.filter'))
    .filter('fticAddComma', require('./fticInsertComma.filter'))
    .filter('fticInvFormatTwoDigitNum', require('./fticInvFormatTwoDigitNum.filter'))
    .filter('fticNACheck', require('./fticNACheck.filter'))
    .filter('fticKycStatus', require('./fticKycStatus.filter'))
    .filter('paymentMode', require('./paymentMode.filter'))
    .filter('removeComma', require('./removeComma.filter'));
