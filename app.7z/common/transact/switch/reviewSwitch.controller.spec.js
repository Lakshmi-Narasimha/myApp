'use strict';
describe('Controller: ReviewSwitchController', function() {
	var $controller,$scope,ReviewSwitchController,TransactConstant,$filter,switchDtlsToReviewModel,authenticationService,eventConstants;

	var switchBaseDtlsObjWithAmountEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Amount",        
        amount : 8000
	};

	var switchBaseDtlsObjWithUnitsEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Amount",              
        units : 3000
	};	

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_TransactConstant_,_$filter_,_switchDtlsToReviewModel_,_authenticationService_,_eventConstants_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();
		
		TransactConstant = _TransactConstant_;
		$filter = _$filter_;		
		
		switchDtlsToReviewModel = _switchDtlsToReviewModel_;		
		authenticationService = _authenticationService_;
		eventConstants = _eventConstants_;
		switchDtlsToReviewModel.setDataObj(switchBaseDtlsObjWithAmountEntered);
		$scope.config = {};
		loadController();			
	}));	

	function loadController(){
        ReviewSwitchController = $controller('ReviewSwitchCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(ReviewSwitchController).toBeDefined();
    });

    it('should define the variables switchDetailsObj and if the user selects amount',function(){ 
    	expect($scope.switchDetailsObj[0].value).toBe("Franklin India PRIMA FUND");
    	expect($scope.switchDetailsObj[1].value).toBe("0010008062712");
    	expect($scope.switchDetailsObj[2].value).toBe("Partial");
    	expect($scope.switchDetailsObj[3].value).toBe(8000);
    });

    it('should define the variables switchDetailsObj and if user selects units',function(){ 
    	switchDtlsToReviewModel.setDataObj(switchBaseDtlsObjWithUnitsEntered);
    	loadController();	
    	expect($scope.switchDetailsObj[0].value).toBe("Franklin India PRIMA FUND");
    	expect($scope.switchDetailsObj[1].value).toBe("0010008062712");
    	expect($scope.switchDetailsObj[2].value).toBe("Partial");
    	expect($scope.switchDetailsObj[3].value).toBe(3000);
    });

    it('should set the variables toState,toTxnDetailsState if investor is logged in',function(){
    	expect($scope.config.toTxnDetailsState).toBe("invTransact.txnDetails");
    	expect($scope.config.toState).toBe("invTransact.base.switch");
    });

    it('should set the variables toState,toTxnDetailsState if advisor is logged in',function(){
		authenticationService.setUser({                                        
                "userId": "test123"                
            });
		loadController();	
		expect($scope.config.toTxnDetailsState).toBe("transact.txnDetails.switch");
    	expect($scope.config.toState).toBe("transact.base.switch");    	
    });

    it('should listen the event eventConstants.ACTION_ICON_CLICKED when triggered',function(){
    	spyOn($scope,"$emit");
    	$scope.$broadcast(eventConstants.ACTION_ICON_CLICKED);
    	expect(switchDtlsToReviewModel.isSwitchEdited).toBe(true);
    	expect($scope.$emit).toHaveBeenCalledWith("NAVIGATE_TO_TRANSACT",{key: 'switch'});
    });
});