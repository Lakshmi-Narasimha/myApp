/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function newFundModalSSController($scope, $uibModalStack, transactEventConstants,smartSolnFundDetailsInitialLoader,smartSolnFundDetailsModel, eventConstants,$filter) {
   
    
	$scope.sectionOptions = [];
    var keys = [];
  
    var fundDtls = smartSolnFundDetailsModel.getFundDetails();`

    for(var k in fundDtls){ keys.push(k);}
        //console.log("keys",keys);
    for(var i in keys){
        $scope.sectionOptions.push({title : keys[i].toString().toLowerCase(), value : keys[i].toString()});
    }

    $scope.sortedSectionOption= $filter('orderBy')($scope.sectionOptions, 'title');
    //console.log("$scope.sortedSectionOption",$scope.sortedSectionOption);
    setOptions(fundDtls.allFunds);

    function setOptions(funds){
        var selectedFundList = [];
        if ($scope.smartSolInvestor === 'smartSolInvestor') {
            angular.forEach($scope.selectfund,function(lbl,key){
                selectedFundList.push(lbl.label + key);
            });
        }
        $scope.singleSelectOptions = [];
        var count = 0;
        angular.forEach(funds,function(lbl,key){
            var obj = {};
            obj = lbl;
            if(lbl.nfoFlag == 'Y'){
            obj.fundName = lbl.fundOptDesc + ' - NFO';
            }else{
                obj.fundName = lbl.fundOptDesc;
            }
            //     if($scope.selectedFund.fundName == lbl.fundOptDesc ){

            //     obj.selected = true;    
            // }else{
            //     obj.selected = false    
            // }                        
            
            $scope.singleSelectOptions.push(obj);

            if ($scope.smartSolInvestor === 'smartSolInvestor') {            
                angular.forEach($scope.selectfund,function(fund,fundKey){
                    if(lbl.fundOptDesc + $scope.indexOfFund === fund.label + $scope.indexOfFund && lbl.fundOptDesc + $scope.indexOfFund !== selectedFundList[fundKey]) {  
                        $scope.singleSelectOptions.splice(key-count, 1);   
                        count++;          
                    }
                });
            }
           
        });
    }

    $scope.$on('fundChanged',function(event,selectedObj){
        setOptions(fundDtls[selectedObj.value]);
    });    
    

    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    };


    $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function(event, data){
        var searchArray = [];
        for(var i in fundDtls.allFunds){
            if(fundDtls.allFunds[i].fundOptDesc.toString().toUpperCase().search(data.searchText.toString().toUpperCase()) != -1){
                searchArray.push(fundDtls.allFunds[i]);
            }
        }
        setOptions(searchArray);
    });

    $scope.$on('fundBasicFilter', function (event, data) {
        $scope.$broadcast('fundFilter', {'filterText': data.filterText});
    });
}


newFundModalSSController.$inject = ['$scope', '$uibModalStack', 'transactEventConstants','smartSolnFundDetailsInitialLoader','smartSolnFundDetailsModel', 'eventConstants','$filter'];

module.exports = newFundModalSSController;