'use strict';
describe('Controller: investor dashboard controller', function() {
    var $controller, $scope, dashboardController, investorDashboardDetailsModelData, smartSaveAccAndOneTouchDataObj, mockInvestorDashboardInitialServices, timeout;
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, investorDashboardDetailsModel, investorDashboardInitialServices, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        investorDashboardDetailsModelData = investorDashboardDetailsModel;
        mockInvestorDashboardInitialServices = investorDashboardInitialServices;

        smartSaveAccAndOneTouchDataObj = {
            'banner': {
                'image': '/images/bulls-and-bears.png',
                'component': 'banner',
                'heading': 'Bulls & Bears',
                'link': '/bulls-and-bears.html',
                'title': 'Bulls & Bears',
                'linkname': 'Read More',
                'content': ''
            }
        };

        dashboardController = $controller('DashboardController', { $scope: $scope });

    }));

    it('should expect dashboard controller to be defined', function() {
        expect(dashboardController).toBeDefined();
    });

    it('should load initial services is called on load and services data is available', function() {
        expect(mockInvestorDashboardInitialServices._isServicesData).toBeTruthy();
    });

    it('should trigger initial services when services data is not available', function() {
        mockInvestorDashboardInitialServices._isServicesData = true;
        $scope.init();
        var isInvesterDashboardData = false;
        $scope.$on('investorDashboardInformation', function() {
            isInvesterDashboardData = true;
        });
        timeout(function() {
			expect(isInvesterDashboardData).toBeTruthy();
		}, 0);
    });

    it('should trigger event INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH and get data', function() {
        investorDashboardDetailsModelData.setSmartSaveAccAndOneTouchData(smartSaveAccAndOneTouchDataObj);
        $scope.$broadcast('investorSmartSavAccAndOneTouch');
        expect($scope.imageData).toBeDefined();
    });
});
