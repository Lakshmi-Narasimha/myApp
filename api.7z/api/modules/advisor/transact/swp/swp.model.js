// swp.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SwpModelSchema = new mongoose.Schema({
    SwpResp: {
        type: Array,
        "default": []
    }
});

var SwpModelLookUp = mongoose.model('SwpModelLookUp', SwpModelSchema);

var SwpModel = new SwpModelLookUp({
    SwpResp : {
        'swp': {
            'bankDetails': [
                {
                    'bankName' :'ICICI',
                    'accountNo' : '1151234567890'
                },
                {
                    'bankName' :'HDFC',
                    'accountNo' : '256234567890'
                },
                {
                    'bankName' :'Dena Bank',
                    'accountNo' : '001234567890'
                },
                {
                    'bankName' :'Axis Bank',
                    'accountNo' : '789234567890'
                }
            ],
            'fundDetails': {
                'loadFreeUnits': '112',
                'valueOfLoadFreeUnits': '456.56',
                'totalAvailableUnits': '97',
                'valueOfTotalAvailableUnits': '576.67'
            }
        }
    }
});

SwpModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SwpLookUp table, please contact admin...');
    } else {
        SwpModelLookUp.remove({}, function(err) {
            console.log('SwpModelLookUp collection removed');
            SwpModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SwpModelLookUp table, please contact admin...');
                }
                console.log('SwpModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SwpModelLookUp;