﻿define(['jquery', 'backbone', 'breeze'
], function ($, Backbone, Breeze) {
    var Event = Backbone.Model.extend({
        defaults: {
            activityId: undefined,
            title: undefined,
            allDay: undefined,
            start: undefined,
            startDate :undefined,
            startTime:undefined,
            end: undefined,
            endDate :undefined,
            endTime:undefined,
            recurrence: undefined,
            availableParticipants:undefined,
            selectedParticpants: undefined,
            participantId: undefined,
            contactId: undefined,
            contactName: undefined,
            contactFirstName: undefined,
            contactLastName: undefined,
            location: undefined,
            isPrivate: undefined,
            priority: undefined,
            status: undefined,
            type: undefined,
            subType: undefined,
            description: undefined,
            recurrenceType: undefined,
            actKeyword:undefined,
            showTimeAs:undefined
        }
    });
    var Participant=Backbone.Model.extend({
        defaults: {
            name: undefined,
            particpantId: undefined,
            isPrimary: undefined,
            isSelected: undefined,
            id:undefined
        }
    });    

    var Events = Backbone.Collection.extend({
        model: Event,
    });
    return EventsCollection = {
        Participant:Participant,
        Event: Event, //Model
        Events: Events //Collection
    };
});
