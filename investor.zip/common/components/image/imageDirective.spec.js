describe('Directive: Image', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('investor'));

    
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;            
            //assign the template to the expected url called by the directive and put it in the cache

            scope.imageData ={
                link:"/bulls-and-bears.html",
                title:"Bulls & Bears",
                url:"/images/bulls-and-bears.png",
                imgClass: "img-responsive"
            };
        });

        var element = angular.element('<ftic-image link="{{imageData.link}}" title="{{imageData.title}}" url="{{imageData.url}}" img-class="{{imageData.imgClass}}"></ftic-image>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();
    });

    it('should compiled element to be defined', function(){
        expect(directiveEle).toBeDefined();
        expect(scope).toBeDefined();
    });    

    it('should have isolated scope', function(){
        expect(directiveEle.isolateScope()).toBeDefined();
    });
    
    it('should have the image responsive class', function(){
        expect(isoScope.actionClass).toEqual("img-responsive");
    });

});
