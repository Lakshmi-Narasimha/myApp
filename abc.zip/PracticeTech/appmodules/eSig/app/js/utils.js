define([
    'jquery',
    'bootstrap','errorLog'
], function($, bootstrap,ErrorLog) {
    /*NOTE: For browsers that do not support orientation change event we use browser resize event listeners
     *Logic: Maintain variables to store previous width and orientation. If current width > current height
     *       then current orientation is landscape, otherwise portrait.
     *       This global variable is maintained in the utils.
     *       //Need to check if there are improvements other than this method 
     * */
    var self = this;
    self.previousWidth = window.innerWidth;
    
    //Error messages and error description in eSig
    // For error 500 and 400 error message is same
    var errorMessages = {
		    			"500": {
					    			"errorMsg": "System unavailable",
					    			"errorDesc": "The system is currently unavailable. Please try again later."
		    					}
    				};

    function getPreviousWidth() {
        return self.previousWidth;
//        if (window.innerWidth !== self.previousWidth) {
//         //   self.currentOrientation = window.innerHeight >= window.innerWidth ? 'portrait' : 'landscape';
//            self.previousWidth = window.innerWidth;
//        }
    }
    function setPreviousWidth(val) {
        self.previousWidth = val;
    }


    
    
    function _send(type, url, contentType, data, successHandler, errorHandler,
            headers, processData, xhr1, async) {
        headers = headers || {};
        headers = $.extend(headers, {
            'cache-control': 'no-cache'
        });

        var response = $
                .ajax({
                    cache: false,
                    type: type,
                    async:async,
                    url: url,
                    processData: ((processData != null && processData != undefined) ? processData
                            : true),
                    headers: headers,
                    contentType: contentType,
                   // beforeSend: eSig.utils.setCustomHeader,
                    data: data,
                //    dataType: "json",
                    success: function(res) {
                        successHandler(res);
                    },
//                    xhr: ((xhr1 != null && xhr1 != undefined) ? xhr1
//                            : function() {
//                                return jQuery.ajaxSettings.xhr();
//                            }),
                    error: errorHandler || _genericErrorHandler

                });
        return response;

    }
    function _genericErrorHandler(xhr, text, status) {
        if (text == "timeout") {
            BootstrapDialog.alert('System Unavailable');
        } else {
            BootstrapDialog.alert('System Unavailable');
        }
    }
    var _ = {
        setCustomHeader: function(xhr) {
            xhr.setRequestHeader('sm_universalid', SM_UNIVERSAL_ID);
            xhr.setRequestHeader('fm_id', FM_ID);

        },
        put: function(url, data, successHandler, errorHandler, headers) {
            var res = _send('PUT', url, "application/json", data,
                    successHandler, errorHandler, headers);
            return res;
        },
        post: function(url, data, successHandler, errorHandler, headers,
                processData, xhr1,async) {
            var res = _send('POST', url,
                    ((xhr1 != "" && xhr1 != undefined && xhr1 != null) ? xhr1
                            : "application/json"), data, successHandler,
                    errorHandler, headers, processData, xhr1,async);
            return res;
        },
        get: function(url, data, successHandler, errorHandler, headers) {
            var res = _send('GET', url, "application/json", data,
                    successHandler, errorHandler, headers);
            return res;
        },
        delete: function(url, data, successHandler, errorHandler) {
            var res = _send('DELETE', url, "application/json", data,
                    successHandler, errorHandler);
            return res;
        },
        getJson: function(url, data, successHandler, errorHandler) {
            $.ajax({
                type: 'GET',
                dataType: "json",
                url: url,
                success: function(resp) {
                    successHandler(resp);
                },
                error: function(resp) {
                    //   console.log(resp, "resp.responseText")
                    successHandler(JSON.parse(resp));
                }
            });
        },
        capitalize: function(string) {
            return string.charAt(0).toUpperCase()
                    + string.substring(1).toLowerCase();
        },
        lowerCase: function(string) {
            return string.toLowerCase();
        },
        readCookie: function(name) {
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ')
                    c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) {
                    var _substring = decodeURIComponent(c.substring(
                            nameEQ.length, c.length));
                    return _substring;

                }
            }
            return null;
        },
        isMobile: function () {

            var _regxMob = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
            return _regxMob.test(navigator.userAgent);
        },
        isWindowsPlatform: function () {
            return (navigator.userAgent.toLowerCase().indexOf(
								"windows nt") != -1 && navigator.userAgent
								.toLowerCase().indexOf("touch") != -1);
        },
        loadSelectbox: function(selectBox, opionData, noEmptyOption) {
            var _optionsData = opionData;
            var _options = '';
            if (!noEmptyOption) {
                _options += '<option value="" >Choose one</option>'
            }
            $.each(_optionsData, function(key, row) {
                _options += '<option name="' + row.name + '" value="' + row.code
                        + '" >' + row.name + '</option>';
            });
            if (Array.isArray(selectBox)) {
                $(selectBox.join(',')).html(_options);
            } else {
                $(selectBox).html(_options);
            }

        },
        arraySplice: function(arr, ele) {
            var i = arr.indexOf(ele);
            if (i != -1) {
                arr.splice(i, 1);
            }
            return arr;
        },
        /*
        initInfoPopup: function() {
        	var _placement = 'left';
			if (window.innerWidth < 650) {
				_placement = 'left';
			}
			$('.popover.info-popup').remove();
			$('#sign-doc-title-contnr.help-icon.info-popup').popover('destroy');
			$('#sign-doc-title-contnr.help-icon')
					.popover(
							{
								container : 'body',
								html : true,
								placement : _placement,
								viewport : 'body',
								title : 'Change type <i class="icon-popover-close"></i>',
								template : '<div class="popover info-popup" role="tooltip"><div class="arrow info-popup">'
										+ '</div><h2 class="popover-title info-popup"></h2><div class="popover-content info-popup"></div></div>'
							});
			var _isOpen = true;
			$('#sign-doc-title-contnr.icon-info').on('hidden.bs.popover', function() {
				_isOpen = false;
			});
			
        },
        */
        setBodySectionHt: function (setBodyHeight) {
            //  Add proper comment for the below
            var screenHt = Math.floor($(window).height());
            var headerHt = Math.floor($('#afinav-navbar').height());
            var $footer = $('.practicetech-footer');
            var footerHt;
            if($footer.is(":visible")){
            	footerHt = Math.floor($footer.height());
            }else{
            	footerHt=0;
            }
            
            var bodyHt = screenHt - (headerHt + footerHt) - 1;
            if(setBodyHeight){
                $('#esig-app-container').height(Math.floor(bodyHt));
            }else{
                $('#esig-app-container').css("height","auto");
            }
            
        },
        setOverlay: function() {
            var _overlay = $("#overlay-upper");
            if (_overlay.is(":visible")) {
                _overlay.css({
                    'height': $(window).height() + "px",
                    'width': $(window).width() + "px",
                    'display': 'block'
                });
            }
            window.scrollTo(0, 0);
        },
        getPrevWidth: function() {
            return getPreviousWidth();
        },
        setPreviousWidth: setPreviousWidth,
        logError:function(error,hidePopup,customMessage) {
			//pass second parameter to hide the popup
			if(error){
				if(customMessage){
				ErrorLog.ErrorUtils.myError(error,true);
					// this.logError(error.message, error.url, error.lineNum);
				}else{
					ErrorLog.ErrorUtils.prepareAndLogError(error,true);
				}
			}
			
			
		},
		showErrorMsg : function(el) {
			/*var errTmpl = "<div class='row'>"+
							 "<div class='col-md-8 col-sm-10 col-xs-12 alert pt-alert-container' role='alert'>"+
							   "<div class='esig-alert-icon'>" +
							     "<div class='pt-alert-head'>" +
							        "<span>"+errorMessages[errorCode].errorMsg+"</span>"+ 
							      "</div>"+
							      "<div class='pt-alert-text'>"+
							         "<span>"+errorMessages[errorCode].errorDesc+"</span>"+ 
							      "</div>"+
							   "</div>"+
							 "</div>"+
						 "</div>";*/
			 $('.esig-service-error-wrapper').addClass('hidden');
			 $(el).removeClass('hidden');
			//_$el.html("");
			//_$el.append(errTmpl);
			//_$el.removeClass('hidden');
			
		},
		hideErrorMsg : function() {
			var _$el = $('.esig-service-error-wrapper');
			_$el.addClass('hidden');
			//_$el.html("");
		}

		
    };
    return _;
});