﻿define([
    'underscore',
    'config'
], function (_, Config) {   

    var GetAppInfo = function (appId) {
        return _.find(RegisteredApplications, function (obj) { return obj.ID == appId })
    };

    var GetAppInfoByRouteName = function (routeName) {
        var appInfo;
        _.each(RegisteredApplications, function (registerdApplication) {
            _.each(registerdApplication.LaunchTarget, function (LaunchTarget) {
                if (LaunchTarget.Route == routeName) {
                    appInfo = registerdApplication;
                }
            })
        })
        return appInfo;
    };
    var GetTargetURLByRouteName = function (appInfo, routeName) {
        if (undefined === typeof (appInfo))
            return;
        if (undefined === typeof (routeName))
            return;
        var targetUrl;
        _.each(appInfo.LaunchTarget, function (LaunchTarget) {
            if (LaunchTarget.Route == routeName) {
                targetUrl = LaunchTarget.URL;
            }
        })
        return targetUrl;
    };
    var GetLaunchTargetByRouteName = function (routeName) {
        var launchTarget;
        _.each(RegisteredApplications, function (registerdApplication) {
            _.each(registerdApplication.LaunchTarget, function (LaunchTarget) {
                if (LaunchTarget.Route == routeName) {
                    launchTarget = LaunchTarget;
                }
            })
        })
        return launchTarget;
    };

    var GetAppContextByRouteName = function (routeName) {
        var requiredContext;
        _.each(RegisteredApplications, function (registerdApplication) {
            _.each(registerdApplication.LaunchTarget, function (LaunchTarget) {
                if (LaunchTarget.Route == routeName) {
                    requiredContext = LaunchTarget.Context;
                }
            })
        })
        return requiredContext;
    };

    var GetReqAppContextByURL = function (targetUrl) {
        var requiredContext;
        if (undefined === typeof (targetUrl))
            return;
        _.each(RegisteredApplications, function (registerdApplication) {
            _.each(registerdApplication.LaunchTarget, function (LaunchTarget) {
                if (LaunchTarget.URL == targetUrl) {
                    requiredContext = LaunchTarget.Context;
                }
            })
        })
        return requiredContext;
    };
    var RegisteredApplications = [{
        ID: '100',
        RegisterdName: 'Navigator',
        DeviceProfile: ['Phone', 'Tablet', 'Windows'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        RequireContext: false,
        LaunchParams: ['none'],
        LaunchSource: [],
        LaunchTarget: [{
            Route: 'navigator/',
            URL: Config.defaultNavURL,
            Context: 'user',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/'
            }]

        }, {
            Route: 'navigator/contactlist',
            URL: Config.contactListURL,
            Context: 'advisor',
            NotifyChange: false,
            DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
            Actions: [{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }]

        }, {
            Route: 'navigator/prospectlist',
            URL: Config.contactListURL,
            Context: 'advisor',
            NotifyChange: false,
            Actions: [{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/prospectlist'
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }]

        }, {
            Route: 'navigator/addcontact',
            URL: Config.contactListURL,
            Context: 'advisor',
            NotifyChange: false,
            Actions: [{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }]

        }, {
            Route: 'navigator/editcontact',
            URL: Config.contactListURL,
            Context: 'advisor',
            NotifyChange: false,
            Actions: [{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }]

        }, {
            Route: 'navigator/draftspage',
            URL: Config.contactListURL,
            Context: 'advisor',
            NotifyChange: false,
            Actions: [{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }]

        }]
    }, {
        ID: '101',
        RegisterdName: 'Contact Profile',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'contactprofile/',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },
        {
            Route: 'contactprofile/preferences',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }, {
        	Route: 'contactprofile/bank',
        	URL: Config.contactProfileURL,
        	Context: 'contact',
        	NotifyChange: false,
        	Actions: [{
        		Event: 'ContactChanged',
        		Redirect: 'contactprofile/'
        	}, {
        		Event: 'ContactRemoved',
        		Redirect: ''
        	}, {
        		Event: 'AdvisorChanged',
        		Redirect: 'navigator/contactlist'
        	}]
        },
        {
            Route: 'contactprofile/beneficiary',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },
        {
            Route: 'contactprofile/fiduciary',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },
        {
            Route: 'contactprofile/contributions',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },
        {
            Route: 'contactprofile/distributions',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },
        {
            Route: 'contactprofile/iradetails',
            URL: Config.contactProfileURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }
        ]
    }, {
        ID: '102',
        RegisterdName: 'Account Viewer',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'accountviewer/',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/accountdetails',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/activitylist',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/activitylist'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/activitylist',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/activitylist'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/financial',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/financial'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/portfolio',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/portfolio'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/arrangement',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/arrangement'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'accountviewer/accountstatements',
            URL: Config.accountListURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'GroupChanged',
                Redirect: 'accountviewer/accountstatements'
            }, {
                Event: 'GroupRemoved',
                Redirect: ''
            }, {
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: ''
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }]
    }, {
        ID: '103',
        RegisterdName: 'CRM',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'crm/',
            URL: Config.calendarURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: ''
            }]
        },{
            Route: 'crm/new-activity',
            URL: Config.calendarURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'crm/smartpad',
            URL: Config.calendarURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }, {
            Route: 'crm/addsmartpad',
            URL: Config.calendarURL,
            Context: 'user',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'crm/editsmartpad',
            URL: Config.calendarURL,
            Context: 'user',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }, {
            Route: 'crm/notedetail',
            URL: Config.calendarURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'crm/tasks',
            URL: Config.calendarURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'crm/addtask',
            URL: Config.calendarURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'crm/edittask',
            URL: Config.calendarURL,
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }]
    }, {
        ID: '104',
        RegisterdName: 'Change of Address',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'coa/',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'coa/home',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'coa/validation',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'coa/verify',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'coa/confirm',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }]
    }, {
        ID: '105',
        RegisterdName: 'New Client Setup',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'ncst/',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/client-info',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/address-entry',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/address-validation',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/client-details',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/employment',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/income',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/verification',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'ncst/confirmation',
            URL: Config.ncstURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }]
    },{
        ID: '106',
        RegisterdName: 'eSignature',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'eSig/',
            URL: Config.eSigURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'eSig/req-signers-list',
            URL: Config.eSigURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'eSig/sign-submitted',
            URL: Config.eSigURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'eSig/sign-document-view',
            URL: Config.eSigURL,
            Context: 'all',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }]
    }, {
        ID: '107',
        RegisterdName: 'External Tools',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'externalTools/contactManager',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop', 'iPad'],
            NotifyChange: false

        }, {
            Route: 'externalTools/eFileDelivery',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
            
        }, {
            Route: 'externalTools/eFormsManager',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
        }, {
            Route: 'externalTools/NBST',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false,
       
        }, {
            Route: 'externalTools/OnlineFileManager',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false       
        }, {
            Route: 'externalTools/PortfolioManager',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Phone', 'Tablet', 'Desktop', 'iPad'],
            NotifyChange: false
        }, {
            Route: 'externalTools/ShareDocuments',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
        }, {
            Route: 'externalTools/ShareToDos',
            URL: '',
            Context: 'contact',
            DeviceProfile: [ 'Desktop'],
            NotifyChange: false
        }, {
            Route: 'externalTools/BoxForAmeriprise',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop', 'Tablet', 'Phone',],
            NotifyChange: false
        }, {
            Route: 'externalTools/ConfidentRetirement',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Windows', 'Desktop', 'iPad'],
            NotifyChange: false
        }, {
            Route: 'externalTools/eFileDelivery',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
        }, {
            Route: 'externalTools/MoneyMovementWIP',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Phone', 'Tablet', 'Desktop', 'iPad'],
            NotifyChange: false
        }, {
            Route: 'externalTools/MorningstarAdvisorWorkstation',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
        },  {
            Route: 'externalTools/PriceCard',
            URL: '',
            Context: 'contact',
            DeviceProfile: [ 'Desktop'],
            NotifyChange: false
        }, {
            Route: 'externalTools/StatusManager',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
        },{
            Route: 'externalTools/T1Anywhere',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Phone','Tablet','iPad'],
            NotifyChange: false
        }, {
            Route: 'externalTools/ThomsonONE',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Desktop'],
            NotifyChange: false
        }, {
            Route: 'externalTools/TotalView',
            URL: '',
            Context: 'contact',
            DeviceProfile: ['Phone', 'Tablet', 'Desktop', 'All'],
            NotifyChange: false
        }
        ]
    },
{

        ID: '108',
        RegisterdName: 'GPM',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'gpm/',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'gpm/update',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'gpm/verification',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'gpm/confirm',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }]
    },
    {

        ID: '109',
        RegisterdName: 'HOC',
        DeviceProfile: ['Phone', 'Tablet', 'Desktop'],
        VisibilityGroup: ['PilotGroup'],
        Navigable: true,
        LaunchSource: ['100'],
        LaunchTarget: [{
            Route: 'hoc/',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'hoc/serviceopportunities',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },{
            Route: 'hoc/takeAction',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            },{
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        },
        {
            Route: 'hoc/dol',
            URL: '',
            Context: 'contact',
            NotifyChange: false,
            Actions: [{
                Event: 'ContactChanged',
                Redirect: 'contactprofile/'
            }, {
                Event: 'ContactRemoved',
                Redirect: 'navigator/contactlist'
            }, {
                Event: 'AdvisorChanged',
                Redirect: 'navigator/contactlist'
            }]
        }
        ]
    }
    ];

    //Move this code to Template processing section for menus
    var Menu = [{
        ID: '1',
        AppID: '101',
        DisplayName: 'Contact Information',
        RouteName: 'contactprofile/',
        Clickable: true,
        IsRoot: true
    }, {
        ID: '2',
        AppID: '102',
        DisplayName: 'Accounts',
        RouteName: 'accountlist',
        Clickable: true,
        IsRoot: true
    }, {
        ID: '3',
        AppID: '103',
        DisplayName: 'Smartpad',
        RouteName: 'smartpad',
        Clickable: true,
        IsRoot: true
    }, {
        ID: '4',
        AppID: '103',
        DisplayName: 'New Appointment',
        RouteName: 'appointment',
        Clickable: true,
        IsRoot: true
    }, {
        ID: '5',
        AppID: '103',
        DisplayName: 'New Task',
        RouteName: 'task',
        Clickable: true,
        IsRoot: true
    }, {
        ID: '6',
        AppID: '103',
        DisplayName: 'View Activity List',
        RouteName: 'activitylist',
        Clickable: true,
        IsRoot: true
    }, {
        ID: '8',
        AppID: '100',
        DisplayName: 'Start Over',
        RouteName: 'default',
        Clickable: true,
        IsRoot: true
    }];

    return {
        GetAppInfo: GetAppInfo,        
        GetAppInfoByRouteName: GetAppInfoByRouteName,
        GetTargetURLByRouteName: GetTargetURLByRouteName,
        GetReqAppContextByURL: GetReqAppContextByURL,
        GetLaunchTargetByRouteName: GetLaunchTargetByRouteName,
        GetAppContextByRouteName: GetAppContextByRouteName
    }
});