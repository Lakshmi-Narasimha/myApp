describe('Directive: Action Button Popup', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            scope.buttons = ["EditDetails", "Unlock Sub-User", "Delete Sub-User"];            
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-action-buttons-popup button-options="buttons"></ftic-action-buttons-popup>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

       
    });

    // it('span label should be "back", if label is not defined', function(){
    //     var spanText = directiveEle.find('span').text();
    //     expect(spanText).toEqual("Back");
    // });

    it('should compiled element to be defined', function(){
        expect(directiveEle).toBeDefined();
        expect(scope).toBeDefined();
        
    });

    it('should have isolated scope', function(){
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    /*it('should match the data with isolated scope', function(){
        expect(scope.buttons).toEqual("EditDetails");
    });
*/
  
});
