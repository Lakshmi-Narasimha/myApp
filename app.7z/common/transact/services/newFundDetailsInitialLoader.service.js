'use strict';

var newFundDetailsInitialLoader = function (newFundDetailsModel, transactEvents, transactEventConstants, $loader) {
    
    var newFundDetailsInitialLoader = {
        _isServicesData: false,     
        loadAllServices : function (scope,selectedInv) {

            function newFundDetailsSuccess(data) {
                newFundDetailsModel.setFundDetails(data);
                newFundDetailsModel.setMaxFundLimit(data.maxFundsLimit)
                newFundDetailsModel.setExistingFundDetails(data);
                transactEvents.transact.publishNewFundDetails(scope,newFundDetailsModel.getFundDetails());
            }

            function handleFailure(data){
                console.error('handleFailure');
                newFundDetailsInitialLoader._isServicesData = false;
            }

            $loader.start();
            newFundDetailsModel.fetchNewFundDetails(selectedInv)
                .then(newFundDetailsSuccess, handleFailure)
                .finally(function() {
                    $loader.stop();
                });
            
        }
        
    };
    return newFundDetailsInitialLoader;
};

newFundDetailsInitialLoader.$inject = ['newFundDetailsModel', 'transactEvents', 'transactEventConstants', '$loader'];

module.exports = newFundDetailsInitialLoader;