import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import {Observer} from 'rxjs/Observer';

import { Agent } from '../_models/agent';
import { Intent } from '../_models/intent';
import { Parameter } from '../_models/parameter';
import { UserExpression } from '../_models/userexpression';
import { User } from '../_models/user';
import { ParamField } from '../_models/paramfield';

import { AIAssistRestService } from './aiassistrest.service';
import { AIAssistAlertService } from './aialert.service';

@Injectable()
export class AIAssistCacheService {

  currentUser: User = null;
  private agentsList: Array<Agent> = [];
  private activeAgent: Agent;
  private activeAgentIntents: Array<Intent> = [];
  private activeIntent: Intent;
  private activeUserExpressions: Array<UserExpression> = [];
  private intentEditMode: boolean = true;
  private newUserExpressions: Array<UserExpression> = [];
  private removedUserExpressions: Array<UserExpression> = [];
  private activeParamMap: any = {};
  private activeParamList: Array<ParamField> = [];
  private activeIntentResponses: Array<string> = [];
  private activeIntentResponse: string;
  private newIntentResponse: Array<string> = [];
  private removedIntentResponse: Array<string> = [];
  private selectedList: Array<Parameter> = [];
  private unSelectedList: Array<Parameter> = [];
  private newIntentName: string;
  private rootPath: string;
  private intentsToPublish: Array<Intent> = [];

  private agentsListObserver: Observer<any>;
  private activeAgentObserver: Observer<any>;
  private activeIntentsObserver: Observer<any>;
  private activeIntentObserver: Observer<any>;
  private activeUserExpressionsObserver: Observer<any>;
  private intentEditModeObserver: Observer<any>;
  private activeParamListObserver: Observer<any>;
  private activeParamMapObserver: Observer<any>;
  private isParameterModifed: boolean = false;
  private isUserExpressionModified: boolean = false;
  private activeIntentResponseObserver: Observer<any>;
  // private selectedListObserver : Observer<any>;
  // private unSelectedListObserver : Observer<any>;
  private rootPathObserver: Observer<any>;
  private currentUserObserver: Observer<any>;
  private intentsPublishObserver: Observer<any>;

  agentListObservable: Observable<any>;
  activeAgentObservable: Observable<any>;
  activeIntentsObservable: Observable<any>;
  activeIntentObservable: Observable<any>;
  activeUserExpressionsObservable: Observable<any>;
  intentEditModeObservable: Observable<any>;
  activeParamListObservable: Observable<any>;
  activeParamMapObservable: Observable<any>;
  activeIntentResponseObservable: Observable<any>;
  // selectedListObservable : Observable<any>;
  // unSelectedListObservable : Observable<any>;
  rootPathObservable: Observable<any>;
  currentUserObservable: Observable<any>;
  intentsPublishObservable: Observable<any>;

  constructor(private restService: AIAssistRestService, private aiAlertService: AIAssistAlertService, private router: Router) {
    this.agentListObservable = new Observable(observer => this.agentsListObserver = observer).share();
    this.activeAgentObservable = new Observable(observer => this.activeAgentObserver = observer).share();
    this.activeIntentsObservable = new Observable(observer => this.activeIntentsObserver = observer).share();
    this.activeIntentObservable = new Observable(observer => this.activeIntentObserver = observer).share();
    this.activeUserExpressionsObservable = new Observable(observer => this.activeUserExpressionsObserver = observer).share();
    this.intentEditModeObservable = new Observable(observer => this.intentEditModeObserver = observer).share();
    this.activeParamListObservable = new Observable(observer => this.activeParamListObserver = observer).share();
    this.activeParamMapObservable = new Observable(observer => this.activeParamMapObserver = observer).share();
    this.activeIntentResponseObservable = new Observable(observer => this.activeIntentResponseObserver = observer).share();

    // this.selectedListObservable = new Observable( observer => this.selectedListObserver = observer ).share();
    // this.unSelectedListObservable = new Observable( observer => this.unSelectedListObserver = observer ).share();

    this.rootPathObservable = new Observable( observer => this.rootPathObserver = observer ).share();
    this.currentUserObservable = new Observable( observer => this.currentUserObserver = observer).share();
    this.intentsPublishObservable = new Observable (observer => this.intentsPublishObserver = observer).share();
  }

  serverLoadAgents() {
    this.restService.getAllAgents().subscribe((data) => {
      if (data.statusCode == 0) {
          this.updateAgents(data.agentList);
      } else if (data.statusMessage == "Authentication required.") {
        this.navigateToLoginPage();
      }
    },
      (err) => {
        console.log(err);
      });
  }

  getIntentsByAgentFromServer(pAgent: Agent) {
    this.restService.getAgentById(pAgent).subscribe((data) => {
      if (data.statusCode == 0) {
        this.updateActiveAgentIntentList(data.agent);
      } else if (data.statusMessage == "Authentication required.") {
        this.navigateToLoginPage();
      }
    },
      (err) => {
        console.log(err);
      });
  }

  getIntentByIdFromServer(pIntent: Intent) {
    this.restService.getIntentById(pIntent).subscribe((data) => {
      if (data.statusCode == 0) {
        this.updateActiveIntent(data.intent);
      } else if (data.statusMessage == "Authentication required.") {
        this.navigateToLoginPage();
      }
    },
      (err) => {
        console.log(err);
      });
  }

  updateAgents(pagentsList: Array<Agent>) {
    if (pagentsList == null || pagentsList == undefined)
      pagentsList = [];
    this.agentsList = pagentsList;
    this.agentsListObserver.next(pagentsList);
    if (this.activeAgent == null && this.activeAgent == undefined) {
      this.updateActiveAgent(pagentsList[0]);
    } else {
      var currentAgent  = pagentsList.filter((agent: Agent) => agent.name === this.activeAgent.name);
      if(currentAgent && currentAgent.length > 0) {
        this.updateActiveAgent(currentAgent[0]);
      } else {
        this.updateActiveAgent(pagentsList[0]);
      }
    }
  }

  updateActiveAgent(pAgent: Agent) {
    this.activeAgent = pAgent;
    if (!this.activeAgentObserver || !this.activeAgentObservable)
      this.activeAgentObservable = new Observable(observer => this.activeAgentObserver = observer).share();
    this.activeAgentObserver.next(pAgent);
    this.getIntentsByAgentFromServer(pAgent);
    this.isParameterModifed = false;
    this.isUserExpressionModified = false;
  }

  updateActiveAgentIntentList(pAgent: Agent) {
    if (pAgent != null)
      this.activeAgentIntents = pAgent.intentList;
    else
      this.activeAgentIntents = new Array<Intent>();
    if (!this.activeIntentsObserver || !this.activeIntentsObservable )
      this.activeIntentsObservable = new Observable(observer => this.activeIntentsObserver = observer).share();
    this.activeIntentsObserver.next(this.activeAgentIntents);

    if (this.activeAgentIntents != null && this.activeAgentIntents != undefined && this.activeAgentIntents.length > 0) {
      if (this.newIntentName) {
        let newIntentArray = this.activeAgentIntents.filter(itemIntent => itemIntent.name === this.newIntentName );
        if(newIntentArray && newIntentArray.length > 0) {
          this.newIntentName = null;
          this.getIntentByIdFromServer(newIntentArray[0]);
        } else {
          this.getIntentByIdFromServer(this.activeAgentIntents[0]);
        }
      } else {
        this.getIntentByIdFromServer(this.activeAgentIntents[0]);
      }
    } else {
      this.updateActiveIntent(null);
      this.updateActiveUserExpression(new Array<UserExpression>());
    }
  }

  updateActiveIntent(pIntent: Intent) {
    this.activeIntent = pIntent;
    if (!this.activeIntentObserver || !this.activeIntentObservable )
      this.activeIntentObservable = new Observable(observer => this.activeIntentObserver = observer).share();

    this.activeIntentObserver.next(pIntent);

    // console.log(pIntent);
    // console.log(JSON.stringify(pIntent));

    if (pIntent) {
      this.updateActiveUserExpression(pIntent.expressionList);
      this.updateParamList(pIntent.parameterList);
      this.isParameterModifed = false;
      //this.updateCurrentIntentParamMap( pIntent.selectedList, pIntent.unSelectedList );
      this.isParameterModifed = false;
      this.isUserExpressionModified = false;
    }
  }

  updateActiveUserExpression(pUserExpressions: Array<UserExpression>) {
    if (pUserExpressions == undefined || pUserExpressions == null) {
      pUserExpressions = new Array<UserExpression>();
    }
    this.activeUserExpressions = pUserExpressions;
    if (this.activeUserExpressionsObserver == null || this.activeUserExpressionsObserver == undefined || this.activeUserExpressionsObservable == null || this.activeUserExpressionsObservable == undefined)
      this.activeUserExpressionsObservable = new Observable(observer => this.activeUserExpressionsObserver = observer).share();
    this.activeUserExpressionsObserver.next(pUserExpressions);
  }

  updateParamList(pParamList: Array<ParamField>) {

    // console.log(pParamList);
    // console.log(JSON.stringify(pParamList));

    if (pParamList == undefined || pParamList == null) {
      pParamList = [];
    }
    this.activeParamList = pParamList;
    if (this.activeParamListObservable == null || this.activeParamListObservable == undefined || this.activeParamListObserver == null || this.activeParamListObserver == undefined)
      this.activeParamListObservable = new Observable(observer => this.activeParamListObserver = observer).share();
    this.activeParamListObserver.next(pParamList);
  }

  updateCurrentIntentParamMap( pSelectedList : Array<Parameter>, pUnselectedList : Array<Parameter>) {
        let paramList = [];

        if ( !pSelectedList )
          pSelectedList = new Array<Parameter>();

        if ( !pUnselectedList )
          pUnselectedList = new Array<Parameter>();

        for ( var i = 0; i < pSelectedList.length; i++ ) {
          paramList.push( pSelectedList[i].paramType );
        }

        for ( var i = 0; i < pUnselectedList.length; i++ ) {
          paramList.push( pUnselectedList[i].paramType );
        }

        this.updateParamList(paramList);

        // this.selectedList = pSelectedList;
        // this.unSelectedList = pUnselectedList;
        //
        // if( !this.selectedListObservable || !this.selectedListObserver )
        //   this.selectedListObservable = new Observable( observer => this.selectedListObserver = observer ).share();
        // this.selectedListObserver.next(pSelectedList);
        //
        // if( !this.unSelectedListObservable || !this.unSelectedListObserver )
        //   this.unSelectedListObservable = new Observable( observer => this.unSelectedListObserver = observer ).share();
        // this.unSelectedListObserver.next(pUnselectedList);

  }

  // updateActiveParamMap(pParamMap: any) {
  //   if (pParamMap == undefined || pParamMap == null) {
  //     pParamMap = {};
  //   }
  //   this.activeParamMap = pParamMap;
  //   if (this.activeParamMapObserver == null || this.activeParamMapObserver == undefined || this.activeParamMapObservable == null || this.activeParamMapObservable == undefined)
  //     this.activeParamMapObservable = new Observable(observer => this.activeParamMapObserver = observer).share();
  //   this.activeParamMapObserver.next(pParamMap);
  //
  // }

  setIntentEdit(pEditMode: boolean) {
    this.intentEditMode = pEditMode;
    if (this.intentEditModeObserver == null || this.intentEditModeObserver == undefined || this.intentEditModeObservable == null || this.intentEditModeObservable == undefined)
      this.intentEditModeObservable = new Observable(observer => this.intentEditModeObserver = observer).share();
    this.intentEditModeObserver.next(pEditMode);
    this.newUserExpressions = new Array<UserExpression>();
    this.removedUserExpressions = new Array<UserExpression>();
  }

  getAllAgents() {
    return this.agentListObservable;
  }

  getActiveAgent() {
    return this.activeAgentObservable;
  }

  getActiveIntentList() {
    return this.getActiveIntentList;
  }

  getActiveIntent() {
    return this.activeIntentObservable;
  }

  createAgent(pAgent: Agent) {
    this.aiAlertService.setMessage("status", "Creating Agent " + pAgent.name);
    this.restService.createAgent(pAgent).subscribe(
      data => {
        if (data.statusCode == 0) {
          this.aiAlertService.setMessage("success", "Agent " + pAgent.name + ". Created successfully.")
          this.activeAgent = pAgent;
          this.serverLoadAgents();
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
      },
      error => {
        console.log(error);
      });
  }

  removeActiveAgent() {
    this.aiAlertService.setMessage("status", "Removing Agent " + this.activeAgent.name);
    this.restService.removeAgent(this.activeAgent).subscribe(
      data => {
        if (data.statusCode == 0) {
          this.aiAlertService.setMessage("success", "Agent " + this.activeAgent.name + " removed successfully.");
          this.activeAgent = null;
          this.serverLoadAgents();
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
      },
      error => {
        this.handleError(error);
      });
  }

  createIntent(pIntent: Intent) {
    pIntent.agentId = this.activeAgent.agentId;
    this.aiAlertService.setMessage("status", "Creating Intent " + pIntent.name);
    this.restService.createIntent(pIntent).subscribe(
      data => {
        if (data.statusCode == 0) {
          this.newIntentName = pIntent.name;
          this.aiAlertService.setMessage("success", "Intent " + pIntent.name + " created successfully.");
          this.getIntentsByAgentFromServer(this.activeAgent);
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
      },
      error => {
        //console.log("Intent creation failed : " + error);
      });
  }

  removeActiveIntent() {
    this.aiAlertService.setMessage("status", "Removing Intent " + this.activeIntent.name);
    this.restService.removeIntent(this.activeIntent).subscribe(
      data => {
        if (data.statusCode == 0) {
          this.aiAlertService.setMessage("success", "Intent " + this.activeIntent.name + " removed successfully.");
          this.updateActiveAgent(this.activeAgent);
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
      },
      error => {
        console.log(error);
      });
  }

  addUserExpression(pUserExpressionString: string) {
    let userExpression: UserExpression = new UserExpression();
    let existingUserExpression = this.activeUserExpressions.filter((userExpression: UserExpression) => userExpression.expression === pUserExpressionString.trim());

    if (existingUserExpression != null && existingUserExpression.length > 0)
      return false;
    userExpression.expression = pUserExpressionString.trim();
    userExpression.intentId = this.activeIntent.intentId;
    this.activeUserExpressions.unshift(userExpression);
    this.activeUserExpressionsObserver.next(this.activeUserExpressions);
    this.newUserExpressions.push(userExpression);
    this.isUserExpressionModified = true;
    return true;
  }

  removeUserExpression(pUserExpression: UserExpression) {
    var index = this.activeUserExpressions.indexOf(pUserExpression);
    if (index > -1) {
      this.activeUserExpressions.splice(index, 1);
      if (pUserExpression.userExpressionId == null) {
        var indexNewExpression = this.newUserExpressions.indexOf(pUserExpression);
        if (indexNewExpression > -1) {
          this.newUserExpressions.splice(indexNewExpression, 1);
        }
      } else {
        this.removedUserExpressions.push(pUserExpression);
      }
      this.isUserExpressionModified = true;
    }
    this.activeUserExpressionsObserver.next(this.activeUserExpressions)
  }

  removeUserExpressionById(pExpressionId: string) {
    var userExpressionToRemove = this.activeUserExpressions.filter((userExpression: UserExpression) => userExpression.userExpressionId === pExpressionId);
    var index = this.activeUserExpressions.indexOf(userExpressionToRemove[0]);
    this.removeUserExpressionByIndex(index);
  }

  removeUserExpressionByIndex(pElementIndex: number) {
    if (pElementIndex != null && pElementIndex >= 0 && pElementIndex < this.activeUserExpressions.length)
      this.activeUserExpressions.splice(pElementIndex, 1);
  }

  parametersModified(pSelectedParameters : Array<Parameter>, pUnselectedParameters : Array<Parameter>) {
    this.isParameterModifed = true;
    this.selectedList = pSelectedParameters;
    this.unSelectedList = pUnselectedParameters;
    //this.activeParamMap = pParamMap;
  }

  parametersChanged(parameters : Array<ParamField>) {
    this.isParameterModifed = true;
    this.updateParamList(parameters);
    //this.activeParamMap = pParamMap;
  }

  saveEditChanges(pActiveIntentName: string) {

    if (this.newUserExpressions.length > 0) {
      this.restService.createUserExpressions(this.newUserExpressions).subscribe(
        data => {
          if (data.statusCode == 0) {
            this.aiAlertService.setMessage("success", this.newUserExpressions.length + " new User Expressions Added");
            this.getIntentByIdFromServer(this.activeIntent);
          } else if (data.statusMessage == "Authentication required.") {
            this.navigateToLoginPage();
          } else {
            this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
          }
        },
        error => {
          console.log(error);
        });
    }

    if (this.removedUserExpressions.length > 0) {
      this.restService.deleteUserExpressions(this.removedUserExpressions).subscribe(
        data => {
          if (data.statusCode == 0) {
            this.aiAlertService.setMessage("success", this.removedUserExpressions.length + " new User Expressions Added");
            this.getIntentByIdFromServer(this.activeIntent);
          } else if (data.statusMessage == "Authentication required.") {
            this.navigateToLoginPage();
          } else {
            this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
          }
        },
        error => {
          console.log(error);
        });
    }

    if (this.isParameterModifed) {
      let parameterInfoVOList = [];
      for(var i = 0; i < this.activeParamList.length; i++){
        let i_param = this.activeParamList[i];
        // if ( !i_param.isAvailableParam ) {
            let obj: any = {};
              // obj.paramTypeId = i_param.paramTypeId;

              if ( i_param.intentId )
                obj.intentId = i_param.intentId;
              else
                obj.intentId = this.activeIntent.intentId;

                obj.paramValue = this.activeParamList[i].paramValue;
                obj.paramName =  this.activeParamList[i].paramName;

              // if ( i_param.fieldText )
              //   obj.fieldText = i_param.fieldText;

              // obj.paramList = [];
              // if (i_param.paramList) {
              //   for ( var j = 0, k=0; j < i_param.paramList.length; j++ ) {
              //     if (i_param.paramList[j].paramValue) {
              //       let objParamField : any = {};
              //       objParamField.paramFieldRelId = i_param.paramList[j].paramFieldRelId;
              //       objParamField.paramFieldId = i_param.paramList[j].paramFieldId;
              //       objParamField.paramValue = i_param.paramList[j].paramValue;
              //       if ( i_param.intentId )
              //         objParamField.intentId = i_param.intentId;
              //       else
              //         objParamField.intentId = this.activeIntent.intentId;
              //       obj.paramList[k] = objParamField;
              //       k++;
              //     }
              //   }
              // }



              parameterInfoVOList.push(obj);
        // }
      }
      if (parameterInfoVOList.length > 0) {
        // console.log(JSON.stringify(parameterInfoVOList));
        this.restService.updateParmeter(parameterInfoVOList).subscribe(
          data => {
            // console.log(data);
            if (data.statusCode == 0) {
              this.aiAlertService.setMessage("success", "Parameter changes saved successfully.");
              this.getIntentByIdFromServer(this.activeIntent);
            } else if (data.statusMessage == "Authentication required.") {
              this.navigateToLoginPage();
            } else {
              this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
            }
          },
          error => {
            console.log(error);
          });
      }
    }

    if (pActiveIntentName != null) {
      this.activeIntent.name = pActiveIntentName;
      this.restService.updateIntent(this.activeIntent).subscribe(
        data => {
          if (data.statusCode == 0) {
            this.getIntentsByAgentFromServer(this.activeAgent);
          } else if (data.statusMessage == "Authentication required.") {
            this.navigateToLoginPage();
          }
        },
        error => {

        });
    }
    this.setIntentEdit(false);
  }

  publishIntents() {
    this.aiAlertService.setMessage("status", "Publishing Intents ");
    this.restService.publishIntents().subscribe(
      data => {
        // console.log(data);
        if (data.statusCode == 0) {
          this.aiAlertService.setMessage("success", "Intents published successfully.");
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
      },
      error => {
        console.log(error);
      });
  }

  publishSelectedIntents(pIntentsSelected: Array<Intent>,pPublishEnvironment: string) {
    this.aiAlertService.setMessage("status", "Publishing Intents ");
    this.restService.publishSelectedIntents(pIntentsSelected, pPublishEnvironment).subscribe(
      data => {
        // console.log(data);
        if (data.statusCode == 0) {
          this.aiAlertService.setMessage("success", "Intents published successfully.");
          this.getIntentsforPublish(pPublishEnvironment);
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
      },
      error => {
        console.log(error);
      });
  }

  confirmPublishIntents() {
    this.aiAlertService.confirmDialog("Do you want to Publish the Intents ?", "Do you want to publish all modified Intents", "publishIntents" , null );
  }

  navigateIntent(pIntent : Intent) {
    if ( !this.isNavigable() ) {
      this.aiAlertService.confirmDialog("Do you want to leave the page ?", "Looks like you modified something in this Intent. Click No to continue on this intent. Click Yes to move to another intent or agent.", "getIntentByIdFromServer" , pIntent );
    } else {
      this.isParameterModifed = false;
      this.isUserExpressionModified = false;
      this.getIntentByIdFromServer( pIntent );
    }
  }

  navigateAgent( pAgent : Agent ) {
    if ( !this.isNavigable() ) {
      this.aiAlertService.confirmDialog("Do you want to leave the page ?", "Looks like you modified something in this Intent. Click No to continue on this intent. Click Yes to move to another intent or agent.", "updateActiveAgent" , pAgent );
      return false;
    } else {
      this.isParameterModifed = false;
      this.isUserExpressionModified = false;
      this.updateActiveAgent( pAgent );
      return true;
    }
  }

  navigatePublishIntents() {
    if ( !this.isNavigable() ) {
      this.aiAlertService.confirmDialog("Do you want to leave the page ?", "Looks like you modified something in this Intent. Click No to continue on this intent. Click Yes to Publish the intents.", "publishIntents" , null );
    } else {
      this.confirmPublishIntents();
    }
  }

  updateRootPath(pRootPath: string) {
    if (!this.rootPathObservable || !this.rootPathObserver) {
      this.rootPathObservable = new Observable( observer => this.rootPathObserver = observer ).share();
    }
    this.rootPath = pRootPath;
    this.restService.updateEngineURL(pRootPath);
    this.rootPathObserver.next(pRootPath);
  }

  updateCurrentUser(pUser: any) {
    if(!this.currentUserObservable || !this.currentUserObserver) {
      this.currentUserObservable = new Observable( observer => this.currentUserObserver = observer).share();
    }
    this.currentUser = pUser;
    this.currentUserObserver.next(pUser);
  }

  getRootPath() {
    return this.rootPath;
  }

  isNavigable() {
    if ( this.isParameterModifed || this.isUserExpressionModified )
      return false;
    else
      return true;
  }

  navigateToLoginPage() {
    this.router.navigate(['/login']);
  }

  getIntentsforPublish(pEnv: string) {
    this.restService.getIntentsforPublish(pEnv).subscribe(
      (data) => {
        if (data.statusCode == 0) {
          this.updatePublishableIntents(data);
          this.aiAlertService.clearAlertMessages();
        } else if (data.statusMessage == "Authentication required.") {
          this.navigateToLoginPage();
        } else {
          this.aiAlertService.setMessage("danger", data.errorCode + " : " + data.statusMessage);
        }
    },
    error => {
      console.log(error);
    });
  }

  updatePublishableIntents(pIntents: Array<Intent>) {
    if(!this.intentsPublishObservable || !this.intentsPublishObserver) {
      this.intentsPublishObservable = new Observable (observer => this.intentsPublishObserver = observer).share();
    }
    this.intentsToPublish = pIntents;
    this.intentsPublishObserver.next(pIntents);
  }

  /**
   * Comment for method handleError
   * methodName : handleError
   * accesibility : private
   * @param error
   * @returns Objservable.throw()
  */
  private handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    this.aiAlertService.setMessage("danger", errMsg);
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

}
