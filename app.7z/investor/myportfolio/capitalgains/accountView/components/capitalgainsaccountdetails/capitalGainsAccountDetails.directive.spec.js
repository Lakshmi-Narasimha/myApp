'use strict';

describe('Directive : Capital gains account details grid', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, cgAccDetModel;

    var cgAccData = {
        'foliodet': [{
            'fundName': 'Franklin India Pension Plan-GROWTH',
            'accountNo': '0100007823616',
            'purchase': {
                'fundWiseData': null,
                'txType': 'Purchase',
                'txDate': '2008-06-24 00:00:00.0',
                'indexedVal': '8797.27'
            },
            'redemption': {
                'txType': 'Switch Out',
                'txDate': '16 dec 2014',
                'amount': '9791.1'
            },
            'capital': {
                'shorterm': '993.83',
                'longterm': '4791.089025'
            },
            'taxded': {
                'total': '',
                'stt': '0'
            }
        },
        {
            'fundName': 'Franklin India Pension Plan-GROWTH',
            'accountNo': '0100007823616',
            'purchase': {
                'fundWiseData': null,
                'txType': 'Purchase',
                'txDate': '2008-06-24 00:00:00.0',
                'indexedVal': '8797.27'
            },
            'redemption': {
                'txType': 'Switch Out',
                'txDate': '16 dec 2014',
                'amount': '9791.1'
            },
            'capital': {
                'shorterm': '993.83',
                'longterm': '4791.089025'
            },
            'taxded': {
                'total': '',
                'stt': '0'
            }
        }]
    };
    cgAccDetModel = {
        getcgaccountdetails: function() {
            return cgAccData.foliodet
        }
    }

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('cgAccDetModel', cgAccDetModel);
        });
    });
    var getCompiledElement = function() {
        var element = angular.element('<ftic-capital-gain-ac-details></ftic-capital-gain-ac-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _cgAccDetModel_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            cgAccDetModel = _cgAccDetModel_;

            directiveEle = getCompiledElement();
            isolatedScope = directiveEle.isolateScope();
        });
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have selectedFundAccName from isolated scope', function() {
        expect(isolatedScope.selectedFundAccName).toBeDefined();
        expect(isolatedScope.selectedFundAccName[0].accountNo).toBe('0100007823616');
    });

    it('should have defined fundName and accountNumber from isolated scope', function() {
        expect(isolatedScope.fundName).toBe('Franklin India Pension Plan-GROWTH');
        expect(isolatedScope.accountNo).toBe('0100007823616');
    });

    it('should render data in the view', function() {
        expect(isolatedScope.selectedAccntDetails).toBeDefined();
        expect(isolatedScope.selectedAccntDetails[0].accountNo).toBe('0100007823616');
        expect(isolatedScope.selectedAccntDetails[0].fundName).toBe('Franklin India Pension Plan-GROWTH');
        expect(isolatedScope.selectedAccntDetails[0].capital).toBeDefined();
        expect(isolatedScope.selectedAccntDetails[0].purchase).toBeDefined();
        expect(isolatedScope.selectedAccntDetails[0].redemption).toBeDefined();
        expect(isolatedScope.selectedAccntDetails[0].taxded).toBeDefined();
    });

    it('should have defined columnDefs from isolated scope', function() {
        expect(isolatedScope.gridOptions.columnDefs).toBeDefined();
    });
});
