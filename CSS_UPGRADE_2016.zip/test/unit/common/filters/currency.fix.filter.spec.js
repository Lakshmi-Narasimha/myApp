'use strict';

/* jasmine specs for controllers go here */

describe('currencyFixFilter', function() {

	var currencyFixFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    currencyFixFilter = $injector.get('$filter')('currencyFix');
	}));

	//--- Test for definition

	it('should expect currencyFixFilter to be defined...', function(){
		expect(currencyFixFilter).toBeDefined();
	});

	//--- Test currency filter

	it('should format the given number with proper currency symbol...', function(){
		expect(currencyFixFilter('3789')).toEqual('$3,789.00');
	});

	it('should format the given number with proper currency symbol for invalid spaces...', function(){
		expect(currencyFixFilter('3789 ')).toEqual('$3,789.00');
	});

	it('should format the given negative number with proper currency symbol...', function(){
		expect(currencyFixFilter('-3789 ')).toEqual('-$3,789.00');
	});

});