/**
 *@ngdoc object
 *@name common.module:Proceed to Buy
 *@description
 * <p>
 * Calling the services those are for showing the pages
 * </p>
 */


'use strict';
module.exports = angular.module('common.proceedtobuy', [
	])
	// .config(require('./proceedtobuy.routes'))
	.controller('FundDetailsController', require('./funddetails/fundDetails.controller'))
	.controller('PaymentDetailsController', require('./paymentdetails/PaymentDetails.controller'))
	.controller('ReviewNConfirmController', require('./reviewnconfirm/reviewAndConfirm.controller'))
	.controller('TransactionDetailsController', require('./transactiondetails/TransactionDetails.controller'))
	.controller('FundDetailsLumpsumController', require('./funddetails/lumpsuminvestment/lumpsuminvestment.controller'))
	.controller('FundDetailsSipController', require('./funddetails/sipinvestment/sipinvestment.controller'))
	.controller('payment1Controller',require('./paymentdetails/payment1/lumpsumInvestment.controller'))
	.controller('payment2Controller',require('./paymentdetails/payment2/sipInvestment.controller'))
	.directive('fticReviewInvDtls',require('./reviewnconfirm/components/invDetails/investordetails.directive'))		
	.controller('TransactionDetailsSIPController', require('./transactiondetails/sipinvestment/TransactionDetailsSIP.controller'))
	.controller('TransactionDetailsLumpsumController', require('./transactiondetails/lumpsuminvestment/TransactionDetailsLumpsum.controller'))
	.controller('reviewLumpsumController', require('./reviewnconfirm/lumpsum/reviewLumpsum.controller'))
	.controller('reviewSipController', require('./reviewnconfirm/sip/reviewSip.controller'))
	.directive('fticFolioDetReviewConfirm', require('./reviewnconfirm/components/folioDetReviewConfirm/FolioDetReview.directive'))
	.directive('fticInvestmentPreferencesBuyReview', require('./reviewnconfirm/components/investPreferenceBuyReview/investmentPreferenceBuyReview.directive'))
	;