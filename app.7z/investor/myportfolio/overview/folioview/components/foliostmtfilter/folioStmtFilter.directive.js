/**
 * @ngdoc directive
 * @name folioStatementFilter
 * @description
 *
 * - It displays the compound filters view of the folio statements in statements tab of my investors page
 * 
 *
 **/
'use strict';

var folioStatementFilter = function(unitHolderModel, $filter, $timeout, panViewModel, invFolioDetailsModel, investorConstants, myportfolioConstants, fticDateUtils) {
    return {
        template: require('./folioStmtFilter.html'),
        restrict: 'E',
        replace: true,
        scope: {
            foliosArr: '='
        },
        controller: function($scope, $element, $attrs, $state) {

            var dateHolder = {},
                folioNoObj = {};

            $scope.sectionOptions = [];

            if (invFolioDetailsModel.getFolioAccountData()) {
                angular.forEach(invFolioDetailsModel.getFolioAccountData(), function(val) {
                    var folioObj = null;
                    folioObj = {
                        title: $filter('translate')(investorConstants.myportfolio.FOLIO_NO) + '. ' + val.folioId,
                        folioNumber: val.folioId
                    };
                    if ($state.params.folioNumber === val.folioId) {
                        $scope.selecteFolio = folioObj;
                    } else if (!$state.params.folioNumber && angular.lowercase(val.latestFolio) === 'y') {
                        $scope.selecteFolio = folioObj;
                    }
                    $scope.sectionOptions.push(folioObj);
                });

            }

            $scope.dateOptions = myportfolioConstants.panView.DATE_FILTER_OPT;
            $scope.allowValidation = true;
            $scope.errorMsgs = myportfolioConstants.overview.DATEPICKER_VAL_MSGS;
            $scope.dateRangeErrorMsgs = myportfolioConstants.overview.DATEPICKER_RANGE_VAL_MSGS;
            $scope.selectedObj = {};
            $scope.selectedObj.fullDate = fticDateUtils.getYesterday();

            $scope.validationObj = {};
            $scope.validationObj.isApply = false;
            $scope.validationObj.isDateLess = false;
            $scope.validationObj.isFromDate = false;
            $scope.hideSelect = true;

            $scope.$on('selectedOption', function(event, data) {
                folioNoObj.folioPanAccNo = data.folioNumber;
               
            });

            $scope.initFlag = true;
            $scope.$on('selectedValue', function(event, data) {
                $scope.validationObj.isDateLess = false;
                dateHolder = {};
                if (data.key !== null) {
                    dateHolder.dayFlag = data.key;
                }
                if ($scope.initFlag) {
                    $timeout(function() {
                        $scope.emitApply();
                        $scope.initFlag = false;
                        $scope.validationObj.isApply = false;
                    });
                }
            });

            $scope.$on('getdaterange', function(event, date1, date2) {
                dateHolder.fromDate = $filter('date')(date1, 'dd/MM/yyyy');
                dateHolder.toDate = $filter('date')(date2, 'dd/MM/yyyy');
            });

            $scope.$on('fticcmpFilterEvent', function(event, inputVal, inputType) {
                
                if (dateHolder.dayFlag === 'AD') {
                    
                    dateHolder.fromDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    dateHolder.toDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                } else if (dateHolder.dayFlag === 'DR') {
                    $scope.validationObj.isDateLess = false;
                    if (inputType === 'dtr1') {
                        dateHolder.fromDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                        
                    } else if (inputType === 'dtr2') {
                        dateHolder.toDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    }
                    $scope.both = dateHolder.fromDate;
                    $scope.validationObj.isDateLess =  fticDateUtils.checkValidDateRange(dateHolder.toDate, dateHolder.fromDate);
                    
                }

            });

            $scope.$on('getcurrentdate', function(event, date) {
                dateHolder.fromDate = $filter('date')(date, 'dd/MM/yyyy');
                dateHolder.toDate = $filter('date')(date, 'dd/MM/yyyy');
            });

            $scope.emitApply = function() {
                $scope.isDateValid = fticDateUtils.checkIsValidDate(dateHolder, $scope.validationObj.isDateLess);
                $scope.validationObj.isApply = true;
                if ($scope.isDateValid) {
                    $scope.validationObj.isApply = false;
                    var folioFilter = angular.merge({}, folioNoObj, dateHolder);
                    $scope.$emit('apply', folioFilter);
                }
            };

        }
    };
};

folioStatementFilter.$inject = ['unitHolderModel', '$filter', '$timeout', 'panViewModel', 'invFolioDetailsModel', 'investorConstants', 'myportfolioConstants', 'fticDateUtils'];
module.exports = folioStatementFilter;
