var communicationWizard = 'communication Wizard' || {};
communicationWizard = {
    init: function() {
        var that = this;
        that.bindEvents();
    },
    bindEvents: function() {
        var that = this,
        activeCommunicationFormField = $('.form-field');
        $('body').on('click','.communicationWidgetForm .communication-submit-btn',that.validateCommunicationForm)
        .on('keyup', '.form-field' ,that.enableSubmitButton);
    },
    captchaValidation : function(){
        var that = communicationWizard;
        that.enableSubmitButton();
        // $('body').on('click','.communicationWidgetForm .communication-submit-btn',that.validateCommunicationForm)
        // .on('keyup', '.form-field' ,that.enableSubmitButton);
    },
    enableSubmitButton: function() {
        var activeCommunicationForm = $('.communicationWidgetForm:visible'),
            totalValidationCount = 0 ,
            validationFieldCount = 0,
            formName,
            modalID;
        $('.form-field',activeCommunicationForm).each(function(index) {
            var isItRequiredField = $(this).prop("required"),
            fieldType = $(this).prop("type"),
            elementVal;
            if (isItRequiredField && (fieldType=='text'||fieldType=='textarea')) {
                totalValidationCount++;
                elementVal = $(this).val();
                if(elementVal.length >= 1){
                    validationFieldCount++;
                }
            }
        });
        modalID = $('.modal.fade.in.communications').prop('id');
        if(modalID == 'advisor'){
            if(totalValidationCount == validationFieldCount && grecaptcha.getResponse(advisorCaptcha).length > 0){
             $('.communication-submit-btn',activeCommunicationForm).prop('disabled', false);
            }
            else{
                 $('.communication-submit-btn',activeCommunicationForm).prop('disabled', true);
            }
        }
         else if(modalID == 'requestcallback'){
            if(totalValidationCount == validationFieldCount && grecaptcha.getResponse(callbackCaptcha).length > 0){
             $('.communication-submit-btn',activeCommunicationForm).prop('disabled', false);
            }
            else{
                 $('.communication-submit-btn',activeCommunicationForm).prop('disabled', true);
            }
         } else{
            if(totalValidationCount == validationFieldCount && grecaptcha.getResponse(speaktousCaptcha).length > 0){
             $('.communication-submit-btn',activeCommunicationForm).prop('disabled', false);
            }
            else{
                 $('.communication-submit-btn',activeCommunicationForm).prop('disabled', true);
            }
         }  
        
    },
    validateCommunicationForm: function(){
        var that = communicationWizard,
        isItValildForm = false,
        intrestedOptionObj=[],
        modalID,
        result,
        formFlag=true,
        //communicationFormDataObj = {},
        activeCommunicationForm = $('.communicationWidgetForm:visible');
        
        $('.form-field',activeCommunicationForm).each(function(index) {
            var elemId = $(this).attr("data-id"),
                elemVal = $(this).val(),
                isItRequiredField = $(this).prop("required"),
                fieldType = $(this).prop("type");
                $('.' + elemId + '-error').html('');
            if (isItRequiredField && (fieldType=='text'||fieldType=='textarea' || fieldType=='number')) {
                if (elemVal.length < 1) {
                    $('.' + elemId + '-error',activeCommunicationForm).html('Please fillout this field');
                    isItValildForm = false;
                    formFlag=false;
                } else {
                   var fieldValidationResult = that.validateEachField(elemId, elemVal);
                    if (!fieldValidationResult.status) {
                        $('.' + elemId + '-error',activeCommunicationForm).html(fieldValidationResult.errorMsg);
                        isItValildForm = false;
                        formFlag=false;
                    }else{
                        //communicationFormDataObj[elemId] = elemVal;
                        isItValildForm = true;
                    }
                }
            }else{
                if(fieldType=='text'||fieldType=='textarea' || fieldType=='number'){
                    if($(this).attr('email-validation')){
                        if($(this).val().length>0){
                            var fieldValidationResult = that.validateEachField(elemId, elemVal);
                            if (!fieldValidationResult.status) {
                                $('.' + elemId + '-error',activeCommunicationForm).html(fieldValidationResult.errorMsg);
                                isItValildForm = false;
                                formFlag=false;
                            }
                        }
                    }
                    else if($(this).attr('pan-validation')){
                        if($(this).val().length>0){
                            var fieldValidationResult = that.validateEachField(elemId, elemVal);
                            if (!fieldValidationResult.status) {
                                $('.' + elemId + '-error',activeCommunicationForm).html(fieldValidationResult.errorMsg);
                                isItValildForm = false;
                                formFlag=false;
                            }
                        }
                    }
                    //communicationFormDataObj[elemId] = elemVal;
                }else if(fieldType=='checkbox' || fieldType=='radio'){
                    if(fieldType=='checkbox'){
                        if($(this).prop("checked") == true){
                            var checkboxId = $(this).attr('id');
                            //intrestedOptionObj.push(elemVal);
                        }    
                    }else if(fieldType=='radio'){
                        //var gropName = $(this).attr('name');
                        //intrestedOptionObj[gropName] = $('['+gropName+']:checked').val();
                    }
                }
            }
        });
        modalID = $('.modal.fade.in.communications').prop('id');
        result=that.validateCaptcha(modalID);
        if(result == 'fail'){
            $('.captcha-error').html("Please validate Captcha.");
            $('.captcha-error').css('display','block');
            return false;
        } else if(result == 'pass'){
            $('.captcha-error').html("");
            $('.captcha-error').css('display','none');
        }
        if(formFlag){
            if(modalID == 'advisor'){
                that.advisorFormSubmition();
            }
            else if(modalID=='requestcallback'){
                that.requestCallBacnFormSubmition();
            }
            else if(modalID=='emailUsPopup'){
                that.speakToUsFormSubmition();  
            }
        }
        
    },
    validateCaptcha: function (modalID){
        var modalCaptcha;
        if(modalID == 'advisor'){
            if(grecaptcha.getResponse(advisorCaptcha).length == 0)
           {
            return "fail";
           }
           else{
            return "pass";
           }
        }else if(modalID=='requestcallback'){
             if(grecaptcha.getResponse(callbackCaptcha).length == 0)
           {
            return "fail";
           }
           else{
            return "pass";
           }
        }else if(modalID=='emailUsPopup'){
             if(grecaptcha.getResponse(speaktousCaptcha).length == 0)
           {
            return "fail";
           }
           else{
            return "pass";
           }
        }
        },
    validateEachField: function(elemId, elemVal) {
        var that = this;
        switch (elemId) {
            case "communicationUserName":
                var patt = new RegExp(that.regularExpression.communicationUserName),
                    returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'Please Enter a Valid user Name.'
                }
                break;
            case "communicationPanNumber":
                var patt = new RegExp(that.regularExpression.communicationPanNumber),
                    returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'Please Enter a Valid PAN Number.'
                }
                break;
            case "communicationPhoneNumber":
                var patt = new RegExp(that.regularExpression.communicationPhoneNumber);
                returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'Please enter Phone number in the correct format as shown below:<br/>Sample Mobile number 9999900000'
                }
                break;
                case "communicationCallBackPhoneNumber":
                var patt = new RegExp(that.regularExpression.communicationCallBackPhoneNumber);
                returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'Phone Number should not be exceed 12 digits'
                }
                break;
            case "communicationCityName":
                var patt = new RegExp(that.regularExpression.communicationCityName);
                returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'Please Enter a Valid City Name.'
                }
                break;
            case "communicationEmail":
                var patt = new RegExp(that.regularExpression.communicationEmail);
                returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'The format of the email address entered is not valid.'
                }
                break;
            case "communicationQuery":
                var patt = new RegExp(that.regularExpression.communicationQuery);
                returnedVal = patt.test(elemVal || '');
                return {
                    'status': returnedVal,
                    'errorMsg': 'Please Enter a Valid Query.'
                }
                break;
        }
    },
    regularExpression: {
        'communicationUserName': /^[A-Za-z0-9 ]{3,20}$/,
        'communicationPanNumber': /^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/,
        'communicationCallBackPhoneNumber': /^([0-9]){1,12}$/,
        'communicationPhoneNumber': /^\d{10}$/,
        'communicationCityName':/^[a-zA-Z]+(?:[\s-][a-zA-Z]+)*$/,
        'communicationEmail':/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i,
        // 'communicationQuery':/^[A-Za-z0-9? ]{3,200}$/
    },
    advisorFormSubmition:function(){
        var userDataSource ,formData ={} ,interets = [] ,guId,ajaxObject={},accessTokenCookie,that=this;
            guId = that.getCookie('guId');
            accessTokenCookie = that.getCookie('accessToken');
                userDataSource = $("#ask-for-advisor").attr('data-source');
                //event.preventDefault();
                // get the form data
                // there are many ways to get this data using jQuery (you can use the class or id also)
                $('input[name=interests]:checked').each(function(i){        
                 var values = $(this).val();
                 interets[i]=$(this).val();
                });
                //console.log(interets);
                //console.log(interets.join());
                var formData = {
                    'name'              : $('input[name=askAdvisor-username]').val(),
                    'mobile'            : $('input[name=askAdvisor-phonenumber]').val(),
                    'emailId'           : $('input[name=askAdvisor-email]').val(),
                    'city'              : $('input[name=askAdvisor-city]').val(),
                    'subscriptions'     : interets.join()
                };
               if(guId){
                    ajaxObject={
                         headers: {
                            "Authorization" : "Bearer "+ accessTokenCookie,
                            "Content-Type":"application/json"
                        },
                        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url         : userDataSource+"?guId="+guId, // the url where we want to POST
                        data        : JSON.stringify(formData), // our data object
                        dataType    : 'json', // what type of data do we expect back from the server
                        encode      : true,
                        success     :function(data){
                            $('#ask-for-advisor')[0].reset();
                            $('#ask-for-advisor').find('.floatLabels').removeClass('focused');
                            grecaptcha.reset(advisorCaptcha);
                            $('p.advisor-formsuccess-message').text('Thankyou! Your request has been registered. An Adviser will contact you within 24 business hours');
                            $('p.advisor-formsuccess-message').css('display','block')
                        },
                        error       :function(error){
                            $('p.advisor-formsuccess-message').text('Serever Error.Please try again after sometime.');
                            $('p.advisor-formsuccess-message').css('display','block')
                        }
                    }
                }else{
                    ajaxObject={
                         headers: {
                            "Content-Type":"application/json"
                        },
                        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url         : userDataSource, // the url where we want to POST
                        data        : JSON.stringify(formData), // our data object
                        dataType    : 'json', // what type of data do we expect back from the server
                        encode      : true,
                        success     :function(data){
                            $('#ask-for-advisor')[0].reset();
                            $('#ask-for-advisor').find('.floatLabels').removeClass('focused');
                            grecaptcha.reset(advisorCaptcha);
                            $('p.advisor-formsuccess-message').text('Thankyou! Your request has been registered. An Adviser will contact you within 24 business hours');
                            $('p.advisor-formsuccess-message').css('display','block')
                        },
                        error       :function(error){
                            $('p.advisor-formsuccess-message').text('Serever Error.Please try again after sometime.');
                            $('p.advisor-formsuccess-message').css('display','block')
                        }
                    }
                }
                // process the form
                $.ajax(ajaxObject);
                // stop the form from submitting the normal way and refreshing the page
                //event.preventDefault();
    },
    requestCallBacnFormSubmition:function(){
         var userDataSource ,formData ={},guId,ajaxObject={},accessTokenCookie,that=this;
            guId = that.getCookie('guId');
            accessTokenCookie = that.getCookie('accessToken');
                // get the form data
                // there are many ways to get this data using jQuery (you can use the class or id also)
                userDataSource = $("#request-callback").attr('data-source');

                //event.preventDefault();
               formData = {
                    'name'              : $('input[name=reqCallback-username]').val(),
                    'mobile'            : $('input[name=reqCallback-phonenumber]').val()
                };
                if(guId){
                    ajaxObject={
                         headers: {
                            "Content-Type":"application/json",
                            "Authorization" : "Bearer "+ accessTokenCookie
                        },
                        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url         : userDataSource+"?guId="+guId, // the url where we want to POST
                        data        : JSON.stringify(formData), // our data object
                        dataType    : 'json', // what type of data do we expect back from the server
                        encode      : true,
                        success     :function(data){
                            $('#request-callback')[0].reset();
                            $('#request-callback').find('.floatLabels').removeClass('focused');
                            grecaptcha.reset(callbackCaptcha);
                            $('p.reqCallBack-formsuccess-message').text('Thankyou! for your Call back request. Our Representative will call you within 24 business hours');
                            $('p.reqCallBack-formsuccess-message').css('display','block');
                        },
                        error       :function(error){
                            $('p.reqCallBack-formsuccess-message').text('Serever Error.Please try again after sometime.');
                            $('p.reqCallBack-formsuccess-message').css('display','block');
                        }
                    }
                }else{
                    ajaxObject={
                        headers: {
                            "Content-Type":"application/json"
                        },
                        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url         : userDataSource, // the url where we want to POST
                        data        : JSON.stringify(formData), // our data object
                        dataType    : 'json', // what type of data do we expect back from the server
                        encode      : true,
                        success     :function(data){
                            $('#request-callback')[0].reset();
                            $('#request-callback').find('.floatLabels').removeClass('focused');
                            grecaptcha.reset(callbackCaptcha);
                            $('p.reqCallBack-formsuccess-message').text('Thankyou! for your Call back request. Our Representative will call you within 24 business hours');
                            $('p.reqCallBack-formsuccess-message').css('display','block');
                        },
                        error       :function(error){
                            $('p.reqCallBack-formsuccess-message').text('Serever Error.Please try again after sometime.');
                            $('p.reqCallBack-formsuccess-message').css('display','block');
                        }
                    }
                }
                // process the form
                $.ajax(ajaxObject);
                // stop the form from submitting the normal way and refreshing the page
                //event.preventDefault();
    },
    speakToUsFormSubmition:function(){
         var userDataSource ,formData ={},guId,ajaxObject={},accessTokenCookie,that=this;
            guId = that.getCookie('guId');
            accessTokenCookie = that.getCookie('accessToken');
                userDataSource = $("#speak-to-us").attr('data-source');
                //event.preventDefault();
                //console.log($('p.mailId a').val());
                 formData = {
                    'name'              : $('input[name=speaktous-name]').val(),
                    'emailId'           : $('input[name=speaktous-email]').val(),
                    'panNumber'         : $('input[name=speaktous-pan]').val(),
                    'query'             : ($('textarea[name=speaktous-query]').val()).replace(/\?/g, "\'?\'")
                    
                };
                // process the form
                if(guId){
                    ajaxObject={
                         headers: {
                            "Authorization" : "Bearer "+ accessTokenCookie,
                            "Content-Type":"application/json"
                        },
                        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url         : userDataSource+"?guId="+guId, // the url where we want to POST
                        data        : JSON.stringify(formData), // our data object
                        dataType    : 'json', // what type of data do we expect back from the server
                        encode      : true,
                        success     :function(data){
                            $('#speak-to-us')[0].reset();
                            $('#speak-to-us').find('.floatLabels').removeClass('focused');
                            grecaptcha.reset(speaktousCaptcha);
                            $('p.speakToUs-formsuccess-message').text('Thank you! Your email has been sent to Franklin Templeton. A Franklin Templeton Service Representative will revert to your query within 24 business hours');
                            $('p.speakToUs-formsuccess-message').css('display','block');
                        },
                        error       :function(error){
                            $('p.speakToUs-formsuccess-message').text('Server Error.Please try again after sometime.');
                            $('p.speakToUs-formsuccess-message').css('display','block');
                        }
                    }
                }else{
                    ajaxObject={
                        headers: {
                            "Content-Type":"application/json"
                        },
                        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url         : userDataSource, // the url where we want to POST
                        data        : JSON.stringify(formData), // our data object
                        dataType    : 'json', // what type of data do we expect back from the server
                        encode      : true,
                        success     :function(data){
                            $('#speak-to-us')[0].reset();
                            $('#speak-to-us').find('.floatLabels').removeClass('focused');
                            grecaptcha.reset(speaktousCaptcha);
                            $('p.speakToUs-formsuccess-message').text('Thank you! Your email has been sent to Franklin Templeton. A Franklin Templeton Service Representative will revert to your query within 24 business hours');
                            $('p.speakToUs-formsuccess-message').css('display','block');
                        },
                        error       :function(error){
                            $('p.speakToUs-formsuccess-message').text('Server Error.Please try again after sometime.');
                            $('p.speakToUs-formsuccess-message').css('display','block');
                        }
                    }
                }
                $.ajax(ajaxObject);
                // using the done promise callback
                // stop the form from submitting the normal way and refreshing the page
                //event.preventDefault();
    },
    getCookie:function(name){
            var re = new RegExp(name + "=([^;]+)");
            var value = re.exec(document.cookie);
            return (value != null) ? unescape(value[1]) : null;
    }
};

(function($) {
    
        communicationWizard.init();
        $('body').on('click', 'a.chatEmailUs', function () {
            $('#communications-icons ul li:not(:first-child)').addClass('communicationIconHide');
            var activeLi = $('#communications-icons ul li').find('span.icon-fti_speakUs').parents('li');
                $(activeLi).addClass('activeLi');
         });
        $('body').on('click', '#emailUsPopup .icon-fti_close', function () {
            $('#communications-icons ul li').removeClass('communicationIconHide');
            var activeLi = $('#communications-icons ul li').find('span.icon-fti_speakUs').parents('li');
                $(activeLi).removeClass('activeLi');
        });
        $('body').on('click', '.activeLi', function () {
            $('#emailUsPopup').hide();
        });
         $('body').on('click', '#speaktous .icon-fti_close', function () {
            $('#communications-icons ul li').removeClass('communicationIconHide');
            var activeLi = $('#communications-icons ul li').find('span.icon-fti_speakUs').parents('li');
                $(activeLi).removeClass('activeLi');
        });
   
}(jQuery));