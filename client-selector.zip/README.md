
### Project Details


	Project description:			<Team lead should update project description>
	Team name:				<Team lead should update team name>
	Group email:				<Team lead should update group email (DL)>
	Primary contact:			<Team lead should list of primary email IDs [semi-colon {;} separated email IDs]> 

![Remove this line once you update project details](https://www.adflegal.org/WebResource.axd?d=N9RIA0QX1vnfuFOT7bWsL5c0nPWLh0jT55ek-KSnDjgYw1jmIIfB86jgiodd7NUmRiEVR0eOheUQNlPIAN19IHtnKU9f8pHZlZq1czjt4CafZY7PUYLc2V0f3qfglkuOLJwT4HkRFo6tiqU3pdO5ZqPOzSDCx80m61yT0ZMTVAgCItI_-10xdzWKhDQEVKgiCeRLdHo85zD3U5N-BhJJW3w6JIR_ZgHFZo6g2k0V4JM1&t=635768760520000000)	



##### Guidelines from Version Control team

###### What is the Pull Request Workflow?

[Pull Request](https://confluence.atlassian.com/bitbucketserver/using-pull-requests-in-bitbucket-server-776639997.html) in Bitbucket provide a team with a quick and easy way to review changes made on a branch, discuss those changes, and make further modifications before the branch is merged to master or your main development branch.
![](https://confluence.atlassian.com/bitbucketserver/files/776639997/818252858/2/1478563506702/BITBUCKETSERVER-PullRequestFlow.gif)


###### How is the access given to a Bitbucket Repository?

Access to a Bitbucket repository is based on Active Directory Group (AD group). Below is the access level for the AD groups:

	RW access:	AP-VCTRL-XXXX-DEVS 
	R  access:	AP-VCTRL-XXXX-ALL
	
Application team can fill the [Active Directory Group request form](https://invmaint15.i.ameriprise.com/sites/Requests/Lists/Active%20Directory%20Request/NewForm.aspx) to add or remove a user to AD group. Team contact: ActiveDirectory@ampf.com.
Please follow [knowledge document](https://collab.ampf.com/tech/Engineering/Tools/User%20Guides/Request%20Process/Active%20Directory%20Group%20request.docx) for more details on Active Directory Group request.


###### How do I clone a Bitbucket repository?

[GIT Bash](http://git-scm.com/)

Syntax: `git clone https://develop.ampf.com/bitbucket/scm/<project-key>/<repo-name>.git`

Example: 

	1. git clone https://develop.ampf.com/bitbucket/scm/sg/Bitbucket-help.git
	2. git clone https://<SSO-ID>@develop.ampf.com/Bitbucket/scm/sg/Bitbucket-help.git
	3. git clone https://<SSO-ID>:<SSO-pass>@develop.ampf.com/Bitbucket/scm/sg/Bitbucket-help.git

[Source Tree](http://sourcetreeapp.com/)

	1. Open SourceTree
	2. Click on "Clone/New" 
	3. Provide "Source Path/URL" as https://develop.ampf.com/bitbucket/scm/<project-key>/<repo-name>.git
	4. Authenticate by providing your SSO ID and Password. You can select Remember password option and click on Login.
	5. [Optional] Select Folder in Bitbucket
	6. Click on "Clone"

[Eclipse](http://www.eclipse.org/)

	1. Launch Eclipse
	2. Navigate to "Window-> Open Perspective -> Other.."
	3. Select "Git" and click OK
	4. Select "Clone a Git repository" from Git Repositories perspective
	5. Provide below details and click next.
		a. URI:						https://develop.ampf.com/bitbucket/scm/<project-key>/<repo-name>.git
		b. Host:					develop.ampf.com
		c. Repository path:			/bitbucket/scm/<project-key>/<repo-name>.git
		d. Protocol:			    https
		e. User:					<SSO-ID>
		f. Password:				<SSO-pass>
		g. Store in secure Store:	True [optional]
	6. Select Branch which you want to clone and click Next.
	7. On Local Destination page, provide Destination directory and click Finish to clone.


###### What is Branching Model in Bitbucket?

Bitbucket makes it easy for each member of your team to use a branching workflow for your Git development process. Your workflow can be mapped to branches in the Bitbucket 'branching model', allowing Bitbucket to:

	* guide your developers into making consistent naming decisions when creating branches.
	* identify the type of each branch and apply actions like automatic merging accordingly.
	
![](https://collab.ampf.com/tech/Engineering/Tools/Project%20Documents/Version%20Control/GIT-Branching.GIF)
	
For more details read [Branching Model](https://confluence.atlassian.com/bitbucketserver/using-branches-in-bitbucket-server-776639968.html).

	
###### What is Markdown Syntax for Bitbucket?
	
By default, Bitbucket uses Markdown as its markup language. You can read [Markdown Syntax guide](https://confluence.atlassian.com/bitbucketserver/markdown-syntax-guide-776639995.html) to use text formatting in the following places:

	* Any pull request's descriptions or comments, or
	* In README files (if they have the .md file extension).

###### Git Tutorial

* If you are new to GIT, you may read [GIT Tutorial](https://www.atlassian.com/git/tutorials/).
* You can also follow [GIT cheatsheet](http://ndpsoftware.com/git-cheatsheet.html#loc=workspace;) for quick reference.
* You can read [GIT pdf](https://progit2.s3.amazonaws.com/en/2016-03-22-f3531/progit-en.1084.pdf) or [GIT documentation](https://git-scm.com/book/en/v2) for detailed information.


	
###### What is the repository naming convention in Bitbucket?

We follow below naming convention for a Bitbucket Repository:

	* Repository name can have maximum 65 Characters.
	* Repository name cannot contain spaces.
	* Special characters are not allowed except `-`.
	* Repository name will always be in lowercase.
	* Repository name cannot start with a number or `-`.
	
Examples:

__Valid Repository Names__

	setool-test
	setools2015
		
__Invalid Repository Names__

	setools_test
	2015-setool-test
	-setoolsTest


###### What is the project naming convention in Bitbucket?

A Bitbucket project allow you to group repositories and to manage permissions for them in an aggregated way.
We follow below naming convention for a Bitbucket Project:

	* Project name can have maximum 28 Characters.
	* Project name can contain spaces.
	* Special characters are not allowed except `&`.
	* Characters will be in lower case except first character of each word.
	* Project name cannot start with a number or `&`.
	
Examples:

__Valid Project Names__

	SETools
	SharePoint2015
	Digital Technology
	Technology & Management
		
__Invalid Project Names__

	bitbuckethelp (First Character is not in upper case)
	UAT# Testing (special charter #)
	Digital Technology Management (>28 Characters)
	2014SETools (starts with a number)

	
###### How do I contact Version Control team for any query?
	
You may reach out to version.control@ampf.com.