// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PaymentBankListModelSchema = new mongoose.Schema({
    PaymentBankListResp: {
        type: Object,
        "default": {}
    }

});

var PaymentBankListModelLookUp = mongoose.model('PaymentBankListModelLookUp', PaymentBankListModelSchema);

var PaymentBankListModel = new PaymentBankListModelLookUp({
    PaymentBankListResp : {
            "neftDetails": [{
                "code": "Account Number",
                "value": "5050"
            }, {
                "code": "Account Type",
                "value": "Current"
            }, {
                "code": "Bank Name",
                "value": "CITIBANK"
            }, {
                "code": "Branch Name",
                "value": "Fort, Mumbai"
            }, {
                "code": "IFSC Code",
                "value": " CITI0100000"
            }, {
                "code": "Name",
                "value": "Franklin Templeton Mutual Fund"
            }],
            "paymentBankList": [{
                "bankName": "AXIS BANK",
                "directCredit": "Y",
                "eMandate": "Y",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "BANK OF INDIA",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "CANARA BANK",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "ING VYSYA BANK",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "SYNDICATE BANK",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "DEVELOPMENT CREDIT BANK",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
               "bankName": "CITY UNION BANK",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "DHANLAKSHMI BANK",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }, {
                "bankName": "DEVELOPMENT CREDIT BANK CORPORATE",
                "directCredit": "Y",
                "eMandate": "N",
                "neft": "Y",
                "netBanking": "Y"
            }]
    }
});

PaymentBankListModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PaymentBankListModelLookUp table, please contact admin...');
    } else {
        PaymentBankListModelLookUp.remove({}, function(err) {
            console.log('PaymentBankListModelLookUp collection removed');
            PaymentBankListModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PaymentBankListModelLookUp table, please contact admin...');
                }
                console.log('PaymentBankListModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PaymentBankListModelLookUp;