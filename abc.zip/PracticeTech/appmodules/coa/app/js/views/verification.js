coa = coa || {};
define(
		['jquery',
		  'underscore',
		  'backbone', 'text!appmodules/coa/app/templates/addressVerification.html',
				'config', 'appmodules/coa/app/js/utils', 'appcommon/globalcontext', 'Base64', 'text!appmodules/coa/app/templates/IUVerifyAddress.html', 'text!appmodules/coa/app/templates/IUDeleteMailingAddressTemplate.html', 'text!appmodules/coa/app/templates/IUNewMailingAddressTemplate.html', 'services/dataservice', 'appcommon/analytics'],
		function ($,
				_, Backbone, Template, Config, Utils, GlobalContext, Base64, IUVerifyAddressTemplate, IUDeleteMailingAddressTemplate, IUNewMailingAddresstemplate, DataService, Analytics) {
			var _htmlBaseString = '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1"><title></title><style type="text/css">body{font-size: 20px;}label{margin-right: 50px;width: 150px;display: inline-block;vertical-align: top;}.address,.address1{display: inline-block;}.address div,.address span{text-transform: capitalize;}.margin-top{margin-top: 5px;} .coa-margin-html{margin-top: 15px;}</style></head><body><h3>Change of Address Request</h3>';
			var BASE_URL = Config.odataServiceName, CLIENT_ID = null, FM_ID = Utils.readCookie('FMID'),
			queryString = GlobalContext.getInstance().getGlobalContext().Context.QueryString;
			queryString = queryString?queryString:'';
			coa.views.Verification = Backbone.View
					.extend({
						el : '#coa-app',
						template : _.template(Template),
						events : {
							'click #change-address-button' : 'gotoConfirmationPage',
							'click #back-to-validate-page,#m-back-to-validate-page' : 'gotoValidatePage',
							'click .verify-to-entry-button-container' : 'gotoAddressentryPage',
						},
						initialize : function() {
							this.$main = this.$('#user-info');
							$('.coa-step').removeClass('active');
							$('.coa-step.step3').addClass('active')
									.removeClass('finished');
						},
						render : function(updatedModel) {
							if (updatedModel) {
								this.model = updatedModel;
							}
							return this.$main.html(this.template(this.model
									.toJSON()));
						},
						clearView : function() {
							this.undelegateEvents();
							this.model.unbind('change', this.render, this);
						},
						gotoAddressentryPage : function(e) {							
							e.stopPropagation();
							e.preventDefault();
							$('.coa-step').removeClass('active');
							$('.coa-step.step1').addClass('active');
							$('.coa-step').removeClass('finished');
							coa.user.set('fromBackButton', true);
							if (coa.user.get('existingAddress')) {
								coa.user.set('newZip', '');
							}
							coa.Router.navigate('coa/home'+queryString, {
								trigger : true
							});
							if (coa.user.get('accounts').length == 0) {
								$('#use-existing-address , #future-start-end-date-container , #unassign-mailing-address, #new-mailing-address-account-contnr, #msg-mailing , #unassign-mail-address-info' ).addClass('hidden');
							}
						},
						gotoValidatePage : function(e) {
						    if (coa.user.get('addressType') == "Foreign" || coa.user.get('existingAddress') || coa.user.get('changeType') == "Verify" || (coa.user.get('changeType') == "Mailing" && coa.user.get('mailingType') == "delete")) {
								this.gotoAddressentryPage(e);
								return;
							}
							$('.coa-step.step3,.coa-step.step2').removeClass('finished');
							$('.coa-step').removeClass('active');
							$('.coa-step.step2').addClass('active');
							coa.Router.navigate('coa/validation'+queryString, {
								trigger : true
							});
						},
						gotoConfirmationPage: function () {
							if (coa.user.get('changeType') == "Verify") {
								Analytics.analytics.recordAction('COA:Verify address:clicked', Analytics.analytics.SHARED_SUITE);
							}
							if (coa.user.get('changeType') == "Mailing" && coa.user.get('mailingType') == "delete") {
								Analytics.analytics.recordAction('COA:Unassign mailing address:clicked', Analytics.analytics.SHARED_SUITE);
							}
							if (coa.user.get("futureStartEndate") == "yes" && coa.user.get("futureStartDate") != null) {
								Analytics.analytics.recordAction('COA:Future Start date selected', Analytics.analytics.SHARED_SUITE);
							}
							if (coa.user.get("futureStartEndate") == "yes" && coa.user.get("futureEndDate") != null) {
								Analytics.analytics.recordAction('COA:Future End date selected', Analytics.analytics.SHARED_SUITE);
							}

							var _today = new Date();
							var _time = _today.toTimeString().split(" ")[0]
									.split(":").splice(0, 2).join(":");
							var _hr = _today.getHours();
							var _mints = _today.getMinutes();
							_mints = _mints < 10 ? ('0' + _mints) : _mints;
							var _ntime = ((_hr == 12 || _hr == 0) ? 12
									: ((_hr % 12 < 10) ? ('0' + _hr % 12)
											: (_hr % 12)))
									+ ":" + _mints;
							var _pmam = _hr < 12 ? "am" : "pm";
							var _month = _today.getMonth() + 1, _year = _today
									.getFullYear(), _date = _today.getDate();
							var _zone, _zonet, _timeZone;
							if (navigator.appName == 'Microsoft Internet Explorer') {
								_zone = _today.toString().split(" ")[4];
								_timeZone = _zone;
							} else {
								_zone = _today.toString().split("(")[1];
								_zonet = _zone.substring(0, _zone.length - 1);
								_timeZone = coa.timeList[_zonet];

							}
							_submtdDatTme = _month + '/' + _date + '/' + _year
									+ " " + _ntime + " " + _pmam + " ";
							coa.user.set('submittedDateTime', _submtdDatTme);
                            this.createCase();
						},
						createCase: function () {
						    var _self = this;
							CLIENT_ID = coa.user.get('clId');
							var _base64Html = Base64.encode(this.createHtmlString());
							var _user = coa.user;
							var _changeType = _user.get('changeType'), _clients = _user
									.get('clients').toJSON(), _accnts = _user
									.get('accounts').toJSON(), _selectedClients = [], _selectedClientIds = [], _selectedAccounts = [], _selectedAccountIds = [];
							if (_changeType == 'Permanent') {
								_selectedClients = _clients.filter(function(
										clnt) {
									var _selected = clnt.checked;
									if (_selected) {
										_selectedClientIds.push({
											clId : clnt.clId
										});
									}
									return _selected;
								});
							} else if (_changeType == 'Mailing') {
							    if (_user.get("mailingType") == "delete") {
							        var _deleteAddressAccounts = _user.get('deleteAddressAccounts');
							        _deleteAddressAccounts.forEach(function (account, i) {
							            _selectedAccountIds.push({ acctId: account.accountId });
							        });
							    } else {
                                    _selectedAccounts = _accnts.filter(function (
										acct) {
									var _selected = acct.checked;
									if (_selected) {
										_selectedAccountIds.push({
										    acctId: acct.accountId
									});
									}
                                        return _selected;
                                    });
							    }
								
							} else if (_changeType == 'Verify') {
							    var _verifyAddressAccounts = _user.get('verifyAddressAccounts');
							    _verifyAddressAccounts.forEach(function (account, i) {
							        _selectedAccountIds.push({ acctId: account.accountId
							    });
							});
							    _clients.forEach(function (clnt, i) {
							        _selectedClientIds.push({ clId: clnt.clId
							    });
							});
							}

							var _data = {
								"caseOrigId" : "NA",
								"caseOrigRole" : "NA",
								"caseNotes" : null,
								"chnl" : "ChangeOfAddressTool",
								"addrUseCd" : '',
								"advsId" : null,
								"advsCtx" : null,
								"requestorId" : null,
								"specClAddrChgInd" : 'Y',
								"specAcctAddrChgInd" : null,
								"addrChgReasCd" : '',
								"oldAddrSeqNbr" : null,
								"oldAddrLn1Txt" : null,
								"oldAddrLn2Txt" : null,
								"oldAddrLn3Txt" : null,
								"oldAddrLn4Txt" : null,
								"oldAddrLn5Txt" : null,
								"oldRegnAreaCd" : null,
								"oldPostTownNm" : null,
								"oldPoCdTxt" : null,
								"oldSuperiorLocalityNm" : null,
								"oldCtryCd" : null,
								"newAddrLn1Txt" : "",
								"newAddrSeqNbr" : null,
								"newAddrLn2Txt" : null,
								"newAddrLn3Txt" : null,
								"newAddrLn4Txt" : null,
								"newAddrLn5Txt" : null,
								"newRegnAreaCd" : null,
								"newPostTownNm" : null,
								"newPoCdTxt" : null,
								"newSuperiorLocalityNm" : null,
								"newCtryCd" : null,
								"docData" : null,
								"accounts" : null,
								"clients": null,
								"newAddrStatCd": null,
								"oldAddrStatCd": null,
								"newAddrSttDt": null,
								"newAddrEndDt": null,
								"caseTypDetail": {
								    "function": "Client Administration", "topic": "Address Updates", "subtopic": "Address"
								}
							};
							_data.docData = _base64Html;
							_data.advsId = _user.get('submitterId');
							_data.addrChgReasCd = _user.get('changeReason') ? _user.get('changeReason') : "Other";
							if (_changeType == 'Verify') {
							    var _verifyAddressType = _user.get('verifyAddressType'),
                                    _selectedAddress = _user.get('address').toJSON().find(function (data, i) { return data.addrSeqNum == _user.get('verifyAddresSeqNum'); });
							    _data.addrUseCd = _verifyAddressType;
							    _data.newAddrSeqNbr = _selectedAddress.addrSeqNum;
							    _data.oldAddrLn1Txt = _data.newAddrLn1Txt = _selectedAddress.addrLn1;
							    _data.oldAddrLn2Txt = _data.newAddrLn2Txt = _selectedAddress.addrLn2 ? _selectedAddress.addrLn2 : null;
							    _data.oldAddrLn3Txt = _data.newAddrLn3Txt = _selectedAddress.addrLn3 ? _selectedAddress.addrLn3 : null;
							    _data.oldPostTownNm = _data.newPostTownNm = _selectedAddress.ctyNm;
							    _data.oldPoCdTxt = _data.newPoCdTxt = _selectedAddress.postlCd;
							    _data.oldRegnAreaCd = _data.newRegnAreaCd = _selectedAddress.stCd;
							    if (_verifyAddressType == 'Permanent') {
							        _data.oldAddrSeqNbr = _selectedAddress.addrSeqNum;
							        var _cntryCd = _selectedAddress.cntryCd, _cntryNm = _selectedAddress.cntryNm;
							        _cntryCd = _cntryCd ? _cntryCd : "";
							        _cntryNm = _cntryNm ? _cntryNm : "";
							        if (_cntryCd == null || _cntryCd.toLowerCase() == 'us' ||_cntryCd ==  "?" ||
                                        _cntryCd.toLowerCase() == 'usa' || _cntryCd == "" || _cntryNm.toLowerCase() == "usa") {
							            _data.oldCtryCd = _data.newCtryCd = null;
							        } else {
							            _data.oldCtryCd = _data.newCtryCd = _selectedAddress.cntryCd;
							            _data.oldSuperiorLocalityNm = _data.newSuperiorLocalityNm = _selectedAddress.cntryNm;
							        }
							        _data.specAcctAddrChgInd = 'N';
							        _data.specClAddrChgInd = 'Y';
							        if (_selectedClientIds.length > 0) {
							            _data.specClAddrChgInd = 'Y';
							            _data.clients = _selectedClientIds;
							        }
							    } else {
							        _data.oldCtryCd = _data.newCtryCd = null;
							        _data.specClAddrChgInd = 'N';
							        _data.specAcctAddrChgInd = 'Y';
							        _data.accounts = _selectedAccountIds;
							    }
							    _data.oldAddrStatCd = "Undeliverable"
							} else {
							    _data.addrUseCd = _user.get('changeType');
							    if (_user.get('changeType') == 'Mailing' && _user.get('mailingType') == 'delete') {
							        var _permantAddress = coa.user.get("address").toJSON()[0];
							        _data.newAddrLn1Txt = _permantAddress.addrLn1 ? _permantAddress.addrLn1: null;
							        _data.newAddrLn2Txt = _permantAddress.addrLn2 ? _permantAddress.addrLn2: null;
							        _data.newAddrLn3Txt = _permantAddress.addrLn3 ? _permantAddress.addrLn3: null;
							        _data.newPostTownNm = _permantAddress.ctyNm ? _permantAddress.ctyNm : null;
							        _data.newRegnAreaCd = _permantAddress.stCd;
							        _data.newAddrSeqNbr = _permantAddress.aadrSeqNum;
							        _data.newPoCdTxt = _permantAddress.postlCd;
							        var _deletingAddress = _user.get("address").toJSON().find(function (addrs, index) {
                                        if(_user.get('deleteAddresSeqNum') == addrs.addrSeqNum) {
                                                return addrs;
							            }
							        });

                                    _data.oldAddrLn1Txt = _deletingAddress.addrLn1 ? _deletingAddress.addrLn1: null;
							        _data.oldAddrLn2Txt = _deletingAddress.addrLn2 ? _deletingAddress.addrLn2: null;
							        _data.oldAddrLn3Txt = _deletingAddress.addrLn3 ? _deletingAddress.addrLn3: null;
							        _data.oldAddrSeqNbr = _deletingAddress.aadrSeqNum;
							        _data.oldRegnAreaCd = _deletingAddress.stCd;
							        _data.oldPostTownNm = _deletingAddress.ctyNm;
							        _data.oldPoCdTxt = _deletingAddress.postlCd;

                                    _data.specClAddrChgInd = 'N';
                                    _data.specAcctAddrChgInd = 'Y';
                                    _data.accounts = _selectedAccountIds;
							    } else {
							            _data.newAddrLn1Txt = _user.get('addressLine1') ? _user.get('addressLine1'): null;
							            _data.newAddrLn2Txt = _user.get('addressLine2') ? _user.get('addressLine2'): null;
							            _data.newAddrLn3Txt = _user.get('addressLine3') ? _user.get('addressLine3'): null;
							            _data.newPostTownNm = _user.get('newCIty');

							            if (_user.get('changeType') == 'Permanent') {
							                if (_user.get('addressType') == "Foreign") {
							                    _data.newCtryCd = _user.get('newCountry');
							                    _data.newSuperiorLocalityNm = _user.get('newCountryName');
							                    if (_user.get('newCountry') == "CA") {
							                        _data.newRegnAreaCd = _user.get('newProvince');
							                        _data.newPoCdTxt = _user.get('newZip');
							                        }
							            } else {
							                    _data.newRegnAreaCd = _user.get('newState');
							                    _data.newPoCdTxt = _user.get('newZip');
							                    }
							                var _oldAddress = coa.user.get('address').toJSON()[0];
							                _data.oldAddrLn1Txt = _oldAddress.addrLn1 ? _oldAddress.addrLn1: null;
							                _data.oldAddrLn2Txt = _oldAddress.addrLn2 ? _oldAddress.addrLn2: null;
							                _data.oldAddrLn3Txt = _oldAddress.addrLn3 ? _oldAddress.addrLn3: null;
							                _data.oldAddrSeqNbr = _oldAddress.aadrSeqNum;
							                _data.oldRegnAreaCd = _oldAddress.stCd;
							                _data.oldPostTownNm = _oldAddress.ctyNm;
							                _data.oldPoCdTxt = _oldAddress.postlCd;
							                _data.oldCtryCd = _oldAddress.cntryCd;

							                _data.specAcctAddrChgInd = 'N';
							                _data.specClAddrChgInd = 'Y';
							                if (_selectedClients.length > 0) {
							                    _data.specClAddrChgInd = 'Y';
							                    _data.clients = _selectedClientIds;
							                    }
							                    } else {
							                _data.newRegnAreaCd = _user.get('newState');
							                _data.newPoCdTxt = _user.get('newZip');
							                if (_user.get('existingAddress')) {
							                    _data.newAddrSeqNbr = _user.get('addressSeqNum');
							                    }
							                if (_user.get("mailingType") == "new") {
							                    var _startDate = _user.get("futureStartDate"), _endDate = _user.get("futureEndDate");
							                    if (_startDate) {
							                        _data.newAddrSttDt = moment(_startDate).format("YYYY-MM-DD");
							                        _data.caseTypDetail.subtopic = "Seasonal or Temporary";
							                }
							                    if (_endDate) {
							                        _data.newAddrEndDt = moment(_endDate).format("YYYY-MM-DD");
							                        _data.caseTypDetail.subtopic = "Seasonal or Temporary";
                                                   
							                    }
							                    }							                       
                                                    _data.specClAddrChgInd = 'N';
                                                    _data.specAcctAddrChgInd = 'Y';
                                                    _data.accounts = _selectedAccountIds;
                                                    }
                                }
							    
							}
							Utils.lockForm();
							if (coa.user.get('caseId')) {
							    _data.caseNotes = [{ "caseNote": "The processing of a previous Change of Address case created this additional case." }];
							   }
							var _url = BASE_URL+ "Clients(id='"+CLIENT_ID+ "',ctx='COLA.CL')/createChangeClientAddressCase?$format=json";
							Utils.post(_url, JSON.stringify(_data), function (resp,status,xhr) {
							        var _respInfo = resp.d;
							        if (resp && _respInfo && _respInfo.status && _respInfo.status.statCd == "0000" && _respInfo.caseInfo && _respInfo.caseInfo.caseId != "") {
							            $('.coa-step.step4').addClass('active');
							            $('.coa-step.step3').removeClass('active').addClass('finished');
							            coa.user.set('submittedDateTime', _submtdDatTme);
							            var _caseId = coa.user.get('caseId')
							            if (_caseId) {
							                _self.closeExistingCase(_caseId);
							            } else {
							                Utils.unlockForm();
							                coa.Router.navigate('confirm' + queryString, {
							                    trigger: true
							                });
							            }

							        } else {
							            Utils.showSystemUnavailabelError(xhr);
							        }
								}, function(xhr) {
									Utils.unlockForm();
									Utils.showSystemUnavailabelError(xhr,true);
								}, 0);
							// pass max age 0
						}, closeExistingCase: function (caseId) {
						    var _payload = {
						        "coreCommonInfo": {
						            "eWorkflowReqId": caseId,
						            "function": "Client Administration",
						            "topic": "Address Updates",
						            "subTopic": "Seasonal or Temporary",
						            "chnl": "ChangeOfAddressTool"
						        },
						        "closeBusinessSpecific": {
						            "busEvnt": "Withdrawn",
						            "closeInd": "true",
						            "closureReasDesc": "This case was withdrawn. A new Change of Address case was created to complete the request."
						        }
						    }
						    DataService.updateEWorkflowCase(caseId, _payload).then(function (response) {
						        Utils.unlockForm();
						        if (!(response && response.d && response.d.statCd == "0000")) {
						            coa.user.set("eworkflowCaseCloseFailed", true);
						        }
						        coa.Router.navigate('confirm' + queryString, {
						            trigger: true
						        });
						    }).fail(function (xhr) {
						        Utils.unlockForm();
						        coa.user.set("eworkflowCaseCloseFailed", true);
						        coa.Router.navigate('confirm' + queryString, {
						            trigger: true
						        });
						    });
						},
						createHtmlString : function() {
							var _user = coa.user.toJSON();
							var _htmlString = _htmlBaseString;
							if (_user.changeType == "Permanent") {
								_htmlString += this.createPmntHtmlStrng();
							} else if (_user.changeType == "Mailing") {
							    if (_user.mailingType == "new") {
							        _htmlString += this.createMalngHtmlStrng();
							    } else {
							        _htmlString += this.createMalngDeleteHtmlStrng();
							    }
								
							} else if (_user.changeType == "Verify") {
							    _htmlString += this.createVerifyHtmlStrng();
							}
							console.log(_htmlString, "_htmlString");
							return _htmlString;
						},
						createPmntHtmlStrng : function() {
							var _user = coa.user.toJSON();
							var _htmlString = '';
							_htmlString += '<div class="margin-top"><label>Submitted time</label><div class="address1"><span>'
									+ _user.submittedDateTime
									+ '</span></div></div>';
							_htmlString += '<div class="margin-top"><label>Submitted by</label><div class="address"><span>'
									+ _user.submitterId + '</span></div></div>';
							
							_htmlString += '<div class="margin-top"><label>Client name</label><div class="address"><span>'
									+ coa.user.get('name').toLowerCase()
									+ '</span></div></div>';
							
							_htmlString += '<div class="margin-top"><label>Client ID</label><div class="address"><span>'
									+ coa.user.get('id')
									+ '</span></div></div>';

							var _clients = _user.clients;
							for ( var i = 0; i < _clients.length; i++) {
								var _client = _clients[i];
								if (_client.checked) {
									
									_htmlString += '<div class="margin-top"><label>Client name</label><div class="address"><span>'
											+ _client.fName.toLowerCase() + ' ';
									if (_client.mName) {
										_htmlString += _client.mName
												.toLowerCase()
												+ ' ';
									}
									_htmlString += _client.lName.toLowerCase()
											+ '</span></div></div>';
									
									_htmlString += '<div class="margin-top"><label>Client ID</label><div class="address"><span>'
											+ _client.id
											+ '</span></div></div>';
								}
							}
							_htmlString += '<hr>';
							
							var _currAddres = _user.address[0];
							_htmlString += '<div class="margin-top"><label>Address</label><div class="address"><div>'
									+ "Current"
									+ '</div>'
									+ '<div>'
									+ _currAddres.addrLn1.toLowerCase()
									+ '</div>';
							if (_currAddres.addrLn2) {
								_htmlString += '<div>'
										+ _currAddres.addrLn2.toLowerCase()
										+ '</div>';
							}
							if (_currAddres.addrLn3) {
								_htmlString += '<div>'
										+ _currAddres.addrLn3.toLowerCase()
										+ '</div>';
							}
							_htmlString += '<div>'
									+ _currAddres.ctyNm.toLowerCase() + ', '
									+ _currAddres.stCd + ' '
									+ _currAddres.postlCd + '</div>';
							_htmlString += '</div></div>';
							
							_htmlString += '<div class="coa-margin-html"><label></label><div class="address "><div>'
									+ "New"
									+ '</div>'
									+ '<div>'
									+ _user.addressLine1.toLowerCase()
									+ '</div>';
							if (_user.addressLine2) {
								_htmlString += '<div>'
										+ _user.addressLine2.toLowerCase()
										+ '</div>';
							}
							if (_user.addressLine3) {
								_htmlString += '<div>'
										+ _user.addressLine3.toLowerCase()
										+ '</div>';
							}
							if (_user.addressType == "U.S") {
								_htmlString += '<div>'
										+ _user.newCIty.toLowerCase() + ', '
										+ _user.newState + ' ' + _user.newZip
										+ '</div>';
							} else {
								if (_user.newCountry == "CA") {
									_htmlString += '<div>'
											+ _user.newCIty.toLowerCase()
											+ ' '
											+ _user.newProvince
											+ ', '
											+ _user.newCountryName
													.toLowerCase() + ' '
											+ _user.newZip + '</div>';
								} else {
									_htmlString += '<div>'
											+ _user.newCIty.toLowerCase()
											+ ', '
											+ _user.newCountryName
													.toLowerCase() + '</div>';
								}

							}
							_htmlString += '</div></div>';
							_htmlString += '<div class="coa-margin-html"><label>Change type</label><div class="address"><span>'
									+ _user.changeType + '</span></div></div>';
							if (_user.userType == "P") {
								_htmlString += '<div class="margin-top"><label>Change reason</label><div class="address"><span>'
										+ _user.changeReason
										+ '</span></div></div>';
							}

							_htmlString += '</body></html>';
							return _htmlString;
						},
						createMalngHtmlStrng : function() {
						    var _newMailingAddressHtml = _.template(IUNewMailingAddresstemplate);
						    var _compiledIUTemplate = _newMailingAddressHtml({ "user": this.model.toJSON()});
						    _compiledIUTemplate += '</body></html>';
						    return _compiledIUTemplate;
						},
						createVerifyHtmlStrng: function () {
						    var _verifyAddressTemplate = _.template(IUVerifyAddressTemplate);
						    var _compiledIUTemplate = _verifyAddressTemplate(this.model.toJSON());
						    _compiledIUTemplate += '</body></html>';
						    return _compiledIUTemplate;
						},
						exitApp : function() {
							$('#coa-cancel-modal').modal('show');
						},
						createMalngDeleteHtmlStrng: function () {
						    var _deletMailingAddressHtml = _.template(IUDeleteMailingAddressTemplate);
						    var _compiledIUTemplate = _deletMailingAddressHtml(this.model.toJSON());
						    _compiledIUTemplate += '</body></html>';
						    return _compiledIUTemplate;
						}

					});
		});