/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function InvTransactionDetailsController($scope, invTransactionDetailsFactory, $stateParams, $window, $location) {

    console.info('InvTransactionDetailsController Controller!!');
    $scope.transactHeading = {
        heading: 'Transaction Details'
    };
    $scope.showTransactionDetails = true;
    // console.log($stateParams.stateType);
        // if($stateParams.stateType === '/swp') {
        //     $scope.type = 'swp';
        //     $scope.headerText = 'SWP Details';

    var queryParams = $location.search();

    if (queryParams.hasOwnProperty('successFlag')) {
        // authenticationService.setUser({ 'guId': queryParams.guId });
        if (queryParams.successFlag === 'true') {
            // $scope.getTxnDetatils();
            invTransactionDetailsFactory.dataSetter.call($scope, $stateParams.stateType);
        } else if (queryParams.successFlag === 'false') {
            // $scope.showTransactionDetails = false;
            if (queryParams.retryFlag === 'false') {
                $scope.showTransactionDetails = false;
                $scope.errorMsg = queryParams.errorDescription;

            } else if (queryParams.retryFlag === 'true') {
                $scope.params = {
                    webRefNo: queryParams.webRefNo,
                    guId: queryParams.guId
                };
                invTransactionDetailsFactory.setBuyNewFolioDetails(queryParams);
            }
        }
    } else {
        if ($stateParams.stateType === 'dtp') {
            invTransactionDetailsFactory.dtpDateSetter.call($scope, $stateParams.stateType);
        } else {
            invTransactionDetailsFactory.dataSetter.call($scope, $stateParams.stateType);
        }
    }

    //}

    $scope.windowPrint = function() {
        window.print();
    };

    $scope.saveTransaction = function() {
/*
        if ($stateParams.stateType === 'dtp') {
            invTransactionDetailsFactory.callDtpPDFService($scope.type);
        } else {*/
            invTransactionDetailsFactory.callPDFService($scope.type);
        //}
    };
}

InvTransactionDetailsController.$inject = ['$scope', 'invTransactionDetailsFactory', '$stateParams', '$window', '$location'];
module.exports = InvTransactionDetailsController;
