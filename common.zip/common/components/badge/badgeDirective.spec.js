/* eslint-disable */
'use strict';

describe('Directive : Badge',function(){
	var compile, scope, compiledEle;
	beforeEach(angular.mock.module('advisor'));
	beforeEach(function(){
		angular.mock.inject(function($compile,$rootScope){
			scope =$rootScope.$new();
			compile = $compile;
		})		
		var element = '<ftic-badge></ftic-badge>'
		compiledEle = compile(angular.element(element))(scope)		
		scope.$digest();
	})

	it('should be defined',function(){
		expect(compiledEle).toBeDefined();
	})

	it('should have isolated scope',function(){
		expect(compiledEle.isolateScope()).toBeDefined();
	})

})