var config = {
    loggedInUserId: "54631",
    loggedInUserType: "advisor"
};

module.exports = config;