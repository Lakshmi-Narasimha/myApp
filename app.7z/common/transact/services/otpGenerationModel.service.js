/**
 * @ngdoc property
 * @name paperLessModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - paperLessModel is a service model which consists the list of services required for paper less module.
 *
 **/
'use strict';


var otpModel = function(Restangular, $q, fticLoggerMessage, loggerConstants) {

    var  _otpDetails = null;
    var otpDetailsModel = {

        fetchOtpDetails : function (searchQuery) {
            var deferred = $q.defer();
            Restangular.all('/ekycOTPGeneration').getList(searchQuery).then(function (otpDetails) {
                deferred.resolve(otpDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setOtpDetails : function(otpDetails){
        	_otpDetails = otpDetails;
        	return _otpDetails;
        },   
        getOtpDetails : function(){
        	return _otpDetails;
        },     
    };

    return otpDetailsModel;

    
};

otpModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = otpModel;
