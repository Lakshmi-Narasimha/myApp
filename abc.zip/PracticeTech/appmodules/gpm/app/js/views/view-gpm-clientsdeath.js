﻿define(['jquery',
    'underscore',
    'backbone',
    'appcommon/analytics',
    'spinner',
    'appcommon/commonutility',
    'appcommon/globalcontext',
    'appcommon/constants',
    'appcommon/data',
    'appcommon/commonutility',
    'appmodules/ncst/app/data/country-list',
    'services/dataservice',
    'appmodules/gpm/app/js/utils',
    'appmodules/nav/app/models/contactdetails',
    'appmodules/crm/app/models/contactpickerdatasource',
    'appmodules/crm/app/views/contactpickerview',
    'text!appmodules/gpm/app/templates/gpmreportclientsdeath.html',
	'text!appmodules/gpm/app/templates/gpmphoneInfofordeath.html',
	'text!appmodules/gpm/app/templates/gpmaddressInfofordeath.html'
], function ($, _, Backbone, Analytics, Spinner,CommonUtils, GlobalContext, Constants, GPMData, Utility, StateList, DataService, Utils, AppContactDetails, ContactPickerDataSource, ContactPickerView, ReportClientsDeathTemplate, PhoneDeathTemplate, AddressDeathTemplate) {
        var self = null;
        //var app_state = new ContactPickerView();
        var clientsdeath = Backbone.View.extend({
        el: $("#gpm-form-update-field-container"),
        id: 'gpm-form-update-field-container',
        originalContactNames: [],  // if edit
        isEdit: false,
        contactPickerView: null,
        template: _.template(ReportClientsDeathTemplate),
        events: {
            "keypress .contactFirstName,.contactLastName": "checkForNumber",
        },
        initialize: function (data) {
            self = this;
            this.data = data;
            this.isEntity = false;
			var that = this;

            /* Dynamic Containers */
            this.$indiContactContainer = this.$("#individual-contact-details");
            this.$indiOrgCommonContainer = this.$("#indi-org-common-container");
            this.$indiContainer = this.$("#indi-container");
            //this.$clientProspectsYesOpt = this.$("#client-or-prospects-yes");

            $(document).off('click', '#add-client-prospect-no-btn, #add-client-prospect-yes-btn').on('click', '#add-client-prospect-no-btn, #add-client-prospect-yes-btn', function (e) {
                that.validateCliProsYes(e);
            	Analytics.analytics.recordAction('ClientDeathAddAnother:clicked');
            });
			$(document).off('click', '.del-ctn').on('click', '.del-ctn', function(e) {
			 that.deleteContact(e);
			});
			$(document).off('click', '#section-clientsdeath .pt-contact-picker-name-clear-icon').on('click', '#section-clientsdeath .pt-contact-picker-name-clear-icon', function (e) {
			    //that.hideContTypeRelationship(e);
			    that.hideIndiContactDetails(e);
			});
			$(document).off('click', '#pt-contact-picker-overlay').on('click', '#pt-contact-picker-overlay', function (e) {
			    that.handleContactPickerModalClick(e);
			});
			$(document).off('keyup paste copy cut', '#section-clientsdeath .pt-contact-picker > input').on('keyup paste copy cut', '#section-clientsdeath .pt-contact-picker > input', function (e) {
			    that.checkSearchInput(e);
			});
			$(document).off('click', 'input[name="pt-deathdate-radio-grp"]').on('click', 'input[name="pt-deathdate-radio-grp"]', function (e) {
			 that.handleDeathDateOpt(e);
			 });
			$(document).off("change", "input[name='pt-contact-type-radio-group']").on("change", "input[name='pt-contact-type-radio-group']", function (e) { that.toggleRadioClassActive(e) });
			$(document).off("keyup", "input[pt-contact-picker-text-input='pt-cli-death-contact']").on("keyup", "input[pt-contact-picker-text-input='pt-cli-death-contact']", function (e) { that.toggleContTypRelationship(e) });
			$(document).off("click", ".iscontactNotify").on("click", ".iscontactNotify", function (e) { that.toggleContactNotification(e) });
			$(document).off("click", ".isContactClient").on("click", ".isContactClient", function (e) { that.toggleContactClient(e) });
			$(document).off("change", "input[name='contact-address-radio-group']").on("change", "input[name='contact-address-radio-group']", function (e) { that.toggleRadioContactAddress(e) });
			$(document).off("change", "input[name='contact-phone-radio-group']").on("change", "input[name='contact-phone-radio-group']", function (e) { that.toggleRadioPhoneNumbers(e) });
            //commenting events as callback enabled for slectionComplete
            //$(document).off('click', '#pt-cli-contact-name ul.pt-contact-picker-result-pane li').on('click', '#pt-cli-contact-name ul.pt-contact-picker-result-pane li', function (e) {
			//    that.checkSearchInputKeyPress(e);
			//});
			//$(document).off('keydown', '#pt-cli-contact-name .pt-contact-picker').on('keydown', '#pt-cli-contact-name .pt-contact-picker', function (e) {
			//    if (e.which == 13) {
			//        that.checkSearchInputKeyPress(e);
			//    }
			//});
			$(document).off('keypress', '.number-validate, #income-zipcode').on('keypress', '.number-validate, #income-zipcode', that.numValidator);
			$(document).off('keyup', '.jump').on('keyup', '.jump', that.autoJumpToFields);
			$(document).off('keypress', '#section-clientsdeath .number').on('keypress', '#section-clientsdeath .number', that.isNumber);
			$(document).off('click', 'input[type="tel"]').on('click', 'input[type="tel"]', that.highlightTheField);
			$(document).off('focus', '#pt-date-of-death').on('focus', '#pt-date-of-death', that.datepickerActive);
        },
        beforeClose: function() {
            if (this.contactPickerView) {
                this.contactPickerView.close();
            }
        },
        render: function (updateMode) {
            try {
                var self = this;

                if (!this.model.get('currentItemSet')) {
                    this.model.setCurrentValue(updateMode, {data: this.data });
                }
                var _dataSet = this.model.get('items');
                $("#" + this.id).html(this.template({ data: _dataSet }));

            	//Date of death - Date Picker
                var date = new Date();
                $("#pt-date-of-death").datepicker({
                	maxDate: new Date(),
                	showOn: "button",
                	buttonImage: "images/cal-icon.png",
                	buttonImageOnly: true,
                	beforeShow: function () {
                		self.datepickerActive();
                	}
                });
                $("#pt-date-of-death").datepicker("setDate", date);
                    self.loadFamilyRelationship(); //Relationship dropdown
                self.loadUsStateList(); //Load US State List

                var prefillDate = this.model.attributes.items[0].attributes.changedItemValue;
                if (prefillDate !== "") {
                    if (!(prefillDate == "Unknown")) {
                        $("#pt-date-of-death").datepicker("setDate", prefillDate);
                        self.datepickerActive();
                    }

                    $('#iscontactNotifyID .pl-toggle-button-no').addClass('active');

                    var contactArray = this.model.attributes.items[1].attributes.changedItemValue;
                    var arrayLength = contactArray.length;
                    for (i = 1; i <= arrayLength; i++) {
						if (contactArray[(i - 1)].isContactAdded == "Yes"){
                    	var contactDataType = (contactArray[(i -1)].contactType == 'Individual' ? 'A': 'B');
                        var _clientId = "", _contact = contactArray[(i - 1)];
                    	var contactPhoneLabel = '';
                        if (_contact.clientId !== "" && _contact.clientId !== undefined && _contact.clientId !== null) {
                            _clientId = _contact.clientId;
                        }
                        if (contactArray[(i - 1)].phoneNumberLabel && contactArray[(i - 1)].phoneNumberLabel != 'undefined') {
                        	contactPhoneLabel = contactArray[(i - 1)].phoneNumberLabel;
                        } else { contactPhoneLabel = '';}

                        strContainer = '<div data-clientid="' + _clientId + '" id="contact-container-' + i + '" data-contactAdded="' + contactArray[(i - 1)].isContactAdded + '" data-isclient="' + contactArray[(i - 1)].isContactClient + '" class="contact-container"> <div class="row"><div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><a href="javascript:void(0)" class="del-ctn pull-right">Delete</a></div></div><div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-name-lbl"><label class="field-label pt-data-label-demi">Contact name</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-name-val font-booksize" firstname="' + contactArray[(i - 1)].contactFirstName + '" lastname="' + contactArray[(i - 1)].contactLastName + '" data-contactId = "' + contactArray[(i - 1)].contactId + '" data-attr="' + contactArray[(i - 1)].fmtId + '">' + contactArray[(i - 1)].contactName + '</div></div>' +

							'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-contant-info-lbl"><label class="field-label pt-data-label-demi">Contact type</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-contant-info-val font-booksize" value="' +contactArray[(i -1)].contactType + '" data-value="' +
							  contactDataType + '">' + contactArray[(i - 1)].contactType + '</div></div>' +

							 '<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-address-info-lbl"><label class="field-label pt-data-label-demi">Contact address</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-address-info-val font-booksize" data-line1="' +contactArray[(i -1)].addrLine1 + '" data-line2="' +contactArray[(i -1)].addrLine2 + '" data-line3="' +contactArray[(i -1)].addrLine3 + '" data-city="' + contactArray[(i -1)].contactCity + '" data-state="' +contactArray[(i -1)].contactState + '" data-zip="' +contactArray[(i -1)].contactZip + '" >' + contactArray[(i - 1)].contactAddress + '</div></div>' +

							'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-phone-info-lbl"><label class="field-label pt-data-label-demi">Contact phone</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-phone-info-val font-booksize" data-phlabel="' + contactArray[(i - 1)].phoneNumberLabel + '" value="' + contactArray[(i - 1)].phoneNumber + '">' + contactArray[(i - 1)].phoneNumber.replace(' ', '<span>&nbsp;</span>') + contactPhoneLabel + '</div></div>' +

							'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-relation-info-lbl"><label class="field-label pt-data-label-demi">Relationship to deceased</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-relation-info-val font-booksize" value="' +contactArray[(i -1)].relationType + '">' + contactArray[(i - 1)].relationType + '</div></div>' +

							'</div>';
                        $(".multi-contact-container").append(strContainer);
                    }
                    }
                    
                    /* when there's a contact +1, the question should changed to add another */
                    if (self.lengthOf('.multi-contact-container .contact-container') > 0) {
                        $('#iscontactNotifyID label.field-label').text('Do you want to add another contact for notifications?');
                    } else { //Reset back to original if 
                        $('#iscontactNotifyID label.field-label').text('Do you want to add a contact for notifications?');
                    }

                    //change Question -----
                    /*var $addContactNotification = '#iscontactNotifyID';
                    var $contactProspectNo = '.contact-prospect-no';
                    if (self.lengthOf('.multi-contact-container .contact-container') > 0) {
                        $($addContactNotification + ' label.field-label').text('Do you want to add another contact for notifications?');
                        $($addContactNotification + ' .btn-group button').removeClass('active');
                        $($addContactNotification + ' .btn-group .pl-toggle-button-yes').addClass('active');
                        if ($($addContactNotification + ' .btn-group .pl-toggle-button-yes').hasClass('active')) {
                            $($contactProspectNo).removeClass('hidden');
                    }
                    } else { //Reset back to original if 
                        $($addContactNotification + ' .btn-group button').removeClass('active');
                        $($addContactNotification + ' .btn-group .pl-toggle-button-no').addClass('active');
                    }*/
                    //change Question [Close] -----

                }
                self.populateView(self);
                window.scroll(0, 0);
            }
            catch (error) {
                console.log(error);
            }
        },
        populateView: function (view) {
            if (!view.isEdit) {
                view.renderContactPicker(view);
            }
        },
        loadFamilyRelationship: function () {
            var _relationshipList = GPMData.familyRelationships;
            var _listAsOptions = '<option selected="selected" value="Choose one" disabled>Choose one</option>';
            $.each(_relationshipList, function (key, row) {
                _listAsOptions += '<option data-val="'
                        + row.code.toLowerCase() + '" value="'
                        + row.name + '" >' + row.name
                        + '</option>';
            });
            $(".pt-relationship-opts, .pt-relationship-opts-noInd").html(_listAsOptions);
        },
        loadUsStateList : function(){
            var _stateList = StateList.USStateslist;
            var _listAsOptions = '<option value="" >Choose one</option>';
            $.each(_stateList, function(key, row) {
                _listAsOptions += '<option data-val="'
                            + row.name.toLowerCase() + '" value="'
                            + row.code + '" >' + row.name
                            + '</option>';
            });
            $("#income-state-list-select").html(_listAsOptions);
        },
        isNumber: function (evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (isNaN(String.fromCharCode(charCode))) {
                return false;
            }
            return true;
        },
        numValidator : function(obj) {
            var _currTgt = $(obj.currentTarget);
            var _maxLen = _currTgt.attr('maxlength');
            var _regxNumOnly = /^\d*$/;
            var _str = String.fromCharCode(event.keyCode);
            if (!_regxNumOnly.test(_str)
                    || _currTgt.val().length >= _maxLen) {
                obj.stopPropagation();
                if (event.preventDefault)
                    event.preventDefault();
                return false;
            }
        },
        autoJumpToFields: function (e) {
            //block the jump if it is a tab or shift+tab
            e.which = e.which || e.keyCode;
            if(e.which == 9 || e.which == 16){
                return;
            }
            var _target = e.currentTarget || e.target;
            var _el = $(_target);
            var _maxLength = _el.attr("maxlength");
            var _nxtFld = _el.data("jumpto");
            if (_el.val() && _el.val().length == _maxLength) {
                $(document.getElementById(_nxtFld)).focus();
            }
        },
        highlightTheField : function (e) {
            var _target = e.currentTarget || e.target;
            $(_target).select();
            try {
                _target.setSelectionRange(0,99);
            } catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        },
        toggleContactNotification: function (e) {
        	var _self = this;
        	var _$clickedButton = $(e.currentTarget);
            var _btnTxt = _$clickedButton.text();
        	var _$activeSecObj = $('.iscontactNotify');

        	_self.resetContactCliPros($('.isContactClient'));
        	_$activeSecObj.removeClass('active');
        	_$clickedButton.addClass('active');

        	if (_btnTxt == 'Yes') {
        	    $('.contact-prospect-no').removeClass('hidden');
        	} else {
        	    $('.contact-prospect-no').addClass('hidden');
        	}
        	
        },
        resetContactCliPros: function (obj) {
            var _self = this;

            //Reset Yes & No btn group
            obj.removeClass('active');

            //Reset Contact Picker
            _self.contactPickerView.resetRender();
            _self.contactPickerView.hidePageOverlay();
            /* Required Field Validation For Contact Picker */
            $("#pt-cli-contact-name input").attr("id", "cli-contact-name").addClass("needed required");

            //Reset Contact Address & Phone Numbers List
            $("#contact-address, #contact-phoneNumber").remove('.radio');

            //Reset Relationship to deceased select box
            $("#pt-relationship-opts-noInd").find('option:eq(0)').prop('selected', true);

            //Hide all sections under 'Yes' button
            $("#individual-contact-details, .cli-contact-name, #client-or-prospects-yes, #client-or-prospects-no").addClass('hidden');
        },
        toggleContactClient: function (event) {
        	var _self = this;
        	var _$clickedButton = $(event.currentTarget);
        	var _btnTxt = _$clickedButton.text();
        	$('.isContactClient').removeClass('active');
        	_$clickedButton.addClass('active');
        	if (_btnTxt == 'Yes') {
        	    $('#client-or-prospects-yes').removeClass('hidden');
        	    $('#client-or-prospects-no').addClass('hidden');
        	    
        	    //Reset
        	    if ($('.contact-prospect-no > .row').hasClass('error')) { $('.contact-prospect-no > .row').removeClass('error'); }
        	    $('.contact-prospect-no label.error, .contact-prospect-no span.ncst-adjust-left').addClass('hidden');
        	    if ($('.cli-contact-name').hasClass('hidden')) $('.cli-contact-name').removeClass('hidden');

        	    //Reset Contact Picker
        	    if ($(".cli-cnt-name-container").hasClass('error')) { $(".cli-cnt-name-container").removeClass('error'); }
        	    _self.contactPickerView.resetRender();
        	    _self.contactPickerView.hidePageOverlay();
        	    /* Required Field Validation For Contact Picker */
        	    $("#pt-cli-contact-name input").attr("id", "cli-contact-name").addClass("needed required");

        	    //Reset Contact Address & Phone Numbers List
        	    $("#contact-address, #contact-phoneNumber").remove('.radio');

        	    //Reset Relationship to deceased select box
        	    $("#pt-relationship-opts-noInd").find('option:eq(0)').prop('selected', true);

        	    //Hide all sections under 'Yes' button
        	    $("#individual-contact-details").addClass('hidden');

        	} else {
        	    if ($('#client-or-prospects-no > .row.radio-grp-holder').hasClass('error')) { $('#client-or-prospects-no > .row.radio-grp-holder').removeClass('error'); }
        	    $('#client-or-prospects-no').removeClass('hidden');
        	    if (!$('.cli-contact-name').hasClass('hidden')) $('.cli-contact-name').addClass('hidden');
        	    $('#client-or-prospects-yes, #indi-org-common-container').addClass('hidden');

        	    //Reset

                //Reset Individual / Organization Radio
        	    $("#pt-death-contact-type .radio-group-conatiner").removeClass('active');
        	    $("#pt-death-contact-type .radio-group-conatiner input:radio").prop('checked', false);

        	    //Reset Individual / Organization input boxes
        	    $("#indi-container input, #org-container input").val('');
        	    $("#indi-container, #org-container").addClass('hidden');

        	    //Reset State Dropdown
        	    $("#income-state-list-select, #pt-relationship-opts").find('option:eq(0)').prop('selected', true);
        	}

            //Reset Common Container
            //Reset Individual / Organization Common Container
        	$("#indi-org-common-container input").val('');
        	$("#indi-org-common-container").addClass('hidden');
        },
        resetContactCli: function (obj) {
            var _self = this;

            //Reset Yes & No btn group
            obj.removeClass('active');

            //Reset Contact Picker
            _self.contactPickerView.resetRender();
            _self.contactPickerView.hidePageOverlay();
            /* Required Field Validation For Contact Picker */
            $("#pt-cli-contact-name input").attr("id", "cli-contact-name").addClass("needed required");

            //Reset Contact Address & Phone Numbers List
            $("#contact-address, #contact-phoneNumber").remove('.radio');

            //Reset Relationship to deceased select box
            $("#pt-relationship-opts-noInd").find('option:eq(0)').prop('selected', true);

            //Hide all sections under 'Yes' button
            $("#individual-contact-details, .cli-contact-name, #client-or-prospects-yes").addClass('hidden');
        },
        toggleRadioContactAddress: function (event) {
        	var $eventInput = $(event.target);
        	var $eventRadioButtonContainer = $eventInput.closest('.radio-group-conatiner');
        	$('#contact-address .radio-group-conatiner').removeClass('active');
        	$eventRadioButtonContainer.addClass('active');
        },
        toggleRadioPhoneNumbers: function (event) {
        	var $eventInput = $(event.target);
        	var $eventRadioButtonContainer = $eventInput.closest('.radio-group-conatiner');
        	$('#contact-phoneNumber .radio-group-conatiner').removeClass('active');
        	$eventRadioButtonContainer.addClass('active');
        },
        toggleRadioClassActive: function (event) {
            var _self = this;
        	var _radio = $(event.target);
        	var _radioHolder = _radio.parents('div.radio-grp-holder');
        	_radioHolder.find('div.radio-group-conatiner').removeClass('active');
        	_radio.parents('div.radio-group-conatiner').addClass('active');

        	var _$container = $('#section-clientsdeath');
        	var _slectedContactType = _$container.find('input[name="pt-contact-type-radio-group"]:checked').val();
        	if (_slectedContactType == "Individual") {
        	    $("#indi-container").removeClass("hidden");
        	    $("#org-container").addClass("hidden");
        	} else {
        	    $("#org-container").removeClass("hidden");
        	    $("#indi-container").addClass("hidden");
        	}
        	_self.resetRedErrorBoxes('#indi-container, #org-container, #indi-org-common-container');
        	$("#indi-org-common-container").removeClass("hidden");

        },
        toggleContTypRelationship: function (event) {
            var ctnName = $('.pt-contact-picker > input').val();
            if (ctnName != '' && ctnName.trim().length) {
                $('#pt-cont-typ-relation-sec').removeClass('hidden');
                if (!$('#show-error').hasClass('hidden')) {
                    //Clear Validations
                    $('.validation-container').removeClass('error');
                    $('#show-error').addClass('hidden');
            }
            }
        },
        datepickerActive: function () {
            $("input:radio[name=pt-deathdate-radio-grp]").prop('checked', false);
            $("#pt-clients-death-date").prop('checked', true);
            $(".pt-clients-death .radio-group-conatiner").removeClass('active');
            $("input:radio[id=pt-clients-death-date]").parent().parent().addClass('active');
        },
        checkSearchInput: function (e) {
            var _self = this;
            var target = $(e.target);
            var _keyCode = e.keyCode || e.which;
            if (target.val().trim() == '' && target.val().length == 0 ) {
                if (_keyCode == 8) {
                    _self.hideIndiContactDetails(true);
                } else {
                    _self.hideIndiContactDetails();
                }
            }
        },
        hideIndiContactDetails: function (doNotReset) {
            var _self = this;
            if ($('#section-clientsdeath').is(':visible')) {
                $("#individual-contact-details").addClass('hidden');
                if (!doNotReset) {
                    _self.contactPickerView.resetRender();
                    _self.contactPickerView.hidePageOverlay();
                    /* Required Field Validation For Contact Picker */
                    $("#pt-cli-contact-name input").attr("id", "cli-contact-name").addClass("needed required");
                }
            }
        },
        validationRulesForAll: function (obj) {
            if (obj == "individual-contact-details") {

            }
        },
        resetRedErrorBoxes: function (obj) {
            var containers = obj.split(',');
            for (var i = 0; i < containers.length; i++){
                //if ($(containers[i] + ' .row').hasClass('error')) { $(containers[i] + ' .row').removeClass('error'); }

                //For error class
                $(containers[i] + ' .row').each(function () {
                    if ($(this).hasClass('error')) {
                        $(this).removeClass('error');
                    }
                });

                //For Label error
                $(containers[i] + ' label.error').each(function () {
                    if (!$(this).hasClass('hidden')) {
                        $(this).addClass('hidden');
                    }
                });

                //if (!$(containers[i] + ' label.error').hasClass('hidden')) { $(containers[i] + ' label.error').addClass('hidden'); }
            }
        },
        checkSearchInputKeyPress: function (e) {
        	function gototClientProfileSuccess(colaData, cmData) {
        		var _phoneTmplt = _.template(PhoneDeathTemplate);
        		var _addressTmplt = _.template(AddressDeathTemplate);

        		if (colaData[0] && colaData[0].attributes && colaData[0].attributes.telephones) {
        			var _colaphoneNumSet = colaData[0].get('telephones');
        		}
        		if (colaData[0] && colaData[0].attributes && colaData[0].attributes.clientPostalAddresses) {
        			var _colaaddressInfoSet = colaData[0].get('clientPostalAddresses');
        		}
        		if (cmData[0] && cmData[0].attributes && cmData[0].attributes.Addresses) {
        			var _cmaddressInfoSet = cmData[0].get('Addresses');
        		}
        		if (cmData[0] && cmData[0].attributes && cmData[0].attributes.Phones) {
        			var _cmphoneNumSet = cmData[0].get('Phones');
        		}
        		
        		$("#contact-phoneNumber").empty().html(_phoneTmplt({ colaphonedata: _colaphoneNumSet, cmphonedata: _cmphoneNumSet }));
        		$("#contact-address").empty().html(_addressTmplt({ colaaddressdata: _colaaddressInfoSet, cmaddressdata: _cmaddressInfoSet }));

        	};
        	function gotoError(error) {
        		Spinner.hide();
        		_self.handleServiceError(error);
        	};
        	var _contactPicker = self.contactPickerView;
		var clientId = _contactPicker.selectedContact;
		var fmtId = '', orgNm = null, personNm = null;
		var that = self,
            _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
		if ((clientId != undefined || clientId != null) && clientId.contactType == "client") { 
			$("#individual-contact-details").removeClass('hidden');
			that.resetRedErrorBoxes("#individual-contact-details");
			clientId = clientId.id;
			Spinner.show();
			var colaData = '', firstName='',lastName='';
			DataService.getContactprofileInfoFromSourceSystem(clientId).then(function (response) {
				colaData = response;
				orgNm = response[0].get('orgClient').get('orgNm');
				personFNm = response[0].get('personClient').get('clFirstNm');
				personLNm = response[0].get('personClient').get('clLastNm');
				if (orgNm == null) {
					contactTypeName = 'Individual';
					$('.pt-cli-contact-name input').attr({ "firstname": personFNm, "lastname": personLNm });
				}
				else if (personFNm == null) {
					contactTypeName = 'Organization';					
				}
				$('.clientTypeInd').html(contactTypeName);
				if (response != null) {
					fmtId = (response[0] == null || response[0].get == null) ? null : response[0].get('fmtId');
					$('.pt-cli-contact-name input').attr({ "clientId": fmtId, "contactTypeName": contactTypeName, "data-contactid": clientId });
					if (_isNonCMuser == false) {
					    DataService.getContactDetailsbyClientId(Utility.readCookie('FMID'), clientId).then(function (response) {
					        if (response[0] && response[0].attributes && response[0].attributes.contactId) {
					            //firstName = response[0].attributes.firstName;
					            //lastName = response[0].attributes.lastName;
					            //$('.pt-cli-contact-name input').attr({ "firstname": firstName, "lastname": lastName });
					            DataService.getNonClientEbixDetails(Utility.readCookie('FMID'), response[0].get('contactId')).then(function (response) {
					                Spinner.hide();
					                gototClientProfileSuccess(colaData, response);
					            }).fail(gotoError);
					        } else {
					            gototClientProfileSuccess(colaData, response);
					            Spinner.hide();
					        }
					    }).fail(gotoError);
					} else {
					    Spinner.hide();
					    gototClientProfileSuccess(colaData, []);
					}
					
				}
			}).fail(gotoError);
		} else if ((clientId != undefined || clientId != null) && clientId.contactType == "nonclient") {			
			$("#individual-contact-details").removeClass('hidden');
			that.resetRedErrorBoxes("#individual-contact-details");
			clientId = clientId.id;
			Spinner.show();
			DataService.getNonClientEbixDetails(Utility.readCookie('FMID'), clientId).then(function (response) {
				Spinner.hide();
				var personFName = response[0].get('PersonContact').get('clFirstNm');
				var personLName = response[0].get('PersonContact').get('clLastNm');
				orgNm = response[0].get('BusinessContact').get('orgNm');
				if (orgNm == null) { contactTypeName = 'Individual' ,
				    $('.pt-cli-contact-name input').attr({ "firstname": personFName, "lastname": personLName });
				}
				else { contactTypeName = 'Organization' }
				$('.clientTypeInd').html(contactTypeName);
				$('#pt-cli-contact-name input').attr('clientid', '')

				gototClientProfileSuccess('', response);
			}).fail(gotoError);

		}
        },
        hideContTypeRelationship: function (doNotReset) {
            var _self = this;

            if ($('#section-clientsdeath').is(':visible')) {
                $('#pt-relationship-opts').find('option:eq(0)').prop('selected', true);
                //clear contactType radio field
                $('#pt-death-contact-type div').removeClass('active');
                $("input[name='pt-contact-type-radio-group']:radio").attr("checked", false);
                //Clear Validations
                $('#pt-family-relationship, #pt-cont-type, .validation-container').removeClass('error');
                $('#show-error-relationship, #show-error-contacttyp, #show-error').addClass('hidden');
                //Hide Contact type and Relationship
                $('#pt-cont-typ-relation-sec').addClass('hidden');
                if (!doNotReset) {
                    _self.contactPickerView.resetRender();
                    _self.contactPickerView.hidePageOverlay();
                    /* Required Field Validation For Contact Picker */
                    $("#pt-cli-contact-name input").attr("id", "cli-contact-name").addClass("needed required");
                }
            }
        },
        addAnotherClient: function (view) {
        	var self = this;
        	var clientIdVal = '', fmtIdVal = '', fmcidVal = '', contactIdVal = '', contactNameVal = '', additionalInfoVal = '', isContactClientVal = '', contactTypeVal = '', contactFirstNameVal = '', contactLastNameVal = '', addrLine1Val = '', addrLine2Val = '', addrLine3Val = '', contactCityVal = '', contactStateVal = '', contactZipVal = '', phoneNumberVal = '', relationTypeVal = '', clientIdVal = '', contactFmtIdVal = '', contactAddressVal = '', isContactAddedVal = '', phonelabel='';
        	isContactClientVal = $('#isContactClientID').find('button[name="isContactClient"].active').text();
        	if (isContactClientVal == 'Yes') {
        		var contactNameVal = $('.pt-cli-contact-name input').val();
        		contactFirstNameVal = $('#pt-cli-contact-name input').attr('firstname');
        		contactLastNameVal = $('#pt-cli-contact-name input').attr('lastname');
        		contactIdVal = $('#pt-cli-contact-name input').attr('data-contactid');
        		contactFmtIdVal = $('#pt-cli-contact-name input').attr('clientid');
        		contactTypeVal = $('.clientTypeInd').text();
        		var contactAddress = $('#contact-address').find('input[name="contact-address-radio-group"]:checked');
        		var contactAddressId = contactAddress.attr('id');
        		contactAddressVal = $.trim($('label[for="' + contactAddressId + '"]').text());
        		addrLine1Val = contactAddress.data('line1');
        		addrLine2Val = contactAddress.data('line2');
        		addrLine3Val = contactAddress.data('line3');
        		contactCityVal = contactAddress.data('city');
        		contactStateVal = contactAddress.data('state');
        		contactZipVal = contactAddress.data('zip');
        		phoneNumberVal = $('#contact-phoneNumber').find('input[name="contact-phone-radio-group"]:checked').val();
        		phonelabel = $('#contact-phoneNumber').find('input[name="contact-phone-radio-group"]:checked').data('phlabel');
        		relationTypeVal = $('#pt-relationship-opts-noInd option:selected').text();
        		if (relationTypeVal == "" || relationTypeVal == "Choose one") {
        			relationTypeVal = "";
        		}
        		if (phoneNumberVal != 'Unknown') {
        			phonelabel = ((phonelabel == null || phonelabel == "" || phonelabel == undefined) ? '' : '(' + phonelabel + ')');
        		} else {
        			phonelabel = "";
        		}
        	} else if (isContactClientVal == 'No') {
        		var contactTypeVal = $('#pt-death-contact-type').find('input[name="pt-contact-type-radio-group"]:checked').val();
        		if (contactTypeVal == 'Individual') {
        			contactFirstNameVal = $('.contactFirstName').val();
        			contactLastNameVal = $('.contactLastName').val();
        			contactNameVal = contactLastNameVal + ', ' + contactFirstNameVal;
        		}
        		if (contactTypeVal == 'Organization') {
        			contactNameVal = $('.contactFullName').val();
        		}
        		addrLine1Val = $('.contactAddressLine1').val(); 
        		addrLine2Val = $('.contactAddressLine2').val();
        		addrLine3Val = $('.contactAddressLine3').val(); 
        		contactCityVal = $('.contactCity').val();
        		contactStateVal = $('#income-state-list-select option:selected').text();
        		contactZipVal = $('.contactZipCode').val();
        		//contactAddressVal = addrLine1Val + " " + addrLine2Val + " " + addrLine3Val + " " + contactCityVal + " " + contactStateVal + " " +contactZipVal;
        		phoneNumberVal = $('.areaCd').val() + $('.exchCd').val() + $('.sbsNbr').val();
        		relationTypeVal = $('#pt-relationship-opts option:selected').text();

        	var formatph = ("" + phoneNumberVal).replace(/\D/g, '');
        	var m = formatph.match(/^(\d{3})(\d{3})(\d{4})$/);
        	phoneNumberVal = ((!m) ? "" : "(" + m[1] + ") " + m[2] + "-" + m[3]);
        	}
        	if (contactAddressVal != 'Unknown') {
        		contactAddressVal = addrLine1Val + " " + addrLine2Val + " " + addrLine3Val + " " + contactCityVal + " " + contactStateVal + " " + contactZipVal;
        	}
			var contactTD = (contactTypeVal == 'Individual' ? 'A' : 'B');
        	var cntContainer = $('.contact-container');
        	var count = cntContainer.length == 0 ? 1 : parseInt(cntContainer.last().attr('id').split('-')[2], 10) + 1;

        	var strContainer = '<div data-clientid="' + contactIdVal + '" id="contact-container-' + count + '" data-contactAdded="Yes" data-isclient="' + isContactClientVal + '" class="contact-container"> <div class="row"><div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><a href="javascript:void(0)" class="del-ctn pull-right">Delete</a></div></div><div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-name-lbl"><label class="field-label pt-data-label-demi">Contact name</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-name-val font-booksize" firstname="' + contactFirstNameVal + '" lastname="' + contactLastNameVal + '" data-contactId = "' + contactIdVal + '" data-attr="' + contactFmtIdVal + '">' + contactNameVal + '</div></div>' +

			'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-contant-info-lbl"><label class="field-label pt-data-label-demi">Contact type</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-contant-info-val font-booksize" value="' + contactTypeVal + '" data-value="' + contactTD + '">' + contactTypeVal + '</div></div>' +

				'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-address-info-lbl"><label class="field-label pt-data-label-demi">Contact address</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-address-info-val font-booksize" data-line1="' + addrLine1Val + '" data-line2="' + addrLine2Val + '" data-line3="' + addrLine3Val + '" data-city="' + contactCityVal + '" data-state="' + contactStateVal + '" data-zip="' + contactZipVal + '" >' + contactAddressVal + '</div></div>' +

			'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-phone-info-lbl"><label class="field-label pt-data-label-demi">Contact phone</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-phone-info-val font-booksize" data-phlabel="' + phonelabel + '" value="' + phoneNumberVal + '">' + phoneNumberVal.replace(' ', '<span>&nbsp;</span>') + ' ' + phonelabel + '</div></div>' +

			'<div class="row"><div class="col-xs-12 col-sm-3 col-md-3 ctn-relation-info-lbl"><label class="field-label pt-data-label-demi">Relationship to deceased</label></div><div class="col-xs-12 col-sm-8 col-md-6 ctn-relation-info-val font-booksize" value="' + relationTypeVal + '">' + relationTypeVal + '</div></div>' +

			'</div>';
        	$(".multi-contact-container").append(strContainer);

            //Reset UI
        	self.resetContactCliPros($('.isContactClient'));
        	self.resetContactCliPros($('.iscontactNotify'));

            //Hide 'Is this contact one of your clients or prospects?' section
        	if (!$(".contact-prospect-no").hasClass('hidden')) { $(".contact-prospect-no").addClass('hidden'); }
        },
        handleContactPickerModalClick: function () {
            var _contactPicker = self.contactPickerView;
            if (_contactPicker.selectedContact == null) {
                $("input[pt-contact-picker-text-input]").val("");
                self.hideIndiContactDetails();
            }
        },
        deleteContact: function (e) {
            var that = this;
            BootstrapDialog.show({
                title: 'Delete',
                message: "Are you sure you want to delete this contact?",
                closeByBackdrop: false,
                cssClass: 'ncst-dialog',
                buttons: [{
                            label: 'Yes',
                            cssClass: 'btn btn-primary pt-btn-yes',
                            action: function (dialog) {
                                $(e.target).closest('.contact-container').remove();
                                that.changeQuestion(e);
                                dialog.close();
                            }
                        },
                        {
                            label: 'No',
                            cssClass: 'btn btn-primary pt-btn-no',
                            action: function (dialog) { dialog.close(); }
                        }]
            });
            
        },
        renderContactPicker: function (view) {
            var fmid = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
            var dataSource = new ContactPickerDataSource(fmid, CommonUtils.userFMID());
            // if we have one...use the client list the app already retrieved
            var isDynamicSearch = AppContactDetails.advsiorContacts.getContactSearchType(fmid);
            if (!isDynamicSearch) {
                var fixedClientList = AppContactDetails.advsiorContacts.GetContactDetails(fmid, Constants.contactType.Client);
                dataSource.setFixedClientListFromAppClientList(fixedClientList);
            }
            view.contactPickerView = new ContactPickerView({ el: $('#pt-cli-contact-name').get(0), dataSource: dataSource });
            var _userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
            if (_userRoles.indexOf("aac") > -1){
                view.contactPickerView.enableClientIdSearch = true;
            }
            var _isNonCMUser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMUser) {
                view.contactPickerView.isNonCMUser = true;
            }
            view.contactPickerView.render();
            view.contactPickerView.isFreeformAllowed = false;
            view.contactPickerView.selectionComplete = self.checkSearchInputKeyPress;

            /* Required Field Validation For Contact Picker */
            $("#pt-cli-contact-name input").attr("id", "cli-contact-name").addClass("needed required");
        },
        handleDeathDateOpt: function (e) {
            var $priorityInput = $(e.target);
            var $priorityRadioButtonContainer = $priorityInput.closest('.radio-group-conatiner');
            this.$('.dateOfDeath .radio-group-conatiner').removeClass('active');
            $priorityRadioButtonContainer.addClass('active');
        },
        validateCliProsYes: function (e) {
            var that = this;
            var targetId = e.target.id;
            var validateThisContainer = '';

            if (targetId == "add-client-prospect-yes-btn") {
                validateThisContainer = 'client-or-prospects-yes';
            } else if (targetId == "add-client-prospect-no-btn") {
                validateThisContainer = 'client-or-prospects-no';
            }
            
            if (this.model.validate(validateThisContainer, true) && this.validateCountOfPhNumber()) {
                that.addAnotherClient();
                //If a Contact has been added in Multiple Container, enable 'Yes' and change the question text
                that.changeQuestion(e);

            } else { this.validateCountOfPhNumber(); return false; }
        },
        changeQuestion: function (e) {
            var that = this;
            var $addContactNotification = '#iscontactNotifyID';
            var $contactProspectNo = '.contact-prospect-no';

            if (that.lengthOf('.multi-contact-container .contact-container') > 0) {
                if (!$('#iscontactNotifyID .pl-toggle-button-no').hasClass('active')) {
                    $($addContactNotification+' label.field-label').text('Do you want to add another contact for notifications?');
                    $($addContactNotification+' .btn-group button').removeClass('active');
                    $($addContactNotification+' .btn-group .pl-toggle-button-yes').addClass('active');
                    if ($($addContactNotification + ' .btn-group .pl-toggle-button-yes').hasClass('active')) {
                        $($contactProspectNo).removeClass('hidden');
                    }
                }
            } else { //Reset back to original if 
                if (!$($contactProspectNo).hasClass('hidden')) {
                    if ($('#client-or-prospects-yes').hasClass('hidden') && $('#client-or-prospects-no').hasClass('hidden')) {
                        $($addContactNotification + ' label.field-label').text('Do you want to add a contact for notifications?');
                        $($addContactNotification + ' .btn-group button').removeClass('active');
                        if (!$($contactProspectNo).hasClass('hidden')) { $($contactProspectNo).addClass('hidden'); }
                    }
                }
            }
        },
        lengthOf: function (obj) {
            return $(obj).length;
        },
        validateCountOfPhNumber: function (e) {
            var that = this;
            if ($("#indi-org-common-container").is(':visible')) {
                var sum = 0;
                //iterate through each phone textboxes and add the values
                $('#cd-homephone-inputs input').each(function () {
                    if (this.value.length != 0) { sum += parseFloat(this.value.length); }
                });

                if (sum == 0) {
                    $('#cd-homephone-inputs label.error').text('Incomplete required field.');
                    return false;
                } else if (sum > 0 && sum < 10) {
                    if (!$('#phn-add-edit-template-ph').hasClass('error')) { $('#phn-add-edit-template-ph').addClass('error'); }
                    if ($('#cd-homephone-inputs label.error').hasClass('hidden')) {
                        $('#cd-homephone-inputs label.error').removeClass('hidden').text('Invalid phone number.');
                    } else {
                        $('#cd-homephone-inputs label.error').text('Invalid phone number.');
                    }
                    return false;
                }
            }
            return true;
        },
        validateAndNavigateFromStep1: function () {
            var _self = this;
            if ($('.pt-contact-picker input').is(":focus")) {
                return;
            }else{
                //if respective containers not visible, then run common validation else run local validation
                if (!$("#client-or-prospects-yes").is(':visible')) {
                    if (!this.$indiContactContainer.is(':visible') &&
                         !this.$indiOrgCommonContainer.is(':visible') &&
                         !this.$indiContainer.is(':visible')) {
                        if (this.model.validate('gpm-update-form', true) && this.validateCountOfPhNumber()) { gotoView(); } else { _self.validateCountOfPhNumber(); }
                    }
                } else {
                    //Once location validation is done call gotoView
                    //if (this.localValidation()) { gotoView(); }
                    if (this.model.validate('gpm-update-form', true) && this.validateCountOfPhNumber()) { gotoView(); } else { _self.validateCountOfPhNumber(); }
                }
            }
            function gotoView() {
                _self.model.setChangedValue();
                if (valuesModified()) {
                    $('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                        Backbone.history.navigate('gpm/verification/' + _self.model.get('updateMode'), true);
                } else {
                    Utils.showNoChangesMessageToUser();
                }
            }

            function valuesModified() {
                var _isModified = true;
                var _items = _self.model.get('items');
                var _clientDateOfDeath = _items.find(function (row) { return row.get("itemType") == "clientDateOfDeath" }),
					_clientContactName = _items.find(function (row) { return row.get("itemType") == "clientContactName" }),
            		_clientAdditionalInfo = _items.find(function (row) { return row.get("itemType") == "clientAdditionalInfo" });
                if (_clientDateOfDeath.get('valueChanged') == false && _clientContactName.get('valueChanged') == false && _clientAdditionalInfo.get('valueChanged') == false) {_isModified = false;}
                return _isModified;
            }
        },
        checkForNumber: function (event) {
            var _regxNumOnly = /^\d*$/;
            var _str = String.fromCharCode(event.keyCode || event.which);

            if (_regxNumOnly.test(_str)) {
                return false;
            }
        }
    });
    return clientsdeath;
});