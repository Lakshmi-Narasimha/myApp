import { Component, OnInit } from '@angular/core';

import { AIAssistCacheService } from './_services/index';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    title = 'app works!';
    body: string = 'my awesome content';

    constructor(private cacheService : AIAssistCacheService) {
    }

    ngOnInit() {
        this.loadAllAgents();
    }

    private loadAllAgents() {
        this.cacheService.serverLoadAgents();
    }
}
