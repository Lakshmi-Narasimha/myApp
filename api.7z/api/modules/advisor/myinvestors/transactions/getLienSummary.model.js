// getLienSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var LienSummaryModelSchema = new mongoose.Schema({
    LienSummaryResp: {
        type: Array,
        "default": []
    }
});

var LienSummaryModelLookUp = mongoose.model('LienSummaryModelLookUp', LienSummaryModelSchema);

var LienSummaryModel = new LienSummaryModelLookUp({
    LienSummaryResp : {
        "lien": {
            "fundWiseData": [
                {
                  "folioNo": "2341621",
                  "accountNumber": "1000110191",
                  "fund": "Franklin India Equity Fund",
                  "unitBalance": 300,
                  "currentValue": 1069,
                  "lienUnits": 600,
                  "familySolutions": "Yes",
                  "valueOfLienUnits": 2131,
                  "remarks": "CITI"
                },
                {
                  "folioNo": "3456432",
                  "accountNumber": "1000110191",
                  "fund": "Franklin India Equity Fund",
                  "unitBalance": 550,
                  "currentValue": 2345,
                  "lienUnits": 100,
                  "familySolutions": "No",
                  "valueOfLienUnits": 5464,
                  "remarks": "HDFC"
                },
                {
                  "folioNo": "4356453",
                  "accountNumber": "1000110191",
                  "fund": "Franklin India Equity Fund",
                  "unitBalance": 277,
                  "currentValue": 1243,
                  "lienUnits": 380,
                  "familySolutions": "No",
                  "valueOfLienUnits": 2342,
                  "remarks": "ICICI"
                }
            ]
        }     
    }
});

LienSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating LienSummaryModelLookUp table, please contact admin...');
    } else {
        LienSummaryModelLookUp.remove({}, function(err) {
            console.log('LienSummaryModelLookUp collection removed');
            LienSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating LienSummaryModelLookUp table, please contact admin...');
                }
                console.log('LienSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = LienSummaryModelLookUp;
