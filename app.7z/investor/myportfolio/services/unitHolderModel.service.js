/**
 * @ngdoc property
 * @name unitHolderModel
 * @requires Restangular
 * @requires $q
 * @description
 *
 * - unitHolderModel is a service model which consists the list of services required for unit hoder details in 
 *   Statements tab of my investors page.
 *
 **/
'use strict';


var unitHolderModel = function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _unitHolderKeyValueList = null,
        _unitHolderDetails = null;
        
	var unitHolderDetails = {

		getUnitHolderDetails1 : function () {            
            var deferred = $q.defer();
            Restangular.all('getUnitHolderDtls').getList().then(function (unitHolderDetails) {
                deferred.resolve(unitHolderDetails);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        getUnitHolderKeyValueList : function () {
        	if(!angular.isDefined(_unitHolderKeyValueList))
        	{
        		return null;
        	}
        	return _unitHolderKeyValueList;
        },
        setUnitHolderKeyValueList : function (detailsObj) {
        	_unitHolderKeyValueList = [
                {key:'Unit Holder Name',value:detailsObj.custName},
                {key:'PAN',value:detailsObj.pan},
                {key:'Folio No',value:detailsObj.folioId},
                {key:'Mode of Holding',value:detailsObj.holdingType},
                {key:'Mobile',value:detailsObj.mobile},
                {key:'Email',value:detailsObj.emailId},
                {key:'City ',value:detailsObj.city}
            ];
        },

        setUnitHolderDetails : function(unitHolderDetails){
            _unitHolderDetails = unitHolderDetails;
        },

        getUnitHolderDetails : function(){
            return _unitHolderDetails;
        }
    };

    return unitHolderDetails;

};

unitHolderModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = unitHolderModel;
