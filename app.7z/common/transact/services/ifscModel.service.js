/**
 * @ngdoc service
 * @name ifscModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var ifscModel = function (Restangular, $q,authenticationService, bankDtlsModel, fticLoggerMessage, loggerConstants) {
    var _ifscSearch = null,
        _ifscBankDetails = null,
        _ifscCityDetails = null,
        _ifscBank,
        _ifscBrnDetails = null;

    var ifscModel = {
        
        fetchIfscDetails : function (params) {
            // var params = {};
            params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            console.log("fetchIfscDetails", params)
            // params.guId = authenticationService.getUser().guId;
            
            // params.bankName = 'ABHYUDAYA CO OP BANK LTD';
            //  // bankDetailsModel.getSelectedBank;
            // console.log(params.bankName);
            
          
            
            var deferred = $q.defer();
            Restangular.one('transact/ifscSearch').get(params).then(function (ifscSearch) {
                deferred.resolve(ifscSearch);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        fetchIfscSearchDetails : function () {
            
            var deferred = $q.defer();
            Restangular.all('/ifscSearchGrid').getList().then(function (ifscSearch) {
                deferred.resolve(ifscSearch);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getIfscDetails: function() {
            return _ifscSearch;
        },
        
        setIfscDetails: function(ifscSearch) {
            _ifscSearch = ifscSearch;
        },
        setIfscCityDetails: function(ifscCityData) {
            _ifscCityDetails = ifscCityData;
        },
        getIfscCityDetails: function() {
            return _ifscCityDetails;
        },
        setIfscBrnDetails: function(ifscSearch) {
            _ifscBrnDetails = ifscSearch;
        },
         getIfscBrnDetails: function() {
            return _ifscBrnDetails;
        },
        setIfscBankDetails: function(ifscBankData) {
            _ifscBankDetails = ifscBankData;
        },
        getIfscBankDetails: function() {
            return _ifscBankDetails;
        },
        setIfscGridDetails: function(ifscSearch) {
            _ifscSearch = ifscSearch;
            //add arguments for service [city and branch]
        },
        
        getIfscGridDetails: function() {
            return _ifscSearch;
        },
        setIfscGridResDet: function(ifscSearch) {
            _ifscSearch = ifscSearch;
            //add arguments for service [city and branch]
        },
        getIfscBank: function() {
            return _ifscBank;
        },
        setIfscBank: function(bankName) {
            _ifscBank = bankName;
            //add arguments for service [city and branch]
        },
        
        getIfscGridResDet: function() {
            return _ifscSearch;
        }


        

    };
    return ifscModel;
};

ifscModel.$inject = ['Restangular', '$q', 'authenticationService','bankDtlsModel','fticLoggerMessage', 'loggerConstants'];

module.exports = ifscModel;