/**
 *@ngdoc object
 *@name investor.module:MyPortfolio
 *@description
 * <p>
 * It has all linkup of the components, services and initial wrapper
 * </p>
 */



'use strict';
module.exports = angular.module('investor.myportfolio', [])
    .config(require('./myportfolio.routes'))
    .controller('OverviewController', require('./overview/overview.controller'))
    .controller('PanViewController', require('./overview/panview/panview.controller'))
    .controller('FolioViewController', require('./overview/folioview/folioview.controller'))
    .controller('accountViewController', require('./overview/accview/accountView.controller'))
    .factory('panViewInitialLoader', require('./overview/services/panViewInitialLoader.service'))
    .factory('panViewModel', require('./overview/services/panViewModel.service'))
    .factory('folioViewInitialLoader', require('./overview/services/folioViewInitialLoader.service'))
    .factory('folioViewModel', require('./overview/services/folioViewModel.service'))
    .factory('accountViewInitialLoader', require('./overview/services/accountViewInitialLoader.service'))
    .factory('accountViewModel', require('./overview/services/accountViewModel.service'))
    .directive('fticFolioDetailsGrid', require('./overview/folioview/components/foliodetailsgrid/folioDetailsGrid.directive'))
    .directive('fticAccntStmtHolder', require('./overview/accview/components/accountStmtHolder/accountStmtHolder.directive'))
    .directive('fticFisrtUnitHolder', require('./overview/components/firstunitholder/firstUnitHolder.directive'))
    .directive('fticFolioStmtFilter', require('./overview/folioview/components/foliostmtfilter/folioStmtFilter.directive'))
    .directive('fticAccountViewFilter', require('./overview/accview/components/accountViewfilter/accountViewFilter.directive'))
    .directive('fticStmtUnitHolder', require('./overview/folioview/components/stmtunitholder/stmtUnitHolder.directive'))
    .directive('fticAccountDetailsGrid', require('./overview/accview/components/accountDetials/accountDetailsGrid.directive'))
    .directive('fticPortFolioDetailsGrid', require('./overview/panview/components/portfoliodetails/portFolioDetailsGrid.directive'))
    .directive('fticPanSearchFilter', require('./overview/panview/components/searchfilter/searchFitler.directive'))
    .factory('unitHolderModel', require('./services/unitHolderModel.service'))
    .factory('unitHolderInitialLoadService', require('./services/unitHolderInitialLoader.service'))
    .controller('CapitalGainsController', require('./capitalgains/capitalgains.controller'))
    .controller('CGAccountViewCtrl', require('./capitalgains/accountView/accountView.controller'))
    .controller('CGFolioViewCtrl', require('./capitalgains/folioView/folioView.controller'))
    .factory('fticgAccDetLoadInitialService', require('./capitalgains/services/cgAccDetInitialLoader.service'))
    .factory('cgAccDetModel', require('./capitalgains/services/cgAccDetModel.service'))
    .directive('fticCapitalGainAcFilter', require('./capitalgains/accountView/components/cgaccfilter/cgaccfilter.directive'))
    .directive('fticCapitalGainAcUnitDetails', require('./capitalgains/accountView/components/cgaccunitholder/cgunitholder.directive'))
    .directive('fticCapitalGainsFolioDetails', require('./capitalgains/folioView/components/capitalgainsfoliodetails/capitalGainsFolioDetails.directive'))
    .directive('fticCapitalGainAcDetails', require('./capitalgains/accountView/components/capitalgainsaccountdetails/capitalGainsAccountDetails.directive'))
    .directive('fticCapitalGainFolioFilter', require('./capitalgains/folioView/components/cgfoliofilter/cgfoliofilter.directive'))
    .directive('fticCapitalGainsFolioUnitDetails', require('./capitalgains/folioView/components/cgfoliounitholder/cgfoliounitholder.directive'))
    .constant('myportfolioConstants', require('./constants/myportfolio.constants'))
    .controller('FamilyPortfolioController', require('./familyportfolio/familyportfolio.controller'))
    .controller('CASController', require('./casstatement/casStatement.controller'))
    .factory('familyPortfolioModel', require('./familyportfolio/services/familyPortfolioModel.service'))
    .factory('familyPortfolioInitialLoader', require('./familyportfolio/services/familyPortfolioInitialLoader.service'))
    .directive('fticPendingFamilyPortfolio', require('./familyportfolio/components/pendingfamilyportfolio/pendingFamilyPortfolio.directive'))
    .directive('fticFamilyPortfolioAccordion', require('./familyportfolio/components/familyportfolioaccordion/familyPortfolioAccordion.directive'))
    .controller('RemMemConfPopup', require('./familyportfolio/components/removememberconfirmpopup/remMemConfPopup.controller'))
    
    ;
