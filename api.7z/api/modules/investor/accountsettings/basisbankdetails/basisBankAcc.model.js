// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var InvBasisBankAccSchema = new mongoose.Schema({
    basisBankAccDetailsObject: {
        type: Object,
        "default": {}
    }
});

var InvBasisBankAccLookUp = mongoose.model('InvBasisBankAccLookUp', InvBasisBankAccSchema);

var InvBasisBankAccModel = new InvBasisBankAccLookUp({

  'basisBankAccDetailsObject': {
      "invBankDetails": [{
      "fundDetails": [{
      "fundDesc": "Franklin India Prima Plus - Dividend",      
      "folioAccount": "0029903636631",
      "payInType": "E-Mandate"
      },{
      "fundDesc": "Franklin India Bluechip Fund - Dividend",
      "payInType": "NACH",
      "folioAccount": "0069903636632"
      },
      {
      "fundDesc": "Franklin India Taxshield - Dividend",
      "folioAccount": "0359903636633",
      "payInType": "Pay In"      
      },{
      "fundDesc": "Franklin Asian Equity Fund - Growth",
      "folioAccount": "3049903636634",
      "payInType": "Bill Pay"
      
      }],
      "uploadImages":[{
        "imageLink":"Desert"
      },{
        "imageLink":"wildlife"
      }],
      "bankName": "ICIC Bank",
      "type":"Payout Type",
      "ifscCode":"IFSC Code",
      "bankAccountNo": "17259162",
      "payOutType": "Cheque",
      "ifscCodeNo": "ICIC0000001"   
      }, {
      "fundDetails": [{
      "fundDesc": "Franklin India Prima Plus - Growth",
      "folioAccount": "0029903636635",
      "payInType": "E-Mandate"      
      },{
      "fundDesc": "Franklin India Bluechip Fund - Dividend",
      "folioAccount": "0069903636636",
      "payInType": "NACH"      
      },
      {
      "fundDesc": "Franklin India Taxshield - Dividend",      
      "folioAccount": "0359903636637",
      "payInType": "Pay In"
      },{
      "fundDesc": "Franklin Asian Equity Fund - Dividend",      
      "folioAccount": "3049903636638",
      "payInType": "Bill Pay"
      }],
      "uploadImages":[{
        "imageLink":"Desert"
      },{
        "imageLink":"wildlife"
      }],
      "bankName": "HDFC Bank",
      "type":"Payout Type",
      "ifscCode":"IFSC Code",
      "bankAccountNo": "17259164",
      "payOutType": "Direct",
      "ifscCodeNo": "HDFC0008567"   
      }, {
      "fundDetails": [{
      "fundDesc": "Franklin India Prima Plus - Dividend",
      "folioAccount": "0029903636639",
      "payInType": "E-Mandate"      
      },{
      "fundDesc": "Franklin India Bluechip Fund - Growth",
      "folioAccount": "0069903636640",
      "payInType": "NACH"      
      },
      {
      "fundDesc": "Franklin India Taxshield - Dividend",
      "folioAccount": "0359903636641",
      "payInType": "Pay In"      
      },{
      "fundDesc": "Franklin Asian Equity Fund - Growth",
      "folioAccount": "3049903636642",
      "payInType": "Bill Pay"      
      }],
      "uploadImages":[{
        "imageLink":"Desert"
      },{
        "imageLink":"wildlife"
      }],
      "bankName": "Dena Bank",
      "type":"Payout Type",
      "ifscCode":"IFSC Code",
      "bankAccountNo": "17259166",
      "payOutType": "Cheque",
      "ifscCodeNo": "DENA0000010"   
      }, {
      "fundDetails": [{
      "fundDesc": "Franklin India Prima Plus - Dividend",
      "folioAccount": "0029903636643",
      "payInType": "E-Mandate"      
      },{
      "fundDesc": "Franklin India Bluechip Fund - Growth",
      "folioAccount": "0069903636644",
      "payInType": "NACH"      
      },
      {
      "fundDesc": "Franklin India Taxshield - Growth",
      "folioAccount": "0359903636645",
      "payInType": "Pay In"      
      },{
      "fundDesc": "Franklin Asian Equity Fund - Growth",
      "folioAccount": "3049903636646",
      "payInType": "Bill Pay"      
      }],
      "uploadImages":[{
        "imageLink":"Desert"
      },{
        "imageLink":"wildlife"
      }],
      "bankName": "CITI Bank",
      "type":"Payout Type",
      "ifscCode":"IFSC Code",
      "bankAccountNo": "17259168",
      "payOutType": "Direct",
      "ifscCodeNo": "CITI0000004"   
      }]
  }

});

InvBasisBankAccLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvBasisBankAccLookUp table, please contact admin...');
    } else {
        InvBasisBankAccLookUp.remove({}, function(err) {
            console.log('InvBasisBankAccLookUp collection removed');
            InvBasisBankAccModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvBasisBankAccLookUp table, please contact admin...');
                }
                console.log('InvBasisBankAccLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvBasisBankAccLookUp;
