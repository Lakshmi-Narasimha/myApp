export { PagerComponent } from './pager.component';
export { PaginationComponent } from './pagination.component';
export { PaginationModule } from './pagination.module';
