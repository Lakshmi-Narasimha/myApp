'use strict';

var eventConstants = (function() {
    return {

        LoginSuccess: 'loginSuccess',
        // Dashboard Module
        Dashboard: {
            ADV_DB_PROF_DET: 'advisorProfileDetails',
            ADV_DB_QUICK_LINKS: 'advisorQuickLinks',
            ADV_DB_NOTIF: 'advisorNotifications',
            ADV_DB_RECM: 'advisorRecommendations',
            ADV_RC_CNT: 'advisorRecommendationsCount',
            ADV_NOT_CNT: 'advisorNotificationsCount',
            ADV_DB_SIP: 'SIPDetails',
            GetAdvisorContentWidgets: 'getAdvisorContentWidgets',
            ADV_DB_BH_DET: 'businessHighlights',
            ADV_DB_TRANS: 'advisorTransactionStatus',
            ADV_DB_SIDE_NAV_TOGGLE: 'toggleSideNav',
            ADV_DB_USR_CHECK_UPDATE_EMIT: 'updatePersonalizedCheckEmit'
        },

        reports : {
            RECOMM_AND_NOTIFI_DATA : 'recommAndNotifiData'
        },
        
        collaterals: {
            REMOVE_FOCUS_CLASS:'removeFocusClass'
        },

        CHECKBOX_CHECKED : 'checkboxChecked',
        ACTION_ICON_CLICKED : 'iconClicked',
        CHK_ACTION_CLICKED : 'checkboxActionIconClicked',
        SHOW_SEARCH_RESULT : 'showSearchedResult',
        HIDE_SEARCH_RESULT : 'hideSearchedResult',
        CHANNEL_AUTO_SEARCH_OPTION_CHANGED :'channelAutoSearchOptionChanged',
        GET_SUGGESTIONS : 'getSuggestions',
        SET_SUGGESTIONS : 'setSuggestions',
        COMMOM_IRD : 'instantReportsDetails',
        CHANNEL_AUTO_SEARCH_OPTION_RESET :'channelAutoSearchOptionReset',
        RESET_CHANNEL_AUTO_SEARCH_OPTION :'resetChannelAutoSearchOption',
        ADV_MP_CHG_SCRT_QA_UPD : 'secretQAUpdated',
        ADV_MP_SCRT_QUES : 'secretQuestions',
        ACTION_BUTTON_CLICKED :'buttonClicked',

        // For Loader
        LOADER_MESSAGE : 'Loader Message',
        ON_MENU_DETAILS : 'menuDetails',

        //Paperless
        PAPERLESS_CONTINUE_CLICKED : 'Paperless Continue',
        PAPERLESS_VALIDATED : 'Paperless Validated',
        PAPERLESS_QUICK_LOGIN_SUCCESS : 'Paperless Quick login registration success',

        //Mailback constants for Investor
        INV_MAILBACK_CLICKED_SUC:'invMailbackSuccess',
        INV_MAILBACK_CLICKED:'invMailbackClicked',
        transactNow : {
            FOLIO_DETAILS : 'folioDetails'
        },

        //Recommendations And Notifications
        RECOMM_AND_NOTIFI_DATA:'recommAndNotifiData',
        CLOSE_LOGIN_POPUP : 'Close Quick Login Popup',
        REMOVE_FOCUS_CLASS:'removeFocusClass',

        // navigation check for transaction data lost pop on redirection
        NAVIGATE_CHECK : 'navigateCheck',
        //Proceed to buy - Investor
        INV_OPEN_LUMP_ACC: 'OPEN_LUMPSUM_ACC',
        INV_OPEN_SIP_ACC: 'OPEN_SIP_ACC',
        //SIP validation
        SIP_VALIDATION_FAILED:'sipvalidationfailed'
    };

}());

eventConstants.$inject = [];
module.exports = eventConstants;
