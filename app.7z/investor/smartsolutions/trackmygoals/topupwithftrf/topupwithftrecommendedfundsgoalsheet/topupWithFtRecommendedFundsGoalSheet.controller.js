'use strict';
function smartSolsTopupWithFtRecommendedFundsCtrl($scope, $state, recommendedPlanModelService, planSmartSolution, buildPlanModelService, investorGoalModelService) {

    $scope.init = function () {
        $scope.config.stepsConfig.activeStep = 2;
        var planSmartSolutionDetails = planSmartSolution.getSmartSolutionDetails(),
            goalSummary = angular.copy(investorGoalModelService.getSelectedGoalData());
        $scope.keyValueList = [
            {key: "Goal Name", value: goalSummary.goal},
            {key: "Goal Deficit", value: goalSummary.targetAmount - ((goalSummary.achieved.split("%")[0] * goalSummary.targetAmount) /100)},//goalSummary.goal
            {key: "Balance Tenor", value: goalSummary.pendingTimeFrame}
        ];
        planSmartSolution.setGoalSummaryData($scope.keyValueList);

        $scope.investmentSummary = {
            "fundDetails": buildPlanModelService.getGoalPlanData(),
            "total": buildPlanModelService.getGoalTotalPlanData()
        };
        $scope.goalChartData = planSmartSolution.getInvestmentSimulation();
    };

    $scope.init();


    /*$scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function ($event) {
        $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
        $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
        $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
        $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
        //console.log($scope.goalChartData);

    });*/
    $scope.goBack = function () {
        $state.go('smartSol.investor.currentPlan');
    };

    $scope.proceedGoalSheet = function () {
        $scope.fundDtls= "smartSol.planSmartSolution.fundDetailsSS.investment";
        planSmartSolution.setFundDetailsState($scope.fundDtls);
        $state.go('smartSol.planSmartSolution.fundDetailsSS');
    };

    $scope.savedSmartSolBtn = function () {
        $scope.$emit("smartSolSaveBtn");
    };
    $scope.emailInvbtn = function () {
        $scope.$emit("smartSolEmailBtn");
    };


}

smartSolsTopupWithFtRecommendedFundsCtrl.$inject = ['$scope', '$state', 'recommendedPlanModelService', 'planSmartSolution', 'buildPlanModelService', 'investorGoalModelService'];
module.exports = smartSolsTopupWithFtRecommendedFundsCtrl;