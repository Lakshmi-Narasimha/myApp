/**
 * @ngdoc directive
 * @name fatcaForm
 * 
 * @description
 *
 * - fatcaForm directive to be used for eKYC, investor registration & create new folio flows.
 **/
 'use strict';

var fatcaForm = function(formDetailsModel, $state, $timeout, transactModel, paperlessModel,transactEventConstants, appConfig, configUrlModel) {
	return {
		template: require('./fatcaForm.html'),
		restrict: 'E',
		scope: {
			formData:"=",
			formEkyc : "="
		},
		controller:['$scope', function($scope){ 
			var taxIdDetails,
				cnt = 1,				
				taxResidentArray = [],				
				taxResCountryArr = [],
				tsxResidentObj = null,
				taxObj = null,
				holder = $scope.formData.type;

			$scope.inputData = [];
			$scope.templates = [];
			$scope.privacyURL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')]+"/investor/security-and-privacy";
			$scope.formEkyc.fatcaArray = [];			
			$scope.regFormCnfigObj = {};
			$scope.fromStateVariable = transactModel.getTransactType();
			$scope.taxResidentDetailsData = [{title:"Tax Resident Country", value:"Tax Resident Country"}];			

			$scope.userNameObject = {
				key : "name",
				text : "Name Of the Applicant",
				name : holder+"userName",
				isRequired : true,
				type : "text",
				value : $scope.formData.name || '',
				disable : $scope.formData.name || false
			};
			$scope.panObject = {
				key : "pan",
				text : "PAN/PEKRN",
				name : holder+"pan",
				type : "text",
				pattern : '(([a-zA-Z]{5})(\\d{4})([a-zA-Z]{1}))',
				isRequired : true,
				minlength : 10,
				maxlength :10,
				value : $scope.formData.pan || '',
				disable : $scope.formData.pan || false
			};
			$scope.aadhaarObject = {
				key : "aadhar",
				text : "Aadhaar",
				name : holder+"Aadhaar",
				isRequired : false,
				type  : "number",
				isEditable : false,
				maxlength : 12,
				minlength : 12,
				value : parseInt($scope.formData.aadhar) || '',
				disable : $scope.formData.aadhar || false
			};
			$scope.mobileObject = {
				key : "Mobile",
				text : "Mobile",
				name : holder+"mobile",
				type: "number",
				isRequired : true,
				maxlength : 10,
				minlength : 10,
				value : $scope.formData.mobile || '',
				disable : $scope.formData.mobile || false
			};
			$scope.emailObject = {
				key : "Email",
				text : "Email",
				name : holder+"mail",
				type : "email",
				pattern : /^[A-Za-z0-9._]+[A-Za-z0-9._]+@[A-Za-z]+\.[A-Za-z.]{2,5}$/,
				isRequired : true,
				value : $scope.formData.email || '',
				disable : $scope.formData.email || false
			};
			$scope.dobName = holder+"dob";			

			$scope.cntryObject = {
				key : "country",
				text : "Country of Birth",
				type : "text",
				name : holder+"country",
				isRequired : true,
				value : $scope.formData.country || '',
				pattern : /^[A-Za-z]+(\s[A-Za-z]+)*$/
			};
			
			$scope.placeObject = {
				key : "place",
				text : "Place of Birth",
				type : "text",
				name : holder+"place",
				isRequired : true,
				value : $scope.formData.birthPlace || '',
				pattern : /^[A-Za-z]+(\s[A-Za-z]+)*$/
			};

			$scope.checkBoxLabel = {
				label:"I/we hereby declare that the information provided above is to the best of my knowledge & belief, is accurate and complete. I agree to notify Franklin Templeton Asset Management (l)Private Limited immediately in the event the information is the self certification changing.",
				value: $scope.formData.termsCheck ||  false,
				name : holder+"checkBox",
				required : true
			};
									 	
			$scope.$on(transactEventConstants.transact.FATCA_DETAILS, function() {				
				$scope.fatcaObj = {};
				$scope.formEkyc.fatcaArray.push({
					'name': $scope.userNameObject.value || "",
					'pan': $scope.panObject.value || "",
					'aadhar': $scope.aadhaarObject.value || "",
					'mobile': $scope.mobileObject.value || "",
					'email': $scope.emailObject.value || "",
					'dob' : $scope.stpDetails.startDate	|| "",
					'country' : $scope.cntryObject.value || "",
					'birthPlace' : $scope.placeObject.value || "",
					'residentRadios' : $scope.residentRadios[0].model || "",	
					'taxDetailsArr': $scope.regFormCnfigObj.taxValue==undefined?null:$scope.regFormCnfigObj.taxValue,
					'taxIDNumArr' : $scope.templates==undefined?null:$scope.templates,					
					'type' : $scope.formData.type || "",
					'address' : $scope.formData.address || "",
					'Title' : $scope.formData.Title || "",
					'modeOfKyc' : $scope.formData.modeOfKyc || $scope.formData.kycMode || "",
					'kycSource' : $scope.formData.kycSource || "",
					'kycStatus' : $scope.formData.kycStatus || "",
					'appIPVFlag' : $scope.formData.appIPVFlag || $scope.formData.ipvFlag || "",
					'termsCheck':$scope.checkBoxLabel.value || ""
				});			
				transactModel.setFatcaDetail($scope.formEkyc.fatcaArray);
				transactModel.isFatcaSuccess = true;
				
				paperlessModel.invDetails.setFactaDetails($scope.formEkyc.fatcaArray);
				paperlessModel.isFatcaSuccess = true;					
			});
			
		 	if ($scope.formData.taxIDNumArr) {
		 		angular.forEach($scope.formData.taxIDNumArr,function(obj, key){
		 			taxIdDetails = {};
		 			taxIdDetails = {
						key : "taxId",
						text:"Tax Identification Number",
						name : "taxId"+(key+1),
						type : "text",
						isRequired : true,
						value : $scope.formData.taxIDNumArr[key].value || ''
				 	};
				 	$scope.templates.push(taxIdDetails);
		 		});
		 	}
		 	else {
		 		taxIdDetails = {
					key : "taxId",
					text:"Tax Identification Number",					
					name : "taxId"+cnt,
					type : "text",
					isRequired : true,
					value :''
			 	};
			 	$scope.templates.push(taxIdDetails);
		 	}
						
			$scope.taxResidentDetails = {
				title:"Tax resident country",
				// label:"Tax resident country", 
				message : "",
				value: '',
				name : holder+"taxResidentDetails"+cnt,
				selected : $scope.formData.taxResCountry || '',
				isRequired : true
			};			
			$scope.residentRadios = [{
		            label:'Yes',
		            value: 'yes',
		            nameLbl : holder+ 'Yes',
		            model: $scope.formData.residentRadios || 'no',
		            checkedVal : 'yes'
		        },
		        {
		            label:'No',
		            value: 'no',
		            nameLbl : holder+ 'No',
		            model: $scope.formData.residentRadios || 'no',
		            checkedVal : 'no'
		        }
		    ];

		    if (transactModel.isPaperless) {
		 		$scope.paperless = true;
		 		$scope.panObject.disable = true;
		 	}

		    if ($scope.formData.residentRadios == 'yes') {
		    	$scope.isTaxResidentDisable = true;
		    }

			$scope.toggle = function(value, checkedVal){
				angular.forEach($scope.residentRadios, function(obj, key){
 					$scope.residentRadios[key].model = value;
 				});
 				if (checkedVal == 'yes') {
 					$scope.isTaxResidentDisable = true;
 				}
 				else if(checkedVal == 'no'){
 					taxResidentArray = [];
 					$scope.isTaxResidentDisable = false; 
 				}
 					
			}					
			$scope.anotherTemplate = function(){
				cnt++;
				taxIdDetails = {};
				taxIdDetails = {
					key : "taxId",
					text:"Tax Identification Number",
					name : "taxId"+cnt,
					type : "text",
					isRequired : true,
					value : ''
			 	};
				$scope.templates.push(taxIdDetails);
			}
			$scope.removeTaxResident = function(index){
				$scope.templates.splice(index,1);
				$scope.regFormCnfigObj.taxValue.splice(index,1);
			}
			 
			//Datepicker configuration
			$scope.today = function() {
				$scope.transactStartDate = new Date();
				var dd = $scope.transactStartDate.getDate();
				var mm = $scope.transactStartDate.getMonth();
				var yyyy = $scope.transactStartDate.getFullYear()-1;
				var startYear = $scope.transactStartDate.getFullYear();
				$scope.transactEndDate = new Date(yyyy, mm, dd);

				$scope.eightenthYear = new Date(startYear - 18, mm, dd);
            	$scope.eightenthYear = new Date($scope.eightenthYear.toDateString());
			};
			$scope.today();

			$scope.popup1 = {
				opened: false
			};

			$scope.popup2 = {
				opened: false
			};

			$scope.open1 = function() {
				$scope.popup1.opened = true;
			};

			$scope.open2 = function() {
					$scope.popup2.opened = true;
			};

			//Frequency select box options
			$scope.frequencyOptions = [
				{
					title : "Daily"
				},
				{
					title : "Weekly"
				},
				{
					title : "Monthly"
				},
				{
					title : "Quarterly"
				}
			];

			//Default Values
			$scope.dobDateOptions = {
				datepickerMode: 'day',
				minMode: 'day',
				yearRows: 3,
                yearColumns: 4,
                fulldatepickerMode:'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                monthColumns: 4,
                showWeeks: false,
				maxDate : new Date()
			}
			//As on date
			var tempCurrentDate = new Date();
			var dd = tempCurrentDate.getDate() + 1;
			var mm = tempCurrentDate.getMonth();
			var yyyy = tempCurrentDate.getFullYear()-1;
			var minDateforAsOn = new Date(yyyy, mm, dd);
			$scope.dateOptions = {
				datepickerMode: 'day',
				minMode: 'day',
				yearRows: 3,
                yearColumns: 4,
                fulldatepickerMode:'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                monthColumns: 4,
                showWeeks: false,
				maxDate : new Date(),
				minDate : minDateforAsOn
			}										

			//If dob comes from service - this formatting will be done bcz from service we will get date in dd/mm/yyyy format - Which javascript date will convert it as mm/dd/yyyy format
			var dobDateObject = "", dobFromData = $scope.formData.dob;

			dobFromData = $scope.formData.dobInNewDateFormat ? $scope.formData.dobInNewDateFormat : $scope.formData.dob;

			(dobFromData === " " || dobFromData === "null" || dobFromData === null) ? (dobDateObject = "") : (dobDateObject = dobFromData);
			var dob_regex = /^\d{2}\/\d{2}\/\d{4}$/;
			if(dobDateObject && dob_regex.test(dobDateObject)){
				var dobDateString = $scope.formData.dob;
				var dobDateParts = dobDateString.split("/");
				var dobDateObject = new Date(dobDateParts[2], dobDateParts[1] - 1, dobDateParts[0]);
			} 

			$scope.asOnStartDate = new Date();
			var dd = $scope.transactStartDate.getDate(),
			    mm = $scope.transactStartDate.getMonth(),
			 	yyyy = $scope.transactStartDate.getFullYear()-1;
			$scope.asOnEndDate = new Date(yyyy, mm, dd);
			
			$scope.stpDetails = {
				frequency : $scope.frequencyOptions[0].title,
				startDate : dobDateObject,
				endDate : $scope.transactEndDate,
				noofInstallments : $scope.noOfInstallments
			};

			$scope.checkBoxLabel = {
				label:"I/we hereby declare that the information provided above is to the best of my knowledge & belief, is accurate and complete. I agree to notify Franklin Templeton Asset Management (l)Private Limited immediately in the event the information is the self certification changing.",
				value: $scope.formData.termsCheck ||  false,
				name : holder+"checkBox",
				required : true
			};

			$scope.$on('transactFrequency', function(event, selectedValue){
				$scope.stpDetails.frequency = selectedValue.title;
			});

			// Function to find the given "value" in a given object array
            $scope.findItemInFilter = function(objArr, value){
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                        return (x.title == value || x.value == value);
                }))[0];
                return obj;
            };
			
			formDetailsModel.fetchFormResidentDetails().then(ResidentDtlsSuccess, ResidentDtlsFailure);
			function ResidentDtlsSuccess(data) {
				formDetailsModel.setTaxResidentCntry(data.codeValueList);
				var taxResidentDtls = formDetailsModel.getTaxResidentCntry();
				for(var i=0; i<taxResidentDtls.length; i++) {
					$scope.taxResidentDetailsData.push({title: taxResidentDtls[i].code, value : taxResidentDtls[i].value, id : "taxId"+(i+1)});
				}
				$scope.regFormCnfigObj.taxValue = [];
				
				if (paperlessModel.invDetails.hasData) {
					angular.forEach($scope.formData.taxDetailsArr, function(obj, key){
						$scope.regFormCnfigObj.taxValue.push($scope.findItemInFilter($scope.taxResidentDetailsData, obj.title));	
					})
				}
				else{
					$scope.regFormCnfigObj.taxValue.push($scope.findItemInFilter($scope.taxResidentDetailsData, $scope.taxResidentDetailsData[0].title));
				}
			}

			function ResidentDtlsFailure(data) {
				console.log('handleFailure');
			}						
		    
			$scope.$on('taxResidentValue', function(event, data){ 
				tsxResidentObj = {};  
				$scope.taxResidentDetails.selected = data.title;
				tsxResidentObj.selectedTaxResidentCountry = data.title;
				taxResCountryArr.push(tsxResidentObj);
				formDetailsModel.setTaxMethod(tsxResidentObj);
				if(tsxResidentObj.selectedTaxResidentCountry === "Tax Resident Country"){
					setFormFieldValidity($scope.taxResidentDetails.name, "required", false);
				}
				else{
					setFormFieldValidity($scope.taxResidentDetails.name, "required", true);
				}
			});
			
			$scope.dobChanged = function(dobDate){
				$scope.dobDateEntered = new Date(dobDate.toDateString());
				console.log("Previous eighthen year", $scope.eightenthYear);				
				console.log("DOB", $scope.dobDateEntered);
				if($scope.dobDateEntered >= $scope.eightenthYear){
					setFormFieldValidity($scope.dobName, "pattern", false);
				}else{
					setFormFieldValidity($scope.dobName, "pattern", true);
				}
			}

			function setFormFieldValidity(name, validationProperty, flag){
				$timeout(function(){
					$scope.formEkyc[name].$setValidity(validationProperty, flag);
				},0);
			}			
		}]
	};
};
fatcaForm.$inject = ['formDetailsModel', '$state', '$timeout', 'transactModel', 'paperlessModel','transactEventConstants', 'appConfig', 'configUrlModel'];
module.exports = fatcaForm;