// getAdvisorPreferences.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AdvisorPreferencesSchema = new mongoose.Schema({
    advisorPreferencesObject: {
        type: Array,
        "default": []
    }
});

var AdvisorPreferencesLookUp = mongoose.model('AdvisorPreferencesLookup', AdvisorPreferencesSchema);

var AdvisorPreferencesModel = new AdvisorPreferencesLookUp({

  "advisorPreferencesObject": [
    {
      "userWidgets": [{
        "sipBookOverview": {
          "date": "29-Feb-2016",
          "sipCount": "",
          "sipYtmNew": "184",
          "sipYtmMatured": "0",
          "sipYtmCancelled": "0",
          "sipYtmActive": ""
        },
        "transactionStatus": {
          "date":"23 apr 2016",
          "ct":{
             "processed":"12",
             "clarification":"12",
             "underProcessTxn":"12",
             "rejectedTxn":"12",
             "totalTxn":"48"
          },
          "nct":{
             "processed":"34",
             "clarification":"34",
             "underProcessTxn":"12",
             "rejectedTxn":"12",
             "totalTxn":"92"
          }
        }
      }]
    }
  ]

});

AdvisorPreferencesLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AdvisorPreferencesLookUp table, please contact admin...');
    } else {
        AdvisorPreferencesLookUp.remove({}, function(err) {
            console.log('AdvisorPreferencesLookUp collection removed');
            AdvisorPreferencesModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AdvisorPreferencesLookUp table, please contact admin...');
                }
                console.log('AdvisorPreferencesLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AdvisorPreferencesLookUp;
