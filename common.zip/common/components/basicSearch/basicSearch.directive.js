/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var fticSearch = function(eventConstants,searchResultModel) {
	return {
            template: require('./basicSearch.html'),
            restrict: 'E',
            replace: true,
            scope: {
              hideSearch : '='
            },
            controller:['$scope', function($scope){
                $scope.searchOption = '';

                $scope.searchData ={
                    searchText: ''                     
                };

                $scope.searchTextFlag = false;

                $scope.investorSearch = function(){
                  if(typeof($scope.searchData.searchText)==='object'){
                   $scope.searchData.searchText = $scope.searchData.searchText.first_name;
                  }                 
                    
                  if ($scope.searchData.searchText.length > 2) {
                      
                      searchResultModel.setSearchParam({searchText: $scope.searchData.searchText, searchOption: $scope.searchOption});
                      $scope.$emit(eventConstants.SHOW_SEARCH_RESULT, searchResultModel.getSearchParam());
                     
                  }
                  else if($scope.searchData.searchText.length == 0) {
                    searchResultModel.setSearchParam({searchText: $scope.searchData.searchText, searchOption: $scope.searchOption});
                    $scope.$emit(eventConstants.SHOW_SEARCH_RESULT, searchResultModel.getSearchParam());
                  }
                  else{
                      //$scope.searchTextChanged()
                      

                  }               
                };

                $scope.searchTextChanged = function(){
                    //if string length<3 hide the search result;
                    $scope.$emit('fundBasicFilter', {'filterText': $scope.searchData.searchText});
                    if($scope.searchData.searchText.length<2){
                      $scope.$emit(eventConstants.HIDE_SEARCH_RESULT, {});
                      $scope.suggestions = [];                                       
                    }else{
                      // $scope.$emit(eventConstants.GET_SUGGESTIONS, {searchText: $scope.searchData.searchText, searchOption: $scope.searchOption});
                    }
                    if($scope.searchData.searchText.length == 0){
                        $scope.searchTextFlag = false;
                    }else{
                        $scope.searchTextFlag = true;
                    }
                };

                $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, function (event, args) {                  
                  $scope.searchOption = args.req.lable;
                  $scope.searchData.searchText='';
                });

                $scope.$on(eventConstants.SET_SUGGESTIONS, function (event, args) {
                  $scope.suggestions = args.suggestions;
                });

                $scope.$on('RESET_SEARCH_OPTION',function(event, data){
                  $scope.searchData.searchText='';
                });

                $scope.investorSearchKeyEnter = function(evt){
                  if (evt.which == 13) {
                    $scope.investorSearch();
                  }
                };
              
            }],
            link: function(scope){                    
                scope.searchedText = '';
                scope.results = [];
                scope.suggestions = [];
            }
        };
};

fticSearch.$inject = ['eventConstants','searchResultModel'];
module.exports = fticSearch;