// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var STPRegdModelSchema = new mongoose.Schema({
    stpRegdResp: {
        type: Array,
        "default": []
    }
});

var STPRegdModelLookUp = mongoose.model('STPRegdModelLookUp', STPRegdModelSchema);

var STPRegdModel = new STPRegdModelLookUp({
    stpRegdResp : {
      "stpDetails": {
        "fundWiseData": [
          {
            "folioNo": "2341621",
            "sourceFund": "Franklin India Equity Fund - Growth",
            "destFund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "10,000"
          },
          {
            "folioNo": "3341621",
            "sourceFund": "Franklin India Equity Fund - Growth",
            "destFund": "Franklin India Flexi Cap Fund",
            "familySolution": "Yes",
            "frequency": "Monthly",
            "amount": "15,000"
          },
          {
            "folioNo": "4441621",
            "sourceFund": "Franklin India Equity Fund - Growth",
            "destFund": "Franklin India Bluechip Fund",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "18,000"
          },
          {
            "folioNo": "5541621",
            "sourceFund": "Franklin India Equity Fund - Growth",
            "destFund": "Franklin India Prima Plus",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "18,000"
          }
        ],
        "grandTotal": "43,000"
      }
    }
}
);

STPRegdModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating STPRegdModelLookUp table, please contact admin...');
    } else {
        STPRegdModelLookUp.remove({}, function(err) {
            console.log('STPRegdModelLookUp collection removed');
            STPRegdModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating STPRegdModelLookUp table, please contact admin...');
                }
                console.log('STPRegdModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = STPRegdModelLookUp;
