/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var arnDetails = function($timeout,constants,advisorRegistrationModelService,$filter) {
	return {
            template: require('./arnDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
                formObj:'='
            },
            controller:['$scope', function($scope){
                $scope.formData={};
                $scope.arnObject = {
                        key : 'arn',
                        text : 'ARN/RIA Code',
                        value : '',
                        name : 'arncode',
                        isRequired: true,
                        type: 'text'
                       };
                       
                // This is done for ARN Input field to accept only Alphabets, Numbers and Hyphens.
                $scope.validateInput = function(){
                    var re = new RegExp('^[a-zA-Z0-9-]*$');
                    if($scope.arnObject.value){
                        if (!re.test($scope.arnObject.value)) {
                            $scope.arnObject.value = $scope.arnObject.value.replace(/\W/g,'');
                        }
                    }
                };

                $scope.dateOptions = {
                    yearRows: 4,
                    yearColumns: 3,
                    fulldatepickerMode:'year',
                    formatMonth: 'MMM',
                    formatYear: 'yyyy',
                    formatDayTitle: 'MMM yyyy',
                    datepickerMode: 'day',
                    showWeeks: false,
                    maxDate: new Date()
                }
                $scope.$on(constants.login.ARN_SUBMTTED_TEXT,function(event){
                $scope.formData.panARN=$scope.arnObject.value;
                $scope.formData.dobOrRegDate =$filter('date')($scope.startDate, 'dd/MM/yyyy');
                /*$scope.formData.regType = "Adviser";*/
                advisorRegistrationModelService.setArnData($scope.formData);
              });
               

            }]
        };
};

arnDetails.$inject = ['$timeout','constants','advisorRegistrationModelService','$filter'];
module.exports = arnDetails;