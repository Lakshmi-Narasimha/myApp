/**
 * @ngdoc property
 * @name stepUpSip Directive
 * @requires $filter
 * @requires TransactConstant
 * @requires $timeout
 * @description
 *
 * - It handles the step-up sip functionality along with basic form validation. And binds the values to formDetails object.
 *
 **/
'use strict';

var stepUpSip = function ($filter, TransactConstant, $timeout) {
    return {
        template: require('./stepUpSipIncrement.html'),
        restrict: 'E',
        scope: {
            stepUpForm : "=",
            formDetails : "="
        },
        controller:['$scope', function ($scope) { 
            //Translate filter
            var translateFilter = $filter('translate');

            //Variables declaration and default option settings
            $scope.disablePerc = (!!$scope.formDetails && ($scope.formDetails.setpUpOption == "other")) ? false : true;
            $scope.stepUpForm.validPerc = true;
            $scope.stepUpForm.validAmount = true;

            $scope.increaseByAmtInpObj = {
                key : "increaseByAmt",
                text : translateFilter(TransactConstant.common.AMT) +" <span class='icon-fti_rupee'></span>",
                value : ($scope.formDetails.increaseByAmount)? $scope.formDetails.increaseByAmount : "",
                name : "increaseByAmt",
                type : "number",
                message : translateFilter(TransactConstant.common.MULTIPLES_OF) + " <span class='icon-fti_rupee'></span>" +"500",
                isRequired : (!!$scope.formDetails && ($scope.formDetails.setpUpOption == "amount")) ? true : false,
                disable : (!!$scope.formDetails && ($scope.formDetails.setpUpOption == "amount")) ? false : true,
                pattern: /^[0-9]*$/
            }

            $scope.increaseByOptions = [
                {
                    label: '10%',
                    value: '10',
                    type:'10perc',
                    selected: false
                },
                {
                    label: '20%', 
                    value: '20',
                    type:'20perc',
                    selected: false
                },
                {
                    label: '30%',
                    value: '30',
                    type:'30perc',
                    selected: false
                },
                {
                    label: 'Other',
                    value: 'other',
                    type:'other',
                    selected: false
                },
                {
                    label: '',
                    value: 'amount',
                    type:'amount',
                    selected: false
                }
            ];


            //Handles the radio options change functionality
            $scope.listenIncreaseByChange = function(type){
                $scope.disablePerc = true;
                $scope.stepUpForm.validPerc = true;
                $scope.stepUpForm.validAmount = true;
                $scope.increaseByAmtInpObj.disable = true;
                $scope.formDetails.increaseByPerc = "";
                $scope.increaseByAmtInpObj.value = "";
                $scope.increaseByAmtInpObj.isRequired = false;
                if(type == 'other'){
                    $scope.disablePerc = false;
                }
                else if(type == 'amount'){
                    $scope.increaseByAmtInpObj.disable = false;
                    $scope.increaseByAmtInpObj.isRequired = true;
                }
            }


            //Percentage field custom validation, if "Other" option is selected
            $scope.validatePrec = function(number){
                $scope.stepUpForm.validPerc = false;
                if(number % 5 == 0){
                    $scope.stepUpForm.validPerc = true;
                };
            }

            //Amount field custom validation, if "Amount" option is selected
            $scope.validateAmount = function(value){
                $scope.formDetails.increaseByAmount = $scope.increaseByAmtInpObj.value;
                if(value){
                    $scope.stepUpForm.validAmount = false;
                    var number = parseInt(value);
                    if(number % 500 == 0){
                        $scope.stepUpForm.validAmount = true;
                    }
                }
            }

        }]
    };
};

stepUpSip.$inject = ['$filter','TransactConstant','$timeout'];
module.exports = stepUpSip;