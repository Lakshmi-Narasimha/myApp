'use strict';


var selectInvVerticalTileList = function() {
return {
            template: require('./selectInvVerticalTileList.html'),
            restrict: 'E',
            replace: true,
            scope: {

            }
        }
   };     


selectInvVerticalTileList.$inject = [];
module.exports = selectInvVerticalTileList;  