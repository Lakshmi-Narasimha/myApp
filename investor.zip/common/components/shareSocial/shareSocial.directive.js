'use strict';

var fticShareSocial = function() {
	return {
            template: require('./shareSocial.html'),
            restrict: 'A',
            scope: {},
            controller: function($scope, $element, $attrs){   
                console.log("inside controller");                         
            },
            link: function(scope, iElement, iAttrs, controller){
                console.log("inside link");
            }
        };
};

fticShareSocial.$inject = [];
module.exports = fticShareSocial;