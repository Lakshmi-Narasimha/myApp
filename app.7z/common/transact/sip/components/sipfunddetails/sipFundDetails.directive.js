/**
 * @ngdoc property
 * @name sipFundDetails Directive
 * @requires sipDetailsModel
 * @requires eventConstants
 * @description
 *
 * - It will get the fund details from 'sipDetailsModel' and displays the details.  
 **/
'use strict';

var sipFundDetails = function (sipDetailsModel,eventConstants, $filter, TransactConstant, $state, transactEventConstants, fundDetails) {
    return {
        template: require('./sipFundDetails.html'),
        restrict: 'E',
        scope: {
            editRedirectState : "="
        },
        controller:['$scope', function ($scope) { 
            var translateFilter = $filter('translate'), endDate, futureDate, dateSplit, dateObj, date_regex = /^\d{2}\/\d{2}\/\d{4}$/;
            $scope.sipReviewDetails = fundDetails.getFundDetails();
            $scope.infoObj=[];
            function dateConverter(date){
                dateSplit = date.split("/");
                dateObj = new Date(dateSplit[2], dateSplit[1] - 1, dateSplit[0]);
                return dateObj;
            }
            angular.forEach($scope.sipReviewDetails, function(obj, key){
                endDate = $scope.sipReviewDetails[key].endDate;
                futureDate = $scope.sipReviewDetails[key].futureInstallment;
                endDate = (endDate && date_regex.test(endDate)) ? $filter('date')(dateConverter(endDate), 'MMM yyyy') : endDate;
                // futureDate = (futureDate && date_regex.test(futureDate)) ? futureDate.split("/")[0] +" day - "+ $filter('date')(dateConverter(futureDate), 'MMM yyyy') : futureDate;
                futureDate = (futureDate && date_regex.test(futureDate)) ? futureDate.split("/")[0] + "/"+ $filter('date')(dateConverter(futureDate), 'MM/yyyy') : futureDate;
                if($state.current.url === '/renewsip' || $state.current.url === '/sip'){
                    $scope.infoObj.push([
                        {
                            text: translateFilter(TransactConstant.transact.ACCOUNT_NUMBER),
                            value: $scope.sipReviewDetails[key].accNo
                        },
                        {
                            text: translateFilter(TransactConstant.transact.FUND_NAME),
                            value: $scope.sipReviewDetails[key].fundName
                        },
                        {
                            text: translateFilter(TransactConstant.sip.SIP_AMOUNT),
                            value: "<span class='icon-fti_rupee'></span>"+$scope.sipReviewDetails[key].sipAmount
                        },
                        {
                            text: translateFilter(TransactConstant.sip.DIVIDEND_OPTION),
                            value: $scope.sipReviewDetails[key].dividend
                        },
                        {
                            text: translateFilter(TransactConstant.sip.SIP_FIRST_INSTALLMENT_DATE),
                            value: $scope.sipReviewDetails[key].firstInstallment
                        },
                        {
                            text: translateFilter(TransactConstant.sip.SIP_FUTURE_INSTALLMENT),
                            value: futureDate
                        },
                        {
                            text: translateFilter(TransactConstant.sip.SIP_END_DATE),
                            value: endDate
                        },
                        {
                            text: translateFilter(TransactConstant.transact.FREQUENCY),
                            value: $scope.sipReviewDetails[key].frequency
                        },
                        {
                            text: translateFilter(TransactConstant.sip.STEP_UP_SIP_HEADING_RENEWSIP),
                            value: $scope.sipReviewDetails[key].stepUpSip
                        }
                    ]);
                }
                else{
                   $scope.infoObj.push([
                    {
                        text: translateFilter(TransactConstant.transact.ACCOUNT_NUMBER),
                        value: $scope.sipReviewDetails[key].accNo
                    },
                    {
                        text: translateFilter(TransactConstant.transact.FUND_NAME),
                        value: $scope.sipReviewDetails[key].fundName
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_AMOUNT),
                        value: "<span class='icon-fti_rupee'></span>"+$scope.sipReviewDetails[key].sipAmount
                    },
                    {
                        text: translateFilter(TransactConstant.sip.DIVIDEND),
                        value: $scope.sipReviewDetails[key].dividend
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_FIRST_INSTALLMENT),
                        value: $scope.sipReviewDetails[key].firstInstallment
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_FUTURE_INSTALLMENT),
                        value: futureDate
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_END_DATE),
                        value: endDate
                    },
                    {
                        text: translateFilter(TransactConstant.transact.FREQUENCY),
                        value: $scope.sipReviewDetails[key].frequency
                    },
                    {
                        text: translateFilter(TransactConstant.sip.STEP_UP_SIP_HEADING),
                        value: $scope.sipReviewDetails[key].stepUpSip
                    }
                ]); 
                }
                
            }); 

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){    
                $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'Fund'});   
                $scope.$emit(transactEventConstants.transact.guest.PAPERLESS_REVIEW_EDIT_TRIGGERED, {state:$scope.editRedirectState});
                $scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: 'Fund'});   
                $event.stopPropagation();              
            });

        }]
    };
};

sipFundDetails.$inject = ['sipDetailsModel','eventConstants', '$filter', 'TransactConstant', '$state', 'transactEventConstants', 'fundDetails'];
module.exports = sipFundDetails;