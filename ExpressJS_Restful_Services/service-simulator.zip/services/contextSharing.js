var fs = require('fs');
var path = require('path');
var _ = require('lodash');
var Datastore = require('nedb');
var ContextSharingService = function() {

    var dbFile = '/db/contextSharing.db';
    var db = null;

    // public functions

    this.putAdvsSessCntx = function(reqBody, success, error) {
        var clonedReqBody = _.clone(reqBody);
        var sessionObject = {data: clonedReqBody};
        db.insert(sessionObject, function (err, insertedSessionObject) {
            if (err) {
                error(err);
            } else {
                success({d: {
                    'cntxId': insertedSessionObject._id
                 }
                });
            }
        });
    };

    this.getAdvisorSessionContext = function(req, success, error) {

        var contextID = req.query.cntxId;
        db.findOne({ "_id": contextID }, function (err, contextInDB) {
            if (err) {
                error(err);
            } else {
                success(formatContextOutput(contextInDB));
            }
        });
    };

    // private functions

    function formatContextOutput(contextInDB) {
        var dataFromDB = contextInDB.data;

        var clientIDObjects;
        if (dataFromDB.putAdvsSessCntxClIds) {
            clientIDObjects = dataFromDB.putAdvsSessCntxClIds;
        } else {
            if (Array.isArray(dataFromDB)) {
                clientIDObjects = _.filter(dataFromDB, function(o) {return o.clId != null});
            } else {
                // no clients
            }
        }
        var clientIDs = [];
        _.forEach(clientIDObjects, function(aClientIDObject) {
            clientIDs.push({clId : aClientIDObject.clId});
        })

        var accountIDObjects;
        if (dataFromDB.putAdvsSessCntxAcctIds) {
            accountIDObjects = dataFromDB.putAdvsSessCntxAcctIds;
        } else {
            if (Array.isArray(dataFromDB)) {
                accountIDObjects = _.filter(dataFromDB, function(o) {return o.acctId != null});
            } else {
                // no accounts
            }
        }
        var accountIDs = [];
        _.forEach(accountIDObjects, function(anAccountIDObject) {
            accountIDs.push({acctId : anAccountIDObject.acctId});
        })

        var groupIDObjects;
        if (dataFromDB.putAdvsSessCntxGrpIds) {
            groupIDObjects = dataFromDB.putAdvsSessCntxGrpIds;
        } else {
            if (Array.isArray(dataFromDB)) {
                groupIDObjects =_.filter(dataFromDB, function(o) {return o.grpId != null});
            } else {
                // no groups
            }
        }
        var groupIDs = [];
        _.forEach(groupIDObjects, function(aGroupIDObject) {
            groupIDs.push({grpId : aGroupIDObject.grpId});
        })

        var distributorIDObjects;
        if (dataFromDB.putAdvsSessCntxDstrIds) {
            distributorIDObjects = dataFromDB.putAdvsSessCntxDstrIds;
        } else {
            if (Array.isArray(dataFromDB)) {
                distributorIDObjects = _.filter(dataFromDB, function(o) {return o.dstrId != null})
            } else {
                // no distributors
            }
        }
        var distributorIDs = [];
        _.forEach(distributorIDObjects, function(aDistributorIDObject) {
            distributorIDs.push({dstrId : aDistributorIDObject.dstrId});
        })

        var contextToReturn =
            {d: {'clIds' : {'results' : clientIDs},
                 'acctIds' : {'results' : accountIDs},
                 'dstrIds' : {'results': distributorIDs},
                 'grpIds' : {'results' : groupIDs}
                }
            };

        return contextToReturn;
    }

    function initialize() {
        initializeDB();
    }

    function initializeDB() {
        var dirPath = __dirname + dbFile;
        db = new Datastore({ filename: dirPath });
        var dbExists = fs.existsSync(dirPath);
        db.loadDatabase(function (err) {
            if (err) {
                console.log("Error loading context sharing simulator service DB at " + dirPath + ": " + err);
            } else {
                if (dbExists) {
                    console.log("context sharing simulator service DB at at " + dirPath + " was not initialized (already has data))");
                } else {
                    console.log("context sharing simulator service DB at " + dirPath + " established.");
                }
            }
        });
    }

    initialize();
}

module.exports = new ContextSharingService();

