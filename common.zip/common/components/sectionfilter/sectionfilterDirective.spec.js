/* eslint-disable */
'use strict';

describe('Directive: Section filter', function() {

  var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('commmon.components'));

    
    beforeEach(function() {

    angular.mock.inject(function($rootScope, $compile) {
        scope = $rootScope.$new();
        compile = $compile;
        scope.selectOptions = [
            { title:"Option A" },
            { title:'Monthly Bussiness Overview'},
            { title:'Monthly Bussiness Overview'},
            { title:'Monthly Bussiness Overview'},
            { title:'Monthly Bussiness Overview'}
        ];
        

        
        //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-section-filter section-options="selectOptions"></ftic-section-filter>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

  it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should define ftic-section-filter element', function() {
        expect(directiveEle.html()).toBeDefined();
        
    });

    /*it('should define ftic-section-filter element', function() {
        expect(directiveEle.scope.selected).toBeDefined(scope.selected);
        
    });*/
    it('should define objectProperty title to given value', function() {  
        
        expect(isoScope.sectionOptions[0].title).toEqual('Option A');
    });

});