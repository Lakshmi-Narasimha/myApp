/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var instantReportAccordion = function($state) {
	return {
            template: require('./instantReportAccordion.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              accordionData: "=",
              isToggleDisabled: "="
            },
            controller: function($scope, $element, $attrs){ 
                $scope.status = {
                    open:true
                };
            },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

instantReportAccordion.$inject = [];
module.exports = instantReportAccordion;