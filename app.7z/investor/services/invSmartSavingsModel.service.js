/**
 * @ngdoc service
 * @name invPurchaseDetailsModel service
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Eform Model deals with the fetching data from the service and returning the promise object as well as setting and getting the data. 
 *
 */

'use strict';

var invSmartSavingsModel = function(Restangular, $q, authenticationService, investorConstants, loggerConstants, fticLoggerMessage) {

    var params;
    var _selectedInvestorDtls = null,
        _selectedInvestorRedeemDtls = null,
        _selectedPaymentDtls = null,
        _selectedSmartSavingDtls = null,
        _selectedFundDtls = null;
    var invSmartSavingsModel = {

        postValidatePurchaseDtls: function(params) {
            var deferred = $q.defer();
            var preferences = { "guId": authenticationService.getUser().guId };
            Restangular.one('validatePurchases').customPOST(params, "", preferences, {}).then(function(successFlag) {
                deferred.resolve(successFlag);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        postValidateRedeemDtls: function(params) {
            var deferred = $q.defer();
            var preferences = { "guId": authenticationService.getUser().guId };
            Restangular.one('validateRedeem').customPOST(params, "", preferences, {}).then(function(successFlag) {
                deferred.resolve(successFlag);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getSmartSavingsDetails: function(paramsObj) {
            var deferred = $q.defer();
            params = paramsObj || {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one('getSmartSavings').get(params).then(function(response) {
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getFundDetails: function(paramsObj) {
            var deferred = $q.defer();
            params = paramsObj || {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one('smartFundDetails').get(params).then(function(response) {
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        postRemovePurchaseDtls: function(params) {
            var deferred = $q.defer();
            var preferences = { "guId": authenticationService.getUser().guId };
            Restangular.one('removePurchases').customPOST(params, "", preferences, {}).then(function(successFlag) {
                deferred.resolve(successFlag);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        postRemoveRedeemDtls: function(params) {
            var deferred = $q.defer();
            var preferences = { "guId": authenticationService.getUser().guId };
            Restangular.one('removeRedeem').customPOST(params, "", preferences, {}).then(function(successFlag) {
                deferred.resolve(successFlag);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },


        getPurchaseDtls: function() {
            return _selectedInvestorDtls;
        },
        setPurchaseDtls: function(selectedInvestorDtls) {
            _selectedInvestorDtls = selectedInvestorDtls;
        },
        getSelectedPaymentDtls: function() {
            return _selectedPaymentDtls;
        },
        setSelectedPaymentDtls: function(selectedInvestorDtls) {
            _selectedPaymentDtls = selectedInvestorDtls;
        },
        getSmartSavingsData: function() {
            return _selectedSmartSavingDtls;
        },
        setSmartSavingsData: function(selectedInvestorDtls) {
            _selectedSmartSavingDtls = selectedInvestorDtls;
        },
        getFundData: function() {
            return _selectedFundDtls;
        },
        setFundData: function(selectedInvestorDtls) {
            _selectedFundDtls = selectedInvestorDtls;
        }



    };
    return invSmartSavingsModel;
};

invSmartSavingsModel.$inject = ['Restangular', '$q', 'authenticationService', 'investorConstants', 'loggerConstants', 'fticLoggerMessage'];

module.exports = invSmartSavingsModel;
