coa = coa || {};
define(
		[ 'jquery', 'underscore', 'backbone', 'appmodules/coa/app/js/utils' ],
		function($, _, Backbone, Utils) {
			coa.collections.clientList = Backbone.Collection
					.extend({
						model : coa.models.Client,
						parse : function(response) {
							var _clientListResponse = response.d.results;
							var _clientCollection = [];
							var _that = this;
							$(_clientListResponse)
									.each(
											function(i, _clientData) {
												if (coa.user.get('clId') != _clientData.id) {
													var _client = {};
													var _clientEntity = {}, _clientType = "P";
													_clientType = _that
															.getCustomerType(_clientData);
													if (_clientType == "P") {
														_clientEntity = _clientData.personClient;
														_client.clId = _clientData.id;
														_client.id = _clientData.fmtId;

														_client.fName = _clientEntity.clFirstNm ? _clientEntity.clFirstNm
																: '';
														_client.lName = _clientEntity.clLastNm ? _clientEntity.clLastNm
																: '';
														_client.mName = _clientEntity.clMidNm ? " "
																+ _clientEntity.clMidNm
																		.charAt(0)
																: '';
														_client.fullName = Utils
																.lowerCase(_client.fName
																		+ ""
																		+ _client.mName
																		+ " "
																		+ _client.lName);
													} else {

														_clientEntity = _clientData.orgClient;
														_client.clId = _clientData.id;
														_client.id = _clientData.fmtId;
														_client.fName = _clientEntity.orgNm ? _clientEntity.orgNm
																: '';
														_client.lName = '';
														_client.mName = '';
														_client.fullName = Utils
																.lowerCase(_client.fName
																		+ ""
																		+ _client.mName
																		+ " "
																		+ _client.lName);
													}

													_client.grpId = coa.activeGrpId;
													_client.fmtGrpId = coa.activeGrpFmtId;
													_client.checked = true;
													_clientCollection
															.push(_client);
												}

											});
							return _clientCollection;

						},
						nextOrder : function() {
							if (!this.length) {
								return 1;
							}
							return this.last().get('order') + 1;
						},
						getCustomerType : function(resp) {
							var custTypeInfo = {};
							if (resp.customerTypeCd.toLocaleLowerCase() == "o") {
								return "O";
							} else {
								return "P";
							}
						}
					});
			coa.Clients = new coa.collections.clientList();
		});