define([
], function () {
    var config = {
        // E1
        //awmServicePath: 'https://eformsaar.dev.advisorcompass.com/ods.svc/',
        //oboServicePath: 'https://eformsaar.dev.advisorcompass.com/adv_capl/oboselector/',

        // LOCAL
        //awmServicePath: 'http://localhost:9040/simservice/',
        //oboServicePath: 'http://localhost:9040/simservice/',

        virtualizedServicePath: '',
        virtualizedServicePatterns: [],   // regexes for services that should be routed to virtualization
        //sendAnalyticsToOmniture: false,
        //enableAnalyticsConsoleLogging: false,
        //omnitureSAccount: "amppracviewerdev",
        //enableErrorLogging: false

        //DEV
        oboServicePath: 'http://dev12hq508.ampf.com/amp/adv_capl/oboselector/',
        //eformsServicePath: 'https://ctm.qa.advisorcompass.com/efm/ebene/service',
        awmServicePath:'http://dev12hq508.ampf.com/amp/ods.svc/'
    };

    return config;

});
