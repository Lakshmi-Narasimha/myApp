'use strict';

describe('Directive : Account details grid', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, accViewModel;
    var accountViewData = {
                'accountDetails': {
                'accountName': 'Franklin India Bluechip Dividend Fund',
                'accountNumber': '0349904865101',
                'gridData': {
                    'openingBalance': {
                        'totalUnits': '188.98'
                    },
                    'rows': [{
                        'txnDate': '15 Nov 2015',
                        'transaction': 'Opening Balance',
                        'amount': '6656',
                        'nav': '123.56',
                        'units': '34.9',
                        'totalUnits': '188.98',
                        'netAmount': '0'
                    },
                    {
                        'txnDate': '16 Nov 2015',
                        'transaction': 'Opening Balance',
                        'amount': '6657',
                        'nav': '124.56',
                        'units': '35.9',
                        'totalUnits': '189.98',
                        'netAmount': '0'
                    },
                    {
                        'txnDate': '17 Nov 2015',
                        'transaction': 'Opening Balance',
                        'amount': '6658',
                        'nav': '125.56',
                        'units': '36.9',
                        'totalUnits': '190.98',
                        'netAmount': '0'
                    },
                    {
                        'txnDate': '18 Nov 2015',
                        'transaction': 'Opening Balance',
                        'amount': '6659',
                        'nav': '126.56',
                        'units': '37.9',
                        'totalUnits': '191.98',
                        'netAmount': '0'
                    }]
                }
            }
        };

    beforeEach(angular.mock.module('investor'));

    var getCompiledElement = function() {
        var element = angular.element('<ftic-account-details-grid></ftic-account-details-grid>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {
        angular.mock.inject(function(_$rootScope_, _$compile_, _accountViewModel_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            accViewModel = _accountViewModel_;

            accViewModel.setAccountViewObj({
                'accountDetails': accountViewData.accountDetails
            });
        });

        directiveEle = getCompiledElement();
        isolatedScope = directiveEle.isolateScope();
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create separate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have accountName and accountNumber from isolated scope and populate view', function() {
        expect(isolatedScope.accountName).toBe('Franklin India Bluechip Dividend Fund');
        expect(isolatedScope.accountNumber).toBe('0349904865101');
        expect($(directiveEle).find('.fti-acc-no pull-left').prevObject[0].innerText).toContain('Franklin India Bluechip Dividend Fund');
    });

    it('should render date and other details from gridData', function() {
        var gridData = isolatedScope.gridData;
        expect(gridData).toBeDefined();
        expect(gridData[0].date).toContain("15 Nov 2015");
        expect(gridData[0].transaction).toContain("Opening Balance");
        expect(gridData[0].amount).toContain("6656");
        expect(gridData[0].nav).toContain("123.56");
        expect(gridData[0].units).toContain("34.9");
        expect(gridData[0].totalUnits).toContain("188.98");
    });

    it('should render headerCellClass and other details from columnDefs', function() {
        var columnDefs = isolatedScope.columnDefs;
        expect(columnDefs).toBeDefined();
        expect(columnDefs[2].field).toContain("amount");
        expect(columnDefs[2].width).toContain("115");
        expect(columnDefs[2].displayName).toContain("Amount");
        expect(columnDefs[2].headerCellClass).toContain("fti-grid-headercell");
    });
});
