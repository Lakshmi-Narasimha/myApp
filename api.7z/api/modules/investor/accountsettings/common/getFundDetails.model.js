// getInvestPopUpDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var SmartFundDetailsSchema = new mongoose.Schema({
    getFundDetails: {
        type: Object,
        "default": {}
    }
});

var SmartFundDetailsLookUp = mongoose.model('SmartFundDetailsLookUp', SmartFundDetailsSchema);

var SmartFundDetails = new SmartFundDetailsLookUp({
    getFundDetails: {
        'fundName': 'Franklin Savings -Direct-Growth',
        'productCode': '4616',
        'accountNo': '123456789',
        'allowableAmount':'50000'
    }
});

SmartFundDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating SmartFundDetailsLookUp table, please contact admin...');
    } else {
        SmartFundDetailsLookUp.remove({}, function(err) {
            console.log('SmartFundDetailsLookUp collection removed');
            SmartFundDetails.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SmartFundDetailsLookUp table, please contact admin...');
                }
                console.log('SmartFundDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SmartFundDetailsLookUp;
