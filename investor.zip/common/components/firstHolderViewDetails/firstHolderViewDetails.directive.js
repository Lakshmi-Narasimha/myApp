/**
 * @ngdoc directive
 * @name firstHolderView
 * 
 * @description
 *
 * - It will display all the details of the user
 **/
var firstHolderViewDetails = function ($state){
	return {
		template : require('./firstHolderViewDetails.html'),
		restrict : 'E',
		scope : {
			holderDetails : '=',
			formEkyc : "="
		},
		controller : function ($scope,$element,$attrs,transactNowModel, folioValidationInitialLoader, transactModel, transactEventConstants, folioValidationModelService){
              var taxIdDetails;
              $scope.cnt=0;
              $scope.templates = []
              $scope.isMobileFieldEnabled = false ;
              $scope.isEmailFieldEnabled = false;
              $scope.hideTextFields = true;



              $scope.anotherTemplate = function(){
					$scope.cnt++;
					taxIdDetails = {
						key : "taxId",
						text:"Tax Identification Number",
						name : "taxId"+$scope.cnt,
						type : "text",
						isRequired : true,
						value : ''
				 };
					$scope.templates.push(taxIdDetails)
				}

				angular.forEach($scope.holderDetails,function(obj,key){
	               
	               		obj.hideTextFields = false;
	                    if(key > 0){
	                    	 obj.hideTextFields = true;
	                    }
	                    $scope.holderDetails[key] = obj;
              	});    
				$scope.emailObject = {
					key : "Email",
					text : "Email",
					name : "mail",
					type : "email",
					pattern : /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/,
					isRequired : false,
					value : $scope.holderDetails[0].email
				};
				$scope.mobileObject = {
					key : "Mobile",
					text : "Mobile",
					name : "mobile",
					type: "number",
					isRequired : false,
					maxlength : 10,
					minlength : 10,
					value : $scope.holderDetails[0].mobile
				};

				$scope.addMobileField = function(){
	  				$scope.isMobileFieldEnabled = true ;
	               
				}
				$scope.addEmailField = function(){
 					$scope.isEmailFieldEnabled = true;
				}
              $scope.continueSubmission = function () {

              	var email = "";
              	var mobile = "";

 
              	if($scope.emailObject.value != null && $scope.emailObject.value.length > 0){
              		 email = $scope.emailObject.value;
              		 $scope.holderDetails[0].email = email;
              	}
              	if($scope.mobileObject.value != null && $scope.mobileObject.value.length > 0){
 					mobile = $scope.mobileObject.value;
 					$scope.holderDetails[0].mobile = mobile;
              	}

              	
              	

                transactNowModel.setVericationDetails($scope.holderDetails);
                if(transactModel.getSelectedFolioDts()==='Newfolio'){
	                folioValidationInitialLoader.loadAllServices($scope,transactModel.getFolioMatcherParams());
	                $scope.$on(transactEventConstants.transact.Folio_Validation,function(){
			          for(var i=0; i< transactModel.getrawHolderDts().length; i++){
			          	var folioMatcherParams = transactModel.getFolioMatcherParams();
			              folioMatcherParams[i].Title = (i==0) ?"First Holder Details" :(i==1 ? "Second Holder Details" : "Third Holder Details");
			              folioMatcherParams[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo;
			            }
			          transactModel.setInstantKyc(folioMatcherParams);
			          if(folioValidationModelService.getFolioValidationDtls().patternExists == 'true'){
				          $scope.headerOnPopUp="The similar holding pattern is available for investor";
				          $scope.noBtnTxt="Continue to Existing Folio";
				          $scope.yesBtnTxt="Create new Folio";
				          $scope.txtOnPopUp="Do you want to continue creating newfolio";
				          $scope.popUpMainHeader="";
				          $scope.showNotification=true;
			          }
			          else if(folioValidationModelService.getFolioValidationDtls().patternExists == 'false'){
			            transactModel.setIsNewFolio(true);
			              $state.go('transactnow.ekyc');
			              return;
			          }
			        });
				}
				else{
					$state.go('transactnow.ekyc');	
				}
              }
          	$scope.$on('yes', function () {
			  transactModel.setIsNewFolio(true);
			  $state.go('transactnow.ekyc');
			});
			$scope.$on('no', function () {
			  	transactModel.setIsNewFolio(false);
			  	var folioObj={};
				folioObj.folioId = folioValidationModelService.getFolioValidationDtls().folioNo;
				transactModel.setSelectedFolioDts(folioObj);
			  $state.go('transactnow.ekyc');
			});
		 }
	}
};
 firstHolderViewDetails.$inject = ['$state','transactNowModel', 'folioValidationInitialLoader', 'transactModel', 'transactEventConstants', 'folioValidationModelService'];
 module.exports = firstHolderViewDetails;