define(['lodash', 'backbone'], function ( _, Backbone) {
    var InterAppContext = Backbone.Model.extend({
        defaults: {
            contextId: null, // [String]
            fmids: [], // [String]
            clientIds: [], // [String]
            groupIds: [], // [String]
            accountIds: [], // [String]
        },
        asServiceRequestData : function() {
            var data = {};

            if (this.get('fmids').length) {
                data.putAdvsSessCntxDstrIds = _.map(this.get('fmids'), function(fmid) {
                    return {
                        dstrId : fmid,
                        dstrCtx: "DMU.DIST"
                    };
                });
            }
            if (this.get('clientIds').length) {
                data.putAdvsSessCntxClIds = _.map(this.get('clientIds'), function(clientId) {
                    return {
                        clId : clientId,
                        clCtx: "COLA.CL",
                        clRole: "PrimaryClient"
                    };
                });
            }
            if (this.get('groupIds').length) {
                data.putAdvsSessCntxGrpIds = _.map(this.get('groupIds'), function(groupId) {
                    return {
                        grpId : groupId,
                        grpCtx: "COLA.GRP"
                    };
                });
            }
            if (this.get('accountIds').length) {
                data.putAdvsSessCntxAcctIds = _.map(this.get('accountIds'), function(accountId) {
                    return {
                        acctId : accountId,
                        acctCtx: "COLA.ACCT"
                    };
                });
            }

            return data;
        },
        populateFromServiceResponse: function (responseEntity) {
            if(responseEntity){
                const clientIds = responseEntity.clIds ? (responseEntity.clIds.results.length > 0 ? responseEntity.clIds.results[0].clId : '') : '';
                const fmid = responseEntity.dstrIds ? responseEntity.dstrIds.dstrId : null;
                const groupIds = responseEntity.grpIds.results.length ? responseEntity.grpIds.results : [];
                this.set('clientIds', [clientIds]);
                this.set('fmids', [fmid]);
                this.set('groupIds', groupIds);
            }
			return this;
        }
    });

    return InterAppContext;
});

