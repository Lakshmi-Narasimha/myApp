'use strict';

var errorMsg = '//*[@class="error-placeholder"]/div[1]/div/p';
function waitUntilReady(elm) {
    browser.wait(function() {
        return elm.isPresent();
    }, 10000);
    browser.wait(function() {
        return elm.isDisplayed();
    }, 10000);
};

//function
describe('Authentication - User', function() {

    describe('Authentication Customer Lookup', function() {

        beforeEach(function() {
            browser.get('/#/billing/authentication');
            browser.waitForAngular();
        });

        it('TC1 - Authentication Landing Page', function() {
            var pageTitleStep1 = element(by.tagName('h1'));
            expect(pageTitleStep1.getText()).toEqual('Make a one-time payment');
            expect(element(by.linkText('Exit, one time payment.')).isDisplayed()).toBeTruthy();
            expect(element.all(by.css('btn-farmers-red')).isDisplayed()).toBeTruthy();
            expect(element(by.model('authVM.user.accountNumber')).isDisplayed()).toBeTruthy();
            expect(element(by.model('authVM.user.zipCode')).isDisplayed()).toBeTruthy();
        });

        it('TC2 - Fill Authentication and submit', function(){
            element(by.model('authVM.user.accountNumber')).sendKeys('G771987994');
            element(by.model('authVM.user.zipCode')).sendKeys('98102');
            element.all(by.css('btn-farmers-red')).click();
            browser.sleep(500);
        });

        it('TC2 - Fill Authentication and validate accountNumber', function(){
            element(by.model('authVM.user.accountNumber')).sendKeys('a.bbb11222');
            element(by.model('authVM.user.zipCode')).sendKeys('98102');
            element.all(by.css('btn-farmers-red')).click();
            // var errorMsg = element.all(by.css('error-placeholder')).element('p');
            expect(element(by.xpath(errorMsg))).toEqual('Please enter a valid policy or billing account number');
            browser.sleep(500);
        });

        /*it('TC2 - Contact Your Agent', function() {
            expect(element(by.linkText('Contact your agent')).isDisplayed()).toBeTruthy();
            element(by.linkText('Contact your agent')).click();
        });

        it('TC3 - 21st Century Insurance', function() {
            expect(element(by.xpath(Century21)).isDisplayed()).toBeTruthy();
            element(by.xpath(Century21)).click();
        });

        it('TC4 - Bristol West Insurance Group', function() {
            expect(element(by.xpath(bristolWest)).isDisplayed()).toBeTruthy();
            element(by.xpath(bristolWest)).click();
        });

        it('TC5 - Foremost Insurance Group', function() {
            expect(element(by.xpath(foreMost)).isDisplayed()).toBeTruthy();
            element(by.xpath(foreMost)).click();
        });*/


    });

});
