﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appcommon/constants',
  'appmodules/crm/crmcommon',
  'services/dataservice',
  'appmodules/crm/app/models/eventscollection',
  'appmodules/crm/app/models/calendarcontext',
  'appcommon/globalcontext',
  'moment',
  'fullCalendar',
  'jqueryui',
  'appcommon/commonutility',
  'appmodules/crm/app/views/calcontactsearch',
  'appmodules/crm/app/views/calendaruserpickerview',
  'text!appmodules/crm/app/templates/calendarview.html',
  'text!appmodules/crm/app/templates/calendarheaderview.html',
  'text!appmodules/crm/app/templates/addappointmentview.html',
  'text!appmodules/crm/app/templates/appointmentdetailview.html',
  'appcommon/analytics',
  'errorLog',
  'appmodules/nav/app/models/contactdetails',
  'apipublic/navapi',
  'appcommon/nativeadaptor',
  'appcommon/applauncher/device',
  'appmodules/ncst/app/data/country-list',
  'components/js/views/EventColorLegendView',
  'text!components/template/EventColorLegendView.html',
], function ($, _, Backbone, Spinner, Constants, Utility, Dataservice, EventsCollection, CalendarContext, GlobalContext, Moment, FullCalendar, JqueryUI, CommonUtilis, ContactSearchView, CalendarUserPickerView, CalendarView, CalendarHeaderView, AddAppointmentView, AppointmentDetailView, Analytics, ErrorLog, ContactDetailsModel, NavApi, NativeAdaptor, Device, CountryList, EventColorLegendView, EventColorLegendViewTemplate) {
    var getDateFrmDayView = new Date();
    var dtSelectedFrmWeekAndDay = false;
    var calendarview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: '#practicetech-subapp',
        userPickerView: null,
        storePrevDtInstance: null,
        evtColorLegendModalView: null,
        headerTemplate: _.template(CalendarHeaderView),
        events: {
            "click #addNewItem": "agendaClickEvent",
            "click .fc-button-prev, .fc-button-next": "calendarPrevNextBtnClick",
            "click #monthBtn": "calMonthBtnClick",
            "click #weekBtn": "calWeekBtnClick",
            "click #agendaBtn": "calAgendaBtnClick",
            "click #full-week": "calFullWeekBtnClick",
            "click #work-week": "calWorkWeekBtnClick",
            "click .app-timings .val, .app-timings .valtime, #app-more-opts .val, .app-type .val, .app-subtype .val, .app-participants .val, .app-rep-starts .val, .list-of-participants, .app-keywords .val, .app-clients .val": "getMoreOptions",
            "click .app-start-date .val, .app-end-date .val": "toggleDatePicker",
            "click #newEvent": "validateThenMoveSlide",
            "click #appModalCancel": "cancelModal",
            "click #appModalAdd": "saveAddAptEvent",
            "click #addApptBtn": "addAppointment",
            "click #appModalEdit": "editAppointment",
            "click .app-private a.choice-list-button, .app-all-day a.choice-list-button": "yesNoOpts",
            "click .app-part-li input": "isChecked",
            "click .app-type-li input, .app-sub-type-li input, .app-keywords-li input": "isRadioChecked",
            "click .selectAll": "selectAll",
            "click #delEventYes": "deleteEvent",
            "click #saveAppointment": "saveEditApt",
            "shown.bs.modal #viewEventModal, #addAppointment": "adjustModalHeight",
            "click #calendar-lt>h2": "toggleCalendarDisplay",
            "click #markCancelYes": "markActivityAsCancelled",
            "click #markCompYes": "markActivityAsCompleted",
            "click #delEvent, #markComp, #markCancel": "showWarningPopup",
            "click #markCancelNo, #delEventNo, #markCompNo": "hideWarningPopup",
            "change #hr-start-sel": "startHrChange",
            "change #mins-start-sel": "startMinuteChange",
            "change #ampm-start-sel": "startAmPmChange",
            "change #hr-end-sel,#mins-end-sel,#ampm-end-sel": "beforeCheckStartDate",
            "click .viewContactPage": "viewContactFromCal",
            "click [pt-calendar-show-users]": "calShowUsersClick",
            "click #evt-color-setting": "showEventColorLegendModal",
        },
        initialize: function () {
            var that = this;

            //Device Form Factor
            /*Device.operatingSystem();
            Device.physicalDevice();
            that.isDeviceSmall = Device.info.hardware.formFactor == "Small"? true: false;*/

            this.editingEvtDetails = {};
            this.calMode = "week";
            this.eventsCollection = new EventsCollection.Events();
            this.eventsCollection.bind('reset', this.eventsCollectionEvent);
            this.fmId = undefined;
            this.pinnedContact = {
                pinnedContactId: undefined,
                pinnedClientId: undefined,
                pinnedContactType: undefined,
                pinnedContactFirstName: undefined,
                pinnedContactLastName: undefined
            };
            this.selectedContactId = undefined;
            this.selectedContactType = undefined;
            this.calLnks = undefined;
            this.fullWorkWeekLnks = undefined;
            this.keyword = null;
            this.threeMonthEvents = [];
            this.currentEvent = {};
            //to hide the spinner only on the succes of both services
            this.monthServiceCounter = 0;
            this.calContactViewObj = null;
            this.globalContext = GlobalContext.getInstance();
            //Below is the hack for iOS and -webkit-overflow-scrolling: touch
            $(document).on('touchstart', '#addAppointment', function () { });
            $(document).on('touchstart', '#pt-date-picker-overlay', function (event) {
                event.preventDefault();
                var ele = $(event.toElement);
                if (!ele.hasClass("hasDatepicker") && !ele.hasClass("ui-datepicker") && !ele.hasClass("ui-icon") && !$(ele).parent().parents(".ui-datepicker").length) {
                    $(".hasDatepicker").blur().datepicker("hide");
                }
                $('.scrollToTop').removeClass('hidden');
            });

            /*$(document).off('click', '#week-date-picker, #day-date-picker, img.ui-datepicker-trigger').on('click', '#week-date-picker, #day-date-picker, img.ui-datepicker-trigger', function (e) {
                that.alignTheDtPicker(["week-date-picker", "day-date-picker"]);
            });*/

            $(window).off('resize orientationchange', calViewResizeHandler).on('resize orientationchange', calViewResizeHandler);

            $(document).off('focus', '#week-date-picker').on('focus', '#week-date-picker', function (e) { that.onFocusOfWeekPicker(e); });
            $(document).off('click', '.ui-datepicker-prev, .ui-datepicker-next')
                       .on('click', '.ui-datepicker-prev, .ui-datepicker-next', function (e) {
                           $('#week-date-picker, #day-date-picker').blur();
                       });

            this.selContactDetails = "";
            _.bindAll(this, 'goToToday', 'stowCalendarUsers');
            function calViewResizeHandler() {
                that.alignTheDtPicker(["week-date-picker", "day-date-picker"]);
                // If user in browser navigates from sm to md/lg (or) md/lg to sm - adjust the date picker if opened
                if (!that.isDeviceSmall()) {
                    $("#calendar.DayViewCalendar").css('margin-top', '8px');
                }
            }
        },
            close: function () {
            //While navigating away from the crm page, reset the getDateFrmDayView to current date
            var hashStr = window.location.hash;
            if(hashStr.indexOf("crm") == -1 || hashStr.match("#crm/tasks|#crm/addtask|#crm/edittask")) {
                getDateFrmDayView = new Date();
        }
            //Below is the hack for iOS and -webkit-overflow-scrolling: touch
            $(document).off('touchstart', '#addAppointment', function () {
        })
            //Unbinding TimeLine Interval for current time bar
            if (typeof (window.timelineInterval) != "undefined") window.clearInterval(timelineInterval);
            //Unbinding other events
            if (this.beforeClose) {
this.beforeClose(); }
            this.undelegateEvents();
            $(this).empty;
            this.unbind();
            },
            beforeClose: function () {
                if (this.userPickerView) {
                    this.userPickerView.close();
                }
                if (this.evtColorLegendModalView) {
                    this.evtColorLegendModalView.close();
                }
                this.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
            },
                isDeviceSmall: function () {
                    Device.operatingSystem();
                    Device.physicalDevice();
                    return (Device.info.hardware.formFactor == "Small" ? true: false);
                    },
                toggleDatePicker: function (e) {
                    var that = this;
                    var eleId = e.currentTarget.id;
                    if(eleId.indexOf('start') > -1) {
                        $('#add-app-end-dtpickr').hide();
                        $('#add-app-start-dtpickr').slideToggle(200);
                        } else if (eleId.indexOf('end') > -1) {
                            $('#add-app-start-dtpickr').hide();
                            $('#add-app-end-dtpickr').slideToggle(200);
            }
            setTimeout(function () { that.adjustModalHeight(); }, 210);
            },
                onFocusOfWeekPicker: function (e) {
                    var that = this;
                    var firstday = that.currDtOrWkMonday();
                    that.setNavigatedViewAndDate('agendaWeek', new Date(firstday));
                    if (e.type == 'focusin') { //on focus
                        $("#week-date-picker").val(firstday);
                        } else if (e.type == 'focusout') { //on blur
                            $("#week-date-picker").val($('.WeekViewCalendar .fc-header-title > h2').text());
            }
            },
                currDtOrWkMonday: function () {
                    var curr = $('#calendar').fullCalendar('getDate');
                    var currDate = new Date(curr);
                    curr.setHours(0, 0, 0, 0);

                    //if future navigated week is 'not' same as current dated week, change the DD to navigated week Monday
                    var firstday;
                    if(!moment($('#calendar').fullCalendar('getView')).isSame($('#calendar').fullCalendar('getDate'), 'week') && !dtSelectedFrmWeekAndDay) {
                        firstday = moment(moment($('#calendar').fullCalendar('getView').start).add(1, 'days').toDate()).format('MM/DD/YYYY'); //Convert the time to UTC and MM/DD/YYYY format
                    } else {
                        firstday = moment(currDate).format('MM/DD/YYYY');
            }
            return firstday;
            },
                closeTheDatePicker: function (whichPicker) {
                    $.each(whichPicker, function (index, value) {
                        var thisPicker = $("#ui-datepicker-div." +value);
                        if (thisPicker.is(':visible')) {
                            $('#' +value).datepicker('hide').blur();
                }
            });
            },
                alignTheDtPicker: function (whichPicker) {
                    $.each(whichPicker, function (index, value) {
                        var thisPicker = $("#" +value);
                        var winWidth = $(window).width();
                        var pickerWidth = $("#ui-datepicker-div." +value).outerWidth();
                        if (value == 'week-date-picker') {
                            if ($("#ui-datepicker-div." +value).length > 0) {
                        $("#ui-datepicker-div." +value).css({ "position": "absolute", "left": ((winWidth -pickerWidth) / 2) + $(window).scrollLeft() + "px", "top": thisPicker.offset().top +thisPicker.outerHeight()
                        });
                        }
                } else if (value == 'day-date-picker') {
                    if ($("#ui-datepicker-div." +value).length > 0) {
                        if (thisPicker.width() <= 200) {
                            $("#ui-datepicker-div." +value).css({ "left": thisPicker.offset().left + "px"
                        });
                        } else if ((thisPicker.width() > 200 && thisPicker.width() < 221) || (thisPicker.width() > 221)) {
                            //$("#ui-datepicker-div." + value).css({ "left": "30px", "top": thisPicker.offset().top + thisPicker.outerHeight() });
                            $("#ui-datepicker-div." +value).css({ "position": "absolute", "left": ((winWidth -pickerWidth) / 2) + $(window).scrollLeft() + "px", "top": thisPicker.offset().top +thisPicker.outerHeight()
                        });
                        } else if (thisPicker.width() == 221) {
                            $("#ui-datepicker-div." +value).css({ "left": "30px", "top": thisPicker.offset().top +thisPicker.outerHeight()
                        });
                }
                    }
                }
            });
            },
                showYScroll: function (ele) {
                //var modalBody = $('#addAppointment .modal-body');
                //if ($(ele).height() > 640) {
                /*if ($(ele).height() > 520) {
                    if (!this.isMobileOrDesktop()) { $(ele).css({ 'width': 320 }); }
                    modalBody.css({ 'overflow-y': 'auto', 'overflow-x': 'hidden' });
                } else {
                    alert('Coming Here');
                    if (!this.isMobileOrDesktop()) { $(ele).css({ 'width': 338 }); }
                    modalBody.css({ 'overflow-y': 'hidden', 'overflow-x': 'hidden' });
                }*/
                //this.subSecVerticalScroll(ele); - Vivek
                //$('.modal-body').animate({ scrollTop: 0 }, 0); -- Vivek
                this.animateToTop();
            //Vivek
                this.adjustModalHeight();
                },
            subSecVerticalScroll: function (ele) {
                /*var ulSubSec = $(ele + "> ul");
                if (ulSubSec.is(":first-child")) {
                    //if (ulSubSec.hasClass('sections') && $(ulSubSec)[0].scrollHeight > 640) {
                    if (ulSubSec.hasClass('sections') && $(ulSubSec)[0].scrollHeight > 520) {
                        if (!this.isMobileOrDesktop()) { $(ele).css({ 'width': 354 }); }
                    }
                } - Vivek */
            //if (ulSubSec > 640) { $('#app-sub-type-opts').css({ 'width': 354 }); }
            },
                animateToTop: function () { $('.pt-event-modal').animate({
            scrollTop: 0 }, 0); },
                deleteEvent: function () {
                    try {
                        var that = this;
                        Spinner.show();
                        Dataservice.deleteCalendarEvent(CalendarContext.getCalenderFMID(), $('#currentActivityId').text()).done(gotoSaveEditEventSuccess).fail(gotoEditEventFail);
                    function gotoSaveEditEventSuccess(data) {
                        var curr = new Date;
                        curr.setHours(0, 0, 0, 0);
                        var firstday = moment($("#calendar").fullCalendar('getView').start).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                        curr.setHours(23, 59, 0, 0);
                        var lastday = moment($("#calendar").fullCalendar('getView').end).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                        //For Month Day View Calendar
                        var view = $('#calendar').fullCalendar('getView');
                        if (view.name == "agendaDay") {
                        that.monthServiceCounter = 2;
                        var _curr = $('#calendar').fullCalendar('getDate');
                        that.loadEventsForMonthDayView(_curr.getFullYear(), _curr.getMonth() +1, curr);
                            // this.initialiseMonthDayView();
                        that.fetchMonthlyView(_curr.getMonth() +1, _curr.getFullYear());
                        } else {
                        that.loadEventsFromEbix(firstday, lastday);
                    }
                    $('#viewEventModal').modal('hide');
                        that.adjustingOverflow();
                        Analytics.analytics.recordAction('deleteCalendarActivity:save');
                        Spinner.hide();
                };

                function gotoEditEventFail(Error) {
                    Spinner.hide();
                    that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                    ErrorLog.ErrorUtils.myError(Error);
            };
            }
            catch (error) {
                Spinner.hide();
                that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                ErrorLog.ErrorUtils.myError(error);
            }

        },
                selectAll: function (e) {
            e.preventDefault();
            if($('.selectAll').text() == 'Select All') { // check select status
                $('.app-part-li input[data-name=calParticipants]').prop('checked', false).prop('checked', true);
                this.hasErrorInField('Participants', 'hide');
                $('.selectAll').text('Unselect All');
            } else {
                $('.app-part-li input[data-name=calParticipants]').prop('checked', false);
                this.hasErrorInField('Participants', 'show');
                $('.selectAll').text('Select All');
            }
        },
                yesNoOpts: function (e) {
            var _self = this;
            e.preventDefault();
            var parent = $(e.currentTarget).parent().parent().attr('class').split(' ')[0];
            var parentLi = $("." +parent + " > li > a.choice-list-button");
            parentLi.removeClass('active');
            $(e.currentTarget).addClass('active');
            if (parent == "app-all-day") {
                var busyOpt = $('.app-show-tm-sel select>option:eq(0)'); //Busy option in 'Show Time As'
                var freeOpt = $('.app-show-tm-sel select>option:eq(1)'); //Free option in 'Show Time As'
                //var freeOptTxt = $('.app-show-tm-sel .holder');
                var _evtDetails = this.editingEvtDetails.start;
                if (parentLi.first().hasClass('active')) {
                    $('#hr-start-sel,#hr-end-sel').val("12");
                    $('#mins-start-sel,#mins-end-sel').val("00");
                    $('#ampm-start-sel,#ampm-end-sel').val("AM");
                    _evtDetails.currentTime.hr = "12";
                    _evtDetails.currentTime.mins = "00";
                    _evtDetails.currentTime.ampm = "AM";
                    $(".app-start-time, .app-end-time").hide();
                    freeOpt.prop('selected', true)
                    //freeOptTxt.html(freeOpt.text());
                } else {
                    var _startEndTm = _self.currentTime();
                    $("#hr-start-sel").val(_startEndTm[0]); //startHr
                    $("#hr-end-sel").val(_startEndTm[3]); //endHr
                    $("#ampm-start-sel").val(_startEndTm[2]); //startAMPM
                    $("#ampm-end-sel").val(_startEndTm[5]); //endAMPM
                    _evtDetails.currentTime.hr = _startEndTm[0];
                    _evtDetails.currentTime.mins = "00";
                    _evtDetails.currentTime.ampm = _startEndTm[2];
                    $(".app-start-time, .app-end-time").show();
                    busyOpt.prop('selected', true);
                //freeOptTxt.html(busyOpt.text());
        }
            }
        },
                isChecked: function (e) {
                    var parent = $(e.currentTarget).parent();
                    var grandParent = $(parent).parent();

            //$(e.currentTarget).prop('checked',true);

            //For Participants
            if ($(parent).attr('class').split(' ')[0]== "app-part-li") {
                if ($(parent).children().is(":checked")) {
                    $("#" + grandParent.attr('id') + " .has-error").removeClass('bg-danger').hide();
            } else {
                $("#" + grandParent.attr('id') + " .has-error").addClass('bg-danger').show();
        }
            }
            },
                isRadioChecked: function (e) {
            //Type
            var parent = $(e.currentTarget.parentElement).parent().attr('class').split(' ')[0]; //getting first className from element
                    //var parentId = $(e.currentTarget.parentElement).attr('id');
                    $("." +parent + "> input[name=calActivityType]:checked").prop('checked', false);
                    $(e.currentTarget).prop('checked', true);

                    if(parent.indexOf('type') > -1 || parent.indexOf('sub-type') > -1) {
                        if (parent.indexOf('app-type') > -1) {
                            $(".app-type > .val").html($('input[name=calActivityType]:checked').val());
                            $(".app-subtype > .val").html('Select Sub-Type');
                        //Sub Type
                        var data_id = $(e.currentTarget).attr("data-id");
                        var subTypes = this.getSubActivityTypes(data_id);//Appointment
                        $(".app-sub-type-li").html(subTypes);
                        //this.subSecVerticalScroll('#parentId'); - Vivek

                } else if (parent.indexOf('app-sub-type') > -1) {
                    $(".app-subtype > .val").html(($('input[name=calSubType]:checked').val() == 'None') ? 'Select Sub-Type': $('input[name=calSubType]:checked').val());
                }
                        this.goToMainSlide();
                        } else if (parent.indexOf('keywords') > -1) {
                            $(".app-keywords > .val").html(($('input[name=calKeyword]:checked').val() == 'None') ? 'Select Keyword': $('input[name=calKeyword]:checked').val());
                            $(".app-keywords > .val").attr('data-id', $(e.currentTarget).data('id'));
                            this.goToSlide("app-more-options", "app-keywords-3");
                }
            //Vivek
                    this.adjustModalHeight();
                    },
                getActivityTypes: function () {
                    var activityTypes = JSON.parse(Utility.activityTypes);
                    var actTypes =[];
                    _.each(activityTypes, function (e) {
                        var obj = { };
                        obj.name = e.name;
                        obj.value = e.value.name;
                        actTypes.push(obj);
                        obj = null;
            });
                    activityTypes = null;
                    return _.sortBy(actTypes, function (item) {
                    return item.name; });
                    },
                getSubActivityTypes: function (key) {
                    var types = JSON.parse(Utility.activityTypes);
                    var subTypes = _.find(types, function (type) {
                        return type.value.name === key;
            });
                    types = null;
                    var subtypeLi = "";
                    if (subTypes != undefined && subTypes.value != undefined || subTypes.value.value != undefined) {
                        var sortedSubTypes = _.sortBy(subTypes.value.value, function (item) {
                        return item.name;
                        });
                        subtypeLi = subtypeLi + "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='subTypeNone'>None</label><input type='radio' id='subTypeNone' name='calSubType' value='None' checked=true></div>";
                        _.each(sortedSubTypes, function (sbtype) {
                            subtypeLi = subtypeLi + "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='subtype-" + sbtype.value + "'>" +sbtype.name + "</label><input type='radio' data-id='" +sbtype.value + "' name='calSubType' value='" +sbtype.name + "' id='subtype-" +sbtype.value + "'></div>";
                });
                        sortedSubTypes = null;
            }
                    return subtypeLi;
                    },
                adjustModalHeight: function (e) {
                    var objId = '';
                    var modalBody = $('.pt-event-modal .modal-body > div');
                    var _top = $("body").css("top");
                    var _bodytop = Math.abs(_top.substr(0, _top.length -2));
                    if (isNaN(_bodytop)) {
                        _bodytop = $("body").scrollTop();
            }
            setTimeout(function () {
                //Body
                $('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top' : '-' +_bodytop + 'px'
                });
                $(window).scrollTop(_bodytop);
                //Calendar Div                
                $($(".fc-agenda-divider.fc-widget-header").next()[0]).css("overflow-y", "hidden");
                }, 100);

                modalBody.each(function (i, elem) {
                    if ($(elem).hasClass('active')) {
                        objId = $(elem).attr('id');
                        return false;
                }
            });
            var appContHeight = $('#' +objId).height();

                    //Adjust the height if the container height is less than 500 for none IE browsers
                    if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
                        $('.pt-event-modal .modal-body').css({ height : (appContHeight < 515) ? 515: (appContHeight +30)
                    });
                    } else {
                        $('.pt-event-modal .modal-body').css({ height : (appContHeight < 500) ? 500: (appContHeight +15)
                });
            }

            if (objId != "app-start-end") {
                    this.animateToTop(); }
                    $(window).scrollTop(_bodytop);
                    },
                hideWarningPopup: function (e) {
                    $(".popup-warning, #warningPopup, #warning-modal-bg").addClass('hidden');
                    },
                showWarningPopup: function (e) {
                    var targetId = e.target.id;
                    $(".popup-warning").addClass('hidden');
                    $("#warningPopup, #warning-modal-bg, #" +targetId + "Appt").removeClass('hidden');
                    },
            markActivityAsCompleted: function () {
                var _status = 2;
                this.updateAppointmentStatus(_status);
                },
            markActivityAsCancelled: function () {
                var _status = 3;
                this.updateAppointmentStatus(_status);
                },
            updateAppointmentStatus: function (status) {
                var _self = this;
                var _evtDetails = _self.currentEvent;
                var _editEvntModel = new EventsCollection.Event();
                _editEvntModel.set({
                        actKeyword: _evtDetails.actKeyword,
                        activityId: _evtDetails.activityId,
                    allDay: _evtDetails.allDay,
                        description: _evtDetails.description,
                        end: _evtDetails.endDateTime,
                        isPrivate: _evtDetails.isPrivate,
                        location: _evtDetails.location,
                        priority: _evtDetails.priority,
                        selectedParticpants: _evtDetails.selectedParticpants,
                        showTimeAs: _evtDetails.showTimeAs,
                        start: _evtDetails.startDateTime,
                    //set the new status
                    status: status,
                    subType: _evtDetails.subType,
                    title: _evtDetails.title,
                    type: _evtDetails.type,
            }, {
                silent: true });
                Spinner.show();
                Dataservice.updateCalendarEvent(CalendarContext.getCalenderFMID(), _editEvntModel).done(gotoSaveEditEventSuccess).done(hideSpinner).fail(gotoEditEventFail);
                function gotoSaveEditEventSuccess(data) {
                    var curr = new Date;
                    curr.setHours(0, 0, 0, 0);
                    var firstday = moment($("#calendar").fullCalendar('getView').start).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                    curr.setHours(23, 59, 0, 0);
                    var lastday = moment($("#calendar").fullCalendar('getView').end).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd 
                    //For Month Day View Calendar
                    var view = $('#calendar').fullCalendar('getView');
                    var curr = $('#calendar').fullCalendar('getDate');
                    if (view.name != 'agendaWeek') {
                        _self.fetchMonthlyView(moment(firstday).format('MM'), moment(firstday).format('YYYY'));
                        _self.loadEventsForMonthDayView(curr.getFullYear(), curr.getMonth() +1, curr);
                    } else {
                        _self.loadEventsFromEbix(firstday, lastday);
                }
                $('#viewEventModal').modal('hide');
                    _self.adjustingOverflow();
                    Analytics.analytics.recordAction('editCalendarActivity:save');

            };

            function hideSpinner(data) {
                setTimeout(function () {
Spinner.hide();
            }, 500);
            };

            function gotoEditEventFail(Error) {
                Spinner.hide();
                that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                ErrorLog.ErrorUtils.myError(Error);
            };

            },
                saveEditApt: function (e) {
                    try {
                        var that = this;
                    //commented code
                    var editEvntMdl = new EventsCollection.Event();
                editEvntMdl.set({ "activityId": $('#currentActivityId').text()
                }, {
                    silent: true
                    });
                editEvntMdl.set({ "title": $('.app-sub .val textarea').val()
                }, {
                    silent: true
                });

                    //All Day
                    var isAllDay = $(".app-all-day a.choice-list-button:eq(0)");
                editEvntMdl.set({ "allDay": (isAllDay.hasClass('active') && isAllDay.text() == 'Yes') ? true: false
                }, {
                    silent: true
                });

                    //isPrivate
                    var isPrivate = $('.app-private a.choice-list-button:eq(0)');
                editEvntMdl.set({ "isPrivate": (isPrivate.hasClass('active') && isPrivate.text() == 'Yes') ? 1: 0
                }, {
                    silent: true
                });

                    // Priority Options
                editEvntMdl.set({ "priority": $('#app-priority-sel :selected').val()
                }, {
                    silent: true
                });

                    // Status Options
                editEvntMdl.set({ "status": $('#app-status-sel :selected').val()
                }, {
                    silent: true
                });

                    //Type
                editEvntMdl.set({ "type": $("form.app-type-li  input[name=calActivityType]:checked").attr('data-id')
                }, {
                    silent: true
                });

                    //Sub Type
                editEvntMdl.set({ "subType": $("form.app-sub-type-li  input[name=calSubType]:checked").attr('data-id')
                }, {
                    silent: true
                });

                    //Description
                editEvntMdl.set({ "description": $('#description').html().substr(0, 4000)
                }, {
                    silent: true
                });

                    //Location
                editEvntMdl.set({ "location": $('.app-location textarea').val()
                }, {
                    silent: true
                });

                    //Start Date & Time
                editEvntMdl.set({ "start": Moment.utc($('#app-starts').text()).format('YYYY-MM-DD HH:mm:ss')
                }, {
                    silent: true
                    });
                editEvntMdl.set({ "end": Moment.utc($('#app-ends').text()).format('YYYY-MM-DD HH:mm:ss')
                }, {
                    silent: true
                });

                    //Selected Participants
                        var prtnts = new Array();
                        $(".app-part-li input[data-name=calParticipants]").each(function (idx, li) {
                            if ($(li).is(":checked")) {
                        var particpant = new EventsCollection.Participant();
                        particpant.set({ "id": $(li).attr('data-id')
                        }, {
                            silent: true
                        });
                        particpant.set({ "isPrimary": $(li).attr('data-isprimary')
                        }, {
                            silent: true
                        });
                                prtnts.push(particpant);
                                particpant = null;
                }
                });
                editEvntMdl.set({ "selectedParticpants": prtnts
                }, {
                    silent: true
                });
                    // Keyword
                    var kWord = $(".app-keywords-li input[name=calKeyword]:checked").val();
                    var keyWord = (kWord && kWord != "keywordNone") ? kWord: "";
                editEvntMdl.set({ "actKeyword": keyWord
                }, {
                    silent: true
                });
                    //Show time as
                editEvntMdl.set({ "showTimeAs": $("#app-show-tm-sel-edit").val()
                }, {
                    silent: true
                });

                var _top = $("body").css("top");
                var _bodytop = Math.abs(_top.substr(0, _top.length -2));

                $(window).scrollTop(_bodytop);

                    //bump primary user to the top of the list  
                    for (var i = 0; i < prtnts.length; i++) {
                        if (prtnts[i].attributes.isPrimary === "true") {
                            prtnts.unshift(prtnts[i]);
                            break;
                }
                }

                        Spinner.show();
                        Dataservice.updateCalendarEvent(CalendarContext.getCalenderFMID(), editEvntMdl).done(gotoSaveEditEventSuccess).fail(gotoEditEventFail);
                        $(window).scrollTop(_bodytop);
                    function gotoSaveEditEventSuccess(data) {
                        if ($("#calendar").fullCalendar('getView').name == "agendaDay") {
                        that.monthServiceCounter = 2;
                        var curr = $('#calendar').fullCalendar('getDate');
                        that.loadEventsForMonthDayView(curr.getFullYear(), curr.getMonth() +1, curr);
                        // this.initialiseMonthDayView();
                        that.fetchMonthlyView(curr.getMonth() +1, curr.getFullYear());
                    } else {
                            var curr = new Date;
                            curr.setHours(0, 0, 0, 0);
                        var firstday = moment($("#calendar").fullCalendar('getView').start).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                        curr.setHours(23, 59, 0, 0);
                        var lastday = moment($("#calendar").fullCalendar('getView').end).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                        that.loadEventsFromEbix(firstday, lastday);
                    }


                    $('#viewEventModal').modal('hide');
                        that.adjustingOverflow();
                        $(window).scrollTop(_bodytop);
                        Analytics.analytics.recordAction('editCalendarActivity:save');
                        Spinner.hide();
                };

                function gotoEditEventFail(Error) {
                    Spinner.hide();
                    that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                    ErrorLog.ErrorUtils.myError(Error);
            };
            }
            catch (error) {
                Spinner.hide();
                that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                ErrorLog.ErrorUtils.myError(error);
            }
            },
                editAppointment: function (e) {
                    Analytics.analytics.recordAction('editCalenderActivity');
                    var that = this;
                    var priorityVal = "", showtimeasVal = "", eventStatusVal = "", types = "", selParticipants = new Array(), selParticipantsId =[];

                    //remember the current window position
                    var _top = $("body").css("top");
                    var _bodytop = Math.abs(_top.substr(0, _top.length -2));


                    //Hide All Scroll Bars
                    this.adjustModalHeight();
                    $(window).scrollTop(_bodytop);
                    //All Day
                    $("#app-all-day-" +($(".view-eve-all-day .val").text()).toLowerCase() + " .choice-list-button").addClass('active');
                    if ($("#app-all-day-yes").text() == 'Yes' && $("#app-all-day-yes > a").hasClass('active')) { $(".app-start-time, .app-end-time").hide();
                }

                    //DatePicker for Start & End
                    this.initDatePicker();
                    this.showYScroll('#app-container');
                    var startDtField = ($(".view-eve-timings .app-starts .val").text()).split(' ');
                    var endDtField = ($(".view-eve-timings .app-ends .val").text()).split(' ');

                    $(".app-timings .app-starts .val").html(startDtField[0]+ " " +((typeof (startDtField[1]) != 'undefined') ? startDtField[1]: '') + " " +((typeof (startDtField[2]) != 'undefined') ? startDtField[2]: ''));
                    $(".app-timings .app-ends .val").html(endDtField[0]+ " " +((typeof (endDtField[1]) != 'undefined') ? endDtField[1]: '') + " " +((typeof (endDtField[2]) != 'undefined') ? endDtField[2]: ''));

                    $("#startDate").val(startDtField[0]);
                    $("#endDate").val(endDtField[0]);
                    $("#add-apt-startDt").datepicker('setDate', startDtField[0]);
                    $("#add-apt-endDt").datepicker('setDate', endDtField[0]);
                    //For Month Day View Calendar
                    var view = $('#calendar').fullCalendar('getView');
                    if (view.name != 'agendaWeek') { that.fetchMonthlyView(moment(startDtField[0], "MM-DD-YYYY").format('MM'), moment(startDtField[0], "MM-DD-YYYY").format('YYYY'));
                    }

                    if (this.itsAllDay()) {
                        var startEndTm = this.currentTime();
                        $("#hr-start-sel").val(startEndTm[0]); //startHr
                        $("#hr-end-sel").val(startEndTm[3]); //endHr
                        $("#mins-start-sel").val(startEndTm[1]); //startMm
                        $("#mins-end-sel").val(startEndTm[4]); //endMm
                        $("#ampm-start-sel").val(startEndTm[2]); //startAMPM
                        $("#ampm-end-sel").val(startEndTm[5]); //endAMPM
                    } else {
                        $("#hr-start-sel").val(startDtField[1].split(":")[0]);
                        $("#hr-end-sel").val(endDtField[1].split(":")[0]);
                        $("#mins-start-sel").val(startDtField[1].split(":")[1]);
                        $("#mins-end-sel").val(endDtField[1].split(":")[1]);
                        $("#ampm-start-sel").val(startDtField[2]);
                        $("#ampm-end-sel").val(endDtField[2]);
                }

                    //Hide View Elements in View Appointment Screen and show Edit Elements in Edit Appointment Screen
                    $('.viewVal').hide();
                    $('.editVal').removeClass('hidden').addClass('show');

                    //Hide edit label, and inplace show 'Done' link
                    $('#appModalEdit').hide();
                    $('#saveAppointment').removeClass('hidden').empty().text('Done');
                    $('#moreOpts').text('Edit Activity');
                    $('#appModalCancel').html('Cancel');

                    //Dynamically add class to Type and Subtype classes (This will enable click event)
                    $(".view-eve-types").addClass("no-r-padding");
                    $(".view-eve-type").addClass("app-type more-opts-arrow");
                    $(".view-eve-subtype").addClass("app-subtype more-opts-arrow");
                    $(".view-eve-type .val, .view-eve-subtype .val").css('cursor', 'pointer');

            //Type
            var activityTypes = this.getActivityTypes();
            var typeId = $(".view-eve-type .val").attr('id');
            $.each(activityTypes, function (key, value) {
                var checkIt = "";
                if (typeId == activityTypes[key].value) checkIt = " checked=true";
                types += "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='act-type-" + activityTypes[key].value + "'>" + activityTypes[key].name + "</label><input type='radio' name='calActivityType' data-id='" + activityTypes[key].value + "' value=" + activityTypes[key].name + " id='act-type-" + activityTypes[key].value + "' " +checkIt + "></div>";
            });
            $(".app-type-li").empty().append(types);

                    //SubType
                    var subTypes = this.getSubActivityTypes(typeId);//Appointment
                    $('.app-sub-type-li').empty().append(subTypes);
                    $('form.app-sub-type-li input[name=calSubType]').each(function (i, val) {
                        if ($('form.app-sub-type-li input[name=calSubType]:eq(' +i + ')').attr('data-id') == $(".view-eve-subtype .val").attr('id')) $('form.app-sub-type-li input[name=calSubType]:eq(' +i + ')').prop('checked', true);
                });

                    //Private
                    var isPrivate = $('.app-private a.choice-list-button');
                    var isPrivateYes = $('.app-private a.choice-list-button:eq(0)');
                    var isPrivateNo = $('.app-private a.choice-list-button:eq(1)');
                    isPrivate.removeClass('active');
                    if (isPrivateYes.text() == $(".view-eve-private > .val").text()) {
                        isPrivateYes.addClass('active');
                    } else {
                        isPrivateNo.addClass('active');
                }

                    //Priority
                    $.each(JSON.parse(Utility.priority), function (key, value) {
                        var selected = "";
                        if ($(".view-eve-priority .val").attr("id") == value.name) selected = "selected";
                        priorityVal += "<option value=" +value.value + " " + selected + ">" +value.name + "</option>";
            })
            $('#app-priority-sel').empty().append(priorityVal);
                    priorityVal = null;

                    //Showtimeas
                    $.each(JSON.parse(Utility.showtimeas), function (key, value) {
                        var selected = "";
                        if ($(".view-eve-showtm .val").attr("id") == value.value) selected = "selected";
                        showtimeasVal += "<option value=" +value.value + " " + selected + ">" +value.name + "</option>";
            })
            $('#app-show-tm-sel-edit').empty().append(showtimeasVal);
                    showtimeasVal = null;

            //Status
            $.each(JSON.parse(Utility.eventStatus), function (key, value) {
                var selected = "";
                if ($(".view-eve-status .val").attr("id") == value.name) selected = "selected";
                eventStatusVal += "<option value=" +value.value + " " + selected + ">" +value.name + "</option>";
            })
            $('#app-status-sel').empty().append(eventStatusVal);
                    eventStatusVal = null;

                    //list-of-participants
                    selParticipants.length = 0; selParticipantsId.length = 0;
                    if ($("#participants li").length == 1) {
                        var _$singleParticipant = $('.singleParticipant');
                        selParticipants.push({ name: _$singleParticipant.text(), id: _$singleParticipant.attr('id')
                        });
                        selParticipantsId.push(_$singleParticipant.attr('id'));
                        $("#participants").empty();
                    } else {
                        $('.singleParticipant').empty();
                        $("#participants li").each(function (i, val) {
                            selParticipants.push({ name: $(this).text(), id: this.id
                        });
                            selParticipantsId.push(this.id);
                });
            }

                    Spinner.show();
                    $(window).scrollTop(_bodytop);
                    var additionalParticipant = CalendarContext.isCalendarSignedOnUser() ? null: CalendarContext.getCalenderFMID();
                    Dataservice.getParticipant(CommonUtilis.userFMID(), true, additionalParticipant).then(gotoParticipantList).fail(gotoFailedParticipant);
                    $(window).scrollTop(_bodytop);
                    function gotoParticipantList(participant) {
                        var participantsLi = "";
                        for (var m = 0; m < selParticipants.length; m++) {
                            participant.pushIfNotExist(selParticipants[m], function (e) {
                        return e.id === selParticipants[m].id;
                    });
                }
                $.each(participant, function (key, value) {
                    var checkIt = "";
                    if (participant[key].get) {
                        if ($.inArray(participant[key].get("id"), selParticipantsId) != -1) checkIt = " checked=true";
                        participantsLi += "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='participant-" + participant[key].get("id") + "'> " + participant[key].get("name") + "</label><input type='checkbox' data-name='calParticipants' value='" + participant[key].get("name") + "' data-id='" + participant[key].get("id") + "' id='participant-" + participant[key].get("id") + "' data-isPrimary=" +participant[key].get("isPrimary") +checkIt + "></div>";
                    } else {
                        if ($.inArray(participant[key]["id"], selParticipantsId) != -1) checkIt = " checked=true";
                        participantsLi += "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='participant-" + participant[key]["id"]+ "'> " + participant[key]["name"]+ "</label><input type='checkbox' data-name='calParticipants' value='" + participant[key]["name"]+ "' data-id='" + participant[key]["id"] + "' id='participant-" + participant[key]["id"]+checkIt + "' data-isPrimary=" + participant[key]["isPrimary"]+ "></div>";
                }

                });
                $(".app-part-li").empty().append(participantsLi);
                        //Fill keyword
                        that.fillKeyword("app-keywords-li");
                        Spinner.hide();
                        $(window).scrollTop(_bodytop);
            };

            function gotoFailedParticipant(Error) {
                Spinner.hide();
                that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                ErrorLog.ErrorUtils.myError(Error);
            };
            },
            showEventColorLegendModal: function () {
                    var _self = this,
                        _target,
                        _fmId = CommonUtilis.readCookie("FMID"),
                        _peopleSoftID = CommonUtilis.readCookie("PeopleSoftID"),
                        _evtColorSettings = CommonUtilis.readCookie("EventColorSettings"),
                        _showColorCookieval = "on";
                    if (_evtColorSettings) {
                        _evtColorSettings = JSON.parse(_evtColorSettings);
                        if (_evtColorSettings.fmId == _fmId) {
                            _showColorCookieval = _evtColorSettings.showColor;
                        }
                    }
                    if (!this.evtColorLegendModalView) {
                        this.evtColorLegendModalView = new EventColorLegendView({
                            el: $('#AppointmentTmpt'),
                            "cancelCallback": function () {
                                $("#event-color-legend-modal-" + _self.evtColorLegendModalView.getContainerId()).modal('hide');
                                _self.resetBodyStyle();
                            },
                            "doneCallback": function (params/*{showColor:"on/off"}*/) {
                                var _showColor = params.showColor,
                                    _expires = new Date(),
                                    _settings = {
                                        "id": _peopleSoftID,
                                        "fmId": _fmId,
                                        "showColor": _showColor
                                    };
                                    _expires.setTime(_expires.getTime() + (365 * 24 * 60 * 60 * 1000));//setting cookie expiry as 1 year from now
                                    CommonUtilis.writeCookie("EventColorSettings", JSON.stringify(_settings), {
                                        "expires": _expires.toGMTString()
                                    });
                                if (_showColorCookieval != _showColor) {
                                    //Render the options
                                    var _gContext = GlobalContext.getInstance().getGlobalContext().Context, options = {
                                        fmId: CalendarContext.getCalenderFMID(),
                                        selectedContactId: _gContext.ContactId,
                                        selectedContactType: _gContext.ContactType,
                                        action: ""
                                    };
                                    _self.render(options);
                                }

                            }
                        });
                    }
                    _self.evtColorLegendModalView.render({ showColor: _showColorCookieval });
                    $('#evt-color-setting').attr('data-target', ("#event-color-legend-modal-" + _self.evtColorLegendModalView.getContainerId()));
                    Spinner.show();
                    Dataservice.promiseToGetEventTypeColors(_fmId).then(function (res) {
                        var _evtTypeColors = [];
                        if (res && res.EventTypeColors && res.EventTypeColors.length > 0) {
                            _evtTypeColors = res.EventTypeColors;
                        }
                        _self.evtColorLegendModalView.updateLegend(_evtTypeColors);
                        Spinner.hide();
                    }).fail(function (error) {
                        Spinner.hide();
                        ErrorLog.ErrorUtils.myError(error);
                    });

                },
                resetColorLegendView: function () {
                    if (this.evtColorLegendModalView) {
                        this.evtColorLegendModalView.closeView();
                        this.evtColorLegendModalView = null;
                    }
                },
                addAppointment: function (e) {
                    Analytics.analytics.recordAction('addNewCalendarActivity');
                    var that = this;
                    //cal month day view editFlag
                    that.editingEvtDetails.fromEdit = false;
                    e.preventDefault();

                    //Modal middle title change
                    $('#addAppointment .middle-title').text('New Activity');

                    var activityTypes = this.getActivityTypes(),
                        subTypes = this.getSubActivityTypes(activityTypes[0].value)/*Appointment */,
                        zonetime_abreviation = CommonUtilis.getTimezoneAbbreviation(),
                        data = {
                            activityTypes: activityTypes,
                                priority: JSON.parse(Utility.priority),
                                showtimeas: JSON.parse(Utility.showtimeas),
                                zonetime: zonetime_abreviation
                };

            var compiledTemplate = _.template(AddAppointmentView, {
                data: data
                });

                $('#AppointmentTmpt').empty().append(compiledTemplate);
                $(".app-sub-type-li").empty().append(subTypes);
                $("form.app-type-li input[name=calActivityType]:eq(0)").prop('checked', true);
                $('#addApptBtn').attr('data-target', '#addAppointment');

                    this.adjustModalHeight(); // Adjust the modal height

                    //Need to check this
                    if (/Android/i.test(navigator.userAgent)) { $("#AppointmentTmpt .modal").css('overflow', 'auto');
                }

                    //Date Picker
                    this.initDatePicker();
                    this.showYScroll('#app-container');

                    var asyncClientNonClientListCall = [];
                    var additionalParticipant = CalendarContext.isCalendarSignedOnUser() ? null: CalendarContext.getCalenderFMID();
                    asyncClientNonClientListCall[0]= Dataservice.getParticipant(CommonUtilis.userFMID(), true, additionalParticipant);
                    // asyncClientNonClientListCall[1] = Dataservice.getParticipant(CommonUtilis.readCookie('FMID'), true); //Later to validate the client exist in Ebix
                    if (this.pinnedContact.pinnedContactType == Constants.contactType.NonClient && GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                        asyncClientNonClientListCall[1]= Dataservice.getContactDetailsbyContactId(CommonUtilis.readCookie('FMID'), GlobalContext.getInstance().getGlobalContext().Context.ContactId);
            }
            else if (this.pinnedContact.pinnedContactType == Constants.contactType.Client && GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                asyncClientNonClientListCall[1]= Dataservice.getContactDetailsbyClientId(CommonUtilis.readCookie('FMID'), GlobalContext.getInstance().getGlobalContext().Context.ContactId);
                }

                    //Spinner.show({ inline: true, parentElement: 'app-participants' });
                    Spinner.show();
                    Q.allSettled(asyncClientNonClientListCall).then(gotoParticipantCollection).fail(gotoErrorHandler);

                    function gotoParticipantCollection(resultsData) {
                        var participantsLi = "", primaryParticipant = "";

                        if (resultsData && resultsData[0] && resultsData[0].value && resultsData[0].value.length > 0) {
                            var participantsList = _.sortBy(resultsData[0].value, function (item) {
                                return item.get("name");
                        });
                        $.each(participantsList, function (key, value, index) {
                        if (participantsList[key].get("isPrimary")) {
                            primaryParticipant = "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='participant-" + participantsList[key].get("id") + "'> " + participantsList[key].get("name") + "</label><input type='checkbox' data-name='calParticipants' checked=true primary' value='" + participantsList[key].get("name") + "' data-id='" + participantsList[key].get("id") + "' id='participant-" + participantsList[key].get("id") + "'></div>";
                            $(".singleParticipant").html(participantsList[key].get("name"));
                            //$(".list-of-participants").append("<li id=" + participantsList[key].get("id") + ">" + participantsList[key].get("name") + "</li>");
                            //$('#subject').focus();
                        } else {
                            participantsLi += "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='participant-" + participantsList[key].get("id") + "'> " + participantsList[key].get("name") + "</label><input type='checkbox' data-name='calParticipants' value='" + participantsList[key].get("name") + "' data-id='" + participantsList[key].get("id") + "' id='participant-" + participantsList[key].get("id") + "'></div>";
                        }
                        });
                        $(".app-part-li").empty().append(primaryParticipant);
                        $(".app-part-li").append(participantsLi);
                    }

                        //Fill keyword
                        that.fillKeyword("app-keywords-li");

                        if (resultsData[1] && resultsData[1].value != undefined && resultsData[1].value[0].attributes) {
                            $(".sel-contact, .pinned-client-in-add-appt .val").empty().html((resultsData[1].value[0].get("firstName") != null && resultsData[1].value[0].get("firstName").length > 0) ? resultsData[1].value[0].get("lastName") + ", " +resultsData[1].value[0].get("firstName"): resultsData[1].value[0].get("lastName"));
                            if ($('.sel-contact').text() != "") {
                        if ($('.pinned-client-in-add-appt').hasClass('hidden')) { $('.pinned-client-in-add-appt').removeClass('hidden');
                            }
                        }
                        $(".sel-contact").attr('id', resultsData[1].value[0].get("contactId"));
                        $("form#calContactSearch .typeahead").css('max-height', '345px');

                    that.pinnedContact.pinnedClientId = resultsData[1].value[0].get("clientId");
                    that.pinnedContact.pinnedContactId = resultsData[1].value[0].get("contactId");
                        } else {
                            $(".sel-contact").empty();
                            $(".sel-contact").attr('id', "");
                            that.pinnedContact.pinnedClientId = undefined;
                            that.pinnedContact.pinnedContactId = undefined;
                    }
                        //Calendar Contact Search
                        //Spinner.hide({ inline: true, parentElement: 'app-participants' });
                        Spinner.hide();
            };
            function gotoErrorHandler(error) {
                //Spinner.hide({ inline: true, parentElement: 'app-participants' });
                Spinner.hide();
                that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                ErrorLog.ErrorUtils.myError(error);
            };
        },
                itsAllDay: function (e) {
                    var yesBtn = $(".app-all-day a.choice-list-button:eq(0)");
                    return (yesBtn.hasClass('active') && yesBtn.text().toLowerCase() == 'yes') ? true: false;
                    },
                saveAddAptEvent: function (e) {
                    var that = this;
                    e.preventDefault();
                    contactName = $('.sel-contact').text().trim();

                    //remember the current window position
                    var _top = $("body").css("top");
                    var _bodytop = Math.abs(_top.substr(0, _top.length -2));
                    $('body').removeAttr('style');


                    //Remove style tag for Body
                    setTimeout(function () { $('body').removeAttr('style');
                }, 100);

                    //Type Id
                    var typeId = $("form.app-type-li input").is(':checked') ? $(this).attr('id'): '';

                    //Selected Participants
                    var prtnts = new Array();
                    $(".app-part-li input[data-name=calParticipants]").each(function (idx, li) {
                        if ($(li).is(':checked')) {
                            var particpant = new EventsCollection.Participant();
                    particpant.set({ "id": $(li).attr('data-id')
                    }, {
                        silent: true
                    });
                            prtnts.push(particpant);
                            particpant = null;
                }

                });

                    //isPrivate
                    var isPrivate = $('.app-private a.choice-list-button.active');

                    //Start Date & Time
                    var startDt = moment($("#startDate").val()).format('YYYY/MM/DD');
                    var startTm = $(".hr-start-sel :selected").text() + ":" +$(".mins-start-sel :selected").text() + " " +$(".ampm-start-sel :selected").text();

                    var endDt = moment($("#endDate").val()).format('YYYY/MM/DD');
                    var endTm = $(".hr-end-sel :selected").text() + ":" +$(".mins-end-sel :selected").text() + " " +$(".ampm-end-sel :selected").text();

                    var addEvntMdl = new EventsCollection.Event();
            addEvntMdl.set({ "title": $('.app-sub .val textarea').val()
                }, {
                    silent: true });
                    var startUtctime = Moment.utc(startDt + " " +startTm).format('YYYY-MM-DD HH:mm:ss');
                    var endUtctime = Moment.utc(endDt + " " +endTm).format('YYYY-MM-DD HH:mm:ss');
            addEvntMdl.set({ "start": startUtctime
                }), {
                    silent: true };
            addEvntMdl.set({ "end": endUtctime
                }), {
                    silent: true
                };

                //AllDay
                if (this.itsAllDay()) {
                    addEvntMdl.set({ "allDay": true
                }), {
                    silent: true
                };
                } else {
                addEvntMdl.set({ "allDay": false
                }), {
                    silent: true
                };
            }

            addEvntMdl.set({ "selectedParticpants": prtnts
                }), {
                    silent: true };
            addEvntMdl.set({ "description": $('#description').html().substr(0, 4000)
                }), {
                    silent: true };
            addEvntMdl.set({ "type": $("form.app-type-li input[name=calActivityType]:checked").attr('data-id')
                }), {
                    silent: true };
            addEvntMdl.set({ "subType": $("form.app-sub-type-li input[name=calSubType]:checked").attr('data-id')
                }), {
                    silent: true };
            addEvntMdl.set({ "location": $('.app-location textarea').val()
                }), {
                    silent: true };
            addEvntMdl.set({ "isPrivate": (isPrivate.hasClass('active') && isPrivate.text() == 'Yes') ? "1": "0"
                }), {
                    silent: true
                    };
                    if ($(".sel-contact").attr('id')) {
                addEvntMdl.set({ "contactId": $(".sel-contact").attr('id')
                    }), {
                        silent: true
                };
            }
            if ($(".sel-contact").text()) {
                addEvntMdl.set({ "ContactName": $(".sel-contact").text()
            }), {
                silent: true
                };
                }
                    // Priority Options
            addEvntMdl.set({ "priority": $('#app-priority-sel :selected').val()
                }), {
                    silent: true
                };

                    // Status
                    addEvntMdl.set({ "status": "1"
                }), {
                    silent: true
                }; //Active   

                    // Keyword
                    //var keyWord = $(".app-keywords-li li.radio-checked").attr("id") || '';
                    //addEvntMdl.set({ "actKeyword": keyWord }), { silent: true };
                    var kWord = $(".app-keywords-li input[name=calKeyword]:checked").attr('data-id');
                    var keyWord = (kWord && kWord != "keywordNone") ? kWord: "";
            addEvntMdl.set({ "actKeyword": keyWord
                }, {
                    silent: true
                });

                    //Show time as
            addEvntMdl.set({ "showTimeAs": $("#app-show-tm-sel-add").val()
                }), {
                    silent: true };
                    $(window).scrollTop(_bodytop);
                    Spinner.show();

                    Dataservice.postCalendarEvent(CalendarContext.getCalenderFMID(), addEvntMdl).done(gotoAddEventSuccess).fail(gotoAddEventFail);
                    function gotoAddEventSuccess(data) {
                        $('#addAppointment').modal('hide');
                        $(window).scrollTop(_bodytop);
                        //if month day view load the loadEventsForMonthDayView
                        if ($("#calendar").fullCalendar('getView').name == "agendaDay") {
                            var curr = $('#calendar').fullCalendar('getDate');
                            that.monthServiceCounter = 2;
                            that.loadEventsForMonthDayView(curr.getFullYear(), curr.getMonth() +1, curr);
                            // this.initialiseMonthDayView();
                            that.fetchMonthlyView(curr.getMonth() +1, curr.getFullYear());
                        } else {
                            var curr = new Date;
                            curr.setHours(0, 0, 0, 0);
                            var firstday = moment($("#calendar").fullCalendar('getView').start).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                            curr.setHours(23, 59, 0, 0);
                            var lastday = moment($("#calendar").fullCalendar('getView').end).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                            that.loadEventsFromEbix(firstday, lastday);
                }
                Analytics.analytics.recordAction('addCalendarActivity:save');
                if (!addEvntMdl.get("ContactName")) {
                    Analytics.analytics.recordAction('addCalendarActivity:saveWithNoContact');
                    }
                    //Spinner.hide();
            };

                    this.adjustingOverflow(); //Adjusting Overflow property depending on the mobile and ipad devices

                    function gotoAddEventFail(Error) {
                        Spinner.hide();
                        that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                        ErrorLog.ErrorUtils.myError(Error);
            };
            if ($("#afi-nav-modal").is(":visible")) {
                $("#afi-nav-modal").modal('hide');
            }
            },
                cancelModal: function (e) {
                    $('#addAppointment, #viewEventModal, #afi-nav-modal').modal('hide');
                    this.resetBodyStyle();
                    e.stopPropagation();
                },
                resetBodyStyle: function () {
                    var _top = $("body").css("top");
                    var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
                    $('body').removeAttr('style');
                    $(window).scrollTop(_bodytop);
                    $($(".fc-agenda-divider.fc-widget-header").next()[0]).css({ "overflow-y": "auto", "-webkit-overflow-scrolling": "touch" });
                },
                adjustingOverflow: function (e) {

                    var _top = $("body").css("top");
                    var _bodytop = Math.abs(_top.substr(0, _top.length -2));
                    if (isNaN(_bodytop)) {
                        _bodytop = $("body").scrollTop();
                }


                    /* When Add Appointment Modal Closed, make overflow-y of calendar to auto for body scrolling */
                    $($(".fc-agenda-divider.fc-widget-header").next()[0]).css({ "overflow-y": "auto", "-webkit-overflow-scrolling": "touch"
                    });
                    if (/Android/i.test(navigator.userAgent)) { $("#AppointmentTmpt .modal").css('overflow', 'hidden'); }
                    $('body').removeAttr('style');
                    $(window).scrollTop(_bodytop);
                    },
            validateThenMoveSlide: function (e) {
                var that = e.target.id;
                var moreOptsTxt = $('#moreOpts').text();
                var thisSlide = '';

                if((moreOptsTxt).indexOf('Start') != -1 ||($('#moreOpts').text()).indexOf('End') != -1) thisSlide = 'Starts';
                if((moreOptsTxt).indexOf('Participants') != -1) thisSlide = 'Participants';
                if((moreOptsTxt).indexOf('Sub-Type') != -1) thisSlide = 'Sub-Type';
                if((moreOptsTxt).indexOf('Keywords') != -1) thisSlide = 'Options';
                if((moreOptsTxt).indexOf('Start-Date') != -1) thisSlide = 'StartDate';
                if((moreOptsTxt).indexOf('Contact Search') != -1) thisSlide = 'Contact-Search';


                this.hasErrorInField(thisSlide, 'hide');
                //var hasError = $(".has-error");
                //hasError.hide();
                switch (thisSlide) {
                    case 'Sub-Type':
                        var checkedOpt = '';
                        $("form.app-sub-type-li input[name=calSubType]").each(function (key, val) {
                        if($(this).is(':checked') && $(this).is('#subTypeNone')) {
                            checkedOpt = 'Select Sub-Type';
                            return false;
                        } else if($(this).is(':checked') && $(this).not('#subTypeNone')) {
                            checkedOpt = $(this).val();
                            return false;
                        }
                });
                $(".app-subtype > .val").html(checkedOpt);
                        this.goToMainSlide();
                        break;
                    case 'Participants':
                            //Selected Participants
                            var listOfParticipants = $(".list-of-participants");
                            var appPartLi = $(".app-part-li input[data-name=calParticipants]");
                            var checkedItem = $(".app-part-li input[data-name=calParticipants]:checked");
                            $(".singleParticipant").empty();
                        listOfParticipants.empty();

                    if (appPartLi.is(':checked')) {
                        if (checkedItem.length == 1) {
                            $(".singleParticipant").html(checkedItem.val());
                        } else {
                            appPartLi.each(function (idx, li) {
                                if ($(li).is(':checked')) {
                                    $(".list-of-participants").append("<li id=" + idx + ">" +$(li).val() + "</li>");
                            }
                        });
}//if close
                        this.goToMainSlide();
} else {
                        this.hasErrorInField(thisSlide, 'show');
                        return false;
                        }//if close
                        break;
                    case 'Starts':
                    case 'Ends':
                        var startdatetime = '', enddatetime = '';
                        var allDayCheck = true;

                    if (this.itsAllDay()) { // For ALLDay show only date not time
                        startdatetime = $("#startDate").val();
                        enddatetime = $("#endDate").val();
                        allDayCheck = true;
} else {
                        startdatetime = $("#startDate").val() + " " +$('.hr-start-sel :selected').text() + ":" +$('.mins-start-sel :selected').text() + " " +$('.ampm-start-sel :selected').text();
                        enddatetime = $("#endDate").val() + " " +$('.hr-end-sel :selected').text() + ":" +$('.mins-end-sel :selected').text() + " " +$('.ampm-end-sel :selected').text();
                        allDayCheck = false;
                    }

                    var timediff = new Date(enddatetime) -new Date(startdatetime);

                    setTimeout(function () {
                        $('#app-starts').html(startdatetime);
                        $('#app-ends').html(enddatetime);
                    }, 100);

                    if (timediff < 0) {
                        this.hasErrorInField(thisSlide, 'show');
                        return false;
                    } else {
                        this.goToMainSlide();
                    }
                        break;
                    case 'Options':
                        this.goToSlide("app-more-options", "app-keywords-3");
                        break;
                    case 'Contact-Search':
                        $('#calsearch').blur();
                        this.goToMainSlide();
                        break;
                    default:
                        this.goToMainSlide();
            }
            this.showYScroll('#app-container');
                this.adjustModalHeight(); //-- Vivek
                },
                hasErrorInField: function (thisSlide, togglediv) {
                    //ex: app-participants-opts
                    var hasError = $(".app-" + thisSlide.toLowerCase() + "-opts" + " .has-error");
                    if (togglediv == 'hide') {
                        hasError.removeClass('bg-danger').hide();
                        } else if (togglediv == 'show') {
                            hasError.show().addClass('bg-danger');
            }
        },
                goToSlide: function (from, to) {
                    var activeDivId = '', parentContainer = '';
                    $(".app-panel").each(function (i, val) {

                        var that = '#' +$(this).attr('id');
                        if ($(that).hasClass('active')) {
                            activeDivId = that.substring(1);
                            $(that).removeClass('active').animate({
                                    right : -($(that).width() +16), margin: '0px -15px'
                    }, 500, function () {
                                $(that).hide();
                        });
                            //To get good animation, we are hiding after animation
                        //setTimeout(function () { $(that).hide(); }, 600);
        }
        });//each loop close

        $('#' +from).addClass('active').show().css({
                left: - ($('#' +from).width() +16), margin: '0px 5px'
            }).animate({
                left: 0
        }, 500);

        $("#appModalCancel, #appModalAdd, #saveAppointment").addClass('hide');
        $("#newEvent, #moreOpts").removeClass('hide');
        parentContainer = $("#" +activeDivId).closest('.pt-event-modal').attr('id');
        this.changeTitles(parentContainer, 'More options');
        },
                goToMainSlide: function (e) {
                    var activeDivId = '', parentContainer = '';
                    $(".app-panel").each(function (i, val) {
                        $(this).css('left', '');
                        var that = '#' +$(this).attr('id');
                        if ($(that).hasClass('active')) {
                            activeDivId = that.substring(1);
                            $(that).removeClass('active').animate({
                                    right : -($(that).width() +16), margin: '0px -15px'
                    }, 500, function () {
                                $(that).hide();
                        });

                            //setTimeout(function () { $(that).hide(); }, 600);

                            return false;
                }
                });//each loop close

                $('#app-container').addClass('active').show().css({
                        left: -($('#app-container').width() +16), margin: '0px 5px'
            }).animate({
                        left: 0
                }, 500);

                    this.adjustModalHeight(); // Vivek
                    $("#appModalCancel, #appModalAdd, #saveAppointment, #appModalEdit").removeClass('hide');
                    $("#newEvent").addClass('hide');
                    parentContainer = $("#" +activeDivId).closest('.pt-event-modal').attr('id');
                    this.changeTitles(activeDivId, parentContainer);
                    },
                getMoreOptions: function (ev) {
                    var getId = $(ev.currentTarget).data('slideto');
                    var getLbl = $("." +$(ev.currentTarget).parent().attr("class").split(' ')[0]+ " .lbl:eq(0)").text();
                    var slideToMove = '';

                    this.showYScroll("#" +getId);

                    if (!$('#' +getId).hasClass('active')) {
                        $('#app-container').removeClass('active').animate({
                                left: -($('#app-container').width() +16), margin: '0px -15px'
                }, 500, function () {
                    $('#app-container').hide();
                    });

                        //setTimeout(function () { $('#app-container').hide(); }, 600);

                        if (getId.indexOf('3') > -1) {
                            if (getId == 'app-keywords-3') { slideToMove = 'app-more-options';
                        }
                        $("#" +slideToMove).removeClass('active').animate({
                                left: -($("#" +slideToMove).width() +16), margin: '0px -15px'
                    }, 500, function () {
                        $("#" +slideToMove).hide();
                        });
                        //setTimeout(function () { $("#" + slideToMove).hide(); }, 600);
                }

                $('#' +getId).addClass('active').show().css({
                        right: -($('#' +getId).width() +16), margin: '0px 5px'
                }).animate({
                    right: 0
                    }, 500);

                    $("#appModalCancel, #appModalAdd, #saveAppointment, #appModalEdit").addClass('hide');
                    $("#newEvent, #moreOpts").removeClass('hide');
                    this.changeTitles(getId, getLbl);
                    //this.adjustModalHeight(); // Vivek
            }

            if (getId == "app-contact-search-opts") {

                if (this.calContactViewObj) {
                    this.calContactViewObj.clearView();
                }
                this.calContactViewObj = new ContactSearchView();
                this.calContactViewObj.render();
            }
                    this.adjustModalHeight();
                    },
                changeTitles: function (idVal, lblName) {
                    var that = this;
                    switch (lblName) {
                        case 'Start':
                        case 'End':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html(lblName + ' Date-Picker');
                            $('.right-title').html('');
                            break;
                        case 'Starts':
                        case 'Ends':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html('Start & End');
                            $('.right-title').html('');
                            break;
                        case 'Repeats':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html('Repeat');
                            $('.right-title').html('');
                            break;
                        case 'Participants':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html('Participants');
                            $('.right-title').html('');
                            break;
                        case 'Type':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html('Type');
                            $('.right-title').html('');
                            break;
                        case 'Sub-Type':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html('Sub-Type');
                            $('.right-title').html('');
                            break;
                        case 'More options':
                                // [View/Edit] -- Need to check with Business, on what would be the title in View Activity
                                // As of now we kept 'Activity'
                                if (idVal == "viewEventModal" || idVal == "app-more-options") {
                        $('#newEvent').html('Activity');
                        $('.middle-title').html('More options');
                        $('.right-title').html('');
                    } else if (idVal == "addAppointment") {
                        $('#newEvent').html('Activity');
                        $('.middle-title').html('More options');
                        $('.right-title').html('');
                            }
                            break;
                        case 'Keywords':
                            $('#newEvent').html('Options');
                            $('.middle-title').html('Keywords');
                            $('.right-title').html('');
                            break;
                        case 'addAppointment':
                            $('#appModalAdd').html('Done');
                            $('.middle-title').html('New Activity');
                            break;
                        case 'Contact':
                            $('#newEvent').html('Activity');
                            $('.middle-title').html('Contact Search');
                            $('.right-title').html('');
                            break;
                        case 'viewEventModal':
                            if (idVal == 'app-start-end' || idVal == 'app-participants-opts' || idVal == 'app-type-opts' || idVal == 'app-sub-type-opts' || idVal == 'app-more-options' || idVal == 'app-rep-opts-2') {
                        if(!$('#saveAppointment').hasClass('hidden')) {
                            $('#saveAppointment').html('Done');
                            $('.middle-title').html('Edit Activity');
                        } else {
                            $('#appModalEdit').html('Edit');
                            $('.middle-title').html('View Activity');
                        }
                            }
                            break;
                        default:
            }
            },
            initialiseMonthDayView: function (defaultSelectedDt) {
                /*experimental fix for allday evt*/
                var _curCalView = $("#calendar").fullCalendar("getView");
                var $dayViewCalendar = $("#calendar.DayViewCalendar");
                if (_curCalView.name == "agendaDay") {
                    $('.fc-agenda-allday').hide();
                    $('.fc-agenda-divider').hide();
            }
                var _that = this;
                var selectedMMDDYYYY = new Date();

                if (typeof defaultSelectedDt !== 'undefined') {
                    //selectedMMDDYYYY = new Date(defaultSelectedDt[0] + '/' + defaultSelectedDt[1] + '/' + defaultSelectedDt[2]);
                    selectedMMDDYYYY = new Date(defaultSelectedDt);
                } else {
                    selectedMMDDYYYY = new Date();
            }

            $('table.fc-agenda-allday th:eq(0)').html('All<br/>day');
                //$("#day-date-picker").val($.datepicker.formatDate("mm/dd/yy", new Date(getDateFrmDayView)));
                $("#day-date-picker").datepicker({
                    //dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                    showOtherMonths: true,
                    selectOtherMonths: true,
                    showOn: "both",
                    showButtonPanel: true,
                        buttonImage: "images/cal-icon.png",
                    buttonImageOnly: true,
                    buttonText: 'Click Here',
                    //defaultDate: moment(selectedMMDDYYYY).utc().format('MM/DD/YYYY'), //mm/dd/yyyy
                        defaultDate: moment(selectedMMDDYYYY).utc().format('MM/DD/YYYY'),
                    onSelect: function (dateText, inst) {
                            dtSelectedFrmWeekAndDay = true;
                            _that.currentDaysEventCounter = 0;
                            var d = new Date(dateText);
                            getDateFrmDayView = d; //Assign the selected date from day

                        /*experimental fix for allday evt*/
                        var _curCalView = $("#calendar").fullCalendar("getView");
                        if (_curCalView.name == "agendaDay") {
                        $('.fc-agenda-allday, .fc-agenda-divider').hide();
                }
                $('#calendar').fullCalendar('gotoDate', d);
                $('.fc-header-title > h2').css('color', '#333333');
                setTimeout(function () {
                        var _uAgent = navigator.userAgent.toLowerCase();
                        if (_uAgent.indexOf('iphone') > -1 || _uAgent.indexOf('ipad') > -1 || _uAgent.indexOf('android') > -1) {
                            $('#day-date-picker td>a.ui-state-hover').removeClass('ui-state-hover');
                }
                }, 100);

                        /*var theDate = new Date(Date.parse($(this).datepicker('getDate')));
                        _that.monthServiceCounter = 2;
                        _that.loadEventsForMonthDayView(theDate.getFullYear(), theDate.getMonth() + 1, null);
                        _that.fetchMonthlyView(theDate.getMonth() + 1, theDate.getFullYear());*/
                        //CalendarContext.setChoosenDate(getDateFrmDayView);
                        _that.setNavigatedViewAndDate('agendaDay', getDateFrmDayView);
                            getEventsFrmSelectedDate(getDateFrmDayView);

                    $(this).datepicker('hide').blur();
                },
                    beforeShow: function (input, inst) {
                        $("#day-date-picker").attr("disabled", true);
                        var $uidatepickerdiv = $('#ui-datepicker-div');
                        $('body').append('<div id="pt-date-picker-overlay" class="pt-transparent-overlay"></div>');
                        //Initially remove both the classes, then add the appropriate class
                        $uidatepickerdiv.removeClass("week-date-picker day-date-picker").addClass(this.id);
                        $(".DayViewCalendar #day-date-picker, .DayViewCalendar .ui-datepicker-trigger, #ui-datepicker-div").addClass('daypickerzindex');

                    if (_that.isDeviceSmall()) {
                        $dayViewCalendar.css('margin-top', '320px')
                }
                setTimeout(function () {
                    //if (_that.isDeviceSmall()) { $dayViewCalendar.css('margin-top', $uidatepickerdiv.outerHeight() + 'px'); }
                        _that.alignTheDtPicker(["day-date-picker"]);
                        $("#day-date-picker").attr("disabled", false);
                }, 10);

                    /*var d = new Date(input.value);
                    _that.monthServiceCounter = 2;
                    _that.loadEventsForMonthDayView(d.getFullYear(), d.getMonth(), null);
                    _that.fetchMonthlyView(d.getMonth(), d.getFullYear());*/
                },
                    beforeShowDay: function (date) {
                        var result =[true, '', null];
                        var matching = $.grep(_that.threeMonthEvents, function (event) {
                        return event.Date.valueOf() === date.valueOf();
                });
                if (matching.length) {
                        result =[true, 'highlight', null];
                }

                    return result;
                },
                    onChangeMonthYear: function (year, month, widget) {
                        //$('#calendar-lt>h2').html(_monthName);
                        _that.monthServiceCounter = 2;
                        _that.loadEventsForMonthDayView(year, month, null);
                        _that.fetchMonthlyView(month, year);
                },
                    onClose : function (selectedDate) {
                        //getDateFrmDayView = new Date(selectedDate);
                        $('#pt-date-picker-overlay').remove();
                        if (_that.isDeviceSmall()) {
                        $dayViewCalendar.css('margin-top', '8px');
                }
                $("#day-date-picker").val($.datepicker.formatDate("mm/dd/yy", new Date(getDateFrmDayView))).blur();
                $('#ui-datepicker-div').removeClass('day-date-picker');
                    window.scrollTo(0, 0);
                    $(".DayViewCalendar #day-date-picker, .DayViewCalendar .ui-datepicker-trigger, #ui-datepicker-div").removeClass('daypickerzindex');
                        //$("#day-date-picker").val($.datepicker.formatDate("mm/dd/yy", new Date()));
                    //$('#calendar').fullCalendar('gotoDate', new Date());
            }
            });

            function getEventsFrmSelectedDate(selectedDtObject) {
                //After selecting a date, change the calendar view to agendaWeek
                //$("#calendar").fullCalendar('changeView', 'agendaDay').fullCalendar('gotoDate', selectedDtObject);
                //Get the Events and Render onto the calendar
                _that.calendarPrevNextBtnClick(selectedDtObject, false);
            }

                //$("#day-date-picker").val($.datepicker.formatDate("mm/dd/yy", new Date(getDateFrmDayView)));

                /* This was commented out
                if (!_that.isDeviceSmall()) {
                    $("#day-date-picker").focus().datepicker('setDate', new Date(getDateFrmDayView));
                    //On load of Day Date Picker, Cursor will be moved to Today button, this will get rid of mobile keyboard
                    $(".day-date-picker button.ui-datepicker-current").focus();
                } else {
                    $("#day-date-picker").val($.datepicker.formatDate("mm/dd/yy", new Date(getDateFrmDayView)));
                }*/

                //onChange event
                /*$('#day-date-picker').datepicker().on("input change", function (e) {
                });*/

                /*$('#day-date-picker').on("focus", function (e) {
                });*/

                //Enter Event
                $('#day-date-picker').datepicker().on("keydown", function (e) {
                    if (e.which == 13) {
                        _that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
            }
            });
            },
                calMonthBtnClick: function (e) {
                    e.preventDefault();
                    var that = this;
                    CalendarContext.setViewType('agendaDay');
                    this.calMode = "dayMonth"
                    this.linkActive(this.calLnks, e.target.id);

                    var start_date = moment($('#calendar').fullCalendar('getView').start);
                    //var weeks_monday = start_date.add(1, 'days');
                    //var weeks_monday_todate_fmt = weeks_monday.toDate();
                    var weeks_monday = moment(CalendarContext.getChoosenDate());
                    var weeks_monday_todate_fmt = moment(CalendarContext.getChoosenDate()).toDate();

                    //Store navigated week
                    var future_navigated_week = start_date.format("MM-DD-YYYY").split("-"); //[0] - MM, [1] - DD, [2] - YYYY
                    //if future navigated week is 'not' same as current dated week, change the DD to navigated week Monday
                    if(!moment($('#calendar').fullCalendar('getView')).isSame($('#calendar').fullCalendar('getDate'), 'week')) {
                        future_navigated_week[1]= weeks_monday.format("DD"); //Week's Monday Date
                        //Showing Day View
                        this.calendarInit(true, 'agendaDay');
                        $('#calendar').fullCalendar('gotoDate', weeks_monday_todate_fmt);
                        getDateFrmDayView = weeks_monday_todate_fmt;
                    } else {
                        //Showing Day View
                        this.calendarInit(true, 'agendaDay');
                        getDateFrmDayView = new Date(CalendarContext.getChoosenDate());
                        $('#calendar').fullCalendar('gotoDate', getDateFrmDayView);
            }

            that.setNavigatedViewAndDate('agendaDay', getDateFrmDayView);
                    //var end_date = $('#calendar').fullCalendar('getView').end;
                    //var current_day = moment(moment($('#calendar').fullCalendar('getDate')), "YYYY-MM-DD HH:mm:ss").format('dddd');
                    //var current_date = moment(moment($('#calendar').fullCalendar('getDate')), "YYYY-MM-DD HH:mm:ss").format('DD');
                    //var current_month = moment(moment($('#calendar').fullCalendar('getDate')), "YYYY-MM-DD HH:mm:ss").format('MMMM');
                    //var current_year = moment(moment($('#calendar').fullCalendar('getDate')), "YYYY-MM-DD HH:mm:ss").format('YYYY');

                    // Monday
                    var _monthName = moment(new Date());
                    _monthName.set('month', (weeks_monday_todate_fmt.getMonth()));
                    _monthName = _monthName.format("MMMM");
                    $('#calendar-lt>h2').html(_monthName);
                    this.monthServiceCounter = 2;
                    this.loadEventsForMonthDayView(weeks_monday_todate_fmt.getFullYear(), weeks_monday_todate_fmt.getMonth() +1, weeks_monday_todate_fmt);
                    this.initialiseMonthDayView(future_navigated_week);
                    this.fetchMonthlyView(weeks_monday_todate_fmt.getMonth() +1, weeks_monday_todate_fmt.getFullYear());

                    $('#calendar').fullCalendar('option', 'height', (this.getCalHeight() -100));

                    //Set the date to day-date-picker
                    $("#day-date-picker").val(moment(CalendarContext.getChoosenDate()).format('MM/DD/YYYY'));

                    Analytics.analytics.recordAction('viewCalendar:monthDay');
                    },
            loadEventsForMonthDayView: function (year, month, curr) {
                var getStartEnd = (curr != null) ? this.getMonthDateRange(moment(curr).format('YYYY'), moment(curr).format('M')): this.getMonthDateRange(year, month);
                var currDayfirstHr = moment(moment(getStartEnd.start.toDate()).subtract(1, 'months').format("MM/DD/YYYY")).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                var nextDayInitialHr = moment(moment(getStartEnd.end.toDate()).add(1, 'months').format("MM/DD/YYYY")).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                this.loadEventsFromEbix(currDayfirstHr, nextDayInitialHr); //Prev, Current, Next is fetched
            //Prev, Current, Next is fetched
            },
                fetchMonthlyView: function (month, year) {
                    var _that = this;
                    _that.threeMonthEvents =[];
                    Spinner.show();
                    var _gmtOffset = -(new Date().getTimezoneOffset())
                    Dataservice.calendarMonthlyView(CalendarContext.getCalenderFMID(), month, year, _gmtOffset)
                                .then(handleMonthlyViewResponse)
                                .fail(function (Error) {
                            _that.monthServiceCounter--;
                                    Spinner.hide();
                            _that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                            ErrorLog.ErrorUtils.myError(Error);
                        });
                        function handleMonthlyViewResponse(response) {
                            try {
                                _that.monthServiceCounter--;
                                if (response) {
                                    //Curent month
                        if (response.current) {
                            var _current = response.current;
                            if (_current.eventCount) {
                                $.each(_current.eventCount, function (key, row) {
                                    if (row > 0) {
                                        var tmpDate = { Date: new Date(_current.month + "/" +key + "/" +_current.year)
                                    };
                                        if (tmpDate) {
                                            _that.threeMonthEvents.push(tmpDate);
                                    }
                                }

                            });
                        }
                                }
                                    //Next month
                        if (response.next) {
                            var _next = response.next;
                            if (_next.eventCount) {
                                $.each(_next.eventCount, function (key, row) {
                                    if (row > 0) {
                                        var tmpDate = { Date : new Date(_next.month + "/" +key + "/" +_next.year)
                                    };
                                        if (tmpDate) {
                                            _that.threeMonthEvents.push(tmpDate);
                                    }
                                }

                            });
                        }
                                }
                                    //Prior month
                        if (response.prior) {
                            var _prior = response.prior;
                            if (_prior.eventCount) {
                                $.each(_prior.eventCount, function (key, row) {
                                    if (row > 0) {
                                        var tmpDate = { Date: new Date(_prior.month + "/" +key + "/" +_prior.year)
                                    };
                                        if (tmpDate) {
                                            _that.threeMonthEvents.push(tmpDate);
                                    }
                                }

                            });
                        }
                                }
                                    //_that.initialiseMonthDayView(threeMonthEvents);
                        $("#day-date-picker").datepicker("refresh");
                        }
                        if (_that.monthServiceCounter == 0) {
                            Spinner.hide();
                        }
                        $('#day-date-picker').find('a.ui-state-hover').removeClass('ui-state-hover');
                }
                catch (error) {
                    _that.monthServiceCounter--;
                    Spinner.hide();
                    _that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                    ErrorLog.ErrorUtils.myError(error);
                }
            };
            },
                calWeekBtnClick: function (e) {
                    CalendarContext.setViewType("agendaWeek");
                    this.linkActive(this.calLnks, e.target.id);
                    //$('.fc-button-agendaWeek').click();
                    //$("#week-ends").show();
                    //this.highlightToday();
                    Analytics.analytics.recordAction('viewCalendar:weekly');
                    },
                calAgendaBtnClick: function (e) {
                    e.preventDefault();
                    //Commenting below for Sprint 6
                    //this.linkActive(this.calLnks, e.target.id);
                    //$("#week-ends").hide();
                    Analytics.analytics.recordAction('viewCalendar:agenda');
                    },
                calFullWeekBtnClick: function (e) {
                    e.preventDefault();
                    this.linkActive(this.fullWorkWeekLnks, e.target.id);
                    this.calendarInit(true, 'agendaWeek');
                    var curr = $('#calendar').fullCalendar('getDate');
                    var currDate = new Date(curr);
                    curr.setHours(0, 0, 0, 0);
                    var firstday = moment(this.getFirstDayOfWeek(currDate, false)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                    curr.setHours(23, 59, 0, 0);
                    var lastday = moment(this.getLastDayOfWeek(currDate, false)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                    this.loadEventsFromEbix(firstday, lastday);
                    $('#calendar').fullCalendar('option', 'height', this.getCalHeight());
                    this.highlightToday();
                    Analytics.analytics.recordAction('viewCalendar:fullWeek');
                    },
                calWorkWeekBtnClick: function (e) {
                    e.preventDefault();
                    this.linkActive(this.fullWorkWeekLnks, e.target.id);
                    this.calendarInit(false, 'agendaWeek');
                    var curr = $('#calendar').fullCalendar('getDate');
                    var currDate = new Date(curr);
                    curr.setHours(0, 0, 0, 0);
                    var firstday = moment(this.getFirstDayOfWeek(currDate, true)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                    curr.setHours(23, 59, 0, 0);
                    var lastday = moment(this.getLastDayOfWeek(currDate, true)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format            
                    this.loadEventsFromEbix(firstday, lastday);
                    $('#calendar').fullCalendar('option', 'height', this.getCalHeight());
                    $('#calendar').fullCalendar({
                slotEventOverlap: false
                });
                    this.highlightToday();
                    Analytics.analytics.recordAction('viewCalendar:workWeek');
                    },
            calendarPrevNextBtnClick: function (selectedDtFrmWkDtPicker, frmWeekDtPicker) {
                var that = this;
                that.storePrevDtInstance = $("#week-date-picker").val();
                var dtSelectedFrmWkDtPicker = new Date();
                var curr = $('#calendar').fullCalendar('getDate');
                var isdayorweek = $('.fc-header-title').data('dayorweek');

                if (frmWeekDtPicker) {
                    dtSelectedFrmWeekAndDay = true;
                } else {
                    dtSelectedFrmWeekAndDay = false;
            }

            if (isdayorweek == 'week') { 
                if (frmWeekDtPicker == undefined) {
selectedDtFrmWkDtPicker = curr; }
                            var currDate = (isdayorweek == 'week') ? new Date(curr): new Date(selectedDtFrmWkDtPicker);
                curr.setHours(0, 0, 0, 0);
                var firstday = moment(this.getFirstDayOfWeek(currDate)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                var formattedfirstday = moment(this.getFirstDayOfWeek(currDate)).utc().format('MM/DD/YYYY'); //Convert the time to UTC and yyyy-mm-dd format
                curr.setHours(23, 59, 0, 0);
                var lastday = moment(this.getLastDayOfWeek(currDate)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                this.loadEventsFromEbix(firstday, lastday);
                if (frmWeekDtPicker != undefined && frmWeekDtPicker) {
                    dtSelectedFrmWkDtPicker = moment(selectedDtFrmWkDtPicker).format('MM/DD/YYYY');
                } else {
                    dtSelectedFrmWkDtPicker = that.currDtOrWkMonday();
                }
                that.setNavigatedViewAndDate("agendaWeek", dtSelectedFrmWkDtPicker);
                this.highlightToday();
                } else if (isdayorweek == 'day') {
                    var currDate = new Date(curr); //This might be next day / prev day
                    $('#calendar').fullCalendar('gotoDate', currDate);
                    //Allways Sync < > from day view calendar with day date picker
                    //$('#day-date-picker').datepicker().datepicker('setDate', currDate);
                    that.loadEventsForMonthDayView(currDate.getFullYear(), currDate.getMonth() +1, null);
                    that.fetchMonthlyView(currDate.getMonth() +1, currDate.getFullYear());
                    that.setNavigatedViewAndDate("agendaDay", new Date(currDate));
            }
            },
            toggleCalendarDisplay: function (e) {
                setTimeout(function () {
                    if($("#calendar-lt > h2").hasClass("closed")) {
                        $("#calendar-widget").slideDown();
                        $("#calendar-lt > h2").removeClass("closed");
                }
                else {
                    $("#calendar-widget").slideUp();
                    $("#calendar-lt > h2").addClass("closed");
            }
            }, 300);
            },
                getMonthDateRange: function (year, month) {
                    var moment = require('moment');

                    // month in moment is 0 based, so 9 is actually october, subtract 1 to compensate
                    // array is 'year', 'month', 'day', etc
                    var startDate = moment([year, month -1]);

                    // Clone the value before .endOf()
                    var endDate = moment(startDate).endOf('month');

                    // make sure to call toDate() for plain JavaScript date type
                    return { start: startDate, end: endDate };
                    },
            calculateActivityEndDate: function (startDate, endDate, timeParseRequired, changedMinutes) {
                var _start = {
            }, _end = { };
            var _mStartDate = startDate, _mEndDate = endDate;
            var _startDate = _mStartDate.toDate();
            if (changedMinutes != undefined) {
                _mEndDate = moment(_mEndDate).add(changedMinutes, "minutes");
                } else if (_mStartDate >= endDate) {
                    if (timeParseRequired) {
                        var _mStDate = moment(_startDate);
                        if(_mEndDate.get('hours') > _mStDate.get('hours')) {
                        _mEndDate = moment(_mStartDate.format('MM/DD/YYYY') + " " + _mEndDate.format('HH') + ":" +_mEndDate.format('mm'), "MM/DD/YYYY HH:mm");
                    } else if(_mEndDate.get('hours') == _mStDate.get('hours')) {
                        if (_mEndDate.get('minutes') <= _mStDate.get('minutes')) {
                            _mEndDate = moment(_startDate).add(1, "hours");
                        } else {
                            _mEndDate = moment(_mStartDate.format('MM/DD/YYYY') + " " + _mEndDate.format('HH') + ":" +_mEndDate.format('mm'), "MM/DD/YYYY HH:mm");
                    }
                    } else {
                        _mEndDate = moment(_startDate).add(1, "hours");
                }

                } else {
                        _mEndDate = moment(_startDate);
            }
            }
            _start = {
                    date: _mStartDate.format('MM/DD/YYYY'),
                    hours: _mStartDate.format('hh'),
                    minutes: _mStartDate.format('mm'),
                    ampm: _mStartDate.format('A'),
            };
            _end = {
                    date: _mEndDate.format('MM/DD/YYYY'),
                    hours: _mEndDate.format('hh'),
                    minutes: _mEndDate.format('mm'),
                    ampm: _mEndDate.format('A'),
            };

            return {
                start: _start,
                end: _end
            }


            }, calculateActivityStartDate: function (startDate, endDate, timeParseRequired) {
                var _start = {
            }, _end = { };
            var _mStartDate = startDate, _mEndDate = endDate;
            var _endDate = _mEndDate.toDate();
            if (_mEndDate <= startDate) {
                _mStartDate = moment(_endDate);
                /*if(timeParseRequired){
                    var _mEDate = moment(_endDate);
                    if(_mStartDate.get('hours')<_mEDate.get('hours')){
                        _mStartDate = moment(_mEndDate.format('MM/DD/YYYY') + " "+_mStartDate.format('HH')+":"+_mStartDate.format('mm'),"MM/DD/YYYY HH:mm");
                    }else if(_mStartDate.get('hours') == _mEDate.get('hours')){
                        if(_mStartDate.get('minutes') >= _mEDate.get('minutes')){
                            _mStartDate = moment(_endDate).add(-1,"hours");
                        }else{
                            _mStartDate = moment(_mEndDate.format('MM/DD/YYYY') + " "+_mStartDate.format('HH')+":"+_mStartDate.format('mm'),"MM/DD/YYYY HH:mm");
                        }
                    }else{
                        _mStartDate = moment(_endDate).add(-1,"hours");
                    }
                    
                }else{
                    _mStartDate = moment(_endDate);
                }*/
            }
            _start = {
                    date: _mStartDate.format('MM/DD/YYYY'),
                    hours: _mStartDate.format('hh'),
                    minutes: _mStartDate.format('mm'),
                    ampm: _mStartDate.format('A'),
            };
            _end = {
                    date: _mEndDate.format('MM/DD/YYYY'),
                    hours: _mEndDate.format('hh'),
                    minutes: _mEndDate.format('mm'),
                    ampm: _mEndDate.format('A'),
            };

            return {
                start: _start,
                end: _end
            }


            },
            beforeCheckStartDate: function () {
                this.checkStartDate($('#endDate').val())
                },
                startHrChange: function () {
                    var _changedHr = $("#hr-start-sel").val(), _chngdDurtnInMns = null;
                    _changedHr = _changedHr == 12 ? 0: _changedHr;
                    var _evtDetails = this.editingEvtDetails.start;
                    var _currhr = Number(_evtDetails.currentTime.hr);
                    _currhr = _currhr == 12 ? 0: _currhr;
                    _chngdDurtnInMns = (Number(_changedHr) * 1 -_currhr) * 60;
                    _evtDetails.changedTime.hr = _changedHr;
                    this.checkEndDate($('#startDate').val(), true, _chngdDurtnInMns);
                    _evtDetails.currentTime.hr = _changedHr;
                    },
                startMinuteChange: function () {
                    var _changedMins = $("#mins-start-sel").val(), _chngdDurtnInMns = null;
                    var _evtDetails = this.editingEvtDetails.start;
                    _chngdDurtnInMns = Number(_changedMins) * 1 -Number(_evtDetails.currentTime.mins);
                    _evtDetails.changedTime.mins = _changedMins;
                    this.checkEndDate($('#startDate').val(), true, _chngdDurtnInMns);
                    _evtDetails.currentTime.mins = _changedMins;
                    },
                startAmPmChange: function () {
                    var _changedAmPm = $("#ampm-start-sel").val();
                    var _evtDetails = this.editingEvtDetails.start;
                    _chngdDurtnInMns = _changedAmPm == "PM" ? 720: -720;
                    _evtDetails.changedTime.ampm = _changedAmPm;
                    this.checkEndDate($('#startDate').val(), true, _chngdDurtnInMns);
                    _evtDetails.currentTime.ampm = _changedAmPm;
                    },
                checkStartDate: function (selectedDate) {
                    var _self = this;
                    var _$endHrEl = $("#hr-end-sel"), _$endMinute = $("#mins-end-sel"), _$endAmPm = $("#ampm-end-sel"),
                        _$startHrEl = $("#hr-start-sel"), _$startMinuteEl = $("#mins-start-sel"), _$startAmPmEl = $("#ampm-start-sel");
                    var _strtHour = _$startHrEl.val(), _strtMinute = _$startMinuteEl.val(), _startAmPm = _$startAmPmEl.val(),
                        _endHour = _$endHrEl.val(), _endMinute = _$endMinute.val(), _endAmPm = _$endAmPm.val()
                    _$enDateEl = $('#endDate'), _$startDateEl = $('#startDate');
                    var _startDate = moment(_$startDateEl.val() + " " + _strtHour + ":" +_strtMinute + " " +_startAmPm, "MM/DD/YYYY hh:mm A");
                    var _endDate = moment(selectedDate + " " + _endHour + ":" +_endMinute + " " +_endAmPm, "MM/DD/YYYY hh:mm A");
                    if (_endDate == _startDate) {
                        var _timeParsing = true;
                        //check if all day or not
                        if (!_$endHrEl.is(':visible')) {
                            //if all day no need of time parsing
                            _timeParsing = false;
                }
                var _finalDates = _self.calculateActivityStartDate(_startDate, _endDate, _timeParsing);
                        //$("#add-apt-endDt").datepicker( "option", "minDate", _finalDates.start.date );
                        $("#add-apt-stratDt").datepicker("setDate", _finalDates.start.date);
                        $('#startDate').val(_finalDates.start.date);
                        _self.editingEvtDetails.start.currentTime.date = _finalDates.start.date;
                        if (_timeParsing) {
                            _$startHrEl.val(_finalDates.start.hours);
                            _$startMinuteEl.val(_finalDates.start.minutes);
                            _$startAmPmEl.val(_finalDates.start.ampm);
                            var _evtDetails = this.editingEvtDetails.start;
                            _evtDetails.currentTime.hr = _finalDates.start.hours;
                            _evtDetails.currentTime.mins = _finalDates.start.minutes;
                            _evtDetails.currentTime.ampm = _finalDates.start.ampm;
                    }

                    } else if (_endDate < _startDate) {
                        _endDate = _endDate.add('hours', 12);
                        _$endHrEl.val(_endDate.format("hh"));
                        _$endMinute.val(_endDate.format("mm"));
                        _$endAmPm.val(_endDate.format("A"));
                        var _endDate = _endDate.format("MM/DD/YYYY");
                    _$enDateEl.val(_endDate);
                    $("#add-apt-endDt").datepicker('setDate', _endDate);
            }
            },
                checkEndDate: function (selectedDate, isTimeChange, changedMinutes) {
                    var _self = this;
                    var _$endHrEl = $("#hr-end-sel"), _$endMinute = $("#mins-end-sel"), _$endAmPm = $("#ampm-end-sel");
                    var _strtHour = $("#hr-start-sel").val(), _strtMinute = $("#mins-start-sel").val(), _startAmPm = $("#ampm-start-sel").val(),
                        _endHour = _$endHrEl.val(), _endMinute = _$endMinute.val(), _endAmPm = _$endAmPm.val(),
                        _$enDateEl = $('#endDate'), _$startDateEl = $('#startDate');
                    var _startDate = moment(selectedDate + " " + _strtHour + ":" +_strtMinute + " " +_startAmPm, "MM/DD/YYYY hh:mm A");
                    var _endDate = moment(_$enDateEl.val() + " " + _endHour + ":" +_endMinute + " " +_endAmPm, "MM/DD/YYYY hh:mm A");
                    if (changedMinutes != undefined) {
                        var _finalDates = _self.calculateActivityEndDate(_startDate, _endDate, _timeParsing, changedMinutes);
                        $("#add-apt-endDt").datepicker("setDate", _finalDates.end.date);
                        _$enDateEl.val(_finalDates.end.date);
                        //if(_timeParsing){
                        _$endHrEl.val(_finalDates.end.hours);
                        _$endMinute.val(_finalDates.end.minutes);
                        _$endAmPm.val(_finalDates.end.ampm);
                        //}
            }
            else if (_endDate <= _startDate) {
                var _timeParsing = true;
                //check if all day or not
                if (!_$endHrEl.is(':visible')) {
                    //if all day no need of time parsing
                    _timeParsing = false;
                }
                var _finalDates = _self.calculateActivityEndDate(_startDate, _endDate, _timeParsing);
                //$( "#add-apt-endDt").datepicker( "option", "minDate", selected );
                $("#add-apt-endDt").datepicker("setDate", _finalDates.end.date);
                _$enDateEl.val(_finalDates.end.date);
                if (_timeParsing) {
                    _$endHrEl.val(_finalDates.end.hours);
                    _$endMinute.val(_finalDates.end.minutes);
                    _$endAmPm.val(_finalDates.end.ampm);
                }

            }
            },
                initDatePicker: function (e) {
                    var view = this;
                    var dt = new Date();
                    var minutes = moment().minutes();
                    var seconds = moment().seconds();
                    var hrs = moment().hours();
                    //set a variable for start end date change
                    $("#rep-startDate").datepicker({
                        showOn: "button",
                            buttonImage: "images/cal-icon.png",
                        buttonImageOnly: true,
                        buttonText: "Select date"
            });

            $("#add-apt-startDt").datepicker({
                numberOfMonths: 1,
                    onSelect: function (selected) {

                    view.editingEvtDetails.start.changedTime.date = selected;
                    var _chnagedMins = moment(selected) -moment(view.editingEvtDetails.start.currentTime.date);
                    _chnagedMins = _chnagedMins / (1000 * 60);
                    view.checkEndDate(selected, true, _chnagedMins);
                    $('#startDate').val(selected);
                    $('#add-app-start-dtpickr').slideToggle(200);
                    view.editingEvtDetails.start.currentTime.date = selected;
                    setTimeout(function () { view.adjustModalHeight();
                }, 210);
                }
            });

            $("#add-apt-endDt").datepicker({
                numberOfMonths: 1,
                    onSelect: function (selected) {
                        view.checkStartDate(selected);
                        $('#endDate').val(selected);
                        $("#add-apt-endDt").datepicker('setDate', selected);
                        $('#add-app-end-dtpickr').slideToggle(200);
                        setTimeout(function () { view.adjustModalHeight();
                }, 210);
                }
            });

            var startEndTm = view.currentTime();
            var _slectedDate = null, _sleDate = null, _slectedEndDate = null, _sleEndDate = null, _currDate = null;

            if ($("#calendar").fullCalendar('getView').name == "agendaDay") {
                _currDateFrmCalendar = moment($('#calendar').fullCalendar('getDate')).format('MM/DD/YYYY');
                _currDate = moment().format('MM/DD/YYYY');
                _slectedDate = moment($("#day-date-picker").datepicker('getDate')).format('MM/DD/YYYY');

                // Checking if the current date & high-lighted date is within the current week or not
                if (moment(_currDateFrmCalendar).isSame(moment(_currDate)) && (moment(_slectedDate).weekday() != 0 || moment(_slectedDate).weekday() != 6)) {
                    _slectedDate = moment().format('MM/DD/YYYY'); //Selected date would be Current Date
                } else {
                    _slectedDate = $("#day-date-picker").datepicker('getDate');
                }

                _slectedEndDate = _slectedDate;
                _sleDate = moment(_slectedDate).format('MM/DD/YYYY');
                _sleEndDate = _sleDate;
                if (startEndTm[0] == 11 && startEndTm[2]== "PM") {
                    _slectedEndDate = moment(_slectedDate).add("hours", 24);
                    _sleEndDate = moment(_slectedEndDate).format('MM/DD/YYYY');
            }

                $("#app-starts").html(moment(CalendarContext.getChoosenDate()).format('MM/DD/YYYY') + " " + startEndTm[0] + ":" + startEndTm[1]+ " " +startEndTm[2]); //startHr:startMm startAMPM
                $("#app-ends").html(moment(_slectedEndDate).format('MM/DD/YYYY') + " " + startEndTm[3] + ":" + startEndTm[4]+ " " +startEndTm[5]); //endHr:endMm endAMPM
                $("#rep-startDate").datepicker("setDate", _sleDate);
                $("#startDate").val(_sleDate);
                $("#endDate").val(_sleEndDate);
                $("#add-apt-startDt").datepicker('setDate', _sleDate);
                $("#add-apt-endDt").datepicker('setDate', _sleEndDate);
                //$("#add-apt-endDt").datepicker('setDate',_sleDate);
            } else {
                _sleDate = moment(CalendarContext.getChoosenDate()).format('MM/DD/YYYY');

                var start_date = moment($('#calendar').fullCalendar('getView').start);
                var weeks_monday = start_date.add(1, 'days');
                var weeks_monday_todate_fmt = weeks_monday.format('MM/DD/YYYY');

                // Checking if the current date is within the current week or not
                if (moment(_sleDate).isSame(moment(), 'week') && (moment(_sleDate).weekday() != 0 || moment(_sleDate).weekday() != 6)) {
                    _sleDate = _sleDate;
                } else {
                    if (dtSelectedFrmWeekAndDay) {
                        _sleDate = _sleDate;
                } else {
                        _sleDate = weeks_monday_todate_fmt;
            }
            }

                //if future navigated week is 'not' same as current dated week, change the DD to navigated week Monday
                if(!moment($('#calendar').fullCalendar('getView')).isSame($('#calendar').fullCalendar('getDate'), 'week') && !dtSelectedFrmWeekAndDay) {
                    _sleDate = weeks_monday_todate_fmt;
                }

                _sleEndDate = _sleDate;
                if (startEndTm[0] == 11 && startEndTm[2]== "PM") {
                    _sleEndDate = moment(_sleDate).add("hours", 24);
                    _sleEndDate = moment(_sleEndDate).format('MM/DD/YYYY');
                }
                $("#app-starts").html(_sleDate + " " + startEndTm[0] + ":" + startEndTm[1]+ " " +startEndTm[2]); //startHr:startMm startAMPM
                $("#app-ends").html(_sleEndDate + " " + startEndTm[3] + ":" + startEndTm[4]+ " " +startEndTm[5]); //endHr:endMm endAMPM
                $("#rep-startDate").datepicker("setDate", weeks_monday.toDate());
                $("#startDate, #add-apt-startDt").val(_sleDate);
                $("#endDate,#add-apt-endDt").datepicker('setDate', _sleEndDate);
                $("#startDate").val(_sleDate);
                $("#endDate").val(_sleEndDate);
                $("#add-apt-startDt").datepicker('setDate', _sleDate);
                $("#add-apt-endDt").datepicker('setDate', _sleEndDate);
                    // $("#add-apt-endDt").datepicker('setDate',moment(dt).format('MM/DD/YYYY'));
            }

            $("#hr-start-sel option", "#hr-end-sel option").find('option:selected').removeAttr("selected");
            $("#hr-start-sel").val(startEndTm[0]); //startHr
            $("#hr-end-sel").val(startEndTm[3]); //endHr

            $("#ampm-start-sel, #ampm-end-sel").find('option:selected').removeAttr("selected");
            $("#ampm-start-sel").val(startEndTm[2]); //startAMPM
            $("#ampm-end-sel").val(startEndTm[5]); //endAMPM
                    //save the current start time of event
                    if (!view.editingEvtDetails.fromEdit) {
                        view.editingEvtDetails.start = {
                        currentTime: {
                        date: (_sleDate),
                        hr: startEndTm[0],
                        mins: 0,
                        ampm: startEndTm[2]
                        },
                        changedTime: {
                        date: (_sleDate),
                        hr: startEndTm[0],
                        mins: 0,
                        ampm: startEndTm[2]
                    }
                };
            }
            view.editingEvtDetails.fromEdit = false;

            },
                currentTime: function (e) {
                //Rounding start hour to next hour, End hour would be 1 above hr
                var stRemainder =(60 -moment().minute()) % 60;
                var roundToOneHr = moment(moment()).add("minutes", stRemainder);
                var startHr = roundToOneHr.format("hh");
                var startMm = roundToOneHr.format("mm");
                var startAMPM = roundToOneHr.format("A");

                var edRemainder =(120 -moment().minute()) % 120;
                var roundToTwoHr = moment(roundToOneHr).add("hours", 1);//moment(moment()).add("minutes", edRemainder);
                var endHr = roundToTwoHr.format("hh");
                var endMm = roundToTwoHr.format("mm");
                var endAMPM = roundToTwoHr.format("A");

                result =[startHr, startMm, startAMPM, endHr, endMm, endAMPM];
            return (result);
            },
            eventsCollectionEvent: function (e) {
                $("#calendar").fullCalendar('removeEvents');
                $("#calendar").fullCalendar('addEventSource', this.toJSON());
            /* var now = moment();
            var g = _.chain(this.toJSON()).filter(function (ev) {
                return ev.allDay != true && ev.start.indexOf(now.format("YYYY-MM-DD")) > -1
            }).first().value();
            var firstEventTime = (typeof (g) != "undefined") ? (Moment(g.start).format("HH") == 12 ? 0 : parseInt(Moment(g.start).format("HH"))):08;
            //The week view should adjust the start time to the start time of the earliest activity if activities begin prior to 8 AM
            $('#calendar').fullCalendar('option', 'firstHour', firstEventTime < 8 ? firstEventTime : 08); */
            },
                loadEventsFromEbix: function (startdate, endDate) {
                    var that = this;
                    Spinner.show();
                    var servicePromises =[Dataservice.getCalendarWeeklyViewEvents(CalendarContext.getCalenderFMID(), startdate, endDate)];
                    var retrieveCalendarUsers = CommonUtilis.isEmpty(CalendarContext.getUserList());
                    var _fmId = CommonUtilis.readCookie("FMID"),
                        _evtColorSettings = CommonUtilis.readCookie("EventColorSettings"),
                        _showColorCookieval;
                    if (_evtColorSettings) {
                        _evtColorSettings = JSON.parse(_evtColorSettings);
                        if (_evtColorSettings.fmId == _fmId) {
                            _showColorCookieval = _evtColorSettings.showColor;
                        }
                    }
                    if (retrieveCalendarUsers) {
                        servicePromises.push(Dataservice.getSharedCalendarUserList(CommonUtilis.userFMID()));
                    }
            Q.allSettled(servicePromises).then(function (results) {
                if (retrieveCalendarUsers) {
                    that.stowCalendarUsers(results[1].value[0]);
                    that.renderCalendarHeader();
            }
                //Set the last navigated View and Date from users visit
                //that.setNavigatedViewAndDate();
                gotoCalendar(results[0].value);
                Spinner.hide();
                }).fail(gotoError);
                    function gotoCalendar(evnts) {
                        //servicecounter check for month day view 
                        that.monthServiceCounter--;
                        if (evnts != undefined && evnts[0]!= undefined) {
                            var eventModels = evnts[0].get("Events").map(function (event) {
                        var evntMdl = new EventsCollection.Event();
                        evntMdl.set({ "activityId": event.get("activityId")
                            });
                        evntMdl.set({ "isPrivate": event.get("isPrivate")
                            });
                        if (!CalendarContext.isCalendarSignedOnUser() && event.get("isPrivate") == 'Yes') {
                            evntMdl.set({
"title": "PRIVATE"
                        });
                        } else {
                            var _title = event.get("title") ? event.get("title"): "";
                            var fullNameWithtitle = null;
                            fullNameWithtitle = event.get("contactLastName") != null ? (event.get("contactFirstName") != null ? event.get("contactLastName") + ", " + event.get("contactFirstName"): event.get("contactLastName")): event.get("contactName");
                            //fullNameWithtitle = fullNameWithtitle != null ? fullNameWithtitle + " - " + _title : _title;
                            if (fullNameWithtitle != null && fullNameWithtitle != undefined && $.trim(fullNameWithtitle) != "") {
                                if (_title != null && _title != undefined && _title != "") {
                                    fullNameWithtitle = fullNameWithtitle != null ? fullNameWithtitle + " - " +_title: _title;
                            }
                            } else {
                                if (_title != null && _title != undefined && $.trim(_title) != "") {
                                    fullNameWithtitle = _title;
                                } else {
                                    fullNameWithtitle = "";
                            }
                        }
                            evntMdl.set({ "title": fullNameWithtitle
                        });
                            }
                        evntMdl.set({ "allDay": event.get("allDay")
                            });
                        evntMdl.set({ "recurrence": event.get("recurrence")
                            });

                        if (event.get("recurrence") == true) evntMdl.set({
                                "className": "recurrence"
                            });

                        if(event.get("startDate") == null)
                            evntMdl.set({
                                "start": moment(moment.utc(event.get("end")).toDate()).format('YYYY-MM-DD HH:mm:ss')
                            });
                                //Temporary Fix for 2hr height on same time event
                        var _startDate = moment(moment.utc(event.get("start")).toDate());
                        evntMdl.set({
                            "start": _startDate.format('YYYY-MM-DD HH:mm:ss')
                            });
                        var _endDate = moment(moment.utc(event.get("end")).toDate());
                        if (_startDate.format("MM/DD/YYYY hh:mm:ss") == _endDate.format("MM/DD/YYYY hh:mm:ss"))
                                    _endDate.add("minutes", 30);
                                //Fix for below 30 Minute Events
                        var _diff = moment.duration(_endDate.diff(_startDate));
                        if (_diff.asMinutes() < 30) { _endDate.add((30 -_diff.asMinutes()), "minutes");
                            }
                            evntMdl.set({
                                "end": _endDate.format('YYYY-MM-DD HH:mm:ss')
                            });
                            //Set border color to the color coming from json
                            if (_showColorCookieval != "off" && event.get("hexColor")) {
                                evntMdl.set('borderColor', event.get("hexColor"));
                                evntMdl.set('className', "evt-custom-border");
                            }
                            return evntMdl;
                        });
                        
                        var _haveAlldayEvt = false;
                            //Getting first event hour for entire current week
                            var firstEventHr = _.min(((_.filter(eventModels, function (obj) {
                        if (obj.get("allDay")) {
                            _haveAlldayEvt = true;
                            }
                        return obj.get("allDay") != true;
                    })).map(function (model) {
                        return Moment(model.get('start')).format('H');
                    })), function (timenum) {
                                return parseInt(timenum);
                        });

                            /*experimental fix for allday evt*/
                            var _curCalView = $("#calendar").fullCalendar("getView");
                            if (_curCalView.name != "agendaDay") {
                        if (_haveAlldayEvt) {
                            $('.fc-agenda-allday').show();
                            $('.fc-agenda-divider').show();
                        } else {
                            $('.fc-agenda-allday').hide();
                            $('.fc-agenda-divider').hide();
                            }
                        }
                        that.eventsCollection.reset(eventModels);
                }
                var _curCalView = $("#calendar").fullCalendar("getView");
                if (_curCalView.name == "agendaDay") {
                    if (that.monthServiceCounter == 0) {
Spinner.hide();
                }
                if ($("#day-date-picker").datepicker("getDate") === null) {
                        $("#day-date-picker").datepicker('setDate', CalendarContext.getChoosenDate());
                }
                } else {
                    Spinner.hide();
                }
            };

            function gotoError(Error) {
                that.monthServiceCounter--;
                Spinner.hide();
                that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
            };
            },
                agendaClickEvent: function (e) {
                    e.preventDefault();
                    },
                getShowTimeAsTxt: function (selected) {
                    var text = "";
                    if (selected) {
                        if (Utility.showtimeas) {
                            $.each(JSON.parse(Utility.showtimeas), function (key, val) {
                        if (val.value == selected) {
                            text = val.name;
                            }
                    });
                }
            }
            return text;
        },
                getKeyword: function (text) {
            var keyWordObj = {
                id: "", text: ""
                };
                if (text && this.keyword && text != "keywordNone") {
                    _.find(this.keyword, function (val, key) { if (val == text) { keyWordObj = { id: key, text: val
                }; return true;
        }
        })
            }
            return keyWordObj;
            },
                fillKeyword: function (elemnt) {
                var options = "";
                var selectedKeyword = $(".app-keywords .val").data('id');
                if (this.keyword) {
                    //For Keyword coming from CM not present in list
                    if (selectedKeyword && selectedKeyword != "keywordNone") {
                        var keyIndex = Math.random().toString().substr(2, 5);
                        this.keyword[keyIndex]= selectedKeyword;
                }
                if (selectedKeyword == 'keywordNone') {
                    options = options + "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='keyword-none'>None</label><input type='radio' value='None' name='calKeyword' id='keyword-none' checked=true></div>";
                } else { options = options + "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='keyword-none'>None</label><input type='radio' value='None' name='calKeyword' id='keyword-none'></div>"; }
                $.each(this.keyword, function (key, val) {
                    if (selectedKeyword && selectedKeyword == val) {
                        options += "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='keyword-" +key + "'>" +val + "</label><input type='radio' name='calKeyword' value='" + val + "' data-id='" + key + "' id='keyword-" +key + "'  checked=true></div>";
                } else {
                        options += "<div class='pt-radio-container'><label class='cursor-pointer pt-radio-label' for='keyword-" +key + "'>" +val + "</label><input type='radio' name='calKeyword' value='" + val + "' data-id='" + key + "' id='keyword-" +key + "'></div>";
                }
            });
            }
            if ($("." +elemnt)) {
                $("." +elemnt).html(options);
            }
            },
                getKeywords: function () {
                var _that = this;
                Dataservice.getKeywords(CommonUtilis.userFMID())
                .then(function (response) { _that.keyword = response.keywords; })
                .fail(function (error) { });
        },
            render: function (options) {
            window.scrollTo(0, 0); //This has been added for Save as draft Cancel Scenario
            Array.prototype.inArray = function (comparer) {
                for (var i = 0; i < this.length; i++) {
                    if (comparer(this[i])) return true;
                }
                return false;
        };

            // adds an element to the array if it does not already exist using a comparer 
            // function
            Array.prototype.pushIfNotExist = function (element, comparer) {
                if (!this.inArray(comparer)) {
                    this.push(element);
        }
            };

            try {
                this.fmId = options.fmId;
                this.pinnedContact.pinnedContactType = options.selectedContactType;
                if (this.pinnedContact.pinnedContactType == Constants.contactType.NonClient) {
                    this.pinnedContact.pinnedContactId = options.selectedContactId;
                } else {
                    this.pinnedContact.pinnedClientId = options.selectedContactId;
                }
                var compiledTemplate = _.template(CalendarView);
                this.$el.html(compiledTemplate({
                }));
                this.renderCalendarHeader();
                this.calLnks = $("#calendar-menu-list a");
                this.fullWorkWeekLnks = $(".choice-list-item-sm");
                $('.fc-header-left').append($('#calendar-obo-list').show());

                var _viewType = CalendarContext.getViewType() ? CalendarContext.getViewType(): 'agendaWeek';
                this.calendarInit(true, _viewType);

                getDateFrmDayView = CalendarContext.getChoosenDate() ? CalendarContext.getChoosenDate(): getDateFrmDayView;
                $('#calendar').fullCalendar('gotoDate', new Date(getDateFrmDayView));

                var curr = new Date(getDateFrmDayView); //getting the date from day view, if need current change it to 'new Date()'
                curr.setHours(0, 0, 0, 0);
                var firstday = moment(this.getFirstDayOfWeek(curr)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format
                curr.setHours(23, 59, 0, 0);
                var lastday = moment(this.getLastDayOfWeek(curr)).utc().format('YYYY-MM-DD HH:mm:ss'); //Convert the time to UTC and yyyy-mm-dd format

                this.loadEventsFromEbix(firstday, lastday);
                $('table.fc-agenda-allday th:eq(0)').html('All<br/>day');

                if (CalendarContext.getViewType() != 'agendaDay') {
                    this.highlightToday();
                } else if (CalendarContext.getViewType() == 'agendaDay') {
                    if (CalendarContext.getChoosenDate() != undefined) {
                        var choosenDate = new Date(CalendarContext.getChoosenDate());
                        this.monthServiceCounter = 2;
                        this.loadEventsForMonthDayView(choosenDate.getFullYear(), choosenDate.getMonth() +1, choosenDate);
                        this.initialiseMonthDayView(choosenDate);
                        this.fetchMonthlyView(choosenDate.getMonth() +1, choosenDate.getFullYear());
                        $("#day-date-picker").datepicker('refresh');
            }
            }

                //Below one is commented for Sprint 6
                //$(".fc-header").after("<div class='datepicker-container'><div id='datePicker'></div><div style='clear:both;'></div></div>");
                //$(".fc-header-title").click(function () { $('.datepicker-container').slideToggle("slow"); })
                //this.initializeCustomSelect();
                //Fetching keyword
                this.getKeywords();

                if (options.action == "newActivity") {
                    setTimeout(function () {
                        $("#addApptBtn").click();
                        Analytics.analytics.recordAction('AddNewCalendarActivity:contact:clicked');
                }, 1000)
            }

                //Storing the previous date instance from Week View Date Picker
                this.storePrevDtInstance = $("#week-date-picker").val();
                } catch (error) {
                    //that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                    ErrorLog.ErrorUtils.myError(error);
            }
            },
                calendarEventClick: function (calEvent, jsEvent, view) {
                    Analytics.analytics.recordAction('viewCalendarActivity');
                    var zonetime_abreviation = CommonUtilis.getTimezoneAbbreviation(),
                        _self = this,
                        isOtherUserCalendar = !CalendarContext.isCalendarSignedOnUser();
                    if (isOtherUserCalendar && calEvent.isPrivate == 'Yes') {
                        BootstrapDialog.alert("You are not authorized to view the details of this activity.", "", "Information");
                        } else {
                            try {
                                var that = this;
                                var tmpTemplate = _.template(AppointmentDetailView);
                            //window.scrollTo(0, 0);
                                Spinner.show();
                                Dataservice.getCalendarEventDetails(CalendarContext.getCalenderFMID(), calEvent.activityId).then(gotoCalendar).fail(gotoError);

                    function gotoCalendar(eventDetails) {
                        if (eventDetails && eventDetails[0]&& eventDetails[0].Event) {
                            _self.currentEvent = eventDetails[0].Event.toJSON();
                            var eventDetails = { "eventDetails": eventDetails[0].Event
                        };
                            var count = 0;
                            if (eventDetails != undefined) {
                                calEvent.startDate = moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('MM/DD/YYYY');
                                calEvent.startTime = moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('hh:mm A');
                                calEvent.endDate = moment(moment.utc(eventDetails.eventDetails.get("endDateTime")).toDate()).format('MM/DD/YYYY');
                                calEvent.endTime = moment(moment.utc(eventDetails.eventDetails.get("endDateTime")).toDate()).format('hh:mm A');
                                calEvent.contactId = eventDetails.eventDetails.get("contactId") == null ? '': eventDetails.eventDetails.get("contactId");
                                calEvent.contactFirstName = eventDetails.eventDetails.get("contactFirstName") == null ? '': eventDetails.eventDetails.get("contactFirstName");
                                calEvent.contactLastName = eventDetails.eventDetails.get("contactLastName") == null ? '': eventDetails.eventDetails.get("contactLastName");
                                calEvent.contactName = eventDetails.eventDetails.get("contactName") == null ? '': eventDetails.eventDetails.get("contactName");
                                calEvent.location = eventDetails.eventDetails.get("location") == null ? '': eventDetails.eventDetails.get("location");
                                calEvent.isPrivate = eventDetails.eventDetails.get("isPrivate") == null ? '': eventDetails.eventDetails.get("isPrivate");
                                calEvent.priority = eventDetails.eventDetails.get("priority") == null ? '': eventDetails.eventDetails.get("priority");
                                calEvent.status = eventDetails.eventDetails.get("status") == null ? '': eventDetails.eventDetails.get("status");
                                calEvent.type = eventDetails.eventDetails.get("type") == null ? '': eventDetails.eventDetails.get("type");
                                calEvent.typeId = eventDetails.eventDetails.get("type") == null ? '': eventDetails.eventDetails.get("typeId");
                                calEvent.subType = eventDetails.eventDetails.get("subType") == null ? 'Select Sub-Type': eventDetails.eventDetails.get("subType");
                                calEvent.subTypeId = eventDetails.eventDetails.get("subTypeId") == null ? 'subTypeNone': eventDetails.eventDetails.get("subTypeId");
                                calEvent.description = eventDetails.eventDetails.get("description") == null ? '': (eventDetails.eventDetails.get("description")).substr(0, 4000);
                                calEvent.recurrenceType = eventDetails.eventDetails.get("recurrenceType") == null ? '': eventDetails.eventDetails.get("recurrenceType");

                                var fullNameWithtitle = null;
                                fullNameWithtitle = eventDetails.eventDetails.get("contactLastName") != null ? (eventDetails.eventDetails.get("contactFirstName") != null ? eventDetails.eventDetails.get("contactLastName") + ", " +eventDetails.eventDetails.get("contactFirstName"): eventDetails.eventDetails.get("contactLastName")): eventDetails.eventDetails.get("contactName");
                                fullNameWithtitle = fullNameWithtitle != null ? fullNameWithtitle + " - " +eventDetails.eventDetails.get("title"): eventDetails.eventDetails.get("title");
                                calEvent.title = fullNameWithtitle;
                                calEvent.dataTitle = eventDetails.eventDetails.get("title") != null ? eventDetails.eventDetails.get("title"): ' ';

                                calEvent.actKeyword = (that.getKeyword(eventDetails.eventDetails.get("actKeyword"))).text == null ? 'Select Keyword': (that.getKeyword(eventDetails.eventDetails.get("actKeyword"))).text;
                                calEvent.actKeywordId = (that.getKeyword(eventDetails.eventDetails.get("actKeyword"))).id == null ? '': (that.getKeyword(eventDetails.eventDetails.get("actKeyword"))).id;
                                calEvent.showTimeAsText = that.getShowTimeAsTxt(eventDetails.eventDetails.get("showTimeAs"));
                                calEvent.showTimeAs = eventDetails.eventDetails.get("showTimeAs") == null ? '': eventDetails.eventDetails.get("showTimeAs");
                                calEvent.selectedParticpants = {
                            };

                                _.each(eventDetails.eventDetails.get("selectedParticpants"), function (Particpant, i) {
                                    var selPartcpnt = {
                                };
                                    selPartcpnt.id = Particpant.get("id");
                                    selPartcpnt.name = Particpant.get("name");
                                    selPartcpnt.isPrimary = Particpant.get("isPrimary");
                                    calEvent.selectedParticpants[i]= selPartcpnt;
                                    selPartcpnt = null;
                                    count++;
                            });
                                calEvent.zonetime = zonetime_abreviation;
                                $('#AppointmentTmpt').empty().append(tmpTemplate({
                                    calEvent: calEvent,
                                    noOfParticipants: count
                            }));
                                $('#viewEventModal').modal('show');
                                $("#viewEventModal #appModalCancel").html('Close');
                                if (eventDetails.eventDetails.get("status") == 2 || eventDetails.eventDetails.get("status") == "Done") {
                                    $('#markComp').addClass('hidden');
                            }
                                //save the current start time of event
                                that.editingEvtDetails.fromEdit = true;
                                that.editingEvtDetails.start = {
                                        currentTime: {
                                            date: (calEvent.startDate),
                                            hr: moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('hh'),
                                            mins: moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('mm'),
                                            ampm: moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('A')
                                },
                                        changedTime: {
                                            date: (calEvent.startDate),
                                            hr: moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('hh'),
                                            mins: moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('mm'),
                                            ampm: moment(moment.utc(eventDetails.eventDetails.get("startDateTime")).toDate()).format('A')
                                }
                            };

                        }
                            Spinner.hide();

                        } else {
                            Spinner.hide();
                            if (eventDetails && eventDetails[0]&& eventDetails[0].status) {
                                var _customMessage = { stack: eventDetails[0].value, message: eventDetails[0].value
                            };
                        }
                            ErrorLog.ErrorUtils.myError(_customMessage);
}
                        };

                            function gotoError(Error) {
                                Spinner.hide();
                        that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                        ErrorLog.ErrorUtils.myError(Error);
                    };
                    } catch (error) {
                    Spinner.hide();
                    that.closeTheDatePicker(["week-date-picker", "day-date-picker"]);
                    ErrorLog.ErrorUtils.myError(error);
                }
                }
            // View Event [End]
            },
                getFirstDayOfWeek: function (curr, workweek) {
                    if (workweek == undefined || workweek == false) {
                        return new Date(curr.setDate(curr.getDate() -curr.getDay())).setHours(0);
                } else {
                    return new Date(curr.setDate((curr.getDate() -curr.getDay()) +1)).setHours(0);
            }
            },
                getLastDayOfWeek: function (curr, workweek) {
                    if (workweek == undefined || workweek == false) {
                        return new Date(curr.setDate(curr.getDate() -curr.getDay() +6)).setHours(24);
                } else {
                    return new Date(curr.setDate(curr.getDate() -curr.getDay() +5)).setHours(24);
            }
            },
                isMobileOrDesktop: function (e) {
                    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ? true: false;
                    },
            formatDatetoYYYYMMDD: function (date) {
                return moment(date).format('YYYY-MM-DD');
                },
                showingWkView: function (e) {
                    $('#calendar-lt').hide();
                    $('#calendar').removeClass('add-border').toggleClass();
                    },
                showingDayView: function (e) {
                    $('#calendar-lt').addClass('col-fixed-300').show();
                    $('#calendar-lt').show();
                    //$('#calendar-widget').addClass('add-border');
                    $('#calendar').addClass('col-sm-12 col-md-12 col-offset-300 add-border');
                    //$('#calendar').addClass('col-sm-12 col-md-12 col-lg-12 add-border');
                    $("#week-ends").hide(); //Hide fullweek and workweek buttons
                    },
                calendarInit: function (needWorkWeek, thisView) {
                    var that = this;
                    that.currentDaysEventCounter = 0;
                    var calLnks = $(".choice-list-item > a");
                    var fullWorkWeekLnks = $(".choice-list-item-sm");
                    $("#calendar").fullCalendar('destroy');
                    $('#calendar').fullCalendar({
                        height: this.getCalHeight(),
                        slotEventOverlap: false, //This will not make events overlap one another
                    buttonText: {
                    prev: '',
                    next: ''
                },
                    titleFormat: {
                    month: 'MMMM yyyy', // September 2014
                        week: "MMM d {'-' [MMM ]d', 'yyyy}", // Sep 13 2014
                    day: 'dddd, MMMM d'  // Thursday, August 10
                },
                    columnFormat: {
                    week: 'd\nddd',
                    day: ''
                },
                    header: {
                        left: thisView == 'agendaDay' ? 'prev,next,title': '',
                        center: thisView == 'agendaDay' ? '': 'prev,title,next',
                        right: 'month,agendaWeek,agendaDay'
                },
                    viewDisplay: function (view) {
                        if (thisView == 'agendaWeek') {
                            that.showingWkView();
                        $(".fc-header-title").attr('data-dayorweek', 'week');
                        $("#calendar-lt, #calendar").removeClass("DayViewCalendar").addClass("WeekViewCalendar");
                        that.renderDatePickerOn("Week");
                        //Calendar Title inside date picker textbox
                        //Example Nov 27 - Dec 3, 2016
                        $("#week-date-picker").val($('.WeekViewCalendar .fc-header-title > h2').text());
                        //that.setNavigatedViewAndDate('agendaWeek', dtSelectedFrmWkDtPicker);
                        that.setNavigatedViewAndDate('agendaWeek', CalendarContext.getChoosenDate());
                    } else {
                            that.showingDayView();
                        $('.fc-header-title > h2').css('color', '#333333');
                        $(".fc-header-title").attr('data-dayorweek', 'day');
                        $("#calendar-lt, #calendar").removeClass("WeekViewCalendar").addClass("DayViewCalendar");
                        that.renderDatePickerOn("Day");
                }

                        //$("#day-date-picker").val(moment(CalendarContext.getChoosenDate()).format('MM/DD/YYYY'));

                    if (typeof (timelineInterval) != "undefined") window.clearInterval(timelineInterval);
                    timelineInterval = window.setInterval(that.setTimeline, 1000);
                    try {
                        that.setTimeline();
                } catch (err) {
                }
                        //that.renderTodayButton(view); //Commenting this function call, as the today button is added in datepicker.

                        //This is triggered when "Today" button is clicked.
                        $.datepicker._gotoToday = function (id) {
                        $(id).datepicker('hide').blur();
                            that.goToToday();
                };

                    that.renderCalendarHeader();
                    $("#day-date-picker").removeClass('hidden');
                    if ($("#day-date-picker").length > 0 && $("#day-date-picker").datepicker("getDate") === null) {
                        $("#day-date-picker").datepicker('setDate', CalendarContext.getChoosenDate());
                    }
                },
                        editable: false,
                        selectable: false,
                        selectHelper: true,
                        disableDragging: true,
                    eventClick: function (calEvent, jsEvent, view) {
                        that.calendarEventClick(calEvent, jsEvent, view);
                },
                        defaultView: thisView,
                        weekends: needWorkWeek,
                        firstHour: 08,
                    dayClick: function (start, allDay, jEvent) {
                        $('#addApptBtn').click();
                        var startUTC = moment(moment.utc(start).toDate());
                        var endUTCAdd1HrToStart = moment(moment(moment.utc(start).toDate()).format('MM/DD/YYYY hh:mm A')).add('h', 1);
                        //var endUTC = moment(moment.utc(end).toDate());
                        var startDt =[startUTC.format('MM/DD/YYYY'), startUTC.format('hh:mm'), startUTC.format('A')];
                        var startHrMn = startDt[1].split(":");
                        var endDt =[endUTCAdd1HrToStart.format('MM/DD/YYYY'), endUTCAdd1HrToStart.format('hh:mm'), endUTCAdd1HrToStart.format('A')];
                        var endHrMn = endDt[1].split(":");

                    if (!allDay) { //Not an AllDay Event
                        $('#addAppointment #app-starts').html(startDt[0] + " " +startDt[1]+ " " +startDt[2]);
                        $('#addAppointment #app-ends').html(endDt[0] + " " +endDt[1]+ " " +endDt[2]);
                        $('#addAppointment #startDate').val(startDt[0]);
                        $('#addAppointment #endDate').val(endDt[0]);
    //Hour
                        $("#addAppointment #hr-start-sel", "#addAppointment #hr-end-sel").find('option:selected').removeAttr("selected");
                        $("#addAppointment #hr-start-sel").val(startHrMn[0]); //start Hr
                        $("#addAppointment #hr-end-sel").val(endHrMn[0]); //end Hr
    //Min
                        $("#addAppointment #mins-start-sel, #addAppointment #mins-end-sel").find('option:selected').removeAttr("selected");
                        $("#addAppointment #mins-start-sel").val(startHrMn[1]); //start Min
                        $("#addAppointment #mins-end-sel").val(endHrMn[1]); //end Min
    //AM/PM
                        $("#addAppointment #ampm-start-sel, #addAppointment #ampm-end-sel").find('option:selected').removeAttr("selected");
                        $("#addAppointment #ampm-start-sel").val(startDt[2]); //start AMPM
                        $("#addAppointment #ampm-end-sel").val(endDt[2]); //end AMPM
} else { //AllDay Event
                        $('#addAppointment #app-starts').html(startDt[0]);
                        $('#addAppointment #app-ends').html(endDt[0]);
                        $('#addAppointment #startDate').val(startDt[0]);
                        $('#addAppointment #endDate').val(endDt[0]);
                        $('#addAppointment #app-all-day-yes > .choice-list-button, #addAppointment #app-all-day-no > .choice-list-button').removeClass('active');
                        $('#addAppointment #app-all-day-yes > .choice-list-button').addClass('active');
                        $(".app-start-time, .app-end-time").hide();
                }
                $("#add-apt-startDt").datepicker('setDate', startDt[0]);
                $("#add-apt-endDt").datepicker('setDate', endDt[0]);
                        //save the current start time of event
                        that.editingEvtDetails.fromEdit = true;
                        that.editingEvtDetails.start = {
                            currentTime: {
                            date: (startDt[0]),
                                hr: startUTC.format('hh'),
                                mins: startUTC.format('mm'),
                            ampm: startDt[2]
                        },
                            changedTime: {
                            date: (startDt[0]),
                                hr: startUTC.format('hh'),
                                mins: startUTC.format('mm'),
                            ampm: startDt[2]
                        }
                    };
                },
                    eventRender: function (event, element, view) {
                        that.currentDaysEventCounter++;
                        $(element).find(".fc-event-time").remove();
                        var eventsTopPosition = element.position().top +1; //As per business requirement, added 1px top for all events
                        element.parent().children().eq(element.index()).css('top', eventsTopPosition);

                    var _curCalView = $("#calendar").fullCalendar("getView");
                        /*if(_curCalView.name == "agendaDay" && that.currentDaysEventCounter == 1){
                            var _eventTime = event.start.getHours();
                            if(_eventTime < 8 && !event.allDay){
                                var _$scrollContainer = $('.fc-view-agendaDay .fc-event-container:last').parent().parent();
                                var _slotNumber = _eventTime*2;
                                _$scrollContainer.animate({
                                    scrollTop: $(".fc-slot"+_slotNumber).offset().top - _$scrollContainer.offset().top + _$scrollContainer.scrollTop()// Scroll to this ID
                                }, 10);
                            }
                        }*/

                        /* Experimental fix for allday evt */
                        if (_curCalView.name == "agendaDay") {
                        if (event.allDay) { $('.fc-agenda-allday, .fc-agenda-divider').show();
                        }
                }

                        //Side-by-side
                        /*var nextEventLeft = element.offset().left + element.width() + 5;
                        element.parent().children().eq(element.index() + 1).css('left', nextEventLeft);*/

                        //Side-by-side (Adding Event)
                        //$(element).addClass('events' + '_' + event.start.getDate() + '_' + event.start.getHours() + '_' + that.currentDaysEventCounter);
                },
                    eventAfterAllRender: function (view) {
                        $('.fc-event.evt-custom-border').css("border-left-width", "5px");
                }
            });

            }, // calendarInit function close
                renderDatePickerOn: function (dayorweek) {
                    var that = this;
                    if (dayorweek == "Week" && $(".DayViewCalendar").length == 0) {
                        if($("#week-date-picker").length == 0) {
                        //Initially, On Week View - append the input box.
                        $(".WeekViewCalendar .fc-header-title").attr('data-dayorweek', 'week').append('<input type="text" name="week-date-picker" value="' +$('.fc-header-title > h2').text() + '" class="form-control" id="week-date-picker" data-date-format="YYYY/MM/DD" autocomplete="off" autocorrect="off" spellcheck="false" />');
                    }

                        //Once input box appended, attach datepicker to it
                        if($("#week-date-picker").length > 0) {
                            $("#week-date-picker").datepicker({
                                showOtherMonths: true,
                                selectOtherMonths: true,
                                showOn: "both",
                                showButtonPanel: true,
                                    buttonImage: "images/cal-icon.png",
                                buttonImageOnly: true,
                                buttonText: 'Click Here',
                                    defaultDate: moment(CalendarContext.getChoosenDate()).format('MM/DD/YYYY'),
                            beforeShow: function (input, inst) {
                            $('.scrollToTop').addClass('hidden');
                            $("#week-date-picker").attr("disabled", true);
                            $('body').append('<div id="pt-date-picker-overlay" class="pt-transparent-overlay"></div>');
                            if ($('#ui-datepicker-div').hasClass('day-date-picker')) {
                                $('#ui-datepicker-div').removeClass('day-date-picker');
                        }
                            $('#ui-datepicker-div').addClass(this.id);
                            setTimeout(function () {
                                that.alignTheDtPicker(["week-date-picker"]);
                                that.setNavigatedViewAndDate('agendaWeek', CalendarContext.getChoosenDate());
                                $("#week-date-picker").datepicker('setDate', CalendarContext.getChoosenDate()).attr("disabled", false);
                        }, 10);

                            },
                            onSelect: function (dateText, inst) {
                                dtSelectedFrmWeekAndDay = true;
                            var selectedDt = $(this).datepicker('getDate'); //the getDate method
                            $(".fc-header-title").attr('data-dayorweek', 'week');
                                getEventsFrmSelectedDate(selectedDt);
                            $(this).datepicker('hide').blur();
                                //Example: Nov 27 - Dec 3, 2016
                            $(this).val($('.WeekViewCalendar .fc-header-title > h2').text());
                            },
                            onClose: function () {
                            $('#pt-date-picker-overlay').remove();
                            $('.scrollToTop').removeClass('hidden');
                                //Example: Nov 27 - Dec 3, 2016
                            $("#week-date-picker").val($('.WeekViewCalendar .fc-header-title > h2').text()).blur();
                            $('#ui-datepicker-div').removeClass('week-date-picker');
                            }
                    }).keydown(function (event) { //Enter/Return Click
                        if (event.which === $.ui.keyCode.ENTER) {
                            event.preventDefault();
                    }
                    });
                }
                } else if (dayorweek == 'Day') {
                    //$("#day-date-picker").datepicker('setDate', 'today');
                    if ($("#day-date-picker").datepicker("getDate") === null) {
                        $("#day-date-picker").datepicker('setDate', CalendarContext.getChoosenDate());
                }
                $(".ui-datepicker-today > a").removeClass('ui-state-hover');
                this.initialiseMonthDayView(CalendarContext.getChoosenDate());
            }

            function getEventsFrmSelectedDate(selectedDtObject) {
                //After selecting a date, change the calendar view to agendaWeek
                $("#calendar").fullCalendar('changeView', 'agendaWeek').fullCalendar('gotoDate', selectedDtObject);
                //Get the Events and Render onto the calendar
                that.calendarPrevNextBtnClick(selectedDtObject, true);
            }

            },
                setTimeline: function setTimeline() {
                var curTime = new Date();
                if (curTime.getHours() == 0 && curTime.getMinutes() <= 5) {
                    var todayElem = $(".fc-today");
                    todayElem.removeClass("fc-today");
                    todayElem.removeClass("fc-state-highlight");

                    todayElem.next().addClass("fc-today");
                    todayElem.next().addClass("fc-state-highlight");
            }

            var parentDiv = $(".fc-agenda-slots:visible").parent();
            var timeline = parentDiv.children(".timeline");
            if (timeline.length == 0) { //if timeline isn't there, add it
                timeline = $("<span class='timeline-sm-arrow'><img src='images/current-time.png' width='8' height='9' /></span><hr class='timeline'>");
                parentDiv.prepend(timeline);
            }

            var curCalView = $("#calendar").fullCalendar("getView");
            if (curCalView.visStart < curTime && curCalView.visEnd > curTime) {
                $(".timeline-sm-arrow").show();
                timeline.show();
            } else {
                $(".timeline-sm-arrow").hide();
                timeline.hide();
            }

            var curSeconds = (curTime.getHours() * 60 * 60) + (curTime.getMinutes() * 60) +curTime.getSeconds();
            var percentOfDay = curSeconds / 86400; //24 * 60 * 60 = 86400, # of seconds in a day
            var topLoc = Math.floor(parentDiv.height() * percentOfDay);

            timeline.css("top", topLoc + "px");
                //$('.timeline-sm-arrow').css("top", topLoc - 11 + "px");
                //if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                //    $('.timeline-sm-arrow').css("top", topLoc - 11 + "px");
                //}
                //For all devices less than tablet view
                if (window.innerWidth < 767) {
                    $('.timeline-sm-arrow').css("top", topLoc -9 + "px");
                }
                    //else if (/Android/i.test(navigator.userAgent)) {
                    //    $('.timeline-sm-arrow').css("top", topLoc - 9 + "px");
                    //}
                else {
                    $('.timeline-sm-arrow').css("top", topLoc -11 + "px");
            }
        },
                linkActive: function (calLnks, thisLnk) {
                    if (calLnks.parent().hasClass('hdr-tab-active')) {
                        calLnks.parent().removeClass('hdr-tab-active');
                        $("#" +thisLnk).parent().addClass('hdr-tab-active');
            }
        },
            slideNav: function (Obj, objNav) {
                $('#' +Obj).slideToggle("slow", function () {
                    if ($("#" +Obj).is(":visible")) {
                        $('#' +objNav).removeClass("nav-down").addClass("nav-up");
                } else {
                    $('#' +objNav).removeClass("nav-up").addClass("nav-down");
        }
            });
            },
                highlightToday: function () { if(typeof ($('.fc-today').attr("class")) != "undefined") $("table.fc-agenda-days th." +$('.fc-today').attr("class").split(' ')[0]).css({ 'background-color': '#79b240', 'color': '#ffffff' }); },
                getCalHeight: function () {
                    if (this.isMobileOrDesktop()) {
                        if (navigator.userAgent.match(/iPad/i)) {
                            return (screen.height -200);
                    } else {
                            return (screen.height);
                }
                } else {
                    var innerHt = window.innerHeight;
                if (!innerHt) innerHt = document.documentElement.clientHeight ? document.documentElement.clientHeight: document.body.clientHeight;
                    if (innerHt >= 950) { return 850; } else {
                        return innerHt;
                }
            }
            },
                viewContactFromCal: function (e) {
                    e.preventDefault();
                    var that = this;
                    var contactId = e.target.id;
                    var advFMID = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
                    if (GlobalContext.getInstance().getGlobalContext().Context.ContactType == "nonclient" && GlobalContext.getInstance().getGlobalContext().Context.IsOBO == true) {
                        advFMID = CommonUtilis.readCookie('FMID');
            }
            if (contactId.indexOf("Contact.") > -1) {
                ContactType = Constants.contactType.NonClient;

            } else {
                ContactType = Constants.contactType.Client;
                }
                    // contactId = contactId.replace(/\D/g, '');
                    // contactId = +contactId;
                    //Constants.contactType.NonClient

                    Analytics.analytics.recordAction('viewCalendarActivity:contact:clicked');

                    if (contactId == "undefined" || contactId == "" || contactId === null) {
                        BootstrapDialog.alert("We are not able to link to the Contact Profile at this time. The selected advisor is not authorized to view the details of this client. You may need to select a different advisor before continuing. <br /><br /> If the advisor is authorized, please confirm that the client exists in Contact Manager or that the appointment was not created using a hand-typed entry for contact.");
                    } else {
                        $('#viewEventModal').modal('hide');
                        that.adjustingOverflow();
                        NavApi.changeContactAndLauchCP(contactId, ContactType);
            }
        },
                goToToday: function (e) {
                    $('#calendar').fullCalendar('today');

                    if (this.calMode === "dayMonth") {
                        $("#day-date-picker").datepicker('setDate', 'today');
                        $(".ui-datepicker-today > a").removeClass('ui-state-hover');
                        this.setNavigatedViewAndDate("agendaDay", $("#day-date-picker").val());
                        this.initialiseMonthDayView($("#day-date-picker").val());
                    } else {
                        this.calendarPrevNextBtnClick(e);
        }
            //Spinner.hide();
            },
                renderTodayButton: function (calViewObject) {
            // clear
            this.$('.fc-header-right').html('');
            this.$('[pt-calendar-today-button]').closest('tr').remove();
                    // if view doesn't contain today...show the today button
                    var today = moment(new Date()).startOf('day');
                    var viewStart = moment(calViewObject.start);
                    var viewEnd = moment(calViewObject.end);
                    var viewContainsToday = today.isSame(calViewObject.start) || (today.isAfter(calViewObject.start) && today.isBefore(calViewObject.end));
                    if (!viewContainsToday) {
                        if (calViewObject.name == 'agendaWeek') {
                            this.$('.fc-header-right').html('<button pt-calendar-today-button class="pt-text-button pt-h6 pt-color-blue pull-right hidden-xs pt-pad-rt-zero" style="height: 30px;">Reset to today</button>');
                            this.$('#calendar table').first().append('<tr class="visible-xs"><td colspan="100%" class="text-center"><button pt-calendar-today-button class="pt-text-button pt-h6 pt-color-blue">Reset to today</button></td></tr>');
                    } else {
                        this.$('.fc-header-right').html('<button pt-calendar-today-button class="pt-text-button pt-h6 pt-color-blue pull-right pt-pad-rt-zero" style="height: 30px;"><span class="hidden-xs">Reset to today</span><span class="visible-xs">Today</span></button>');
                }
                this.$('[pt-calendar-today-button]').off('click', this.goToToday).on('click', this.goToToday);
            }
            },
            renderCalendarHeader: function () {
                //reset event color legend modal view
                this.resetColorLegendView();
                this.$('#pt-calendar-header').html(this.headerTemplate(
                    {
                            multiuser: CalendarContext.getUserList().length > 1,
                            calendarOwnerPossesiveName: this.currentCalendarUserPossesiveName(),
                            calendarOwnerName: this.currentCalendarUserName(),
                            isWeekView: CalendarContext.getViewType() == 'agendaWeek'
            }
            ));
            },
                renderUserPicker: function () {
                    var that = this;
                    if (this.userPickerView) {
                        this.userPickerView.close();
            }
            this.userPickerView = new CalendarUserPickerView({ el: this.$('#pt-calendar-user-picker').get(0) });
            this.userPickerView.userList = CalendarContext.getUserList();
            this.userPickerView.selectedUserFmid = CalendarContext.getCalenderFMID();
            this.userPickerView.userSelected = function (selectedFmid) {
                CalendarContext.saveLastCalendarFMID(selectedFmid);
                that.renderCalendarHeader();

                //Render the options
                var _gContext = GlobalContext.getInstance().getGlobalContext().Context, options = {
                    //fmId: _gContext.AdvisorFMID || CommonUtilis.readCookie('FMID'),
                        fmId: CalendarContext.getCalenderFMID(),
                    selectedContactId: _gContext.ContactId,
                        selectedContactType: _gContext.ContactType,
                    action: ""
                };
                that.render(options);

                    //Backbone.history.navigate('/', true);
            };
            this.userPickerView.render();
            },
            currentCalendarUserPossesiveName: function () {
                var calendarUser = this.currentCalendarUser();
                if (!calendarUser) {
                    return null;
            }
                var name = '';
                if(CommonUtilis.isEmpty(calendarUser.firstName)) {
                    if(CommonUtilis.isEmpty(calendarUser.name)) {
                        return name;
                }
                var nameParts = calendarUser.name.split(' ');
                    name = nameParts[0];
                    if (name.length > 10) {
                        name = name.substring(0, 10).trim() + '&hellip;';
                } else if (nameParts.length > 1) {
                    name += ' ' +nameParts[1].substring(0, 1);
                }
                } else {
                    name = calendarUser.firstName;
                    if (name.length > 10) {
                        name = name.substring(0, 10).trim() + '&hellip;';
                } else if(!CommonUtilis.isEmpty(calendarUser.lastName)) {
                    name += ' ' +calendarUser.lastName.substring(0, 1);
            }
            }
                return name + '&#8217;s';
                },
            currentCalendarUserName: function () {
                var calendarUser = this.currentCalendarUser();
                return calendarUser == null ? '': calendarUser.firstName + ' ' +calendarUser.lastName;
                },
                currentCalendarUser: function () {
                    if(CommonUtilis.isEmpty(CalendarContext.getUserList())) {
                        return null;
            }
            var calendarFMID = CalendarContext.getCalenderFMID();
            return _.find(CalendarContext.getUserList(), function (user) {
                return calendarFMID == user.fmid;
            });
            },
                calShowUsersClick: function (e) {
                    if (CalendarContext.getUserList().length > 1) {
                        this.renderUserPicker();
            }
            },
            setNavigatedViewAndDate: function (navigatedView, navigatedDate) {
                CalendarContext.setViewType(navigatedView); //agendaDay or agendaWeek
                CalendarContext.setChoosenDate(navigatedDate); //last stored date
                },
                stowCalendarUsers: function (sharedUsersResponse) {
                    var calendarUsers =[];
                    _.each(sharedUsersResponse.get('sharedUsers'), function (sharedUser) {
                        var user = {
                                fmid: sharedUser.get('extLink'),
                                ebixUserIdentifier: sharedUser.get('userId'),
                                name: sharedUser.get('fullName'),
                                firstName: sharedUser.get('firstName'),
                                lastName: sharedUser.get('lastName')
                }
                        calendarUsers.push(user);
            });
            CalendarContext.setUserList(calendarUsers);
        }
    });
    return calendarview;
});
