import { Parameter } from '../_models/index';
import { Agent } from '../_models/index';
import { UserExpression } from '../_models/userexpression';
import { AIResponse } from '../_models/responsedata';

export class Intent {

    name: string;
    description: string;
    agentId: string;
    action: string;
    expressionList: Array<UserExpression> = [];
    paramMap: any = {};
    intentId : string;
    paramTypeList : Array<string> = [];
    responseList : Array<AIResponse> = [];

}
