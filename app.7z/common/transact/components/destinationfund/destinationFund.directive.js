/**
* @ngdoc property
* @name Destination Fund Directive
* @requires newFundDetailsModel
* @requires newFundDetailsModel
* @requires $uibModal
* @requires newFundDetailsInitialLoader
* @requires transactEventConstants
* @requires $timeout
* @requires $filter
* @requires TransactConstant
* @requires eventConstants
* @requires transactModel
* @description
*
* - Destination Fund directive represents the existing funds of investor along with a chance to create a new fund. 
*
**/
'use strict';

var destinationFund = function($state,selectFundModel,newFundDetailsModel, $uibModal, newFundDetailsInitialLoader, transactEventConstants, $timeout, $filter, TransactConstant, eventConstants, transactModel, fundDetails, recommendedFundCardModelService,authenticationService) {
	return {
            template: require('./destinationFund.html'),
            restrict: 'E',
            replace: true,            
            scope: {
                destinationFund : '=',
                labelName : '@'
            },
            controller:['$scope', function($scope){  
                var rows;
                var _userType = authenticationService.getUser().userType;
                var _isSTPState = ($state.current.url === '/stp') ? true: false;
                // setting flag based on existing and new investor
                $scope.showNewFund = transactModel.isNewInvestor || transactModel.getIsNewFolio();
                $scope.investInto = {};
                
                // setting flag for Direct or Existing Investment
                $scope.isDirectInvestment = transactModel.isDirect;

                if(!$scope.labelName) {
                    $scope.labelName = $filter('translate')(TransactConstant.transact.DESTINATION_FUND);
                };

                $scope.funds = [$filter('translate')(TransactConstant.transact.EXST_FUND),$filter('translate')(TransactConstant.transact.NEW_FUND)];

                $scope.radios = {};
                // $scope.radios.selectedVal = $scope.funds[0];                                                                                           

                $scope.disableSelectFund = true;
                
                $scope.$on(transactEventConstants.transact.NEW_FUND_DETAILS, function(event,data) {
                    
                    $scope.disableSelectFund = false;
                    var _selectedFundAccNum = transactModel.getFundDetails() ? transactModel.getFundDetails().tschvalAccno : '';                    
                    if(!$scope.showNewFund)
                    {
                        $scope.sectionOptions = [];                        
                        rows = newFundDetailsModel.getExistingFundDetails();
                        if(rows.length === 0) {
                            $scope.existingFundsDisable = true;
                        }else{
                            $scope.radios.selectedVal = $scope.funds[0];
                        }
                        angular.forEach(rows,function(data){
                            var gridRow = {};
                            gridRow = data;
                            if(data.nfoFlag == 'Y'){
                                 gridRow.title = data.accNo +' - '+data.fundOptDesc + " - NFO";                         
                                 gridRow.fundName = data.fundOptDesc + " - NFO";
                            }else{
                                gridRow.title = data.accNo +' - '+data.fundOptDesc;                         
                                gridRow.fundName = data.fundOptDesc;
                            }
                            /**
                             * Code below Added as a part of STP CR - Investor and QC DEFECT #4420
                             * Selected source fund should not be in destination fund for STP.
                             * Start
                             */
                            if(_isSTPState) {
                                if(data.accNo !== _selectedFundAccNum) {
                                    $scope.sectionOptions.push(gridRow);                                                                
                                }                            
                            } else {
                                $scope.sectionOptions.push(gridRow);                            
                            }
                            /**
                             * Code below Added as a part of STP CR - Investor and QC DEFECT #4420
                             * Selected source fund should not be in destination fund for STP.
                             * End
                             */
                        });
                        if($scope.sectionOptions.length > 0){
                            $scope.investInto.defaultFund = $scope.sectionOptions[0];
                        }else{
                            $scope.radios.selectedVal = $scope.funds[1]; 
                        }
                        
                        transactModel.setFormattedExistingFunds($scope.sectionOptions);
                    }
                 });
                                                                   
                                                
                $scope.$on('selectedOption',function(event, data){ 
                    newFundDetailsModel.setSelectedExistingFund(data);
                    $timeout(function () {
                        $scope.destinationFund = data;                                                
                        $scope.$emit(transactEventConstants.transact.FUND_UPDATED); 
                         if(_userType && (_userType.toString() === '10') && $state.current.url ==='/dtp'){
                        $scope.$emit('disableDividendOption',$scope.destinationFund);

                        }
                         if(_userType && (_userType.toString() === '10') && $state.current.url ==='/stp'){
                        $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        
                        }
                        if(_userType && (_userType.toString() === '10') && $state.current.url ==='/switch'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        }
                    }, 0); 
                     if(_userType && (_userType.toString() === '10')){
                        $scope.$emit('existingOptionSelected',data); 
                     }
                    
                });
                
                $scope.listenChange = function(){                    
                    if($scope.radios.selectedVal==$scope.funds[0]){                   
                        $scope.destinationFund = rows[0];
                        fundDetails.setFundType('E');
                        console.log($state.current);
                        $scope.$emit(transactEventConstants.transact.FUND_UPDATED);
                        if(_userType && (_userType.toString() === '10') && $state.current.url ==='/dtp'){
                            $scope.$emit("disableDividendOption",$scope.destinationFund);
                        }
                        if(_userType && (_userType.toString() === '10') && $state.current.url ==='/stp'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        }
                        if(_userType && (_userType.toString() === '10') && $state.current.url ==='/switch'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        }
                        
                    }
                    else if($scope.radios.selectedVal==$scope.funds[1]){
                        $scope.chooseFundsModal();
                        $scope.destinationFund = "" ;
                        fundDetails.setFundType('N');
                        $scope.$emit(transactEventConstants.transact.FUND_UPDATED); 
                        if(_userType && (_userType.toString() === '10') && $state.current.url ==='/stp'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        } else if(_userType && (_userType.toString() === '10') && $state.current.url ==='/switch'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        }                                             
                    }   

                }
                //This is done to open FundCardsModal on click of 'i' icon
                $scope.showFundCardModal = function(fundId) {
                    var modalInstance;  
                    recommendedFundCardModelService.setFundCardId(fundId);
                    /*if(transactModel.getIsNewFolio() && authenticationService.isInvestorLoggedIn()) {

                    }
                    else {*/
                        modalInstance = $uibModal.open({
                            template : require('../../../components/smartSolFundCardModelDetails/smartSolFundCardModel.html'),
                            scope : $scope
                        });
                    // }
                }
                
                // written for checking previous fund selected or not.
                $scope.selectedFund = {};
                $scope.selectedFund.label = "";
                
                var modalInstance;
                $scope.chooseFundsModal = function(){                                        
                    modalInstance = $uibModal.open({
                      template : require('../newFundsModal/newFundsModal.html'),
                      scope : $scope
                    });
                };

                $scope.$on('singleSelectionDone',function(event,obj){
                    newFundDetailsModel.setSelectedExistingFund('');
                    $scope.destinationFund = obj.selectedOne; 
                    console.log($scope.destinationFund)
                    $scope.$emit(transactEventConstants.transact.FUND_UPDATED); 
                    if(_userType && (_userType.toString() === '10')){
                        $scope.$emit("disableDividendOption",$scope.destinationFund);
                        $scope.$emit("dividendOptionStp",obj)
                    }
                    if(_userType && (_userType.toString() === '10') && $state.current.url ==='/stp'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                    } else if(_userType && (_userType.toString() === '10') && $state.current.url ==='/switch'){
                        $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                    }
                    
                    $scope.selectedFund = obj.selectedOne;
                    modalInstance.close();
                });

                $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){
                    $scope.chooseFundsModal();
                });

                $scope.$on(transactEventConstants.transact.RESET_FUND, function(event){
                    $scope.sectionOptions = transactModel.getFormattedExistingFunds();
                    if($scope.showNewFund){
                        $scope.destinationFund = "";
                    }else if($scope.isDirectInvestment) {
                        // $scope.existingFundsDisable = true;
                        $scope.radios.selectedVal = "";
                        $scope.destinationFund = "";
                        $scope.$emit(transactEventConstants.transact.FUND_CHANGED);
                    }else{
                        if($scope.sectionOptions.length > 0){
                            $scope.radios.selectedVal = $scope.funds[0];
                        }else{
                         $scope.radios.selectedVal = "";
                        }                       
                        $scope.investInto.defaultFund = $scope.sectionOptions[0];
                        $scope.destinationFund = $scope.sectionOptions[0];
                    }
                    $scope.$emit(transactEventConstants.transact.FUND_UPDATED);
                    if(_userType && (_userType.toString() === '10') && $state.current.url ==='/stp'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                    } else if(_userType && (_userType.toString() === '10') && $state.current.url ==='/switch'){
                        $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                    }
                });
                $scope.$on(transactEventConstants.transact.EDIT_FUND, function(event, editFundObj){
                    $scope.destinationFund = {};
                    $scope.sectionOptions = transactModel.getFormattedExistingFunds();
                    if(!editFundObj.fundObj){
                        return;
                    }
                    if(editFundObj.fundObj.fundType == 'E'){
                        $scope.radios.selectedVal = $scope.funds[0];
                        $scope.investInto.defaultFund = (_.filter($scope.sectionOptions, function(x) {
                            return x.title == editFundObj.fundObj.title;
                        }))[0];
                        $scope.destinationFund = angular.copy(editFundObj.fundObj);
                    }else if(editFundObj.fundObj.fundType == 'N'){
                        if(!$scope.showNewFund){
                            $scope.radios.selectedVal = $scope.funds[1];
                        }
                        $scope.destinationFund = angular.copy(editFundObj.fundObj);
                    }
                    $scope.$emit(transactEventConstants.transact.FUND_UPDATED);
                    if(_userType && (_userType.toString() === '10') && $state.current.url ==='/stp'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        } else if(_userType && (_userType.toString() === '10') && $state.current.url ==='/switch'){
                            $scope.$emit('dividendOptionsStp',$scope.destinationFund);
                        }
                });

            }]

        };

};

destinationFund.$inject = ['$state','selectFundModel', 'newFundDetailsModel', '$uibModal', 'newFundDetailsInitialLoader', 'transactEventConstants', '$timeout', '$filter', 'TransactConstant', 'eventConstants', 'transactModel', 'fundDetails', 'recommendedFundCardModelService','authenticationService'];
module.exports = destinationFund;