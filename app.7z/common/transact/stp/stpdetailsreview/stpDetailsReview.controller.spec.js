'use strict';
describe('Controller: stpDetailsReviewController', function() {
	var $controller,$scope,stpDetailsReviewController,$filter,authenticationService,eventConstants,stpDetailsModel,transactModel;

    var stpObjectWithAmountSelected = {
        "stpAmount" : {
            "amount" : 51000,
            "type" : "fixedAmount"
        },
        "destinationFund" : {
            "accNo": "0010008062712",
            "fundName": "Franklin India PRIMA FUND"
        },
        "startDate":"Wed Dec 28 2016 18:44:13 GMT+0530 (India Standard Time)",
        "endDate":"Fri Dec 30 2016 22:44:13 GMT+0530 (India Standard Time)",
        "frequency":"Weekly",
        "noofInstallments" : 6
    };

    var stpObjectWithCapitalAppreciationSelected = {
        "stpAmount" : {
            "amount" : "Capital Appreciation",
            "type" : "capitalAppreciation"
        },
        "startDate":"Wed Jan 9 2016 18:44:13 GMT+0530 (India Standard Time)",
        "endDate":"Fri Aug 3 2016 22:44:13 GMT+0530 (India Standard Time)",
        "frequency":"Monthly",
        "destinationFund" : {    
            "accNo": "0010008062712",       
            "fundName": "Franklin India PRIMA FUND"
        },
        "noofInstallments" : 6
    };

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_$filter_,_stpDetailsModel_,_authenticationService_,_eventConstants_,_transactModel_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();		

		$filter = _$filter_;
		stpDetailsModel = _stpDetailsModel_;
        transactModel = _transactModel_;		
		authenticationService = _authenticationService_;
		eventConstants = _eventConstants_;
		stpDetailsModel.setStpDetails(stpObjectWithCapitalAppreciationSelected);
        transactModel.setStpFixedAmtStatus(false);
		$scope.config = {};
		loadController();			
	}));	

	function loadController(){
        stpDetailsReviewController = $controller('stpDetailsReviewController', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(stpDetailsReviewController).toBeDefined();
    });

    it('should define the variables on load if user selects Capital Appreciation',function(){
        expect($scope.stpDetails).toEqual(stpObjectWithCapitalAppreciationSelected);
        expect($scope.destinationFund).toBe(stpObjectWithCapitalAppreciationSelected.destinationFund.fundName)
        expect($scope.stpAmount).toBe(stpObjectWithCapitalAppreciationSelected.stpAmount.amount);
        expect($scope.frequency).toBe(stpObjectWithCapitalAppreciationSelected.frequency);
        expect($scope.startDate).toBe($filter('date')(stpObjectWithCapitalAppreciationSelected.startDate,'dd MMM yyyy'));
        expect($scope.endDate).toBe($filter('date')(stpObjectWithCapitalAppreciationSelected.endDate,'dd MMM yyyy'));
        expect($scope.noofInstallments).toBe(stpObjectWithCapitalAppreciationSelected.noofInstallments);       
        expect($scope.amountStatus).toBe(false);
    });

    it('should define the variables on load if user selects Amount',function(){        
        stpDetailsModel.setStpDetails(stpObjectWithAmountSelected);
        transactModel.setStpFixedAmtStatus(true);
        loadController();
        expect($scope.stpDetails).toEqual(stpObjectWithAmountSelected);
        expect($scope.destinationFund).toBe(stpObjectWithAmountSelected.destinationFund.fundName)
        expect($scope.stpAmount).toBe(stpObjectWithAmountSelected.stpAmount.amount);
        expect($scope.frequency).toBe(stpObjectWithAmountSelected.frequency);
        expect($scope.noofInstallments).toBe(stpObjectWithAmountSelected.noofInstallments);                       
        expect($scope.amountStatus).toBe(true);
    });

    it('should define the variables config.toTxnDetailsState,config.toState based on the user logged in(Investor)',function(){
        expect($scope.config.toTxnDetailsState).toBe("invTransact.txnDetails");
        expect($scope.config.toState).toBe("invTransact.base.stp");
    });

    it('should define the variables config.toTxnDetailsState,config.toState based on the user logged in(Advisor)',function(){
        authenticationService.setUser({"user":"test123"});
        loadController();
        expect($scope.config.toTxnDetailsState).toBe("transact.txnDetails.stp");
        expect($scope.config.toState).toBe("transact.base.stp");
    });

    it('should define the variable stpKeyValuePairs on load',function(){
        expect($scope.stpKeyValuePairs[0].value).toBe("Franklin India PRIMA FUND");
        expect($scope.stpKeyValuePairs[1].value).toBe("0010008062712");
        expect($scope.stpKeyValuePairs[2].value).toBe("capitalAppreciation");
        expect($scope.stpKeyValuePairs[3].value).toBe("Capital Appreciation");
        expect($scope.stpKeyValuePairs[4].value).toBe("Monthly");
        expect($scope.stpKeyValuePairs[5].value).toBe($filter('date')(stpObjectWithCapitalAppreciationSelected.startDate,'dd MMM yyyy'));
        expect($scope.stpKeyValuePairs[6].value).toBe($filter('date')(stpObjectWithCapitalAppreciationSelected.endDate,'dd MMM yyyy'));
        expect($scope.stpKeyValuePairs[7].value).toBe(6);
    });

    it('should listen the event eventConstants.ACTION_ICON_CLICKED when triggered',function(){
        spyOn($scope,"$emit");
        $scope.$broadcast(eventConstants.ACTION_ICON_CLICKED);
        expect($scope.$emit).toHaveBeenCalledWith("NAVIGATE_TO_TRANSACT",{key: 'stp'});
    });
});