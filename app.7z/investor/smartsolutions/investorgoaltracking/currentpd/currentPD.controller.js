
'use strict';
function smartSolsCurrentPdCtrl($scope, $state,$uibModal,recommendedPlanInitialLoader,recommendedPlanModelService,advisorEventConstants, currentPlanFundsInitalLoaderService, currentPlanFundsService,$timeout, investorGoalModelService, authenticationService) {
  $scope.topupOptions = [{
    "title": "Top-up with",
    "category" : "topup"
  }, {
    "title": "Same Funds",
    "category" : "samefunds"
  }, {
    "title": "FT Recommended Funds",
    "category" : "ftrecommended"
  }];

  $scope.$on("selectedTopup", function (event, data) {
    if(data.category=="samefunds"){
        console.log("current state for same funds",$state.current.name);
        recommendedPlanModelService.setRecommendedFromState($state.current.name);
        $state.go("smartSol.investor.topupwithsf.topupwithsamefunds");
    }
    else if(data.category=="ftrecommended"){
      recommendedPlanModelService.setRecommendedFromState($state.current.name);
      $state.go("smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.or");
    }
  });

  // recommendedPlanInitialLoader.loadAllServices($scope);
  var params = {
    "folioPanNo" : investorGoalModelService.folioId, //"17921689",//investorGoalModelService.folioId,
    "guId" : authenticationService.getUser() ? authenticationService.getUser().guId : null,
  };
  currentPlanFundsInitalLoaderService.loadAllServices($scope, params);
  $scope.goalChartData = {
    data : [],
    goalAmount : null
  };
  $scope.$on(advisorEventConstants.smartSolutions.CURR_GOAL_DATA, function($event){
    $scope.goalChartData.data = currentPlanFundsService.getGoalChartDetails().data.reverse();
    $scope.goalChartData.goalAmount = currentPlanFundsService.getGoalChartDetails().goalAmount;
  });
  
        // var statusTemplate = '<div uib-popover-template="" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'
        var statusTemplate ='<div uib-popover-template="\'viewCompostion.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'+
        '<script type="text/ng-template" id="viewCompostion.html">' +
        '<div><button type="button" ng-click="grid.appScope.$emit(\'showViewComposition\', COL_FIELD)" class="btn panel-orange-btn m0">View Composition</button></div></script>';

        $scope.topupwith="Top-up with";
        $scope.update = function(){
          /*alert($scope.topupwith);*/
          if($scope.topupwith=="Same Funds"){
            $state.go("smartSol.investor.topupwithsf.topupwithsamefunds");
          }
          else if($scope.topupwith=="FT Recommended Funds"){
            $state.go("smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.or");
          }
        }


        $scope.modify=function(){
          $state.go("smartSol.investor.modifymain.modify");
          recommendedPlanModelService.setRecommendedFromState($state.current.name)
        };
}

smartSolsCurrentPdCtrl.$inject = ['$scope', '$state','$uibModal','recommendedPlanInitialLoader','recommendedPlanModelService','advisorEventConstants', 'currentPlanFundsInitalLoaderService','currentPlanFundsService','$timeout', 'investorGoalModelService', 'authenticationService'];
module.exports = smartSolsCurrentPdCtrl;