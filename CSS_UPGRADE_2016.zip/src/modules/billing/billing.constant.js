(function() {
    angular.module('CSS.billing').constant('billingConstants', {

        payment_switch_constants: {
            "defaultPayment": "default",
            "paybill": "paybill",
            "editPayment": "editPayment",
            "confirm": "confirm",
            "verify": "verify",
            "unsuccessful": "unsuccessful"
        },

        payment_methods_code: {
            "VI": "Visa",
            "MC": "MasterCard",
            "CR": "Credit",
            "DB": "Debit",
            "CHK": "Checking",
            "CH": "Checking",
            "SAV": "Savings"
        },

        SUPPORTED_CREDIT_CARDS: {
            'DISCOVER': 'DS',
            'AMEX': 'AX',
            'VISA': 'VI',
            'MASTER': 'MC'
        },

        maxAmountLimit: 25000,

        addedPaymentDetails: ["additionalIndex", "cardCategory", "cardCategoryDisplay", "cardDisplayType", "cardtype", "creditCardCategoryDisplay", "digitsCardNum", "isCard", "isDefault", "isNickNameLong", "methodSelectedValue", "nickName", "nickNameDisplay", "bankNickName", "statusOnBillingAccountNumber", "paymentDivision"],

        errorMsgs: {
            'accountNumberDesk': [{
                "expression": "required",
                "description": "'Policy or Billing Account' is a required field"
            }, {
                "expression": ["minlength"],
                "description": "'Policy or Billing Account Number' must be atleast 8 characters"
            }, {
                "expression": "alphaNumeric",
                "description": "Please enter a valid policy or billing account number"
            }, {
                "expression": "validNumber",
                "description": "Enter the valid Policy number; do not use hyphens, or spaces (key as 378586489)"
            }],

            'accountNumberMg': [{
                "expression": "required",
                "description": "'Policy or Billing Account' is a required field"
            }, {
                "expression": ["minlength"],
                "description": "'Policy or Billing Account Number' must be atleast 8 characters"
            }, {
                "expression": "alphaNumeric",
                "description": "Please enter a valid policy or billing account number"
            }, {
                "expression": "validNumber",
                "description": "Enter the valid Policy number; do not use hyphens, or spaces (key as 378586489)"
            }],

            'zipCode': [{
                "expression": "required",
                "description": "'Zip Code' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter a valid 5 digit zip code"
            }],

            'cvvOrcsc': [{
                "expression": "required",
                "description": "'CVV/CSC' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter a valid 3 digit CVV/CSC"
            }],

            'enterzipcode': [{
                "expression": "required",
                "description": "'ZipCode' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter a valid 5 digit zip code"
            }],

            'entername': [{
                "expression": "required",
                "description": "'Enter Name' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter valid name on card"
            }],

            'EmailAddress': [{
                "expression": "required",
                "description": "'Email Address' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter valid Email Address"
            }],

            'confirmEmailAddress': [{
                "expression": "required",
                "description": "'Re Enter Email Address' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter valid Email Address"
            }],

            'accHolderName': [{
                "expression": "required",
                "description": "'Enter Name' is a required field"
            }, {
                "expression": ["pattern"],
                "description": "Please enter valid name on card"
            }]

        }

    });
})();
