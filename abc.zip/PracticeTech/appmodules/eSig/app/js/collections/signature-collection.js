define(['appmodules/eSig/app/js/models/sign-page-model'], function(SignModel) {
    var SignCollection = Backbone.Collection.extend({
        model: SignModel,
        fetched: false,
       // url: 'js/data/content_9.json',
        parse: function(response) {
            for (i = 0; i < response.ESignatureDocument.documentSigner.length; i++) {
                response.ESignatureDocument.documentSigner[i]['images'] = response.ESignatureDocument.documentImage?response.ESignatureDocument.documentImage.imageLocation:"";
                response.ESignatureDocument.documentSigner[i]['additionalVerficationNeeded'] = response.ESignatureDocument['additionalVerficationNeeded'];
            }
            return response.ESignatureDocument.documentSigner;
        },
        search: function(attribute, value) {
            //console.log("search",attribute,value);
            return this.some(function(x) {
                return (x.get(attribute) === value );
            });
        }
    });
    return new SignCollection();
});

