/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function InvTransactController($scope, fticLoggerMessage, loggerConstants, selectFundModel, $state, $stateParams, selectFundInitialLoader, eventConstants, $timeout, transactModel, transactEventConstants, TransactConstant, selectInvestorModel, newFundDetailsInitialLoader, ftiModifySipInitialLoader, paperlessModel, bankDtlsModel, redeemModel, swpModel, stpDetailsModel, transactNowModel, fticCancelStpFundDetailsModel, $q, fticCancelStpInitialLoader, toaster, fundDetails, sipDetailsModel) {
    console.info('Investor Transact Controller!!');
    //Need to check the conflict in the below code in edit case and new investor case.
    // if(!$stateParams.key){
    //     transactModel.resetSetters();
    //     transactModel.isNewInvestor = false;
    // }
    $scope.isOpenInvGrid = {};
    $scope.isOpenFundGrid = {};
    $scope.isOpenRedeemGrid = {};
    $scope.isOpenPayDetails = {};
    $scope.isOpenNomineeGrid = {};
    $scope.isOpenReviewDetails = {};
    $scope.isOpenInvestPreferGrid = {};

    var curState = $state.current.name;
    $scope.isInvestmentPreferAvailable = (curState === 'invTransact.base.switch' || curState === 'invTransact.base.dtp' || curState === 'invTransact.base.stp' || curState === 'invTransact.base.buy' || curState === 'invTransact.base.sip');
    SetInitialValues();
    $scope.config = {};
    $scope.config.detailsHeading = '';
    $scope.keyValueList = [];
    /*$scope.eventName = 'FlexiSip';*/
    // Needs to be set in respective controller with property 'title'
    $scope.config.txnFormDetails = {};
    $scope.config.txnFormPayDetails = {};
    $scope.config.txnFundDetails = {};
    //$scope.ifNewInvestor=true;
    $scope.isNomineeEdit = false;

    $scope.stateStatus = null;
    $scope.stateStatus = transactModel.getStateValue();
    $scope.isNewFolio = transactModel.getIsNewFolio();

    $scope.$on(transactEventConstants.transact.KYC_NOT_REG_FLOW, function(event, data) {
        //$scope.isShowFundGrid=false;
        $scope.isShowInvestorDetails = true;
    });
    $scope.$on(transactEventConstants.transact.Pay_Detail_Show, function(event, data) {
        $scope.isPaymentDetailsIni = true;
        $scope.isDisablePayDetails = true;
    });

    $scope.$on(transactEventConstants.transact.Payment_Detail, function(event, data) {
        $scope.isOpenPayDetails.open = true;
        $scope.isDisablePayDetails = false;
        $scope.isOpenRedeemGrid.open = false;
    });

    if ($scope.stateStatus) {
        $timeout(function() {
            if ($scope.stateStatus.key === TransactConstant.transact.Investor_Key) {

            } else if ($scope.stateStatus.key === TransactConstant.transact.Investment_Perf_Key) {
                $scope.$broadcast(transactEventConstants.transact.Selected_Investor);
                $scope.keyValueInvestPreferList = transactNowModel.getkeyValueInvPreferData();
                $scope.isDisableInvestPreferGrid = false;
                $scope.isShowInvestorDetails = false;
                $scope.isOpenInvestPreferGrid.open = true;
                $scope.isDisableFundGrid = true;
                $scope.isShowInvestPrefer = true;
                $scope.isShowFundGrid = true;
                $scope.isDisableReedemGrid = true;
                //added new folio
                if ($scope.moduleUrl === '/buy' && $scope.isNewFolio) {
                    $scope.isShowNomineeGrid = true;
                    $scope.isInitialShow = false;
                    $scope.$broadcast('getInvestorPreferenceData');
                }
            } else if ($scope.stateStatus.key == TransactConstant.transact.Fund_Key) {
                selectInvestorTile();
                $scope.isDisableReedemGrid = true;
                $scope.isShowInvestPrefer = false;
                $scope.isInitialShow = false;
                $scope.keyValueInvestPreferList = transactNowModel.getkeyValueInvPreferData();
            } else if ($scope.stateStatus.key == TransactConstant.transact.Redeem_Key || $scope.stateStatus.key == TransactConstant.transact.SWP_Key || $scope.stateStatus.key == TransactConstant.transact.Switch_Key || $scope.stateStatus.key == TransactConstant.transact.Stp_Key || $scope.stateStatus.key == TransactConstant.transact.Payment_Key || $scope.stateStatus.key == TransactConstant.transact.Dtp_Key || $scope.stateStatus.key == TransactConstant.transact.NOMINEE_KEY) {
                $scope.$broadcast(transactEventConstants.transact.Selected_Investor);
                $scope.keyValueInvestPreferList = transactNowModel.getkeyValueInvPreferData();
                showFundView();
                $scope.isShowInvestorDetails = false;
                $scope.isShowInvestPrefer = false;
                $scope.isInitialShow = false;
            } else if ($scope.stateStatus.key === 'Investment Preference New Folio') {
                $scope.isInitialShow = false;
                $scope.isShowNomineeGrid = true;
                $scope.isDisableNomineeGrid = true;
                onFolioSelection('newfolio');
            }

        }, 0);
    }

    $scope.$on(transactEventConstants.transact.Set_Key_Value_Transact, function(event, data) {
        $scope.keyValueList = data;
        $scope.isShowReedemGrid = false;
    })

    $scope.$on('FlexiSip', function(event, data) {
        $scope.keyValueList = [];
        $scope.isShowReedemGrid = true;
        $scope.isOpenPayDetails.open = false;
        $scope.isDisablePayDetails = true;
        $scope.isOpenRedeemGrid.open = true;
    })

    var setSelectFundBuy = function() {
        if ($scope.moduleUrl === '/buy') {
            if ($stateParams.key === TransactConstant.transact.Payment_Key) {
                transactModel.setTransactType(TransactConstant.buy.BUY);
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            } else if ($stateParams.key === TransactConstant.transact.Fund_Key) {
                transactModel.setTransactType(TransactConstant.buy.BUYFUND);
                $timeout(function() {
                    $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
                }, 0);
            } else {
                fundDetails.removeFundDetails();
                transactModel.setTransactType(TransactConstant.buy.BUYFUND);
            }
        }

        $scope.config.txnFundDetails.title = 'Select Fund';
    };


    $scope.$on(transactEventConstants.transact.Investor_Details, function(event, data) {
        selectInvestorTile();
    });

    $scope.$on(transactEventConstants.transact.Open_Grid, function(event, data) {
        $scope.isInitialShow = false;
        $scope.isDisableFundGrid = true;
        $scope.isDisableReedemGrid = true;
        $scope.moduleUrl = $state.current.url;
        // console.log('module URL is ' + $scope.moduleUrl)
        if (($scope.moduleUrl === '/buy' || $scope.moduleUrl === '/sip') && ($scope.ifNewInvestor || $scope.isNewFolio)) {
            $scope.isShowNomineeGrid = true;
            $scope.isDisableNomineeGrid = true;
        }
    });

    $scope.$on(transactEventConstants.transact.Show_Fund, function(event, data) {
        showFundView();
    });

    $scope.$on(transactEventConstants.transact.RESET_REDEEM_FORM, function(event, data) {
        $scope.$broadcast(transactEventConstants.transact.REDEEM_FORM_RESET, data);
    });
    $scope.$on(transactEventConstants.transact.RESET_STP_FORM, function(event, data) {
        $scope.$broadcast(transactEventConstants.transact.STP_FORM_RESET);
    });
    $scope.$on(transactEventConstants.transact.RESET_SWP_FORM, function(event) {
        $scope.$broadcast(transactEventConstants.transact.SWP_FORM_RESET);
    });
    $scope.$on(transactEventConstants.transact.RESET_SWITCH_FORM, function(event) {
        $scope.$broadcast(transactEventConstants.transact.SWITCH_FORM_RESET);
    });

    $scope.$on('Select_Fund_Continue', function(event, data) {
        $scope.$broadcast('Call_Balance_Units');
        $scope.$broadcast('Call_Registered_banks');
        $scope.$broadcast('populateRedeemDetails');
        //$scope.$broadcast('Edit_Form');
    });

    $scope.$on('Select_Fund_Continue1', function(event, data) {
        $scope.$broadcast('Call_Balance_Units');
        $scope.$broadcast('Call_Registered_banks');
    });

    $scope.$on('FUND_SELECTION_UNCHANGED', function() {
        $scope.$broadcast('EDIT_SWP_FORM');
        $scope.$broadcast('EDIT_STP_FORM');
    });

    $scope.$on('setInvestorPreference', function(event, data) {
        $scope.keyValueInvestPreferList = transactNowModel.getkeyValueInvPreferData();
        //selectInvestorModel.setSelectedInvestorDtls(transactModel.getSelectedFolioDts());
        $scope.isShowInvestPrefer = false;
        selectInvestorTile();
    });

    $scope.$on('investorPrefer', function(event) {
        $scope.keyValueInvestPreferList = [];
        $scope.isDisableInvestPreferGrid = false;
        $scope.isOpenInvestPreferGrid.open = true;
        $scope.isDisableFundGrid = true;
        $scope.isShowInvestPrefer = true;
        $scope.isShowFundGrid = true;
        $scope.isDisableReedemGrid = true;

        //$scope.$broadcast('closePaymentView'); 
        //$scope.$broadcast('closeSelectFund');
        transactNowModel.invPreferEditClicked = true;
        transactNowModel.hasInvPreferData = true;
        //$scope.$broadcast('showInvestPanel');
    });

    $scope.$on('nomineeDetailsCont', function() {
        if (($scope.ifNewInvestor || $scope.isNewFolio) && ($scope.moduleUrl === '/buy' || $scope.moduleUrl === '/sip')) {
            $scope.isShowNomineeGrid = false; //new folio only
            $scope.isOpenPayDetails.open = true;
            $scope.isOpenRedeemGrid.open = true;
            $scope.isDisableReedemGrid = false;
            $scope.isNomineeEdit = false;
            // transactModel.setTransactType(TransactConstant.buy.NOMINEE);
            transactModel.setNomineeDtlsFlag(true)
            $scope.$broadcast('NOMINEE_TILE', $scope.isNomineeEdit);
        }
    });

    $scope.$on(transactEventConstants.transact.Fund_Edit_Clicked, function(event, args) {
        $scope.keyValueList = [];
        $scope.isShowReedemGrid = true;
        $scope.isDisablePayDetails = true;
        $scope.isShowFundGrid = true;
        $scope.isOpenInvGrid.open = false;
        $scope.isOpenFundGrid.open = true;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isDisableReedemGrid = true;
	    $scope.isDisableNomineeGrid = ($scope.ifNewInvestor || $scope.isNewFolio); //new folio only
        $scope.$broadcast(transactEventConstants.transact.Edit_Fund_Button_Clicked);
        if ($scope.stateStatus) {
            if ($scope.stateStatus.key == TransactConstant.transact.Redeem_Key || $scope.stateStatus.key == TransactConstant.transact.SWP_Key || $scope.stateStatus.key == TransactConstant.transact.Switch_Key || $scope.stateStatus.key == TransactConstant.transact.Stp_Key || $scope.stateStatus.key == TransactConstant.transact.Buy_Key) {
                $scope.$broadcast(transactEventConstants.transact.NEW_FUND_DETAILS);
                $scope.$broadcast(transactEventConstants.transact.INV_FUND_DETAILS);
                $scope.stateStatus.key = '';
            }
        }
    });
    $scope.$on(transactEventConstants.transact.Nominee_Edit_Clicked, function(event, args) {
        $scope.isNomineeEdit = true;
        $scope.isShowFundGrid = false;
        $scope.isShowNomineeGrid = true;
        $scope.isOpenNomineeGrid.open = true;
        $scope.isOpenFundGrid.open = false;
        $scope.isOpenInvGrid.open = false;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isDisableNomineeGrid = false;
        // transactModel.setTransactType(TransactConstant.buy.NOMINEE);
        transactModel.setNomineeDtlsFlag(true);
        $scope.isDisableReedemGrid = true;
        $scope.$broadcast('NOMINEE_TILE', $scope.isNomineeEdit);
    });
    $scope.$on('editNoNominee', function() {
        $scope.isNomineeEdit = true;
        $scope.isShowFundGrid = false;
        $scope.isShowNomineeGrid = true;
        $scope.isOpenNomineeGrid.open = true;
        $scope.isOpenFundGrid.open = false;
        $scope.isOpenInvGrid.open = false;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isDisableNomineeGrid = false;
    })


    $scope.$on(transactEventConstants.transact.Inv_Edit_Clicked, function(event, args) {
        $scope.keyValueList = [];
        $scope.isShowReedemGrid = true;
        //$scope.isDisablePayDetails = true;        
        $scope.isShowInvestorDetails = true;

        if ($scope.isInvestmentPreferAvailable) {
            $scope.isShowInvestPrefer = true;
            $scope.isOpenInvestPreferGrid.open = false;
            $scope.isDisableInvestPreferGrid = true;
        }

        $scope.isOpenInvGrid.open = true;
        $scope.isOpenFundGrid.open = false;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isShowFundGrid = true;
        $scope.isDisableFundGrid = true;

        transactNowModel.isFolioEditClicked = true; //New Code - harsha
        if ($state.current.url == '/cancelStp') {
            $scope.isShowReedemGrid = false;
            $scope.isDisableReedemGrid = true;
        }

        $scope.isDisableReedemGrid = true;
        $scope.$broadcast(transactEventConstants.transact.Edit_Button_Clicked);
    });

    function showFundView() {
        $scope.showView = true;
        if ($state.current.url !== '/cancelStp') {
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            $scope.$broadcast(transactEventConstants.transact.Intl_Modify_Ctrl);
        }
        $timeout(function() {
            $scope.isShowFundGrid = false;
            $scope.isOpenFundGrid.open = false;
            $scope.isOpenInvGrid.open = false;
            $scope.moduleUrl = $state.current.url;

            if (($scope.ifNewInvestor || $scope.isNewFolio) && ($scope.moduleUrl == '/buy' || $scope.moduleUrl == '/sip')) {
                $scope.isDisableNomineeGrid = false;
                $scope.isShowNomineeGrid = true;
                $scope.isOpenNomineeGrid.open = true;
                $scope.isDisablePayDetails = true; //optional - check
            } else if ($scope.moduleUrl == '/cancelStp') {
                $scope.isShowReedemGrid = false;
                $scope.isDisableReedemGrid = true;
            } else {
                $scope.isOpenRedeemGrid.open = true;
                $scope.isDisableReedemGrid = false;
            }
        }, 0);
    }


    function selectInvestorTile() {

        if (transactModel.isNewInvestor || $scope.isNewFolio) {
            $scope.ifNewInvestor = true;
            $scope.isShowNomineeGrid = true;
        }
        if (!transactModel.isNewInvestor) {
            $scope.$broadcast(transactEventConstants.transact.Selected_Investor);
            if ($state.current.name === 'transact.base.modifysip' || $state.current.name === 'invTransact.base.renewsip' || $state.current.name === 'invTransact.base.modifysip') {
                ftiModifySipInitialLoader.loadAllServices($scope, selectInvestorModel.getSelectedInvestorDtls());
                //newFundDetailsInitialLoader.loadAllServices($scope,selectInvestorModel.getSelectedInvestorDtls());
            } else if ($state.current.name === 'invTransact.base.cancelStp') {
                fticCancelStpInitialLoader.loadAllServices($scope, selectInvestorModel.getSelectedInvestorDtls());
            } else if (!transactModel.isSameInv || $scope.stateStatus) {
                $scope.$broadcast('DIFFERENT_INVESTOR_CONTINUE');
                if ($state.current.name === 'invTransact.base.buy') {
                    $scope.isEditBuyFolio = transactModel.isBuyFolioEditState;
                     if (!$scope.isEditBuyFolio) {
                        var userType, folioId;
                        userType = transactNowModel.getInvestPrefer().investorMode === 'direct' ? 'DA' : userType;
                        if ($scope.isNewFolio) {
                            folioId = "";
                        }
                        newFundDetailsInitialLoader.loadAllServices($scope, {folioId : folioId , userType : userType});
                    }
                    /*else {

                    }*/
                    $scope.kycState = 'invTransact.base.kycForm';
                    setSelectFundBuy();
                } else {
                    selectFundInitialLoader.loadAllServices($scope, selectInvestorModel.getSelectedInvestorDtls());
                    newFundDetailsInitialLoader.loadAllServices($scope, selectInvestorModel.getSelectedInvestorDtls());
                }
                $scope.stateStatus = null;
            }
        } else {
            newFundDetailsInitialLoader.loadAllServices($scope, selectInvestorModel.getSelectedInvestorDtls());
        }

        $timeout(function() {
            $scope.isShowInvestorDetails = false;
            $scope.isShowFundGrid = true;
            $scope.isDisableFundGrid = false;
            $scope.isOpenInvGrid.open = false;
            $scope.isOpenFundGrid.open = true;
        }, 0);
    }

    function SetInitialValues() {
        $timeout(function() {
            $scope.isTransactChanged = true;
            //transactModel.isTransactionStarted = false;
        })
        $scope.isShowFundGrid = true;
        $scope.isShowInvestorDetails = true;
        $scope.isShowReedemGrid = true;
        $scope.isShowReviewDetails = (($scope.moduleUrl === "/buy" && $scope.isNewFolio) ? false : true);
        $scope.isInitialShow = true;
        $scope.isDisableFundGrid = true;
        $scope.isDisableReedemGrid = true;
        $scope.isDisableReviewDetails = true;
        // $scope.isDisablePayDetails = true;
        // $scope.isPaymentDetails = false;   
        // $scope.isPaymentDetailsIni = false;
        // $scope.oneAtATime = true;
        $scope.isOpenInvGrid.open = true;
        $scope.isOpenFundGrid.open = false;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isOpenReviewDetails.open = false;
        // $scope.isOpenPayDetails.open= false;

        // //$scope.ifNewInvestor=false;
        transactModel.isModifySip = false;
        transactModel.isSameInv = false;
        // $scope.isShowNomineeGrid=false;
        $scope.isDisableNomineeGrid=true;
        $scope.isDisablePayDetails = true;
        // $scope.isOpenNomineeGrid.open= false;
        // $scope.isOpenPayDetails.open= false;
        // $scope.ifNewInvestor= transactModel.isNewInvestor;
        // $scope.isShowNomineeGrid=false;
        // $scope.isDisableNomineeGrid=true;


        if ($scope.isInvestmentPreferAvailable) {
            $scope.isShowInvestPrefer = true;
            $scope.isDisableInvestPreferGrid = true;
            $scope.isOpenInvestPreferGrid.open = false;
        }

    }
    if ($state.current.name === 'invTransact.base.cancelStp') {
        $scope.isShowReedemGrid = false;
        $scope.isDisableReedemGrid = true;
    }

    $scope.$on(transactEventConstants.transact.INV_TRANSACT_CSTP_REVIEW, function() {
        $scope.isOpenReviewDetails.open = true;
        $scope.isDisableReviewDetails = false;
        $scope.isShowReedemGrid = false;
        $scope.isDisableReedemGrid = true;
        var deferred = $q.defer();
        var body = {};
        body.refTxn = transactModel.getFundDetails().trxnNo;
        body.folioId = fticCancelStpFundDetailsModel.getSelectFundDtls().folioid;
        //body.folioId =  '14512366';
        body.accountNo = transactModel.getFundDetails().sourceAccNo;
        body.effectiveDate = transactModel.getFundDetails().nextTiggerDate;
        body.userType = '10';
        body.txnType = 'STPC';
        body.batchCode = 'FTIDE';
        body.webRefNo = '';
        body.makerId = '';
        body.validation = 'Y';
        fticCancelStpFundDetailsModel.validateCSTP(body).then(function(data) {
            fticCancelStpFundDetailsModel.setRefNum(data.webRefNo);
            fticCancelStpFundDetailsModel.setCstpDetails(data);
            $state.go('invTransact.review.cancelStp');
        }, function(error) {
            toaster.error(error.data[0].errorDescription);
        });

    });

    $scope.$on('reviewBuy', function() {
        $state.go('invTransact.review.buy');
    });

    $scope.$on('reviewRenewSip', function() {
        console.log("in reviewRenewSip");
        $state.go('invTransact.review.renewsip');
    });

    $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
        if ((!!toState && !!fromState) && (toState.parent === fromState.parent)) {
            // Reset all data for diff type of transaction.
            transactModel.isNewInvestor = false;
            $scope.stateStatus = null;
            $scope.keyValueList = [];
            SetInitialValues();
            selectInvestorModel.setEditInvIconChanged(false);
            $scope.$broadcast(transactEventConstants.transact.Trans_Select_Option_Changed);
            var curState = $state.current.name;
            var isInvPref = (curState === 'invTransact.base.switch' || curState === 'invTransact.base.dtp' || curState === 'invTransact.base.stp' || curState === 'invTransact.base.buy');
            $scope.isInvestmentPreferAvailable = $scope.isShowInvestPrefer = $scope.isDisableInvestPreferGrid = isInvPref;

            $scope.isShowReedemGrid = ($state.current.url !== '/cancelStp');

        }

    });

    

    $scope.$on('paymntDtls', function() {
        $scope.$broadcast('Go_To_Payment_Dtls');
    });

    $scope.$on('kycAdntDtls', function() {
        $scope.$broadcast(transactEventConstants.transact.KYC_ADTNL_DETAILS);
    });

    /**
     * New Code Starts - Harsha
     * 
     */
    $scope.$on('FUND_SELECTION_UNCHANGED', function() {

        $scope.$broadcast('EDIT_SWP_FORM')
    });

    var onFolioSelection = function(newfolio) {
        if (!newfolio) {
            selectInvestorModel.setSelectedInvestorDtls(transactModel.getSelectedFolioDts());
        }
        $scope.$broadcast(transactEventConstants.transact.Selected_Investor);
        if ($scope.isInvestmentPreferAvailable) {
            $scope.isShowInvestorDetails = false;
            $scope.isShowInvestPreferGrid = true;
            $scope.isDisableInvestPreferGrid = false;
            $scope.isOpenInvGrid.open = false;
            $scope.isOpenInvestPreferGrid.open = true;
            $scope.$broadcast('getInvestorPreferenceData');
        } else {
            selectInvestorTile();
        }
    }
    $scope.$on(transactEventConstants.transact.INV_FOLIO_SELECTED_CON, function() {
        //console.log(transactModel.getSelectedFolioDts());
        onFolioSelection();
    });
    $scope.moduleUrl = $state.current.url;
    if ($scope.moduleUrl == '/modifysip') {
        transactModel.setTransactType(TransactConstant.modifySip.MODIFYSIP);
        $scope.config.txnFundDetails.title = 'Select SIP';
    } else if ($scope.moduleUrl == '/renewsip') {
        $scope.isPaymentDetailsIni = true;
        transactModel.setTransactType(TransactConstant.renewSip.RENEWSIP);
        $scope.config.txnFundDetails.title = 'Select a SIP';
        $scope.config.txnFormPayDetails.title = 'Payment Details';
        //$scope.isDisablePayDetails = false;
    }else if ($scope.moduleUrl === '/buy') {
        //added - new folio
        transactModel.setTransactType(TransactConstant.buy.BUY);
        $scope.config.txnFundDetails.title = 'Select Fund';
    } else {
        transactModel.setTransactType(TransactConstant.transact.TRANSACT);
        if ($state.current.url === '/stp' || $state.current.url === '/switch') {
            $scope.config.txnFundDetails.title = 'Select Source Fund';
        } else if ($state.current.url === '/dtp') {
            transactModel.setTransactType(TransactConstant.transact.DTP);
            $scope.config.txnFundDetails.title = 'Select Fund';
        } else if ($scope.moduleUrl === $scope.moduleUrl === "/sip") {
            transactModel.setTransactType(TransactConstant.sip.SIP);
        } else {
            $scope.config.txnFundDetails.title = 'Select Fund';
        }
    }
    $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
        if (transactModel.isStateChangedTransact) {
            $timeout(function() {
                $scope.isTransactChanged = false;
            });
            transactModel.isStateChangedTransact = false;
            transactModel.isTransactionStarted = false;
            transactModel.navigationfromPopup = false;
            $timeout(function() {
                $scope.isTransactChanged = true;
            });
        }
    });
    $scope.$on('sipdetailsview',function(){
        $scope.$broadcast('sipdetailsview123');
    });

    $scope.$on('paymntDtls123',function(){
        var keyValues =  sipDetailsModel.getSipDetails();
        $scope.keyValueList = [
          {
              key: "SIP Amount",
              value: keyValues[0].sipAmount
          },
          {
            key: "SIP Future Installment",
            value: keyValues[0].futureInstallment
          },
          {
              key: "SIP End Date",
              value: keyValues[0].endDate
          },
          {
              key: "Frequency",
              value: keyValues[0].frequency
          }
        ];
        $scope.isShowReedemGrid = false;
        $scope.isDisablePayDetails = false;
        $scope.isOpenPayDetails.open = true;
    });
}
InvTransactController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'selectFundModel', '$state', '$stateParams', 'selectFundInitialLoader', 'eventConstants', '$timeout', 'transactModel', 'transactEventConstants', 'TransactConstant', 'selectInvestorModel', 'newFundDetailsInitialLoader', 'ftiModifySipInitialLoader', 'paperlessModel', 'bankDtlsModel', 'redeemModel', 'swpModel', 'stpDetailsModel', 'transactNowModel', 'fticCancelStpFundDetailsModel', '$q', 'fticCancelStpInitialLoader', 'toaster', 'fundDetails', 'sipDetailsModel'];
module.exports = InvTransactController;
