/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accordion = function($state) {
	return {
            template: require('./accordion.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              accordionData: "=",
              lable: "=",
              count: "=",
              isToggleDisabled: "=",
              allOpen: '=',
              mgClick:'&?'
            },
            controller: function($scope, $element, $attrs){
              $scope.status = $scope.allOpen;
            },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

accordion.$inject = [];
module.exports = accordion;