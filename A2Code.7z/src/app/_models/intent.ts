import { Parameter } from '../_models/parameter';
import { ParamField } from '../_models/paramfield';
import { Agent } from '../_models/agent';
import { UserExpression } from '../_models/userexpression';
// import { AIResponse } from '../_models/responsedata';

export class Intent {

    intentId : string;
    name: string;
    action: string;
    agentId: string;
    description: string;
    agentName: string;

    expressionList: Array<UserExpression> = [];
    paramMap: any = {};
    paramTypeList : Array<string> = [];
    selectedList : Array<Parameter> = [];
    unSelectedList : Array<Parameter> = [];

    parameterList: Array<ParamField> = [];

    isSelected: boolean=false;
    status: string;

    // responseList : Array<AIResponse> = [];

}
