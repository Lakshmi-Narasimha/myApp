// getDividendSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var DividendSummaryModelSchema = new mongoose.Schema({
    dividendSummaryResp: {
        type: Array,
        "default": []
    }
});

var DividendSummaryModelLookUp = mongoose.model('DividendSummaryModelLookUp', DividendSummaryModelSchema);

var DividendSummaryModel = new DividendSummaryModelLookUp({
    dividendSummaryResp : {
        "dividends": {
            "fundWiseData": [
                  {
                    "folioNo": "2341621",
                    "accountNo": "0000000012",
                    "fund": "Frnklin India equity fund-growth",
                    "paymentOption": "Reinvestment",
                    "familySolutions": "yes",
                    "dividendAmount": "2300"
                  },
                  {
                    "folioNo": "3456432",
                    "accountNo": "0000000011",
                    "fund": "Frnklin India equity fund-growth",
                    "paymentOption": "Payout",
                    "familySolutions": "no",
                    "dividendAmount": "1356"
                  },
                  {
                    "folioNo": "4356453",
                    "accountNo": "0000000090",
                    "fund": "Frnklin India prima plus",
                    "paymentOption": "Payout",
                    "familySolutions": "no",
                    "dividendAmount": "1234"
                  }
	        ],
	       "grandTotal": "11090"
        }

    }
});

DividendSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating DividendSummaryModelLookUp table, please contact admin...');
    } else {
        DividendSummaryModelLookUp.remove({}, function(err) {
            console.log('DividendSummaryModelLookUp collection removed');
            DividendSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating DividendSummaryModelLookUp table, please contact admin...');
                }
                console.log('DividendSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = DividendSummaryModelLookUp;