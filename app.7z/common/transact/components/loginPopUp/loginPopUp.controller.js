/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function loginPopUpController($scope, $uibModalStack) { 

    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
}


loginPopUpController.$inject = ['$scope', '$uibModalStack'];

module.exports = loginPopUpController;