(function() {
    'use strict';

    angular
        .module('angularSeedApp', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ngResource', 'ui.router', 'ui.bootstrap']);

})();