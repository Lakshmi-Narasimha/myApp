/**
 * @ngdoc property
 * @name fticAdbRecommendations Directive
 * @requires dashboardConstants
 * @requires advisorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - Displays advisor dashboard recommendations section.
 *
 **/
'use strict';

var fticInvdbRecommendations = function (investorEventConstants,fticRecommAndNotifiModel, $state, loggerConstants, fticLoggerMessage) {
	return {
		restrict: 'E',
        scope : true ,
		template: require('./invDbRecommendations.html'),
        controller : function($scope){
            $scope.$on(investorEventConstants.Dashboard.RECOMM_AND_NOTIFI_DATA, function() {

                var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_RECOMMENDATIONS_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.RECOMM_AND_NOTIFI_DATA + ' event' /* Function Name */;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
                $scope.recommandNotifiData = fticRecommAndNotifiModel.getRecommAndNotifiReport();
                $scope.recommendationsData = $scope.recommandNotifiData.recommendations;
                if($scope.recommendationsData) {
                    $scope.recommendationsLength = $scope.recommendationsData.length;
                }
            });
        },
        link: function(scope){
            scope.recommendationsTile = 'recommendationsTile';
            scope.badgeEnable = true;
            scope.panelClose = false;
            scope.recommendations = {
                heading: 'Recommendations',
                badgeClass: 'icon-fti_advisorRecommendation',
                badgeCount: 0
            };

            scope.onButtonClick = function(){
                $state.transitionTo('recommendationsreport');
            };
        }
	};
};

fticInvdbRecommendations.$inject = ['investorEventConstants','fticRecommAndNotifiModel', '$state', 'loggerConstants', 'fticLoggerMessage'];
module.exports = fticInvdbRecommendations;