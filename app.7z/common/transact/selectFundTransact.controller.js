/**
 * @ngdoc property
 * @name SelectFundTransactCtrl
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function SelectFundTransactCtrl(transactModel, TransactConstant,$scope,$state) {
    console.log('SelectFundTransactCtrl');
    $scope.moduleUrl = $state.current.url;
    if($scope.moduleUrl == "/modifysip"){
    	transactModel.setTransactType(TransactConstant.modifySip.MODIFYSIP);
    	$scope.config.txnFundDetails.title = "Select SIP";
    }else {
    	transactModel.setTransactType(TransactConstant.transact.TRANSACT);
		if($state.current.url === "/stp" || $state.current.url === "/switch"){
			$scope.config.txnFundDetails.title = "Select Source Fund";
		}
		else {
			$scope.config.txnFundDetails.title = "Select Fund";
		}
    	
    }
    
}
SelectFundTransactCtrl.$inject = ['transactModel', 'TransactConstant','$scope','$state'];
module.exports = SelectFundTransactCtrl;