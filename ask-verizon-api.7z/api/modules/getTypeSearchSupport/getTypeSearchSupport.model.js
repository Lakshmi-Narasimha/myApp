var getTypeSearchSupportModelConfig = {
  response: {
    "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "server": "saswcvfszwd21.sdc.vzwcorp.com:srv01_wmobilefirst01",
        "buildNumber": "9064",
        "requestId": "9e198055-7b04-4ea4-b419-b9af57f03126",
        "mdn": "2566105456",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
    },
    "Page": {
        "pageType": "getTypeSearchSupport",
        "parentPageType": "myData"
    },
    "ModuleMap": {
        "TypeSearchSupport": {
            "ResponseInfo": {
                "locale": "EN",
                "type": "Success",
                "code": "00000",
                "message": "0",
                "userMessage": "0"
            },
            "TypeAhead": [
                "autopay",
                "pay",
                "manage autopay",
                "pay bill",
                "payment",
                "payment history",
                "view payment history",
                "payment methods",
                "old payments",
                "past payments"
            ]
        }
    }
}
}
};

module.exports = getTypeSearchSupportModelConfig;
