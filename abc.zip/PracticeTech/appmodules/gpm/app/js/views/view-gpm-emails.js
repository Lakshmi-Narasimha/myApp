define(['jquery', 'underscore', 'backbone', 'spinner', 'appcommon/globalcontext', 'appcommon/analytics', 'errorLog','appcommon/data','appmodules/gpm/app/js/lib/validate.js', 'appmodules/gpm/app/js/utils', 'appmodules/contactprofile/app/models/cpviewmodel','services/dataservice','appcommon/commonutility',
		'text!appmodules/gpm/app/templates/gpmemails.html', 'text!appmodules/gpm/app/templates/gpmemailview.html', 'text!appmodules/gpm/app/templates/gpmemailadd.html', 'text!appmodules/gpm/app/templates/gpmemailedit.html','config'], function ($, _, Backbone, Spinner, GlobalContext, Analytics, ErrorLog, GPMData, Validator, Utils, CPViewModel, Dataservices, CommonUtils, EmailsTemplate, EmailViewTpl, EmailAddTPl, EmailEditTPl,Config) {
	var ColaEmailModel = Backbone.Model.extend({
		defaults : {
			clCtx: "COLA.CL",
			clId: null,
			emlAddr: null,
			emlFuncStatCd: null,
			emlUseCd: null,
			emlVldStatCd: "Valid",
			endTs: null,
			Preferred: false,
			preferredEmail: false,
			sttTs: null,
	}
});
 var EbixEmailModel = Backbone.Model.extend({
		defaults : {
			Address:null,
			ElectronicDownload: "0",
			Id: null,
			Preferred: false,
			WebAddressType: "1",
			WebAddressTypeDesc: "Email",
			preferredEmail: false,
			type: "WebAddresses",
	}
});
 var self = null, errorMessages = {
     "noPrimaryEmail": "You must have one primary email address.",
     "duplicatePrimaryEmail": "Only one primary email type is allowed. Choose another type before continuing.",
     "duplicateSecodaryEmail": "Only one secondary email type is allowed. Choose another type before continuing."
 };
 var _EmailsView = Backbone.View.extend({
         el: "#gpm-form-update-field-container",
         id: 'gpm-form-update-field-container',
		            events: {
                        "click #add-another-email": "addAnotherEmail",
		        },
		            initialize: function () {
		            this.data = {
		        };
                this.existingEmailTypes =[];
                this.preferredEmails =[];
                this.isPartialSuccess = false;
                this.totalServicecallsInProgress = 0;
                this.totalSucceededCalls = 0;
                this.failedResponses =[];
                this.updateMode = null;
                this.colEmailUpdatePayloads =[];
                this.isEbixServiceSuccess = null;
                this.isClientInEbix = true;
                this.editableEmailTypes = _.filter(GPMData.emailTypes, function (row, key) { return (row.name != "IM" && row.name != "Url")
		        });
		            self = this;
		            $(document).off("click", "#actual-email-container .edit-gpm-email").on("click", "#actual-email-container .edit-gpm-email", self.showEditEmailPanel);
		            $(document).off("click", "#actual-email-container .cancel-gpm-email").on("click", "#actual-email-container .cancel-gpm-email", self.removeEditEmailPanel);
		            $(document).off("change", "#actual-email-container .emailTypeDropDwn").on("change", "#actual-email-container .emailTypeDropDwn", self.emailTypeDropDwnChangeHandler);
		            $(document).off("change", "#actual-email-container .preferredChkBox").on("change", "#actual-email-container .preferredChkBox", self.preferredEmailHandler);
		            $(document).off("click", "#actual-email-container .delete-gpm-email").on("click", "#actual-email-container .delete-gpm-email", self.deleteEmailHandler);
		            $(document).off("change", "#actual-email-container [data-mode-type='edit'] select.emailTypeDropDwn").on("change", "#actual-email-container [data-mode-type='edit'] select.emailTypeDropDwn", self.handleEditEmailTypeChange);
		        },
		            template: _.template(EmailsTemplate),
		            gemerateUid: function () {
                        var text = "";
                        var possible = "abcdefghijklmnopqrstuvwxyz0123456789";

		            for (var i=0; i < 8; i++)
		                text += possible.charAt(Math.floor(Math.random() * possible.length));

                        return text;
		        },
		            toggleAddAnotherBtn: function (flag) {
                        if(flag) {
                            $("#add-another-email").hide();
		            } else {
		        		$("#add-another-email").show();
 }
		        },
		            render: function (updateMode) {
		            var self = this;
		            try {
		            	self.updateMode = updateMode;
		                var _compiledTemplate = this.template({
		                data: this.model
		            });
		                    $("#" +this.id).html(_compiledTemplate);
		                if(!this.model.get('currentItemSet')) {
		                    var CPData = CPViewModel.getInstance().getData();
		                    this.data = this.getGPMEmailData(CPData);
		                    this.model.setCurrentValue(self.updateMode, {
		                    data: this.data
		                });
		            }

		                var _dataSet = this.model.get('items');
		                var _htmlContent = ""
		                var _viewTmplt =  _.template(EmailViewTpl);
		                $.each(_dataSet, function (key, row) {
		                	_htmlContent+= _viewTmplt({data: row, index: key
		                });
		            })
		                $("#actual-email-container").html(_htmlContent).promise().done(function () {
		                	if(!self.isClientInEbix && self.existingEmailTypes.length>1) {
		                		self.toggleAddAnotherBtn(true);
		                }
		            });
		        }
                catch (error) {
                    ErrorLog.ErrorUtils.myError(error);
 }
		        },
		            scrubEmails: function () {
                        try {
                            var _$gpmChangeEmailBoxes = $('.gpm-email-change-box');
                            var errorList = { }, serviceCounter = 0, invalidEmailerrMsg = "Invalid email address.";
                            if(_$gpmChangeEmailBoxes && _$gpmChangeEmailBoxes.length>0) {
                                serviceCounter = _$gpmChangeEmailBoxes.length;
			        	}
			        	if(_$gpmChangeEmailBoxes && _$gpmChangeEmailBoxes.length == 0) {
	       				 	self.processUpdateEmails();
			        	}
			        	$(_$gpmChangeEmailBoxes).each(function (key, row) {
			        		var _uid = $(this).data("uid"), emailBoxId = "inputEmail"+_uid;
			        		var _itemEmail = $("#"+emailBoxId).val();
			        		Dataservices.validateEmail({emlAddr: _itemEmail})
				        	.done(function (response) {
				        		response = response.d;
				        		serviceCounter--;
				        		if(response && response.vldEmlAddrRespStatCd != "0000") {
				        			errorList[emailBoxId]=[];
				        			errorList[emailBoxId].errMsg = invalidEmailerrMsg;
				        	}
                            showScrubEmailsError(serviceCounter, errorList);
			        		})
				        	.fail(function (error) {
				        		serviceCounter--;
				        		self.failedResponses.push(error);
			        			showScrubEmailsError(serviceCounter, errorList);
		            })
		            });

		                function showScrubEmailsError(serviceCounter) {
			        		if(serviceCounter == 0) {
			        			var validaorObj = new Validator.commonValidator('gpm-update-form');
			        			validaorObj.currentForm = $('#gpm-update-form');
					        	validaorObj.errorList = errorList;
					        	validaorObj.showErrors();
					        	if(self.failedResponses && self.failedResponses.length>0) {
					        		Utils.showServiceError(self.failedResponses[0]);
					        		Spinner.hide();
					        	}
					        	else if(!validaorObj.isFormValid()) {
			        				self.resetEmailDataInModel();
			        				Spinner.hide();
						        	return false;
					        	} else {
			        				 self.processUpdateEmails();
		                }

		                }

		        }
		        	}
		        	catch (error) {
		            	ErrorLog.ErrorUtils.myError(error);
 }
		        },
		            resetEmailDataInModel: function () {
                        var _updatedEmails = this.model.getChangedItems();
                        $.each(_updatedEmails, function (key, row) {
                            row.get("customValues")["updateStatus"]= "";
                            var _customValues = row.get("customValues");
                            if (_customValues.addedBySwap || _customValues.deletedBySwap) {
		        	        customValues.viewDispaly = false;
		        	        customValues.changed = false;
		            }
 });
		        },
		            validateAndNavigateFromStep1: function () {
		                hideDuplicateEmailTypeError();
		                var _$emailTypes = $('.emailTypeDropDwn,.gpm-email-type-name:visible');
		                if (_$emailTypes.length === 0 && this.model.get("items").length === 0) {
                            Utils.showNoChangesMessageToUser();
                            return;
		                }
                        
                        var _colaEmailTypeCounts = getColaEmailTypeCount();
                        if (_colaEmailTypeCounts.primary == 0 || _colaEmailTypeCounts.primary > 1 || _colaEmailTypeCounts.secondary > 1) {
                            //this.model.validate('gpm-update-form', true);
                            if (_colaEmailTypeCounts.primary == 0) {
                                showNoPrimaryEmailError();
                                } else {
                                    if (_colaEmailTypeCounts.primary > 1) {
                                        showDuplicateEmailTypeError("primary");
                                    } else {
                                        showDuplicateEmailTypeError("secondary");
                                    }
                                }

                                return;
                            } else {
                                hideDuplicateEmailTypeError();
                            }
		            if (this.model.validate('gpm-update-form', true)) {
		            	this.failedResponses =[];
		            	this.model.setChangedValue();
		            	this.model.set('submitStatus', "");
		            	this.isPartialSuccess = false;
		            	if(this.model.getChangedItems().length>0) {
		            		Spinner.show();
		            		this.scrubEmails();
		            	} else {
		            		this.resetEmailDataInModel();
		            		Utils.showNoChangesMessageToUser();
		            }
		            }
		            }, navigateToStep2: function () {
		        	_gpmModel = self.model;
		        	_gpmModel.set('submittedTime', moment(new Date()).format('MM/DD/YYYY hh:mm a'));
		        	var _completedSteps = _gpmModel.get('completedSteps');
		        	_gpmModel.set('updateCompleted', true);
		        	$('.gpm-step.step1').addClass("finished").removeClass("active");
		        	$('.gpm-step.step2').addClass("active");
		        	if(_completedSteps.indexOf(1) == -1) {
		        		_gpmModel.get('completedSteps').push(1);
					}
		        	Backbone.history.navigate('gpm/confirm/'+_gpmModel.get('updateMode'), true);
		        },
		            getGPMEmailData: function (CPData) {
		                try {
		                    var _colaData = CPData.cola, _ebixData = CPData.ebix;
		                    var _colaEmails = (_colaData.clientEmails) ? _colaData.clientEmails : [], _ebixEmails = (_ebixData && _ebixData.WebAddresses ? _ebixData.WebAddresses : []);
		                    _ebixValidEmails = [], _colaValidEmails = [];
		                    if (!_ebixData) {
		                        self.isClientInEbix = false;
		                    }
		                    if (_colaEmails.length > 0) {
		                        _colaEmails.sort(function (a, b) {
		                            if (a.get('emlUseCd').match(/primary/i)) { return -1 } else if (b.get('emlUseCd').match(/primary/i)) {
		                                return 1
		                            } return 0;
		                        });
		                        $(_colaEmails).each(function (j, colaEmail) {
		                            var uid = self.gemerateUid();
		                            if (colaEmail.get('preferredEmail')) {
		                                self.preferredEmails.push({
		                                    UID: uid
		                                })
		                            }
		                            //To remove additional space in emails
		                            colaEmail.set('emlAddr', colaEmail.get('emlAddr').trim());
		                            self.existingEmailTypes.push(colaEmail.get('emlUseCd'));
		                            _colaValidEmails.push({
		                                customValues: { viewDispaly: true, srcSystem: "COLA", UID: uid }, value: new ColaEmailModel(colaEmail.toJSON())
		                            });
		                        });
		                    }

		                    if (_ebixEmails && _ebixEmails.length > 0) {
		                        $(_ebixEmails).each(function (index, ebixEmail) {
		                            var _isColaEmail = false, _colaIndex = null, _colaRefId = null, _donotUpdate = false;
		                            var uid = self.gemerateUid();
		                            //Channging default Type lable from Email to Other.
		                            var _ebixEquivalentType = _.find(GPMData.emailTypes, function (row, key) {
		                                return (row.serviceValue.indexOf(ebixEmail.get("WebAddressTypeDesc")) != "-1")
		                            })

		                            if (_ebixEquivalentType != undefined) {
		                                ebixEmail.set("WebAddressTypeDesc", _ebixEquivalentType.name);
		                                if (ebixEmail.get("ElectronicDownload") != "1") {
		                                    if (ebixEmail.get('preferredEmail')) {
		                                        self.preferredEmails.push({
		                                            UID: uid
		                                        });
		                                    }

		                                    //To remove additional space in emails
		                                    ebixEmail.set("Address", ebixEmail.get("Address").trim())
		                                    _ebixValidEmails.push({
		                                        customValues: { viewDispaly: true, srcSystem: "EBIX", UID: uid }, value: new EbixEmailModel(ebixEmail.toJSON())
		                                    });
		                                }
		                            }
		                        });
		                    }
		                    return {
		                        colaEmails: _colaValidEmails,
		                        ebixEmails: _ebixValidEmails
		                    }
		                }
		                catch (error) {
		                    ErrorLog.ErrorUtils.myError(error);
		                }

		            },
		            updateExistingEmailTypeList: function (parent) {
                        var selectBox = parent.find(".emailTypeDropDwn");
                        if(!selectBox.attr("disabled")) {
                            var allOptions = selectBox.find("option");
                            if(allOptions && allOptions.length>0) {
                                $.each(allOptions, function (key, row) {
                                    var index = self.existingEmailTypes.indexOf($(row).text());
                                    if (index != "-1") {
                                        self.existingEmailTypes.splice(index, 1);
			        			} else if($(row).val() != "1") {
			        				self.existingEmailTypes.push($(row).text())
                                }
                            })
                        }

			        	if(self.existingEmailTypes.length<2) {
	                		self.toggleAddAnotherBtn(false);
	                	} else if(!self.isClientInEbix && self.existingEmailTypes.length>=2) {
	                		self.toggleAddAnotherBtn(true);
		            }
		            }

		        },
		            loadEmailTypesList: function (_selectbox, currentType, availableEmailTypes) {

		        	var finalEmailTypes = (availableEmailTypes ? availableEmailTypes : GPMData.emailTypes);
		        	if(!self.isClientInEbix) {
		        		finalEmailTypes = _.filter(finalEmailTypes, function (row, key) {return (row.code != "1")
		            })
		            }

	                var _options = {
	                    selectBox: _selectbox,
	                        optionsList: finalEmailTypes,
	                        selectedVal : (currentType ? currentType: ""),
	                    noEmptyOption: true,
	                    isOptional: false,
		            }
	                Utils.loadSelectbox(_options);
		        },
		            showEditEmailPanel: function (e) {
                        Analytics.analytics.recordAction('gpmEmailEdit:clicked');
                        var dataUid = $(e.target).data("uid");
                        var emailViewBox = $("#gpm-email-view-"+dataUid);
		        	emailViewBox.hide();
		        	var _editTmplt =  _.template(EmailEditTPl);
		        	var row = self.model.get('items').find(function (row) { return row.get("customValues")['UID']== dataUid
		        	});
		        	$(_editTmplt({data: row})).insertAfter(emailViewBox).promise().done(function () {
		        		var selecteBox = "#gpm-email-edit-" +dataUid+" .emailTypeDropDwn";
		        		var currentType = (row.get("changedItemValue").get('emlUseCd') ? row.get("changedItemValue").get('emlUseCd'): row.get("changedItemValue").get('WebAddressType'));
		        		var _ebixEmailTypes = _.filter(GPMData.emailTypes, function (row, key) { return (row.code == "1" && row.name != "Url" && row.name != "IM");
		        		})
		        		var _emailOptions = self.editableEmailTypes;
		        		self.loadEmailTypesList(selecteBox, currentType, _emailOptions);

 });
		        },
		            addAnotherEmail: function () {
		            hideDuplicateEmailTypeError();
		            Analytics.analytics.recordAction('gpmEmailAddAnother:clicked');
		        	var _editTmplt =  _.template(EmailAddTPl);
		        	var dataUid = self.gemerateUid();
		        	$("#actual-email-container").append(_editTmplt({uid: dataUid})).promise().done(function () {
		        	    var _avilableEmailTypes = self.editableEmailTypes;//_.filter(self.editableEmailTypes, function (row, key) { return (row.code != "Primary") });
		        	    //to check secondary email options is already present in UI
		        	    var selecteBox = "#gpm-email-edit-" + dataUid + " .emailTypeDropDwn";
		        	    //1409 Fix: Cancel,Close button is not visible when changed from Primary to Secondary.
                        // Below validation is the root cause and this is not required as we are validating while navigating to next step. 
		        	    //if (getColaEmailTypeCount().primary == 0) {
		        	    //    $("#gpm-email-edit-" + dataUid + " .cancel-gpm-email").remove();
		        	    //}
		        		self.loadEmailTypesList(selecteBox, null, _avilableEmailTypes);
 });
		        },
		            removeEditEmailPanel: function (e) {
		            hideDuplicateEmailTypeError();
		            Analytics.analytics.recordAction('gpmEmailUpdateCancel:clicked');
		        	var dataUid = $(e.target).data("uid");
		        	var emailViewBox = $("#gpm-email-view-"+dataUid);
		        	var emailEditBox = $("#gpm-email-edit-"+dataUid);
		        	if(!$(e.target).data("server-id")) {
		        		self.updateExistingEmailTypeList(emailEditBox);
		        	}
		        	var _updatedEmails = self.model.get('items');
		        	var itemIndex = null;
		        	var getThisItem = _.find(_updatedEmails, function (row, index) {if (row.get('customValues')['UID']== dataUid) { itemIndex =index; return true;
		            }
		            });
		        	if(getThisItem && getThisItem.get('customValues')['isNew']) {
		        		if(itemIndex != null && itemIndex != undefined) {
		        			_updatedEmails.splice(itemIndex, 1);
		            }
		        	} else if (getThisItem && !getThisItem.get('customValues')['isNew']) {
		        	    emailViewBox.data('type-changed', "false");
		        		var _currItemVal = getThisItem.get('currentItemValue').toJSON();
		        		 if(getThisItem.get('customValues').srcSystem == "EBIX") {
		        			 _currItemVal =  new EbixEmailModel(_currItemVal);
		        		} else {
                            _currItemVal =  new ColaEmailModel(_currItemVal);
		        		 }
		        		 getThisItem.set('changedItemValue', _currItemVal);
		        		 getThisItem.set('changedItemValueId', _currItemVal);
		        		 getThisItem.get('customValues').changed = false;
		            }

		        	emailViewBox.show();
		        	emailEditBox.remove();

		        },
		            emailTypeDropDwnChangeHandler: function (e) {
                        var selectBox = $(e.target);
                        if(selectBox.val() != "1" && self.existingEmailTypes.indexOf(selectBox.val()) == "-1") {
                            self.existingEmailTypes.push(selectBox.val());
 }
		        },
		            preferredEmailHandler: function (e) {
                        var dataUid = $(e.target).data("uid");
                        var alreadyIn = false;
                        var _elemnt = $(e.target);
                        self.preferredEmails.forEach(function (row) {if(row.UID == dataUid) alreadyIn = true;
                        })
                            if(_elemnt.is(":checked") && !alreadyIn) {
                                self.preferredEmails.push({
                            UID: dataUid
                        });
		        		} else if(!_elemnt.is(":checked") && alreadyIn) {
		        			self.preferredEmails = _.filter(self.preferredEmails, function (row, key) {return (row.UID != dataUid)
		        		});
		        		}
		        	if(_elemnt.is(":checked")) {
		        		$("#gpm-preferred-label-"+dataUid).removeClass("nav-preferred-gray").addClass("nav-preferred")
		        		} else {
                            $("#gpm-preferred-label-"+dataUid).removeClass("nav-preferred").addClass("nav-preferred-gray")
 }
		        },
		            deleteEmailHandler: function (e) {
		            hideDuplicateEmailTypeError();
		        	var dataUid = $(e.target).data("uid");
		        	var viewBox = $("#gpm-email-view-"+dataUid);
		        	var _dataSet = self.model.get('items');
		        	var modelEntry = _.find(_dataSet, function (row, key) {return (row.get("customValues")['UID']== dataUid) })
		        	modelEntry.get("customValues")['isDeleted']= true;
		        	modelEntry.get("customValues")['changed']= true;
		                //Rempove from preferred Email list
                        self.preferredEmails = _.filter(self.preferredEmails, function (row, key) {return (row.UID != dataUid)
		            });

		                //Putting the removing Email type back
                        var index = self.existingEmailTypes.indexOf($(e.target).data("server-id"));
                        if (index != "-1") {
                            self.existingEmailTypes.splice(index, 1);
        			}
		        	viewBox.fadeOut(function () {
		        		$(this).remove();
		        		if(self.existingEmailTypes.length<2) {
	                		self.toggleAddAnotherBtn(false);
		            }
		        	})
		        	Analytics.analytics.recordAction('gpmEmailUpdateDelete:clicked');

		        },
		            handleEditEmailTypeChange: function (event) {
                        var _$target = $(event.target), _editOriginalType="";
                        var _dataUid = _$target.data("uid"), _$editBox = $("#gpm-email-edit-" + _dataUid), _dataSet = self.model.get('items'), _changedType = _$target.find("option:selected").attr("name");
                        var _editingModelItem = _.find(_dataSet, function (row, key) { return (row.get("customValues")['UID']== _dataUid)
		            });
		            if (_editingModelItem.get("customValues").srcSystem == "EBIX") {
		                _editOriginalType = "Other (Contact Manager)";
		            } else {
		                _editOriginalType = _editingModelItem.get("currentItemValue").get("emlUseCd");
		            }
		            if (_editOriginalType != _changedType) {
		                _$editBox.attr('type-changed', "true");
		            } else {
		                _$editBox.attr('type-changed', "false");
 }

		        },
		            validateMultiplePreferred: function () {
                        var emailSection = $("#gpm-section-email");
                        var multiPreferredEmailMsgBox = $("#preferred-err");
		        	var status = true;
		        	var $editModeContainer = $('.gpm-email-change-box');
		        	if(self.preferredEmails.length>1) {
		        		emailSection.addClass("error");
		        		multiPreferredEmailMsgBox.removeClass("hidden");
		        		if ($editModeContainer.is(':Visible') && $editModeContainer.find('.nav-preferred')) {
	                        $editModeContainer.css('background-color', '#F2D9Df');
		        		}
		        		status = false;
		        	} else {
		        		emailSection.removeClass("error");
		        		multiPreferredEmailMsgBox.addClass("hidden");
		        		status = true;
		        	}
		        	return status;
		        },
		            processUpdateEmails: function () {
                        this.colEmailUpdatePayloads =[];
                        var _updatedEmails = this.model.getChangedItems();
                        this.getColaDeletedEmailsPayload(_updatedEmails);
                        this.getColaUpdatedEmailsPayload(_updatedEmails);
                        this.sendColaUpdatedEmails();
                        var _updatedEbixEmailsPayload = this.getEbixEmailsPayload(_updatedEmails);
                        if(_updatedEbixEmailsPayload) {
                            this.sendEbixUpdatedEmails(_updatedEbixEmailsPayload);
 }
		        },
		            getColaUpdatedEmailsPayload: function (updatedEmails) {
                        var _updatedColaEmails = _.filter(updatedEmails, function(row) {return (row.get('customValues')['srcSystem']== "COLA" && !row.get('customValues')['isDeleted'])
                        });
                        if(_updatedColaEmails && _updatedColaEmails.length>0) {
                            $.each(_updatedColaEmails, function (key, row) {
                                self.colEmailUpdatePayloads.push({ actnCd: "update", emlUseCd: row.get("changedItemValueId").get("emlUseCd"), emlAddr: row.get("changedItemValueId").get("emlAddr"), uId: row.get('customValues')['UID']
                            })
                        });
 }
		        },
		            getColaDeletedEmailsPayload: function (updatedEmails) {
                        var _deletedColaEmails = _.filter(updatedEmails, function(row) {return (row.get('customValues')['srcSystem']== "COLA" && row.get('customValues')['isDeleted'])
                        });
                        if(_deletedColaEmails && _deletedColaEmails.length>0) {
                            $.each(_deletedColaEmails, function (key, row) {
                                self.colEmailUpdatePayloads.push({ actnCd: "remove", emlUseCd: row.get("changedItemValueId").get("emlUseCd"), emlAddr: row.get("changedItemValueId").get("emlAddr"), uId: row.get('customValues')['UID']
                            })
                        });
 }
		        },
		            getEbixEmailsPayload: function (updatedEmails) {
                        var _updatedEbixEmails = _.filter(updatedEmails, function(row) {return (row.get('customValues')['srcSystem']== "EBIX" && !row.get('customValues')['isDeleted'])
                        });
                        var _deletedEbixEmails = _.filter(updatedEmails, function(row) {return (row.get('customValues')['srcSystem']== "EBIX" && row.get('customValues')['isDeleted'])
		            });
	               if(_updatedEbixEmails.length == 0 && _deletedEbixEmails.length == 0) {
	            	   return _ebixReqPayload;
	               }
		        	var addemails = "", editemails = "", deletedEmails = [], _ebixReqPayload = null;
	                if(_updatedEbixEmails && _updatedEbixEmails.length>0) {
	                	$.each(_updatedEbixEmails, function (key, row) {
	                	    //Update existing email
	                		if(row.get("changedItemValueId").get("Id")) {
	                			var tmptEditemail = "EId="+(row.get("changedItemValueId").get("Id") || '#$#');
	                		    //tmptEditemail+= "|EType="+($(row).find('.emailTypeDropDwn').val() || '#$#');
	                				tmptEditemail+= "|EType=1";
	                				tmptEditemail += "|Email="+(row.get("changedItemValueId").get("Address") || '#$#');
	                				tmptEditemail+="~";
	                				editemails += tmptEditemail;
	                		}
	                		    //Add new email
	                		else {
	                			var tmptAddemail = "EId="
	                				tmptAddemail+= "|EType=1";
		                			tmptAddemail += "|Email="+(row.get("changedItemValueId").get("Address") || '#$#');
		                			tmptAddemail+="~";
		                			addemails += tmptAddemail;
	                	}

	                });
		            }
	                if(_deletedEbixEmails && _deletedEbixEmails.length>0) {
	                	$.each(_deletedEbixEmails, function (key, row) {
	                		if(row.get('customValues')['isDeleted']) {
	                			deletedEmails.push(row.get("changedItemValueId").get("Id"));
	                	}
	                })
		            }
		                //Removing default characters
	                addemails = addemails.split('#$#').join('');
	                editemails = editemails.split('#$#').join('');
	                deletedEmails = deletedEmails.join("~");

		        	var _ebixData = (CPViewModel.getInstance().getData() &&CPViewModel.getInstance().getData().ebix) ?CPViewModel.getInstance().getData().ebix: { };
		        	var _personContact = _ebixData.PersonContact? _ebixData.PersonContact: {get: function() {
return ""; }};
					_ebixReqPayload = {
						"id": _ebixData.id,
						"ctx": _ebixData.ctx,
						"type": _ebixData.type,
						"contactType": _ebixData.contactType,//need to change once prospect edit is in place
						"remarks": _ebixData.remarks,
						"PersonContact": {
							"clGreeting": _personContact.get('clGreeting'),
							"clMidNm": _personContact.get('clMidNm'),
							"clSfxTxt": _personContact.get('clSfxTxt') ?_personContact.get('clSfxTxt'): "",
							"clOccupation": _personContact.get('clOccupation'),
							"clJobTitle": _personContact.get('clJobTitle')
						},
						"TobeDeletedPhone": "",
						"EditedPhone": "",
						"TobeDeletedWebAddress": deletedEmails,
						"EditedWebAddress": addemails+editemails,
						"TobeDeletedAddress": "",
						"EditedAddress": "",
						"BusinessContact": { },
						"contactSubType": _ebixData.contactSubType
						};
					return _ebixReqPayload;
		        },
		            sendColaUpdatedEmails: function () {
                        if(self.colEmailUpdatePayloads && self.colEmailUpdatePayloads.length>0) {
                            self.totalServicecallsInProgress += self.colEmailUpdatePayloads.length;
                            var count = 0;
                            sendEmailToServer(self.colEmailUpdatePayloads[count]);
		                function sendEmailToServer(payload) {
		        			Dataservices.updateCOLAEmails(self.model.get('clientId'), payload)
		        			.done(function (response, statusMessage, xhr) {
		        				count++;
		        				if(count<self.colEmailUpdatePayloads.length) {
			        				sendEmailToServer(self.colEmailUpdatePayloads[count]);
		        			}

		        				var uid = payload.uId;
		        				var _changedEmails = self.model.getChangedItems();
		        				var row = _.find(_changedEmails, function(row) {return (row.get('customValues')['UID']== uid)
		        			});
                            if(!response) {
                                self.totalSucceededCalls++;
                                row.get("customValues")["updateStatus"]= "success";
                                self.gpmEmailServiceSuccess(response);
		        			} else {
                                row.get("customValues")["updateStatus"]= "failed";
                                self.failedResponses.push(xhr);
                                self.gpmEmailServiceFail(error);
		        			}

		                })
		        			.fail(function (error) {
		        				count++;
		        				if(count<self.colEmailUpdatePayloads.length) {
			        				sendEmailToServer(self.colEmailUpdatePayloads[count]);
		        			}
                            var uid = payload.uId;
                            var _changedEmails = self.model.getChangedItems();
                            var row = _.find(_changedEmails, function(row) {return (row.get('customValues')['UID']== uid)
		        			});
                            row.get("customValues")["updateStatus"]= "failed";
		        			    try {
		        			        error.responseText = error.responseText ? error.responseText: "";
		        			        var errorResponse = JSON.parse(error.responseText);
		        			        if (errorResponse.error && errorResponse.error.innererror && errorResponse.error.innererror == "1017") {
		        			            $("#gpm-email-edit-"+uid).attr("data-error-code", "innererror"+errorResponse.error.innererror);
		        			    }
		        			    }catch(e) {
		        			        console.log(error, "error");
		        			}

		        				self.failedResponses.push(error);
		        				self.gpmEmailServiceFail(error);

		                });
		            }

		            }

		        },
		            sendEbixUpdatedEmails: function (Payloads) {
                        try {
                            self.totalServicecallsInProgress += 1;
                            Dataservices.editContact(CommonUtils.readCookie('FMID'), Payloads)
                            .then(function (response, sttausMessage, xhr) {
		            		var _changedEmails = self.model.getChangedItems();
	        				var _collection = _.filter(_changedEmails, function(row) {return (row.get('customValues')['srcSystem']== "EBIX")
                            });
		            	    if(typeof (response) != "object" && response.indexOf("Success") > -1) {
		            	    	self.totalSucceededCalls++;
		        				if(_collection && _collection.length>0) {
		        					$.each(_collection, function (key, row) {
		        						row.get("customValues")["updateStatus"]= "success";
		            	    	})
		            	    }
                            self.isEbixServiceSuccess = true;
		            	    	self.gpmEmailServiceSuccess(response);
		            	    } else {
		            	    	if(_collection && _collection.length>0) {
		        					$.each(_collection, function (key, row) {
		        						row.get("customValues")["updateStatus"]= "failed";
		            	    	})
		            	    }
		            	    	self.isEbixServiceSuccess = false;
		            	    	self.failedResponses.push(xhr);
		            	    	self.gpmEmailServiceFail(response);
                            }

                            })
                            .fail(function (error) {
		            		var _changedEmails = self.model.getChangedItems();
	        				var _collection = _.filter(_changedEmails, function(row) {return (row.get('customValues')['srcSystem']== "EBIX")
                            });
		            		if(_collection && _collection.length>0) {
	        					$.each(_collection, function (key, row) {
	        						row.get("customValues")["updateStatus"]= "failed";
		            		})
                            }
		            		self.isEbixServiceSuccess = false;
		            		self.failedResponses.push(error);
		            		self.gpmEmailServiceFail(error)
		            });
		        	}
		        	catch (error) {
		            	ErrorLog.ErrorUtils.myError(error);
 }
		        },
		            gpmEmailServiceSuccess: function (response) {
                        self.totalServicecallsInProgress--;
		                //Handling Email 1017 error case
                        if(!self.isEbixServiceSuccess) {
                            $(".gpm-email-change-box").removeAttr("data-error-code");
		            }

		        	if(self.totalServicecallsInProgress == 0 && self.totalSucceededCalls != 0) {
		        		if(self.isPartialSuccess) {
		        			self.model.set('submitStatus', "partial");
		        	}

		        		self.navigateToStep2();
		        	} else if(self.totalServicecallsInProgress == 0 && self.totalSucceededCalls == 0) {
		        		Spinner.hide();
		        		Utils.showServiceError(self.failedResponses[0]);
		        		self.resetEmailDataInModel();
 }
		        },
		            gpmEmailServiceFail: function (err) {
                        self.totalServicecallsInProgress--;
                        self.isPartialSuccess = true;
                        if(self.totalServicecallsInProgress == 0 && self.totalSucceededCalls != 0) {
                            if(self.isPartialSuccess) {
                                self.model.set('submitStatus', "partial");
		        		}
		        		self.navigateToStep2();
		        	} else if (self.totalServicecallsInProgress == 0 && self.totalSucceededCalls == 0) {
		        	    //delete the emails added to model through swap 
		        		Spinner.hide();
		        		Utils.showServiceError(self.failedResponses[0]);
		        		self.resetEmailDataInModel();
 }
 }


     });
	function showNoPrimaryEmailError() {
        var _$emailFieldsContainer = $('#gpm-section-email');
         _$emailFieldsContainer.addClass("error");
         _$emailFieldsContainer.find('#email-type-gen-err').text(errorMessages.noPrimaryEmail).removeClass("hidden");
     }
    function showDuplicateEmailTypeError(emailType) {
        var _$emailFieldsContainer = $('#gpm-section-email'), _errorMessage = emailType == "primary"? errorMessages.duplicatePrimaryEmail:errorMessages.duplicateSecodaryEmail;
        var _$dupEmailErrors = _$emailFieldsContainer.find('.dup-' + emailType + '-email').removeClass("hidden"),_$emailDropDowns = _$emailFieldsContainer.find('.emailTypeDropDwn');
        _$emailFieldsContainer.find('.email-view-holder[id="gpm-email-view-' + _$dupEmailErrors.data('uid') + '"]').addClass("error");
        /*show error for email types in edit mode*/
        var _$this,_selectedval;
            _$emailDropDowns.each(function() {
                _$this = $(this);
                _selectedval = _$this.val().toLowerCase();
                if(_selectedval == emailType) {
                    $('#email-type-err-' + _$this.data("uid")).removeClass("hidden").text(_errorMessage);
                    $('[data-email-type-err-cont="' +_$this.data("uid") + '"]').addClass("error");
                }
            });
    }
    function hideDuplicateEmailTypeError() {
        var _$emailFieldsContainer = $('#gpm-section-email');
        _$emailFieldsContainer.removeClass("error");
        _$emailFieldsContainer.find('#email-type-gen-err').addClass("hidden");
        _$emailFieldsContainer.find('[data-email-type-err-cont]').removeClass("error");
        _$emailFieldsContainer.find('.dup-email-error').addClass("hidden");
	}
	function getColaEmailTypeCount() {
	    var _secondaryEmailCount = 0, _primaryEmailCount = 0;
	    var _$emailTypes = $('.emailTypeDropDwn,.gpm-email-type-name:visible');
	    _$emailTypes.each(function () {
	        var _emailType = $(this).hasClass("emailTypeDropDwn") ? $(this).find("option:selected").attr("name") : $(this).text();
	        if (_emailType == "Primary") {
	            _primaryEmailCount++;
	        } else if (_emailType == "Secondary") {
	            _secondaryEmailCount++;
	        }
	    });
	    return { "primary": _primaryEmailCount, "secondary": _secondaryEmailCount };
	}
    return _EmailsView;
})