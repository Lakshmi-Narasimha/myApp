/**
 * @ngdoc property
 * @name Buy Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter

function buyController($scope,$state, ifscModel, transactModel, authenticationService) {
    console.info("buy Controller!!");
    if ((authenticationService.isInvestorLoggedIn()) && $state.current.name === 'invTransact.base.buy') {
    	$scope.header.title = 'Buy A Lumpsum';	
    } else{
   		$scope.header.title = 'Buy';
   	}
    $scope.config.txnFormDetails.title = 'Payment Details';
    $scope.reviewDetailsState =  !authenticationService.isInvestorLoggedIn() ? "transact.review.buy" : "invTransact.review.buy";
    
    $scope.isNewInvestor = transactModel.isNewInvestor;
    $scope.isNewCreateFolio = transactModel.getIsNewFolio();
}

buyController.$inject = ['$scope','$state', 'ifscModel', 'transactModel', 'authenticationService'];
module.exports = buyController;