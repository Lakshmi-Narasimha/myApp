 function investerController($scope,$state,advisorRegistrationModelService,$filter,$cookies,appConfig){
      $scope.submitInvestor = function(){
        
      		if($scope.investorForm.$valid){
        		  $scope.$broadcast('panAndDobsubmitted');
              $scope.formData=advisorRegistrationModelService.getPanAndDOBData();
            
              $scope.formData.regType = "Investor";
              var postSuccess = function (response) {
                      advisorRegistrationModelService.setUserData(response.data);
                      $cookies.put('accessToken',response.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
                      $state.go('loginmaster.userverification.securityquestion'); 
               };
               
               var handleFailure = function (errorResp){ 
                  $scope.displayError = errorResp.data[0].errorDescription;
               };
              advisorRegistrationModelService.postArnOrDobForFUNameDetails($scope.formData).then(postSuccess, handleFailure);
              
             
        	 }
        	
        }
}
investerController.$inject = ['$scope','$state','advisorRegistrationModelService','$filter','$cookies','appConfig'];
module.exports = investerController;