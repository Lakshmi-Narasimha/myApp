// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var EmandateDetailsSchema = new mongoose.Schema({
    getEmandateDetails: {
        type: Object,
        "default": {}
    }
});

var EmandateAccLookUp = mongoose.model('EmandateAccLookUp', EmandateDetailsSchema);

var EmandateDetailsModel = new EmandateAccLookUp({
      getEmandateDetails: {
          "pan": "CNKQQ9569X",
          'availableBanks': 'Available only for HDFC Bank and Axis Bank',
          "emandateDetails": [
            {
              "accountType": "SA",
              "amount": "1000",
              "amountType": "F",
              "emRefNo": "EM00001027",
              "bankAccno": "3574063201671",
              "bankName": "HDFC BANK LTD",
              "endDate": "2016-12-09 00:00:00.0",
              "folioId": "14304380",
              "frequency": "M",
              "ifscCode": "null",
              "startDate": "2010-12-09 00:00:00.0"
            },
            {
              "accountType": "SA",
              "amount": "1000",
              "amountType": "F",
              "emRefNo": "EM00001022",
              "bankAccno": "3574063201672",
              "bankName": "AXIS BANK LTD",
              "endDate": "2016-12-09 00:00:00.0",
              "folioId": "14304386",
              "frequency": "M",
              "ifscCode": "null",
              "startDate": "2010-12-09 00:00:00.0"
            }
          ]
        }
});

EmandateAccLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating EmandateAccLookUp table, please contact admin...');
    } else {
        EmandateAccLookUp.remove({}, function(err) {
            console.log('EmandateAccLookUp collection removed');
            EmandateDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating EmandateAccLookUp table, please contact admin...');
                }
                console.log('EmandateAccLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = EmandateAccLookUp;
