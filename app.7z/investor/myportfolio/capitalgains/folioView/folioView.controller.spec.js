'use strict';
describe('Controller: folio view controller', function() {
    var $controller, $scope, event, folioViewController, fticgAccDetLoadInitialService, investorEventConstants, timeout;
    
    var cgfolioFilter = {
        'folioPanAccNo': '4069906573525',
        '_isInitialLoad': true,
        'dayFlag': 'CY',
    }
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _fticgAccDetLoadInitialService_, _investorEventConstants_, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);
        fticgAccDetLoadInitialService = _fticgAccDetLoadInitialService_;
        investorEventConstants = _investorEventConstants_;

        folioViewController = $controller('CGFolioViewCtrl', { $scope: $scope });
    }));

    it('should expect controller to be defined', function() {
        expect(folioViewController).toBeDefined();
    });

    it('should have showcgFolioData to be false', function() {
        expect($scope.showcgFolioData).toBeFalsy();
    });

    it('should trigger initial services when services data is not available', function() {
        spyOn($scope, '$broadcast');
        $scope.$broadcast('cgfolioapply', event, cgfolioFilter);
        expect($scope.$broadcast).toHaveBeenCalledWith('cgfolioapply', event, cgfolioFilter);
    });

    it('should trigger event cgfoliodetailslist', function() {
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('cgfoliodetailslist');
        expect($scope.$broadcast).toHaveBeenCalledWith('cgfoliodetailslist');
        expect($scope.showcgFolioData).toBeTruthy();
    });
});
