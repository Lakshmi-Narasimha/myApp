'use strict';

var pvModel = function(Restangular, $q, authenticationService) {
    var _pvDtls = null;
    var pvModel = {
        fetchPanViewDetails: function(panFilter) {

            panFilter.guId = authenticationService.getUser().guId;

            var deferred = $q.defer();
            Restangular.one('clients/clientStatement').get(panFilter).then(function(panviewdetails) {
                deferred.resolve(panviewdetails);

            }, function(resp) {

                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getPanViewDtls: function() {
            return _pvDtls;
        },

        setPanViewDtls: function(panviewdetails) {
            _pvDtls = panviewdetails;
        }

    };
    return pvModel;

};

pvModel.$inject = ['Restangular', '$q', 'authenticationService'];
module.exports = pvModel;
