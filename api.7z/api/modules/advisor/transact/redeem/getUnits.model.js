// Units.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var UnitsModelSchema = new mongoose.Schema({
    UnitsResp: {
        type: Array,
        "default": []
    }
});

var UnitsModelLookUp = mongoose.model('UnitsModelLookUp', UnitsModelSchema);

var UnitsModel = new UnitsModelLookUp({
    UnitsResp : {
    	'units' : {
    		'value': '225'
    	}
    }
});

UnitsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating UnitsModelLookUp table, please contact admin...');
    } else {
        UnitsModelLookUp.remove({}, function(err) {
            console.log('UnitsModelLookUp collection removed');
            UnitsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating UnitsModelLookUp table, please contact admin...');
                }
                console.log('UnitsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = UnitsModelLookUp;