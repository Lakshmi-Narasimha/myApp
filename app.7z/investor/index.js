'use strict';

module.exports = angular.module('investor',[]);
    // .controller('mainCtrl', require('./mainCtrl'));