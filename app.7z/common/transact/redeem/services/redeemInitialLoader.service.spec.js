'use strict';
describe('Services: redeemInitialLoader', function() {
	var redeemInitialLoader,redeemModel,httpBackend,$window,selectInvestorModel,scope,transactEvents;

	var PaymentBanksByFolioResp = {
       "paymentBank": [{
            "accTypeDesc": "Savings Account",
            "achRefNo": "",
            "amount": "",
            "amountType": "",
            "defaultFlag": "Y",
            "fromDate": "",
            "ifscCode": "CITI0100000",
            "paymentType": "L",
            "payoutFlag": "N",
            "pbAccountType": "SA",
            "pbBankName": "CITI BANK",
            "pbMakerId": "",
            "pbPersonalAccountNumber": "7335300411",
            "regDate": "",
            "status": "",
            "toDate": ""
        }, {
            "accTypeDesc": "Savings Account",
            "achRefNo": "",
            "amount": "",
            "amountType": "",
            "defaultFlag": "Y",
            "fromDate": "",
            "ifscCode": "CITI0100000",
            "paymentType": "T",
            "payoutFlag": "N",
            "pbAccountType": "SA",
            "pbBankName": "CITI BANK",
            "pbMakerId": "",
            "pbPersonalAccountNumber": "7335300411",
            "regDate": "",
            "status": "",
            "toDate": ""
        }, {
            "accTypeDesc": "Savings Account",
            "achRefNo": "",
            "amount": "",
            "amountType": "",
            "defaultFlag": "Y",
            "fromDate": "",
            "ifscCode": "CITI0100000",
            "paymentType": "W",
            "payoutFlag": "N",
            "pbAccountType": "SA",
            "pbBankName": "CITI BANK",
            "pbMakerId": "",
            "pbPersonalAccountNumber": "7335300411",
            "regDate": "",
            "status": "",
            "toDate": ""
        }]
    };	

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

    var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

    beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function(_redeemInitialLoader_,_redeemModel_,_selectInvestorModel_,$httpBackend,_$window_,_transactEvents_){
		redeemInitialLoader = _redeemInitialLoader_;
		redeemModel = _redeemModel_;
		httpBackend = $httpBackend;						
		transactEvents = _transactEvents_;
		selectInvestorModel = _selectInvestorModel_;

		selectInvestorModel.setSelectedInvestorDtls(investorDetails);
		$window = _$window_;
        $window.ga = function() {};

		scope ={
			'$broadcast': function() {
	            return true;
	        }
	    };
	}));	

	it("loadAllServices should be defined",function(){
		expect(redeemInitialLoader.loadAllServices).toBeDefined();
	});

	it("should loadAllServices and check for success ",function(){
		spyOn(transactEvents.transact,"publishRedeemDetails");
		httpBackend.expectGET('http://localhost:3030/transact/paymentBanksByFolio?folioId=3456572&guId=878&paymentMethod=N').respond(200,PaymentBanksByFolioResp);

		redeemInitialLoader.loadAllServices(scope);
		httpBackend.flush();		
		expect(redeemModel.getBankDetails().paymentBank.length).toEqual(3);
		expect(transactEvents.transact.publishRedeemDetails).toHaveBeenCalledWith(scope);
	});	

	it("should loadAllServices and check for failure ",function(){
		httpBackend.expectGET('http://localhost:3030/transact/paymentBanksByFolio?folioId=3456572&guId=878&paymentMethod=N').respond(400,failureResponse);

		redeemInitialLoader.loadAllServices(scope);

		httpBackend.flush();		
		expect(redeemModel.getBankDetails()).toBe(null);		
	});	
});