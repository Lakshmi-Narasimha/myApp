/**
 * @ngdoc property
 * @name Investment Preference Directive
 * @description
 *
 * - Form includes selection of Investment Preferences 
 *
 **/
'use strict';

var fticPurchaseInvestPreferPanel = function(advisorSearchModel, transactModel, paperlessModel, transactNowModel, $state, $stateParams, $timeout, authenticationService, TransactConstant, transactEventConstants, fundDetails, invSmartSavingsModel) {
    return {
        template: require('./investPreferPanel.html'),
        restrict: 'E',
       scope: {
            investSelect : '='
        },
        controller: function($scope) {
            var existingAdvisors, advisorArnCode;
            $scope.configDataLost = {};
            $scope.configDataLost.showNotification = false;
            $scope.disableExistingAdv = false;
            // setting key value object
            var keyValueList = [];
            // advisor name and euin code
            var code = '';
            var euin = '';
            var codeId = '';
            var investPreferValue = {};
            var investPreferObject = null;
            var nullObj = {};
            $scope.selectOptions = [];
            $scope.referSelected = {};

            // initializes radio buttons model variables
            $scope.radios = {};
            //$scope.radios.selectedVal = '';
            $scope.radiosAdvisor = {};
            $scope.radiosAdvisor.selectedVal = '';
            // initializes radio objects
            $scope.preferences = [{
                label: 'Financial Advisor',
                value: 'financial',
                nameLbl: 'invPreference'
            }, {
                label: 'Direct',
                value: 'direct',
                nameLbl: 'invPreference'
            }];

            $scope.advisorTypeDetails = [{
                label: 'Existing Advisor',
                value: 'existing',
                nameLbl: 'advType'
            }, {
                label: 'New Advisor',
                value: 'new',
                nameLbl: 'advType'
            }];

            function advisorNamesSuccess(data) {
                advisorSearchModel.setAdvisorNameDetails(data);
                existingAdvisors = advisorSearchModel.getAdvisorNameDetails();
                if (existingAdvisors) {
                    $scope.selectOptions = [];
                    angular.forEach(existingAdvisors.distName, function (value) {
                        $scope.selectOptions.push({ 'title': value });
                    });
                }
                $scope.initiateInvestmentPreference();
            }

            $scope.$on('getInvestorPreferenceData', function () {
                var params = {
                    'guId': authenticationService.getUser().guId,
                    'userType': 'D',
                    'distValue': transactModel.getSelectedFolioDts().folioId,
                    'distFlag': 'F'
                };
                advisorSearchModel.fetchAdvisorNameDetails(params).then(advisorNamesSuccess);
            });

            $scope.initiateInvestmentPreference = function () {
                // getting existing advisors list
                if (!authenticationService.getUser().distId) {
                    $scope.distId = 'Direct ~ 0000000000';
                    $scope.disableExistingAdv = false;
                } else {
                    $scope.distId = authenticationService.getUser().distId;
                }

                var distIdCheck = $scope.distId.split('~');
                advisorArnCode = distIdCheck[1];

                //Function to find the given 'value' in a given object array
                $scope.findItemInFilter = function (objArr, value) {
                    var obj = null;
                    obj = (_.filter(objArr, function (x) {
                        return x.title == value;
                    }))[0];
                    return obj;
                };

                $scope.$on('advisorOptioSelected', function (event, selectedOption) {
                    code = selectedOption.title
                    codeId = code.split('~');
                    advisorArnCode = codeId[1];
                });

                $scope.listenAdvisorChange = function (input) {
                    $scope.investSelect.advisorselectedVal = input;
                    $scope.selectedAdvisorMode = input;
                    if ($scope.selectedAdvisorMode == 'existing') {
                        nullObj = {};
                        transactModel.setAdvDetails(nullObj);
                    }
                }

                $scope.listenChange = function (input) {
                    $scope.selectedMode = input;
                    $scope.investSelect.investSelectedVal = input;
                    if($scope.investSelect.instructionType !== 'oneTouchInvest'){
                        getFundDetails();
                    }
                    paperlessModel.investorPreferenceOption = input;
                    if ($scope.selectedMode == 'financial') {
                        if ($scope.selectOptions.length > 0) {
                            $scope.listenAdvisorChange($scope.advisorTypeDetails[0].value);
                            $scope.referSelected.distId = $scope.findItemInFilter($scope.selectOptions, $scope.distId);
                        } else {
                            $scope.listenAdvisorChange($scope.advisorTypeDetails[1].value);
                        }
                    } else if ($scope.selectedMode == 'direct') {
                        var nullObj = {};
                        transactModel.setAdvDetails(nullObj);
                    }
                }

                if (transactNowModel.isInvPreferHasInitialData === true) {
                    if (distIdCheck[0].trim().toLowerCase() === 'direct') {
                        $scope.listenChange($scope.preferences[1].value);
                    } else {
                        $scope.listenChange($scope.preferences[0].value);
                        if ($scope.selectOptions.length > 0) {
                            $scope.listenAdvisorChange($scope.advisorTypeDetails[0].value);
                        } else {
                            $scope.listenAdvisorChange($scope.advisorTypeDetails[1].value);
                        }
                    }
                }

                if (transactNowModel.hasInvPreferData == true) {
                    investPreferObject = transactNowModel.getInvestPrefer();
                    if (investPreferObject.investorMode == 'direct') {
                        $scope.listenChange($scope.preferences[1].value);
                    } else {
                        var advisorMode = investPreferObject ? investPreferObject.advisorMode : 'existing';
                        $scope.listenChange($scope.preferences[0].value);
                        $scope.listenAdvisorChange(advisorMode);
                        $scope.isEdit = true;
                        $scope.referSelected.distId = $scope.findItemInFilter($scope.selectOptions, transactNowModel.getInvestPrefer().code);
                    }
                } else {
                    $scope.referSelected.distId = $scope.findItemInFilter($scope.selectOptions, $scope.distId);
                }
            }

            function getFundDetails() {
                var params = {};
                invSmartSavingsModel.getFundDetails(params).then(FundNameSuccess);
            }

            function FundNameSuccess(data) {
                invSmartSavingsModel.setFundData(data);
                $scope.$emit('fundSelected');
            }

            $scope.$on('savePurchaseDetails', function () {
                console.log('called from Investment Preference');
                $scope.investorPrefTransactForm.$setSubmitted();
                transactNowModel.hasInvPreferData = true;
                investPreferValue = {};
                investPreferValue.investorMode = $scope.selectedMode;
                investPreferValue.advisorMode = $scope.selectedAdvisorMode;
                investPreferValue.code = transactModel.getAdvDetails().code;
                investPreferValue.advisorArnCode = advisorArnCode;
                investPreferValue.selectedArn = $scope.referSelected.distId;
                investPreferValue.euin = transactModel.getAdvDetails().euin;
                transactNowModel.setInvestPrefer(investPreferValue);
                transactNowModel.isInvPreferHasInitialData = false;
                if ($scope.selectedMode === 'financial') {
                    keyValueList = [
                        { key: 'Investment Preference', value: 'Financial Advisor' },
                        { key: 'Adviser Name', value: transactModel.getAdvDetails().code },
                        { key: 'ARN Code', value: advisorArnCode }
                    ];
                } else if ($scope.selectedMode === 'direct') {
                    keyValueList = [
                        { key: 'Investment Preference', value: 'Direct-ARN0000000000' }
                    ];
                }
                transactNowModel.setkeyValueInvPreferData(keyValueList);
            });
        }
    };
};

fticPurchaseInvestPreferPanel.$inject = ['advisorSearchModel', 'transactModel', 'paperlessModel', 'transactNowModel', '$state', '$stateParams', '$timeout', 'authenticationService', 'TransactConstant', 'transactEventConstants', 'fundDetails', 'invSmartSavingsModel'];
module.exports = fticPurchaseInvestPreferPanel;
