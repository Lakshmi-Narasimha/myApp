// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetTxnSwpModelSchema = new mongoose.Schema({
    GetTxnSwpResp: {
        type: Array,
        "default": []
    }
});

var GetTxnSwpModelLookUp = mongoose.model('GetTxnSwpModelLookUp', GetTxnSwpModelSchema);

var GetTxnSwpModel = new GetTxnSwpModelLookUp({
    GetTxnSwpResp : {
                      "customerInfoVo": {
                        "custName": "HEMALI H SAFI M GOKARNAKAR ALICE RODRIGUES",
                        "address1": "4109 26TH MAIN ROAD",
                        "address2": "ALAVKIK APARTMENT, ANMOL TOWER",
                        "address3": "ANAND ARCH APARTMENTS",
                        "address4": "W B 743376",
                        "city": "TAL-PANVEL",
                        "pinCode": "403005",
                        "firstHolderName": "HEMALI H SAFI M GOKARNAKAR ALICE RODRIGUES",
                        "secondHolderName": "",
                        "thirdHolderName": "",
                        "guardian": "",
                        "firstHolderPanNo": "CNEQI5450Z",
                        "secondHolderPanNo": "",
                        "thirdHolderPanNo": "",
                        "guardianPanNo": "",
                        "firstHolderKycStatus": "KYC - Registered",
                        "secondHolderKycStatus": "KYC - Registered",
                        "thirdHolderKycStatus": "KYC - Registered",
                        "guardianKycStatus": "",
                        "socialStatus": "Individual",
                        "holdingType": "Single",
                        "bankdetails": "627208375076326/UNION BANK OF INDIA/SANGOLDA",
                        "paymentType": "",
                        "paymentMode": "Directly To Bank"
                      },
                      "retrieveSipVo": null,
                      "fundOptions": [
                        {
                          "accNo": "00699045302261",
                          "amount": "10000",
                          "direct": "",
                          "dividendFlag": null,
                          "endDate": "",
                          "frequency": "",
                          "fundCategory": "",
                          "fundOptDesc": "",
                          "fundOption": "201",
                          "fundType": "",
                          "minAddPurAmt": "",
                          "minNewPurAmt": "",
                          "minSipAmt": "",
                          "multiples": "",
                          "nfoFlag": "N",
                          "payoutFlag": "",
                          "perpetualFlag": "",
                          "reinvestmentFlag": "",
                          "startDate": "",
                          "stepUpType": "",
                          "stepUpValue": ""
                        },

                        {
                          "accNo": "00699045302262",
                          "amount": "20000",
                          "direct": "",
                          "dividendFlag": null,
                          "endDate": "",
                          "frequency": "",
                          "fundCategory": "",
                          "fundOptDesc": "",
                          "fundOption": "201",
                          "fundType": "",
                          "minAddPurAmt": "",
                          "minNewPurAmt": "",
                          "minSipAmt": "",
                          "multiples": "",
                          "nfoFlag": "N",
                          "payoutFlag": "",
                          "perpetualFlag": "",
                          "reinvestmentFlag": "",
                          "startDate": "",
                          "stepUpType": "",
                          "stepUpValue": ""
                        }
                      ],
                      "invPaymentBank": "UNION BANK OF INDIA",
                      "paymentMode": "",
                      "folioId": "17763831",
                      "accountType": null,
                      "paymentBankAccNo": "627208375076326",
                      "invAmount": "",
                      "subBrokerCode": "0000000000",
                      "subBrokerARN": "1",
                      "euin": "A",
                      "txn_no": "SIP1299",
                      "seq_no": "1",
                      "account_number": "987654321",
                      "fund_option": "",
                      "batch_code": "web",
                      "trxn_requested_date": "2016-03-15 00:00:00.0",
                      "trxn_requested_time": "10:00",
                      "txn_source": "SWP",
                      "sub_distributor_id": null,
                      "ref_txn_no": null,
                      "application_sr_no": null,
                      "remarks": null,
                      "maker_id": "Mobile",
                      "maker_date": "2016-03-23 00:00:00.0",
                      "auth_id": "Mobile",
                      "auth_date": "2016-03-23 00:00:00.0",
                      "acc_ref_no": "SIP1299",
                      "transferflag": "-3",
                      "trtype": "ADD",
                      "web_refno": "SIP1299",
                      "transaction_flag": "C",
                      "mode_of_txn": null,
                      "euin_flag": "N",
                      "trxn_units": null,
                      "all_units_flag": null,
                      "start_date": "2016-04-20 00:00:00.0",
                      "end_date": "2017-01-20 00:00:00.0",
                      "frequency": "M",
                      "perpetual_flag": "N",
                      "mf_code": null,
                      "destination_account_number": null,
                      "destination_fund_option": null,
                      "sip_txn_status": null,
                      "urn_no": "22",
                      "nfo_flag": "",
                      "priority_batch_flag": null,
                      "trxn_effective_date": null,
                      "amount_unit_flag": null,
                      "dc_last_xdigits": "3333",
                      "dc_name_on_card": "TEST",
                      "check_no": null,
                      "dividend_option": "",
                      "account_source": "RWD",
                      "branch_code": null,
                      "no_of_installments": "10",
                      "lbd_flag": null,
                      "umrn_no": null,
                      "source": "20",
                      "renewal_flag": "N",
                      "paymentOption": "O",
                      "aadhaar": "",
                      "pepFlag": "",
                      "stepUpType": null,
                      "stepUpValue": null,
                      "emandateDebitType": null,
                      "emandateFrequency": null,
                      "emandateAmount": null,
                      "untillCancel": null,
                      "emandateFromdate": null,
                      "emandateTodate": null,
                      "stepUpFrequency": null
                    }
});

GetTxnSwpModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetTxnSwpModelLookUp table, please contact admin...');
    } else {
        GetTxnSwpModelLookUp.remove({}, function(err) {
            console.log('GetTxnSwpModelLookUp collection removed');
            GetTxnSwpModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetTxnSwpModelLookUp table, please contact admin...');
                }
                console.log('GetTxnSwpModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GetTxnSwpModelLookUp;