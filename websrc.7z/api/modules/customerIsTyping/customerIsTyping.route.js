var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');

var router = express.Router();
var customerIsTypingModel = require('./customerIsTyping.model');

// api route
router.route('/mfchat/rest/customerIsTyping')
    .post(function(req, res) {
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        req.uri = customerIsTypingModel.createRequestUri;
        var post_data = req.body.RequestParams;
        //console.log(post_data);
        //req.query = req.body.RequestParams.InitialMessage;
        var postBody = querystring.stringify(post_data);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, {statusCode: proxyResponse.statusCode}, req.session.id));
            if (proxyResponse.statusCode === 200) {
                res.status(200).end();
                logger.outBoundData.info(logger.formatResMsg(req, res));
            } else {
                //  //logger.error.error({
                //      statusCode: proxyResponse.statusCode,
                //      message: 'Something went wrong while retrieving data.'
                //  });
                res.send({
                    statusCode: proxyResponse.statusCode,
                    message: 'Something went wrong while retrieving data.'
                });
            }
            proxyResponse.on('error', function(err) {
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
                logger.error.error(logger.formatResMsg(req, err));
            });
        });
        // console.log(proxyRequest);
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
