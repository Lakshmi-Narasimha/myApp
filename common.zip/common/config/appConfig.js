'use strict';
var appConfig = (function() {
    return {

        // Set the Environment on which the Current Base needs to Run. Available values: LOCAL, DEV, QA, UAT, PROD
        ENVIRONMENT: 'QA',


        //App Config Constants
        IS_LOG_ENABLED: true,
        IS_AJAXLOG_ENABLED: false,
        LOG_LEVEL: 'ALL',

        //Logging URL
        //LOGGING_URL:'http://localhost:3030/fticLogger',
        LOGGING_URL_LOCAL: 'http://localhost:3030/fticLogger',

        SUCCESS_MSG_TITLE: 'Alert!',
        ERROR_MSG_TITLE: 'Alert!',
        REST_REQ_TIMEOUT: 180000, //  3 mins
        DATEFORMAT: 'dd-MM-yyyy',
        TIMEFORMAT: 'HH:mm:ss',
        IS_STATECHANG_EVENTS_ENABLED: true,
        IS_VIEWCONTENT_EVENTS_ENABLED: true,
        IS_OVERRIDE_HTTPHEADERS_ENABLED: false,
        STATUS: ['Open', 'In-Progress', 'Closed'],
        CAPABILITIES_REST_ENDPOINT_BASEURL: 'Https://api.mongolab.com/api/1/databases/angulardb/collections/',

        //Auth URL
        //AUTH_REST_ENDPOINT_BASEURL: 'https://api-dev.franklintempleton.com/v1/ide/',
        AUTH_REST_ENDPOINT_BASEURL_LOCAL: 'http://localhost:3030',
        AUTH_REST_ENDPOINT_BASEURL_DEV: 'https://api-dev.franklintempleton.com/v1/ide/',
        AUTH_REST_ENDPOINT_BASEURL_QA: 'https://api-dev.franklintempleton.com/v1/ide/',
        AUTH_REST_ENDPOINT_BASEURL_UAT: 'https://api-test.franklintempleton.com/v1/ide/',
        AUTH_REST_ENDPOINT_BASEURL_PROD: 'https://api.franklintempleton.com/v1/ide/',

        //AUTH_REST_ENDPOINT_BASEURL_PROD: '',


        //Proxy URL
        //PROXY_URL : 'http://accounts.ftindiadev1.corp.frk.com/proxyApp/',
        PROXY_URL_LOCAL : 'http://accounts.ftindiadev1.corp.frk.com/proxyApp/',
        PROXY_URL_DEV : 'http://accounts.ftindiadev1.corp.frk.com/proxyApp/',
        PROXY_URL_QA : 'http://accounts.ftindiaqa1.corp.frk.com/proxyApp/',
        PROXY_URL_UAT : 'https://accounts.ftindiastg1.corp.frk.com/proxyApp/',
        PROXY_URL_PROD : 'https://accounts.franklintempletonindia.com/proxyApp/',

        //Marketing URL
        //MARKETING_URL : 'http://localhost:3002',
        MARKETING_URL_LOCAL : 'http://localhost:3002',
        MARKETING_URL_DEV : 'http://ftindiadev1.corp.frk.com',
        MARKETING_URL_QA : 'http://ftindiaqa1.corp.frk.com',
        MARKETING_URL_UAT : 'https://ftindiastg1.corp.frk.com',
        MARKETING_URL_PROD : 'https://beta.franklintempletonindia.com',

        //Guest URL
        //GUEST_URL : 'http://accounts.ftindiadev1.corp.frk.com:8083',
        GUEST_URL_LOCAL : 'http://localhost:3000',
        GUEST_URL_DEV : 'http://accounts.ftindiadev1.corp.frk.com/guest',
        GUEST_URL_QA : 'http://accounts.ftindiaqa1.corp.frk.com/guest',
        GUEST_URL_UAT : 'https://accounts.ftindiastg1.corp.frk.com/guest',
        GUEST_URL_PROD : 'https://accounts.franklintempletonindia.com/guest',

        INVESTOR_URL_LOCAL : 'http://localhost:3000/investor',
        INVESTOR_URL_DEV : 'http://accounts.ftindiadev1.corp.frk.com:8085/investor',
        INVESTOR_URL_QA : 'http://accounts.ftindiaqa1.corp.frk.com:8085/investor',

        IMAGES_ADVISOR : '/advisor/images',
        IMAGES_INVESTOR: '/investor/images',
        IMAGES_GUEST : '/guest/images',
        //cookie config
        COOKIE_NAME: 'sessionAuth',
        EXPIRY_MINUTE: 20,
        EXPIRY_SECONDS: 600, //600
        IDLE_TIME_OUT: 900, //900
        DOMAIN_CONFIG : 'localhost'//localhost,
    };
}());

appConfig.$inject = [];

module.exports = appConfig;
