/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var newFolioDetails= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
     var _NewFolioDtlsResp = null;    

	var newFolioModel = {
        // fetchcgaccountdetails : function () {
        fetchNewFolio : function () {
            var deferred = $q.defer();
            Restangular.one('getNewFolioDetails').get().then(function (NewFolioDtlsResp) {
                console.log(NewFolioDtlsResp);
                deferred.resolve(NewFolioDtlsResp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getNewFolioDtls : function () {
            if (!angular.isDefined(_NewFolioDtlsResp)) {
                return null;
            }
            return _NewFolioDtlsResp;
        } ,
		setNewFolioDtls : function (NewFolioDtlsResp) {
            _NewFolioDtlsResp = NewFolioDtlsResp.result;
        }

    };
    return newFolioModel;

};

newFolioDetails.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = newFolioDetails;
