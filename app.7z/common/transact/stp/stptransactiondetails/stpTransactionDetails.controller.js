/**
 * @ngdoc property
 * @name stp transaction details Controller
 * @requires $scope
 * @requires $filter
 * @requires $state
 * @requires TransactConstant
 * @requires transactModel
 * @description
 *
 * - It gets the data from transactModel and binds the data
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function stpTransDetailsController($scope, TransactConstant, $filter, $state, transactModel) {
    $scope.stpDetails = transactModel.getTransactDetails().stpDetails;
    var transConf = transactModel.getTransactConfirm(),
    fundDetails = transactModel.getFundDetails(), 
    startDate = $filter('date')(new Date($scope.stpDetails.startDate), 'dd MMMM yyyy'),
    endDate = $filter('date')(new Date($scope.stpDetails.endDate), 'dd MMMM yyyy');
    console.log(transactModel.getTransactDetails().stpDetails,transConf);
    
    $scope.destinationFund = $scope.stpDetails.destinationFund.fundName;
    $scope.stpAmount = $scope.stpDetails.stpAmount.amount;
    $scope.invDetails = transactModel.getInvestorDetails();
    
    $scope.keyValuePairs = [{
            key: 'FolioNo',
            text: $filter('translate')(TransactConstant.transact.FOLIO_NUM),
            value: $scope.invDetails.folioId
        }, {
            key: 'sourceFund',
            text: $filter('translate')(TransactConstant.transact.SOURCE_FUND),
            value: fundDetails.fmDescription
        }, {
            key: 'destinationFund',
            text: $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
            value: $scope.destinationFund
        }, {
            key: 'stpType',
            text: $filter('translate')(TransactConstant.transact.STP_TYPE),
            value: $scope.stpDetails.stpAmount.type
        }, {
            key: 'stpAmount',
            text: 'STP Amount',
            value: $scope.stpAmount
        }, {
            key: "frequency",
            text: $filter('translate')(TransactConstant.transact.FREQUENCY),
            value: $scope.stpDetails.frequency
        }, {
            key: 'startDate',
            text: $filter('translate')(TransactConstant.stp.STP_START_DATE),
            value: startDate
        }, {
            key: 'endDate',
            text: $filter('translate')(TransactConstant.stp.STP_END_DATE),
            value: endDate
        }, {
            key: 'transactionRefNo',
            text: $filter('translate')(TransactConstant.common.TRANSACTION_REF_NO),
            value: transConf.transactionRefNo
        }, {
            key: 'requestDateTime',
            text: $filter('translate')(TransactConstant.transact.REQ_DATE_AND_TIME),
            value: transConf.transDateTime
        }

    ];

    //Function to initiate another STP
    $scope.initiateAnotherStp = function() {
        transactModel.resetSetters();
        // transactModel.setStateValue({key:"Fund"});
        transactModel.isNewInvestor = false;
        $state.go('transact.base.stp', { key: null });
    }
}

stpTransDetailsController.$inject = ['$scope', 'TransactConstant', '$filter', '$state', 'transactModel'];
module.exports = stpTransDetailsController;
