/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolFundSelection = function($state) {
	return {
          template: require('./smartSolFundSelection.html'),
           restrict: 'E',
           replace: true,
            controller: function($scope, $element, $attrs){
              $scope.fundSelection = "Franklin Templeton Asian Equity Fund";
              },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

smartSolFundSelection.$inject = [];
module.exports = smartSolFundSelection;