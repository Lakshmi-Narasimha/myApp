'use strict';

var loggerConstants = (function() {
    return {

        // Advisor (app)

        ADVISOR_APP: 'advisor',

        //Dashboard (module)

        DASHBOARD_MODULE: 'advisor.dashboard',

        //Files
        DASHBOARD_CONTROLLER: 'dashboard.controller',
        BUSINESS_HIGHLIGHTS_DIRECTIVE: 'businessHighlights.directive',
        FUND_CONTENT_DIRECTIVE: 'fundContent.directive',
        MARKETING_CONTENT_DIRECTIVE: 'marketingContent.directive',
        NOTIFICATIONS_DIRECTIVE: 'notification.directive',
        QUICK_LINKS_DIRECTIVE: 'quickLinks.directive',
        RECOMMENDATIONS_DIRECTIVE: 'recommendation.directive',
        ADVISOR_ALERTS_MODEL: 'advisorAlertsModel.service',
        ADVISOR_DASHBOARD_DETAILS_MODEL: 'advisorDashboardDetailsModel.service',
        ADVISOR_SIP_DETAILS_MODEL: 'advisorSipDetailsViewModel.service',
        ADVISOR_CONTENT_MODEL: 'ftiAdvisorContentModel.service',
        DASHBOARD_INITIAL_LOADER_SERVICE: 'ftiDashboardInitialLoader.service',
        SIP_BOOK_DIRECTIVE: 'sipBook.directive',
        TRANSACTION_STATUS_DIRECTIVE: 'transactionStatus.directive',
        USER_INFORMATION_DIRECTIVE: 'userInformation.directive',



        //Book of Business (module)
        
        BOOK_OF_BUSINESS_MODULE: 'advisor.bookofbussiness',

        //Files
        SALES_OVERVIEW_CONTROLLER: 'salesOverview.controller',
        SALES_OVERVIEW_CHART_DIRECTIVE: 'soChart.directive',
        SALES_OVERVIEW_GRID_DIRECTIVE: 'soGrid.directive',
        SALES_OVERVIEW_INITIAL_LOADER_SERVICE: 'salesOverviewInitialLoader.service',
        SALES_OVERVIEW_MODEL: 'salesOverviewModel.service',
        VIEW_COMPOSITION_CONTROLLER: 'viewComposition.controller',
        PORTFOLIO_CONTROLLER: 'portfolio.controller',
        AUM_AGEING_DIRECTIVE: 'aumageing.directive',
        FUNDS_PURCHASED_DIRECTIVE: 'fundspurchased.directive',
        FUNDS_REDEEMED_DIRECTIVE: 'fundsredeemed.directive',
        ID_ATTRIBUTE_ANALYSIS_DIRECTIVE: 'idAttrAnalysis.directive',
        ID_AUM_GROWTH_DIRECTIVE:'idAumGrowth.directive',
        ID_INV_BOOK_SPLIT_DIRECTIVE: 'idInvBookSplit.directive',
        ID_INV_FOLIO_SPREAD_DIRECTIVE: 'idInvFolioSpread.directive',
        INVESTOR_DETAILS_CONTROLLER: 'investorDetails.controller',
        LUMPSUM_BOOK_CONTROLLER: 'lumpsumbook.controller',
        MB_COMM_DETAILS_DIRECTIVE: 'mbCommDtls.directive',
        MB_DETAILS_DIRECTIVE: 'mbDetails.directive',
        MB_DETAILS_GRID_DIRECTIVE: 'mbDetailsGrid.directive',
        MB_FUNDS_COMPOSITION_CONTROLLER: 'mbFundsComposition.controller',
        MB_FUNDS_COMPOSITION_DIRECTIVE: 'mbFundsComposition.directive',
        MB_OVERVIEW_DIRECTIVE: 'mbOverview.directive',
        MB_REDEMPTION_DETAILS_DIRECTIVE: 'mbRedemptionDtls.directive',
        MONTHLY_BIZ_CONTROLLER: 'monthlybiz.controller',
        SIP_BOOK_FULLVIEW_DIRECTIVE: 'sipbookfullview.directive',
        SIP_BOOK_VIEW_CONTROLLER: 'sipbookview.controller',
        INV_DETAILS_AUM_GROWTH_MODEL: 'investorDetailsAumGrowthModel.service',
        INVESTOR_DETAILS_INITIAL_LOADER_SERVICE: 'investorDetailsInitialLoader.service',
        INVESTOR_DETAILS_MODEL: 'investorDetailsModel.service',
        INVESTOR_FOLIO_DETAILS_MODEL: 'investorFolioDetailsModel.service',
        LUMPSUM_BOOK_INITIAL_LOADER_SERVICE: 'lumpsumBookInitialLoader.service',
        LUMPSUM_BOOK_MODEL: 'lumpsumBookModel.service',
        MB_FUND_COMPOSITION_MODEL: 'mbFundCompositionModel.service',
        MONTHLY_BUSINESS_OVERVIEW_MODEL: 'monthlyBusinessOverviewModel.service',
        PORTFOLIO_SNAPSHOT_INITIAL_LOADER_SERVICE: 'portfolioSnapshotInitialLoader.service',
        SIP_BOOK_INITIAL_LOADER: 'sipBookInitialLoader.service',
        SIP_BOOK_MODEL: 'sipBookModel.service',
        CM_SNAPSHOT_MODEL: 'commissionSnapshotModel.service',
        CM_SNAPSHOT_INITIAL_LOADER: 'commissionSnapshotInitialLoader.service',
        
        
        
        //My Investor Module
        
        MY_INVESTOR_MODULE: 'advisor.myinvestors',
        
        //Files
        SUBSCRIPTION_DETAILS_MODEL: 'subscriptionDetailsModel.service',
        SUBSCRIPTION_DETAILS_INITIAL_LOADER_SERVICE: 'subscriptionDetailsInitialLoader.service',
        SUBSCRIPTIONS_CONTROLLER: 'subscription.controller',
             
        //Transactions
        TRANSACTION_CONTROLLER: 'transactions.controller',
        TRANSACTION_VIEW_DETAILS_CONTROLLER: 'transactionviewdetails.controller',
        TRANSACTION_SUMMARY_DIRECTIVE: 'transactionsummary.directive',
        TRANSACTION_DETAILS_DIRECTIVE: 'transactiondetail.directive',
        TRANSACTION_FILTER_DIRECTIVE: 'transactionfilter.directive',
        TRANSACTION_MODEL: 'transactionModel.service',
        TRANSACTION_INITIAL_LOADER: 'transactionInitialLoader.service',
        TRANSACT_MODULE : 'advisor.transact',
        FREQUENCY_OPTIONS_MODEL: 'frequencyOptionsModel.service',
        SIP_CONTROLLER : 'sip.controller',
         
        //Systematic Plans
        SYSTEMATIC_PLANS_CONTROLLER: 'sysplans.controller',
        SYSTEMATIC_PLANS_INSTALLMENT_CONTROLLER: 'spinstallment.controller',
        SYSTEMATIC_PLANS_REGISTRATION_DETAILS_DIRECTIVE: 'spregddetails.directive',
        SYSTEMATIC_PLANS_INSTALLMENT_DETAILS_DIRECTIVE: 'spInstlDetails.directive',
        SYSTEMATIC_PLANS_FILTER_DIRECTIVE: 'spFilter.directive',
        SYSTEMATIC_PLANS_MODEL: 'sysPlansModel.service',
        SYSTEMATIC_PLANS_INITIAL_LOADER: 'sysPlansInitialLoader.service',

        INVESTOR_FUND_INFO_DIRECTIVE: 'investorFundInfo.directive',

        //My Profile(module)

        MY_PROFILE_MODULE: 'advisor.myprofile',


        //Files
        GRANT_ACCESS_CONTROLLER: 'grantAccess.controller',
        GRANT_ACCESS_PANEL: 'grantAccessPanel.directive',
        GRANT_ACCESS_USERS_LIST: 'grantAccessUsersList.directive',
        GRANT_ACCESS_USERS_LIST_ITEM: 'grantAccessUsersListItem.directive',
        GRANT_ACCESS_USER_INPUT_FORM: 'userInputForm.directive',
        GRANT_ACCESS_DETAILS_INITIAL_LOADER_SERVICE: 'grantAccessDetailsIntialLoader.service',
        GRANT_ACCESS_DETAILS_MODEL: 'grantAccessDetailsModel.service',

        //Leads (Module)

        MY_LEADS_MODULE: 'advisor.leads',

        //Files

        LEADS_CONTROLLER: 'leads.controller',
        LEADS_DETAILS_INITIAL_LOADER_SERVICE: 'leadsDetailsInitialLoader.service',
        LEADS_DETAILS_MODEL: 'leadsDetailsModel.service',


        //Reports (module)

        REPORTS_MODULE: 'advisor.reports',

        //Files
        USER_EMAIL_IDS_INITIAL_LOADER_SERVICE: 'userEmailIdsInitalLoader.service',
        USER_EMAIL_IDS_MODEL: 'userEmailIdsModel.service',
        ADV_INSTANT_REPORTS_CONTROLLER : 'instantReports.controller',
        TRANSACTION_STATUS_CONTROLLER : 'transactionStatus.controller',
        TRANSACTION_STATUS_INITIAL_LOADER_SERVICE : 'transactionStatusInitialLoader.service',
        TRANSACTION_STATUS_MODEL : 'transactionStatusModel.service',
        BASIS_DATE_CONTROLLER : 'basisDate.controller',
        BASIS_INVESTOR_CONTROLLER : 'basisInvestor.controller',
        BASIS_INVESTOR_DETAILS_CONTROLLER : 'basisInvestorDetails.controller',
        BASIS_INVESTOR_ACCODION_DIRECTIVE : 'basisInvestorAccodion.directive',
        STATUS_FILTER_DIRECTIVE : 'statusFilter.directive',

        //Components (module)

        ADVISOR_COMPONENTS_MODULE: 'advisor.components',

        //Files
        LEFT_NAV_DIRECTIVE: 'leftnav.directive',
        STICKY_HEADER_DIRECTIVE: 'stickyHeader.directive',
        


        //Common Components (module)

        COMMON_COMPONENTS_MODULE: 'commmon.components',

        //Files
        ACCORDION_DIRECTIVE: 'accordion.directive',
        REPORTS_DETAILS: 'reportsdetails.directive',
        REPORTS_DETAILS_CONTROLLER: 'reportsdetails.controller',
        INSTANT_REPORTS_DETAILS_INITIAL_LOADER_SERVICE: 'instantReportsDetailsInitialLoader.service',
        INSTANT_REPORTS_DETAILS_MODEL: 'instantreportsdetailsmodel.service',




        // Guest (app)

        GUEST_APP: 'guest',


        //Distributor Zone (module)
        
        DISTRIBUTOR_ZONE_MODULE: 'guest.distributorzone',

        //Files
        INSTANT_REPORTS_DETAILS_CONTROLLER: 'instantreportsdetails.controller',

        //Customer services (module)

        CUSTOMER_SERVICES_MODULE: 'guest.customerservices',

        //Files
        SMS_NAV_DETAILS_INITIAL_LOADER_SERVICE : 'smsNavInitialLoader.service',


        // Modules and file names goes below

        //Advisor Smart Solutions module
        SMART_SOLUTIONS_MODULE: 'advisor.smartsolutions',

        //Collaterals(Modules)
        COLLATERALS_MODULE:'advisor.collaterals',

        //Files
        EFORM_ACCODION_DIRECTIVE:'eformAccodion.directive',
        EFORM_FILTER_DIRECTIVE:'eformFilter.directive',

        // Investor (app)

        INVESTOR_APP: 'investor',
        //Dashboard (module)

        INV_DASHBOARD_MODULE: 'investor.dashboard',

        //Files
        INV_DASHBOARD_CONTROLLER: 'dashboard.controller',
        INV_IMAGE_TEXT_TILE_DIRECTIVE: 'imageTextTile.directive',
        INV_MY_INVESTMENTS_DIRECTIVE: 'invDbMyInvestments.directive',
        INV_MY_SIPS_DIRECTIVE:'invDbMySips.directive',
        INV_NOTIFICATIONS_DIRECTIVE:'invDbNotifications.directive',
        INV_ONE_TOUCH_INVEST_DIRECTIVE:'invDbOneTouchInvest.directive',
        INV_RECOMMENDATIONS_DIRECTIVE:'invDbRecommendations.directive',
        INV_SMART_SAV_ACCOUNT_DIRECTIVE:'invDbSmartSavingsAccount.directive',
        INV_SMART_SOLUTIONS_DIRECTIVE: 'invDbSmartSolutions.directive',
        INV_USER_INFORMATION_DIRECTIVE: 'invDbUserInformation.directive',
        INV_SMART_SOL_GRID_DIRECTIVE: 'invDbSmartSolutionsGrid.directive',
        INV_UNCLIAMED_AND_DIV_HIS_AMT_DIRECTIVE: 'unclaimedAndDividendHisAmount.directive',
        INVESTOR_DASHBOARD_DETAILS_MODEL:'investorDashboardDetailsModel.service',
        INV_DASHBOARD_INITIAL_LOADER_SERVICE: 'investorDashboardInitialLoader.service',

        //Dashboard (module)

        INV_EFORMS_MODULE: 'investor.eforms',

        //Files
        INV_EFORMS_CONTROLLER: 'eforms.controller',
        INV_EF_INCLUDE_TEMPLATE_DIRECTIVE: 'invEfIncludeTemplate.directive',
        INV_EF_SELECT_FORM_DIRECTIVE: 'invEfSelectForm.directive',
        INVESTOR_EFORMS_MODEL:'invEformModel.service',
        INV_COMMON_FOLIO_DETAILS_MODEL: 'invFolioDetailsModel.service',
        INV_EFORM_INITIAL_LOADER_SERVICE: 'invEformInitialLoader.service',

        //My Profile
        INV_MYPROFILE_MODULE: 'investor.myprofile',
        INV_MP_KYC_CONTROLLER: 'kycstatus.controller',
        //INV_EF_INCLUDE_TEMPLATE_DIRECTIVE: 'invEfIncludeTemplate.directive',
        //INV_EF_SELECT_FORM_DIRECTIVE: 'invEfSelectForm.directive',
        INV_MP_KYC_OTP_GEN_SERVICE:'invMpKycOtpGeneration.service',
        INV_MP_KYC_DATA_MODEL: 'invMpKycDataModel.service',
        INV_MP_KYC_INITIAL_LOADER_SERVICE: 'invMpKycInitialLoader.service',
        INV_MP_KYC_STATUS_LIST_DIRECTIVE: 'invMpKycStatusList.directive',
        INV_MP_KYC_USER_CONSENT_DIRECTIVE: 'invMpKycUserConsent.directive',

        //account settings
        INV_ACCOUNT_SETTINGS_MODULE:'investor.accountsettings',
        INV_CHANGE_DIVIDEND_CONTROLLER:'changedividend.controller',
        INV_CHANGE_PWD_MODAL_CONTROLLER:'confirmPasswordModal.controller',
        INV_CHANGE_DIVIDEND_GET_DIVIDEND_DETAILS:'getDividendDetailsFromApi',
        INV_CHANGE_DIVIDEND_CHECK_CONFIRM_PASSWORD:'checkConfirmPassword',
        INV_CHANGE_DIVIDEND_API:'ChangeDividendOptions'
    };
}());

loggerConstants.$inject = [];
module.exports = loggerConstants;