/**
 * @ngdoc factory
 * @name selectFundGrid factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var selectFundGridFactory = function() {



    var selectFundGridFactory = {

        getColumnDefs: function(userType, statusTemplateTransact, fundTitle, index, stateUrl,cellTemplateForNa) {
            var _columnArray = [{
                field: 'fund',
                displayName: '',
                value: index,
                width: '48',
                cellTemplate: statusTemplateTransact,
                pinnedLeft: true
            }, {
                field: 'fmDescription',
                displayName: fundTitle,
                width: '175',
                enableSorting: false,
                cellTemplate:cellTemplateForNa,
                pinnedLeft: true
            }, {
                field: 'tschvalAccno',
                displayName: 'Account No.',
                width: '152',
                cellTemplate:cellTemplateForNa,
                enableSorting: false
            }, {
                field: 'investmentGoal',
                displayName: 'Investment Goal',
                cellTemplate:cellTemplateForNa,
                width: '163',
                enableSorting: false
            }, {
                field: 'balUnits',
                displayName: 'Total Units',
                width: '127',
                enableSorting: false,
                cellTemplate:cellTemplateForNa,
                headerCellClass: 'text-right',
                cellClass: 'text-right'
            }, {
                field: 'marketValue',
                displayName: 'Current Value',
                headerCellClass: 'fti-grid-rupeeIcon text-right',
                cellTemplate:cellTemplateForNa,
                cellClass: 'text-right',
                width: '127',
                enableSorting: false
            }];
            var _dtpColumnArray = [{
                field: 'fund',
                displayName: '',
                value: index,
                width: '48',
                cellTemplate: statusTemplateTransact,
                pinnedLeft: true
            }, {
                field: 'fmDescription',
                displayName: fundTitle,
                width: '175',
                enableSorting: false,
                pinnedLeft: true
            }, {
                field: 'tschvalAccno',
                displayName: 'Account No.',
                width: '152',
                enableSorting: false
            }, {
                field: 'dividendOption',
                displayName: 'Dividend Option',
                width: '127',
                enableSorting: false
            }, {
                field: 'investmentGoal',
                displayName: 'Investment Goal',
                width: '163',
                enableSorting: false
            }, {
                field: 'marketValue',
                displayName: 'Current Value',
                headerCellClass: 'fti-grid-rupeeIcon text-right',
                   cellClass: 'text-right',
                width: '127',
                enableSorting: false
            }];
            var _resultArray;
            var cellTemplateForNa = '<div class="ui-grid-cell-contents">{{!grid.getCellValue(row, col) ? "NA" :  (grid.getCellValue(row, col).trim()!==""?grid.getCellValue(row, col):"NA")}}</div>';
            var _extTemplateObj = { cellTemplate: cellTemplateForNa };
            if (userType && (userType.toString() === '10')) {
                if (stateUrl === '/dtp') {
                    _resultArray = angular.copy(_dtpColumnArray);
                    _resultArray = _resultArray.reduce(function(dup, elem) {
                        if (elem.cellTemplate) {
                            dup.push(elem);
                        } else {
                            angular.extend(elem, _extTemplateObj);
                            dup.push(elem);
                        }
                        return dup;
                    }, []);
                    return _resultArray;
                } else {
                    _resultArray = angular.copy(_columnArray);
                    _resultArray.splice(4, 1);
                    _resultArray = _resultArray.reduce(function(dup, elem) {
                        if (elem.cellTemplate) {
                            dup.push(elem);
                        } else {
                            angular.extend(elem, _extTemplateObj);
                            dup.push(elem);
                        }
                        return dup;
                    }, []);
                    _resultArray[1].width = '215';
                    _resultArray[2].width = '215';
                    _resultArray[3].width = '175';
                    _resultArray[4].width = '140';

                    return _resultArray;
                }

            } else {
                return angular.copy(_columnArray);
            }
        },
        getFormattedFundDetails: function(userType, details) {
            if ((userType && userType.toString()) === '10') {
                var _details = angular.copy(details);
                _details.fmDescription = details.fmDescription ? (details.fmDescription.trim() !==""?details.fmDescription:'NA') : 'NA';
                _details.investmentGoal = details.investmentGoal ? (details.investmentGoal.trim() !==""?details.investmentGoal:'NA') : 'NA';
                _details.marketValue = details.marketValue ? (details.marketValue.trim() !==""?details.marketValue:'NA') : 'NA';
                _details.tschvalAccno = details.tschvalAccno ? (details.tschvalAccno.trim() !==""?details.tschvalAccno:'NA') : 'NA';
                return _details;
            } else {
                return details;
            }
        }
    };
    return selectFundGridFactory;

};

selectFundGridFactory.$inject = [];
module.exports = selectFundGridFactory;
