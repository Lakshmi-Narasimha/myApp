﻿require.config({
    paths: {
        jquery: 'scripts/jquery-2.1.0.min',
        underscore: 'scripts/underscore',
        backbone: 'scripts/backbone.min'
    },
    shim: {
        'backbone': { deps: ['underscore', 'jquery'], exports: 'Backbone' },
        'underscore': { exports: '_' },                
        'bootstrap': { deps: ['jquery'], exports: 'bootstrap' },        
    }
});

define(['jquery', 'underscore', 'backbone', 'config'],
    function ($, _, Backbone, config) {
        $.support.cors = true;
        var overallStatus = true;
        var svcStatus = [];
        var svcCount = 0;
        
        var monitorView = Backbone.View.extend({
            el: $("#monitor-service"),
            id: 'monitor-service',
            events: {
                "click #btnClientListSvc": "handleClientListSvc",
                "click #btnDistrbOverviewSvc": "handleDistrbOverviewSvc",
                "click #btnClientActGrpsSvc": "handleClientActGrpsSvc",
                "click #btnClientEmploymentSvc": "handleClientEmploymentSvc",
                "click #btnClientCapRegSvc": "handleClientCapRegSvc",
                "click #btnGroupsSvc": "handleGroupsSvc",
                "click #btnClientProfileListSvc": "handleClientProfileListSvc",
                "click #btnClientTaxContrbSvc": "handleClientTaxContrbSvc",
                "click #btnClientDistSvc": "handleClientDistSvc",
                "click #btnClientFiduciariesSvc": "handleClientFiduciariesSvc",
                "click #btnAccountSvc": "handleAccountSvc",
                "click #btnDistributorsSvc": "handleDistributorsSvc",
                "click #btnServiceAll": "handleServiceAll",
            },
            initialize: function(){
               // self.$('#clientListURI').text(config.monClientListSvc);                
            },

            handleClientListSvc: function () {
                var _self = this;
                _self.disableButton("btnClientListSvc");
                _self.$('#clientListSvcStatus').text('');
                _self.executeService(config.monClientListSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[0] = true;
                        _self.setSuccessStyle('clientListSvcStatus');
                        _self.setOverallStatus();                        
                        _self.enableButton("btnClientListSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        if (error.status == 404) {
                            svcStatus[0] = true;
                            _self.setSuccessStyle('clientListSvcStatus');
                        }
                        else {
                            svcStatus[0] = false;
                            _self.setFailureStyle('clientListSvcStatus', error);
                        }
                        _self.setOverallStatus();
                        _self.enableButton("btnClientListSvc");
                    })                    
            },

            handleDistrbOverviewSvc: function () {
                var _self = this;
                _self.disableButton("btnDistrbOverviewSvc");
                _self.$('#distrbOverviewSvcStatus').text('');
                _self.executeService(config.monDistrbOverviewSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[1] = true;
                        _self.setSuccessStyle('distrbOverviewSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnDistrbOverviewSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[1] = false;
                        _self.setFailureStyle('distrbOverviewSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnDistrbOverviewSvc");
                    })
            },

            handleClientActGrpsSvc: function () {
                var _self = this;
                _self.disableButton("btnClientActGrpsSvc");
                _self.$('#clientActGrpsSvcStatus').text('');
                _self.executeService(config.monClientActGrpsSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[2] = true;
                        _self.setSuccessStyle('clientActGrpsSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientActGrpsSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[2] = false;
                        _self.setFailureStyle('clientActGrpsSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientActGrpsSvc");
                    })
            },

            handleClientEmploymentSvc: function () {
                var _self = this;
                _self.disableButton("btnClientEmploymentSvc");
                _self.$('#clientEmploymentSvcStatus').text('');
                _self.executeService(config.monClientEmploymentSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[3] = true;
                        _self.setSuccessStyle('clientEmploymentSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientEmploymentSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[3] = false;
                        _self.setFailureStyle('clientEmploymentSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientEmploymentSvc");
                    })
            },

            handleClientCapRegSvc: function () {
                var _self = this;
                _self.disableButton("btnClientCapRegSvc");
                _self.$('#clientCapRegSvcStatus').text('');
                _self.executeService(config.monClientCapRegSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[4] = true;
                        _self.setSuccessStyle('clientCapRegSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientCapRegSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[4] = false;
                        _self.setFailureStyle('clientCapRegSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientCapRegSvc");
                    })
            },

            handleGroupsSvc: function () {
                var _self = this;
                _self.disableButton("btnGroupsSvc");
                _self.$('#groupsSvcStatus').text('');
                _self.executeService(config.monGroupsSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[5] = true;
                        _self.setSuccessStyle('groupsSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnGroupsSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[5] = false;
                        _self.setFailureStyle('groupsSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnGroupsSvc");
                    })
            },

            handleClientProfileListSvc: function () {
                var _self = this;
                _self.disableButton("btnClientProfileListSvc");
                _self.$('#clientProfileListSvcStatus').text('');
                _self.executeService(config.monClientProfileListSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[6] = true;
                        _self.setSuccessStyle('clientProfileListSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientProfileListSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[6] = false;
                        _self.setFailureStyle('clientProfileListSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientProfileListSvc");
                    })
            },

            handleClientTaxContrbSvc: function () {
                var _self = this;
                _self.disableButton("btnClientTaxContrbSvc");
                _self.$('#clientTaxContrbSvcStatus').text('');
                _self.executeService(config.monClientTaxContrbSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[7] = true;
                        _self.setSuccessStyle('clientTaxContrbSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientTaxContrbSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[7] = false;
                        _self.setFailureStyle('clientTaxContrbSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientTaxContrbSvc");
                    })
            },

            handleClientDistSvc: function () {
                var _self = this;
                _self.disableButton("btnClientDistSvc");
                _self.$('#clientDistSvcStatus').text('');
                _self.executeService(config.monClientDistSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[8] = true;
                        _self.setSuccessStyle('clientDistSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientDistSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[8] = false;
                        _self.setFailureStyle('clientDistSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientDistSvc");
                    })
            },

            handleClientFiduciariesSvc: function () {
                var _self = this;
                _self.disableButton("btnClientFiduciariesSvc");
                _self.$('#clientFiduciariesSvcStatus').text('');
                _self.executeService(config.monClientFiduciariesSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[9] = true;
                        _self.setSuccessStyle('clientFiduciariesSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnClientFiduciariesSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[9] = false;
                        _self.setFailureStyle('clientFiduciariesSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnClientFiduciariesSvc");
                    })
            },

            handleAccountSvc: function () {
                var _self = this;
                _self.disableButton("btnAccountSvc");
                _self.$('#accountSvcStatus').text('');
                _self.executeService(config.monAccountSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[10] = true;
                        _self.setSuccessStyle('accountSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnAccountSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[10] = false;
                        _self.setFailureStyle('accountSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnAccountSvc");
                    })
            },

            handleDistributorsSvc: function () {
                var _self = this;
                _self.disableButton("btnDistributorsSvc");
                _self.$('#distributorsSvcStatus').text('');
                _self.executeService(config.monDistributorsSvc)
                    .then(function (response) {
                        svcCount = svcCount + 1;
                        svcStatus[11] = true;
                        _self.setSuccessStyle('distributorsSvcStatus');
                        _self.setOverallStatus();
                        _self.enableButton("btnDistributorsSvc");
                    })
                    .fail(function (error) {
                        svcCount = svcCount + 1;
                        svcStatus[11] = false;
                        _self.setFailureStyle('distributorsSvcStatus', error);
                        _self.setOverallStatus();
                        _self.enableButton("btnDistributorsSvc");
                    })
            },

            handleServiceAll: function () {
                this.resetAll();
                this.disableButton("btnServiceAll");
                this.$('#allservicestatus').text('');
                this.handleClientListSvc();
                this.handleDistrbOverviewSvc();
                this.handleClientActGrpsSvc();
                this.handleClientEmploymentSvc();
                this.handleClientCapRegSvc();
                this.handleGroupsSvc();
                this.handleClientProfileListSvc();
                this.handleClientTaxContrbSvc();
                this.handleClientDistSvc();
                this.handleClientFiduciariesSvc();
                this.handleAccountSvc();
                this.handleDistributorsSvc();
            },

            setOverallStatus: function () {                
                if (svcCount == 12) {
                    this.enableButton("btnServiceAll");
                }
                overallStatus = true;
                for (i = 0; i < svcStatus.length; i++) {
                    overallStatus = overallStatus && svcStatus[i];
                }

                if (overallStatus == true)
                    this.setSuccessStyle('allservicestatus');
                else if (overallStatus == false)
                    this.setFailureStyle('allservicestatus');
                
            },

            resetAll: function () {
                svcCount = 0;
                overallStatus = true;
                svcStatus = [];
            },

            disableButton: function (btnName) {
                $("#" + btnName).attr("disabled", true);
            },

            enableButton: function (btnName) {
                $("#" + btnName).attr("disabled", false);
            },

            setSuccessStyle: function (control) {
                if (control == "allservicestatus")
                    this.$('#' + control).text('Overall - Success');
                else
                    this.$('#' + control).text('Success');
                this.$('#' + control).addClass('status-success');
                this.$('#' + control).removeClass('status-fail');
            },
            setFailureStyle: function (control, error) {
                if (error != null)
                    var errorMsg = "Fail (" + error.status + " - " + error.statusText + ")";
                else
                    var errorMsg = "Fail";

                if (control == "allservicestatus")
                    errorMsg = "Overall - Fail";
                this.$('#' + control).text(errorMsg);
                this.$('#' + control).removeClass('status-success');
                this.$('#' + control).addClass('status-fail');
            },

            executeService: function (svcURL, btnName, statusName) {
                return $.ajax({
                    headers: { 'consumer': config.consumerId },
                    url: svcURL,
                    type: "GET",
                    dataType: 'json'
                });
            }
        })

        var appView = new monitorView();
      
    });