define(['jquery', 'appcommon/commonutility'], function ($, Util) {

    NativeAdaptor = function () {
        self = this;

        // public methods

        this.notifyContactUpdated = function () {
            if (isMessageHandlerAvailable('contactUpdated')) {
                messageHandlers().contactUpdated.postMessage({});
                return true;
            } else {
                return false;
            }
        }

        this.notifyTasksUpdated = function () {
            if (isMessageHandlerAvailable('tasksUpdated')) {
                messageHandlers().tasksUpdated.postMessage({});
                return true;
            } else {
                return false;
            }
        }

        this.notifyContactSwitched = function (newContactNamecontact) {
            if (isMessageHandlerAvailable('contactSwitched')) {
                messageHandlers().contactSwitched.postMessage({name: contactName});
                return true;
            } else {
                return false;
            }
        }

        this.notifyNewActivityRequested = function (subject, isTask) {
            if (isMessageHandlerAvailable('newActivityRequested')) {
                messageHandlers().newActivityRequested.postMessage({subject: subject, isTask: isTask == null ? false: isTask});
                return true;
            } else {
                return false;
            }
        }

        this.notifyNewNoteRequested = function () {
            if (isMessageHandlerAvailable('newNoteRequested')) {
                messageHandlers().newNoteRequested.postMessage({});
                return true;
            } else {
                return false;
            }
        }

        this.getNativeContext = function (callback) {
            if (isMessageHandlerAvailable('getContext')) {
                window.ampfPracticeTechNativeContextCallback = callback;
                messageHandlers().getContext.postMessage({});
                return true;
            } else {
                var context = getSimulatedNativeContext();
                if (context) {
                    callback(context);
                    return true;
                }
            }
            return false;
        }

        this.isEmbedded = function() {
            return isRunningEmbedded();
        }

       function isRunningEmbedded() {
            return document.cookie.indexOf('pt-embedded') > -1;
        }

        function messageHandlers() {
            return window.webkit ? window.webkit.messageHandlers : null;
        }

        function isMessageHandlerAvailable(handlerName) {
            return isRunningEmbedded() && messageHandlers() != null && messageHandlers()[handlerName] != null;
        }

        function getSimulatedNativeContext() {
            var ctxCookieValue = Util.readCookie('pt-simulated-native-context');
            return ctxCookieValue == null ? null : JSON.parse(ctxCookieValue);
        }

    }

    return new NativeAdaptor();

});