'use strict';

var registeredBankInitLoader = function (RegisteredBankModel, transactEventConstants, transactEvents, $loader) {
    
    var registeredBankInitLoader = {
        loadAllServices : function (scope) {                    	

            function regBankSuccess (data) {
                RegisteredBankModel.setRegisteredBank(data);
                transactEvents.transact.publishRegisteredBank(scope);
            }

            function handleFailure () {
                console.log('handleFailure');
            }

            $loader.start();
            RegisteredBankModel.fetchRegisteredBank()
            .then(regBankSuccess, handleFailure)
            .finally(function() {
                $loader.stop();
            });  
        }
    };
    return registeredBankInitLoader;
};

registeredBankInitLoader.$inject = ['RegisteredBankModel', 'transactEventConstants', 'transactEvents', '$loader'];
module.exports = registeredBankInitLoader;
