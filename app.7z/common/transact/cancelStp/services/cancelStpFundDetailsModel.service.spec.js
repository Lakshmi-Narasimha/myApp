'use strict';
describe('Service: fticCancelStpFundDetailsModel ', function() {
	var fticCancelStpFundDetailsModel,httpBackend,$window,fetchSelectFundDetailsPromise,validateCSTPPromise;

	var fundDetailsResponse = {
	"stpSummary": [
		{
			"trxnNo": "SS000176",
			"totalInsallNo": "155",
			"startDate": "28/11/2010",
			"sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
			"sourceAccNo": "1689900886175",
			"nextTiggerDate": "28/04/2017",
			"frequency": "Monthly",
			"endDate": "28/10/2019",
			"destFundDesc": "Franklin India Savings Plus Fund Retail Option",
			"destAccNo": "1729900886175",
			"cancelDate": "28/04/2017",
			"balInsallNo": "31",
			"amount": "2000",
			"alertFlag": "Y",
			"alertDays": "7"
		},
		{
			"trxnNo": "SS000976",
			"totalInsallNo": "90",
			"startDate": "07/12/2010",
			"sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
			"sourceAccNo": "1689900886175",
			"nextTiggerDate": "07/05/2017",
			"frequency": "Monthly",
			"endDate": "07/10/2019",
			"destFundDesc": "Franklin India Savings Plus Fund Retail Option",
			"destAccNo": "1729900886175",
			"cancelDate": "07/05/2017",
			"balInsallNo": "30",
			"amount": "2000",
			"alertFlag": "N",
			"alertDays": "7"
		},
		{
			"trxnNo": "SS000976",
			"totalInsallNo": "90",
			"startDate": "07/12/2010",
			"sourceFundDesc": "Franklin India Dynamic P E Ratio Fund Of Funds",
			"sourceAccNo": "1689900886175",
			"nextTiggerDate": "07/05/2017",
			"frequency": "Monthly",
			"endDate": "07/10/2019",
			"destFundDesc": "Franklin India Savings Plus Fund Retail Option",
			"destAccNo": "1729900886175",
			"cancelDate": "07/05/2017",
			"balInsallNo": "30",
			"amount": "2000",
			"alertFlag": "N",
			"alertDays": "7"
		}
	],
	"folioId": "14512366"
	};

	var validateCSTPResponse = [
		{
			"urnNo": "",
			"trDate": "",
			"webRefNo": "STP000735",
			"transactionValidated": "True",
			"folioId": "14512366",
			"accountNo": "1689900886175"
		}
	];

	var selectedInvestor = {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 14512366,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,_fticCancelStpFundDetailsModel_){	
		fticCancelStpFundDetailsModel = _fticCancelStpFundDetailsModel_;		
        httpBackend = $httpBackend;		        
       
		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the functions fetchSelectFundDetails,validateCSTP',function(){
		expect(fticCancelStpFundDetailsModel.fetchSelectFundDetails).toBeDefined();
		expect(fticCancelStpFundDetailsModel.validateCSTP).toBeDefined();		
	});

	describe("fetchSelectFundDetails promise",function(){
		beforeEach(inject(function() {						
			fetchSelectFundDetailsPromise = fticCancelStpFundDetailsModel.fetchSelectFundDetails(selectedInvestor);				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/clients/stpSummary?folioId=14512366&guId=878').respond(200,fundDetailsResponse);
			fetchSelectFundDetailsPromise.then(function(response){														
				expect(response.stpSummary.length).toBe(3);							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/clients/stpSummary?folioId=14512366&guId=878').respond(400,failureResponse);
			fetchSelectFundDetailsPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	describe("validateCSTP promise",function(){
		beforeEach(inject(function() {						
			validateCSTPPromise = fticCancelStpFundDetailsModel.validateCSTP();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectPOST('http://localhost:3030/transact/cancelStp?guId=878').respond(200,validateCSTPResponse);
			validateCSTPPromise.then(function(response){														
				expect(response[0].webRefNo).toBe('STP000735');							 
				done();
			});

			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectPOST('http://localhost:3030/transact/cancelStp?guId=878').respond(400,failureResponse);
			validateCSTPPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});
});	
