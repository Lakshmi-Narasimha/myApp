coa = coa || {};
define(['jquery', 'underscore', 'backbone','backboneRelational'], function($, _, Backbone,backboneRelational) {
	coa.models.Account = Backbone.RelationalModel.extend({
	defaults : {
		checked : false,
		accountId : '',
		accountNumberFmtd : '',
		ownership : '',
		type : '',
		currentAddress : ''
	}

});

});