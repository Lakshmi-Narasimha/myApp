export class AIResponse {

  responseId : string = null;
  intentId : string = null;
  response : string = null;
  clientId : number = null;


}
