'use strict';

<<<<<<< HEAD
var smartSolCustomizeModel = function ($state, planSmartSolution, recommendedPlanModelService,paperlessModel) {
=======
var smartSolCustomizeModel = function ($state, planSmartSolution, $timeout, recommendedPlanModelService, paperlessModel) {
>>>>>>> ftic-inv-sprint6
    return {
        template: require('./smartSolCustomizeModel.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            formCustomized: "=",
            tabName: '=',
            smartSolInvestor:'@'
        },
        controller:['$scope', function ($scope) {
            /*$scope.status = $scope.allOpen;*/

            /*$scope.investmentDetails = [];
            planSmartSolution.callParamsCodes({'groupId': 'InvestmentType'}).then(function (data) {
                
                angular.forEach(data.codeValueList, function (obj, ind){
                    var investment = {};
                    investment.title = obj.code;
                    $scope.investmentDetails.push(investment);
                })
            }, function (data) {

            });*/
<<<<<<< HEAD

            var planInputDet = recommendedPlanModelService.getPlanInputDtls();
            
            if(planInputDet.age >= 20 && planInputDet.age < 60){
                if(planInputDet.investmentTenure < 5){
=======
            //planSmartSolution.setSliderMaxLimit(80);
            //console.log("getMaxValue...", planSmartSolution.getSliderMaxLimit());
            var planInputDet = recommendedPlanModelService.getPlanInputDtls();
            console.log("planInputDetailsentered....", planInputDet);
            if(planInputDet.age >= 20 && planInputDet.age <= 60){
                if(planInputDet.investmentTenure <= 5){
>>>>>>> ftic-inv-sprint6
                    planSmartSolution.setSliderMaxLimit(0);
                    planSmartSolution.setSliderDisable(true);
                }
                else if(planInputDet.investmentTenure > 5){
                    planSmartSolution.setSliderDisable(false); 
                    if(planInputDet.age <= 50){
                       planSmartSolution.setSliderMaxLimit(100);
                    }
                    else{
                        planSmartSolution.setSliderMaxLimit(65);
                    }
                }
            }
            else if(planInputDet.age > 60){
<<<<<<< HEAD
               if(planInputDet.investmentTenure < 5){
=======
               if(planInputDet.investmentTenure <= 5){
>>>>>>> ftic-inv-sprint6
                    planSmartSolution.setSliderMaxLimit(0);
                    planSmartSolution.setSliderDisable(true); 
                } 
                else if(planInputDet.investmentTenure > 5){
                   planSmartSolution.setSliderMaxLimit(25); 
                   planSmartSolution.setSliderDisable(false); 
                }
            }
            $scope.investmentDetails = [{
                    title: "Monthly",
                    message: "",
                    value: "",
                    name: "investmentDetails",
                    selected: "",
                    isRequired : true
                },
                {
                    title: "Annually",
                    message: "",
                    value: "",
                    name: "investmentDetails",
                    selected: "",
                    isRequired : true
                },
                {
                    title: "One-time",
                    message: "",
                    value: "",
                    name: "investmentDetails",
                    selected: "",
                    isRequired : true
                },
                {
                    title: "Combo",
                    message: "",
                    value: "",
                    name: "investmentDetails",
                    selected: "",
                    isRequired : true
                }];
            if($scope.smartSolInvestor === 'smartSolInvestor') { 
                $scope.monthlyInputObject = {
                    key: "monthly",
                    text: "",
                    name: "monthlyInput",
                    type: "text",
                    isEditable: true,
                    maxlength: 6,
                    // isRequired:true,/^[0-9]*$/
                    //pattern: /^[0-9]{1,6}$/,/*/^500$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$|^[5-9]{1}[0-9]{2}$/*/
                    value: ""
                };
                $scope.annualInputObject = {
                    key: "annually",
                    text: "",
                    name: "annualInput",
                    type: "text",
                    isEditable: true,
                    maxlength: 6,
                    // isRequired:true,
                    //pattern: /^[0-9]{1,6}$/,/*/^500$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$|^[5-9]{1}[0-9]{2}$/*/
                    value: ""
                };
                $scope.oneTimeInvestmentObject = {
                    key: "oneTime",
                    text: "",
                    name: "oneTimeInput",
                    type: "text",
                    isEditable: true,
                    maxlength: 9,
                    value: "",
                    // isRequired:true,
                    //pattern: /^[0-9]{1,9}$//*/^1000$|^[1-9]{1}[0-9]{8}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$/*/
                };
            } else {
                $scope.monthlyInputObject = {
                    key: "monthly",
                    text: "",
                    name: "monthlyInput",
                    type: "number",
                    isEditable: true,
                    maxlength: 6,
                    // isRequired:true,/^[0-9]*$/
                    pattern: /^[0-9]{1,6}$/,/*/^500$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$|^[5-9]{1}[0-9]{2}$/*/
                    value: ""
                };
                $scope.annualInputObject = {
                    key: "annually",
                    text: "",
                    name: "annualInput",
                    type: "number",
                    isEditable: true,
                    maxlength: 6,
                    // isRequired:true,
                    pattern: /^[0-9]{1,6}$/,/*/^500$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$|^[5-9]{1}[0-9]{2}$/*/
                    value: ""
                };
                $scope.oneTimeInvestmentObject = {
                    key: "oneTime",
                    text: "",
                    name: "oneTimeInput",
                    type: "number",
                    isEditable: true,
                    maxlength: 9,
                    value: "",
                    // isRequired:true,
                    pattern: /^[0-9]{1,9}$//*/^1000$|^[1-9]{1}[0-9]{8}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$/*/
                };
            }

            
            $scope.monthlyInputObject.value = parseInt(planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().monthlySIP));
            $scope.annualInputObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().annualSIP);
            $scope.oneTimeInvestmentObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().lumpsum);
            if($scope.smartSolInvestor === 'smartSolInvestor') { 
                $scope.stepUpObject = {
                    key: "stepUp",
                    text: "",
                    name: "stepUpInput",
                    type: "text",
                    isEditable: true,
                    isRequired: true,
                    maxlength: 2,
                    //pattern: /*/^[0-9]{1,2}$/,*//^5$|^[0-9]{1,2}[5-5]{1}$|^[1-9]{1,2}[0-0]{1}$|^[1-9]{1,2}$/,
                    value: ""
                }
            } else {
                $scope.stepUpObject = {
			key: "stepUp",
			text: "",
			name: "stepUpInput",
			type: "number",
			isEditable: true,
			disable:false,
			// isRequired: true,
			// maxlength: 2,
			// pattern: /*/^[0-9]{1,2}$/,*//^5$|^[0-9]{1,2}[5-5]{1}$|^[1-9]{1,2}[0-0]{1}$|^[1-9]{1,2}$/,
			pattern: /^\d+$/,
			value: ""
		};
            }
            //$scope.stepUpObject.value = 0;
            $scope.expectedReturnsObject = {
                key: "expectedReturns",
                text: "",
                name: "expectedReturnsInput",
                type: "number",
                isEditable: true,
                maxlength: 2,
                pattern: /^[0-9]{1,2}/,
                isRequired: true,
                value: ""
            };

            $scope.comboTypes = [
                {
                    label: "Investment Amount",
                    value: "investment",
                    selected: true
                },
                {
                    label: "Expected Return",
                    value: "expectReturn",
                    selected: false
                }
            ];
            $scope.radios = {};
            $scope.radios.selectedVal = 'investment';
            $scope.investChange = false;
            $scope.listenChange = function () {
                console.log($scope.radios.selectedVal);
                $timeout(function () {
                    $scope.investChange = $scope.radios.selectedVal == 'expectReturn';
                }, 0);

            };

            /*$scope.withdrawalObject = {
                key: "withdrawal",
                text: "",
                name: "withdrawalAmount",
                type: "number",
                min:1000,
                isEditable: false,
                maxlength: 9,
                pattern: /^[1-9]{1}[0-9]{1,8}$/,*//*//*^1000$|^[1-9]{1}[0-9]{8}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$*//*//*
                value: "",
                messages:"Withdrawal Amount can contain upto 9 digits only"
            };
            $scope.withdrawalObject.value = 0;*/
            // $scope.goBack=function(){
            //   $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan');
            // }

            $scope.$on('investmentType', function (event, data) {
                $scope.investmentType = data.title;
                if ($scope.investmentType == 'Combo') {
                    $scope.monthlyInputObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().monthlySIP);
                    $scope.annualInputObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().annualSIP);;
                    $scope.oneTimeInvestmentObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().lumpsum);
                    $scope.stepUpObject.disable = false;
                } else if($scope.investmentType == 'Annually'){
                    $scope.annualInputObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().annualSIP);
                    $scope.monthlyInputObject.value = "";
                    $scope.oneTimeInvestmentObject.value = "";
                    $scope.stepUpObject.disable = false;
                } else if($scope.investmentType == 'One-time'){
                    $scope.monthlyInputObject.value = "";
                    $scope.annualInputObject.value = "";
                    $scope.stepUpObject.value = ""; //added for 5225 defect fix 
                    $scope.stepUpObject.disable = true;  //added for 5225 defect fix                 
                    $scope.oneTimeInvestmentObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().lumpsum);
                } else if($scope.investmentType == 'Monthly'){
                    $scope.monthlyInputObject.value = planSmartSolution.replaceComma(planSmartSolution.getSmartSolutionDetails().monthlySIP);
                    $scope.annualInputObject.value = "";
                    $scope.oneTimeInvestmentObject.value = "";
                    $scope.stepUpObject.disable = false;
                }
            });

            $scope.showTab = !($scope.tabName == "buildplan");
            //if ($scope.tabName == "buildplan") {
            //    $scope.showTab = false;
            //}
            //else
            //    $scope.showTab = true;
            $scope.WithdrawalInputChanged = function(){
                if($scope.withdrawalObject.value) {
                    $scope.withdrawalObject.value = $scope.withdrawalObject.value.replace(/[&\/\\#,+()$~%.'":*?!_\-<>{}^@a-zA-Z]/g,'');
                    $scope.withdrawalObject.value = parseInt($scope.withdrawalObject.value);
                } else {
                    $scope.withdrawalObject.value = parseInt($scope.withdrawalObject.value);
                }
            }
            $scope.setUpInputChanged = function() {
                if($scope.stepUpObject.value) {
                    $scope.stepUpObject.value = $scope.stepUpObject.value.replace(/[&\/\\#,+()$~%.'":*?!_\-<>{}^@a-zA-Z]/g,'');
                    $scope.stepUpObject.value = parseInt($scope.stepUpObject.value);
                } else {
                    $scope.stepUpObject.value = parseInt($scope.stepUpObject.value);
                }
            }
            $scope.annuallytextInputChanged = function() {
                if($scope.annualInputObject.value) {
                    $scope.annualInputObject.value = $scope.annualInputObject.value.replace(/[&\/\\#,+()$~%.'":*?!_\-<>{}^@a-zA-Z]/g,'');
                    $scope.annualInputObject.value = parseInt($scope.annualInputObject.value);
                } else {
                    $scope.annualInputObject.value = parseInt($scope.annualInputObject.value);
                }
            }
            $scope.monthlytextInputChanged = function() {
                if($scope.monthlyInputObject.value) {
                    $scope.monthlyInputObject.value = $scope.monthlyInputObject.value.replace(/[&\/\\#,+()$~%.'":*?!_\-<>{}^@a-zA-Z]/g,'');
                    $scope.monthlyInputObject.value = parseInt($scope.monthlyInputObject.value);
                } else {
                    $scope.monthlyInputObject.value = parseInt($scope.monthlyInputObject.value);
                }
            }
            $scope.oneTimeTextInputChanged = function() {
                if($scope.oneTimeInvestmentObject.value) {
                    $scope.oneTimeInvestmentObject.value = $scope.oneTimeInvestmentObject.value.replace(/[&\/\\#,+()$~%.'":*?!_\-<>{}^@a-zA-Z]/g,'');
                    $scope.oneTimeInvestmentObject.value = parseInt($scope.oneTimeInvestmentObject.value);
                } else {
                    $scope.oneTimeInvestmentObject.value = parseInt($scope.oneTimeInvestmentObject.value);
                }
            }
            $scope.multiplesOfFiveFn = function() {
                if($scope.stepUpObject.value && ($scope.stepUpObject.value < 5 || $scope.stepUpObject.value > 100))
                {
                    return false;
                }
                else if(($scope.stepUpObject.value) > 5 && ($scope.stepUpObject.value)%5 !== 0) {
                    $scope.multiplesOfFive="Step-up(%) value should be in multiples of 5. Please enter Valid value";
                    return false;
                }
                else{
                    $scope.multiplesOfFive = null;
                    return true;
                }                    
            }
            $scope.apply = function () {
                
                if ($scope.formCustomized.$valid && $scope.multiplesOfFiveFn() && (($scope.investmentType ==="Combo" && $scope.monthlyInputObject.value >=500 && $scope.annualInputObject.value>=500 && $scope.oneTimeInvestmentObject.value>=5000) || ($scope.investmentType !=="Combo" && ($scope.monthlyInputObject.value >=500 || $scope.annualInputObject.value>=500 || $scope.oneTimeInvestmentObject.value>=5000)))) {
                    if ($scope.tabName == "buildplan") {
                        $scope.slider_floor_ceil.value = "";
                    }
                    $scope.customizationDetails = {
                        investmentType: $scope.investmentType,
                        monthly: $scope.monthlyInputObject.value,
                        annually: $scope.annualInputObject.value,
                        onetime: $scope.oneTimeInvestmentObject.value,
                        stepUp: $scope.stepUpObject.value || '',
                        expectedReturns: $scope.expectedReturnsObject.value,
                        //withdrawl: $scope.withdrawalObject.value,
                        equityExposure: $scope.slider_floor_ceil.value,
                        currentState: $state.current.name
                    };
<<<<<<< HEAD
                    paperlessModel.isCustPlan = true;
=======
                    paperlessModel.isCustPlan=true;
>>>>>>> ftic-inv-sprint6
                    $scope.multiplesOfFiveFn();
                    $scope.$emit("customizeDetailsApply", $scope.customizationDetails);

                    
                }
            };

            $scope.cancel = function () {
                
                $scope.$emit("customizeDetailsCancel");
            }
        }]
    };
};
<<<<<<< HEAD
smartSolCustomizeModel.$inject = ['$state', 'planSmartSolution', 'recommendedPlanModelService','paperlessModel'];
module.exports = smartSolCustomizeModel;
=======
smartSolCustomizeModel.$inject = ['$state', 'planSmartSolution', '$timeout', 'recommendedPlanModelService','paperlessModel'];
>>>>>>> ftic-inv-sprint6
