/**
 * @ngdoc property
 * @name fticQuickLinks Directive
 * @requires advisorDashboardDetailsModel
 * @requires eventConstants
 * @requires advisorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Displays the Quick Actions section
 *
 **/


'use strict';

var fticQuickLinks = function() {
	return {
            template: require('./quickLinks.html'),
            restrict: 'E',
            replace: true,
            scope: {
                quicklinks : '=',
                moduletype : '@'
            },
            controller: function(){
                              
            },
            link: function(){

            }
        };
};

fticQuickLinks.$inject = [];
module.exports = fticQuickLinks;