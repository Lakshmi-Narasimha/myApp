/**
 * @ngdoc property
 * @name fticRedemptionReviewStatus Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Status.
 *
 **/
'use strict';

var dtpTxnDetails = function (transactModel, $filter) {
    return {
        template: require('./dtpTxndetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function ($scope, $element, $attrs) {
            var dtpDetails = transactModel.getTransactDetails().investorDetails;
            var sourceDetails=transactModel.getTransactDetails().switchDetails;
            var destinationDetails=transactModel.getTransactDetails().fundDetails;
            var transConf = transactModel.getTransactConfirm();
            var datefilter = $filter('date');
            //console.log(swpDetails);
            $scope.keyValuePair = [
                {
                    key: "FolioNo",
                    text: "Folio No.",
                    value: dtpDetails.folioId
                },
                {
                    key: "SourceFund",
                    text: "Source Fund",
                    value: destinationDetails.fmDescription
                },
                 {
                    key: "SourceAccountNo",
                    text: "Account Number",
                    value: destinationDetails.tschvalAccno
                },
                 {
                    key: "TransactionRefNo",
                    text: "Transaction Reference No",
                    value: transConf.transactionRefNo
                },

                {
                    key: "ReqDateAndTime",
                    text: "Request Date and Time",
                    value: datefilter(transConf.transDateTime, 'dd MMMM yyyy, hh:mm a')
                },
                 {
                    key: "DestinationFund",
                    text: "Destination Fund",
                    value: sourceDetails.destinationFund.fundName 
                },
                {
                    key: "DividendOption",
                    text: "Dividend Option",
                    value: destinationDetails.dividendOption
                },
                
            ];
        },
        link: function (scope, iElement, iAttrs, controller) {

        }
    };
};

dtpTxnDetails.$inject = ['transactModel', '$filter'];
module.exports = dtpTxnDetails;
