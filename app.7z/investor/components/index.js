/**
 *@ngdoc object
 *@name advisor.module:Components
 *@description
 * <p>
 * It has the app level common components like sidenav, sticky header etc
 * </p>
 * 
 */

'use strict';
// Home View
module.exports = angular.module('investor.components', [])
	.directive('invErrorMessage', require('./inverrormessage/invErrorMessage.directive'))
    .directive('fticInvestmentSummaryGrids', require('./investmentsummarydetails/investmentSummaryGrids.directive'))
    .directive('fticInvestorSelectFolio', require('./investselectfolio/investorSelectFolio.directive'))
    .directive('fticInvestWarningPopup', require('./investwarningpopup/investWarningPopup.directive'))
    .directive('fticInvestConfirmPopup', require('./investconfirmpopup/investConfirmPopup.directive'))
    .directive('fticPaymentDetails', require('./paymentDetails/paymentDetails.directive'))
    .directive('fticPurchasesDetails', require('./purchasesDetails/purchasesDetails.directive'))
    .directive('fticNewEmandateAccountBankDetails', require('./newAccountBankDetails/newAccountBankDetails.directive'))
   .directive('fticInvEditableKeyValuePanel', require('./invEditableKeyValuePanel/invEditableKeyValuePanel.directive'))
   .directive('fticInvRedeemDetails', require('./invRedeemDetails/invRedeemDetails.directive'))
   .directive('fticPurchaseInvestPreferPanel', require('./investmentPreferencePanel/investPreferPanel.directive'))
   .directive('fticInvEmandateDetails', require('./invEmandateDetails/invEmandateDetails.directive'))
   .factory('purchasesDetailsFactory', require('./purchasesDetails/purchasesDetails.factory'));


// .directive('fticLeftNav', require('./leftnav/leftnav.directive'))
// .directive('fticStickyHeader', require('./stickyheader/stickyHeader.directive'))
// .directive('fticTextTile', require('./texttile/textTile.directive'));
