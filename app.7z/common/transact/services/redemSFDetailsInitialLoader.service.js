'use strict';

var SelectFundInitLoader = function (selectFundModel, transactEvents, transactEventConstants, fticLoggerMessage, loggerConstants) {
    
    var SelectFundInitLoader = {
    	_isServicesData: false,     
        loadAllServices : function (scope,selectedInv) {                    	

             selectFundModel.fetchSelectFundDetails(selectedInv)
             .then(selectFundDetailsSuccess, handleFailure);

             function selectFundDetailsSuccess(data) {
             	selectFundModel.setSelectFundGridDtls(data[0].result);                           
             	transactEvents.transact.publishselectFundDetails(scope);
             };
             function handleFailure(data) {
             	console.error('handleFailure');
                SelectFundInitLoader._isServicesData = false;
             };
            
        },
        setSelectFundDtls : function(obj){
            selectFundModel.setSelectFundDtls(obj);
        }
    };
    return SelectFundInitLoader;
};

SelectFundInitLoader.$inject = ['selectFundModel', 'transactEvents', 'transactEventConstants', 'fticLoggerMessage', 'loggerConstants'];
module.exports = SelectFundInitLoader;
