/**
 * @ngdoc directive
 * @name ftickeyValueVerticalTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - ftickeyValueVerticalTile will display the vertical tiles for "My profile - Grant Access" .
 * 
 *
 **/
'use strict';

var keyValueVerticalTile = function() {
	return {
            template: require('./keyValueVerticalTile.html'),
            restrict: 'E',
            replace: true,
            scope: {
                verticalTileObj: '=',
                myindex: '=?'
            },
            controller: function(){    
                          
            },
            link: function(scope){
                console.log(scope.verticalTileObj);
            }
        };
};

keyValueVerticalTile.$inject = [];
module.exports = keyValueVerticalTile;