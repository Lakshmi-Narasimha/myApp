var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var sendMessageModel = require('./sendMessage.model');
var getMessageModel = require('../getMessage/getMessage.model');
var apiUtils = require('../../common/apiUtils');
var async = require("async");
var myCache = require('../../../api-server');
var proxy = require('../../../config/proxy');

// api route
router.route('/mfchatnode/rest/message')
    .post(function(req, res) {        
        var msgCount = parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"),10) || 0;
        myCache.set(req.session.engagementID+".chatSendMsgCounter", msgCount+1);  
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.uri = sendMessageModel.createRequestUri;
        req.body.RequestParams = req.body.RequestParams || {};
        myCache.set(req.session.engagementID+".mqtt",req.body.RequestParams.mqtt); 
        delete req.body.RequestParams.mqtt;
        var post_data = req.body.RequestParams;       
        var postBody = querystring.stringify(post_data);
        if(post_data.state === 'closed'){
            myCache.set(req.session.engagementID+".closed", true);
            logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + "{'state': 'closed'}" + ' MQTT:' + myCache.get(req.session.engagementID+".mqtt"));
        }else{
            logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + req.body.RequestParams.messageText + ' MQTT:' + myCache.get(req.session.engagementID+".mqtt"));
        }
        
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.session.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };        
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {

            //console.log("proxyResponse.statusCode:", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');            
            logger.general.info(logger.formatOutBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
            if (proxyResponse.statusCode === 200) {                          
				if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                 parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && 
                 parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
	                    myCache.set(req.session.engagementID+".isAssisted", true);
	                    apiUtils.assisted(req,res,function(response) {});
	                    apiUtils.saveMDN(req,res,function(response) {});
	            }               
                 logger.general.info(logger.formatInfoMsg(req.session.id, "MQTT flag: "+ myCache.get(req.session.engagementID+".mqtt") + ", isRecurEnabled: "+ myCache.get(req.session.engagementID+".isRecurEnabled")
                                                            +" with engagementID: " + req.session.engagementID));
                if (myCache.get(req.session.engagementID+".mqtt") === true  && !myCache.get(req.session.engagementID+".isRecurEnabled")) {
                    myCache.set(req.session.engagementID+".isRecurEnabled", true);
                    logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop started with EngagementID: "+ req.session.engagementID)); 
                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop started with EngagementID: "+req.session.engagementID));                    
                    async.forever(function(next){                            
                        apiUtils.getMsg(req,res,function(chunk){                            
                            if(myCache.get(req.session.engagementID+".closed")){
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "User closed chat with engagementID "+req.session.engagementID));
                                logger.general.info(logger.formatInfoMsg(req.session.id, "User closed chat with engagementID "+req.session.engagementID));
                                 if (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && 
                                 parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 4) {
                                        apiUtils.surveyEligibility(req, res, function(response) {
                                            if(response.eligible === true){
                                                var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                                var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                                getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                                getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                                getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                                req.session.getMsgRes = getMessageModel.surveyResponse;                                                  
                                                apiUtils.sendCmd(req, res, function(response) {});                                                
                                                logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.surveyResponse));
                                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                                logger.general.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                            }else{
                                                req.session.getMsgRes = getMessageModel.endResponse;                                                 
                                                apiUtils.sendCmd(req, res, function(response) {});
                                                logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                                                logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                            }
                                            apiUtils.cleanMFCCache(req.session.engagementID);
                                        }); 
                                    }else{                   
                                        req.session.getMsgRes = getMessageModel.endResponse; 
                                        apiUtils.sendCmd(req, res, function(response) {});
                                        apiUtils.cleanMFCCache(req.session.engagementID);
                                        logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse)); 
                                        logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID " +req.session.engagementID));
                                        logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID "+req.session.engagementID));                 
                                    }                                                     
                                logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID: "+ req.session.engagementID)); 
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID: "+ req.session.engagementID));                              
                                myCache.set(req.session.engagementID+".mqtt", false);
                                
                                next("chat closed");
                            }else if(myCache.get(req.session.engagementID+".timeout")==='true'){
                                logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID due to timeout: "+ req.session.engagementID));
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID due to timeout: "+ req.session.engagementID));
                                req.session.getMsgRes = getMessageModel.timeoutResponse; 
                                apiUtils.sendCmd(req, res, function(response) {});
                                apiUtils.cleanMFCCache(req.session.engagementID);
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.timeoutResponse));  
                                next("chat closed");
                            }else{
                                if(apiUtils.handleGetMessageRes(req, res, chunk)){
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID: "+ req.session.engagementID));
                                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID: "+ req.session.engagementID));                                   
                                    myCache.set(req.session.engagementID+".mqtt", false); 
                                    next("chat closed");
                                }else{
                                   next();                                  
                                }
                               
                            }                            
                        });                                              
                    },
                    
                    function(err){
                        if(err){
                            logger.general.info(logger.formatInfoMsg(req, "Get Message loop ended "+JSON.stringify(err)));
                        }                         
                    }
                );
                  /*
                    apiUtils.getMsgMultiRecursiveCall(req, res, function(chunk) {
                       
                    });
                    */
                    //res.send({});
                    logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
                     res.send(sendMessageModel.response);
                } else {
                    //req.session.chatSendMsgCounter++;
                    //res.send({});
                    //logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop not started with EngagementID: "+ req.session.engagementID)); 
                    logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
                     res.send(sendMessageModel.response);
                    //res.end();
                }
            } else {
                 var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id)); 
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(sendMessageModel.response); 
            }
            proxyResponse.on('error', function(err) {
               logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                res.send(sendMessageModel.response);
            });
        });
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
