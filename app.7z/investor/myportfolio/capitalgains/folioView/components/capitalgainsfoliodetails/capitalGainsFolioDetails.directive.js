/**
 * @ngdoc property
 * @name fticCapitalGainsFolio Directive
 * @requires cgAccDetModel
 * @description
 *
 * - Displays the Capital Gains Folio Details
 *
 **/


'use strict';

var fticCapitalGainsFolioDetails = function(cgAccDetModel) {
	return {
            template: require('./capitalGainsFolioDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {},
            controller: function($scope){
                $scope.folioNumber = cgAccDetModel.getAccFolioNumber();
                $scope.folioGridLength = cgAccDetModel.getCgFoliodetails().length;
                $scope.accountStatementData = [];
                var gridRow = {};
                angular.forEach(cgAccDetModel.getCgFoliodetails(), function (obj) {
                    gridRow = {};
                    gridRow.fundName = obj.fundName;
                    gridRow.accountNo = obj.accountNo;
                    gridRow.purchase = obj.purchase;
                    gridRow.redemption = obj.redemption;
                    gridRow.capital = obj.capital;
                    gridRow.taxded = obj.taxded;
                    $scope.accountStatementData.push(gridRow);
                });

                $scope.gridOptions= {};
                // var statusTemplate = '<div uib-popover-template="\'veiwCompTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" popover-append-to-body="false" class="fti-view-composition icon-fti_plusSign"></div>' +
                //   '<script type="text/ng-template" id="veiwCompTemplate.html">' +
                //   '<div><button type="button" ng-click="grid.appScope.$emit(\'cgfolioac\', {accountNo : row.entity.accountNo,fundName:row.entity.fundName})" class="btn panel-orange-btn m0">Account Statement</button></div></script>';

                $scope.gridOptions.columnDefs = [
                    //{ field: 'fundName',displayName:'', width:"45", cellTemplate: statusTemplate, headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
                    
                    { field: 'accountNo', width:'175', enableSorting:false, headerCellTemplate:'headrTempAccount', headerCellClass: 'fti-grid-sortDisabledHeader fti-grid-headercell', pinnedLeft:true},
                    { field: 'fundName', width:'200', enableSorting:false, headerCellTemplate:'headrTempFund',  headerCellClass: 'fti-grid-sortDisabledHeader fti-grid-headercell'},
                    { field: 'purchase', width:'400', enableSorting:false, headerCellTemplate : 'headrTempPurchase', cellTemplate:'dataTempPurchase', headerCellClass: 'fti-grid-headercell'},
                    { field: 'redemption',width:'400', enableSorting:false, headerCellTemplate : 'headrTempRedemption', cellTemplate:'dataTempRedemption', headerCellClass: 'fti-grid-headercell'},
                    { field: 'capital',width:'400', enableSorting:false, headerCellTemplate : 'headrTempCap', cellTemplate:'dataTempCap', headerCellClass: 'fti-grid-headercell'},
                    { field: 'taxded',width:'250', enableSorting:false, headerCellTemplate : 'headrTempTax', cellTemplate:'dataTempTax', headerCellClass: 'fti-grid-headercell'}
                ];
              
            }
        };
};

fticCapitalGainsFolioDetails.$inject = ['cgAccDetModel'];
module.exports = fticCapitalGainsFolioDetails;



