/**
 * @ngdoc factory
 * @name Investor Dashboard chart factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var investorDashboardConfig = function() {
    var investorDashboardConfig = {
        chartConfig: function() {
            var chartOptions = {
                'chart': {
                    'type': 'bar',
                    'width': null,
                    'height': 220,
                    'backgroundColor': '#fff',
                    'spacing': [10, 0, 10, 0]
                },
                'title': {
                    'text': ''
                },
                'legend': {
                    'enabled': false
                },
                'xAxis': {
                    // 'tickWidth': 1,
                    // 'lineWidth': 1,
                    // 'lineColor': '#E0E7EF',
                    'title': {
                        'align': 'top',
                        'offset': 0,
                        'rotation': 180,
                        'x': -15,
                        'y': 10,
                        'color': '#333333!important'
                    },
                    'categories': null,
                    'labels': {
                        'style': {
                            'text-transform': 'inherit',
                            'color': '#333333'
                        }
                    }
                },
                'yAxis': {
                    'tickWidth': 1,
                    'lineWidth': 1,
                    'lineColor': '#E0E7EF',
                    'title': {
                        'text': ''
                    },
                    'labels': {
                        'overflow': 'justify'
                    }
                },
                'plotOptions': {
                    'bar': {
                        'dataLabels': {
                            'enabled': true
                        }
                    },
                    'series': {
                        'dataLabels': {
                            'enabled': true,
                            'useHTML': true,
                            'formatter': function() {
                                return '<i class="icon-fti_rupee"></i> ' + this.y + 'L';
                            }
                        }
                    }
                },
                'tooltip': {
                    'enabled': false,
                    'useHTML': true,
                    'style' : { opacity: 0.9},
                    'formatter': function() {
                        return '<b>'+ this.x +'</b>: '+'<i class="icon-fti_rupee"></i><b>' + this.y + '</b>:L';
                    }
                },
                'credits': {
                    'enabled': false
                },
                'series': [{
                    'data': null
                }]
            };

            return chartOptions;
        }

    };
    return investorDashboardConfig;

};

investorDashboardConfig.$inject = [];
module.exports = investorDashboardConfig;
