// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PurchaseSummaryModelSchema = new mongoose.Schema({
    PurchaseSummaryResp: {
        type: Array,
        "default": []
    }
});

var PurchaseSummaryModelLookUp = mongoose.model('PurchaseSummaryModelLookUp', PurchaseSummaryModelSchema);

var PurchaseSummaryModel = new PurchaseSummaryModelLookUp({
    PurchaseSummaryResp : {
        "purchase": {
            "fundWiseData": [
                {
                    "folioNo": "2341621",
                    "fund": "Franklin India Equity Fund - Growth",
                    "familySolutions": "Yes",
                    "totalPurchasedAmount": "23,987"
                },
                {
                    "folioNo": "3852146",
                    "fund": "Franklin India Equity Fund - Growth",
                    "familySolutions": "Yes",
                    "totalPurchasedAmount": "30,987"
                }
            ],
            "grandTotal": "54,974"
        }
     }
});

PurchaseSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating PurchaseSummaryModelLookUp table, please contact admin...');
    } else {
        PurchaseSummaryModelLookUp.remove({}, function(err) {
            console.log('PurchaseSummaryModelLookUp collection removed');
            PurchaseSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PurchaseSummaryModelLookUp table, please contact admin...');
                }
                console.log('PurchaseSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PurchaseSummaryModelLookUp;
