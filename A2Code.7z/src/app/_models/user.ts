export class User {
  userId: number;
  userName: string;
  password: string;
  firstName: string;
  lastName: string;
  isAdmin: boolean;
}
