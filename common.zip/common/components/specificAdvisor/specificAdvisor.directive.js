/**
 * @ngdoc directive
 * @name contentEta
 * @description
 *
 * - contentEta component will display the description and based on the configuration set.
 * 
 *
 **/
'use strict';
var specificAdvisor = function ($filter, advisorSearchModel, guestEventConstants, transactModel, TransactConstant, transactEvents, authenticationService, transactEventConstants, transactNowModel,$loader) {
    return {
        template: require('./specificAdvisor.html'),
        restrict: 'E',
        replace: true,
        scope : {
            advisorForm: '=',
        	advisorDetails:"="
        },
        controller: ['$scope', function ($scope) {
        	var advNamesArray = [],
        	params = {};
        	$scope.advCode = null;
        	$scope.euinOptions = []; //service
        	$scope.advisorDetail = {};
        	var guIdParam = authenticationService.getUser().guId, noEuin = TransactConstant.transact.NO_EUIN, defaultEuin, isEdit = false;

            defaultEuin = [{
                title : noEuin
            }];

            $scope.advisorArnCode = {
                key: 'advisorArnCode',
                text: 'Advisor Name or ARN Code',
                name: $scope.type + 'aadhar',
                isRequired: true,
                type: 'text',
                value: '',
                disable: true
            };

            $scope.subBrokerCode = {
                key: 'subBrokerCode',
                text: 'Sub Broker Code',
                name: 'subBrokerCode',
                type: 'text',
                value: ''
            }; 

            $scope.subBrokerArn = {
                key: 'subBrokerArn',
                text: 'Sub Broker ARN',
                name: 'subBrokerArn',
                type: 'text',
                value: ''
            }; 

            $scope.sectionFilterOptions = {
                text: 'EUIN',
                required : true,
                name : "euin"
            };

            	

        	$scope.euinServiceCall = function(searchQuery){
                $loader.start();
                transactModel.fetchEUINDetails(searchQuery).then(function (data) {
                transactModel.setEUINDetails(data.euins)
                transactEvents.transact.publishEUINDetails($scope);                
                }, function (data) {

                }).finally(function(){
                    $loader.stop();
                });
                params = {};
                params.guId = guIdParam;
            }

        	// Advisor Details for paperless & transactnow
        	$scope.$on('specificAdvisorDetails', function(evt, data){
                var arnDetails = data.code;
        		advNamesArray =  arnDetails.split('~');
                $scope.advCode = advNamesArray[1];

                $scope.advisorArnCode.value = $scope.advCode;
                
                params.distId = advNamesArray[1];
                params.guId = guIdParam;
                $scope.euinServiceCall(params);

                $scope.advisorDetail.code = arnDetails;
                $scope.advisorDetail.advisorArnCode = $scope.advCode;
                $scope.advisorDetail.investorMode = "financial";
                $scope.advisorDetail.euin = "";                              
        	});   
        	

            






            //Function to find the given "value" in a given object array
            $scope.findItemInFilter = function(objArr, value){
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                        return x.title == value;
                }))[0];
                return obj;
            }
            //$scope.defaultEuinSelected = $scope.findItemInFilter($scope.euinOptions, $scope.euinOptions[0].title);          
            //$scope.defaultEuinSelected = $scope.euinOptions[0];
            
            
            $scope.$on(transactEventConstants.transact.EUIN_DTLS,function(event){
                $scope.euinOptions = angular.copy(defaultEuin);
                $scope.advisorDetail.euin = $scope.euinOptions[0].title;
                $scope.defaultEuinSelected = $scope.euinOptions[0];
                $scope.euinData = transactModel.getEUINDetails(); //service                 
                for(var i=0; i< $scope.euinData.length;i++) {      
                    $scope.euinOptions.push({title : $scope.euinData[i]});      
                }
                transactModel.isEuinServiceSuccess = true;
                if($scope.advisorDetail.euin === noEuin){
                    $scope.showNoEuinTnC = true;
                }
                transactModel.setFormattedEUINDetails($scope.euinOptions);   
                advisorSearchModel.setAdvisorDetails($scope.advisorDetail);
                if (transactModel.isPaperless) {
                    transactModel.setAdvDetails($scope.advisorDetail);
                }else{
                    transactNowModel.setInvestPrefer($scope.advisorDetail);
                }
            }); 

            $scope.sectionFilterOptions = {
                required : true,
                name : "euin"
            };

            $scope.$on('EUIN_CHANGED', function(event, selectedValue){
                if(selectedValue.title){
                    $scope.showNoEuinTnC = false;   
                    $scope.advisorDetail.euin = selectedValue.title; 
                    $scope.defaultEuinSelected = selectedValue;
                    if(selectedValue.title == noEuin){
                        $scope.showNoEuinTnC = true;
                    } 
                }              
            });


        }]
    };
};
specificAdvisor.$inject = ['$filter','advisorSearchModel', 'eventConstants', 'transactModel','TransactConstant', 'transactEvents', 'authenticationService','transactEventConstants', 'transactNowModel','$loader'];
module.exports = specificAdvisor;