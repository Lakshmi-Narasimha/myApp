define([
    'applauncher/message',
    'models/globalcontext',
    'config'
    ],function (Message, Context,Config) {
    var targetURL;
    var navURL = Config.defaultNavURL;
    var parent = window.parent;

    var Initialize = function () {

        if (window.addEventListener) {
            window.addEventListener('message', processMessage);
        }
        else if (window.attachEvent) {
            window.attachEvent('onmessage', processMessage);
        }

    };
    var GetContext = function () {
        var message = new Message.GetContextRequest();
        parent.postMessage(JSON.stringify(message), navURL);
    };

    var LaunchApplication = function (targetAppId, targetResource) {
        var message = new Message.LaunchApplication(targetAppId, targetResource)
        parent.postMessage(JSON.stringify(message), navURL);
    };

    var triggerNavigation = function (route) {
        $.event.trigger({
            type: "launchAction",
            message: route,
            time: new Date()
        });
    };

    function processMessage(e) {
        if (e.preventDefault) { e.preventDefault(); }
        else { e.returnValue = false; }
        if (e.origin != navURL)
            // return;
            if (e.data == undefined)
                return
        //deserialize the json message to object
        var recievedMessage = JSON.parse(e.data);        
        if (recievedMessage.Type == "GetContextResponse") {
            var globalContext = Context.getInstance();
            globalContext.setGlobalContext(recievedMessage.Content.Context);
            triggerNavigation();
        }
        else if (recievedMessage.Message.Type == "ErrorNotification") {
            //TBD :Notify error 
        }
        else {
            //TBD: unexpected error condition , log error
        }

    };
    return { Initialize: Initialize, GetContext: GetContext, LaunchApplication: LaunchApplication }
})
