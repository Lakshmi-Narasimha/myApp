/**
 * @ngdoc property
 * @name fticCapitalGainAcDetails Directive
 * @requires advisorConstants 
 * @requires advisorEventConstants 
 * @requires fticLoggerMessage 
 * @requires loggerConstants 
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Capital Gains Account Statement details for selected Folio Number and Account Number
 *
 **/
'use strict';
var fticCapitalGainAcDetails = function(cgAccDetModel) {
    return {
        template: require('./capitalGainsAccountDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope, $element, $attrs) {

            $scope.selectedFundAccName = cgAccDetModel.getcgaccountdetails();
            $scope.accountGridLength = cgAccDetModel.getcgaccountdetails().length;
                       
            $scope.fundName = $scope.selectedFundAccName[0].fundName;
            $scope.accountNo = $scope.selectedFundAccName[0].accountNo;

            $scope.selectedAccntDetails = []; 
            angular.forEach(cgAccDetModel.getcgaccountdetails(), function(obj, key) {
                var gridRow = {};
                gridRow.fundName = obj.fundName;
                gridRow.accountNo = obj.accountNo;
                gridRow.purchase = obj.purchase;
                gridRow.redemption = obj.redemption;
                gridRow.capital = obj.capital;
                gridRow.taxded = obj.taxded;
                $scope.selectedAccntDetails.push(gridRow);
            });

            $scope.gridOptions = {};
            $scope.gridOptions.columnDefs = [
                { field: 'purchase', enableSorting:false, width:"320",headerCellTemplate : 'headrTempacPurchase', cellTemplate:'dataTempacPurchase', headerCellClass: 'fti-grid-headercell'},
                { field: 'redemption',width:"320", headerCellTemplate : 'headrTempacRedemption', enableSorting:false,cellTemplate:'dataTempacRedemption', headerCellClass: 'fti-grid-headercell'},
                { field: 'capital',width:"320", enableSorting:false, headerCellTemplate : 'headrTempacCap', cellTemplate:'dataTempacCap', headerCellClass: 'fti-grid-headercell'},
                { field: 'taxded',width:"250", enableSorting:false, headerCellTemplate : 'headrTempacTax', cellTemplate:'dataTempacTax', headerCellClass: 'fti-grid-headercell'}
            ];
        },

        link: function(scope, iElement, iAttrs, controller) {}
    };
};

fticCapitalGainAcDetails.$inject = ['cgAccDetModel'];
module.exports = fticCapitalGainAcDetails;