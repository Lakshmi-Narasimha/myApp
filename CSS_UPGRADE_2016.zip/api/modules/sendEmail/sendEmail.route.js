// sendEmail.route.js
var express = require('express');
var router = express.Router();
var emailSend = require('./sendEmail.model');

// api route

router.route('/sendEmail')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        emailSend.find({},{ emailObject: { $elemMatch: { "functionName": req.body.functionName}} },function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].emailObject.length === 0) {

                    // Failure response is not given in ServiceContract Document

                err = {
                    "uiErrorDisplayMessage": "We werent able to process your request. Please try again. If you still need help, contact Farmers Customer Service at 1-877-327-6392",
                    "transactionStatus": "E",
                    "transactionDescription": "Failure",
                    "transactionCode": "",
                };
                res.send(err);
            } else {
                 res.json(data[0].emailObject[0].emailDetails); // return all emailSend data in JSON format
            }

        });
    });

// route to handle creating goes here (app.post)
// route to handle delete goes here (app.delete)
module.exports = router;
