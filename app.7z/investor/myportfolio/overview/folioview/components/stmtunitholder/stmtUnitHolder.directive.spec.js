'use strict';

describe('Directive: Statement unit holder', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, folioViewModel;
	var unitHolderData = {
			'unitHolderDetails': {
	            'invName': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
	            'address': {
	                'address1': 'BUDHA VILLAGE PO ASANSOL',
	                'address2': 'OPP SITE SAMTHAR PETROL PUMP',
	                'address3': 'MAYUR VIHAR PHASE III',
	                'address4': 'HYDERABAD AP 500028',
	                'city': 'DOMEIVALI',
	                'pinCode': '400062',
	                'line1': null,
	                'line2': null,
	                'line3': null
	            },
	            'holders': [{
	                'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
	                'pan': 'ABJQL2964N',
	                'kycStatus': 'KYC - Registered',
	                'kycSource': null,
	                'modeOfKyc': null,
	                'aadharNo': null,
	                'balAmount': null,
	                'type': 'Firstholder'
	            }, {
	                'name': 'YASMIN POLLY PATEL',
	                'pan': 'CDJQL2964N',
	                'kycStatus': 'KYC',
	                'kycSource': null,
	                'modeOfKyc': null,
	                'aadharNo': null,
	                'balAmount': null,
	                'type': 'Secondholder'
	            }],
	            'status': 'Individual',
	            'modeofOperation': 'Single',
	            'bankDetails': null,
	            'modeofpayment': null
	        }
		}

	var getCompiledElement = function() {
        var element = angular.element('<ftic-stmt-unit-holder></ftic-stmt-unit-holder>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _folioViewModel_) {            
            rootScope = _$rootScope_;
            scope = rootScope.$new();
            compile = _$compile_;
            folioViewModel = _folioViewModel_;
        });

        folioViewModel.setFolioViewObj({
            'unitHolderDetails': unitHolderData.unitHolderDetails
        })

        directiveEle = getCompiledElement();
        isolatedScope = directiveEle.isolateScope();
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create separate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have isUnitHolderDataAvailable to be defined', function() {
    	var isUnitHolderDataAvailable = isolatedScope.isUnitHolderDataAvailable;
        expect(isUnitHolderDataAvailable).toBeDefined();
    });

    it('should have verticalTileRows to be defined', function() {
    	var verticalTileRows = isolatedScope.verticalTileRows;
        expect(verticalTileRows).toBeDefined();
        expect(verticalTileRows[0][0].key).toBe('First Holder');
        expect(verticalTileRows[0][0].value).toBe('ABJQL2964N');
    });

    it('should have stmtUnitHolderData from isolated scope', function() {
    	var stmtUnitHolderData = isolatedScope.stmtUnitHolderData;
        expect(stmtUnitHolderData).toBeDefined();
    });

    it('should have keyValuesArr from isolated scope', function() {
    	var keyValuesArr = isolatedScope.keyValuesArr;
        expect(keyValuesArr).toBeDefined();
        expect(keyValuesArr[0].text).toBe('Status');
        expect(keyValuesArr[0].value).toBe('Individual');
    });
});