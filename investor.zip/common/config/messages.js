
'use strict';

function messages ($translateProvider) {
    $translateProvider.translations('en_US',{
    	//InstantReport Types
		COMM_DETAILS : 'Commission Details',
		INVESTOR_DETAILS : 'Investor Details',
		SPECIAL_PRODUCTS : 'Special Products',
		TRANSACTION_DETAILS : 'Transaction Details',
		ACC_STMTS_LIMIT : "Maximum 10 Folio's can be selected at a time",
		ACC_STMT_DATE_RANGE_ERR : "StartDate should be less than or equal to EndDate",
		ACC_STMT_NO_DATA_ERR_MSG : 'The Folio number/Account number/PAN number/Phone number/ Email ID you have entered is incorrect or not tagged to your Advisor code',
		ACC_STMT_INVALID_KEY : 'The entered format of keyword is incorrect, Please try again',
		SEARCH_RESULTS : 'Search Results',

		//Frequency filter options
		ONE_MONTH : '1 Month',
		THREE_MONTHS : '3 Months',
		ONE_YEAR : '1 Year',
		PERIOD : 'Period',

		//Instant reports buttons
		EMAIL_REPORTS : 'Email Reports',
		NEXT : 'Next',
		RESET : 'Reset',

		//login
		TERMS_N_CONDITION_ONLINE_ADV:'I/We have read and accept all the online adviser ',
		TERMS_N_CONDITION_TEXT:'Terms & Conditions.',
		OTP_TEXT:'One time Password (OTP) has been sent to your registered email/Mobile no.',
		WARNING_TEXT:'Kindly note that this code will be valid for the next 20 minutes only.',
		RESEND_OTP_TEXT:'Resend  OTP?',
		SUBMIT_TEXT:'Submit',
		CONTINUE_TEXT:'Continue',
		TERMS_AND_CONDITIONS:'Terms and Conditions',
		I_ACCEPT:'I Accept',
		I_DONOT_ACCEPT:'I do not Accept' ,
		SUBMIT_USER:'Submit', 
		MY_ACCOUNT : 'My Account',
		//Instant reports accordion label
		SELECTED : 'Selected',
		CLICK_HERE : 'Click here to ',
		LOGIN : 'Login',
		INVESTOR_TEXT:"I'm an Investor",
		ADVISOR_TEXT:"I'm an  Adviser",
		PLEASE_ENTER_YOUR_TEXT:'Please enter your',
		AND_TEXT:'and',
		OTP_TEXT_AFTER_GETTINGOTP:'Please enter your One Time Password (OTP):',
		ENTER_SECURITY_QUESTION : 'Please enter your Answer to secret Question',
		CHOOSE_OPTION : 'Choose either options to retrieve your username ',
		ANSWER_QUESTION : 'Answer Secret Question ',
		SEND_OTP : 'Send One Time Password (OTP)',
		OR:'OR',
		SELECT_SECURITY_QUESTION : 'Please Enter the Valid Security Answer',
		ARN_VALIDATION_TEXT:'ARN field cannot be empty',
		USERNAME_VALIDATION_TEXT:'Username field cannot be empty',
		OTP_VALIDATION_TEXT:'Please Enter OTP',
		ENTER_OTP:'Please enter OTP',
		ENTER_ARN_REGISTRATION_DATE:'Please enter ARN registration date',
		ENTER_DOB:'Please enter date of birth',
		CHOOSE_OPTIONS: 'Choose either options to retrieve your password',
		VIEW_ALL_RECOMMENDATIONS_TEXT:'View All Recommendations',
		VIEW_ALL_NOTIFICATIONS_TEXT:'View All Notifications',

		//common notification events
		NOTIFI_CLICKED_TEXT:'noticlicked',
		RECOM_CLICKED_TEXT:'recomclicked',
		NOTIFICATION_CLICKED_TEXT:'notificationClicked',
		RECOMMENDATION_CLICKED_TEXT:'recommendationClicked',

		//advisor components
		RECOMM_CLICK_FOR_DETLS_TEXT:'recmmonClickFrDtls',

		//Investor Module Message Translatables
		SMART_SAVINGS_ACCOUNT:'Smart Savings Account',
		ONE_TOUCH_INVEST: 'One Touch Invest',


		// Advisor Registration
		LOGIN_USER_NAME_FORMAT : 'Username should contain a minimum of 6 characters',

		//Header Search
        HEADER_SEARCH_RESULTS : 'Search Results',
        HEADER_VIEW_ALL : 'View All',
        HEADER_SEARCH_RESULTS_SUGGESTION_FIRST : 'Search results for',
        HEADER_SEARCH_RESULTS_SUGGESTION_LAST : 'in Page results',
        HEADER_SMART_RESULTS : 'Smart Solutions',
        HEADER_FUND_RESULTS : 'Funds',
        HEADER_NO__RESULTS : 'No Search results found for',

		//SWP Flow
		SWP_INST_START : 'Installments can start on any business day only after 7 days from today',
        SWP_MIN_INST: 'Minimum 6 installments'
	});

    /* Determine automatically the preferred language based on users window.navigator object */
    $translateProvider.determinePreferredLanguage();

    /*If a translation id is not present in the particular language translation table, angular-translate
    will search for it in the registered fallback language i.e english translation table */
    $translateProvider.fallbackLanguage('en_US');

    $translateProvider.useSanitizeValueStrategy('sanitize');
}

messages.$inject = ['$translateProvider'];
module.exports = messages;