var config = require('../../../config/config');

var customerIsTypingModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [

                ],
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "c3446753-f8c7-4fc8-9fb3-451f9a3ab34a",
                    "type": "Success"
                }
            }
        },
        "Page": {
            "showChatHistory": false,
            "parentPageType": "myData",
            "agentBusy": false,
            "callType": null,
            "timeToWait": null,
            "pageType": "livechat"
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "c3446753-f8c7-4fc8-9fb3-451f9a3ab34a",
            "type": "Success"
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_SURVEY_URI
    }
};

module.exports = customerIsTypingModelConfig;
