'use strict';
describe('Directive: fticPendingFamilyPortfolio', function() {
	var compile,scope,directiveElement,isolatedScope,$window,familyPortfolioModel,httpBackend,$uibModal;

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.myportfolio'));
    beforeEach(angular.mock.module('ui.bootstrap'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-family-portfolio-accordion user-details="userItem" primary-owner-pan="primaryOwnerPan"></ftic-family-portfolio-accordion>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope, _$compile_,_$uibModal_,$window,familyPortfolioModel,_familyPortfolioInitialLoader_,_$httpBackend_) {            
            compile = _$compile_;
            scope = $rootScope.$new();            
            $window = $window;
            $window.ga = function() {};
            familyPortfolioModel = familyPortfolioModel;            
            $uibModal = _$uibModal_;
            httpBackend = _$httpBackend_;            
            scope.userItem = {"currentValue":"6,50,000.00","currentCost":"2,50,000.00","pan":"ABAPL1235C","custName":"Shankar Narayan"};
            scope.primaryOwnerPan= "ABAPL1235D";

            httpBackend.expectGET("uib/template/accordion/accordion-group.html").respond("200","success");            
            directiveElement = getCompiledElement();
            isolatedScope = directiveElement.isolateScope();
            isolatedScope.status = {"open" : false};                        
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
        expect(isolatedScope.userDetails[0].key).toBe("Shankar Narayan");
        expect(isolatedScope.userDetails[0].value).toBe("ABAPL1235C");
    });

    it('should show the accordion body on click of aacordion', function() {
        isolatedScope.mgClick(isolatedScope.userDetails,true);        
    });

    it('should show the "Remove this member" link for other than primary pan holder', function() {
        expect(isolatedScope.userDetails[0].value).not.toBe(isolatedScope.primaryOwnerPan);
    });

    it('should not show the "Remove this member" link for primary pan holder', function() {
        isolatedScope.primaryOwnerPan = "ABAPL1235C";
        expect(isolatedScope.userDetails[0].value).toBe(isolatedScope.primaryOwnerPan);
    });

    it('should open the remove member modal on click of "Remove this member" link', function() {
        isolatedScope.removeMember({"stopPropagation":function(){}},isolatedScope.userDetails);
    });

    it('should listen the event familyportfoliodeletememberconf', function() {
        scope.$broadcast("familyportfoliodeletememberconf");        
    });    
});