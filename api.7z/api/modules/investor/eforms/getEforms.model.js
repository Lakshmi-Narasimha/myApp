// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var EformsSchema = new mongoose.Schema({
    'codeValueList': {
        'type': Array,
        'default': []
    }
});

var EformsLookUp = mongoose.model('EformsLookUp', EformsSchema);

var EformsModel = new EformsLookUp({
    'codeValueList': [
        {
            code:'MBARF',
            value: 'Multiple bank account registration form'
        },
        {
            code:'KYCAFI',
            value: 'KYC application form – individuals'
        },
        {
            code:'KYCCDF',
            value: 'KYC change details form – individuals'
        },
        {
            code:'KYCAFNI',
            value: 'KYC application form – non-individuals'
        },
        {
            code:'ANIKYCAF',
            value: 'Annexure – non-individual KYC application form'
        },
        {
            code:'NACHR',
            value: 'Auto Debit Form - NACH Registration'
        },
        {
            code:'NACHC',
            value: 'Auto Debit Form - NACH Cancellation/Update'
        },
        {
            code:'SIPTDDF',
            value: 'SIP through Direct Debit form'
        },
        {
            code:'SIPTADF',
            value: 'SIP through Auto Debit form'
        },
        {
            code:'CTFINV',
            value: 'Common Transaction Form'
        }
    ]
});

EformsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating EformsLookUp table, please contact admin...' + err);
    } else {
        EformsLookUp.remove({}, function(err) {
            console.log('EformsLookUp collection removed' + err);
            EformsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating EformsLookUp table, please contact admin...');
                }
                console.log('EformsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = EformsLookUp;
