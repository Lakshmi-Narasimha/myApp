define(['jquery', 'underscore', 'backbone', 'backboneRelational', 'appmodules/ncst/app/js/lib/validate-4.2', 'appmodules/ncst/app/js/models/model-new-client', 'appmodules/ncst/app/js/models/model-address-entry', 'appmodules/ncst/app/js/models/model-client-details', 'appmodules/ncst/app/js/models/model-emloyment', 'appmodules/ncst/app/js/models/model-client-info', 'appmodules/ncst/app/js/models/model-income-investment', 'appmodules/ncst/app/js/models/model-client-details', 'services/dataservice', 'appmodules/ncst/app/js/utils', 'appcommon/globalcontext', 'appcommon/commonutility'],
		function($, _, Backbone,backboneRelational, Validator,NewClientModel,AddressModel,ClientDetailsModel,EmploymentModel,ClientInfoModel,IncomeMOdel,ClientDetailsModel,DataService,Utils,GlobalContext, CommonUtility) {
	var _clientModel = Backbone.RelationalModel.extend({
		defaults : {
			advisorNumber : '',
			stepsCompleted : [],
			clientCreated : 'no',
			newClientWithAddress : false,
			newClient : false,
			scrubEntityName:null,
			entityName:null,
                        serverErrorCodes: []
		},
		initialize:function(){},
		push : function(arg, val) {
			var arr = _.clone(this.get(arg));
			arr.push(val);
			this.set(arg, arr);
		},
		erase : function(arg) {
			var _clientCreated = this.get('clientCreated');
			var _clntType = ClientInfoModel.get('clientType');
			this.set('clientCreated','no');
			this.set('draftID',null);
			NewClientModel.clear().set(NewClientModel.defaultValues());
			this.get('clientInfo').clear().set(this.get('clientInfo').defaults);
			ClientDetailsModel.clear().set(ClientDetailsModel.defaults);
			this.get('employement').clear().set(this.get('employement').defaults);
			this.get('income').clear().set(this.get('income').defaults);
			if (arg == 'all') {
				AddressModel.clear().set(AddressModel.defaults);
				this.set({
					stepsCompleted : [],
					clientCreated : 'yes'
				});
			} else if (arg == 'all!address') {
				this.set({
					stepsCompleted : [ 'address-entry', 'address-validation' ],
					clientCreated : 'yes'
				});
			}else{
				AddressModel.clear().set(AddressModel.defaults);
				this.set({
					clientCreated : '',
					stepsCompleted : [],
					fullName : null
				});
			}
			if(_clientCreated == "yes" && arg){
				ClientInfoModel.set('clientType',_clntType);
				this.set('clientType',_clntType);
			}
			
		},
		createDraft : function(isSubmit,clientId){
		var _draftId= null;
		if(this.get('draftID')){
			_draftId = this.get('draftID');
		}
				var _headers= this.getHeaders();
				var _data = this.formatDraftPayload(_draftId, isSubmit, clientId);
				return DataService.createNCSTDraft(_headers,_data);
		},
		updateDraft:function(draftId){
			var _headers= this.getHeaders();
			var _data  = this.formatDraftPayload();
			return DataService.updateNCSTDraft(_headers,_data,draftId);
		},
		showDraftSaveSuccesMessage:function(response){
			if(response && response.requestId){
				this.set('draftID',response.requestId);
			}
			Utils.showDraftSaveSuccesMessage();
		},
		getHeaders:function(){
			var _sadConfig =  Utils.getConfigProperty('SAD_CONFIG');
			var _headers = {
					//fmid: Utils.readCookie('FMID'),
					//ldapGroups: 'CSR,CRS',
					appId: _sadConfig['appId'],
					//guid:1234
			};
			return _headers;
		},
		formatDraftPayload: function (draftId, isSubmit, clientId) {
			var _model = this;
			var _clientInfoModel = _model.get('clientInfo');
			_clientInfoModel.set('clientInfoValid',false);
			var _clType = _clientInfoModel.get('clientType');
			var _ssn ="";
			var _clientInfo = _clientInfoModel.toJSON();
			if(_clType == "P"){
				if(_clientInfoModel.get('citizenship') == 'Non-Resident Alien' && _clientInfoModel.get('ssn1') == ''){
					_ssn = '000000000';
				}else{
					_ssn = _clientInfoModel.get('ssn1')+""+_clientInfoModel.get('ssn2')+""+_clientInfoModel.get('ssn3');
				}
			}else{
				_ssn = _clientInfoModel.get('ein1')+""+_clientInfoModel.get('ein2');
			}
			var _enteredAdvsrNum = "";
			var _advsrName = "";
			if(_model.get('isAACUser')==true){
			    _enteredAdvsrNum = _model.get('advisorNumber');
			    _advsrName = _model.get('advisorNm');
			}
			else{
			    _enteredAdvsrNum = _model.get('servicingAdvisorNumber');
			    _advsrName = _model.get('servicingAdvisorName');
			}
			var _queryAdvsr = _enteredAdvsrNum, _primaryAdvsr = _model.get('advisorNumber');//?this.zeropad($('#i-advisor-number').val(),9):this.get('advisorNumber');
			var _context = GlobalContext.getInstance().getGlobalContext().Context;
			
			var _data = {
					"advisorId": _queryAdvsr,
					"advisorName":_advsrName,
					"appName": "ncst",
					"contactId":null,
				   // "createById": Utils.readCookie('FMID'),
				    "formStatus": isSubmit?"submitted":"draft",
				    "firstName":_clType=="P"?_clientInfoModel.get('firstName'):null,
				    "middleName":_clType=="P"?_clientInfoModel.get('middleName'):null,
				    "lastName":_clType=="P"?_clientInfoModel.get('lastName'):null,
				    "entityName":_clType !="P"?_clientInfoModel.get('uEntityName'):null,
				    "ssn":_ssn,
				    "WIPDraftData":{}
			};
			var _ignoreDraftID = true;
			if (draftId && (!_clientInfoModel.get('ssnChanged') || CommonUtility.getUrlParams().srcSystem == "EAR")) {
				_data.requestId = draftId;
				_ignoreDraftID = false;
			}
			if(_clientInfoModel.get('prosId') && (!_ignoreDraftID || !draftId) ){
				_data.contactId = _clientInfoModel.get('prosId');
			}else{
				_clientInfo.prosId = null;
			}
            //don't save associated client details
			_clientInfo.clientNames = [];
			_clientInfo.clientAssociated = [];
		    _clientInfo.clientassocName = [];
		    _clientInfo.clientassocId=[];
		    _clientInfo.clientassocReltn = [];
		    //don't save associated client details
			var _sadData = {};
			_sadData.clientInfo = _clientInfo;
			_sadData.clientAddress = _model.get('addressEntry').toJSON();
			_sadData.clientDetails =_model.get('details').toJSON(); 
			_sadData.clientDetails.clientNames = [];
			_sadData.clientEmployment =_model.get('employement').toJSON(); 
			_sadData.clientIncome =_model.get('income').toJSON(); 
			_sadData.advisorID = _primaryAdvsr;
			_sadData.clientId = clientId ? clientId : null;
			_sadData.version = "2.0";
			_data.WIPDraftData = _sadData;
			return _data;
		},zeropad: function(num, numLength){
			var n = Math.abs(num);
		    var zeros = Math.max(0, numLength - Math.floor(n).toString().length );
		    var zeroString = Math.pow(10,zeros).toString().substr(1);
		    if( num < 0 ) {
		        zeroString = '-' + zeroString;
		    }

		    return zeroString+n;
		},
		relations : [ {
			type : Backbone.HasOne,
			key : 'clientInfo',
			relatedModel : ClientInfoModel,
			reverseRelation : {
				key : 'client',
				includeInJSON : true
			}
		}, {
			type : Backbone.HasOne,
			key : 'address',
			relatedModel : AddressModel,
			reverseRelation : {
				key : 'client',
				includeInJSON : true
			}
		}, {
			type : Backbone.HasOne,
			key : 'details',
			relatedModel : ClientDetailsModel,
			reverseRelation : {
				key : 'client',
				includeInJSON : true
			}
		}, {
			type : Backbone.HasOne,
			key : 'employement',
			relatedModel : EmploymentModel,
			reverseRelation : {
				key : 'client',
				includeInJSON : true
			}
		}, {
			type : Backbone.HasOne,
			key : 'income',
			relatedModel : IncomeMOdel,
			reverseRelation : {
				key : 'client',
				includeInJSON : true
			}
		} ],
		validate : function() {
		},
	});
	return new _clientModel({
		"submitterId" : "",
		"advisorName" : "",
		"clientId" : "",
		"groupId" : "",
		'clientInfo' : ClientInfoModel,
		'addressEntry' : AddressModel,
		'details' : ClientDetailsModel,
		'employement' : EmploymentModel,
		'income' : IncomeMOdel,
		'newClientWithAddress' : false,
		'newClient' : false,
		'scrubEntityName':null,
		'entityName':null,
		'draftID':null
	});
});