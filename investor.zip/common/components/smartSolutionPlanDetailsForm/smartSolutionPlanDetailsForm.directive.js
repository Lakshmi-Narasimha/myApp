'use strict';

var smartSolutionPlanDetailsForm = function ($state, recommendedPlanModelService, planSmartSolution) {
    return {
        template: require('./smartSolutionPlanDetailsForm.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            formParent: "=",
            isBackEnabled: "=?"
        },
        controller: function ($scope, $element, $attrs) {
            $scope.inflationAdjust ;
            $scope.goalinflationRateError = false;
            $scope.secOptions = [];
            //$scope.secOptions = [{title: "Select"}];
            // $scope.defaultInflationRates = "";
            var Obj = {
                "groupId": "InflationRates"
            };
            $scope.inflation = {};
            planSmartSolution.getInflationRates(Obj)
                .then(function (data) {
                    angular.forEach(data.codeValueList, function (obj) {
                        var inflationRate = {title: obj.value};
                        $scope.secOptions.push(inflationRate);
                    });
                    $scope.inflation.defaultRate = $scope.secOptions[6];
                    // $scope.defaultInflationRates = $scope.secOptions[6];
                }, function () {

                });

            $scope.isBackEnabled = $scope.isBackEnabled || false;
            $scope.ageObject = {
                key: "age",
                type: "text",
                name: "age",
                min: 10,
                isRequired: true,
                pattern: /^([1-9]){1}([0-9]){1}$/,
                value: ""
            };
            $scope.investTenureObject = {
                key: "investTenure",
                type: "number",
                name: "investTenure",
                isRequired: true,
                min: 1,
                max: 40,
                pattern: /^[0-0]{1}[1-9]{1}$|^[1-3]{1}[0-9]{1}$|^[1-9]{1}$|^40$/,
                value: ""
              };
              $scope.goalAmtTodayObject = {
                key: "goalAmtToday", 
                text: "", 
                type: "text", 
                name: "goalAmtToday", 
                isRequired: true,
                pattern:  /^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{8}$/,
                value: ""
              };
              $scope.$on('selectedOption', function (event, data) {
                  $scope.selecetdInflationRate = data.title;

                  if (data.title !== "Select") {
                      $scope.goalinflationRateError = false;
                      loadAdjustedAmount();
                  }
                  else {
                      $scope.goalinflationRateError = true;
                  }
              });

              $scope.goBack = function () {
                  $scope.$emit('goToBackScreen');
              };

              $scope.planButton = function () {
                if ($scope.planInputDtlsForm.$valid) {
                    var investmentAmount = null;
                    if ($scope.goalAmtTodayObject.value !== "") {
                        investmentAmount = $scope.goalAmtTodayObject.value;
                    }
                    else {
                        investmentAmount = $scope.goalAmtEndOfGoalObject.value;
                    }
                    $scope.planInputDetails = {
                        "age": $scope.ageObject.value,
                        "investmentTenure": $scope.investTenureObject.value,
                        "investmentAmount": investmentAmount,
                        "equityPerc": 0
                    };
                    recommendedPlanModelService.setPlanInputDtls($scope.planInputDetails);

                    $scope.goalAmountField = false;
                    if ($scope.goalAmtTodayObject.value === "" && $scope.goalAmtEndOfGoalObject.value === "") {
                        $scope.goalAmountField = true;
                    }

                    if ($scope.planInputDtlsForm.$valid && !$scope.goalAmountField) {
                        $scope.$emit('planInputDetailsBtn');
                    }
                    recommendedPlanModelService.setRecommendedFromState($state.current.name);
                }
              };

            $scope.planInputChanged = function () {
                if($scope.goalAmtTodayObject.value !=="" && $scope.investTenureObject.value !=="") {
                    loadAdjustedAmount();
                }
            };

            function loadAdjustedAmount() {
                $scope.queryObj = {
                    "currentGoalAmt": $scope.goalAmtTodayObject.value,
                    "inflationRate": $scope.selecetdInflationRate,
                    "noOfYears": $scope.investTenureObject.value
                };
                planSmartSolution.getAdjGoalAmt($scope.queryObj)
                    .then(function (data) {
                        $scope.inflaValue = data.status;
                        $scope.inflationAdjust = true;
                    }, function () {

                    });
              }
        },
        link: function (scope, iElement, iAttrs, controller) {

        }
    };
};
smartSolutionPlanDetailsForm.$inject = ['$state', 'recommendedPlanModelService', 'planSmartSolution'];
module.exports = smartSolutionPlanDetailsForm;