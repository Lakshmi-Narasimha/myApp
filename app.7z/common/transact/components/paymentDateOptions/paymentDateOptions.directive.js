/**
 * @ngdoc property
 * @name fticPaymentDateOptions Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Period, Start date and End date options.
 *
 **/
'use strict';

var fticPaymentDateOptions = function (fundDetails, bankDtlsModel, $stateParams, TransactConstant, paperlessModel) {
    return {
        template: require('./paymentDateOptions.html'),
        restrict: 'E',
        replace: true,
        scope: {
            parentForm: '=',
            emandateClasses: '@'
        },
        controller:['$scope', function ($scope) {
            $scope.endDateDisable = true;
            $scope.disableRadio = false;
            setDefaultPeriod();
            setDateOptions(bankDtlsModel.getBankName());

            $scope.$on('bankChanged', function(event, data) {
                setDateOptions(data.title);
            });            

            $scope.periodChanged = function(value) {
                $scope.endDateDisable = true;
                bankDtlsModel.setPeriod(value);
                if(value === TransactConstant.transact.DATE_RANGE) {
                    $scope.endDateDisable = false;
                }
            };

            function setDateOptions(bank) {
                bankDtlsModel.setPeriod($scope.selectedPeriod);
                var isHDFC = checkBank(bank);
                if(isHDFC) {
                   disableUntilCancelled(); // Disable 'Until Cancelled' option for HDFC bank
                } else {
                    setDefaultPeriod();
                }
            }
            
            $scope.startDate = new Date();

            if($stateParams.key !== TransactConstant.transact.Payment_Key) {
                var currentDate = new Date(); 
                var tenYrDate = currentDate.setFullYear(currentDate.getFullYear() + 10);
                $scope.endDate = tenYrDate;

                var date = new Date(tenYrDate);
                bankDtlsModel.setStartDate($scope.startDate);
                bankDtlsModel.setEndDate(date.toString('dd/MM/yyyy'));
            }

            $scope.getDate = function(dateVal) {
                bankDtlsModel.setStartDate($scope.startDate);
                var date = new Date(dateVal);
                bankDtlsModel.setEndDate(date.toString('dd/MM/yyyy'));
            };

            //Save previous selections
            function savePaymentOptions(){
                var period = bankDtlsModel.getPeriod();
                $scope.selectedPeriod = period;

                if(period === TransactConstant.transact.DATE_RANGE) {
                    var date = bankDtlsModel.getEndDate();
                    var dateVal = new Date(date);
                    $scope.endDate = dateVal;
                    $scope.endDateDisable = false;
                } else {
                    var currentDate = new Date();
                    var tenYrDate = currentDate.setFullYear(currentDate.getFullYear() + 10);
                    $scope.endDate = tenYrDate;
                }

                //Check if HDFC bank has been selected then disable 'Until Cancelled' option
                var selectedBank = bankDtlsModel.getSelectedBank(),
                    isHDFC = checkBank(selectedBank);
                    if(isHDFC) {
                       disableUntilCancelled();                  
                    }
            }

            function setDefaultPeriod() {
                $scope.disableRadio = false;
                $scope.selectedPeriod = TransactConstant.transact.UNTIL_CANCEL;
            }
            
            function disableUntilCancelled() {
               $scope.disableRadio = true;
               $scope.endDateDisable = false;
               $scope.selectedPeriod = TransactConstant.transact.DATE_RANGE;
               bankDtlsModel.setPeriod($scope.selectedPeriod);
            }

            function checkBank(bankVal) {
                if(bankVal !== null && bankVal.indexOf(TransactConstant.transact.HDFC) >= 0) {
                    return true;
                }
                return false;
            }
            $scope.endDateOptions = {
                yearRows: 3,
                yearColumns: 4,
                datepickerMode: 'day',
                minMode: 'day',
                fulldatepickerMode:'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                monthColumns: 4,
                showWeeks: false,
                minDate:new Date()                 
             };
             
            //For Transact Module
            if($stateParams.key === TransactConstant.transact.Payment_Key) {
                savePaymentOptions();
            }

            //For Paperless Module
            if(paperlessModel.paymentDtls.hasData) {
                savePaymentOptions();
            }
        }]
    };
};

fticPaymentDateOptions.$inject = ['fundDetails', 'bankDtlsModel', '$stateParams', 'TransactConstant', 'paperlessModel'];
module.exports = fticPaymentDateOptions;