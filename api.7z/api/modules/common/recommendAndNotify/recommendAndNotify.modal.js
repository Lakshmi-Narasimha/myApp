// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RecommendAndNotifySchema = new mongoose.Schema({
    recomNotificationsObject: {
        type: Array,
        'default' : []
    }
});

var RecommendAndNotifyLookUp = mongoose.model('RecommendAndNotifyLookUp', RecommendAndNotifySchema);

var RecommendAndNotifyModel = new RecommendAndNotifyLookUp({

    'recomNotificationsObject': [{
        'recommendations': [{
            'recomRefNo': '1064',
            'recomId': '1',
            'recomMsg': '119 SIPs out of your SIP book with us are coming up for renewal.',
            'recomDt': '31 Aug 2016',
            'recomReq': 'Y',
            'readStatus': 'N',
            'linkText': 'SIP Renewal Details',
            'reportCode': '1008',
            'reportType': 'D,M',
            'reportFormat': 'EXCEL',
            'hoursAgo': '',
            'url': ''
        }, {
            'recomRefNo': '1097',
            'recomId': '1',
            'recomMsg': '176 SIPs out of your SIP book with us are coming up for renewal.',
            'recomDt': '30 Sep 2016',
            'recomReq': 'Y',
            'readStatus': 'N',
            'linkText': 'SIP Renewal Details',
            'reportCode': '1008',
            'reportType': 'D,M',
            'reportFormat': 'EXCEL',
            'hoursAgo': '18 Days 22 Hours 16 Minutes',
            'url': ''
        }, {
            'recomRefNo': '1065',
            'recomId': '2',
            'recomMsg': '4878000  Potential for Step Ups Message with investor list',
            'recomDt': '24 Aug 2016',
            'recomReq': 'Y',
            'readStatus': 'N',
            'linkText': 'SIP Features Details',
            'reportCode': '1009',
            'reportType': 'D,M',
            'reportFormat': 'EXCEL',
            'hoursAgo': '',
            'url': ''
        }],
        'notifications': [{
            'recomRefNo': '1127',
            'recomId': '10',
            'recomMsg': 'Commission Not Paid @@COC CoC not submitted, 665057 ARN Expiry, 8366 EUIN expiry',
            'recomDt': '31 Jul 2013',
            'recomReq': 'Y',
            'readStatus': 'N',
            'linkText': 'Commission Deatails',
            'reportCode': '1017',
            'reportType': 'D',
            'reportFormat': 'EXCEL',
            'hoursAgo': '5 Days 29 Minutes 59 Seconds',
            'url': ''
        }]
    }]

});

RecommendAndNotifyLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating RecommendAndNotifyLookUp table, please contact admin...');
    } else {
        RecommendAndNotifyLookUp.remove({}, function(err) {
            console.log('RecommendAndNotifyLookUp collection removed');
            RecommendAndNotifyModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating RecommendAndNotifyLookUp table, please contact admin...');
                }
                console.log('RecommendAndNotifyLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RecommendAndNotifyLookUp;
