var HtmlReporter = require('protractor-html-screenshot-reporter');
var reporter=new HtmlReporter({
    baseDirectory: './test/coverage/e2e/ScrnShots', // a location to store screen shots.
    docTitle: 'E2E Test Execution Report',
    docName:    'e2e-test-execution-report.html'
});
exports.config = {

    allScriptsTimeout: 11000,

    // The address of a running selenium server. If specified, Protractor will
    // connect to an already running instance of selenium. This usually looks like
    // seleniumAddress: 'http://localhost:4444/wd/hub'
    //seleniumAddress: null,
    seleniumServerJar: '../node_modules/selenium-server/lib/runner/selenium-server-standalone-2.45.0.jar',

    // ----- What tests to run -----
    // Spec patterns are relative to the location of this config.
    specs: [
        'e2e/billing.authenticationCtrl.spec.js'
    ],
        
    chromeDriver: '../node_modules/chromedriver/lib/chromedriver/chromedriver',

    baseUrl: 'http://localhost:3000/app/',

    framework: 'jasmine',

    jasmineNodeOpts: {
        isVerbose: true,
        showColors: true,
        includeStackTrace: true,
        defaultTimeoutInterval: 30000
    },

    // If false, the grunt process stops when the test fails.
    keepAlive: true,

    // If true, protractor will not use colors in its output.
    noColor: false,

    onPrepare: function() {
        jasmine.getEnv().addReporter(reporter);
    },

};
