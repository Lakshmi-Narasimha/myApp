/**
 *@ngdoc object
 *@name investor.module:home
 *@description
 * <p>
 * Module declaration for my profile
 * </p>
 */

'use strict';
// Home View
module.exports = angular.module('investor.accountsettings', [])
    .config(require('./accountSettings.routes'))
    .controller('BankDetailsController', require('./bankdetails/basisbankaccount.controller'))
    .controller('eMandateController', require('./emandate/emandate.controller'))
    .controller('newEmandateController', require('./emandate/newemandate.controller'))
    .directive('fticBasisBankAccountDetails', require('./bankdetails/basisbankaccount/components/basisBankAccDetails.directive'))
    .directive('eMandateDetails', require('./emandate/components/eMandateDetails.directive'))
    //.directive('fticNewEmandateAccountBankDetails', require('./emandate/components/newAccountBankDetails/newAccountBankDetails.directive'))
    .directive('createNewEmandate', require('./emandate/components/newemandate/createnewemandate.directive'))
    .factory('basisBankAccInitialLoader', require('./bankdetails/services/basisBankAccInitialLoader.service'))
    .factory('basisBankAccModel', require('./bankdetails/services/basisBankAccModel.service'))
    .controller('ChangeDividendController', require('./changedividend/changedividend.controller'))
    //.directive('changeDividendGrid', require('./changedividend/components/changedividendgrid.directive'))
    .factory('eMandateIntialLoadService', require('./emandate/services/eMandateInitialLoader.service'))
    .factory('eMandateModel', require('./emandate/services/eMandateModel.service'))
    .factory('changeDividendInitialLoadService', require('./changedividend/services/changeDividendInitialLoader.service'))
    .factory('changeDividendModel', require('./changedividend/services/changeDividendModel.service'))
    .factory('changeDividendGridConfigModel', require('./changedividend/services/changeDividendGridConfig.service'))
    .controller('SmartSavingsAccountController', require('./smartsavingsaccount/smartSavingsAccount.controller'))
    .controller('PurchasesController', require('./smartsavingsaccount/smartSavingsPurchases.controller'))
    .controller('RedeemController', require('./smartsavingsaccount/smartSavingsRedeem.controller'))
    .factory('smartSavingsAccountModel', require('./smartsavingsaccount/services/smartSavingsAccountModel.service'))

    //.factory('paymentDetailsUtility', require('../../common/transact/services/paymentDetailsUtility.service'))
    .controller('OneTouchInvestController', require('./onetouchinvest/oneTouchInvest.controller'))
    .factory('oneTouchInvestModel', require('./onetouchinvest/services/oneTouchInvestModel.service'))
    .controller('StandingInstructionsController', require('./onetouchinvest/standingInstructions.controller'))
    .controller('NomineeDetailsController', require('./nomineedetails/nomineeDetails.controller'))
    .factory('nomineeDetailsInitialLoader', require('./nomineedetails/services/nomineeDetailsInitialLoader.service'))
    .factory('nomineeDetailsModel', require('./nomineedetails/services/nomineeDetailsModel.service'))
    .directive('fticNomineeLists', require('./nomineedetails/components/nomineelists/nomineeLists.directive'))
    .directive('fticNomineeFilter', require('./nomineedetails/components/nomineefilter/nomineeFilter.directive'))
    .controller('fticConfirmModalController', require('./nomineedetails/components/confirmmodal/confirmModal.controller'))
    .controller('FamilyPortfolioAccessController', require('./familyportfolioaccess/FamilyPortfolioAccessController.controller'))
    .factory('familyPortfolioUserAccessModel', require('./familyportfolioaccess/services/fpUserAccessDetails.service'))
    .factory('fticFTUserAccessDetailsLoadInitialService', require('./familyportfolioaccess/services/fpUserAccessDetailsInitialLoader.service'))
    .directive('fticBasisFolio', require('./bankdetails/basisfolio/basisFolio.directive'))
    .directive('fticAddNewBankForm', require('./bankdetails/addnewbank/components/addnewbankform/addNewBankForm.directive'))
    .directive('fticAddNewBankLink', require('./bankdetails/components/addnewbanklink/addNewBankLink.directive'))
    .factory('ftiAddNewBankInitialService', require('./bankdetails/addnewbank/services/addNewBankInitialLoader.service'))
    .factory('addNewBankModel', require('./bankdetails/addnewbank/services/addNewBankModel.service'))
    .factory('basisFolioModel', require('./bankdetails/services/basisFolioModel.service'))
    .factory('basisBankListModel', require('./bankdetails/services/bankNamesListModel.service'))
    .factory('basisFolioInitialLoader', require('./bankdetails/services/basisFolioInitialLoader.service'))
    .directive('fticKeyValueCrossIconTileList', require('./familyportfolioaccess/components/keyvaluecrossicontilelist/keyValueCrossIconTileList.directive'))
    .controller('RemMemConfPopup', require('./familyportfolioaccess/components/removegrantaccessconfirmpopup/remGranAccessConfPopup.controller'))
    .controller('ConfirmPasswordModalController', require('./changedividend/components/confirmmodal/confirmPasswordModal.controller'))
    .directive('fticUploadFiles', require('./bankdetails/addnewbank/components/uploadFile/uploadFile.directive'))
    .controller('ConfirmModalController', require('./bankdetails/components/confirmmodal/confirmModal.controller'))
    ;



   

    

    