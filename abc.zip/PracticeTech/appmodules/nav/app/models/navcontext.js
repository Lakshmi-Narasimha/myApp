define([
  'jquery',  
  'backbone',  
], function ($,Backbone) {
    var clientSearchEventModel = Backbone.Model.extend({
        defaults: {
            loggedadvisor: undefined,
            selectedadvisor: undefined,
            selectedclient: undefined,
            selectedcontacttype: undefined,
            selectedclientgroups: undefined,
            triggeredevent: undefined,
            isOBO:undefined
        }
    });
    var navContext = {
        clientSearchEventModel: clientSearchEventModel
    };
    return navContext;
});
