// JavaScript Document
define(['jquery'],function($){
	var generalError = "Please check the indicated fields";
	var errorMsg = {
		"generic" : "Incomplete required field.",
		"invalidCharacters" : "Invalid special character.",
		"poBox" : "Permanent addresses cannot be a P.O. Box.",
		"zipUsNonNumeric" : "Zip code may only contain numbers.",
		"zipUsLt5" : "Zip code must contain 5 numbers.",
		"zipCanNotInFormat" : "Postal code must only contain numbers and letters.",
		"zipCanLt6" : "Postal code must contain 6 numbers and letters.",
		"invalidEmail" : "Invalid email address.",
	};

	function validateInputs(frmId) {
		var status = $("#" + frmId).navValidate(frmId);
		if ($("#" + frmId).length < 1) {
			return false;
		}
		return status;
	}

	jQuery.fn.navValidate = function(formId) {
		
		var validate = new jQuery.navValidate(formId);
		return validate.validateForm();
	}

	jQuery.navValidate = function(formId) {

		var validator = this;
		this.errorList = {};
		this.currentForm;
		this.validateForm = function() {
			validator.errorList = {};
			validator.currentForm = $('#' + formId);
			$('label.error', validator.currentForm).addClass("hidden");
			$('span.coa-adjust-left', validator.currentForm).addClass("hidden");
			$("div").removeClass("error");
			// $(':input', validator.currentForm).removeClass("error")

			$(".required", validator.currentForm).each(function() {
				if ($(this).is(':visible')) {
					validator.validateRequired(this);
				}
			});
			$(".email", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateEmail(this);
				}

			});

			$(".number", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateNumber(this);
				}
			});

			$(".phone-number", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validatePhoneNumber(this);
				}
			});

			$(".url", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateURL(this);
				}
			});

			$(".greater-than", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateGreaterThan(this);
				}
			});
			$(".integer", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateInteger(this);
				}
			});
			$(".float", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateFloat(this);
				}
			});
			$(".amount", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateAmount(this);
				}
			});
			$(".address", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateAddress(this);
				}
			});
			$(".us-address-1", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateUSAddress1(this);
				}
			});
			$(".po-box-check", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validatePoBox(this);
				}
			});
			$(".alphanumeric", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateAlphanumeric(this);
				}
			});
			$(".us-zipcode", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateUSzipcode(this);
				}
			});
			$(".canada-zipcode", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateCanadazipcode(this);
				}
			});
			$(".val-city", validator.currentForm).each(function() {
				if (validator.checkForHiddenAndEmpty(this)) {
					validator.validateCity(this);
				}
			});
			if (!validator.isFormValid()) {
				return false;
			}
			return true;
		};
		this.checkForHiddenAndEmpty = function(element) {
			if (!$(element).is(':visible') || $.trim($(element).val()) == "") {
				return false;
			}
			return true;
		};
		this.validateEmail = function(element) {

			if ($(element).val()
					&& !(/(^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$)/i)
							.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidEmail;
			}

		};

		this.validateRequired = function(element) {
			if (!$.trim(($(element).val()))) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.generic;
			} else if ($(element).hasClass("blur")
					&& $.trim($(element).val()) == $(element).attr("title")) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.generic;
			}
		};
		this.validateNumber = function(element) {
			if (isNaN($(element).val()) || $(element).val() <= 0) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};

		this.validatePhoneNumber = function(element) {
			var re = new RegExp(/^([0-9]{0,12})+$/);
			if ($(element).val() && !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};

		this.validateGreaterThan = function(element) {
			this.elemntID = element.id;
			this.theId = this.elemntID.match(/\d/g);
			this.theId = this.theId.join("");
			if (parseFloat($("#fieldMin" + this.theId).val()) >= parseFloat($(
					element).val())) {
				this.errorList[element.id] = [];

			}
		};
		this.validateURL = function(element) {
			if (!(/^(http:\/\/www.|https:\/\/www.|www.|http:\/\/){1}([\w]+)(\.[\w]+){1,2}$/)
					.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};

		this.validateInteger = function(element) {
			var re = new RegExp(/^\d{0,15}$/g);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};
		this.validateAmount = function(element) {
			var re = new RegExp(/^-?(\d{0,10})?(\.\d{1,4})?$/g);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			// var limitAmount = "999999999.9999";
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
			/*
			 * if(parseFloat($(element).val()) >= limitAmount){
			 * this.errorList[element.id] = []; }
			 */
		};
		this.validateAddress = function(element) {
			var re = new RegExp(/^[ A-Za-z0-9-;,:#\/]*$/g);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};

		this.validateUSAddress1 = function(element) {
			var re = new RegExp(/^[ A-Za-z0-9\/]*$/g);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};

		this.validatePoBox = function(element) {
			var re = new RegExp(/\b(?:p\.?\s*o\.?|post\s+office)\s+box\b/i);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.poBox;
			}
		};
		this.validateAlphanumeric = function(element) {
			var re = new RegExp(/^[a-zA-Z]+$/);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};
		this.validateUSzipcode = function(element) {
			var re = new RegExp("^\\d{5}?$");
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				var _regxNumOnly = new RegExp("^\\d+$");
				if (!_regxNumOnly.test($(element).val())) {
					this.errorList[element.id].errMsg = errorMsg.zipUsNonNumeric;
				} else {
					this.errorList[element.id].errMsg = errorMsg.zipUsLt5;
				}
			}
		};
		this.validateCanadazipcode = function(element) {
			var re = new RegExp(/([a-z]\d){3}/i);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			var _val = $(element).val();
			if (_val && (_val != defaultVal) && !re.test(_val)) {
				this.errorList[element.id] = [];
				if (_val.length < 6) {
					this.errorList[element.id].errMsg = errorMsg.zipCanLt6;
				} else {
					this.errorList[element.id].errMsg = errorMsg.zipCanNotInFormat;
				}

			}
		};
		this.validateCity = function(element) {
			var re = new RegExp(/^[ 'A-Za-z0-9.-]*$/g);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
		};
		this.validateFloat = function(element) {
			var re = new RegExp(/^-?(\d{0,10})?(\.\d{1,8})?$/g);
			var defaultVal = ($(element).attr("placeholder")) ? $(element).attr(
					"placeholder") : $(element).attr("title");
			// var limitFloat = "9999999999.99999999";
			if ($(element).val() && ($(element).val() != defaultVal)
					&& !re.test($(element).val())) {
				this.errorList[element.id] = [];
				this.errorList[element.id].errMsg = errorMsg.invalidCharacters;
			}
			/*
			 * if(parseFloat($(element).val()) >= limitFloat){
			 * this.errorList[element.id] = []; }
			 */
		};
		this.isFormValid = function() {
			var count = 0;
			for (i in this.errorList) {
				count++;
			}
			if (count == 0) {
				return true;
			} else {
				this.showErrors();
				return false;
			}
		};
		this.showErrors = function() {
			var context = this.currentForm;
			for (elementID in this.errorList) {

                //contact profile international phone number
			    if ($('#' + elementID).attr('data-master-container')) {
			        var elemendData = $('#' + elementID).attr('data-master-container');
			        $("div[data-for=" + elemendData + "]").addClass("error").find(
						"span.coa-adjust-left").removeClass("hidden");
			    }

				$("div[for=" + elementID + "]").addClass("error").find(
						"span.coa-adjust-left").removeClass("hidden");
				;
				$("div[data-for=" + elementID + "]").addClass("error").find(
						"span.coa-adjust-left").removeClass("hidden");
				;
				$("#" + elementID).parent().find("label.error").text(
						this.errorList[elementID].errMsg);
				$("div[data-for=" + elementID + "]").find("label.error").text(
						this.errorList[elementID].errMsg);
				$("#" + elementID).parent().find("label.error").removeClass(
						"hidden");
				$("#" + elementID).parent().parent().find("label.error")
						.removeClass("hidden");
			    // For contact profile Edit
				/*$("#" + elementID).parent().parent().parent().find("label.error")
						.removeClass("hidden");*/
			    // For adjusting the left when error showing

			    //For add prospect
				if ($("#" + elementID).parent().parent().hasClass('prospcheck') == true) {
				    $("#" + elementID).parent().parent().addClass('error');
				}
				$("div[data-for=" + elementID + "]").find("label.error")
						.removeClass("hidden");
			}
			try {
				var _firstErrorInput = context.find('.row.error')[0];
				_firstErrorInput.scrollIntoView(true);
			} catch (e) {
				window.scrollTo(0, 0);
			}

			showError();
			// showMessage();
		};

	};

	function showError(error) {
		hideMessage();

		// if(!error && !$('.errorMsg').html()){
		if (!error) {
			error = generalError;
		}

		$('.errorMsg').html(error);
		$('#error').fadeIn(500);
		setTimeout(function() {
			hideError();
		}, 2000);
	}
	function hideError() {
		if ($("#error").css('display') == 'block') {
			// $('#error').css("display","none");
			$('#error').fadeOut('slow');
		}
	}
	function showMessage(message) {
		hideError();
		$('.warningMsg').html(message);
		$('#message').fadeIn('slow');
		setTimeout(function() {
			hideMessage();
		}, 4000);
	}

	function hideMessage() {
		if ($("#message").css('display') == 'block') {
			$('.warningMsg').html('');
			$('#message').fadeOut('slow');
		}
	}
	
	return {
		validateInputs : validateInputs
	}
});
