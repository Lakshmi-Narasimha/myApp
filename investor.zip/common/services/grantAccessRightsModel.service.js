/**
 * @ngdoc service
 * @name Grant Access Model
 * @requires Restangular
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles the services and model for Advisor content details & widgets
 *
 */
'use strict';

var grantAccessRightsModel = function (Restangular, fticLoggerMessage, loggerConstants, $q) {
    var _accessRights = null;
    var accessModel = {
        _accessCodes : {},
        getGrantAccessRights : function (params) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.DASHBOARD_MODULE + ' | ' + loggerConstants.ADVISOR_CONTENT_MODEL + ' | getAdvisorContent' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            Restangular.one('profile/subUserModuleAccess').get(params).then(function (accessRight) {
                deferred.resolve(accessRight);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setAccessRights : function (accessRight) {
             _accessRights = accessRight.accessRights;
        },
        getAccessRights : function () {
            if (!angular.isDefined(_accessRights)) {
                return null;
            }
            return _accessRights;
        }
        
    };
    return accessModel;
};

grantAccessRightsModel.$inject = ['Restangular', 'fticLoggerMessage', 'loggerConstants', '$q'];
module.exports = grantAccessRightsModel;