/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var checkboxes = function($state) {
	return {
            template: require('./chkbox.html'),
            restrict: 'E',
            replace: true,
            scope: {
              checkboxes: '='
            },
            controller: function($scope, $element, $attrs){  
            },
            link: function(scope, iElement, iAttrs, controller){
                 scope.updateChecks = function(){
                    angular.forEach(scope.checkboxes, function(checkboxItem){
                        checkboxItem.selected = scope.allSelected;
                    });
                 };

                 scope.updateSelectAll = function(isSelected){
                    if(!isSelected){
                        scope.allSelected = false;
                    }
                 };
            }
        };
};

checkboxes.$inject = ["$state"];
module.exports = checkboxes;