// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var SubscriptionDetailsInvModelSchema = new mongoose.Schema({
    subscriptionDetails: {
        type: Object,
        'default': {}
    }
});

var SubscriptionDetailsInvModelLookUp = mongoose.model('SubscriptionDetailsInvModelLookUp', SubscriptionDetailsInvModelSchema);

var SubscriptionDetailsModel = new SubscriptionDetailsInvModelLookUp({
    subscriptionDetails: {
        'subscriptions': {
            'valuationSubscriptions': [{
                'folioPanAccounts': 'COTQW5074X',
                'flag': 'P',
                'subscriptionID': '378620',
                'subscriptionDetails': 'Weekly',
                'subscriptionBySms': 'true',
                'subscriptionByEmail': 'false'
            }, {
                'folioPanAccounts': '0100007823616',
                'flag': 'A',
                'subscriptionID': '378697',
                'subscriptionDetails': 'Weekly',
                'subscriptionBySms': 'true',
                'subscriptionByEmail': 'true'
            }, {
                'folioPanAccounts': '14449994',
                'flag': 'F',
                'subscriptionID': '378644',
                'subscriptionDetails': 'Weekly',
                'subscriptionBySms': 'false',
                'subscriptionByEmail': 'true'
            }, {
                'folioPanAccounts': '14449994',
                'flag': 'F',
                'subscriptionID': '378698',
                'subscriptionDetails': 'Monthly',
                'subscriptionBySms': 'true',
                'subscriptionByEmail': 'true'
            }, {
                'folioPanAccounts': '0110007823616',
                'flag': 'A',
                'subscriptionID': '378696',
                'subscriptionDetails': 'Daily',
                'subscriptionBySms': 'true',
                'subscriptionByEmail': 'true'
            }],
            'navSubscriptions': [{
                'subscriptionBySmsFunds': null,
                'subscriptionID': '378699',
                'subscriptionDetails': 'Daily',
                'subscriptionBySms': 'false',
                'subscriptionByEmail': 'true'
            }, {
                'subscriptionBySmsFunds': [{
                    'fundCode': '012',
                    'fundDescription': 'Franklin India Income Builder Account - Plan A - Growth'
                }, {
                    'fundCode': '011',
                    'fundDescription': 'Franklin India Income Builder Account - Plan B - Growth'
                },{
                    'fundCode': '013',
                    'fundDescription': 'Franklin India Income Builder Account - Plan C - Growth'
                }],
                'subscriptionID': '378700',
                'subscriptionDetails': 'Weekly',
                'subscriptionBySms': 'true',
                'subscriptionByEmail': 'false'
            }, {
                'subscriptionBySmsFunds': [{
                    'fundCode': '002',
                    'fundDescription': 'Franklin India Income Builder Account - Plan AA - Growth'
                }],
                'subscriptionID': '378639',
                'subscriptionDetails': 'Daily',
                'subscriptionBySms': 'true',
                'subscriptionByEmail': 'true'
            }],
            'weeklyMarketView': [{
                'subscriptionID': '378655',
                'subscriptionByEmailFunds': 'Weekly Market View',
                'subscriptionDetails': 'Weekly',
                'subscriptionByEmail': 'true'
            }]
        }
    }
});

SubscriptionDetailsInvModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SubscriptionDetailsInvModelLookUp table, please contact admin...');
    } else {
        SubscriptionDetailsInvModelLookUp.remove({}, function(err) {
            console.log('SubscriptionDetailsInvModelLookUp collection removed');
            SubscriptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SubscriptionDetailsInvModelLookUp table, please contact admin...');
                }
                console.log('SubscriptionDetailsInvModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SubscriptionDetailsInvModelLookUp;
