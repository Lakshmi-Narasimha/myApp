/**
 * @ngdoc service
 * @name FTI Dashboard Initial Load Service
 * @requires investorDashboardDetailsModel
 * @requires eventConstants
 * @requires toaster
 * @requires dashboardConstants
 * @requires $timeout
 * @description
 *
 * - Handles the services and model for investor content details & widgets
 *
 */
'use strict';

var invSmartSavingsInitialService = function(eventConstants, toaster, fticLoggerMessage, loggerConstants, $cookies, invSmartSavingsModel, investorEvents, $loader,invPanFolioKycModel) {

    var invSmartSavingsInitialService = {
        // _isServicesData: false,
        getsmartSavingsData: function() {

            var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });

            function validateSuccess(data) {
                invSmartSavingsModel.setSmartSavingsData(data);
            }

            function handleFailure(error) {

                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | promiseFailure' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'error', 'message': message });
                if (error.data.length > 0) {
                    toaster.error(error.data[0].errorDescription);
                }
            }

            function stopLoader() {
                $loader.stop();
            }
            var params = {};
            $loader.start();
            invSmartSavingsModel.getSmartSavingsDetails(params).then(validateSuccess, handleFailure).finally(stopLoader);
        }
    };
    return invSmartSavingsInitialService;
};

invSmartSavingsInitialService.$inject = ['eventConstants', 'toaster', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'invSmartSavingsModel', 'investorEvents', '$loader','invPanFolioKycModel'];
module.exports = invSmartSavingsInitialService;
