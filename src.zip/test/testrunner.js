require.config({
    baseUrl: '',
    paths: {
        jquery: 'lib/jquery.min-2.2.4',
        elementary: 'lib/elementary-1.0.0',
        lodash: 'lib/lodash.min-4.13.0',
        q: 'lib/q.min-1.4.1',
        backbone: 'lib/backbone.min-1.3.3',
        backbonesubroute: 'lib/backbone.subroute.min-0.4.5',
        text: 'lib/text.min-2.0.12',
        moment: 'lib/moment.min-2.13.0',
        momentTimezone: 'lib/moment-timezone.min-0.5.4',
        bootstrap: 'lib/bootstrap.min-3.3.6',
        'bootstrap-dialog': 'lib/bootstrap-dialog.min-1.35.1',
        CryptoJS: 'lib/sha1.min-3.1.2',
        'squire': 'test/lib/squire-2014-11-26',
        ampfComponents: 'lib/ampf-components'
    },
    map: {
        '*': {
            // backbone requires underscore...lodash is a superset of underscore
            underscore: 'lodash'
        }
    },
    shim: {
        backbone: {deps: ['underscore', 'jquery'], exports: 'Backbone'},
        bootstrap: {deps: ['jquery']},
        CryptoJS: {exports: 'CryptoJS'}
    },
    urlArgs: 'bust=' + (new Date()).getTime()
});

// Add test suites as necessary...(you don't need to declare them as function args...they register themselves with Mocha on load)
define([
    'test/tests-miscellaneous/util-test',
    'test/tests-miscellaneous/formatter-test',
	'test/tests-services/awmServices-test'
], function () {
    chai.use(chaiHtml);
    mocha.run();
});
