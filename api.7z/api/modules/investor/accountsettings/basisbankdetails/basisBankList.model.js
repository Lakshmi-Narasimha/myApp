// getBankList.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var InvBasisBankNamesSchema = new mongoose.Schema({
    basisBankNameListObject: {
        type: Object,
        "default": {}
    }
});

var InvBasisBankListLookUp = mongoose.model('InvBasisBankListLookUp', InvBasisBankNamesSchema);

var InvBasisBankListModel = new InvBasisBankListLookUp({

  "basisBankNameListObject":{
    "bankNames": [
  {
    "bank": "B1",
    "bankName": "HDFC"
  },
  {
    "bank": "B2",
    "bankName": "ICIC"
  },
  {
    "bank": "B3",
    "bankName": "DENA"
  },
  {
    "bank": "B4",
    "bankName": "YES"
  },
  {
    "bank": "B5",
    "bankName": "AXSIS"
  }  
]}

});

InvBasisBankListLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvBasisBankListLookUp table, please contact admin...');
    } else {
        InvBasisBankListLookUp.remove({}, function(err) {
            console.log('InvBasisBankListLookUp collection removed');
            InvBasisBankListModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvBasisBankListLookUp table, please contact admin...');
                }
                console.log('InvBasisBankListLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvBasisBankListLookUp;
