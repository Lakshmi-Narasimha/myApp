// getCgFolio.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var CgFolioModelSchema = new mongoose.Schema({
    folioResp: {
        type: Array,
        "default": []
    }
});

var CgFolioModelLookUp = mongoose.model('CgFolioModelLookUp', CgFolioModelSchema);

var CgFolioModel = new CgFolioModelLookUp({
  folioResp: [{
     "unitHolderDetails" : {
          "invname" : "Shankar",
          "sstatus" : "NRI",
          "address" : {
            "line1":"B-34 Acrot Street No 161 Yerapalli street",
            "line2":"Vadapallani",
            "line3":"Chennai 763001"
          }
        },

      "foliodet":[
        {
          "fundName": "Franklin India BlueChip - Fund Dividend",
          "accountNo": 5675454568,
          "purchase": {
              "TxType": "Purchase",
              "TxDate": "10 Nov 2015",
              "IndexedVal": "1230,22"
          },
          "redemption": {
              "TxType":"Redemption",
              "TxDate": "10 Nov 2015",
              "Amount": "1230,22"
          },
          "capital": {
            "shorterm": 0.00,
            "longterm": "10,12,00"
          },
           "taxded": {
            "total": 0.00,
            "stt": 169.0
          }
          
          
      },
      {
          "fundName": "Franklin India Prima Plus",
          "accountNo": 1456444456,
          "purchase": {
              "TxType": "Purchase",
              "TxDate": "10 Nov 2015",
              "IndexedVal": "1230,22"
          },
          "redemption": {
              "TxType":"Redemption",
              "TxDate": "10 Nov 2015",
              "Amount": "1230,22"
          },
          "capital": {
            "shorterm": 0.00,
            "longterm": "10,12,00"
          },
           "taxded": {
            "total": 0.00,
            "stt": 169.0
          }
          
          
      },
      {
          "fundName": "Franklin India Feeder - Franklin U.S. Opportunities Fund - (D)",
          "accountNo":1457258694,
          "purchase": {
              "TxType": "Purchase",
              "TxDate": "10 Nov 2015",
              "IndexedVal": "1230,22"
          },
          "redemption": {
              "TxType":"Redemption",
              "TxDate": "10 Nov 2015",
              "Amount": "1230,22"
          },
          "capital": {
            "shorterm": 0.00,
            "longterm": "10,12,00"
          },
           "taxded": {
            "total": 0.00,
            "stt": 169.0
          }
        }
      ]
  }          
  ]

});

CgFolioModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating CgFolioModelLookUp table, please contact admin...');
    } else {
        CgFolioModelLookUp.remove({}, function(err) {
            console.log('CgFolioModelLookUp collection removed');
            CgFolioModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating CgFolioModelLookUp table, please contact admin...');
                }
                console.log('CgFolioModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = CgFolioModelLookUp;
