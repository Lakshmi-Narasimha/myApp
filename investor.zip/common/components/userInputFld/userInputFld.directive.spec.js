describe('Directive: user Input Feild', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;            
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-user-input-fld></ftic-user-input-fld>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();
        
    });

    it('should compiled element to be defined', function(){
        expect(directiveEle).toBeDefined();
        expect(scope).toBeDefined();
        
    });

    it('should have isolated scope', function(){
        expect(directiveEle.isolateScope()).toBeDefined();
    });
    
    it('should define toggleLabel function', function() {

        isoScope.toggleLabel(event);
        // expect(isoScope.isChanged).toBe(true);
        expect(isoScope.isChanged).toBe(false);
    });

    it('should define updateParent function', function() {

        expect(isoScope.isChanged).toBe(false);
        isoScope.updateParent();
        expect(isoScope.isChanged).toBe(true);
        
    });
});
