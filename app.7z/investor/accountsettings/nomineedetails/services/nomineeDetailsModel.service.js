/**
 * @ngdoc service
 * @name Investor Nominee Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 *
 */
'use strict';

var nomineeDetailsModel= function(Restangular, $q, fticLoggerMessage, loggerConstants, appConfig, $http, authenticationService, configUrlModel) {
    var _folioNumbersList = null;

	var nomineeDetailsModel = {
        getNomineeDetails: function() {
            var deferred = $q.defer();
            var params = {};                   
            params.guId = authenticationService.getUser().guId;
            params.flag = 'P';
            Restangular.one('clients/nomineeDetails').get(params).then(function(response) {
                deferred.resolve(response);             
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setFolioNumbersList : function (folioNumbersList) {
            _folioNumbersList = folioNumbersList;
        },
        getFolioNumbersList : function () {
            if (!angular.isDefined(_folioNumbersList)) {
                return null;
            }
            return _folioNumbersList;
        },
        checkConfirmPasswordPost : function(creds){
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'confirmPassword', creds).then( function (data) {
                deferred.resolve(data);
            }, function (data) {
                console.log('Confirm Password error', data);
                deferred.reject(data);
            });
            return deferred.promise;
        },
        addEditNomineeDetails : function(body){
            var deferred = $q.defer();
            var params = {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one('clients/changeNominee').customPOST(body, '' , params, {}).then(function (success) {
                deferred.resolve(success);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        }
    };
    return nomineeDetailsModel;
};

nomineeDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'appConfig', '$http', 'authenticationService', 'configUrlModel'];
module.exports = nomineeDetailsModel;
