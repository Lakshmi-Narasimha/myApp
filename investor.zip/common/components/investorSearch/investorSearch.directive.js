/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var investorSearch = function($state, searchResultModel, eventConstants,$compile, unitHolderModel) {
	return {
            template: require('./investorSearch.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              channelSearchOptions: "="
            },
            controller: function($scope, $element, $attrs){

              var pageRange = {},
                    pageOffset = 1,
                    limit = 5,
                    previousPage = 0
                    ;
                pageRange.limit = 5;
                pageRange.offset = 1;
                $scope.paginationObject = {
                    paginationTotal : 1,
                    currentPage : 1
                };
                $scope.pageChanged = function() {
                  $scope.showSearchResult = false;
                  if($scope.paginationObject.currentPage === 1){
                      pageRange.offset = 1;
                  }else{
                      pageRange.offset = (pageRange.limit * ($scope.paginationObject.currentPage-1)) + 1;
                  }
                  searchResultModel.fetchSearchResult($scope.searchQuery,pageRange).then (function (data) {
                    $scope.searchResult = [];
                    $scope.searchResult=data;
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;

                    angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                    })

                    $scope.showSearchResult = true;
                  }, function (data) {
                      $scope.searchResult = [];
                  });
                }; 
                
                $scope.includeZeroBalanceAccounts = {};
                $scope.closePop = {};
                $scope.showSearchResult = false;
                $scope.ShowAllFundsGrid = false;
                $scope.activeVar = false;
                // $scope.isOpen = true;
                var isStatusTemplate = '<div uib-popover-template="\'isVeiwCompTemplate.html\'" popover-is-open="col.colDef.value[row.entity.index]" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                              '<script type="text/ng-template" id="isVeiwCompTemplate.html">' +
                              '<div class="fti-popClass">' +
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:0,data:row.entity})" class="btn panel-orange-btn mt0">Valuation/Statements</button>' + 
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:1,data:row.entity})" class="btn panel-orange-btn">Systematic plans</button>' + 
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:2,data:row.entity})" class="btn panel-orange-btn">Transactions</button>' + 
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:3,data:row.entity})" class="btn panel-orange-btn">Subcriptions</button>' + 
                              '</div></script>';

                $scope.searchResult = [];


                $scope.fundDetailsGrid = [];
                $scope.gridOptions={};
               

                //var arr = [false,false,false,false];
                var arr = []

                $scope.gridOptions.columnDefs = [

                  { field: 'custName',displayName:'', width:"5%", value:arr,cellTemplate: isStatusTemplate, enableSorting:false, pinnedLeft:true},
                  { field: 'custName', displayName: 'Unit Holder Name', width:"180", cellTemplate: '<div class="ui-grid-cell-contents ftic-uhName" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'unitHolderNameRedirect\', {tabNo:0,data:row.entity})">{{grid.getCellValue(row, col)}}</div>', enableSorting:false, pinnedLeft:true, footerCellTemplate: '<div class="ui-grid-cell-contents">Total</div>'},                        
                  { field: 'pan', displayName: 'PAN', width:"140", enableSorting:false},
                  { field: 'folioId', displayName: 'Folio No.', width:"154", enableSorting:false},
                  { field: 'holdingType', displayName: 'Mode of Holding', width:"180",  enableSorting:false},
                  { field: 'mobile', displayName: 'Mobile No', width:"154", enableSorting:false},
                  { field: 'emailId', displayName: 'Email ID', width:"254",  enableSorting:false},
                  { field: 'city', displayName: 'City', width:"154",  enableSorting:false}
                  
                ];

                $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) {                  
                  $scope.searchQuery = {};
                  if(args.searchOption === "Unit Holder Name"){
                    $scope.searchQuery.searchType = "N";
                  }else if(args.searchOption === "PAN"){
                    $scope.searchQuery.searchType = "P";
                  }else if(args.searchOption === "Folio No."){
                    $scope.searchQuery.searchType = "F";
                  }else if(args.searchOption === "Mobile No."){
                    $scope.searchQuery.searchType = "M";
                  }else if(args.searchOption === "Email ID"){
                    $scope.searchQuery.searchType = "E";
                  }else if(args.searchOption === "Aadhaar No."){
                    $scope.searchQuery.searchType = "U";
                  }else if(args.searchOption === "Account No."){
                    $scope.searchQuery.searchType = "A";
                  }else if(args.searchOption === "CAN"){
                    $scope.searchQuery.searchType = "C";
                  }else if(args.searchOption === "IIN"){
                    $scope.searchQuery.searchType = "I";
                  }
                  
                  $scope.searchQuery.searchValue = args.searchText;
                  $scope.showSearchResult = false;
                  $scope.noSearchData = false;
                  $scope.searchQuery.active = "Y";
                  $scope.includeZeroBalanceAccounts.zeroBalAccounts = false;
                  searchResultModel.fetchSearchResult($scope.searchQuery,pageRange).then (function (data) {
                    $scope.searchResult = [];
                    $scope.searchResult=data;
                    searchResultModel.setsearchresult(data);
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;

                    angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                    });
                    $scope.$emit('showText', true);
                    $scope.showSearchResult = true;
                  }, function (data) {
                      $scope.searchResult = [];
                      if($scope.searchResult.length === 0) {
                        $scope.showSearchResult = true;
                        $scope.noSearchData = true;
                      }
                  });

                }); 

				$scope.$on('setmyinvestorexistdata',function(){
					$scope.showSearchResult = false;
                  	$scope.noSearchData = false;
                  	$scope.includeZeroBalanceAccounts.zeroBalAccounts = false;                  	
					$scope.searchResult = searchResultModel.getsearchresult();
					angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                    });
                    $scope.$emit('showText', true);
                    $scope.showSearchResult = true;
				});

                $scope.zeroBalanceAccounts = function(){

                  if($scope.includeZeroBalanceAccounts.zeroBalAccounts){
                    $scope.active = "N";
                  }else{
                    $scope.active = "Y";
                  }

                  $scope.$emit('disableEvent');

                  $scope.searchQuery.active = $scope.active;
                  $scope.showSearchResult = false;

                  searchResultModel.fetchSearchResult($scope.searchQuery,pageRange).then (function (data) {
                    $scope.searchResult = [];
                    $scope.searchResult=data;
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;

                    angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                    })

                    $scope.showSearchResult = true;
                  }, function (data) {
                      $scope.searchResult = [];
                  });
                };

                $scope.$on(eventConstants.HIDE_SEARCH_RESULT, function (event, args) {                 
                  $scope.showSearchResult = false;
                  $scope.searchResult = [];
                  //$scope.$emit('disableEvent');
                  
                });

                $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, function (event, args) {                  
                  $scope.showSearchResult = false;
                  $scope.searchResult = [];
                  $scope.ShowAllFundsGrid = false;
                  $scope.$emit('disableEvent');
                });

                 $scope.$on(eventConstants.GET_SUGGESTIONS, function (event, args) {
                    $scope.$emit('showText', false);
                    $scope.showSearchResult = false;
                    $scope.searchResult = [];
                    $scope.$emit('disableEvent');

                  // $scope.$broadcast(eventConstants.SET_SUGGESTIONS, {"suggestions": suggestions});                                       
                });               
            },

            link: function(scope, element, iAttrs, controller){
              
                scope.$on('unitHolderNameRedirect', function(event, data){
                  if(unitHolderModel.setUnitHolderNameClickabl){
                    scope.$emit("showTab", data);
                  }
                });
                            

                scope.$on('showTab', function(event, data){
                  scope.activeVar = true;
                  scope.$emit('activeEvent',scope.activeVar);
                });
            }
        };
};

investorSearch.$inject = ['$state','searchResultModel', 'eventConstants','$compile', 'unitHolderModel'];
module.exports = investorSearch;