define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appcommon/analytics',
  'appmodules/accountviewer/app/data/accounttaxonomymapping',
  'services/accountdetailservice',
  'text!appmodules/accountviewer/app/templates/accountdetailsview.html',
  'text!appmodules/accountviewer/app/templates/accountdetailfixedsection.html',
  'text!appmodules/accountviewer/app/templates/accountdetailexpandablesection.html',
  'appcommon/commonutility'
], function ($, _, Backbone, Spinner, Analytics, taxonomyMapping, dataService, AccountDetailsViewHtml, FixedSectionHtml, ExpandableSectionHtml, CommonUtility) {
    var brkgProdClsCds = CommonUtility.getBrkgProdClsCds();
    var AccountDetailsView = Backbone.View.extend({
        clientId:  null,
        groupId:  null,
        accountSummary: null, 
        errorHandler: null,
        clientPickHandler: null,
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        template: _.template(AccountDetailsViewHtml),
        fixedSectionTemplate: _.template(FixedSectionHtml),
        expandableSectionTemplate: _.template(ExpandableSectionHtml),
        productTaxonomyKey: null,
        productViewDefinition: null,
        sectionViews: {},
        sectionsPreviouslyExpanded: {},
        events: { 
          'click [pt-detail-return-button]': 'handleBackToAccountList',
          'click [pt-detail-section-expander-button]': 'handleExpandCollapseSection',
        },
        initialize: function (options) {
          _.extend(this, _.pick(options, 'clientId', 'groupId', 'accountSummary', 'errorHandler', 'clientPickHandler'));  // copies constructor attributes to this
          _.bindAll(this, 'renderSections', 'handleExpandCollapseSection');
        },
        handleBackToAccountList: function (e) {
          e.preventDefault();
          Backbone.history.navigate("accountviewer/", true);
        },
        handleExpandCollapseSection: function (e) {      
        	var $section = $(e.target).closest('[pt-detail-section]');
          var sectionId = $section.attr('pt-detail-section');
          var $sectionContent = $section.find('[pt-detail-section-contents]');
          var isCollapsed = $sectionContent.css('display') == 'none';
          this.toggleExpandCollapseIcon($section.find('[pt-detail-section-expander-icon]'), !isCollapsed);
          if (isCollapsed) {
            var sectionView = this.sectionViews[sectionId];
            this.renderViewInSection(sectionView, sectionId);
            $sectionContent.slideDown();
            if (!this.sectionsPreviouslyExpanded[sectionId]) {
              this.sectionsPreviouslyExpanded[sectionId] = true;
              Analytics.analytics.recordAction('AccountDetailView:' + this.productTaxonomyKey + ':' + sectionId  + ':Expanded');
            }
          } else {
            $sectionContent.slideUp();
          }
        },
        toggleExpandCollapseIcon: function($expandCollapse, shouldBeCollapsed) {
          $expandCollapse.toggleClass("icon-plus", shouldBeCollapsed);
          $expandCollapse.toggleClass("icon-minus", !shouldBeCollapsed);
        },
        render: function() {
          var self = this;
          Spinner.show();
          dataService.promiseToGetProductTaxonomy(this.accountSummary.accountId)
          .then(function(taxomonyProperties) {
              $(window).scrollTop(0);
              Spinner.hide();
              self.$el.html(self.template({ "brkgProdClsCds": brkgProdClsCds, accountData: self.accountSummary }));
              self.productTaxonomyKey = taxomonyProperties.ptrnCd + '/' + taxomonyProperties.srcSysCd + '/' + self.accountSummary.statusCd;
              self.productViewDefinition = _.clone(taxonomyMapping[self.productTaxonomyKey]);
              self.productViewDefinition.sections = self.filterProductSections(self.productViewDefinition, self.accountSummary);
              if (self.productViewDefinition) {
                  self.renderSections();
                  Analytics.analytics.recordAction('AccountDetailView:' + self.productTaxonomyKey + ':SelectedFromAccountList');
              } else {
                  self.handleError("no taxonomy mapping found for " + self.productTaxonomyKey);
              }
          })
          .fail(function(error) {
              Spinner.hide();
              history.back();
              if (error.jqXHR && error.jqXHR.status == 401) {
                  BootstrapDialog.alert("You are not authorized to view the details of this account.", "", "Unauthorized");
              } else {
                  self.handleError(error);
              }
          });
        },
        renderSections: function() {
            var self = this;
            var html = [];
            _.each(self.productViewDefinition.sections, function(section) {
                var sectionView = new section.view({clientId: self.clientId, groupId: self.groupId, accountSummary: self.accountSummary, errorHandler: self.errorHandler, clientPickHandler: self.clientPickHandler});
                self.sectionViews[section.id] = sectionView;
                var sectionData = { section: section };
                if (section.isExpandable) {
                    html.push(self.expandableSectionTemplate(sectionData));
                } else {
                    html.push(self.fixedSectionTemplate(sectionData));
                }
                $('#pt-accountdetail-sections').html(html.join(''));
            });
            self.renderFixedSections();
        },
        renderFixedSections: function() {
            var self = this;
            _.each(self.productViewDefinition.sections, function(section) {
                if (!section.isExpandable) {
                    var sectionView = self.sectionViews[section.id];
                    self.renderViewInSection(sectionView, section.id);
                }
            });
        },
        renderViewInSection: function(sectionView, sectionId) {
           sectionView.setElement('[pt-detail-section-contents="' + sectionId + '"]').render();
        },
        filterProductSections: function(productViewDefinition, accountSummary) {
            return _.filter(productViewDefinition.sections, function(section) {
                if (section.omit) {
                  return !section.omit(accountSummary);
                } else {
                  return true;
                }
            });
        },
        beforeClose: function () {            
            _.each(_.values(this.sectionViews), function(sectionView) {
              sectionView.close();
            });
        },
        handleError: function(error) {
          if (this.errorHandler) {
            this.showRetry(true);
            this.errorHandler(error);
          } else {
            console.log(error);
          }
        },
        showRetry: function(shouldShow) { 
          var $retry = this.$el.find('#pt-accountdetail-error-retry');
          if (shouldShow) {
            $retry.toggleClass('hidden', false);
            var $retryButton = this.$el.find("[pt-accountdetail-retry-button]");
            var self = this;
            $retryButton.off("click").on('click', function() {
              self.showRetry(false);
              self.render();
            })
          } else {
            $retry.toggleClass('hidden', true);
          }
        }
    });;

    return AccountDetailsView;
});