var config = require('../../../config/config');

var engagementModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [{
                    "state": "assigned",
                    "agentGroupID": "10004688",
                    "sequenceNumberInt": 2,
                    "messageList": [{
                        "loginReq": false,
                        "messageText": "VZW MobApp Tester joined the conversation"
                    }],
                    "animationDuration": 800,
                    "type": "header",
                    "msgId": 10000,
                    "messageType": "stateChange",
                    "sequenceNumber": "2"
                }],
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "dcc06d18-64cf-4823-a53b-05ed2733b2c0",
                    "type": "Success",
                    "topMessage": "You're chatting with VZW MobApp Tester"
                }
            }
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "agentName": "VZW MobApp Tester",
            "agentID": "vzw-mobile-app-03",
            "callType": "engagement",
            "timeToWait": null,
            "engagementID": "-1196452972424366591",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "dcc06d18-64cf-4823-a53b-05ed2733b2c0",
            "type": "Success",
            "topMessage": "You're chatting with VZW MobApp Tester"
        }
    },
    createRequestUri: {
        Billing: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Billing,
        },
        WirelessSales: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessSales + '&agentGroupID=' + config.AG_WirelessSales,
        },
        Device: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Device,
        },
        Global: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Global,
        },
        MVTrans: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_MVTrans,
        }
    }
};

module.exports = engagementModelConfig;
