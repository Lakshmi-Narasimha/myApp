// AssetFundDetailsModel.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AssetFundDetailsModelSchema = new mongoose.Schema({
    AssetFundDetails: {
        type: Array,
        "default": []
    }
});

var AssetFundModelLookUp = mongoose.model('AssetFundModelLookUp', AssetFundDetailsModelSchema);

var AssetFundDetailsModel = new AssetFundModelLookUp({
        "AssetFundDetails":
        [{
          "finAssetFund":
                [   
                    {
                        "category": "equity",
                        "title": "Equity",
                        "funds":[
                            {
                                "category": "fund1",
                                "title": "Franklin India Prima Plus"        
                            },
                            {
                                "category": "fund2",
                                "title": "Franklin India Taxshield"
                            },   
                        ]
                    },
                    {
                        "category": "fixedIncome",
                        "title": "Fixed Income",
                        "funds":[
                            {
                                "category": "fund3",
                                "title": "Franklin India Balanced Fund"
                            },
                            {
                                "category": "fund4",
                                "title": "Franklin Dynamic Accrual Fund"
                            }
                        ]
                    },
                    {
                        "category": "balanced",
                        "title": "Balanced",
                        "funds":[
                            {
                                "category": "fund5",
                                "title": "Franklin India Prima Plus"
                            },
                            {
                                "category": "fund6",
                                "title": "Franklin India Taxshield"
                            }
                        ]
                    },
                    {
                        "category": "ELSS",
                        "title": "ELSS",
                        "funds":[
                            {
                                "category": "fund7",
                                "title": "Franklin India Balanced Fund"
                            },
                            {
                                "category": "fund8",
                                "title": "Franklin Dynamic Accrual Fund"
                            }
                        ]
                    },
                    {
                        "category": "FoF",
                        "title": "FoF",
                        "funds":[
                            {
                                "category": "fund9",
                                "title": "Franklin India Prima Plus"
                            },
                            {
                                "category": "fund10",
                                "title": "Franklin India Taxshield"
                            }
                        ]
                    },
                    {
                        "category": "feeder",
                        "title": "Feeder",
                        "funds":[
                            {
                                "category": "fund11",
                                "title": "Franklin Dynamic Accrual Fund"
                            },
                            {
                                "category": "fund12",
                                "title": "Franklin India Balanced Fund"
                            }
                        ]
                    },
                    {
                        "category": "liquid",
                        "title": "Liquid",
                        "funds":[
                            {
                                "category": "fund13",
                                "title": "Franklin India Taxshield"
                            },
                            {
                                "category": "fund14",
                                "title": "Franklin India Balanced Fund"
                            }
                        ]
                    }
                ],
                "nonfinAssetFund":
                [   
                    {
                        "category": "equity",
                        "title": "Equity",
                        "funds":[
                            {
                                "category": "fund1",
                                "title": "Franklin India Prima Plus"        
                            },
                            {
                                "category": "fund2",
                                "title": "Franklin India Taxshield"
                            },   
                        ]
                    },
                    {
                        "category": "fixedIncome",
                        "title": "Fixed Income",
                        "funds":[                            
                            {
                                "category": "fund4",
                                "title": "Franklin Dynamic Accrual Fund"
                            }
                        ]
                    },
                    {
                        "category": "balanced",
                        "title": "Balanced",
                        "funds":[
                            {
                                "category": "fund5",
                                "title": "Franklin India Prima Plus"
                            }
                        ]
                    },
                    {
                        "category": "ELSS",
                        "title": "ELSS",
                        "funds":[
                            {
                                "category": "fund7",
                                "title": "Franklin India Balanced Fund"
                            },
                            {
                                "category": "fund8",
                                "title": "Franklin Dynamic Accrual Fund"
                            }
                        ]
                    },
                    {
                        "category": "FoF",
                        "title": "FoF",
                        "funds":[
                            {
                                "category": "fund9",
                                "title": "Franklin India Prima Plus"
                            }
                        ]
                    },
                    {
                        "category": "feeder",
                        "title": "Feeder",
                        "funds":[
                            {
                                "category": "fund11",
                                "title": "Franklin Dynamic Accrual Fund"
                            },
                            {
                                "category": "fund12",
                                "title": "Franklin India Balanced Fund"
                            }
                        ]
                    },
                    {
                        "category": "liquid",
                        "title": "Liquid",
                        "funds":[
                            {
                                "category": "fund13",
                                "title": "Franklin India Taxshield"
                            }
                        ]
                    }
                ]  
        }]
});

AssetFundModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AssetFundModelLookUp table, please contact admin...');
    } else {
        AssetFundModelLookUp.remove({}, function(err) {
            console.log('AssetFundModelLookUp collection removed');
            AssetFundDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating AssetFundModelLookUp table, please contact admin...');
                }
                console.log('AssetFundModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AssetFundModelLookUp;