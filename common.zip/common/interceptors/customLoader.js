/**
 *@ngdoc service
 *@name common.interceptors.errorinterceptor
 *@description
 * <p>
 * Error Interceptor Module to handle system error or exception occurs during  pre-processing of
 * request or postprocessing of responses. Intercept requests before they are handed to
 * the server and responses before they are handed
 * over to the application code that initiated these requests
 * </p>
 * @project FTIC-Advisor
 *
 */
'use strict';
var customLoader = function ($q, $rootScope, $log) {
    //var log = fticLogger.getLogger('errorInterceptor');
     var numLoadings = 0;
    return {
        request: function (config) {
            //alert("hello")
            numLoadings++;

            // Show loader
            $rootScope.$broadcast("loader_show");
            return config || $q.when(config)

        },
        response: function (response) {

            if ((--numLoadings) === 0) {
                // Hide loader
                $rootScope.$broadcast("loader_hide");
            }

            return response || $q.when(response);

        },
        responseError: function (response) {

            if (!(--numLoadings)) {
                // Hide loader
                $rootScope.$broadcast("loader_hide");
            }

            return $q.reject(response);
        }
       
    };
};

customLoader.$inject = ['$q', '$rootScope', '$log'];
module.exports = customLoader;
