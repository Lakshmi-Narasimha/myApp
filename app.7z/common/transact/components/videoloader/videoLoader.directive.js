/**
 * @ngdoc property
 * @name videoLoader Directive
 * @description
 *
 * Displays Video
 *
 **/
'use strict';

var videoLoader = function($uibModal, constants) {
	return {
        template: require('./videoLoader.html'),
        restrict: 'E',
        replace: false,
        scope: {
            videosData: '=',
            stateName: '='
        },
        controller: function($scope){
            
            $scope._URLLIST = $scope.videosData['links-list'];
            $scope._URLLIST.every(function(element) {

                if(constants.investor.VIDEO_CONSTANTS[$scope.stateName] === element.id) {
                    $scope.currentUrl = element.url;
                    return false;
                } else {
                    return true;
                }
            });

            $scope.openInvVideoModal = function() {  
                $uibModal.open({
                    template : require('../invvideomodal/invVideoModal.html'),
                    scope: $scope
                });
            };  
         
        },
        link: function(){

        }
    };
};

videoLoader.$inject = ['$uibModal', 'constants'];
module.exports = videoLoader;