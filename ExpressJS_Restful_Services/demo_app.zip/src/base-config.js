define([
], function () {
    var config = {
        oboServicePath: 'http://dev12hq508.ampf.com/amp/adv_capl/oboselector/',
        awmServicePath:'http://dev12hq508.ampf.com/amp/ods.svc/',
        mgpServiceUrl:'http://dev20hq508.ampf.com:8081/ResponseProviderService/svc/mgp/',
        mgpSubscriptionUrl: 'http://laa2app2527xrp:10108/fumigo.svc/',
        launchMgpUrl: 'pt-exit-mgp-scenario-1.html',
        sendAnalyticsToOmniture: false,
        enableAnalyticsConsoleLogging: false,
        omnitureSAccount: "amppracviewerdev",
        enableErrorLogging: false
    };

    return config;

});
