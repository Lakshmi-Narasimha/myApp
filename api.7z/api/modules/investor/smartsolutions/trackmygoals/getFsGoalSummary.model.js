// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var fsGoalSummarySchema = new mongoose.Schema({
    fsGoalSummaryObject: {
        type: Object,
        "default": {}
    }
});

var InvFsGoalSummaryLookup = mongoose.model('InvFsGoalSummaryLookup', fsGoalSummarySchema);

var InvFsGoalSummaryModel = new InvFsGoalSummaryLookup({

  fsGoalSummaryObject : {
  "fsGoalSummary": [
    {
      "goalId": "",
      "SNO": "1",
      "goal": "Wealth Builderaaaa",
      "goalDetails": "Marriage",
      "mktvalue": "1863.56",
      "targetAmount": "36000",
      "timeFrame": "3",
      "pendingTimeFrame": "0",
      "futureReturn": "42000",
      "initcap": "4.44",
      "series": "Wealth Builder-Marriage - ",
      "achieved": "5.18%",
      "completedTime": "100%",
      "investmentAmount": "",
      "goalText": "",
      "birthDate": "01/OCT/1999"
    }
  ]
}

});

InvFsGoalSummaryLookup.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvFsGoalSummaryLookup table, please contact admin...');
    } else {
        InvFsGoalSummaryLookup.remove({}, function(err) {
            console.log('InvFsGoalSummaryLookup collection removed');
            InvFsGoalSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvFsGoalSummaryLookup table, please contact admin...');
                }
                console.log('InvFsGoalSummaryLookup table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvFsGoalSummaryLookup;
