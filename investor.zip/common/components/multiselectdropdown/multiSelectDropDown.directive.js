/**
 * @ngdoc property
 * @name multiSelectDropDown directive
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var multiSelectDropDown = function() {
	return {
            template: require('./multiSelectDropDown.html'),
            restrict: 'E',
            replace: true,
            scope: {
              header : "=",
              list : '=',
              selectedCount : '='
            },
            controller: function($scope, $element, $attrs){
                $scope.selectedCount = $scope.selectedCount || 'Select'; 
                $scope.selection = [];
                $scope.toggleSelection = function toggleSelection(option) {
                    var idx = $scope.selection.indexOf(option);

                    // is currently selected
                    if (idx > -1) {
                      $scope.selection.splice(idx, 1);
                    }

                    // is newly selected
                    else {
                      $scope.selection.push(option);
                    }
                    $scope.$emit('multiSelectDropdownOptions',{'header' : $scope.header, 'selection' : $scope.selection});
                };

                $scope.$on('resetSelectDropdownOptions', function(event, headerText, accounts) {
                    if($scope.header === headerText) {
                        _.each(accounts, function(account) {
                            var idx = $scope.selection.indexOf(account);
                            if (idx > -1) {
                                $scope.selection.splice(idx, 1);
                            }
                        });
                        $scope.$emit('multiSelectDropdownOptions',{'header' : $scope.header, 'selection' : $scope.selection});
                    }
                });

            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

multiSelectDropDown.$inject = [];
module.exports = multiSelectDropDown;