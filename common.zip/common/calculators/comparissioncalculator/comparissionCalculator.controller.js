/**
 * @ngdoc property
 * @name Comparission Calculator Controller
 * @requires $scope
 * @requires $state
 * @requires constants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/
'use strict';
function comparissionCalculatorController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel, calculatorsConstants, comparisonCalculatorInitialService, comparisonCalculatorModel, calculatorsEventConstants, fticStateChange) {
    $scope.init = function() {
        if ($state.current && $state.current.data && $state.current.data.isAdvisor) {
            $scope.isAdvisor = $state.current.data.isAdvisor;
        }
        $scope.$emit('setBreadCrumb', {
            cat: 'funds',
            subcat: 'tools',
            breadCrumb: {
                label: 'SIP Vs Lumpsum Calculator',
                state: ''
            }
        });
        comparisonCalculatorInitialService.loadAllServices($scope);
    };

    $scope.init();

    $scope.statusTypes = [{
        label: calculatorsConstants.SIP_CAL,
        value: $state.current.parent + '.sip',
        selected: false
    }, {
        label: calculatorsConstants.LUMP_CAL,
        value: $state.current.parent + '.lumpsum',
        selected: false
    }];

    $scope.radios = {};
    // if($scope.radios == {}){
    $scope.radios.selectedVal = $state.current.parent + '.sip';
    fticStateChange.stateChange($state, $scope.radios.selectedVal);
    //$state.go($scope.radios.selectedVal);
    // };

    $scope.listenChange = function() {
        fticStateChange.stateChange($state, $scope.radios.selectedVal);
        //$state.go($scope.radios.selectedVal);
    };

    $scope.$on(calculatorsEventConstants.COMPARISON_FUND_SUBMIT, function(event, calculatorReq) {
        // console.log(calculatorReq);
        comparisonCalculatorModel.callComparisonCalculatorData({
            'comparisionCalculatorReq': calculatorReq
        }, $scope.isAdvisor).then(function(data) {
            //console.log('comparisonFundDetails');
            comparisonCalculatorModel.setComparisonCalculations(data.comparisionCalculatorResp);
            $scope.$broadcast(calculatorsEventConstants.COMPARISON_FUND_CHART);

        }, function() {
            //console.log('ERROR')
        });
    });

}

comparissionCalculatorController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsConstants', 'comparisonCalculatorInitialService', 'comparisonCalculatorModel', 'calculatorsEventConstants', 'fticStateChange'];
module.exports = comparissionCalculatorController;