/**
 * @ngdoc directive
 * @name sticky-header 
 * @requires eventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - It displays the count of recommendations and notifications in the transaction status bar 
 *   (sticky header) section of the advisor dashboard page.
 * 
 *
 **/

'use strict';

var stickyHeader = function( fticLoggerMessage, loggerConstants, eventConstants, constants, $cookies, authenticationService){
	return{
		template : require('./stickyHeader.html'),
		restrict : 'E',
		controller : function($scope, $element, $attrs) {

			/*if($scope.app === "advisor"){
				$scope.transactOptions = advTransactOptions;
			} else {
				$scope.transactOptions = invTransactOptions;
			}*/

			if(authenticationService.getAppName() === 'guest') {
				$scope.isAdvInvApp = false;
			}else{
				$scope.isAdvInvApp = true;
			}

			$scope.redirectAdvisorApp = $cookies.get("userRedirectURI");

			$scope.transactOptions = constants[$scope.app].TRANSACT_CONSTANTS;

			var recCount = $scope.$on(eventConstants.Dashboard.ADV_RC_CNT,function(event,data){

				var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.ADVISOR_COMPONENTS_MODULE + ' | ' + loggerConstants.STICKY_HEADER_DIRECTIVE + ' | on ' + eventConstants.Dashboard.ADV_RC_CNT + ' event' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

				$scope.recommendationsCount = data.advisorRecommendationsCount;				
				$scope.destroyEvent();								
			})
			
			$scope.$on(eventConstants.Dashboard.ADV_NOT_CNT,function(event,data){							

				var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.ADVISOR_COMPONENTS_MODULE + ' | ' + loggerConstants.STICKY_HEADER_DIRECTIVE + ' | on ' + eventConstants.Dashboard.ADV_NOT_CNT + ' event' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

				$scope.notificationsCount = data.advisorNotificationsCount;
			})

			$scope.destroyEvent = function () {
				recCount();
			}

			$scope.reset = function(){
				
				$scope.$emit(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_RESET, {});
			}
		}		
	}
}

stickyHeader.$inject = ['fticLoggerMessage', 'loggerConstants', 'eventConstants', 'constants', '$cookies', 'authenticationService'];
module.exports = stickyHeader;