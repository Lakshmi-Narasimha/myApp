/**
 * @ngdoc directive
 * @name msgNotification
 * @description
 *
 * - It displays a tittle which need to be passed while declaring this directive and count.
 * 
**/

'use strict';

var msgNotification = function (){
	return {
		template : require('./msgNotification.html'),
		restrict : 'E',
		scope : {
			messageText: '='
		}
	};
};

msgNotification.$inject = [];
module.exports = msgNotification;