'use strict';

describe('Directive: Smart Solutions Grid Directive', function() {

    var compile, scope, directiveElem, isoScope, validHtml;
    var getCompiledElement = function() {
        var element = angular.element('<ftic-smart-solutions-grid></ftic-smart-solutions-grid>');
        var compiledDirective = compile(element)(scope);
        scope.$digest();
        return compiledDirective;
    };

    //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            directiveElem = getCompiledElement();
        });

    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should be created with scope:true', function() {
        expect(directiveElem.scope()).toBeDefined();
    });

    it('should applied template', function() {
        expect(directiveElem.html()).not.toEqual('');
    });
    it('should be scope data rendered in template', function() {
        var goalAchievedTemplate = '<div class="ui-grid-cell-contents"><div class="grid-cell-progress-text"><span class="custom-bold">{{row.entity.achieved}}</span>  {{ row.entity.encourageText}}</div><div class=""><uib-progressbar type="success" value="row.entity.achieved.slice(0,row.entity.achieved.length-1)"></uib-progressbar></div><div ng-bind-html="row.entity.achievedAmount | fticRupee"></div></div>';
        var rupeeTemplate = '<div class="ui-grid-cell-contents" ng-bind-html="grid.getCellValue(row, col) | fticRupee"></div>';
        var btnTemplate = '<button ui-sref="startsip" type="button" class="btn panel-orange-btn mt+">{{"VIEW_DETAILS" | translate}}</button>';
        var yearsToGoalTemplate = '<div class="ui-grid-cell-contents">{{grid.getCellValue(row, col)+ " years" }}</div>';
        scope.columnDefs = [
            { field: 'goalName', displayName: 'GOAL', width: '130', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting: false },
            { field: 'investment', displayName: 'INVESTMENT', width: '130', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: rupeeTemplate, enableSorting: false },
            { field: 'targetAmount', displayName: 'GOAL AMOUNT', width: '130', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: rupeeTemplate, enableSorting: false },
            { field: 'pendingTimeFrame', displayName: 'YEARS TO GOAL', width: '130', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: yearsToGoalTemplate, enableSorting: false },
            { field: 'achievedAmount', displayName: 'GOAL ACHIEVED', width: '200', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: goalAchievedTemplate, enableSorting: false },
            { field: 'achievedAmount', displayName: ' ', width: '114', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: btnTemplate, enableSorting: false }
        ];
        scope.$digest();

        expect(scope.columnDefs).toBeDefined();
        expect(scope.columnDefs[0].field).toBe('goalName');

        expect(angular.element(directiveElem.find('span')[0]).text()).toBe('GOAL');
        expect(angular.element(directiveElem.find('span')[4]).text()).toBe('GOAL AMOUNT');
        expect(directiveElem.find('button').length).toEqual(4);

    });

    it('should populate data on grid', function() {
        scope.smartSol= {
            goals: [{
                'goalId': 'G1234',
                'goalName': 'Wealth Creation',
                'investment': '75,000.87',
                'targetAmount': '2,16,000 ',
                'achievedAmount': '1,25,876.90',
                'pendingTimeFrame': '32',
                'encourageText': 'Great start!',
                'achieved': '15.07%'
            }]
        }
        scope.$digest();

        expect(scope.smartSol.goals).toBeDefined();
        expect(scope.smartSol.goals[0].goalId).toBe('G1234');
        expect(directiveElem.find('i').length).toEqual(6);
    });

});
