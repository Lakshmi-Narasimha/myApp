/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var unitHolderDetails = function($timeout, eventConstants) {
	return {
            template: require('./unitHolderDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
               
            },
            controller: function($scope, $element, $attrs){

               $scope.displayMsg = "Please provide consent for Aadhaar Verification for the below Unit Holders";                
               $scope.continueMsg = "Please Enter OTP receive from Aadhaar for below Unit Holders"
               

               $scope.firstHolderDetails = [
                    {key:"First Holder Name",value:"Shankar Naraynan"},
                    {key: "PAN/PEKRN", value: "AMRPB4446B"},
                    {key: "KYC Status", value: "Registered"}
                ]

                $scope.secondHolderDetails = [
                    {key:"Second Holder Name",value:"Shyama Shankar"},
                    {key: "PAN/PEKRN", value: "AWSPS6728L"},
                    {key: "KYC Status", value: "Not Registered"}
                ]  

                $scope.thirdHolderDetails = [
                    {key:"Third Holder Name",value:"Shyama Shankar"},
                    {key: "PAN/PEKRN", value: "AWSPS6728L"},
                    {key: "KYC Status", value: "Not Registered"}
                ]

                $scope.inputFieldsForSecondHolder = [
                  {
                    text: "Aadhaar",
                    value: "",
                    message: "",
                    isRequired: true
                  },
                  {
                    text: "One Time Password (OTP)",
                    value: "",
                    message: "",
                    isRequired: true
                  }
                ];

                $scope.inputFieldsForThirdHolder = [
                  {
                    text: "Aadhaar",
                    value: "",
                    message: "",
                    isRequired: true
                  },
                  {
                    text: "One Time Password (OTP)",
                    value: "",
                    message: "",
                    isRequired: true
                  }
                ];

                $scope.continueFunction = function(){
                  console.log("continueFunction");
                } 

                $scope.isSubmitted = false;
                $scope.submitFunction = function(){
                  console.log("submitFunction");
                  $scope.isSubmitted = true;
                  $scope.displayMsg = $scope.continueMsg;

                }

                $scope.$on("INPUT_CHANGED",function(event,args){
                    console.log(args);
                });
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

unitHolderDetails.$inject = ['$timeout', 'eventConstants'];
module.exports = unitHolderDetails;