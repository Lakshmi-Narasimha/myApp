// npm modules
var express = require('express');
var https = require('https');
var bodyParser = require('body-parser');
var querystring = require('querystring');

//url config file
var config = require('./config/config');

var app = express();
// set our port
var port = process.env.PORT || 9000;

// get all data/stuff of the body (POST) parameters
// parse application/json
app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: false
}));

//app.UseCors(CorsOptions.AllowAll);
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// set the static files location
app.use(express.static(__dirname + '/'));

// authenticate touchcommerce
function authenticateTouchCommerce(req, res, next) {
    // authenticate
    var post_data = querystring.stringify({
        'j_username': 'VWMobApp',
        'j_password': 'x95VIFsC',
        'submit': 'login'
    });
    var proxyRequest = https.request({
            host: config.TC_SERVER_NAME,
            method: 'POST',
            path: config.TC_FORM_LOGIN_URI,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(post_data)
            },
            rejectUnauthorized: false
        },
        function(proxyResponse) {
            console.log(proxyResponse.headers);
            var sessionCookie = proxyResponse.headers["set-cookie"].toString().split(";");
            proxyResponse.setEncoding('utf8');

            proxyResponse.on('data', function(chunk) {
                if (sessionCookie) {
                    req.sessionCookie = app.sessionCookie = sessionCookie[0];
                    //res.send(chunk);
                    next();
                } else {
                    app.sessionCookie = null;
                    chunk.message = 'ERROR!!! failed to login into website';
                    res.send(chunk);
                }
            });
            proxyResponse.on('error', function(err) {
                app.sessionCookie = null;
                err.message = 'ERROR!!! failed to login into website';
                res.send(err);
            });
        });

    proxyRequest.write(post_data);
    proxyRequest.end();
}


// check authentication touchcommerce
function isAuthenticated(req, res, next) {
    if (app.sessionCookie) {
        console.log('authenicated');
        req.sessionCookie = app.sessionCookie;
        next();
    } else {
        console.log('not authenticated');
        authenticateTouchCommerce(req, res, next);
    }
}

// routes
var agentAvailabilityRoute = require('./api/modules/agentAvailability/agentAvailability.route');
var engagementRoute = require('./api/modules/engagement/engagement.route');
var getMessageRoute = require('./api/modules/getMessage/getMessage.route');
var customerIsTypingRoute = require('./api/modules/customerIsTyping/customerIsTyping.route');
var sendMessageRoute = require('./api/modules/sendMessage/sendMessage.route');

// api services
app.post('/mfchat/rest/agent', isAuthenticated, agentAvailabilityRoute);
app.post('/mfchat/rest/engagement', isAuthenticated, engagementRoute);
app.post('/mfchat/rest/message/:engagementID', isAuthenticated, getMessageRoute);
app.post('/mfchat/rest/message', isAuthenticated, sendMessageRoute);
app.post('/mfchat/rest/customerIsTyping', isAuthenticated, customerIsTypingRoute);



app.listen(port);
console.log('Application is running on this port http://localhost:' + port);
