/**
 * @ngdoc property
 * @name sipTransDetailsController
 * @requires $scope
 * @requires transactModel
 * @requires $filter
 * @requires $state
 * @requires TransactConstant
 
 * @description
 *
 * - It gets the data from transactModel and binds the data to a view
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function sipTransDetailsController($scope, transactModel, $filter, TransactConstant, $state, bankDtlsModel) {  
	var translateFilter = $filter('translate');
	var paymentDetails = transactModel.getTransactDetails().paymentDetails;
    var transConf = transactModel.getTransactConfirm();
    var advDetails = transactModel.getAdvDetails();
   
    //console.log(advDetails)
    //bankDtlsModel.getSelectedBank()
    $scope.transactPaymentDetails = [
	    {
	        key: "BankDetails",
	        text: translateFilter(TransactConstant.transact.BANK_DETAILS),
	        value: paymentDetails.selectedBank 
	    },
	    {
	        key: "paymentMethod",
	        text: translateFilter(TransactConstant.common.PAYMENT_METHOD_LABEL),
	        value: paymentDetails.paymentMethod
	    },	    
	    {
	        key: "totalInvestmentAmount",
	        text: translateFilter(TransactConstant.common.TOTAL_INVESTMENT_AMOUNT),
	        value: paymentDetails.totalAmount
	    }
	];

	$scope.transactAdvisorDetails = [
	    {
	        key: "advisorARN",
	        text: translateFilter(TransactConstant.common.ADVISOR_ARN),
	        value: advDetails.arnCode 
	    },
	    {
	        key: "transactionRefNo",
	        text: translateFilter(TransactConstant.common.TRANSACTION_REF_NO),
	        value: transConf.transactionRefNo
	    },
        {
            key: "requestDateTime",
            text: translateFilter(TransactConstant.transact.ADV_REQ_DATE),
            value: transConf.transDateTime
        }	    
	];

    //Handles initiate another SIP
    $scope.initiateAnotherSip = function(){
    	transactModel.resetSetters(); 
        transactModel.isNewInvestor = false;	
    	// transactModel.setStateValue({key:null});
    	$state.go("transact.base.sip",{key:null});
    }
    
}

sipTransDetailsController.$inject = ['$scope', 'transactModel', '$filter', 'TransactConstant', '$state','bankDtlsModel'];
module.exports = sipTransDetailsController;