define([
    'jquery',
    'underscore',
    'backbone',
    'appcommon/commonutility',
    'text!appmodules/crm/app/templates/contactpickerview.html',
    'errorLog'
], function ($, _, Backbone, Util, ContactPickerViewHtml, ErrorLog) {

    /*
     NOTE: This view requires constructor properties:
     1.) the element on which this view will be attached*
     2.) the data source (a ContactPickerDataSource object)
     *This allows you to have more than one contact picker on the page.
     example:
     var pickerView = new ContactPickerView({el: $('#my-contact-picker').get(0), dataSource: new ContactPickerDataSource()});
     NOTE: the element must have a unique DOM id
     */
    var ContactPickerView = Backbone.View.extend({
        //PUBLIC
        selectedContact: null, // 
        selectionComplete: null, // callback whenever the contact is changed (one arg: selectedContact)
        isClientOnly: false, // setting to true will prevent display of client/prospect type selection
        isFreeformAllowed: true, // if true, the picker will allow the user to select the search text as a contact
        //PRIVATE
        template: _.template(ContactPickerViewHtml),
        isSearchEnabled: false,
        resultList: null,  // [contact]
        searchText: '',
        dataSource: null,
        lastSelectedContact: null,
        serverSearchDelayMilliseconds: 200,
        lastScheduledSearchTimer: null,
        mininumCharsForSearch: 3,
        enableClientIdSearch: false,
        isNonCMUser: false,
        initializeElementVars: function () {
            this.$textInput = this.$('[pt-contact-picker-text-input="' + this.pickerId() + '"]');
            this.$typeButtonContainer = this.$('[pt-contact-picker-type-button-container="' + this.pickerId() + '"]');
            this.$clientTypeButton = this.$('[pt-contact-picker-client-type-button="' + this.pickerId() + '"]');
            this.$clientIdTypeButton = this.$('[pt-contact-picker-client-id-type-button="' + this.pickerId() + '"]');
            this.$prospectTypeButton = this.$('[pt-contact-picker-prospect-type-button="' + this.pickerId() + '"]');
            this.$resultsList = this.$('[pt-contact-picker-result-contact-list="' + this.pickerId() + '"]');
            this.$resultsNone = this.$('[pt-contact-picker-no-results="' + this.pickerId() + '"]');
            this.$resultsWaiting = this.$('[pt-contact-picker-waiting="' + this.pickerId() + '"]');
            this.$clearButton = this.$('[pt-contact-picker-clear-button="' + this.pickerId() + '"]');
            this.$contactPicker = this.$('.pt-contact-picker');
            this.$clientIdGoBtn = this.$('#client-search-go-btn-' + this.pickerId());
            this.$clientIdSearchError = this.$('[pt-contact-picker-client-id-error="' + this.pickerId() + '"]');
        },
        events: function () {
            evts = {}
            evts['click [pt-contact-picker-text-input="' + this.pickerId() + '"]'] = 'handleTextClicked';
            evts['keyup [pt-contact-picker-text-input="' + this.pickerId() + '"]'] = 'handleTextKeyup';
            evts['input [pt-contact-picker-text-input="' + this.pickerId() + '"]'] = 'handleSearchTextChanged';
            evts['click [pt-contact-picker-clear-button="' + this.pickerId() + '"]'] = 'handleClearClicked';
            evts['click [pt-contact-picker-client-type-button="' + this.pickerId() + '"]'] = 'handleClientTypeClicked';
            evts['click [pt-contact-picker-prospect-type-button="' + this.pickerId() + '"]'] = 'handleProspectTypeClicked';
            evts['click [pt-contact-picker-use-as-typed-button="' + this.pickerId() + '"]'] = 'handleUseAsTypeClicked';
            evts['click [pt-contact-picker-client-id-type-button="' + this.pickerId() + '"]'] = 'handleClientIdTypeClicked';
            evts['click #client-search-go-btn-' + this.pickerId()] = 'handleClinetIdSearch';
            return evts;
        },
        initialize: function (options) {
            _.extend(this, _.pick(options, 'dataSource'));  // copies constructor attributes to this
            _.bindAll(this, 'enableSearch', 'disableSearch', 'handleResultClick', 'handleResultMouseOver', 'handleKeyDown', 'searchType');
        },
        beforeClose: function () {
            if (this.$contactPicker) {
                this.hidePageOverlay();
            }
        },
        render: function () {
            this.$el.html(this.template({ pickerId: this.pickerId(), isFreeformAllowed: this.isFreeformAllowed, enableClientIdSearch: this.enableClientIdSearch }));
            this.initializeElementVars();
            this.updateInput();
        },
        resetRender: function () { //reset to null then render
            this.selectedContact = null;
            this.lastSelectedContact = null;
            this.isSearchEnabled = false;
            this.render();
        },
        pickerId: function () {
            return this.$el.prop('id');
        },
        handleClearClicked: function (e) {
            this.selectedContact = null;
            this.lastSelectedContact = null;
            this.enableSearch();
        },
        handleClientTypeClicked: function (e) {
            e.preventDefault();
            if (!this.isClientMode()) {
                this.setClientMode(true);
            }
        },
        handleProspectTypeClicked: function (e) {
            e.preventDefault();
            if (this.isNonCMUser) {
                Util.toggleNonCMmsg("function");
                return;
            } else {
                if (this.isClientMode()) {
                    this.setClientMode(false);
                }
            }
        },
        handleClientIdTypeClicked: function (e) {
            e.preventDefault();
            this.setClientIdMode(true);
        },
        handleUseAsTypeClicked: function (e) {
            e.preventDefault();
            this.selectedContact = {
                fullName: this.searchText,
                displayName: this.searchText,
                isClient: false
            };
            this.disableSearch();
        },
        handleTextKeyup: function (e) {
            if (this.$clientIdTypeButton.hasClass("active")) {
                return;
            }
            if (e.which == 9) {
                this.enableSearch();
                this.$textInput.focus();
            }
        },
        handleTextClicked: function (e) {
            //need to handle in a better way, right now the input box is etting cleared whenever the user clicks on text box. It shouldn't be like that. So now handling only for client Id search, 
            //but it should be handled for client name seacrh as well, after business alignement.
            if (this.$clientIdGoBtn.length==0 || this.$clientIdGoBtn.hasClass("hidden")) {
                this.enableSearch();
                this.$textInput.focus();
            }
            
        },
        handleSearchTextChanged: function (e) {
            this.searchText = $.trim(this.$textInput.val());
            if (this.$clientIdTypeButton.hasClass("active")) {
                this.updateClearButton();
                return;
            }
            if (this.searchText.length >= this.mininumCharsForSearch) {
                this.lastSelectedContact = null;
            }
            this.updateClearButton();
            this.updateSearchResults();
        },
        handleResultClick: function (e) {
            var $resultElement = e.target.nodeName == "LI" ? this.$(e.target) : this.$(e.target).closest('li');
            var chosenContactId = $resultElement.attr('pt-contact-picker-result-contact-id');
            this.selectContact(chosenContactId);
            //this.set('current_event');
        },
        handleResultMouseOver: function (e) {
            var $resultElement = e.target.nodeName == "LI" ? this.$(e.target) : this.$(e.target).closest('li');
            var $resultList = $resultElement.closest('ul');
            $resultList.find('li').removeClass('active');
            $resultElement.addClass('active');
        },
        handleKeyDown: function (e) {
            if (e.which == 13) {
                this.handleEnter(e)
            } else if (e.which == 27) { // escape
                this.handleEscape(e);
            } else if (e.which == 38 || e.which == 40) { // 38 = pageup, 40 = pagedown
                this.handleResultsPageUpDownKey(e.which == 38);
            }
        },
        handleEnter: function (r) {
            if (!Util.isEmpty(this.resultList)) {
                var $selectedResult = this.$('[pt-contact-picker-result-contact-id].active');
                if ($selectedResult.length == 1) {
                    var chosenContactId = $selectedResult.attr('pt-contact-picker-result-contact-id');
                    this.selectContact(chosenContactId);
                }
            }
        },
        handleEscape: function (e) {
            if (Util.isEmpty(this.resultList)) {
                this.disableSearch();
            } else {
                this.enableSearch();
            }
        },
        handleResultsPageUpDownKey: function (isUp) {
            var $selectedResult = this.$('[pt-contact-picker-result-contact-id].active');
            var $adjacent = isUp ? $selectedResult.prev() : $selectedResult.next();
            if ($adjacent.length) {
                $selectedResult.removeClass('active');
                $adjacent.addClass('active');
            }
        },
        selectContact: function (chosenContactId) {
            var contact = _.find(this.resultList, function (contactResult) {
                return contactResult.id == chosenContactId;
            });
            if (contact) {
                this.selectedContact = contact;
                this.disableSearch();
            }
        },
        updateSearchResults: function () {
            this.setResultList(null);
            if (this.searchText.length >= this.mininumCharsForSearch) {
                this.toggleResultsContainer(true);
                if (this.isClientMode()) {
                    if (this.dataSource.isClientListFixed()) {
                        this.setResultList(this.dataSource.searchFixedClientList(this.searchText));
                        this.populateResults();
                    } else {
                        this.populateResults();
                        this.scheduleServerSearch('client');
                    }
                } else {
                    this.populateResults();
                    this.scheduleServerSearch('nonClient');
                }
            } else {
                this.toggleResultsContainer(false);
            }
        },
        enableSearch: function () {
            this.$textInput.addClass('open');
            this.lastSelectedContact = this.selectedContact;
            this.searchText = '';
            this.selectedContact = null;
            if (!this.isSearchEnabled) {
                this.isSearchEnabled = true;
                if (!this.isClientOnly) {
                    this.$typeButtonContainer.removeClass('hidden');
                }
                this.showPageOverlay();
            }
            if (this.$clientIdTypeButton.hasClass("active")) {
                this.$clientIdGoBtn.removeClass("hidden");
            }
            this.updateInput();
            this.updateSearchResults();
        },
        disableSearch: function () {
            this.$textInput.removeClass('open');
            if (this.lastSelectedContact) {
                this.selectedContact = this.lastSelectedContact;
            }
            this.searchText = '';
            if (this.isSearchEnabled) {
                this.isSearchEnabled = false;
                this.toggleResultsContainer(false);
                this.$typeButtonContainer.addClass('hidden');
            }
            this.$clientIdGoBtn.addClass('hidden');
            this.hidePageOverlay();
            this.updateInput();
            if (this.selectionComplete) {
                this.selectionComplete(this.selectedContact);
            }
        },
        showPageOverlay: function () { // adds a transparent div that listens for any tap on page outside of the picker
            var self = this;
            $('body').append('<div id="pt-contact-picker-overlay" class="pt-transparent-overlay"></div>');
            this.$contactPicker.css('z-index', 999);
            $('#pt-contact-picker-overlay').on('click', function () {
                self.disableSearch();
            });
            this.$contactPicker.on('keydown', this.handleKeyDown);
        },
        hidePageOverlay: function () {
            $('#pt-contact-picker-overlay').remove();
            this.$contactPicker.css('z-index', 'auto');
            this.$contactPicker.off('keydown', this.handleKeyDown);
        },
        toggleResultsContainer: function (shouldShow) {
            var $resultsContainer = this.$('[pt-contact-picker-result-container="' + this.pickerId() + '"]');
            $resultsContainer.css('z-index', shouldShow ? 999 : 'auto');
            $resultsContainer.toggleClass('hidden', !shouldShow);
            var $errorContainer = this.$('[pt-contact-picker-client-id-error="' + this.pickerId() + '"]');
            $errorContainer.css('z-index', shouldShow ? 999 : 'auto');
            $errorContainer.toggleClass('hidden', !shouldShow);
            this.$contactPicker.toggleClass('pt-square-bottom-border', shouldShow);
            if (shouldShow) {
                this.populateResults();
            }
        },
        isClientMode: function () {
            return this.$clientTypeButton.hasClass('active');
        },
        searchType: function () {
            return this.isClientMode() ? 'client' : 'nonClient';
        },
        setClientMode: function (shouldBeClientMode) {
            this.$textInput.attr('maxlength', 23);
            this.$clientTypeButton.toggleClass('active', shouldBeClientMode);
            this.$prospectTypeButton.toggleClass('active', !shouldBeClientMode);
            this.$clientIdTypeButton.removeClass("active");
            this.setResultList(null);
            this.updateSearchResults();
            this.$clientIdGoBtn.addClass("hidden");
            this.$clientIdSearchError.addClass("hidden");
        },
        setClientIdMode: function (shouldBeClientIdMode) {
            this.$textInput.attr('maxlength', 8);
            this.$resultsNone.addClass("hidden");
            this.$clientIdTypeButton.toggleClass('active', shouldBeClientIdMode);
            this.$clientTypeButton.toggleClass('active', !shouldBeClientIdMode);
            this.$clientIdGoBtn.removeClass("hidden");
            this.setResultList(null);
            this.$textInput.focus();
        },
        populateResults: function () {
            var hasResults = !Util.isEmpty(this.resultList);
            if (hasResults) {
                this.renderResultList();
            }
            this.$resultsList.toggleClass('hidden', !hasResults);
            this.$resultsNone.toggleClass('hidden', hasResults || this.resultList == null);
            this.$resultsWaiting.toggleClass('hidden', hasResults || this.resultList != null);
        },
        updateInput: function () {
            var isContactSelected = this.selectedContact != null;
            this.$contactPicker.toggleClass("active", this.isSearchEnabled);
            this.$textInput.val(isContactSelected ? this.selectedContact.displayName : this.searchText);
            this.updateClearButton();
        },
        updateClearButton: function () {
            this.$clearButton.toggleClass('hidden', Util.isEmpty(this.searchText) && this.selectedContact == null);
        },
        renderResultList: function () {
            if (this.resultList) {
                var resultListHtml = [];
                var isClientList = this.isClientMode();
                var count = 0;
                _.each(this.resultList, function (contact) {
                    resultListHtml.push('<li pt-contact-picker-result-contact-id="' + contact.id + '"' + (count == 0 ? ' class="active" ' : '') +
                        '><span class="pt-contact-picker-result-name">' + this.decorateWithSearchTerms(contact.displayName) + '</span>');
                    if (isClientList) {
                        var formattedClientId = contact.id != null && contact.id.length > 8 ? contact.id.slice(-8) : contact.id;
                        if (!Util.isEmpty(formattedClientId)) {
                            resultListHtml.push('<span class="pull-right">' + this.decorateWithSearchTerms(formattedClientId) + '</span>');
                        }
                    }
                    resultListHtml.push('</li>');
                    count++;
                }, this);
                this.$resultsList.html(resultListHtml.join(''));
                var $resultSelection = this.$('[pt-contact-picker-result-contact-list] li');
                $resultSelection.on('mouseover', this.handleResultMouseOver);
                $resultSelection.on('click', this.handleResultClick);
            }
        },
        decorateWithSearchTerms: function (aString) {
            if (Util.isEmpty(this.searchText)) {
                return aString;
            } else {
                var matchText = this.searchText.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                return aString.replace(new RegExp('(' + matchText + ')', 'ig'), function ($1, match) {
                    return '<span class="highlight">' + match + '</span>';
                });
            }
        },
        scheduleServerSearch: function (type) {
            var self = this;
            clearTimeout(self.lastScheduledSearchTimer);
            self.lastScheduledSearchTimer = setTimeout(function () {
                self.performServerSearch(type);
            }, self.serverSearchDelayMilliseconds);
        },
        performServerSearch: function (type) {
            var self = this;
            var queryText = this.searchText;
            if (queryText.length < 3) {
                self.setResultList(null);
                self.populateResults();
            } else {
                self.dataSource.searchServerContacts(type, queryText, function (contacts) {
                    // verify that this search is still relevant (user might have changed things since search was triggered)
                    if (self.searchType() == type && self.searchText == queryText) {
                        self.setResultList(contacts);
                        self.populateResults();
                    }
                }, function (error) {
                    self.handleServiceError(error);
                })
            }
        },
        handleServiceError: function (error) {
            this.setResultList(null);
            this.toggleResultsContainer(false);
            ErrorLog.ErrorUtils.prepareAndLogError(error);
        },
        setResultList: function (contacts) {
            this.resultList = null;
            if (contacts) {
                contacts.sort(function (c1, c2) {
                    return c1.displayName.localeCompare(c2.displayName);
                });
                this.resultList = contacts;
            }
        },
        handleClinetIdSearch: function () {
            this.$clientIdSearchError.addClass("hidden");
            var _clientId = $.trim(this.$textInput.val());
            if (isNaN(_clientId) || _clientId.length != 8) {
                this.$clientIdSearchError.removeClass("hidden").text("Enter 8 digit client ID.");
                return;
            } 
            var _23digitClId = this.clientIDFormatter(_clientId);
            this.performClientIdSearch(_23digitClId);
        },
        performClientIdSearch: function (clientId) {
            var self = this;
            self.dataSource.searchClientById(clientId, function (contacts) {
                var contactInfo = null;
                if (contacts && contacts[0]) {
                    contactInfo = contacts[0].toJSON();
                }
                if (contactInfo) {
                    var selectedContact = {
                        "contactType": "client",
                        "id": contactInfo.id,
                        "clientId": contactInfo.id,
                        "firstName": null,
                        "lastName": null,
                        "orgName": null,
                        "displayName": null
                    }
                    if (contactInfo.orgClient.get('orgNm')) {
                        selectedContact.displayName = selectedContact.orgName = contacts.orgClient.get('orgNm');
                    } else if (contactInfo.personClient.get("clFirstNm") && contactInfo.personClient.get("clLastNm")) {
                        var personClnt = contactInfo.personClient;
                        selectedContact.firstName = personClnt.get("clFirstNm");
                        selectedContact.lastName = personClnt.get("clLastNm");
                        selectedContact.displayName = selectedContact.lastName + ", " + selectedContact.firstName;
                    }
                    if (selectedContact.displayName) {
                        self.selectedContact = selectedContact;
                        self.disableSearch();
                    } else {
                        self.$clientIdSearchError.removeClass("hidden").text("Incorrect 8 digit typed.");
                    }
                    
                } else {
                    self.$clientIdSearchError.removeClass("hidden").text("Incorrect 8 digit typed.");
                }
            }, function (xhr) {
                if (xhr && xhr.status == 401) {
                    self.$clientIdSearchError.removeClass("hidden").text("8 digit matches but not authorized.");
                }
                ErrorLog.ErrorUtils.myError(xhr,true);
                //self.handleServiceError(error);
            });
        },
        clientIDFormatter: function (id) {
            var _admnCd = '001', _formattedIdLength = 23, _padzeoLength = 12, _zeroString = "", _formattedId = id;
            _padzeoLength = (_formattedIdLength - _admnCd.length - id.length);
            if ((_admnCd.length + id.length) < 23) {
                _zeroString = Math.pow(10, _padzeoLength).toString().substr(1);
                _formattedId = _admnCd + '' + _zeroString + '' + id;
            }
            return _formattedId;

        },
        showClientIdSearchButton: function () {
            this.$clientIdGoBtn.removeClass("hidden");
        }
    });

    return ContactPickerView;

});
