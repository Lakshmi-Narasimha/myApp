/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details Lumpsum controller for Advisor module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function fundDtlsLumpsumCtrl($scope, buildPlanModelService, planSmartSolution, authenticationService, TransactConstant, transactModel, fundDetails, truncateTextService) {
    // transactModel.setTransactType("Lumpsum");
    $scope.fundDetails = buildPlanModelService.getGoalPlanData();
    $scope.lumpsumFundDetails = [];
    angular.forEach($scope.fundDetails, function (obj) {
        var gridRow = {};
        gridRow.fundName = obj.fundName;
        gridRow.dividend = planSmartSolution.dividendFlagCheck(obj.dividendFlag);
        gridRow.fundOption = obj.fundOption;
        gridRow.dividendFlag = obj.dividendFlag;
        gridRow.amount = obj.installmentDetails.oneTime;
        gridRow.nfoFlag = obj.nfoFlag;
        gridRow.fundType = obj.fundType;
        gridRow.accNo = obj.accNo;
        $scope.lumpsumFundDetails.push(gridRow);
    });
    planSmartSolution.setLumpsumFunds($scope.lumpsumFundDetails);
    $scope.lumpsumFundDetails = truncateTextService.updateLabel(angular.copy($scope.lumpsumFundDetails), 'fundName', 27);
    var celltemp = '<div class="ui-grid-cell-contents" title="{{col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)].fundName_orignal}}">{{COL_FIELD}}</div>';
    var width = authenticationService.getAppName()==='advisor' ? 350 : 520;
    $scope.lumpsumColumnDefs = [
        {field: 'fundName', displayName: 'Invest Into',data: $scope.lumpsumFundDetails, cellTemplate: celltemp, width: '210', pinnedLeft: true},
        {
            field: 'amount',
            displayName: 'Buy Amount',
            width: '213',
            headerCellClass: 'fti-grid-rupeeIcon text-right pr+',
            cellClass: 'text-right pr+'
        },
        {field: 'dividend', displayName: 'Dividend Option', width: width}
    ];

    $scope.accordionClicked = function(){
        transactModel.setTransactType(TransactConstant.buy.BUY);
        fundDetails.removeFundDetails();
        
        angular.forEach(planSmartSolution.getLumpsumFunds(),function(obj){           
            if(!angular.isNumber(obj.amount)) {
                obj.amount = obj.amount.indexOf(',') >-1 ? obj.amount.replace(/,/g, '') : obj.amount;
            }
            fundDetails.setFundDetails(obj);
        });
    };
    
    $scope.isOpenInvGrid = {
        'open': true      
    };
    $scope.accordionClicked();

}

fundDtlsLumpsumCtrl.$inject = ['$scope', 'buildPlanModelService', 'planSmartSolution', 'authenticationService', 'TransactConstant', 'transactModel', 'fundDetails', 'truncateTextService'];

module.exports = fundDtlsLumpsumCtrl;