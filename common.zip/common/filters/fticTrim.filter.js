/**
 * @ngdoc service
 * @name Common FTIC Display Error Message
 * @description
 *
 * - Common method for throwing error message to backend as well as to console.
 *
 */


'use strict';

var fticTrim = function() {
	return function(input) {
		if (input) {
			return input.replace(/\s+/g, '');    
		}
	};

};

fticTrim.$inject = [];
module.exports = fticTrim;
