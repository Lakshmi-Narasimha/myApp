/**
 * @ngdoc property
 * @name fticInvDbNotifications Directive
 * @requires dashboardConstants
 * @requires advisorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - Displays investor dashboard notifications section.
 *
 **/
'use strict';

var fticInvDbNotifications = function (investorEventConstants,fticRecommAndNotifiModel, $state, loggerConstants, fticLoggerMessage) {
	return {
		restrict: 'E',
        scope: true,
		template: require('./invDbNotifications.html'),
        controller : function($scope){
            $scope.$on(investorEventConstants.Dashboard.RECOMM_AND_NOTIFI_DATA, function() {

                var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_NOTIFICATIONS_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.RECOMM_AND_NOTIFI_DATA + ' event' /* Function Name */;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
                $scope.recommandNotifiData = fticRecommAndNotifiModel.getRecommAndNotifiReport();
                $scope.notificationsData = $scope.recommandNotifiData.notifications;
                if($scope.notificationsData) {
                    $scope.notificationsLength = $scope.notificationsData.length;
                }
            });
        },
        link: function(scope){
            scope.notificationsTile = 'notificationsTile';
            scope.badgeEnable = true;
            scope.panelClose = false;
            scope.notifications = {
                heading: 'Notifications',
                badgeClass: 'icon-fti_advisorNotification',
                badgeCount: 0
            };
            scope.onButtonClick = function(){
                $state.transitionTo('notificationsreport');
            };
        }
	};
};

fticInvDbNotifications.$inject = ['investorEventConstants','fticRecommAndNotifiModel', '$state', 'loggerConstants', 'fticLoggerMessage'];
module.exports = fticInvDbNotifications;