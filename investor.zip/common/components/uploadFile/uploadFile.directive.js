'use strict';

var uploadFile = function($parse,becomeAnAdvisorModel) {
    return {
        template: require('./uploadFile.html'),
        restrict: 'E', 
        scope: false,
        controller: function($scope, $element, $attrs){
        },
        link: function(scope, element, attrs) {
            var fn = $parse(attrs.onreadfile);
            element.on('change', function(onChangeEvent) {
                var reader = new FileReader();
                reader.onload = function(onLoadEvent) {
                    scope.$apply(function() {
                        fn(scope, {$fileContent:onLoadEvent.target.result});
                    });
                };
                becomeAnAdvisorModel.setPDFDetails(onChangeEvent.target.files[0]);
                reader.readAsDataURL( onChangeEvent.target.files[0]);
                 scope.fileName =onChangeEvent.target.files[0].name;
            });

           
        }
    }
};

uploadFile.$inject = ['$parse','becomeAnAdvisorModel'];
module.exports = uploadFile;