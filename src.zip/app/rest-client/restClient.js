define(['ampfComponents', 'app/common/errorLogging'],
    function (ampfComponents, errorLogging) {

        var restClient = new ampfComponents.RestClient();
        restClient.setRemoteErrorLogger(function(jqXHR, textStatus, errorThrown, requestUrl, requestData) {
            errorLogging.prepareAndLogError(jqXHR, "", requestUrl, requestData);
        });
        return restClient;

    });