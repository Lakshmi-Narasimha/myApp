define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailinvestmentview.html',
  'appcommon/commonutility',
  'moment'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml, Utils, moment) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
          var self = this;
          var servicePromises = [];
          servicePromises.push(dataService.promiseToGetMutualFundBalance(this.accountSummary.accountId));
          servicePromises.push(dataService.promiseToGetAccountROADetails(this.accountSummary.accountId, this.groupId));
          servicePromises.push(dataService.promiseToGetMutualFundSpecialDetails(this.accountSummary.accountId));
          Q.all(servicePromises)
            .then(function(responseValues){
              var balanceData = responseValues[0];
              var roaDetailsData = responseValues[1];
              var specialDetailsData = responseValues[2];

              var accountValues = {};
              accountValues.symbol = specialDetailsData.ticker ? specialDetailsData.symbol : '';
              accountValues.cusip = specialDetailsData.ticker ? specialDetailsData.cusip : '';
              if (specialDetailsData.spclDetail) {
                switch(specialDetailsData.spclDetail.assetValCd) {
                    case 'Y':
                        accountValues.assetValueCd = 'Yes';
                        break;
                    case 'N':
                        accountValues.assetValueCd = 'No';
                        break;
                    default:
                        accountValues.assetValueCd = 'Not Applicable';
                }
              } else {
                accountValues.assetValueCd = 'Not Applicable';
              }
              accountValues.combinedROAValue = Utils.isEmpty(roaDetailsData.grpAcctValROAAmt) ? '' : roaDetailsData.grpAcctValROAAmt.formatMoney();
              var loiAmt = parseInt(Utils.isEmpty(roaDetailsData.LOIAmt) ? '0' : roaDetailsData.LOIAmt);
              accountValues.letterOfIntentCommittment = loiAmt > 0 ? roaDetailsData.LOIAmt.formatMoney() : 'Not available';
              accountValues.purchasesWithin90Days = loiAmt > 0 && !Utils.isEmpty(roaDetailsData.cshInvAmt) ? roaDetailsData.cshInvAmt.formatMoney() : 'Not available';
              accountValues.repurchaseCredits = loiAmt > 0 && !Utils.isEmpty(roaDetailsData.grpAcctValROAAmt) ? roaDetailsData.grpAcctValROAAmt.formatMoney() : 'Not available';
              accountValues.loiEscrowSchares = balanceData.escrShrQty;
              accountValues.newMoneyShares = balanceData.newMnyQty;

              self.renderSection(SectionTemplateHtml, {accountValues: accountValues});
          })
          .fail(this.handleServiceError);
        }
    });

    return SectionView;
});