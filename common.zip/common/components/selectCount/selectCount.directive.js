/**
 * @ngdoc property
 * @name selectCount Directive
 * @description
 *
 * - selectCount Directive will display the total count by default. And the count can change based on the no.of items selected. 
 *
 **/
'use strict';

var selectCount = function() {
	return {
            template: require('./selectCount.html'),
            restrict: 'E',
            replace: true,
            scope: {
              lable: '@',
              count: '='
            }
        };
};

selectCount.$inject = [];
module.exports = selectCount;