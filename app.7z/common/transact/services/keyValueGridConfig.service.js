/**
 * @ngdoc service
 * @name Key value Grid Config Model
 * @requires MyInvestorConstant
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var keyValueGridConfigModel = function (fticLoggerMessage, loggerConstants, TransactConstant) {

    var _fundGridConfig = {};
        _fundGridConfig.INV = {};
    
    var editIconTemplate = '<div><a><i class="icon-fti_inlineEdit" ng-click="grid.appScope.$emit(\'editFund\', COL_FIELD)"></i></a></div>';
    var sipEditIconTemplate = '<div><a><i class="icon-fti_inlineEdit" ng-click="grid.appScope.$emit(\'editFund\', {data:row.entity, index: grid.renderContainers.body.visibleRowCache.indexOf(row)})"></i></a></div>';
    var _sipSelectFundEditIconTemplate = '<div><a><i class="icon-fti_inlineEdit" ng-click="grid.appScope.$emit(\'editSipFund\', {data:row.entity, index: grid.renderContainers.body.visibleRowCache.indexOf(row)})"></i></a></div>';
    var removeIconTemplate = '<div><a><i class="icon-fti_close" ng-click="grid.appScope.$emit(\'RemoveFund\',  {data:row.entity, index: grid.renderContainers.body.visibleRowCache.indexOf(row)})"></i></a></div>';
    var editIconNomineeTemplate = '<div><a><i class="icon-fti_inlineEdit" ng-click="grid.appScope.$emit(\'editNominee\', COL_FIELD)"></i></a></div>';
    var renewSipIconTemplate = '<div><a><i class="icon-fti_inlineEdit" ng-click="grid.appScope.$emit(\'editRenewSipFund\', {data:row.entity, index: grid.renderContainers.body.visibleRowCache.indexOf(row)})"></i></a></div>';

    _fundGridConfig[TransactConstant.transact.TRANSACT] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, pinnedLeft:true, cellClass: 'text-center'},
        { field: 'fmDescription', displayName: 'Fund', width:"160", enableSorting:false, pinnedLeft:true},
        { field: 'tschvalAccno', displayName: 'Account No.', width:"172", enableSorting:false},
        { field: 'investmentGoal', displayName: 'Investment Goal', width:"172", enableSorting:false},
        { field: 'balUnits', displayName: 'Total Units', width:"100", enableSorting:false, headerCellClass: 'text-right', cellClass: 'text-right'},
        { field: 'marketValue', displayName: 'Current Value', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"180", enableSorting:false}
    ],

    //DTP Select Fund Details Tile

    //  _fundGridConfig[TransactConstant.transact.DTP] = [
    //     { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, pinnedLeft:true, cellClass: 'text-center'},
    //     { field: 'fmDescription', displayName: 'Source Fund', width:"180", enableSorting:false, pinnedLeft:true},
    //     { field: 'dividendOption', displayName: 'Dividend Option', width:"180", enableSorting:false,pinnedLeft:true},
    //     { field: 'investmentGoal', displayName: 'Investment Goal', width:"150", enableSorting:false,pinnedLeft:true},
    //     { field: 'marketValue', displayName: 'Current Value', width:"180", enableSorting:false,pinnedLeft:true}
    // ],
    
    _fundGridConfig[TransactConstant.modifySip.MODIFYSIP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundOptionDesc', displayName: 'Fund', width:"160", enableSorting:false, pinnedLeft:true},
        { field: 'accountNumber',displayName: 'Account No.', width:"172", enableSorting:false},
        { field: 'startDateField', displayName: 'SIP Start Date', width:"172", enableSorting:false},
        { field: 'endDateField', displayName: 'SIP End Date', width:"172", enableSorting:false},
        { field: 'amount',  displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"172", enableSorting:false},
        { field: 'frequency',  displayName: 'Frequency', width:"127", enableSorting:false},
        {field: 'stepUpAmount', displayName: 'Step-up', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right',width:"127", enableSorting:false}
    ],

    _fundGridConfig[TransactConstant.buy.BUY] = [
        { field: 'editIcon', displayName: '', width:"70", enableSorting:false, cellTemplate: editIconTemplate,cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Into', width:"180", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"227", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right pr', headerCellClass: 'text-right pr'},
        { field: 'dividend', displayName: 'Dividend Option', width:"250", enableSorting:false}
    ];

    _fundGridConfig["transactNowSmartSolBuy"] = [
        { field: 'fundName', displayName: 'Invest Into', width:"180", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"227", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right pr', headerCellClass: 'text-right pr'},
        { field: 'dividend', displayName: 'Dividend Option', width:"250", enableSorting:false}
    ];

    _fundGridConfig[TransactConstant.guest.LUMPSUMINV] = [
        { field: 'fundName', displayName: 'Invest Into', width:"350", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"255", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right', headerCellClass: 'text-right'}
    ];

    _fundGridConfig[TransactConstant.buy.BUYFUND] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: sipEditIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Info', width:"190", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"200", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right', headerCellClass: 'text-right'},
        { field: 'dividend', displayName: 'Dividend Option', width:"150", enableSorting:false},
        { field: 'removeIcon', displayName: '', width:"30", enableSorting:false, pinnedRight:true, cellTemplate: removeIconTemplate}
    ];

    _fundGridConfig[TransactConstant.sip.FUNDSIP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: sipEditIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Into', width:"200", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"100", cellClass: 'fti-grid-cell-rupee text-right' , headerCellClass: 'text-right', enableSorting:false},
        { field: 'dividend', displayName: 'Dividend Option', width:"140", enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"140", enableSorting:false},
        { field: 'endDateMonthYear', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"150", enableSorting:false},
        { field: 'removeIcon', displayName: '', width:"30", enableSorting:false, pinnedRight:true, cellTemplate: removeIconTemplate}
    ];
    _fundGridConfig[TransactConstant.buy.NOMINEE] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconNomineeTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'nomName', displayName: 'Nominee Name', width:"150", enableSorting:false},
        { field: 'nomPerValue', displayName: '%Allocation', width:"200", enableSorting:false}
    ];

    _fundGridConfig[TransactConstant.sip.SIP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Into', width:"160", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"174", cellClass: 'fti-grid-cell-rupee text-right pr',headerCellClass:'text-right pr', enableSorting:false},
        { field: 'dividend', displayName: 'Dividend Option', width:"172", enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"177", enableSorting:false},
        { field: 'endDateMonthYear', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"120", enableSorting:false}
    ];

    _fundGridConfig["transactNowSmartSolSip"] = [
        { field: 'fundName', displayName: 'Invest Into', width:"160", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"174", cellClass: 'fti-grid-cell-rupee text-right pr',headerCellClass:'text-right pr', enableSorting:false},
        { field: 'dividend', displayName: 'Dividend Option', width:"172", enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"177", enableSorting:false},
        { field: 'sipenddate', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"120", enableSorting:false}
    ];

    _fundGridConfig[TransactConstant.guest.SIPINV] = [
        { field: 'fundName', displayName: 'Invest Into', width:"350", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"100", cellClass: 'fti-grid-cell-rupee text-right',headerCellClass: 'text-right', enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"140", enableSorting:false},
        { field: 'endDateMonthYear', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"120", enableSorting:false}
    ];

    _fundGridConfig[TransactConstant.guest.SMARTSIPINV] = [
        { field: 'fundName', displayName: 'Invest Into', width:"200", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmt', displayName: 'SIP Amount', width:"180", cellClass: 'fti-grid-cell-rupee text-right',headerCellClass: 'text-right', enableSorting:false},
        { field: 'sipstartdate', displayName: 'SIP Start Date', width:"180", enableSorting:false},
        { field: 'sipenddate', displayName: 'SIP End Date', width:"180", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"180", enableSorting:false},
        { field: 'stepup', displayName: 'Step up SIP', width:"180", enableSorting:false}
    ];

    _fundGridConfig[TransactConstant.guest.RENEWSIP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: renewSipIconTemplate, pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Into', width:"120", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"100", cellClass: 'fti-grid-cell-rupee text-right',headerCellClass: 'text-right', enableSorting:false},
        { field: 'dividend', displayName: 'Dividend', width:"100", enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"140", enableSorting:false},
        { field: 'futureInstallment', displayName: 'SIP Future Installment', width:"180", enableSorting:false},
        { field: 'endDateMonthYear', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"120", enableSorting:false}
    ];
    _fundGridConfig[TransactConstant.guest.SELECTSIP] = [
        { field: 'editIcon', displayName: '', width:"110", enableSorting:false, cellTemplate: editIconTemplate, pinnedLeft:true, cellClass: 'text-center pl pr+'},
        { field: 'fundOptionDesc', displayName: 'Invest Into', width:"120", enableSorting:false}
    ];

    _fundGridConfig['INV'][TransactConstant.transact.TRANSACT] = [
            { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, pinnedLeft:true, cellClass: 'text-center'},
            { field: 'fmDescription', displayName: 'Fund', width:"180", enableSorting:false, pinnedLeft:true},
            { field: 'tschvalAccno', displayName: 'Account No.', width:"170", enableSorting:false},
            { field: 'investmentGoal', displayName: 'Investment Goal', width:"150", enableSorting:false},
            { field: 'marketValue', displayName: 'Current Value', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"180", enableSorting:false}
    ];

    _fundGridConfig['INV'][TransactConstant.transact.DTP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, pinnedLeft:true, cellClass: 'text-center'},
        { field: 'fmDescription', displayName: 'Source Fund', width:"180", enableSorting:false},
        { field: 'dividendOption', displayName: 'Dividend Option', width:"170", enableSorting:false},
        { field: 'investmentGoal', displayName: 'Investment Goal', width:"150", enableSorting:false},
        { field: 'marketValue', displayName: 'Current Value', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"180", enableSorting:false}
    ];
     _fundGridConfig['INV'][TransactConstant.buy.BUY] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate,cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Info', width:"150", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"150", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right', headerCellClass: 'text-right'},
        { field: 'dividend', displayName: 'Dividend Option', width:"250", enableSorting:false}
    ];
     _fundGridConfig['INV'][TransactConstant.buy.BUYFUND] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: sipEditIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Info', width:"190", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"200", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right', headerCellClass: 'text-right'},
        { field: 'dividend', displayName: 'Dividend Option', width:"150", enableSorting:false},
        { field: 'removeIcon', displayName: '', width:"30", enableSorting:false, pinnedRight:true, cellTemplate: removeIconTemplate}
    ];

     _fundGridConfig['INV'][TransactConstant.modifySip.MODIFYSIP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: editIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundOptionDesc', displayName: 'Fund', width:"150", enableSorting:false, pinnedLeft:true},
        { field: 'accountNumber',displayName: 'Account No.', width:"200", enableSorting:false},
        { field: 'startDateField', displayName: 'SIP Start Date', width:"163", enableSorting:false},
        { field: 'endDateField', displayName: 'SIP End Date', width:"127", enableSorting:false},
        { field: 'amount',  displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"127", enableSorting:false},
        { field: 'frequency',  displayName: 'Frequency', width:"127", enableSorting:false},
        {field: 'stepUpAmount', displayName: 'Step Up', headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right',width:"127", enableSorting:false}
    ];
    _fundGridConfig['INV'][TransactConstant.renewSip.RENEWSIP] = [
        { field: 'editIcon', displayName: '', width:"110", enableSorting:false, cellTemplate: editIconTemplate, pinnedLeft:true, cellClass: 'text-center pl pr+'},
        { field: 'fundOptionDesc', displayName: 'Fund', width:"80%", enableSorting:false}

    ];

    _fundGridConfig['INV'][TransactConstant.sip.SIP] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: sipEditIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Into', width:"200", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"100", cellClass: 'fti-grid-cell-rupee text-right' , headerCellClass: 'text-right', enableSorting:false},
        { field: 'dividend', displayName: 'Dividend Option', width:"140", enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"140", enableSorting:false},
        { field: 'endDateMonthYear', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"150", enableSorting:false},
        { field: 'removeIcon', displayName: '', width:"30", enableSorting:false, pinnedRight:true, cellTemplate: removeIconTemplate}
    ];

    _fundGridConfig['INV']['SAVE_SIP'] = [
        { field: 'editIcon', displayName: '', width:"83", enableSorting:false, cellTemplate: _sipSelectFundEditIconTemplate, cellClass: 'text-center', pinnedLeft:true},
        { field: 'fundName', displayName: 'Invest Into', width:"200", enableSorting:false, pinnedLeft:true},
        { field: 'sipAmount', displayName: 'SIP Amount', width:"100", cellClass: 'fti-grid-cell-rupee text-right' , headerCellClass: 'text-right', enableSorting:false},
        { field: 'dividend', displayName: 'Dividend Option', width:"140", enableSorting:false},
        { field: 'firstInstallment', displayName: 'SIP Start Date', width:"140", enableSorting:false},
        { field: 'endDateMonthYear', displayName: 'SIP End Date', width:"125", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"90", enableSorting:false},
        { field: 'stepUpSip', displayName: 'Step up SIP', width:"150", enableSorting:false},
        { field: 'removeIcon', displayName: '', width:"30", enableSorting:false, pinnedRight:true, cellTemplate: removeIconTemplate}
    ];

    var keyValueGridConfigModel = {
        fundGridConfig: _fundGridConfig
    };
    return keyValueGridConfigModel;
};

keyValueGridConfigModel.$inject = ['fticLoggerMessage', 'loggerConstants', 'TransactConstant'];

module.exports = keyValueGridConfigModel;