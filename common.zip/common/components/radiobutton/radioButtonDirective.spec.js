/* eslint-disable */
'use strict';

describe('Directive : radioButton',function(){
	var compile, scope, compiledEle;
	beforeEach(angular.mock.module('advisor'));
	beforeEach(function(){
		angular.mock.inject(function($compile,$rootScope){
			compile = $compile;
			scope = $rootScope.$new();			
		})
		var element = '<ftic-radio-button></ftic-radio-button>';
		compiledEle = compile(angular.element(element))(scope);
		scope.$digest();
	})
	
	it('should be defined',function(){
		expect(compiledEle).toBeDefined();
	})

	it('should have isolated scope',function(){
		expect(compiledEle.isolateScope()).toBeDefined();
	})

})