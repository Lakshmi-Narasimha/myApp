// goalinvestor.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var goalInvestorSchema = new mongoose.Schema({
    GoalDetails: {
        type: Array,
        "default": []
    }
});

var goalInvestorLookUp = mongoose.model('goalInvestorLookUp', goalInvestorSchema);

var goalInvestorModel = new goalInvestorLookUp({
    "GoalDetails":{
      "fsGoalSummary": [
        {
          "goalId": "G5678",
          "goal": "Retirement",
          "goalDetails": "Retirement",
          "mktvalue": "109431.83",
          "targetAmount": "2160000",
          "timeFrame": "36",
          "pendingTimeFrame": "32",
          "futureReturn": "5616000",
          "initcap": "1.95",
          "series": "Retirement-Retirement - ",
          "achieved": "5.07%",
          "completedTime": "11.11%",
          "sno": "1"
        },
        {
          "goalId": "G5678",
          "goal": "null",
          "goalDetails": "null",
          "mktvalue": "109431.83",
          "targetAmount": "null",
          "timeFrame": "null",
          "pendingTimeFrame": "null",
          "futureReturn": "null",
          "initcap": "0",
          "series": "- - ",
          "achieved": "0%",
          "completedTime": "0%",
          "sno": "1"
        }
      ]
    }

});

goalInvestorLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating goalInvestorLookUp table, please contact admin...');
    } else {
        goalInvestorLookUp.remove({}, function(err) {
            console.log('goalInvestorLookUp collection removed');
            goalInvestorModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating goalInvestorLookUp table, please contact admin...');
                }
                console.log('goalInvestorLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = goalInvestorLookUp;
