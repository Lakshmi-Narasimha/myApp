// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SWPInvInstallmentModelSchema = new mongoose.Schema({
    swpInstallmentResp: {
        type: Array,
        "default": []
    }
});

var SWPInvInstallmentModelLookUp = mongoose.model('SWPInvInstallmentModelLookUp', SWPInvInstallmentModelSchema);

var SWPInstallmentModel = new SWPInvInstallmentModelLookUp({
    swpInstallmentResp : {
      "swpInstallments": {
        "fundWiseData": [
          {
            "installmentDate": "19 Jan 2015",
            "installmentAmount": "1000",
            "nav": "67.18",
            "units": "100",
            "status": "processed",
            "bank": "ICICI Bank Ltd.",
            "bankAccountNo": "007601123321",
            "payoutType": "NACH"
          },
          {
            "installmentDate": "19 Feb 2015",
            "installmentAmount": "1000",
            "nav": "67.18",
            "units": "100",
            "status": "processed",
            "bank": "ICICI Bank Ltd.",
            "bankAccountNo": "007601123321",
            "payoutType": "NACH"
          },
          {
            "installmentDate": "19 Mar 2015",
            "installmentAmount": "1000",
            "nav": "67.18",
            "units": "100",
            "status": "processed",
            "bank": "ICICI Bank Ltd.",
            "bankAccountNo": "007601123321",
            "payoutType": "NACH"
          },
          {
            "installmentDate": "19 Apr 2015",
            "installmentAmount": "1000",
            "nav": "67.18",
            "units": "100",
            "status": "processed",
            "bank": "ICICI Bank Ltd.",
            "bankAccountNo": "007601123321",
            "payoutType": "NACH"
          },
          {
            "installmentDate": "19 May 2015",
            "installmentAmount": "1000",
            "nav": "67.18",
            "units": "100",
            "status": "processed",
            "bank": "ICICI Bank Ltd.",
            "bankAccountNo": "007601123321",
            "payoutType": "NACH"
          }
        ],
        "fundInfo": {
          "fundName": "Franklin India Equity Fund - Growth",
          "folioId": "19950599",
          "accountNo": "000901524837",
          "goal": "Wealth Creation",
          "goalDetails": "Buying a House",
          "startDate": "13 Jan 2014",
          "endDate": "13 Jan 2016",
          "frequency": "Weekly",
          "type": "Fixed Amount",
          "modeOfHolding": "Joint",
          "holders": {
            "firstHoldersName": "Shankar Narayan",
            "secondHoldersName": "Meenakshi",
            "minorGuardian": "Archana"
          }
        }
      }
    }
}
);

SWPInvInstallmentModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SWPInvInstallmentModelLookUp table, please contact admin...');
    } else {
        SWPInvInstallmentModelLookUp.remove({}, function(err) {
            console.log('SWPInvInstallmentModelLookUp collection removed');
            SWPInstallmentModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SWPInvInstallmentModelLookUp table, please contact admin...');
                }
                console.log('SWPInvInstallmentModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SWPInvInstallmentModelLookUp;
