/**
 * @ngdoc property
 * @name addNomineeCtrl
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function addNomineeCtrl() {
    console.log('selectedInvestorCtrl');
    
}
addNomineeCtrl.$inject = [];
module.exports = addNomineeCtrl;