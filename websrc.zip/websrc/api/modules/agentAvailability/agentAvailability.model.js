var config = require('../../../config/config');

var agentAvailabilityModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [

                ],
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "userMessage": "An expert will join you shortly",
                    "code": "00000",
                    "messageStyle": "TopPersistent",
                    "message": "Waiting for live chat",
                    "topMessage": "Your live chat will start soon",
                    "buildNumber": "207",
                    "type": "ChatTop",
                    "requestId": "f01926d1-db5f-4035-84d7-2c7eeb4ecd0f",
                    "buttonTitle": "View"
                }
            }
        },
        "Page": {
            "status": "online",
            "pageType": "livechat",
            "parentPageType": "myData",
            "availability": "true",
            "inHOP": "true",
            "callType": "agent",
            "timeToWait": "5",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "9afe0b3f-a232-47df-80bf-b9f8e68de25e",
            "type": "Success"
        }
    },
    createRequestUri: {
        Billing: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Billing,
        },
        WirelessSales: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessSales + '&agentGroupID=' + config.AG_WirelessSales,
        },
        Device: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Device,
        },
        Global: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Global,
        },
        MVTrans: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_MVTrans,
        }
    }
};

module.exports = agentAvailabilityModelConfig;
