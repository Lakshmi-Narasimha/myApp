/**
 * @ngdoc property
 * @name RenewSIPReviewCtrl
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function RenewSIPReviewCtrl($scope,eventConstants,transactNowModel,$state,transactModel,fundDetails,bankDtlsModel) {
    console.info("renew sip Controller!!");
    $scope.sipType = "renewSip";
    $scope.config.toState = 'invTransact.base.renewsip';
    $scope.config.fromState = $state.current.name;
    $scope.presentState = $state.current.name;
    $scope.keyValuePairs = [
                {
                    text: "Payment Method",
                    value: bankDtlsModel.getPaymentDetails().selectedBank
                },
                {
                    text: "Total Amount",
                    value: bankDtlsModel.getPaymentDetails().totalAmount

                }
            ];


    $scope.isNewFolio = transactModel.getIsNewFolio();
    // investor preference auto populated data for renew sip
    var renewSipInvestorPreferences = transactModel.getFundDetails();
    var distIdCheck = renewSipInvestorPreferences.distributor.split("~");
    if(transactNowModel.hasRenewInvData){
        var investPreferValue = {
            investorMode: distIdCheck[0].trim().toLowerCase() == "direct" ? "direct" : "financial",
            advisorMode: "existing",
            code: renewSipInvestorPreferences.distributor,
            subBrokerArn: renewSipInvestorPreferences.subBrokerARN,
            subBrokerCode:renewSipInvestorPreferences.subDistId,
            euin: renewSipInvestorPreferences.euin
        };
    }
    
    $scope.showInvestorPreferencePanel = true;
    // $scope.config.toState = "transactnow.baseNow.renewSip";
    // $scope.config.fromState = $state.current.name;
    if(transactNowModel.hasRenewInvData){
        transactNowModel.setInvestPrefer(investPreferValue);
        transactModel.setAdvDetails(investPreferValue);
    }
    $scope.config.toTxnDetailsState = "invTransact.txnDetailsNow.renewsip";
    transactNowModel.hasRenewInvData = false;
    $scope.$on("NAVIGATE_TO_RENEW_SIP_REVIEW",function(event){
        $scope.showInvestorPreferencePanel = false;
        $scope.$broadcast('getInvestorPreferenceData');
    });

	$scope.$on("openRenewSipModel",function(event){
        $scope.$broadcast("continueInvestPrefer");
	});
    $scope.$on("investorPanelRenewSipUpdated",function(event){
        $scope.showInvestorPreferencePanel = true;
        transactNowModel.isRenewSipInvEditClicked = false;
    });


    //redirecting to transact page
    $scope.$on("NAVIGATE_TO_TRANSACTNOW",function(event,data){
    	//debugger
        if($scope.presentState === "invTransact.review.renewsip" && transactNowModel.isRenewSipInvEditClicked == true){
            transactNowModel.hasInvPreferData = true;
            transactNowModel.isInvPreferHasInitialData = false;
            $scope.$broadcast("NAVIGATE_TO_RENEW_SIP_REVIEW");
        }else{
            /*$scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);*/
            transactModel.setStateValue({ key: data.key });
            $state.go($scope.config.toState,data);
        }
        // param = data;
    });

    $scope.$on('validated', function(event) {
        
        var transactType = transactModel.getTransactType();

        //debugger;
        /*if(transactType !== null) {
            if(transactType === TransactConstant.sip.SIP || transactType === TransactConstant.sip.FUNDSIP) {
                $scope.reviewDetailsState = "transactnow.reviewNow.sip";
            } else if(transactType === TransactConstant.buy.BUY || transactType === TransactConstant.buy.BUYFUND) {
                $scope.reviewDetailsState = "transactnow.reviewNow.buy";
            } else if(transactType === TransactConstant.guest.RENEWSIP) {
                $scope.reviewDetailsState = "transactnow.reviewNow.renewSip";
            } 
            // else if(transactType === TransactConstant.guest.SMART_SOLUTIONS) {
            //     $scope.reviewDetailsState = "transactnow.reviewNow.smartSol";
            // }
        }
        if(transactModel.isTransactNowSmartSol)
        {
            $scope.reviewDetailsState = "transactnow.reviewNow.smartSol";   
        }*/
        $state.go('invTransact.review.renewsip');
    });
 	
	
}

RenewSIPReviewCtrl.$inject = ['$scope','eventConstants','transactNowModel','$state','transactModel','fundDetails','bankDtlsModel'];
module.exports = RenewSIPReviewCtrl;