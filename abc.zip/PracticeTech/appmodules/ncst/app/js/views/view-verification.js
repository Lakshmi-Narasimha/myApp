
define(
        ['text!appmodules/ncst/app/templates/verification.html', 'appmodules/ncst/app/js/lib/validate-4.2', 'appmodules/ncst/app/js/utils', 'config', 'appmodules/ncst/app/js/models/model-new-client', 'appmodules/ncst/app/js/models/model-client', 'appcommon/globalcontext', 'appcommon/analytics', 'services/dataservice', 'appcommon/constants', 'appmodules/ncst/app/data/country-list'],
        function (Template, Validator, Utils, Config, NewClientModel, ClientModel, GlobalContext, Analytics, DataService, constants, DropdownOptions) {
        	 var BASE_URL = Config.odataServiceName, ClientInfoModel = ClientModel.get('clientInfo');
        	 var context = GlobalContext.getInstance().getGlobalContext().Context, clientData = null;
             var _validateClientDataMapping = {
             clientInfo: {
                 entityRole: {
                     "Corporation - C-Corp": "1C",
                     "Corporation - S-Corp": "1S",
                     "Estate": "09",
                     "Government entity": "04",
                     "Irrevocable trust": "08",
                     "LLP": "10",
                     "LLC - C-Corp": "6C",
                     "LLC - S-Corp": "6S",
                     "Non-Profit": "05",
                     "Partnership": "02",
                     "Revocable trust": "07"
                 }
             }
         };
           var verificationView = Backbone.View
                    .extend({
                        el: '#ncst-app',
                        statsTemplate: _.template(Template),
                        initialize: function() {
                            this.$main = this.$('#client-info');

                        },
                        events: {
                            'click #back-to-step6,#m-back-to-step6': 'navigateToStep6',
                            'click #create-client-button,#m-create-client-button': 'navigateToStep8',
                            'click #edit-ncst-client-info' : 'clientInfoLinkClicked',
                            'click #edit-ncst-address-entry' : 'clientAddressLinkClicked',
                            'click #edit-ncst-client-details' : 'clientDetailsLinkClicked',
                            'click #edit-ncst-client-details2' : 'clientDetails2LinkClicked',
                            'click #edit-ncst-employment' : 'clientEmploymentLinkClicked',
                            'click #edit-ncst-income' : 'clientIncomeLinkClicked',
                            'click #edit-ncst-income2' : 'clientIncome2LinkClicked',
							"click .sad-text.sad-step7":"handleSAD"
						},
					handleSAD:function(){
						Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
						Utils.lockForm();
						ClientModel.createDraft().done(function(response){
							Utils.unlockForm();
							ClientModel.showDraftSaveSuccesMessage(response);
						}).fail(function(error){
							Utils.unlockForm();
							Utils.showDraftSaveErrorMessage();
						});
					},
                        clientInfoLinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientInfoLinkClicked');
                        },
                        clientAddressLinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientAddressLinkClicked');
                        },
                        clientDetailsLinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientDetailsLinkClicked');
                        },
                        clientDetails2LinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientDetails2LinkClicked');
                        },
                        clientEmploymentLinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientEmploymentLinkClicked');
                        },
                        clientIncomeLinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientIncomeLinkClicked');
                        },
                        clientIncome2LinkClicked : function() {
                        	Analytics.analytics.recordSharedSuiteAction('ncstVerification:clientIncome2LinkClicked');
                        },
                        render: function(obj) {
                        	var _clientObj = ClientModel.toJSON();
                        	_clientObj.clientInfo = _clientObj.clientInfo.toJSON();
                        	_clientObj.addressEntry = _clientObj.addressEntry.toJSON();
                        	_clientObj.details = _clientObj.details.toJSON();
                        	_clientObj.employement = _clientObj.employement.toJSON();
                        	_clientObj.income = _clientObj.income.toJSON();
                        	_clientObj.obj = obj;
                        	clientData = obj;
                        	domiciledName = this.domiciledName(clientData);
                        	industryVal = this.industryClassification(clientData);
                        	firstCitizenshipName = this.citizenshipValues(clientData.firstCtznCtryCd);
                        	secondCitizenshipName = this.citizenshipValues(clientData.scndCtznCtryCd);
                        	investmentArray = this.investmentArrayData(clientData);
                        	assetArray = this.assetHeldAwayData(clientData);
                        	this.$main.html(this.statsTemplate(_clientObj, domiciledName, firstCitizenshipName, secondCitizenshipName, industryVal, investmentArray, assetArray));
                            var clientType = ClientInfoModel.get('clientType');
                            // Deciding if Person or entity
                            if (clientType == "P") {
                                $('.entity-field').addClass('hidden');
                                $('.person-field').removeClass('hidden');
                            } else {
                                $('.entity-field').removeClass('hidden');
                                $('.person-field').addClass('hidden');
                            }
                           $("#client-info").css({'border-top': 'solid 3px #7db742', 'padding': '0'});
                           $(document).off('click','.edit-link').on('click','.edit-link',function(e){
                        	   e.preventDefault();
                        	   var _queryString = context.QueryString?context.QueryString:'';
                        	   Backbone.history.navigate($(this).attr('data-href')+_queryString, true);	
                           });
                        },
                        citizenshipValues: function (obj) {
                        	var countryName = "", mappingCode = DropdownOptions.ISOCountryList;
                        	if (obj) {
                        		_.each(mappingCode, function (list) {
                        			if (list.code == obj) {
                        				countryName = list.name;
                        			}
                        		});
                        	}
                        	return countryName;
                        },
                        domiciledName: function (obj) {
                        	var frgnOrgIndCd = obj.frgnOrgInd, stateCntry = "", mappingCode,domiciledName = "";
                        	if (frgnOrgIndCd == 'Y') {
                        		stateCntry = obj.stOfIncorpCd;
                        		mappingCode = DropdownOptions.USStateslist;
                        	} 
                        	_.each(mappingCode, function (list) {
                        		if (list.code == stateCntry) {
                        			domiciledName = list.name;
                        		}
                        	});
                        	return domiciledName;
                        },
                        industryClassification: function (obj) {
                        	var indsClsCd = obj.riskProfile.indsClsCd;
                        	if (indsClsCd != "") {
                        	var mappingCode = constants.industryClassifications;
                        	var indsName = "";                        	
                        		_.each(mappingCode, function (list) {
                        			if (list.code == indsClsCd) {
                        				indsName = list.name;
                        			}
                        		});

                        	} else { indsName = "";}
                        	return indsName;
                        },
                        investmentArrayData: function (obj) {
                        	var productExpList = obj.productExpe;
                        	var investArray = [], investZeroArray = [];

                        	var descObj = {
                        		'A': 'Certificates/CDs',
                        		'B': 'Mutual Funds/529s',
                        		'C': 'Annuities/Variable life',
                        		'D': 'Equities (includes ETFs)',
                        		'E': 'Fixed income (includes UITs)',
                        		'F': 'Options',
                        		'G': 'Commodities',
                        		'H': 'Limited Partnerships',
                        		'J': 'Structured products',
                        		'K': 'Alternative investments (includes managed futures, fund of hedge funds)',
                        		'L': 'Non-traded REITs/BDCs and non-traded closed-end funds'
                        	}
                        	var yearObj = {
                        		'A': '0 YEARS',
                        		'B': '1-2 YEARS',
                        		'C': '3-5 YEARS',
                        		'D': '6+ YEARS'
                        	}
                        	var transObj = {
                        		'A': '0-5',
                        		'B': '6-15',
                        		'C': '16+'
                        	}
							_.each(productExpList, function(list) {
								var investExpDesc = "", investExpList = list.prodExpeTypCd, investExpListCode = list.invExpeYrCd;
								var investmentObj = {
									key: descObj[investExpList],
									years: yearObj[investExpListCode],
									trans: transObj[list.annlTransCd]
								}
								if (investExpListCode == "A") {
									investZeroArray.push(investmentObj)
								} else {
									investArray.push(investmentObj)
								}
							});
							if(investZeroArray.length == 11){code='Yes'}else{code='No'}
							return {
								code: code,
								investArray: investArray,
								investZeroArray: investZeroArray
							}
                    	},
                        assetHeldAwayData: function (obj) {
                        	var heldAwayArray = obj.heldAway;
                        	var heldAwayCode = heldAwayArray.heldAwayInfoCd;
                        	var heldAwayDetails = heldAwayArray.heldAwayDetail;
                        	var assetWithValueArr = [];
                        	var assetWithoutValueArr = [];

							var descObj = {
								heldAwayAltInvAmt: "Alternative investments (includes managed futures, fund of hedge funds)",
									heldAwayAnntVarLifeAmt: "Annuities/Variable life",
									heldAwayBndAmt: "Fixed income (includes UITs)",
									heldAwayCertOrCdAmt: "Certificates/CDs",
									heldAwayCmdtyAmt: "Commodities",
									heldAwayLtdPtnrAmt: "Limited Partnerships",
									heldAwayMFAmt: "Mutual Funds/529s",
									heldAwayNonTrdREITAmt: "Non-traded REITs/BDCs and non-traded closed-end funds",
									heldAwayOptAmt: "Options",
									heldAwayOthAmt: "Other",
									heldAwayStkAmt: "Equities (includes ETFs)",
									heldAwayStrcProdAmt: "Structured products"
                        	}

                        	for (var property in heldAwayDetails) {
                        		if (heldAwayDetails.hasOwnProperty(property)) {
                        			var desc = descObj[property];
                        			var assetObj = {
                        				key: desc,
                        				value: heldAwayDetails[property]
                        			}
                        			if (heldAwayDetails[property]== "0") {
                        				assetWithoutValueArr.push(assetObj)
                        			} else {
										assetWithValueArr.push(assetObj)
                        		}
                        	}
                        	}
                        	return {
                        			code: heldAwayCode,
                        			assetWithValueArr: assetWithValueArr,
                        			assetWithoutValueArr: assetWithoutValueArr
							}
						},
                        clearView : function(){
								this.undelegateEvents();// Unbind all local event bindings
                        	//this.model.unbind( 'change', this.render, this ); // Unbind reference to the model
                        	},
                        	afterRender: function() {
                        },
                        	navigateToStep6: function() {
                        	$('.ncst-step.step6').find('.step-nav-links').click();
                        },
                        	navigateToStep8: function() {
                        	this.createClient();
                        },
                        	createClient: function() {
                			Utils.lockForm();
                            var _data1 = ClientModel.get('clientValidatedDtls');
                            var _url1 = BASE_URL + 'setupNewClient?$format=json';
                        		//var _url1 = 'data/createclientO.json';
                            var _self = this;
                        		//console.log(JSON.stringify(_data1));
                            Utils.post(_url1, _data1,
                                    newClientCreatedSucces, function(xhr) {
                            			Utils.logError(xhr);
                                        if(xhr.status == 401){
                                           Utils.unlockForm(); 
                                           BootstrapDialog.alert(Validator.errorMsg['401'],function(result) {
                                            $(window).scrollTop(0);
                                           }, "Unauthorized user");
                                        }else{                                        
                                            Utils.showSystemUnavailableMsg("7", "verify");
                                    }    
                                    },{accept: "application/vnd.awm.ampf.com+json;"});

                        		function newClientCreatedSucces(resp, statusMessage, xhr) {
                                var response = resp.d;
                                var obj = {}, validatedData,
                                    explanations,
                                    paAssignmentFailedExplntn,
										paAssignmentFailed;
                                obj.faceToClient = null;
                                try{
                                   explanations = response.explanations.results;
                                }catch(e){
                                    explanations = [];
                                } finally {
                                    paAssignmentFailedExplntn = _.find(explanations, function (explanation) {
                                        return explanation.explCd == "15812"
                                });
                                    paAssignmentFailed = paAssignmentFailedExplntn ? true : false;
                        		}
                                if (!explanations.length || (response && response.crteSSDCaseInd && response.crteSSDCaseInd === "Y")) {
                                    validatedData = JSON.parse(ClientModel.get("clientValidatedDtls"));
                                    obj = response.customerTypeCd == 'P' ? (response.personClient || validatedData.personClient)  : (response.orgClient || validatedData.orgClient);
                                    obj.paAssignmentFailed = paAssignmentFailed;
                                    obj.clientType = response.customerTypeCd;
                                    obj.advId = response.prmAdvsDstrId;
                                    obj.isF2CEstablished = false;
                                    obj.f2cUpdateFailed = false;
                                    obj.f2cRetreivefailed = false;
                                    obj.advisorNm = ClientModel.get("advisorNm");
                                    obj.servcAdvsrId = response.servAdvsDstrId;
                                    obj.servcAdvsrNm = ClientModel.get("servicingAdvisorName");
                                    obj.clId = response.fmtClId;
                                    obj.fullclId = response.clId;
                                    obj.grpId = response.fmtGrpId;
                                    obj.grpIdFullLength = response.grpId;
                                    obj.Primary = '', obj.Mailing = '', obj.PrimaryMail = '', obj.SecondaryMail = '';
                                    obj.crteSSDCaseInd = response.crteSSDCaseInd;
                                    
                                	// primary/mailing address
                                    var postalAddrArr = typeof obj.postalAddresses.results != 'undefined' ? obj.postalAddresses.results : obj.postalAddresses;
                                    if (postalAddrArr.length > 0){
                                        $.each(postalAddrArr, function(indx,addr){
                                            var addrDtls = {'addrLn1': addr.addrLn1, 'addrLn2': addr.addrLn2, 'addrLn3': addr.addrLn3, 'ctyNm': addr.ctyNm, 'stCd': addr.stCd, 'postlCd': addr.postlCd,ctryNm:addr.ctryNm};
                                            if(addr.addrUseCd == 'Primary'){
                                                obj['Primary'] = addrDtls;
                                            }else if (addr.addrUseCd == 'Mailing'){
                                                obj['Mailing'] = addrDtls;
                                        }
                                    });
                                    }else{
                                    	//log custom error
                                    	var _errorObj = {message:""};
                                    	var _messgae = {"description":"Postal Address Empty","responseData":obj.postalAddresses};
                                    	_errorObj.message = JSON.stringify(_messgae);
                                    	Utils.logError(_errorObj,true);
                                }
                                	// primary/secondary email
                                    var emailAddrArr = typeof obj.emails.results != 'undefined' ? obj.emails.results : obj.emails;
                                    if (emailAddrArr.length){

                                        $.each(emailAddrArr, function(indx,mail){
                                            var mailDtls = {'emlAddr': mail.emlAddr};
                                            if(mail.emlUseCd == 'Primary'){
                                                obj['PrimaryMail'] = mailDtls;
                                            }else if (mail.emlUseCd == 'Secondary'){
                                                obj['SecondaryMail'] = mailDtls;
                                        }
                                    });
                                } 
                                	// homephone/work phone
                                	/*** Changes- new requirement in phone ***/
                                    obj['Home'] = null;
                                    obj['Business'] = null;
                                    obj['Mobile'] = null;
                                    obj['Other1'] = null;
                                    obj['Other2'] = null;
                                    var telPhArr = typeof obj.telephones.results != 'undefined' ? obj.telephones.results : obj.telephones;
                                    if(telPhArr.length>0){

                                    	$.each(telPhArr, function(indx, tel) {
                                		
                                    		switch (tel.phnLblTxt) {
    										case 'HOME':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Home'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr
    												};
    												}else{
    													obj['Home'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    												};
    										}
    												obj['Home'].phnPrfrCd = tel.phnPrfrCd;
    											
    											break;
    										case 'WORK':
    											
    											 tel.phnExtnNbr = (tel.phnExtnNbr == 0) ? '' : tel.phnExtnNbr;
    	                                        
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													// telDtls = {'phnNbr': tel.phnNbr, 'teleExtnNbr': tel.phnExtnNbr};
    													obj['Business'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    												}else{
    													obj['Business'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    										}
    												obj['Business'].phnPrfrCd = tel.phnPrfrCd;
    											
    											break;
    										case 'MOBILE':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Mobile'] ={
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr
    												};
    												}else{
    													obj['Mobile'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    												};
    										}
    												obj['Mobile'].phnPrfrCd = tel.phnPrfrCd;
    											
    											break;
    										case 'OTHER1':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Other1'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    												}else{
    													obj['Other1'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    										}
    												obj['Other1'].phnPrfrCd = tel.phnPrfrCd;
    											break;
    										case 'OTHER2':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Other2'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    												}else{
    													obj['Other2'] ={
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												}
    										}
    												obj['Other2'].phnPrfrCd = tel.phnPrfrCd;
    											break;
    										default:
    											break;
                                    	}
                                    	
                                    });
                                    
                                }
                                    
                                    if (response.customerTypeCd == 'P'){
                                                                         
                                        if (obj.bthDt){
                                            var dateStr = obj.bthDt;
                                            var match = dateStr.match(/(\d{4})(\d{2})(\d{2})/);
                                            var bthDt = match[2] + '/' + match[3] + '/' + match[1];
                                            obj['birthday'] = bthDt;
                                    } 
                                    	//product experiences
                                        if (obj.productExpe.length) {
                                        	obj['pdtExperiences'] = obj.productExpe;
                                        	/*var pe = [];
                                            var swapPdtExpArr = _.invert(_validateClientDataMapping.clientIncome.prodExp);
                                            $.each(obj.productExpe, function(indx,pdtexp){
                                               pe.push(swapPdtExpArr[pdtexp.prodExpeTypCd]);                                                
                                            });
                                            obj['pdtExperiences'] = pe.join(',');*/
                                    }
                                    	//married status code
                                    	//                                        if (obj.mrtlStatCd){
                                    	//                                            var swapMrtlStatArr = _.invert(_validateClientDataMapping.clientDetails.maritalStatus);
                                    	//                                            obj['marriedStatus'] = swapMrtlStatArr[obj.mrtlStatCd];
                                    	//                                        }

                                    } else if (response.customerTypeCd == 'O') {
                                        var swapEntityRoleArr = _.invert(_validateClientDataMapping.clientInfo.entityRole);
                                        obj['orgType'] = swapEntityRoleArr[obj.orgTypCd];
                                }
                                	//set assoc cleint name
                                    if(obj.associatedClient && obj.associatedClient.clId && obj.associatedClient.clId !=""){
                                        obj['asccoaitedClientName'] = ClientInfoModel.get('clientassocFmtNm');
                                }
                                    ClientModel.set('clientCreated','yes'); 
                                    NewClientModel.clear();
                                    
                                    if (obj.grpIdFullLength !== "undefined" && obj.grpIdFullLength !== null && obj.crteSSDCaseInd == "N") {
                                        if (ClientInfoModel.get("clientAssociated") == "Yes" || obj.servcAdvsrId == obj.advId || ClientModel.get('isAACUser')) {
                                            getF2CInformation(obj);
                                        } else {
                                            updateGroupF2CInformation(obj);
                                    }
                                    } else {
                                        navigateToConfirmStep(obj);
                                }
                                    
                                }
                                else {
                                	Utils.unlockForm();
                                    obj = {Primary:'',Mailing:'',PrimaryMail:'',SecondaryMail:'',prospectInfo:'',financialInfo:''};
                                    obj['Home'] = null;
                                    obj['Business'] = null;
                                    obj['Mobile'] = null;
                                    obj['Other1'] = null;
                                    obj['Other2'] = null;
                                    obj.isF2CEstablished = false;
                                    obj.f2cUpdateFailed = false;
                                    resp = Utils.normalizeWS(JSON.stringify(resp));
                                    resp = JSON.parse(resp);
                                    var _explntns = resp.d.explanations.results;
									 ClientModel.set('clientCreated','yes'); 
									 NewClientModel.clear();
	                                 navigateToConfirmStep(clientData)
									try {
                                    	xhr.responseJSON.error = { message: { value: JSON.stringify(_explntns) } };
                                    	Utils.logError(xhr);
									} catch (e) {
										Utils.logError(e);
                                }
                        		}
                        			function updateGroupF2CInformation(clientInfoObj) {
                                    var _data = {
                                        "actnCd": "A",
                                        "faceprflId": null,
                                        "grpFacePrflUnasReasCd": null,
                                        "eTag": null,
                                        "dstrId": clientInfoObj.servcAdvsrId,
                                        "dstrCtx": "DMU.DIST",
                        			}
                                    DataService.maintainGroupFaceProfileAssignment(_data, clientInfoObj.grpIdFullLength).done(function () {
                                        clientInfoObj.f2cUpdateFailed = false;
                                        clientInfoObj.isF2CEstablished = true;
                                        getF2CInformation(clientInfoObj);
                                    }).fail(function (xhr) {
                                        clientInfoObj.f2cUpdateFailed = true;
                                        navigateToConfirmStep(clientInfoObj);
                        			});
                        		}
                        			function getF2CInformation(clientInfoObj) {
                                    var _facePrflid = null;
                                    DataService.getFaceToClientAssignments(clientInfoObj.grpIdFullLength).done(function (respons) {
                                            if (respons && respons.value && respons.value.length > 0) {
                                                _facePrflid = respons.value[0].facePrflId;
                                                DataService.getFaceToClient(_facePrflid).done(function (respns) {
                                                    if (respns && respns.d) {
                                                        clientInfoObj.isF2CEstablished = true;
                                                        var _f2c = respns.d;
                                                        clientInfoObj.faceToClient = {
                                                            "facePrflDistributor": _f2c.facePrflDistributor,
                                                            "prflAddress": _f2c.prflAddress,
                                                            "prflTelephone": _f2c.prflTelephone,
                                                            "prflPractice": _f2c.prflPractice,
                                                            "preferred":false
                                                    }
                                                        var _f2cDstid = (clientInfoObj.servcAdvsrId == clientInfoObj.advId || ClientModel.get('isAACUser')) ? clientInfoObj.advId : clientInfoObj.servcAdvsrId;
                                                        DataService.getDistributorInfo(_f2cDstid, [401, 404, 500]).then(function (DistbtrResponse) {
                                                            var _dstrInfo = DistbtrResponse[0];
                                                            if (_dstrInfo !== undefined && _dstrInfo !== null) {
                                                                if (_facePrflid == _dstrInfo.prfrFacePrflId) {
                                                                    clientInfoObj.faceToClient.preferred = true;
                                                            }
                                                            } else {
                                                                clientInfoObj.f2cRetreivefailed = true; 
                                                        }
                                                            navigateToConfirmStep(clientInfoObj);
                                                        }).fail(function () {
                                                            clientInfoObj.f2cRetreivefailed = true;
                                                            navigateToConfirmStep(clientInfoObj);
                                                    });
                                                    } else {
                                                        clientInfoObj.f2cRetreivefailed = true;
                                                        navigateToConfirmStep(clientInfoObj);
                                                }
                                                	//navigateToConfirmStep(clientInfoObj);
                                                }).fail(function () {
                                                        clientInfoObj.f2cRetreivefailed = true;
                                                        navigateToConfirmStep(clientInfoObj);
                                            });
                                            } else {
                                                clientInfoObj.f2cRetreivefailed = true;
                                                navigateToConfirmStep(clientInfoObj);
                                    }
                                    }).fail(function () {
                                            clientInfoObj.f2cRetreivefailed = true;
                                            navigateToConfirmStep(clientInfoObj);
                        			});
                        		}
                        			function navigateToConfirmStep(clientInfoObj) {
                                    setnewClientObject(clientInfoObj);
                                    var _queryString = context.QueryString ? context.QueryString: '';
                                    Backbone.history.navigate('ncst/confirmation' +_queryString, true);
                                    $('.ncst-step:not(.step8)').removeClass('active pending').addClass('finished');
                                    window.scrollTo(0, 0);
                        		}
                        			function setnewClientObject(newClientObj) {
                                    NewClientModel.set(newClientObj);
                        		}
                        			/*********Comment this one for 9/18 release*********/
                                ClientModel.createDraft(true, obj.fullclId).done(function (response) {
                                	//Utils.unlockForm();
                                	//ClientModel.showDraftSaveSuccesMessage(response);
                                	console.log("Draft status updated.");
                                	}).fail(function (error) {
                                		//Utils.unlockForm();
                                		//Utils.showDraftSaveErrorMessage();
                                        console.log("Draft status update failed.");
                        		});
                        	}
                        },                           
                        	handlerForCancel: function() {
                            BootstrapDialog
                                    .confirm(
                                            "Cancel",
                                            "All your work will be lost.  Are you sure you want to cancel?",
                                            function(confirm) {
                                                if (confirm) {
                                                    window.open('', '_self');
                                                    window.close();
                                                    Analytics.analytics.recordSharedSuiteAction('ncstVerification:cancelClicked');
                                            }
                        	});

                        }
                    });
           return verificationView;
        });
