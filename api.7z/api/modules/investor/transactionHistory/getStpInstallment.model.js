// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var STPInvInstallmentModelSchema= new mongoose.Schema({
    stpInstallmentResp: {
        type: Array,
        "default": []
    }
});

var STPInvInstallmentModelLookUp= mongoose.model('STPInvInstallmentModelLookUp', STPInvInstallmentModelSchema);

var STPInstallmentModel = new STPInvInstallmentModelLookUp
({
    stpInstallmentResp : {
      "stpInstallments": {
        "fundWiseData": [
          {
            "installmentDate": "19 Apr 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth-Franklin India Prima",
            "amount": "100",
            "nav": "111.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Mar 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth-Franklin India Prima",
            "amount": "100",
            "nav": "109.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Feb 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth-Franklin India Prima",
            "amount": "100",
            "nav": "120.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Jan 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "107.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Dec 2015",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "106.21",
            "units": "15",
            "status": "Processed"
          }
        ],
        "fundInfo": {
          "fundName": "Franklin India Equity Fund - Growth",
          "folioId": "19950599",
          "accountNo": "000901524837",
          "goal": "Wealth Creation",
          "goalDetails": "Buying a House",
          "startDate": "13 Jan 2014",
          "endDate": "13 Jan 2016",
          "frequency": "Weekly",
          "type": "Fixed Amount",
          "modeOfHolding": "Joint",
          "holders": {
            "firstHoldersName": "Shankar Narayan",
            "secondHoldersName": "Meenakshi",
            "minorGuardian": "Archana"
          }
        }
      }
    }
}
);

STPInvInstallmentModelLookUp
.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating STPInvInstallmentModelLookUptable, please contact admin...');
    } else {
        STPInvInstallmentModelLookUp.remove({}, function(err) {
            console.log('STPInvInstallmentModelLookUp collection removed');
            STPInstallmentModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating STPInvInstallmentModelLookUp table, please contact admin...');
                }
                console.log('STPInvInstallmentModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = STPInvInstallmentModelLookUp
;
