'use strict';

describe('Directive: First Unit Holder', function() {
	var $rootScope, $scope, $compile, validHTML, compiledElement;

	beforeEach(angular.mock.module('investor'));
	 beforeEach(function() {
        angular.mock.inject(function(_$compile_, _$rootScope_) {
            $rootScope = _$rootScope_;
            $compile = _$compile_;
            $scope = $rootScope.$new();

            validHTML = angular.element('<first-unit-holder></first-unit-holder>');
            compiledElement = $compile(validHTML)($scope);
            $scope.$digest();
        });
    });

	it('should be defined', function() {
		expect(compiledElement).toBeDefined();
	});
});