function createNewPasswordController ($scope, $state, constants, advisorRegistrationModelService,$window,toaster,$cookies,appConfig) {
	 
			$scope.newPasswordObj = {
            key : 'newpassword',
            text : 'New password',
            value : '',
            name : 'newpassword',
            isRequired: true,
            type: 'text'
			 }

       $scope.headingObj = {
          text:'Forgotten Password',
          displayBack:true
       }
       
      $scope.confirmPasswordObj = {
        text : 'confirm password',
        key:'confirmpassword',
        name:'confirmpassword',
        isRequired : true,
        value:'',
        type:'text'
       }

       $scope.backBtn = function($event){
         $event.preventDefault();
         $state.go('loginmaster.userverification.securityquestion')
       }
       $scope.submitPassword = function(data){  
         var postObj = {};
         postObj.guId = advisorRegistrationModelService.getUserData().guId;//
         postObj.newPwd=data.newpassword.$viewValue;
         postObj.confirmNewPwd=data.confirmpassword.$viewValue;
         if((data.newpassword.$viewValue === data.confirmpassword.$viewValue)&& data.newpassword.$viewValue){
              var resetSuccess = function(successResp){
                $cookies.remove('accessToken', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('guId', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('userType', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.put('accessToken',successResp.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.put('guId',successResp.data.guId, {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.put('userType',successResp.data.userType, {'domain': appConfig.DOMAIN_CONFIG});
                $window.location.href = successResp.data.userRedirectURI;
              };
              var resetFailure = function(errResp){ 
                   toaster.error(errResp.data[0].errorDescription);
              };
           advisorRegistrationModelService.postPassword(postObj).then(resetSuccess,resetFailure);
          }
         
       }
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
createNewPasswordController.$inject = ['$scope', '$state' , 'constants' ,'advisorRegistrationModelService','$window','toaster','$cookies','appConfig'];
module.exports = createNewPasswordController;