/**
 * @ngdoc directive
 * @name basisBankAccountDetails
 *
 * @description
 *
 * -
 *
 **/
'use strict';

var basisBankAccountDetails = function(investorEventConstants, basisBankAccInitialLoader, basisBankAccModel, basisBankListModel, investorEvents, investorConstants, eventConstants, toaster, fticLoggerMessage, loggerConstants) {
    return {
        template: require('./basisBankAccount.html'),
        restrict: 'E',
        replace: true,
        controller: function($scope, $element, $attrs) {
            var selected = {};
            $scope.cfrBankAcc = [];            
            $scope.changeBankList = [];
            $scope.currentBankAcc = [];
            $scope.selectedBankName = [];            
            $scope.imageError = false;
            $scope.actionClass = "icon-fti_inlineEdit";
            basisBankAccInitialLoader.bankDetails($scope);
            $scope.$on('basisBankAccDetails', function(data) {
                var data = basisBankAccModel.getBasisBankDetails();
                $scope.invBankDetails = data.invBankDetails;
            });
            $scope.inputObject = {
                label:"Select Bank",
                isRequired: true
            }
            $scope.gridOptions = {};
            $scope.gridOptions.columnDefs = [{
                field: 'fundDesc',
                displayName: 'Fund Name',
                width: "275",
                headerCellClass: 'fti-grid-sortDisabledHeader',
                enableSorting: false,
                pinnedLeft: true

            }, {
                field: 'folioAccount',
                displayName: 'Account No.',
                width: "280",
                headerCellClass: 'fti-grid-sortDisabledHeader',
                enableSorting: false
            }, {
                field: 'payInType',
                displayName: 'Pay In Type',
                width: "280",
                headerCellClass: 'fti-grid-sortDisabledHeader',
                enableSorting: false

            }];

            $scope.loadIFSCDetails = function($index) {
                $scope.$broadcast(investorEventConstants.Eforms.INV_EFORM_BANK_SELECTED_IFSC, {
                    title: $scope.selectedBankName[$index].title
                });
            };
            $scope.$on('bankChange', function(event, data) {
                $scope.$broadcast(investorEventConstants.Eforms.INV_EFORM_BANK_SELECTED_IFSC, {
                    title: data.title
                });
            })

            $scope.onClick = function($index, bankDetails) {
                bankDetails.editMode = true;
                var data = basisBankAccModel.getBasisBankDetails();
                angular.element($element[0].querySelectorAll('.floatLabels')).addClass('focused');                
                basisBankAccInitialLoader.bankNameList($scope);
                $scope.currentBankAcc[$index] = {
                    text: "Enter Bank Account No.",
                    value: data.invBankDetails[$index].bankAccountNo,
                    isRequired: true,
                    class: "",
                    type: "password"
                }
                $scope.cfrBankAcc[$index] = {
                    text: "Confirm Bank Account No.",
                    value: data.invBankDetails[$index].bankAccountNo,
                    isRequired: true,
                    class: "",
                    errorMessage: ""
                }

                $scope.selectedBankName[$index] = {
                    title: data.invBankDetails[$index].bankName,
                    key: "B1"
                }
                $scope.$on(investorEventConstants.Eforms.INV_EFORM_IFSC_SEARCH_RES, function(event, data) {

                    var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_EFORMS_MODULE + ' | ' + loggerConstants.INV_EF_INCLUDE_TEMPLATE_DIRECTIVE + ' | on ' + investorEventConstants.Eforms.INV_EFORM_IFSC_SEARCH_RES + ' event' /* Function Name */ ;
                    fticLoggerMessage.displayLoggerMessage({
                        level: 'info',
                        'message': message
                    });
                    $scope.currentIfscNumber = data.ifscCode;

                });

                $scope.loadIFSCDetails($index);
                $scope.$on('bankNamesList', function($event) {
                    var banksList = basisBankListModel.getBasisBankNames();
                    $scope.invBankList(banksList);
                });
            }
            $scope.invBankList = function(bankNamesList) {
                $scope.changeBankList = [];
                angular.forEach(bankNamesList, function(bankNamesList, index) {
                    var obj = {};
                    obj.title = bankNamesList.bankName + " Bank";
                    obj.key = bankNamesList.bank;
                    $scope.changeBankList.push(obj);
                });
            };

            $scope.onClose = function(bankDetails) {
                bankDetails.editMode = false;
            };
            $scope.onSubmit = function(index, bankDetails) {              
                var imageData = basisBankAccModel.getImageData();
                var imageLength = basisBankAccModel.getImageLength();
                console.log("imageLength",imageLength);                
                var queryObject = {};
                queryObject.bankName = $scope.selectedBankName[index].title;
                queryObject.bankAccNo = $scope.currentBankAcc[index].value;
                queryObject.cfrBankAcc = $scope.cfrBankAcc[index].value;
                queryObject.ifscCode = $scope.currentIfscNumber;
                queryObject.imageUploaded = imageData;
                if(queryObject.bankAccNo != '' && queryObject.bankAccNo.length !=0){
                    var regexPattern = new RegExp(/^\d+$/);
                    if(regexPattern.test(queryObject.bankAccNo)){
                        $scope.currentBankAcc[index].class = "";
                        $scope.currentBankAcc[index].errorMessage = "";
                    }else{
                        $scope.currentBankAcc[index].class = "errBrd";
                        $scope.currentBankAcc[index].errorMessage = "ERROR_LABEL";
                    }
                }
                if(queryObject.bankAccNo != queryObject.cfrBankAcc) {
                    $scope.cfrBankAcc[index].class = "errBrd";
                    $scope.cfrBankAcc[index].errorMessage = "ERROR_LABEL";
                }                
                else {
                    if(imageLength > 2097152) {
                        $scope.imageError = true;
                    }else{
                        $scope.imageError = false;
                        $scope.cfrBankAcc[index].class = "";
                        $scope.cfrBankAcc[index].errorMessage = "";                    
                        console.log("queryObject",queryObject);                    
                        basisBankAccInitialLoader.editBankDetails($scope,queryObject);
                        bankDetails.editMode = false;
                    }
                }                
                $scope.$on('basisbankdetailsupdated',function($event){
                    toaster.success("Your bank details has been successfully changed");
                });
            }            

        },
        link: function(scope, element, attr) {

        }

    };
};

basisBankAccountDetails.$inject = ['investorEventConstants', 'basisBankAccInitialLoader', 'basisBankAccModel', 'basisBankListModel', 'investorEvents', 'investorConstants', 'eventConstants', 'toaster', 'fticLoggerMessage', 'loggerConstants'];
module.exports = basisBankAccountDetails;