define(['app/common/models/InterAppContext'], function (InterAppContext) {

	return {
		context: new InterAppContext()
	}

});