'use strict';

var savedSmartSolutionsInitialLoaderService = function(savedSmartSolutionsModel, investorEvents,toaster,investorEventConstants) {
    var savedSmartSolInitialLoader = {
        _isServicesData: false,
        loadAllServices: function(scope) {


            function savedSmartSolutionsSuccess(data) {
                savedSmartSolutionsModel.setSavedSmartSolDtls(data);
                investorEvents.smartSolutions.publishSavedSmartSol(scope, savedSmartSolutionsModel.getSavedSmartSolDtls());
                //investorEvents.accountSettings.getEmandateDetails(scope);
            }

            function handleFailure(error) {
                console.error('handleFailure');
                toaster.error(error.data[0].errorDescription);
                savedSmartSolInitialLoader._isServicesData = false;
            }
            savedSmartSolutionsModel.fetchSavedSmartSol()
                .then(savedSmartSolutionsSuccess, handleFailure);

        }

    };
    return savedSmartSolInitialLoader;
};

savedSmartSolutionsInitialLoaderService.$inject = ['savedSmartSolutionsModel', 'investorEvents','toaster','investorEventConstants'];

module.exports = savedSmartSolutionsInitialLoaderService;
