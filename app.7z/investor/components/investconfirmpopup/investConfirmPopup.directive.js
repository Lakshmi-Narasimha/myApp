'use strict';

var InvestConfirmPopup = function() {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            mainHeader: '@?',
            popUpBody: '=',
            btnYes: '@?',
            btnNo: '@?',
            yesEventName: '@?',
            noEventName: '@?',
            extraBtn: '@?',
            extraEventName: '@?'
        },
        controller: function($scope, $uibModal) {
            $scope.animationsEnabled = true;
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                template: require('./investConfirmPopup.html'),
                backdrop: 'static',
                keyboard: false,
                windowClass: 'ftic-confirm-popup',
                scope: $scope,
                controller: function($scope, $uibModalInstance) {
                    $scope.popUpHeader1 = angular.isUndefined($scope.popUpHeader) ? 'You might lose some/all data entered/chosen till now' : $scope.popUpHeader;
                    $scope.btnNo1 = angular.isUndefined($scope.btnNo) ? 'No' : $scope.btnNo;
                    $scope.btnYes1 = angular.isUndefined($scope.btnYes) ? 'Yes' : $scope.btnYes;
                    $scope.mainHeader1 = angular.isUndefined($scope.mainHeader) ? 'Are you sure you want to change your selection?' : $scope.mainHeader;
                    $scope.popUpBody = $scope.popUpBody;
                    $scope.amountObject = {
                        key: 'Other Amount',
                        text: 'Other Amount &#8377;',
                        value: '',
                        type: 'number'
                    };
                    $scope.radios = { 'selectedVal': 'default' };
                    $scope.errors = {};
                    $scope.amountObject.disable = true;


                    $scope.listenChange = function() {
                        if ($scope.radios.selectedVal === 'other') {
                            $scope.amountObject.disable = false;
                        } else {
                            $scope.amountObject.value = '';
                            $scope.amountObject.disable = true;
                        }
                        $scope.errors = {};
                    };

                    $scope.yes = function() {
                        $scope.errors = {};
                        if ($scope.radios.selectedVal === 'other') {
                            if (!$scope.amountObject.value) {
                                $scope.errors.amount = 'Please enter Purchase Amount to proceed further.';
                            } else if ($scope.amountObject.value && ($scope.amountObject.value <= $scope.popUpBody.radioButtons[1].minAmount)) {
                                $scope.errors.amount = 'The Amount entered should be equal to or greater than the Minimum Investment Amount for the Fund.';
                            } else if ($scope.amountObject.value.toString().indexOf('.') > -1) {
                                $scope.errors.amount = 'Purchase Amount should not contain decimals.';
                            }
                        }
                        if (angular.equals($scope.errors, {})) {
                            $scope.$emit($scope.yesEventName || 'yes');
                            $uibModalInstance.close();
                        }
                    };

                    $scope.no = function() {
                        $scope.$emit($scope.noEventName || 'no');
                        $uibModalInstance.close();
                    };

                    $scope.extraBtn1 = function() {
                        $scope.$emit($scope.extraEventName);
                        $uibModalInstance.close();
                    };
                }
            });
        }
    };
};

InvestConfirmPopup.$inject = [];
module.exports = InvestConfirmPopup;
