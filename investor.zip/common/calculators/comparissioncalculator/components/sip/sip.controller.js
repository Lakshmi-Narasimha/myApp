
function siptabController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, comparisonCalculatorInitialService, comparisonCalculatorModel,calculatorsEventConstants) {


  $scope.init();

  $scope.selectOptions = {
    "Fund" : [],
    "Frequency" : []
  };

  
  $scope.$on(calculatorsEventConstants.COMPARISON_FUND_DETAILS, function(event, data){
    console.log("fundDetailsComparison", comparisonCalculatorModel.getFundDetails());
    if($scope.radios.selectedVal == $state.current.parent +".sip") {
      $scope.selectOptions.Fund.push({"title":"Select Fund", "category" : ""});  
      var fundlist = comparisonCalculatorModel.getFundDetails().codeValueList;
      for(var fd=0, len=fundlist.length;fd<len;fd++) {
        $scope.selectOptions.Fund.push({
          "title" : fundlist[fd].value,
          "category" :  fundlist[fd].code
        })    
      }
    }
    console.log($scope.selectOptions);
  });
  $scope.selectOptions.Frequency = [
  {
    title: "Select Frequency"
  },
  {
    title:"Monthly"   
  },
  {
    title: "Quarterly"
  }
  ]; 

  $scope.selectedType = "fundType";

  $scope.inputObject = {
   Fund :{
     required:true,
     name : "fundSelection",
     label: "Select Fund"
   },
   Frequency :{
     required:true,
     name : "freqSelection",
     label: "Select Frequency"
   }
 };


 $scope.userInput= { 
   Amount: {
    key: "", 
    text: "Investment Amount",
    value: "",
    pattern:/^[0-9]*$/,
    message: "",
    isMasked: false,
    isRequired: true,
    type: "number"
  },
  Tenure : {
    key: "", 
    text: "Investment Tenure",
    value: "",
    pattern:/^[0-9]*$/,
    message: "",
    isMasked: false,
    isRequired: true ,
    type: "number"	              
  },
  Annual : {
   key: "", 
   text: "Enter Annualized Returns",
   value: "",
   pattern:/^[0-9]*$/,
   message: "",
   isMasked: false,
   isRequired: false,
   maxlength: 6,
   disable:true,
   type: "number"
 }
};

$scope.reload = true;
$scope.listenChange = function() {
  $scope.TypeSelected = $scope.selectedType;
  if($scope.selectedType === "fundType")
  {
    $scope.userInput.Annual.disable = true;
    $scope.userInput.Annual.isRequired = false;
    $scope.inputObject.Fund.disable = false;
    $scope.inputObject.Fund.required = true;
    $scope.userInput.Annual.value = "";
    $scope.reload = true;
  }
  else
  {
    $scope.userInput.Annual.disable = false;
    $scope.userInput.Annual.isRequired = true;
    $scope.inputObject.Fund.disable = true;
    $scope.inputObject.Fund.required = false;
    $scope.fundType.fundCode ="";
    $scope.reload = false;
    $timeout(function () {
      $scope.reload = true;
    },0);
  } 
}

$scope.formInvalid = true;
$scope.calculatorReq=[];
$scope.fundType = [];
$scope.fundType.fundCode ="";
$timeout(function () {
  $scope.$on('selectedFund', function(event, data){                 
   $scope.fundType.fundName = data.title;
   $scope.fundType.fundCode = data.category;
 });
},0);
$scope.$on('selectedFrequency', function(event, data){   
 $scope.fundType.frequency = data.title; 
});

$scope.resetForm = function () {
  $scope.selectedType = null;
  $scope.$broadcast(calculatorsEventConstants.COMPARISON_RESET_DATA);
  $timeout(function () {
    $scope.selectedType= "fundType";
    $scope.userInput.Tenure.value = "";
    $scope.userInput.Amount.value = "";
    $scope.fundType.fundCode = "";
    $scope.userInput.Annual.value = "";
    $scope.inputObject.Fund.disable = false;
    $scope.inputObject.Fund.required = true;
    $scope.userInput.Annual.disable = true;
    $scope.userInput.Annual.isRequired = false;
    $scope.calculatorReq = {};
  }, 0)
};
$scope.onSubmit = function() {
   $scope.$broadcast(calculatorsEventConstants.COMPARISON_RESET_DATA);
  if($scope.userInput.Amount.value < 500 || $scope.userInput.Amount.value > 999999 || $scope.userInput.Tenure.value > 40 ||
    $scope.userInput.Tenure.value < 1 || (($scope.userInput.Annual.value >99 || $scope.userInput.Annual.value < 1) && ($scope.userInput.Annual.isRequired))) {
    return;
}
else {

  $scope.calculatorReq = 
  [{
    "investmentTenure": $scope.userInput.Tenure.value,
    "annualizedReturn" : $scope.userInput.Annual.value,
    "investmentAmount" : $scope.userInput.Amount.value,
    "fundName" : $scope.fundType.fundCode,
    "frequency" : $scope.fundType.frequency,
    "trxnType" : "SIP"
  }];
 
  $scope.$emit(calculatorsEventConstants.COMPARISON_FUND_SUBMIT, $scope.calculatorReq);
}
};


}

siptabController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'comparisonCalculatorInitialService', 'comparisonCalculatorModel','calculatorsEventConstants'];
module.exports = siptabController;