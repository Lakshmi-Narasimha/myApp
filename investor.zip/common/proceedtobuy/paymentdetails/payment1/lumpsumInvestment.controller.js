/**
 * @ngdoc property
 * @name payment 1 Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details Lumpsum controller for Advisor module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function payment1Ctrl($scope, buildPlanModelService, keyValueGridConfig, TransactConstant, transactModel, $timeout, planSmartSolution, fundDetails) {


    $scope.isNewInvestor = transactModel.isNewInvestor;    
    $scope.lumpsumFundDetails = planSmartSolution.getLumpsumFunds();

    $scope.lumpsumColumnDefs = [
        { field: 'fundName', displayName: 'Invest Into', width:"250", enableSorting:false, pinnedLeft:true},
        { field: 'amount', displayName: 'Buy Amount', width:"255", enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right', headerCellClass: 'text-right'},
        { field: 'dividend', displayName: 'Dividend Option', width:"300", enableSorting:false}

    ];
    var flag = false;
    $scope.accordionClicked = function () {
        
        transactModel.setTransactType(TransactConstant.buy.BUY);

        $scope.showComp = true;

        if(!flag) {
            $timeout(function () {
                $scope.$broadcast("Go_To_Payment_Dtls");
            }, 0);
            flag = true;
        }

        $timeout(function () {
            $scope.$broadcast("hideContinue", {accordion: "lumpsum"})
        }, 0);

        console.log("planSmartSolution.getLumpsumFunds()",planSmartSolution.getLumpsumFunds())

        fundDetails.removeFundDetails();
        
        angular.forEach(planSmartSolution.getLumpsumFunds(),function(obj,ind){           
            fundDetails.setFundDetails(obj);
        })        

        transactModel.setLumpsumFundDtls(fundDetails.getFundDetails());

    }
}
payment1Ctrl.$inject = ['$scope', 'buildPlanModelService', 'keyValueGridConfig', 'TransactConstant', 'transactModel', '$timeout', 'planSmartSolution', 'fundDetails'];
module.exports = payment1Ctrl;