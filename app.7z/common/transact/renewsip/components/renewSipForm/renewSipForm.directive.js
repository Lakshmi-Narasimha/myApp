/**
* @ngdoc property
* @name fticRenewSipForm Directive
* @requires TransactConstant
* @requires TransactConstant
* @requires $filter
* @requires transactEventConstants
* @requires frequencyOptionsModel
* @requires loggerConstants
* @requires transactEvents
* @requires fticLoggerMessage
* @requires frequencyOptionsInitalLoader
* @requires $timeout
* @requires sipDetailsModel
* @requires transactModel
* @requires fundDetails
* @requires $uibModal
* @requires $stateParams
* @description
*
* - It handles all the functionality and validations related to the form present in the Renew SIP form. And stores the data in a TransactModel, sipDetailsModel and fundDetails model.
*
**/
'use strict';

var fticRenewSipForm = function (TransactConstant, $filter, transactEventConstants, frequencyOptionsModel, loggerConstants, transactEvents, fticLoggerMessage, frequencyOptionsInitalLoader, $timeout, sipDetailsModel, transactModel, fundDetails, $uibModal, $stateParams, $state, bankDtlsModel, fundDetailsModel, configUrlModel, appConfig, $window, toaster) {
    return {
        template: require('./renewSipForm.html'), 
        restrict: 'E',
        scope: {
            kycState : '=?'
        },
        controller: ['$scope', function($scope){
            

            $scope.sipConfigObj = {};
            $scope.sipDetails = {};

             //Variable assignments and default settings
            $scope.isPaperLess = transactModel.isPaperless;
            var translateFilter = $filter('translate'),
                futureYear, 
                futureMonth, 
                futuredate, 
                futureInstallmentDate,
                datefilter = $filter('date');
            $scope.transactionLimit = 0;
            $scope.master = {};
            $scope.showFundsTile = false;
            $scope.showRenewSipNotification = false;
            $scope.isEditTile = false;
            $scope.editIndex = null;
            $scope.untilCancelledInfo = translateFilter(TransactConstant.sip.UNTIL_CANCELLED_INFO);
              //Datepicker options
            $scope.dateOptions = {
                yearRows: 3,
                yearColumns: 4,
                datepickerMode: 'month',
                minMode: 'month',
                fulldatepickerMode: 'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                maxDate: $scope.oneYearFromToday,
                minDate: $scope.thirtyDaysFromToday,
                monthColumns: 4,
                showWeeks: false
            };

            //Datepicker options
            $scope.endDateOptions = {
                yearRows: 3,
                yearColumns: 4,
                datepickerMode: 'month',
                minMode: 'month',
                fulldatepickerMode: 'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                minDate: new Date(),
                monthColumns: 4,
                showWeeks: false
            };

            //UserInputFld Options
            $scope.sipAmtInputObject = {
                key : 'sipAmount',
                text : translateFilter(TransactConstant.common.AMT) +' <span class=\'icon-fti_rupee\'></span>',
                value : '',
                name : 'sipAmount',
                type : 'number',
                min : '',
                message : '',
                isRequired : true,
                pattern : /^[0-9]*$/
            };

            //Dividend radio buttons options
            $scope.dividendOptions = [
                {
                    label: translateFilter(TransactConstant.common.DIVIDEND_RE_INVESTMENT),
                    value: 'Re-Investment',
                    selected: true,
                    disable: false
                },
                {
                    label: translateFilter(TransactConstant.common.DIVIDEND_PAYOUT), 
                    value: 'Payout',
                    selected: true,
                    disable: false
                }
            ];

            //SIP End date radio buttons options
            $scope.sipEndDateOptions = [
                {
                    label: translateFilter(TransactConstant.common.UNTIL_CANCELLED),
                    type: 'untilCancelled',
                    value: 'Until Cancelled',
                    selected: true
                },
                {
                    label: '', 
                    type: 'endDate',
                    value: 'End Date',
                    selected: false
                }
            ];

             //For Transaction limit validation, if user is KYC-reg through Aadhar            
            $scope.$on('checkKycMode', function() {
                $scope.isKycRegAadhar = transactModel.getKYCMode();
                // Fetch transaction limit from service
                setRequestObject();
            });

            //On SIPForm load
            function checkKycModeOnLoad() {
                $scope.isKycRegAadhar = transactModel.getKYCMode();
                $scope.onFundLoad = true;
                setRequestObject();
            }

            var loadPreviousSipData = function() {

                var _prevData = sipDetailsModel.getSipDetails() ? sipDetailsModel.getSipDetails(): [];
                if(_prevData[0]) {
                    $scope.sipAmtInputObject.value = _prevData[0].sipAmount ? _prevData[0].sipAmount : '';
                    $scope.sipDetails.firstInstallment = _prevData[0].firstInstallment;
                    $scope.sipConfigObj.defaultDaySelected = _prevData[0].futureInstallmentDay;
                    $scope.futureInstallmentMonth = _prevData[0].futureInstallment;
                }
                
            }
            //checkKycModeOnLoad();
            $scope.$on('sipdetailsview123',function(){
                $scope.destinationFund = transactModel.getFundDetails();//$scope.selectedFund
                $scope.sipEndDate = $scope.destinationFund.sipEndDate;
                $scope.referenceNo = $scope.destinationFund && $scope.destinationFund.referenceNo;
                $scope.arr = $scope.sipEndDate.split("/");
                $scope.arr1 = [parseInt($scope.arr[2]), parseInt($scope.arr[1]), parseInt($scope.arr[0])]
                $scope.sipDate = new Date($scope.arr1);
                $scope.sipDate = new Date($scope.sipDate);
                if($scope.destinationFund.sipStatusCode == "N" && $scope.sipDate <= $scope.threeMonthsFromToday){
                    var endDateMonth = $scope.sipDate.getMonth();
                    var endDateYear = $scope.sipDate.getFullYear();
                    var endDateDay = $scope.sipDate.getDate();

                    $scope.firstInstallment = new Date(endDateYear, endDateMonth, endDateDay + 30);
                    $scope.firstInstallment = new Date($scope.firstInstallment.toDateString());
                    $scope.firstInstallmentDate = datefilter($scope.firstInstallment, 'dd/MM/yyyy'); 
                    $scope.sipDetails.firstInstallment = $scope.firstInstallmentDate;
                }else{
                    $scope.sipDetails.firstInstallment = "Current Business Day";
                }
                //If the SIP tenure is less than 2 years then the step up option must be disabled.
                $scope.sipStartDate = $scope.destinationFund.sipStartDate;
                $scope.arr = $scope.sipStartDate.split('/');
                $scope.arr1 = [parseInt($scope.arr[2]), parseInt($scope.arr[1]), parseInt($scope.arr[0])];
                $scope.sipStartDate = new Date($scope.arr1);
                $scope.timeDiff = Math.abs($scope.sipDate - $scope.sipStartDate);
                $scope.daysDiff = Math.ceil($scope.timeDiff / (1000 * 3600 * 24));
                $scope.yearsDiff = Math.round($scope.daysDiff/365);
                if($scope.yearsDiff < 2){
                    $scope.sipDetails.disableStepUp = true;
                }

                 //setting Dividend options based on the Fund selected.
                //$timeout(function(){
                    $scope.dividendOptions[0].disable = false;
                    $scope.dividendOptions[1].disable = false;
                    $scope.sipConfigObj.showDividendOptions = true;
                    $scope.sipDetails.dividend = '';
                    if($scope.destinationFund){
                        $scope.sipAmtInputObject.min = parseInt($scope.destinationFund.minSipAmount);
                        $scope.sipAmtInputObject.message = translateFilter(TransactConstant.common.MINIMUM) + ' <span class=\'icon-fti_rupee\'></span>' + $scope.destinationFund.minSipAmount;
                        if($scope.destinationFund.payoutFlag === 'Y' && $scope.destinationFund.reinvestFlag === 'Y'){
                            if($scope.destinationFund.dividendFlag === 'P'){
                                $scope.sipDetails.dividend = 'Payout';
                            }else if($scope.destinationFund.dividendFlag === 'R'){
                                $scope.sipDetails.dividend = 'Re-Investment';
                            }
                        }else if($scope.destinationFund.payoutFlag === 'N' && $scope.destinationFund.reinvestFlag === 'N'){
                            $scope.sipDetails.dividend = 'NA';
                            $scope.sipConfigObj.showDividendOptions = false;
                        }else if($scope.destinationFund.payoutFlag === 'N' && $scope.destinationFund.reinvestFlag === 'Y'){
                            $scope.sipDetails.dividend = 'Re-Investment';
                            $scope.dividendOptions[1].disable = true;
                        }else{
                            $scope.sipDetails.dividend = 'Payout';
                            $scope.dividendOptions[0].disable = true;
                        }
                    }                     
                //},100);
                checkKycModeOnLoad();
                $scope.sipDetails.futureInstallmentMonth = new Date();
                $scope.dateOptions = {
                    yearRows: 3,
                    yearColumns: 4,
                    datepickerMode: 'month',
                    minMode: 'month',
                    fulldatepickerMode: 'year',
                    formatMonth: 'MMM',
                    formatYear: 'yyyy',
                    formatDayTitle: 'MMM yyyy',
                    maxDate: $scope.oneYearFromToday,
                    minDate: $scope.thirtyDaysFromToday,
                    monthColumns: 4,
                    showWeeks: false
                };
                // Assigning the selected Fund of Select A Sip to destinationFund variable.
                //loadPreviousSipData();
            });
           
            //Assigning sipAmount to sipDetails object, if amount changes
            $scope.sipAmountChanged = function(sipAmount){
                $scope.sipDetails.sipAmount = sipAmount;
                $scope.sipConfigObj.invalidSixInstallments = false;
            };

            
            

            
            // data setting for the Popup
            $scope.renewPopUpHeader= translateFilter(TransactConstant.guest.EXISTING_ONLINE_SIP);
            $scope.renewPopUpText= 'Please continue with your existing Reference No.' + $scope.referenceNo + ' to make payments';
            $scope.renewbtnNo= translateFilter(TransactConstant.guest.RENEWSIP_CANCEL);
            $scope.renewbtnYes= translateFilter(TransactConstant.guest.RENEWSIP_CONTINUE);

            $scope.showSipForm = true;
            $scope.sipDetails = {};
            $scope.sipDetails.disableStepUp = false;

            $scope.disableEndDate = true;
            $scope.isKycRegAadhar = false;
           // $scope.showKycDtlsNotif = false;
           // $scope.showNotification = false;
            $scope.isInvalidFutureDate = true;
            $scope.isFutureDateWithinRange = true;
            //Setting default values for sipDetails object 
            var defaultDetails = angular.copy(sipDetailsModel.getDefaultSipDetails());
            $scope.sipDetails = defaultDetails;

            //Date variables setting - Needed to enable step up option and to validate no.of installments
            $scope.startDate = new Date();
            var startDateMonth = $scope.startDate.getMonth();
            var startDateYear = $scope.startDate.getFullYear();
            var startDateDay = $scope.startDate.getDate();

            $scope.twoYearsFromToday = new Date(startDateYear + 2, startDateMonth);
            $scope.twoYearsFromToday = new Date($scope.twoYearsFromToday.toDateString());

            $scope.threeMonthsFromToday = new Date(startDateYear, startDateMonth + 3, startDateDay);
            $scope.threeMonthsFromToday = new Date($scope.threeMonthsFromToday.toDateString());

            $scope.sixMonthsFromToday = new Date(startDateYear, startDateMonth + 6);
            $scope.sixMonthsFromToday = new Date($scope.sixMonthsFromToday.toDateString());

            $scope.eighteenMonthsFromToday = new Date(startDateYear, startDateMonth + 18);
            $scope.eighteenMonthsFromToday = new Date($scope.eighteenMonthsFromToday.toDateString());

            $scope.oneYearFromToday = new Date(startDateYear + 1, startDateMonth);
            $scope.oneYearFromToday = new Date($scope.oneYearFromToday.toDateString());

            $scope.threeYearsFromToday = new Date(startDateYear + 3, startDateMonth);
            $scope.threeYearsFromToday = new Date($scope.threeYearsFromToday.toDateString());

            $scope.sixYearsFromToday = new Date(startDateYear + 6, startDateMonth);
            $scope.sixYearsFromToday = new Date($scope.sixYearsFromToday.toDateString());

            $scope.twelveYearsFromToday = new Date(startDateYear + 12, startDateMonth);
            $scope.twelveYearsFromToday = new Date($scope.twelveYearsFromToday.toDateString());

            $scope.thirtyDaysFromToday = new Date(startDateYear, startDateMonth, startDateDay + 30);
            $scope.thirtyDaysFromToday = new Date($scope.thirtyDaysFromToday.toDateString());

          

            
            /*Service Integration For InvestmentAmount - Starts*/
            var requestObject = {},returnedObj = {};
            requestObject.bodyObj = {};
            requestObject.bodyObj.fundOptions = [];

            function setRequestObject() {
                requestObject = {};
                requestObject.bodyObj = {};
                requestObject.bodyObj.fundOptions = [];
                returnedObj = fundDetailsModel.setCommonInvProperties();
                requestObject.bodyObj.folioId = returnedObj.folioId;
                requestObject.bodyObj.panNo = returnedObj.panNo;
                requestObject.bodyObj.webRefNo = returnedObj.webRefNo;

                if(fundDetails.getFundDetails()){
                    setFundOptions(fundDetails.getFundDetails());
                } else {
                    requestObject.bodyObj.fundOptions = [];
                }
                //Calling service with requestObject
                if (requestObject.bodyObj.panNo && requestObject.bodyObj.folioId) {
                    fundDetails.fetchRvalidateInvFYLimit(requestObject).then(transactionLimitSuccess, transactionLimitFailure);
                }
            }
            function setFundOptions(fundDetailsArray) {
                angular.forEach(fundDetailsArray, function(value) {
                    var fundObj = {};
                    fundObj.amount = value.amount ? value.amount.toString() : '' || value.sipAmount ? value.sipAmount.toString() : '';
                    fundObj.txnType = 'SIP';
                    fundObj.startDate = datefilter(new Date(), 'dd/MM/yyyy');
                    fundObj.endDate = value.endDate === 'Until Cancelled' ? '' : value.endDate;
                    fundObj.frequency = value.frequency === TransactConstant.transact.MNTHLY ? 'M' :(value.frequency === TransactConstant.transact.FREQ_ANNUALLY ? 'A' : (value.frequency === TransactConstant.transact.QUATERLY ? 'Q' : ''));
                    requestObject.bodyObj.fundOptions.push(fundObj);
                });
            }
            function transactionLimitSuccess(data) {
                //$scope.showNotification = false;
                //$scope.showKycDtlsNotif = false;
                if(!$scope.transactionLimit){
                    // alert("in transactionLimitSuccess");
                    // console.log(data);
                    // debugger;
                    transactModel.setKycTransactionLimit(data.allowableTxnAmount);
                    $scope.transactionLimit = transactModel.getKycTransactionLimit();
                }

                // if (!$scope.onFundLoad) {
                //     if (data.statusFlag === TransactConstant.transact.INVESTMENT_REJECTED_CODE) {
                //         $scope.showNotification = true;
                //     } else if (data.statusFlag === TransactConstant.transact.INVESTMENT_WARNING_CODE) {
                //         //$scope.showKycDtlsNotif = true;
                //     } else {
                //         //$scope.$emit(transactEventConstants.transact.Show_Fund);
                //         $scope.$emit("paymntDtls");
                //     }
                // }
            }

            function transactionLimitFailure(data) {
                toaster.error(data.data[0].errorDescription);
            }
            /*Service Integration For InvestmentAmount - Ends*/

           

            /*If user comes from Review edit, reseting select fund - START */

            // data setting for the allowable transaction limit popup
            $scope.popUpHeader= $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_LIMIT);
            $scope.popUpText= $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_Desc);
            $scope.btnNo= $filter('translate')(TransactConstant.buy.CANCEL_BUTTON);
            //$scope.btnYes= $filter('translate')(TransactConstant.buy.DOWNLOAD_KYC_FORM);
            $scope.noEventName = 'FundLimitCancel';

            // KYC Additional Details Notification popup        
            // $scope.kycDtlsText= $filter('translate')(TransactConstant.common.KYC_ADDITIONAL_DETAILS);
            // $scope.kycDtlsBtnNo= $filter('translate')(TransactConstant.common.CANCEL);
            // $scope.kycDtlsBtnYes= $filter('translate')(TransactConstant.common.CONTINUE);
            // $scope.kycDtlsNoEventName = 'kycDetailsCancel';

            // var configURL = configUrlModel.getEnvUrl('MARKETING_URL'),
            //     transactNowUrl = appConfig[configURL] + '/#tab_tab2',
            //     pdfUrl = appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL;
            // $scope.$on('downloadKyc', function () {    
            //     $scope.showNotification = false;
            //     $window.open(pdfUrl, '_blank');
            //     location.href = transactNowUrl;  
            // }); 

            $scope.$on('FundLimitCancel', function(){
                 $scope.showNotification = false;        
            });

            // $scope.$on('showKycDtlsForm', function() {
            //     $scope.showKycDtlsNotif = false;
            //     $state.go($scope.kycState);             
            // });

            // $scope.$on('kycDetailsCancel', function() {
            //     $scope.showKycDtlsNotif = false;
            // });

            //If user comes from Review edit, reseting select fund
            if($stateParams.key === TransactConstant.transact.Fund_Key || $stateParams.key === TransactConstant.transact.Payment_Key){
                //debugger
                //$scope.showSipForm = false;
            }

            //If user selects "Download E-KYC" in notification popup
            // $scope.$on('yes', function () {
            //     transactModel.downloadKycForm();
            //fticStateChange.stateChange($state, 'transactnow.baseNow.renewSip');
            //     $state.go("transactnow.baseNow.renewSip");
            // });

            // renewSip popup if the Funds SIP Status is ‘Active, and going to expire in the next 3 months’ and if the current payment mode is via ‘Billpay’
            $scope.$on('renewSipPopup_Yes', function () {
                bankDtlsModel.setSelectedBank($scope.destinationFund.bankDetails);
                if($scope.destinationFund.paymentMode === TransactConstant.common.EMANDATE_CODE) {
                    $scope.paymentMode = 'Billpay';
                }else {
                    $scope.paymentMode = 'NA';
                }
                bankDtlsModel.setPaymentMethod($scope.paymentMode);
                bankDtlsModel.setTotalAmount($scope.destinationFund.amount);
                //fticStateChange.stateChange($state, 'transactnow.reviewNow.renewSip');
                //$state.go("transactnow.reviewNow.renewSip");
            });

               

            // SIP First Installment’ date field defaulted to current business day for all SIP Status except for SIP Status is ‘Active, and going to expire in the next 3 months’ where default date should be current SIP End date + 30 days 
            
            


            






            

            //Future Installment Day option settings for section filter
            $scope.sipDetails.futureInstallmentMonth = new Date();
            $scope.days = [];
            var maxDayInMonth;

            $scope.futureInstDayInputObject = {
                label : translateFilter(TransactConstant.sip.DAY),
                name : 'futureInstDay',
                required : true
            };

            function futureDays(date) {
                $scope.days = [];
                maxDayInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
                for (var i = 1; i <= maxDayInMonth; i++) {
                    $scope.days.push(i);
                }
                $scope.futureInstDayOptions = $scope.days.map(function(e) {
                    return {
                        title: e
                    };
                });
                if ($scope.futureInstDayOptions) {
                    $scope.sipConfigObj.defaultDaySelected = $scope.futureInstDayOptions[0];
                }
            }
            futureDays(new Date());

            $scope.futureInstallmentDateChange = function(selectedFutureDate) {
                $scope.isInvalidFutureDate = true;
                $scope.isFutureDateWithinRange = true;
                futureDays(selectedFutureDate);
            };

            //Assigning futureInstallmentDay to sipDetails object, if day changes
            $scope.$on('FutureInstallmentDayChange', function(event, selectedValue){
                $scope.isInvalidFutureDate = true;
                $scope.isFutureDateWithinRange = true;
                $scope.sipDetails.futureInstallmentDay = selectedValue.title;
                

            });

            //Function to find the given "value" in a given object array
            $scope.findItemInFilter = function(objArr, value){
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                    return x.title === value;
                }))[0];
                return obj;
            };

            $scope.frequencyOptions = [
                {
                    title:'Monthly'
                }, {
                    title:'Quaterly'
                }, {
                    title:'Annually'
                }
            ];

            $scope.sipConfigObj.defaultFrequencySelected = $scope.findItemInFilter($scope.frequencyOptions, 'Monthly');

            //Destroying frequency serviceHandler
            // function destroyServiceHandler() {
            //     serviceEventHandler();
            // }
            $scope.frequencyInputOptions = {
                required : true,
                name : 'frequency'
            };

            //Assigning frequency to sipDetails object, if frequency changes
            $scope.$on('transactFrequency', function(event, selectedValue){
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipConfigObj.invalidTwelveInstallments = false;
                $scope.sipDetails.frequency = selectedValue.title;
            });

            //Handles End-date radio button change
            $scope.listenEndDateChange = function(type){
                $scope.disableEndDate = true;
                $scope.sipDetails.disableStepUp = false;
                $scope.sipDetails.sipDetailsEndDate = '';
                if(type === 'endDate'){
                    $scope.sipDetails.disableStepUp = true;
                    $scope.disableEndDate = false;
                }
            };
            
            //Enable/disable Step-up based on end-date entered
            
            $scope.sipEndDateChange = function(endDate) {
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipConfigObj.invalidTwelveInstallments = false;
                if ($scope.sipDetails.endDateOption == "End Date") {
                    $scope.sipDetails.disableStepUp = true;
                    if (endDate) {
                        $scope.finalDate = new Date(endDate.toDateString());
                        if ($scope.finalDate >= $scope.twoYearsFromToday) {
                            $scope.sipDetails.disableStepUp = false;
                        } else {
                            $scope.sipDetails.showStepUpSip = false;
                        }
                    }
                }
            };

            //Handles Continue Functionality
            $scope.continue = function() {
                // var isAboveLimit = false;
                // $scope.showKycDtlsNotif = false;

                // transactModel.setTransactType(TransactConstant.guest.RENEWSIP);

                // if($scope.isKycRegAadhar || transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
                //     $scope.onFundLoad = false;
                //     $scope.invocationPoint = 2;
                //     setRequestObject();
                // } else{
                //     $scope.$emit(transactEventConstants.transact.Show_Fund);
                //     $scope.$emit('paymntDtls');
                // }  

                transactModel.setTransactType(TransactConstant.renewSip.RENEWSIP);
                
                $scope.$emit('paymntDtls');
                $scope.$emit('paymntDtls123');

            }

            //Listened when Edit icon clicked in the Fund details grid
            $scope.$on(transactEventConstants.transact.Edit_Fund_Button_Clicked, function () {
                // transactModel.setTransactType(TransactConstant.sip.FUNDSIP);
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            });

            //Handles Save functionality on clicking "Save"
            var  sipDetailsObj = {};
            var formValid = false;
            //Handles Save functionality on clicking "Save"
            $scope.saveSipDetails = function() {
               
                $scope.noFundSelected = true;
                sipDetailsObj = {};
                $scope.isFundSelected = false;
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipConfigObj.invalidTwelveInstallments = false;
                $scope.sipConfigObj.isSixInstallments = false;
                $scope.sipConfigObj.isTwelveInstallments = false;
                $scope.isInvalidFutureDate = true;
                $scope.isFutureDateWithinRange = true;
                if (!$scope.sipDetails.showStepUpSip) {
                    $scope.sipDetails.setpUpOption = "";
                    $scope.sipDetails.increaseByPerc = "";
                    $scope.sipDetails.increaseByAmount = "";
                    $scope.sipDetails.stepUpSip = "NA";
                }

                //If sipForm valid and Invest into fund is selected
                if ($scope.sipForm.$valid && $scope.destinationFund) {
                    formValid = true;

                    //STEP-UP-SIP custom form validation, if step-up-sip is selected
                    if ($scope.sipDetails.showStepUpSip) {
                        formValid = false;
                        if ($scope.sipForm.validPerc && $scope.sipForm.validAmount) {
                            formValid = true;
                        }
                    }

                    /*
                        No.of installments validation based on the End-date entered
                        NO_OF_INSTALLMENTS_SIP_MIN : 500
                        NO_OF_INSTALLMENTS_SIP_MAX : 1000
                    */
                    
                    $scope.validateNoofInstallments = function(annualDate, quaterlyDate, monthlyDate, frequency) {
                        $scope.isInvalidInsatllment = false;
                        $scope.sipConfigObj.invalidSixInstallments = false;
                        $scope.sipConfigObj.invalidTwelveInstallments = false;
                        switch (frequency) {
                            case TransactConstant.transact.FREQ_ANNUALLY:
                                if ($scope.finalInstallmentDate < annualDate) {
                                    $scope.isInvalidInsatllment = true;
                                    // formValid = false;
                                }
                                break;
                            case TransactConstant.transact.QUATERLY:
                                if ($scope.finalInstallmentDate < quaterlyDate) {
                                    $scope.isInvalidInsatllment = true;
                                    // formValid = false;
                                }
                                break;
                            case TransactConstant.transact.MNTHLY:

                                if ($scope.finalInstallmentDate < monthlyDate) {
                                    $scope.isInvalidInsatllment = true;
                                    // formValid = false;
                                }
                                break;
                            default:
                        }
                        if ($scope.isInvalidInsatllment) {
                            if ($scope.sipConfigObj.isTwelveInstallments) {
                                $scope.sipConfigObj.invalidSixInstallments = false;
                                $scope.sipConfigObj.invalidTwelveInstallments = true;
                                formValid = false;
                            } else if ($scope.sipConfigObj.isSixInstallments) {
                                $scope.sipConfigObj.invalidSixInstallments = true;
                                $scope.sipConfigObj.invalidTwelveInstallments = false;
                                formValid = false;
                            }
                        }
                    };
                    
                    if ($scope.sipDetails.endDateOption == "End Date") {
                        $scope.finalInstallmentDate = new Date($scope.sipDetails.sipDetailsEndDate.toDateString());
                        var selectedFrequency = $scope.sipDetails.frequency;

                        if ($scope.sipDetails.sipAmount >= parseInt(TransactConstant.sip.NO_OF_INSTALLMENTS_SIP_MIN) && $scope.sipDetails.sipAmount < parseInt(TransactConstant.sip.NO_OF_INSTALLMENTS_SIP_MAX)) {
                            $scope.sipConfigObj.isTwelveInstallments = true;
                            $scope.validateNoofInstallments($scope.twelveYearsFromToday, $scope.threeYearsFromToday, $scope.oneYearFromToday, selectedFrequency);

                        } else if ($scope.sipDetails.sipAmount >= parseInt(TransactConstant.sip.NO_OF_INSTALLMENTS_SIP_MAX)) {
                            $scope.sipConfigObj.isSixInstallments = true;
                            $scope.validateNoofInstallments($scope.sixYearsFromToday, $scope.eighteenMonthsFromToday, $scope.sixMonthsFromToday, selectedFrequency);

                        }
                    }
                    

                    //Validating if the same fund is selected
                    if (!($scope.isEditTile && angular.equals(fundDetails.getFundArr()[$scope.editIndex], $scope.destinationFund))) {
                        var fundDetailsArrObj = fundDetails.getFundArr();
                        if (fundDetailsArrObj.length > 0) {
                            angular.forEach(fundDetailsArrObj, function(value, key) {
                                // if (angular.equals(fundDetailsArrObj[key], $scope.destinationFund) ) {
                                //     $scope.isFundSelected = true;
                                //     formValid = false;
                                // };
                            });
                        }
                    }
                    

                    /*Future installment Validation*/
                    futureInstallmentDate = $scope.sipDetails.futureInstallmentDay + ' ' + datefilter($scope.sipDetails.futureInstallmentMonth, 'MMM yyyy');
                    futureMonth = $scope.sipDetails.futureInstallmentMonth.getMonth();
                    futureYear = $scope.sipDetails.futureInstallmentMonth.getFullYear();
                    futuredate = new Date(futureYear, futureMonth, $scope.sipDetails.futureInstallmentDay);
                    if (futuredate < $scope.thirtyDaysFromToday || futuredate > $scope.oneYearDayFromToday) {
                        $scope.isFutureDateWithinRange = false;
                        formValid = false;
                    }

                }

                //Assigning sipDetails data to the models, if all the above validations are valid
             
                if (formValid) {
                    $scope.sipConfigObj.showTransactionAmtNotification = false;
                    $scope.sipConfigObj.showKycDtlsNotif = false;
                    fundDetails.removeFundDetails();
                    $scope.sipDetails.stepUpValue = '';
                    $scope.sipDetails.stepUpType = '';
                    $scope.sipDetails.fundName = $scope.destinationFund.fundOptionDesc;
                    $scope.sipDetails.sipStatusCode = $scope.destinationFund.sipStatusCode;
                    $scope.sipDetails.paymentMode = $scope.destinationFund.paymentMode;
                    $scope.sipDetails.fundOption = $scope.destinationFund.fundOption;
                    $scope.sipDetails.nfoFlag = $scope.destinationFund.nfoFlag;
                    $scope.sipDetails.accNo = $scope.destinationFund.accountNumber;
                    $scope.sipDetails.dividendFlag = $scope.destinationFund.dividendFlag;                    
                    $scope.sipDetails.startDate = datefilter(futuredate, 'dd/MM/yyyy');                    
                    $scope.sipDetails.futureInstallment = futureInstallmentDate;
                    if($scope.sipDetails.dividend === 'Payout'){
                        $scope.sipDetails.dividendFlag = 'P';
                    }else if($scope.sipDetails.dividend === 'Re-Investment'){
                        $scope.sipDetails.dividendFlag = 'R';
                    }

                    // $scope.sipDetails.startDate = datefilter($scope.startDate, 'dd/MM/yyyy');
                    if ($scope.destinationFund.fundType == 'E') {
                        $scope.sipDetails.accNo = $scope.destinationFund.accNo;
                    } else if ($scope.destinationFund.fundType == 'N') {
                        $scope.sipDetails.accNo = "NEW";
                    }

                    $scope.sipDetails.startDate = datefilter(futuredate, 'dd/MM/yyyy');
                    $scope.sipDetails.futureInstallment = futureInstallmentDate;
                    $scope.sipDetails.firstInstallment = "Current Business Day";

                    if ($scope.sipDetails.setpUpOption) {
                        if ($scope.sipDetails.setpUpOption == "other") {
                            $scope.sipDetails.stepUpSip = $scope.sipDetails.increaseByPerc + "%";
                            $scope.sipDetails.stepUpValue = $scope.sipDetails.increaseByPerc;
                            $scope.sipDetails.stepUpType = "P";
                        } else if ($scope.sipDetails.setpUpOption == "amount") {
                            $scope.sipDetails.stepUpSip = "Rs." + $scope.sipDetails.increaseByAmount;
                            $scope.sipDetails.stepUpValue = $scope.sipDetails.increaseByAmount;
                            $scope.sipDetails.stepUpType = "A";
                        } else {
                            $scope.sipDetails.stepUpSip = $scope.sipDetails.setpUpOption + "%";
                            $scope.sipDetails.stepUpValue = $scope.sipDetails.setpUpOption;
                            $scope.sipDetails.stepUpType = "P";
                        }

                        $scope.sipDetails.stepUpSip = $scope.sipDetails.stepUpSip + " " + TransactConstant.transact.FREQ_ANNUALLY;

                    } else {
                        $scope.sipDetails.stepUpSip = "NA";
                    };

                    if ($scope.sipDetails.endDateOption == "Until Cancelled") {
                        $scope.sipDetails.endDate = "Until Cancelled";
                        $scope.sipDetails.endDateMonthYear = "Until Cancelled";
                        $scope.sipDetails.perpetualFlag = "Y";
                    } else if ($scope.sipDetails.endDateOption == "End Date") {
                        $scope.sipDetails.perpetualFlag = "N";
                        $scope.sipDetails.endDate = datefilter($scope.sipDetails.sipDetailsEndDate, 'dd/MM/yyyy');
                        $scope.sipDetails.endDateMonthYear = datefilter($scope.sipDetails.sipDetailsEndDate, 'MMM yyyy');
                    };
                    
                    if ($scope.isEditTile) {
                        fundDetails.removeTile($scope.editIndex);
                        fundDetails.removeFundArr($scope.editIndex);
                        $scope.isEditTile = false;
                        $scope.editIndex = null;
                    }

                    //Transaction limit validation, if any of the user is kyc-red through aadhar
                    if ($scope.isKycRegAadhar) {
                        $scope.onFundLoad = false;
                        $scope.sipConfigObj.showTransactionAmtNotification = false;
                        $scope.invocationPoint = 1;
                        setRequestObject();
                    } else {
                        sipDetailsObj = angular.copy($scope.sipDetails);
                        fundDetails.setFundDetails(sipDetailsObj);
                        fundDetails.setFundArr($scope.destinationFund);
                        var sipDetailsArr = fundDetails.getFundDetails();
                        sipDetailsModel.setSipDetails(sipDetailsArr);
                        $scope.continue();
                    }
                }
                // if(!formValid){
                //     $scope.continue();
                // }
            }
            $scope.continue = function() {
                // var isAboveLimit = false;
                // $scope.showKycDtlsNotif = false;

                // transactModel.setTransactType(TransactConstant.guest.RENEWSIP);

                // if($scope.isKycRegAadhar || transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
                //     $scope.onFundLoad = false;
                //     $scope.invocationPoint = 2;
                //     setRequestObject();
                // } else{
                //     $scope.$emit(transactEventConstants.transact.Show_Fund);
                //     $scope.$emit('paymntDtls');
                // }  

                transactModel.setTransactType(TransactConstant.renewSip.RENEWSIP);
                
                $scope.$emit('paymntDtls');
                $scope.$emit('paymntDtls123');

            }
            function checkInvestmentAmount() {
                $scope.showKycDtlsNotif = false;
                var isAboveLimit = false;                  
                
                if(parseInt($scope.sipAmtInputObject.value) >= investAmtLimit) {
                    $scope.showKycDtlsNotif = true;
                    isAboveLimit = true;
                }
                return isAboveLimit;
            }

            function saveInvestmentDetails(){
                sipDetailsObj = angular.copy($scope.sipDetails);
                fundDetails.setFundDetails(sipDetailsObj);
                fundDetails.setFundArr($scope.destinationFund);
                var sipDetailsArr = fundDetails.getFundDetails();
                sipDetailsModel.setSipDetails(sipDetailsArr);
                transactModel.setFundDetails(sipDetailsArr);

                // if($state.current.url === '/renewsip') {
                //     transactModel.setTransactType(TransactConstant.renewSip.RENEWSIP);
                // }
                
                // $scope.showFundsTile = true;
                // $scope.showAddMoreBtn = true;
                // $scope.showContinueBtn = true;
                // $scope.showSipForm = false;
                // if (sipDetailsArr.length == parseInt($scope.fundLimit)) {
                //     $scope.showAddMoreBtn = false;
                // }
                // $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
                // $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            }
        }]
    };
};

fticRenewSipForm.$inject = ['TransactConstant', '$filter', 'transactEventConstants', 'frequencyOptionsModel', 'loggerConstants', 'transactEvents', 'fticLoggerMessage', 'frequencyOptionsInitalLoader', '$timeout', 'sipDetailsModel', 'transactModel', 'fundDetails', '$uibModal', '$stateParams', '$state', 'bankDtlsModel', 'fundDetailsModel', 'configUrlModel', 'appConfig', '$window', 'toaster'];
module.exports = fticRenewSipForm;