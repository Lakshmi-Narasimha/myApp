/**
* @ngdoc service
* @name bankDetailsModel
* @description
*
* - It will hit the restangular(network service) call and resolve the data to wrapper.
* Also works like model with setters and getters.
*
*/

'use strict';

var bankDetailsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _bankDetails = null,
        _preRegBanks = null,
        _paymentMethod = null,
        _futureInstPayMethod = null,
        _selectedBank = null,
        _futureInstBank = null,
        _bankName = null,
        _totalAmount = null,
        _amountType = null,
        _frequency = null,
        _period = null,
        _startDate = null,
        _endDate = null,
        _accountNo = null,
        _accountType = null,
        _ifscCode = null,
        _branchName = null,
        _branchAddress = null,        
        _paymentDetails = null,
        _isNewAccount = null,
        _isFundAmountError = null,
        _isFixedAmountError = null,
        _isMultiPayMode = null,        
        _isNewAccBankError = null,
        _isAutoBankError = null,
        _isSipFreqError = null,
        _bankAccNo = null,
        _isBuyEditable = null,
        _isMultiBankError = null,
        _neftDtls = null,
        _isModifySipEditable = null,
        _achRefNo = null,
        _paymentMode = null,
        _bankNme = null,
        _webref = null,
        _lumpsuPaymentDetails = null,
        _sipPaymentDetails = null,
        _lumpsumPaymentMethod = null,
        _sipPaymentMethod = null,
        _lumpsumTotalAmount = null,
        _sipTotalAmount = null,
        _isMultiPayModeLumsum = null,
        _isMultiPayModeSip = null,
        _lumpsumStartDate = null,
        _sipStartDate = null,
        _lumpsumEndDate = null,
        _nextPaymentMode = null,
        _sipEndDate = null,
        _neftDetails = {},
        _guestEdit = null,
        _distId = "",
        _emandateDetails = {},
        _isExhausted = null,
        _isAccTypeError = null,
        _newInvestor = null,
        _isNoBankError = null,
        _isInvalidAmtError = false,
        _paymentBankAccNo = null,        
        _selectdfolioId = null,
        _selectdfolioKey = null,
        _selectdfolioTitle = null,
        _setValidateParams = null,
        _paymentMethodError = false;
       
    var bankDetailsModel = {

        resetForm : function() {
            _bankDetails = null,
            _paymentMethod = null,
            _futureInstPayMethod = null,
            _selectedBank = null,
            _futureInstBank = null,
            _bankName = null,
            _totalAmount = null,
            _amountType = null,
            _frequency = null,
            _period = null,
            _startDate = null,
            _endDate = null,
            _accountNo = null,
            _accountType = null,
            _ifscCode = null,
            _branchName = null,
            _branchAddress = null;
        },
        
        //Existing Investor
        fetchBankDetails : function (params) {
            var deferred = $q.defer();
            Restangular.one('transact/paymentBanksByFolio').get(params).then(function (bankDetails) {
           //Restangular.all('/getBanks').getList().then(function (bankDetails) {
                deferred.resolve(bankDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        fetchNewInvBanks : function (params) {
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('transact/paymentBankList').get(params).then(function (preRegBanks) {
                deferred.resolve(preRegBanks);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
         postValidateBuyDtls : function (params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId};
            Restangular.one('transact/validateBuy').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postBuyDtls : function (params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId, "op" : "postBuy"};
            Restangular.one('transact/orders').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postGuestBuyDtls : function (params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId, "op" : "confirmBuy"};
            Restangular.one('transact/orders').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postValidateSip : function (params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId};
            Restangular.one('transact/validateSip').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

         postSysBuy : function (params) {
           var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId, "op" : "systematicBuy"};
            Restangular.one('transact/orders').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        //added for SIP
        postSipDtls : function (params) {
            console.log('postSipDtls method');
           var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId, "op" : "confirmSip"};
            Restangular.one('transact/orders').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        postCustBankDtls : function(params) { // /customerBank service
            var deferred = $q.defer(),
                preferences = {'guId': authenticationService.getUser().guId};

            Restangular.one('clients/customerBank').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
 //end       
        
        getBankDetails : function() {
            return _bankDetails;
        },

        setBankDetails : function(bankDetails) {
            _bankDetails = bankDetails;
        },

        getPaymentMethod : function() {
            return _paymentMethod;
        },

        setPaymentMethod : function(paymentMethod) {
            _paymentMethod = paymentMethod;
        },

        getFutureInstPayMethod : function() {
            return _futureInstPayMethod;
        },

        setFutureInstPayMethod : function(futureInstPayMethod) {
            _futureInstPayMethod = futureInstPayMethod;
        },

        getLumpsumPaymentMethod : function(){
            return _lumpsumPaymentMethod;
        },

        setLumpsumPaymentMethod: function(paymentMethod){
            _lumpsumPaymentMethod = paymentMethod;
        },

        getSipPaymentMethod : function(){
            return _sipPaymentMethod;
        },

        setSipPaymentMethod: function(paymentMethod){
            _sipPaymentMethod = paymentMethod;
        },

        getSelectedBank : function() {
            return _selectedBank;
        },

        setSelectedBank : function(selectedBank) {
            _selectedBank = selectedBank;
        },

        getFutureInstBank : function()   {
            return _futureInstBank;
        },

        setFutureInstBank : function(futureInstBank) {
            _futureInstBank = futureInstBank;
        },

        getBankName : function() {
            return _bankName;
        },

        setBankName : function(bankName) {
            _bankName = bankName;
        },

        getSelectedBankIndex : function() {
            return _selectedBankIndex;
        },

        setSelectedBankIndex : function(selectedBankIndex) {
            _selectedBankIndex = selectedBankIndex;
        },

        getTotalAmount : function() {
            return angular.copy(_totalAmount);
        },

        setTotalAmount : function(totalAmount) {
            _totalAmount = angular.copy(totalAmount);
        },

        getLumpsumTotalAmount : function() {
            return _lumpsumTotalAmount;
        },

        setLumpsumTotalAmount : function(totalAmount) {
            _lumpsumTotalAmount = totalAmount;
        },

        getSipTotalAmount : function() {
            return _sipTotalAmount;
        },

        setSipTotalAmount : function(totalAmount) {
            _sipTotalAmount = totalAmount;
        },

        getPreRegBanks : function() {
            return _preRegBanks;
        },

        setPreRegBanks : function(preRegBanks) {
            _preRegBanks = preRegBanks;
        },

        getAmountType : function() {
            return _amountType;
        },

        setAmountType : function(amountType) {
            _amountType = amountType;
        },

        getDistId : function() {
            return _distId;
        },

        setDistId : function(id) {
            _distId = id;
        },

        getFrequency : function() {
            return _frequency;
        },

        setFrequency : function(frequency) {
            _frequency = frequency;
        },

        getPeriod : function() {
            return _period;
        },

        setPeriod : function(period) {
            _period = period;
        },

        getPaymentDetails : function() {
            return _paymentDetails;
        },

        setPaymentDetails : function(paymentDetails) {
            _paymentDetails = paymentDetails;
        },

        setLumpsumPaymentDetails:function(paymentDetails) {
            _lumpsuPaymentDetails = paymentDetails;
        },

        getLumpsumPaymentDetails:function() {
            return  
        },

        setSipInvestmentPaymentDetails:function(paymentDetails) {
            _sipPaymentDetails = paymentDetails;
        },

        getSipInvestmentPaymentDetails:function() {
            return _sipPaymentDetails
        },

        getStartDate : function() {
            return _startDate;
        },

        setStartDate : function(startDate) {
            _startDate = startDate;
        },

        getLumpsumStartDate : function() {
            return _lumpsumStartDate;
        },

        setLumpsumStartDate : function(startDate) {
            _lumpsumStartDate = startDate;
        },

        getSipStartDate : function() {
            return _sipStartDate;
        },

        setSipStartDate : function(startDate) {
            _sipStartDate = startDate;
        },

        getEndDate : function() {
            return _endDate;
        },

        setEndDate : function(endDate) {
            _endDate = endDate;
        },

        getLumpsumEndDate : function() {
            return _lumpsumEndDate;
        },

        setLumpsumEndDate : function(endDate) {
            _lumpsumEndDate = endDate;
        },

        getSipEndDate : function() {
            return _sipEndDate;
        },

        setSipEndDate : function(endDate) {
            _sipEndDate = endDate;
        },

        getAccountNo : function() {
            return _accountNo;
        },

        setAccountNo : function(accountNo) {
            _accountNo = accountNo;
        },

        getAccountType : function() {
            return _accountType;
        },

        setAccountType : function(accountType) {
            _accountType = accountType;
        },

        getAchRefNo : function () {
            return _achRefNo;
        },

        setAchRefNo : function (achRefNo) {
            _achRefNo = achRefNo;
        },

        getIfscCode : function() {
            return _ifscCode;
        },

        setIfscCode : function(ifscCode) {
            _ifscCode = ifscCode;
        },

        getBranchAddress : function() {
            return _branchAddress;
        },

        setBranchAddress : function(branchAddress) {
            _branchAddress = branchAddress;
        },

        getBranchName : function() {
            return _branchName;
        },

        setBranchName : function(branchName) {
            _branchName = branchName;
        },        

        getIsNewAccount : function() {
            return _isNewAccount;
        },

        setIsNewAccount : function(isNewAccount) {
            _isNewAccount = isNewAccount;
        },

        getIsFundAmountError : function() {
            return _isFundAmountError;
        },

        setIsFundAmountError : function(isFundAmountError) {
            _isFundAmountError = isFundAmountError;
        },

        getIsFixedAmountError : function() {
            return _isFixedAmountError;
        },

        setIsFixedAmountError : function(isFixedAmountError) {
            _isFixedAmountError = isFixedAmountError;
        },

        getIsMultiPayMode : function() {
            return _isMultiPayMode;
        },

        setIsMultiPayMode : function(isMultiPayMode) {
            _isMultiPayMode = isMultiPayMode;
        },

        getIsMultiPayModeLumpsum : function() {
            return _isMultiPayModeLumsum;
        },

        setIsMultiPayModeLumpsum : function(isMultiPayMode) {
            _isMultiPayModeLumsum = isMultiPayMode;
        },

        getIsMultiPayModeSip : function() {
            return _isMultiPayModeSip;
        },

        setIsMultiPayModeSip : function(isMultiPayMode) {
            _isMultiPayModeSip = isMultiPayMode;
        },        

        getIsNewAccBankError : function() {
            return _isNewAccBankError;
        },

        setIsNewAccBankError : function(isNewAccBankError) {
            _isNewAccBankError = isNewAccBankError;
        },

        getIsAutoBankError : function() {
            return _isAutoBankError;
        },

        setIsAutoBankError : function(isAutoBankError) {
            _isAutoBankError = isAutoBankError;
        },

        getIsSipFreqError : function() {
            return _isSipFreqError;
        },

        setIsSipFreqError : function(isSipFreqError) {
            _isSipFreqError = isSipFreqError;
        },
        setBankAccNumber :function(bankAccNo){
            _bankAccNo = bankAccNo
        },
        getBankAccNumber : function() {
            return _bankAccNo;
        },
        setBuyEditable : function(stateVal) {
            _isBuyEditable = stateVal;
        },
        getBuyEditable : function() {
            return _isBuyEditable;
        },
        setIsMultiBankError : function(isMultiBankError) {
            _isMultiBankError = isMultiBankError;
        },
        getIsMultiBankError : function() {
            return _isMultiBankError;
        },
        setneftDetails : function(neftDtls) {
            _neftDtls = neftDtls;
        },
        getneftDetails : function() {
            return _neftDtls;
        },
        setModifysipEditable : function(stateVal) {
            _isModifySipEditable = stateVal;
        },
        getModifysipEditable : function() {
            return _isModifySipEditable;
        },
         setPaymentMode : function(stateVal) {
            _paymentMode = stateVal;
        },
        getPaymentMode : function() {
            return _paymentMode;
        },
        setNextPaymentMode : function(stateVal) {
            _nextPaymentMode = stateVal;
        },
        getNextPaymentMode : function() {
            return _nextPaymentMode;
        },
        setBnkNme : function(bankNme) {
            _bankNme = bankNme;
        },
        getBnkNme : function() {
            return _bankNme;
        },
        setWebRefNo:function(webref){
            _webref= webref;

        },
        getWebRefNo :function(){
            return _webref;
        },
        setGuestEdit : function(data){
            _guestEdit = data;

        },
        getGuestEdit:function(){
            return _guestEdit;
        },
        formatNeftDetails : function(neftDetails){
            angular.forEach(neftDetails, function(obj, key){
                switch (obj.code) {
                    case "Branch Name":
                        _neftDetails.nameOfBranch = obj.value
                        break;

                    case "Name":
                       _neftDetails.orgName = obj.value
                        break;

                    case "Bank Name":
                        _neftDetails.nameOfBank = obj.value
                        break;

                    case "IFSC Code":
                        _neftDetails.ifsc_Cd = obj.value
                        break;

                    case "Account Number":
                        _neftDetails.accNum = obj.value
                        break;

                    case "Account Type":
                        _neftDetails.acc_Typ = obj.value
                        break;
                };
            });
            return _neftDetails;
        },
        getEmandateDetails: function() {
            return angular.copy(_emandateDetails);
        },
        setEmandateDetails : function(emandateDetails) {
            _emandateDetails = angular.copy(emandateDetails);
        },
        setSelectedfolioId: function(selectdfolioId) {
            _selectdfolioId = selectdfolioId;
        },
        setSelectedfoliotitle: function(folioTitle) {
            _selectdfolioTitle = folioTitle;
        },
        setSelectedfolioKey: function(folioKey) {
            _selectdfolioKey = folioKey;
        },
        getSelectedfolioId: function() {
            return _selectdfolioId;
        },
        getSelectedfoliotitle: function() {
            return _selectdfolioTitle;
        },
        getSelectedfolioKey: function() {
            return _selectdfolioKey;
        },
        getIsExhausted: function() {
            return angular.copy(_isExhausted);
        },
        setIsExhausted : function(isExhausted) {
            _isExhausted = angular.copy(isExhausted);
        },
        getIsAccTypeError : function() {
            return _isAccTypeError;
        },
        setIsAccTypeError : function(isAccTypeError) {
            _isAccTypeError = isAccTypeError;
        },
        setNewInvestor : function(newInvestor){
            _newInvestor = newInvestor;
        },
        getNewInvestor : function(){
            return _newInvestor;
        },
        setIsNoBankError : function(isNoBankError) {
            _isNoBankError = angular.copy(isNoBankError);
        },
        getIsNoBankError : function() {
            return _isNoBankError;
        },
        setIsInvalidAmtError : function(isInvalidAmtError) {
            _isInvalidAmtError = angular.copy(isInvalidAmtError);
        },
        getIsInvalidAmtError : function() {
            return _isInvalidAmtError;
        },
        setPaymentBankAccNo : function(paymentBankAccNo) {
            _paymentBankAccNo = paymentBankAccNo;
        },
        getPaymentBankAccNo : function() {
            return _paymentBankAccNo;
        },
        setPaymentMethodError : function(paymentMethodError) {
            _paymentMethodError = paymentMethodError;
        },
        getPaymentMethodError : function() {
            return _paymentMethodError;
        },
        setValidateParams: function(setValidateParams) {
            _setValidateParams = setValidateParams;
        },
        getValidateParams : function() {
            return _setValidateParams;
        }
    };
    return bankDetailsModel;
};

bankDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = bankDetailsModel;
