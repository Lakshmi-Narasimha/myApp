import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavcomponentComponent } from './navcomponent/navcomponent.component';
import { ChatbotEditorComponent } from './chatbot-editor/chatbot-editor.component';
import { PublishComponent } from './publish/publish.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGuard } from './_guards/auth.guard';

// export const router: Routes = [
//   { path: '', redirectTo: 'manager', pathMatch: 'full'},
//   { path: 'manager', component: ChatbotEditorComponent},
//   { path: 'publisher', component: PublishComponentComponent}
// ];
//


export const router: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'logout', component: LogoutComponent },
    { path: 'publish', component: PublishComponent, canActivate: [AuthGuard]  },

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routes: ModuleWithProviders = RouterModule.forRoot(router);
