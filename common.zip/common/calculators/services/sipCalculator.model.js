/**
 * @ngdoc service
 * @name advisor alerts model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Setting the default $cacheFactory options for http call
 *
 */
 'use strict';

 var sipCalculatorModel = function (Restangular, $q, fticLoggerMessage, loggerConstants,authenticationService,toaster) {
    var _sipCalculation = null,
    _fundDetails = null;
    var sipCalculatorModel = {

        callSipCalculatorData : function (params, isAdvisor, source) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.ADVISOR_ALERTS_MODEL + ' | callSipCalculatorData' /* Function Name */;
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var body = params;
            params = {};
            if(isAdvisor) {
                params = {

                    'guId' : authenticationService.getUser().guId,
                };
            }
            if(source === 'PS') {
                params.source = source;
            }


            Restangular.one('smartsolution/sipLumpCalculator').customPOST(body, '', params, {}).then(function (sipcalculations) {
                deferred.resolve(sipcalculations);
            }, function (resp) {
                deferred.reject(resp);
                toaster.error(resp.data[0].errorDescription);

            });
            return deferred.promise;
        },
        callFundDetailsData : function (isAdvisor) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.ADVISOR_ALERTS_MODEL + ' | CallFundDetails' /* Function Name */;
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var params = {};
            if(isAdvisor) {
                params = {
                   // 'groupId' : 'FundsPerfCalc',
                   'source':'TC',
                   'guId': authenticationService.getUser() !== null ? authenticationService.getUser().guId : null
               };
           }
           else
                params = {'source' : 'TC'};
            //params = {'groupId' : 'FundsPerfCalc'};

           // Restangular.one('services/paramCodes').get(params).then(function (sipcalculations) {
            // Restangular.one('transact/fundsList').get(params).then(function (sipcalculations) {
            Restangular.one('transact/fundsList').customPOST(params, '', {}, {}).then(function (sipcalculations) {
            deferred.resolve(sipcalculations);
        }, function (resp) {
            deferred.reject(resp);

        });
        return deferred.promise;
    },
    setSipCalculations:function(sipcalculations){
        _sipCalculation = sipcalculations;

    },
    getSipCalculations:function(){
        if(!angular.isDefined(_sipCalculation))
        {
            return null;
        }

        return _sipCalculation;
    },
    setFundDetails : function(fundDetails){
        _fundDetails = fundDetails;
    },
    getFundDetails : function(){
        if(!angular.isDefined(_fundDetails))
        {
            return null;
        }
        return _fundDetails;
    }

};
return sipCalculatorModel;
};

sipCalculatorModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService','toaster'];

module.exports = sipCalculatorModel;
