// modules
var express = require('express');
var bodyParser = require('body-parser');
var querystring = require('querystring');
var session = require('express-session');

// app configuration
var app = express();

// set our port
var port = process.env.PORT || 9000;

// get all data/stuff of the body (POST) parameters
// parse application/json
app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: true
}));

// initialize the session
app.use(session({ secret: 'ASKVERIZON123456', saveUninitialized: true, resave: true }));

// app.UseCors(CorsOptions.AllowAll);
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// set the static files location /public/img will be /img for users
app.use(express.static(__dirname + '/'));

// api routes
var liveChatRoute = require('./api/modules/livechat/livechat.route');
var endChatRoute = require('./api/modules/endchat/endchat.route');
var getSupportRoute = require('./api/modules/getSupport/getSupport.route');
var getTypeSearchSupportRoute = require('./api/modules/getTypeSearchSupport/getTypeSearchSupport.route');
var searchRoute = require('./api/modules/search/search.route');
var launchAppRoute = require('./api/modules/launchApp/launchApp.route');

// api services
app.post('/ask-verizon-api/livechat', liveChatRoute);
app.post('/ask-verizon-api/endchat', endChatRoute);
app.post('/ask-verizon-api/getSupport', getSupportRoute);
app.post('/ask-verizon-api/getTypeSearchSupport', getTypeSearchSupportRoute);
app.post('/ask-verizon-api/search', searchRoute);
//app.post('/ask-verizon-api/launchApp', launchAppRoute);



app.listen(port);
// shoutout to the user
console.log('Application is running on http://localhost:' + port);
