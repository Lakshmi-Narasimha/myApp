export { TabHeadingDirective } from './tab-heading.directive';
export { TabsetComponent } from './tabset.component';
export { TabDirective } from './tab.directive';
export { TabsModule } from './tabs.module';
export { NgTranscludeDirective } from './ng-transclude.directive';
export { TabsetConfig } from './tabset.config';
