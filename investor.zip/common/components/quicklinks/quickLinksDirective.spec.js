'use strict';

describe('Directive: Advisor Quick Links', function() {

	var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
          scope = $rootScope.$new();
          compile = $compile;
          scope.quicklinks = [
                {
                icon:"icon-fti_advisorAccountStatement",
                lable:"Account Statement",
                href:"/somelink" 
                },
                {
                icon:"icon-fti_advisorPortfolioValuation",
                lable:"Portfolio Valuation",
                href:"/somelink"  
                },
                {
                icon:"icon-fti_advisorCapitalGain",
                lable:"Capital Gains Statement",
                href:"/somelink"  
                },
                {
                icon:"icon-fti_advisorPrefilled",
                lable:"Pre-filled Transaction Slips",
                href:"/somelink"  
                },
                {
                icon:"icon-fti_advisorBuildMyReport",
                lable:"Build My Report",
                href:"/somelink"  
                }
          ]; 
          //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-adb-quick-links link-data="quicklinks"></ftic-adb-quick-links>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();
    });

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should be defined',function(){
		expect(directiveEle).toBeDefined();
	});
});