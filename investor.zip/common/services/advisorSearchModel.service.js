




        /**
 * @ngdoc property
 * @name paperLessModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - paperLessModel is a service model which consists the list of services required for paper less module.
 *
 **/
'use strict';


var advisorSearchModel = function(Restangular, $q, fticLoggerMessage, loggerConstants) {

    var  _advisorNameDetails = null;
    var _proxyTestData=null;

    var advisorSearchNameDetails = {

        fetchAdvisorNameDetails : function (params) {
            var deferred = $q.defer();
            Restangular.one('services/searchAdvisor').get(params).then(function (advisorDetails) {
                deferred.resolve(advisorDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setAdvisorNameDetails : function(advisornames){
        	_advisorNameDetails = advisornames;
        	return _advisorNameDetails;
        },   
        getAdvisorNameDetails : function(){
        	return _advisorNameDetails;
        },
        setProxyTestData:function(data){
            _proxyTestData = data;
        },
        getProxyTestData:function(){
            return _proxyTestData;
        }     
    };

    return advisorSearchNameDetails;

    
};

advisorSearchModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = advisorSearchModel;
