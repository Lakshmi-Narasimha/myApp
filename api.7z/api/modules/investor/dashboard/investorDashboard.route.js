'use strict';

var express = require('express');
var router = express.Router();
var investorDashboard = require('./getInvestorDashboard.model'),
    InvestPopUpDetailsModel = require('./getInvestPopUpDetails.model'),
    ConfirmInvestDetailsModel = require('./confirmInvestDetails.model');



var errorObj = [{
    errorCode: 'A0003',
    errorMessage: 'Something went wrong'
}];
// api route
router.route('/dashboard/investorDashboard')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        investorDashboard.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(errorObj);
            } else {

                res.json({
                    investorDashboardObject: {
                        'profileDetails': data[0].investorDashboardObject.profileDetails,
                        'mySips': data[0].investorDashboardObject.mySips,
                        'myTransactions': data[0].investorDashboardObject.myTransactions,
                        'unclaimedAmount': data[0].investorDashboardObject.unclaimedAmount,
                        'dividendHistory': data[0].investorDashboardObject.dividendHistory
                    }
                });
                //res.send(500, errorObj);

            }

        });
    });

router.route('/dashboard/investorSmartSavings')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        investorDashboard.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(errorObj);
            } else {
                res.json({
                    'smartSavingsAccount': data[0].investorDashboardObject.smartSavingsAccount,
                    'oneTouchInvest': data[0].investorDashboardObject.oneTouchInvest,
                    'banner': data[0].investorDashboardObject.banner
                });
                //res.send(500, errorObj);

            }

        });
    });

router.route('/dashboard/investorSmartSolGoals')
    .get(function(req, res) {

        investorDashboard.find(function(err, data) {

            if (err) {
                res.send(errorObj);
            } else {
                var response = {
                    hasGoals: 'Y', // replace with N to set carosel data and uncomment carousel data & comment grid data
                    smartSolutionGoals: data[0].investorDashboardObject.smartSolutions.smartSolutionGoals // for grid data
                        //smartSolutionGoals: data[0].investorDashboardObject.smartSolutions.carousel //for carosel data
                };
                res.json(response);
                //res.send(500, errorObj);

            }

        });
    });

/// smart saving and one Touch Invest service call
router.route('/dashboard/getInvestDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvestPopUpDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].getInvestDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0]);
            }
        });
    });

router.route('/dashboard/confirmInvestDetails')
    .post(function(req, res) {
        ConfirmInvestDetailsModel.find(function(err, data) {
            res.send(data[0].confirmInvestDetailsResp);
        });
    });



module.exports = router;
