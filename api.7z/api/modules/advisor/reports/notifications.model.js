// getNotificationReport.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var NotificationReportModelSchema = new mongoose.Schema({
    notificationReportResp: {
        type: Array,
        "default": []
    }
});

var NotificationReportModelLookUp = mongoose.model('NotificationReportModelLookUp', NotificationReportModelSchema);

var NotificationReportModel = new NotificationReportModelLookUp({
    notificationReportResp : {
      "notificationReport": [
               {
                    "dateOfNotifications":"16 may 2016",
                    "Title": "Brokrage Paid out report",
                    "type" : "excel",
                    "data" : "https://rouskmportal.cognizant.com/sites/rouskmportal/Customers/Cognizant%40FT/ProjectArtifacts/User%20Stories/Advisor%20User%20Stories/Reports/User%20Story_Custom%20Reports_v0.5%20-%20Sign%20Off.doc"
                },
                {
                    "dateOfNotifications":"17 may 2015",
                    "Title": "Brokrage Paid out report",
                    "type" : "pdf",
                    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA=="

                },
                {
                    "dateOfNotifications":"18 may 2016",
                    "Title": "Brokrage Paid out report",
                    "type" : "excel",
                    "data" : "https://rouskmportal.cognizant.com/sites/rouskmportal/Customers/Cognizant%40FT/ProjectArtifacts/User%20Stories/Advisor%20User%20Stories/Reports/User%20Story_Custom%20Reports_v0.5%20-%20Sign%20Off.doc"
                },
                {
                    "dateOfNotifications":"16 may 2016",
                    "Title": "Brokrage Paid out report",
                    "type" : "pdf",
                    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA=="
                }
        ]
        
    }
});

NotificationReportModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating NotificationReportModelLookUp table, please contact admin...');
    } else {
        NotificationReportModelLookUp.remove({}, function(err) {
            console.log('NotificationReportModelLookUp collection removed');
            NotificationReportModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating NotificationReportModelLookUp table, please contact admin...');
                }
                console.log('NotificationReportModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = NotificationReportModelLookUp;
