/**
 * @ngdoc property
 * @name sipFundDetails Directive
 * @requires sipDetailsModel
 * @requires eventConstants
 * @description
 *
 * - It will get the fund details from 'sipDetailsModel' and displays the details.  
 **/
'use strict';

var sipFundDetails = function ($filter, TransactConstant, sipDetailsModel) {
    return {
        template: require('./sipTxnDetails.html'),
        restrict: 'E',
        scope: {
        },
        controller:['$scope', function ($scope) { 
            
            var translateFilter = $filter('translate'), datefilter = $filter('date'), endDate, futureDate, dateSplit, dateObj, date_regex = /^\d{4}-\d{2}-\d{2}$/, date_regex2 = /^\d{2}\/\d{2}\/\d{4}$/;
            $scope.sipTxnDetails = sipDetailsModel.getSipDetails();
            $scope.infoObj=[];
            function dateConverter(date, exp){
                if(exp === 'reg1'){
                    dateSplit = date.split("-");
                }else if(exp === 'reg2'){
                    dateSplit = date.split("/");
                }
                
                dateObj = new Date(dateSplit[0], dateSplit[1] - 1, dateSplit[2]);
                return dateObj;
            }
            angular.forEach($scope.sipTxnDetails, function(obj, key){
                endDate = $scope.sipTxnDetails[key].endDate;
                futureDate = $scope.sipTxnDetails[key].startDate;
                endDate = (endDate && date_regex.test(endDate)) ? $filter('date')(dateConverter(endDate, 'reg1'), 'MMM yyyy') : ((endDate && date_regex2.test(endDate, 'reg2')) ? $filter('date')(dateConverter(endDate), 'MMM yyyy') : endDate);
                // endDate = (endDate && date_regex.test(endDate)) ? $filter('date')(dateConverter(endDate), 'dd MMM yyyy') : endDate;
                futureDate = (futureDate && date_regex.test(futureDate)) ? futureDate.split("-")[2] +" day - "+ $filter('date')(dateConverter(futureDate, 'reg1'), 'MMM yyyy') :((futureDate && date_regex2.test(futureDate, 'reg2')) ? futureDate.split("-")[2] +" day - "+ $filter('date')(dateConverter(futureDate), 'MMM yyyy') : futureDate);
                $scope.infoObj.push([
                    {
                        text: translateFilter(TransactConstant.transact.ACCOUNT_NUMBER),
                        value: $scope.sipTxnDetails[key].accNo
                    },
                    {
                        text: translateFilter(TransactConstant.transact.FUND_NAME),
                        value: $scope.sipTxnDetails[key].fundOptDesc
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_AMOUNT),
                        value: "<span class='icon-fti_rupee'></span>" + $scope.sipTxnDetails[key].amount
                    },
                    {
                        text: translateFilter(TransactConstant.sip.DIVIDEND),
                        value: $scope.sipTxnDetails[key].dividendFlag === "R" ? "Re-Investment" : ($scope.sipTxnDetails[key].dividendFlag === "P" ? "Payout" : "NA")
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_FIRST_INSTALLMENT),
                        value: "Current Business Day"
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_FUTURE_INSTALLMENT),
                        value: futureDate
                    },
                    {
                        text: translateFilter(TransactConstant.sip.SIP_END_DATE),
                        value: $scope.sipTxnDetails[key].perpetualFlag === "Y" ? "Until Cancelled" : endDate
                    },
                    {
                        text: translateFilter(TransactConstant.transact.FREQUENCY),
                        value: $scope.sipTxnDetails[key].frequency === "M" ? "Monthly" : ($scope.sipTxnDetails[key].frequency === "Q" ? "Quaterly" : $scope.sipTxnDetails[key].frequency === "A" ? "Annually": "")
                    },
                    {
                        text: translateFilter(TransactConstant.sip.STEP_UP_SIP_HEADING),
                        value: $scope.sipTxnDetails[key].stepUpType === "P" ? $scope.sipTxnDetails[key].stepUpValue+"% Annually" : ($scope.sipTxnDetails[key].stepUpType === "A" ? ("<span class='icon-fti_rupee'></span>"+$scope.sipTxnDetails[key].stepUpValue+" Annually") : "NA")
                    }
                ]);
            }); 
        }]
    };
};

sipFundDetails.$inject = ['$filter', 'TransactConstant', 'sipDetailsModel'];
module.exports = sipFundDetails;