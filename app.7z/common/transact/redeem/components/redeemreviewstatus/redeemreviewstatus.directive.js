/**
 * @ngdoc property
 * @name fticRedemptionReviewStatus Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Status.
 *
 **/
'use strict';

var fticRedemptionReviewStatus = function (transactModel) {
    return {
        template: require('./redeemreviewstatus.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {

            var redeemDetails = transactModel.getTransactDetails().transactDetails;            
            var transConf = transactModel.getTransactConfirm();

            console.log(transactModel.getTransactDetails())
            $scope.keyValuePairs = [
                {
                    key: "transactionRefNo",
                    text: "Transaction Reference No.",
                    value: transConf.transactionRefNo
                },
                {
                    key: "requestDateTime",
                    text: "Request Date and Time ",
                    value: transConf.transDateTime
                }
            ];
            if(redeemDetails.amount !== "" && redeemDetails.amount !== null)
                {
                    var amountObj = {
                        key: "redemptionAmount",
                        text : "Redemption Amount",
                        value: redeemDetails.amount
                    };
                    $scope.keyValuePairs.push(amountObj);
                }
                else if(redeemDetails.units !== "" && redeemDetails.units !== null)
                {
                    var unitObj = {
                        key: "redemptionUnits",
                        text : "Redemption Units",
                        value: redeemDetails.units        
                    };
                    $scope.keyValuePairs.push(unitObj);
                }    
        }]
    };
};

fticRedemptionReviewStatus.$inject = ['transactModel'];
module.exports = fticRedemptionReviewStatus;
