/**
 * @ngdoc directive
 * @name fticInvDbSsTile
 * @requires $scope
 * @requires configUrlModel
 * @requires appConfig

 * @description
 *
 * - fticInvDbSsTile will display text on image tile for "Smart Solutions carousel" .
 *
 **/

'use strict';

var imageTextTile = function(configUrlModel, appConfig) {
    return {
        template: require('./imageTextTile.html'),
        restrict: 'E',
        replace: true,
        scope: true,
        link: function(scope) {
            scope.getImgAbsUrl = function(slideObj, imgPath){
                var imgPath = slideObj[imgPath];
                return imgPath.indexOf('http') !== -1 ? imgPath : appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + imgPath;
            };

            scope.recommendPlan = function() {
                //alert(scope.amount);
            };
        }
    };
};

imageTextTile.$inject = ['configUrlModel', 'appConfig'];
module.exports = imageTextTile;
