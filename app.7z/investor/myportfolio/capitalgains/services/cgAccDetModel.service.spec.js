'use strict';
describe('Services: capital gains account details model factory', function() {

    var cgAccDetModelData, httpBackend, Restangular, $window, params;

    var params = {
            flag: 'A',
            guId: '878'
        }
        var paramsF = {
            flag: 'F',
            guId: '878'
        }
    beforeEach(angular.mock.module('investor'));
    beforeEach(inject(function(_cgAccDetModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
        cgAccDetModelData = _cgAccDetModel_;
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        $window = _$window_;
        $window.ga = function() {};
    }));

    it('should accountViewModel to be defined', function() {
        expect(cgAccDetModelData).toBeDefined();
    });

    describe('Services: load capital gains account details services', function() {
        var cgAccViewObject;
        beforeEach(inject(function() {
            cgAccViewObject = {
                   "accdetails":[  
                      {  
                         "panFolioAccounts":[  
                            {  
                               "folioAccounts":[  
                                  "0019906346498"
                               ],
                               "latestFolio":"N",
                               "folioId":"18507834"
                            },
                            {  
                               "folioAccounts":[  
                                  "0019906346500"
                               ],
                               "latestFolio":"N",
                               "folioId":"18507836"
                            }
                         ],
                         "panNo":"CVCQH7718M"
                      }
                   ],
                   "foliodet":[  
                      {  
                         "taxded":{  
                            "stt":"0",
                            "total":""
                         },
                         "capital":{  
                            "longterm":"4791.089025",
                            "shorterm":"993.83"
                         },
                         "redemption":{  
                            "amount":"9791.1",
                            "txDate":"16 dec 2014",
                            "txType":"Switch Out"
                         },
                         "purchase":{  
                            "indexedVal":"8797.27",
                            "txDate":"2008-06-24 00:00:00.0",
                            "txType":"Purchase",
                            "fundWiseData":null
                         },
                         "accountNo":"0100007823616",
                         "fundName":"Franklin India Pension Plan-GROWTH"
                      }
                   ],
                   "unitHolderDetails":{  
                      "sstatus":"NRI",
                      "address":{  
                         "line3":null,
                         "line2":null,
                         "line1":null,
                         "pinCode":"763001",
                         "city":"Chennai",
                         "address4":"Acrot Street No",
                         "address3":"Yerapalli street",
                         "address2":"Vadapallani",
                         "address1":"B-34 Acrot Street No 161 Yerapalli street"
                      },
                      "invname":"Deepit Manish Banode Dholkia Motiram Umalkar"
                   }
            };

            httpBackend.expectGET('http://localhost:3030/clients/capitalGain?dayFlag=CY&flag=F&folioPanAccNo=14503662&guId=878').respond(cgAccViewObject);
            httpBackend.expectGET('http://localhost:3030/clients/folioAccounts?guId=878').respond(cgAccViewObject.accdetails[0].panFolioAccounts);
        }));

        it('should load fetchcgaccountdetails with success data and retreive the data using getter', function() {
            cgAccDetModelData.fetchcgaccountdetails(params).then(function(result) {
                expect(result).toBeDefined();
            });
        });

        it('should load fetchCgFolioDetails with success data and retreive the data using getter', function() {
            cgAccDetModelData.fetchCgFolioDetails(paramsF).then(function(result) {
                expect(result).toBeDefined();
            });
        });

        it('should retrive getcgaccountdetails data using getter', function() {
            cgAccDetModelData.setcgaccountdetails(cgAccViewObject);
            expect(cgAccDetModelData.getcgaccountdetails().accdetails[0].panNo).toEqual('CVCQH7718M');
        });

        it('should retrive getCgFoliodetails data using getter', function() {
            cgAccDetModelData.setCgFoliodetails(cgAccViewObject);
            expect(cgAccDetModelData.getCgFoliodetails().accdetails[0].panNo).toEqual('CVCQH7718M');
        });

        it('should retrive getcapitalgainsfoliodetails data using getter', function() {
            cgAccDetModelData.setcapitalgainsfoliodetails(cgAccViewObject);
            expect(cgAccDetModelData.getcapitalgainsfoliodetails().accdetails[0].panNo).toEqual('CVCQH7718M');
        });

        it('should retrive getCapitalGainsUnitHolder data using getter', function() {
            cgAccDetModelData.setCapitalGainsUnitHolder(cgAccViewObject);
            expect(cgAccDetModelData.getCapitalGainsUnitHolder().sstatus).toEqual('NRI');
        });

        it('should retrive getcgaccountdetunitholder data using getter', function() {
            cgAccDetModelData.setcgaccountdetunitholder(cgAccViewObject);
            expect(cgAccDetModelData.getcgaccountdetunitholder().sstatus).toEqual('NRI');
        });

        it('should retrive getCgFolioDetUnitholder data using getter', function() {
            cgAccDetModelData.setCgFolioDetUnitholder(cgAccViewObject);
            expect(cgAccDetModelData.getCgFolioDetUnitholder().sstatus).toEqual('NRI');
        });

        it('should retrive getAccFolioNumber data using getter', function() {
            cgAccDetModelData.setAccFolioNumber(cgAccViewObject);
            expect(cgAccDetModelData.getAccFolioNumber().foliodet[0].accountNo).toEqual('0100007823616');
        });

        it('should load getFolioAccountDetails with success data and retreive the data using getter', function() {
            cgAccDetModelData.getFolioAccountDetails().then(function(result) {
                expect(result).toBeDefined();
            });
        });

        it('should retrive getFolioNumbersList data using getter', function() {
            cgAccDetModelData.setFolioNumbersList(cgAccViewObject);
            expect(cgAccDetModelData.getFolioNumbersList().foliodet[0].accountNo).toEqual('0100007823616');
        });
    });
});
