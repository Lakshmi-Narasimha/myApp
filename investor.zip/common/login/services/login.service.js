'use strict';

var loginModelService= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _choosenOption = null;
    
    var loginModel = {
        
        fetchLoginDtls : function () {

            var deferred = $q.defer();
            Restangular.all('getChoosenOptionData').getList().then(function (attrDetails) {
                deferred.resolve(attrDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setChoosenOptionData : function(data){
            _choosenOption = data;
        },
        getChoosenOptionData : function(){
            return _choosenOption;
        }

        

    };
    return loginModel;

};

loginModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = loginModelService;
