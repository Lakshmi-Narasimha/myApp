
/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var SipModifyDetailModel = function(Restangular, $q, fticLoggerMessage, loggerConstants,authenticationService,$state,transactModel) {
    var _sipDetail = null;
    var _sipInpDetail = null;
	var SipModifyDetailModel = {    
        fetchSipDetails : function (selectedInv) {
            var params = {};
            params.guId = authenticationService.getUser().guId;
            if($state.current.name === 'transact.base.modifysip' || $state.current.name === 'invTransact.base.modifysip') {
                params.folioPanAccNo = selectedInv.folioId;
                params.fetchType = "C";
                params.folioPanFlag = "F"
            }else if($state.current.name === 'transactnow.baseNow.renewSip'){
                var isNewFolio = transactModel.getIsNewFolio();
                params.folioPanAccNo = isNewFolio ? authenticationService.getUser().pan : selectedInv.folioId;
                params.fetchType = "R";
                params.folioPanFlag = isNewFolio ? "P" : "F";
            } else if($state.current.name === 'invTransact.base.renewsip') {
                params.folioPanAccNo = selectedInv.folioId;
                params.fetchType = "R";
                params.folioPanFlag = "F"
            }
            var deferred = $q.defer();
            Restangular.one('transact/sipDetails').get(params).then(function (modSipDetails) {
                deferred.resolve(modSipDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },  

        postModifyTransactDetails : function (params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId, "op" : "modifySip","pat":"async"};
            Restangular.one('transact/orders').customPOST(params, "", preferences, {}).then(function (transactDetails) {
                deferred.resolve(transactDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },  

        postGuestModifyTransactDetails : function (params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId, "op" : "modifySip"};
            Restangular.one('transact/orders').customPOST(params, "", preferences, {}).then(function (transactDetails) {
                deferred.resolve(transactDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },  
        
        setModifySipDetails : function (sipDetail) {
            
            _sipDetail = sipDetail;
        },
        getModifySipDetails : function () {
            if (!angular.isDefined(_sipDetail)) {
                return null;
            }
            return _sipDetail;
        },    
        
        setModifySipInpDetails : function (sipInpDetail) {
            
            _sipInpDetail = sipInpDetail;
        },
        getModifySipInpDetails : function () {
            if (!angular.isDefined(_sipInpDetail)) {
                return null;
            }
            return _sipInpDetail;
        },

        fetchTxnDetailsModifySip : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('getTxnDetailsModifySip').get(params).then(function (modifySipDetails) {
                deferred.resolve(modifySipDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        }
    };
    return SipModifyDetailModel;
};

SipModifyDetailModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService','$state','transactModel'];
module.exports = SipModifyDetailModel;
