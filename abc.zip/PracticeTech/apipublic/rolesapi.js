﻿define([
  'jquery',
  'underscore',
  'config',
   'appcommon/commonutility'

], function ($, _, Config, Utility) {
    getUserRoles = function (user) {
        var user = user || "current", _userRole = "none", _isNonCMUser = false; //placeholder argument for future use

        //groups the user belongs to
        //check for user role 
        var groups = Utility.readCookie('LDAP_Groups') || 'none';
        if ((/AFI_ADVISORMOBILE_CSR_ACCESS/i.test(groups))
            || (/AFI_ADVISORMOBILE_CSR_ACCESS_FIELD_INSTALL/i.test(groups))
            || (/AFI_ADVISORMOBILE_CSR_ACCESS_AML/i.test(groups))
            || (/AFI_ADVISORMOBILE_CSR_ACCESS_COMPL/i.test(groups))) {
            _userRole = 'csr';
        } else if (/aefa_home_office_fsc/i.test(groups)) {
            _userRole = 'aac';
        } else if (/aefa_field_rp/i.test(groups)) {
            _userRole = 'rp';
        } else if (/aefa_field_rp_delegates/i.test(groups)) {
            _userRole = 'rpdelegates';
        } else if ((/AFI_ContactService_Pilot/i.test(groups)) || (/AFI_ContactService_Tech/i.test(groups))) {
            _userRole = 'cspilotTech';
        }
        //Modified below logic as negation. If user has LDAP group then consider him/her as NonCMUser.
        //check for non CM user
        if (!/AFI_ADVISORMOBILE_CONTACTMANAGER_ACCESS/i.test(groups)) {
            _isNonCMUser = false;
        }
        else {
            _isNonCMUser = true;
        }

        if (Config.isDevEnv) {
            _isNonCMUser = false;
        }        
        return {
            "role": _userRole,
            "isNonCMUser": _isNonCMUser
        };

        groups.toLowerCase();
        groups = groups.split('^');
        groups = groups.split('=');


        //groups definitions
        var groupMatrix = Config.roles;
        if (!Config.roles) { return "common" }
        var groupMatrixKeys = [];
        for (key in groupMatrix) {
            groupMatrixKeys.push(key)
        }

        for (key in groupMatrix) {
            if (groupMatrix[key].groups) {
                for (i = 0; i < groupMatrix[key].groups.length; i++) {
                    groupMatrix[key].groups[i] = groupMatrix[key].groups[i].toLowerCase()
                }
            }
        }



        //Array to hole groups user can belong to.
        var userGroups = [];

        //itterate through each role definition and see if user groups exist 
        for (key in groupMatrix) {
            selector = key;

            for (var i = 0; i < groups.length; i++) {
                if (groupMatrix[selector].groups.indexOf(groups[i].toLowerCase()) > -1) {
                    userGroups.push(key);
                }
            }
        }

        return userGroups;

    }



    return getUserRoles();
});