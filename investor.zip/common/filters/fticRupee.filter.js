/**
 * @ngdoc filter
 * @name fticRupee
 * @description
 *
 * - This common filter is used to display Rupee Icon.
 *
 */

'use strict';

var fticRupee = function() {
    return function(input) {
        return input ? '<i class="icon-fti_rupee bold"></i> ' + input : '';
    };
};

fticRupee.$inject = [];
module.exports = fticRupee;
