define(
        ['spinner', 'momentTimezone', 'config', "underscore",'errorLog','Base64'],
        function (Spinner, MomentTimezone, MainConfig, underscore,ErrorLog,Base64) {
            var views = {};
            var config = {
                    APP_VERSION: "",
                    BASE_URL: "",
                    SM_UNIVERSAL_ID: "",
                    FM_ID: "",
                    API_COMMON_DATA_BODY: {
                        $format: 'json'
                    },
                    SAD_CONFIG: {
                    		appId:"A0061097",
                    		appName:"ncst"
                    }
                };
            var _ = {
                setCustomHeader: function (xhr,maxAge) {
					if (maxAge != undefined) {
						xhr.setRequestHeader('cache-control', 'max-age='
								+ maxAge);
					} 
                },
                lockForm: function (options) {
                    Spinner.show(options);
                },
                unlockForm: function () {
                    Spinner.hide();
                },
                put: function (url, data, successHandler, errorHandler, headers) {
                    var res = _send('PUT', url, "application/json", data,
                            successHandler, errorHandler, headers);
                    return res;
                },
                post: function (url, data, successHandler, errorHandler,
                        headers, processData, xhr1,maxAge) {
                    var res = _send('POST', url, ((xhr1 != ""
                            && xhr1 != undefined && xhr1 != null) ? false
                            : "application/json"), data, successHandler,
                            errorHandler, headers,maxAge, processData, xhr1);
                    return res;
                },
                get: function (url, data, successHandler, errorHandler, headers,maxAge) {
                    var res = _send('GET', url, "application/json", data,
                            successHandler, errorHandler, headers,maxAge);
                    return res;
                },
                delete: function (url, data, successHandler, errorHandler) {
                    var res = _send('DELETE', url, "application/json", data,
                            successHandler, errorHandler);
                    return res;
                },
                getJson: function (url, data, successHandler, errorHandler) {
                    $.ajax({
                        type: 'GET',
                        dataType: "json",
                        url: url,
                        success: function (resp) {
                            successHandler(resp);
                        },
                        error: function (resp) {
                            successHandler(JSON.parse(resp));
                        }
                    });
                },
                capitalize: function (string) {
                    return string.charAt(0).toUpperCase()
                            + string.substring(1).toLowerCase();
                },
                lowerCase: function (string) {
                    return string.toLowerCase();
                },
                readCookie: function (name) {
                    try {
                    	var options = options || {};
                        var nameEQ = name + "=";
                        var ca = document.cookie.split(';');
                        for (var i = 0; i < ca.length; i++) {
                            var c = ca[i];
                            while (c.charAt(0) == ' ')
                                c = c.substring(1, c.length);
                            if (c.indexOf(nameEQ) == 0) {
                            	if(options.decode){
                            		var _substring = decodeURIComponent(Base64.decode(c.substring(nameEQ.length, c.length)));
                            	}else{
                            		var _substring = decodeURIComponent(c.substring(nameEQ.length, c.length));
                            	}
                                return _substring;

                            }
                        }
                    } catch (e) {

                    }

                    return null;
                },
                isMobile: function () {
                    var _regxMob = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
                    return _regxMob.test(navigator.userAgent);
                },
                showSystemUnavailabelError: function (message, url, lineNumber) {
                    this.unlockForm();
                    $('.ncst-alert-row:first').removeClass('hidden').show();
                    // coa.utils.logError(message, url, lineNumber);

                    // BootstrapDialog.alert('System Unavailable.<br/>The system
                    // is
                    // currently unavailable. Please try again later.');
                },
                hideSystemUnavailabelError: function () {
                    $('.ncst-alert-row').addClass('hidden');

                },
                logError : function(error,customMessage,showPopup) {
                	if(error.responseJSON){
                		error.responseJSON = JSON.parse(this.normalizeWS(JSON.stringify(error.responseJSON)));
                	}
					if(customMessage){
					ErrorLog.ErrorUtils.myError(error,true);
						//this.logError(error.message, error.url, error.lineNum);
					}else{
						var _hidePopup = showPopup?false:true;
						ErrorLog.ErrorUtils.prepareAndLogError(error,_hidePopup);
					}
				
				},
                 loadSelectbox: function (selectBox, opionData, selectedVal,noEmptyOption) {
                    var _optionsData = opionData;
                    var _options = '';
                    if (!noEmptyOption) {
                        _options += '<option value="" >Choose one</option>'
                    }
                    $.each(_optionsData, function (key, row) {
                    	var _val = row.code || row.value
                    	if(selectedVal == _val){
                    		 _options += '<option selected name="' + row.name + '" value="'
                             + _val + '" >' + row.name + '</option>';
                    	}else{
                    		 _options += '<option name="' + row.name + '" value="'
                             + _val + '" >' + row.name + '</option>';
                    	}
                       
                    });
                    if (Array.isArray(selectBox)) {
                        $(selectBox.join(',')).html(_options);
                    } else {
                        $(selectBox).html(_options);
                    }

                },
                arraySplice: function (arr, ele) {

                    var i = arr.indexOf(ele);
                    if (i != -1) {
                        arr.splice(i, 1);
                    }
                    return arr;
                },
                /*
                initInfoPopup: function () {
                    var _placement = 'right';
                    if (window.innerWidth < 768) {
                        _placement = 'bottom';
                    }
                    $('.popover.info-popup').remove();
                    $('#ncst-user-home-view .icon-info.info-popup').popover(
                            'destroy');
                    $('#ncst-user-home-view .icon-info')
                            .popover(
                                    {
                                        container: 'body',
                                        html: true,
                                        placement: _placement,
                                        viewport: 'body',
                                        title: 'Change type <i class="icon-popover-close"></i>',
                                        template: '<div class="popover info-popup ncst-popover" role="tooltip"><div class="arrow info-popup">'
                                                + '</div><h2 class="popover-title info-popup"></h2><div class="popover-content info-popup"></div></div>'
                                    });
                    var _isOpen = true;
                    $('#ncst-user-home-view .icon-info').on(
                            'hidden.bs.popover', function () {
                                _isOpen = false;
                            });
                    $('#ncst-user-home-view .icon-info')
                            .on(
                                    'shown.bs.popover',
                                    function () {
                                        _isOpen = true;
                                        if (!$('.icon-popover-close').length) {
                                            $('.popover-title')
                                                    .append(
                                                            '<i class="icon-popover-close"></i>');
                                        }
                                        $(".icon-popover-close")
                                                .off("click")
                                                .on(
                                                        "click",
                                                        function (e) {
                                                            $(
                                                                    '.icon-info')
                                                                    .popover(
                                                                            'hide');
                                                            _isOpen = false;
                                                        });
                                        $(document)
                                                .off('click', 'body')
                                                .on(
                                                        'click',
                                                        'body',
                                                        function (e) {
                                                            var _$targetElm = $(e.target);
                                                            if (_isOpen
                                                                    && !_$targetElm
                                                                    .hasClass('info-popup')) {
                                                                $(
                                                                        '#ncst-user-home-view .icon-info')
                                                                        .popover(
                                                                                'hide');
                                                                _isOpen = false;
                                                            }
                                                        });

                                    });
                    function isWinTablet() {
                        return (navigator.userAgent.toLowerCase().indexOf(
                                "windows nt") != -1 && navigator.userAgent
                                .toLowerCase().indexOf("touch") != -1);
                    }
                    // adjust the position pof opened info popup on orientaion
                    // chnage
                    var _evt = isWinTablet() ? 'resize' : 'orientationchange';
                    $(window).off(_evt, orientaionChangehandler).on(_evt,orientaionChangehandler);
                    function orientaionChangehandler(event) {
                        var _timeout = 0;
                        (function (_event) {
                            if (navigator.userAgent.indexOf('Android') > -1) {
                                _timeout = 200;
                            }
                            setTimeout(function () {
                                        var _activePopup = $('#ncst-user-home-view .icon-info[aria-describedby]');
                                        if(_activePopup.length>0){
                                        	 _.initInfoPopup();
                                             setTimeout(function () {_activePopup.click();}, 10);
                                             }
                                        }, _timeout);
                        })(event);


                    }
                },
                */
                iOSversion: function () {
                    if (/iP(hone|od|ad)/.test(navigator.userAgent)) {
                        // supports iOS 2.0 and later: <http://bit.ly/TJjs1V>
                        var v = (navigator.appVersion)
                                .match(/OS (\d+)_(\d+)_?(\d+)?/);
                        return parseInt(v[1], 10);
                        // return [parseInt(v[1], 10), parseInt(v[2], 10),
                        // parseInt(v[3] || 0, 10)];
                    }
                },
                getConfigProperty: function (prop) {
                    return config[prop] ? config[prop] : "";
                },
                setConfigProperty: function (prop, val) {
                    config[prop] = val;
                },
                showErrorMsg: function (container) {
                    $('.ncst-alert-row').addClass('hidden');
                    $(container).removeClass('hidden');
                },
                hideErrorMsg: function () {
                    $('.ncst-alert-row').addClass('hidden');
                },
                showSystemUnavailableMsg: function (stepNo, step, statusCode) {
                    var _errMsg, _errDes;
                    this.unlockForm();                    
                    switch(statusCode) {
                        case 401: 
                            _errMsg = "Unauthorized access";
                            _errDes = "You are not authorized to use this application. Contact the Technology Service Desk at 1.877.444.3375 to request access.";
                            break;
                        case 3000: 
                            _errMsg = "System unavailable";
                            _errDes = "";
                            break;
                        default: 
                            _errMsg = "System unavailable";
                            _errDes = "The system is currently unavailable. Please try again later.";
                            break;
                    };
                    $('#ncst-step' + stepNo + '-error-msg-header').html(_errMsg);
                    $('#ncst-step' + stepNo + '-error-msg-desc').html(_errDes);
                    this.showErrorMsg('#client-' + step + '-error-msg-cntnr');
                    window.scrollTo(0, 0);
                },
                addView: function (viewName, view) {
                    views[viewName] = view;
                },
                getView: function (viewName) {
                    return views[viewName] || null;

                },
                checkServerOutage: function (servertime) {
                var _moment, _day, _time, _serverTimeMins,_timerange, _outageStart, _outageEnd, serverDown = false;

                _moment = MomentTimezone.tz(servertime,"America/Chicago");
                _day = _moment.format('LLLL').split(',')[0].toLowerCase();
                _time = _moment.format('HH:mm');
                //console.log("server time:", _time);
                _serverTimeMins = getMinutes(_time);

                if (MainConfig.ncstOutageTime[_day] != undefined) {
                    //_outageStart = getMinutes(MainConfig.ncstOutageTime[_day].startTime);
                    //_outageEnd = getMinutes(MainConfig.ncstOutageTime[_day].endTime);
                    for (var i = 0; i < MainConfig.ncstOutageTime[_day].timerange.length; i++) {
                        _timerange = MainConfig.ncstOutageTime[_day].timerange[i].split("-");
                        _outageStart = getMinutes(_timerange[0]);
                        _outageEnd = getMinutes(_timerange[1]);

                        if (_outageStart > _outageEnd) {
                            _outageEnd += getMinutes('24:00');
                        }

                        if ((_serverTimeMins >= _outageStart) && (_serverTimeMins <= _outageEnd)) {
                            serverDown = true;
                            return serverDown;
                        } 

                    }

                }

                function getMinutes(str) {
                    var time = str.split(':');
                    return time[0] * 60 + time[1] * 1;

                };

                return serverDown;
                },
                /*** add a common class to fields in respective step to show the 
                **** error box and message which is done in validate.js
                ***/
                setServerErrValidations: function(step, errCodes) {
                    var errorCodeMaptoField = {
                        15824: {
                            1: {
                                fields: ["#i-advisor-number"],
                                className: "pa-eligibiity-failed"
                            }
                        },
                        15508: {
                            1: {
                                fields: ["#ncst-app [name='clientSex']", "#ncst-app #ci-client-honorific"],
                                className: "inconsistent"
                            }
                        },
                        15657: {
                            1: {
                                fields: ["#ncst-app #i-advisor-number"],
                                className: "invalidAdvId"
                            }
                        },
                        15666: {
                            1: {
                                fields: ["#associate-client-container"],
                                className: "entity-assoc-client"
                            }
                        },
                        15588: {
                            2: {
                                fields: ["#ncst-app .us-city-flag", "#ncst-app .us-state-flag", "#ncst-app .us-zip-flag"],
                                className: "inconsistent"
                            },
                            3: {
                                fields: [],
                                className: ""
                            }
                        },
                        15583: {
                            2: {
                                fields: ["#ncst-app .us-city-flag", "#ncst-app .us-state-flag", "#ncst-app .us-zip-flag"],
                                className: "inconsistent"
                            },
                            3: {
                                fields: [],
                                className: ""
                            }
                        },
                        404404: {
                            4: {
                                fields: ["#ncst-app button[name='clientAssociated']"],
                                className: "no-recors-found"
                            }
                        },
                        401401: {
                            4: {
                                fields: ["#ncst-app button[name='clientAssociated']"],
                                className: "not-authorized"
                            },
                            1: {
                                fields: ["#i-advisor-number"],
                                className: "not-authorized-step1"
                            }
                        },
                        15509: {
                            4: {
                                fields: ["#ncst-phone-section-container"],
                                className: "invalid-phone-number"
                            }
                        },
                        15510: {
                            4: {
                                fields: ["#ncst-phone-section-container"],
                                className: "invalid-phone-number"
                            }
                        },
                        15521: {
                            4: {
                                fields: ["#ncst-phone-section-container"],
                                className: "invalid-phone-number"
                            }
                        },
                        9: {
                            4: {
                                fields: ["#ncst-phone-section-container"],
                                className: "invalid-phone-number"
                            }
                        },
                        10: {
                            4: {
                                fields: ["#ncst-phone-section-container"],
                                className: "invalid-phone-number"
                            }
                        },
                        21: {
                            4: {
                                fields: ["#ncst-phone-section-container"],
                                className: "invalid-phone-number"
                            }
                        } 
                    };
                    underscore.each(errCodes, function(value) {
                        if (errorCodeMaptoField[value][step]) {
                            underscore.each(errorCodeMaptoField[value][step].fields, function(val) {
                                $(val+':visible').addClass(errorCodeMaptoField[value][step].className).attr("data-err-code", value);
                            });
                        }
                    });
                },
                getUrlParams : function(){
                	var regex = /[?&]([^=#]+)=([^&#]*)/g, url = window.location.href, params = {}, match;
                	//console.log(url,"url");
            		while (match = regex.exec(url)) {
            			params[match[1]] = match[2];
            		}
            		return params;
                },
                normalizeWS : function (s) {
                    s = s.match(/\S+/g);
                    return s ? s.join(' ') : '';
                },
                showDraftSaveSuccesMessage:function(){
                	var _top = $("body").css("top");
			         var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
                	$('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top': '-' + _bodytop + 'px' });
                    BootstrapDialog.show({
                        cssClass:'draftSaveSucess',
                        title: 'Draft saved',
                        message: '<div class="right-tick"></div><div>Your draft has been successfully saved. To make changes later, go to your Work in Progress page in eForms Manager to find your draft.</div>',
                        onhide: function(dialog) {
                        	$('body').removeAttr("style");
                        },
                        buttons: [{
                            label: 'OK',
                            cssClass: "btn pt-btn-yes generic-button btn-primary",
                            action: function (dialog) {
                            	$('body').removeAttr("style");
                                dialog.close();
                            }
                        }]
                    });
                },
                showDraftSaveErrorMessage:function(){
                	var _top = $("body").css("top");
			         var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
                	$('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top': '-' + _bodytop + 'px' });
                    BootstrapDialog.show({
                        cssClass:'draftSaveFailure',
                        title: 'Draft save failed',
                        message: 'Failed to save drafts.',
                        onhide: function(dialog) {
                        	$('body').removeAttr("style");
                        },
                        buttons: [{
                            label: 'OK',
                            cssClass: "btn pt-btn-yes generic-button btn-primary",
                            action: function (dialog) {
                            	$('body').removeAttr("style");
                                dialog.close();
                            }
                        }]
                    });
                },
                zeropad: function (num, numLength) {
                    var n = Math.abs(num);
                    var zeros = Math.max(0, numLength - Math.floor(n).toString().length);
                    var zeroString = Math.pow(10, zeros).toString().substr(1);
                    if (num < 0) {
                        zeroString = '-' + zeroString;
                    }
                    return zeroString + n;
                }
            };
            
            function _send(type, url, contentType, data, successHandler,
                    errorHandler, headers,maxAge, processData, xhr1) {
                headers = headers || {};
                headers = $.extend(headers, {
                    'cache-control': 'no-cache'
                });

                var response = $
                        .ajax({
                            cache: false,
                            type: type,
                            url: url,
                            processData: ((processData != null && processData != undefined) ? processData
                                    : true),
                            headers: headers,
                            contentType: contentType,
                            data: data,
                            dataType: "json",
                            success: function (res, textStatus, request) {
                                successHandler(res, textStatus, request);
                            },
                            xhr: ((xhr1 != null && xhr1 != undefined) ? xhr1
                                    : function () {
                                        return jQuery.ajaxSettings.xhr();
                                    }),
                            error: errorHandler || _genericErrorHandler,
                            maxAge : maxAge

                        });
                return response;

            }
            function _genericErrorHandler(xhr, text, status) {
                _.showSystemUnavailabelError();
            }

            return _;

        });
