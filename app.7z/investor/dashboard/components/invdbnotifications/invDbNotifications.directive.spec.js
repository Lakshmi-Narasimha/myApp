'use strict';

describe('Directive: Notifications', function() {

	var compile, scope, directiveEle, isoScope, validHtml, fticRecommAndNotifiModel;
    validHtml = '<ftic-inv-db-notifications></ftic-inv-db-notifications>';
     //load all modules, including the html template, needed to support the test

    var create = function(html) {
        var element = angular.element(html);
        var compiledElem = compile(element)(scope);
        //isoScope = directiveEle.isolateScope();
        scope.$digest();
        return compiledElem;
    };

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile, _fticRecommAndNotifiModel_) {
          scope = $rootScope.$new();
          compile = $compile;
          fticRecommAndNotifiModel = _fticRecommAndNotifiModel_;
        });
        
    });

    var notifRecomData = {
        'recomNotificationsObject': [{
            'recommendations': [{
                'recomRefNo': '1064',
                'recomId': '1',
                'recomMsg': '119 SIPs out of your SIP book with us are coming up for renewal.',
                'recomDt': '31 Aug 2016',
                'recomReq': 'Y',
                'readStatus': 'N',
                'linkText': 'SIP Renewal Details',
                'reportCode': '1008',
                'reportType': 'D,M',
                'reportFormat': 'EXCEL',
                'hoursAgo': '',
                'url': ''
            }, {
                'recomRefNo': '1097',
                'recomId': '1',
                'recomMsg': '176 SIPs out of your SIP book with us are coming up for renewal.',
                'recomDt': '30 Sep 2016',
                'recomReq': 'Y',
                'readStatus': 'N',
                'linkText': 'SIP Renewal Details',
                'reportCode': '1008',
                'reportType': 'D,M',
                'reportFormat': 'EXCEL',
                'hoursAgo': '18 Days 22 Hours 16 Minutes',
                'url': ''
            }, {
                'recomRefNo': '1065',
                'recomId': '2',
                'recomMsg': '4878000  Potential for Step Ups Message with investor list',
                'recomDt': '24 Aug 2016',
                'recomReq': 'Y',
                'readStatus': 'N',
                'linkText': 'SIP Features Details',
                'reportCode': '1009',
                'reportType': 'D,M',
                'reportFormat': 'EXCEL',
                'hoursAgo': '',
                'url': ''
            }],
            'notifications': [{
                'recomRefNo': '1127',
                'recomId': '10',
                'recomMsg': 'Commission Not Paid @@COC CoC not submitted, 665057 ARN Expiry, 8366 EUIN expiry',
                'recomDt': '31 Jul 2013',
                'recomReq': 'Y',
                'readStatus': 'N',
                'linkText': 'Commission Deatails',
                'reportCode': '1017',
                'reportType': 'D',
                'reportFormat': 'EXCEL',
                'hoursAgo': '5 Days 29 Minutes 59 Seconds',
                'url': ''
            }]
        }]
    };

    it('Directive should be defined', function() {
        var directiveEle = create(validHtml);
        expect(directiveEle).toBeDefined();
    });

    it('directive should be created with scope:true',function(){
        var directiveEle = create(validHtml);
        expect(directiveEle.scope()).toBeDefined();
	});

    it('Case-1 When data is available for Notifications Directive',function(){
        var directiveEle = create(validHtml);
        var dirScope = directiveEle.scope();
        expect(directiveEle.scope()).toBeDefined();
        fticRecommAndNotifiModel.setRecommAndNotifiReport(notifRecomData);
        scope.$broadcast('recommAndNotifiData');
        expect(dirScope.recommandNotifiData).toBeDefined();
        expect(dirScope.notificationsData).toBeDefined();
        expect(dirScope.notificationsLength).toBe(1);
        expect(dirScope.notifications.badgeCount).toBe(0);
	});
});