'use strict';

/*Unit test case for billingAccount*/

describe('directive: billingAccount', function() {

    var scope, rootScope, compile, validHTML, timeout, $httpBackend, $injector, billingFactory, $filter, billingConstants, billingInfo, billingAcctVM, paymentData;

    validHTML = '<billing-account></billing-account>';

    beforeEach(module('CSS.billing'));
    beforeEach(module('CSS.common'));
    beforeEach(module('component.tile'));
    beforeEach(module('templates'));

    billingInfo = {
            "uiErrorDisplayMessage": "",
            "transactionStatus": "S",
            "transactionDescription": "",
            "transactionCode": "",
            "region": "",
            "postalCode": "60606",
            "policies": [{
                "policyContractNumber": "900500520",
                "lineOfBusiness": "HOME"
            },{
                "policyContractNumber": "230500520",
                "lineOfBusiness": "AUTO"
            }, {
                "policyContractNumber": "560500520",
                "lineOfBusiness": "UMBRELLA"
            }, {
                "policyContractNumber": "140500520",
                "lineOfBusiness": "AUTO"
            }],
            "paymentPlanCode": "MT",
            "paymentPlanCodeDesc": "MONTHLY",
            "billingScheduledMaintenance": "N",
            "estimatedDowntime": "01:56:07",
            "systemDateTime": "2016-01-01T11:59:04.159Z",
            "paymentDueDate": "2016-01-03",
            "outStandingAmountCurrency": "USD",
            "outStandingAmount": "50000.00",
            "minPaymentDueAmountCurrency": "USD",
            "minPaymentDueAmount": "23000.00",
            "isMultiPolicyAccount": "N",
            "fullName": "GAYLE JOHNSON",
            "city": "Princeton",
            "billingAccountNumber": "T718142962",
            "agentOfRecord": "13053T",
            "addressLine1": "1119 Fairway Dr",
            "accountStatus": "Active",
            "loginURL": "https://csstw.farmers.com/",
            "registerURL": null
        };

    paymentData = {
        paymentListNow : {
            isCard: true
        }
    }

    beforeEach(function() {
        module(function($provide) {
            $provide.constant('componentConstant', {
                'policy_status_constants': {
                    'active': 'A',
                    'cancelled': 'C',
                    'expired': 'E'
                }
            });
        });
    });
    beforeEach(inject(function($compile, $rootScope, $timeout, $httpBackend, $injector, billingUtils) {
        scope = $rootScope.$new();
        compile = $compile;
        timeout = $timeout;
        rootScope = $rootScope;

        billingFactory = billingUtils;
        
        // $httpBackend = $injector.get('$httpBackend');
    }));

    function create() {
        var elem, compiledElem;/**/
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();
        return compiledElem;
    }

    describe('when changing the scope values', function() {

        beforeEach(function() {    
            validHTML = "<billing-account></billing-account>";
            scope.$digest();
        });

        it('should have a populated scope', function() {

            var el = create();
            var isolate = el.isolateScope();
            billingFactory.setBillingData(billingInfo);
            expect(billingFactory.setBillingData).toBeDefined();
        });
    });

    describe('when calling the functions', function() {

        beforeEach(function() {  
            validHTML = "<billing-account></billing-account>";
            scope.$digest();
        });

        it('should define billingAcctVM.switchPayBills', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            expect(billingFactory.setBillingData).toBeDefined()
            el.find(".btn-farmers-off-white").trigger('click');
        });

        it('should define billingAcctVM.isOverPayment function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();

            el.isolateScope().billingAcctVM.isOverPayment(billingInfo);
        });

        it('should define billingAcctVM.validateSubmitPayment function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            el.isolateScope().billingAcctVM.validateSubmitPayment(billingInfo);
        });

        it('should define billingAcctVM.isValidAmount function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            el.isolateScope().billingAcctVM.isValidAmount(billingInfo);
        });

        it('should define billingAcctVM.isAmountShort function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            el.isolateScope().billingAcctVM.isAmountShort(billingInfo);
        });

        it('should define billingAcctVM.isAmountLarger function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            el.isolateScope().billingAcctVM.isAmountLarger(billingInfo);
        });

        it('should define billingAcctVM.isPayDateAfterDueDate function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            el.isolateScope().billingAcctVM.isPayDateAfterDueDate(billingInfo);
        });

        // it('should define billingAcctVM.printConfirmation function', function() {
        //     billingFactory.setBillingData(billingInfo);
        //     var el = create();
        //     var isolate = el.isolateScope();
            
        //     // paymentData.paymentListNow.isCard = true;
        //     el.isolateScope().billingAcctVM.printConfirmation();
        // });

        it('should define submitted function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            rootScope.$emit('submitted', {});
        });

        it('should define cancelPaymentMethod function', function() {
            billingFactory.setBillingData(billingInfo);
            var el = create();
            var isolate = el.isolateScope();
            
            rootScope.$broadcast('cancelPaymentMethod');
        });
    });
});
