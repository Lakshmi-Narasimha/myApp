'use strict';
describe('Controller: dtpController', function() {
	var $controller,$scope,dtpController,TransactConstant,transactModel,fundDetailsModel,swpInitialLoader;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_TransactConstant_,_transactModel_,_fundDetailsModel_,_swpInitialLoader_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();
		
		TransactConstant = _TransactConstant_;
		transactModel = _transactModel_;
		fundDetailsModel = _fundDetailsModel_;
		swpInitialLoader = _swpInitialLoader_;
		$scope.config = {"txnFormDetails":{}};	
		$scope.header = {"title": ""};
		spyOn(swpInitialLoader,"loadAllServices");
		loadController();			
	}));	

	function loadController(){
        dtpController = $controller('dtpController', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(dtpController).toBeDefined();
    });

    it('should define the variables config,header',function(){    	
    	expect($scope.config.txnFormDetails.title).toBe('Dividends Transfer Details');
    	expect($scope.header.title).toBe("Start a DTP");
    	expect(transactModel.isSWP).toBe(true);
    	expect(fundDetailsModel.getInvestorType()).toBe(true);    	 
    	expect(swpInitialLoader.loadAllServices).toHaveBeenCalledWith($scope);
    });
});