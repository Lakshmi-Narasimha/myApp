/**
 * @ngdoc service
 * @name user emailids inital loader service
 * @requires frequencyOptionsModel
 * @requires transactEvents
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - 
 *
 */
'use strict';

var frequencyOptionsInitLoader = function (frequencyOptionsModel, transactEvents, fticLoggerMessage, loggerConstants, authenticationService, $loader) {
    
    var frequencyOptionsInitLoader = {
        _isServicesData: false,     
        loadAllServices : function (scope) {

            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.TRANSACT_MODULE + ' | ' + loggerConstants.FREQUENCY_OPTIONS_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            
            var  params = {};
            params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;;
            if(frequencyOptionsModel.getAmountFormType().formType === 'STPFORM'){
                if(frequencyOptionsModel.getAmountFormType().amountType === 'FIXEDAMOUNT'){
                    params.groupId = 'STPFreqFA';
                }else if(frequencyOptionsModel.getAmountFormType().amountType === 'CAPITAL'){
                    params.groupId = 'STPFreqCA';
                }
            } else if(frequencyOptionsModel.getAmountFormType().formType === 'SWPFORM'){
                if(frequencyOptionsModel.getAmountFormType().amountType === 'FIXEDAMOUNT'){
                    params.groupId = 'SWPFreqFA';
                }else if(frequencyOptionsModel.getAmountFormType().amountType === 'CAPITAL'){
                    params.groupId = 'SWPFreqCA';
                }
            };

            $loader.start();       
            frequencyOptionsModel.fetchFrequencyOptions(params)
                .then(frequencyOptionsSuccess, handleFailure)
                .finally(function() {
                    $loader.stop(); 
                });

            function frequencyOptionsSuccess(data) {
                frequencyOptionsModel.setFrequencyOptions(data.codeValueList);
                transactEvents.transact.publishFrequencyOptions(scope);

            };

            function handleFailure (data) {
                console.error('handleFailure');
                frequencyOptionsInitLoader._isServicesData = false;

            };
        }
        
    };
    return frequencyOptionsInitLoader;
};

frequencyOptionsInitLoader.$inject = ['frequencyOptionsModel', 'transactEvents', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', '$loader'];

module.exports = frequencyOptionsInitLoader;