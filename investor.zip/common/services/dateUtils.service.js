/**
 * @ngdoc factory
 * @name dateUtils
 * @description
 *
 * - This factory is help to format dates and provides utilty methods
 *
 */

'use strict';

var dateUtils = function() {
    return {
        isToDateGreater: false,
        isValidDate: false,
        getYesterday: function(selDate) {
            var date = selDate ? new Date(selDate) : new Date();
            var yesterday = new Date(date.getTime());
            yesterday.setDate(date.getDate() - 1);
            return yesterday;
        },
        checkValidDateRange: function(toDate, fromDate) {
            this.isToDateGreater = false;
            if (toDate && fromDate) {
                var validateToDate = this.formateDatepickerValue(toDate);
                var validateFromDate = this.formateDatepickerValue(fromDate);
                this.isToDateGreater = (new Date(validateFromDate) >= new Date(validateToDate));
            }

            return this.isToDateGreater;
        },
        checkIsValidDate: function(dateHolderObj, isToDateGreater) {
            this.isValidDate = false;
            if (dateHolderObj.dayFlag === 'AD') {
                this.isValidDate = dateHolderObj.fromDate ? true : false;
            } else if (dateHolderObj.dayFlag === 'DR') {
                this.isValidDate = dateHolderObj.fromDate && dateHolderObj.toDate && !isToDateGreater ? true : false;
            } else {
                this.isValidDate = (dateHolderObj.dayFlag === 'DF' || dateHolderObj.dayFlag === 'LFY' || dateHolderObj.dayFlag === 'SI' || dateHolderObj.dayFlag === 'LM' || dateHolderObj.dayFlag === 'LQ' || dateHolderObj.dayFlag === 'LH' || dateHolderObj.dayFlag === 'L1Y') ? true : false;
            }

            return this.isValidDate;
        },
        formateDatepickerValue: function(dateParam) {
            var newDate;
            newDate = dateParam && dateParam.split('/').length > 0 ? (dateParam.split('/')[1] + '/' + dateParam.split('/')[0] + '/' + dateParam.split('/')[2]) : dateParam;
            return newDate;
        }

    };
};

dateUtils.$inject = [];
module.exports = dateUtils;
