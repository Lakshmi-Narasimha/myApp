/**
 * @ngdoc property
 * @name Smart Solutions Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Smart solutions controller for guest module.
 *
 **/
'use strict';
function smartSolutionsController($scope,$uibModal,transactModel, investorDashboardDetailsModel, recommendedPlanInitialLoader) {
  $scope.header = {};
  $scope.config = {};
	$scope.config.stepsConfig = {};
	$scope.config.stepsConfig.activeStep = 1;
	$scope.config.stepsConfig.noOfSteps = 3;
  transactModel.setIsSmartSol(true);
 // transactModel.setFlowType("advisor");

  /*$scope.$emit("setBreadCrumb",{
        cat : "smart",
        breadCrumb :{
            label:'Smart Solutions',
            state : ''
        }       
    });*/
  var panLevelInvModalFlag = false;
  $scope.$on('panLevelInvModalEvent', function($event, flag){
    if(flag === 'FS') {
      var modalInstance = $uibModal.open({
        template : require('./investorgoaltracking/components/panLevelInvModal/panLevelInvModal.html'),
        scope : $scope
      });
    }
  });

  $scope.$on('showPANLevelInvModal',function(){
     var panNo,
         userDetails = investorDashboardDetailsModel.getDashboardData();
      if(userDetails) {
          panNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
      }
      //panNo = 'CNKQQ9569X';
      recommendedPlanInitialLoader.loadPanlLevelServices(panNo, $scope);
      
  });
  
}

smartSolutionsController.$inject = ['$scope','$uibModal','transactModel', 'investorDashboardDetailsModel', 'recommendedPlanInitialLoader'];
module.exports = smartSolutionsController;