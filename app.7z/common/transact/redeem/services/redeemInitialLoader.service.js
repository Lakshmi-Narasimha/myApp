'use strict';

var redeemInitialLoader = function (redeemModel, transactEventConstants, transactEvents) {
    
    var redeemInitialLoader = {
    	loadAllServices : function (scope) {                    	

            redeemModel.fetchBankDetails().then(redeemSuccess, handleFailure);

            function redeemSuccess (data) {
                redeemModel.setBankDetails(data);
                transactEvents.transact.publishRedeemDetails(scope);
            }
            function handleFailure (data) {
                console.log('handleFailure');
            }
        }
    };
    return redeemInitialLoader;
};

redeemInitialLoader.$inject = ['redeemModel', 'transactEventConstants', 'transactEvents'];
module.exports = redeemInitialLoader;
