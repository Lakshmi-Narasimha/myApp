﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appcommon/commonutility',
  'services/dataservice',
  'appmodules/nav/app/models/editcontact',
  'apipublic/navapi',
  'appcommon/constants',
  'appmodules/nav/navvalidate',
  'text!appmodules/nav/app/templates/editcontact.html',
  'appcommon/analytics',
  'errorLog'
], function ($, _, Backbone, Spinner, CommonUtils, Dataservice, EditcontactModel, NavApi, Constants, NavValidator, EditContactTemplate, Analytics, ErrorLog) {
    var editcontact = Backbone.View.extend({
        template: _.template(EditContactTemplate),
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click #edit-contact-save": "editContact",
            "click #edit-contact-cancel": "handleCancel",
            "click #back-to-cp": "backToCP",
            "keyup .jump": "autoJumpToFields",
            "keypress #edit-contact .number": "isNumber",
            "click #addPh": "addPhDynamicFields",
            "click #addEmail": "addEmailDynamicFields",
            "click #addaddress": "addAddressDynamicFields",
            "click .delPh, .delEmail, .delAddress": "delDynamicFields",
           // "focus .jump": "highlightTheField",
            "click input[type='tel']" : "highlightTheField",
            //"focus input[type='tel']": "highlightTheField",
            "input #edit-contact input" : "listenValueUpdate",
            "change #edit-contact select": "listenValueUpdate",
            "click  .container-fluid": "hideIOSKeyboard",
            "click .cd-inter-checkbox": "internationalNoCheck",
        },
        initialize: function () {
        	this.isClient = true;
        	this.contactId = null;
        	this.deletedPhones = [];
        	this.deletedEmails = [];
        	this.deletedAddress = [];
        	this.type = null;
        	this.contactType = null;
        },
        handleCancel: function () {
            BootstrapDialog
				.confirm(
						"Cancel",
						"All your work will be lost.  Are you sure you want to cancel?",
						function (confirm) {
							if (confirm) {
							    window.scrollTo(0, 0);
							    Backbone.history.navigate("#contactprofile/", true);
							}

						}, 'edit-contact');
        },
        backToCP: function () {

            BootstrapDialog
					.confirm(
							"Cancel",
							"All your work will be lost.  Are you sure you want to continue?",
							function (confirm) {
							    if (confirm) {
							        window.scrollTo(0, 0);
							        Backbone.history.navigate("#contactprofile/", true);
							    }

							}, 'edit-contact');



        },
        scrollToSpecificId: function (idObj){
            // Scroll
            $('html,body').animate({ scrollTop: $("#"+idObj).offset().top},'slow');
        },
        // for international phone no in edit contact profile
        internationalNoCheck: function (event) {
            var _currTgt = $(event.currentTarget), internationalInputId, currBlock;
            internationalInputId = _currTgt.data('toggle');
            currBlock = _currTgt.attr('id');
            var phoneID = $('#' + currBlock).closest('div[class^="row cm-white-background phone-block"]').attr('id');

            $("#" + phoneID).find("input[type=text]").val("");
            $("#" + phoneID).find("input[type=tel]").val("");

            if (_currTgt.find('input').prop('checked')) {
                this.$('#edit-contact-ph').find('#' + phoneID + ' .textbox-wrapper').addClass('hidden');
                this.$('#edit-contact-ph').find('#' + phoneID + ' #' + internationalInputId).removeClass('hidden');
            } else {
                this.$('#edit-contact-ph').find('#' + phoneID + ' .textbox-wrapper').addClass('hidden');
                this.$('#edit-contact-ph').find('#' + phoneID + ' .default').removeClass('hidden');
            }
        },
        delDynamicFields: function (e) {
        	var target = e.target || e.currentTarget;
        	var that = this;
            BootstrapDialog
				.confirm(
				    "Delete",
				    "Click Yes to delete!",
				    function (confirm) {
					    if (confirm) {
						    var targetId = target.id;
						    var getIncValFromId = targetId.split("-");
						    if (getIncValFromId[0].indexOf('Ph') != -1) {
						    	that.deletedPhones.push($(target).data("id"));
						        $("#phcontainer-" + getIncValFromId[1]).remove();
						    } else if (getIncValFromId[0].indexOf('Email') != -1) {
						    	that.deletedEmails.push($(target).data("id"));
						        $("#emailcontainer-" + getIncValFromId[1]).remove();
						    } else if (getIncValFromId[0].indexOf('Address') != -1) {
						    	that.deletedAddress.push($(target).data("id"));
						        $("#addresscontainer-" + getIncValFromId[1]).remove();
						    }
					    }
				    }, 'edit-contact');
        },
        addPhDynamicFields: function (e) {
            e.preventDefault();
            var that = this;
            var targetClName = e.currentTarget.className.split(' ')[0];
            var divCount = $("div[id^='" + targetClName + "']").length;
            var lastDivId = '';
            var getLastDivId = '';
            var newCount = 0;
            var newId = '';
            if (divCount > 0) {
                lastDivId = $("div[id^='" + targetClName + "']").last().attr('id');
                getLastDivId = lastDivId.split("-");
                newCount = parseInt(getLastDivId[1]) + 1;
                newId = getLastDivId[0] + "-" + newCount;
            }

            $("#edit-contact-ph").append(
               '<div class="row cm-white-background phone-block" data-for="error-valid-holder-' + newCount + '" id="phcontainer-' + newCount + '"><div class="row pt-container"><div class="col-sm-3 col-lg-2 pt-verticalCtr"><label class="pt-data-label" for="home-phone">Phone type</label></div>' +
                '<div class="col-xs-12 col-sm-9 col-md-7 col-lg-6"><div class="phType"><select class="phTypeDropDwn form-control" id="phTypeDropDwnId' + newCount + '"><option selected="selected" value="0">Select Type</option><option value="1">Home</option><option value="1">Home (Contact Manager)</option><option value="16004">Home - TTY/TDD (Contact Manager)</option><option value="2">Business</option><option value="2">Business (Contact Manager)</option><option value="4">Business Fax (Contact Manager)</option><option value="16005">Business - TTY/TDD (Contact Manager)</option><option value="10">Mobile</option><option value="10">Mobile (Contact Manager)</option><option value="16001">Mobile - Business (Contact Manager)</option><option value="13">Fax - Home (Contact Manager)</option><option value="16006">Other 1</option><option value="16006">Other 1 (Contact Manager)</option><option value="16007">Other 2</option><option value="16007">Other 2 (Contact Manager)</option></select><div class="clearfix"></div></div>' +
                '<div class="phTxtVa' + newCount + '">' +
                '<label class="error hidden">Incomplete required field.</label><div class="textbox-wrapper default">' +
                '<div class="col-xs-3 col-sm-2 col-md-2 phone-a"><input id="ph' + newCount + '-part-a" name="ph' + newCount + '-part-a" value="" type="tel" data-jumpto="ph' + newCount + '-part-n1" class="xs-offset-right-1 form-ctrl jump number homephone pt-h5 number-validate movetonext" data-minlength=3 maxlength="3"></div>' +

                '<div class="col-xs-3 col-sm-2 col-md-2 phone-n1"><input data-master-container="error-valid-holder-' + newCount + '" id="ph' + newCount + '-part-n1" name="ph' + newCount + '-part-n1" value="" type="tel" data-jumpto="ph' + newCount + '-part-n2" class="xs-offset-right-1 form-ctrl jump number homephone pt-h5 number-validate movetonext required" data-minlength=3 maxlength="3"><span class="requiredTxt">(required)</span></div>' +

                '<div class="col-xs-4 col-sm-3 col-md-3 phone-n2"><input data-master-container="error-valid-holder-' + newCount + '" id="ph' + newCount + '-part-n2" name="ph' + newCount + '-part-n2" value="" type="tel" data-jumpto="ph' + newCount + '-part-e" class="xs-offset-right-1 form-ctrl jump number homephone pt-h5 number-validate movetonext required" data-minlength=4 maxlength="4"><span class="requiredTxt">(required)</span></div></div>' +

                '<div id="cd-home-int" class="textbox-wrapper hidden"><div class="col-sm-2  col-xs-3 col-md-2 pad-zero xs-offset-right-1"><input data-master-container="error-valid-holder-' + newCount + '" id="cd-homephone-int-country-' + newCount + '" name="cd-homephone-int-country-' + newCount + '" data-jumpto="cd-homephone-int-number-' + newCount + '" value="" type="tel" class="form-ctrl col-sm-12  col-xs-12 col-md-12 homephone pt-h5 jump countrycode-validate required" maxlength="3"><label class="pt-h7">Country</label><span class="requiredTxt">(required)</span></div>' +
                '<div class="xs-offset-right-1 xs-pad-zero col-sm-5  col-xs-7 col-md-5"><input data-master-container="error-valid-holder-' + newCount + '" id="cd-homephone-int-number-' + newCount + '" name="cd-homephone-int-number-' + newCount + '" value="" type="tel" class="form-ctrl col-sm-12  col-xs-12 col-md-12 number homephone pt-h5 jump number-validate required" maxlength="15"><label class="pt-h7">Number</label><span class="requiredTxt">(required)</span></div></div>' +
    
                '<div class="col-xs-7 col-sm-4 col-md-4 col-lg-4 phone-e"><label class="pull-left extLbl pt-data-label">ext</label><input type="tel" id="ph' + newCount + '-part-e" name="ph' + newCount + '-part-e" class="form-ctrl number inputPh' + newCount + '-E" maxlength="6" value=""></div>' +    

                '</div></div></div>' +

                '<div class="row pt-container"><div class="col-md-12 col-sm-12 col-xs-12"><div><label class="custom-input-container cl-details cd-inter-checkbox pt-white-checkbox" id="cp-phone-int-contnr-' + newCount + '" data-toggle="cd-home-int" data-block="cd-homephone-inputs"><input id="cp-phone-int-' + newCount + '" class="value-selection" data-index="0" type="checkbox"> <label class="custom-checkbox"></label><label for="cp-phone-int-' + newCount + '" id="cp-' + newCount + '-phone-int-label" class="custom-int-cp pt-h7 cust-marg-int-ph">International</label></label></div></div>' +
                '<div class="row pt-container hello"><div class="col-sm-3 col-lg-2"><a href="javascript:void(0);" class="delPh del-icon" id="delPh-' + newCount + '">Delete phone</a></div></div></div>'
            );
            that.scrollToSpecificId("phcontainer-" + newCount);
            //Defect #789 
            if ((navigator.userAgent.match(/iPhone/i))) {
                document.getElementById("phTypeDropDwnId" + newCount).focus();
            } else {
                setTimeout(function () {
                    document.getElementById("phTypeDropDwnId" + newCount).focus();
                }, 300);
            }
         },
        addEmailDynamicFields: function (e) {
            e.preventDefault();
            var that = this;
            var targetClName = e.currentTarget.className.split(' ')[0];
            var divCount = $("div[id^='" + targetClName + "']").length;
            var lastDivId='';
            var getLastDivId = '';
            var newCount = 0;
            if (divCount > 0) {
                lastDivId = $("div[id^='" + targetClName + "']").last().attr('id');
                getLastDivId = lastDivId.split("-");
                newCount = parseInt(getLastDivId[1]) + 1;
            }

            $("#edit-contact-email").append(
                '<div class="row cm-white-background email-block" for="inputEmail' + newCount + '" id="emailcontainer-' + newCount + '"><div class="row pt-container"><div class="col-sm-3 col-lg-2"><span class="add-prospect-adjust-left">&nbsp;</span><label for="home-phone" class="pt-data-label">Email address</label><span class="requiredTxt">(required)</span></div>' +
                '<div class="col-sm-9 col-xs-12 col-md-7 col-lg-6">' +
                //'<div class="emailType"><select class="emailTypeDropDwn form-control" id="emailTypeDropDwnId' + newCount + '"><option value="1">Email</option></select><div class="clearfix"></div></div>' +
                '<div class="emailTxtVal"><label class="error hidden">Incomplete required field.</label><input name="email1" maxlength="100" type="text" id="inputEmail' + newCount + '" class="form-control inputEmail required email" value="" /><div class="clearfix"></div></div></div></div>' +
                '<div class="row pt-container"><div class="col-sm-3 col-lg-2"><a href="javascript:void(0);" class="delEmail del-icon" id="delEmail-' + newCount + '">Delete email</a></div></div></div>'
            );
            that.scrollToSpecificId("emailcontainer-" + newCount);
            //Defect #789 
            document.getElementById("inputEmail" + newCount).focus();
        },
        addAddressDynamicFields: function (e) {
            e.preventDefault();
            var that = this;
            var targetClName = e.currentTarget.className.split(' ')[0];
            var divCount = $("div[id^='" + targetClName + "']").length;
            var lastDivId = '';
            var getLastDivId = '';
            var newCount = 0;
            var drpStateOption = '';
            if (divCount > 0) {
                lastDivId = $("div[id^='" + targetClName + "']").last().attr('id');
                getLastDivId = lastDivId.split("-");
                newCount = parseInt(getLastDivId[1]) + 1;
            }

            //State Types
            var StateTypes = new Object();
            StateTypes['AL'] = 'Alabama';
            StateTypes['AK'] = 'Alaska';
            StateTypes['AZ'] = 'Arizona';
            StateTypes['AR'] = 'Arkansas';
            StateTypes['CA'] = 'California';
            StateTypes['CO'] = 'Colorado';
            StateTypes['CT'] = 'Connecticut';
            StateTypes['DE'] = 'Delaware';
            StateTypes['DC'] = 'District of Columbia';
            StateTypes['FL'] = 'Florida';
            StateTypes['GA'] = 'Georgia';
            StateTypes['HI'] = 'Hawaii';
            StateTypes['ID'] = 'Idaho';
            StateTypes['IL'] = 'Illinois';
            StateTypes['IN'] = 'Indiana';
            StateTypes['IA'] = 'Iowa';
            StateTypes['KS'] = 'Kansas';
            StateTypes['KY'] = 'Kentucky';
            StateTypes['LA'] = 'Louisiana';
            StateTypes['ME'] = 'Maine';
            StateTypes['MD'] = 'Maryland';
            StateTypes['MA'] = 'Massachusetts';
            StateTypes['MI'] = 'Michigan';
            StateTypes['MN'] = 'Minnesota';
            StateTypes['MS'] = 'Mississippi';
            StateTypes['MO'] = 'Missouri';
            StateTypes['MT'] = 'Montana';
            StateTypes['NE'] = 'Nebraska';
            StateTypes['NV'] = 'Nevada';
            StateTypes['NH'] = 'New Hampshire';
            StateTypes['NJ'] = 'New Jersey';
            StateTypes['NM'] = 'New Mexico';
            StateTypes['NY'] = 'New York';
            StateTypes['NC'] = 'North Carolina';
            StateTypes['ND'] = 'North Dakota';
            StateTypes['OH'] = 'Ohio';
            StateTypes['OK'] = 'Oklahoma';
            StateTypes['OR'] = 'Oregon';
            StateTypes['PA'] = 'Pennsylvania';
            StateTypes['RI'] = 'Rhode Island';
            StateTypes['SC'] = 'South Carolina';
            StateTypes['SD'] = 'South Dakota';
            StateTypes['TN'] = 'Tennessee';
            StateTypes['TX'] = 'Texas';
            StateTypes['UT'] = 'Utah';
            StateTypes['VT'] = 'Vermont';
            StateTypes['VA'] = 'Virginia';
            StateTypes['WA'] = 'Washington';
            StateTypes['WV'] = 'West Virginia';
            StateTypes['WI'] = 'Wisconsin';
            StateTypes['WY'] = 'Wyoming';
            
            $.each(StateTypes, function (key, value) {
                if (key == 'AL') {
                    drpStateOption = drpStateOption + '<option value=' + key + '>' + value + '</option>';
                }
                else {
                    drpStateOption = drpStateOption + '<option value=' + key + '>' + value + '</option>';
                }
            });
            drpStateOption = '<option value="" selected="selected">Choose one</option>'+drpStateOption;
            $("#edit-contact-address").append('<div class="row cm-white-background address-block" id="addresscontainer-' + newCount + '"><div class="row pt-container"><div class="col-sm-3 col-lg-2 pt-verticalCtr"><label class="pt-data-label">Address type</label></div>' +
                '<div class="col-sm-9 col-xs-12 col-md-7 col-lg-6 "><div class="addressType"><select class="addrsTypeDropDwn form-control" id="addrsTypeDropDwnId' + newCount + '"><option selected="selected" value="">Select Type</option><option value="1">Home</option><option value="2">Business</option><option value="3">Vacation</option><option value="7">Other</option><option value="16003">Second Home</option></select>'+
                '<div class="clearfix"></div></div></div></div>'+
                '<div class="row pt-container" for="priAddress' + newCount + '"><div class="col-sm-3 col-lg-2"><span class="add-prospect-adjust-left">&nbsp;</span><label class="pt-data-label">Address line 1</label><span class="requiredTxt">(required)</span></div><div class="col-sm-9 col-xs-12 col-md-7 col-lg-6 "><label class="error hidden">Incomplete required field.</label><input type="text" id="priAddress' + newCount + '" maxlength="30" value="" class="form-control priAddress1 required us-address-1" name="priAddress' + newCount + '"></div></div>' +
                '<div class="row pt-container"><div class="col-sm-3 col-lg-2 pt-verticalCtr"><label class="pt-data-label">Address line 2</label></div><div class="col-sm-9 col-xs-12 col-md-7 col-lg-6 "><label class="error hidden">Incomplete required field.</label><input type="text" id="optAddress' + newCount + '" maxlength="30" value="" class="form-control optAddress' + newCount + '" name="optAddress' + newCount + '"></div></div>' +
                '<div class="row pt-container" for="city' + newCount + '"><div class="col-sm-3 col-lg-2"><span class="add-prospect-adjust-left">&nbsp;</span><label class="pt-data-label">City</label><span class="requiredTxt">(required)</span></div><div class="col-sm-9 col-xs-12 col-md-7 col-lg-6 "><label class="error hidden">Incomplete required field.</label><input type="text" id="city' + newCount + '" maxlength="90" value="" class="form-control city' + newCount + ' required" name="city' + newCount + '"></div></div>' +
                '<div class="row pt-container"><div class="col-sm-3 col-lg-2 pt-verticalCtr"><label class="pt-data-label" for="state">State</label></div><div class="col-sm-9 col-xs-12 col-md-7 col-lg-6 "><select id="stateAddress' + newCount + '" class="form-control stateAddress' + newCount + ' stateDropDwn">' + drpStateOption + '</select></div></div>' +
                '<div class="row pt-container"><div class="col-sm-3 col-lg-2 pt-verticalCtr"><label class="pt-data-label" for="zipCode' + newCount + '">Zip code</label></div><div class="col-sm-9 col-xs-12 col-md-7 col-lg-6"><label class="error hidden">Incomplete required field.</label><input type="text" id="zipCode' + newCount + '" value="" class="form-control col-sm-5 col-xs-5 col-md-5 col-lg-5"></div></div>' +
                '<div class="row pt-container"><div class="col-sm-3 col-lg-2"><a href="javascript:void(0);" class="delAddress del-icon" id="delAddress-' + newCount + '">Delete address</a></div></div></div>'
            );

            that.scrollToSpecificId("addresscontainer-" + newCount);
            //Defect #789 
            if ((navigator.userAgent.match(/iPhone/i))) {
                document.getElementById("addrsTypeDropDwnId" + newCount).focus();
            } else {
                setTimeout(function () {
                    document.getElementById("addrsTypeDropDwnId" + newCount).focus();
                }, 300);
            }
                 
        },
        editContact: function () {
            try {
                var _that = this;
                /*if(_that.isClient){
                	alert("Edit on a client is not yet available");
                	return true;
                }*/
                if (!NavValidator.validateInputs('edit-contact')) {
                    return;
                }

                var contact = new EditcontactModel.Contact();
                contact.set("id", _that.contactId);
                contact.set("type", _that.type);
                contact.set("contactType", _that.contactType);
                
                contact.set("remarks", ($.trim($("#editContactRemarks").html()) || ""));
                contact.set("employerName", $("#editContactEN").val());
                var _contactSubType = $("#sub-contact-type").val();
                _contactSubType = _contactSubType?_contactSubType:"";
                contact.set("contactSubType", _contactSubType);
                //Phone numbers
                var phoneBlocks = $(".phone-block");
                var addPhones = "";
                var editPhones = "";
                if(phoneBlocks && phoneBlocks.length>0){
                	$.each(phoneBlocks,function(key, row){
                		//Update existing phone
                		if($($(row).find('input[type=tel]')[1]).val() && $($(row).find('input[type=tel]')[2]).val()){
                			if($(row).find('.delPh').data("id") && $(row).find('.delPh').data("user-edited")){
                    			var tmptEditPhone = "PId="+$(row).find('.delPh').data("id");
                    				tmptEditPhone+= "|PType="+ ($(row).find('.phTypeDropDwn').val() || '#$#');
                    				tmptEditPhone+= "|PNo="+ ($($(row).find('input[type=tel]')[1]).val() || '#$#')+ ($($(row).find('input[type=tel]')[2]).val() || '#$#');
                    				tmptEditPhone+= "|PAc="+ ($($(row).find('input[type=tel]')[0]).val() || '#$#');
                    				tmptEditPhone += "|PEx=" + ($($(row).find('input[type=tel]')[5]).val() || '#$#');
                    				tmptEditPhone += "|PCc=" + ('#$#');
                    				tmptEditPhone += "~";
                    				editPhones += tmptEditPhone;
                    		}
                    		//Add new phone
                    		else if(!$(row).find('.delPh').data("id")){
                    			var tmptAddPhone = "PId="
                    				tmptAddPhone+= "|PType="+($(row).find('.phTypeDropDwn').val() || '#$#');
    	                			tmptAddPhone+= "|PNo="+($($(row).find('input[type=tel]')[1]).val() || '#$#')+ ($($(row).find('input[type=tel]')[2]).val() || '#$#' );
    	                			tmptAddPhone+= "|PAc="+ ($($(row).find('input[type=tel]')[0]).val() || '#$#');
    	                			tmptAddPhone += "|PEx=" + ($($(row).find('input[type=tel]')[5]).val() || '#$#');
    	                			tmptAddPhone += "|PCc=" + ('#$#');
    	                			tmptAddPhone += "~";
    	                			addPhones += tmptAddPhone;
                    		}
                		}
                	    //for international number
                		if (($($(row).find('input[type=tel]')[3]).val() && $($(row).find('input[type=tel]')[4]).val())) {
                		    if ($(row).find('.delPh').data("id") && $(row).find('.delPh').data("user-edited")) {
                		        var tmptEditPhone = "PId=" + $(row).find('.delPh').data("id");
                		        tmptEditPhone += "|PType=" + ($(row).find('.phTypeDropDwn').val() || '#$#');
                		        tmptEditPhone += "|PNo=" + ($($(row).find('input[type=tel]')[4]).val() || '#$#');
                		        tmptEditPhone += "|PAc=" + ($($(row).find('input[type=tel]')[0]).val() || '#$#');
                		        tmptEditPhone += "|PEx=" + ($($(row).find('input[type=tel]')[5]).val() || '#$#');
                		        tmptEditPhone += "|PCc=" + ($($(row).find('input[type=tel]')[3]).val() || '#$#');
                		        tmptEditPhone += "~";
                		        editPhones += tmptEditPhone;
                		    }
                		        //Add new phone
                		    else if (!$(row).find('.delPh').data("id")) {
                		        var tmptAddPhone = "PId="
                		        tmptAddPhone += "|PType=" + ($(row).find('.phTypeDropDwn').val() || '#$#');
                		        tmptAddPhone += "|PNo=" + ($($(row).find('input[type=tel]')[4]).val() || '#$#');
                		        tmptAddPhone += "|PAc=" + ($($(row).find('input[type=tel]')[0]).val() || '#$#');
                		        tmptAddPhone += "|PEx=" + ($($(row).find('input[type=tel]')[5]).val() || '#$#');
                		        tmptAddPhone += "|PCc=" + ($($(row).find('input[type=tel]')[3]).val() || '#$#');
                		        tmptAddPhone += "~";
                		        addPhones += tmptAddPhone;
                		    }
                		}
                		
                	});
                }
                //Removing default characters
                addPhones = addPhones.split('#$#').join('');
                editPhones = editPhones.split('#$#').join('');
                
                
                //contact.set("Phones", addPhones);
                contact.set("EditedPhone", addPhones+editPhones);
                //Phones to be deleted
                contact.set("TobeDeletedPhone", _that.deletedPhones.join("~"));
                
              //Emails 
                var emailBlocks = $(".email-block");
                var addemails = "";
                var editemails = "";
                if(emailBlocks && emailBlocks.length>0){
                	$.each(emailBlocks,function(key, row){
                		//Update existing email
                		if($(row).find('.delEmail').data("id") && $(row).find('.delEmail').data("user-edited")){
                			var tmptEditemail = "EId="+ ($(row).find('.delEmail').data("id") || '#$#');
                				//tmptEditemail+= "|EType="+($(row).find('.emailTypeDropDwn').val() || '#$#');
                				tmptEditemail+= "|EType=1";
                				tmptEditemail+= "|Email="+($($(row).find('input[type=text]')[0]).val() || '#$#');
                				tmptEditemail+="~";
                				editemails += tmptEditemail;
                		}
                		//Add new email
                		else if(!$(row).find('.delEmail').data("id")){
                			var tmptAddemail = "EId="
                				//tmptAddemail+= "|EType="+ ($(row).find('.emailTypeDropDwn').val() || '#$#');
                				tmptAddemail+= "|EType=1";
	                			tmptAddemail+= "|Email="+ ($($(row).find('input[type=text]')[0]).val() || '#$#');
	                			tmptAddemail+="~";
	                			addemails += tmptAddemail;
                		}
                		
                	});
                }
                //Removing default characters
                addemails = addemails.split('#$#').join('');
                editemails = editemails.split('#$#').join('');
                
                //contact.set("WebAddresses", addemails);
                contact.set("EditedWebAddress", addemails+editemails);
                //Emails to be deleted
                contact.set("TobeDeletedWebAddress", _that.deletedEmails.join("~"));
                
                
                //Addresses
                var addressBlocks = $(".address-block");
                var addaddresss = "";
                var editaddresss = "";
                if(addressBlocks && addressBlocks.length>0){
                	$.each(addressBlocks,function(key, row){
                		//Update existing address
                		if($(row).find('.delAddress').data("id") && $(row).find('.delAddress').data("user-edited")){
                			var tmptEditaddress = "AddrId="+ ($(row).find('.delAddress').data("id") || '#$#');
                				tmptEditaddress+= "|Street1="+ ($($(row).find('input')[0]).val() || '#$#');
                				tmptEditaddress+= "|Street2="+ ($($(row).find('input')[1]).val() || '#$#');
                				tmptEditaddress+= "|City="+ ($($(row).find('input')[2]).val() || '#$#');
                				tmptEditaddress+= "|Postal="+($($(row).find('input')[3]).val() || '#$#');
                				tmptEditaddress+= "|AddressType="+ ($(row).find('.addrsTypeDropDwn').val() || '#$#');
                				tmptEditaddress+= "|State="+ ($(row).find('.stateDropDwn').val() || '#$#');
                				tmptEditaddress+="~";
                				editaddresss += tmptEditaddress;
                		}
                		//Add new address
                		else if(!$(row).find('.delAddress').data("id")){
                			var tmptAddaddress = "AddrId=";
	            				tmptAddaddress+= "|Street1="+ ($($(row).find('input')[0]).val() || '#$#');
	            				tmptAddaddress+= "|Street2="+ ($($(row).find('input')[1]).val() || '#$#');
	            				tmptAddaddress+= "|City="+ ($($(row).find('input')[2]).val() || '#$#');
	            				tmptAddaddress+= "|Postal="+ ($($(row).find('input')[3]).val() || '#$#');
	            				tmptAddaddress+= "|AddressType="+ ($(row).find('.addrsTypeDropDwn').val() || '#$#');
	            				tmptAddaddress+= "|State="+ ($(row).find('.stateDropDwn').val() || '#$#');
	            				tmptAddaddress+="~";
	            				addaddresss += tmptAddaddress;
                		}
                		
                	});
                }
                //Removing default characters
                addaddresss = addaddresss.split('#$#').join('');
                editaddresss = editaddresss.split('#$#').join('');
                
                //contact.set("Addresses", addaddresss);
                contact.set("EditedAddress", addaddresss+editaddresss);
                
                //Address to be deleted
                contact.set("TobeDeletedAddress", _that.deletedAddress.join("~"));

                //Personal info
                var person = new EditcontactModel.PersonContact();
                person.set({
                    "clGreeting": ($("#editContactGreet").val() || ""),
                    "clFirstNm": ($("#editContactFN").val() || undefined),
                    "clMidNm": ($("#editContactMN").val() || ""),
                    "clLastNm": ($("#editContactLN").val() || undefined),
                    "clSfxTxt": ($("#editContactSuffix").val() || ""),
                    "clOccupation": ($("#editContactOccupation").val() || ""),
                    "clJobTitle": ($("#editContactJobTitle").val() || "")
                });
                contact.set("PersonContact", person);
              //Organization info
                var businessContact = new EditcontactModel.BusinessContact();
                businessContact.set({
                    "orgNm": ($("#editContactON").val() || undefined)
                });
                contact.set("BusinessContact", businessContact);
                
                var data = contact.toJSON();
                Analytics.analytics.recordAction('editContactSave:clicked');
                Spinner.show();
                Dataservice.editContact(CommonUtils.readCookie('FMID'), data)
            	.then(function (response) {
            	    //Spinner.hide();
                    //1412 Fix: Need to handle the valid error response from Ebix.
            	    if (response.status != undefined && response.status.toLowerCase() == "error" && response.value != undefined) {
            	        Spinner.hide();
            	        var _customLog = {
            	            "message": response.status,
            	            "responseText": response.value            	            
            	        }
            	        ErrorLog.ErrorUtils.prepareAndLogError(_customLog, false);
            	    }
            	    else {
            	        if (response.indexOf("Success") > -1) {
            	            if (!_that.isClient) {

            	                var clientName = ($("#editContactON").val() ? $("#editContactON").val() : $("#editContactLN").val() + ", " + $("#editContactFN").val());
            	                $(".desk-tab-client-name a").text(clientName);
            	            }
            	            Backbone.history.navigate("#contactprofile/", true);

            	        } else {
            	            alert("System is unavilable.");
            	        }
            	    }
            	    
            	})
            	.fail(function (Error) {
            		Spinner.hide();
            		ErrorLog.ErrorUtils.myError(Error);
            	});
            }
            catch (error) {
            	Spinner.hide();
                ErrorLog.ErrorUtils.myError(error);
            }

        },
        isNumber: function (evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (isNaN(String.fromCharCode(charCode))) {
                return false;
            }
            return true;
        },
        autoJumpToFields: function (e) {
        	//block the jump if it is a tab or shift+tab
        	e.which = e.which || e.keyCode;
        	if(e.which == 9 || e.which == 16){
        		return;
        		}
            var _target = e.currentTarget || e.target;
            var _el = $(_target);
            var _maxLength = _el.attr("maxlength");
            var _nxtFld = _el.data("jumpto");
            if (_el.val() && _el.val().length == _maxLength) {
                $("#" + _nxtFld).focus();
            }
        },
        highlightTheField : function (e) {
        	var _target = e.currentTarget || e.target;
        	$(_target).select();
        	try {
    			_target.setSelectionRange(0,99);
			} catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        },
        listenValueUpdate : function(e){
        	var _target = e.currentTarget || e.target;
        	var delIcon = null;
        	if($(_target).parents(".cm-white-background").find(".del-icon")){
        		delIcon = $(_target).parents(".cm-white-background").find(".del-icon");
        	}else{
        		delIcon = $(_target).parents(".cm-white-background").find(".del-icon");
        	}
        	if($(delIcon).data("id")){
        		$(delIcon).data("user-edited",true);
        	}
        },
        renderTemplateWithDetails : function(data){
        	var that = this;
        	that.$el.html(that.template(data)).promise().done(function(){
        		var selecteBoxes = $("#edit-contact select:not(.sub-type-select)");
        		$.each(selecteBoxes,function(key, element){
        			if($(element).data("to-be-selected")){
        			    $(element).val($(element).data("to-be-selected"));
        			}
        			
                    // Defect #856 - To show junk data if present for State field
        			var countStateInstance = 0;
        			var currentVal = $(element).data("to-be-selected");
        			if ($("#" + element.id).is('.stateDropDwn')) {
        			    $('#' + element.id + ' option').each(function () {
        			        if (this.value == currentVal) {
        			            countStateInstance++;
        			        } 
        			    });
        			    if (countStateInstance == 0) {
        			        $("#" + element.id).append("<option value='" + currentVal + "' selected='selected'>" + currentVal + "</option>");
        			    }
        			}
        			
        		});
        		//sub contact type
        		
        		var _$subTypeSelectBox = $('#sub-contact-type'),_currentSubType =  data.ebix.get('contactSubType'),_subTypeOptions = data.subTypes;
        		if(_currentSubType != "" && _currentSubType != undefined && _currentSubType != null){
        			if(_subTypeOptions.indexOf(_currentSubType) == -1){
            			_subTypeOptions.unshift(_currentSubType);
            		}
        		}
        		_subTypeOptions.sort(function(a,b){
        		a = a.toLowerCase();
        	    b = b.toLowerCase();
        	    if( a == b) return 0;
        	    if( a > b) return 1;
        	    return -1;});
        		var _options = '<option value="">Choose one</option>';
        		for(var i=0;i<_subTypeOptions.length;i++){
        			_options +=	'<option value="'+_subTypeOptions[i]+'">'+_subTypeOptions[i]+'</option>';
        		}
        		_$subTypeSelectBox.html(_options);
        		if(_currentSubType != "" && _currentSubType != undefined && _currentSubType != null){
        			_$subTypeSelectBox.val(_currentSubType);
        		}
        		
        		
        	});
        },
        hideIOSKeyboard: function (e) {
            CommonUtils.hideIOSKeyboard(e);
        },
        render: function (contactId) {
        	try{
        		var that = this;
        		var _serviceCallsStack = [];
        		Spinner.show();
        		if(contactId && contactId.indexOf("Contact.")> -1){
        			that.isClient = false;
        			that.contactId = contactId;
        			 _serviceCallsStack.push(Dataservice.getNonClientEbixDetails(CommonUtils.readCookie('FMID'),contactId,false));
        			 _serviceCallsStack.push(Dataservice.getContactSubTypes(CommonUtils.readCookie('FMID')));
      	            //Queuing the service requests
      	            Q.allSettled(_serviceCallsStack)
      	            	.then(function(response){
      	            		_serviceCallsStack=[];
      	            		Spinner.hide();
      	            		try {
      	            			that.type = response[0].value[0].get("type");
      	        				that.contactType = response[0].value[0].get("contactType");
      	        				var _contactSubTypes = [];
      	        				if(response[1] && response[1]['value']&&response[1]['value']['contactSubTypes']){
      	                  			var _subTypes = response[1]['value']['contactSubTypes'];
      	                  			for(var _subType in _subTypes){
      	                  				_contactSubTypes.push(_subTypes[_subType]);
      	                  			}
      	                  		  }
      	        				that.renderTemplateWithDetails({isClient:that.isClient,cola:null,ebix:response[0].value[0],subTypes:_contactSubTypes});
							} catch (error) {
								_serviceCallsStack=[];
								ErrorLog.ErrorUtils.myError(error);
							}
      	            	})
      	            	.fail(function (error) {
      	            		Spinner.hide();
      	            		ErrorLog.ErrorUtils.myError(error);
      		            });
        			
        			
        		}else{
        			that.isClient = true;
        			function gototContactDetailsSuccess(response){
        				that.type = response[1]['value'][0].get("type");
        				that.contactType = response[1]['value'][0].get("contactType");
        				
        				if(response[2]['value'][0]){
        					response[0]['value'][0].set({'clientPersonal': response[2]['value'][0]}, { silent: true });
        				}
        				var _contactSubTypes = [];
        				if(response[3] && response[3]['value']&&response[3]['value']['contactSubTypes']){
                  			var _subTypes = response[3]['value']['contactSubTypes'];
                  			for(var _subType in _subTypes){
                  				_contactSubTypes.push(_subTypes[_subType]);
                  			}
                  		  }
        				that.renderTemplateWithDetails({isClient:that.isClient,cola:response[0]['value'][0],ebix:response[1]['value'][0],subTypes:_contactSubTypes});
        				Spinner.hide();
        			}
        			
        			
        			//Fetch ContactId from client id
        			Dataservice.getContactDetailsbyClientId(CommonUtils.readCookie('FMID'),contactId)
        			.then(function(response){
        				that.contactId = response[0].get('contactId');
        	            _serviceCallsStack.push(Dataservice.getContactprofileInfo(contactId));
        	            _serviceCallsStack.push(Dataservice.getNonClientEbixDetails(CommonUtils.readCookie('FMID'),response[0].get('contactId')));
        	            _serviceCallsStack.push(Dataservice.getClientPersonal(contactId));
        	            _serviceCallsStack.push(Dataservice.getContactSubTypes(CommonUtils.readCookie('FMID')));
        	           // _serviceCallsStack.push(DataService.getAdvisorInfo());
        	            
        	            //Queuing the service requests
        	            Q.allSettled(_serviceCallsStack)
        	            	.then(function(response){
        	            		if(response && response.length>0){
        	            			_serviceCallsStack = [];
        	            			gototContactDetailsSuccess(response);           				
        	            		}
        	            	})
        	            	.fail(function (error) {
        	            		Spinner.hide();
        	            		ErrorLog.ErrorUtils.myError(error);
        		            });
        			})
        			.fail(function(error){
        				Spinner.hide();
                		ErrorLog.ErrorUtils.myError(error);
        			});
        		}
                    
        	}catch (error) {
        		Spinner.hide();
                ErrorLog.ErrorUtils.myError(error);
            }
        	
        	
        }

    });
    return editcontact;
});