// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetTxnSwpModelSchema = new mongoose.Schema({
    GetTxnSwpResp: {
        type: Array,
        "default": []
    }
});

var GetTxnSwpModelLookUp = mongoose.model('GetTxnSwpModelLookUp', GetTxnSwpModelSchema);

var GetTxnSwpModel = new GetTxnSwpModelLookUp({
    GetTxnSwpResp : {
  "customerInfoVo": {
    "custName": "HEMALI H SAFI M GOKARNAKAR ALICE RODRIGUES",
    "address1": "4109 26TH MAIN ROAD",
    "address2": "ALAVKIK APARTMENT, ANMOL TOWER",
    "address3": "ANAND ARCH APARTMENTS",
    "address4": "W B 743376",
    "city": "TAL-PANVEL",
    "pinCode": "403005",
    "firstHolderName": "HEMALI H SAFI M GOKARNAKAR ALICE RODRIGUES",
    "secondHolderName": "",
    "thirdHolderName": "",
    "guardian": "",
    "firstHolderPanNo": "CNEQI5450Z",
    "secondHolderPanNo": "",
    "thirdHolderPanNo": "",
    "guardianPanNo": "",
    "firstHolderKycStatus": "KYC - Registered",
    "secondHolderKycStatus": "KYC - Registered",
    "thirdHolderKycStatus": "KYC - Registered",
    "guardianKycStatus": "",
    "socialStatus": "Individual",
    "holdingType": "Single",
    "bankdetails": "627208375076326/UNION BANK OF INDIA/SANGOLDA",
    "paymentType": "",
    "paymentMode": "Cheque"
  },
  "retrieveSipVo": null,
  "fundOptions": [
    {
      "accNo": "0069904530226",
      "amount": "10000",
      "direct": "",
      "dividendFlag": null,
      "endDate": "",
      "frequency": "",
      "fundCategory": "",
      "fundOptDesc": "",
      "fundOption": "006",
      "fundType": "",
      "minAddPurAmt": "",
      "minNewPurAmt": "",
      "minSipAmt": "",
      "multiples": "",
      "nfoFlag": null,
      "payoutFlag": "",
      "perpetualFlag": "",
      "reinvestmentFlag": "",
      "startDate": "",
      "stepUpFrequency": "",
      "stepUpType": "",
      "stepUpValue": "",
      "txnType": ""
    }
  ],
  "invPaymentBank": null,
  "paymentMode": "",
  "folioId": "17763831",
  "accountType": null,
  "paymentBankAccNo": null,
  "invAmount": "89800",
  "subBrokerCode": null,
  "subBrokerARN": "1",
  "euin": null,
  "txn_no": "SWD000002",
  "seq_no": "1",
  "account_number": "",
  "fund_option": "",
  "batch_code": "web",
  "trxn_requested_date": "2016-03-15 00:00:00.0",
  "trxn_requested_time": "10:00",
  "txn_source": "SWP",
  "sub_distributor_id": null,
  "ref_txn_no": "RI00043813",
  "application_sr_no": "SWD000002",
  "remarks": null,
  "maker_id": "mobile",
  "maker_date": "2016-04-11 00:00:00.0",
  "auth_id": "mobile",
  "auth_date": "2016-04-11 00:00:00.0",
  "acc_ref_no": null,
  "transferflag": "1",
  "trtype": "SWP",
  "web_refno": "SWD000002",
  "transaction_flag": "C",
  "mode_of_txn": null,
  "euin_flag": null,
  "trxn_units": "0",
  "all_units_flag": null,
  "start_date": "2016-04-20 00:00:00.0",
  "end_date": "2017-01-20 00:00:00.0",
  "frequency": "M",
  "perpetual_flag": null,
  "mf_code": null,
  "destination_account_number": null,
  "destination_fund_option": null,
  "sip_txn_status": null,
  "urn_no": "22",
  "nfo_flag": "",
  "priority_batch_flag": null,
  "trxn_effective_date": null,
  "amount_unit_flag": "A",
  "dc_last_xdigits": null,
  "dc_name_on_card": null,
  "check_no": null,
  "dividend_option": "",
  "account_source": "RWD",
  "branch_code": "BR0008",
  "no_of_installments": "30",
  "lbd_flag": "Y",
  "umrn_no": null,
  "source": "10",
  "renewal_flag": null,
  "paymentOption": null,
  "aadhaar": "",
  "pepFlag": "",
  "stepUpType": null,
  "stepUpValue": null,
  "emandateDebitType": null,
  "emandateFrequency": null,
  "emandateAmount": null,
  "untillCancel": null,
  "emandateFromdate": null,
  "emandateTodate": null,
  "stepUpFrequency": null
}
});

GetTxnSwpModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetTxnSwpModelLookUp table, please contact admin...');
    } else {
        GetTxnSwpModelLookUp.remove({}, function(err) {
            console.log('GetTxnSwpModelLookUp collection removed');
            GetTxnSwpModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetTxnSwpModelLookUp table, please contact admin...');
                }
                console.log('GetTxnSwpModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GetTxnSwpModelLookUp;