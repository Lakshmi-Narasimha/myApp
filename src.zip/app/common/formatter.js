define(['jquery', 'lodash', 'app/common/util'],
    function ($, _, util) {

        var Formatter = function () {

            this.string = function (string, emptyFormat) {
                return util.isEmpty(string) ? emptyFormat : string;
            };

            this.formatAsEIN = function (string, emptyFormat) {
                return util.isEmpty(string) ? emptyFormat : (string.substr(-9, 2) + '-' + string.substr(-7));
            };

            this.formatAsSSN = function (string, emptyFormat) {
                return util.isEmpty(string) ? emptyFormat : (string.substr(-9, 3) + '-' + string.substr(-6, 2) + '-' + string.substr(-4));
            };

            this.formatYMDasMDY = function (string, emptyFormat) {
                return util.isEmpty(string) ? emptyFormat : (string.split('-')[1] + '/' + string.split('-')[2] + '/' + string.split('-')[0]);
            };

            this.formatAsPercent = function (string, emptyFormat) {
                var self = this;
                return util.isEmpty(string) ? emptyFormat : self.removeLeadingZeros(string) + '%';
            };

            this.formatAsDollars = function (string, emptyFormat) {
                var self = this;
                if (util.isEmpty(string)) {
                    return emptyFormat;
                }
                var noZerosString = self.removeLeadingZeros(string);
                if (noZerosString.startsWith('.')) {
                    noZerosString = '0' + noZerosString;
                }
                return '$' + noZerosString.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1,');
            };

            this.maritalStatus = function (string, emptyFormat) {

                if (string === undefined || string === null) {
                    return emptyFormat;
                }
                switch (string) {
                    case '':
                        return 'Unknown';
                    case 'D':
                        return 'Divorced';
                    case 'M':
                        return 'Married';
                    case 'P':
                        return 'Parted or separated';
                    case 'S':
                        return 'Single';
                    case 'W':
                        return 'Widowed';
                    default:
                        return string;
                }

            };

            this.gender = function (string, emptyFormat) {

                if (string === undefined || string === null) {
                    return emptyFormat;
                }
                switch (string) {
                    case '':
                        return 'Unknown';
                    case 'F':
                        return 'Female';
                    case 'M':
                        return 'Male';
                    default:
                        return string;
                }

            };

            this.removeLeadingZeros = function (string, emptyFormat) {
                var self = this;
                if (util.isEmpty(string)) {
                    return emptyFormat;
                }
                if (string.substr(0, 1) === '0') {
                    return self.removeLeadingZeros(string.substr(1));
                } else {
                    return string;
                }
            };

            this.yesNoString = function (bool, emptyFormat) {
                if (emptyFormat && (bool === null || bool === undefined)){
                    return emptyFormat;
                }
                if (bool) {
                    return 'Yes';
                }
                return 'No';
            }


        };

        return new Formatter();

    });
