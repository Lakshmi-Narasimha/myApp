export class User {
    username: string;
    userId: string;
}
