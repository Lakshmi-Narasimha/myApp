'use strict';
describe('Services: account view model service', function() {

    var accountViewModelData, httpBackend, Restangular, $window, params;

    var accountFilter = {
            flag: 'P',
            guId: '878'
        }

    beforeEach(angular.mock.module('investor'));

    beforeEach(inject(function(_accountViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
        accountViewModelData = _accountViewModel_;
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        $window = _$window_;
        $window.ga = function() {};
    }));

    it('should accountViewModel to be defined', function() {
        expect(accountViewModelData).toBeDefined();
    });

    describe('Services: load accountViewModel services', function() {
        var accountViewObject;
        
        beforeEach(inject(function() {
            accountViewObject = {
                "accountDetails":{  
                  "gridData":{  
                     "rows":[  
                        {  
                           "netAmount":"0",
                           "totalUnits":"188.98",
                           "units":"34.9",
                           "nav":"123.56",
                           "amount":"6656",
                           "transaction":"Opening Balance",
                           "txnDate":"15 Nov 2015"
                        }
                     ],
                     "openingBalance":{  
                        "totalUnits":"188.98"
                     }
                  },
                  "accountNumber":"0349904865101",
                  "accountName":"Franklin India Bluechip Dividend Fund"
               }
            };

            httpBackend.expectGET('http://localhost:3030/clients/clientStatement?flag=A&guId=878').respond(accountViewObject);
        }));

        it('should load getAccountViewDetails with success data and retreive the data using getter', function() {
            accountViewModelData.getAccountViewDetails(accountFilter).then(function(result) {
                expect(result.accountDetails).toBeDefined();
            });
        });

        it('should retrive getAccountViewObj data using setter', function() {
            accountViewModelData.setAccountViewObj(accountViewObject);
            expect(accountViewModelData.getAccountViewObj().accountDetails.accountNumber).toEqual('0349904865101');
        });

    });
});
