/**
* @ngdoc property
* @name fticUserConsent Directive
* @description
*
* - directive concludes user consent/agreement with terms and conditions
*
**/
'use strict';

var fticUserConsent = function ($filter,TransactConstant,$uibModal,authenticationService) {
    return {
        template: require('./userConsent.html'),
        restrict: 'E',
        scope: {},
        controller:['$scope', function ($scope) { 
            if(authenticationService.isInvestorLoggedIn()){
                $scope.userAgreement = {
                    label : $filter('translate')(TransactConstant.modifySip.Terms_Condition_Sip_Inv),
                    value : false
                }
            }else{
                $scope.userAgreement = {
                    label : $filter('translate')(TransactConstant.modifySip.Terms_Condition_Sip),
                    value : false
                }
            }
        	 
            $scope.reviewTermsNconditions = function(){
                var modalInstance = $uibModal.open({
                    template : require('../../review/components/termsNconditions/termsNconditions.html'),
                    scope : $scope,
                    size: 'lg'
                });
            }
            $scope.reviewServiceStandards = function() {
                
                var modalInstance = $uibModal.open({
                    template : require('../../review/components/serviceStandards/serviceStandards.html'),
                    scope : $scope,
                    size: 'lg'
                });
            }
        }]
    };
};

fticUserConsent.$inject = ['$filter','TransactConstant','$uibModal','authenticationService'];
module.exports = fticUserConsent;