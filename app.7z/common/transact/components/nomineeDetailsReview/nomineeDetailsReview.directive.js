/**
 * @ngdoc property
 * @name nomineeDetailsReview Directive
 * @requires sipDetailsModel
 * @requires eventConstants
 * @description
 *
 * - It will get the fund details from 'sipDetailsModel' and displays the details.  
 **/
'use strict';

var nomineeDetailsReview = function (formDetailsModel,eventConstants, TransactConstant, $filter, $state,paperlessModel, transactEventConstants) {
    return {
        template: require('./nomineeDetailsReview.html'),
        restrict: 'E',
        scope: {
            editRedirectState : "="
        },
        controller:['$scope', function ($scope) { 
            var translateFilter = $filter('translate');
            $scope.isPaperlessSS = false;
            if(paperlessModel.invType.getInvType() === 'SmartSoln'){
                $scope.isPaperlessSS = true;
            }

            $scope.nomineeReviewDetails = formDetailsModel.getNomineeDetails();
            $scope.infoObj=[];
            angular.forEach($scope.nomineeReviewDetails, function(obj, key){
                $scope.infoObj.push([
                    {
                        text: translateFilter(TransactConstant.common.NOMINEE_NAME),
                        value: $scope.nomineeReviewDetails[key].nomName
                    },
                    {
                        text: translateFilter(TransactConstant.common.NOMINEE_ALLOCATION),
                        value: $scope.nomineeReviewDetails[key].nomPerValue
                    }
                ]);
            }); 

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){ 
                paperlessModel.isNomineeEdit = true;
                $scope.$emit(transactEventConstants.transact.guest.PAPERLESS_REVIEW_EDIT_TRIGGERED, {state:$scope.editRedirectState});
                $scope.$emit("NAVIGATE_TO_TRANSACT", {key: TransactConstant.transact.NOMINEE_KEY});
            }); 

        }]
    };
};

nomineeDetailsReview.$inject = ['formDetailsModel','eventConstants', 'TransactConstant', '$filter','$state','paperlessModel', 'transactEventConstants'];
module.exports = nomineeDetailsReview;