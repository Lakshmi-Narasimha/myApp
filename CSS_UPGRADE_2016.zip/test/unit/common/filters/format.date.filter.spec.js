'use strict';

/* jasmine specs for controllers go here */

describe('formatDateFilter', function() {

	var formatDateFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    formatDateFilter = $injector.get('$filter')('formatDate');
	}));

	//--- Test for definition

	it('should expect formatDateFilter to be defined...', function(){
		expect(formatDateFilter).toBeDefined();
	});

	//--- Test formatDateFilter

	it('should format the given date to mm/dd/yyyy format...', function(){
		expect(formatDateFilter('2015-12-9')).toEqual('12/9/2015');
	});


});