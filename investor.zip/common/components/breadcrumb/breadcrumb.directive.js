/**
 * @ngdoc directive
 * @name fticBreadCrumb
 * @requires
 * @requires
 * @requires
 * @description
 *
 * - It displays the bootstrap breadcrumb component.
 *
**/

'use strict';

var breadCrumb = function($window) {
	return {
            template: require('./breadcrumb.html'),
            restrict: 'E',
            replace: true,
            scope: {
              breadCrumbList : '='
            },
            link: function(scope){
            	scope.redirectPath = function(breadcrumbObject){
            		if(breadcrumbObject.state){
            			$window.location.href = breadcrumbObject.state;
            		}
            	};
            } 
        };
};

breadCrumb.$inject = ['$window'];
module.exports = breadCrumb;