/**
 * @ngdoc filter
 * @name Filter removeComma
 * @description
 *
 * - Filter method to format number to 2 digits.
 *
 */


'use strict';

var removeComma = function() {

	return function(value) {
		if(value) {
            var num = value.replace(/\,/g,'');
            num = parseInt(num,10);
            return num;
        } else {
            return 0;
        }
	};
};

removeComma.$inject = [];
module.exports = removeComma;
