/**
 * @ngdoc directive
 * @name invDbUserInformation 
 * @requires investorEventConstants
 * @requires investorDashboardDetailsModel
 * @description
 *
 * - It represents the data of profile and ranking details of investor in the dashboard page.
 * 
 *
 **/

'use strict';

var invDbUserInformation = function(investorEventConstants, investorDashboardDetailsModel, loggerConstants, fticLoggerMessage) {
	return {
            template: require('./invDbUserInformation.html'),
            restrict: 'E',
            replace: true,
            scope:true,
            link: function(scope) {
                  scope.isDataAvailable = false;
                  scope.$on(investorEventConstants.Dashboard.INV_DB_INFO, function() {
                        
                        var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_USER_INFORMATION_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_INFO + ' event' /* Function Name */; 
                        fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
                        if(investorDashboardDetailsModel.getDashboardData().profileDetails){
                              scope.profileDetails = investorDashboardDetailsModel.getDashboardData().profileDetails;
                              scope.isDataAvailable = true;
                        }else {
                              scope.isDataAvailable = false;
                        }
                  });
            }
      };
};

invDbUserInformation.$inject = ['investorEventConstants', 'investorDashboardDetailsModel', 'loggerConstants', 'fticLoggerMessage'];
module.exports = invDbUserInformation;