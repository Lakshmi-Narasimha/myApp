// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var ValidateKycSchema = new mongoose.Schema({
    'kycStatusObj': {
        'type': Object,
        'default': {}
    }
});

var ValidateKycLookUp = mongoose.model('ValidateKycLookUp', ValidateKycSchema);

var ValidateKycModel = new ValidateKycLookUp({
    'kycStatusObj': {
        'kycValidation': {
            'aadhar':' ',
            'appCreatedDate': '22-10-2012 12:21:23',
            'appEntryDate': ' ',
            'appHoldDeactiveRmks': ' ',
            'appIPVFlag': 'Y',
            'appMissFields': '',
            'appModifyDate': ' ',
            'appPanDob': '',
            'appPanNo': 'AFRPG8490G',
            'appRemarks': '',
            'appRespDate': '02-11-2016 11:34:11',
            'appStatusDelta': '',
            'appStausDate': '12-04-2016 10:09:04',
            'appUpdtRemarks': '',
            'appUpdtStatus': '02',
            'appUpdtdate': '12-04-2016 10:09:04',
            'camskra': ' ',
            'cvlkra': ' ',
            'dotexkra': ' ',
            'fullName': 'SHAILENDRA GODBOLE',
            'karvykra': ' ',
            'kycId': 'AFRPG8490G',
            'kycMode': '0',
            'kycSource': 'KRA Verified',
            'kycStatus': 'A',
            'kycType': 'A',
            'ndmlkra': ' '
        }
        
    }
});

ValidateKycLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidateKycLookUp table, please contact admin...' + err);
    } else {
        ValidateKycLookUp.remove({}, function(err) {
            console.log('ValidateKycLookUp collection removed' + err);
            ValidateKycModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ValidateKycLookUp table, please contact admin...');
                }
                console.log('ValidateKycLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ValidateKycLookUp;
