/**
 * @ngdoc property
 * @name Build My Plan Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Build My Planfor guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function buildmyPlanController($scope, $state, smartSolnFundDetailsInitialLoader, buildPlanModelService) {

    smartSolnFundDetailsInitialLoader.loadAllServices($scope, true, buildPlanModelService.getInvestorSearch() ? buildPlanModelService.getInvestorSearch().folioId : "");
    buildPlanModelService.tabname = "buildplan";

    if (buildPlanModelService.fromGoalSheet) {
        buildPlanModelService.fromGoalSheet = false;
        if(buildPlanModelService.isFromCustomize) {
            $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan.bmycustomizeplan");
        } else {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.buildplan.buildplanshowdtls');
        }
    }
    $scope.$on('goBuildMyPlanCntrl', function (event, args) {
        if(buildPlanModelService.isFromCustomize) {
            $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan.bmycustomizeplan");
        }else {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.buildplan.buildplanshowdtls');
        }

    })
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
buildmyPlanController.$inject = ['$scope', '$state', 'smartSolnFundDetailsInitialLoader', 'buildPlanModelService'];
module.exports = buildmyPlanController;