/**
 * @ngdoc property
 * @name RemMenConfPopupController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function RemMenConfPopupController($scope, $uibModalStack, familyPortfolioUserAccessModel, fticFTUserAccessDetailsLoadInitialService,toaster,$loader,$filter,investorConstants) {
    var FPGA_USER_REM_SUCC_MSG = $filter('translate')(investorConstants.accountsettings['FPGA_USER_REM_SUCC_MSG']);
    $scope.onCancel = function(){
        $uibModalStack.dismissAll();
    };
    $scope.onSubmit = function(){
        $uibModalStack.dismissAll();
        $loader.start();
        $scope.params = {
			accessType:'RM',
			userId:$scope.userName
        };
        familyPortfolioUserAccessModel.removeOrAddGrantAccess($scope.params).then(function () {
            toaster.success(FPGA_USER_REM_SUCC_MSG);
            $scope.deleted();
        },function(error){
            if(error && error.data && error.data.length > 0) {
                //toaster.error(error.data[0].errorDescription);
            }
        }).finally(function(){
            $loader.stop();
        });
    };
}
RemMenConfPopupController.$inject = ['$scope', '$uibModalStack', 'familyPortfolioUserAccessModel', 'fticFTUserAccessDetailsLoadInitialService','toaster','$loader','$filter','investorConstants'];
module.exports = RemMenConfPopupController;