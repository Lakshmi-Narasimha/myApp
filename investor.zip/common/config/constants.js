'use strict';

var constants = (function() {
    return {

        // Login Messages
        LOGIN_SUCCESS: 'You have successfully logged in.',
        LOGIN_FAILURE: 'Your ARN Code or Email Address is incorrect.',
        key: 'value',
        ERROR_SC_0: 'Sorry! We are currently experiencing technical difficulties please try again later.',
        ERROR_SC: 'Error Occured While Calling Rest Service.Please try again later.',
        ERROR_02: 'Sorry for the inconvenience caused. Please contact our help desk 1800-200-2345!',
        ERROR_03: 'Invalid Username or Password!',
        ERROR_REST_TIMEOUT: 'Sorry! Rest Call Timeout',
        AUTHENTICATION_FAILED:'Authentication Failed.Pleaser try again.',
        INSTANT_REPORTS_AUTH_FAILED: 'The entered details are incorrect, Please try again.',
        SIGNUP_FAILED:'Signup Failed. Please try again.',
        ACC_STMT_DATE_RANGE_ERR : "ACC_STMT_DATE_RANGE_ERR",
        ACC_STMT_FOLIO_ERR : '‘Please choose atleast 1 Folio, for Account statement to be emailed.',
        

        //  success message
        SUCCESS_TRANSACTION: 'Transaction complete successfully',
        SUCCESS_RECORD_INSERTED:'Record Sucessfully Inserted',
        SUCCESS_RECORD_UPDATED:'Record Sucessfully Updated',
        SUCCESS_RECORD_DELETED:'Record Sucessfully Deleted',
        IR_WARNING : 'Maximum 05 reports can be selected for Email at a time',
        EMAIL_REPORTS_SUCCESS : 'Reports sent successfully.',
        EMAIL_REPORTS_FAILURE : 'Failed to send the reports.',

        // Reports

        // Reports Types
        instantreports: {
            COMM_DETAILS: 'COMM_DETAILS',
            INVESTOR_DETAILS: 'INVESTOR_DETAILS',
            SPECIAL_PRODUCTS: 'SPECIAL_PRODUCTS',
            TRANSACTION_DETAILS: 'TRANSACTION_DETAILS'
        },
        // Reports Frequency filter Options
        frequency: {
            ONE_MONTH: 'ONE_MONTH',
            THREE_MONTHS: 'THREE_MONTHS',
            ONE_YEAR: 'ONE_YEAR',
            PERIOD: 'PERIOD'
        },

        advisor: {
            TRANSACT_CONSTANTS: [
                {
                    'text': 'Buy',
                    'sref': 'transact.base.buy'
                }, {
                    'text': 'Switch',
                    'sref': 'transact.base.switch'
                }, {
                    'text': 'Redeem',
                    'sref': 'transact.base.redeem'
                }, {
                    'text': 'SIP',
                    'sref': 'transact.base.sip'
                },

                {
                    'text': 'Modify a SIP',
                    'sref': 'transact.base.modifysip'
                }, {
                    'text': 'STP',
                    'sref': 'transact.base.stp'
                }, {
                    'text': 'SWP',
                    'sref': 'transact.base.swp'
                }, {
                    'text': 'Smart Solutions',
                    'sref': ''
                }
            ]
        },

        investor: {
            TRANSACT_CONSTANTS: [{
                'text': 'Buy a Lump sum',
                'sref': ''
            }, {
                'text': 'Start a SIP',
                'sref': ''
            }, {
                'text': 'Modify a SIP',
                'sref': ''
            }, {
                'text': 'Renew a SIP',
                'sref': ''
            }, {
                'text': 'Switch Funds',
                'sref': 'invTransact.base.switch'
            }, {
                'text': 'Start an STP',
                'sref': 'invTransact.base.stp'
            }, {
                'text': 'Cancel an STP',
                'sref': 'invTransact.base.cancelStp'
            }, {
                'text': 'Redeem',
                'sref': 'invTransact.base.redeem'
            }, {
                'text': 'Start a SWP',
                'sref': 'invTransact.base.swp'
            }, {
                'text': 'Start a DTP',
                'sref': 'invTransact.base.dtp'
            }]
        },

        //Account Statements
        accountStatements : {
            ACC_STMTS_LIMIT : 'ACC_STMTS_LIMIT',
            ACCTS_LIMIT : 10,
            PAN : 'PAN',
            FOLIO_NO : 'Folio No.',
            MOBILE : 'Mobile',
            EMAIL : 'Email',
            ACC_NO : 'Account No.'
        },

        login:{
            
        TERMS_N_CONDITION_ONLINE_ADV : 'TERMS_N_CONDITION_ONLINE_ADV',
        TERMS_N_CONDITION_TEXT : 'TERMS_N_CONDITION_TEXT',
        OTP_TEXT:'OTP_TEXT',
        WARNING_TEXT:'WARNING_TEXT',
        RESEND_OTP_TEXT:'RESEND_OTP_TEXT',
        SUBMIT_TEXT:'SUBMIT_TEXT',
        CONTINUE_TEXT:'CONTINUE_TEXT',
        TERMS_AND_CONDITIONS:'TERMS_AND_CONDITIONS',
        I_ACCEPT:'I_ACCEPT',
        I_DONOT_ACCEPT:'I_DONOT_ACCEPT',
        FORGOTTEN_PASSWORD : 'Forgot Password',
        FORGOTTEN_USERNAME : 'Forgot username',
        SUBMIT : 'SUBMIT',
        LOGIN_THANKYOU :'Thank you',
        THANKYOU_MESSAGE:'Your Username has been sent to your registered email address and mobile number',
        INVESTOR_TEXT:'INVESTOR_TEXT',
        ADVISOR_TEXT:'ADVISOR_TEXT',
        PLEASE_ENTER_YOUR_TEXT:'PLEASE_ENTER_YOUR_TEXT',
        AND_TEXT:'AND_TEXT',
        OTP_TEXT_AFTER_GETTINGOTP:'OTP_TEXT_AFTER_GETTINGOTP',
         SECURITY_QUESTION : "What's your school name ?",
         SELECT_SECURITY_QUESTION : 'SELECT_SECURITY_QUESTION',
         ARN_VALIDATION_TEXT:'ARN_VALIDATION_TEXT',
         OTP_VALIDATION_TEXT:'OTP_VALIDATION_TEXT',
         CHOOSE_OPTIONS:'CHOOSE_OPTIONS',
         FU_WARNING_TEXT:'The entered ARN Code or ARN Registration Date is incorrect, Please try again',
         ARN_SUBMTTED_TEXT:'arnsubmitted'
         },


         // GUEST CUSTOMER SERVICE
         INVALID_EMAIL : 'INVALID_EMAIL',
         INVALID_PAN_NO : 'INVALID_PAN_NO',
         SINCE_INC : 'SINCE_INC',
         NAV_SELECT : 'NAV_SELECT',
         VALUATION_ACC :'VALUATION_ACC',
         CAPITAL_ACC :'CAPITAL_ACC',
         TRANSACT_ACC :'TRANSACT_ACC',
         DIVIDEND_ACC :'DIVIDEND_ACC',
         AUTH_TYPE :'AUTH_TYPE',
         EMAIL_ID :'EMAIL_ID',
         PAN_FOLIO_NUM :'PAN_FOLIO_NUM',
         CONSOLI_ACC :'CONSOLI_ACC',
         CONSOLI_ACC_BODY :'CONSOLI_ACC_BODY',
         INST_MAIL :'INST_MAIL',
         INST_BODY : 'INST_BODY',
         INST_BODY_MSG :'INST_BODY_MSG',
         VALIDATE_LABEL :'VALIDATE_BTN',
         EASY_SERV :'EASY_SERV',
         EASY_FIRST_BODY_MSG :'EASY_FIRST_BODY_MSG',
         EASY_REGS_NOW :'EASY_REGS_NOW',
         EASY_MOBILE :'EASY_MOBILE',
         EASY_MOBILE_MSG :'EASY_MOBILE_MSG',
         EASY_EUPDATE :'EASY_EUPDATE',
         EASY_EUPDATE_MSG :'EASY_EUPDATE_MSG',
         EASY_REGS_MSG :'EASY_REGS_MSG',
         ADD_INF :'ADD_INF',
         PLS_NT :'PLS_NT',
         FOOTER_MSG :'FOOTER_MSG',
         EASY_MOBILE_ACCPT :'EASY_MOBILE_ACCPT',
         EASY_UPDATE_ACCPT :'EASY_UPDATE_ACCPT',
         SUB_SUCCESS :'SUB_SUCCESS',
         EASY_UNSUB_MSG :'EASY_UNSUB_MSG',
         DISCLAIMER_MSG :'DISCLAIMER_MSG',
         DISCLAIMER :'DISCLAIMER',
         EASY_NOTE :'EASY_NOTE',
         INVAID_DETAILS :'INVAID_DETAILS',
         INVAID_BANK :'INVAID_BANK',
         ENTER_BANK :'ENTER_BANK',
         PHONE_NUMBER_WARNING_TEXT :'PHONE_NUMBER_WARNING_TEXT',
         ENTER_MOBILE :'ENTER_MOBILE',
         ENTER_EMAIL :'ENTER_EMAIL',
         ENTER_PAN :'ENTER_PAN',
         ENTER_PINCODE :'ENTER_PINCODE',
         ENTER_AMOUNT :'ENTER_AMOUNT',
         ENTER_DOB :'ENTER_DOB',
         HIST_NAV :'HIST_NAV',
         HIST_NAV_MSG :'HIST_NAV_MSG',
         SELECT_SCHEME :'SELECT_SCHEME',
         ENTER_FUND :'ENTER_FUND',
         ENTER_FORMAT:'ENTER_FORMAT',
         VAL_ACCNT :'VAL_ACCNT',
         VAL_ACCNT_MSG :'VAL_ACCNT_MSG',
         VAL_UNSUB :'VAL_UNSUB',
         VAL_ACCR_MSG :'VAL_ACCR_MSG',
         FATCA_HEAD :'FATCA_HEAD',
         ADD_KYC :'ADD_KYC',
         PLS_TICK :'PLS_TICK',
         TAX_RESIDENT :'TAX_RESIDENT',
         TAX_PURPOSE :'TAX_PURPOSE',
         THANKU_MSG :'THANKU_MSG',
         DISC_MSG :'DISC_MSG',
         CHK_NAV_ALRTS : 'CHK_NAV_ALRTS',
         UNSUB_SUCCESS :'UNSUB_SUCCESS',
        //Reports accordion label
        SELECTED : 'SELECTED',
        JSON_SERVICES : 'jsonservices', //advisor/jsonservices
        //common notification events
        NOTIFI_CLICKED_TEXT:'NOTIFI_CLICKED_TEXT',
        RECOM_CLICKED_TEXT:'RECOM_CLICKED_TEXT',
        NOTIFICATION_CLICKED_TEXT:'NOTIFICATION_CLICKED_TEXT',
        RECOMMENDATION_CLICKED_TEXT:'RECOMMENDATION_CLICKED_TEXT',

        //advisor components
        RECOMM_CLICK_FOR_DETLS_TEXT:'RECOMM_CLICK_FOR_DETLS_TEXT',

        LOGIN_USER_NAME_FORMAT : 'LOGIN_USER_NAME_FORMAT',

        ADVISOR_MAIN_USER : 20,
        ADVISOR_SUB_USER1 : 30,
        ADVISOR_SUB_USER2 : 40,
        INVESTOR_MAIN_USER: 10,
        Dashboard : {
            ADV_NOT_CNT : 'advisorNotificationsCount',
            ADV_RC_CNT : 'advisorRecommendationsCount'
        }

    };
}());

constants.$inject = [];
module.exports = constants;
