/**
 * @ngdoc property
 * @name ftictaxCalculatorForm Directive
 * @description
 *
 * ftictaxCalculatorChart directive 
 *
 **/
'use strict';

var fticTaxCalculatorGrid = function($state,$timeout,eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, taxCalculatorInitialService, taxCalculatorModel, calculatorsEventConstants) {
	return {
        template: require('./taxCalculatorGrid.html'),
        restrict: 'E',
        replace: true,
        scope:{},
        controller: function($scope, $element, $attrs){


          $scope.$on(calculatorsEventConstants.TAX_CALCULATE_GRID, function(event){
             $scope.taxGridValues = false;
                $scope.taxGrid = {};
            $scope.fundName = taxCalculatorModel.getTaxCalculations()[0].fundName;

            $scope.taxGridValues = taxCalculatorModel.getTaxCalculations()[0].returnData;
            
            $scope.taxGrid.columnDefs = [
            { field: 'year', displayName: "Year", width:"100", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft: true},
            { field: 'amountInvested', displayName: 'Amount Invested', width:"200", headerCellClass: 'text-right fti-grid-headercell fti-grid-sortDisabledHeader',cellClass:'text-right', enableSorting:false},
            { field: 'valueOfAmount', displayName: 'Value of Investment', width:"200", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false},
            { field: 'capitalGain', displayName: 'Capital Gain', width:"200", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false},
            { field: 'taxImplication', displayName: 'Tax Implication', width:"150", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false},
            { field: 'fdTaxImplication', displayName: 'FD Tax Implication*', width:"175", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false}
            ]; 


            });

            $scope.$on(calculatorsEventConstants.TAX_RESET_DATA, function(event) {
                $scope.taxGridValues = false;
            });
                      
        },
        link: function(scope, element, attrs, ctrl){
        }
    };
};
fticTaxCalculatorGrid.$inject = ['$state','$timeout','eventConstants','fticLoggerMessage', 'loggerConstants', '$cookies','authenticationService','taxCalculatorInitialService','taxCalculatorModel', 'calculatorsEventConstants'];
module.exports = fticTaxCalculatorGrid;