/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var FolioDetails = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _folioDetailsResp = null,
        _kycDetails;

    var folioDetailsModel = {
        // fetchcgaccountdetails : function () {
        fetchFolioDetails: function (params) {
            /*var guIDParam = {
                "guId" : authenticationService.getUser().guId,
            }*/
            var deferred = $q.defer();
            //Restangular.one('getFolioDetail').get().then(function (folioDetailsResp) {
            Restangular.one('transact/fetchPanFolios').get(params).then(function (folioDetailsResp) {
                console.log(folioDetailsResp);
                deferred.resolve(folioDetailsResp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getFolioDetails: function () {
            if (!angular.isDefined(_folioDetailsResp)) {
                return null;
            }
            return _folioDetailsResp;
        },
        setFolioDetails: function (folioDetailsResp) {
            _folioDetailsResp = folioDetailsResp;
        },
        /**
         * Below 2 methods found un-used
         */
        setKycDetails: function (kycDetails) {
            _kycDetails = kycDetails;
        },
        getKycDetails: function () {
            if (!angular.isDefined(_kycDetails)) {
                return null;
            }
            return _kycDetails;
        }

    };
    return folioDetailsModel;

};

FolioDetails.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = FolioDetails;
