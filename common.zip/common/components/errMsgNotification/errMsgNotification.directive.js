/**
 * @ngdoc directive
 * @name msgNotification
 * @description
 *
 * - It displays a tittle which need to be passed while declaring this directive and count.
 * 
**/

'use strict';

var errMsgNotification = function (appConfig, configUrlModel){
	return {
		template : require('./errMsgNotification.html'),
		restrict : 'E',
		scope : {
			messageText: '='
		},
        controller:['$scope', function($scope){ 
			$scope.redirect = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')]; 
			//$window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')]; 
        }]
	};
};

errMsgNotification.$inject = ['appConfig','configUrlModel'];
module.exports = errMsgNotification;