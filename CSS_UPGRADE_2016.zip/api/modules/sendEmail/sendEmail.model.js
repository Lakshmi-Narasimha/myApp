// email.subscription.model.js
// grab the mongoose module
// define our email.subscription.model model
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var EmailSendSchema = new mongoose.Schema({
    emailObject: {
        type: Array,
        "default": []
    }

});

var EmailSend = mongoose.model('EmailSend', EmailSendSchema);


var EmailSendModel = new EmailSend({
    emailObject: [{
        "functionName": "SendPaymentConfirmationEmail",
        "emailDetails": {  
           "uiErrorDisplayMessage":null,
           "transactionStatus":"S",
           "transactionDescription":"Success",
           "transactionCode":null
        }
    }]
});



EmailSend.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating Email Send table,please contact admin...');
    } else {
        EmailSend.remove({}, function(err) {
            console.log('Email Send collection removed');
            EmailSendModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating Email Send table,please contact admin...');
                }
                console.log('Email Send table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = EmailSend;
