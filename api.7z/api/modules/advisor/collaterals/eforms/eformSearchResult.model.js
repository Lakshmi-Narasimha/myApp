// Eforms.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var EformSearchResultModelSchema = new mongoose.Schema({
    EformSearchResult: {
        type: Array,
        "default": []
    }
});

var EformSearchResultModelLookUp = mongoose.model('EformSearchResultModelLookUp', EformSearchResultModelSchema);

var EformSearchResultModel = new EformSearchResultModelLookUp({
    "EformSearchResult" : 
        [
            {
                "unitHolderName": "Shankar Narayanan",
                "pan": "ABCD1234KF",
                "folioNo": 4563152,
                "modeOfHolding": "Joint",
                "mobile": 9987009827,
                "email": "shankarnarayanan@abc.com",
                "city": "Chennai",
                "holders": {
                    "firstHoldersName": "Swapnil",
                    "secondHoldersName": "Ramesh",
                    "minorGuardian": "Suresh"
                },
                "active":true
            },
            {
                "unitHolderName": "Shankar Iyer",
                "pan": "MKLK1234IJ",
                "folioNo": 4563178,
                "modeOfHolding": "Single",
                "mobile": 9987820101,
                "email": "shankar.iyer@gmail.com",
                "city": "Delhi",
                "holders": {
                    "firstHoldersName": "Vamsi",
                    "secondHoldersName": "Ramesh",
                    "minorGuardian": "Suresh"
                },
                "active":true
            },
            {
                "unitHolderName": "Shankar Krishnan",
                "pan": "OIUH1234GH",
                "folioNo": 9963178,
                "modeOfHolding": "Joint",
                "mobile": 9223231498,
                "email": "shankar.krishnan@gmail.com",
                "city": "Calcutta",
                "holders": {
                    "firstHoldersName": "Suresh",
                    "secondHoldersName": "Vamsi",
                    "minorGuardian": "Ramesh"
                },
                "active":false
            },
            {
                "unitHolderName": "Shankar B",
                "pan": "ABCD1234KF",
                "folioNo": 4563152,
                "modeOfHolding": "Joint",
                "mobile": 9987009827,
                "email": "shankarnarayanan@abc.com",
                "city": "Chennai",
                "holders": {
                    "firstHoldersName": "Swapnil",
                    "secondHoldersName": "Ramesh",
                    "minorGuardian": "Suresh"
                },
                "active":true
            },
            {
                "unitHolderName": "Shankar C",
                "pan": "MKLK1234IJ",
                "folioNo": 4563178,
                "modeOfHolding": "Single",
                "mobile": 9987820101,
                "email": "shankar.iyer@gmail.com",
                "city": "Delhi",
                "holders": {
                    "firstHoldersName": "Vamsi",
                    "secondHoldersName": "Ramesh",
                    "minorGuardian": "Suresh"
                },
                "active":false
            }
        ]
});

EformSearchResultModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating EformSearchResultModelLookUp table, please contact admin...');
    } else {
        EformSearchResultModelLookUp.remove({}, function(err) {
            console.log('EformSearchResultModelLookUp collection removed');
            EformSearchResultModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating EformSearchResultModelLookUp table, please contact admin...');
                }
                console.log('EformSearchResultModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = EformSearchResultModelLookUp;