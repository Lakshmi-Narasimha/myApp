coa = coa || {};
define(['jquery', 'underscore', 'backbone','backboneRelational'], function($, _, Backbone,backboneRelational) {
	coa.models.Client = Backbone.RelationalModel.extend({
	defaults : {
		name : '',
		id : '',
		groupId : ''
	}

});

});