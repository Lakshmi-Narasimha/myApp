var componentModule = angular.module('component.customcarousel', []);

componentModule.directive("carouselCustomize", ['$window', function($window) {
    return {
        restrict: "AEC",
        replace: true,
        scope: {
            cancelclickable: '=',
            carousellist: '=',
            visibleitems: '=',
            vertical: "=",
            slideitems: '=',
            verticalitems: "=",
            navigationbars: "=",
            carouseltype: "@",
            detailtype: "@",
            idname: "@",
            onlymobile: "@",
            onlydesktop: "@",
            cycle: "@",
            textimagetoggle: '@',
            page:'=',
            incdet: '=?',
            siteprefixagent:"=",
            billingmaintenance: "="
        },
        templateUrl: $window.UIC.sitePrefix + 'components/partials/carousel.template.html',
        link: function(scope, element, attrs) {
        },
        controller: ['$scope', '$window', '$element', '$timeout', function($scope, $window, $element, $timeout) {
            var _this_self = this;
            $scope.pagename = $scope.page;
            /*$scope.clickEventSlick = function(type) {
                $(".policy-detail-head-carousel .slick-slide").off("click");
                $(".policy-detail-head-carousel .slick-slide").on("click", function(event) {
                    $(".policy-detail-head-carousel .slick-slide").removeClass('policy-active');
                    angular.element(event.currentTarget).addClass('policy-active');
                    $scope.$broadcast('policy-tile-detail-clicked', event, angular.element(event.currentTarget).attr("data-slick-index"), type);
                });
            };*/

            $scope.initializeSlick = function() {
                return $timeout(function() {
                    var slider;
                    slider = angular.element(_this_self.element).find(".slider");
                    if (angular.element(_this_self.element).find(".slick-initialized").length > 0) {
                        return false;
                    }
                    slider.slick({
                        dots: true,
                        focusOnSelect: false,
                        speed: 500,
                        slidesToShow: _this_self.visibleitems,
                        slidesToScroll: _this_self.slideitems,
                     /*   slidesToScroll: 1,*/
                        responsive: [{
                            breakpoint: 768,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }]
                    });

                    angular.element(_this_self.element).find(".slick-prev").text("");
                    angular.element(_this_self.element).find(".slick-next").text("");

                    /*if (angular.lowercase(_this_self.detailtype) === "policydetailtype" || angular.lowercase(_this_self.detailtype) === "policytile") {

                        angular.element($window).on('resize', function() {
                            setTimeout(function() {
                                $scope.clickEventSlick(angular.lowercase(_this_self.detailtype));
                                
                                if (angular.element(".policy-detail-head-carousel .slick-slide .policy-tile-content.active").length > 0) {
                                    var notClonedelementIndex = angular.element(".policy-detail-head-carousel .slick-slide .policy-tile-content.active").parents(".slick-slide").not(".slick-cloned");
                                    var elementIndex = notClonedelementIndex.attr("data-slick-index");


                                    var slider;
                                    slider = angular.element(_this_self.element).find(".slider");
                                    slider.slick('slickGoTo', elementIndex);
                                }
                                angular.element(angular.element(".policy-detail-head-carousel .slick-dots")[0]).clone().insertAfter(angular.element(".policy-detail-head-carousel .slick-dots"));
                                angular.element(".policy-detail-head-carousel .slick-dots").eq(0).hide();
                                angular.element(".policy-detail-head-carousel .slick-dots").eq(1).addClass("additional-dots");
                                angular.element(".policy-detail-head-carousel .slick-dots.additional-dots li").on("click",function(ev){
                                    slider.slick('slickGoTo', angular.element(this).index());
                                    angular.element(".additional-dots .slick-active").removeClass("slick-active");
                                    angular.element(this).addClass("slick-active");
                                });
                            }, 500);
                            
                        });
                        $scope.clickEventSlick(angular.lowercase(_this_self.detailtype));
                    }*/
                    /*if (angular.lowercase(_this_self.detailtype) === "driverdata") {
                        slider.on('beforeChange', function(event, slick, currentSlide, nextSlide) {
                            angular.element(".policy-driver-panel-block").removeClass("show");
                            angular.element(".carousel-container").removeClass("highlight").removeClass("mobile-driver").removeClass("desktop-driver");
                        });

                    } else */
                    if (angular.lowercase(_this_self.detailtype) === "coveragedriver") {
                        slider.on('beforeChange', function(event, slick, currentSlide, nextSlide) {
                            $scope.$broadcast('coverage-driver-changing', currentSlide);
                        });

                    }
                    if (!_this_self.navigationbars) {
                        slider.find(".slick-prev").hide();
                        slider.find(".slick-next").hide();
                    }
                    //707230 Fixed
                    /*if($(".policy-detail-head-carousel .slick-dots").length && ($(".policy-detail-head-carousel .slick-dots").length < 2)){
                        angular.element(angular.element(".policy-detail-head-carousel .slick-dots")[0]).clone().insertAfter(angular.element(".policy-detail-head-carousel .slick-dots"));
                        angular.element(".policy-detail-head-carousel .slick-dots").eq(0).hide();
                        angular.element(".policy-detail-head-carousel .slick-dots").eq(1).addClass("additional-dots");
                        angular.element(".policy-detail-head-carousel .slick-dots.additional-dots li").on("click",function(ev){
                            slider.slick('slickGoTo', angular.element(this).index());
                            angular.element(".additional-dots .slick-active").removeClass("slick-active");
                            angular.element(this).addClass("slick-active");
                        });
                    }*/

                });
            };




            $scope.unInitializeSlick = function() {
                return $timeout(function() {
                    var slider;
                    slider = angular.element(_this_self.element).find(".slider");
                    setTimeout(function() {
                        if (angular.element(_this_self.element).find(".slick-initialized").length > 0) {
                            slider.slick("unslick");
                        }

                    }, 500);

                });
            };

            $scope.checkIntializeSlick = function(value) {
                var windowWidth = $window.innerWidth || document.documentElement.clientWidth;
                if (value && _this_self.onlymobile) {
                    if (windowWidth < 767) {
                        $scope.initializeSlick();
                    } else if (windowWidth > 767) {
                        $scope.unInitializeSlick();

                    }
                } else if (value && _this_self.onlydesktop) {
                    if (windowWidth < 767) {
                        $scope.unInitializeSlick();
                    } else if (windowWidth > 767) {

                        $scope.initializeSlick();

                    }
                } else {
                    $scope.initializeSlick();
                }

            };



            $scope.$watch('carousellist', function(data) {
                if ($scope.carousellist) {
                    if ($scope.vertical) {

                        $scope.carousellists = data;

                    } else {
                        $scope.carousellists = $scope.carousellist;
                    }

                    _this_self.carousellist = $scope.carousellists;
                    _this_self.visibleitems = $scope.visibleitems;
                    _this_self.slideitems = $scope.slideitems;
                    _this_self.carouseltype = $scope.carouseltype;
                    _this_self.verticalitems = $scope.verticalitems;
                    _this_self.navigationbars = $scope.navigationbars;
                    _this_self.vertical = $scope.vertical;
                    _this_self.detailtype = $scope.detailtype;
                    _this_self.elementId = $scope.idname;
                    _this_self.element = $element;
                    _this_self.onlymobile = $scope.onlymobile || false;
                    _this_self.onlydesktop = $scope.onlydesktop || false;
                    _this_self.cyclic = $scope.cycle || false;
                    _this_self.textimagetoggle = $scope.textimagetoggle || false;
                    
                    if (angular.element(_this_self.element).find(".slick-initialized").length > 0) {
                        angular.element(_this_self.element).find(".slider").slick("unslick");
                    }

                    if (_this_self.onlymobile || _this_self.onlydesktop) {
                        $scope.checkIntializeSlick(true);
                        angular.element($window).on('resize', function() {
                            setTimeout(function() {
                                $scope.checkIntializeSlick(true);

                            });
                        });
                    } else {
                        $scope.initializeSlick();
                    }


                }






            });


        }]
    };
}]);


componentModule.directive("carosuelRepeat", function($timeout) {
    return {
        restrict: "AEC",
        require: "^?carouselCustomize",
        priority: 1,
        link: function(scope, element, attrs, parent) {
            if(!parent){
                return;
            }

            scope.carouselType = parent.carouseltype;
            scope.carouselElementId = parent.elementId || "";
            scope.parentDetailtype = parent.detailtype || "";
            scope.tileType = parent.detailtype;

            if (parent.carousellist && parent.detailtype === "vehicledetails") {

                if (scope.$parent && scope.$parent.carousel && (scope.$parent.carousel.subjectOfInsurance != null || angular.isUndefined(scope.$parent.carousel.subjectOfInsurance) || scope.$parent.carousel.vehicleID)) {
                    scope.tileType = parent.detailtype;
                }

            }

            /*if (angular.lowercase(parent.detailtype) === "policydetailtype") {
                scope.parenttype = "policydetailtype";
            }*/


            if (parent.onlymobile) {
                scope.carouselTableCheck = false;
                if (parent.detailtype === "policylosses") {
                    scope.carouselTableCheck = true;
                }
            }


            scope.classcarousel = function() {
                var classname;

                classname = "col-md-12 col-sm-12 col-lg-12 col-xs-" + (12 / parent.verticalitems);

                return classname;

            };



        }
    };
});

componentModule.directive('carouselDefault', ['$window', function($window) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            content: '='

        },
        templateUrl: $window.UIC.sitePrefix + 'components/partials/defaultcarousel.html',
            link: function(scope, elm, attr) {
                scope.sitePrefix = (window.sitePrefix) ? window.sitePrefix : "";
        }

    };
}]);