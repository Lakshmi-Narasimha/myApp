/**
 * @ngdoc service
 * @name transactions Grid Config Model
 * @requires MyInvestorConstant
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var transactionsGridConfigModel = function (fticLoggerMessage, loggerConstants, MyInvestorConstant) {

    var _summaryGridConfig = {};
    var _detailsGridConfig = {};
    var _totalRow = {};

    _totalRow[MyInvestorConstant.MY_INVSTR_PURCHASE] = "totalPurchasedAmount";
    _totalRow[MyInvestorConstant.MY_INVSTR_REDEMPTION] = "totalRedemptionAmount";
    _totalRow[MyInvestorConstant.MY_INVSTR_SWITCH] = "switchAmount";
    _totalRow[MyInvestorConstant.MY_INVSTR_DIVIDENDS] = "dividendAmount";
    _totalRow[MyInvestorConstant.MY_INVSTR_LIEN] = "remarks";
    _totalRow[MyInvestorConstant.MY_INVSTR_POSTAL_RETURNS] = "unclaimedUnits";
    _totalRow[MyInvestorConstant.MY_INVSTR_NOMINATION_DETAILS] = "percentageAllocation";    

    var detailsTemplatePurchase = '<div uib-popover-template="\'transactionviewdetails.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                              '<script type="text/ng-template" id="transactionviewdetails.html">' +
                              '<div><button type="button" ng-click="grid.appScope.$emit(\'showTransactionDetails\', COL_FIELD)" class="btn panel-orange-btn m0">View Purchase Details</button></div></script>';
    
    var detailsTemplateRedemption = '<div uib-popover-template="\'transactionviewdetails.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                              '<script type="text/ng-template" id="transactionviewdetails.html">' +
                              '<div><button type="button" ng-click="grid.appScope.$emit(\'showTransactionDetails\', COL_FIELD)" class="btn panel-orange-btn m0">View Redemption Details</button></div></script>';
    
    var detailsTemplateSwitch = '<div uib-popover-template="\'transactionviewdetails.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                              '<script type="text/ng-template" id="transactionviewdetails.html">' +
                              '<div><button type="button" ng-click="grid.appScope.$emit(\'showTransactionDetails\', COL_FIELD)" class="btn panel-orange-btn m0">View Switch Details</button></div></script>';
    
    var detailsTemplateDividends = '<div uib-popover-template="\'transactionviewdetails.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                              '<script type="text/ng-template" id="transactionviewdetails.html">' +
                              '<div><button type="button" ng-click="grid.appScope.$emit(\'showTransactionDetails\', COL_FIELD)" class="btn panel-orange-btn m0">View Dividends Details</button></div></script>';
    var roundNumTemplate='<div class="ui-grid-cell-contents">{{grid.getCellValue(row, col) | number:2}}</div>';
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_PURCHASE] = [
        { field: 'detailButtom', displayName: '', width: "48", cellTemplate: detailsTemplatePurchase, pinnedLeft:true},
        { field: 'folioNo', displayName: 'Folio No.', width: "159", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'fund', displayName: 'Fund', width: "253", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolutions', displayName: 'Family Solutions', width: "130", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:true},
        { field: 'totalPurchasedAmount', displayName: 'Total Purchased Amount', width: "203", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader fti-grid-rupeeIcon ', enableSorting:false}
    ],
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_REDEMPTION] = [
        { field: 'detailButtom', displayName: '', width: "48", cellTemplate: detailsTemplateRedemption, pinnedLeft:true},
        { field: 'folioNo', displayName: 'Folio No.', width: "159", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'fund', displayName: 'Fund', width: "253", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolutions', displayName: 'Family Solution', width: "130", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'totalRedemptionAmount', displayName: 'Total Redemption Amount', width: "203", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
    ],
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_SWITCH] = [   
        { field: 'detailButtom', displayName: '', width: "48", cellTemplate: detailsTemplateSwitch, pinnedLeft:true},
        { field: 'folioNo', displayName: 'Folio No.', width: "159", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'sourceFund', displayName: 'Source Fund', width: "172", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'destinationFund', displayName: 'Destination Fund', width: "192", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolutions', displayName: 'Family Solution', width: "132", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'switchAmount', displayName: 'Switch Amount', width: "132", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
    ],
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_DIVIDENDS] = [
        { field: 'detailButtom', displayName: '', width: "48", cellTemplate: detailsTemplateDividends, pinnedLeft:true},
        { field: 'folioNo', displayName: 'Folio No.', width: "159", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'accountNo', displayName: 'Account No', width: "110", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'fund', displayName: 'Fund', width: "148", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'paymentOption', displayName: 'Payment Option', width: "125", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolutions', displayName: 'Family Solution', width: "125", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'dividendAmount', displayName: 'Dividend Amount', width: "140", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
    ],
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_LIEN] = [
        { field: 'folioNo', displayName: 'Folio No.', width: "110", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'accountNumber', displayName: 'Account No.', width: "120", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'fund', displayName: 'Fund', width: "150", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'unitBalance', displayName: 'Unit Balance', width: "120", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'currentValue', displayName: 'Current Value', width: "120", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'lienUnits', displayName: 'LIEN Units', width: "110", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolutions', displayName: 'Family Solution', width: "140", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'valueOfLienUnits', displayName: 'Value of LIEN Units', width: "90", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'remarks', displayName: 'Remarks', width: "100", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
        
    ],
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_POSTAL_RETURNS] = [
        { field: 'folioNo', displayName: 'Folio No.', width: "110", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'accountNumber', displayName: 'Account No.', width: "100", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'fund', displayName: 'Fund', width: "148", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'transactionType', displayName: 'Transaction Type', width: "130", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'amount', displayName: 'Amount', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'postalReturns', displayName: 'Postal Returns', width: "130", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'unclaimedFund', displayName: 'Unclaimed Fund', width: "250", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolution', displayName: 'Family Solutions', width: "130", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'unclaimedUnits', displayName: 'Unclaimed Units', width: "130", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
    ],
    _summaryGridConfig[MyInvestorConstant.MY_INVSTR_NOMINATION_DETAILS] = [
        { field: 'folioNo', displayName: 'Folio No.', width: "110", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
        { field: 'accountNo', displayName: 'Account No.', width: "145", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'fund', displayName: 'Fund', width: "145", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'nomination', displayName: 'Nomination', width: "125", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'familySolutions', displayName: 'Family Solution', width: "145", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},        
        { field: 'percentageAllocation', displayName: 'Percentage allocation', width: "165", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}                
    ],
    _detailsGridConfig[MyInvestorConstant.MY_INVSTR_PURCHASE] = [
        { field: 'purchaseDate', displayName: 'Purchase Date', width: "167", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'purchaseAmount', displayName: 'Purchase Amount', width: "167", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'nav', displayName: 'NAV', width: "167", headerCellClass: 'fti-grid-sortDisabledHeader',cellTemplate: roundNumTemplate, enableSorting:false},
        { field: 'units', displayName: 'Units', width: "167", headerCellClass: 'fti-grid-sortDisabledHeader',cellTemplate: roundNumTemplate, enableSorting:false},
        { field: 'status', displayName: 'Status', width: "167", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
    ],
    _detailsGridConfig[MyInvestorConstant.MY_INVSTR_REDEMPTION] = [
        { field: 'redemptionDate', displayName: 'Redemption Date', width: "139", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'redemptionAmount', displayName: 'Redemption Amount', width: "160", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'nav', displayName: 'NAV', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'units', displayName: 'Units', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'bankName', displayName: 'Bank Name', width: "119", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'bankAccountNo', displayName: 'Bank Account No', width: "138", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'payoutType', displayName: 'Payout Type', width: "119", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}        
    ],
    _detailsGridConfig[MyInvestorConstant.MY_INVSTR_SWITCH] = [
        { field: 'switchOutDate', displayName: 'Switch Out Date', width: "100", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'SwitchInDate', displayName: 'Switch In Date', width: "100", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'destinationFund', displayName: 'Destination Fund', width: "140", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'destinationAccountNo', displayName: 'Destination Account No', width: "100", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'switchAmount', displayName: 'Switch Amount', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'switchOutNAV', displayName: 'Switch Out NAV', width: "100", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'switchInNAV', displayName: 'Switch In NAV', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'units', displayName: 'Units', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'status', displayName: 'Status', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'type', displayName: 'Type', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}                             
    ],
    _detailsGridConfig[MyInvestorConstant.MY_INVSTR_DIVIDENDS] = [
        { field: 'dividendRecordDate', displayName: 'Dividend Record Date', width: "110", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'dividendPaymentDate', displayName: 'Dividend Payment Date', width: "109", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'dividendOption', displayName: 'Dividend Option', width: "139", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'dividendAmount', displayName: 'Dividend Amount', width: "80", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'bankName', displayName: 'Bank Name', width: "119", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'bankAccountNo', displayName: 'Bank Account No', width: "138", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
        { field: 'modeOfPayment', displayName: 'Mode of Payment', width: "138", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
    ];

    var transactionsGridConfigModel = {
        summaryGridConfig: _summaryGridConfig,
        detailsGridConfig: _detailsGridConfig,
        totalRow: _totalRow
    };
    return transactionsGridConfigModel;
};

transactionsGridConfigModel.$inject = ['fticLoggerMessage', 'loggerConstants', 'MyInvestorConstant'];

module.exports = transactionsGridConfigModel;