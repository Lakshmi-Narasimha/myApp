// submitDetailsInfo.route.js
var express = require('express');
var router = express.Router();
var submitDetailsInfo = require('./submitPaymentDetails.model');

// api route
var  error = {
    errorMessageCode: 500,
    errorDescription: "Something went wrong..."
};

var submitDataError = {  
    "uiErrorDipslayMessage":"We were not able to process your request. Please try again. If you still need help, contact Farmers Consumer Solutions at 1-877-327-6392",
    "transactionStatus":"E",
    "transactionDescription":"Invalid account Number",
    "transactionCode":"E4522",
    "confirmationNumber" :null,
    "billingScheduledMaintenance" : "N",
    "estimatedDowntime": "01:56:07"
};


router.route('/submitPaymentDetails')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        if (!req.body["functionName"] &&
            !req.body["billingAccountNumber"]) {
            res.send(error);
        }

        var matcherObjectPrelogin = {
            $elemMatch: {
                "functionName": req.body.functionName
            }
        };

        var matchObject;

        if (req.body.functionName === "Prelogin") {
            matchObject = matcherObjectPrelogin;
        } 

        submitDetailsInfo.find({}, {
            submitObject: matchObject
        }, function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (!data) {  
                res.send(submitDataError);
            } else if (data) {
                if (data[0].submitObject[0].functionName === "Prelogin") {
                    res.json(data[0].submitObject[0].dataResponseObject);
                }
            }
        });
    });


module.exports = router;
