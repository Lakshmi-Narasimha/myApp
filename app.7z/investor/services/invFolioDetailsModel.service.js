/**
 * @ngdoc service
 * @name eform model service
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Eform Model deals with the fetching data from the service and returning the promise object as well as setting and getting the data. 
 *
 */

'use strict';

var invFolioDetailsModel = function (Restangular, $q, authenticationService, investorConstants, loggerConstants, fticLoggerMessage) {
    
    var _folioAccounts = null;
    var params;
    var invFolioDetailsModel = {
        getFolioAccountDetails: function(paramsObj) {
            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_EFORMS_MODULE + ' | ' + loggerConstants.INV_COMMON_FOLIO_DETAILS_MODEL + ' | getFolioAccountDetails' /* Function Name */;
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            params = paramsObj || {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one(investorConstants.eforms.INV_EFORMS_FOLIO_ACC_URL).get(params).then(function(response) {
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setFolioAccountData: function(folios) {
            _folioAccounts = folios.panFolioAccounts;
        },
        getFolioAccountData: function() {
            return _folioAccounts;
        }
    };
    return invFolioDetailsModel;
};

invFolioDetailsModel.$inject = ['Restangular', '$q', 'authenticationService', 'investorConstants', 'loggerConstants', 'fticLoggerMessage'];

module.exports = invFolioDetailsModel;
