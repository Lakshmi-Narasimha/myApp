/**
 * @ngdoc property
 * @name transDetails Directive
 * @description
 *
 * transDetails - Displays investor details, fund details, redemption details
 *
 **/
'use strict';

var transDetails = function() {
	return {
        template: require('./redeem_TransactionDetails.html'),
        restrict: 'E',
        replace: true,
        scope:{
            panelList : "="
        }
    }
};

transDetails.$inject = [];
module.exports = transDetails;