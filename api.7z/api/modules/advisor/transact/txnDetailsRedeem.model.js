// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetTxnRedeemModelSchema = new mongoose.Schema({
    GetTxnRedeemResp: {
        type: Array,
        "default": []
    }
});

var GetTxnRedeemModelLookUp = mongoose.model('GetTxnRedeemModelLookUp', GetTxnRedeemModelSchema);

var GetTxnRedeemModel = new GetTxnRedeemModelLookUp({
    GetTxnRedeemResp : {
  "customerInfoVo": {
    "custName": "MUNIRA ABDI HARARWALA D AVASHIA SURESH PANJWANI",
    "address1": "HOUSE NO 429 ",
    "address2": "I CROSS J S NAGAR",
    "address3": "NEW NALLAKUKUNTA",
    "address4": "605602",
    "city": "MELLINGEN",
    "pinCode": "400101",
    "firstHolderName": "MUNIRA ABDI HARARWALA D AVASHIA SURESH PANJWANI",
    "secondHolderName": "",
    "thirdHolderName": "",
    "guardian": "",
    "firstHolderPanNo": "CTZQF2638E",
    "secondHolderPanNo": "",
    "thirdHolderPanNo": "",
    "guardianPanNo": "",
    "firstHolderKycStatus": "KYC - Registered",
    "secondHolderKycStatus": "KYC - Registered",
    "thirdHolderKycStatus": "KYC - Registered",
    "guardianKycStatus": "",
    "socialStatus": "Individual",
    "holdingType": "Single",
    "bankdetails": "33688052500940/HDFC BANK LTD/MADHAPUR HYDERABAD",
    "paymentType": "Amount",
    "paymentMode": "Directly To Bank"
  },
  "retrieveSipVo": null,
  "fundOptions": [
    {
      "accNo": "0069900835384",
      "amount": "10000",
      "direct": "",
      "dividendFlag": null,
      "endDate": "",
      "frequency": "",
      "fundCategory": "",
      "fundOptDesc": "",
      "fundOption": "006",
      "fundType": "",
      "minAddPurAmt": "",
      "minNewPurAmt": "",
      "minSipAmt": "",
      "multiples": "",
      "nfoFlag": null,
      "payoutFlag": "",
      "perpetualFlag": "",
      "reinvestmentFlag": "",
      "startDate": "",
      "stepUpFrequency": "",
      "stepUpType": "",
      "stepUpValue": "",
      "txnType": ""
    }
  ],
  "invPaymentBank": null,
  "paymentMode": "",
  "folioId": "14504452",
  "accountType": null,
  "paymentBankAccNo": null,
  "invAmount": "80000",
  "subBrokerCode": null,
  "subBrokerARN": null,
  "euin": null,
  "txn_no": "RED9124",
  "seq_no": "1",
  "account_number": "",
  "fund_option": "",
  "batch_code": "WEB",
  "trxn_requested_date": "2016-02-26 00:00:00.0",
  "trxn_requested_time": "10:00",
  "txn_source": "R",
  "sub_distributor_id": null,
  "ref_txn_no": null,
  "application_sr_no": null,
  "remarks": null,
  "maker_id": "Mobile",
  "maker_date": "2016-03-14 00:00:00.0",
  "auth_id": "Mobile",
  "auth_date": "2016-03-14 00:00:00.0",
  "acc_ref_no": null,
  "transferflag": "0",
  "trtype": "R",
  "web_refno": "RED9124",
  "transaction_flag": "C",
  "mode_of_txn": null,
  "euin_flag": null,
  "trxn_units": "250",
  "all_units_flag": "Y",
  "start_date": "",
  "end_date": "",
  "frequency": null,
  "perpetual_flag": null,
  "mf_code": null,
  "destination_account_number": null,
  "destination_fund_option": null,
  "sip_txn_status": null,
  "urn_no": null,
  "nfo_flag": "",
  "priority_batch_flag": null,
  "trxn_effective_date": null,
  "amount_unit_flag": "U",
  "dc_last_xdigits": null,
  "dc_name_on_card": null,
  "check_no": null,
  "dividend_option": "",
  "account_source": null,
  "branch_code": null,
  "no_of_installments": null,
  "lbd_flag": null,
  "umrn_no": null,
  "source": null,
  "renewal_flag": null,
  "paymentOption": null,
  "aadhaar": "",
  "pepFlag": "",
  "stepUpType": null,
  "stepUpValue": null,
  "emandateDebitType": null,
  "emandateFrequency": null,
  "emandateAmount": null,
  "untillCancel": null,
  "emandateFromdate": null,
  "emandateTodate": null,
  "stepUpFrequency": null
}

});


GetTxnRedeemModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetTxnRedeemModelLookUp table, please contact admin...');
    } else {
        GetTxnRedeemModelLookUp.remove({}, function(err) {
            console.log('GetTxnRedeemModelLookUp collection removed');
            GetTxnRedeemModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetTxnRedeemModelLookUp table, please contact admin...');
                }
                console.log('GetTxnRedeemModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GetTxnRedeemModelLookUp;