
(function() {
  'use strict';

  angular
    .module('CSS.justPay')
    .controller('JustPayMainController', JustPayMainController);

  JustPayMainController.$inject = ['$rootScope'];

  function JustPayMainController($rootScope) {
    var vm = this;
    $rootScope.bgcolor=true;
    $rootScope.copyrighdata = window.year;
  }

})();
