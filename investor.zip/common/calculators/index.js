/**
 *@ngdoc object
 *@name advisor.module:Calculators
 *@description
 * <p>
 * Calling the services those are for showing the pages
 * </p>
 */


'use strict';
module.exports = angular.module('common.calculators', [
	require('./constants').name
	])
	.config(require('./calculators.routes'))
	.controller('sipCalculatorController', require('./sipcalculator/sipCalculator.controller'))
	.directive('fticFundCalculator', require('./components/fundcalculator/fundCalculator.directive'))
	.directive('fticSipCalculatorForm', require('./sipcalculator/components/sipCalculatorForm/sipCalculatorForm.directive'))
	.directive('fticSipCalculatorChart', require('./components/sipCalculatorChart/sipCalculatorChart.directive'))
	.factory('sipCalculatorInitialService', require('./services/sipCalculatorInitialLoader.service'))
	.factory('sipCalculatorModel', require('./services/sipCalculator.model'))
	.controller('taxAdvantageCalculatorController', require('./taxadvantagecalculator/taxAdvantageCalculator.controller'))
	.controller('lumpsumCalculatorController', require('./lumpsumcalculator/lumpsumCalculator.controller'))
	.controller('comparissionCalculatorController', require('./comparissioncalculator/comparissionCalculator.controller'))
	.directive('fticLumpsumCalculatorForm', require('./lumpsumcalculator/components/lumpsumCalculatorForm/lumpsumCalculatorForm.directive'))
	.controller('siptabController', require('./comparissioncalculator/components/sip/sip.controller'))
	.controller('lumpsumtabController', require('./comparissioncalculator/components/lumpsum/lumpsumtab.controller'))
	.directive('fticTaxCalculatorForm', require('./taxadvantagecalculator/components/taxCalculatorsForm/taxCalculatorsForm.directive'))
	.directive('fticTaxCalculatorGrid', require('./taxadvantagecalculator/components/taxCalculatorGrid/taxCalculatorGrid.directive'))
	.factory('taxCalculatorModel', require('./services/taxCalculators.model'))
	.factory('taxCalculatorInitialService', require('./services/taxCalculatorsInitalLoader.service'))
	.controller('commissionCalculatorController', require('./commissioncalculator/commissionCalculator.controller'))
	.controller('commissionSipController', require('./commissioncalculator/components/sip/commissionSip.controller'))
	.controller('commissionLumpsumController', require('./commissioncalculator/components/lumpsum/commissionLumpsum.controller'))
	.directive('fticCommissionCalculatorGrid', require('./commissioncalculator/components/commissionCalculatorGrid/commissionCalculatorGrid.directive'))
	.factory('commissionCalculatorModel', require('./services/commissionCalculator.model'))
	.directive('fticComparissionCalculatorChart', require('./comparissioncalculator/components/comparissionchart/comparissionCalculatorChart.directive'))
	.controller('simulatorsController',require('./components/simulators/simulators.controller'))
	.factory('comparisonCalculatorInitialService', require('./services/comparisonCalculatorInitialLoader.service'))
	.factory('comparisonCalculatorModel', require('./services/comparisonCalculator.model'))
	;