/**
 * @ngdoc directive
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires investorConstants
 * @description
 *
 * - It displays error
 * 
 **/
'use strict';

var invErrorMessage = function(investorConstants) {
    return {
        restrict: 'AEC',
        template: require('./invErrorMessage.html'),
        replace: true,
        scope: true,
        link: function(scope) {
            scope.errorObj = scope.errorObj || { title: investorConstants.dashboard.SORRY, message: investorConstants.dashboard.DATA_CURRENTLY_UNAVAILABLE };
        }
    };

};

invErrorMessage.$inject = ['investorConstants'];
module.exports = invErrorMessage;
