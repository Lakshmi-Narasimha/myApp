/**
 * @ngdoc directive
 * @name ftickeyValueVerticalTileMoreInfo
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - ftickeyValueVerticalTileMoreInfo will display the vertical tiles with more info ellipse.
 * 
 *
 **/
'use strict';

var keyValueVerticalTileMoreInfo = function() {
	return {
            template: require('./keyValueVerticalTileMoreInfo.html'),
            restrict: 'E',
            replace: true,
            scope: {
                verticalTileObj: '='
            }
        };
};

keyValueVerticalTileMoreInfo.$inject = [];
module.exports = keyValueVerticalTileMoreInfo;