/**
 * @ngdoc directive
 * @name panel header
 * @requires advisorAlertsModel
 * @requires eventConstants
 * @requires $filter
 * @requires advisorEvents
 * @description
 *
 * - It represents the header part of each and every module containing heading along with the close option.
 *
**/

'use strict';

var panelHeader = function(eventConstants, $filter, $rootScope, events) {
	return {
            template: require('./panelHeader.html'),
            restrict: 'E',
            replace: true,
            scope: {
                panelInfo : '=info',
                isBadge : '=',
                isClosed : '=',
                length:'=',
                eventName :'@?',
                actionClass :'@?'
            },
            link: function(scope){
                console.log(scope.panelInfo);

                 scope.$on(eventConstants.ACTION_ICON_CLICKED, function (event, args) {         
                 scope.$emit(scope.eventName);
                });
                 //scope.$emit(scope.eventName);
                scope.removePanel = function (preference) {
                   
                    angular.element( document.querySelector( '.userPreference #'+$filter('fticTrim')(preference.id) )).remove(); 
                    events.updatePersonalizedCheckEmit(scope, {'preference':preference.id});
                }

            }
        };
};

panelHeader.$inject = ['eventConstants', '$filter', '$rootScope', 'events'];
module.exports = panelHeader;