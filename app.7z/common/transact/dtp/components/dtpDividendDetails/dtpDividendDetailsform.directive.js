/**
 * @ngdoc property
 * @name Switch Form Directive
 * @requires $state
 * @requires $timeout
 * @requires 
 * @description
 *
 * - Switch form directive will represent the form details of switch module in transact controller.
 *
 **/
'use strict';

var dtpDividendForm = function($state, $timeout, dtpModel, $filter, TransactConstant, transactModel, toaster, $stateParams, transactEventConstants, fundDetailsModel, authenticationService,reviewDtpDetailsModel) {
    return {
        template: require('./dtpDividendDetailsform.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope, $element, $attrs) {
            var _userType = authenticationService.getUser().userType;
            $scope.reinvestmentDisable = false;
            $scope.payoutDisable = false;
            var switchType;
            $scope.continueBtn = true;

            $scope.config = {};
            $scope.config.showNotification = false;

            $scope.radios = {};
            $scope.dividendOptns = [$filter('translate')(TransactConstant.transact.RE_INVESTMENT), $filter('translate')(TransactConstant.transact.PAYOUT)];

            $scope.radios.selectedVal = $scope.dividendOptns[0];
            dtpModel.setType($scope.radios.selectedVal);

            function SetDetailsGoReview() {
                dtpModel.validateDTP().then(function(data) {
                    if (_userType && (_userType.toString() === '10')) {
                        $state.go('invTransact.review.dtp');
                    } else {
                        $state.go('transact.review.swp');
                    }
                    transactModel.setvalidateSWITCHDetails(data);
                    transactModel.setWebRefNo(data.webRefNo);
                }, function(data) {
                    toaster.error(data.data[0].errorDescription);
                });
            }

            function clearInputValues() {
                $scope.inputObjs[0].value = "";
                $scope.inputObjs[1].value = "";
            }
            $scope.typeChanged = function(val) {
                    dtpModel.setType(val);
                    /*$scope.inputObjs[0].disable = true;
                    $scope.inputObjs[1].disable = true;
                    $scope.inputObjs[0].isRequired = false;
                    $scope.inputObjs[1].isRequired = false;
                    if ($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.FULL)) {
                        switchType = $filter('translate')(TransactConstant.transact.FULL);
                        var valueOfTotalAvailableUnits = parseFloat(fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits);
                        var totalAvailableUnits = parseFloat(fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits);
                        // $scope.inputObjs[0].value = valueOfTotalAvailableUnits;
                        $scope.inputObjs[1].value = totalAvailableUnits;
                        $scope.inputUnit = $element[0].querySelector('.unit-label input');
                        // $scope.inputAmount = $element[0].querySelector('.fixed-amount-label input');
                        angular.element($scope.inputUnit).triggerHandler('focus');
                        // angular.element($scope.inputAmount).triggerHandler('focus');
                    } else {
                        switchType = $filter('translate')(TransactConstant.transact.PARTIAL);
                        if ($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.AMT_CAP)) {
                            clearInputValues();
                            // $scope.inputObjs[1].value = "";    
                            $scope.inputObjs[0].disable = false;
                            $scope.inputObjs[0].isRequired = true;
                            angular.element($scope.inputAmount).triggerHandler('blur');
                            // $scope.inputObjs[1].value = transactModel.convertAmountToUnit($scope.inputObjs[0].value, 10);
                        } else if ($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.UNITS_CAP)) {
                            clearInputValues();
                            // $scope.inputObjs[0].value = "";
                            $scope.inputObjs[1].disable = false;
                            $scope.inputObjs[1].isRequired = true;
                            angular.element($scope.inputUnit).triggerHandler('blur');
                            // $scope.inputObjs[0].value = transactModel.convertUnitToAmount($scope.inputObjs[1].value, 10);                            
                        }
                    }*/
                }
                // this is done for auto-populating the Amounts and Units simultaniously.
            $scope.$on('INPUT_CHANGED', function(event, data) {
                if (data.value) {
                    var nav = fundDetailsModel.getFundDetails().fundDetails[0].lastestNav;
                    if (data.value && dtpModel.getType() === "Full") {
                        $scope.inputObjs[0].value = "";
                    }
                    if (data.value && data.key == "amount") {

                        if (dtpModel.getType() === "Amount") {
                            if (data.value) {
                                $scope.inputUnit = $element[0].querySelector('.unit-label input');
                                // angular.element($scope.inputUnit).triggerHandler('focus');
                                // $scope.inputObjs[1].value = transactModel.convertAmountToUnit(data.value, nav);
                            }
                        }
                    }
                    if (data.value && data.key == "units") {

                        if (dtpModel.getType() === 'Units') {
                            if (data.value) {
                                $scope.inputAmount = $element[0].querySelector('.fixed-amount-label input');
                                // angular.element($scope.inputAmount).triggerHandler('focus'); 
                                // $scope.inputObjs[0].value = transactModel.convertUnitToAmount(data.value, nav);
                            }
                        }
                    }
                }
            });
            /*$scope.$on("Edit_Form", function(){
                $scope.typeChanged();
            });*/
            // $scope.continueBtn = false;
            if ($stateParams.key === "dtp") {

                // $scope.continueBtn = true;
                setPreviousData();
            }

            function setPreviousData() {
                $scope.$emit("Select_Fund_Continue");
                $scope.switchValues = transactModel.getTransactDetails().switchDetails;
                $scope.fundObj = {};
                $scope.fundObj = $scope.switchValues.destinationFund;
                switchType = $scope.switchValues.switchType;
                $timeout(function() {
                    $scope.$broadcast(transactEventConstants.transact.EDIT_FUND, { fundObj: $scope.fundObj });
                }, 0)
                
                $scope.radios.selectedVal = $scope.switchValues.switchType;
            }


            // $scope.swpDetails = {};

            function changedtpForm() {
                $scope.radios.selectedVal = "";
                $scope.inputObjs[0].value = "";
                $scope.inputObjs[1].value = "";
                $scope.typeChanged();
            }
            $scope.$on(transactEventConstants.transact.SWITCH_FORM_RESET, function(event) {
                changedtpForm();
            });
            $scope.$on("disableDividendOption", function(event, data) {
                var growthSubstring = "Growth";
                var taxsheildSubstring = "Taxshield";
                if (data.fundOptDesc.indexOf(taxsheildSubstring) !== -1) {
                    $scope.radios.selectedVal = $scope.dividendOptns[1];
                    $scope.reinvestmentDisable = true;
                     $scope.payoutDisable = false;
                     dtpModel.setType($scope.radios.selectedVal);

                } else if (data.fundOptDesc.indexOf(growthSubstring) !== -1) {
                    $scope.radios.selectedVal = "";
                    $scope.reinvestmentDisable = true;
                    $scope.payoutDisable = true;
                    if($scope.radios.selectedVal == ""){
                         dtpModel.setType("NA");
                    }
                   
                }else{
                      $scope.reinvestmentDisable = false;
                    $scope.payoutDisable = false;
                     $scope.radios.selectedVal = $scope.dividendOptns[0];
                    dtpModel.setType($scope.radios.selectedVal);

                }

            });
            $scope.types = dtpModel.getType();
            //var editReviewDTPDetails = reviewDtpDetailsModel.getReviewDtpObj();
            editDTP();
            function editDTP(){
                if(reviewDtpDetailsModel.isSwitchEdited){
                   var selectedItems = dtpModel.getDataObj();
                   $scope.radios.selectedVal = selectedItems.switchType;
                   $scope.destinationFund = selectedItems.destinationFund
                }
            };
               //Dividend options flag setting based on the fund selected
           /* $scope.$on(transactEventConstants.transact.FUND_UPDATED, function(event){
                if(!$scope.fundLimit){
                    $scope.fundLimit = parseInt(newFundDetailsModel.getMaxFundLimit());
                }
                $scope.reinvestmentDisable = false;
                $scope.payoutDisable = false;
            });*/
            $scope.postStpDetails = function() {
                $scope.config.showNotification = false;
                $scope.$emit("dtpFormSubmit");
                var switchModel = {};
                var switchBaseDtlsObj = {
                    destinationFund: angular.copy($scope.destinationFund),
                    switchType: $scope.radios.selectedVal,
                    type: ""
                };
                //$scope.dtpForm.dividendType.$viewValue

                /*      if (switchType == $filter('translate')(TransactConstant.transact.PARTIAL)) {
                          if ($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.AMT_CAP)) {
                              switchBaseDtlsObj.amount = $scope.inputObjs[0].value;
                              switchBaseDtlsObj.type = $scope.radios.selectedVal;
                          } else if ($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.UNITS_CAP)) {
                              switchBaseDtlsObj.units = $scope.inputObjs[1].value;
                              switchBaseDtlsObj.type = $scope.radios.selectedVal;
                          }

                      } else if ($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.FULL)) {
                          switchType = $filter('translate')(TransactConstant.transact.FULL);
                          var valueOfTotalAvailableUnits = parseFloat(fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits);
                          // $scope.inputObjs[0].value = valueOfTotalAvailableUnits;
                          // switchBaseDtlsObj.amount = $scope.inputObjs[0].value;
                          var totalAvailableUnits = parseFloat(fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits);
                          $scope.inputObjs[1].value = totalAvailableUnits;
                          switchBaseDtlsObj.units = $scope.inputObjs[1].value;
                          switchBaseDtlsObj.type = $scope.radios.selectedVal;
                      }*/


                if ($scope.dtpForm.$valid && $scope.destinationFund) {

                    dtpModel.setDataObj(switchBaseDtlsObj);
                    switchModel.investorDetails = transactModel.getInvestorDetails();
                    switchModel.fundDetails = transactModel.getFundDetails();
                    switchModel.switchDetails = switchBaseDtlsObj;
                    switchModel.fundDetails.dividendType = $scope.dtpForm.dividendType.$viewValue;
                    if ($stateParams.key == 'dtp') {
                        $scope.config.showNotification = false;
                        var result = _.isEqual(transactModel.getTransactDetails().switchDetails, switchModel.switchDetails);
                        if (!result) {
                            $scope.config.showNotification = true;
                            var destroyHandler = $scope.$on('yes', function() {
                                transactModel.setTransactDetails(switchModel);
                                SetDetailsGoReview();
                                $scope.config.showNotification = false;
                                destroyHandler();
                            });

                            $scope.$on('no', function() {
                                $scope.config.showNotification = false;
                                setPreviousData();
                            });
                        } else
                            SetDetailsGoReview();
                    } else {
                        transactModel.setTransactDetails(switchModel);
                        SetDetailsGoReview();
                    }
                }
            }
        }
    };

};

dtpDividendForm.$inject = ['$state', '$timeout', 'dtpModel', '$filter', 'TransactConstant', 'transactModel', 'toaster', '$stateParams', 'transactEventConstants', 'fundDetailsModel', 'authenticationService','reviewDtpDetailsModel'];

module.exports = dtpDividendForm;
