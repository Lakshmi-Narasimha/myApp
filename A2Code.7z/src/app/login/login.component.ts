import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import {  AuthenticationService } from '../_services/authentication.service';
import { AIAssistAlertService } from '../_services/aialert.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

    model: any = {};
    loading = false;
    returnUrl: string;
    clientList = [
      {id:'MFChat', name:'MFChat'},
      {id:'FB', name:'FB'},
      {id:'Google Home', name:'Google Home'}
    ];

    selectedElement = this.clientList[0].id;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AIAssistAlertService) {       this.model.client = this.clientList[0].id; }

    ngOnInit() {
        // reset login status
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    login() {
        this.loading = true;
        // if ( this.authenticationService.login(this.model.username, this.model.password, this.model.client) ) {
        //   this.router.navigate([this.returnUrl])
        // } else {
        //   this.alertService.setMessage("danger", "Unable to login");
        //   this.loading = false;
        // }
            this.authenticationService.login(this.model.username, this.model.password, this.model.client).subscribe(
                data => {
                    this.router.navigate([this.returnUrl]);
                    this.alertService.clearAlertMessages();
                },
                error => {
                    this.alertService.setMessage("danger", error);
                    this.loading = false;
                });
    }
}
