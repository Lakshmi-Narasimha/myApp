/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function transactController($scope, fticLoggerMessage, loggerConstants, selectFundModel, $state ,$stateParams, selectFundInitialLoader,eventConstants,$timeout,transactModel,transactEventConstants,TransactConstant,selectInvestorModel,newFundDetailsInitialLoader,ftiModifySipInitialLoader, paperlessModel, bankDtlsModel,redeemModel,swpModel,stpDetailsModel) {
    console.info("Transact Controller!!");
    //Need to check the conflict in the below code in edit case and new investor case.
    // if(!$stateParams.key){
    //     transactModel.resetSetters();
    //     transactModel.isNewInvestor = false;
    // }
    $scope.isNewInvestor = transactModel.isNewInvestor;
    $scope.isNewFolio = transactModel.getIsNewFolio();
    $scope.isOpenInvGrid = {};
    $scope.isOpenFundGrid = {};
    $scope.isOpenRedeemGrid = {};
    $scope.isOpenPayDetails = {};
    
    $scope.isOpenNomineeGrid={};
    SetInitialValues();
    $scope.config = {};
    $scope.config.detailsHeading = "";
    $scope.keyValueList = [];
    /*$scope.eventName = "FlexiSip";*/
    // Needs to be set in respective controller with property "title"
    $scope.config.txnFormDetails = {};  
    $scope.config.txnFormPayDetails = {};  
    $scope.config.txnFundDetails = {};
    //$scope.ifNewInvestor=true;
    $scope.isNomineeEdit = false;

    $scope.stateStatus = null;
    $scope.stateStatus = transactModel.getStateValue();
    $scope.$on(transactEventConstants.transact.Pay_Detail_Show,function(event,data){
        $scope.isPaymentDetailsIni = true;
        $scope.isDisablePayDetails = true;
    });
    
    $scope.$on(transactEventConstants.transact.Payment_Detail,function(event,data){
        $scope.isOpenPayDetails.open = true;
        $scope.isDisablePayDetails = false;
        $scope.isOpenRedeemGrid.open = false;
    });

    if($scope.stateStatus){
        $timeout(function(){
            if ($scope.stateStatus.key == TransactConstant.transact.Investor_Key){

            }
            else if ($scope.stateStatus.key == TransactConstant.transact.Fund_Key){
                selectInvestorTile();
                $scope.isInitialShow = false;
                $scope.isDisableReedemGrid = true;        
                $scope.isDisableReedemGrid = true;
            }
            else if ($scope.stateStatus.key == TransactConstant.transact.Redeem_Key || $scope.stateStatus.key == TransactConstant.transact.SWP_Key || $scope.stateStatus.key == TransactConstant.transact.Switch_Key || $scope.stateStatus.key == TransactConstant.transact.Stp_Key || $scope.stateStatus.key == TransactConstant.transact.Payment_Key || $scope.stateStatus.key == TransactConstant.transact.NOMINEE_KEY){
                $scope.$broadcast(transactEventConstants.transact.Selected_Investor);                
                showFundView();
                $scope.isShowInvestorDetails = false;
                $scope.isInitialShow = false;
            }
        },0);
    }
    
    $scope.$on(transactEventConstants.transact.Set_Key_Value_Transact,function(event,data){
        $scope.keyValueList = data;
        $scope.isShowReedemGrid = false;
    })

    $scope.$on("FlexiSip",function(event,data){
        $scope.keyValueList = [];
        $scope.isShowReedemGrid = true;
        $scope.isOpenPayDetails.open = false;
        $scope.isDisablePayDetails = true;
        $scope.isOpenRedeemGrid.open = true;
    })


    $scope.$on(transactEventConstants.transact.Investor_Details,function(event,data){  
       selectInvestorTile();
    });

    $scope.$on("ChangePayment", function() {
        $scope.$broadcast("ChangePaymentOnChange");
    })
    $scope.$on(transactEventConstants.transact.Open_Grid,function(event,data){ 
        $scope.isInitialShow = false;
        $scope.isDisableFundGrid = true;
        $scope.isDisableReedemGrid = true;
        $scope.moduleUrl = $state.current.url;
        if(($scope.moduleUrl=="/buy" || $scope.moduleUrl=="/sip") && ($scope.ifNewInvestor || $scope.isNewFolio)){
            $scope.isShowNomineeGrid=true;
            $scope.isDisableNomineeGrid=true;
        }
    });

    $scope.$on(transactEventConstants.transact.Show_Fund,function(event,data){  
        showFundView();
    });

    $scope.$on(transactEventConstants.transact.RESET_REDEEM_FORM, function(event){
        $scope.$broadcast(transactEventConstants.transact.REDEEM_FORM_RESET); 
    });
    $scope.$on(transactEventConstants.transact.RESET_SWP_FORM, function(event){
        $scope.$broadcast(transactEventConstants.transact.SWP_FORM_RESET); 
    });
    $scope.$on(transactEventConstants.transact.RESET_SWITCH_FORM, function(event){
        $scope.$broadcast(transactEventConstants.transact.SWITCH_FORM_RESET); 
    });
    
    $scope.$on("Select_Fund_Continue", function(event,data){
        $scope.$broadcast("Call_Balance_Units");
        $scope.$broadcast("Call_Registered_banks");
        $scope.$broadcast("Edit_Form");
        $scope.$broadcast('populateRedeemDetails');
    });
    $scope.$on("Select_Fund_Continue1", function(event,data){
        $scope.$broadcast("Call_Balance_Units");
        $scope.$broadcast("Call_Registered_banks");
    });

    $scope.$on("Select_Fund_Continue1", function(event,data){
        $scope.$broadcast("Call_Balance_Units");
        $scope.$broadcast("Call_Registered_banks");
    });
    
    $scope.$on("nomineeDetailsCont",function(){
        if(($scope.ifNewInvestor || $scope.isNewFolio) && ($scope.moduleUrl=="/buy" || $scope.moduleUrl=="/sip")){
            $scope.isShowNomineeGrid = false;
            $scope.isOpenPayDetails.open = true;
            $scope.isOpenRedeemGrid.open = true;
            $scope.isDisableReedemGrid = false;
            $scope.isNomineeEdit = false; 
            // transactModel.setTransactType(TransactConstant.buy.NOMINEE);
            transactModel.setNomineeDtlsFlag(true)
            $scope.$broadcast("NOMINEE_TILE", $scope.isNomineeEdit);
        }
    });

    $scope.$on(transactEventConstants.transact.Fund_Edit_Clicked, function (event, args) {         
        $scope.keyValueList = [];
        $scope.isShowReedemGrid = true;  
        $scope.isDisablePayDetails = true;
        $scope.isShowFundGrid = true;
        $scope.isOpenInvGrid.open= false;
        $scope.isOpenFundGrid.open= true;
        $scope.isOpenRedeemGrid.open= false;      
        $scope.isDisableReedemGrid = true;
        $scope.$broadcast(transactEventConstants.transact.Edit_Fund_Button_Clicked); 
        if ($scope.stateStatus)
        {
            if($scope.stateStatus.key == TransactConstant.transact.Redeem_Key || $scope.stateStatus.key == TransactConstant.transact.SWP_Key || $scope.stateStatus.key == TransactConstant.transact.Switch_Key || $scope.stateStatus.key == TransactConstant.transact.Stp_Key || $scope.stateStatus.key == TransactConstant.transact.Buy_Key)  
            {
                $scope.$broadcast(transactEventConstants.transact.NEW_FUND_DETAILS);
                $scope.$broadcast(transactEventConstants.transact.INV_FUND_DETAILS); 
                $scope.stateStatus.key = "";              
            } 
        }
    });
    $scope.$on(transactEventConstants.transact.Nominee_Edit_Clicked, function (event, args) {
        $scope.isNomineeEdit = true;
        $scope.isShowFundGrid = false;  
        $scope.isShowNomineeGrid = true;
        $scope.isOpenNomineeGrid.open= true;
        $scope.isOpenFundGrid.open= false;
        $scope.isOpenInvGrid.open= false;
        $scope.isOpenRedeemGrid.open= false;      
        $scope.isDisableNomineeGrid = false;
        $scope.isShowReedemGrid = true;        
        $scope.isDisablePayDetails = true;               
        // transactModel.setTransactType(TransactConstant.buy.NOMINEE);
        transactModel.setNomineeDtlsFlag(true)
        $scope.$broadcast("NOMINEE_TILE", $scope.isNomineeEdit);
     });
    $scope.$on('editNoNominee',function(){
        $scope.isNomineeEdit = true;
        $scope.isShowFundGrid = false;  
        $scope.isShowNomineeGrid = true;
        $scope.isOpenNomineeGrid.open= true;
        $scope.isOpenFundGrid.open= false;
        $scope.isOpenInvGrid.open= false;
        $scope.isOpenRedeemGrid.open= false;      
        $scope.isDisableNomineeGrid = false;
        $scope.isShowReedemGrid = true;        
        $scope.isDisablePayDetails = true;
    })


    $scope.$on(transactEventConstants.transact.Inv_Edit_Clicked, function (event, args) { 
        $scope.keyValueList = [];
        $scope.isShowReedemGrid = true;   
        $scope.isDisablePayDetails = true;        
        $scope.isShowInvestorDetails = true;
        $scope.isOpenInvGrid.open= true;
        $scope.isOpenFundGrid.open= false;
        $scope.isOpenRedeemGrid.open= false;
        $scope.isShowFundGrid = true;       
        $scope.isDisableFundGrid = true;
        $scope.isDisableReedemGrid = true;
        
        $scope.$broadcast(transactEventConstants.transact.Edit_Button_Clicked);
    });

        function showFundView(){
            $scope.showView = true;                
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            $scope.$broadcast(transactEventConstants.transact.Intl_Modify_Ctrl);
            $timeout(function(){
                $scope.isShowFundGrid = false;
                $scope.isOpenFundGrid.open = false;
                $scope.isOpenInvGrid.open= false;
                $scope.moduleUrl = $state.current.url;

                if(($scope.ifNewInvestor || $scope.isNewFolio) && ($scope.moduleUrl=="/buy" || $scope.moduleUrl=="/sip"))
                {
                    $scope.isShowNomineeGrid = true;
                    $scope.isDisableNomineeGrid=false;
                    $scope.isOpenNomineeGrid.open=true;
                    $scope.isDisablePayDetails = true;
                }
                else 
                {
                    $scope.isOpenRedeemGrid.open = true;
                    $scope.isDisableReedemGrid = false;
                }
            },0);
        }


        function selectInvestorTile(){
            
            if(transactModel.isNewInvestor || transactModel.getIsNewFolio()){
                $scope.ifNewInvestor = true;
                $scope.isNewFolio = true;
                $scope.isShowNomineeGrid=true;                
            }
            if(!transactModel.isNewInvestor|| !transactModel.getIsNewFolio())
            {                
                $scope.$broadcast(transactEventConstants.transact.Selected_Investor);
                if ($state.current.name === "transact.base.modifysip"){
                    ftiModifySipInitialLoader.loadAllServices($scope,selectInvestorModel.getSelectedInvestorDtls());
                    //newFundDetailsInitialLoader.loadAllServices($scope,selectInvestorModel.getSelectedInvestorDtls());
                } 
                else if(!transactModel.isSameInv || $scope.stateStatus){
                        $scope.$broadcast('DIFFERENT_INVESTOR_CONTINUE');
                        // Restricting call of txnEligibleAccounts in case of BUY and SIP.
                        if($state.current.name !== 'transact.base.buy' && $state.current.name !== 'transact.base.sip'){
                            selectFundInitialLoader.loadAllServices($scope,selectInvestorModel.getSelectedInvestorDtls());
                        }
                        newFundDetailsInitialLoader.loadAllServices($scope,selectInvestorModel.getSelectedInvestorDtls());
                        $scope.stateStatus = null;
                }
            }
            else
            {
                newFundDetailsInitialLoader.loadAllServices($scope,selectInvestorModel.getSelectedInvestorDtls());
            }                         

            $timeout(function(){
                $scope.isShowInvestorDetails = false;
                $scope.isShowFundGrid = true;
                $scope.isDisableFundGrid = false;
                $scope.isOpenInvGrid.open= false;
                $scope.isOpenFundGrid.open = true;
            },0);
        }

        function SetInitialValues(){
            $scope.isShowFundGrid = true;
            $scope.isShowInvestorDetails = true;
            $scope.isInitialShow = true;
            $scope.isDisableFundGrid = false;
            $scope.isDisableReedemGrid = false;
            $scope.isDisablePayDetails = true;
            $scope.isShowReedemGrid = true;
            $scope.isPaymentDetails = false;   
            $scope.isPaymentDetailsIni = false;
            $scope.oneAtATime = true;
            $scope.isOpenInvGrid.open= true;
            $scope.isOpenFundGrid.open= false;
            $scope.isOpenRedeemGrid.open= false;
            $scope.isOpenPayDetails.open= false;

            //$scope.ifNewInvestor=false;
            transactModel.isModifySip = false;
            transactModel.isSameInv = false;            
            $scope.isOpenNomineeGrid.open= false;
            $scope.isOpenPayDetails.open= false;
            $scope.ifNewInvestor= transactModel.isNewInvestor;
            $scope.isNewFolio = transactModel.getIsNewFolio();
            $scope.isShowNomineeGrid=false;
            $scope.isDisableNomineeGrid=true;
        }

    $scope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
        if ((!!toState && !!fromState) && (toState.parent === fromState.parent)) {
            // Reset all data for diff type of transaction.
            transactModel.isNewInvestor = false;
            transactModel.setIsNewFolio(false);
            $scope.stateStatus = null;
            $scope.keyValueList = [];
            SetInitialValues();
            selectInvestorModel.setEditInvIconChanged(false); 
            $scope.$broadcast(transactEventConstants.transact.Trans_Select_Option_Changed);
        }
        
    });

    $scope.$on("paymntDtls", function () {
        $scope.$broadcast("Go_To_Payment_Dtls");
     });
    $scope.$emit('transactClick', true);
}
transactController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants','selectFundModel', '$state','$stateParams','selectFundInitialLoader','eventConstants','$timeout','transactModel','transactEventConstants','TransactConstant','selectInvestorModel','newFundDetailsInitialLoader','ftiModifySipInitialLoader', 'paperlessModel','bankDtlsModel','redeemModel','swpModel','stpDetailsModel'];
module.exports = transactController;
