/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var userInputFld = function($timeout, eventConstants) {
	return {
            template: require('./userInputFld.html'),
            restrict: 'E',
            replace: true,
            scope: {
                inputObject: "=",
                inputChanged: "&?"
            },
            controller: ['$scope', '$element', '$attrs', function($scope, $element, $attrs){
                $scope.$input = $element[0].querySelector('input');
                $scope.isChanged = false;
                $scope.toggleLabel = function($event){
                    if($event.type ==='blur'){
                        $scope.$emit("INPUT_BLUR", {event:$event, inpObj:$scope.inputObject});
                    }
                    angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || $scope.$input.value.length > 0));
                    $scope.$emit("INPUT_TOGGLE",{event:$event,inpObj:$scope.inputObject});
                    $scope.updateParent();
                };

                $timeout(function(){
                    $scope.isChanged = true;
                    angular.element($scope.$input).triggerHandler('blur');
                }, 0);

                $scope.updateParent = function(){
                    if(!$scope.isChanged) {
                        return;
                    } else {
                        $scope.$emit("INPUT_CHANGED", $scope.inputObject);
                    }
                }

                $scope.$on(eventConstants.collaterals.REMOVE_FOCUS_CLASS,function(event){
                    $timeout(function(){
                        angular.element($scope.$input).triggerHandler('blur');
                    }, 0);
                });

            }],
            link: function(scope, iElement, iAttrs, controller){

               /* scope.inputChanged = function(){
                    var re = new RegExp("^(0|[1-9][0-9]*)$");
                    if(scope.inputObject.type === 'number') {
                        if(scope.inputObject.value){
                            if (!re.test(scope.inputObject.value)) {
                                scope.inputObject.value = scope.inputObject.value.replace(/\D/g,'');
                            }
                        }
                    }
                }*/
            }
        };
};

userInputFld.$inject = ['$timeout', 'eventConstants'];
module.exports = userInputFld;