/**
 * @ngdoc property
 * @name fticRedemptionReviewStatus Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Status.
 *
 **/
'use strict';

var fticRedemptionReviewStatus = function (transactModel, $filter, authenticationService, swpTxnDetailsFactory) {
    return {
        template: require('./swptndetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function ($scope) {
            
            $scope.isInvestorType = false;
            var _userType = authenticationService.getUser().userType;
            if(_userType && (_userType.toString() === '10')) {
                $scope.isInvestorType = true;
            }
            var invDetails = transactModel.getInvestorDetails();
            var fundDetails = transactModel.getFundDetails();
            var swpDetails = transactModel.getTransactDetails().swpDetails;
            var transConf = transactModel.getTransactConfirm();
            var datefilter = $filter('date');
            console.log(swpDetails);
            $scope.keyValuePairs = swpTxnDetailsFactory.getTxnDetails(_userType, transConf, swpDetails, invDetails, fundDetails, datefilter);
        },
        link: function () {

        }
    };
};

fticRedemptionReviewStatus.$inject = ['transactModel', '$filter', 'authenticationService', 'swpTxnDetailsFactory'];
module.exports = fticRedemptionReviewStatus;
