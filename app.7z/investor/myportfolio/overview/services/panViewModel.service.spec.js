'use strict';
describe('Services: pan view model service', function() {

    var panViewModelData, httpBackend, Restangular, $window, params;
    var panFilter = {
            guId: '878'
        }

    beforeEach(angular.mock.module('investor'));

    beforeEach(inject(function(_panViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
        panViewModelData = _panViewModel_;
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        $window = _$window_;
        $window.ga = function() {};
    }));

    it('should panViewModel to be defined', function() {
        expect(panViewModelData).toBeDefined();
    });

    describe('Services: load pan View services', function() {

        var panViewObject;
        
        beforeEach(inject(function() {
            panViewObject = {
             "investmentSummary":[{  
                   "grandTotal":{  
                      "currentCost":"82498.74",
                      "currentValue":"122163.91",
                      "account":"GRAND TOTAL",
                      "folioId":null,
                      "totalUnits":"285.758"
                   },
                   "holders":[  
                      {  
                         "type":"Firstholder",
                         "balAmount":null,
                         "aadharNo":null,
                         "modeOfKyc":null,
                         "kycSource":null,
                         "kycStatus":"KYC - Registered",
                         "pan":"CNJQL2964N",
                         "name":"YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED"
                      }
                   ],
                   "modeofHolding":"Single",
                   "rows":[  
                      {  
                         "goal":null,
                         "returns":"20.46%",
                         "currentValue":"92755.57",
                         "currentCost":"59998.89",
                         "totalUnits":"219.347",
                         "scheme":"Franklin India Taxshield - Growth",
                         "accountNo":"1349904865101"
                      }
                   ],
                   "folioId":"17877097"
             }],
             "portfolioDetails":{  
                "grandTotal":{  
                   "currentCost":"82498.74",
                   "currentValue":"122163.91",
                   "account":null,
                   "folioId":"GRAND TOTAL",
                   "totalUnits":null
                },
                "rows":[  
                   {  
                      "returns":"25%",
                      "accessLevel":"View",
                      "currentValue":"122163.91",
                      "currentCost":"82498.74",
                      "holidingType":"Single",
                      "folioId":"17877097"
                   }
                ]
             }
          };

            httpBackend.expectGET('http://localhost:3030/clients/clientStatement?guId=878').respond(panViewObject);
        }));

        it('should load fetchPanViewDetails with success', function() {
            panViewModelData.fetchPanViewDetails(panFilter).then(function(result) {
                expect(result.investmentSummary[0].folioId).toEqual('17877097');
            });
        });

        it('should retrive getPanViewDtls data using getter', function() {
            panViewModelData.setPanViewDtls(panViewObject);
            expect(panViewModelData.getPanViewDtls().investmentSummary[0].folioId).toEqual('17877097');
        });

    });
});
