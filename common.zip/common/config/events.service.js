'use strict';

var commonEvents = function (eventConstants, fticBroadcast) {
        return {

                publishInstantReportsDetails: function (scope) {
                        fticBroadcast.eventBroadcast(scope, eventConstants.COMMOM_IRD, '', '');
                },
                changeSecretQA: function (scope) {
                        fticBroadcast.eventBroadcast(scope, eventConstants.ADV_MP_CHG_SCRT_QA_UPD);
                },
                secretQuestions: function (scope) {
                        fticBroadcast.eventBroadcast(scope, eventConstants.ADV_MP_SCRT_QUES);
                },
                updatePersonalizedCheckEmit: function (scope, data) {
                        scope.$emit(eventConstants.Dashboard.ADV_DB_USR_CHECK_UPDATE_EMIT, data);
                        // fticBroadcast.eventBroadcast(scope,  eventConstants.Dashboard.ADV_DB_USR_CHECK_UPDATE, data, 'preference');
                },
                loginSuccess: function (scope) {
                        scope.$emit(eventConstants.LoginSuccess);
                },
                publishMenuDetails: function (scope) {
                        fticBroadcast.eventBroadcast(scope, eventConstants.ON_MENU_DETAILS);
                },
                emitMailbackClick: function (scope, data) {
                        scope.$emit(eventConstants.INV_MAILBACK_CLICKED, data);
                },
                emitMailbackSuc: function (scope, data) {
                        scope.$emit(eventConstants.INV_MAILBACK_CLICKED_SUC, data);
                },
                publishFolioDetails: function (scope, data) {
                        fticBroadcast.eventBroadcast(scope, eventConstants.transactNow.FOLIO_DETAILS, data, 'result');
                }
                
        };
};

commonEvents.$inject = ['eventConstants', 'fticBroadcast'];

module.exports = commonEvents;
