/**
 * @ngdoc property
 * @name eMandateIntialLoadService service
 * @requires DetailsModel
 
 * @description
 *
 * - eMandateIntialLoadService loads all the initial services for change password page in my profile module.
 *
 **/

'use strict';

var eMandateIntialLoadService = function(eMandateModel, investorEvents, fticLoggerMessage, loggerConstants, toaster, $loader, bankDtlsModel, transactModel, authenticationService, investorEventConstants, investorDashboardDetailsModel, $state) {
	var userDetails,
        _regEmandate;
    var eMandateIntialLoadService = {
		getEmandatesList : function(scope, params){
			var params = {},
                message = loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.MY_INVESTOR_MODULE + ' | ' + loggerConstants.TRANSACTION_INITIAL_LOADER + ' | loadTransactionSummary event' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
            console.log('getEmandatesList');
            function stopLoader() {
                $loader.stop();
            }
            $loader.start();

            function eMandateSuccess(data) {
            	eMandateModel.setEMandateDetails(data);
                investorEvents.accountSettings.getEmandateDetails(scope);
            }

            function handleFailure(data){
            	console.log('handleFailure');
                toaster.error(data.data[0].errorDescription);
            }
            userDetails = investorDashboardDetailsModel.getDashboardData();
            if(userDetails) {
                params.panNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
            }
            //params.panNo = 'CNKQQ9569X';
            params.guId = authenticationService.getUser().guId;

            eMandateModel.fetcheMandateList(params)
                .then(eMandateSuccess, handleFailure).finally(stopLoader);

		},
        newEmandate : function(scope, params) {
            console.log('newEmandate');
            var message,
                bankOptions;
                
                message = loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.MY_INVESTOR_MODULE + ' | ' + loggerConstants.TRANSACTION_INITIAL_LOADER + ' | loadTransactionSummary event' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });

                var emandates = eMandateModel.getEMandateDetails();
                if(emandates) {
                    bankDtlsModel.setBankDetails(emandates);
                    eMandateModel.setEMandateDetails(emandates.emandateDetails);
                    eMandateIntialLoadService.getFolios(scope);                    
                }
        },
        regEmandate : function(params, body, regEmandateFlag) {
            var message;
            _regEmandate = body;
            message = loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.MY_INVESTOR_MODULE + ' | ' + loggerConstants.TRANSACTION_INITIAL_LOADER + ' | loadTransactionSummary event' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
            console.log('removeEmandates');
            function stopLoader() {
                $loader.stop();
            }
            $loader.start();

            if(userDetails) {
                body.panNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
            }
            //body.panNo = 'CNKQQ9569X';
            params.guId = authenticationService.getUser().guId;

            function regEmandateSuccess(data) {
                eMandateModel.setEMandateDetails(data);
                if(data.transactionValidated === 'True') {
                    _regEmandate.webRefNo = data.webRefNo;
                    _regEmandate.validation = "N";                    
                    if(data.transactionValidated === 'True' && regEmandateFlag === false) {
                        regEmandateFlag = true;
                        eMandateIntialLoadService.regEmandate(params, _regEmandate, regEmandateFlag);                        
                    } else if(regEmandateFlag) {
                        $state.go('emandate');
                        eMandateIntialLoadService.getEmandatesList($scope, {});
                    }                
                } else if(regEmandateFlag) {
                    $state.go('emandate');
                    eMandateIntialLoadService.getEmandatesList($scope, {});
                }
            }
            function handleFailure(data){
                console.log('handleFailure');
                regEmandateFlag = false;
                if(data.data) {
                    toaster.error(data.data[0].errorDescription);
                } else {
                    toaster.error(data[0].errorDescription);
                }
                
            }

            eMandateModel.createEmandate(params, body)
                .then(regEmandateSuccess, handleFailure).finally(stopLoader);


        },
        removeEmandates : function($scope, eachMandate) {
            var params = {},
                message = loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.MY_INVESTOR_MODULE + ' | ' + loggerConstants.TRANSACTION_INITIAL_LOADER + ' | loadTransactionSummary event' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
            console.log('removeEmandates');
            function stopLoader() {
                $loader.stop();
            }
            $loader.start();

            function eMandateSuccess(data) {
                eMandateModel.setEMandateDetails(data);
                if(data.status === 'true') {
                    eMandateIntialLoadService.getEmandatesList($scope, {});
                }                
            }

            if(userDetails) {
                eachMandate.panNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
            }            
            if(authenticationService.getUser()) {
                params.guId = authenticationService.getUser().guId ? authenticationService.getUser().guId : '';
            }

            var body = {
                "panNo": eachMandate.panNo || '',
                "folioId": eachMandate.folioId,
                "paymentBankAccNo": eachMandate.bankAccno,
                "emRefNo": eachMandate.emRefNo
            }
            function handleFailure(data){
                console.log('handleFailure');
                toaster.error(data.data[0].errorDescription);
            }

            eMandateModel.removeEmandate(params, body)
                .then(eMandateSuccess, handleFailure).finally(stopLoader);
        },
        getFolios: function(scope) {
            var params = {},
                message = loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.MY_INVESTOR_MODULE + ' | ' + loggerConstants.TRANSACTION_INITIAL_LOADER + ' | loadTransactionSummary event' /* Function Name */ ;
            fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
            console.log('getFolios');
            function stopLoader() {
                $loader.stop();
            }
            $loader.start();

            function getFolioSuccess(data) {
                eMandateModel.setFolioDetails(data.panFolioKyc);
                investorEvents.accountSettings.newEmandateDetails(scope);
            }

            function handleFailure(data){
                console.log('handleFailure');
                toaster.error(data.data[0].errorDescription);
            }
            userDetails = investorDashboardDetailsModel.getDashboardData();
            if(userDetails) {
                params.panNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
            }
            //params.panNo = 'CNKQQ9569X';
            params.guId = authenticationService.getUser().guId;

            eMandateModel.fetchfolioList(params)
                .then(getFolioSuccess, handleFailure).finally(stopLoader);
        }
	}
	
	return eMandateIntialLoadService;
};

eMandateIntialLoadService.$inject = ['eMandateModel', 'investorEvents', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader', 'bankDtlsModel', 'transactModel', 'authenticationService', 'investorEventConstants', 'investorDashboardDetailsModel', '$state'];
module.exports = eMandateIntialLoadService;
