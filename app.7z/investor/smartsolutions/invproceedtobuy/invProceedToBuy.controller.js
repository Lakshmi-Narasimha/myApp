/**
 * @ngdoc property
 * @name Proceed to buy Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Saved Smart Solutions controller for smartSolutions module.
 *
 **/

'use strict';

function InvProceedToBuyController($scope, transactModel, $state) {
    
    $scope.info = {
        heading: 'Proceed to buy'
    };
    $scope.investorDetails = transactModel.getInvestorDetails();

    // if (transactModel.getInvestorDetails()) {
        
    //     $scope.investorDetails = transactModel.getInvestorDetails();
    // } else {
    //     $state.go('smartSol.planSmartSolution.selectFolio');
    // }
}

InvProceedToBuyController.$inject = ['$scope', 'transactModel', '$state'];
module.exports = InvProceedToBuyController;
