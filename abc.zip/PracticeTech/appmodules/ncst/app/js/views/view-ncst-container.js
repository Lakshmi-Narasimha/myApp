define(['jquery', 'underscore', 'backbone', 'appmodules/ncst/app/js/utils','appcommon/globalcontext', 'appcommon/analytics',
		'text!appmodules/ncst/app/templates/ncstContainer.html'], function ($,
		_, Backbone,Utils,GlobalContext, Analytics, NcstContainerTemplate) {
		    var _containerView = Backbone.View.extend({
		        el: $("#practicetech-subapp"),
		        id: 'practicetech-subapp',
		        events: {
		            "click #help-link": "helpLinkClicked"
		        },
		        initialize: function () {
		        },
		        render: function () {
		            var _compiledTemplate = _.template(NcstContainerTemplate);
		            this.$el.html(_compiledTemplate);
		        },
		        afterRender: function () {
                   // Utils.lockForm();
                    var _context = GlobalContext.getInstance().getGlobalContext().Context;
                    if(_context.IsStandalone){
                    	Backbone.history.navigate("ncst/client-info"+_context.QueryString, true);	
                    }
                    else{
                    	location.hash = "ncst/client-info";
                    }
		        },
		        helpLinkClicked : function() {
		        	Analytics.analytics.recordSharedSuiteAction('ncstHelpLink:clicked');
		        }
		        
		    });
		    return _containerView;
		});