var liveChatModelConfig = {
response: {
  "ResponseInfo": {
    "locale": "EN",
    "type": "Success",
    "server": "saswcvfszwd21.sdc.vzwcorp.com:srv01_wmobilefirst01",
    "buildNumber": "9047",
    "requestId": "15e72196-ec20-4466-b567-4fb3b6795e9c",
    "mdn": "2566105456",
    "code": "00000",
    "message": "0",
    "userMessage": "0"
  },
  "Page": {
    "pageType": "search",
    "parentPageType": "myData",
    "pageStatNames": [
      "/mf/support/suggested/term/search"
    ]
  },
  "ModuleMap": {
    "Support": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "msgList": [
        {
          "type": "content",
          "msgId": 1010,
          "messageList": [
            {
              "content": "I found something about that in the app. Would you like to use that feature?",
              "nextmsgId": -1,
              "animationDuration": 800,
              "childType": "contentTitle"
            },
            {
              "content": "Yes",
              "nextmsgId": 1011,
              "animationDuration": 800,
              "childType": "contentOption"
            },
            {
              "content": "No, thanks.",
              "nextmsgId": 1017,
              "animationDuration": 800,
              "childType": "contentOption"
            }
          ],
          "feedCard": false
        },
        {
          "type": "userMessage",
          "msgId": 1011,
          "messageList": [
            {
              "content": "Yes",
              "nextmsgId": 1012,
              "animationDuration": 0
            }
          ],
          "feedCard": false
        },
        {
          "type": "userMessage",
          "msgId": 1017,
          "messageList": [
            {
              "content": "No, thanks.",
              "nextmsgId": 684,
              "animationDuration": 0
            }
          ],
          "feedCard": false
        },
        {
          "type": "userMessage",
          "msgId": 3000,
          "messageList": [
            {
              "content": "256.610.5456",
              "nextmsgId": -1,
              "animationDuration": 0
            }
          ],
          "feedCard": false
        },
        {
          "type": "userMessage",
          "msgId": 3001,
          "messageList": [
            {
              "content": "323.493.1017",
              "nextmsgId": -1,
              "animationDuration": 0
            }
          ],
          "feedCard": false
        },
        {
          "type": "userMessage",
          "msgId": 3002,
          "messageList": [
            {
              "content": "256.610.7310",
              "nextmsgId": -1,
              "animationDuration": 0
            }
          ],
          "feedCard": false
        },
        {
          "type": "content",
          "msgId": 1012,
          "messageList": [
            {
              "content": "Great. You have 3 devices to pick from. Which one do you want manage?",
              "nextmsgId": 1013,
              "animationDuration": 800,
              "childType": "contentTitle"
            },
            {
              "content": "256.610.5456",
              "nextmsgId": 3000,
              "animationDuration": 800,
              "mdn": "2566105456",
              "childType": "contentOption",
              "ButtonMap": {
                "FeedLink": {
                  "title": "256.610.5456",
                  "presentationStyle": "push",
                  "tryToReplaceFirst": false,
                  "disableAction": false,
                  "analyticsKey": "2017-03-01 11:16:34:1634_31686",
                  "resultType": null,
                  "selected": false,
                  "pageType": "deviceSelection",
                  "appContext": "mobileFirstSS",
                  "actionType": "openPage",
                  "isSelected": false,
                  "extraParameters": {
                    "selectedMdn": "2566105456",
                    "uniqueKey": "2017-03-01 11:16:34:1634_31686"
                  }
                }
              }
            },
            {
              "content": "323.493.1017",
              "nextmsgId": 3001,
              "animationDuration": 800,
              "mdn": "3234931017",
              "childType": "contentOption",
              "ButtonMap": {
                "FeedLink": {
                  "title": "323.493.1017",
                  "presentationStyle": "push",
                  "tryToReplaceFirst": false,
                  "disableAction": false,
                  "analyticsKey": "2017-03-01 11:16:34:1634_31686",
                  "resultType": null,
                  "selected": false,
                  "pageType": "deviceSelection",
                  "appContext": "mobileFirstSS",
                  "actionType": "openPage",
                  "isSelected": false,
                  "extraParameters": {
                    "selectedMdn": "3234931017",
                    "uniqueKey": "2017-03-01 11:16:34:1634_31686"
                  }
                }
              }
            },
            {
              "content": "256.610.7310",
              "nextmsgId": 3002,
              "animationDuration": 800,
              "mdn": "2566107310",
              "childType": "contentOption",
              "ButtonMap": {
                "FeedLink": {
                  "title": "256.610.7310",
                  "presentationStyle": "push",
                  "tryToReplaceFirst": false,
                  "disableAction": false,
                  "analyticsKey": "2017-03-01 11:16:34:1634_31686",
                  "resultType": null,
                  "selected": false,
                  "pageType": "deviceSelection",
                  "appContext": "mobileFirstSS",
                  "actionType": "openPage",
                  "isSelected": false,
                  "extraParameters": {
                    "selectedMdn": "2566107310",
                    "uniqueKey": "2017-03-01 11:16:34:1634_31686"
                  }
                }
              }
            }
          ],
          "feedCard": false
        },
        {
          "type": "link",
          "msgId": 684,
          "messageList": [
            {
              "content": "I found some info on our site. <a> Go take a look.  </a>",
              "nextmsgId": 0,
              "animationDuration": 800,
              "ButtonMap": {
                "FeedLink": {
                  "browserUrl": "http://www.verizonwireless.com/search/vzwSearch?Ntt=want%2Bto%2Bblock%2Ba%2Bnumber",
                  "presentationStyle": "push",
                  "tryToReplaceFirst": false,
                  "disableAction": false,
                  "analyticsKey": "2017-03-01 11:16:34:1634_31686",
                  "resultType": "SearchResult",
                  "selected": false,
                  "appContext": "mobileFirstSS",
                  "actionType": "openURL",
                  "isSelected": false
                }
              }
            }
          ],
          "feedCard": false
        },
        {
          "type": "link",
          "msgId": 684,
          "messageList": [
            {
              "content": "I found some info on our site. <a> Go take a look.  </a>",
              "nextmsgId": 0,
              "animationDuration": 800,
              "ButtonMap": {
                "FeedLink": {
                  "browserUrl": "http://www.verizonwireless.com/search/vzwSearch?Ntt=want%252Bto%252Bblock%252Ba%252Bnumber",
                  "presentationStyle": "push",
                  "tryToReplaceFirst": false,
                  "disableAction": false,
                  "analyticsKey": "2017-03-01 11:16:34:1634_31686",
                  "resultType": "SearchResult",
                  "selected": false,
                  "appContext": "mobileFirstSS",
                  "actionType": "openURL",
                  "isSelected": false
                }
              }
            }
          ],
          "feedCard": false
        }
      ],
      "topLevelIntent": "Block",
      "searchTerm": "want to block a number",
      "startMsgId": 1010,
      "inConversationalFlow": false,
      "secondLevelIntent": "INAPP_BLOCK-CALLMSGBLOCK",
      "searchStartIndex": 0
    }
  }
}
};

module.exports = liveChatModelConfig;
