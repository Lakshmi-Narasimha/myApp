// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var SmartSavingsDetailsSchema = new mongoose.Schema({
    getSmartSavingsDetails: {
        type: Object,
        "default": {}
    }
});

var SmartSavingsLookUp = mongoose.model('SmartSavingsLookUp', SmartSavingsDetailsSchema);

var SmartSavingsModel = new SmartSavingsLookUp({
    getSmartSavingsDetails: {
        "purchaseInstructions": {
            "refId": "18282292",
            "firstHolder": "Shankar Narayan",
            "folioNo": "17023676",
            "modeOfHolding": "Joint",
            "investInto": "Franklin India Savings Plus Fund - Direct – Growth",
            "instructionAmount": 5000,
            "paymentMethod": "Existing Payment Mandate",
            "selectedBank":"HDFC BANK LTD-3574063201671",
            "investorMode":"financial",
            "advisorMode":"existing",
            "subDist":"",
            "subBrokerARN":"",
            "euinFlag":"N",
            "euin":""
        },
        "redeemInstructions": {
            "refId": "73291119",
            "amount": 5000,
            "bankDetails": "Dena Bank – 001234567890",
            "modeOfPayment": "Direct Credit",
            "IFSCCode": "IDB0001138",
            "branch": "Koliwada",
            "address": "2413 Kumar Real Estate  Street,Koliwada,Mumbai, Maharashtra."
        }
    }
});

SmartSavingsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating SmartSavingsLookUp table, please contact admin...');
    } else {
        SmartSavingsLookUp.remove({}, function(err) {
            console.log('SmartSavingsLookUp collection removed');
            SmartSavingsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SmartSavingsLookUp table, please contact admin...');
                }
                console.log('SmartSavingsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SmartSavingsLookUp;
