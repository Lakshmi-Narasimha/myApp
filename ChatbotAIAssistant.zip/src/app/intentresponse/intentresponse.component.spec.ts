/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { IntentresponseComponent } from './intentresponse.component';

describe('IntentresponseComponent', () => {
  let component: IntentresponseComponent;
  let fixture: ComponentFixture<IntentresponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntentresponseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentresponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
