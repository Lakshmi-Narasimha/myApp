// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var BankModelSchema = new mongoose.Schema({
    BankResp: {
        type: Array,
        "default": []
    }
});

var BankModelLookUp = mongoose.model('BankModelLookUp', BankModelSchema);

var BankModel = new BankModelLookUp({
    BankResp : {
                  "folioId": "14304380",
                  "netBanking": [
                    {
                      "pbBankName": "HDFC BANK LTD",
                      "pbPersonalAccountNumber": "3574063201671",
                      "pbAccountType": "SA",
                      "accTypeDesc": "Savings Account",
                      "paymentType": "N",
                      "payoutFlag": "R",
                      "achRefNo": null
                    }
                  ],
                  "debit": [
                    {
                      "pbBankName": "HDFC BANK LTD",
                      "pbPersonalAccountNumber": "3574063201671",
                      "pbAccountType": "SA",
                      "accTypeDesc": "Savings Account",
                      "paymentType": "D",
                      "payoutFlag": "R",
                      "achRefNo": null
                    }
                  ],
                  "emandate": [
                    {
                      "pbBankName": "HDFC BANK LTD",
                      "pbPersonalAccountNumber": "3574063201671",
                      "pbAccountType": "SA",
                      "accTypeDesc": "Savings Account",
                      "umrn": "425159780",
                      "amount": "1000",
                      "frequency": "M",
                      "toDate": "2016-08-30 00:00:00.0",
                      "fromDate": "2016-08-10 00:00:00.0",
                      "regDate": "2016-08-09 11:54:25.0",
                      "paymentType": "E",
                      "amountType": "U",
                      "payoutFlag": "R",
                      "achRefNo": "EM00000466"
                    }
                  ],
                  "newEmandates": [],
                  "neftRtgs": [
                    {
                      "pbBankName": "HDFC BANK LTD",
                      "pbPersonalAccountNumber": "3574063201671",
                      "pbAccountType": "SA",
                      "accTypeDesc": "Savings Account",
                      "paymentType": "R",
                      "payoutFlag": "R",
                      "achRefNo": null,
                      "neftDetails": [
                        {
                          "code": "Branch Name",
                          "value": "Fort, Mumbai"
                        },
                        {
                          "code": "Name",
                          "value": "Franklin Templeton Mutual Fund"
                        },
                        {
                          "code": "Bank Name",
                          "value": "Mumbai"
                        },
                        {
                          "code": "IFSC Code",
                          "value": "CITIBANK"
                        },
                        {
                          "code": "Account Number",
                          "value": "64737291"
                        },
                        {
                          "code": "Account Type",
                          "value": "Current"
                        }
                      ]
                    }
                  ],
                  "billPay": []
                }
/*{
        'banks' : {
            "folioId": "14304380",
            "netBanking": [
                {
                    "pbBankName": "HDFC BANK LTD",
                    "pbPersonalAccountNumber": "3574063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "Savings Account",
                    "paymentType": "N",
                    "amount": "2500"
                }
            ],
            "debit": [
                {
                    "pbBankName": "HDFC BANK LTD",
                    "pbPersonalAccountNumber": "3574063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "Savings Account",
                    "paymentType": "D",
                    "amount": "2500"
                }
            ],
            "emandate": [
                {
                    "pbBankName": "HDFC BANK LTD",
                    "pbPersonalAccountNumber": "3574063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "Savings Account",
                    "umrn": "8888888888",
                    "amount": "1200",
                    "frequency": "As & When",
                    "amountType": "Maximum",
                    "toDate": "2016-07-30 00:00:00.0",
                    "fromDate": "2016-07-22 00:00:00.0",
                    "regDate": "2016-07-21 06:35:27.0",
                    "paymentType": "E",
                    "status": "Utilized"
                },
                {
                    "pbBankName": "Axis Bank",
                    "pbPersonalAccountNumber": "1234063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "Savings Account",
                    "umrn": "8888888888",
                    "amount": "2500",
                    "frequency": "As & When",
                    "amountType": "Maximum",
                    "toDate": "2016-02-15 00:00:00.0",
                    "fromDate": "2016-01-22 00:00:00.0",
                    "regDate": "2015-07-21 06:35:27.0",
                    "paymentType": "E",
                    "status": "Active"
                },
            ],
            "newEmandates": [
                {
                    "pbBankName": "HDFC BANK LTD",
                    "pbPersonalAccountNumber": "3574063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "HDFC BANK LTD",
                    "paymentType": "NE",
                    "amount": "2500"
                },
                {
                    "pbBankName": "Axis Bank",
                    "pbPersonalAccountNumber": "4578063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "HDFC BANK LTD",
                    "paymentType": "NE",
                    "amount": "2500"
                }
            ],
            "neftRtgs": [
                {
                    "pbBankName": "HDFC BANK LTD",
                    "pbPersonalAccountNumber": "3574063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "Savings Account",
                    "paymentType": "NEFT",
                    "amount": "2500"
                }
            ],
            'payeeDetails': [
                {
                    'name' : 'Franklin Templeton Mutual Fund',
                    'bankName' : 'CITIBANK',
                    'ifscCode' : 'CITI0100000',
                    'branchName' : 'Fort, Mumbai',
                    'accountNumber' : '5050AHTPG6546Y',
                    'accountType' : 'Current'
                }
            ]
        }
    }*/
});

BankModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating BankModelLookUp table, please contact admin...');
    } else {
        BankModelLookUp.remove({}, function(err) {
            console.log('BankModelLookUp collection removed');
            BankModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating BankModelLookUp table, please contact admin...');
                }
                console.log('BankModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = BankModelLookUp;