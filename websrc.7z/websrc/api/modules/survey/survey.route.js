var express = require('express');
var https = require('https');
var querystring = require('querystring');

var router = express.Router();
var surveyModel = require('./survey.model');

// api route
router.route('/mfchat/rest/surveyUrl')
    .post(function(req, res) {
        req.uri = surveyModel.createRequestUri;
        var post_data = req.body.RequestParams;
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'POST',
                path: req.uri.path + '&siteID=' + post_data.siteID + '&surveySpecID=' + post_data.surveySpecID,
                headers: {
                    'Cookie': req.sessionCookie,
                },
                rejectUnauthorized: true
            },

            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                    proxyResponse.on('data', function(chunk) {
                        chunk = JSON.parse(chunk);
                        surveyModel.response.page.SurveyUrl = chunk.SurveyUrl;
                        res.send(surveyModel.response);
                    });
                    
                } else {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {

                });
            });

        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
