/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var fticSearch = function() {
	return {
            template: require('./search.html'),
            restrict: 'E',
            replace: true,
            scope: {
                searchClass : '=',
                modelValue : '=?'
            },
            controller:['$scope', function($scope){
                $scope.$on('$stateChangeSuccess',function(event){
                    $scope.modelValue = '';
                });
            }]
        };
};

fticSearch.$inject = [];
module.exports = fticSearch;