// getMonthlyBussinessOverview.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var MonthlyBussinessOverviewSchema = new mongoose.Schema({
    monthlyBussinessOverviewObject: {
        type: Array,
        "default": []
    }
});

var MonthlyBussinessOverviewLookUp = mongoose.model('MonthlyBussinessOverviewLookup', MonthlyBussinessOverviewSchema);

var MonthlyBussinessOverviewModel = new MonthlyBussinessOverviewLookUp({

    "monthlyBussinessOverviewObject": [
      {
  "monthlyBusinessOverviewResp": {
    "fundWiseSales": {
      "grossSales": [{
        "fundType": "BALANCED",
        "sales": "10000"
      }, {
        "fundType": "ELSS",
        "sales": "207000"
      }, {
        "fundType": "EQUITY",
        "sales": "8319784"
      }, {
        "fundType": "FEEDER",
        "sales": "35500"
      }, {
        "fundType": "FOF",
        "sales": "44464.82"
      }, {
        "fundType": "FIXED INCOME",
        "sales": "5440668"
      }, {
        "fundType": "LIQUID",
        "sales": "678053.4"
      }],
      "totalGrossSales": "14735469.64",
      "AUM": [{
        "fundType": "BALANCED",
        "aum": "17280730"
      }, {
        "fundType": "ELSS",
        "aum": "66202170"
      }, {
        "fundType": "EQUITY",
        "aum": "691186000"
      }, {
        "fundType": "FEEDER",
        "aum": "6430883"
      }, {
        "fundType": "FOF",
        "aum": "34224680"
      }, {
        "fundType": "FIXED INCOME",
        "aum": "461452000"
      }, {
        "fundType": "LIQUID",
        "aum": "6260632"
      }],
      "totalAUM": "1283037054.71"
    },
    "fundWiseSummary": {
      "fundDetails": [{
        "assetCategory": "BALANCED",
        "grossSales": "10000",
        "upfrontAccured": "262.5",
        "upfrontReleased": "262.5",
        "AUM": "17280730",
        "trailAccured": "6869.9",
        "redemption": "6795.6",
        "netSales": "85972.48",
        "clawback": "-75972.48",
        "prevCommReleased": "0",
        "incentiveAccured": "0",
        "incentiveReleased": "0"
      }, {
        "assetCategory": "ELSS",
        "grossSales": "207000",
        "upfrontAccured": "5762.48",
        "upfrontReleased": "3507.48",
        "AUM": "66202170",
        "trailAccured": "19134.99",
        "redemption": "19052.63",
        "netSales": "153923.3",
        "clawback": "53076.73",
        "prevCommReleased": "0",
        "incentiveAccured": "0",
        "incentiveReleased": "0"
      }, {
        "assetCategory": "EQUITY",
        "grossSales": "8319784",
        "upfrontAccured": "145664.7",
        "upfrontReleased": "142512.2",
        "AUM": "691186000",
        "trailAccured": "284188.6",
        "redemption": "282632.8",
        "netSales": "4836866",
        "clawback": "3482918",
        "prevCommReleased": "-4520.16",
        "incentiveAccured": "7561.06",
        "incentiveReleased": "0"
      }, {
        "assetCategory": "FEEDER",
        "grossSales": "35500",
        "upfrontAccured": "937.5",
        "upfrontReleased": "757.5",
        "AUM": "6430883",
        "trailAccured": "1194.22",
        "redemption": "1166.83",
        "netSales": "0",
        "clawback": "35500",
        "prevCommReleased": "0",
        "incentiveAccured": "0",
        "incentiveReleased": "0"
      }, {
        "assetCategory": "FOF",
        "grossSales": "44464.82",
        "upfrontAccured": "565",
        "upfrontReleased": "565",
        "AUM": "34224680",
        "trailAccured": "2001.93",
        "redemption": "2001.93",
        "netSales": "0",
        "clawback": "44464.82",
        "prevCommReleased": "0",
        "incentiveAccured": "0",
        "incentiveReleased": "0"
      }, {
        "assetCategory": "FIXED INCOME",
        "grossSales": "5440668",
        "upfrontAccured": "16815.31",
        "upfrontReleased": "3247.14",
        "AUM": "461452000",
        "trailAccured": "136149.9",
        "redemption": "135630.6",
        "netSales": "17237190",
        "clawback": "-11796520",
        "prevCommReleased": "-53241.01",
        "incentiveAccured": "0",
        "incentiveReleased": "0"
      }, {
        "assetCategory": "LIQUID",
        "grossSales": "678053.4",
        "upfrontAccured": "0",
        "upfrontReleased": "0",
        "AUM": "6260632",
        "trailAccured": "337.77",
        "redemption": "337.77",
        "netSales": "690000.4",
        "clawback": "-11947.02",
        "prevCommReleased": "0",
        "incentiveAccured": "0",
        "incentiveReleased": "0"
      }],
      "grandTotal": {
        "assetCategory": "Grand Total",
        "grossSales": "14735469.64",
        "upfrontAccured": "170007.46",
        "upfrontReleased": "150851.79",
        "AUM": "1283037054.71",
        "trailAccured": "449877.33",
        "redemption": "447618.19",
        "netSales": "23003947.92",
        "clawback": "-8268478.28",
        "prevCommReleased": "-57761.17",
        "incentiveAccured": "7561.06",
        "incentiveReleased": "0"
      },
      "lastMonth": {
        "assetCategory": "Last Month",
        "grossSales": "19067712.84",
        "upfrontAccured": "217748.41",
        "upfrontReleased": "200921.27",
        "AUM": "1276945909.63",
        "trailAccured": "416950.04",
        "redemption": "414789.16",
        "netSales": "11226314.10",
        "clawback": "7841398.74",
        "prevCommReleased": "-2614.56",
        "incentiveAccured": "0",
        "incentiveReleased": "2565"
      },
      "ytd": {
        "assetCategory": "YTD",
        "grossSales": "153837169.43",
        "upfrontAccured": "1433875.95",
        "upfrontReleased": "1368154.31",
        "AUM": "9149522179.91",
        "trailAccured": "2837753.67",
        "redemption": "2827381.96",
        "netSales": "209431492.53",
        "clawback": "-55594323.10",
        "prevCommReleased": "-166061.49",
        "incentiveAccured": "10661.99",
        "incentiveReleased": "2565"
      }
    },
    "investorDetails": [{
      "type": "New Investors",
      "count": "35",
      "AUM": "0"
    }, {
      "type": "Total Investors",
      "count": "7683",
      "AUM": ""
    }],
    "foliosDetails": [{
      "type": "New Folios",
      "count": "39",
      "AUM": "0"
    }, {
      "type": "Total Folios",
      "count": "8241",
      "AUM": ""
    }],
    "incompleteCommunications": [{
      "type": "Email",
      "count": "8241"
    }, {
      "type": "Mobile",
      "count": "8241"
    }, {
      "type": "Pin Code",
      "count": "8241"
    }, {
      "type": "KYC",
      "count": "8241"
    }, {
      "type": "Nominee details",
      "count": "8241"
    }, {
      "type": "Mode of payment",
      "count": "8241"
    }],
    "redemptionExitLoadPeriod": [{
      "assetCategory": "EQUITY",
      "noOfTransaction": "23",
      "noOfCustomers": "23",
      "valueOfRedemption": "440208.02"
    }, {
      "assetCategory": "FIXED INCOME",
      "noOfTransaction": "4",
      "noOfCustomers": "4",
      "valueOfRedemption": "11528378.52"
    }]
  }
}
    ]

});

MonthlyBussinessOverviewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating MonthlyBussinessOverviewLookUp table, please contact admin...');
    } else {
        MonthlyBussinessOverviewLookUp.remove({}, function(err) {
            console.log('MonthlyBussinessOverviewLookUp collection removed');
            MonthlyBussinessOverviewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating MonthlyBussinessOverviewLookUp table, please contact admin...');
                }
                console.log('MonthlyBussinessOverviewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = MonthlyBussinessOverviewLookUp;
