'use strict'
function ekycVerificationCtrl($scope,$state,transactModel,ekycVerificationModel,authenticationService,otpGenerationModel, configUrlModel, toaster, $filter){

	$scope.folioId =  transactModel.getSelectedFolioDts().folioId;
	$scope.holderDetails = transactModel.getInstantKyc();
	

	$scope.aadharPanDetailsFirstHolder = {
		aadhar : null ,
		pan : null,
		otpObject : {
			key :'One-time Password(OTP)',
			text : 'One-time Password(OTP)',
			name : 'otp',
			isRequired : true,
			type: "number",
			value:"",
			maxlength:6
		},
		aadharObject : {
			key :'Aadhaar',
			text : 'Aadhaar',
			isRequired : true,
			name : 'aadhar',
			type: "number",
			value:"",
			disable:true
		}
	}
	$scope.aadharPanDetailsSecondHolder = {
		aadhar : null ,
		pan : null,
		otpObject : {
			key :'One-time Password(OTP)',
			text : 'One-time Password(OTP)',
			name : 'otp',
			isRequired : true,
			type: "number",
			value:"",
			maxlength:6
		},
		aadharObject : {
			key :'Aadhaar',
			text : 'Aadhaar',
			isRequired : true,
			name : 'aadhar',
			type: "number",
			value:"",
			disable:true
		}
	}
	$scope.aadharPanDetailsThirdHolder = {
		aadhar : null ,
		pan : null,
		otpObject : {
			key :'One-time Password(OTP)',
			text : 'One-time Password(OTP)',
			name : 'otp',
			isRequired : true,
			type: "number",
			value:"",
			maxlength:6
		},
		aadharObject : {
			key :'Aadhaar',
			text : 'Aadhaar',
			isRequired : true,
			name : 'aadhar',
			type: "number",
			value:"",
			disable:true
		}
	}

	$scope.firstHolderDetails = [

	];
	$scope.secondHolderDetails = [

	]; 

	$scope.thirdHolderDetails = [

	];

	if($scope.holderDetails){
		if($scope.holderDetails.length > 0 ){
			$scope.firstHolderDetails = transactModel.setInvTileData($scope.holderDetails[0].name, $scope.holderDetails[0].pan, $scope.holderDetails[0].aadhar, $scope.holderDetails[0].kycStatus, "First Holder Name");
			$scope.aadharPanDetailsFirstHolder.aadharObject.value = $scope.holderDetails[0].aadhar;
			$scope.aadharPanDetailsFirstHolder.pan = $scope.holderDetails[0].pan;
		}
	}
	if($scope.holderDetails.length > 1){
		$scope.secondHolderDetails = transactModel.setInvTileData($scope.holderDetails[1].name, $scope.holderDetails[1].pan, $scope.holderDetails[1].aadhar, $scope.holderDetails[1].kycStatus, "Second Holder Name");		
		$scope.aadharPanDetailsSecondHolder.aadharObject.value = $scope.holderDetails[1].aadhar;
		$scope.aadharPanDetailsSecondHolder.pan = $scope.holderDetails[1].pan;
	}
	if($scope.holderDetails.length > 2){
		$scope.thirdHolderDetails = transactModel.setInvTileData($scope.holderDetails[2].name, $scope.holderDetails[2].pan, $scope.holderDetails[2].aadhar, $scope.holderDetails[2].kycStatus, "Third Holder Name");		
		$scope.aadharPanDetailsThirdHolder.aadharObject.value = $scope.holderDetails[2].aadhar;
		$scope.aadharPanDetailsThirdHolder.pan = $scope.holderDetails[2].pan;
	}

	$scope.handleSubmit = function(){
		$state.go("invTransact.ekycVerifyDetails");
	}

	function aadharDtlsSuccess(data) {
		var userDetails = data.eKYCOTPValidation;
		if(userDetails)   {
			 if(userDetails.length) {

			angular.forEach($scope.holderDetails,function(obj,key){
				var address, date_regex = /^\d{2}-\d{2}-\d{4}$/, dateSplit, dob="", dobInNewDateFormat = "";
				address = userDetails[key].houseNo + ', '+userDetails[key].landMark +', '+userDetails[key].subDist+', '+userDetails[key].district + ', '+userDetails[key].pinCode;
				address = address.replace(/\s+/g,' ').trim();
					if(userDetails[key].dob && date_regex.test(userDetails[key].dob)){
	            		dateSplit = userDetails[key].dob.split("-");
	            		dobInNewDateFormat = new Date(dateSplit[2], dateSplit[1] - 1, dateSplit[0]);
	            		dob = $filter('date')(dobInNewDateFormat, 'dd/MM/yyyy');
	        		}
	        	obj.name = userDetails[key].name;
				obj.dob = dob;
				obj.dobInNewDateFormat = dobInNewDateFormat;
				obj.gender = userDetails[key].gender === "M"? 'Male' : (userDetails[key].gender === "F" ? 'Female' : 'Male');
				obj.address = address;
				obj.image =configUrlModel.getImagesUrl()+'/person.jpg';
				$scope.holderDetails[key] = obj;
			});	
			var isOtpSuccess = true;
				angular.forEach(userDetails,function(obj,key){
					 if(obj &&  obj.statusDescription !== 'SUCCESS'){
			                isOtpSuccess = false;    
			            }
			        });

				if(isOtpSuccess) {
					transactModel.setInstantKyc($scope.holderDetails);
			                $scope.handleSubmit();
				}
				else{
			            toaster.error('Please enter valid OTP');
			        }
			

		}else {
			angular.forEach($scope.holderDetails,function(obj,key){
				if(obj.kycStatus !== "KYC - Registered") {
					var address, date_regex = /^\d{2}-\d{2}-\d{4}$/, dateSplit, dob="", dobInNewDateFormat = "";
					address = userDetails.houseNo + ', '+userDetails.landMark +', '+userDetails.subDist+', '+userDetails.district + ', '+userDetails.pinCode;
					address = address.replace(/\s+/g,' ').trim();
						if(userDetails.dob && date_regex.test(userDetails.dob)){
		            		dateSplit = userDetails.dob.split("-");
		            		dobInNewDateFormat = new Date(dateSplit[2], dateSplit[1] - 1, dateSplit[0]);
		            		dob = $filter('date')(dobInNewDateFormat, 'dd/MM/yyyy');
		        		}
		        	obj.name = userDetails.name;
					obj.dob = dob;
					obj.dobInNewDateFormat = dobInNewDateFormat;
					obj.gender = userDetails.gender === "M"? 'Male' : (userDetails.gender === "F" ? 'Female' : 'Male');
					obj.address = address;
					obj.image =configUrlModel.getImagesUrl()+'/person.jpg';
				}
				$scope.holderDetails[key] = obj;
			})
			var isOtpSuccess = true;
					 if(userDetails &&  userDetails.statusDescription !== 'SUCCESS'){
			                isOtpSuccess = false;    
			          }
			     
				if(isOtpSuccess) {
					transactModel.setInstantKyc($scope.holderDetails);
			                $scope.handleSubmit();
				}
				else{
			            toaster.error('Please enter valid OTP');
			        }
		}
	}else{
            toaster.error('Please enter valid OTP');
        }
		
		
	};
	function aadharDtlsFailure(error){
		console.log(error);
	}

	$scope.onSubmit = function(){
		if ($scope.aadharForm.$valid) {
			var requestObj = [];

			if($scope.holderDetails.length > 0 && $scope.holderDetails[0].kycStatus !== "KYC - Registered"){
				requestObj.push({"adrPANPkrn":$scope.aadharPanDetailsFirstHolder.aadharObject.value + "","otp":$scope.aadharPanDetailsFirstHolder.otpObject.value + ""});
			}
			if($scope.holderDetails.length > 1 && $scope.holderDetails[1].kycStatus !== "KYC - Registered"){
				requestObj.push({"adrPANPkrn":$scope.aadharPanDetailsSecondHolder.aadharObject.value + "","otp":$scope.aadharPanDetailsSecondHolder.otpObject.value + ""});
			}
			if($scope.holderDetails.length > 2 && $scope.holderDetails[2].kycStatus !== "KYC - Registered"){
				requestObj.push({"adrPANPkrn":$scope.aadharPanDetailsThirdHolder.aadharObject.value + "","otp":$scope.aadharPanDetailsThirdHolder.otpObject.value + ""});

			}

			var requestObject = {
				paramObj: {"guId" : authenticationService.getUser().guId},
				bodyObj: {
					"validateOTPeKYC":requestObj
				}
			}
			ekycVerificationModel.validateEkycOtp(requestObject).then(aadharDtlsSuccess, aadharDtlsFailure);
		}
	}

	
}

ekycVerificationCtrl.$inject = ['$scope','$state','transactModel','ekycVerificationModel','authenticationService','otpGenerationModel', 'configUrlModel', 'toaster', '$filter'];
module.exports = ekycVerificationCtrl;