import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/catch';

import { Agent } from '../_models/index';
import { Intent } from '../_models/index';
import { UserExpression } from '../_models/userexpression';
import { ReqBodyHelper } from '../_helpers/reqBodyHelper';

@Injectable()
export class AIAssistRestService {
    constructor(private http: Http) { }
    urlSecKey:string ="sf34r23rwefdwet34sewr34";
    baseURL:string = 'http://localhost:8080';
    //baseURL:string='http://10.177.253.68:8080';
    //baseURL:string='http://10.177.205.63:8080';
    engineURL:string = '/ChatBotEngine';

    getAllAgents() {
        let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
        return this.http.post(this.baseURL + this.engineURL + '/config/getAllAgents',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    getAgentById(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
      return this.http.post(this.baseURL + this.engineURL + '/config/getAgentById',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    createAgent(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
       return this.http.post(this.baseURL + this.engineURL + '/config/createAgent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    removeAgent(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
       return this.http.post(this.baseURL + this.engineURL + '/config/deleteAgent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    createIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
       return this.http.post(this.baseURL + this.engineURL + '/config/createIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    removeIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
       return this.http.post(this.baseURL + this.engineURL + '/config/deleteIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    updateIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
       return this.http.post(this.baseURL + this.engineURL + '/config/updateIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    getIntentById(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
      return this.http.post(this.baseURL + this.engineURL + '/config/getIntentById',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    createUserExpressions(pUserExpressions: Array<UserExpression>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqUserExpressions = pUserExpressions;
      return this.http.post(this.baseURL + this.engineURL + '/config/createUserExpression',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    deleteUserExpressions(pUserExpression: Array<UserExpression>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqUserExpressions = pUserExpression;
      return this.http.post(this.baseURL + this.engineURL + '/config/deleteUserExpression',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    updateParmeter(pParamInfoVOList: Array<any>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqParamInfoVOList = pParamInfoVOList;
      return this.http.post(this.baseURL + this.engineURL + '/config/updateParameter',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    deleteParameter() {

    }

    private jwt() {
            let headers = new Headers({});
            return new RequestOptions({ headers: headers });
    }

 private extractData(res: Response) {
        let body = res.json();
        return body.data || { };
    }

   private handleError (error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

}
