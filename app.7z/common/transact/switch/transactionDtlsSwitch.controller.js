/**
 * @ngdoc property
 * @name Switch transaction details Controller
 * @requires $scope
 * @description
 *
 * - 
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function switchTransDetailsController($scope, TransactConstant, $filter, $state, switchDtlsToReviewModel, transactModel) {  
	

    var switchDetailsObj = switchDtlsToReviewModel.getData();
    
    var transConf = transactModel.getTransactConfirm();

	$scope.keyValuePairs = [
				{	key : "destinationFund",
                    text : $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
                    value: switchDetailsObj.destinationFund.fundOptDesc
			    },
                {
                    key: "transactionRefNo",
                    text: $filter('translate')(TransactConstant.common.TRANSACTION_REF_NO),
                    value: transConf ? transConf.transactionRefNo : ""
                },
                {
                    key: "requestDateTime",
                    text: $filter('translate')(TransactConstant.transact.REQ_DATE_AND_TIME),
                    value: transConf ? transConf.transDateTime : ""
                }                
    ];                           
    
    if(switchDetailsObj.amount!=null || switchDetailsObj.amount!=undefined)
    {
        var amountObj = {
            key: "switchAmount",
            text : $filter('translate')(TransactConstant.transact.SWITCH_AMT),
            value: switchDetailsObj.amount
        };
        $scope.keyValuePairs.push(amountObj);
    }
    else if(switchDetailsObj.units!=null || switchDetailsObj.units!=undefined)
    {
        var uinitObj = {
            key: "switchUnit",
            text : $filter('translate')(TransactConstant.transact.SWITCH_UNIT),
            value: switchDetailsObj.units        
        };
        $scope.keyValuePairs.push(uinitObj);
    }    

    $scope.initiateAnotherSwitch = function(){
        transactModel.resetSetters(); 
        // transactModel.setStateValue({key:"Fund"});
        transactModel.isNewInvestor = false;
        $state.go('transact.base.switch',{key:null});
    } 
}

switchTransDetailsController.$inject = ['$scope', 'TransactConstant', '$filter', '$state','switchDtlsToReviewModel', 'transactModel'];
module.exports = switchTransDetailsController;