define([ 'appmodules/eSig/app/js/models/document-model' ], function(DocModel) {
	var DocumentCollection = Backbone.Collection.extend({
		model : DocModel,
		url : 'appmodules/eSig/app/js/data/content_1.js',
		parse : function(response) {
			return response.documentList;
		}
	});
	return new DocumentCollection();
});
