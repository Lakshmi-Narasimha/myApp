﻿define(['jquery',
    'underscore',
    'backbone',
    'components/js/views/AggregateView',
    'text!components/template/CheckBox.html'
], function ($, _, Backbone, AggregateView, CheckBoxHtml) {
	"use strict";
	var CheckBoxView = AggregateView.extend({
		// OPTIONAL PUBLIC PROPERTIES
		selectedItems: [],
		itemSelectionComplete: null, 
		objectRender: null,
		objectIdentifier: null, 
		//allButtonDisplay: null, 
		errorMessage: "Incomplete required field.",
		// PRIVATE PROPERTIES
		items: null,		
		template: _.template(CheckBoxHtml),
		initialize: function (options) {
			AggregateView.prototype.initialize.apply(this, arguments);
			_.extend(this, _.pick(options, 'items', 'sideCompIndex'));  // copies constructor attributes to this
			this.initializeProps();
		},
		events: {
			'change [pt-checkbox-button]': 'handleChange',
		},
		initializeProps: function () {
			this.selectedIndexes = []; // [Number]  indexes for selectedItems
			this.itemDescriptions = []; //[String] itemDescription to be shown on UI
			this.allSelectedItems = []; // [Object] .. selectedItems in order of selectedIndexes
		},
		initializeVars: function () {
			this.allItems = _.clone(this.items);
		},
		componentId: function () {
			return this.$el.prop('id');
		},
		render: function () {
			this.getValuesForPopulateUI();
			this.initializeVars();
		},
		reRender:function(){
			this.initializeProps();
			this.getValuesForPopulateUI();
		},
		getValuesForPopulateUI: function () {
			var self = this;
			_.each(this.items, function (item) {
				self.itemDescriptions.push(self.itemDescription(item));
			});
			this.getIndexForSelectedItems();
		},
		getIndexForSelectedItems: function () {
			var self = this;
			if (this.objectIdentifier && this.objectIdentifier == 'model') {
				_.each(self.items, function (allItem, index) {
					_.each(self.selectedItems, function (selectedItem) {
						if (selectedItem && selectedItem.id == allItem.id) {
							self.selectedIndexes.push(index);
							self.allSelectedItems.push(selectedItem);
						}
					});
				});
			} else {
				_.each(self.items, function (item, index) {
					_.each(self.selectedItems, function (selectedItem) {
						if (selectedItem && _.isEqual(selectedItem, item)) {
							self.selectedIndexes.push(index);
							self.allSelectedItems.push(selectedItem);
						}
					});
				});
			}
			this.populateUI();
		},
		initialHtmlForItem: function () {
			return this.template({
				componentId: this.componentId(),
				itemDescriptions: this.itemDescriptions,
				selectedIndexes: this.selectedIndexes,
				sideCompIndex: this.sideCompIndex
			});
		},
		populateUI: function () {
			var html = [];
			html.push(this.initialHtmlForItem());
			this.$el.html(html.join('\n'));
		},
		itemDescription: function (item) {
			if (this.objectRender) {
				return this.objectRender(item);
			} else if (item.description) {
				return typeof item.description === 'function' ? item.description() : item.description;
			} else {
				return '' + item;
			}
		},
		handleChange: function (e) {
			var itemId = parseInt($(e.target).closest('input').attr('pt-checkbox-button-id'));
			var targetVal = $(e.target);

			if ($(e.target).closest('input').is(":checked")) {
				this.selectedIndexes.push(itemId);
				this.allSelectedItems.push(this.allItems[itemId]);
				targetVal.parents('div.radio-group-conatiner')
						.addClass('active');
			} else {
				var itemIdIndexInSelectedIndexes = this.selectedIndexes.indexOf(itemId);
				this.allSelectedItems.splice(itemIdIndexInSelectedIndexes, 1);
				this.selectedIndexes.splice(itemIdIndexInSelectedIndexes, 1);
				targetVal.parents('div.radio-group-conatiner')
						.removeClass('active');
			}

			if (this.itemSelectionComplete) {
			    this.itemSelectionComplete(this.allSelectedItems, itemId, this.items[itemId]);
			}					
		},
		showError: function (shouldShow) {
		    if (!shouldShow) {
		        this.$('[ampf-error-label]').addClass('hidden');
		    } else {
		        this.$('[ampf-error-label]').text(this.errorMessage).removeClass('hidden');
		    }
		}
	});

	return CheckBoxView;

});
