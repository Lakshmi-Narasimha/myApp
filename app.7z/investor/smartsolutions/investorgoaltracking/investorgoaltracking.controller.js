
'use strict';
function smartSolInvestorGoalTrackingCtrl($scope, $state,investorGoalModelService, overviewModel, authenticationService, advisorEvents, recommendedPlanModelService, $uibModal,buildPlanModelService,savedSmartSolutionsModel, currentPlanFundsService, recommendedPlanInitialLoader) {

	$scope.selectInv = true;
	$scope.selectGoal = false;
	$scope.selectGoalTileList = false;
	$scope.selectedInvestor = {};
	$scope.selectedGoal = {};
	$scope.holderInfoArray =[];
	$scope.goalKeyValueList = [];
	$scope.currentPlanDtls = false;
	$scope.invstorGoalTracking = {};
	$scope.invstorGoalTracking.checkIGT=true;
	buildPlanModelService.tabname = "IGT";
	// goalTrackingInitialLoaderService.loadAllServices($scope);
	// $scope.goalSummary = buildPlanModelService.getBuildPlanDtls().planSmartSolutionPostReq.goalSummary;
	$scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
	
	$scope.$on('selectInvestor',function(event ,args){
		$scope.selectedInvestor = args;
		investorGoalModelService.setSelectedInvestorDetails($scope.selectedInvestor);
	});

	$scope.$on('selectGoal',function(event,args){
		$scope.selectedGoal = angular.copy(investorGoalModelService.getGoalInvestorData()[args]);
		investorGoalModelService.setSelectedGoalData($scope.selectedGoal);
	});

	$scope.$on('smartSolSelectInvestor',function(){
		var params = {
			"folioPanNo": $scope.selectedInvestor.folioId,//"17731364",//$scope.selectedInvestor.folioId,
			"guId" : authenticationService.getUser() ? authenticationService.getUser().guId : null
		};
		investorGoalModelService.folioId = $scope.selectedInvestor.folioId;
		investorGoalModelService.fetchGoalTrackingDtls(params)
			.then(function (data) {
				investorGoalModelService.setGoalInvestorData(data.fsGoalSummary);
				advisorEvents.smartSolutions.publishGoalInvestorData($scope,investorGoalModelService.getGoalInvestorData());
				$scope.selectInv = false;
				$scope.selectGoal = true;
			}, function (data) {
				console.log("ERROR");
				$scope.selectInv = false;
				$scope.selectGoal = true;
			});

		//recommendedPlanInitialLoader.loadPanlLevelServices(investorGoalModelService.getSelectedInvestorDetails().pan);
		
		var cFunds = {
			'goalId' : 'GO00000331',//Goal ID
			'guId' : authenticationService.getUser() ? authenticationService.getUser().guId : null
		};
		currentPlanFundsService.fetchCurrentFunds(cFunds)
			.then(function (data) {
				currentPlanFundsService.setCurrentFunds(data);
				console.log("CURRENT FUNDS", data)
			}, function () {
				console.log("ERROR")
			});

		$scope.holderInfoArray = [
              {key:"First Holder",value:$scope.selectedInvestor.custName},
              {key:"Second Holder",value:$scope.selectedInvestor.holders[1] ? $scope.selectedInvestor.holders[1].name : "NA"},
              {key:"Third Holder",value:$scope.selectedInvestor.holders[2] ? $scope.selectedInvestor.holders[2].name : "NA"},
              {key:"Folio. No.",value:$scope.selectedInvestor.folioId},
              {key:"Mode of Holding",value:$scope.selectedInvestor.holdingType}
        ];
        overviewModel.setHolderInformation($scope.holderInfoArray);
	});
	
	$scope.$on('smartSolSelectGoal',function(){
		$scope.selectGoalTileList = true;
		$scope.selectGoal = false;

		$scope.goalKeyValueList=[
					{key:"Goal",value:$scope.selectedGoal.goal},
                    {key:"Goal Details",value:$scope.selectedGoal.goalDetails},
                    {key:"Tenure (in Yrs.)",value:$scope.selectedGoal.timeFrame},
                    {key:"% Tenure Completed",value:($scope.selectedGoal.timeFrame - $scope.selectedGoal.pendingTimeFrame)},
                    {key:"Target Amount",value:$scope.selectedGoal.targetAmount},
                    {key:"Goal Achived Till Date",value:($scope.selectedGoal.achieved.split("%")[0] * $scope.selectedGoal.targetAmount) /100},
                    {key:"% Achieved",value:$scope.selectedGoal.achieved},
                    {key:"No of Yrs. Remaining (in Yrs.)",value:$scope.selectedGoal.pendingTimeFrame}
          	];
      	$state.go("smartSol.investor.cp");
      	$scope.currentPlanDtls = true;
	});
	
	$scope.panLevelInv = function(){
		$scope.$emit('showPANLevelInvModal');
	};

	$scope.getCurrentFunds = function () {
		var modalInstance = $uibModal.open({
        template : require('./components/newFundsModal/newFundsModal.html'),
        scope : $scope
      });
	};
	
	$scope.gridShow = function () {
		$scope.selectInv = true;
		$scope.selectGoal = false;
		$scope.selectGoalTileList = false;
		$scope.currentPlanDtls = false;		
		//$state.go("smartSol.investor", {}, {reload: true});
		$scope.$broadcast('invEditIcon');
	};

	$scope.goalGridShow = function () {
		$scope.selectGoal = true;
		$scope.selectGoalTileList = false;
		$scope.currentPlanDtls = false;
		$scope.$broadcast('topUpOptionsection');
	};
	
	$scope.$on('smartSolSaveBtn',function(){
		if(buildPlanModelService.getGoalSummaryFromState() === "smartSol.investor.topupwithsf.topupwithsamefunds"){
	        $scope.setFlag = "IS";
	    }
	    else if(buildPlanModelService.getGoalSummaryFromState() === "smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.or"){
	       $scope.setFlag = "IR"
	    }
	    else if(buildPlanModelService.getGoalSummaryFromState() === "smartSol.investor.modifymain.modifyapply"){
	      	$scope.setFlag = "IM"
	    }
	      
	    if(recommendedPlanModelService.getRecommendedFromState() === "smartSol.investor.cp"){
	        $scope.mode = "A";
	    }
	    else{
	        $scope.mode = "U"
	    }
      	var inputDtlsData = recommendedPlanModelService.getPlanInputDtls();
      	var investmentSummaryData = buildPlanModelService.getGoalPlanData();
      	var body = {
            "investorData": {
                "emailId": $scope.selectedInvestor.emailId,
                "trxnType": $scope.setFlag,
                "trxnNo": "",
                "folioId": ""+$scope.selectedInvestor.folioId,
                "holdingType": $scope.selectedInvestor.holdingType,
                "mode": $scope.mode,
                "holderDetails": [
                  {
                    "name": $scope.selectedInvestor.holders[0] ? $scope.selectedInvestor.holders[0].name : "",
                    "type": "Firstholder"
                  },
                  {
                    "name": $scope.selectedInvestor.holders[1] ? $scope.selectedInvestor.holders[1].name : "",
                    "type": "Secondholder"
                  },
                  {
                    "name": $scope.selectedInvestor.holders[2] ? $scope.selectedInvestor.holders[2].name : "",
                    "type": "Thirdholder"
                  }
                ]
              },
              "goalSheetData": {
                	"goalSummary": [
	                  {
	                    "goalName": $scope.selectedGoal.goal,
				        "goalDescription": $scope.selectedGoal.goaldetails,
				        "goalAmountAot": "20,00,00",
				        "goalAmountEog": "20,00,00",
				        "annualWithDrawals": "4000",
				        "annualStepUp": "10%",
				        "currentAge": "30 Years",
				        "goalTenor": $scope.selectedGoal.TenorinYrs,
				        "goalCompPer": $scope.selectedGoal.NoofYrstogoal,
				        "goalAchievedTillDt": $scope.selectedGoal.goalachivedtilldate,
				        "goalAchivedPer": $scope.selectedGoal.percentageachived,
				        "goalTenorRemained": "15"
				      }
	                ],
	                "topUpSummary": {
	                  "goalName": "Child Education",
	                  "goalDeficit": "9,00,000",
	                  "goalTenorRemained": "15"
	                },
	                "investmentSummary": [
	                  {
				        "fund": "Franklin India blue Chip",
				        "allocation": "50%",
				        "monthly": "800",
				        "annual": "8,000",
				        "oneTime": "40,000"
				      },
				      {
				        "fund": "Franklin Templeton Asian Equity Fund",
				        "allocation": "50%",
				        "monthly": "550",
				        "annual": "4,500",
				        "oneTime": "35,000"
				      },
				      {
				        "fund": "Total",
				        "allocation": "100%",
				        "monthly": "1350",
				        "annual": "12,500",
				        "oneTime": "75,000"
				      }
	                ],
	                "investmentSimulation": [
	                  {
	                    "time": "Current",
	                    "amount": "800"
	                  },
	                  {
	                    "time": "10 years",
	                    "amount": "1,500"
	                  },
	                  {
	                    "time": "15 years",
	                    "amount": "1,800"
	                  }
	                ]
              	}
            };

        console.log("saved smart solutions- investor goal tracking",body);
        savedSmartSolutionsModel.postSavedSmartSolDtls(body);
	});
 	
 	$scope.$on('smartSolEmailBtn',function(){
 		var body = {
		  	"investorData":
                {
                    "userId":"SDANDAM",
                    "invEmailId":transactModel.getInvestorDetails().emailId,
                    "reqstType":"GoalSheet",
                    "reqstNumber":"GS3399909",
                    "reqstDate":"8/26/2016"
                },
            "goalSheetData":
              {
                "goalSummary":[
                  {
	                  "goalName":$scope.selectedGoal.goal,
	                  "goalAmount":"",
	                  "annualWithDrawals": "4000",
				      "annualStepUp": "10%",
				      "currentAge": "30 Years",
	                  "goalAtAge":"20 years",
	                  "goalTenor": $scope.selectedGoal.TenorinYrs,
             	 }
                ],
                "investmentSummary":[
                  {
			        "fund": "Franklin India blue Chip",
			        "allocation": "50%",
			        "monthly": "800",
			        "annual": "8,000",
			        "oneTime": "40,000"
			      },
			      {
			        "fund": "Franklin Templeton Asian Equity Fund",
			        "allocation": "50%",
			        "monthly": "550",
			        "annual": "4,500",
			        "oneTime": "35,000"
			      },
			      {
			        "fund": "Total",
			        "allocation": "100%",
			        "monthly": "1350",
			        "annual": "12,500",
			        "oneTime": "75,000"
			      }
                ],
                "investmentSimulation":
                  {
                  "fiveYears":"Franklin India blue Chip",
                  "tenYears":"80%",
                  "fifteenyears":"800",
                  "twentyYears":"8000",
                  "twentyFiveYears":"40,000"
                  }
              }
		};
      console.log("Investor Goal Tracking Email smart solutions",body);
      savedSmartSolutionsModel.postEmailSmartSolDtls(body);
 	});
}

smartSolInvestorGoalTrackingCtrl.$inject = ['$scope', '$state','investorGoalModelService', 'overviewModel', 'authenticationService', 'advisorEvents', 'recommendedPlanModelService', '$uibModal','buildPlanModelService','savedSmartSolutionsModel', 'currentPlanFundsService', 'recommendedPlanInitialLoader'];
module.exports = smartSolInvestorGoalTrackingCtrl;