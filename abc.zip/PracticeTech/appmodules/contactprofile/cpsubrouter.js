﻿// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
  'backbonesubroute',
  'appcommon/memmorymgr',
  'appmodules/contactprofile/cpcommon',
  'appcommon/constants',
  'appcommon/globalcontext',
  'appmodules/contactprofile/app/views/cpshellview',
  'appmodules/contactprofile/app/views/iraview',
  'appcommon/commonutility',
], function ($, _, Backbone, backbonesubroute, MemmoryMgr, CommonUtil, Constants, GlobalContext, CPShellView, IRAView, CommonUtility) {
    var cpRouter = Backbone.SubRoute.extend({
        routes: {
        	// Define some URL routes         
        	'preferences': 'showPreferences',
        	'bank': 'showBank',
            'fiduciary': 'showFiduciary',
            'beneficiary': 'showBeneficiary',
            'contributions': 'showContributions',
            'distributions': 'showDistributions',
            'iradetails/:index/:type': 'showIraDetails',
            'activitylist': 'donothing',
            'newappointment': 'donothing',
            'newtask': 'donothing',
            // Default
            '*actions': 'defaultAction'
        },
        initialize : function(){
        	this.cpshell = undefined;
        	this.iraView = undefined;
        },
        defaultAction: function () {
        	this.renderCPShell("contactprofile")
        },
        showSmartPad: function (actions) {                      
            Backbone.history.navigate('crm/smartpad', true);
        },
        showBeneficiary : function (actions) {
        	this.renderCPShell('beneficiary');
        },
        showPreferences : function (actions) {
        	this.renderCPShell('preferences');
        },
        showBank: function (actions) {
        	this.renderCPShell('bank');
        },
        showFiduciary : function (actions) {
        	this.renderCPShell('fiduciary'); 
        },
        showContributions : function (actions) {
        	if(!this.iraView || (this.iraView.iraType && this.iraView.iraType != "contributions")){
        		this.iraView = new IRAView({iraType:"contributions"});
        	}
        	MemmoryMgr.setcurrentview(this.iraView);
        	this.renderCPShell('contributions', {view:this.iraView,iraType:"contributions"}); 
        },
        showDistributions : function (actions) {
        	if(!this.iraView || (this.iraView.iraType && this.iraView.iraType != "distributions")){
        		this.iraView = new IRAView({iraType:"distributions"});
        	}
          	 MemmoryMgr.setcurrentview(this.iraView);
        	this.renderCPShell('distributions',{view:this.iraView,iraType:"distributions"}); 
        },
        showIraDetails : function (index, type) {
        	this.iraView.renderDetails(index, type, this.iraView);
        },
        renderCPShell: function (subtab, params) {
            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
        	if(!this.cpshell){
        		this.cpshell = new CPShellView();
        	}
        	this.cpshell.render(_gContext.ContactId, subtab, params);
        }
    });
    return { cpRouter: cpRouter };
});
