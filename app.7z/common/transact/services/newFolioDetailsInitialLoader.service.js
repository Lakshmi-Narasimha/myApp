'use strict';

var newFolioDetailsInitialLoader = function (newFolioModelService, transactEvents, transactEventConstants, $loader) {

    var newFolioDetailsInitialLoader = {
        _isServicesData: false,
        loadAllServices: function (scope) {

            function newFolioDetailsSuccess(data) {
                newFolioModelService.setNewFolioDtls(data[0]);
                transactEvents.transact.publishNewFolioDetails(scope, newFolioModelService.getNewFolioDtls());

            }

            function handleFailure() {
                console.error('handleFailure');
                newFolioDetailsInitialLoader._isServicesData = false;
            }

            $loader.start();
            newFolioModelService.fetchNewFolio()
                .then(newFolioDetailsSuccess, handleFailure)
                .finally(function () {
                    $loader.stop();
                });


        }

    };
    return newFolioDetailsInitialLoader;
};

newFolioDetailsInitialLoader.$inject = ['newFolioModelService', 'transactEvents', 'transactEventConstants', '$loader'];

module.exports = newFolioDetailsInitialLoader;