'use strict';

var goalTrendsModelService= function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _attrDtls = null;

    var goalTrendsModel = {
        fetchAttrAnalysisDtls : function (scope,selectedGoal) {
            var params = {};
            params.guId = authenticationService.getUser().guId;
            params.strInputType = "";
            params.strGoalType = "";
            if(selectedGoal){
                params.strInputType = selectedGoal.strInputType;
                params.strGoalType = selectedGoal.strGoalType;
            }
            var deferred = $q.defer();
            Restangular.one('smartsolution/goalTrends').get(params).then(function (attrDetails) {
                deferred.resolve(attrDetails);
                console.log("attrDetails",attrDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getAttrAnalysisDtls : function () {
                 return _attrDtls;
        },
        setAttrAnalysisDtls : function (attrAnalysisData) {
            _attrDtls = attrAnalysisData;
        }

    };
    return goalTrendsModel;

};

goalTrendsModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService'];
module.exports = goalTrendsModelService;
