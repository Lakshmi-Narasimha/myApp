define([
    'jquery',
    'underscore',
    'backbone',
    'appmodules/gpm/app/js/utils',
    'appmodules/ncst/app/data/country-list',
    'appmodules/contactprofile/app/models/cpviewmodel',
    'text!appmodules/gpm/app/templates/gpmemployment.html',
    'appcommon/commonutility',
    'appcommon/constants',
    'appmodules/ncst/app/js/lib/validate-4.2',
    'appcommon/abstractview',
    'text!components/template/EmpCompTemplate.html',
    'text!components/template/EmpCompViewTemplate.html',
    'components/js/views/EmpCompView',
    'components/js/views/CheckBoxView',
    'components/js/model/EmpCompModel',
    'components/js/views/RadioButtonView'
], function ($, _, Backbone, Utils, DropdownListData, CPViewModel, GPMEmploymentTemplate, CommonUtility, Constants,
Validator, AbstractView, EmployerCompanyTemplate,
EmployerCompanyViewTemplate, EmpCompView, CheckBoxView, EmpCompModel,
RadioButtonView) {
    var empBtn = '', ofcBtn = '';
    var newEmployerComponentCount = 0;
    var newCompanyComponentCount = 0;
    var newFinraCompanyComponentCount = 0;
    var FINRAData = [], shareHolderData = [], employmentData = [], shareHolderCheckbox = [], finraCheckbox = [];
    var self = null;
    var maxCount = 3; //Including 0 this should be 4
    var employmentView = AbstractView.extend({
        el: "#gpm-form-update-field-container",
        id: "gpm-form-update-field-container",
        componentId: 0,
        template: _.template(GPMEmploymentTemplate),
        initialize: function (data) {
            self = this;
            this.data = data;
            newEmployerComponentCount = 0;
            newCompanyComponentCount = 0;
            newFinraCompanyComponentCount = 0;
            this.$main = this.$('#client-info');
            this.employerComponentNm = "Employer";
            this.companyComponentNm = "Company";
            this.finraCompanyComponentNm = "Company";
            this.employerCompData = new EmpCompModel().toJSON();
            this.isOfficerCheckboxToCompViewMapping = {};
            this.isOfficerAddrssCompViews = [];
            this.employerDynamicCheckboxView = 'employerDynamicCheckboxView';
            this.companyDynamicCheckboxView = 'companyDynamicCheckboxView';
            this.selectSameAsSectionCheckboxes = 'select-same-as-section-checkboxes';
            this.selectWhichEmployerCheckboxes = 'select-which-employer-checkboxes';
            this.employmentStatusViewName = 'employmentStatusView';
            this.employmentStatusOptions = Constants.employmentStatusOptions;
            AbstractView.prototype.initialize.apply(this, arguments);
        },
        events: {
            'click .is-employed': 'toggleEmployed',
            'click .is-officer': 'toggleOfficer',
            'change #ce-not-employed, #ce-retired, #ce-other': 'toggleNotEmployed',
            'change input[name="empStatus"]': 'handleEmpStatusChange',
            'click #add-another-employer-btn': 'handleAddingAnotherEmployer',
            'click #add-another-company-btn': 'handleAddingAnotherCompBtnClick',
            'click #finra-add-another-company-btn': 'handleFinraAddingAnotherCompany',
            'change select#pt-emp-select-industry': 'handleEmpIndustryOptions',

            'keypress .us-zipcode': 'numValidator',

            'change #employed, #self-employed': 'selectedEmployed',
            'change input[name="aeAddressType"]': 'toggleAddressType'
        },
        initializeElementVars: function () {
            this.$addAnotherEmployerBtn = this.$("[data-for='add-another-employer-btn']");
            this.$addAnotherCompanyBtn = this.$("[data-for='add-another-company-btn']");
            this.$finraAddAnotherCompanyBtn = this.$("[data-for='finra-add-another-company-btn']");
            this.$addAnotherCompanyContainer = $('#add-another-company-cntr');
            this.$empComponentContainer = $("#employer-component");
            this.$isEmployedBtnsHolder = $('[data-for="is-employed"]');
            this.$isOfficerBtnCHolder = $('[data-for="is-officer"]');
            this.$finraContainer = $('#finra-add-company-component');
            this.$shareHolderContainer = $("#company-component");
            this.$employmentStatusViewContainer = $("#employment-status-view-container");
        },
        clearView: function () {
            this.undelegateEvents();// Unbind all local event
            // bindings
            this.model.unbind('change', this.render, this); // Unbind reference to the model
        },
        render: function (updateMode) {
            var self = this;
            try {
                var empCntryList = DropdownListData.employerCountryList;
                if (!this.model.get('currentItemSet')) {
                    var CPData = CPViewModel.getInstance().getData();
                    var employmentInfo = CPData.cola.clientPersonal.attributes.employmentInfo;
                    this.data.fieldsInfo = this.getGPMData(CPData);
                    var cntryNm = employmentInfo.get("emprCntryNm");
                    if (cntryNm != null) {
                        if (cntryNm.length > 2) {
                            for (var i = 0; i < empCntryList.length; i++) {
                                var _cntry = empCntryList[i];
                                if (_cntry.name == cntryNm) {
                                    this.data.fieldsInfo.emprCntryNm = empCntryList[i].code;
                                }
                            }
                        }
                    }
                    this.model.set('isNotInCM', this.data.fieldsInfo.isNotInCM);
                    this.model.setCurrentValue(updateMode, { data: this.data });
                }
                var _compiledTemplate = this.template({ data: this.model });
                $("#" + this.id).html(_compiledTemplate);
                self.initializeElementVars();
                this.renderUI();
                var _emplStatCd = _.find(this.model.get("items"), function (item) {
                    return item.get("itemType") == "emplStatCd";
                });
                if (_emplStatCd.get('changedItemValueId') == "C") { $('.emp-common').addClass('hidden'); }
                $('#notemployedInfo').addClass("hidden");
                var finraSectionInfo = _.find(this.model.get('items'), function (item) {
                    return item.get("itemType") == "finraSectionArr";
                });
                var shareHolderInfo = _.find(this.model.get('items'), function (item) {
                    return item.get("itemType") == "sameAsCompanyArr";
                });
                finraSectionInfo.set({
                    changedItemValue: [],
                    changedItemValueId: []
                });
                shareHolderInfo.set({
                    changedItemValue: [],
                    changedItemValueId: []
                });
            }
            catch (error) {
                console.log(error);
            }
            $('#section-employment').invokeInfoPopup();
        },
        renderUI: function () {
            var emplStatCd = self.model.get('items').find(function (row) { return row.get("itemType") == "emplStatCd" });
            var empStatusOption = _.find(this.employmentStatusOptions, function (employmentStatusOptions) {
                   return emplStatCd.get("changedItemValueId") == employmentStatusOptions.serviceVal;
            });
            var finraStatus = self.model.get('items').find(function (row) { return row.get("itemType") == "finInstnEmplCd" });;
            var shareHolderStatus = self.model.get('items').find(function (row) { return row.get("itemType") == "ownrOfcrCd" });


            var employerADdrsColl = self.model.get('items').find(function (row) { return row.get("itemType") == "employerAddressCollection" });
            var employmentAddrData = employerADdrsColl.get("changedItemValue");

            var finraAddressCollection = self.model.get('items').find(function (row) { return row.get("itemType") == "finraAddressCollection" });
            var finraAddrData = finraAddressCollection.get("changedItemValue");

            var shareHolderADdrsColl = self.model.get('items').find(function (row) { return row.get("itemType") == "shareholderAddressCollection" });
            var shareHolderAddrData = shareHolderADdrsColl.get("changedItemValue");

            var industryClassifyType = self.model.get('items').find(function (row) { return row.get("itemType") == "industryClassifyType" });
            var industryFreeFormText = self.model.get('items').find(function (row) { return row.get("itemType") == "industryFreeFormText" });

            if ((empStatusOption.value == "Employed" || empStatusOption.value == "Self employed") ) {
                $("#employer-component").removeClass('hidden');
                if (employmentAddrData.length > 0) {
                    for (i = 0; i < employmentAddrData.length; i++) {
                        if (i > 0) {
                            this.handleAddingAnotherEmployer(undefined, employmentAddrData[i], true);
                        } else {
                            this.renderEmployerCompView(employmentAddrData[i], 0/*rendering the first emp address component, so index is 0*/, !this.model.get("isNotInCM"));
                        }
                    }
                } else {
                    this.renderEmployerCompView(undefined, 0/*rendering the first emp address component, so index is 0*/, !this.model.get("isNotInCM"));
                }
                
            }
            //Show or Hide 'Which Employer' Section
            self.renderWhichEmployerSection("employer", "which-employer");

            //Show or Hide 'Which Employer' Section
            self.renderSameAsSection("company", "same-as-section");

            if (finraStatus.get("changedItemValue") == "Yes" && finraAddrData.length > 0) {
                $('#finra-add-company-component').removeClass('hidden');
                for (i = 0; i < finraAddrData.length; i++) {
                    if (finraAddrData[i].doNotDisplay && finraAddrData[i].doNotDisplay == true) {
                    } else {
                        this.handleFinraAddingAnotherCompany(finraAddrData[i]);
                    }
                }
            }

            if (shareHolderStatus.get("changedItemValue") == "Yes" && shareHolderAddrData.length > 0) {
                $('#company-component').removeClass('hidden');
                for (i = 0; i < shareHolderAddrData.length; i++) {
                    var launchMode = shareHolderAddrData[i].launchMode,
                        addressViewName;
                    addressViewName = this.handleAddingAnotherCompany(shareHolderAddrData[i], launchMode);
                    if (launchMode == "view") {
                        this.isOfficerCheckboxToCompViewMapping[shareHolderAddrData[i]["EmpAddComUIRefId"]] = addressViewName;
                    }
                }
            }
            if (emplStatCd.get("changedItemValueId") == "B") {
                $('#emp-industry-classification').removeClass('hidden');
                CommonUtility.loadSelectbox(["#pt-emp-select-industry"], Constants.industryClassifications);
                var industryValue = industryClassifyType.get('changedItemValueId');
                if (industryValue != null) {
                    var industryInput = $('#pt-emp-industry-other-input');
                    $('#pt-emp-select-industry').val(industryValue);
                    if (industryClassifyType.get('changedItemValue').toLowerCase() == "other") {
                        $('#pt-emp-industry-other').removeClass('hidden');
                        industryInput.val(industryFreeFormText.get('changedItemValueId'));
                    } else {
                        industryInput.val("");
                    }
                }
            } else {
                $('#emp-industry-classification, #pt-emp-industry-other').addClass('hidden');
            }
            this.afterRender();
            return this;
        },
        afterRender: function () {
            var $isEmployed = $('.emp-yes.active');

            //If either "yes" clicked, hide radio buttons
            if ($isEmployed.length) {
                //hide retired. hide other.
                $('#ce-not-employed').hide().removeClass('active');
                $('#not-employed').attr('checked', false);
                $('#ce-retired').hide().removeClass('active');
                $('#retired').attr('checked', false);
                $('#ce-other').hide().removeClass('active');
                $('#other').attr('checked', false);
            }
        },
        doCustomValidations: function (employmentDetails) {
            var hasError = false;
            var $employmentContainer = $("#gpm-form-update-field-container"),
                $isEmployedContainer = $employmentContainer.find('div[data-for="is-employed"]'),
                $isofficerContainer = $employmentContainer.find('div[data-for="is-officer"]'),
                noCompanyErrorMessage = "At least one employer or company is required.";
            if (employmentDetails.isEmployed == "Yes") {
                if (employmentDetails.finraAddrsColl.length === 0) {
                    hasError = true;
                    $isEmployedContainer.addClass("error").find("label.error").removeClass("hidden").text(noCompanyErrorMessage);
                }
            }
            if (employmentDetails.isShareHolder == "Yes") {
                if (employmentDetails.shareHolderAddrsColl.length === 0) {
                    hasError = true;
                    $isofficerContainer.addClass("error").find("label.error").removeClass("hidden").text(noCompanyErrorMessage);
                }
            }
            var $errorDiv = $('.error:visible');
            if ($errorDiv[0]) {
                $errorDiv[0].scrollIntoView(true);
            }
            return hasError;
        },
        handleEmpStatusChange: function (el) {
            this.toggleNotEmployed(el);
            this.toggleRadioClassActive(el);
            var empStatusEleId = el.currentTarget.id;
            var employerComponentId = $("#employer-component"),
                notEMployed = empStatusEleId == "not-employed",
                isEmplyedOrSelfEmployed = empStatusEleId == "employed" || empStatusEleId == "self-employed",
                clearFinraViews = !isEmplyedOrSelfEmployed;
            this.clearSameAsAndWhichEmployerCheckBoxViews(clearFinraViews);
            this.resetSections("employer-component", "employer");
            this.resetSections("which-employer");
            if (isEmplyedOrSelfEmployed && !employerComponentId.is(':Visible') && employerComponentId.hasClass('hidden')) {
                //Show the container first then render the template inside that
                var $employerComps = $("#employer").find(">div");
                employerComponentId.removeClass('hidden');
                //Render Employer Template
                this.renderEmployerCompView(undefined, 0/*rendering the first emp address component, so index is 0*/);
            }
            if (empStatusEleId == "self-employed") {
                $('#emp-industry-classification').removeClass('hidden');
                CommonUtility.loadSelectbox(["#pt-emp-select-industry"], Constants.industryClassifications);
            } else {
                $('#emp-industry-classification, #pt-emp-industry-other').addClass('hidden');
            }
            self.checkForAddressMaxNumLimit(["employer", "company", "finra-add-company-component"]);
        },
        validateAndPreSelectIndstryClassfctn: function (empStatus) {
            if (empStatus == "Self employed") {
                $('#emp-industry-classification').removeClass('hidden');
                CommonUtility.loadSelectbox(["#pt-emp-select-industry"], Constants.industryClassifications);
                if (_dataEmp && _dataEmp.get('industryClassifyEmp') != "") {
                    var industryValue = _dataEmp.get('industryClassifyEmp');
                    var industryInput = $('#pt-emp-industry-other-input');

                    indText = this.industryClassification(industryValue);

                    $('#pt-emp-select-industry').val(indText);
                    if (industryValue == "Other") {
                        $('#pt-emp-industry-other').removeClass('hidden');
                        industryInput.val(_dataEmp.get('industryClassifyEmpOther'));
                    } else {
                        industryInput.val("");
                    }
                }
            } else {
                $('#emp-industry-classification, #pt-emp-industry-other').addClass('hidden');
            }
        },
        renderEmployerCompView: function (compData, comonentUiIndex, isCMuser) {
            newEmployerComponentCount++;
            var launchMode = 'edit';
            var compReferenceNm = self.employerComponentNm.toLowerCase(); //Employer - to - employer
            var mainCompReferenceId = $("#" + compReferenceNm); //$("#employer")
            var count = self.getCount(compReferenceNm) + 1;
            var dynamicPlaceHolder = self.employerComponentNm + "-comp-" + newEmployerComponentCount;
            mainCompReferenceId.append("<div id='" + dynamicPlaceHolder + "'></div>");
            var compReferenceId = self.$("#" + dynamicPlaceHolder);

            var componentViewOptions = {
                "nestedViewName": "pt-temp-employer-" + newEmployerComponentCount + "-" + comonentUiIndex,
                "compConstrParams": {
                    showJobTitleField: (isCMuser && comonentUiIndex === 0 ? true : false), showPrimOccpatn: (comonentUiIndex === 0 ? true : false), el: compReferenceId, componentName: self.employerComponentNm, componentId: newEmployerComponentCount, compData: this.employerCompData, count: count, compData: compData ? compData : null
                },
                "compType": compReferenceNm
            };

            this.renderEmpCompView(componentViewOptions, launchMode);
            this.updateEmployerComponentUIIndex();
        },
        isItemSelected: function (view, refId) {
            var selectedItems = view.allSelectedItems,
                selectedItem = _.find(selectedItems, function (item) {
                    return item.empRefId == refId;
                });
            return selectedItem;

        },
        handleEmpCompCancelBtn: function (params/*compType, viewName, view*/) {
            var view = params.view,
                compType = params.compType,
                viewName = params.viewName,
                isAddressValid = view.isTheAddressValid(),
                el = view.el,
                uiIndex = $(el).find(".pt-empcomp").attr("ui-index"),
                isEmployedSelected,
                isOfficerSelected,
                countOfContainers = self.getCount('employer'),
                corrspndngCmpnyView,
                selectedItem,
                companyDynamicCheckboxView = this.getNestedView(this.companyDynamicCheckboxView),
                employerDynamicCheckboxView = this.getNestedView(this.employerDynamicCheckboxView);

            if (compType == "employer") {
                isEmployedSelected = this.$isEmployedBtnsHolder.find(".toggle-button-yes").hasClass("active");
                isOfficerSelected = this.$isOfficerBtnCHolder.find(".toggle-button-yes").hasClass("active");
                self.removeNestedView(viewName);
                $(el).remove();
                self.updateEmployerComponentUIIndex();
                if (isAddressValid) {
                    if (isEmployedSelected) {
                        if (employerDynamicCheckboxView) {
                            self.triggerUncheckEventOfCheckbox(employerDynamicCheckboxView, view.employerCompanyInfo.id);
                        }
                        //re render which employed check box
                        self.renderIsEmployerCheckBox();
                    }
                    if (isOfficerSelected) {
                        if (companyDynamicCheckboxView) {
                            self.triggerUncheckEventOfCheckbox(companyDynamicCheckboxView, view.employerCompanyInfo.id);
                        }
                        //re render is office check box
                        self.renderOfficerSameAsCheckBox();
                    }
                }


                function hideFinraSection() {
                    //Hide Finra Add Company
                    $('#finra-add-company').empty(); //Clear off the content
                    $('#finra-add-company-component').addClass('hidden'); //hide the parent container
                    //Uncheck if anything is checked
                    self.unCheckAllCheckBoxes(this.selectWhichEmployerCheckboxes);
                    self.resetAllSelectedItems(this.employerDynamicCheckboxView);
                    $("#which-employer").addClass('hidden');
                }

            } else {
                if (view.launchMode == "view") {
                    //view mode is only for Same As section
                    self.triggerUncheckEventOfCheckbox(companyDynamicCheckboxView, view.employerCompanyInfo.relatedModelRefId);
                } else {
                    self.removeNestedView(viewName);
                    $(el).remove();
                }
            }

        },
        industryClassification: function (indsClsCd) {
            var mappingCode = Constants.industryClassifications;
            var indsName = "";
            _.each(mappingCode, function (list) {
                if (list.name == indsClsCd) {
                    indsName = list.code;
                }
            });
            return indsName;
        },
        triggerUncheckEventOfCheckbox: function (checkBoxView, relatedModelRefId) {
            var selectedItem = self.getSelectedItemByRelatedModelId(checkBoxView, relatedModelRefId);
            if (selectedItem) {
                $("#" + selectedItem.id).trigger("click");
            }
        },
        employerAddressCompFieldChangeHandler: function (empCompView) {
            var compType = empCompView.componentName.toLowerCase(),
                dataModel = empCompView.employerCompanyInfo,
                whichEmployerPlaceHolder = "which-employer",
                sameAsPlaceHolder = "same-as-section",
                companyPlaceHolder = "company",
                isAddressValid = false,
                companyDynamicCheckboxView = self.getNestedView(self.companyDynamicCheckboxView),
                employerDynamicCheckboxView = self.getNestedView(self.employerDynamicCheckboxView);

            var getEmployerSectionCount = self.getCount(compType); //employer
            var isFinraQuesSelected = $('.is-employed').filter('.active').val();
            var isShareHolerQuesSelected = $('.is-officer').filter('.active').val();

            if ((getEmployerSectionCount > 0 && compType == 'employer') && ((isFinraQuesSelected != 'No' && isFinraQuesSelected != null) || (isShareHolerQuesSelected != 'No' && isShareHolerQuesSelected != null))) {
                isAddressValid = empCompView.isTheAddressValid();
                if (isFinraQuesSelected == "Yes") {
                    self.renderWhichEmployerSection(compType, whichEmployerPlaceHolder, dataModel);
                }
                if (isShareHolerQuesSelected == "Yes") {
                    if (!isAddressValid) {
                        //trigger uncheck event if checked
                        self.uncheckIsOfficerCheckbox(self.getNestedView(self.companyDynamicCheckboxView), empCompView.employerCompanyInfo.id);
                        self.renderSameAsSection(compType, sameAsPlaceHolder, dataModel);
                    } else {
                        self.renderSameAsSection(compType, sameAsPlaceHolder, dataModel);
                        self.updateSameAsSection(empCompView);
                    }

                }
            }
        },
        updateSameAsSection: function (empCompView) {
            var isThisItemSelected,
                corrspndngCompanyView;
            isThisItemSelected = self.getSelectedItemByRelatedModelId(self.getNestedView(self.companyDynamicCheckboxView), empCompView.employerCompanyInfo.id);
            if (!!isThisItemSelected) {
                //manually call the on change event
                corrspndngCompanyView = self.getEmployeComViewByViewModelProp("relatedModelRefId", empCompView.employerCompanyInfo.id);
                corrspndngCompanyView.employerCompanyInfo = $.extend(corrspndngCompanyView.employerCompanyInfo, _.omit(empCompView.employerCompanyInfo, ["relatedModelRefId", "id", "tickerSymbol", "relSeqNbr"]));
                corrspndngCompanyView.reRender();
            }
        },
        uncheckIsOfficerCheckbox: function (view, relatedModelRefId) {
            var selectedItems,
                selectedItem = self.getSelectedItemByRelatedModelId(view, relatedModelRefId),
                itemIndex;
            if (!!selectedItem) {
                selectedItems = _.filter(view.allSelectedItems, function (item) {
                    return item.relatedModelRefId != relatedModelRefId;
                });
                view.selectedItems = selectedItems;
                view.allSelectedItems = [];
                itemIndex = Number(selectedItem.id.charAt(0));
                view.reRender();
                //manually call the on change event
                view.itemSelectionComplete(selectedItems, itemIndex, selectedItem);
            }
        },
        getSelectedItemByRelatedModelId: function (view, relatedModelRefId) {
            var chckboxItems,
                chboxItemCorrspndngToEmpView,
                isThisItemSelected,
                selectedItems;
            if (view && view.allSelectedItems) {
                selectedItems = $.extend([], view.allSelectedItems);
                chckboxItems = view.items;
                chboxItemCorrspndngToEmpView = _.find(chckboxItems, function (item) {
                    return item.relatedModelRefId == relatedModelRefId;
                });
                isThisItemSelected = _.find(view.allSelectedItems, function (item) {
                    return chboxItemCorrspndngToEmpView && chboxItemCorrspndngToEmpView.id == item.id;
                });
            }
            return isThisItemSelected;
        },
        renderEmpCompView: function (componentRenderingOptions, launchMode) {
            var self = this;
            var launchMode = (launchMode == '') ? 'view' : launchMode;
            var empCompView = new EmpCompView(componentRenderingOptions.compConstrParams);
            this.addNestedView(componentRenderingOptions.nestedViewName, empCompView);

            //Trigger an event on all fields change
            empCompView.triggerFieldEvents = function (modelPropNm, changedVal) {
                self.employerAddressCompFieldChangeHandler(empCompView, modelPropNm, changedVal);
                self.checkForAddressMaxNumLimit(["company", "finra-add-company-component"]);
            };
            //Trigger an event on Cancel button click
            empCompView.triggerCancelBtnEvt = function (selectedItem) {
                //update the UI index on removing one comp from UI
                self.handleEmpCompCancelBtn({
                    "compType": componentRenderingOptions.compType,
                    "viewName": componentRenderingOptions.nestedViewName,
                    "view": empCompView
                });
                self.addDynamicLabels(componentRenderingOptions.compType);
                self.checkForAddressMaxNumLimit(["employer", "company", "finra-add-company-component"]);
                //self.removeSectionFrmMultiplicity(componentRenderingOptions.compConstrParams.componentName.toLowerCase(), selectedItem, componentRenderingOptions.nestedViewName);
                //self.handleBlurEvntOnEmployerName();
            };
            empCompView.compType = componentRenderingOptions.compType;
            empCompView.launchMode = launchMode;
            empCompView.render();
            //add the UI Index only for Employer component
            if (componentRenderingOptions.compType) {
                empCompView.$el.attr("ui-index", componentRenderingOptions.uiIndex);
            }
        },
        getEmployeComViewByViewModelProp: function (modelProp, modelPropVal) {
            var nestedViews = self.nestedViews,
                requestedView;
            for (viewName in nestedViews) {
                var view = nestedViews[viewName];
                if (viewName.indexOf('pt-temp-') > -1) {
                    if (view.employerCompanyInfo && view.employerCompanyInfo[modelProp] && view.employerCompanyInfo[modelProp] == modelPropVal) {
                        requestedView = view;
                    }
                }
            }
            return requestedView;
        },
        removeSectionFrmMultiplicity: function (componentName, selectedItem, nestedViewNm) {
            var $parentContainer = $('#pt-temp-' + selectedItem).parent();
            var referenceIndexId = $parentContainer.attr('data-reference-id');

            var replaceEmpToComp = selectedItem.replace('employer', 'company');
            //var $companyContainer = $('#pt-temp-' + replaceEmpToComp).is(':visible');
            var $companyParentContainer = $('#pt-temp-' + replaceEmpToComp).parent();

            var selectedItemSplit = selectedItem.split('-');
            var compNm = selectedItemSplit[0];
            var compId = selectedItemSplit[1];

            //Handle when Cancel button clicked in Company Section - which is orginated from Same As section
            if (componentName == 'company') {
                var sameAsCheckBoxReferenceId = $parentContainer.attr('data-reference-id');
                var sameAsCheckBoxReferenceNm = $parentContainer.attr('data-reference-name');
                var dataIdentifier, companyArrId, companyArr;
                //pt-employer-name-1
                if (referenceIndexId != undefined || sameAsCheckBoxReferenceId != undefined || sameAsCheckBoxReferenceNm != undefined) {
                    if (this.getNestedView('companyDynamicCheckboxView') != undefined) {
                        companyArr = this.nestedViews["companyDynamicCheckboxView"].allSelectedItems;
                    }
                    dataIdentifier = sameAsCheckBoxReferenceId - 1;
                    dataIdentifierEleId = $('input[name=' + this.selectSameAsSectionCheckboxes + ']').filter('[data-identifier=' + dataIdentifier + ']').attr('id');
                    companyArrId = dataIdentifierEleId;

                    self.uncheckAndDisableCheckBox(dataIdentifierEleId);

                    self.spliceIt(companyArr, companyArrId);
                }
            } else if (componentName == 'employer') { //Handle when Cancel button clicked in Employer Section - which is orginated from Actual Employer section
                var nestedViewsData = this.nestedViews["companyDynamicCheckboxView"];
                if ($('input[name=' + this.selectSameAsSectionCheckboxes + ']').filter('[data-identifier="pt-' + compNm + '-name-' + compId + '"]').prop('checked')) {
                    this.removeNestedView($('div [data-reference-name="' + compNm + '"][data-reference-id="' + compId + '"]').children().attr('id'));
                    $('div [data-reference-name="' + compNm + '"][data-reference-id="' + compId + '"]').remove();
                }
                if (this.getNestedView('companyDynamicCheckboxView') != undefined) {
                    //this.nestedViews["employerDynamicCheckboxView"].allSelectedItems.splice(parseInt(referenceIndexId -1), 1);
                    nestedViewsData.allSelectedItems.splice(parseInt(compId - 1), 1);
                    nestedViewsData.selectedIndexes.splice(parseInt(compId - 1), 1);
                    nestedViewsData.items.splice(parseInt(compId - 1), 1);
                    nestedViewsData.allItems.splice(parseInt(compId - 1), 1);
                }
            }

            this.removeNestedView(nestedViewNm);
            $parentContainer.remove(); // Remove the section

            //if company div exists remove that
            //$companyParentContainer.remove();

            //Show or Hide 'Which Employer' Section
            //this.renderSameAsSection("company", "same-as-section");

            /*var getCountLength = self.getCount(componentName);
            if (getCountLength <= maxCount) {
                this.enableAddButtons(componentName);
            }*/

            var containersArr = ["employer", "company", "finra-add-company-component"];

            $.each(containersArr, function (index, value) {
                var getCountLength = self.getCount(value);
                if (getCountLength <= maxCount) {
                    self.enableAddButtons(value);
                }
            });

            this.addDynamicLabels(componentName);
        },
        addDynamicLabels: function (componentName) {
            //Dynamically edit the label
            var containerId = (componentName == 'finra') ? "finra-add-company" : componentName;
            var componentTitle = (componentName == 'finra' || componentName == 'finra-add-company') ? "company" : componentName;

            $('#' + containerId + " .pt-empcomp").each(function (i) {
                i = ++i;
                if (i == 1) {
                    $(this).find(".dynamic-label").html(componentTitle).css('text-transform', 'capitalize');
                } else {
                    $(this).find(".dynamic-label").html(componentTitle + " " + i).css('text-transform', 'capitalize');
                }
            });
        },
        spliceIt: function (arr, refArrId) {
            $.each(arr, function (i, el) {
                if (this.id == refArrId) { //0-same-as-section-checkboxes
                    arr.splice(i, 1);
                }
            });
            return arr;
        },
        unCheckAllCheckBoxes: function (chkBoxSectionId) {
            $('input[name=' + chkBoxSectionId + ']')
                    .attr('checked', false)
                    .prop('disabled', false)
                    .closest('.radio-group-conatiner')
                    .removeClass('active');
        },
        uncheckAndDisableCheckBox: function (identifierId) {
            $('#' + identifierId)
                    .attr('checked', false)
                    .prop('disabled', true)
                    .closest('.radio-group-conatiner')
                    .removeClass('active');
        },
        renderCompanyCompView: function () {
            newCompanyComponentCount++;
            var compReferenceNm = self.companyComponentNm.toLowerCase(); //Employer - to - employer
            var mainCompReferenceId = $("#" + compReferenceNm); //$("#employer")
            var dynamicPlaceHolder = self.companyComponentNm + "-comp-" + newCompanyComponentCount;
            mainCompReferenceId.append("<div id='" + dynamicPlaceHolder + "'></div>");
            var compReferenceId = self.$("#" + dynamicPlaceHolder);

            var componentViewOptions = {
                "nestedViewName": "pt-temp-company-" + newCompanyComponentCount,
                "compConstrParams": { el: compReferenceId, componentName: self.companyComponentNm, componentId: newCompanyComponentCount },
                "compType": compReferenceNm
            }

            //Call common render of Employer Company Function
            this.renderEmpCompView(componentViewOptions, launchMode);
        },
        handleEventsOfSameAsSectionChkBox: function (selectedItems, itemId, launchMode) {
            var referenceId = parseInt(itemId), createdAddresviewName;
            for (var key in this.nestedViews) {
                if (key.indexOf("pt-temp") > -1) {
                    var nestedViewName = this.nestedViews[key];
                    if (nestedViewName.componentName == 'Employer' && Number(key.substr(-1)) == referenceId) {
                        var compData = new EmpCompModel().toJSON();
                        compData.EmpAddComUIRefId = itemId;
                        compData.relatedModelRefId = nestedViewName.employerCompanyInfo.id;
                        createdAddresviewName = self.handleAddingAnotherCompany($.extend(compData, _.omit(nestedViewName.employerCompanyInfo, ["relatedModelRefId", "id", "relSeqNbr"])), launchMode);
                    }
                }
            }
            return createdAddresviewName;
        },
        handleEventsOfWhichEmployerChkBox: function (selectedItems, itemId) {
            var referenceId = parseInt(itemId);
            for (var key in this.nestedViews) {
                if (key.indexOf("pt-temp") > -1) {
                    var nestedViewName = this.nestedViews[key];
                    if (nestedViewName.componentName == 'Employer' && Number(key.substr(-1)) == referenceId) {
                        self.handleAddingAnotherCompany(nestedViewName.employerCompanyInfo);
                    }
                }
            }
        },
        handleAddingAnotherEmployer: function (evt, compData, doNotRenderDynamicCheckBoxes) {
            var launchMode = 'edit',
                getCountLength = self.getCount('employer'),
                compReferenceNm = self.employerComponentNm.toLowerCase(),
                uiIndex = $("#employer").find(">div").length;

            if (getCountLength < maxCount) {
                $(self.$addAnotherEmployerBtn).removeClass('hidden');
            }
            if (getCountLength == maxCount || getCountLength >= maxCount) {
                $(self.$addAnotherEmployerBtn).addClass('hidden');
            }
            newEmployerComponentCount++;
            var componentViewOptions = {
                "nestedViewName": "pt-temp-employer-" + newEmployerComponentCount + "-" + uiIndex,
                "compConstrParams": {
                    el: self.$("#employer"),
                    componentId: newEmployerComponentCount,
                    componentName: 'Employer',
                    selectedAddrsType: '',
                    count: getCountLength + 1,
                    compData: compData ? compData : null
                },
                "compType": compReferenceNm
            };

            self.renderMultipleEmployerTemplate(componentViewOptions, $('#employer'), launchMode);
            if (!doNotRenderDynamicCheckBoxes) {
                //Show or Hide 'Which Employer' Section
                self.renderWhichEmployerSection("employer", "which-employer");

                //Show or Hide 'Which Employer' Section
                self.renderSameAsSection("company", "same-as-section");
            }
            this.updateEmployerComponentUIIndex();
            //Dynamically adjust the label counter
            this.addDynamicLabels("employer");
            self.checkForAddressMaxNumLimit(["employer", "company", "finra-add-company-component"]);
        },
        renderMultipleEmployerTemplate: function (componentRenderingOptions, $employercontainer, launchMode) {
            var self = this;
            var launchModeVal = (launchMode == '') ? 'view' : launchMode;
            var compNm = componentRenderingOptions.compConstrParams.componentName;
            var compId = componentRenderingOptions.compConstrParams.componentId;
            var compDataId = componentRenderingOptions.compConstrParams.compData ? componentRenderingOptions.compConstrParams.compData.compId : undefined
            var compDataNm = componentRenderingOptions.compConstrParams.compData ? componentRenderingOptions.compConstrParams.compData.compNm : undefined;
            var refId = componentRenderingOptions.compConstrParams.compData ? componentRenderingOptions.compConstrParams.compData.EmpAddComUIRefId : componentRenderingOptions.uiIndex;
            var dynamicPlaceHolder = compNm + "-comp-" + compId;
            if (compNm == 'Company' && compDataId != undefined) {
                $employercontainer.append("<div id='" + dynamicPlaceHolder + "' data-reference-name=" + compDataNm + " data-reference-id=" + refId + "></div>");
            } else {
                $employercontainer.append("<div id='" + dynamicPlaceHolder + "'></div>");
            }

            componentRenderingOptions.compConstrParams.el = self.$("#" + dynamicPlaceHolder);

            this.renderEmpCompView(componentRenderingOptions, launchModeVal);
        },
        handleFinraAddingAnotherCompany: function (compData, launchMode) {
            var launchModeVal = (launchMode == undefined) ? 'edit' : launchMode;
            var getCountLength = self.getCount('finra-add-company') + 1;
            var compReferenceNm = self.finraCompanyComponentNm.toLowerCase();
            var noOfCheckBoxesChecked = $('input[name=' + self.selectWhichEmployerCheckboxes + ']:checked').size();
            var countOfChkBoxesChkedAndNoOfContainersAdded = noOfCheckBoxesChecked + getCountLength;

            newFinraCompanyComponentCount++;
            var componentViewOptions = {
                "nestedViewName": "pt-temp-finra-" + newFinraCompanyComponentCount,
                "compConstrParams": {
                    el: self.$("#finra-add-company"),
                    componentId: newFinraCompanyComponentCount,
                    componentName: 'finra',
                    selectedAddrsType: '',
                    count: getCountLength,
                    componentNameAsFinra: 'finra',
                    compData: compData ? compData : null
                },
                "compType": compReferenceNm
            }

            self.renderMultipleEmployerTemplate(componentViewOptions, $('#finra-add-company'), launchModeVal);

            if (countOfChkBoxesChkedAndNoOfContainersAdded < 4) {
                self.$finraAddAnotherCompanyBtn.removeClass('hidden');
            } else if (countOfChkBoxesChkedAndNoOfContainersAdded >= 4) {
                self.$finraAddAnotherCompanyBtn.addClass('hidden');
                self.disableCheckboxes(self.selectWhichEmployerCheckboxes);
            }

            this.addDynamicLabels('finra-add-company');
            self.checkForAddressMaxNumLimit(["finra-add-company-component"]);
        },
        handleAddingAnotherCompBtnClick: function () {
            this.handleAddingAnotherCompany();
            self.checkForAddressMaxNumLimit(["company"]);
        },
        handleAddingAnotherCompany: function (compData, launchMode) {
            var launchModeVal = (launchMode == undefined) ? 'edit' : launchMode;
            var getCountLength = self.getCount('company') + 1;
            var compReferenceNm = self.companyComponentNm.toLowerCase();
            //var noOfCheckBoxesChecked = $('input[name=' + self.selectSameAsSectionCheckboxes + ']:checked').size();
            //var countOfChkBoxesChkedAndNoOfContainersAdded = noOfCheckBoxesChecked + getCountLength;

            newCompanyComponentCount++;

            var componentViewOptions = {
                "nestedViewName": "pt-temp-company-" + newCompanyComponentCount,
                "compConstrParams": {
                    el: self.$("#employer"),
                    componentId: newCompanyComponentCount,
                    componentName: 'Company',
                    selectedAddrsType: '',
                    count: getCountLength,
                    compData: compData ? compData : null
                },
                "compType": compReferenceNm
            }

            self.renderMultipleEmployerTemplate(componentViewOptions, $('#company'), launchModeVal);

            if (getCountLength < 4) {
                self.$addAnotherCompanyBtn.removeClass('hidden');
            } else if (getCountLength >= 4) {
                self.$addAnotherCompanyBtn.addClass('hidden');
                self.disableCheckboxes(self.selectSameAsSectionCheckboxes);
            }

            this.addDynamicLabels('company');
            return componentViewOptions.nestedViewName;
        },
        getCount: function (divId) {
            return $('#' + divId + ' .pt-empcomp:visible').length;
        },
        renderWhichEmployerSection: function (containerNm, sectionId, dataModel) {
            var isEmployed = $('.is-employed').filter('.active').val();
            var checkIsEmployedIsActive = (isEmployed != '' && isEmployed == 'Yes') ? true : false;
            var countOfContainers = self.getCount('employer');
            var sectionNmId = $("#" + sectionId); //#which-employer (or) #same-as-section
            var firstEmployerNmInput = $("#pt-" + self.employerComponentNm.toLowerCase() + "-name-1");
            var showSection = (countOfContainers > 0) ? true : false; //employer
            var showFinraAddCompanySection = (countOfContainers >= 0) ? true : false,
                showWhichEmployerChkbox = false;
            for (var key in self.nestedViews) {
                var view = self.nestedViews[key];
                if (key.indexOf("pt-temp-employer") > -1) {
                    if (view.isTheAddressValid()) {
                        showWhichEmployerChkbox = true;
                        break;
                    }
                }
            }

            if (checkIsEmployedIsActive) {
                if (firstEmployerNmInput != "" && showSection) {
                    if (showWhichEmployerChkbox) {
                        //Show the container first then render the template inside that
                        sectionNmId.removeClass('hidden');
                    } else {
                        sectionNmId.addClass('hidden');
                    }
                    self.renderIsEmployerCheckBox(containerNm, sectionId, dataModel);
                }
                if (showFinraAddCompanySection) {
                    //Show the container first then render the template inside that
                    $('#finra-add-company-component').removeClass('hidden');
                }
            } else {
                //Hide Finra Add Company
                $('#finra-add-company').empty(); //Clear off the content
                $('#finra-add-company-component').addClass('hidden'); //hide the parent container
                //Uncheck if anything is checked
                self.unCheckAllCheckBoxes(this.selectWhichEmployerCheckboxes);
                self.resetAllSelectedItems(this.employerDynamicCheckboxView);
                sectionNmId.addClass('hidden');
            }
        },
        renderSameAsSection: function (containerNm, sectionId, dataModel) {
            var isOfficer = $('.is-officer').filter('.active').val();
            var checkIsOfficerIsActive = (isOfficer != '' && isOfficer == 'Yes') ? true : false;
            var countOfContainers = self.getCount('employer');
            var sectionNmId = $("#" + sectionId); //#which-employer (or) #same-as-section
            var firstEmployerNmInput = $("#pt-" + self.employerComponentNm.toLowerCase() + "-name-1");
            var showSection = (countOfContainers > 0) ? true : false; //employer
            var showSameAsAddCompanySection = (countOfContainers >= 0) ? true : false;

            if (checkIsOfficerIsActive) {
                if (firstEmployerNmInput != "" && showSection) {
                    if (!sectionNmId.is(':Visible') && sectionNmId.hasClass('hidden')) {
                        //Show the container first then render the template inside that
                        sectionNmId.removeClass('hidden');
                    }
                    self.renderOfficerSameAsCheckBox(containerNm, sectionId, dataModel);
                }
                if (showSameAsAddCompanySection) {
                    //Show the container first then render the template inside that
                    $('#company-component').removeClass('hidden');
                }
            } else {
                //Hide Same As Add Company
                $('#company').empty(); //Clear off the content
                $('#company-component').addClass('hidden'); //hide the parent container
                self.unCheckAllCheckBoxes(this.selectSameAsSectionCheckboxes);
                self.resetAllSelectedItems(this.companyDynamicCheckboxView);
                sectionNmId.addClass('hidden');
            }
        },
        reRenderDynamicChkboxSectionOnEmpAddressChange: function (employerAddressView, relatedModelRefId) {
            var dynamicCheckboxViews = [this.getNestedView("employerDynamicCheckboxView"), this.getNestedView("companyDynamicCheckboxView")];
            try {
                _.each(dynamicCheckboxViews, function (dynamicCheckboxView) {
                    var checkboxItemCorspndngToEmpAddrsView,
                    slectedItems,
                    allItems,
                    isThisEmpAddrsChecked = false;
                    if (dynamicCheckboxView && dynamicCheckboxView.allItems && dynamicCheckboxView.allItems[index]) {
                        allItems = dynamicCheckboxView.allItems;
                        checkboxItemCorspndngToEmpAddrsView = allItems[index];
                        slectedItems = dynamicCheckboxView.allSelectedItems;
                        isThisEmpAddrsChecked = !!_.find(slectedItems, function (item) {
                            return item.id == checkboxItemCorspndngToEmpAddrsView.id;
                        });
                    }
                    if (isThisEmpAddrsChecked) {
                        var itemIndex,
                            selectedItem;
                        slectedItems = _.filter(dynamicCheckboxView.allSelectedItems, function (item) {
                            return item.id != checkboxItemCorspndngToEmpAddrsView.id;
                        });
                        itemIndex = Number(checkboxItemCorspndngToEmpAddrsView.id.charAt(0));
                        dynamicCheckboxView.selectedItems = slectedItems;
                        dynamicCheckboxView.allSelectedItems = slectedItems;
                        selectedItem = dynamicCheckboxView.items[itemIndex];
                        dynamicCheckboxView.reRender();
                        //manually call the on change event
                        dynamicCheckboxView.itemSelectionComplete(slectedItems, itemIndex, selectedItem);
                    }
                });
            } catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
            this.renderWhichEmployerSection("employer", "which-employer");
            this.renderSameAsSection("company", "same-as-section");

        },
        resetAllSelectedItems: function (dynamicCheckboxView) {
            var getNestedCheckBoxView = this.getNestedView(dynamicCheckboxView);
            if (getNestedCheckBoxView != undefined) {
                getNestedCheckBoxView.allSelectedItems = [];
                getNestedCheckBoxView.selectedIndexes = [];
                getNestedCheckBoxView.selectedItems = [];
            }
        },
        getComponentIdForEmpCheckBoxes: function (chckBoxType) {
            return (chckBoxType == "which-employer") ? "which-employer-checkboxes" : "same-as-section-checkboxes";
        },
        getValidEmployerOptions: function (chckBoxType) {
            var nestedViews = this.nestedViews,
                isEmployer = (chckBoxType == "which-employer") ? true : false,
                componentId = this.getComponentIdForEmpCheckBoxes(chckBoxType),
                employerCheckBoxOptions = [],
                view,
                employerName,
                checkBoxUiIndex = 0,
                relatedEmployerModel,
                companyModel = new EmpCompModel().toJSON();
            for (var key in nestedViews) {
                view = nestedViews[key];
                if (key.indexOf("pt-temp-employer") > -1) {
                    relatedEmployerModel = view.employerCompanyInfo;
                    companyModel = $.extend(companyModel, _.omit(relatedEmployerModel, ["relatedModelRefId", "id", "relSeqNbr"]));
                    companyModel.relatedModelRefId = relatedEmployerModel.id;
                    if (view.isTheAddressValid()) {
                        employerName = view.employerCompanyInfo.employerName;
                        employerCheckBoxOptions.push({
                            description: isEmployer ? employerName : "Same as " + employerName,
                            id: checkBoxUiIndex + "-" + componentId,
                            empRefId: Number($(view.el).find(".pt-empcomp").attr("ui-index")),
                            relatedModelRefId: companyModel.relatedModelRefId,
                            modelId: companyModel.id
                        });
                        checkBoxUiIndex++;
                    }
                }
            }
            return employerCheckBoxOptions;
        },
        getSelectedItemsFromViewForEmpCheckboxes: function (viewName, items) {
            var view = this.getNestedView(viewName),
                selectedItems = [];
            if (view) {
                selectedItems = view.allSelectedItems;
            } else {
                if (viewName == this.employerDynamicCheckboxView) {
                    selectedItems = this.getSelectedItemsForWhichEmplChkboxFromModel();
                } else {
                    selectedItems = this.getSelectedItemsForIsOffcSameAsChkboxFromModel();
                }
            }
            for (var i = 0; i < items.length; i++) {
                for (var k = 0; k < selectedItems.length; k++) {
                    if (items[i].relatedModelRefId === selectedItems[k].relatedModelRefId) {
                        selectedItems[k] = items[i];
                    }
                }
            }
            return selectedItems;
        },
        getSelectedItemsForWhichEmplChkboxFromModel: function () {
            var selectedItems = [],
                finraSectionInfo = _.find(this.model.get('items'), function (item) {
                    return item.get("itemType") == "finraSectionArr";
                });
            if (finraSectionInfo != undefined && finraSectionInfo.get("changedItemValue")) {
                selectedItems = finraSectionInfo.get("changedItemValue");
            }
            return selectedItems;
        },
        getSelectedItemsForIsOffcSameAsChkboxFromModel: function () {
            var selectedItems = [],
                shareHolderInfo = _.find(this.model.get('items'), function (item) {
                    return item.get("itemType") == "sameAsCompanyArr";
                });
            if (shareHolderInfo != undefined && shareHolderInfo.get("changedItemValue")) {
                selectedItems = shareHolderInfo.get("changedItemValue");
            }
            return selectedItems;
        },
        isOfficerSameAsCheckboxChangeHandler: function (selectedItems, itemId, changedItem) {
            var launchMode = 'view',
                count = 0,
                mappedAddressViewName,
                selectedItem,
                containerNm = self.getComponentIdForEmpCheckBoxes("is-officer");//"same-as-section-checkboxes"
            selectedItem = _.filter(selectedItems, function (item) {
                return item.id == (itemId + "-" + containerNm)
            });
            count = self.getCount(containerNm);
            if (selectedItem.length > 0 && count < 4) {
                mappedAddressViewName = self.handleEventsOfSameAsSectionChkBox(selectedItems, changedItem.empRefId, launchMode);
                self.isOfficerCheckboxToCompViewMapping[changedItem.empRefId] = mappedAddressViewName;
                self.addDynamicLabels(containerNm);
                count = self.getCount(containerNm);
                if (count == 4) {
                    $(this.getNestedView(this.companyDynamicCheckboxView).el)
                        .find("input:not(:checked)")
                        .attr('checked', false)
                        .prop('disabled', true);
                }
            } else {
                var correspondingCompAddressView = self.isOfficerCheckboxToCompViewMapping[changedItem.empRefId];
                if (!!correspondingCompAddressView) {
                    self.getNestedView(correspondingCompAddressView).$el.remove();
                    self.removeNestedView(correspondingCompAddressView); //pt-temp-company-1
                    self.enableCheckboxes(self.selectSameAsSectionCheckboxes); //Enable checkbox if it is in disable mode
                    self.addDynamicLabels(containerNm);
                }
                count = self.getCount(containerNm);
                if (count < 4) {
                    self.enableAddButtons(containerNm);
                }
            }
            self.checkForAddressMaxNumLimit(["company"]);
        },
        whichEmployerCheckboxChangeHandler: function (selectedItems, itemId, changedItem) {
            var containerNm = self.getComponentIdForEmpCheckBoxes("which-employer"),
                selectedItem = _.filter(selectedItems, function (item) {
                    return item.id == (itemId + "-" + containerNm)
                });
            self.enableCheckboxes(self.selectWhichEmployerCheckboxes);

            whichEmployerCount = self.getCount("finra-add-company");
            sumOfWhichEmployerAndAddFinraCount = selectedItems.length + whichEmployerCount;

            if (sumOfWhichEmployerAndAddFinraCount == 4) {
                self.disableCheckboxes(self.selectWhichEmployerCheckboxes);
                self.$finraAddAnotherCompanyBtn.addClass('hidden');
            } else {
                whichEmployerCount = self.getCount("finra-add-company");
                sumOfWhichEmployerAndAddFinraCount = selectedItems.length + whichEmployerCount;
                if (sumOfWhichEmployerAndAddFinraCount < 4) {
                    self.$finraAddAnotherCompanyBtn.removeClass('hidden');
                }
            }
            self.checkForAddressMaxNumLimit(["finra-add-company-component"]);
        },
        renderOfficerSameAsCheckBox: function (dataModel) {
            var chckOptions = this.getValidEmployerOptions("is-officer"),
                renderingOptions = {
                    viewName: this.companyDynamicCheckboxView,
                    items: chckOptions,
                    elId: this.getComponentIdForEmpCheckBoxes("is-officer"),
                    selectedItems: this.getSelectedItemsFromViewForEmpCheckboxes(this.companyDynamicCheckboxView, chckOptions),
                    selectionChangeCallback: this.isOfficerSameAsCheckboxChangeHandler
                };
            this.renderCheckBoxView(renderingOptions);
            $('#which-employer-checkboxes input').removeClass('needed required-group');
            //After render, append data-identifier attribute to Same As checkboxes
            $.each(chckOptions, function (i, item) {
                $("#same-as-section-checkboxes input[pt-checkbox-button]:eq(" + i + ")").attr("data-identifier", chckOptions[i].empRefId);
            });
        },
        renderIsEmployerCheckBox: function () {
            var items = this.getValidEmployerOptions("which-employer"),
                renderingOptions = {
                    viewName: this.employerDynamicCheckboxView,
                    items: items,
                    elId: this.getComponentIdForEmpCheckBoxes("which-employer"),
                    selectedItems: this.getSelectedItemsFromViewForEmpCheckboxes(this.employerDynamicCheckboxView, items),
                    selectionChangeCallback: this.whichEmployerCheckboxChangeHandler
                };
            this.renderCheckBoxView(renderingOptions);
            $('#which-employer-checkboxes input').removeClass('needed required-group');
            if (items.length == 0) {
                self.resetSections("which-employer");
            }
        },
        renderCheckBoxView: function (params /*viewName, items, elId, selectedItems, selectionChangeCallback, triggerOnPreselction-optional */) {
            var checkboxView = new CheckBoxView({
                el: $('#' + params.elId),
                items: params.items
            });
            checkboxView.selectedItems = params.selectedItems;
            checkboxView.itemSelectionComplete = params.selectionChangeCallback /*selectedItems, itemId, changedItem*/;
            this.addNestedView(params.viewName, checkboxView);
            checkboxView.render();
        },
        disableCheckboxes: function (chkBoxName) {
            $("input:checkbox[name=" + chkBoxName + "]").each(function () {
                if (!$(this).prop('checked')) {
                    $(this).prop('disabled', true)
                           .closest('.radio-group-conatiner')
                           .removeClass('active');
                }
            })
        },
        enableCheckboxes: function (chkBoxName) {
            $("input:checkbox[name=" + chkBoxName + "]").each(function () {
                if ($(this).prop('disabled')) {
                    $(this).prop('disabled', false)
                           .closest('.radio-group-conatiner')
                           .removeClass('active');
                }
            });
        },
        enableAddButtons: function (containerNm) {
            if (containerNm == 'employer') {
                self.$addAnotherEmployerBtn.removeClass('hidden'); // Show 'Add another employer' btn
            } else if (containerNm == 'company') {
                self.$addAnotherCompanyBtn.removeClass('hidden'); // Show 'Add another company' btn
            } else {
                self.$finraAddAnotherCompanyBtn.removeClass('hidden'); // Show 'Add another company' finra btn
            }
        },
        disableAddAnotherButton: function (sectionType) {
            switch (sectionType) {
                case "employer":
                    self.$addAnotherEmployerBtn.addClass('hidden'); // Show 'Add another employer' btn
                    break;
                case "company":
                    self.$addAnotherCompanyBtn.addClass('hidden'); // Show 'Add another company' btn
                    break;
                case "finra-add-company-component":
                    self.$finraAddAnotherCompanyBtn.addClass('hidden'); // Show 'Add another company' finra btn
                    break;
                default:
                    break;
            }
        },
        checkForAddressMaxNumLimit: function (sectionTypes /*employer, company, finra-add-company-component*/) {
            var maxAddrssCount = 4;
            _.each(sectionTypes, function (sectionType) {
                var addrsCompCount = self.getCount(sectionType),
                enableDisableChkbox = false,
                chkboxNm,
                sectionEnabled = false;
                switch (sectionType) {
                    case "employer":
                        sectionEnabled = true;
                        break;
                    case "company":
                        sectionEnabled = self.$shareHolderContainer.is(":visible");
                        enableDisableChkbox = true;
                        chkboxNm = self.selectSameAsSectionCheckboxes;
                        break;
                    case "finra-add-company-component":
                        sectionEnabled = self.$finraContainer.is(":visible");
                        addrsCompCount += $('input[name=' + self.selectWhichEmployerCheckboxes + ']:checked').length;
                        enableDisableChkbox = true;
                        chkboxNm = self.selectWhichEmployerCheckboxes;
                        break;
                    default:
                        break;
                }
                if (sectionEnabled) {
                    if (addrsCompCount < maxAddrssCount) {
                        self.enableAddButtons(sectionType);
                        if (enableDisableChkbox) {
                            self.enableCheckboxes(chkboxNm);
                        }
                    } else {
                        self.disableAddAnotherButton(sectionType);
                        if (enableDisableChkbox) {
                            self.disableCheckboxes(chkboxNm);
                        }
                    }
                }
            });

        },
        //"Is client employed.." button [YES/NO] button toggle
        toggleEmployed: function (obj) {
            var _$clickedButton = $(obj.currentTarget),
					        $finarComponent = $('#finra-add-company-component');
            var _btnTxt = _$clickedButton.text();
            var isOfferToggleButton = $('.is-officer').filter('.active').text();
            if (isOfferToggleButton == 'Yes') { ofcBtn = 'Y'; } else { ofcBtn = 'N'; }

            $('.is-employed').removeClass('active');
            _$clickedButton.addClass('active');
            if (_btnTxt == 'Yes') { empBtn = 'Y'; } else { empBtn = 'N'; }
            if (_btnTxt === 'Yes' && empBtn === 'Y') {
                $('#ce-not-employed').hide().removeClass('active');
                $('#not-employed').attr('checked', false);
                //hide retired. hide other.
                $('#ce-retired').hide().removeClass('active');
                $('#retired').attr('checked', false);
                $('#ce-other').hide().removeClass('active');
                $('#other').attr('checked', false);

                //Reset the counter
                newFinraCompanyComponentCount = 0;

                //If Add button is hidden, make it visible
                if (self.$finraAddAnotherCompanyBtn.hasClass('hidden') && self.isEmployedOrSelfEmployedChecked()) {
                    self.$finraAddAnotherCompanyBtn.removeClass('hidden');
                }
                //Show or Hide 'Which Employer' Section
                if (self.isEmployedOrSelfEmployedChecked()) {
                    self.renderWhichEmployerSection("finra-add-company", "which-employer");
                }
            }
            else //when "client employed" is "no"
            {
                //show when switch back to no
                $('#ce-not-employed, #ce-retired, #ce-other').show();
                if (!(isOfferToggleButton === 'Yes' && ofcBtn === 'Y')) {
                    $('.is-employed-alert').addClass('clientofficer-status-hide');
                }
            }

            if (_btnTxt === 'Yes') {
                $finarComponent.removeClass('hidden');
                $('.is-employed-alert').removeClass('clientofficer-status-hide');
            } else {
                $('.is-employed-alert').addClass('clientofficer-status-hide');
                $finarComponent.addClass('hidden');
                self.clearWhichEmployerRelatedViewsAndData();
            }
        },
        //"Is the client an officer.." [YES/No] button
        toggleOfficer: function (obj) {
            var _$clickedButton = $(obj.currentTarget);
            var companyComponentId = $("#company-component");

            if (_$clickedButton.hasClass('active')) {
                return false;
            } else {
                var _btnOfcTxt = _$clickedButton.text();
                var isEmployedToggleButton = $('.is-employed').filter('.active').text();
                if (isEmployedToggleButton == 'Yes') { empBtn = 'Y'; } else { empBtn = 'N'; }
                $('.is-officer').removeClass('active');
                _$clickedButton.addClass('active');
                if (_btnOfcTxt == 'Yes') { ofcBtn = 'Y'; } else { ofcBtn = 'N'; }
                if (_btnOfcTxt === 'Yes' && ofcBtn === 'Y') {
                    companyComponentId.removeClass('hidden');
                    //Reset the counter
                    newCompanyComponentCount = 0;
                    self.$addAnotherCompanyContainer.removeClass('hidden');
                    self.renderSameAsSection("company", "same-as-section");

                } else {
                    ////show when switch back to no
                    if (isEmployedToggleButton === 'Yes' && empBtn === 'Y') {
                        $('#ce-not-employed, #ce-retired, #ce-other').hide();
                    } else {
                        $('#ce-not-employed, #ce-retired, #ce-other').show();
                    }
                    if (companyComponentId.is(':Visible') && !companyComponentId.hasClass('hidden')) {
                        //Show the container first then render the template inside that
                        companyComponentId.addClass('hidden');
                    }
                    self.clearIsOfficerRelatedViewsAndData();
                }
            }
        },
        isEmployedOrSelfEmployedChecked: function () {
            //Check if Employed and Self Employed are checked or not
            var isEmployedChecked = $('input[name="empStatus"]#employed').prop('checked');
            var isSelfEmployedChecked = $('input[name="empStatus"]#self-employed').prop('checked');
            return (isEmployedChecked || isSelfEmployedChecked);
        },
        isNotEmployedChecked: function () {
            return $('#not-employed').prop('checked');
        },
        captureData: function () {
            var $employmentStatus = $("input[name='empStatus']:checked"),
                empStatus = $employmentStatus.attr("data-value"),
                $industryClassfctnSel = $("#pt-emp-select-industry"),
                $industryClassOtherText = $("#pt-emp-industry-other-input"),
                indstryClassFtcn
                
            var employmentDetails = {
                jobTitle: "",
                isEmployed: $("button[name='is-employed'].active").attr("value"),
                isShareHolder: $("button[name='is-officer'].active").attr("value"),
                empStatus: _.find(Constants.employmentStatusOptions, function (option) {
                    return empStatus == option.serviceVal;
                }),
                industryClassification:{},
                employmentAddrsColl: [],
                finraAddrsColl: [],
                shareHolderAddrsColl: [],
                finraCheckbox: {},
                shareHolderCheckbox: {},
                primaryOccupation : {},
                prmroccufreeText:""
            };
            if (empStatus == "B" /*self employed*/) {
                indstryClassFtcn = $industryClassfctnSel.val();
                employmentDetails.industryClassification.indsClsCd = indstryClassFtcn;
                employmentDetails.industryClassification.indsClsDesc = $industryClassfctnSel.find('option:selected').text();
                if (indstryClassFtcn == "IC031") {
                    employmentDetails.industryClassification.indsClsTxt = $industryClassOtherText.val();
                }
            }
            
            for (var key in this.nestedViews) {
                if (key.indexOf("pt-temp") > -1) {
                    var nestedViewName = this.nestedViews[key];
                    switch (nestedViewName.componentName) {
                        case 'Employer':
                            employmentDetails.employmentAddrsColl.push(nestedViewName.employerCompanyInfo);
                            break;
                        case 'finra':
                            employmentDetails.finraAddrsColl.push(nestedViewName.employerCompanyInfo);
                            break;
                        case 'Company':
                            employmentDetails.shareHolderAddrsColl.push(nestedViewName.employerCompanyInfo);
                            break;
                        default: break;
                    }
                }

                if (key.indexOf("employerDynamicCheckboxView") > -1) {
                    employmentDetails.finraCheckbox["finraCheck"] = true;
                    var selectedItemArr = this.nestedViews[key].allSelectedItems;
                    employmentDetails.finraCheckbox["finraSectionArr"] = selectedItemArr;
                    _.each(selectedItemArr, function (list) {
                        var index = parseInt(list.id);
                        var cloneEmpData = employmentDetails.employmentAddrsColl[index],
                            refId = cloneEmpData.id,
                            finraDat = $.extend({}, _.omit(cloneEmpData, ["relatedModelRefId", "id", "relSeqNbr"]));
                        finraDat.relatedModelRefId = refId;
                        finraDat.doNotDisplay = true;
                        employmentDetails.finraAddrsColl.push(finraDat);
                    });
                }

                if (key.indexOf("companyDynamicCheckboxView") > -1) {
                    employmentDetails.shareHolderCheckbox["sameAsCompanyCheck"] = true;
                    var selectedItemArr = this.nestedViews[key].allSelectedItems
                    employmentDetails.shareHolderCheckbox["sameAsCompanyArr"] = selectedItemArr;
                }
            }
            if (empStatus == "A" || empStatus == "B") {
                employmentDetails.primaryOccupation.code = employmentDetails.employmentAddrsColl[0].primaryOccupation;
                employmentDetails.primaryOccupation.desc = _.find(Constants.employerPriOccupationList, function (prmOccu) {
                    return prmOccu.code == employmentDetails.primaryOccupation.code;
                }).name;
                if (employmentDetails.primaryOccupation.code == "Other") {
                    employmentDetails.prmroccufreeText = employmentDetails.employmentAddrsColl[0].priOccupationOther;
                }
                employmentDetails.jobTitle = employmentDetails.employmentAddrsColl[0].jobTitle;
            }
            return employmentDetails;
        },
        customModelValidation: function () {
            var isFIRAValid = true,
                isShareHolderValid = true;
            if (this.model.get("isEmployed") == "Yes") {
                if (FINRAData.length == 0) {
                    isFIRAValid = false;
                }
            }
            if (this.model.get("isClientODSP") == "Yes") {
                if (shareHolderData.length == 0) {
                    isShareHolderValid = false;
                }
            }
            return isShareHolderValid && isFIRAValid;
        },
        handleBlurEvntOnEmployerName: function () {
            var getCountOfEmployers = self.getCount('employer');
            if (getCountOfEmployers >= 1) {
                self.renderWhichEmployerSection("employer", "which-employer");
                self.renderSameAsSection("company", "same-as-section");
            } else {
                //Reset Sections
                //this.resetSections("company-component", "company");
                this.resetSections("which-employer");
                this.resetSections("same-as-section");
                //this.resetSections("finra-add-company-component");

                //Reset Buttons
                //this.resetButtons("is-employed");
                //this.resetButtons("is-officer");
            }
        },
        resetButtons: function ($elId) {
            var $ToggleBtn = $("div[data-for=" + $elId + "] button.toggle-button");
            if ($ToggleBtn.hasClass('active')) {
                $ToggleBtn.removeClass('active');
            }

            if ($elId == 'is-employed') {
                $('.is-employed-alert').addClass('clientofficer-status-hide');
            }

        },
        clearSameAsAndWhichEmployerCheckBoxViews: function (clearFinraViews) {
            var nestedViews = this.nestedViews,
                nestedViewNames;
            for (key in nestedViews) {
                if (key.indexOf("pt-temp-employer") > -1) {
                    this.removeNestedView(key);
                }
            }
            for (key in nestedViews) {
                if (key.indexOf("pt-temp-company") > -1 && nestedViews[key].launchMode == "view") {
                    nestedViews[key].$el.find('.cancel-the-section-btn').click();
                    //nestedViews[key].removeFromDom();
                }
            }
            for (key in nestedViews) {
                if (key.indexOf("pt-temp-company") > -1 && nestedViews[key].launchMode == "view" || clearFinraViews && key.indexOf("pt-temp-finra") > -1) {
                    this.removeNestedView(key);
                }
            }

            var sameAsCheckboxView = this.getNestedView(this.companyDynamicCheckboxView),
                whichEmployerChkboxView = this.getNestedView(this.employerDynamicCheckboxView);
            if (sameAsCheckboxView) {
                this.removeNestedView(this.companyDynamicCheckboxView);
            }
            if (whichEmployerChkboxView) {
                this.removeNestedView(this.employerDynamicCheckboxView);
            }
        },
        clearIsOfficerRelatedViewsAndData: function () {
            //Crosscheck this when working on model
            /*var nestedViews = this.nestedViews,
                sameAsCheckboxView,
                empModel = ClientModel.get("employement");*/
            var nestedViews = this.nestedViews, sameAsCheckboxView;
            for (key in nestedViews) {
                if (key.indexOf("pt-temp-company") > -1) {
                    nestedViews[key].$el.find('.cancel-the-section-btn').click();
                }
            }
            for (key in nestedViews) {
                if (key.indexOf("pt-temp-company") > -1) {
                    this.removeNestedView(key);
                }
            }
            sameAsCheckboxView = this.getNestedView(this.companyDynamicCheckboxView);
            if (sameAsCheckboxView) {
                this.removeNestedView(this.companyDynamicCheckboxView);
            }
            this.resetSections("company-component", "company");
            //clear is officer related model
            //Crosscheck this when working on model
            /*empModel.set('shareHolderAddrCollection', undefined);
            empModel.set('shareHolderCheckbox', undefined);*/
        },
        clearWhichEmployerRelatedViewsAndData: function () {
            //Crosscheck this when working on model
            /*var nestedViews = this.nestedViews,
                whichEmployerChkboxView,
                empModel = ClientModel.get("employement");*/

            var nestedViews = this.nestedViews, whichEmployerChkboxView;

            for (key in nestedViews) {
                if (key.indexOf("pt-temp-finra") > -1) {
                    nestedViews[key].$el.find('.cancel-the-section-btn').click();
                    this.removeNestedView(key);
                }
            }
            whichEmployerChkboxView = this.getNestedView(this.employerDynamicCheckboxView);
            if (whichEmployerChkboxView) {
                this.removeNestedView(this.employerDynamicCheckboxView);
            }
            this.resetSections("finra-add-company-component", "company");
            this.resetSections("which-employer");
            //clear is which employer related model
            //Crosscheck this when working on model
            /*empModel.set('FINRAAddrCollection', undefined);
            empModel.set('finraCheckbox', undefined);*/
        },
        resetSections: function (hideSection, clearElements) {
            var $hideSectionDiv = $("#" + hideSection);
            var $emptyInsideContent = $("#" + clearElements);

            if (!$hideSectionDiv.hasClass('hidden')) {
                if (clearElements != '' || clearElements != undefined) {
                    $emptyInsideContent.empty();
                }
                $hideSectionDiv.addClass('hidden');
            }
        },
        handlerForCancel: function () {
            BootstrapDialog
                    .confirm(
                            "Cancel",
                            "All your work will be lost.  Are you sure you want to cancel?",
                        function (confirm) {
                            if (confirm) {
                                window.open('', '_self');
                                window.close();
                            }
                        });

        },

        /* Till Here */


        updateEmployerComponentUIIndex: function () {
            this.$empComponentContainer.find(".pt-empcomp").each(function (i) {
                $(this).attr("ui-index", i);
            });
        }, /*
		        toggleOfficer: function (obj) {
		            var _$clickedButton = $(obj.currentTarget);
		            if (_$clickedButton.hasClass('active')) {
		                return false;
		            } else {
		                $('.is-officer').removeClass('active');
		                _$clickedButton.addClass('active');
		            }
		        },*/
        loadEmploymentStateList: function (selectedValue) {
            var _stateList = DropdownListData.USStateslist;
            var _selectbox = "#income-state-list-select";
            //  Utils.loadSelectbox(_selectbox, _stateList, selectedValue);
            var _options = {
                selectBox: _selectbox,
                optionsList: _stateList,
                selectedVal: selectedValue,
                noEmptyOption: false,
                isOptional: false,
                noneOption: {
                    value: "",
                    label: "None"
                }
            }
            Utils.loadSelectbox(_options);
        },
        loadEmploymentCntryList: function (selectedValue) {
            var _stateList = DropdownListData.employerCountryList;
            var _selectbox = "#country-list-select";
            //  Utils.loadSelectbox(_selectbox, _stateList, selectedValue);
            var _options = {
                selectBox: _selectbox,
                optionsList: _stateList,
                selectedVal: selectedValue,
                noEmptyOption: false,
                isOptional: false
            }
            Utils.loadSelectbox(_options);
        },
        toggleRadioClassActive: function (event) {
            var _radio = $(event.target);
            var _radioHolder = _radio.parents('div.radio-grp-holder');
            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
            _radio.parents('div.radio-group-conatiner').addClass('active');
        },
        numValidator: function (obj) {
            var _regxNumOnly = /^\d*$/;
            var _str = String.fromCharCode(event.keyCode);
            if (!_regxNumOnly.test(_str)) {
                obj.stopPropagation();
                if (event.preventDefault)
                    event.preventDefault();
                return false;
            }
        },
        validateAndNavigateFromStep1: function () {
            $("div[ampf-checkbox-buttons]").find("input[type='checkbox']").removeClass("needed required-group");
            if (Validator.validateInputs('gpm-update-form', true)) {
                var employmentDetails = this.captureData();
                if (!this.doCustomValidations(employmentDetails)) {
                    this.model.setChangedValue({ employmentDetails: employmentDetails });
                    
                    //if (this.model.getChangedItems().length > 0) {
                        $('.gpm-step.step1').addClass("finished").removeClass("active");
                        $('.gpm-step.step2').addClass("active");
                        Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                    //} else {
                    //    Utils.showNoChangesMessageToUser();
                    //}
                }
                
		    }
		},
        toggleNotEmployed: function (event) {
            var targetId = event.target.id;
            var $yellowAlertMsg = $('#notemployedInfo');
            if (targetId == 'not-employed' || targetId == 'retired' || targetId == 'other') {
                $yellowAlertMsg.removeClass('hidden');
            } else {
                $yellowAlertMsg.addClass('hidden');
            }
        },
        handleIndustryClassificationFields: function (el) {
            var empStatusEleId = el.currentTarget.id;
            if (empStatusEleId == "self-employed") {
                $('#emp-industry-classification').removeClass('hidden');
                CommonUtility.loadSelectbox(["#pt-emp-select-industry"], Constants.industryClassifications);
            } else {
                $('#emp-industry-classification, #pt-emp-industry-other').addClass('hidden');
            }
        },
        handleEmpIndustryOptions: function () {
            var selectedOption = $('#pt-emp-select-industry :selected').text();
            if (selectedOption == "Other") {
                $('#pt-emp-industry-other').removeClass('hidden');
                $('#pt-emp-industry-other-input').val("");
            } else {
                $('#pt-emp-industry-other').addClass('hidden');
            }
        },
        getGPMData: function (CPData) {
            var employmentInfo, ebixData = {}, isNotInCM = false,
                riskProfile, categorizedAddress, self = this,
                empStatus,
                finraCheckbox = {},
                shareHolderCheckbox = {};
            if (CPData.cola) {
                employmentInfo = CPData.cola.clientPersonal.attributes.employmentInfo.attributes;
                riskProfile = CPData.cola.riskProfile; riskProfile
            }
            empStatus = _.find(Constants.employmentStatusOptions, function (empStatOptn) {
                return employmentInfo.emplStatCd.toLowerCase() == empStatOptn.value.toLowerCase();
            });
            if (CPData.ebix) {
                ebixData = CPData.ebix.PersonContact.attributes;
            } else {
                isNotInCM = true;
            }
            categorizedAddress = this.ctaegorizeAddress(employmentInfo.companies);
            
            _.each(categorizedAddress.employerAddrrsColl, function (employerAddrs, i) {
                categorizedAddress.employerAddrrsColl[i] = employerAddrs.toJSON();
            });
            _.each(categorizedAddress.finraAddrsColl, function (finraAddrs, j) {
                categorizedAddress.finraAddrsColl[j] = finraAddrs.toJSON();
            }); 
            _.each(categorizedAddress.isOfficerAddrsCll, function (isOfficerAddr, k) {
                categorizedAddress.isOfficerAddrsCll[k] = isOfficerAddr.toJSON();
            });
            var primaryOccupation;
            if (employmentInfo.occpDescTxt) {
                primaryOccupation = _.find(Constants.employerPriOccupationList, function (prmOccu) {
                    return prmOccu.code == employmentInfo.occpDescTxt;
                });
                if (!primaryOccupation) {
                    primaryOccupation = {
                        code: "Other",
                        desc: "Other"
                    }
                }
                if (categorizedAddress.employerAddrrsColl[0]) {
                    categorizedAddress.employerAddrrsColl[0].primaryOccupation = primaryOccupation.code;
                    categorizedAddress.employerAddrrsColl[0].priOccupationOther = employmentInfo.occpDescTxt;
                }
            } else {
                primaryOccupation =  {
                        code: "",
                        desc: ""
                }
            }
            if (!isNotInCM && categorizedAddress.employerAddrrsColl[0] &&  ebixData.clJobTitle) {
                categorizedAddress.employerAddrrsColl[0].jobTitle = ebixData.clJobTitle;
            }
            var fieldsInfo = {
                primaryOccupation: primaryOccupation,
                occpDescTxt: employmentInfo.occpDescTxt,
                finInstnEmplCd: employmentInfo.finInstnEmplCd,
                empStatus: empStatus,
                ownrOfcrCd: employmentInfo.ownrOfcrCd,
                indsClsCd: riskProfile.indsClsCd,
                indsClsDesc: riskProfile.indsClsDesc,
                indsClsTxt: riskProfile.indsClsTxt,
                clJobTitle: (!isNotInCM && ebixData.clJobTitle) ? ebixData.clJobTitle : "",
                isNotInCM: isNotInCM,
                employerAddrrsColl: categorizedAddress.employerAddrrsColl,
                finraAddrsColl: categorizedAddress.finraAddrsColl,
                isOfficerAddrsCll: categorizedAddress.isOfficerAddrsCll,
                finraCheckbox: finraCheckbox,
                shareHolderCheckbox: shareHolderCheckbox
            };
            return fieldsInfo;
        },
        createCheckBoxOption: function (option) {
            var dynamiCchkboxOption = {
                "description": option.description,
                "id": option.empRefId + "-" + option.checkBoxType + "-" + "checkboxes",
                "empRefId": 0,
                "relatedModelRefId": option.relatedModelId,
                "modelId": option.modelId
            };
        },
        getItemFromDropdownList: function (listItems, code) {
            var listObj;
            listObj = _.find(listItems, function (listItem) {
                return listItem.code == code;
            });
            if (!listObj) {
                listObj = {
                    "name": "",
                    "code":""
                }
            }
            return listObj;
        },
        convertIntoEmpCompModel: function (empAddress, primaryOccupation, jobTitle) {
            var emprCntryCd = (empAddress.cntryNm != "" && empAddress.cntryNm != null) ? empAddress.cntryNm : "US",
                addressType,
                empAddressModel = new EmpCompModel(),
                stateOption,
                provinceOption,
                countryOption;
            empAddress.cntryNm = empAddress.cntryNm.trim();
            emprCntryCd = emprCntryCd == "USA" ? "US" : emprCntryCd;
            emprCntryCd = (emprCntryCd != "Unknown" && emprCntryCd != "Untranslatable") ? emprCntryCd : "US";
            addressType = emprCntryCd == "US" ? "U.S" : "Foreign";
            countryOption = this.getItemFromDropdownList(DropdownListData.countryList, emprCntryCd);
            stateOption = this.getItemFromDropdownList(DropdownListData.USStateslist, empAddress.stCd);
            provinceOption = this.getItemFromDropdownList(DropdownListData.canadaStateslist, empAddress.stCd);
            if (addressType == "U.S") {

            }
            var addressDetails = {
                employerName: empAddress.coNm,
                addressType: addressType,
                address1: empAddress.addrLn1Txt,
                address2: empAddress.addrLn2Txt,
                countryNm: countryOption.code,
                countryFullNm: countryOption.name,
                city: empAddress.cityNm,
                state: addressType == "U.S" ? stateOption.code : "",
                stateFullNm: addressType == "U.S" ? stateOption.name : "",
                province: addressType != "U.S" ? provinceOption.code : "",
                provinceFullNm: addressType != "U.S" ? provinceOption.name : "",
                zipCode: empAddress.postlCd,
                primaryOccupation: primaryOccupation ? primaryOccupation.code: "",
                priOccupationOther: primaryOccupation ? primaryOccupation.otherDesc: "",
                jobTitle: jobTitle,
                tickerSymbol: empAddress.relTypCd == "B" ? empAddress.symbol : "",
                relSeqNbr: empAddress.relSeqNbr
            };
            empAddressModel.set(addressDetails);
            return empAddressModel;
        },
        ctaegorizeAddress: function (companies) {
            var self = this;
            if (!companies) {
                return;
            }
            var ctgrzsdAddress = {
                employerAddrrsColl : [],
                finraAddrsColl : [],
                isOfficerAddrsCll : []
            };
            var empAddrsModel;
            _.each(companies, function (address) {
                empAddrsModel = self.convertIntoEmpCompModel(address.attributes);
                var addrssFrmModel;
                switch (address.attributes.relTypCd) {
                    case "A":
                        if (ctgrzsdAddress.employerAddrrsColl.length < 4) {
                            addrssFrmModel = _.find(ctgrzsdAddress.employerAddrrsColl, function (addr) {
                                return addr.get("relSeqNbr") == empAddrsModel.get("relSeqNbr");
                            });
                            if (!addrssFrmModel) {
                                ctgrzsdAddress.employerAddrrsColl.push(empAddrsModel);
                            }
                        }
                        break;
                    case "B":
                        if (ctgrzsdAddress.isOfficerAddrsCll.length < 4) {
                            addrssFrmModel = _.find(ctgrzsdAddress.isOfficerAddrsCll, function (addr) {
                                return addr.get("relSeqNbr") == empAddrsModel.get("relSeqNbr");
                            });
                            if (!addrssFrmModel) {
                                ctgrzsdAddress.isOfficerAddrsCll.push(empAddrsModel);
                            }
                        }
                        break;
                    case "C":
                        if (ctgrzsdAddress.finraAddrsColl.length < 4) {
                            addrssFrmModel = _.find(ctgrzsdAddress.finraAddrsColl, function (addr) {
                                return addr.get("relSeqNbr") == empAddrsModel.get("relSeqNbr");
                            });
                            if (!addrssFrmModel) {
                                ctgrzsdAddress.finraAddrsColl.push(empAddrsModel);
                            }
                            
                        }
                        break;
                    default:
                        break;

                }
            });
            return ctgrzsdAddress;
        },
        compareAddress: function (address1, address2) {
            var isSameAddress = true,
                comparableProperties = [
                    "addressType",
                    "address1",
                    "address2",
                    "countryNm",
                ];
            if (address1.employerName == address2.employerName) {
                _.each(comparableProperties, function (prop) {
                    if(address1[prop] !== address2[prop]){
                        isSameAddress = false;
                        return;
                    }
                });
                if (isSameAddress) {
                    var stateKey = address1["addressType"] == "U.S" ? "state" : "province";
                    if (address1[stateKey] != address2[stateKey] ||
                        address1["city"] != address2["city"] ||
                        address1["zipCode"] != address2["zipCode"]) {
                        isSameAddress = false;
                    }
                }
            }else{
                isSameAddress = false;
            }
            return isSameAddress;
        },
      
    });
    return employmentView;
});