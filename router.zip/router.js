define([
    'jquery',
    'lodash',
    'app/common/util',
    'app/common/constants',
    'app/application/app'
], function ($, _, util, constants, app) {

    /*
     This router uses browser push state to navigate views.
     The route name is passed as a query string parameter.
     */

    const ROUTE_PARAM_NAME = 'route';

    const Router = function () {

        /* PUBLIC FUNCTIONS */

    this.start = function () {
            /* AUDIT-IGNORE-WINDOW-REF-RULE */
            window.addEventListener('popstate', () => handleRouteToUrl(location.href));
            handleRouteToUrl(location.href);
        };

        this.routeTo = function (routeName) {
            let url = location.href.split('?')[0] + '?${ROUTE_PARAM_NAME}=${routeName}';
            history.pushState({}, null, url);
            handleRouteToUrl(url);
        };

        /* PRIVATE FUNCTIONS */

        handleRouteToUrl = function (url) {
            const routeData = util.parseURL(url);
            const routeParameters = routeData.params;
            //const routeName = routeParameters[ROUTE_PARAM_NAME];
            const routeName = routeData.hashTag;
            console.log('handling route to ' + routeName);
            handleRoute(routeName, routeParameters);
        };

        handleRoute = function (routeName, routeParameters) {
            //console.log("routeName: "+routeName);
            switch (routeName) {
                case "/clientSearchView":
                    handleClientSearchView();
                    break;
                case "/clientView":
                    handleClientView();
                    break;
                default:
                    handleClientSearchView();
            }
        };

        handleClientSearchView = function () {
            require(['app/modules/views/ClientSearchView'], function (View) {
                renderAsPrimaryView(new View());
            });
        };

        handleClientView = function () {
            require(['app/modules/views/ClientView'], function (View) {
                renderAsPrimaryView(new View());
            });
        };

        function renderAsPrimaryView(view, tabBarOptionTitle) {
            app.appView.setPrimaryView(view);
            view.render();
            app.appView.scrollToTop();
        }

    };

    return new Router();

});
