define([
  'jquery',
  'underscore',
  'backbone',
  'config',
  'spinner',
  'typeahead',
  'services/dataservice',
  'appcommon/constants',
  'appcommon/commonutility',
  'appmodules/nav/app/models/contactdetails',
  'appmodules/nav/app/models/navcontext',
  'text!appmodules/nav/app/templates/home.html',
  'text!appmodules/nav/app/templates/obodropdown.html',
  'text!appmodules/nav/app/templates/homecsr.html',
   'text!appmodules/nav/app/templates/clientsearchgroup.html',
  'text!appmodules/nav/app/templates/clientsearchgrphsehld.html',
  'text!appmodules/nav/app/templates/navmegamenu.html',
  'appcommon/applauncher/megaMenu',
  'appcommon/globalcontext',
  'appcommon/analytics',
  'errorLog',
  'apipublic/navapi',
  'appmodules/contactprofile/app/models/cpviewmodel',
  'appcommon/applauncher/device'
], function ($, _, Backbone, Config, Spinner, Typeahead, DataService, Constants, CommonUtilis, ContactDetailsModel, NavContext, HomeTmpt, OBOTmpt, ClientIdhomeTmpt, ClientSearchGroupTemplate, ClientSearchGroupHseHoldTemplate, NavmegaMenuTemplate, MegaMenu, GlobalContext, Analytics, ErrorLog, NavApi, CPViewModel, Device) {
	var _self = null;
	var oboCSRList = [];
    var homeView = Backbone.View.extend({
        el: $("#afinav-master"),
        id: 'afinav-master',
        events: {
            //stop the events getting triggered from the right dropdown menu1 commented 
            "click .search-box, .search-box form, .newsfeed": "stopPropagation",
            //"click #right-menu-nav, #afinav-favorite-btn, #afinav-household-btn, #afinav-left-menu-nav, .nav-mega-menu, #afinav-obo-list, .nav-mobile-search": "hidetypeahead",            
            "click #right-menu-nav, #afinav-favorite-btn, #afinav-household-btn, #afinav-left-menu-nav, .nav-mega-menu, #afinav-obo-list, .nav-mobile-search": "hidetypeahead",
            //"click #afinav-obo-list": "toggleDropDown",
            "click #afinav-favorite-btn, #afinav-left-menu-nav, #obo-drop-box": "toggleMenus",
            //This is triggered when user selects obo from the dropdown menu
            "focus #search": "txtBoxOnFocus",
            "focus #search-csr": "txtBoxOnFocusCsr",
            "focus #obo-search-csr": "txtBoxOnFocusOboCsr",
            "keydown #search": "keydownOnSearch",
            "keydown #search-csr": "keydownOnSeachCsr",
            "keydown #obo-search-csr": "keydownOnSeachCsrObo",
            "keypress #search-csr": "keypressOnSeachCsr",
            "keypress #obo-search-csr": "keypressOnSeachCsrObo",
            "input #search": "serachBoxChangeHandler",
            "input #search-csr, #obo-search-csr": "searchBoxCsrChangeHandler",
            "click #afinav-obo-menu li": "advisorclick",
            //Subapplication route
            "click .contact-info": "contactprofileclick",
            "click #accounts": "accntviewclick",
            "click #portfolio": "portfolioclick",
            "click #portfolio2": "portfolio2click",
            "click #teaming": "teamingclick",
            "click #navtanylink": "tanyclick",
            "click #boxlink": "boxforampfclick",
            "click #confident-retirement": "confidentretirementclick",
            "click #mm-system-link": "mmsysytemclick",
            "click #ppa-vpn-link": "ppavpnlink",
            "click #total-view-link": "totalviewclick",
            "click #nav-smartpad": "smartpadclick",
            "click #nav-hocInsights": "hocInsightsclick",
            "click .afinav-grp-lnk": "groupchangeevent",
            "click .search-clear": "clearsearch",
            "click .csr-clear": "clearcsrsearch",
            "click .csrobo-clear": "clearcsrobosearch",
            "click .calendar, .home-logo": "opencalendar",
            "click .afinav-toggle-sub-menus": "toggleAfinavSubMenus",
            //"click #toggleMenu, #right-menu-nav": "toggleRightMenu",
            "click #toggleMenu": "toggleRightMenu",
            "click .contact-list": "opencontactlist",
            "click .prospect-list": "openprospectlist",
            "click .drafts": "opendrafts",
            //For Mobile View Search Toggle
            "click .nav-mega-menu": "showMegaMenu",
            "click #nav-megamenu-modal": 'rembodystyle',
            "click #clients-list, #prospects-list": "navContactSearch",
            "click #afinav-obo-list": "oboClick",
            "click #afinav-logout-html": "logoutclick",
            "click #megamenuNCSTLink": "navigateToNCST",
            "click #lanchTaskList":"launchTaskList",
            //"mouseleave #nav-megamodal-content":"hideMegamodal",
            "click #client-id-gobtn": "showcpCSR",
            "click #obo-gobtn": "showcpOboCSR",
            "click #client-viewer": "clientViewerLink",
            "click #online-file-manager": "onlineFileManagerLink",
            "click #status-manager": "statusManagerLink",
            "click #technical-support": "technicalSupportLink",
            "click #contact-manager": "contactManagerLink",
            "click #efile-delivery": "efileDeliveryLink",
            "click #eforms-manager": "eformsManagerLink",
            "click #new-business-setup": "newBusinessSetupLink",
            "click #opportunity-manager": "opportunityManagerLink",
            "click #share-class-analyzer": "shareClassAnalyzerLink",
            "click #mstar-advisor-ws": "mstarAdvisorWsLink",
            "click #naviplan": "naviplanLink",
            "click #share-documents, #share-to-dos": "shareDocumentToDoLink",
            "click #contact-service": "contactServiceLink",
            "click #dol-impact-dashboard": "dolImpactDashboardLink",
        },

        initialize: function (params) {
            var that = this;
            this.keywordSearchRequired = false;
            this.searchTimeout = null;
            this.lastKeyword = null;
            this.contactSearchType = "client";
            //This event will be triggered whenever the Adisor(this.setAdisorId) got changed in the Advisor select option  
            this.globalContext = GlobalContext.getInstance();

            this.clientSearchEventModel = new NavContext.clientSearchEventModel();
            this.listenTo(this.clientSearchEventModel, 'change:selectedadvisor', this.eventTriggered);
            this.listenTo(this.clientSearchEventModel, 'change:selectedclient', this.eventTriggered);
            this.listenTo(this.clientSearchEventModel, 'change:selectedclientgroups', this.eventTriggered);
            this.selContactDetails = null;
            this.t1Window = null;
            this.params = params
            _self = this;
            this.megamenu = null;
            document.clientSearchEventModel = this.clientSearchEventModel;
            /* Transparent Nav Click Event */
            $(document).off("click", "#transparent-nav").on("click", "#transparent-nav", that.transparentNavClick);

            $(document).on("changeAction", this.globalContextChange);
            $(document).on('click', function (e) {
                if ($("#afinav-obo-menu").is(":visible")) { $("#afinav-obo-menu").hide(); }

                if ($(e.target).hasClass("nav-mobile-search")) {
                    practicetech.modules.tasks = new practicetech.createNew.module();
                    $("#search-field-box").toggleClass("search-tablet-show");
                    $("#search").val('').focus();
                    if (($(".typeahead.dropdown-menu")).is(":visible")) { $(".typeahead.dropdown-menu").hide(); }
                    var ww = window.innerWidth;
                    if (ww >= 768) {
                        $("#search-csr,#search-field-box, .nav-mobile-search, .desk-tab-client-name").toggleClass("hidden");
                        $("#search").val('').focus();
                    }
                }
                else if ($(e.target).hasClass("nav-mobile-search-csr")) {
                    var ww = window.innerWidth;
                    if (ww < 768) {
                        if ($('#clientIdSearchbox').not(":visible")) {
                            $('#afi-nav-modal').modal('show');
                            $('#afinav-navbar').css('z-index', '1050');
                        }
                    if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
                        if (ww < 768) {
                            $('#client-id-gobtn').removeClass('hidden');
                            $('#clientIdSearchbox').addClass('search-tablet-show');
                            $('#search-field-box-csr').addClass('navbar-search-csr');
                            $('#search-csr').val('').focus();
                            $('.search-clear').addClass('search-clear-csr');
                            return;
                        }
                    } else {

                        //$('#search-csr, #search-field-box-csr, #client-id-gobtn').css('display', 'block');
                        $('#search-csr,#search-field-box-csr, #client-id-gobtn').toggleClass('hidden');
                        $('#clientIdSearchbox').addClass('search-tablet-show');
                        $('#search-field-box-csr').addClass('navbar-search-csr');
                        $('#search-csr').val('').focus();
                        $('.search-clear').addClass('search-clear-csr');
                        return;
                        }
                   
                    }

                    $("#search-field-box-csr").toggleClass("search-tablet-show");
                    $("#search-csr").val('').focus();
                    
                    if (ww >= 768) {
                        $(".nav-mobile-search-csr, .desk-tab-client-name-csr, #search-field-box-csr, #client-id-gobtn").toggleClass("hidden");
                        $("#search-csr").val('').focus();
                    }
                }
                else if ($(e.target).hasClass("client-input-csr") || $(e.target).hasClass("csr-clear")) {
                    return;
                }
                else {
                    //This is for scenario, when user clicks on OBO and when OBO Search box is visible, when user clicks on the top bar - this should be closed if it is opened
                    if ($("#oboSearchbox").is(":Visible")) {
                        $("#oboSearchbox").hide();
                        if ($('#afi-nav-modal').hasClass('in')) $('#afi-nav-modal').modal('hide');
                    }
                    that.togglesearchboxes();
                }            
            });

            $(document).on('click', '#afinav-master', function (e) {
                $('#no-records-found').hide();

                if (e.currentTarget.id == "afinav-master") {
                    that.contactSearchTabs();
                    if ($("#afinav-obo-menu").is(":visible")) { navmenu(); }
                    $(".typeahead").hide();
                } else if ($(e.currentTarget).hasClass("dropdown-toggle") || $(this)[0].id == "toggleMenu") {
                    var _opened = $(".navbar-collapse").hasClass("in") || $(".dropdown-menu").parent().hasClass("open");
                    if (_opened == true) { that.openModal(true); } else { that.openModal(false); }
                } else if (!$(e.currentTarget).hasClass("typeahead") && $(".typeahead.dropdown-menu").is(":visible")) {
                    $(".typeahead.dropdown-menu").hide();
                    $(".client-search-mobile").hide();
                }
            });

           
            $(document).on('click touchstart', '.modal-backdrop', function (e) {
                $('#no-records-found').hide();

                e.preventDefault();
                e.stopPropagation();         
               if ($("#afinav-obo-menu, #oboSearchbox").is(":visible")) {
                   $("#afinav-obo-menu, #oboSearchbox").hide();
                   //that.rembodystyle();
                   //For Dynamic OBO Height
               }
                that.contactSearchTabs();
                navmenu();
                that.clearsearch('modalClose');
                that.togglesearchboxes();
            });

            $(document).off('click', '.cl-client-name a').on('click', '.cl-client-name a', function (e) { that.launchCP(e); });

            $(window).on("orientationchange", function () {
                var ww = window.innerWidth;
                if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/Android/i))){
                   if (ww > 767) {
                       var div3h = $(".nav-menu-main-sec3").height();
                        if ($(".nav-menu-main-sec1").is(":visible")) {
                            //var div1h = $(".nav-menu-main-sec1").height();
                            $(".nav-menu-main-sec1, .nav-menu-main-sec2").css("height", div3h);
                        }
                        else {  
                            $(".nav-menu-main-sec2").css("height", div3h);
                        }
                   }
                }
                if ($("#nav-megamenu-modal").is(":visible")) { menudynamics(); }
            });

            $(window).resize(function () {
                var ww = window.innerWidth;
                if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
                if (ww >= 768) {
                    var div3h = $(".nav-menu-main-sec3").height();
                    if ($("#search-field-box").hasClass("search-tablet-show")) {
                        $("#search-field-box").removeClass("search-tablet-show");
                    }
                    if ($("#search-field-box-csr").hasClass("search-tablet-show")) {
                        $("#search-field-box-csr").removeClass("search-tablet-show");
                    }
                    if ((!$("#search").is(":focus")) && ($(".desk-tab-client-name").text() != "")) {
                            $("#search-field-box").addClass("hidden");
                            $(".nav-mobile-search, .desk-tab-client-name").removeClass("hidden");
                    }
                    /*home office*/
                    if ((!$("#search-csr").is(":focus")) && ($(".desk-tab-client-name-csr").text() != "")) {
                        $("#search-field-box-csr").addClass("hidden");
                        $(".nav-mobile-search-csr, .desk-tab-client-name-csr").removeClass("hidden");
                    }
                  
                    if (!$("#search-icon").hasClass("hidden")) {
                        $('#client-id-gobtn').addClass("hidden");
                    }
                    if ($(".nav-menu-main-sec1").is(":visible")) {
                        //var div1h = $(".nav-menu-main-sec1").height();
                        $(".nav-menu-main-sec1").css("height", div3h);
                        $(".nav-menu-main-sec2").css("height", div3h);
                    }
                    if (!$(".nav-menu-main-sec1").is(":visible")) {
                        $(".nav-menu-main-sec2").css("height", div3h);
                    }
                    if (!$('#clientIdSearchbox').is(':visible')) {
                        $('#clientIdSearchbox').css('display', 'block');
                    }
                }
                else if (ww < 768) {
                    // Resize condition when window size less than mobile
                    if (!$("#search-field-box").hasClass("search-tablet-show") && ($("#search").is(":focus"))) {
                        $("#search-field-box").addClass("search-tablet-show");
                    }
                    if (!$("#search-field-box-csr").hasClass("search-tablet-show") && ($("#search-csr").is(":focus"))) {
                        $("#search-field-box-csr").addClass("search-tablet-show");
                    }
                    if (($("#search").is(":focus")) && ($(".desk-tab-client-name").text() != "")) {
                        $("#search-field-box").removeClass("hidden");
                        $(".nav-mobile-search, .desk-tab-client-name").addClass("hidden");
                    }// Ends Resize condition when window size less than mobile
                    /*home office*/
                    if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
                        if (window.innerWidth < 768) {
                            if ($("#search-icon").hasClass("hidden")) {
                                $('#search-csr, #search-field-box-csr').removeClass("hidden");
                            }
                        }
                    }
                    if ((!$("#search-csr").is(":focus")) && ($(".desk-tab-client-name-csr").text() != "")) {
                        $("#search-field-box-csr").removeClass("hidden");
                        $(".nav-mobile-search-csr, .desk-tab-client-name-csr").addClass("hidden");
                    }
                    if ($('#clientIdSearchbox').is(':visible')) {
                        $('#clientIdSearchbox').css('display','none');
                    }                    

                    $(".nav-menu-main-sec2, .nav-menu-main-sec1").css("height", "auto");
                }
                    if ($("#nav-megamenu-modal").is(":visible")) { menudynamics(); }
                }

                //For Mega Menu UI Changes (For Mobile devices, expand the first section by default)
                //For All Environments (Desktop / Tablet / Mobile)
                //that.showFirstVisibleMenuItems();

                //Excute only for tablet (In Tablet portrait, Width of menu should be 100%)
                that.adjustMenuInTablet();
            });
            
            var menudynamics= function () {
                setTimeout(function () {
                    var sh = window.innerHeight, _offsetHeight = 0;
                    if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
                        if ($(window).width() > $(window).height()) {
                            _offsetHeight = 110;
                        }
                        else if ($(window).height() > $(window).width()) {
                            _offsetHeight = 140;
                        }
                    }
                    else {
                        _offsetHeight = 110;
                    }
                    var reqheight = sh - _offsetHeight;
                    //$(".nav-megamenu-container, .nav-menu-main-sec1, .nav-menu-main-sec2, .nav-menu-main-sec3, .nav-menu-main-sec4").css({ "max-height": reqheight + "px" });
                    $(".nav-megamenu-container").css({ "max-height": reqheight + "px" });
                }, 300);
                //Using timeout to make sure orientaion change triggered in Android.
            };
            var navmenu = function () {
                if ($(".dropdown-menu").parent().hasClass('open') || $('.navbar-collapse').hasClass('in') || $(".modal-backdrop").hasClass('in')) {
                    $(".dropdown-menu").parent().removeClass('open');
                    $('.navbar-collapse').removeClass('in');
                    that.openModal(false);
                }
            };
            //event listener for contextReady to populate client list
            $(document).off('contextReady').on('contextReady', that.handleContextReadyEvent);
            
        },
        transparentNavClick: function () {
            $('.cancel-text:visible').click();
            //BootstrapDialog.alert("Please Cancel or Continue below before leaving the transaction.", "", "Information");
        },
	    oboIDFormatter: function (id) {
	        var _formattedIdLength = 9, _padzeoLength = 8, _zeroString = "", _formattedId = id;
                _padzeoLength = (_formattedIdLength -id.length);
	        if ((id.length) < 9) {
	            _zeroString = Math.pow(10, _padzeoLength).toString().substr(1);
	            _formattedId = _zeroString + '' +id;
	        }
	        return _formattedId;
	    },
	    showcpOboCSR: function (e) {
	        e.preventDefault();
	        e.stopPropagation();
            var that = this;
            if($('#obo-search-csr').val() == "" || $('#obo-search-csr').val().length <5){
            	BootstrapDialog.alert("Advisor ID must contain at least 5 digits.");
        		return true;
			}
            var oboAdvisorId = $('#obo-search-csr').val();   
	        oboAdvisorId = this.oboIDFormatter(oboAdvisorId);
	        Spinner.show();
	        DataService.getDistributorAssistantRelationship(oboAdvisorId).then(function (resp, status, xhr) {
	            if (resp && resp.d) {
	                DataService.getDistributorInfo(oboAdvisorId, [401, 404, 500]).then(function (response) {
	                    if (response.status && (response.status == 401 || response.status == 404 || response.status == 500)) {
	                        Spinner.hide();
	                        BootstrapDialog.alert("You are not authorized to view advisor data.");
	                    }
	                    else {
	                        if (response[0] && response[0].prefName && (response[0].prefName.firstNm || response[0].prefName.lastNm)) {
	                            var _prefNm = response[0].prefName,
	                                _sfxText = (_prefNm.sfxTxt && _prefNm.sfxTxt.trim()) ? (" " + _prefNm.sfxTxt.trim()) : "";
	                            $('.afinav-obo-user').text(_prefNm.firstNm + " " + _prefNm.lastNm + _sfxText);
	                            }
	                            else {
	                                $('.afinav-obo-user').text("");
	                            }
	                        //if ($("#oboSearchbox").is(":visible")) {
	                        $("#oboSearchbox").hide();
	                        //}
	                        that.openModal(false);
	                        Spinner.hide();
	                        $("#csr-clientid-search-container,.nav-mobile-search-csr").addClass("hidden");
	                        $("#advisor-client-search-container").removeClass("hidden");
	                        if (window.innerWidth > 767) {
	                            $("#search-field-box").removeClass("hidden");
	                            $(".nav-mobile-search,.desk-tab-client-name").addClass("hidden");
	                        }
                            console.log("Advisor Removed Event triggered - showcpOboCSR - 111");
	                        that.clientSearchEventModel.set({ selectedclient: undefined, selectedclientgroups: undefined, selectedcontacttype: undefined, triggeredevent: "AdvisorSelected" }, { "silent": true });
	                        that.clientSearchEventModel.set({ selectedclient: undefined }, { silent: true });
	                        that.clientSearchEventModel.set({ selectedclientgroups: undefined }, { silent: true });
	                        console.log("Advisor Selected Event triggered - showcpOboCSR - 222");
	                        that.clientSearchEventModel.set({ selectedadvisor: oboAdvisorId, isOBO: true, triggeredevent: "AdvisorSelected" });
	                        $('#search').val("");
	                    }/* else {
	                        var errMessage = "No record found";
	                        BootstrapDialog.alert(errMessage, function (result) {
	                            $('#obo-search-csr').attr("data-norecord", "true");
	                        }, "Error title");
	                        that.openModal(false);
	                        Spinner.hide();
	                    }*/
	                })
                    .fail(function (error) {
                        Spinner.hide();
                        ErrorLog.ErrorUtils.myError(error);
                    });
	            } else {
	                Spinner.hide();
	                BootstrapDialog.alert("Advisor ID not found. Please verify value and try again.");
	                that.openModal(false);
	            }
	        }).fail(function (xhr) {
	            Spinner.hide();
	            if (xhr.status == 401) {
	                BootstrapDialog.alert("You are not authorized to view advisor data.");
	            } else {
	                Spinner.hide();
	                BootstrapDialog.alert("Advisor ID not found. Please verify value and try again.");
	                that.openModal(false);
	            }
	            
	        });

	        /*var oboCSRAttr = _.pluck(oboCSRList, 'attributes');
	        var oboCSRObj = _.map(oboCSRAttr, function (row, key) {
	            if (row.fmid == oboAdvisorId) {
	                return row;
	            }
	        });
	        var oboCSRVal = _.without(oboCSRObj, undefined);

            $('#search-csr').val('');

	        if (oboCSRVal.length > 0) {
                $('.afinav-obo-user').text(oboCSRVal[0].name);
                if ($("#oboSearchbox").is(":visible")) {
                    $("#oboSearchbox").hide();
	                }
                this.openModal(false);
                Spinner.hide();
	        } else {
	            var errMessage = "No record found";
	            BootstrapDialog.alert(errMessage, function (result) {
	                $('#obo-search-csr').attr("data-norecord", "true");
	            }, "Error title");
                this.openModal(false);
	            Spinner.hide();
	        } */          

	    },
	    clientIDFormatter: function (id) {
	        var _admnCd = '001', _formattedIdLength = 23, _padzeoLength = 12, _zeroString = "", _formattedId = id;
	        _padzeoLength = (_formattedIdLength - _admnCd.length - id.length);
	        if ((_admnCd.length + id.length) < 23) {
	            _zeroString = Math.pow(10, _padzeoLength).toString().substr(1);
	            _formattedId = _admnCd + '' + _zeroString + '' + id;
	        }
	        return _formattedId;
	    },
	    showcpCSR: function () {
	    	if($('#search-csr').val() == "" || $('#search-csr').val().length<5){
	    		BootstrapDialog.alert("Please enter a valid client Id.");
        		return true;
			}
	        $('#afi-nav-modal').modal('hide');
	        var clientVal = $('#search-csr').val(); 
	        var clientid = this.clientIDFormatter(clientVal);
	        var that = this;
	        var advFMID = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;

	        Spinner.show();
	        DataService.getClientgroup(clientid, [401]).done(gotoclientGroupSelected);
	        function gotoclientGroupSelected(result) {
	        	if(result.status && result.status == 401){
	        		Spinner.hide();
	        		BootstrapDialog.alert("You are not authorized to view client data.");
				}else if (result != undefined && result[0] != undefined && result[0].attributes.activeGroups[0] != undefined) {
					var contact = [{
	        			ctx: "COLA.CL",
						firstNm: null,
						fmtNm: null,
						id: clientid,
						lastNm: null,
						orgNm: null
	        		}];
	        		if(result[0].get("orgClient") && result[0].get("orgClient").get("orgNm")){
	        			contact[0].fmtNm = result[0].get("orgClient").get("orgNm");
	        			contact[0].lastNm = result[0].get("orgClient").get("orgNm");
	        			contact[0].orgNm = result[0].get("orgClient").get("orgNm");
	        		}else{
	        			contact[0].fmtNm = result[0].get("personClient").get("clFirstNm")+" "+result[0].get("personClient").get("clLastNm");
	        			contact[0].firstNm = result[0].get("personClient").get("clFirstNm");
	        			contact[0].lastNm = result[0].get("personClient").get("clLastNm");
	        		}
	        		if (!ContactDetailsModel.advsiorContacts.getSelectedContactDetails(advFMID, contact[0].id, Constants.contactType.Client)) {
	        		    ContactDetailsModel.advsiorContacts.AddContactDetails(advFMID, contact, Constants.contactType.Client, false);
	        		}
	                var selContactId = result[0].id; 
	                var contactType = "client";
	                CPViewModel.getInstance().setData({ 'cola': result[0].attributes });
	                that.clientSearchEventModel.set({ selectedclientgroups: undefined, triggeredevent: "ClientSelected" }, { "silent": true });
	                that.clientSearchEventModel.set({ selectedclient: selContactId, selectedcontacttype: contactType, triggeredevent: "ClientSelected" });
	                $('.afinav-users, #afinav-household-grp, #afinav-left-menu-box').removeClass('hidden');
	                that.toggleMenus();
	                //that.contactSearchTabs();
	                if (isNaN($("#search-csr").val()) && $('.desk-tab-client-name-csr').hasClass('hidden')) {
	                    $('#search-csr').val('').blur();
	                    $('#search-field-box-csr, #client-id-gobtn').toggleClass("hidden"); //hide();
	                    if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
	                        if (window.innerWidth < 768) { }
	                    } else {
	                        if (window.innerWidth < 768) {
	                            $('#search-csr').addClass("hidden");
	                        }
	                    }
	                    $('.desk-tab-client-name-csr, .nav-mobile-search-csr').toggleClass("hidden");
	                }
	               // that.togglesearchfields()	               
	                Spinner.hide();
	            } else {
	                var errMessage = "No record found";
                    $('.modal-content').addClass('marginLeft');
	                BootstrapDialog.alert(errMessage, function (result) {
	               // $('.modal-content').addClass('marginLeft');
	                }, "Error title","noRecordAlertAlign");
	                Spinner.hide();
	            }
	        }
        },
        oboClick: function (e) {
                e.preventDefault();
                e.stopPropagation();
                var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
                if (userRoles && (userRoles.indexOf("csr") > -1 || userRoles.indexOf("aac") > -1 || userRoles.indexOf("rp") > -1 || userRoles.indexOf("rpdelegates") > -1)) {
                    if ($("#oboSearchbox").is(":visible")) { $("#oboSearchbox").hide(); this.openModal(false); } else { $("#oboSearchbox").show(); this.openModal(true); }
                    if (userRoles.indexOf("csr") > -1 || userRoles.indexOf("aac") > -1) {
                        if (window.innerWidth < 768) {
                            if ($('#clientIdSearchbox').is(":visible")) {
                                $('#clientIdSearchbox').css('display', 'none');
                                $('#search-csr,#client-id-gobtn,#search-field-box-csr').addClass('hidden');
                            }
                        }
                    }
                	 
                }else{
                	if ($("#afinav-obo-menu").is(":visible")) {
                        $("#afinav-obo-menu").hide();
                        //For Dynamic OBO Height
                        this.openModal(false);
		            } else {
		                        $("#afinav-obo-menu").show();
		                        this.contactSearchTabs();
		                if ($("#search-field-box, #search-field-box-csr").hasClass('search-tablet-show')) { this.togglesearchfields(); }
		                        this.openModal(true);
		            }
                }
            
        },  
        logoutclick: function (e) {
        	Analytics.analytics.recordAction('navigationLogout:clicked');
        },
        navContactSearch: function (e) {
            e.preventDefault();
            var target = e.target || e.currentTarget;
            this.contactSearchType = $(target).data("search-type");
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (this.contactSearchType == "nonclient" && _isNonCMuser) {
                this.contactSearchType = "client";
                $('.modal-backdrop').click();
                CommonUtilis.toggleNonCMmsg("function");
                return;
            } else {
                var contactLnks = $("#contact-search-div a");
                //if (contactLnks.hasClass('hdr-tab-active')) {  $('#afi-nav-modal').modal('hide');
                contactLnks.removeClass('hdr-tab-active');
                $(target).addClass('hdr-tab-active');
                //}
                this.contactSearchType = $(target).data("search-type");
                if ((this.contactSearchType) === "nonclient") {
                    $("#search-field-box").addClass("nav-prospect");
                }
                else {
                    if ($("#search-field-box").hasClass("nav-prospect")) {
                        $("#search-field-box").removeClass("nav-prospect");
                    }
                }
            }
            $(".typeahead").hide();
            this.noRecordsFound(false);
            this.lastKeyword = null;
            ContactDetailsModel.advsiorContacts.clearContacts(this.getAdvFMID(), ((this.keywordSearchRequired) ? true : false));
            $("#search").focus();
            $("#search").trigger("keyup");
                //function to call show/hide contact search tabs / no records found

        },
        serachBoxChangeHandler : function(){
        	if($("#search").val().length ===0){
            	ContactDetailsModel.advsiorContacts.clearContacts(this.getAdvFMID(),((this.keywordSearchRequired) ? true : false));
            	this.lastKeyword = null;
        	}
        	this.noRecordsFound(false);
        },
        searchBoxCsrChangeHandler: function () {
            if ($("#search-csr").val().length === 0 || $("#obo-search-csr").val().length === 0  ) {
                ContactDetailsModel.advsiorContacts.clearContacts(this.getAdvFMID(), ((this.keywordSearchRequired) ? true : false));
                this.lastKeyword = null;
            }
            this.noRecordsFound(false);
        },
        setClientSelectedAlways : function(){
        	$("#contact-search-div a").removeClass('hdr-tab-active');
        	$("#clients-list").addClass('hdr-tab-active');
        	if ($("#search-field-box").hasClass("nav-prospect")) {
        	    $("#search-field-box").removeClass("nav-prospect");
        	}
        	this.contactSearchType = $("#clients-list").data("search-type");
        	this.noRecordsFound(false);
            this.lastKeyword = null;
            //ContactDetailsModel.advsiorContacts.clearContacts(this.getAdvFMID(),((this.keywordSearchRequired) ? true : false));
        },
        openModal: function (val) {
            if (val) {
                $('#afi-nav-modal').modal('show');
                $('#afinav-navbar').css('z-index', 1050);
            } else {
                $('#afi-nav-modal').modal('hide');
                $('#afinav-navbar').css('z-index', 1038);
            }
        },

        contactSearchTabs: function () {
            var ww = window.innerWidth;
            if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
                if (ww < 768) {
                    if ($("#search-icon").hasClass("hidden")) {
                        $('#search-csr, #search-field-box-csr').removeClass("hidden");
                    }
                }
            }
            if ($('#contact-search-div').is(":visible")) {
                $("#contact-search-div").hide();
                $("#search").val('').blur();
                $('#afi-nav-modal').modal('hide');
                $('#afinav-navbar').css('z-index', 1038);
            }
        },

        togglesearchboxes : function () {
            var ww = window.innerWidth;
            if (ww >= 768) {
                if ($(".nav-to-cp").html() != "") {
                    if ($(".nav-mobile-search").hasClass("hidden")) {
                        $("#search-field-box, .nav-mobile-search, .desk-tab-client-name").toggleClass("hidden");
                    }
                    if ($(".nav-mobile-search-csr").hasClass("hidden")) {
                        $("#search-field-box-csr, .nav-mobile-search-csr, .desk-tab-client-name-csr,  #client-id-gobtn").toggleClass("hidden");
                    }
                }
            }
            else {
                if ($("#search-field-box").hasClass("search-tablet-show")) {
                    $("#search-field-box").toggleClass("search-tablet-show");
                }
                if ($("#search-field-box-csr").hasClass("search-tablet-show")) {
                    $("#search-field-box-csr").toggleClass("search-tablet-show");
                }
                if ($("#clientIdSearchbox").hasClass("search-tablet-show")) {
                    $("#clientIdSearchbox").toggleClass("search-tablet-show");
                   // $("#client-id-gobtn, #search-field-box-csr").hide();
                }
            }
        },
        togglesearchfields: function () {
            var ww = window.innerWidth;
            if (ww < 768) {
                $("#search-field-box").toggleClass("search-tablet-show");
                $("#search-field-box-csr").toggleClass("search-tablet-show");
            }
            if (ww >= 768) {
                $("#search-field-box, .nav-mobile-search, .desk-tab-client-name").toggleClass("hidden");
                $("#search-field-box-csr, .nav-mobile-search-csr, .desk-tab-client-name-csr,  #client-id-gobtn").toggleClass("hidden");
            }
        },

        dropdownheights : function (e){
            var _navSearchHeight = 390;
            var _availheight = window.innerHeight - 150;
            if (_availheight < _navSearchHeight) {
                return _availheight;
                //$(".typeahead.dropdown-menu").css("max-height", _availheight + "px");
            }
            else {
                return _navSearchHeight;
                //$(".typeahead.dropdown-menu").css("max-height", _navSearchHeight + "px");
            }
            // For Dynamic height of search dropdown
        },

        globalContextChange: function (e) {
            e.preventDefault();
            var that = _self;
            var advFMID = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
            if(GlobalContext.getInstance().getGlobalContext().Context.ContactType == "nonclient" && GlobalContext.getInstance().getGlobalContext().Context.IsOBO == true){
            	advFMID = CommonUtilis.readCookie('FMID');
            }
            if (JSON.parse(e.message).toString().toLowerCase().indexOf("contactchanged") >= 0) {
                DataService.clearCacheManager(Constants.subAppName.ContactProfile);               
                that.selContactDetails = ContactDetailsModel.advsiorContacts.getSelectedContactDetails(advFMID, GlobalContext.getInstance().getGlobalContext().Context.ContactId, GlobalContext.getInstance().getGlobalContext().Context.ContactType);
                $('#afinav-client-name').empty();
                $('#search').val("");
                if (that.selContactDetails != undefined) {
                    document.clientSearchEventModel.set({ selectedclient: that.selContactDetails.id, selectedcontacttype: that.selContactDetails.contactType }, { "silent": true });
                    var selContactName = "";
                    var Name = "";
                    if (that.selContactDetails.contactType == Constants.contactType.Client) {
                        selContactName = that.selContactDetails.orgNm != null ? that.selContactDetails.orgNm : that.selContactDetails.lastNm + ", " + that.selContactDetails.firstNm + ", " + that.selContactDetails.id.slice(-9);
                        Name = that.selContactDetails.orgNm != null ? that.selContactDetails.orgNm : that.selContactDetails.lastNm + ", " + that.selContactDetails.firstNm;
                    } else {
                        selContactName = CommonUtilis.hasValue(that.selContactDetails.firstNm) ? that.selContactDetails.lastNm + ", " + that.selContactDetails.firstNm : that.selContactDetails.lastNm;
                        Name = CommonUtilis.hasValue(that.selContactDetails.firstNm) ? that.selContactDetails.lastNm + ", " + that.selContactDetails.firstNm : that.selContactDetails.lastNm;
                    }
                    $('#search').val(selContactName);
                    $(".nav-to-cp").html(Name);
                    $("#search").blur();
                }
            }
        },

        toggleRightMenu: function (e) {
            if (!$(".modal-backdrop").hasClass('in')) { this.openModal(true); } else { this.openModal(false); }
        },
        clearsearch: function (obj) {
            var $contSearchDiv = $('#contact-search-div');
            if (obj == "modalClose" || obj == "undefined") {
                $("#search").val('').blur();
            } else {
                $("#search").val('').focus();
                if (!$contSearchDiv.is(':visible')) { $contSearchDiv.show(); }
            }
            if ($(".typeahead").is(':visible')) { $(".typeahead").hide(); }
            if ($("#no-records-found").is(':visible')) { $("#no-records-found").hide(); }
        },
	    clearcsrsearch: function (obj) {
            $('#search-csr').val('').focus();
	    },
	    clearcsrobosearch: function (obj) {
	        $('#obo-search-csr').val('').focus();
	    },
        keydownOnSearch : function(e){
            if ((e.keyCode == 13)) {
                e.preventDefault();
            }
        },
        keydownOnSeachCsr: function (e) {
            $("#search-csr").on("paste", function (e) {
                var that = this;
                setTimeout(function () {
                    that.value = that.value.replace(/\D/g, "");
                }, 100);
            });
        },
        keypressOnSeachCsr: function (e) {
            if ((e.keyCode == 13)) {
                $('#client-id-gobtn').click();
            }
            var _regxNumOnly = new RegExp('^\\d*$');
            var _str = String.fromCharCode(e.keyCode);
            if (!_regxNumOnly.test(_str)) {
                e.stopPropagation();
                e.preventDefault();
                return false;
            }
        },
        keydownOnSeachCsrObo: function (e) {
            $("#obo-search-csr").on("paste", function (e) {
                var that = this;
                setTimeout(function () {
                    that.value = that.value.replace(/\D/g, "");
                }, 100);
            });
        },
        keypressOnSeachCsrObo: function (e) {
            if ((e.keyCode == 13)) {
                $('#obo-gobtn').click();
            }
            var _regxNumOnly = new RegExp('^\\d*$');
            var _str = String.fromCharCode(e.keyCode);
            if (!_regxNumOnly.test(_str)) {
                e.stopPropagation();
                e.preventDefault();
                return false;
            }
        },
        keywordSearch : function(process){
        	var _that = this;
        	var serachKey = $("#search").val();
        	if(_that.searchTimeout){
    			clearTimeout(_that.searchTimeout);
    		}
    		_that.searchTimeout = setTimeout(function(){
    			serachKey = $("#search").val();
    			if(serachKey && serachKey.length>2){
    				_that.lastKeyword = serachKey;
    				_that.processTheKeywordSearch(serachKey,process);
    			}
    		},Config.contactListTimeout);
        },
        searchInExistingKey : function(key){
            if (key) {
                try{
                    if(key.search(new RegExp("^"+this.lastKeyword+"", "i")) == -1){
                        return true;
                    }
                }
                catch (err) {
                    var _customLog = {
                        "message": "Custom log - searchInExistingKey()",
                        "stack": {
                            "description": "Key: " + key + "; Error: " + err.message
                        }
                    }
                    ErrorLog.ErrorUtils.myError(_customLog, true);
                    return true;
                }
        	}
        	return false;        	
        },
        processTheKeywordSearch : function(serachKey,process){
        	var _that = this;
        	if(_that.contactSearchType == "client"){
				_that.searchClientList(_that.clientSearchEventModel.get('selectedadvisor'),serachKey,process);
			}else if(_that.contactSearchType == "nonclient"){
				_that.searchProspectList(CommonUtilis.readCookie('FMID'),serachKey,process);
			}
        },
            txtBoxOnFocusCsr: function (e) {
            	this.openModal(false);
            	var ww= window.innerWidth;
            if (e.target.id == "search-csr" && ww < 768) {
            	this.openModal(true);
                    $('#afi-nav-modal').modal('show');
                    $('#afinav-navbar').css('z-index', 1050);
            }
            
            $("#obo-search-csr").val("");
            $("#oboSearchbox").hide();
       },
            txtBoxOnFocusOboCsr : function (e) {
            if (e.target.id == "obo-search-csr") {
            }
        },
            txtBoxOnFocus: function (e) {
            if (e.target.id == "search") {
                if (!$('#contact-search-div').is(':visible')) {
                    $('#contact-search-div').show();
                    $('#afi-nav-modal').modal('show');
                    $('#afinav-navbar').css('z-index', 1050);
        		}
            }            
            if ($('#right-menu-nav, #afinav-obo-list, #afinav-left-menu-items, #afinav-household-menu, #afinav-favorite-menu, #afinav-household-btn').parent().hasClass('open'))
                $('#right-menu-nav, #afinav-obo-list, #afinav-left-menu-items, #afinav-household-menu, #afinav-favorite-menu, #afinav-household-btn').parent().removeClass('open');
            if ($("#afinav-obo-menu, #oboSearchbox").is(":visible")) {
                $("#afinav-obo-menu, #oboSearchbox").hide();
                //For Dynamic OBO Height
                //that.rembodystyle();
            }
            
        },
        groupchangeevent: function (e) {
            e.preventDefault();
            var that = this;
            if (e.currentTarget.href == "") {
            	that.selContactDetails = ContactDetailsModel.advsiorContacts.getSelectedContactDetails(that.getAdvFMID(), e.currentTarget.id);
                if (that.selContactDetails != undefined && that.selContactDetails != null) {
                    this.clientSearchEventModel.set({ selectedclientgroups: undefined, triggeredevent: "ClientSelected" }, { "silent": true });
                    this.clientSearchEventModel.set({ selectedclient: e.currentTarget.id, selectedcontacttype: Constants.contactType.Client, triggeredevent: "ClientSelected" });
                }
                else {
                	BootstrapDialog.alert('The selected advisor is not authorized to view the details of this client. You may need to select a different advsior before continuing.');
                }
            }
            else {
                Spinner.show();
                DataService.getClientgroupLocal(this.clientSearchEventModel.get('selectedclient')).then(gotoResortGroups).fail(gotoResortGroupError);
                function gotoResortGroups(clientGroups) {
                    var sortedGroup = that.sortClientGroup(clientGroups.results[0], e.currentTarget.id);//Sort logic
                    that.populateGroupMembers(sortedGroup);
                    $("#afinav-household-grp > li").removeClass('open');
                    if ($(".modal-backdrop").hasClass('in')) { that.openModal(false); }
                    Spinner.hide();
                    Analytics.analytics.recordAction("ChangeHouseholdGroup:clicked");
                };
                function gotoResortGroupError(Error) {
                	Spinner.hide();
                	ErrorLog.ErrorUtils.myError(Error);
                };
            }
        },
        stopPropagation: function (e) {
            e.preventDefault();
            e.stopPropagation();
        },
        hidetypeahead: function (e) {
            var that = this;
            if ($('.typeahead.dropdown-menu').is(":visible"))
                $('.typeahead.dropdown-menu').hide();
            //if ($(".modal-backdrop").hasClass('in')) that.openModal(false);
            //that.navContactSearch(e);
            if ($('#contact-search-div').is(":visible") && e.currentTarget.id == "afinav-obo-list") {
                $("#contact-search-div").hide();
            }

            //Execute only for tablet
            that.adjustMenuInTablet();
            if ($('#pt-calendar-user-picker-list').is(":visible")) {
                $('#pt-calendar-user-picker-list').slideUp();
            }
            //that.showFirstVisibleMenuItems();
        },
        adjustMenuInTablet: function() {
            //For only Tablet portrait and landscape modes
            var ww = window.innerWidth;
            if (ww >= 768 && ww <= 1024) {
                $("#nav-megamenu-modal .modal-dialog").css("width", "97%");
            }
        },
        showFirstVisibleMenuItems:function() {
            if ($('.nav-menu-sec-header').length > 0) {
                if ($('.nav-menu-main-sec1').is(':visible')) {
                    $('.nav-menu-sec-header [data-target="client-tools"]').removeClass('expand-icon').addClass('collapse-icon');
                    $('.nav-menu-links-container.client-tools').removeClass('hidden-xs');
                } else {
                    $('.nav-menu-sec-header [data-target="my-tools"]').removeClass('expand-icon').addClass('collapse-icon');
                    $('.nav-menu-links-container.my-tools').removeClass('hidden-xs');
                }
            }
        },
        toggleMenus: function (e) {
            var that = this;
            if ($('#right-menu-collapse').hasClass('in')) $('#right-menu-collapse').removeClass('in');
            $('#afinav-left-menu-box .dropdown, #obo-drop-box .dropdown, #afinav-household-grp .dropdown').on('hidden.bs.dropdown', function () {
                if ($(".modal-backdrop").hasClass('in')) that.openModal(false);
            })
        },
        toggleDropDown: function (e) {
            e.preventDefault();
            e.stopPropagation();
            $('#afinav-obo-list').next(".dropdown-menu").toggle();
            this.hidetypeahead();
        },
        opencalendar: function (e) {
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
        	var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;

            //When user role is isNonCMuser/AAC, on click of Home Logo need to redirect to Client List
        	if (userRoles && (_isNonCMuser || userRoles.indexOf("aac") > -1)) {
        	    //When user clicks on Calendar link in MegaMenu
        	    if (e.currentTarget.className == 'calendar') {
        	        CommonUtilis.toggleNonCMmsg("function");
        	        return;
        	    }
        	    Backbone.history.navigate('navigator/contactlist', true);
        	} else {
        	    practicetech.modules.tasks = new practicetech.createNew.module();
        	    Backbone.history.navigate('crm/', true);
        	}
        },
        opencontactlist: function (e) {
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            Backbone.history.navigate('navigator/contactlist', true);
        },
        openprospectlist: function (e) {
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                $('.modal-backdrop').click();
                CommonUtilis.toggleNonCMmsg("function");
                return;
            } else {
                Backbone.history.navigate('navigator/prospectlist', true);
            }
        },
        opendrafts: function (e) {
            e.preventDefault();
            this.toggleMenus();
            Backbone.history.navigate('navigator/draftspage', true);
        },
        contactprofileclick: function (e) {
            e.preventDefault();
            if (_self.clientSearchEventModel.get('selectedcontacttype') == "client") {
            	_self.hideMegamodal();
                Backbone.history.navigate('contactprofile/', true);
            }
            else if (_self.clientSearchEventModel.get('selectedcontacttype') == "nonclient") {
            	_self.hideMegamodal();
                Backbone.history.navigate('contactprofile/', true);
            }
            else {
            	BootstrapDialog.alert("Client or Prospect is not yet selected");
            }

        },
        navigateToNCST: function (e) {
        	Analytics.analytics.recordAction('externalTools:newClientSetup:clicked');
        	CommonUtilis.writeCookie('nocontextlaunch',true);
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            Backbone.history.navigate('ncst/', true);
        },
        launchTaskList:function(){
        	 this.toggleMenus();
             this.hideMegamodal();
             var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
             if (_isNonCMuser) {
                 CommonUtilis.toggleNonCMmsg("function");
                 return;
             } else {
                 Backbone.history.navigate('crm/tasks', true);
             }
        },
        advisorclick: function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (e.currentTarget.textContent != "OBO currently not available") {
                $('.afinav-obo-user').text($(e.currentTarget).text());
            }
            
            //$('.form-group').html($(e.currentTarget).text());
            $('#search').val('');
            //Clearing Dynamic search settings
            this.setClientSelectedAlways();
            console.log("Advisor Removed Event triggered - advisorclick - 111");
            this.clientSearchEventModel.set({ selectedclient: undefined, selectedclientgroups: undefined,selectedcontacttype: undefined, triggeredevent: "AdvisorSelected" }, { "silent": true });
            if(CommonUtilis.readCookie('FMID') != e.currentTarget.id){
            	ContactDetailsModel.advsiorContacts.clearContacts(e.currentTarget.id,true);
            	ContactDetailsModel.advsiorContacts.clearSearchType(e.currentTarget.id);
            	console.log("Advisor Selected (OBO) Event triggered - advisorclick - 222");
            	this.clientSearchEventModel.set({ selectedadvisor: e.currentTarget.id, isOBO:true, triggeredevent: "AdvisorSelected" });
            } else {
                console.log("Advisor Selected Event triggered - advisorclick - 333");
            	this.clientSearchEventModel.set({ selectedadvisor: e.currentTarget.id, triggeredevent: "AdvisorSelected" });
            }
            $("#afinav-obo-menu li").removeClass("nav-obo-highlight");
            $(e.currentTarget).addClass("nav-obo-highlight");
            this.openModal(false);
            if($("#afinav-obo-menu, #oboSearchbox").is(":visible")) {
                $("#afinav-obo-menu, #oboSearchbox").hide();
                //For Dynamic OBO Height
                //that.rembodystyle();
            }
            //$('#afinav-obo-list').next(".dropdown-menu").toggle(); in textbox focus its hidden
        },
        accntviewclick: function (e) {
            Analytics.analytics.recordAction('Accounts:mega-menu:clicked');
            e.preventDefault();
            if (_self.clientSearchEventModel.get('selectedcontacttype') == "client") {
            	_self.hideMegamodal();
                Backbone.history.navigate('accountviewer/', true);
            }
            else if (_self.clientSearchEventModel.get('selectedcontacttype') == "nonclient") {
            	BootstrapDialog.alert("This is Non Client and no account information available");
            }
            else {
            	BootstrapDialog.alert("No Client is selected");
            }
        },
        contextwithDevice: function (linkName, linkURL, e) {
        	Spinner.show();
        	var self = this;
        	var _url = linkURL;
        	var _contextId = null;
        	var _v2Compatible = true;
        	var async = false;
        	if (linkName == "confidentRetirement") {
        		var contextResult = {
        			putAdvsSessCntxAcctIds: null,
        			putAdvsSessCntxClIds: null,
        			putAdvsSessCntxDstrIds: null,
        			putAdvsSessCntxGrpIds: null
        		};
        		var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
        		var _dstrCtx = {
        			dstrId: _gContext.AdvisorFMID,
        			dstrCtx: "DMU.DIST"
        		};
        		contextResult.putAdvsSessCntxDstrIds = [_dstrCtx];
        	} else if (linkName == "totalviewWithOBO") {
				var contextResult = {
        			putAdvsSessCntxAcctIds : null,
        				putAdvsSessCntxClIds: null,
        				putAdvsSessCntxDstrIds: null,
        				putAdvsSessCntxGrpIds: null
        		};
        		var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
        		var _dstrCtx = {
        		dstrId: _gContext.AdvisorFMID,
        			dstrCtx: "DMU.DIST"
        		};
        		contextResult.putAdvsSessCntxDstrIds =[_dstrCtx];
				if (_v2Compatible) {
        			contextResult.clCntxIdTypCd = "IDs";
				}
        	}else if (linkName == "portfolio" || linkName == "portfolio2") {
					var contextResult = {
						putAdvsSessCntxAcctIds: null,
						putAdvsSessCntxClIds: null,
						putAdvsSessCntxDstrIds: null,
						putAdvsSessCntxGrpIds: null
        		};
        		if (_v2Compatible) {
        			contextResult.clCntxIdTypCd = "IDs";
        		}
        		var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
        		var _dstrCtx = {
        		    dstrId: _gContext.AdvisorFMID,
        		    dstrCtx: "DMU.DIST"
        		};
        		contextResult.putAdvsSessCntxDstrIds = [_dstrCtx];
        		var _clientId = _gContext.ContactId;
        		var _clientCtx = {
        				clId: _clientId,
        				clCtx: "COLA.CL",
        				clRole: "PrimaryClient"
        		};
        		contextResult.putAdvsSessCntxClIds = [_clientCtx];
        	} else if (linkName == "totalviewTab" || linkName == "naviplan" || linkName == "contactservice") {
        		var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext, true);
        	} else {
				var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
			}
			DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
            	Spinner.hide();
            	if (response && response.d) {
            		_contextId = response.d.cntxId;
            		_url = _url +_contextId;
            		window.open(_url, linkName).focus();
            	} else {
            		ErrorLog.ErrorUtils.myError(response);
			}
			}).fail(self.genericServiceErrorHandler);
				e.preventDefault();
				this.toggleMenus();
				this.hideMegamodal();
        },
        contactServiceLink: function (e) {
        	var self = this;
        	Analytics.analytics.recordAction('ContactService:mega-menu:clicked');
        	var _url = Config.contactServiceOBOURL;
        	self.contextwithDevice("contactservice", _url, e);
        },
        dolImpactDashboardLink: function (e) {
        	Analytics.analytics.recordAction('DolImpactDashboard:mega-menu:clicked');
        	var url = Config.dolImpactDashboardURL;
        	var that = this;
        	Device.operatingSystem();
        	Device.physicalDevice();
        	Device.browser();
        	var _deviceInfo = Device.info;
        	var _deviceType = _deviceInfo.hardware.make;
        	if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
        	    CommonUtilis.checkVPN(loadHandler, errorHandler);
        	} else {
        	    BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
        	    e.preventDefault();
        	    that.toggleMenus();
        	    that.hideMegamodal();
        	    return;
        	}

        	function errorHandler() {
        	    //evt.preventDefault();
        	    that.toggleMenus();
        	    that.hideMegamodal();
        	    BootstrapDialog.alert("This functionality is only available when using an internal network or VPN.", null, "Function unavailable");
        	}

        	function loadHandler() {
        	    //evt.preventDefault();
        	    that.toggleMenus();
        	    that.hideMegamodal();
        	    window.open(url);
        	}
        },
        confidentretirementclick: function (e) {
        	var self = this;
        	Analytics.analytics.recordAction('ConfidentRetirement:mega-menu:clicked');
			Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) || (_deviceInfo.os.type.indexOf('ios') !== -1 && _deviceType == "iPad" && _deviceInfo.browser.name === 'safari')) {
            	var advisorId = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
            	var fmid = CommonUtilis.readCookie('FMID');
            	if (advisorId == fmid) {
					var _url = Config.confidentRetirementNoOBOURL;
					window.open(_url);
					e.preventDefault();
					this.toggleMenus();
					this.hideMegamodal();
            	} else {
					var _url = Config.confidentRetirementOBOURL;
					self.contextwithDevice("confidentRetirement", _url, e);
            	}            	
            } else {
				BootstrapDialog.alert("This functionality is not available with your browser and device combination.", null, "Function unavailable");
				e.preventDefault();
				this.toggleMenus();
				this.hideMegamodal();
				return;
        	}
        },
        shareDocumentToDoLink: function (e) {
        	var self = this;
        	var targetLink = e.target.id;
        	if (targetLink == 'share-documents') {
        		Analytics.analytics.recordAction('ShareDocument:mega-menu:clicked');
        	}
        	if (targetLink == 'share-to-dos') {
        		Analytics.analytics.recordAction('ShareToDo:mega-menu:clicked');
        	}
			Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface") && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.shareDocumentToDoURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext, true);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        if (targetLink == 'share-documents') {
                            _url = _url + _contextId + '&PAGETYPE=DocumentVault';
                        }
                        if (targetLink == 'share-to-dos') {
                            _url = _url + _contextId + '&PAGETYPE=ToDos';
                        }
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                    }
				}).fail(self.genericServiceErrorHandler);
					e.preventDefault();
					this.toggleMenus();
					this.hideMegamodal();
			} else {
					BootstrapDialog.alert("This functionality is not available with your browser and device combination.", null, "Function unavailable");
					e.preventDefault();
					this.toggleMenus();
					this.hideMegamodal();
					return;
			}
		},
    	naviplanLink: function (e) {
			var self = this;
			Analytics.analytics.recordAction('Naviplan:mega-menu:clicked');
			Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
        	if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
				var _url = Config.naviplanURL;
				self.contextwithDevice("naviplan", _url, e);
        	} else {
					BootstrapDialog.alert("This functionality is not available with your browser and device combination.", null, "Function unavailable");
					e.preventDefault();
					this.toggleMenus();
					this.hideMegamodal();
					return;
			}
		},
        portfolioclick: function (e) {
			var self = this;
			Analytics.analytics.recordAction('portfolioManager:mega-menu:clicked');
			var _url = Config.portfolioURL;
			self.contextwithDevice("portfolio", _url, e);
        },
        portfolio2click: function (e) {
			var self = this;
			Analytics.analytics.recordAction('portfolioManager2:mega-menu:clicked');
			var _url = Config.portfolio2URL;
			self.contextwithDevice("portfolio2", _url, e);
			},
        totalviewclick: function (e) {
        	var self = this;
        	Analytics.analytics.recordAction('total-view:mega-menu:clicked');
            Spinner.show();
			var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
        	var _clientId = _gContext.ContactId;
        	var advisorId = _gContext.AdvisorFMID;
			var fmid = CommonUtilis.readCookie('FMID');
        	var totalviewRegister = "";

			DataService.getClientOnlineAccessPreference(_clientId).then(function (result) {
        		Spinner.hide();
        		var collection = result[0].results;
        		if (collection && collection.length > 0) {
        			$.each(collection, function (key, row) {
        				if (row.status === "Active" && row.rsrcCd === "CE") {
        					totalviewRegister = "yes";
        				}
        			});
        		}
        		if (totalviewRegister == "yes") {
        			var _url = Config.totalviewURL;
        			self.contextwithDevice("totalviewTab", _url, e);
        		} else {
        			if (advisorId == fmid) {
						var _url = Config.totalviewNoOBOURL;
						window.open(_url);
						e.preventDefault();
						this.toggleMenus();
						this.hideMegamodal();						
					} else {
						var _url = Config.totalviewURL;
        				self.contextwithDevice("totalviewWithOBO", _url, e);
						
					}
        		}
				}).fail(function (err) {
                Spinner.hide();
			});


			/*var _url = Config.totalviewURL;
			self.contextwithDevice("totalviewTab", _url, e);*/
        },
        teamingclick: function (e) {
            Analytics.analytics.recordAction("externalTools:practiceRelationshipManager:clicked");
            e.preventDefault();
            this.hideMegamodal();
            var teamingURL = Config.teamingURL;
            window.open(teamingURL);
        },
        	getAdvFMID : function(){
        	var advFMID = this.clientSearchEventModel.get('selectedadvisor');
            if(this.contactSearchType == "nonclient" && GlobalContext.getInstance().getGlobalContext().Context.IsOBO == true){
            	advFMID = CommonUtilis.readCookie('FMID');
        	}
            return advFMID;
        },
        	tanyclick: function (e) {
            Analytics.analytics.recordAction('AmeripriseBrokeragePlatform:clicked');
        	var ABPMobileWindow  = CommonUtilis.getABPMobileWindow();
            e.preventDefault();
            var that = this;
            this.hideMegamodal();
            var _url = Config.t1URL;
            var _options = {
                "strAccNum": "",
                "strTabId": "",
                "strThomledId": "",
                "strRefreshThomletId": 123,
        	}
            CommonUtilis.launchThomsonSmart(_options, openT1Link);
        		function openT1Link() {
                if (ABPMobileWindow) { ABPMobileWindow.close(); }
                ABPMobileWindow = window.open(_url); CommonUtilis.setABPMobileWindow(ABPMobileWindow);
        	}
        },

        	boxforampfclick: function (e) {
        	Analytics.analytics.recordAction('externalTools:boxForAmeriprise:clicked');
            e.preventDefault();
            var that = this;
            this.hideMegamodal();
            var boxurl = Config.boxURL;
            window.open(boxurl, "boxforampfTab");
        },
        mmsysytemclick: function (e) {
        	Analytics.analytics.recordAction('externalTools:moneyMovementSystem:clicked');
            e.preventDefault();
            var that = this;
            this.hideMegamodal();
            var mmsysytemurl = Config.mmsystemURL;
            window.open(mmsysytemurl, "mmsysytemTab").focus();
        },
        ppavpnlink: function (e) {
            Analytics.analytics.recordAction('externalTools:ppaVPNlink:clicked');
            var vpnCheckURL = Config.getConfigProperty("dnsPreCheckVPNLink");
            var url = Config.getConfigProperty("ppaReportLink");
            //var cachetimestamp = new Date();
            var that = this;

            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
                //var imgObj = CommonUtilis.checkVPN(vpnCheckURL);
                //imgObj.onload = loadHandler;
                //imgObj.onerror = errorHandler;
                loadHandler();
            } else {
            	BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
				e.preventDefault();
                that.toggleMenus();
                that.hideMegamodal();
				return;
            }

            function errorHandler(evt) {
                //evt.preventDefault();
                that.toggleMenus();
                that.hideMegamodal();
                BootstrapDialog.alert("This functionality is only available when using an internal network or VPN.", null, "Function unavailable");
            }

            function loadHandler(evt) {
                //evt.preventDefault();
                that.toggleMenus();
                that.hideMegamodal();
                window.open(url);
            }
        },
        smartpadclick: function (e) {
            e.preventDefault();
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                this.toggleMenus();
                this.hideMegamodal();
                CommonUtilis.toggleNonCMmsg("function");
                return;
            } else {
                var that = this;
                if (this.clientSearchEventModel.get('selectedcontacttype') == "client") {
                    Spinner.show();
                    DataService.getContactDetailsbyClientId(CommonUtilis.readCookie('FMID'), this.clientSearchEventModel.get('selectedclient'))
                    .then(function (response) {
                        Spinner.hide();
                        if (response && response[0].attributes && response[0].attributes.contactId) {
                            that.hideMegamodal();
                            Backbone.history.navigate('#crm/smartpad', true);
                        } else {
                            BootstrapDialog.alert("This client cannot be found in Contact Manager. The client might not have an active account or might be hidden. <a href='https://www.askameriprise.com/app/answers/detail/a_id/26890/kw/client%20not%20in%20contact%20manager' target='_blank'>Tell me more.</a>", "", "Client not found");
                        }

                    })
                    .fail(function (error) {
                        Spinner.hide();
                        ErrorLog.ErrorUtils.myError(error);
                    });
                } else {
                    that.hideMegamodal();
                    Backbone.history.navigate('#crm/smartpad', true);
                }
            }
        },
        	hocInsightsclick: function(e){
        	e.preventDefault();
            var that = this;
            that.hideMegamodal();
            Analytics.analytics.recordAction('InsightFromMegamenu:clicked');
            Backbone.history.navigate("hoc/", true);
        },
        	eventTriggered: function (eventmodel) {
        		// var that = this;
            switch (eventmodel.get('triggeredevent')) {
                case 'AdvisorSelected':
                    DataService.clearCacheManager(Constants.subAppName.ContactProfile);
                    var _gContext = GlobalContext.getInstance().getGlobalContext().Context, _gContextClId = _gContext.ContactId, _gContextAdvId = _gContext.AdvisorFMID, _newAdvId = eventmodel.get('selectedadvisor');
                        //condition to check false reset of Global context in deeplink mode
                    if (_gContextAdvId == _newAdvId && _gContextClId && _gContext.QueryString) {
                        console.log("False triggering of Advisor Selected Event blocked");
                        console.log(JSON.stringify(_gContext), "Context Information >> Home JS - AdvisorSelected event false trigger ");
                        //do not trigger any events if same advisor id trying to set to the global context if there is an contactId already there in G Context - only in deeplink mode
                         var _customLog = {
                            "message": "CV Deeplink eternal spinner custom log - Not an Error",
                            "stack": {
                                "description" : "This is not an error, this is for debugging and analysis purpose. This log is related to the CV deeplink to AM eternal spinner issue."
                                }
                            }
                        ErrorLog.ErrorUtils.myError(_customLog, true);
                        return;
                    } 
                   (typeof practicetech !== 'undefined' && typeof practicetech.modules !== 'undefined' && typeof practicetech.modules.contactprofile !== 'undefined' && typeof practicetech.modules.contactprofile.state !== 'undefined') ? practicetech.modules.contactprofile = { } :"";
                  
                    $('#contact-nav').hide();
                    $('.desk-tab-client-name a').empty();
                    $('.desk-tab-client-name-csr a').empty();
                    console.log("Advisor Selected Event Home - Global Context Change>>>>>>>>>>>>>>>>>>>");
                    this.globalContext.setContext(eventmodel.get('selectedadvisor'), eventmodel.get('isOBO'), undefined, undefined, undefined, undefined); //set Advsior context to the global context
                    this.populateClientList(eventmodel.get('selectedadvisor'));
                    this.changeClientsCource();
                    if ($("#afinav-obo-menu").is(":visible")) {
                        if ($("#search-field-box").hasClass("hidden")) {
                            $("#search-field-box, .nav-mobile-search, .desk-tab-client-name").toggleClass("hidden");
                    }
                        if ($("#search-field-box-csr").hasClass("hidden")) {
                            $("#search-field-box-csr, .nav-mobile-search-csr, .desk-tab-client-name-csr").toggleClass("hidden");
                    }
                }
                    if ($("#oboSearchbox").is(":visible")) {
                        $("#oboSearchbox").hide();
                } /*else {
                        $("#oboSearchbox").show();
                    }*/
                    setTimeout(function() {
                    	if(_self.params && _self.params.contactId && _self.params.contactType) {
                        	_self.clientSearchEventModel.set({ selectedclient: _self.params.contactId, selectedcontacttype: _self.params.contactType, triggeredevent: "ClientSelected"
                    	});
                        	_self.params = {};
                    }
                    },1000);
                    
                    
                    break;
                case 'ClientSelected':
                    (typeof practicetech !== 'undefined' && typeof practicetech.modules !== 'undefined' && typeof practicetech.modules.contactprofile !== 'undefined' && typeof practicetech.modules.contactprofile.state !== 'undefined') ? practicetech.modules.contactprofile = {} : "";
                    $('#contact-nav').hide();
                    this.selContactDetails = ContactDetailsModel.advsiorContacts.getSelectedContactDetails(this.getAdvFMID(), this.clientSearchEventModel.get('selectedclient'), this.contactSearchType);
                    $('#afinav-client-name').empty();
                    $('#search').val("");
                    if ($('#search-csr')) { $('#search-csr').val(""); }
                    if (this.selContactDetails != undefined) {
                        
                    	var name = this.selContactDetails.orgNm != null ? this.selContactDetails.orgNm : ((this.selContactDetails.firstNm !== null && this.selContactDetails.firstNm.length > 0) ? this.selContactDetails.lastNm + ", " + this.selContactDetails.firstNm : this.selContactDetails.lastNm);
                    	$('#afinav-client-name').html(name);
                    	$('.desk-tab-client-name a').html(name);
                    	$('.desk-tab-client-name-csr a').html(name);
                    	$('#search').val(this.selContactDetails.orgNm != null ? this.selContactDetails.orgNm : this.selContactDetails.lastNm + ", " + this.selContactDetails.firstNm + ", " + this.selContactDetails.id.slice(-9));
                    	if ($('#search-csr')) {
                    	    $('#search-csr').val(this.selContactDetails.orgNm != null ? this.selContactDetails.orgNm : this.selContactDetails.lastNm + ", " + this.selContactDetails.firstNm + ", " + this.selContactDetails.id.slice(-9));
                    }
                }
                    if (this.clientSearchEventModel.get('selectedcontacttype') == Constants.contactType.Client) {
                        console.log("ClientSelected Event Home - Global Context Change>>>>>>>>>>>>>>>>>>>", eventmodel.get('selectedclient'));
                       this.globalContext.setContext(eventmodel.get('selectedadvisor'), undefined, eventmodel.get('selectedclient'), this.clientSearchEventModel.get('selectedcontacttype'), undefined, undefined); //set Client context to the global context
                    	//  this.populateClientGroup(eventmodel.get('selectedclient'));
                        $("#afinav-household-grp > li").show();
                        $("#afinav-left-menu-box").removeClass('inc-margin-left');
                    }
                    else {
                        $('#contact-nav').show();
                    	//$("#practicetech-subapp").css("margin-top", "30px");
                        $("#afinav-household-grp > li").hide();
                        $("#afinav-left-menu-box").addClass('inc-margin-left');
                        console.log("ClientSelected(for prospects) Event Home - Global Context Change>>>>>>>>>>>>>>>>>>>", eventmodel.get('selectedclient'));
                        this.globalContext.setContext(eventmodel.get('selectedadvisor'), undefined, eventmodel.get('selectedclient'), this.clientSearchEventModel.get('selectedcontacttype'), undefined, undefined); //set Client context to the global context
                }
                    $("#search").blur();
                    this.setClientSelectedAlways();
                    break;
                case 'ClientGroupSelected':
                    $('#contact-nav').show();
                	//$("#practicetech-subapp").css("margin-top", "30px");
                	// this.globalContext.setContext(eventmodel.get('selectedadvisor'), undefined, eventmodel.get('selectedclient'), Constants.contactType.Client, undefined, eventmodel.get('selectedclientgroups')); //set Client context to the global context                    
                    break;

                default: return;
        	}
			
        },
        	toggleAfinavSubMenus: function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(e.currentTarget).parent().siblings().removeClass('open');
            $(e.currentTarget).parent().toggleClass('open');
        },
        	showMegaMenu: function (e) {
            var _that = this;
        		//     if (this.megamenu !== true) {
                this.megamenu = MegaMenu.create(_that, ContactDetailsModel);
        		//       } else {
        		//        alert('wwerks')
        		//    }
            practicetech.modules.tasks = new practicetech.createNew.module();  

        },

        	rembodystyle: function () {
            $('body').removeAttr('style');
            $("#afinav-master").removeAttr('style');
            $($(".fc-agenda-divider.fc-widget-header").next()[0]).css({ "overflow-y": "auto", "-webkit-overflow-scrolling": "touch" });
        },

        	hideMegamodal: function (e) {
            $("#nav-megamenu-modal").modal('hide');
            $('#afinav-navbar').css('z-index', 1038);
        },
        	noRecordsFound: function (show,msg) {
        	msg = msg || "No records found.";
            if(show) {
                    $("#no-records-found").text(msg).show();
            } else {
                    $("#no-records-found").hide();
        	}
        	},
        	handleContextReadyEvent: function (event) {
        	    var _advsid = event.message;
        	    console.log("Advisor Selected Event triggered -  this event is triigering from deeplink controlwhen conetxt service success- handleContextReadyEvent - home js");
        	    _self.clientSearchEventModel.set({ selectedadvisor: _advsid, triggeredevent: "AdvisorSelected" }, { "silent": true });
        	    _self.populateClientList(_advsid);
            },
        	render: function (fmid) {
        	    try {
        	        A = GlobalContext;
        	        console.log("Home view rendering debugging >>>>>>>>>>>>");
                var that = this;
                var tmpTemplate = _.template(HomeTmpt);
                var oboTemplate = _.template(OBOTmpt);
                var fmid = CommonUtilis.readCookie('FMID');
            	//Spinner.show();

                var clientIDtmpTemplate = _.template(ClientIdhomeTmpt);
                var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
                var _queryParams = CommonUtilis.getUrlParams(GlobalContext.getInstance().getGlobalContext().Context.QueryString);
                var _launchMode = _queryParams["mode"]; 
            	//Defaults - Draw the template with a blank advisor. This solves a rare case where OBO is not present
                that.$el.html(tmpTemplate({ advisors: {} }));
                console.log("Home view context setting debugging >>>>>>>>>>>> Setting logged in advisor context to Global context HOme js render");
                this.clientSearchEventModel.set({ selectedadvisor: fmid, triggeredevent: "AdvisorSelected" }, { "silent": false });
                $('.afinav-obo-user').text((''));
                $("#afinav-obo-list").css({ 'background': 'none', 'padding-top': '20px', 'padding-right': '0px', 'color': '#ffffff', 'cursor': 'default' });
            	// $("#afinav-obo-list").hide();

                $('.afinav-obo-user').text($('#afinav-obo-menu li:eq(0)').text());
                $("#afinav-obo-menu li:eq(0)").addClass("nav-obo-highlight");   
            	//End Defaults
            	function gotoclientSearch(advisors) {
            		/*if (userRoles && userRoles.indexOf("hoc") > -1) {
						$('#hocMegamenuLink, .cp-hoc, #insightDiv').removeClass('hidden');
					};*/
            	    if (userRoles && (userRoles.indexOf("csr") > -1 || userRoles.indexOf("aac") > -1 || userRoles.indexOf("rp") > -1 || userRoles.indexOf("rpdelegates") > -1)) {
            	        var _showClientNameSearch = false;
            	        if (userRoles.indexOf("rp") > -1 || userRoles.indexOf("rpdelegates") > -1) {
            	            _showClientNameSearch = true;
            	        }
            	        that.$el.html(clientIDtmpTemplate({ advisors: advisors.models, "showClientNameSearch": _showClientNameSearch }));
            	        oboCSRList = advisors.models;
            	        var ww = window.innerWidth;
            	        if (!_showClientNameSearch) {
            	            if (ww < 768) {
            	                //$('').hide();
            	                $('#clientIdSearchbox').css('display', 'none');
            	                $('#search-csr,#client-id-gobtn,#search-field-box-csr').addClass('hidden');
            	            }
            	        }
            	        if (userRoles.indexOf("rp") > -1 || userRoles.indexOf("rpdelegates") > -1) {
            	            that.changeClientsCource();
            	        }
                        $('.afinav-obo-user').text((advisors.models[0].get('name')));
                        //that.clientSearchEventModel.set({ selectedadvisor: advisors.models[0].get('fmid'), selectedclient: undefined, selectedclientgroups: undefined, triggeredevent: "AdvisorSelected" });
                    	/*Added temperory for CSR HOC roles*/
                    	//$('#hocMegamenuLink, .cp-hoc, #insightDiv').removeClass('hidden');
        			   
                    } else {
        			            $("#obo-drop-box").html(oboTemplate({ advisors: advisors.models })).promise().done(function () {
        			                $.event.trigger({
        			                		type: "obolistready",
        			                		message: advisors.models,
        			                		time: new Date()
        			            });
                    });
                    	// that.$el.html(oboTemplate({  }));
                    	// that.$el.html(tmpTemplate({ advisors: advisors.models }));
        			            if (advisors.length == 1) {
        			                $('.afinav-obo-user').text((advisors.models[0].get('name')));
        			                $('.afinav-obo-user').text((advisors.models[0].get('name')));
        			                $("#afinav-obo-list").css({ 'background': 'none', 'padding-top': '20px', 'padding-right': '0px', 'color': '#ffffff', 'cursor': 'default' });
        			                $("#afinav-obo-list").hide();
        			            } else {
        			                $('.afinav-obo-user').text($('#afinav-obo-menu li:eq(0)').text());
        			                $("#afinav-obo-menu li:eq(0)").addClass("nav-obo-highlight");
                    }
                    	// that.clientSearchEventModel.set({ selectedadvisor: undefined, selectedclient: undefined, selectedclientgroups: undefined, selectedcontacttype: undefined }, { "silent": true });
                    	// that.clientSearchEventModel.set({ selectedadvisor: advisors.models[0].get('fmid'), selectedclient: undefined, selectedclientgroups: undefined, triggeredevent: "AdvisorSelected" });
                    	// Spinner.hide();
            	}
            };
                DataService.getAdvisorInfo()
                .done(gotoclientSearch).fail(gotoErrorHandler);
                
            	function gotoErrorHandler(resp) {
                	if(resp.data){
                		gotoclientSearch(resp.data);
            	}

            		//$("#obo-drop-box").html(oboTemplate({ advisors: '' }));
                	ErrorLog.ErrorUtils.prepareAndLogError(resp.error, true);
            		//Spinner.hide();
            		// alert(JSON.stringify(resp.error));
            };
            } catch (error) {
                ErrorLog.ErrorUtils.myError(error);
        	}
        },
        	//This will refersh the Typeahead source - ClientList
        	populateClientList: function (fmid) {
            var that = this;
            $('#afinav-household-btn').empty();
            
            if (!ContactDetailsModel.advsiorContacts.isExist(fmid,Constants.contactType.Client)) {
                var asyncCalls = [];
            	//Spinner.show({ inline: true, parentElement: 'nav-search', serachBox: true });
                Spinner.show({ inline: true, parentElement: 'contact-search-div', serachBox: false });

                asyncCalls[0] = DataService.getClients(fmid,Config.contactListLimit,"",[404]);
            	//asyncCalls[1] = DataService.getNonClients(fmid);

                Q.allSettled(asyncCalls).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);
            	function gotoAsyncCallSuccess(result) {
                    var _isContactSearchDynamic = ContactDetailsModel.advsiorContacts.getContactSearchType(fmid);
                    if (result[0].value && result[0].value.status == 404) {
                    	//BootstrapDialog.alert('Client is not available');
                        that.keywordSearchRequired = false;
                        //trigger contactlist ready event only if if isDynamic is undefined
                    	ContactDetailsModel.advsiorContacts.setContactSearchTypeAsDynamic(fmid,false);
                    }
                    else {
                        
                    	if(result[0].value[0] && result[0].value[0]['__count'] && parseInt(result[0].value[0]['__count'])<Config.contactListLimit){
                    		ContactDetailsModel.advsiorContacts.AddContactDetails(fmid, result[0].value[0]['results'], Constants.contactType.Client);
                    		ContactDetailsModel.advsiorContacts.setContactSearchTypeAsDynamic(fmid,false);
                    		that.keywordSearchRequired = false;
                    		ContactDetailsModel.advsiorContacts.setContactSearchTypeAsDynamic(fmid,false);
                    	}else{
                    		that.keywordSearchRequired = true;
                    		/*var contextObj = GlobalContext.getInstance().getGlobalContext().Context;
                    		that.globalContext.setContext(contextObj.AdvisorFMID,contextObj.IsOBO,contextObj.ContactId,contextObj.ContactType,
                    				contextObj.ContactSource,contextObj.GroupId,contextObj.IsStandalone,contextObj.QueryString,true);*/
                    		ContactDetailsModel.advsiorContacts.setContactSearchTypeAsDynamic(fmid,true);
                    }
                    
            	}
                    if (_isContactSearchDynamic === undefined) {
                        $.event.trigger({
                        		type: "contactlistready",
                        		message: { "status": "success" },
                        		time: new Date()
                    });
            	}
            		/*if (result[1].value == undefined) {
                        alert('Non Client is not available');
                    }
                    else {
                        ContactDetailsModel.advsiorContacts.AddContactDetails(fmid, result[1].value[0].get('clientRefs'), Constants.contactType.NonClient);
                    }*/
                    DataService.clearCacheManager(Constants.subAppName.Navigator);
            		//  ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(fmid);                   
            		//Spinner.hide({ inline: true, parentElement: 'nav-search' });
                    Spinner.hide({ inline: true, parentElement: 'contact-search-div' });
            };
            	function gotoAsyncCallError(err) {
                    var _isContactSearchDynamic = ContactDetailsModel.advsiorContacts.getContactSearchType(fmid);
                    if (_isContactSearchDynamic === undefined) {
                        $.event.trigger({
                        		type: "contactlistready",
                        		message: { "status": "error" },
                        		time: new Date()
                    });
                    }
            	    //to handle unauthorized error set it as false on any error
                    that.keywordSearchRequired = false;
            	    //to handle unauthorized error set it as false on any error
                    ContactDetailsModel.advsiorContacts.setContactSearchTypeAsDynamic(fmid, false);
            		//Spinner.hide({ inline: true, parentElement: 'nav-search' });
                    Spinner.hide({ inline: true, parentElement: 'contact-search-div' });
                    $('#afinav-household-btn').empty();
            };
            } else {
            	//set contactsearch type
                that.keywordSearchRequired = ContactDetailsModel.advsiorContacts.getContactSearchType(fmid);
        	}
        },
        	searchClientList: function (fmid,keyWord, process) {
            var that = this;
            var filter = undefined;
        		// if (!ContactDetailsModel.advsiorContacts.isExist(fmid)) {
                if(keyWord){
                	//Spinner.show({ inline: true, parentElement: 'nav-search', serachBox: true });
                    Spinner.show({ inline: true, parentElement: 'contact-search-div', serachBox: false });
                    
                	filter = "startswith(firstNm,'"+keyWord+"') eq true  or startswith(lastNm,'"+keyWord+"') eq true";
                	DataService.getClients(fmid,Config.contactListLimit,filter,[404]).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);
        	}
        		function gotoAsyncCallSuccess(result) {
                	var actualResult = (result[0] && result[0]['results']) ? result[0]['results'] : null;
        			//function to call show/hide contact search tabs / no records found
                	if(!actualResult){
                		that.noRecordsFound(true,"No client records found for the selected advisor.");
                	}else{
                		that.noRecordsFound(((actualResult && actualResult.length >0) ? false : true));
        		}
                    
                	

                    if (result[0]) {
                    	ContactDetailsModel.advsiorContacts.AddContactDetails(fmid, actualResult, Constants.contactType.Client,true);
                    	if(process){
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(fmid,Constants.contactType.Client));
                    }
        		}
                    DataService.clearCacheManager(Constants.subAppName.Navigator);
        			//Spinner.hide({ inline: true, parentElement: 'nav-search' });
                    Spinner.hide({ inline: true, parentElement: 'contact-search-div' });
        	};
        		function gotoAsyncCallError(err) {
        			//Spinner.hide({ inline: true, parentElement: 'nav-search' });
                    Spinner.hide({ inline: true, parentElement: 'contact-search-div' });
        	};
        		//}
        },
        	searchProspectList : function (fmid,keyWord, process) {
            var that = this;
            var filter = undefined;
            Spinner.show({ inline: true, parentElement: 'contact-search-div', serachBox: false });
        		// if (!ContactDetailsModel.advsiorContacts.isExist(fmid)) {
                if(keyWord){
                	//Spinner.show({ inline: true, parentElement: 'nav-search', serachBox: true });
                	DataService.getNonClients(fmid,false,keyWord).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);
        	}
        		function gotoAsyncCallSuccess(result) {
                	var actualResult = result[0].get("clientRefs") || null;
        			//function to call show/hide contact search tabs / no records found
                    that.noRecordsFound(((actualResult && actualResult.length < 1) ? true : false));
                    
                    if(actualResult) {
                    	ContactDetailsModel.advsiorContacts.AddContactDetails(fmid, actualResult, Constants.contactType.NonClient,true);
                    	if(process){
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(fmid,Constants.contactType.NonClient));
                    }
        		}
                    DataService.clearCacheManager(Constants.subAppName.Navigator);
        			//Spinner.hide({ inline: true, parentElement: 'nav-search' });
                    Spinner.hide({ inline: true, parentElement: 'contact-search-div' });
        	};
        		function gotoAsyncCallError(err) {
        			//Spinner.hide({ inline: true, parentElement: 'nav-search' });
                    Spinner.hide({ inline: true, parentElement: 'contact-search-div' });
        	};
        		//}
        },
        	changeClientsCource: function () {
            var that = this;

            $("#search").typeahead({
            		items: 1000,
            		minLength: 3,
            		highlighter: function (items) {
            			//var _navSearchHeight = 390;
            			//var _availheight = window.innerHeight -150;
            			//if (_availheight < _navSearchHeight) {
            			//    $(".typeahead.dropdown-menu").css("max-height", _availheight + "px");
            			//}
            			//else {
            			//    $(".typeahead.dropdown-menu").css("max-height", _navSearchHeight + "px");
            			//}
            			// For Dynamic height of search dropdown
                    var matchSpan = '<span class="highlight">';
                    var leftAlign = '<span class="pull-left clearfix truncate pt-dropdown-client-name">';
                    var rightAlign = '<span class="pull-right clearfix pt-dropdown-client-id">';
                    var endSpan = '</span>';
                    var clientID = '';
                    if (items.indexOf("Contact.") >= 0) {
                        clientName = items.substr(0, items.indexOf("Contact.") - 1);
                        clientID = items.substr(items.indexOf("Contact."));
                    }
                    else {
                        clientName = items.substr(0, items.length - 9);
                        clientID = items.substr(items.length - 8);
            		}
                    var queryclientName = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                    var tmpclientName = clientName.replace(new RegExp('(' + queryclientName + ')', 'ig'), function ($1, match) {
                        return matchSpan + match + '</span>';
            		});
                    var queryclientID = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                    var tmpclientID = clientID.replace(new RegExp('(' + queryclientID + ')', 'ig'), function ($1, match) {
                        return matchSpan + match + '</span>';
            		});

                    if (items.indexOf("Contact.") >= 0) {
                        return leftAlign + tmpclientName + endSpan + '<span id="mySpan" hidden = "hidden">' + clientID + '</span>';
                    }
                    else {
                        return leftAlign + tmpclientName + endSpan + rightAlign + tmpclientID + endSpan + '<span id="contactSpanId" hidden = "hidden">' + clientID + '</span>';
            		}
            },
            		sorter: function (items) {
                	if(items.length === 0){
                		that.noRecordsFound(true);
            		}
                    return items.sort();
            },
            		source: function (query, process) {
            			//process(that.clientsCollection.getModels(that.clientSearchEventModel.get('selectedadvisor')));
                    var serachKey = $("#search").val();
                                        
                    if(serachKey && that.keywordSearchRequired && that.contactSearchType == "client"){
                    	if(serachKey.length>=3 && that.searchInExistingKey(serachKey)){
                    		that.keywordSearch(process);
                    	}else{
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(that.clientSearchEventModel.get('selectedadvisor'),that.contactSearchType));
                    }
                    }else if(serachKey && !that.keywordSearchRequired && that.contactSearchType == "client"){
                    	
                    	var fetchedContacts = ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(that.clientSearchEventModel.get('selectedadvisor'),that.contactSearchType);
                    	
                    	if(fetchedContacts && fetchedContacts.length>0){
                    		process(fetchedContacts);
                    	}else{
                    		that.noRecordsFound(true,"No client records found for the selected advisor.");
                    }
                    }else if(serachKey && that.contactSearchType == "nonclient"){
                    	if(serachKey.length>=3 && that.searchInExistingKey(serachKey)){
                    		that.keywordSearch(process);
                    	}else{
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(that.getAdvFMID(),that.contactSearchType));
                    }
                    }else{
                		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(that.clientSearchEventModel.get('selectedadvisor')));
            		}
            },
            		matcher: function (item) {
                    var queryclientName = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                    if (item.indexOf("Contact.") >= 0) {
                        if (item.substr(0, item.indexOf("Contact.") - 1).search(new RegExp(queryclientName, "i")) != -1) {
                            return true;
                        }
                        else {
                            return false;
                    }
                    }
                    else {
                        if (item.search(new RegExp(queryclientName, "i")) != -1) {
                            return true;
                        }
                        else {
                            return false;
                    }
            		}
            },
            		updater: function (item) {
                    var selContactId = '';
                    var contactType;
                    if (item.indexOf("Contact.") >= 0) {
                        selContactId = item.substr(item.indexOf("Contact."));
                        item = item.substr(0, item.indexOf("Contact."));
                        contactType = Constants.contactType.NonClient;
                        $('#afinav-client-name').html(" " + item + " ");

                    }
                    else {
                        selContactId = ContactDetailsModel.advsiorContacts.getSelectedContactId(that.clientSearchEventModel.get('selectedadvisor'), item, Constants.contactType.Client);
                        contactType = Constants.contactType.Client;
                        $('#afinav-client-name').html(" " + item.substring(0, item.length - 9) + " ");
            		}
                    that.clientSearchEventModel.set({ selectedclientgroups: undefined, triggeredevent: "ClientSelected" }, { "silent": true });
                    that.clientSearchEventModel.set({ selectedclient: selContactId, selectedcontacttype: contactType, triggeredevent: "ClientSelected" });
                    $('.afinav-users, #afinav-household-grp, #afinav-left-menu-box').removeClass('hidden');
                    that.toggleMenus();
                    that.contactSearchTabs();
                    that.togglesearchfields();
            			//$('.desk-tab-client-name').html($("#search").val());
            			//var ww = window.innerWidth;
            			//if (ww < 768) {
            			//    $("#search-field-box").toggleClass("search-tablet-show");
            			//}
            			//if (ww >= 768) {
            			//    $("#search-field-box, .nav-mobile-search, .desk-tab-client-name").toggleClass("hidden");
            			//}
                    
                    if ($.isNumeric(this.query)) {
                    	Analytics.analytics.recordSearch(contactType, 'byID');
                    } else {
                    	Analytics.analytics.recordSearch(contactType, 'byName');
            		}
                    
                    return item;
            }
        	});
        },
        	populateClientGroup: function (clientid) {
            var that = this;
            Spinner.show();
            DataService.getClientgroup(clientid).then(gotoclientGroupSelected);
            $('#clientgroups').empty();
        		function gotoclientGroupSelected(clientGroups) {
                var modifgroup = [];
                var pensionGrp = [];
                if (clientGroups != undefined && clientGroups[0] != undefined && clientGroups[0].attributes.activeGroups[0] != undefined) {
                	//    modifgroup = _.chain(_.pluck(clientGroups[0].results, 'attributes')).value();
                    var asyncGrpMembCallList = [];
                    clientGroups[0].attributes.activeGroups.forEach(
                       function (srtGroup, i) {
                           srtGroup.attributes.sortSecondPriorId = srtGroup.get('fmtId').substr(10, 1).replace(/\s+/g, '');
                           srtGroup.attributes.sortFirstPriorId = srtGroup.get('fmtId').substr(0, 9).replace(/\s+/g, '');
                           srtGroup.attributes.adminCode = srtGroup.get('fmtId').slice(-3).replace(/\s+/g, '');
                           srtGroup.attributes.currClient = clientid;
                });
                    pensionGrp = clientGroups[0].attributes.activeGroups;
                    pensionGrp.forEach(
                        function (groups, i) {
                            if (groups.get('adminCode') != '002') {
                                asyncGrpMembCallList[i] = DataService.getGroupActiveMembers(groups.id);
                        }
                });
                    Q.allSettled(asyncGrpMembCallList).then(gotoclientGroupAcriveMembers).fail(gotoClientGroupActiveMemError);
                	function gotoclientGroupAcriveMembers(groupmem) {
                        clientGroups[0].attributes.activeGroups = _.reject(pensionGrp, function (gp) { return gp.attributes.activeClients.length == undefined && gp.attributes.adminCode != '002' });
                        var sortedGroup = that.sortClientGroup(clientGroups[0]);//Sort logic
                        that.populateGroupMembers(sortedGroup);
                };
                	function gotoClientGroupActiveMemError(err) {
                		// alert(err);
                		//  var e = err;
                };
        		}
                Spinner.hide();
        	};
        		function gotoclientGroupFailed(Error) {
            	Spinner.hide();
            	ErrorLog.ErrorUtils.myError(Error);
        	};
        },
        	sortClientGroup: function (clientgroups, pingrpid) {
            if (pingrpid == undefined) {
                return _(clientgroups.get('activeGroups')).sortBy(
                    function (group) {
                        return [group.get('adminCode'), group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
            });
            }
            else {
                var sortedGrp = _(clientgroups.get('activeGroups')).sortBy(
                function (group) {
                    return [group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
            });
                var movGrp = _.filter(sortedGrp, function (grp, index) {
                    return grp.get('id') == pingrpid;
            });
                var index = sortedGrp.indexOf(movGrp[0]);
                sortedGrp.splice(index, 1);
                sortedGrp.splice(0, 0, movGrp[0]);
                return sortedGrp;
        	}
        },
        	populateGroupMembers: function (sortedGroup) {
        		//var householdGroupTemplate = _.template(HouseholdGroupTemplate);
        		//$('.nav-household').empty().append(householdGroupTemplate);

            var groupTemplate = '';
            var tmpTemplate = _.template(ClientSearchGroupTemplate);
            var tmpHouseHoldTemplate = _.template(ClientSearchGroupHseHoldTemplate);
            $('#afinav-household-btn').text(sortedGroup[0].get('fmtId'));
            $("#search").blur();
            this.clientSearchEventModel.set({ selectedclientgroups: sortedGroup[0].get('id'), triggeredevent: "ClientGroupSelected" }, { "silent": false });
            sortedGroup.forEach(
            function (srtGroup, i) {
                if (srtGroup.get('activeClients')[0] != undefined) {
                    groupTemplate = groupTemplate + tmpTemplate({ group: srtGroup });
                }
                else {
                    groupTemplate = groupTemplate + tmpHouseHoldTemplate({ group: srtGroup });
            }
        	});


            $('#afinav-household-menu').empty().append(groupTemplate);
            if (sortedGroup.length == 1) {
                $("#afinav-household-grp > li").removeClass('open');
            } else {
                $("#afinav-household-grp > li").addClass('open');
            	//Show the customized modal
                if ($('#afinav-household-menu').parent().hasClass('open')) {
                    this.openModal(true);
            }
        	}

            $('#afinav-household-menu').keydown(function (e) {
                if ($(this).is(':visible')) {

                    var menu = $(this);
                    var active = menu.find('ul li:first-child');
                    var height = active.outerHeight(); //Height of <li>
                    var top = menu.scrollTop(); //Current top of scroll window
                    var menuHeight = menu[0].scrollHeight; //Full height of <ul>

                	//Up
                    if (e.keyCode == 38) {
                        if (top != 0) {
                        	//All but top item goes up
                            menu.scrollTop(top - height);
                        } else {
                        	//Top item - go to bottom of menu
                        	//menu.scrollTop(menuHeight + height);
                    }
                }
                	//Down
                    if (e.keyCode == 40) {
                    	//window.alert(menuHeight - height);
                        var nextHeight = top + height; //Next scrollTop height
                        var maxHeight = menuHeight - height; //Max scrollTop height

                        if (nextHeight <= maxHeight) {
                        	//All but bottom item goes down
                            menu.scrollTop(top + height);
                        } else {
                        	//Bottom item - go to top of menu
                            menu.scrollTop(0);
                    }
                }
            }
        	});

        },
        	pinClientAndLauchCP: function (e) {
            Spinner.show();
        		//practicetech.clientContext.setCaplistFullName(null)
            var _target = e.target || e.currentTarget;
            var _clientId = $(_target).data("client-id");
            this.globalContext.clearContact();
            var clientType = ((_clientId.indexOf("Contact.") == -1) ? Constants.contactType.Client : Constants.contactType.NonClient);
            this.clientSearchEventModel.set({ selectedclient: undefined, selectedclientgroups: undefined, triggeredevent: "ClientSelected" }, { "silent": true });
            this.clientSearchEventModel.set({ selectedclient: _clientId, selectedcontacttype: clientType, triggeredevent: "ClientSelected" });
            $('.afinav-users, #afinav-household-grp, #afinav-left-menu-box').removeClass('hidden');
            this.toggleMenus();
        		//$('#search').val("");
            window.scrollTo(0, 0);
        		// Spinner.hide();
        },

        	launchCP: function (e) {
                    console.log("In launchprosprofile");
                    var _target = e.target || e.currentTarget;
                    var contactId = $(_target).data("client-id");
                    if (contactId.indexOf("Contact.") > -1) {
                        ContactType = Constants.contactType.NonClient;
                        ContactType = 'nonclient';
                    } else {
                        ContactType = Constants.contactType.Client;
        	}
                  NavApi.changeContactAndLauchCP(contactId, ContactType);
        },
        	clientViewerLink: function (e) {
            Spinner.show();
                var self = this;
                var _url = Config.getConfigProperty("hocExtrnlActnLinks").acctsuitmisReviewInCV;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId ;
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            Analytics.analytics.recordAction('client-viewer:mega-menu:clicked');
        },
        onlineFileManagerLink: function (e) {            
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.getConfigProperty("beneOFMLink");
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
            Analytics.analytics.recordAction('onlineFileManagerLink:mega-menu:clicked');
        },
        	statusManagerLink: function (e) {
            Spinner.show();
            var self = this;
            var _url = Config.getConfigProperty("hocExtrnlActnLinks").nigoopnReviewInSM;
            window.open(_url);
            Spinner.hide();
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            Analytics.analytics.recordAction('Status-manager:mega-menu:clicked');
        },
        	technicalSupportLink: function (e) {
             Spinner.show();
            var self = this;
            var _url = Config.technicalSupportURL;
            window.open(_url);
            Spinner.hide();
            e.preventDefault();
            this.toggleMenus();
            this.hideMegamodal();
            Analytics.analytics.recordAction('Technical Support:mega-menu:clicked');
        },
        	contactManagerLink: function (e) {
            Analytics.analytics.recordAction('contactManagerLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.contactManagerURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}

        },
        	efileDeliveryLink: function (e) {
            Analytics.analytics.recordAction('efileDeliveryLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.efileDeliveryURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
        },
        	eformsManagerLink: function (e) {
            Analytics.analytics.recordAction('eformsManagerLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.eformsManagerURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
        },
        	newBusinessSetupLink: function (e) {
            Analytics.analytics.recordAction('newBusinessSetupLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.newBusinessSetupURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
        },
        	opportunityManagerLink: function (e) {
            Analytics.analytics.recordAction('opportunityManagerLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.opportunityManagerURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
        },
        	shareClassAnalyzerLink: function (e) {
            Analytics.analytics.recordAction('shareClassAnalyzerLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.shareClassAnalyzerURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
        },
        	mstarAdvisorWsLink: function (e) {
            Analytics.analytics.recordAction('mstarAdvisorWsLink:mega-menu:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.morningstarAdvisorWorkstationURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtilis.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                _contextId = response.d.cntxId;
                _url = _url + _contextId ;
                window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(self.genericServiceErrorHandler);           
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
            }   else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                this.toggleMenus();
                this.hideMegamodal();
                return;
        	}
        },
    });
    return homeView;
});
