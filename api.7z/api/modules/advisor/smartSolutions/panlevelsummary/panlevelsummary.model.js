// panLevelSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var panLevelSummarySchema = new mongoose.Schema({
    panLevelSummary: {
        type: Array,
        "default": []
    }
});

var panLevelSummaryLookUp = mongoose.model('panLevelSummaryLookUp', panLevelSummarySchema);

var panLevelSummaryModel = new panLevelSummaryLookUp({
    "panLevelSummary":{
  "investmentSummary": [
    {
      "folioId": "18137383",
      "isFsType": true,
      "rows": [
        {
          "accountNo": "2019905367101",
          "scheme": "Franklin India Flexi Cap Fund - Growth",
          "totalUnits": "692.168",
          "currentCost": "33477.12",
          "currentValue": "116102.46",
          "returns": "null",
          "goal": "Retirement"
        },
        {
          "accountNo": "1049905367101",
          "scheme": "Franklin India Short Term Income Plan -  Retail Plan - Growth",
          "totalUnits": "7.799",
          "currentCost": "21003.44",
          "currentValue": "24409.75",
          "returns": "null",
          "goal": "Retirement"
        }
      ],
      "modeofHolding": "ANYONE OR SURVIVOR",
      "holders": [
        {
          "name": "ANITA NIMMA GADDA B DAVE MEGHANT",
          "pan": "AFPL10258F3",
          "kycStatus": "",
          "kycSource": null,
          "modeOfKyc": null,
          "aadharNo": null,
          "balAmount": null,
          "type": "Firstholder"
        },
        {
          "name": "ROHAN G THAKKAR DIPAK MORE S SUSIWALA",
          "pan": "AFPL10258F4",
          "kycStatus": "",
          "kycSource": null,
          "modeOfKyc": null,
          "aadharNo": null,
          "balAmount": null,
          "type": "Secondholder"
        }
      ],
      "grandTotal": {
        "totalUnits": "699.96704",
        "folioId": null,
        "account": "GRAND TOTAL",
        "currentValue": "140512.22",
        "currentCost": "54480.562"
      }
    },
    {
      "folioId": "17921689",
      "isFsType": false,
      "rows": [
        {
          "accountNo": "0389904937491",
          "scheme": "Franklin India Bluechip Fund - Growth",
          "totalUnits": "45.575",
          "currentCost": "15216.10",
          "currentValue": "17224.85",
          "returns": "null",
          "goal": "Wealth Creation"
        }
      ],
      "modeofHolding": "Single",
      "holders": [
        {
          "name": "ANITA NIMMA GADDA B DAVE MEGHANT",
          "pan": "AFPL10258F5",
          "kycStatus": 'KYC Registered',
          "kycSource": null,
          "modeOfKyc": null,
          "aadharNo": null,
          "balAmount": null,
          "type": "Firstholder"
        }
      ],
      "grandTotal": {
        "totalUnits": "45.575",
        "folioId": null,
        "account": "GRAND TOTAL",
        "currentValue": "17224.85",
        "currentCost": "15216.1"
      }
    }
  ]
}
});

panLevelSummaryLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating panLevelSummaryLookUp table, please contact admin...');
    } else {
        panLevelSummaryLookUp.remove({}, function(err) {
            console.log('panLevelSummaryLookUp collection removed');
            panLevelSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating panLevelSummaryLookUp table, please contact admin...');
                }
                console.log('panLevelSummaryLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = panLevelSummaryLookUp;
