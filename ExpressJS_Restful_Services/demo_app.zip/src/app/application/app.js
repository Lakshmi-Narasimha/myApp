define([
    'jquery',
    'lodash',
    'app/common/util',
], function ($, _, util){

    var Application = function () {
        this.appView = null;
        //this.userInformation = {};
        this.start = function () {
            var self = this;
            require(['app/application/views/AppView', 'app/application/router', 'app/services/awmService'], function (AppView, router, awmService) {
                const params = util.getUrlParams() || {};
                const contextId = params.context || null;
                console.log('contextId:'+contextId);

                if(contextId){
                   awmService.promiseToGetInterAppContext(contextId).then(data => {
                        data = data.toJSON();
                        console.log(data);
                        app.selOboId = data.fmid;
                        app.selClientId = data.clientIds[0];
                    });
                }
                self.appView = new AppView();
				self.appView.initiateAppRouter = function() {
					router.start();
                };
                self.appView.render();
            });
        };
    };
    var app =  new Application();
    return app;
});
