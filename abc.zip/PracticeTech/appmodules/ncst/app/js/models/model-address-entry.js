define([ 'jquery', 'underscore', 'backbone','backboneRelational','appmodules/ncst/app/js/lib/validate-4.2','appmodules/ncst/app/js/models/model-client-details','appmodules/ncst/app/js/models/model-new-client' ], 
		function($, _, Backbone, backboneRelational, Validator,ClientDetailsModel,newClientModel) {
	var _self = null;
	var _addressModelClass = Backbone.RelationalModel.extend({
		defaults : {
			'type' : 'Permanent',
			'primaryAddress' : {
				uAddressLine1 : '',
				uAddressLine2 : '',
				uCity : '',
				uState : '',
				uZip : '',
				uEntAddressLine1 : '',
				uEntAddressLine2 : ''
			},
			'mailingAddress' : {},
			'seperateMailingAddress' : false,
			'fromBack' : false,
			'clientAddressCheck' : false,
			'mailClientAddressCheck' : false,
			'validAddr' : false,
			'mailValidAddr' : false,
			'stdAddressLine1' : '',
			'stdAddressLine2' : '',
			'stdAddressLine3' : '',
			'stdCountry' : '',
			'stdCity' : '',
			'stdState' : '',
			'stdZip' : '',
			'mStdAddressLine1' : '',
			'mStdAddressLine2' : '',
			'mstdAddressLine3' : '',
			'mStdCountry' : '',
			'mStdCity' : '',
			'mStdState' : '',
			'mStdZip' : ''
		},
		initialize :function(){
			_self = this;
		},
		validate : function() {
			var _proceed = true;
			if (!Validator.validateInputs('address-entry')) {
				_proceed = false;
			} else {
				if (Validator.checkforMandatoryFields('address-entry')) {
					ClientDetailsModel.set('addrEntryValid', true);
				} else {
					ClientDetailsModel.set('addrEntryValid', false);
				}
			}
			return _proceed;
		},
		setModel : function() {
			var _adressEntryoForm = $('#address-entry');
			var _addressType = _adressEntryoForm.find(
					'input[name="aeAddressType"]:checked').val();
			var _addL1 = $('#address-line1').val();
			var _addL2 = $('#address-line2').val();
			var _addL3 = $('#address-line3').val();
			var _eAddL1 = $('#ent-address-line1').val();
			var _eAddL2 = $('#ent-address-line2').val();
			var _eAddL3 = $('#ent-address-line3').val();
			var _city = $('#ae-city').val();
			var _state = (_addressType == "Foreign") ? $(
					'#province-list-select').val() : $('#state-list-select')
					.val();
			var _zip = $('#zipcode').val();
			var _country = (_addressType == "Foreign") ? $(
					'#country-list-select').val() : '';
                        var _countryTxt =  (_addressType == "Foreign") ? $('#country-list-select option:selected').text() : '';      
			var _province = (_addressType == "Foreign") ? $(
					'#province-list-select').val() : '';

			var _primaryAddress = {
				'addressType' : _addressType,
				'addressLine1' : _addL1,
				'addressLine2' : _addL2,
				'addressLine3' : _addL3,
				'entAddressLine1' : _eAddL1,
				'entAddressLine2' : _eAddL2,
				'entAddressLine3' : _eAddL3,
				'city' : _city,
				'state' : _state,
				'zip' : _zip,
				'country' : _country,
                                'countryTxt' : _countryTxt,
				'province' : _province,
				'uAddressLine1' : _addL1,
				'uAddressLine2' : _addL2,
				'uAddressLine3' : _addL3,
				'uEntAddressLine1' : _eAddL1,
				'uEntAddressLine2' : _eAddL2,
				'uEntAddressLine3' : _eAddL3,
				'uCity' : _city,
				'uState' : _state,
				'uZip' : _zip,
				'uCountry' : _country,
				'uProvince' : _province
			};
			// if (_primaryAddress['addressType'] == "Foreign") {
			// _primaryAddress['state', ($('#province').val() ? $('#province')
			// .val() : $('#province-list-select').val())];
			// }
			var _mAddL1 = $('#ma-address-line1').val();
			var _mAddL2 = $('#ma-address-line2').val();
			var _mAddL3 = $('#ma-address-line3').val();
			var _mEAddL1 = $('#ent-ma-address-line1').val();
			var _mEAddL2 = $('#ent-ma-address-line2').val();
			var _mEAddL3 = $('#ent-ma-address-line3').val();
			var _mCity = $('#ae-ma-city').val();
			var _mState = $('#ma-state-list-select').val();
			var _mZip = $('#ma-zipcode').val();
			var _mailingAddress = {
				'addressType' : "U.S",
				'addressLine1' : _mAddL1,
				'addressLine2' : _mAddL2,
				'addressLine3' : _mAddL3,
				'entAddressLine1' : _mEAddL1,
				'entAddressLine2' : _mEAddL2,
				'entAddressLine3' : _mEAddL3,
				'city' : _mCity,
				'state' : _mState,
				'zip' : _mZip,
				'uAddressLine1' : _mAddL1,
				'uAddressLine2' : _mAddL2,
				'uAddressLine3' : _mAddL3,
				'uEntAddressLine1' : _mEAddL1,
				'uEntAddressLine2' : _mEAddL2,
				'uEntAddressLine3' : _mEAddL3,
				'uCity' : _mCity,
				'uState' : _mState,
				'uZip' : _mZip
			};
			if (_self.get('addressValChange')) {
				_self.set('primaryAddress', _primaryAddress);
				_self.set('mailingAddress', _mailingAddress);
			}
			// save the data to new Client Data model
			// addrUseCd
			var _newClientReqModel = newClientModel.get('newClientModel');
			var _client = {}, _primAdd = {}, _mailAdd = {};
			if (_newClientReqModel['customerTypeCd'] == "P") {
				_client = _newClientReqModel['personClient'];
				_primAdd = {
					addrLn1 : _addL1,
					addrLn2 : _addL2,
					addrLn3 : _addL3

				};
			} else {
				_client = _newClientReqModel['orgClient'];
				_primAdd = {
					addrLn1 : _eAddL1,
					addrLn2 : _eAddL2,
					addrLn3 : _eAddL3

				};
			}
			_primAdd['addrUseCd'] = "Primary";
			_primAdd['ctyNm'] = _city;
			_primAdd['postlCd'] = _state;
			_primAdd['stCd'] = _zip;
			var _postalAddress = [];
			//always save prima addres at 0th index
			_postalAddress[0] = _primAdd;
			if ($('#reqrd-mailing-addrs:checked').length > 0) {
				// if user opted for mailing address save mailing address
				if (_newClientReqModel['customerTypeCd'] == "P") {
					_mailAdd = {
						addrLn1 : _mAddL1,
						addrLn2 : _mAddL2,
						addrLn3 : _mAddL3
					};
				} else {
					_mailAdd = {
						addrLn1 : _mEAddL1,
						addrLn2 : _mEAddL2,
						addrLn3 : _mEAddL3
					};
				}
				_mailAdd['addrUseCd'] = "Mailing";
				_mailAdd['ctyNm'] = _mCity;
				_mailAdd['postlCd'] = _mState;
				_mailAdd['stCd'] = _mZip;
				//always save mail addres at 1st index
				_postalAddress[1] = (_mailAdd);
			}
			_client['postalAddresses'] = _postalAddress;
			_self.set('fromBack', true);
		},
		addrValidation : function() {
			// validation for address
			if (_self.get('primaryAddress').addressType != "Foreign") {
				if ($(".us-zipcode#zipcode").val() > 77777) {
					return false;
				} else {
					return true;
				}
			} else {
				return true;
			}
		},
		mailAddrValidation : function() {
			// validation for address
			if ($(".us-zipcode#ma-zipcode").val() > 77777) {
				return false;
			} else {
				return true;
			}
		}
	});
	return new _addressModelClass();
});