/**
 * @ngdoc property
 * @name SWP Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function swpController($scope, fticLoggerMessage, loggerConstants, swpInitialLoader, transactModel) {
    console.info("SWP Controller!!"+$scope.header);
    $scope.header.title = "Start a SWP";
    $scope.config.txnFormDetails.title = "SWP Details";
    swpInitialLoader.loadAllServices($scope);
    transactModel.isSWP = true;

}

swpController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'swpInitialLoader', 'transactModel'];
module.exports = swpController;