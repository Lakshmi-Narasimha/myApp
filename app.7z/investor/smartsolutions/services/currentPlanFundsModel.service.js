'use strict';

var currentPlanFundsService= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _currPlanFunds = null,
        _goalChartDetails = null,
        _currFunds = null;

    var currentPlanFundsModel = {
        fetchCurrentPlanFunds : function (params) {
            var deferred = $q.defer();
            // getCurrentPlanFunds
            Restangular.one('smartsolution/fsGoalDetails').get(params).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        fetchCurrentFunds : function (params) {
            var deferred = $q.defer();
            // getCurrentPlanFunds
            Restangular.one('smartsolution/currentFunds').get(params).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getCurrentPlanFunds : function () {
                 return _currPlanFunds;
        } ,
        setCurrentPlanFunds : function (data) {
            _currPlanFunds = data;
        },
        setGoalChartDetails : function (data) {
            _goalChartDetails = data;
        },
        getGoalChartDetails : function () {
            return _goalChartDetails;
        },
        getCurrentFunds : function () {
                 return _currFunds;
        } ,
        setCurrentFunds : function (data) {
            _currFunds = data;
        }

    };
    return currentPlanFundsModel;

};

currentPlanFundsService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = currentPlanFundsService;
