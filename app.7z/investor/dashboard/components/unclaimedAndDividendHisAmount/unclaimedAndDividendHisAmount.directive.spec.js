'use strict';

describe('Directive: Unclaimed and Dividend History', function() {

	var compile, scope, directiveEle, isoScope, validHtml, investorDashboardDetailsModel;
    validHtml = '<ftic-unclaimed-amount></ftic-unclaimed-amount>';
     //load all modules, including the html template, needed to support the test

    var create = function(html) {
        var element = angular.element(html);
        var compiledElem = compile(element)(scope);
        //isoScope = directiveEle.isolateScope();
        scope.$digest();
        return compiledElem;
    };

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile, _investorDashboardDetailsModel_) {
          scope = $rootScope.$new();
          compile = $compile;
          investorDashboardDetailsModel = _investorDashboardDetailsModel_;
        });
        
    });

    var dashboardData = {
        investorDashboardObject: [{
            'unclaimedAmount': '5,000.00',
            'dividendHistory': '1000'
        }]
    };

    it('Directive should be defined', function() {
        var directiveEle = create(validHtml);
        expect(directiveEle).toBeDefined();
    });

    it('directive should be created with scope:true',function(){
        var directiveEle = create(validHtml);
        expect(directiveEle.scope()).toBeDefined();
	});

    it('Case-1 When data is available for Unclaimed&dividendHistory Directive',function(){
        var directiveEle = create(validHtml);
        var dirScope = directiveEle.scope();
        expect(directiveEle.scope()).toBeDefined();
        investorDashboardDetailsModel.setDashboardData(dashboardData.investorDashboardObject[0]);
        scope.$broadcast('investorDashboardInformation');
        expect(dirScope.unclaimedAmount).toEqual('5,000.00');
        expect(dirScope.dividendHisAmount).toEqual('1000');
	});
});