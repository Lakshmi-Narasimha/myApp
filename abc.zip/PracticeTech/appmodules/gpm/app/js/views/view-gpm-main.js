define(['jquery', 'underscore', 'backbone', 'spinner','appcommon/globalcontext', 'appcommon/analytics','appcommon/commonutility','appmodules/gpm/app/js/utils','appmodules/contactprofile/app/models/cpviewmodel','appmodules/contactprofile/app/models/preferenceviewmodel',
		'text!appmodules/gpm/app/templates/gpmadvsrclntinfotemplate.html', 'text!appmodules/gpm/app/templates/gpmcommonsectionstemplate.html',
		'text!appmodules/gpm/app/templates/gpmcontainer.html','text!appmodules/gpm/app/templates/gpmcontainertwostep.html'], function ($,_, Backbone,Spinner,GlobalContext, Analytics,CommonUtil, Utils, CPViewModel, PreferenceViewModel,GPMAdvsrClientTemplate, CommonSectionTemplate, GPMContainerTemplate,GPMTwoStepContainerTemplate) {
	var Self = null;	    
	var _containerView = Backbone.View.extend({
		        el: $("#practicetech-subapp"),
		        id: 'practicetech-subapp',
                referrer:  null,
		        events: {
		        	'click .gpm-step:not(.active):not(.gpm-noclick-step)':'doStepNavigation',
		        	//'click #gpm-step1-next-button,#m-gpm-step1-next-button': 'vaidateAndNavigateFromStep1',
		        },
		        initialize: function () {
		        	Self = this;
		        	$(document).off("click","#gpm-step1-next-button,#m-gpm-step1-next-button").on("click","#gpm-step1-next-button,#m-gpm-step1-next-button",Self.invokeNextButonClick);
		        	$(document).off('keyup','#gpm-update-form-container input[type="text"]:not(.special-text-fields)').on('keyup','#gpm-update-form-container input[type="text"]:not(.special-text-fields)',
							function(e) {
								e.which = e.which || e.keyCode;
								if (e.which == 13) {
									$('#gpm-update-form-container .next-button:visible').click();
								}});
		        	$(document).off("click", "#gpm-update-form-container .cancel-text").on("click", "#gpm-update-form-container .cancel-text", function (e) {
		        	    handlerForCancel(e, Self.referrer);
		        	});
		            //events to track user interactions, so that if the useer made any changes in step1 enable
		        	$(document).off("change", "#gpm-update-form input,#gpm-update-form select").on("change", "#gpm-update-form input,#gpm-update-form select", Self.blockNavigator); 
		        	$(document).off("keyup paste copy cut", "#gpm-update-form input,#gpm-update-form div[contenteditable=true]").on("keyup paste copy cut", "#gpm-update-form input,#gpm-update-form div[contenteditable=true]", Self.blockNavigator);
		        	$(document).off("click", "#gpm-update-form button.pt-toggle-btn,#gpm-update-form button.toggle-button,.edit-delete-action-tracking").on("click", "#gpm-update-form button.pt-toggle-btn,#gpm-update-form button.toggle-button,.edit-delete-action-tracking", Self.blockNavigator);
		        	this.data = {};
		        	this.data.advsrInfo ={fmid:CommonUtil.readCookie('FMID')};
		        },
		        invokeNextButonClick:function(){
		        	Self.currentUpdateView.validateAndNavigateFromStep1();
		        },
		        render: function (data, updateEgment) {
		        	if (/accountstatements/.test((Backbone.history.list.slice(-1)[0]))) {
		        		this.model.set('referrer', CommonUtil.getReferrer(-1));
		        	}  
                    //if the gpm workflow is launching from gpm confirmation page set the referrer as ContactProfile
		            else if (/gpm/.test((Backbone.history.list.slice(-3)[0]))) {
		                this.model.set('referrer', { "context": "Profile", "referer": "#contactprofile/" });
		            }else if (/gpm/.test((Backbone.history.list.slice(-1)[0]))) {
                        this.model.set('referrer', CommonUtil.getReferrer(-2));
		            } else { 
                        this.model.set('referrer', CommonUtil.getReferrer(-1));
	                }
		            
		        	var _isTwoStepWorkflow = false;
		        	var _containerTemplate = GPMContainerTemplate;
                    //Step 1 title is now hardcoded.
		        	var _stepPanelData = { "step1Title": "Client Information", "cssClass": "", "pageTitle": "Client Information", "pageTitleXs": "Client Information"  };
		        	switch (updateEgment) {
		        	    case 'reportclientsdivorce':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Details", "cssClass": "", "pageTitle": "Report Client's Divorce", "pageTitleXs": "Report Client's Divorce" };
		        	        break;
		        	    case 'reportclientsdeath':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Details", "cssClass": "", "pageTitle": "Report Client's Death", "pageTitleXs": "Report Client's Death" };
		        	        break;
		        	    case 'alert':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Alerts Update", "pageTitleXs": "Alerts Update" };
		        	        break;
		        	    case 'communicationPreference':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Communication Preference Update", "pageTitleXs": "Communication Update" };
		        	        break;
		        	    case 'documentDelivery':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Document Delivery Update", "pageTitleXs": "Document Update" };
		        	        break;
		        	    case 'gender':
		        	        _isTwoStepWorkflow = true;
		        	        _containerTemplate = GPMTwoStepContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Gender Update", "pageTitleXs": "Gender Update" };
		        	        break;
		        	    case 'greeting':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Greeting Update", "pageTitleXs": "Greeting Update" };
		        	        break;
		        	    case 'remarks':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Remarks Update", "pageTitleXs": "Remarks Update" };
		        	        break;
		        	    case 'dependents':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Total Dependents Update", "pageTitleXs": "Total Dependents Update" };
		        	        break;
		        	    case 'honorific':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Honorific Update", "pageTitleXs": "Honorific Update" };
		        	        break;
		        	    case 'maritalstatus':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Marital Status Update", "pageTitleXs": "Marital Status Update" };
		        	        break;
		        	    case 'passport':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Passport Update", "pageTitleXs": "Passport Update" };
		        	        break;
		        	    case 'subtype':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Sub-type Update", "pageTitleXs": "Sub-type Update" };
		        	        break;
		        	    case 'employment':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Employment Update", "pageTitleXs": "Employment Update" };
		        	        break;
		        	    case 'suitability':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Income & Investments Update", "pageTitleXs": "Suitability Update" };
		        	        break;
		        	    case 'entity':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Entity Information Update", "pageTitleXs": "Entity Information Update" };
		        	        break;
		        	    case 'driverslicense':
		        	        _containerTemplate = GPMContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Driver's License Update", "pageTitleXs": "Driver's License Update" };
		        	        break;
		        	    case 'phonenumbers':
		        	        _isTwoStepWorkflow = true;
		        	        _containerTemplate = GPMTwoStepContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Phone Number Update", "pageTitleXs": "Phone Number Update" };
		        	        break;
		        	    case 'email':
		        	        _isTwoStepWorkflow = true;
		        	        _containerTemplate = GPMTwoStepContainerTemplate;
		        	        _stepPanelData = { "step1Title": "Update", "cssClass": "", "pageTitle": "Email Address Update", "pageTitleXs": "Email Address Update" };
		        	        break;
		        	    default:
		        	        break;
		        	}
		            //
		        	_stepPanelData.columns = 1;
		        	_stepPanelData.actions = [];
		        	_stepPanelData.confirmPage = false;
		            //_stepPanelData = {"step1Title":"Update","cssClass":""};step1Title
		        	this.referrer = this.model.get("referrer");
		        	_stepPanelData.history = this.model.get("referrer");
		        	var _gpmTmplt = _.template(_containerTemplate);
		        	_gpmCmpldTmplt = _gpmTmplt(_stepPanelData)
		        	this.$el.html(_gpmCmpldTmplt);
		        	var _commonTemplate = _.template(CommonSectionTemplate);
		        	var _sectionName = { sectionName: updateEgment };
		        	if(_isTwoStepWorkflow){
		        		$('#ensure-accuracy-section-holder').html(Utils.getTemplateSection(_commonTemplate(_sectionName), '#ensure-accuracy-text')).removeClass('hidden');
		        	}
		        	Backbone.history.navigate('gpm/update/'+updateEgment, true);
		            Spinner.hide();
		            window.scrollTo(0, 0);
		        },
		        getClientInfo : function(){
		        	var CPData = CPViewModel.getInstance().getData();
		        	var cliemtName = ""
		        		if(CPData.cola.personClient.get("clLastNm")){
		        			cliemtName = CPData.cola.personClient.get("clLastNm")+ ", "+CPData.cola.personClient.get("clFirstNm");
		        		}else{
		        			cliemtName = CPData.cola.orgClient.get("orgNm");
		        		}
		        	this.data.clientInfo = {fmtId:CPData.cola.fmtId,name : cliemtName};
		        	//this.model.setCurrentValue(updateMode,{data:this.data});
		        	this.loadAdvsrClientNametemplate();
		        	
		        },
		        doStepNavigation:function(e){
		        	var _$el = $(e.currentTarget),_$activeStep = $('.gpm-step.active');
		        	var _currentStep = _$activeStep.find('a.pt-step-nav-links').data('step-no'),_clickedStep = _$el.find('a.pt-step-nav-links').data('step-no');
		        	switch (_clickedStep) {
					case 1:
						$('.back-button:visible').trigger('click');
						break;
					case 2:
						$('.next-button:visible').trigger('click');
						break;
					case 3:
						
						$('.next-button:visible').trigger('click');
						break;
					default:
						break;
					}
		        	
		        },
		        blockNavigator: function () {
		            $('#transparent-nav').show();
		        }
		    });
	   function handlerForCancel(e, referrer) {
		    BootstrapDialog
				    .confirm(
						    "Cancel",
						    "All your work will be lost.  Are you sure you want to cancel?",
						    function(confirm) {
							    if (confirm) {
								    location.hash = referrer.referer;
							    }

						    }, 'ncst-dialog');
	    }
		    return _containerView;
		});
