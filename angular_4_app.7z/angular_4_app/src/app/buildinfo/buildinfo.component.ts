import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardService } from "../services/dashboard.service";

@Component({
  selector: 'app-buildinfo',
  templateUrl: './buildinfo.component.html',
  styleUrls: ['./buildinfo.component.scss'],
  providers: [DashboardService]
})
export class BuildinfoComponent implements OnInit {
  headerText: String;
  envHeaderList: any = {
    1: 'ENV1',
    2: 'ENV2',
    3: 'ENV3'
  };
  deploymentHeaderList: any = {
    'UAT': 'UAT BUILD DEPLOYMENT DETAILS',
    'SIT': 'SIT BUILD DEPLOYMENT DETAILS',
    'PROD': 'PROD BUILD DEPLOYMENT DETAILS'
  };
  constructor(private route: ActivatedRoute, private DashboardService: DashboardService) {
  }
  getApplications(key:any): void {
    this.DashboardService.getLatestProjectDeploymentDeatils(key)
      .subscribe(
      resultArray => this.deploymentSuccessCallback(resultArray),
      error => console.log("Error :: " + error)
      );
  }
  deploymentSuccessCallback(resultArray: any): void {
  }
  ngOnInit(): void {
    this.route.params
      .zip(this.route.data)
      .subscribe((value) => {
        this.getApplications(value[0].key.split('-')[0]);
        this.headerText = this.envHeaderList[value[0].id] + ' ' + this.deploymentHeaderList[value[0].buildType];
      });
  }

}
