import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'response',
  templateUrl: './response.component.html',
  styleUrls: ['./response.component.css']
})
export class ResponseComponent implements OnInit {

constructor() {
}

response : string = null;

  ngOnInit() {
  }

}
