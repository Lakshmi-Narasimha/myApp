// getinvestordetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AttritionAnalysisSchema = new mongoose.Schema({
    attritionAnalysisObject: {
        type: Array,
        "default": []
    }
});

var AttritionAnalysisLookUp = mongoose.model('AttritionAnalysisLookUp', AttritionAnalysisSchema);
/*json order: investor book-*/
var AttritionAnalysisModel = new AttritionAnalysisLookUp({
    "attritionAnalysisObject": [
                {
                  "purchase": {
                    "year": "2012",
                    "NoOfUnits": "11276552.5690"
                  },
                  "redemption": {
                    "year1": {
                      "key": "2012",
                      "value": "0"
                    },
                    "year2": {
                      "key": "2013",
                      "value": "45.84"
                    },
                    "year3": {
                      "key": "2014",
                      "value": "14.96"
                    },
                    "year4": {
                      "key": "2015",
                      "value": "34.2"
                    },
                    "year5": {
                      "key": "2016",
                      "value": "4.99"
                    },
                    "total": "421"
                  }
                },
                {
                  "purchase": {
                    "year": "2016",
                    "NoOfUnits": "866942.7880"
                  },
                  "redemption": {
                    "year1": {
                      "key": "2012",
                      "value": ""
                    },
                    "year2": {
                      "key": "2013",
                      "value": ""
                    },
                    "year3": {
                      "key": "2014",
                      "value": ""
                    },
                    "year4": {
                      "key": "2015",
                      "value": ""
                    },
                    "year5": {
                      "key": "2016",
                      "value": "0"
                    },
                    "total": "0"
                  }
                },
                {
                  "purchase": {
                    "year": "2013",
                    "NoOfUnits": "13755496.5350"
                  },
                  "redemption": {
                    "year1": {
                      "key": "2012",
                      "value": ""
                    },
                    "year2": {
                      "key": "2013",
                      "value": "0"
                    },
                    "year3": {
                      "key": "2014",
                      "value": "54.34"
                    },
                    "year4": {
                      "key": "2015",
                      "value": "30.87"
                    },
                    "year5": {
                      "key": "2016",
                      "value": "14.79"
                    },
                    "total": "311"
                  }
                },
                {
                  "purchase": {
                    "year": "2014",
                    "NoOfUnits": "30995194.2730"
                  },
                  "redemption": {
                    "year1": {
                      "key": "2012",
                      "value": ""
                    },
                    "year2": {
                      "key": "2013",
                      "value": ""
                    },
                    "year3": {
                      "key": "2014",
                      "value": "0"
                    },
                    "year4": {
                      "key": "2015",
                      "value": "64.98"
                    },
                    "year5": {
                      "key": "2016",
                      "value": "35.02"
                    },
                    "total": "317"
                  }
                },
                {
                  "purchase": {
                    "year": "2015",
                    "NoOfUnits": "11045489.9660"
                  },
                  "redemption": {
                    "year1": {
                      "key": "2012",
                      "value": ""
                    },
                    "year2": {
                      "key": "2013",
                      "value": ""
                    },
                    "year3": {
                      "key": "2014",
                      "value": ""
                    },
                    "year4": {
                      "key": "2015",
                      "value": "0"
                    },
                    "year5": {
                      "key": "2016",
                      "value": "100"
                    },
                    "total": "105"
                  }
                }
              ]

});

AttritionAnalysisLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AttritionAnalysisLookUp table, please contact admin...');
    } else {
        AttritionAnalysisLookUp.remove({}, function(err) {
            console.log('AttritionAnalysisLookUp collection removed');
           AttritionAnalysisModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AttritionAnalysisLookUp table, please contact admin...');
                }
                console.log('AttritionAnalysisLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AttritionAnalysisLookUp;
