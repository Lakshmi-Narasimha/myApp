'use strict';

var investorEvents = function(fticBroadcast, investorEventConstants) {
    return {
        dashboard: {
            investorDashboardInformation: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.Dashboard.INV_DB_INFO);
            },
            investorSmartSolutions: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.Dashboard.INV_DB_SMART_SOLUTIONS);
            },
            // investorMyInvestments: function(scope) {
            //     fticBroadcast.eventBroadcast(scope, investorEventConstants.Dashboard.INV_DB_MY_INVMENT);
            // },
            // investorMySips: function(scope) {
            //     fticBroadcast.eventBroadcast(scope, investorEventConstants.Dashboard.INV_DB_MY_SIPS);
            // },
            investorSmartSaveAccAndOneTouch: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.Dashboard.INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH);
            }
        },
        myPortfolio: {
            publishPanViewVDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.OVERVIEW_PAN_VIEW);
            },
            accountStmtsFolioView: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.OVERVIEW_FOLIO_VIEW);
            },
            folioAccountDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.OVERVIEW_FOLIO_ACCOUNTS);
            },
            capitalgaingsaccountdetails: function(scope) {
                //fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.CG_ACC_DET);                
                scope.$emit(investorEventConstants.MyPortfolio.CG_ACCOUNT_DETAILS);
            },
            capitalgainsfoliodetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.CG_FOLIO_DETAILS);
            },
            accountStmtsAccountView: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.ACCT_STMTS_ACCOUNT_VIEW);
            },
            accountStmtsUnitHolder: function(scope) {

                //fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.ACCT_STMTS_UNIT_HOLDER);
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.ACCT_STMTS_UNIT_HOLDER, unitHolderModel.getUnitHolderObj(), 'unitHolder');

            },
            /*publishsubscriptionDetails : function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.SUBSCRIPTION_DETAILS, '', '');
            }*/
            capitalGainsFolisNumberList: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.CG_FOLIO_NUMBER_LIST);
            },
            capitalGaingsFoliodetails: function(scope) {
                scope.$emit(investorEventConstants.MyPortfolio.CG_FOLIO_DETAILS_LIST);
            },
            familyPortfolioList:function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_LIST);
            }
        },
        eforms: {
            broadcastEformOptions: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.Eforms.EFORM_OPTIONS);
            },
            broadcastEformSelection: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.Eforms.CHANGE_TEMPLATE);
            },
            broadcastEformSubmission: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.Eforms.INV_EFORM_SUBMITTED);
            },
            emitEformDetails: function(scope) {
                scope.$emit(investorEventConstants.Eforms.INV_EFORM_GENERATED);
            },
            emitAsMobileDetected: function(scope, data) {
                scope.$emit(investorEventConstants.Eforms.INV_EFORM_MOBILE_DETECTED, data);
            },
            broadcastIfscDetails: function(scope) {
                scope.$emit(investorEventConstants.Eforms.INV_EFORM_IFSC_CODE_DETECTED);
            }
        },
        myProfile: {
            personalInfo: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.INV_MP_PERSONAL_INFO_DET);
            },
            mobileNotUpdated: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.INV_MP_PER_MOB_NO_UPD);
            },
            publishsubscriptionDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.SUBSCRIPTION_DETAILS);
            },
            publishsubscriptionNullDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.SUBSCRIPTION_DETAILS_NULL);
            },
            changePassword:function(scope){
              fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.INV_MP_CHG_PWD);  
            },
            secretQANotUpdated : function(scope) {
                    fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.INV_MP_CHG_SCRT_QA_NO_UPD);
            },
            //KYC Flow
            broadcastPanLevelData: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.INV_MP_KYC_PANLEVEL_DATA);
            },
            broadcastPanFolioKycData: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.MyProfile.INV_MP_KYC_PANFOLIOKYC_DATA);
            }
        },
        accountSettings: {
            bankAccDetails: function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.INV_BASIS_BANK_ACC_DETAILS);
            },
            broadcastDividendDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.DIVIDEND_DETAILS);
            },
            broadcastDividendChangeAssetCategories: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.cHANGEDIVIDEND_ASSET_CATEGORIES);
            },
            broadcastEmandateDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.EMANDATE_DETAILS);
            },
            getEmandateDetails : function (scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.LOAD_EMANDATE_DATA_EVENT);
            },
            newEmandateDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.LOAD_NEW_EMANDATE_DATA_EVENT);
            },
            getUserAccessDetailsList :function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.USER_ACCESS_LIST);
            },
            basisFolioDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.INV_BF_INFO);
            },
            loadFolioDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.INV_ADD_NEW_BANK);
            },
            getNomineeDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.NOMINEE_DETAILS);
            },
            bankNamesList: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.INV_BANK_LIST);
            },
            loadBankDetails: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.INV_BANK_DETAILS);
            },
            editBasisBankAccDetails:function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.accountSettings.INV_BANK_DETAILS_UPDATED);
            }
        },
        transactionhistory: {
            publishTransactionSummary: function (scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.TranscationHistory.MYINVESTOR_TRANSACTION_SUMMARY);
            },
            publishTransactionDetails: function (scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.TranscationHistory.MYINVESTOR_TRANSACTION_DETAILS);
            },
            publishTxnSuccessDetails : function (scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.TranscationHistory.LOAD_DATA_EVENT);
            },
            broadcastUnclaimedMoney : function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.TranscationHistory.UNCLAIMED_MONEY);
            },
            broadcastFinancialTransactionStatus: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.TranscationHistory.FINANCIAL_TRANSACTIONS_DETAILS);
            },
            broadcastNonFinancialTransactionStatus: function(scope) {
                fticBroadcast.eventBroadcast(scope, investorEventConstants.TranscationHistory.NON_FINANCIAL_TRANSACTIONS_DETAILS);
            }
        },
        //Investor Smart Solution Events
        smartSolutions:{
          publishRecommendedPlan: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.RECOMMENDED_PLAN);
            },
            publishRecommendedFundPlan: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.RECOMMENDED_FUND_PLAN);
            },
            publishSavedSmartSol: function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.smartSolutions.SAVED_SMART);
            },
            publishBuildPlan: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.BUILD_PLAN);
            },
            publishOverview: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.ADV_SS_OVERVIEW,overviewModel.getOverviewDtls());
            },
            publishInvTrends: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.ADV_SS_INV_TRENDS,invTrendsModel.getInvTrendsDtls());
            },
            publishGoalTrends: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.ADV_SS_ATTRITION_ANALYSIS,goalTrendsModel.getAttrAnalysisDtls(), 'getAttrDtls');
            },
            publishGoalInvestorData: function(scope){
                fticBroadcast.eventBroadcast(scope, advisorEventConstants.smartSolutions.GOAL_INVS_DATA);
            },
            publishCurrentPlanFunds: function(scope){
                fticBroadcast.eventBroadcast(scope, investorEventConstants.smartSolutions.CURR_FUNDS_DATA);
            },
            publishCurrentGoalchart : function (scope) {
              fticBroadcast.eventBroadcast(scope, investorEventConstants.smartSolutions.CURR_GOAL_DATA);  
            }
        }
    };
};

investorEvents.$inject = ['fticBroadcast', 'investorEventConstants'];
module.exports = investorEvents;
