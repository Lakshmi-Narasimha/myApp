// getoverviewdetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InvTrendsSchema = new mongoose.Schema({
    InvTrendsObject: {
        type: Array,
        "default": []
    }
});

var InvTrendsLookUp = mongoose.model('InvTrendsLookUp', InvTrendsSchema);

var InvTrendsModel = new InvTrendsLookUp({
	"InvTrendsObject" : [
					  {
					    "goalExposureCompletion": {
					      "goalExposure": [
					        {
					          "goals": "1 Goal",
					          "value":"230",
					          "investors": "Investors"
					        },
					        {
					          "goals": "2 Goals",
					          "value":"100",
					          "investors": "Investors"
					        },
					        {
					          "goals": "3 Goals",
					          "value":"64",
					          "investors": "Investors"
					        },
					        {
					          "goals": ">3 Goals",
					          "value":"6",
					          "investors": "Investors"
					        }
					      ],
					      "goalCompletion": [
					        {
					          "goalsPercent": "25%",
					          "value":"265",
					          "investors": "Investors"
					        },
					        {
					          "goalsPercent": "50%",
					          "value":"75",
					          "investors": "Investors"
					        },
					        {
					          "goalsPercent": "75%",
					          "value":"40",
					          "investors": "Investors"
					        },
					        {
					          "goalsPercent": "100%",
					          "value":"20",
					          "investors": "Investors"
					        }
					      ]
					    },
					    "goalAUMAgeing": {
					      "goalWiseAUMAgeingResp": [
					        {
					          "goal": "RP",
					          "ltOneYr": "90.67%",
					          "oneToThreeYrs": ".09%",
					          "threeToFiveYrs": "6.65%",
					          "gtFiveYrs": "2.6%",
					          "grandTotal": "6276761.68"
					        },
					        {
					          "goal": "DH",
					          "ltOneYr": "91.57%",
					          "oneToThreeYrs": ".06%",
					          "threeToFiveYrs": ".13%",
					          "gtFiveYrs": "8.24%",
					          "grandTotal": "31375881.23"
					        },
					        {
					          "goal": "WC",
					          "ltOneYr": "10.1%",
					          "oneToThreeYrs": "16.93%",
					          "threeToFiveYrs": "12.57%",
					          "gtFiveYrs": "60.4%",
					          "grandTotal": "52729698.74"
					        },
					        {
					          "goal": "CM",
					          "ltOneYr": "20.46%",
					          "oneToThreeYrs": "12.58%",
					          "threeToFiveYrs": "9.79%",
					          "gtFiveYrs": "57.17%",
					          "grandTotal": "552142084.79"
					        },
					        {
					          "goal": "TP",
					          "ltOneYr": "6.62%",
					          "oneToThreeYrs": "15.11%",
					          "threeToFiveYrs": "12.64%",
					          "gtFiveYrs": "65.63%",
					          "grandTotal": "17014927.17"
					        },
					        {
					          "goal": "HOLI",
					          "ltOneYr": "10.35%",
					          "oneToThreeYrs": "89.65%",
					          "threeToFiveYrs": "%",
					          "gtFiveYrs": "%",
					          "grandTotal": "4912451.50"
					        },
					        {
					          "goal": "CE",
					          "ltOneYr": "22.95%",
					          "oneToThreeYrs": "31.75%",
					          "threeToFiveYrs": "2.68%",
					          "gtFiveYrs": "42.63%",
					          "grandTotal": "457605571.42"
					        }
					      ]
					    }
					  }
					]
		});

InvTrendsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvTrendsLookUp table, please contact admin...');
    } else {
        InvTrendsLookUp.remove({}, function(err) {
            console.log('InvTrendsLookUp collection removed');
            InvTrendsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InvTrendsLookUp table, please contact admin...');
                }
                console.log('InvTrendsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvTrendsLookUp;
