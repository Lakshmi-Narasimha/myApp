define(['jquery', 'lodash', '../../app/common/util'],
  function($, _, util) {
  mocha.ui('bdd');
  var assert = chai.assert;
  var expect = chai.expect;

  /* Tests */

  describe('Util', function() {
      // this.timeout(0);  // only uncomment if you are debugging the test!!!!

      describe("urlParts", function() {

          it("should parse hash tag from url", function(){
              var url = util.parseURL("http://my.com/things#foo");
              expect(url.urlWithoutQueryString).to.equal('http://my.com/things');
          });

          it("should parse url without hash tag or query string", function(){
              var urlProperties = util.parseURL("http://my.com/things");
              expect(urlProperties.urlWithoutQueryString).to.equal('http://my.com/things');
              expect(urlProperties.hashTag).to.not.exist;
              expect(Object.keys(urlProperties.params).length).to.equal(0);
          });

          it("should parse url with query string but no hash tag", function(){
              var urlProperties = util.parseURL("http://my.com/things?foo=bar");
              expect(urlProperties.urlWithoutQueryString).to.equal('http://my.com/things');
              expect(urlProperties.hashTag).to.not.exist;
              expect(Object.keys(urlProperties.params).length).to.equal(1);
              expect(urlProperties.params.foo).to.equal('bar');
          });

          it("should parse url with query string & hash tag", function(){
              var urlProperties = util.parseURL("http://my.com/things?foo=bar#thang");
              expect(urlProperties.urlWithoutQueryString).to.equal('http://my.com/things');
              expect(urlProperties.hashTag).to.equal('thang');
              expect(Object.keys(urlProperties.params).length).to.equal(1);;
              expect(urlProperties.params.foo).to.equal('bar');
          });

          it("should parse url with query string with more than one param", function(){
              var urlProperties = util.parseURL("http://my.com/things?foo=bar&stuff=thing");
              expect(urlProperties.urlWithoutQueryString).to.equal('http://my.com/things');
              expect(urlProperties.hashTag).to.not.exist;
              expect(Object.keys(urlProperties.params).length).to.equal(2);
              expect(urlProperties.params.foo).to.equal('bar');
              expect(urlProperties.params.stuff).to.equal('thing');
          });

      });

      describe("toURL", function() {

          it("should write URL without query string or hash tag", function(){
              var urlProperties = {
                  urlWithoutQueryString: 'http://my.com/things'
              };
              expect(util.toURL(urlProperties)).to.equal('http://my.com/things');
          });

          it("should write URL with hash tag", function(){
              var urlProperties = {
                  urlWithoutQueryString: 'http://my.com/things',
                  hashTag: "foo"
              };
              expect(util.toURL(urlProperties)).to.equal('http://my.com/things#foo');
          });

          it("should write URL with hash tag & 1 query string param", function(){
              var urlProperties = {
                  urlWithoutQueryString: 'http://my.com/things',
                  hashTag: "foo",
                  params: {thing: "stuff"}
              };
              expect(util.toURL(urlProperties)).to.equal('http://my.com/things?thing=stuff#foo');
          });

          it("should write URL with hash tag & 2 query string param", function(){
              var urlProperties = {
                  urlWithoutQueryString: 'http://my.com/things',
                  hashTag: "foo",
                  params: {thing: "stuff", name: "bob"}
              };
              var url = util.toURL(urlProperties);
              expect(url == 'http://my.com/things?name=bob&thing=stuff#foo' || url == 'http://my.com/things?thing=stuff&name=bob#foo').to.be.true;
          });

          it("should write URL without param if param value is null", function(){
              var urlProperties = {
                  urlWithoutQueryString: 'http://my.com/things',
                  params: {thing: null}
              };
              expect(util.toURL(urlProperties)).to.equal('http://my.com/things');
          });

      });

      describe("isBackboneModel", function() {

          it("should indicate if object is backbone model (including subtypes)", function(){
              var TestModel = Backbone.Model.extend({});
              var testModelInstance = new TestModel();
              expect(util.isBackboneModel(testModelInstance)).to.be.true;
              expect(util.isBackboneModel({})).to.be.false;
              expect(util.isBackboneModel(null)).to.be.false;
          });


      });



  });




});
