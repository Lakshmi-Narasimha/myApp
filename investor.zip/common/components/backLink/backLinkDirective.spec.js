'use strict';

describe('Directive: Back Link with state and label defined', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;            
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-back-link state="portfolio.mb" label="Portfolio Monthly Business"></ftic-back-link>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should be defined',function(){
        expect(directiveEle).toBeDefined();
    });

    it('span should be updated with the given label, if label is defined', function(){
        isoScope.label= "Portfolio Monthly Business";
        var spanText = directiveEle.find('span').text();
        expect(spanText).toEqual(isoScope.label);
    });

    it('should navigate to portfolio monthly business overview if state is defined', inject(function($state){
        isoScope.state= "portfolio.mb";
        spyOn($state, 'go');
        isoScope.goBack();
        expect($state.go).toHaveBeenCalledWith(isoScope.state); 
    }));

});

describe('Directive: Back Link with state and label undefined', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;            
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-back-link></ftic-back-link>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

    // it('span label should be "back", if label is not defined', function(){
    //     var spanText = directiveEle.find('span').text();
    //     expect(spanText).toEqual("Back");
    // });

    it('should navigate to previous view if state is not defined', inject(function($window){
        spyOn($window.history, 'back');
        isoScope.goBack();
        expect($window.history.back).toHaveBeenCalled(); 
    }));

});

