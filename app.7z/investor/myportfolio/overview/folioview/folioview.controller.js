/**
 * @ngdoc Controller
 * @name FolioViewController
 * @requires $scope
 * @requires investorEventConstants
 * @requires folioViewInitialLoader
 * @description
 *
 * - It controls the view of Folio view in Account statements of Statements tab in my investors page.
 *
 **/


'use strict';

var FolioViewController = function($scope, investorEventConstants, folioViewInitialLoader, $state, folioViewModel, invInstantMailback, investorConstants, downloadService) {

    $scope.$emit('changeNavPill', 'folioview');
    $scope.populateFolioData = false;
    $scope.viewObj = {};

    // get folio accounts service on load
    folioViewInitialLoader.loadFolioAccountDetails($scope);

    $scope.$on('apply', function(event, folioFilter) {
        $scope.showFolioData = false;
        $scope.viewObj.populateFolioData = false;
        invInstantMailback.setMailBackData({
            folioPanAcc: folioFilter.folioPanAccNo,
            fromDate: folioFilter.fromDate || null,
            toDate: folioFilter.toDate || null,
            periodType: folioFilter.dayFlag
        });
        downloadService.setQueryparams({
            strInputData: folioFilter.folioPanAccNo,
            inputFlag: 'F',
            periodType: folioFilter.dayFlag,
            dtFromDate: folioFilter.fromDate,
            dtToDate: (folioFilter.dayFlag === 'DR' ? folioFilter.toDate : null)
        });
        folioViewInitialLoader.loadAllServices($scope, folioFilter);
    });
    $scope.$on(investorEventConstants.MyPortfolio.OVERVIEW_FOLIO_ACCOUNTS, function() {
        $scope.viewObj.showFolioAccounts = true;
    });
    $scope.$on(investorEventConstants.MyPortfolio.OVERVIEW_FOLIO_VIEW, function() {
        $scope.showFolioData = true;
        $scope.viewObj.isFolioDataAvailable = (folioViewModel.getFolioViewObj() ? folioViewModel.getFolioViewObj().folioDetails : false);
        if($scope.viewObj.isFolioDataAvailable) {
            $scope.viewObj.populateFolioData = true;
        } else {
            $scope.viewObj.folioViewErrorMsg = investorConstants.dashboard.DATA_CURRENTLY_UNAVAILABLE;
        }
        
    });

    $scope.$on('showAccountView', function(event, accountFilter) {
        $scope.$emit('changeNavPill', 'accountview');
        $state.transitionTo('overview.accview', accountFilter);
    });
};



FolioViewController.$inject = ['$scope', 'investorEventConstants', 'folioViewInitialLoader', '$state', 'folioViewModel', 'invInstantMailback', 'investorConstants', 'downloadService'];
module.exports = FolioViewController;
