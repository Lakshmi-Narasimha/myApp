// getDividendDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var nonFinancilalTransactionModelSchema = new mongoose.Schema({
    nonFinancialTransactionDetailsResp: {
        type: Array,
        "default": []
    }
});

var nonFinancilalTransactionModelLookUp = mongoose.model('nonFinancilalTransactionModelLookUp', nonFinancilalTransactionModelSchema);

var nonFinancilalTransactionModel = new nonFinancilalTransactionModelLookUp({
    nonFinancialTransactionDetailsResp : {
      "nctDetails": [
        {
          "accountNo": "17024206",
          "customerName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
          "folioId": "17024206",
          "fund": "",
          "impacted": "17024206",
          "newValue": "",
          "oldValue": "",
          "processDate": "",
          "reportedDate": "14 nov 2016",
          "status": "Processed",
          "trxnType": "Change Of Address"
        },
        {
          "accountNo": "17024206",
          "customerName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
          "folioId": "17024206",
          "fund": "",
          "impacted": "",
          "newValue": "",
          "oldValue": "",
          "processDate": "14 nov 2016",
          "reportedDate": "14 nov 2016",
          "status": "Completed",
          "trxnType": "Change Of Address"
        },
        {
          "accountNo": "17024206",
          "customerName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
          "folioId": "17024206",
          "fund": "",
          "impacted": "17024206",
          "newValue": "",
          "oldValue": "",
          "processDate": "14 nov 2016",
          "reportedDate": "14 nov 2016",
          "status": "Completed",
          "trxnType": "Change Of Address"
        },
        {
          "accountNo": "17024206",
          "customerName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
          "folioId": "",
          "fund": "",
          "impacted": "17024206",
          "newValue": "",
          "oldValue": "",
          "processDate": "14 nov 2016",
          "reportedDate": "",
          "status": "Completed",
          "trxnType": "Change Of Address"
        },
        {
          "accountNo": "17024206",
          "customerName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
          "folioId": "17024206",
          "fund": "",
          "impacted": "17024206",
          "newValue": "",
          "oldValue": "",
          "processDate": "14 nov 2016",
          "reportedDate": "14 nov 2016",
          "status": "Completed",
          "trxnType": "Change Of Address"
        },
        {
          "accountNo": "17024206",
          "customerName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
          "folioId": "17024206",
          "fund": "",
          "impacted": "17024206",
          "newValue": "",
          "oldValue": "",
          "processDate": "14 nov 2016",
          "reportedDate": "14 nov 2016",
          "status": "Completed",
          "trxnType": "Change Of Address"
        }
      ]
    }
});

nonFinancilalTransactionModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating nonFinancilalTransactionModelLookUp table, please contact admin...');
    } else {
        nonFinancilalTransactionModelLookUp.remove({}, function(err) {
            console.log('nonFinancilalTransactionModelLookUp collection removed');
            nonFinancilalTransactionModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating nonFinancilalTransactionModelLookUp table, please contact admin...');
                }
                console.log('nonFinancilalTransactionModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = nonFinancilalTransactionModelLookUp;
