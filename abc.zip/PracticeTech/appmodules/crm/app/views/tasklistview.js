define(
		['jquery', 'underscore', 'backbone', 'spinner', 'moment', 'jqueryui',
				'appcommon/constants',
				'appcommon/commonutility',
                'appmodules/crm/crmcommon',
				'appmodules/crm/app/models/task',
                'appmodules/crm/app/models/taskcontext',
                'services/dataservice',
                'appmodules/crm/app/views/obouserpickerview',
				'text!appmodules/crm/app/templates/tasklist.html',
				'text!appmodules/crm/app/templates/tasklistitem.html',
				'text!appmodules/crm/app/templates/taskdetailview.html',
                'text!appmodules/crm/app/templates/taskheaderview.html',
			    'appcommon/analytics',
                'apipublic/navapi',
				'errorLog'],
		function ($, _, Backbone, Spinner, Moment, JqueryUI, Constants, CommonUtilis, CRMCommon, Task, TaskContext,
				Dataservice, OBOUserPickerView, TaskListTemplate, TaskListItemTemplate, TaskDetailViewTemplate, TaskHeaderView, Analytics, NavApi, ErrorLog) {
		    // var moment = require('moment');
		    var state, _self;
		    var taskList = Backbone.View
					.extend({
					    el: $("#practicetech-subapp"),
					    id: 'practicetech-subapp',
					    oboUserPickerView: null,
					    headerTemplate: _.template(TaskHeaderView),
					    events: {
					        "click .sort-key": "sortTaskList",
					        "click #show-more-text": "loadFutureTask",
					        "click .c-task-contact-name a": "moveToContactProfile",
					        "click .expand-collapse": "toggleExpColDesktop", //expand collapse desktop
					        "click [pt-task-show-users]": "taskShowUsersClick",
					        "click .add-new-task": "addTaskClicked"
					    },
					    initialize: function (e) {
					        this.state = {
					            sort: {
					                key: "startDate",
					                desc: false
					            },
					            edit: false,
								add: false
					        };
					        var that = self = this;
					        _.bindAll(this, 'render');
					        this.taskList = {};
					        $(document).off('click', '.js-savestatetask').on('click', '.js-savestatetask', function (e) {
					            that.loadOrSaveTask(e);
					        });
					    },
					    loadOrSaveTask: function (e) {
					        that = this;
					        (typeof practicetech.modules.tasks === 'undefined') ? practicetech.modules.tasks = new practicetech.createNew.module() : "";
					        practicetech.modules.tasks.state = that.saveTaskState();
					    },
					    saveTaskState: function () {
					        return this.state;
					    },
					    moveToContactProfile: function (e) {
					        e.preventDefault();
					        var contactId = e.target.id;
					        if (contactId.indexOf("Contact.") > -1) {
					            ContactType = Constants.contactType.NonClient;

					        } else {
					            ContactType = Constants.contactType.Client;
					        }

					        if (!(contactId == "undefined" || contactId == "" || contactId === null)) {
					            NavApi.changeContactAndLauchCP(contactId, ContactType);
					        }
					    },
					    toggleExpColDesktop: function (e) {
					        var _self = this;
					        Spinner.show();

					        var _$target = $(e.currentTarget);
					        var _$targetDiv = $(_$target).parent().parent();
					        var taskId = _$target.data('taskid');
					        var taskDetailTab = _$targetDiv.parent().find('.taskList-desc-tab').attr('id');

					        var taskContactID = _$targetDiv.parent().find('.c-task-contact-name').attr('id');

					        if (_$target.hasClass("collapse-icon")) {
					            $('#' + _$target.attr('data-taskdetails-target')).slideUp();
					            _$target.removeClass("collapse-icon").addClass('expand-icon');

					            _$targetDiv.find('div:not(.expand-collapse-div)').addClass('pt-ellipsis');
					            _$targetDiv.removeClass('padding-btm15');

					            if (!($('#' + taskDetailTab + '').hasClass('hidden'))) {
					                $('#' + taskDetailTab + '').addClass('hidden').css('display', 'none');
					                $('#' + taskContactID + '' + ' ul' + '').remove();
					            }
					            Spinner.hide();
					            Analytics.analytics.recordAction('taskListView:individualTaskCollapse:clicked');
					        }
					        else {
					            $('#' + _$target.attr('data-taskdetails-target')).slideDown();
					            _$target.addClass("collapse-icon").removeClass('expand-icon');

					            _$targetDiv.find('div').removeClass('pt-ellipsis');
					            _$targetDiv.addClass('padding-btm15');

					            if ($('#' + taskDetailTab + '').hasClass('hidden')) {
					                $('#' + taskDetailTab + '').removeClass('hidden').css('display', 'block');
					            }

					            var _tmpTemplate = _.template(TaskDetailViewTemplate);
					            Dataservice.getTaskDetails(TaskContext.getTaskFMID(), taskId).then(gotoToDetailsSuccess).fail(_self.gotoError);
					            function gotoToDetailsSuccess(response) {
					                Spinner.hide();
					                if (response && response[0]) {
					                    var _dataLoadedTemplate = _tmpTemplate({ taskDetails: response[0] });
					                    $('#' + taskDetailTab + '').html(_dataLoadedTemplate);

					                    var allContactName = response[0].attributes.allContacts;
					                    if (!(allContactName == "undefined" || allContactName == "" || allContactName === null)) {
					                        var allContactList = allContactName.split(',');
					                        $('#' + taskContactID + '').append('<ul></ul>');
					                        for (i = 1; i < allContactList.length; i++) {
					                            $('#' + taskContactID + '' + ' ul' + '').append('<li>' + allContactList[i] + '</li>');
					                        }
					                    }
					                    _self.registerTaskActionListeners(_self);
					                }
					            }
					            Analytics.analytics.recordAction('taskListView:individualTaskExpand:clicked');
					        }
					    },
					    sortTaskList: function (e) {
					        Analytics.analytics.recordAction('taskListView:sortTasklist:clicked');
					        var _$this = $(e.currentTarget);
					        var _$thisSpan = _$this.find("span.sorticons");
					        var _desc = false;
					        var sortField = _$this.data('sort-key');
					        _$thisSpan.addClass('active');
					        $('.sort-current-task').find('.sorticons:not(.active)').removeClass('asc-icon desc-icon');
					        $('.sorticons').removeClass('active');
					        if (_$thisSpan.hasClass("desc-icon")) {
					            _$thisSpan.removeClass("desc-icon").addClass("asc-icon");
					            _desc = false;
					        }
					        else if (_$thisSpan.hasClass("asc-icon")) {
					            _$thisSpan.removeClass("asc-icon").addClass("desc-icon");
					            _desc = true;
					        }
					        else {
					            _$thisSpan.addClass("asc-icon");
					            _desc = false;
					        }
					        var _sortOptions = {
					            key: sortField,
					            desc: _desc,
					            data: $.extend([], this.taskList)
					        };
					        this.state.sort = {
					            key: sortField,
					            desc: _desc
					        };
					        this.state.edit = false;
					        this.state.add = false;
					        this.updateTaskList(_sortOptions);
					    },
					    updateTaskList: function (sortOptions, noSort) {
					        var _taskList = sortOptions.data;
					        if (!noSort) {
					            this.objSort(_taskList, [sortOptions.key, sortOptions.desc]);
					        }
					        this.objSort(_taskList, [sortOptions.key, sortOptions.desc]);
					        var _$taskListCtnr = $('#current-task-list-ctnr');
					        var _tasklist = { taskList: _taskList };
					        var _taskListItemTemplate = _.template(TaskListItemTemplate);
					        var _dataLoadedTemplete = _taskListItemTemplate(_tasklist);
					        _$taskListCtnr.html(_dataLoadedTemplete);
					        this.registerTaskActionListeners(this);
					    },
					    loadFutureTask: function (e) {
					        var _self = this;
					        var _$this = $(e.currentTarget),
					    		_startDate = _$this.data('start-date');
					        Spinner.show();
					        Analytics.analytics.recordAction('taskListView:s:clicked');
					        Dataservice.getFutureTaskList(TaskContext.getTaskFMID(), _startDate).then(getFutureTaskListSuccess).fail(_self.gotoError);
					        function getFutureTaskListSuccess(taskList) {
					            $('#displaying-through').html("Displaying through " + moment(_startDate).add(6, "days").format("MM/DD/YY"));
					            Spinner.hide();
					            if (!taskList) {
					                return;
					            }
					            var _futureTaskList = taskList[0].get('tasks');
					            //$('#load-beyond-date').html(moment(_startDate).add(6,"days").format("MM-DD-YYYY"));
					            $('#show-more-text').data('start-date', moment(_startDate.replace(/-/g, "/")).add(7, "days").format("YYYY-MM-DD"));
					            var _$taskHeaders = $('.sort-current-task');
					            if (_futureTaskList.length > 0) {
					                _self.customizeTaskList(_futureTaskList);
					                _self.taskList = _self.taskList.concat(_futureTaskList);
					                var _sortHeader = "", _sortOptions = {};
					                //do the sorting based on current selected sorting
					                if (_$taskHeaders.find('span.asc-icon').length > 0 || _$taskHeaders.find('span.desc-icon').length > 0) {
					                    if (_$taskHeaders.find('span.asc-icon').length > 0) {
					                        _sortHeader = _$taskHeaders.find('span.asc-icon').parent();
					                        _sortOptions = {
					                            key: _sortHeader.data('sort-key'),
					                            desc: false,
					                            data: $.extend([], _self.taskList)
					                        };
					                    } else {
					                        _sortHeader = _$taskHeaders.find('span.desc-icon').parent();
					                        _sortOptions = {
					                            key: _sortHeader.data('sort-key'),
					                            desc: true,
					                            data: $.extend([], _self.taskList)
					                        };
					                    }
					                    _self.updateTaskList(_sortOptions);
					                } else {
					                    //_self.objSort( _self.taskList,"startDate","subject","priorityNum");
					                    _self.updateTaskList({ key: '', desc: false, data: _self.taskList }, true);
					                }

					            }

					        }
					    },
					    render: function (selectedUserFMID) {
					        window.scrollTo(0, 0);
					        _self = this;
					        Spinner.show();
					        var _startDate = moment(new Date()).utc().format('YYYY-MM-DD');
					        var tmpTemplate = _.template(TaskListTemplate);
					        _self.$el.html(tmpTemplate({}));
					        _self.renderTaskHeader();
					        $('.task-list-container').html('');

					        (typeof practicetech.modules.tasks === 'undefined') ? practicetech.modules.tasks = new practicetech.createNew.module() : "";

					        if (practicetech.modules.tasks.state != undefined && (
								practicetech.modules.tasks.state.edit == true || practicetech.modules.tasks.state.add == true)) {
					            _self.state.sort.key = practicetech.modules.tasks.state.sort.key;
					            _self.state.sort.desc = practicetech.modules.tasks.state.sort.desc;
					        } else {
					            _self.state.sort.key = 'startDate';
					            _self.state.sort.desc = false;
					        }

					        var servicePromises = [Dataservice.getTasksList(TaskContext.getTaskFMID(), _startDate)];
					        var retrieveTaskUsers = CommonUtilis.isEmpty(TaskContext.getUserList());
					        if (retrieveTaskUsers) {
					            //GetSharedUsers service
					            servicePromises.push(Dataservice.getSharedTasksUserList(TaskContext.getTaskFMID()));
					            //Dataservice.getSharedCalendarUserList(CommonUtilis.readCookie('FMID')).then(getSharedUsersList).fail(_self.gotoError);
					        }

					        Q.allSettled(servicePromises).then(function (results) {
					            if (retrieveTaskUsers) {
					                _self.showTasksSharedUsers(results[1].value[0]);
					                _self.renderTaskHeader();
					            }
					            gotoTaskList(results[0].value);
					        }).fail(gotoError);

					        function gotoTaskList(taskList) {
					            try {
					                Spinner.show();
					                if (taskList != undefined && taskList[0] != undefined && taskList[0].get('tasks') != undefined) {
					                    var _sortedTaskList = taskList[0].get('tasks');
					                    var _customizedTaskList = _self.customizeTaskList(_sortedTaskList), _copyOfCustomTaskList = $.extend([],_customizedTaskList);
					                    _self.taskList = _customizedTaskList;
					                    _self.objSort(_copyOfCustomTaskList, [_self.state.sort.key, _self.state.sort.desc]);
					                    var _taskList = { "taskList": _copyOfCustomTaskList };

					                    var _taskListItemTemplate = _.template(TaskListItemTemplate);
					                    var _dataLoadedTaskTemplete = _taskListItemTemplate(_taskList);
					                    _self.$el.html(tmpTemplate({}));
					                    _self.renderTaskHeader();
					                    var _$currentTaskListCtnr = $('#current-task-list-ctnr');
					                    _$currentTaskListCtnr.html(_dataLoadedTaskTemplete);
					                    $('#displaying-through').html("Displaying through " + moment(_startDate).add(6, "days").format("MM/DD/YY"));
					                    $('#show-more-text').data('start-date', moment(_startDate.replace(/-/g, "/")).add(7, "days").format("YYYY-MM-DD"));
					                }
					            } catch (e) {
					                ErrorLog.ErrorUtils.myError(e, true);
					                Spinner.hide();
					            }
					            _self.registerTaskActionListeners(_self);
					            Spinner.hide();
					        }

					        function gotoError(Error) {
					            Spinner.hide();
					        };
					    },
					    renderTaskHeader: function () {
					        this.$('#pt-task-header').html(
                                this.headerTemplate(
                                    {
                                        multiuser: TaskContext.getUserList().length > 1,
                                        taskOwnerPossesiveName: this.currentTaskUserPossesiveName(),
                                        taskOwnerName: this.currentTaskUserName()
                                    }
                                ));
					    },
					    renderTaskUserPicker: function () {
					        if (this.oboUserPickerView) { this.oboUserPickerView.close(); }
					        this.oboUserPickerView = new OBOUserPickerView({ el: this.$('#pt-task-user-picker').get(0) });
					        this.oboUserPickerView.userList = TaskContext.getUserList();
					        this.oboUserPickerView.selectedUserFmid = TaskContext.getTaskFMID();
					        this.oboUserPickerView.render();
					        this.oboUserPickerView.userSelected = this.taskUserChangeHandler;
					    },
					    taskUserChangeHandler: function (selectedFmid) {
					        _self.state.edit = true;
					        _self.loadOrSaveTask();
					        _self.taskList = {};
					        TaskContext.saveLastTaskFMID(selectedFmid);
					        _self.render(selectedFmid);
					    },
					    currentTaskUserPossesiveName: function () {
					        var taskUser = this.currentTaskUser();
					        if (!taskUser) { return null; }
					        var name = '';
					        if (CommonUtilis.isEmpty(taskUser.firstName)) {
					            if (CommonUtilis.isEmpty(taskUser.name)) {
					                return name;
					            }
					            var nameParts = taskUser.name.split(' ');
					            name = nameParts[0];
					            if (name.length > 10) {
					                name = name.substring(0, 10).trim() + '&hellip;';
					            } else if (nameParts.length > 1) {
					                name += ' ' + nameParts[1].substring(0, 1);
					            }
					        } else {
					            name = taskUser.firstName;
					            if (name.length > 10) {
					                name = name.substring(0, 10).trim() + '&hellip;';
					            } else if (!CommonUtilis.isEmpty(taskUser.lastName)) {
					                name += ' ' + taskUser.lastName.substring(0, 1);
					            }
					        }
					        return name + '&#8217;s';
					    },
					    currentTaskUserName: function () {
					        var taskUser = this.currentTaskUser();
					        return taskUser == null ? '' : taskUser.firstName + ' ' + taskUser.lastName;
					    },
					    currentTaskUser: function () {
					        if (CommonUtilis.isEmpty(TaskContext.getUserList())) {
					            return null;
					        }
					        var taskFMID = TaskContext.getTaskFMID();
					        return _.find(TaskContext.getUserList(), function (user) {
					            return taskFMID == user.fmid;
					        });
					    },
					    registerTaskActionListeners: function (view) {
					        $('[pt-task-complete-button]').off('click').on('click', function () {
					            view.completeTaskClicked($(this).attr('pt-task-complete-button'));
					        });
					        $('[pt-task-remove-button]').off('click').on('click', function () {
					            view.removeTaskClicked($(this).attr('pt-task-remove-button'));
					        });
					        $('[pt-task-edit-button]').off('click').on('click', function () {
					            view.editTaskClicked($(this).attr('pt-task-edit-button'));
					        });
					        if (practicetech.modules.tasks.state != undefined && ((practicetech.modules.tasks.state.edit != undefined && practicetech.modules.tasks.state.edit != false) ||
								(practicetech.modules.tasks.state.add != undefined && practicetech.modules.tasks.state.add != false))) {
					        	practicetech.modules.tasks.state.edit = false;
					        	practicetech.modules.tasks.state.add = false;
					            if (practicetech.modules.tasks.state.sort.key === 'startDate' && practicetech.modules.tasks.state.sort.desc === true) {
					                $('#ascdscstartDate').removeClass("asc-icon");
					                $('#ascdscstartDate').addClass("desc-icon");
					            } if (practicetech.modules.tasks.state.sort.key != 'startDate') {
					                if (practicetech.modules.tasks.state.sort.desc === true) {
					                    $('#ascdscstartDate').removeClass("asc-icon");
					                    $('#ascdsc' + practicetech.modules.tasks.state.sort.key).addClass("desc-icon");
					                } else {
					                    $('#ascdscstartDate').removeClass("asc-icon");
					                    $('#ascdsc' + practicetech.modules.tasks.state.sort.key).addClass("asc-icon");
					                }
					            }
					        }
					    },
					    completeTaskClicked: function (taskId) {
					        this.state.edit = true;
					        var _self = this;
					        var task = this.taskWithId(taskId);
					        BootstrapDialog.confirm(
								'Mark Done',
								'Are you sure you want to mark task <span class="pt-data-label-demi">"' + _self.taskSubject(task) + '"</span> done?',
								function (result) {
								    if (result) {
								        _self.updateTaskStatus(task, 'Done');
								        Analytics.analytics.recordAction('taskListView:individualTaskCompleteCofirmed:clicked');
								    } else {
								        Analytics.analytics.recordAction('taskListView:individualTaskCompleteNotConfirmed:clicked');
								    }
								},
								'pt-task-mark-done-confirm-dialog',
								"No",
								"Yes");
					    },
					    removeTaskClicked: function (taskId) {
					        this.state.edit = true;
					        var _self = this;
					        var task = this.taskWithId(taskId);
					        new BootstrapDialog({
					            title: 'Remove',
					            message: 'Are you sure you want to remove task <span class="pt-data-label-demi">"' + _self.taskSubject(task) + '"</span>?',
					            closable: true,
					            cssClass: 'pt-task-remove-confirm-dialog',
					            buttons: [{
					                label: 'Yes, permanently delete it',
					                cssClass: 'btn-primary pt-btn-yes',
					                action: function (dialog) {
					                    dialog.close();
					                    _self.deleteTask(task);
					                    Analytics.analytics.recordAction('taskListView:individualTaskRemovePermanentlyDeleted:clicked');
					                }
					            }, {
					                label: 'Yes, cancel it',
					                cssClass: 'btn-primary pt-btn-no',
					                action: function (dialog) {
					                    dialog.close();
					                    _self.updateTaskStatus(task, 'Cancelled');
					                    Analytics.analytics.recordAction('taskListView:individualTaskRemoveCancelled:clicked');
					                }
					            }, {
					                label: 'No',
					                cssClass: 'btn-primary pt-btn-no',
					                action: function (dialog) {
					                    Analytics.analytics.recordAction('taskListView:individualTaskRemoveNotRemoved:clicked');
					                    dialog.close();
					                }
					            }]
					        }).open();
					    },
					    beforeClose: function () {
					        if (this.oboUserPickerView) {
					            this.oboUserPickerView.close();
					        }
					    },
					    editTaskClicked: function (taskId) {
					        this.state.edit = true;
					        location.href = '#crm/edittask/' + taskId;
					        Analytics.analytics.recordAction('taskListView:individualTaskEdit:clicked');
					    },
					    addTaskClicked: function () {
					    	that = this;
					    	(typeof practicetech.modules.tasks === 'undefined') ? practicetech.modules.tasks = new practicetech.createNew.module() : "";
					    	practicetech.modules.tasks.state = that.saveTaskState();
					    	this.state.add = true;
					    	location.href = '#crm/addtask';
					    },

					    taskWithId: function (taskId) {
					        return _.find(this.taskList, function (task) { return task.get('activityId') == taskId; });
					    },
					    updateTaskStatus: function (task, status) {
					        var _self = this;
					        Spinner.show();
					        Dataservice.getTaskDetails(TaskContext.getTaskFMID(), task.get('activityId')).then(function (taskArray) {
					            var breezeTask = taskArray[0];
					            var updateTask = new Task();
					            updateTask.populateFromBreezeEntity(breezeTask);
					            updateTask.set('status', status);
					            return updateTask;
					        }).then(function (task) {
					            return Dataservice.updateTask(TaskContext.getTaskFMID(), task);
					        }).then(function (updateResponse) {
					            if (updateResponse == 'Failed') {
					                ErrorLog.ErrorUtils.myError(new Error('Ebix returned fail when attempting to update task'));
					            }
					        }).then(_self.render).fail(_self.gotoError);
					    },
					    deleteTask: function (task) {
					        var _self = this;
					        Spinner.show();
					        Dataservice.deleteTask(TaskContext.getTaskFMID(), task.get('activityId')).then(function (deleteResponse) {
					            //if (deleteResponse == 'Failed') {
					            //	ErrorLog.ErrorUtils.myError(new Error('Ebix returned fail when attempting to delete task'));
					            //}
					        }).then(_self.render).fail(_self.gotoError);
					    },
					    taskSubject: function (task) {
					        var subject = (task.get('subject') || '').trim();
					        if (subject.length == 0) {
					            return "No Subject";
					        } else if (subject.length > 50) {
					            return subject.substring(0, 50).trim() + '&#8230;';
					        } else {
					            return subject;
					        }
					    },
					    customizeTaskList: function (taskList) {
					        var _today = moment(moment(new Date()).format('MM/DD/YYYY')), _tasks = [];
					        if (taskList && taskList.length == 0) {
					            return _tasks;
					        }
					        taskList.forEach(function (task, index) {
					            var _startDate = task.get('startDate');
					            switch (task.get('priority')) {
					                case "High":
					                    task.set('priorityNum', 1);
					                    break;
					                case "Medium":
					                    task.set('priorityNum', 2);
					                    break;
					                case "Low":
					                    task.set('priorityNum', 3);
					                    break;
					                default:
					                    task.set('priorityNum', 4);
					                    break;
					            }
					            if (_startDate != null) {
					                var _mStartDtae = moment(task.get('startDate').replace(/-/g, "/"));
					                task.set('fmtStartDate', _mStartDtae.format('MM/DD/YY'));
					                _tasks.push(task);
					            }
					            if (task.get('endDate') && task.get('endDate') != null) {
					                var _mToday = _today;
					                var _mEndDate = moment(task.get('endDate').replace(/-/g, "/"));
					                task.set('fmtEndDate', _mEndDate.format('MM/DD/YY'));
					                if (_mEndDate < _mToday) {
					                    task.set('overdue', true);
					                }
					            }
					            if (task.get('dueDate') && task.get('dueDate') != null) {
					                var _mToday = _today;
					                var _mDueDtae = moment(task.get('dueDate').replace(/-/g, "/"));
					                task.set('fmtDueDate', _mDueDtae.format('MM/DD/YY'));
					                if (_mDueDtae < _mToday) {
					                    task.set('overdue', true);
					                }
					            }
					        });
					        return _tasks;
					    },
					    objSort: function () {
					        var args = arguments, array = args[0], case_sensitive, keys_length, key, desc, a, b, i, keyName = args[1], argumentsAttributes;
					        if (typeof arguments[arguments.length - 1] === 'boolean') {
					            case_sensitive = arguments[arguments.length - 1];
					            keys_length = arguments.length - 1;
					        } else {
					            case_sensitive = false;
					            keys_length = arguments.length;
					            if (keyName[0] === "contactName") {
					                var argumentsLength = arguments[0].length;
					                for (i = 0; i < argumentsLength; i++) {
					                    argumentsAttributes = arguments[0][i].attributes;
					                    if (argumentsAttributes.contactId !== null && argumentsAttributes.contactFirstName !== null && argumentsAttributes.contactLastName !== null) {
					                        var contactName = "";

					                        contactName = argumentsAttributes.contactLastName + ", " + argumentsAttributes.contactFirstName;
					                        argumentsAttributes.contactName = contactName;
					                    }
					                }
					            }

					        }
					        return array.sort(function (obj1, obj2) {
					            for (i = 1; i < keys_length; i++) {
					                key = args[i];
					                if (typeof key !== 'string') {
					                    desc = key[1];
					                    key = key[0];
					                    a = obj1.get(args[i][0]);
					                    b = obj2.get(args[i][0]);
					                } else {
					                    desc = false;
					                    a = obj1.get(args[i]);
					                    b = obj2.get(args[i]);
					                }
					                if (key == "startDate" || key == "dueDate") {
					                    if (a == null) {
					                        desc ? a = 0 : a = 11111111111111111111111111111;
					                    } else {
					                        a = new Date(a.replace(/-/g, "/")).getTime();
					                    } if (b == null) {
					                        desc ? b = 0 : b = 11111111111111111111111111111;
					                    } else {
					                        b = new Date(b.replace(/-/g, "/")).getTime();
					                    }

					                } else if (case_sensitive === false && (typeof a === 'string' || typeof a === "object" || typeof b === "object")) {
					                    a = (a === null) ? (desc == true ? "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" : "zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz") : "" + a.toLowerCase();
					                    b = (b === null) ? (desc == true ? "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" : "zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz") : "" + b.toLowerCase();
					                }

					                if (desc == true)
					                    return a < b ? 1 : (a === b ? 0 : -1);
					                else
					                    return a > b ? 1 : (a === b ? 0 : -1);
					                //return 0;
					            }
					            return 0;
					        });
					    },
					    gotoError: function (error) {
					        Spinner.hide();
					        ErrorLog.ErrorUtils.myError(Error, true);
					    },
					    taskShowUsersClick: function (e) {
					        if (TaskContext.getUserList().length > 1) {
					            this.renderTaskUserPicker();
					        }
					    },
					    showTasksSharedUsers: function (sharedUsersResponse) {
					        var taskUsers = [];
					        _.each(sharedUsersResponse.get('sharedUsers'), function (sharedUser) {
					            var user = {
					                fmid: sharedUser.get('extLink'),
					                ebixUserIdentifier: sharedUser.get('userId'),
					                name: sharedUser.get('fullName'),
					                firstName: sharedUser.get('firstName'),
					                lastName: sharedUser.get('lastName')
					            }
					            taskUsers.push(user);
					        });
					        //console.log("taskUsers: " + taskUsers);
					        TaskContext.setUserList(taskUsers);
					    }
					});
		    return taskList;
		});