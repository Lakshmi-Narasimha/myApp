var express = require('express');
var https = require('https');
var logger = require('../../../config/logger');
var querystring = require('querystring');
var router = express.Router();
var config = require('/app/conf/properties/mfchatnode/config');
var apiUtils = require('../../common/apiUtils');
var conversionModel = require('../conversion/conversion.model');
var proxy = require('../../../config/proxy')

// api route
router.route('/mfchatnode/rest/conversion')
    .post(function(req, res) {  
        logger.general.info(logger.formatInfoMsg(req.session.id,"Conversion api call from App"));      
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.body.RequestParams = req.body.RequestParams || {};  
        req.session.MDN = req.body.RequestParams.mdn;       
        apiUtils.conversion(req, res, function(chunk) {  
            try{
               chunk = JSON.parse(chunk);    
            }catch(e){                
               logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json"));               
            }          
            if(!chunk.customerId){
                logger.general.info(logger.formatInfoMsg(req.session.id,"Customer was not helped by any agent, no Converions call"));
                res.status(200).end();
            }else{
                if(req.body.RequestParams.clientOrderConfirmNum.includes("Order #")){
                    conversionModel.request.clientOrderNumber = apiUtils.formatOrderNum(req.body.RequestParams.clientOrderConfirmNum);
                }else if(req.body.RequestParams.clientOrderNumber.includes("Order #")){
                    conversionModel.request.clientOrderNumber = apiUtils.formatOrderNum(req.body.RequestParams.clientOrderNumber);
                }
                if(req.body.RequestParams.ReviewMonthlyBillBrkdnDetails && req.body.RequestParams.ReviewMonthlyBillBrkdnDetails.flow){
                    conversionModel.request.orderType = req.body.RequestParams.ReviewMonthlyBillBrkdnDetails.flow;
                }
                conversionModel.request.tcCustomerID = chunk.customerId;
                conversionModel.request.products = apiUtils.getProducts(req);                 
                
                //var postBody = querystring.stringify(conversionModel.request);

                var reqObj = {
                    host: config.TC_SERVER_NAME,
                    method: 'POST',
                    path: config.TC_CONVERSION_URI,
                    agent: proxy.agent,
                    ca:proxy.ca,
                    headers: {
                        'Content-Type': 'application/json',
                        'Cookie': req.session.sessionCookie
                    }
                };
                logger.general.info(logger.formatOutBoundReqMsg(reqObj, conversionModel.request, req.session.id));
                
                var proxyRequest = https.request(reqObj, function(proxyResponse) {
                    proxyResponse.setEncoding('utf8');
                   if (proxyResponse.statusCode === 200) {  
                       logger.general.info(logger.formatOutBoundResMsg(reqObj, {statusCode:proxyResponse.statusCode}, req.session.id));                      
                        res.status(200).end();
                    }else{
                        var errObj = {
                            message: proxyResponse.statusMessage,
                            statusCode: proxyResponse.statusCode
                        };
                        logger.error.error(logger.formatOutBoundReqMsg(reqObj, conversionModel.request, req.session.id)); 
                        logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                        res.send(errObj);  
                    } 
                    proxyResponse.on('error', function(err) {
                        logger.error.error(logger.formatOutBoundReqMsg(reqObj, conversionModel.request, req.session.id));
                        logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                        res.send(err);

                    });
                });

                proxyRequest.write(JSON.stringify(conversionModel.request));
                proxyRequest.end();
             }

        });        
    });

module.exports = router;
