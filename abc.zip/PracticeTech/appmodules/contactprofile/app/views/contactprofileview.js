define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'appmodules/contactprofile/app/models/cpviewmodel',
    'text!appmodules/contactprofile/app/templates/contactprofilegeneral.html',
    'text!appmodules/contactprofile/app/templates/contactprofilephone.html',
    'text!appmodules/contactprofile/app/templates/contactprofileaddress.html',
    'text!appmodules/contactprofile/app/templates/contactprofilescheduledaddrs.html',
    'text!appmodules/contactprofile/app/templates/contactprofileemail.html',
    'text!appmodules/contactprofile/app/templates/prospectphone.html',
    'text!appmodules/contactprofile/app/templates/prospectemail.html',
    'text!appmodules/contactprofile/app/templates/prospectaddress.html',
    'text!appmodules/contactprofile/app/templates/prospectrelations.html',
    'appcommon/globalcontext',
    'appcommon/analytics',
    'errorLog',
    'appmodules/nav/app/models/contactdetails',
    'apipublic/navapi',
	'apipublic/rolesapi',
    'appcommon/constants',
    'appcommon/nativeadaptor',
    'appcommon/hocindicator',
    'config',
    'appcommon/globalcontext',
    'appcommon/applauncher/device',
    'appcommon/commonutility',
    'appcommon/CPDataLoadModule',
    'appmodules/ncst/app/data/country-list',
    'text!appmodules/contactprofile/app/templates/groupingTemplate.html',
], function ($, _, Backbone, Spinner, cpCommon, DataService, CPViewModel, contactProfileGeneralTemplate, contactProfilePhoneTemplate, contactProfileAddressTemplate, contactProfileSchdAddrsTemplate, 
        contactProfileEmailTemplate, ProspectPhone, ProspectEmail, ProspectAddress, ProspectRelations, Context, Analytics, ErrorLog, ContactDetailsModel, NavApi, Roles, Constants, NativeAdaptor, HOCIndicator, Config, GlobalContext, Device, CommonUtilityPopover, CPDataModule, DropdownListData, GroupingTemplate) {
    var handlePopoverEvent = null, groupingDetails = { "grpDetailsReady": false }, self = null, countOfHouseHoldGrp = 0, countOfPensionGrp = 0, countOfCSGGrp = 0; //Groups
    var contactProfileView = Backbone.View.extend({
        el: $("#cp-content-container"),
        id: 'cp-content-container',
        events: {},

        initialize: function () {
            var _gContext;
            var _pinnedClient;
            try {
                _gContext = GlobalContext.getInstance().getGlobalContext().Context;
                _pinnedClient = NavApi.getSelecetdContactdetails(_gContext.AdvisorFMID, _gContext.ContactId);                
                var _name = (_pinnedClient !== undefined) ? (_pinnedClient.orgNm !== undefined ? _pinnedClient.orgNm : (_pinnedClient.firstNm + " " + _pinnedClient.lastNm)) : "";
                groupingDetails = { "clientName": _name, "clientId": _gContext.ContactId, "grpDetailsReady": false, "cprendered": false, "f2c": {}, "pa": {}, "acs": {}, "f2cServiceCount": 0, "paServiceCount": 0, "dependencyModuleCount": 2, "dependencyLoadedCount": 0, "serviceStatus": false };
                this.clientId = null;
                this.contactId = null;
                var that = self = this;
                this.grpupSectionRendered = false;

                $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                $(".hdr-tab-buttons-wrap .bt-contact").addClass("hdr-tab-active");
                $(document).off("click", ".cp-edit-client-details").on("click", ".cp-edit-client-details", function (e) {
                    that.editclient(e);
                });
                $(document).off("click", ".keyRelationsCP").on("click", ".keyRelationsCP", function (e) {
                

                    practicetech.modules.contactprofile === undefined;
                    that.gotoClientProfile(e);
                });            
                $(document).off('click', '#viewPersonal').on('click', '#viewPersonal', function (e) {
                    that.toggleViewMode("view", 'drawerClickEvent', 'Personal');
                });
                $(document).off('click', '.js-savestate').on('click', '.js-savestate', function (e) {
                    that.loadOrSave(e);
                });
                $(document).off('click', '#editPersonal').on('click', '#editPersonal', function (e) {
                    that.toggleViewMode("edit", 'drawerClickEvent', 'Personal');
                });

                $(document).off('click', '#viewDetails').on('click', '#viewDetails', function (e) {
                    that.toggleViewMode("view", 'drawerClickEvent', 'Details');
                });
                $(document).off('click', '#editDetails').on('click', '#editDetails', function (e) {
                    that.toggleViewMode("edit", 'drawerClickEvent', 'Details');
                });
            
                $(document).off('click', '#viewGroups').on('click', '#viewGroups', function (e) {
                    that.toggleViewMode("view", 'drawerClickEvent', 'Groups');
                });
                $(document).off('click', '#editGroups').on('click', '#editGroups', function (e) {
                    if (countOfHouseHoldGrp == 0 && countOfPensionGrp > 0 && countOfCSGGrp == 0) {
                        //Only Pension Groups
                        BootstrapDialog.alert("Your request cannot be completed because pension groups cannot be edited online.", "", "Editing disabled");
                    } else if (countOfHouseHoldGrp == 0 && countOfPensionGrp == 0 && countOfCSGGrp == 0) {
                        //No Groups
                        BootstrapDialog.alert("Your request cannot be completed because the client is not associated with any groups.", "", "Editing disabled");
                    } else {
                        that.toggleViewMode("edit", 'drawerClickEvent', 'Groups');
                    }
                });
            
                $(document).off('click', '.drawerable').on('click', '.drawerable', function (e) {
                    that.drawerToggle(event.target.id, 'drawerClickEvent');
                });

                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-citizenship").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-citizenship", function (e) {
                    that.RouteToGPM(e);
                });
                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-second-citizenship").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-second-citizenship", function (e) {
                    that.RouteToGPM(e);
                });
                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-taxtreaty-cntry ").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-taxtreaty-cntry ", function (e) {
                    that.RouteToGPM(e);
                });
                $(document).off("click", ".cp-info h2 .pt-edit-icon, .cp-edit-clientsdeath, .cp-edit-clientsdivorce").on("click", ".cp-info h2 .pt-edit-icon, .cp-edit-clientsdeath, .cp-edit-clientsdivorce", function (e) {
                    that.RouteToGPM(e);
                });
                $(document).off("click", "#changeAddressLink").on("click", "#changeAddressLink", function (e) {
                    that.gottoCOA(e);
                });

                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-indst-classification").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-indst-classification", function (e) {
                    that.RouteToGPM(e);
                });

                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-operating-entity").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-operating-entity", function (e) {
                    that.RouteToGPM(e);
                });

                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-legally-established").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-legally-established", function (e) {
                    that.RouteToGPM(e);
                });

                $(document).off("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-entity-type").on("click", ".cp-info  h3  .pt-edit-icon,#cp-edit-entity-type", function (e) {
                    that.RouteToGPM(e);
                });

                $(document).off("click", ".cp-LaunchGPM").on("click", ".cp-LaunchGPM", function (e) {
                    that.RouteToGPM(e);
                });

                $(document).off('click', '#launchHOCBtn').on('click', '#launchHOCBtn', function (e) {
                    that.launchHOCBtn(e);
                });
            
                $(document).off('click', '#launchClientsDeath').on('click', '#launchClientsDeath', function (e) {
                    that.RouteToGPM(e);
                });

                $(document).off("keydown").on("keydown", function (e) {
                    that.analyticsPrint(e);
                });
                $(document).off('click', '.pt-scheduled-address-edit').on('click', '.pt-scheduled-address-edit', function (e) {
                    that.editScheduledAddress(e);
                });
            
                $(document).off('click', '.grouping-view-accounts-link').on('click', '.grouping-view-accounts-link', function (e) {
                    that.linktoAccountsPage(e);
                });
                $(document).off('click', '.edit-house-hold-grp-members,.edit-consoildated-stmnt-grp,#csg-cration-link').on('click', '.edit-house-hold-grp-members,.edit-consoildated-stmnt-grp,#csg-cration-link', function (e) {
                    that.linkoutToEformsGroupingWorkflow(e);
                });
                $(document).off('click', '.showhide-details').on('click', '.showhide-details', function (e) {
                    CommonUtilityPopover.plShowHide(e, "(Show details)", "(Hide details)");
                });
                $(document).off('click', '#cp-accuracy-completeness').on('click', '#cp-accuracy-completeness', function (e) {
                    BootstrapDialog.show({
                        title: "Attestation",
                        message: "The servicing advisor or another advisor (in the case of a team practice) reviewed the complete profile with the client to validate the information is current.",
                        buttons: [
                                {
                                    label: 'Cancel',
                                    cssClass: 'btn pt-btn-yes generic-button btn-primary pl-margin-rt-15px',
                                    action: function (dialog) {
                                        dialog.close();
                                    }
                                },
                                {
                                    label: 'Attest',
                                    cssClass: 'btn pt-btn-yes generic-button btn-primary',
                                    action: function (dialog) {
                                        //Action code comes here
                                    }
                                }]
                    });

                });

                /*$(document).off('click', '#ssn-tin').on('click', '#ssn-tin', function (e) {
                    console.log("e.target: " + e.target);
                    //$(e.target).invokeInfoPopup({ lg_screenposition: "right", sm_screenposition: "bottom", window_width: 768 });
                });*/
            
                function ViewSetter() { // if there is an viewSet data, execute on it.
                    var scrollPos = opts.scrollPos || 0;

                    window.scrollTo(0, 0);
                    if (options.action) {
                        (opts.actions.suitability) ? that.drawerToggle('#personalDetails') : that.drawerToggle('#entityDetails');
                    }

                };
            
                $(document).off("groupComponentReady").on("groupComponentReady", that.groupComponentReady);
            
                $(document).off("cprendered").on("cprendered", that.cprendered);
                window.onafterprint = function () {
                    if (window.location.hash === '#contactprofile/') {
                        Analytics.analytics.recordAction('Print:contactProfile');
                    }
                };
            }
            catch (err) {
                if (ContactDetailsModel !== undefined && ContactDetailsModel.advsiorContacts !== undefined
                       && ContactDetailsModel.advsiorContacts.currentadvsiorContacts !== undefined
                        && ContactDetailsModel.advsiorContacts.currentadvsiorContacts[_gContext.AdvisorFMID] !== undefined) {
                    var errMessage = err.message
                    if (CommonUtilityPopover.readCookie('firstLaunch') != null) {
                        errMessage = errMessage + "; CVFirstLaunch: " + CommonUtilityPopover.readCookie('firstLaunch');
                    }
                    errMessage = errMessage + "; Contacts count: " + ContactDetailsModel.advsiorContacts.currentadvsiorContacts[_gContext.AdvisorFMID].length;

                    var _customLog = {
                        "message": errMessage,
                        "stack": {
                            "description": "This is for debugging and analysis purpose."
                        }
                    }
                    ErrorLog.ErrorUtils.myError(_customLog, true);
                }
                ErrorLog.ErrorUtils.myError(err, false);
            }
        },
        analyticsPrint: function (e) {
        	if (window.location.hash === '#contactprofile/' && (window.chrome)) {
             if (e.ctrlKey && e.keyCode == 80) {
             	Analytics.analytics.recordAction('Print:contactProfile');
             }
         }        
        },
        toggleViewMode: function (mode, triggeredByClickEvent, target) {
            //this can be tuned up - but may change
            if (target != undefined || typeof (target) != "undefined")
                var temp = target.toLowerCase();
            if (mode === "view") {
                $("#" + temp + "EntityDetailsDrawer .pt-edit-icon, #" + temp + "EntityDetailsDrawer .cp-edit-clientsdeath, #" + temp + "EntityDetailsDrawer .cp-edit-clientsdivorce, #" + temp + "EntityDetailsDrawer .cp-edit-key-relations, #" + temp + "EntityDetailsDrawer .cp-edit-practice-assigned-advisor, #" + temp + "EntityDetailsDrawer .cp-edit-referred-by").hide().addClass("hidden");

                $('#second-citizenship-cntry-edit-popup, #industry-classification-edit-popup').addClass('hidden');
                $('#second-citizenship-cntry-view-popup, #industry-classification-view-popup').removeClass('hidden');

                if (temp == "personal") {
                	$('#cp-edit-citizenship').hide();
                    $('#cp-edit-second-citizenship').hide();
                    $('#cp-edit-taxtreaty-cntry').hide();
                	if (triggeredByClickEvent) {
                		Analytics.analytics.recordAction('contactProfilePersonalView:clicked');
                	}
                }
                $("#edit" + target).removeClass('active');
                $("#view" + target).addClass('active');                
            } else {
                $("#" + temp + "EntityDetailsDrawer .pt-edit-icon, #" + temp + "EntityDetailsDrawer .cp-edit-clientsdeath, #" + temp + "EntityDetailsDrawer .cp-edit-clientsdivorce, #" + temp + "EntityDetailsDrawer .cp-edit-key-relations, #" + temp + "EntityDetailsDrawer .cp-edit-practice-assigned-advisor, #" + temp + "EntityDetailsDrawer .cp-edit-referred-by").show().removeClass("hidden");

                $('#second-citizenship-cntry-edit-popup, #industry-classification-edit-popup').removeClass('hidden');
                $('#second-citizenship-cntry-view-popup, #industry-classification-view-popup').addClass('hidden');

                if (temp == "personal") {
                	$('#cp-edit-citizenship').show();
                    $('#cp-edit-second-citizenship').show();
                    $('#cp-edit-taxtreaty-cntry').show();
                	if (triggeredByClickEvent) {
                		Analytics.analytics.recordAction('contactProfilePersonalEdit:clicked');
                	}
                }
                $("#view" + target).removeClass('active');
                $("#edit" + target).addClass('active');                
            }
        },

        showSsn: function (cola) {
            var ssn = "";
            Device.operatingSystem();
            Device.physicalDevice();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
                if (cola.clientPersonal !== undefined) {
                    var s = cola.clientPersonal.attributes.taxPayerId;
                    if (s !== null) {
                        if (cola.orgClient.attributes.orgNm !== null) {
                             ssn = (s.substring(3, 5) + '-' + s.substring(5, s.length));

                        } else {
                            ssn = (s.substring(3, 6) + '-' + s.substring(6, 8) + '-' + s.substring(s.length - 4, s.length));

                        }
                    }
                }
            } else {
                if (cola.clientPersonal !== undefined) {
                    var s = cola.clientPersonal.attributes.taxPayerId;
                    if (s !== null) {
                        if (cola.orgClient.attributes.orgNm !== null) {
                            ssn = ('XX-XXX' + s.substring(s.length - 4, s.length));

                        } else {
                            ssn = ('XXX-XX-' + s.substring(s.length - 4, s.length));

                        }
                    }
                }
            }
            return ssn
        },
        launchHOCBtn: function (e) {
            e.preventDefault();
            Backbone.history.navigate("hoc/", true);
        },
        initializeSuitabilityDateInfo: function () {
            //CommonUtilityPopover.invokeInfoPopup('cpPersonalContainer', 'right', 'bottom', 768);
            //$("#cpPersonalContainer").invokeInfoPopup({ lg_screenposition: "right", sm_screenposition: "bottom", window_width: 768 });
            //$("#suitabilityDetailsDrawer").greenify({ color: "orange" });
            $('#cpPersonalContainer').invokeInfoPopup();
        },
        drawerToggle: function (drawerId, triggeredByClickEvent, fastLoad) {
            var target = null;
            var fastLoad = fastLoad || false;
            var id = "#" + drawerId;
            var additional = null;
            switch (id) {
                case '#generalDetails':
                    target = "#detailsEntityDetailsDrawer";
                    additional = "#switchDetails";
                    break;
                case '#personalDetails':
                    target = "#personalEntityDetailsDrawer"; 
                    additional = "#switchPersonal";
                    break;
                case '#entityDetails':
                    target = "#personalEntityDetailsDrawer" 
                    additional = "#switchPersonal";
                    break;
                case '#suitabilityDetails':
                    target = id + "Drawer";
                    additional = "#cp-edit-suitability"
                    break;
                case '#employmentDetails':
                    target = id + "Drawer";
                    additional = "#cp-edit-employment"
                    break;
                case '#generalDetailsDrawer':
                    target = "#detailsEntityDetailsDrawer";
                    additional = "#switchDetails";
                    break;
                case '#groupingDetails':
                    target = "#groupingDetailsDrawer";
                    additional = "#edit-goups";
                    break;
                default:
                    target = null;
                    break;
            }
            if (target === null) {
                console.log("no valid drawer assigned to this target")
                return false;
            }
            if ($(id).hasClass("closed")) {
                (fastLoad === true) ? $(target).css({ display: "block" }) : $(target).slideDown();
                $(id).removeClass("closed");

                if (additional !== null) {
                    $(additional).show();
                    if (triggeredByClickEvent) {
                        Analytics.analytics.recordAction('contactProfileDrawerOpened:' + additional);
                    }
                }

            } else {
                (fastLoad === true) ? $(target).css({ display: "none" }) : $(target).slideUp();
                $(id).addClass("closed");
                if (additional !== null) {
                    $(additional).hide();
                    if (triggeredByClickEvent) {
                        Analytics.analytics.recordAction('contactProfileDrawerClosed:' + additional);
                    }
                }
            }
        },
        cpAdditionalClick: function (e) {
            if ($(".cp-additional-info > h2").hasClass("cp-pref-information")) {
                Analytics.analytics.recordAction('contactProfileDetails:clicked');
            } else {
                if ($(".cp-additional-info > h2").hasClass("closed")) {
                    $("#additionalInfoContainer").slideDown();
                    $(".cp-additional-info > h2").removeClass("closed");
                    Analytics.analytics.recordAction('contactProfileDetails:clicked');
                }
                else {
                    $("#additionalInfoContainer").slideUp();
                    $(".cp-additional-info > h2").addClass("closed");
                }
            }
        },
        validateClientAndShowMsg: function (isGPPMEditCustomMsg) {
            if (!this.contactId) {
                if (isGPPMEditCustomMsg) {
                    BootstrapDialog.alert("Some updates cannot be made because the client cannot be found in Contact Manager.  The client might not have an active account or might be hidden.");
                } else {
                    BootstrapDialog.alert("This client cannot be found in Contact Manager. The client might not have an active account or might be hidden. <a href='https://www.askameriprise.com/app/answers/detail/a_id/26890/kw/client%20not%20in%20contact%20manager' target='_blank'>Tell me more.</a>", "", "Client not found");
                }
                return false;
            }
            return true;
        },
        gottoCOA: function (e) {
            Analytics.analytics.recordAction('gpm:updateChangeofAddressPencil:clicked');
            var url = "coa/";
            (typeof practicetech.modules.contactprofile === 'undefined') ? practicetech.modules.contactprofile = new practicetech.createNew.module() : "";
            practicetech.modules.contactprofile.state = this.saveState();
            practicetech.modules.contactprofile.state.target = e.target.id;

            Backbone.history.navigate(url, true);
        }, editScheduledAddress: function (event) {
            Analytics.analytics.recordAction('gpm:updateScheduledAddressPencil:clicked');
            var _$el = $(event.currentTarget);
            var url = "coa/" + _$el.data("case-id");
            (typeof practicetech.modules.contactprofile === 'undefined') ? practicetech.modules.contactprofile = new practicetech.createNew.module() : "";
            practicetech.modules.contactprofile.state = this.saveState();
            practicetech.modules.contactprofile.state.target = "changeScheduledAddrsLink";

            Backbone.history.navigate(url, true);
        },
        editclient: function (e) {
            if (this.validateClientAndShowMsg()) {
                var url = "navigator/editcontact/" + this.clientId;
                Backbone.history.navigate(url, true);
                NativeAdaptor.notifyContactUpdated();
            }
        },
        linktoAccountsPage: function (event) {
        	Analytics.analytics.recordAction('groups:viewAccountsAndStatements:clicked');
            var _$el = $(event.currentTarget), _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _selectedGrpId = _$el.data('group-id'), _currentGrpId = _gContext.GroupId;
            if (_selectedGrpId != _currentGrpId) {
                console.log("Seeting global context, for group change >>>>viewAccountsAndStatements -CP");
                GlobalContext.getInstance().setContext(_gContext.AdvisorFMID, _gContext.IsOBO, _gContext.ContactId, _gContext.ContactType, _gContext.ContactSource, _selectedGrpId, _gContext.IsStandalone, _gContext.QueryString, _gContext.ContextId);
            }
            (typeof practicetech.modules.contactprofile === 'undefined') ? practicetech.modules.contactprofile = new practicetech.createNew.module() : "";
            Backbone.history.navigate("accountviewer/accountstatements", true);
        },
        linkoutToEformsGroupingWorkflow: function (event) {
            var _$el = $(event.currentTarget), _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _selectedGrpId = _$el.data('group-id'), _grpType = _$el.data('group-type'), _oboId = _gContext.AdvisorFMID, _loggedInFmId = CommonUtilityPopover.readCookie('FMID');
            var _grpContxt = false;
            if (_grpType == "household" || _grpType == "cst") {
                _grpContxt = true;
            } 
            var _putContextPaylod = CommonUtilityPopover.preparePutAdvContextPayLoad(false, GlobalContext, _grpContxt, false, _selectedGrpId);
            Spinner.show();
            DataService.putAdvisorSessionContext(_putContextPaylod, false).done(function (response, status, xhr) {
                Spinner.hide();
                var _url = Config.getConfigProperty("eformsUrl");
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    if (_grpType == "household") {
                    	Analytics.analytics.recordAction('groups:editGroupMembers Pencil:clicked');
                        _url = _url + _contextId + '&formCategory=household#grouping/';
                    } else if (_grpType == "cst" || _grpType == "create-cst") {
                        Analytics.analytics.recordAction('groups:Create new statement for select accounts or accounts across groups:clicked');
                        _url = _url + _contextId + '&formCategory=clientstatements&formName=cst#grouping/';
                    }
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.prepareAndLogError(xhr);
                }
            }).fail(function (error) {
                ErrorLog.ErrorUtils.myError(error);
            });
        },
        render: function (clId, smuId) {
            practicetech.modules.tasks = new practicetech.createNew.module();
            var that = this;
            groupingDetails.clId = clId;
            practicetech.clientContext.setCaplistFullName(null);
            that.clientId = clId;
            var tmpTemplate = '';
            var asyncGrpMembCallList = [];
            var _serviceCallsStack = [], _coaCaseList = [];
            var eBixcontactDetails = null;
            window.scrollTo(0, 0);
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            function gototClientPersonalSuccess(CPServiceResponses) {
                try {
                    if (CPServiceResponses && CPServiceResponses.clientPersonalResponse && CPServiceResponses.clientPersonalResponse.length > 0) {
                        var clientPersonal = CPServiceResponses.clientPersonalResponse[0]['value'];
                        if (_isNonCMuser == false) {
                            var contactDetails = CPServiceResponses.clientPersonalResponse[1]['value'];
                        }
                    }
                    gototClientProfileSuccess(CPServiceResponses.clientProfileResponse);
                    function gototClientProfileSuccess(clientProfileResponse) {
                        if (clientProfileResponse && clientProfileResponse.length > 0) {
                            var clientInfo = clientProfileResponse[0]['value'];                           
                            if (clientProfileResponse[1] && clientProfileResponse[1]['value']) {
                                eBixcontactDetails = clientProfileResponse[1]['value'];
                        }
                        }
                        if (clientInfo != undefined) {
                            if (clientInfo[0] != undefined) {
                                if (clientPersonal != undefined) {
                                    if (clientPersonal[0] != undefined) {
                                        if ((clientInfo[0].get('clientPersonal').attributes == undefined) || (clientInfo[0].get('id') != clientInfo[0].get('clientPersonal').get('clId'))) {
                                            clientInfo[0].set({ 'clientPersonal': clientPersonal[0] }, { silent: true });
                                        }

                                        //Get Industry Classification description based on the code.
                                        var indClassDesc = "";
                                        if (clientInfo[0].attributes.riskProfile && clientInfo[0].attributes.riskProfile.indsClsCd != null
                                               && clientInfo[0].attributes.riskProfile.indsClsCd.trim() != '') {
                                            indClassDesc = getIndustryClassificationByCode(clientInfo[0].attributes.riskProfile.indsClsCd);
                                        }

                                        //stOfIncorpCd
                                        var stateDesc = "";
                                        if (clientInfo[0].attributes.orgClient && clientInfo[0].attributes.orgClient.attributes.stOfIncorpCd != null
                                            && clientInfo[0].attributes.orgClient.attributes.stOfIncorpCd.trim() != '') {
                                            stateDesc = getStateDescByCode(clientInfo[0].attributes.orgClient.attributes.stOfIncorpCd);
                                        }

                                        var generalTemplate = _.template(contactProfileGeneralTemplate);
                                        var data = {};
                                        CPViewModel.getInstance().clearData();
                                        data.cola = clientInfo[0].toJSON();
                                        CPViewModel.getInstance().setData({ 'scheduledAddress': _coaCaseList });
                                        CPViewModel.getInstance().setData({ 'cola': data.cola });
                                        var formattedId = (data !== undefined && data.cola !== undefined && data.cola.fmtId !== undefined) ? (' - ' + data.cola.fmtId.substring(0, 4) + data.cola.fmtId.substring(5)) : ' -';
                                        
                                        data.ebix = {};
                                        if (eBixcontactDetails) {
                                            data.ebix = eBixcontactDetails[0].toJSON();
                                            CPViewModel.getInstance().setData({ 'ebix': data.ebix });
                                        }
                                        data.cola.personClient.attributes.clSfxTxt = data.cola.personClient.attributes.clSfxTxt || null;
                                        if (data.cola.personClient.attributes.clMidNm !== 'undefined' && data.cola.personClient.attributes.clMidNm !== "null" && data.cola.personClient.attributes.clMidNm !== null) {
                                            practicetech.clientContext.setCaplistFullName(data.cola.personClient.attributes.clFirstNm + ':' + data.cola.personClient.attributes.clMidNm + ':' + data.cola.personClient.attributes.clLastNm + ':' + data.cola.personClient.attributes.clSfxTxt);
                                        } else {
                                            practicetech.clientContext.setCaplistFullName(data.cola.personClient.attributes.clSfxTxt);
                                        }
                                        practicetech.clientContext.getCaplistFullName();

                                        var _$grpUi = $('.pt-product-name.grp-icon');
                                       if (_$grpUi.length > 0) {
                                            //var clientName = $.trim(_$grpUi.find("a").text());
                                            //_$grpUi.html(_$grpUi.html().split(clientName)[0] + clientName + '</a>' + formattedId);
                                            //_$grpUi.append(_$grpUi.html() + formattedId);
                                            _$grpUi.html(_$grpUi.find("a")[0].outerHTML + formattedId);
                                        }

                                        var temp = data.cola, _ssn = that.showSsn(temp);
                                        //call the perfomrance anlysis logging mechanism before render
                                        CommonUtilityPopover.logFisrtViewLoadTime("CP:Profile", ErrorLog);
                                        $("#cp-content-container").html(generalTemplate({ data: data, _isNonCMuser: _isNonCMuser, ssn: _ssn, missingFieldIndicator: Constants.missingFieldIndicator, prodExpList: Constants.investmentExpList, invstExpYrsList: Constants.invExpYearRadioList, noOfTransList: Constants.noOfTransRadioList, indClassifyDesc: indClassDesc, usStateDesc: stateDesc })).promise().done(function () {
                                            groupingDetails.cprendered = true;
                                            $.event.trigger({
                                                type: "cprendered",
                                                message: { 'status': "success" }
                                            });
                                        	
                                            if (clientPersonal[0].get('bthDt') != "" && clientPersonal[0].get('bthDt') != null) {
												if (clientInfo[0] && !clientInfo[0].get('orgClient').get('orgNm')) {
													DataService.getTaxPayerAge(clientInfo[0].id)
	                								.then(function (response) {
	                									if (response != null) {
	                										if (response[0] && response[0].clAge) {
	                											$(".cp-client-age").html("(" + response[0].clAge + ")");
	                										}
	                									}
	                								})
	                								.fail(function (error) { });
												}
                                            } else {
                                            	$(".cp-client-age").html();
                                            }
                                            that.toggleViewMode("view", false, 'Personal');
                                            that.toggleViewMode("view", false, 'Details');
                                            HOCIndicator.showCount();

                                        });
                                        tmpTemplate = "";
                                        var tmpClientTlphones = clientInfo[0].get('telephones');
                                        if (tmpClientTlphones !== undefined && tmpClientTlphones.length !== undefined) {
                                            if (eBixcontactDetails && eBixcontactDetails[0] && eBixcontactDetails[0].get('Phones')) {
                                                var eBixCLientTelephone = eBixcontactDetails[0].get('Phones');
                                            } else {
                                                var eBixCLientTelephone = [];
                                            }
                                        }
                                        if (tmpClientTlphones == undefined || tmpClientTlphones.length == undefined) {
                                            var tmpClientTlphones = [];
                                        }
                                        var phoneTemplate = _.template(contactProfilePhoneTemplate);

                                        var currentPhnLbl = _.pluck(tmpClientTlphones, 'phnLblTxt');
                                        if (currentPhnLbl.length < 6) {
                                            if (!(_.contains(currentPhnLbl, 'HOME'))) {
                                                tmpClientTlphones.push({ phnLblTxt: 'HOME', nonNANPPhnNbr: '', phnExtnNbr: '', NANPAreaCd: '', NANPExchCd: '', NANPSbscNbr: '', phnCtryCd: '', isCustom: true });
                                            }
                                            if (!(_.contains(currentPhnLbl, 'WORK')) && !(_.contains(currentPhnLbl, 'BUSINESS'))) {
                                                tmpClientTlphones.push({ phnLblTxt: 'WORK', nonNANPPhnNbr: '', phnExtnNbr: '', NANPAreaCd: '', NANPExchCd: '', NANPSbscNbr: '', phnCtryCd: '', isCustom: true });
                                            }
                                            if (!(_.contains(currentPhnLbl, 'MOBILE'))) {
                                                tmpClientTlphones.push({ phnLblTxt: 'MOBILE', nonNANPPhnNbr: '', phnExtnNbr: '', NANPAreaCd: '', NANPExchCd: '', NANPSbscNbr: '', phnCtryCd: '', isCustom: true });
                                            }
                                            if (!(_.contains(currentPhnLbl, 'OTHER1')) && !(_.contains(currentPhnLbl, 'OTHER 1'))) {
                                                tmpClientTlphones.push({ phnLblTxt: 'OTHER 1', nonNANPPhnNbr: '', phnExtnNbr: '', NANPAreaCd: '', NANPExchCd: '', NANPSbscNbr: '', phnCtryCd: '', isCustom: true });
                                            }
                                            if (!(_.contains(currentPhnLbl, 'OTHER2')) && !(_.contains(currentPhnLbl, 'OTHER 2'))) {
                                                tmpClientTlphones.push({ phnLblTxt: 'OTHER 2', nonNANPPhnNbr: '', phnExtnNbr: '', NANPAreaCd: '', NANPExchCd: '', NANPSbscNbr: '', phnCtryCd: '', isCustom: true });
                                            }
                                        }
                                        _.each(tmpClientTlphones, function (val, key) {
                                            val.phnLblTxt = val.phnLblTxt.toUpperCase(val.phnLblTxt);
                                            if (val.phnLblTxt == 'HOME') { val['prefCode'] = "1"; }
                                            if (val.phnLblTxt == 'WORK') { val['prefCode'] = "2"; val['phnLblTxt'] = "BUSINESS"; }
                                            if (val.phnLblTxt == 'MOBILE') { val['prefCode'] = "3"; }
                                            if (val.phnLblTxt == 'OTHER1' || val.phnLblTxt == 'OTHER 1') {
                                                val['prefCode'] = "4";
                                                val['phnLblTxt'] = 'OTHER 1';
                                            }
                                            if (val.phnLblTxt == 'OTHER2' || val.phnLblTxt == 'OTHER 2') {
                                                val['prefCode'] = "5";
                                                val['phnLblTxt'] = 'OTHER 2';
                                            }
                                        });

                                        tmpClientTlphones = _.sortBy(tmpClientTlphones, 'prefCode');
                                        
                                        if (tmpClientTlphones !== undefined && tmpClientTlphones.length !== undefined) {

                                            tmpClientTlphones.forEach(
                                                function (ClientTelephone) {
                                                    var colateleNbr = (ClientTelephone.NANPAreaCd || "") + (ClientTelephone.NANPExchCd || "") + (ClientTelephone.NANPSbscNbr || "");
                                                    colateleNbr = colateleNbr.replace(/\D/g, '');
                                                    ClientTelephone.preferredPhone = false;

                                                    if (eBixCLientTelephone !== undefined && eBixCLientTelephone.length !== undefined) {
                                                        eBixCLientTelephone.forEach(function (eBixTelephone) {
                                                            var ebixNumber = (eBixTelephone.attributes.AreaCode || "") + (eBixTelephone.attributes.Number || "");
                                                            ebixNumber = ebixNumber.replace(/\D/g, '');
                                                            if (colateleNbr && ebixNumber && colateleNbr == ebixNumber && eBixTelephone.get('Preferred') == "1") {
                                                                ClientTelephone.preferredPhone = true;
                                                            }
                                                        });
                                                    }

                                                    //Preferred logic phnPrfCd - 01
                                                    if (ClientTelephone.phnPrfrCd == "01") {
                                                        ClientTelephone.preferredPhone = true;
                                                    } else {
                                                        ClientTelephone.preferredPhone = false;
                                                    }

                                                    //Text enabled logic SMSEnrlStateCd - 01
                                                    if (ClientTelephone.SMSEnrlStatCd == "01") {
                                                        ClientTelephone.textEnabled = true;
                                                    } else {
                                                        ClientTelephone.textEnabled = false;
                                                    }

                                                    if (ClientTelephone.phnLblTxt.match(/home/i)) {
                                                        tmpTemplate = phoneTemplate(ClientTelephone) + tmpTemplate;
                                                    }
                                                    else {
                                                        tmpTemplate += phoneTemplate(ClientTelephone);
                                                    }

                                                });
                                        }
                                        //Adding phones from Ebix data
                                        if (eBixcontactDetails && eBixcontactDetails[0] && eBixcontactDetails[0].get('Phones')) {
                                            var eBixCLientTelephone = eBixcontactDetails[0].get('Phones');
                                            var prospectPhoneTemplate = _.template(ProspectPhone);
                                            eBixCLientTelephone.forEach(
                                                    function (ClientTelephone) {
                                                        if (ClientTelephone.attributes.ElectronicDownload != "1") {
                                                            if (ClientTelephone.attributes.Preferred == "1") {
                                                                ClientTelephone.attributes.preferredPhone = true;
                                                            } else {
                                                                ClientTelephone.attributes.preferredPhone = false;
                                                            }
                                                            tmpTemplate += prospectPhoneTemplate(ClientTelephone.toJSON());
                                                        }
                                                    });
                                        }

                                        if (tmpTemplate.trim() == "") {
                                            $(".cp-telephone").append('<div class="col-xs-12 col-md-12 col-sm-12"><p> &ndash; </p>' + Constants.missingFieldIndicator + '</div>');
                                        } else {
                                            $(".cp-telephone").append(tmpTemplate);
                                        }

                                        $("a[href*='tel']").each(function () {
                                            $(this).click(function () {
                                                Analytics.analytics.recordAction('contactProfilePhone:clicked');
                                            })
                                        })


                                        var tmpPostalAddresses = clientInfo[0].get('clientPostalAddresses');//Postal address
                                        tmpTemplate = '';
                                        if (tmpPostalAddresses !== undefined && tmpPostalAddresses.length !== undefined) {
                                            var addrTemplate = _.template(contactProfileAddressTemplate);
                                            tmpPostalAddresses.forEach(
                                                function (clientPostalAddresses) {
                                                    clientPostalAddresses.attributes.preferredAddress = false;
                                                    if (clientPostalAddresses.attributes.addrEndDt === "" || clientPostalAddresses.attributes.addrEndDt === null || clientPostalAddresses.attributes.addrEndDt === "0") {
                                                        if (clientPostalAddresses.attributes.addrUseCd !== null && clientPostalAddresses.attributes.addrUseCd.match(/home/i)) {
                                                            tmpTemplate = addrTemplate(clientPostalAddresses.toJSON()) + tmpTemplate;
                                                        } else {
                                                            var _data = clientPostalAddresses.toJSON();
                                                            _data.addrUseCd = "Mailing address";
                                                            //add mailing address sub-label
                                                            tmpTemplate = tmpTemplate + addrTemplate(_data);
                                                        }
                                                    }
                                                });
                                        }
                                        //Commenting below as per PT - 4832 - Hiding Contact Manager postal address in CP View page
                                        //Adding Address from Ebix data
                                        /*if (eBixcontactDetails && eBixcontactDetails[0] && eBixcontactDetails[0].get('Addresses')) {
                                            var eBixClientAddress = eBixcontactDetails[0].get('Addresses');
                                            var prospectAddressTemplate = _.template(ProspectAddress);
                                            eBixClientAddress.forEach(
                                                    function (clientPostalAddresses) {
                                                        if (clientPostalAddresses.attributes.ElectronicDownload != "1") {
                                                            if (clientPostalAddresses.attributes.Preferred == "1") {
                                                                clientPostalAddresses.attributes.preferredAddress = true;
                                                            } else {
                                                                clientPostalAddresses.attributes.preferredAddress = false;
                                                            }
                                                            tmpTemplate += prospectAddressTemplate(clientPostalAddresses.toJSON());
                                                        }
                                                    });
                                        }*/

                                        if (tmpTemplate.trim() == "") {
                                            $(".cp-address").append('<div class="col-xs-12 col-md-12 col-sm-12 padding-large"><p> &ndash; </p>' + Constants.missingFieldIndicator + '</div>');
                                        }
                                        else {
                                            $(".cp-address").append(tmpTemplate);
                                        }

                                        if (tmpPostalAddresses.length === 1 && $(".cp-addr-cd.cola-address").text() != "Home") {
                                            $(".cp-addr-cd.cola-address").remove();
                                        }

                                        $("a[href*='maps.google.com']").each(function () {
                                            $(this).click(function () {
                                                Analytics.analytics.recordAction('contactProfileAddress:clicked');
                                            })
                                        })

                                        var scheduledAddrsTemplate = _.template(contactProfileSchdAddrsTemplate);
                                        $(".cp-scheduled-address").append(scheduledAddrsTemplate({ "caseList": _coaCaseList }));
                                        
                                        var tmpClientEmails = clientInfo[0].get('clientEmails');//Emails
                                        tmpTemplate = '';
                                        if (tmpClientEmails !== undefined && tmpClientEmails.length != undefined) {
                                            if (eBixcontactDetails && eBixcontactDetails[0] && eBixcontactDetails[0].get('WebAddresses')) {
                                                var eBixClientEmail = eBixcontactDetails[0].get('WebAddresses');
                                            } else {
                                                var eBixClientEmail = [];
                                            }
                                            var emailTemplate = _.template(contactProfileEmailTemplate);
                                            tmpClientEmails.forEach(
                                                function (clientEmails) {
                                                    var colaEmail = clientEmails.get("emlAddr");
                                                    clientEmails.attributes.preferredEmail = false;
                                                    eBixClientEmail.forEach(function (eBixEmail) {
                                                        var ebixEmail = eBixEmail.get("Address");
                                                        if (colaEmail && ebixEmail && $.trim(colaEmail) == $.trim(ebixEmail) && eBixEmail.get("Preferred") == "1") {
                                                            clientEmails.attributes.preferredEmail = true;
                                                        }
                                                    });
                                                    var _isUndeliverable = false, _undeliverableMsg = "";
                                                    if (clientEmails.get("emlFuncStatCd") == 'Valid' || clientEmails.get("emlFuncStatCd") == 'Functional') {
                                                        _isUndeliverable = false;
                                                        _undeliverableMsg = "";
                                                    } else {
                                                        _isUndeliverable = true;
                                                        _undeliverableMsg = "Undeliverable";
                                                    }
                                                    var _colaEmailData = clientEmails.toJSON();
                                                    _colaEmailData.undeliverable = _isUndeliverable;
                                                    _colaEmailData.undeliverableMsg = _undeliverableMsg;
                                                    if (clientEmails.attributes.emlUseCd.match(/primary/i)) {
                                                        tmpTemplate = emailTemplate(_colaEmailData) + tmpTemplate;
                                                    } else {
                                                        tmpTemplate = tmpTemplate + emailTemplate(_colaEmailData);
                                                    }
                                                });
                                        }
                                        //Adding Email from Ebix data
                                        if (eBixcontactDetails && eBixcontactDetails[0] && eBixcontactDetails[0].get('WebAddresses')) {
                                            var eBixClientEmail = eBixcontactDetails[0].get('WebAddresses');
                                            var prospectEmailTemplate = _.template(ProspectEmail);
                                            eBixClientEmail.forEach(
                                                    function (clientEmails) {
                                                        if (clientEmails.attributes.ElectronicDownload != "1") {
                                                            if (clientEmails.attributes.Preferred == "1") {
                                                                clientEmails.attributes.preferredEmail = true;
                                                            } else {
                                                                clientEmails.attributes.preferredEmail = false;
                                                            }
                                                            var _ebixEmailData = clientEmails.toJSON();
                                                            _ebixEmailData.undeliverable = false;
                                                            _ebixEmailData.undeliverableMsg = "";
                                                            tmpTemplate += prospectEmailTemplate(_ebixEmailData);
                                                        }
                                                    });
                                        }

                                        if (tmpTemplate.trim() == "") {
                                            $(".cp-email").append('<div class="col-xs-12 col-md-12 col-sm-12 padding-large"><p> &ndash; </p></div>');
                                        }
                                        else {
                                            $(".cp-email").append(tmpTemplate);
                                        }

                                        //CLient key relations
                                        tmpTemplate = '';
                                        if (eBixcontactDetails && eBixcontactDetails[0] && eBixcontactDetails[0].get('Relations') && eBixcontactDetails[0].get('Relations').length > 0) {
                                            var tmpRelations = eBixcontactDetails[0].get('Relations');

                                            var relationsTemplate = _.template(ProspectRelations);
                                            var numRelations = 0;
                                            tmpRelations.forEach(
                                                function (prospectRelations) {
                                                    if (prospectRelations.attributes.RelatedToFirstName !== null && /\S/.test(prospectRelations.attributes.RelatedToFirstName) &&
                                                        prospectRelations.attributes.RelatedToLastName !== null && /\S/.test(prospectRelations.attributes.RelatedToLastName) &&
                                                        prospectRelations.attributes.FullRelatedToName !== null && /\S/.test(prospectRelations.attributes.FullRelatedToName)) {
                                                        tmpTemplate = tmpTemplate + relationsTemplate(prospectRelations.toJSON());
                                                        numRelations++;
                                                        firstSectionElementFound = true;
                                                    }
                                                }
                                            );
                                            $(".cp-relations").append(tmpTemplate);
                                            if (numRelations < 1) { }
                                            else if (numRelations > 1) {
                                                $(".cp-fid-fulldiv.relations").addClass("multiple-relations");
                                            }
                                        }
                                        else {
                                            $(".cp-relations").append("&ndash;").removeClass("pt-data-value-medium");
                                        }

                                        var tmpClientPersonals = clientInfo[0].get('clientPersonal');
                                        if (tmpClientPersonals !== undefined &&
                                            (tmpClientPersonals.get('clientProductExpes') !== undefined &&
                                            tmpClientPersonals.get('clientProductExpes') !== null)) {
                                            var prodExp = "";
                                            if (tmpClientPersonals.get('clientProductExpes') != null && tmpClientPersonals.get('clientProductExpes').length != undefined) {
                                                tmpClientPersonals.get('clientProductExpes').forEach(
                                                function (clientProductExpes) {
                                                    if (prodExp.length > 0) {
                                                        prodExp = prodExp + ", ";
                                                    }
                                                    prodExp = prodExp + clientProductExpes.attributes.prodExpeTypDesc;
                                                });
                                            }
                                            if (prodExp.length == 0) {
                                                $(".cp-product-experience").html('&ndash;').removeClass("pt-data-value-medium");
                                            } else {
                                                $(".cp-product-experience").html(prodExp);
                                            }                                                                                    
                                        }
                                        if (clientInfo[0].get('orgClient').get('orgNm') !== null) {
                                            $(".cp-person").remove();
                                        } else {
                                            $(".cp-entity").remove();
                                        }
                                        that.initializeSuitabilityDateInfo();
                                    }
                                }
                            }
                        }

                        $("#personal-remarks a").prop('target', '_blank');
                        (practicetech.modules.contactprofile) ? ((practicetech.modules.contactprofile.state) ? that.loadFromSavedState() : "") : "";

                        Spinner.hide();


                    }

                    function getIndustryClassificationByCode(indsClsCd) {
                        var mappingCode = Constants.industryClassifications;
                        var indsName = "";
                        _.each(mappingCode, function (list) {
                            if (list.code == indsClsCd) {
                                indsName = list.name;
                            }
                        });
                        return indsName;
                    }

                    function getStateDescByCode(stateCd) {
                        var mappingCode = DropdownListData.USStateslist;
                        var stateName = "";
                        _.each(mappingCode, function (list) {
                            if (list.code == stateCd) {
                                stateName = list.name;
                            }
                        });
                        return stateName;
                    }

                    function gotoClientProfileError(error) {
                        Spinner.hide();
                        ErrorLog.ErrorUtils.myError(error);
                    }

                    if (contactDetails && contactDetails[0] && contactDetails[0].attributes && contactDetails[0].attributes.contactId) {
                        that.contactId = contactDetails[0].get('contactId');
                    }
                } catch (error) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.myError(error);
                }
            }
            function gotoClientPersonalError(Error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.myError(Error);
            }
            var _coaTotalCase = 0, _coaProcessedCaseCount = 0, _finalServiceBlockCount = 2, _CPServiceResponses = null;
            CPDataModule.getCPData(function (response) {
                _CPServiceResponses = response;
                finalServiceSuccessHandler();
            }, function () { });
            getCOAScheduledAddressCaseList()
            function getCOAScheduledAddressCaseList() {

                DataService.getCOAScheduledAddressCaseList(clId).done(function (response) {
                    var _caseList = [], _notResolvedCaseList = [];
                    if (response && response.d && response.d.statCd == "0000") {
                        _caseList = response.d.cases.results;
                        _caseList.forEach(function (ewCase, index) {
                            if (ewCase.caseStat.indexOf("Resolved") === -1) {
                                _notResolvedCaseList.push(ewCase);
                            }
                        });
                        _coaTotalCase = _notResolvedCaseList.length;
                        if (_notResolvedCaseList.length == 0) {
                            finalServiceSuccessHandler();
                        }
                        _notResolvedCaseList.forEach(function (ewCase, indx) {
                            getCOACaseDetails(ewCase.caseId);
                        });
                    } else {
                        finalServiceSuccessHandler();
                    }
                    
                    
                }).fail(function (error) {
                    finalServiceSuccessHandler();
                    ErrorLog.ErrorUtils.prepareAndLogError(error, true);
                });
            }
            function getCOACaseDetails(caseId) {
                DataService.getCOACaseDetails(caseId).done(function (response) {
                    var _caseDetails = {};
                    if (response && response.d) {
                        COACaseDetailSuccess(response.d)
                    } else {
                        COACaseDetailSuccess();
                    }
                }).fail(function (error) {
                    ErrorLog.ErrorUtils.prepareAndLogError(error, true);
                    COACaseDetailSuccess();
                });
            }
            function COACaseDetailSuccess(caseDetails) {
                _coaProcessedCaseCount++;
                var _caseDetails = {
                    "addrChgReasCd": '',
                    "oldAddrLn1Txt": null,
                    "oldAddrLn2Txt": null,
                    "oldAddrLn3Txt": null,
                    "oldAddrLn4Txt": null,
                    "oldAddrLn5Txt": null,
                    // state
                    "oldRegnAreaCd": null,
                    // city
                    "oldPostTownNm": null,
                    // zip
                    "oldPoCdTxt": null,
                    // country name
                    "oldSuperiorLocalityNm": null,
                    // country code
                    "oldCtryCd": null,
                    "newAddrLn1Txt": "",
                    "newAddrSeqNbr": null,
                    "newAddrLn2Txt": null,
                    "newAddrLn3Txt": null,
                    "newAddrLn4Txt": null,
                    "newAddrLn5Txt": null,
                    "newRegnAreaCd": null,
                    "newPostTownNm": null,
                    "newPoCdTxt": null,
                    "newSuperiorLocalityNm": null,
                    "newCtryCd": null,
                    "StartDate": null,
                    "EndDate": null
                };
                if (caseDetails) {
                    _caseDetails.caseId = caseDetails.caseId;
                    _caseDetails.assocAccounts = caseDetails.assocAccounts.results;
                    _caseDetails.caseFields = caseDetails.caseFields.results;
                    _caseDetails.caseFields.forEach(function (caseItem, index) {
                        switch (caseItem.propNm) {
                            case 'AddressChangeReasonCode':
                                _caseDetails.addrChgReasCd = caseItem.propVal;
                                break;
                            case 'OldAddress_AddressLine1':
                                _caseDetails.oldAddrLn1Txt = caseItem.propVal;
                                break;
                            case 'OldAddress_AddressLine2':
                                _caseDetails.oldAddrLn2Txt = caseItem.propVal;
                                break;
                            case 'OldAddress_AddressLine3':
                                _caseDetails.oldAddrLn3Txt = caseItem.propVal;
                                break;
                            case 'OldAddress_RegionalAreaCd':
                                _caseDetails.oldRegnAreaCd = caseItem.propVal;
                                break;
                            case 'OldAddress_PostTownNm':
                                _caseDetails.oldPostTownNm = caseItem.propVal;
                                break;
                            case 'OldAddress_PostalCodeTxt':
                                _caseDetails.oldPoCdTxt = caseItem.propVal;
                                break;
                            case 'OldAdress_CountryCd':
                                _caseDetails.oldCtryCd = caseItem.propVal;
                                break;
                            case 'NewAddress_AddressLine1':
                                _caseDetails.newAddrLn1Txt = caseItem.propVal;
                                break;
                            case 'NewAddress_AddressLine2':
                                _caseDetails.newAddrLn2Txt = caseItem.propVal;
                                break;
                            case 'NewAddress_AddressLine3':
                                _caseDetails.newAddrLn3Txt = caseItem.propVal;
                                break;
                            case 'NewAddress_RegionalAreaCd':
                                _caseDetails.newRegnAreaCd = caseItem.propVal;
                                break;
                            case 'NewAddress_PostTownNm':
                                _caseDetails.newPostTownNm = caseItem.propVal;
                                break;
                            case 'NewAddress_PostalCodeTxt':
                                _caseDetails.newPoCdTxt = caseItem.propVal;
                                break;
                            case 'NewAdress_CountryCd':
                                _caseDetails.newCtryCd = caseItem.propVal;
                                break;
                            case 'StartDate':
                                var _dateString = caseItem.propVal;
                                var _yyyy = _dateString.substr(0, 4), _mm = _dateString.substr(4, 2), _dd = _dateString.substr(6, 2);
                                _caseDetails.StartDate = _mm + "/" + _dd + "/" + _yyyy;
                                break;
                            case 'EndDate':
                                var _dateString = caseItem.propVal;
                                var _yyyy = _dateString.substr(0, 4), _mm = _dateString.substr(4, 2), _dd = _dateString.substr(6, 2);
                                _caseDetails.EndDate = _mm + "/" + _dd + "/" + _yyyy;
                                break;
                            default:
                                break;

                        }

                    });
                    _coaCaseList.push(_caseDetails);
                }
                if (_coaTotalCase == _coaProcessedCaseCount) {
                    finalServiceSuccessHandler();
                }
            }

            function finalServiceSuccessHandler() {
                _finalServiceBlockCount--;
                if (_finalServiceBlockCount == 0) {
                    gototClientPersonalSuccess(_CPServiceResponses)
                }
            }
        },
        afterRender: function () { },
        gotoClientProfile: function (e) {
			Analytics.analytics.recordAction('Group Members: Contact Profile Key Relations:clicked');
            e.preventDefault();
            var that = this;
            var contactId = e.target.id;
            if (contactId.indexOf("Contact.") > -1) {
                ContactType = Constants.contactType.NonClient;

            } else {
                ContactType = Constants.contactType.Client;
            }

            if (contactId == "undefined" || contactId == "" || contactId === null) {
                BootstrapDialog.alert("Contact was saved to appointment as text only. No profile exists for this contact.", "", "Contact not found");
            } else {
                $('#viewEventModal').modal('hide');
                NavApi.changeContactAndLauchCP(contactId, ContactType);
            }
        },
        RouteToGPM: function (e) {
            var targetRoute = null, _isExternal = false;
            NativeAdaptor.notifyContactUpdated();

            switch (e.target.id) {
                case 'cp-edit-clientgreeting':
                    if (this.validateClientAndShowMsg()) {
                        targetRoute = "gpm/greeting";
                        Analytics.analytics.recordAction('gpm:greetingPencil:clicked');
                    }
                    break;
                case 'cp-edit-gender':
                    targetRoute = "gpm/gender"
                    break;
                case 'cp-edit-clientremarks':
                    if (this.validateClientAndShowMsg()) {
                        targetRoute = "gpm/remarks";
                        Analytics.analytics.recordAction('gpm:remarksPencil:clicked');
                    }
                    break;
                case 'cp-edit-dependents':
                    targetRoute = "gpm/dependents";
                    Analytics.analytics.recordAction('gpm:dependentsPencil:clicked');
                    break;
                case 'cp-edit-honorificupdates':
                    targetRoute = "gpm/honorific";
                    Analytics.analytics.recordAction('gpm:honorificPencil:clicked');
                    break;
                case 'cp-edit-maritalstatus':
                    targetRoute = "gpm/maritalstatus";
                    Analytics.analytics.recordAction('gpm:maritalStatusPencil:clicked');
                    break;
                case 'cp-edit-passport':
                    targetRoute = "gpm/passport";
                    Analytics.analytics.recordAction('gpm:passportPencil:clicked');
                    break;
                case 'cp-edit-subtype':
                    if (this.validateClientAndShowMsg()) {
                        targetRoute = "gpm/subtype";
                        Analytics.analytics.recordAction('gpm:subtypePencil:clicked');
                    }
                    break;
                case 'cp-edit-employment':
                    targetRoute = "gpm/employment"
                    break;
                case 'cp-edit-suitability':
                    targetRoute = "gpm/suitability"
                    break;
                case 'cp-edit-driverlicense':
                    targetRoute = "gpm/driverslicense";
                    Analytics.analytics.recordAction('gpm:driversLicensePencil:clicked');
                    break;
                case 'cp-edit-phonenumbers':
                        targetRoute = "gpm/phonenumbers";
                        Analytics.analytics.recordAction('gpm:updatePhoneNumber:clicked');
                    break;
                case 'cp-edit-emails':
                    targetRoute = "gpm/email";
                    Analytics.analytics.recordAction('gpm:updateEmailAddress:clicked');
                    break;
                case 'cp-edit-nameupdate':
                    targetRoute = "gpm/nameupdate";
                    Analytics.analytics.recordAction('gpm:updateName:clicked');
                    break;
                case 'cp-edit-birthdate':
                    targetRoute = "gpm/birthdate"
                    break;
                case 'cp-edit-clientsdeath':
                    targetRoute = "gpm/reportclientsdeath";
                    Analytics.analytics.recordAction('contactProfileClientDeath:clicked');

                    break;
                case 'cp-edit-clientsdivorce':
                    targetRoute = "gpm/reportclientsdivorce";
                    Analytics.analytics.recordAction('contactProfileClientDivorce:clicked');
                    break;
                case 'cp-edit-citizenship':
                    _isExternal = true;
                    this.linkToCitizenshipArticle();
                    Analytics.analytics.recordAction('gpm:updateCitizenshipPencil:clicked');
                    break;
                case 'cp-edit-second-citizenship':
                    _isExternal = true;
                    this.linkToCitizenshipArticle();
                    Analytics.analytics.recordAction('gpm:updateCitizenshipPencil:clicked');
                    break;
                case 'cp-edit-taxtreaty-cntry':
                    _isExternal = true;
                    this.linkToCitizenshipArticle();
                    Analytics.analytics.recordAction('gpm:updateCitizenshipPencil:clicked');
                    break;
                case 'cp-edit-name':
                case 'cp-edit-org-name':
                    _isExternal = true;
                    this.linkToDOBNameSsnWorkflow('name');
                    Analytics.analytics.recordAction('gpm:updateName:clicked');
                    break;
                case 'cp-edit-indst-classification':
                case 'cp-edit-operating-entity':
                case 'cp-edit-legally-established':
                case 'cp-edit-entity-type':
                    targetRoute = "gpm/entity";
                    Analytics.analytics.recordAction('gpm:updateEntity:clicked');
                    break;
                case 'cp-edit-ssn':
                    _isExternal = true;
                    this.linkToDOBNameSsnWorkflow('ssn');
                    Analytics.analytics.recordAction('gpm:update:Ssn-Tin-Ein:clicked');
                    break;
                case 'cp-edit-dob':
                    _isExternal = true;
                    this.linkToDOBNameSsnWorkflow('dob');
                    Analytics.analytics.recordAction('gpm:updateDOB:clicked');
                    break;
                default:
                    console.log("error: edit field operator error")

                    break;
            }
            if (targetRoute && _isExternal == false) {

                (typeof practicetech.modules.contactprofile === 'undefined') ? practicetech.modules.contactprofile = new practicetech.createNew.module() : "";
                practicetech.modules.contactprofile.state = this.saveState();
                practicetech.modules.contactprofile.state.target = e.target.id;

                Backbone.history.navigate(targetRoute, true);
            }

            return false;
        },
        linkToCitizenshipArticle: function () {
            var _url = Config.getConfigProperty("citizenshipAskarticleLink");
            window.open(_url);
        },
        linkToDOBNameSsnWorkflow: function (editmode) {
            var _url = Config.getConfigProperty("DOBWorkfloLink");
            this.callPutContextService(false).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId + '&editmode=' + editmode + "#client-update/";
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
            }).fail(function (error) {
                ErrorLog.ErrorUtils.myError(error)
            });
        },
        callPutContextService: function (async) {
            var _data = {
                putAdvsSessCntxAcctIds: null,
                putAdvsSessCntxClIds: null,
                putAdvsSessCntxDstrIds: null,
                putAdvsSessCntxGrpIds: null

            };
            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _clientId = _gContext.ContactId;
            var _clientCtx = {
                clId: _clientId,
                clCtx: "COLA.CL",
                clRole: "PrimaryClient"
            };
            _data.putAdvsSessCntxClIds = [_clientCtx];
            var _dstrCtx = {
                dstrId: _gContext.AdvisorFMID,
                dstrCtx: "DMU.DIST"
            };
            _data.putAdvsSessCntxDstrIds = [_dstrCtx];
            return DataService.putAdvisorSessionContext(_data, (async != undefined) ? async : true);
        },

        loadFromSavedState: function () {
            that = this;

            if (typeof practicetech.modules.contactprofile === 'undefined') { return false }
            retainSave = ["contactprofile/", "coa/home", "coa/validation", "coa/confirm", "coa/verify"];
            if (retainSave.indexOf(Backbone.history.list.slice(-2)[0]) === -1 && /gpm/.test(Backbone.history.list.slice(-2)[0]) === false) { return false }

            var state = practicetech.modules.contactprofile.state || {};

            if (typeof state.routeToTab !== 'undefined' && state.routeToTabEnforce === true) {
                Backbone.history.navigate('#contactprofile/' + state.routeToTab, true);
                return true;
            }
            else {

                practicetech.modules.contactprofile.state = undefined;

                if (state && state.expand) {
                    state.expand.forEach(
                    function (expandId) {
                        ($("#" + expandId).hasClass('Closed')) ? that.drawerToggle(expandId, "", true) : "";
                    })
                }
                if (state && state.collapse) {
                    state.collapse.forEach(
                     function (collapseId) {
                         ($("#" + collapseId).hasClass('Closed')) ? "" : that.drawerToggle(collapseId, "", true);
                     })
                }

            }

            if (state && state.misc && state.misc.edit) {
                (state.misc.edit === true) ? $("#editPersonal").click() : ""
            }
            if (state && state.switch && state.switch.switchDetails && state.switch.switchDetails.mode && state.switch.switchDetails.mode == true) {
                $("#editDetails").click();
            }

            (state.target && $("#" + state.target).length > 0) ? $(window).scrollTop($("#" + state.target).offset().top - 50) : "";
        },
        saveState: function () {

            state = state || {};
            state.scroll = $(window).scrollTop();
            state.expand = state.expand || [];
            state.collapse = state.collapse || [];
            state.expand = state.expand || [];
            state.collapse = state.collapse || [];
            state.misc = state.misc || {};
            state.switch = state.switch || {};
            state.switch.switchDetails = state.switch.switchDetails || {};
            state.switch.switchDetails.mode = state.switch.switchDetails.mode || false;
            state.misc.edit = false;
            //this flag will set to false from subtabs, means it is contactprofile home page
            state.subTabFalg = false;
            ($("#generalDetails").hasClass('closed')) ? SaveDrawerState("generalDetails", "collapse") : SaveDrawerState("generalDetails", "expand");
            ($("#generalDetailsDrawer").hasClass('closed')) ? SaveDrawerState("generalDetailsDrawer", "collapse") : SaveDrawerState("generalDetailsDrawer", "expand");
            ($("#personalDetails").hasClass('closed')) ? SaveDrawerState("personalDetails", "collapse") : SaveDrawerState("personalDetails", "expand");
            ($("#entityDetails").hasClass('closed')) ? SaveDrawerState("entityDetails", "collapse") : SaveDrawerState("entityDetails", "expand");
            ($("#suitabilityDetails").hasClass('closed')) ? SaveDrawerState("suitabilityDetails", "collapse") : SaveDrawerState("suitabilityDetails", "expand");
            ($("#employmentDetails").hasClass('closed')) ? SaveDrawerState("employmentDetails", "collapse") : SaveDrawerState("employmentDetails", "expand");
            ($("#editPersonal").hasClass('active')) ? state.misc.edit = true : state.misc.edit = false;
            ($("#editDetails").hasClass('active')) ? state.switch.switchDetails.mode = true : state.switch.switchDetails.mode = false;


            function SaveDrawerState(target, action) {
                if (typeof target === 'undefined' || typeof action === 'undefined') {
                    return false
                };

                var targetExpandedIndex = state.expand.indexOf(target);
                var targetCollapsedIndex = state.collapse.indexOf(target);

                (targetExpandedIndex !== -1 && action === "collapse") ? state.expand.splice(targetExpandedIndex, 1) : "";
                (targetCollapsedIndex === -1 && action === "collapse") ? state.collapse.push(target) : "";
                (targetCollapsedIndex !== -1 && action === "expand") ? state.collapse.splice(targetCollapsedIndex, 1) : "";
                (targetExpandedIndex === -1 && action === "expand") ? state.expand.push(target) : "";

            }
            return state;
        },
        loadOrSave: function (e) {
            that = this;
            if (practicetech.modules.contactprofile && practicetech.modules.contactprofile.state && Backbone.history.fragment === "contactprofile/") {
                practicetech.modules.contactprofile.state = that.saveState();
            } else if (Backbone.history.fragment === "contactprofile/") {
                (practicetech.modules.contactprofile) ? "" : practicetech.modules.contactprofile = {}
                practicetech.modules.contactprofile.state = that.saveState();
                practicetech.modules.contactprofile.state.target = e.target.id;
            }
        },
        groupComponentReady: function (event) {
            countOfHouseHoldGrp = 0; countOfPensionGrp = 0; countOfCSGGrp = 0;

            if (self.grpupSectionRendered) {
            return;
            }
            self.grpupSectionRendered = true;
            var _clId = null, _grpId = null;
            if (event.message.status == "success") {
                _clId = event.message.clId;
                DataService.getClientgroupLocal(_clId).then(gotoResortGroups).fail(gotoResortGroupError);
            } else if (event.message.status == "nogroups") {
                groupingDetails.sortedGrps = [];
                groupingDetails.grpDetailsReady = true;
            }

            function gotoResortGroups(clientGroups) {
                var _sortedGroups = CommonUtilityPopover.sortClientGroup(clientGroups.results[0], _grpId);
                groupingDetails.sortedGrps = _sortedGroups;
                groupingDetails.f2cServiceCount = 0;
                groupingDetails.pacServiceCount = 0;
                groupingDetails.dependencyLoadedCount = 0;
                groupingDetails.sortedGrps.forEach(function (groupInfo, i) {
                    (function (grpId, arrIndex) {
                        var clientGrpAdminCode = groupingDetails.sortedGrps[i].attributes.adminCode;
                        if (clientGrpAdminCode == '001') {
                            countOfHouseHoldGrp = countOfHouseHoldGrp + 1;
                        } else if (clientGrpAdminCode == '002') {
                            countOfPensionGrp = countOfPensionGrp + 1;
                        } else if (clientGrpAdminCode == '003') {
                            countOfCSGGrp = countOfCSGGrp + 1;
                        }
                        
                        getF2C(grpId, arrIndex);
                        getPrimaryAdvisor(grpId);
                    })(groupInfo.get('id'), i);
                });
            };
            function gotoResortGroupError(xhr) {
            	groupingDetails.serviceStatus = true;
                ErrorLog.ErrorUtils.prepareAndLogError(xhr, true);
            };
            function getF2C(grpId, arrIndx) {
                var _f2cInfo = { "name": "Not available", "facePrflTyp": "Not available" };
                //status 0000 - success
                //status 0001 - no F2C keep value empty string
                //status 0002 - service error, keep value as Not available
                DataService.promiseToGetGroupF2C(grpId).then(function (respns) {
                    if (respns && respns.d) {
                        var _f2cDeails = respns.d, _facePrflDistributor = _f2cDeails.facePrflDistributor;
                        _f2cInfo = {
                            "name": _f2cDeails.prflNkNm ? _f2cDeails.prflNkNm : (_facePrflDistributor.firstNm + " " + _facePrflDistributor.lastNm), "facePrflTyp": _f2cDeails.facePrflTyp
                        };
                        setF2C({ "grpId": grpId, "status": "0000", "f2cInfo": _f2cInfo });
                    } else {
                        _f2cInfo.name = "";
                        _f2cInfo.facePrflTyp = "";
                        setF2C({ "grpId": grpId, "status": "0001", "f2cInfo": _f2cInfo });
                    }

                }).fail(function (xhr) {
                    ErrorLog.ErrorUtils.myError(xhr, true);
                    setF2C({ "grpId": grpId, "status": "0002", "f2cInfo": _f2cInfo });
                });

            }

            function getPrimaryAdvisor(grpId) {
                DataService.getGrpPrimaryAdvisor(grpId).done(function (response, status, xhr) {
                    if (response && response.d && response.d.prefName && response.d.prefName.firstNm && response.d.prefName.lastNm) {
                        var _grpPrmAdvisor = response.d.prefName,
                            _sfxTxt = (_grpPrmAdvisor.sfxTxt && _grpPrmAdvisor.sfxTxt.trim()) ? (" " + _grpPrmAdvisor.sfxTxt.trim()) : "";
                        setPA({ "grpId": grpId, "status": "0000", "value": _grpPrmAdvisor.firstNm + " " + _grpPrmAdvisor.lastNm + _sfxTxt });
                    } else {
                        setPA({ "grpId": grpId, "status": "0001", "value": "" });
                    }
                }).fail(function (xhr) {
                    ErrorLog.ErrorUtils.myError(xhr, true);
                    setPA({ "grpId": grpId, "status": "0002", "value": "Not available" });
                });

            }
            function setF2C(f2c) {
                try {
                    groupingDetails.f2cServiceCount++;
                    groupingDetails.f2c[f2c.grpId] = {
                        'status': f2c.status,
                        'f2cInfo': f2c.f2cInfo
                    };
                    if ((groupingDetails.sortedGrps !== undefined) && (groupingDetails.f2cServiceCount == groupingDetails.sortedGrps.length)) {
                        renderGroupUI();
                    }
                }
                catch (err) {
                    var _customLog = {
                        "message": "Custom log - setF2C: " + err.message,
                        "stack": {
                            "description": "groupingDetails: " + JSON.stringify(groupingDetails)
                        }
                    }
                    ErrorLog.ErrorUtils.myError(_customLog, true);
                }
            }
            function setPA(pa) {
                try {
                    groupingDetails.paServiceCount++;
                    groupingDetails.pa[pa.grpId] = {
                        'status': pa.status,
                        'value': pa.value
                    };
                    if ((groupingDetails.sortedGrps !== undefined) && (groupingDetails.paServiceCount == groupingDetails.sortedGrps.length)) {
                        renderGroupUI();
                    }
                }
                catch (err) {
                    var _customLog = {
                        "message": "Custom log - setPA: " + err.message,
                        "stack": {
                            "description": "groupingDetails: " + JSON.stringify(groupingDetails)
                        }
                    }
                    ErrorLog.ErrorUtils.myError(_customLog, true);
                }
            }
            function renderGroupUI() {
                groupingDetails.dependencyLoadedCount++;
                if (groupingDetails.dependencyModuleCount == groupingDetails.dependencyLoadedCount) {
                    groupingDetails.grpDetailsReady = true;
                    self.cprendered();
                }
            }
        },
        cprendered: function () {
            if (groupingDetails.grpDetailsReady && groupingDetails.cprendered) {
                var _$grpngSubCntnr = $("#groupingDetailsDrawer");
                if (_$grpngSubCntnr.length > 0) {
                    var _grpTemplate = _.template(GroupingTemplate);
                    var _dataCompiledTmplt = _grpTemplate(groupingDetails);
                    _$grpngSubCntnr.html(_dataCompiledTmplt);
                }
            }

        }
    });

    return contactProfileView;
});
