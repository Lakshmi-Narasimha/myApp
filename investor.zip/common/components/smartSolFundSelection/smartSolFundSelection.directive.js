/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolFundSelection = function($state,authenticationService) {
	return {
          template: require('./smartSolFundSelection.html'),
           restrict: 'E',
           replace: true,
           scope : {
            fundName : "=?"
           },
           controller: function($scope, $element, $attrs){
             //recommendedFundsInitialLoader.loadAllServices($scope);
            // $scope.fundSet = function(){
              $scope.fundSelection = $scope.fundName;
            // }; 

             /*$scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_FUND_PLAN, function($event) {
              console.log("event",recommendedFundsModelService.getRecommendedFundPlanDtls().fundName);
              $scope.fundName = recommendedFundsModelService.getRecommendedFundPlanDtls().fundName;
              $scope.fundSet();
            });
             $scope.fundSet();*/
           },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

smartSolFundSelection.$inject = ['$state','authenticationService'];
module.exports = smartSolFundSelection;