// getSalesOverviewTable.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SalesOverviewTableSchema = new mongoose.Schema({
    salesoverviewTableObject: {
        type: Array,
        "default": []
    }
});

var SalesOverviewTableLookUp = mongoose.model('SalesOverviewTableLookup', SalesOverviewTableSchema);

var SalesOverviewTableModel = new SalesOverviewTableLookUp({
    "salesoverviewTableObject": {
    "fundsSummary": [
      {
        "assetCatagory": "BALANCED",
        "noOfAccounts": 148081,
        "AUM": 18.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "FEEDER",
        "noOfAccounts": 148081,
        "AUM": 19.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "FOF",
        "noOfAccounts": 148081,
        "AUM": 17.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "ELSS",
        "noOfAccounts": 148081,
        "AUM": 18.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "EQUITY",
        "noOfAccounts": 148081,
        "AUM": 18.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "INCOME",
        "noOfAccounts": 148081,
        "AUM": 18.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "LIQUID",
        "noOfAccounts": 148081,
        "AUM": 18.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      },
      {
        "assetCatagory": "TOTAL",
        "noOfAccounts": 148081,
        "AUM": 18.27,
        "AUMAllocation": "0.13%",
        "grossSalesMTD": 1230.49
      }
    ]
  }
});

SalesOverviewTableLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SalesOverviewTableLookUp table, please contact admin...');
    } else {
        SalesOverviewTableLookUp.remove({}, function(err) {
            console.log('SalesOverviewTableLookUp collection removed');
            SalesOverviewTableModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating SalesOverviewTableLookUp table, please contact admin...');
                }
                console.log('SalesOverviewTableLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SalesOverviewTableLookUp;
