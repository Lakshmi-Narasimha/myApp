var express = require('express');
var router = express.Router();
var Usernames = require('./usernames.model');

// api route

var error = {status: 404, message: 'No users found'}; /* Error messge object */


router.route('/users').get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        Usernames.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].usernamesObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].usernamesObject); 
            }

        });
    });

router.route('/user/:email').get(function(req, res){
        res.send({name: 'Suresh', comp_name: 'Cognizant', emp_id: 543310});
    });

module.exports = router;
