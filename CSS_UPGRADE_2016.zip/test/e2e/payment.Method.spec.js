'use strict';
//
var autopaymentsList = null;
var autopaymentAccountList = null;
var accountDetails = null;
var billingAccountDetails = null;
var billingObject = null;
var req = require("request");
// var apiGetAutoPayments = 'http://localhost:8000/autopayments/autoPaymentEnrollDeenroll';

var displayedAutoPaymentList = [];
var billingAcctStr = 'Billing Account # ';

describe('Payment Method Testing',function(){
	
	describe('Open Payment Method page',function(){

		beforeEach(function(){
			browser.get('/#/billing/authentication'); 
			browser.waitForAngular();
	  	});

	  	it('TC1 - Add Payment Method Link validation',function(){
	  		var pageTitle = element(by.tagName('h1'));
	  		expect(pageTitle.getText()).toEqual('Manage Payment Methods');
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);
		});

	  	it('TC2 - Add Payment Method - Card validation',function(){
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);

			expect(element(by.css('[ng-click="selectPaymentType(\'Card\')"]')).isDisplayed()).toBeTruthy();
			element(by.css('[ng-click="selectPaymentType(\'Card\')"]')).click();
			browser.sleep(500);
			
			var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-off-white']";
			var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";

			expect(element(by.name('nickname')).isDisplayed()).toBeTruthy();
			expect(element(by.name('cardnumber')).isDisplayed()).toBeTruthy();	
			expect(element(by.name('cardtype')).isDisplayed()).toBeTruthy();
			expect(element(by.name('selectmonth')).isDisplayed()).toBeTruthy();
			expect(element(by.name('selectyear')).isDisplayed()).toBeTruthy();
			expect(element(by.name('entername')).isDisplayed()).toBeTruthy();
			expect(element(by.name('enterzipcode')).isDisplayed()).toBeTruthy();
			expect(element(by.xpath(cancelPath)).isDisplayed()).toBeTruthy();
			expect(element(by.xpath(submitpath)).isDisplayed()).toBeTruthy();
		});

		it('TC3 - Add Payment Method - Card Cancel validation',function(){
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);

			expect(element(by.css('[ng-click="selectPaymentType(\'Card\')"]')).isDisplayed()).toBeTruthy();
			element(by.css('[ng-click="selectPaymentType(\'Card\')"]')).click();
			browser.sleep(500);
			
			var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-off-white']";
			var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";
			element(by.xpath(cancelPath)).click();	
		});


		it('TC4 - Add Payment Method - Card submit validation',function(){
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);

			expect(element(by.css('[ng-click="selectPaymentType(\'Card\')"]')).isDisplayed()).toBeTruthy();
			element(by.css('[ng-click="selectPaymentType(\'Card\')"]')).click();
			browser.sleep(500)
			
			var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";
			var defaultchkPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][1]/div[@class='body-nav clearfix']/form[@id='addCreditForm']/div[@class='row'][6]/div[@class='checkbox']/label/span[@class='chbox']";
			var termchkpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/form[@id='termsForm']/div[@class='checkbox']/label/span[@class='chbox']";
			
			element(by.model('user.cardHolderNickName')).sendKeys('Paul'); 
			element(by.model('user.cardNumber')).sendKeys('4012888888881881'); 
			element(by.model('user.expMonth')).sendKeys('11'); 
			element(by.model('user.expYear')).sendKeys('2020'); 
			element(by.id('addCredit')).click();
			element(by.model('user.cardHolderName')).sendKeys('Paul Walker'); 
			element(by.model('user.zipCode')).sendKeys('95134'); 
			element(by.xpath(defaultchkPath)).click();
			element(by.xpath(termchkpath)).click();	
			element(by.xpath(submitpath)).click();	
		});

		it('TC5 - Add Payment Method - Bank validation',function(){
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);

			var bankpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][1]/div[@class='header-nav clearfix']/ul[@class='nav navbar-nav col-xs-12']/li[@class='text-uppercase col-xs-6']/span[@class='hidden-xs']";
			expect(element(by.css('[ng-click="selectPaymentType(\'Account\')"]')).isDisplayed()).toBeTruthy();
			element(by.css('[ng-click="selectPaymentType(\'Account\')"]')).click();
			browser.sleep(500);
			
			var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-off-white']";
			var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";

			expect(element(by.name('banknickname')).isDisplayed()).toBeTruthy();
			expect(element(by.name('accounttype')).isDisplayed()).toBeTruthy();	
			expect(element(by.name('routingnumber')).isDisplayed()).toBeTruthy();
			expect(element(by.name('accountnumber')).isDisplayed()).toBeTruthy();
			expect(element(by.name('accHolderName')).isDisplayed()).toBeTruthy();
			expect(element(by.xpath(cancelPath)).isDisplayed()).toBeTruthy();
			expect(element(by.xpath(submitpath)).isDisplayed()).toBeTruthy();
		});
		
		it('TC6 - Add Payment Method - Bank Cancel validation',function(){
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);

			var bankpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][1]/div[@class='header-nav clearfix']/ul[@class='nav navbar-nav col-xs-12']/li[@class='text-uppercase col-xs-6']/span[@class='hidden-xs']";
			expect(element(by.css('[ng-click="selectPaymentType(\'Account\')"]')).isDisplayed()).toBeTruthy();
			element(by.css('[ng-click="selectPaymentType(\'Account\')"]')).click();
			browser.sleep(500);
			
			var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-off-white']";
			var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";
			
			element(by.xpath(cancelPath)).click();	
		});

		it('TC7 - Add Payment Method - Bank submit validation',function(){
			expect(element(by.id('addPayMethod')).isDisplayed()).toBeTruthy();
			element(by.id('addPayMethod')).click();
			browser.sleep(500);

			var bankpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][1]/div[@class='header-nav clearfix']/ul[@class='nav navbar-nav col-xs-12']/li[@class='text-uppercase col-xs-6']/span[@class='hidden-xs']";
			expect(element(by.css('[ng-click="selectPaymentType(\'Account\')"]')).isDisplayed()).toBeTruthy();
			element(by.css('[ng-click="selectPaymentType(\'Account\')"]')).click();
			browser.sleep(500);
			
			var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-off-white']";
			var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";
			var defaultchkPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][2]/div[@class='body-nav clearfix']/form[@id='addBankForm']/div[@class='row col-xs-12']/div[@class='checkbox']/label/span[@class='chbox']";
			var termchkpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/form[@id='termsForm']/div[@class='checkbox']/label/span[@class='chbox']";
			
			element(by.model('user.bankAccountHolderNickName')).sendKeys('Walker'); 
			element(by.model('user.bankAccountType')).sendKeys('Saving'); 
			element(by.model('user.routingnumber')).sendKeys('121000358'); 
			element(by.model('user.accountNumber')).sendKeys('6026015147'); 
			element(by.model('user.accountHolderName')).sendKeys('Paul Walker'); 
			element(by.xpath(defaultchkPath)).click();
			element(by.xpath(termchkpath)).click();	
			element(by.xpath(submitpath)).click();
		});

		it('TC8 - Edit functionality validation', function(){
			// if (element(by.linkText('Here is the solution')).isDisplayed())
			// {
			// }
			// else
			// {
				var editpath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/div[@class='container clearfix auto-payments-container']/div[@class='row']/div[@class='col-xs-12 manage-payments-section']/div[@class=' row payment-method-section']/div[@class='row payment-content ng-scope'][1]/div[@class='col-xs-12 col-sm-3 icons hidden-xs ng-scope']/a[@id='editPayMethod']/span";
				expect(element(by.xpath(editpath)).isDisplayed()).toBeTruthy();
				element(by.xpath(editpath)).click();
				browser.sleep(500);
				element(by.css('[ng-click="closeModal()"]')).click();
			// }
			
		});
		
		it('TC9 - Edit functionality - cancel validation', function(){
			// if (element(by.linkText('Here is the solution')).isDisplayed())
			// {
			// }
			// else
			// {
				var editpath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/div[@class='container clearfix auto-payments-container']/div[@class='row']/div[@class='col-xs-12 manage-payments-section']/div[@class=' row payment-method-section']/div[@class='row payment-content ng-scope'][1]/div[@class='col-xs-12 col-sm-3 icons hidden-xs ng-scope']/a[@id='editPayMethod']/span";
				expect(element(by.xpath(editpath)).isDisplayed()).toBeTruthy();
				element(by.xpath(editpath)).click();
				browser.sleep(500);

				var cancelPath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-off-white']";
				expect(element(by.xpath(cancelPath)).isDisplayed()).toBeTruthy();
				element(by.xpath(cancelPath)).click();
			// }
		});

		it('TC10 - Edit functionality - submit validation', function(){
			// if (element(by.linkText('Here is the solution')).isDisplayed())
			// {
			// }
			// else
			// {
				var editpath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/div[@class='container clearfix auto-payments-container']/div[@class='row']/div[@class='col-xs-12 manage-payments-section']/div[@class=' row payment-method-section']/div[@class='row payment-content ng-scope'][1]/div[@class='col-xs-12 col-sm-3 icons hidden-xs ng-scope']/a[@id='editPayMethod']/span";
				expect(element(by.xpath(editpath)).isDisplayed()).toBeTruthy();
				element(by.xpath(editpath)).click();
				browser.sleep(500);

				var cardHeader = "EDIT PAYMENT CARD";
				var bankHeader = "EDIT BANK ACCOUNT";

				
				element.all(by.css('.container-fluid')).each(function(elemt,j) {
				    elemt.getText().then(function(txt) 
				    {  
				    	//console.log("t1: " + txt);         
				        var tmp = [];
						tmp = txt.split('\n');
						if (tmp[0] == cardHeader)
						{
							element(by.model('user.cardHolderNickName')).sendKeys('Jason'); 
							element(by.model('user.expMonth')).sendKeys('12'); 
							element(by.model('user.expYear')).sendKeys('2020'); 
							element(by.model('user.cardHolderName')).sendKeys('Jason Satham'); 

							//var defaultchkPath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][1]/div[@class='body-nav clearfix']/form[@id='addCreditForm']/div[@class='row'][6]/div[@class='checkbox']/label/span[@class='chbox']";
							var defaultchkPath = '//*[@id="addCreditForm"]/div[6]/div/label/span';
							var termchkpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/form[@id='termsForm']/div[@class='checkbox']/label/span[@class='chbox']";
							var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";
							element(by.xpath(defaultchkPath)).click();
							element(by.xpath(termchkpath)).click();	
							element(by.xpath(submitpath)).click();	
						}
						if (tmp[0] == bankHeader)
						{
							
							element(by.model('user.bankAccountHolderNickName')).sendKeys('Vin Diesel'); 
							element(by.model('user.routingnumber')).sendKeys('122220593'); 

							//var defaultchkPath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='modal-content']/div[@class='modal-body']/div[@class='container-fluid']/div[@class='row'][1]/div[@class='body-nav clearfix']/form[@id='addCreditForm']/div[@class='row'][6]/div[@class='checkbox']/label/span[@class='chbox']";
							var defaultchkPath = '//*[@id="addCreditForm"]/div[6]/div/label/span';
							var termchkpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/form[@id='termsForm']/div[@class='checkbox']/label/span[@class='chbox']";
							var submitpath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/add-edit-payment-modal[@class='ng-isolate-scope']/div[@id='addnewPaymentModal']/div[@class='modal-dialog add-new-payment-modal']/div[@class='terms-conditons-section']/div[@class='row terms-condition-container']/div[@class='form-group col-xs-12 col-sm-12']/div[@class='row']/div[@class='col-xs-6 col-sm-6 col-md-6 col-lg-6 text-left']/div[@class='row']/button[@class='btn btn-farmers-default btn-farmers-blue']";
							element(by.xpath(defaultchkPath)).click();
							element(by.xpath(termchkpath)).click();	
							element(by.xpath(submitpath)).click();	
						}
				    });
				});
			// }
		});

		it('TC11 - Delete functionality - Cancel validation', function(){

			// if (element(by.linkText('Here is the solution')).isDisplayed())
			// {
			// }
			// else
			// {
				var deletepath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/div[@class='container clearfix auto-payments-container']/div[@class='row']/div[@class='col-xs-12 manage-payments-section']/div[@class=' row payment-method-section']/div[@class='row payment-content ng-scope'][1]/div[@class='col-xs-12 col-sm-3 icons hidden-xs ng-scope']/a[@class='fa fa-trash-o account-icon']";
				expect(element(by.xpath(deletepath)).isDisplayed()).toBeTruthy();
				element(by.xpath(deletepath)).click();
				browser.sleep(500);

				var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/delete-modal[@class='ng-isolate-scope']/div[@id='deletePaymentModal']/div[@class='modal-dialog payment-modal']/div[@class='modal-content']/div[@class='modal-footer']/button[@class='pull-left btn btn-farmers-default btn-farmers-off-white']";
				var removepath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/delete-modal[@class='ng-isolate-scope']/div[@id='deletePaymentModal']/div[@class='modal-dialog payment-modal']/div[@class='modal-content']/div[@class='modal-footer']/button[@class='pull-right btn btn-farmers-default btn-farmers-blue']";

				expect(element(by.xpath(cancelPath)).isDisplayed()).toBeTruthy();
				expect(element(by.xpath(removepath)).isDisplayed()).toBeTruthy();

				element(by.xpath(cancelPath)).click();
			// }
		});
	
		it('TC12 - Delete functionality - Remove validation', function(){

			// if (element(by.linkText('Here is the solution')).isDisplayed())
			// {
			// }
			// else
			// {
				var deletepath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/div[@class='container clearfix auto-payments-container']/div[@class='row']/div[@class='col-xs-12 manage-payments-section']/div[@class=' row payment-method-section']/div[@class='row payment-content ng-scope'][1]/div[@class='col-xs-12 col-sm-3 icons hidden-xs ng-scope']/a[@class='fa fa-trash-o account-icon']";
				expect(element(by.xpath(deletepath)).isDisplayed()).toBeTruthy();
				element(by.xpath(deletepath)).click();
				browser.sleep(500);

				var cancelPath ="/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/delete-modal[@class='ng-isolate-scope']/div[@id='deletePaymentModal']/div[@class='modal-dialog payment-modal']/div[@class='modal-content']/div[@class='modal-footer']/button[@class='pull-left btn btn-farmers-default btn-farmers-off-white']";
				var removepath = "/html[@class='ng-scope']/body[@id='CSSRedesign']/div[@id='wrapper']/div[@id='content']/div[@id='managePayContainer']/delete-modal[@class='ng-isolate-scope']/div[@id='deletePaymentModal']/div[@class='modal-dialog payment-modal']/div[@class='modal-content']/div[@class='modal-footer']/button[@class='pull-right btn btn-farmers-default btn-farmers-blue']";

				expect(element(by.xpath(cancelPath)).isDisplayed()).toBeTruthy();
				expect(element(by.xpath(removepath)).isDisplayed()).toBeTruthy();

				element(by.xpath(removepath)).click();
			// }
		});
	
		it('TC13 - No Payment Method Added Already' , function()
		{
			if (element(by.linkText('Here is the solution')).isDisplayed())
			{
				element(by.linkText('Here is the solution')).click();
			}
			
		});
	});
});