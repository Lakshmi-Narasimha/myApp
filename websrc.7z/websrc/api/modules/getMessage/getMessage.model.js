var config = require('../../../config/config');

var getMessageModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [{
                    "messageList": [{
                        "loginReq": false,
                        "messageText": "hi"
                    }],
                    "sequenceNumberInt": 6,
                    "animationDuration": 800,
                    "type": "chat",
                    "msgId": 10004,
                    "messageType": "chatLine",
                    "sequenceNumber": "6"
                }],
                "startMsgId": 10004,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
                    "type": "Success"
                }
            }
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "agentID": "vzw-mobile-app-03",
            "callType": "getMessage",
            "timeToWait": null,
            "engagementID": "-1196452972424366591",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
            "type": "Success"
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_GET_MSG_URI
    }
};

module.exports = getMessageModelConfig;
