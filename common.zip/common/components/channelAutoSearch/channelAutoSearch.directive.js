/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var ChannelAutoSearch = function($timeout, eventConstants) {
return {
            template: require('./channelAutoSearch.html'),
            restrict: 'E',
            replace: true,
            scope: {
               searchOptions : '='
            },
            controller:['$scope', function($scope){
                $scope.optionChange = function(option){                  
                  $scope.$broadcast(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, {req: option});
                  // $scope.$emit(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, {});
                  
                };
                $scope.sortTypeChange=function(option){
                  $scope.$emit('CHANNEL_AUTO_SORT_OPTION_CHANGED', option);
                };
                $scope.setSearchType = function(option){
                  // $scope.$emit('showText', false);
                  $scope.searchTypeLable = option.lable;
                  $scope.searchTypeText = option.lableText;
                  $scope.optionChange(option);
                };
                $scope.setSortType = function(option){
                  $scope.sortTypeLable = option.lable;
                  $scope.sortTypeChange(option);
                };
                $timeout(function() {
                    $scope.setSearchType($scope.searchOptions[0]);                    
                },1000);

                $scope.$on(eventConstants.RESET_CHANNEL_AUTO_SEARCH_OPTION, function (event, args) {                  
                   $scope.setSearchType($scope.searchOptions[0]);   
                });



            }]
        };
};

ChannelAutoSearch.$inject = ['$timeout', 'eventConstants'];
module.exports = ChannelAutoSearch;
