/**
 * @ngdoc directive
 * @name investmentPreferencesReview
 * @description
 *
 * - investmentPreferencesReview component will provide preview of the user investor prefernce .
 * 
 *
 **/
 'use strict';

var investmentPreferencesBuyReview = function(eventConstants,transactNowModel, $filter, TransactConstant) {
	return {
            template: require('./investmentPreferenceBuyReview.html'),
            restrict: 'E',
            replace: true,
            scope: {
                sipType:"=?"
            },
            controller: function($scope, $element, $attrs){
                console.log("invest prefer");
                var invPrefDetails = transactNowModel.getInvestPrefer();
                var translateFilter = $filter('translate');
                
                if(invPrefDetails.investorMode === "financial"){
                    $scope.invPrefKeyValuePairs = [
                        {
                            text : translateFilter(TransactConstant.common.FINANCIAL_ADVISOR),
                            value: invPrefDetails.code || 'NA'
                        },
                        {
                            text : translateFilter(TransactConstant.common.SUB_BROKAR_CODE),
                            value: invPrefDetails.subBrokerCode || 'NA'
                        },
                        {
                            text: translateFilter(TransactConstant.common.SUB_BROKAR_ARN),
                            value: invPrefDetails.subBrokerArn || 'NA'
                        },
                        {
                            text: translateFilter(TransactConstant.common.EUIN),
                            value: invPrefDetails.euin || 'NA'
                        }
                    ];
                }else{
                    $scope.invPrefKeyValuePairs = [
                        {
                            text : translateFilter(TransactConstant.common.DIRECT_ARN_MSG)
                        }
                    ];
                }

                $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){ 
                    if($scope.sipType == "renewSip"){
                        transactNowModel.isRenewSipInvEditClicked = true;
                        $scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: 'investorPreferenceRenew'});
                    }else{
                        $scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: 'investorPreference'});
                    }           
                    $event.stopPropagation(); 
                }); 
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

investmentPreferencesBuyReview.$inject = ['eventConstants','transactNowModel', '$filter', 'TransactConstant'];
module.exports = investmentPreferencesBuyReview;