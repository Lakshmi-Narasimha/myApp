'use strict';

var express = require('express'),
    router = express.Router(),
    TransDividendSummaryModel = require('./getDividendSummary.model'),
    TransUnclaimedMoneySummaryModel = require('./getUnclaimedMoneySummary.model'),
    TransDividendDetailsModelLookUp = require('./getDividendDetails.model'),
    TransRedumptionSummaryModel = require('./getRedemptionSummary.model'),
    TransRedumptionDetailsModel = require('./getRedemptionDetails.model'),
    SysPlansSIPRegdModel = require('./getSipReg.model'),
    SysPlansSTPRegdModel = require('./getStpReg.model'),
    SysPlansSWPRegdModel = require('./getSwpReg.model'),
    SysPlansSIPInstallmentModel = require('./getSipInstallment.model'),
    SysPlansSTPInstallmentModel = require('./getStpInstallment.model'),
    SysPlansSWPInstallmentModel = require('./getSwpInstallment.model'),
    purchasesSummaryModel = require('./purchasesSummary.model'),
    purchasesHistoryModel = require('./purchasesHistory.model'),
    financialTransactionModel = require('./getFinancialTransactionDetails.model'),
    nonFinancialTransactionModel = require('./getNonFinancialTransactionDetails.model');

var errorObj = [{
    errorCode: 'A0003',
    errorMessage: 'Something went wrong'
}];

// api route
router.route('/clients/siSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        var findModel = {
            'SIP': SysPlansSIPRegdModel,
            'STP': SysPlansSTPRegdModel,
            'SWP': SysPlansSWPRegdModel
            
        };
        var findModel1 = {
            'SIP': 'sipRegdResp',
            'STP': 'stpRegdResp',
            'SWP': 'swpRegdResp'
            
        };
       
        findModel[req.query.trxnType].find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {
                console.log("sip data"+data);
                res.json(data[0][findModel1[req.query.trxnType]][0]);
                //res.send(500, error);
            }

        });
    });

// SIP Installment
router.route('/SysInvPlansSIPInstallment')
    .get(function (req, res) {
        SysPlansSIPInstallmentModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].sipInstallmentResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].sipInstallmentResp);
            }

        });

});
    // api route
router.route('/clients/stpQuery')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        var findModel = {
            'SIP': SysPlansSIPInstallmentModel,
            'STP': SysPlansSTPInstallmentModel,
            'SWP': SysPlansSWPInstallmentModel
            
        };
        var findModel1 = {
            'SIP': 'sipInstallmentResp',
            'STP': 'stpInstallmentResp',
            'SWP': 'swpInstallmentResp'
            
        };
        console.log(req.query)
        findModel[req.query.trxnType].find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {
                 console.log(data[0],data[0][findModel1[req.query.trxnType]][0]);
                res.json(data[0][findModel1[req.query.trxnType]][0]);
                //res.send(500, error);
            }

        });
    });
    // api route
router.route('/clients/swpQuery')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        var findModel = {
            'SIP': SysPlansSIPInstallmentModel,
            'STP': SysPlansSTPInstallmentModel,
            'SWP': SysPlansSWPInstallmentModel
            
        };
        var findModel1 = {
            'SIP': 'sipInstallmentResp',
            'STP': 'stpInstallmentResp',
            'SWP': 'swpInstallmentResp'
            
        };
        console.log(req.query)
        findModel[req.query.trxnType].find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {
                 console.log(data[0],data[0][findModel1[req.query.trxnType]][0]);
                res.json(data[0][findModel1[req.query.trxnType]][0]);
                //res.send(500, error);
            }

        });
    });
// api route
router.route('/clients/sipQuery')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        var findModel = {
            'SIP': SysPlansSIPInstallmentModel,
            'STP': SysPlansSTPInstallmentModel,
            'SWP': SysPlansSWPInstallmentModel
            
        };
        var findModel1 = {
            'SIP': 'sipInstallmentResp',
            'STP': 'stpInstallmentResp',
            'SWP': 'swpInstallmentResp'
            
        };
        console.log(req.query)
        findModel[req.query.trxnType].find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {
                 console.log(data[0],data[0][findModel1[req.query.trxnType]][0]);
                res.json(data[0][findModel1[req.query.trxnType]][0]);
                //res.send(500, error);
            }

        });
    });

// SIP Installment
router.route('/SysInvPlansSIPInstallment')
    .get(function (req, res) {
        SysPlansSIPInstallmentModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].sipInstallmentResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].sipInstallmentResp);
            }

        });

});

// STP Installment
router.route('/SysInvPlansSTPInstallment')
    .get(function (req, res) {
        SysPlansSTPInstallmentModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].stpInstallmentResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].stpInstallmentResp);
            }

        });

});
// SWP Installment
router.route('/SysInvPlansSWPInstallment')
    .get(function(req, res) {
        SysPlansSWPInstallmentModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].swpInstallmentResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].swpInstallmentResp);
            }

        });

    });

router.route('/clients/divSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        TransDividendSummaryModel.find(function(err, data) {

            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].dividendSummaryResp.length === 0) {
                console.log('dividendSummaryResp');
                res.send(errorObj);
            } else {
                res.json(data[0].dividendSummaryResp[0]);
            }

        });
    });

router.route('/clients/divHistory')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        TransDividendDetailsModelLookUp.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].dividendDetailsResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].dividendDetailsResp[0]);
            }

        });
    });

router.route('/clients/transactionSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        if(req.query.trxnType === 'D') {
            // use mongoose to get all nerds in the database
            // Mandatary elements are present
            TransDividendSummaryModel.find(function(err, data) {

                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute 
                if (err) {
                    res.send(err);
                } else if (data[0].dividendSummaryResp.length === 0) {
                    console.log('dividendSummaryResp');
                    res.send(errorObj);
                } else {
                    res.json(data[0].dividendSummaryResp[0]);
                }
            });
            
        } else if(req.query.trxnType === 'R'){
            TransRedumptionSummaryModel.find(function(err, data) {
                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute 
                if (err) {
                    res.send(err);
                } else if (data[0].RedumptionSummaryResp.length === 0) {
                    console.log('RedumptionSummaryResp');
                    res.send(errorObj);
                } else {
                    res.json(data[0].RedumptionSummaryResp[0]);
                }
            });
        } else if(req.query.trxnType === 'P'){
            purchasesSummaryModel.find(function(err, data) {
                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute 
                if (err) {
                    res.send(err);
                } else if (data[0].purchasesSummaryDetails.length === 0) {
                    console.log('purchasesSummaryDetails');
                    res.send(errorObj);
                } else {
                    res.json(data[0].purchasesSummaryDetails[0]);
                }
            });
        } else if(req.query.trxnType === 'Postal'){
            TransUnclaimedMoneySummaryModel.find(function(err, data) {
                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute 
                if (err) {
                    res.send(err);
                } else if (data[0].unclaimedMoneySummaryResp.length === 0) {
                    console.log('unclaimedMoneySummaryResp');
                    res.send(errorObj);
                } else {
                    res.json(data[0].unclaimedMoneySummaryResp[0]);
                }
            });
        }
        
    });
router.route('/clients/redHistory')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        TransRedumptionDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].RedumptionDetailsResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].RedumptionDetailsResp[0]);
            }

        });
    });

router.route('/clients/purchasesSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        purchasesSummaryModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (!data[0]) {
                res.send(errorObj);
            } else {
                res.json(data[0]);
            }

        });
    });
router.route('/clients/purchaseHistory')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        purchasesHistoryModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (!data[0].PurchasesHistoryDetails[0]) {
                res.send(errorObj);
            } else {
                res.json(data[0].PurchasesHistoryDetails[0]);
            }
        });

    });

router.route('/clients/unclaimedMoneySummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        TransUnclaimedMoneySummaryModel.find(function(err, data) {

            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].unclaimedMoneySummaryResp.length === 0) {
                console.log('unclaimedMoneySummaryResp');
                res.send(errorObj);
            } else {
                res.json(data[0].unclaimedMoneySummaryResp[0]);
            }

        });

    });

router.route('/services/retrieveTxns')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        financialTransactionModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 

            if (err) {
                res.send(err);
            } else if (data[0].financialTransactionDetailsResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].financialTransactionDetailsResp[0]);
            }

        });
    });
router.route('/services/nctDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        nonFinancialTransactionModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 

            if (err) {
                res.send(err);
            } else if (data[0].nonFinancialTransactionDetailsResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].nonFinancialTransactionDetailsResp[0]);
            }

        });
    });
module.exports = router;
