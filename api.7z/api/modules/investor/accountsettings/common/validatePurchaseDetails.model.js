// swp.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ValidatePurchaseModelSchema = new mongoose.Schema({
    validatePurchaseResp: {
        type: Object,
        'default': {}
    }
});

var ValidatePurchaseModelLookUp = mongoose.model('ValidatePurchaseModelLookUp', ValidatePurchaseModelSchema);

var ValidatePurchaseModel = new ValidatePurchaseModelLookUp({
    validatePurchaseResp: {
        'accountNo': '0380000217154',
        'folioId': '13884342',
        'transactionValidated': 'true',
        'webRefNo': 'SWD000893'
    }
});

ValidatePurchaseModelLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidatePurchaseModelLookUp table, please contact admin...');
    } else {

        ValidatePurchaseModelLookUp.remove({}, function () {
            console.log('ValidatePurchaseModelLookUp collection removed');
            ValidatePurchaseModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating ValidatePurchaseModelLookUp table, please contact admin...');
                }
                console.log('ValidatePurchaseModelLookUp table created in mongoose...');
            });
        });
    }
});

module.exports = ValidatePurchaseModelLookUp;