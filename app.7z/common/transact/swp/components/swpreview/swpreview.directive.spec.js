'use strict';
describe('Directive: fticSwpReview', function() {
	var compile,scope,directiveElement,isolatedScope,$window,$filter,authenticationService,reviewSwpDetailsModel,swpReviewDetailsFactory;

	var swpObject = { 
		selectedMode: 'cheque', 
		startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
		endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
		noofInstallments: 6,
		frequency: 'Monthly', 
		selectedType: 'capital',
		swpAmtValue: 'Capital Appreciation',
		bankDetails: 'CITI BANK - 7335300411'  
	};

	var advisor = false;

	beforeEach(angular.mock.module('advisor'));	
   
	var getCompiledElement = function(){
		var element = angular.element('<ftic-swp-review></ftic-swp-review>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope,_$compile_,$window,_$filter_,_authenticationService_,_swpReviewDetailsFactory_,_reviewSwpDetailsModel_) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};

            $filter = _$filter_;
            authenticationService = _authenticationService_;
            reviewSwpDetailsModel = _reviewSwpDetailsModel_;
            swpReviewDetailsFactory = _swpReviewDetailsFactory_

            reviewSwpDetailsModel.setReviewSwpObj(swpObject);            

            if(advisor){
            	authenticationService.setUser({                                        
        			"userId" : "test123"        
        		});	
            }

            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();                   
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

   	it('should define the variables on load',function(){
    	expect(isolatedScope.swpAmount).toBe('Capital Appreciation');
    	expect(isolatedScope.frequency).toBe('Monthly');
    	expect(isolatedScope.startDate).toBe($filter('date')(swpObject.startDate, 'dd MMM yyyy'));
    	expect(isolatedScope.endDate).toBe($filter('date')(swpObject.endDate, 'dd MMM yyyy'));
    	expect(isolatedScope.noofInstallments).toBe(6);
    	expect(isolatedScope.bankDetails).toBe('CITI BANK - 7335300411');
    	expect(isolatedScope.selectedMode).toBe('cheque');
    	expect(isolatedScope.selectedType).toBe('capital');    	
    });

    it('should define the variable swpObj if investor logged in',function(){
    	expect(isolatedScope.swpObj[0].text).toBe('Withdrawl Type');
    	expect(isolatedScope.swpObj[0].value).toBe('Capital Appreciation');
    	expect(isolatedScope.swpObj[1].text).toBe('Amount');
    	expect(isolatedScope.swpObj[1].value).toBe('Capital Appreciation');
    	expect(isolatedScope.swpObj[2].text).toBe('Frequency');
    	expect(isolatedScope.swpObj[2].value).toBe('Monthly');
    	expect(isolatedScope.swpObj[3].text).toBe('SWP Start Date');
    	expect(isolatedScope.swpObj[3].value).toBe($filter('date')(swpObject.startDate, 'dd MMM yyyy'));
    	expect(isolatedScope.swpObj[4].text).toBe('SWP End Date');
    	expect(isolatedScope.swpObj[4].value).toBe($filter('date')(swpObject.endDate, 'dd MMM yyyy'));
    	expect(isolatedScope.swpObj[5].text).toBe('No. of Installments');
    	expect(isolatedScope.swpObj[5].value).toBe(6);
    	expect(isolatedScope.swpObj[6].text).toBe('Bank Details');
    	expect(isolatedScope.swpObj[6].value).toBe('CITI BANK - 7335300411');
    	expect(isolatedScope.swpObj[7].text).toBe('Mode of Payment');
    	expect(isolatedScope.swpObj[7].value).toBe('cheque');
    	advisor = true;
    });

	it('should define the variable swpObj if advisor logged in',function(){    	
    	expect(isolatedScope.swpObj[0].text).toBe('Amount');
    	expect(isolatedScope.swpObj[0].value).toBe('Capital Appreciation');
    	expect(isolatedScope.swpObj[1].text).toBe('Frequency');
    	expect(isolatedScope.swpObj[1].value).toBe('Monthly');
    	expect(isolatedScope.swpObj[2].text).toBe('SWP Start Date');
    	expect(isolatedScope.swpObj[2].value).toBe($filter('date')(swpObject.startDate, 'dd MMM yyyy'));
    	expect(isolatedScope.swpObj[3].text).toBe('SWP End Date');
    	expect(isolatedScope.swpObj[3].value).toBe($filter('date')(swpObject.endDate, 'dd MMM yyyy'));
    	expect(isolatedScope.swpObj[4].text).toBe('No. of Installments');
    	expect(isolatedScope.swpObj[4].value).toBe(6);
    	expect(isolatedScope.swpObj[5].text).toBe('Mode of Bank Details');
    	expect(isolatedScope.swpObj[5].value).toBe('CITI BANK - 7335300411');
    	expect(isolatedScope.swpObj[6].text).toBe('Mode of Payment');
    	expect(isolatedScope.swpObj[6].value).toBe('cheque');    	
    });      
});