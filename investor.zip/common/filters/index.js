/**
 *@ngdoc object
 *@name common.module:filters
 *@description
 * <p>
 * In this we have the all global filters 
 * </p> 
 */

module.exports = angular.module('common.filters', [])
    .filter('fticTrim', require('./fticTrim.filter'))
    .filter('fticVideo', require('./fticVideo.filter'))
    .filter('fticRupee', require('./fticRupee.filter'))
    .filter('fticInvFormatTwoDigitNum', require('./fticInvFormatTwoDigitNum.filter'));
