// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var SubmitRedemptionDetailsModelSchema = new mongoose.Schema({
    submitRedemptionDetailsResponse: {
        type: Object,
        'default': {}
    }
});

var SubmitRedemptionDetailsModelLookUp = mongoose.model('SubmitRedemptionDetailsModelLookUp', SubmitRedemptionDetailsModelSchema);

var SubmitRedemptionDetailsModel = new SubmitRedemptionDetailsModelLookUp({
    submitRedemptionDetailsResponse: {
        'status': 'pending',
        'Reference_Number': 'SWI001167',
        'misc_info': {
            'Submitted': '2016-11-10T00:02:57.665',
            'MWESBID': '1780b41ca71c11e68b6c0a415f66000030592c7720000000'
        }

    }
});

SubmitRedemptionDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SubmitRedemptionDetailsModelLookUp table, please contact admin...');
    } else {
        SubmitRedemptionDetailsModelLookUp.remove({}, function(err) {
            console.log('SubmitRedemptionDetailsModelLookUp collection removed');
            SubmitRedemptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SubmitRedemptionDetailsModelLookUp table, please contact admin...');
                }
                console.log('SubmitRedemptionDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SubmitRedemptionDetailsModelLookUp;
