/**
 * @ngdoc property
 * @name fticRedemptionForm Directive
 * @requires MyInvestorConstant
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Redemption Form.
 *
 **/
'use strict';


var fticRedemptionForm = function(transactModel, populateAmountModel, populateUnitsModel, RegisteredBankInitLoader, RegisteredBankModel, redeemModel, redeemInitialLoader, transactEventConstants, transactEvents, selectFundModel, $state, TransactConstant, toaster, fundDetailsModel, $stateParams, $timeout, redeemReviewDetailsFactory, $loader,$filter) {
    return {
        template: require('./redeemform.html'),
        restrict: 'E',
        replace: true,
        scope: {},

        controller:['$scope', '$element', function ($scope, $element) {
            $scope.greaterAmtUnitsMsgStaus = false;
            $scope.required = true;
            $scope.continueBtn = true;
            $scope.editRedeemBankDetails = '';
            $scope.config = {};
            $scope.$amountInput = $element[0].querySelector('.amountInput input');
            $scope.$unitsInput = $element[0].querySelector('.unitsInput input');
            $scope.config.showNotification = false;
            $scope.redeemCtnBtn = true;
            $scope.populateRedeemDetails = false;
            $scope.amountObject = {
                key: 'Amount',
                text: 'Amount '+'<span class="icon-fti_rupee"></span>',
                value: ''
                //type: 'number',
                //name:'amount',
                //pattern:/^(?!\.?$)\d{0,9}(\.\d{1,2})?$/
                    // isRequired : true
            };

            $scope.unitsObject = {
                key: 'Units',
                text: 'Units',
                value: ''
                //type: 'number',
                //name:'unit',
                //pattern:/^(?!\.?$)\d{0,9}(\.\d{1,3})?$/
                    // isRequired : true
            };
            $scope.isInvestorLogin = redeemReviewDetailsFactory.isLoggedInvestor();
            $scope.isBankCreditDefault = false;

            var formResetOnFundChange = function() {
                $scope.amountObject.value = '';
                $scope.unitsObject.value = '';
                $scope.selectedVal = '';
                redeemModel.setUnits('');
                redeemModel.setAmount('');
                redeemModel.setType('');
                redeemModel.setMode('Cheque');
                $scope.modeSelectedVal = 'Cheque';
            };

            $scope.$on(transactEventConstants.transact.REDEEM_FORM_RESET, function(event, isFormReset) {
                resetRedeemForm();
                if(isFormReset && $scope.isInvestorLogin) {
                    formResetOnFundChange();
                }
            });
            var redeemDetailsModel = {};
            /*$scope.amountObject.disable = true;
            $scope.unitsObject.disable = true;*/
            $scope.$on('INPUT_CHANGED', function(event, data) {
                console.log($scope.redeemForm.amount);
                $scope.showInputError = false;
                if (data.value) {
                    var nav;
                    nav = fundDetailsModel.getFundDetails().fundDetails[0].lastestNav;
                    if (redeemModel.getType() === 'Amount') {
                        // var amountToUnits = transactModel.convertAmountToUnit($scope.amountObject.value,nav);
                        // populateUnitsModel.setUnits(amountToUnits);
                        // $scope.unitsObject.value = populateUnitsModel.getUnits();
                        redeemModel.setAmount($scope.amountObject.value);
                        $scope.unitsObject.disable = true;
                        // redeemModel.setUnits((amountToUnits).toString());
                        transactEvents.transact.publishAmountDetails($scope);

                    } else if (redeemModel.getType() === 'Units') {
                        // var unitToAmount = transactModel.convertUnitToAmount($scope.unitsObject.value,nav);
                        // populateAmountModel.setAmount(unitToAmount);
                        // $scope.amountObject.value = populateAmountModel.getAmount();
                        redeemModel.setUnits($scope.unitsObject.value);
                        $scope.amountObject.disable = true;
                        // redeemModel.setAmount((unitToAmount).toString());
                        transactEvents.transact.publishAmountDetails($scope);
                    }
                }
            });

            function SetDetailsGoReview() {
                $loader.start();
                if ($scope.continueBtn === true) {
                    redeemModel.validateRedeem().then(function(data) {
                        if ($scope.greaterAmtUnitsMsgStaus) {
                            toaster.success('No.of Amount/Units you have entered is more than the balance available. Hence entire amount/unit balance will be considered for redemption');
                        }
                        if ($scope.isInvestorLogin) {
                            $state.go('invTransact.review.redeem');
                        } else {
                            $state.go('transact.review.redeem');
                        }
                        transactModel.setWebRefNo(data.webRefNo);
                    }, function(data) {
                        toaster.error(data.data[0].errorDescription);
                    }).finally(function() {
                        $loader.stop();
                    });
                } else {
                    redeemModel.validateRedeem().then(function() {
                        //alert('success')
                        //transactModel.setWebRefNo(data.webRefNo);
                        $scope.$emit('postTransactTypeDetails');
                        if ($scope.greaterAmtUnitsMsgStaus) {
                            toaster.success('No.of Amount/Units you have entered is more than the balance available. Hence entire amount/unit balance will be considered for redemption');
                        }

                    }, function(data) {
                        toaster.error(data.data[0].errorDescription);
                    }).finally(function() {
                        $loader.stop();
                    });
                }
            }

            function displayFullUnits() {
                if (!fundDetailsModel.getFundDetails()) {
                    return;
                }
                var totalAvlUnits = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits;
                totalAvlUnits = totalAvlUnits ? totalAvlUnits.replace(/,/g, "") : totalAvlUnits;
                // var totalValOfUnits =  fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split('.')[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split('.')[1].substring(0, 2);
                // $scope.amountObject.value = totalValOfUnits;
                $scope.unitsObject.value = $filter('fticInvStringToNumber')(totalAvlUnits);
                $scope.amountObject.value = '';
                console.log('$scope.unitsObject.value', $scope.unitsObject.value);
                // populateAmountModel.setAmount($scope.amountObject.value);
                populateUnitsModel.setUnits($scope.unitsObject.value);
                redeemModel.setUnits($scope.unitsObject.value);
                // redeemModel.setAmount($scope.amountObject.value);
                //transactEvents.transact.publishAmountDetails($scope);
            }

            function clearInputValues() {
                redeemModel.setUnits('');
                redeemModel.setAmount('');
                $scope.amountObject.value = '';
                $scope.unitsObject.value = '';
                $scope.amountObject.disable = true;
                $scope.unitsObject.disable = true;
            }
            //$scope.selectedVal = redeemModel.getType();
            $scope.typeChanged = function(val) {
                $scope.redeemCtnBtn = false;
                $scope.showTypeError = false;
                var fundDtls;
                fundDtls = selectFundModel.getSelectFundDtls();

                redeemModel.setType(val);
                if (redeemModel.getType() === 'Full') {
                    $scope.amountObject.disable = true;
                    $scope.unitsObject.disable = true;
                    // redeemModel.setAmount(fundDtls.currentValue);
                    // $scope.amountObject.value = redeemModel.getAmount();
                    // redeemModel.setUnits(fundDtls.totalUnits);
                    // $scope.unitsObject.value = redeemModel.getUnits();
                    // angular.element($scope.$amountInput).triggerHandler('focus');
                    angular.element($scope.$unitsInput).triggerHandler('focus');
                    displayFullUnits();
                } else if (redeemModel.getType() === 'Amount') {
                    clearInputValues();
                    $scope.amountObject.disable = false;
                    // $scope.unitsObject.disable = true;
                    angular.element($scope.$amountInput).triggerHandler('blur');
                    // angular.element($scope.$unitsInput).triggerHandler('focus');
                } else if (redeemModel.getType() === 'Units') {
                    clearInputValues();
                    $scope.unitsObject.disable = false;
                    // $scope.amountObject.disable = true;
                    angular.element($scope.$unitsInput).triggerHandler('blur');
                    // angular.element($scope.$amountInput).triggerHandler('focus');
                }
            };

            //$scope.modeSelectedVal = 'Cheque';
            //redeemModel.setMode('Cheque');
            $scope.modeChanged = function(val) {
                redeemModel.setMode(val);
                // console.log(val);
            };

            $scope.bankOptionValues = {
                name: 'bankDetails',
                required: true
            };
            $scope.$on('Call_Registered_banks', function() {
                redeemInitialLoader.loadAllServices($scope);
            });
            $scope.$on(transactEventConstants.transact.REDEMPTION_DETAILS, function() {
                $scope.amountObject.disable = true;
                $scope.unitsObject.disable = true;
                var bankDtls = redeemModel.getBankDetails().paymentBank;
                var bankArr = [];
                var bankPayoutType = bankDtls && bankDtls.length > 0 ? redeemModel.getBankDetails().paymentBank[0].payoutFlag : 'Cheque';
                $scope.isBankCreditDefault = (bankPayoutType === 'Directly To Bank') ? 'Direct Credit' : 'Cheque';

                redeemModel.setMode($scope.isBankCreditDefault);
                $scope.modeSelectedVal = $scope.isBankCreditDefault;

                for (var i = 0; i < bankDtls.length; i++) {
                    var bank = { title: bankDtls[i].pbBankName + ' - ' + bankDtls[i].pbPersonalAccountNumber };
                    if (bank.title === redeemModel.getBank()) {
                        $scope.selected = bank;
                    }
                    bankArr.push(bank);
                }
                /*if(redeemModel.getIsRedeemEdit() !== null && redeemModel.getIsRedeemEdit()){
                    setBankDeatils();
                }*/
                $scope.bankOptions = null;
                $timeout(function() {
                    $scope.bankOptions = bankArr;
                });

            });

            $scope.$on('selectedOption', function(event, data) {

                redeemModel.setBank(data.title);
            });

            // var registeredBank = null;
            // $scope.$on('Call_Registered_banks', function(event,data){
            //     RegisteredBankInitLoader.loadAllServices($scope);
            // });
            // $scope.$on(transactEventConstants.transact.REGISTERED_BANK, function(event, data) {

            //     registeredBank = RegisteredBankModel.getRegisteredBank().bankDetails[0];
            //     var regBankAccount = registeredBank.bankName + ' - ' + registeredBank.accountNo;
            //     //console.log(regBankAccount)
            //     for(var i=0; i<$scope.bankOptions.length; i++) {
            //         if($scope.bankOptions[i].title === regBankAccount) {
            //             $scope.selected = $scope.bankOptions[i];
            //             redeemModel.setBank(regBankAccount);
            //             console.log($scope.selected)
            //         }
            //     }
            // });

            $scope.showTypeError = false;
            $scope.showInputError = false;
            $scope.showBankError = false;

            function replaceComma(data){
                if(data){
                    data = data.replace(/,/g, "");
                }
                return data;
            }

            $scope.getSelections = function() {
                if ($scope.redeemForm.bankDetails.$invalid) {
                    $scope.showBankError = true;
                } else {
                    $scope.showBankError = false;
                }
                if ($scope.redeemForm.$valid) {
                    $scope.greaterAmtUnitsMsgStaus = false;
                    var totalAvlUnits = replaceComma(fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits);
                    var totalAvlAmount = replaceComma(fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits);
                    if (parseInt(redeemModel.getAmount()) > parseInt(totalAvlAmount) || parseInt(redeemModel.getUnits()) > parseInt(totalAvlUnits)) {
                        var type = 'Full';
                        var units = $filter('fticInvStringToNumber')(totalAvlUnits);
                        redeemModel.setType(type);
                        redeemModel.setUnits(units);
                        $scope.greaterAmtUnitsMsgStaus = true;
                        if (redeemModel.getAmount() > 0) {
                            redeemModel.setAmount('');
                            $scope.amountObject.value = '';
                        }
                    }
                    var redeemDetails = {
                        'type': redeemModel.getType(),
                        'amount': redeemModel.getAmount(),
                        'units': redeemModel.getUnits(),
                        'mode': redeemModel.getMode(),
                        'bank': redeemModel.getBank()
                    };
                    redeemModel.setRedeemDetails(redeemDetails);
                    redeemDetailsModel.investorDetails = transactModel.getInvestorDetails();
                    redeemDetailsModel.fundDetails = transactModel.getFundDetails();
                    redeemDetailsModel.transactDetails = redeemModel.getRedeemDetails();

                    if ($stateParams.key === 'Redeem') {
                        var result = _.isEqual(transactModel.getTransactDetails(), redeemDetailsModel);
                        if (!result) {
                            $scope.config.showNotification = true;
                            var destroyHandler = $scope.$on('yes', function() {
                                transactModel.setTransactDetails(redeemDetailsModel);
                                SetDetailsGoReview();
                                destroyHandler();
                            });

                            $scope.$on('no', function() {
                                $scope.config.showNotification = false;
                            });
                        } else
                            SetDetailsGoReview();
                    } else {
                        transactModel.setTransactDetails(redeemDetailsModel);
                        SetDetailsGoReview();
                    }

                } else {
                    if ($scope.redeemForm.type.$invalid) {
                        $scope.showTypeError = true;
                    } else if ($scope.redeemForm.name.$invalid) {
                        $scope.showInputError = true;
                    } else if ($scope.continueBtn === false) {
                        $scope.showInputError = true;
                    }
                }
            };

            function resetRedeemForm() {
                $scope.selectedVal = '';
                $scope.amountObject.value = '';
                $scope.unitsObject.value = '';
                $scope.modeSelectedVal = 'Cheque';
                //redeemModel.setMode('Cheque'); //commented for investor
                $scope.continueBtn = true;
                $scope.populateRedeemDetails = false;  
                $scope.unitsObject.disable  = true;
                $scope.amountObject.disable = true;                                                
            }


            // for guest module edit REDEEM details...
            /*function setBankDeatils (){
                for(var i=0; i<$scope.bankOptions.length; i++) {
                        if($scope.bankOptions[i].title === $scope.editRedeemBankDetails) {
                            $scope.selected = $scope.bankOptions[i];
                        }
                    }
            }*/

            if($stateParams.key === "Fund"){
                $scope.populateRedeemDetails = true;
            }  

            function redeemEditPopulation(fromContinue) {
                if (redeemModel.getIsRedeemEdit() !== null || $stateParams.key === 'Redeem' || fromContinue) {
                    //alert(redeemModel.getIsRedeemEdit())
                    $scope.unitsObject.disable  = true;
                    $scope.amountObject.disable = true;
                    if (redeemModel.getIsRedeemEdit() || $stateParams.key === 'Redeem' || fromContinue) {
                        $scope.redeemCtnBtn = false;
                        $scope.continueBtn = false;
                        if ($stateParams.key === 'Redeem') {
                            $scope.continueBtn = true;
                            $scope.$emit('Select_Fund_Continue');
                        }
                        if (fromContinue) {
                            $scope.continueBtn = true;
                            $scope.$emit('Select_Fund_Continue1');
                        }
                        $scope.selectedVal = redeemModel.getType();
                        if (redeemModel.getType() === 'Full') {
                            $scope.amountObject.disable = true;
                            $scope.unitsObject.disable = true;
                            // $scope.amountObject.value = redeemModel.getAmount();
                            // $scope.unitsObject.value = redeemModel.getUnits();
                            angular.element($scope.$amountInput).triggerHandler('focus');
                            angular.element($scope.$unitsInput).triggerHandler('focus');
                            displayFullUnits();
                        } else if (redeemModel.getType() === 'Amount') {
                            angular.element($scope.$amountInput).triggerHandler('focus');
                            $scope.amountObject.disable = false;
                            $scope.unitsObject.disable = true;
                            $scope.amountObject.value = redeemModel.getAmount();
                            $scope.unitsObject.value = redeemModel.getUnits();
                            angular.element($scope.$unitsInput).triggerHandler('focus');
                        } else if (redeemModel.getType() === 'Units') {
                            angular.element($scope.$unitsInput).triggerHandler('focus');
                            $scope.unitsObject.disable = false;
                            $scope.amountObject.disable = true;
                            $scope.amountObject.value = redeemModel.getAmount();
                            $scope.unitsObject.value = redeemModel.getUnits();
                            angular.element($scope.$amountInput).triggerHandler('focus');
                        }

                        if (redeemModel.getMode() === 'Direct Credit') {
                            $scope.modeSelectedVal = 'Direct Credit';
                        } else if (redeemModel.getMode() === 'Cheque') {
                            $scope.modeSelectedVal = 'Cheque';
                        } else {
                            $scope.modeSelectedVal = 'Cheque';
                        }
                        $scope.editRedeemBankDetails = redeemModel.getBank();
                    } else {
                        resetRedeemForm();
                    }
                }
            }

            redeemEditPopulation(false);
            $scope.$on('populateRedeemDetails', function() {
                if (redeemModel.getType()) { 
                //if ($scope.populateRedeemDetails) { //commented from merge

                    redeemEditPopulation(true);
                }
            });


            $scope.$on('validateRedeemForm', function() {
                $scope.redeemForm.$submitted = true;
                $scope.getSelections();
            });

           $scope.validateAmountInput = function () {
                if ($scope.amountObject.value) {
                    $scope.amountObject.value = $scope.amountObject.value.replace(/[^0-9]+/g, '');
                     /*if ($scope.amountObject.value.split('.').length > 2) {
                        $scope.amountObject.value = $scope.amountObject.value.substring(0, $scope.amountObject.value.length - 1);
                    }
                    if($scope.amountObject.value.split('.')[1]){
                    if($scope.amountObject.value.split('.')[1].length>2){
                         $scope.amountObject.value = $scope.amountObject.value.substring(0, $scope.amountObject.value.length - 1);
                    }
                }*/
                } 
            };

             $scope.validateUnitInput = function () {
                if ($scope.unitsObject.value) {
                    $scope.unitsObject.value = $scope.unitsObject.value.replace(/[^0-9\.]+/g, "");
                    if ($scope.unitsObject.value.split('.').length > 2) {
                        $scope.unitsObject.value = $scope.unitsObject.value.substring(0, $scope.unitsObject.value.length - 1);
                    }
                    if($scope.unitsObject.value.split('.')[1]){
                     if($scope.unitsObject.value.split('.')[1].length>3){
                         $scope.unitsObject.value = $scope.unitsObject.value.substring(0, $scope.unitsObject.value.length - 1);
                    }
                }
                } 
            };
        }]
       
    };
};

fticRedemptionForm.$inject = ['transactModel', 'populateAmountModel', 'populateUnitsModel', 'RegisteredBankInitLoader', 'RegisteredBankModel', 'redeemModel', 'redeemInitialLoader', 'transactEventConstants', 'transactEvents', 'selectFundModel', '$state', 'TransactConstant', 'toaster', 'fundDetailsModel', '$stateParams', '$timeout', 'redeemReviewDetailsFactory', '$loader','$filter'];
module.exports = fticRedemptionForm;
