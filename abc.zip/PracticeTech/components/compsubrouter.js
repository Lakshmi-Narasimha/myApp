﻿define([
  'jquery',
  'underscore',
  'backbone',
  'backbonesubroute',
  'components/js/views/ComponentsIndexView',
  'components/js/views/EmpCompView'
], function ($, _, Backbone, backbonesubroute, ComponentsIndexView, EmpCompView) {
    var compRouter = Backbone.SubRoute.extend({
        routes: {
            "index": "showComponentsIndex",
            "employercomp": "showEmployerComponent",
            "*path": "defaultAction"
        },
        showComponentsIndex: function () {
            var compIndex = new ComponentsIndexView();
            compIndex.render();
        },
        showEmployerComponent: function () {
            var employercomp = new EmpCompView();
            employercomp.render();
        },
        defaultAction: function () {
            Backbone.history.navigate("comp/index", true);
        }
    });
    return { compRouter: compRouter };
});

/*define(['jquery',
    'lodash',
    'backbone',
    'backbonesubroute'
], function ($, _, Backbone, backbonesubroute) {
    var compRouter = Backbone.SubRoute.extend({
        routes: {
            "comp1": "showComp1",
            "*path": "defaultAction"
        },
        showComp1: function () {
            requirejs(['components/js/views/comp1'], function (Comp1) {
                var comp1 = new Comp1();
                //app.appView.setPrimaryView(sampleView);
                comp1.render();
            });
        },
        defaultAction: function () {
            Backbone.history.navigate("comp/comp1", true);
        }
    });
    return { compRouter: compRouter };
});*/