define(['services/dataservice',
        'errorLog',
        'appcommon/constants',
        'appcommon/globalcontext',
        'appmodules/hoc/app/data/hoc-matrix',
        'appcommon/commonutility'],

        function (DataService, ErrorLog, Constants, GlobalContext, HOCMatrix, CommonUtils) {
    function init() {
        var indicatorObj = null, isServiceCallInProgress = false;
		var indicatorModel = Backbone.Model.extend({
    		defaults:{
    			clientId:null,
    			openActions:null,
    			pendingAction:null,
    			closedActions:null,
    			deferedActions:null,
    			dataNAActions:null,
    			totalActions: null,
    			totalOpenItems: 0,
    			ctgrWiseOpnItmCount: { "1": 0, "2": 0, "3": 0 },
    		}
		});
    	var createObjAndRegisterEvents = function(){
    		if(!indicatorObj){
				indicatorObj = new indicatorModel();
			}
    		indicatorObj.on("change",updateCount);
    	};
    		
    	var getActionStatus = function (response, isCalculatedResults, maxAge,includeCtg2) {
    		
    		var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId,
    		    clientType = GlobalContext.getInstance().getGlobalContext().Context.ContactType,
    		    userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles,
                serviceCallStack;
    		var status = {
    		    clientId: clientId, openActions: 0, pendingAction: 0, closedActions: 0, deferedActions: 0, dataNAActions: 0, totalActions: 0, ctgrWiseOpnItmCount: { "1": 0, "2": 0, "3": 0 }, totalOpenItems:0
    		};
    			if(clientId && clientType == Constants.contactType.Client){
        			if(response){
        				if(response && isCalculatedResults){
        					updateCalculatedActionsStatus(response);
        				}
        				else if(response && response.value && !isCalculatedResults){
            				calculateActionsStatus(response, status);
            			}
        			}else{
        				if(!isServiceCallInProgress){
        				    isServiceCallInProgress = true;
        				    var _clId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
        				    DataService.getHOCListItems(_clId, includeCtg2, maxAge, maxAge).then(function (responses) {
        				        var hocListResp = CommonUtils.parseHOCListemsResponse(responses);
        				        isServiceCallInProgress = false;
        				        if (hocListResp && hocListResp.value && hocListResp.value.length > 0) {
        				            calculateActionsStatus(hocListResp, status);
        				        }
        				    }).fail(function (error) {
        				        isServiceCallInProgress = false;
        				        ErrorLog.ErrorUtils.myError(error, true);
        				    });
        				}
        			
        			}
        		}
    	};
    	var calculateActionsStatus = function(response, status){
    	    var results = response.value, _ctgrWiseOpnItmCount = { "1": 0, "2": 0, "3": 0 }, _ctgCd,_totalOpenItems = 0;
			if(results && results.length>0){
			    results.forEach(function (row, key) {
			        if (row.itemStatCd == "opn" && compareWithHOCMatrix(row)) {
			            if (row.ctgCd == "1") {
			                status.openActions++;
			                status.totalActions++;
			            }
			           
			            _totalOpenItems++;
			            _ctgCd = row.ctgCd;
			            if (typeof _ctgrWiseOpnItmCount[_ctgCd] == "undefined") {
			                _ctgrWiseOpnItmCount[_ctgCd] = 0;
			            }
			            _ctgrWiseOpnItmCount[_ctgCd]++;
			        }
			        if (row.itemStatCd == "ni" && compareWithHOCMatrix(row) && row.ctgCd == "1") {
			            status.closedActions++;
			        }
			        if (row.itemStatCd == "smb" && compareWithHOCMatrix(row) && row.ctgCd == "1" ) {
			            status.pendingAction++;
			        }
			        if (row.itemStatCd == "psp" && compareWithHOCMatrix(row) && row.ctgCd == "1" ) {
			            status.deferedActions++;
			        }
			        if (row.itemStatCd == "dna" && compareWithHOCMatrix(row) && row.ctgCd == "1" ) {
			            status.dataNAActions++;
			        }
			    });
			    status.totalOpenItems = _totalOpenItems;
			    status.ctgrWiseOpnItmCount = _ctgrWiseOpnItmCount;
			}
			
			indicatorObj.set(status);
			updateCount();
    	};
    	var updateCalculatedActionsStatus = function(data){
    		var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId, status = indicatorObj.toJSON(),_totalOpenItems = 0;
    		status.ctgrWiseOpnItmCount = data.ctgrWiseOpnItmCount;
    		if(isValidCount(data.openActions)){
    			status.openActions = data.openActions;
    			status.totalActions = data.openActions;
    		}
    		if(isValidCount(data.pendingAction)){
    			status.pendingAction = data.pendingAction;
    		}
    		if(isValidCount(data.closedActions)){
    			status.closedActions = data.closedActions;
    		}
    		if(isValidCount(data.deferedActions)){
    			status.deferedActions = data.deferedActions;
    		}
    		if(isValidCount(data.dataNAActions)){
    			status.dataNAActions = data.dataNAActions;
    		}
    		for (var ctgd in status.ctgrWiseOpnItmCount) {
    		    _totalOpenItems = _totalOpenItems + status.ctgrWiseOpnItmCount[ctgd];
    		}
    		status.totalOpenItems = _totalOpenItems;
    		indicatorObj.set(status);
			updateCount();
    	};
    	var isClientChanged = function(){
    		var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
    		if(indicatorObj.get("clientId") && indicatorObj.get("clientId") != clientId){
    			return true;
    		}
    		return false;
    	};
    	var isValidCount = function(count){
    		if(count !== null && count !== "" && count !== undefined){
    			return true;
    		}
    		return false;
    	};
    	var updateCount = function(){
    	    var megaMenuEntry = $("#nav-hocInsights .mm-hocIndicator"), cpMoreACtionsENtry = $("#hoc-doc-count"), hocPageActionEntry = $("#takeActionCount"), cplaunchHOCBtn = $("#launchHOCBtn"),
                _$dolCount = $('#dolCount'), _$servcoprtCount = $('#servc-oprt-count'), _ctgrWiseOpnItmCount = indicatorObj.get("ctgrWiseOpnItmCount"), _takeActionOpnItems = _ctgrWiseOpnItmCount["1"],
    	        _servcOprtntsOpnItems = _ctgrWiseOpnItmCount["2"], _dolOpnItems = _ctgrWiseOpnItmCount["3"], _totalOpnItems = indicatorObj.get("totalOpenItems");
    	    if (_totalOpnItems && _totalOpnItems > 0) {
    	        var _dolAndTakeActnOpenItems = Number(_dolOpnItems) + Number(_takeActionOpnItems);
    	        if (megaMenuEntry && cplaunchHOCBtn && _dolAndTakeActnOpenItems > 0) {
    	            megaMenuEntry.removeClass("hidden").text(_dolAndTakeActnOpenItems);
    	            cplaunchHOCBtn.removeClass("hidden").text(_dolAndTakeActnOpenItems + (_dolAndTakeActnOpenItems == 1 ? " insight" : " insights"));
    	        } else {
    	            megaMenuEntry.addClass("hidden");
    	            cplaunchHOCBtn.addClass("hidden");
    	        }
    	        if (typeof _takeActionOpnItems != "undefined" && _takeActionOpnItems > 0) {
    	            if (cpMoreACtionsENtry) { cpMoreACtionsENtry.removeClass("hidden"); cpMoreACtionsENtry.text(_takeActionOpnItems); }
    	            if (hocPageActionEntry) { hocPageActionEntry.removeClass("hidden"); hocPageActionEntry.text(_takeActionOpnItems); }
    	            //if (cplaunchHOCBtn) { cplaunchHOCBtn.removeClass("hidden"); cplaunchHOCBtn.text(_takeActionOpnItems + (_takeActionOpnItems == 1 ? " insight" : " insights")); }
    	        } else {
    	            cpMoreACtionsENtry.addClass("hidden");
    	            hocPageActionEntry.addClass("hidden");
    	            //cplaunchHOCBtn.addClass("hidden");
    	        }
    	        if (typeof _dolOpnItems != "undefined" && _dolOpnItems > 0) {
    	            _$dolCount.removeClass("hidden").text(_dolOpnItems);
    	        } else {
    	            _$dolCount.addClass("hidden");
    	        }
    	        if (typeof _servcOprtntsOpnItems != "undefined" && _servcOprtntsOpnItems > 0) {
    	            _$servcoprtCount.removeClass("hidden").text(_servcOprtntsOpnItems);
    	        } else {
    	            _$servcoprtCount.addClass("hidden");
    	        }
    	    } else {
    	        megaMenuEntry.addClass("hidden");
    	        cpMoreACtionsENtry.addClass("hidden");
    	        hocPageActionEntry.addClass("hidden");
    	        cplaunchHOCBtn.addClass("hidden");
    	        _$servcoprtCount.addClass("hidden");
    	        _$dolCount.addClass("hidden");
    	    }
    	    
    	};
    	var logCustomError = function(stack){
    	    var _customLog = {
    	        "message": "Error occured while calculating HOC open items coun",
    	        "stack": {
    	            "description" : stack
    	        }
    	    }
    	    ErrorLog.ErrorUtils.myError(_customLog, true);
    	}
    	var compareWithHOCMatrix = function (data) {
    	    var proceed = false,
                _count = 0,
                _catgry,
                _hocSections,
                _itemViewDisplay;
    	    _catgry = HOCMatrix.categories.find(function (ctgry) {
    	        return ctgry.ctgCd == data.ctgCd;
    	    });
    	    if (_catgry && _catgry.sections) {
    	        try{
    	            _hocSections = _catgry.sections.find(function (sectn) {
    	                return sectn.sectionId == data.itemStatCd;
    	            });
    	        } catch (e) {
    	            logCustomError({
    	                "category": _catgry,
    	                "data": data,
                        "message":e.message
    	            })
    	        }
    	    } else {
    	        logCustomError({
    	            "category": _catgry,
    	            "data": data
    	        })
    	    }
    	    if (_hocSections && _hocSections.items && _hocSections.items.length > 0) {
    	        _hocSections.items.forEach(function (item, key) {
    	            if (item.itemTypCd == data.itemTypCd) {
    	                _count++;
    	                _itemViewDisplay = item.viewDisplay;
    	                if (item.viewDisplay == true) {
    	                    proceed = true;
    	                }
    	            }
    	        });
    	    }
    	    if ((_count > 0 && _itemViewDisplay !== false)) {
    	        proceed = true;
    	    }
    	    return proceed;
    	};
    	//Create object and register events
    	createObjAndRegisterEvents();
    	
    	//Get latest HOC status
    	getActionStatus();    	
    	this.updateActionStatus = function (response, isCalculatedResults, maxAge, includeCtg2) {
    	    getActionStatus(response, isCalculatedResults, maxAge, includeCtg2);
        };
        this.showCount = function(){
        	if(indicatorObj.get("totalActions") == null){
        		getActionStatus();
        	}else if(isClientChanged()){
        		getActionStatus();
        	}
        	else{
        		updateCount();
        	}
        	
        };
        this.getStatus = function(){
        	return indicatorObj.toJSON();
        }
    };
    return new init();
});