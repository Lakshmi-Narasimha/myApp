﻿define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils',
        'appmodules/contactprofile/app/models/cpviewmodel',
        'text!appmodules/gpm/app/templates/gpmhonorific.html',
        'appcommon/data'
], function ($, _, Backbone, Utils, CPViewModel, HonorificTemplate, GPMdata) {
    var honorificMapping = GPMdata.honorific;
    var honorific = Backbone.View.extend({
        el: $("#gpm-form-update-field-container"),
        id: 'gpm-form-update-field-container',
        events: {
        },
        template: _.template(HonorificTemplate),
        initialize: function (data) {
            this.data = data;
            ;
        },
        render: function (updateMode) {
            try {   
                var self = this;
                if (!this.model.get('currentItemSet')) {
                    var CPData = CPViewModel.getInstance().getData();
                    var _code = CPData.cola.personClient.get('clHnrfNm');
                    //var _mappedCode = honorificMapping.find(function (row) { return row.serviceValue == _code }).code || "";
                    var honorary = (_.find(GPMdata.honorific, function (obj) { return obj.code == CPData.cola.personClient.get('clHnrfNm') }) || { name: "", code: "" });
                    this.data.fieldsInfo = {
                        clHnrfNm: honorary.code,
                        hnyName: honorary.name 
                    };
                    this.model.setCurrentValue(updateMode, { data: this.data })
               }
                
                var _dataSet = this.model.get('items');
                var _honorific = _dataSet.find(function (row) { return row.get("itemType") == "honorific" }).get("changedItemValueId");
                $("#" + this.id).html(this.template({ data: _dataSet })).promise().done(function() {
                    self.loadHonorariesList(_honorific);
                });
            }
            catch (error) {
                console.log(error);
            }
        }, loadHonorariesList: function (selected) {
            var _honoraryList = GPMdata.honorific;
            var _selectbox = "#ci-client-honorific";
            var _options = {
                selectBox: _selectbox,
                optionsList: _honoraryList,
                selectedVal: selected,
                noEmptyOption: false,
                isOptional: true,
                noneOption: {
                    value: " ",
                    label: "None"
                }
            }
            Utils.loadSelectbox(_options);
        },

        validateAndNavigateFromStep1: function () {
            if (this.model.validate('gpm-update-form', true)) {
                this.model.setChangedValue();
                if(this.model.getChangedItems().length>0){
                	$('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                }else{
                	Utils.showNoChangesMessageToUser();
                }
                
            }
        }

    });
    return honorific;
});