import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';

import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { ParamField } from '../_models/paramfield';

@Component({
  selector: 'parameditor',
  templateUrl: './parameditor.component.html',
  styleUrls: ['./parameditor.component.css']
})
export class ParameditorComponent implements OnInit, OnDestroy {

  parameters: Array<ParamField> = [];
  rows: Array<ParamField> = [];
  editMode: boolean = true;
  paramName: string;
  paramValue: string;
  showhidePagination: boolean = false;
  parameterSubscription: any = {};
  isParametersModified: boolean = false;

  public totalItems: number = this.parameters.length;
  public currentPage: number = 1;
  public itemsPerPage: number = 10;

  public maxSize: number = 5;
  public bigTotalItems: number = 175;
  public bigCurrentPage: number = 1;

  constructor(private aiAssistCacheService: AIAssistCacheService, private cd: ChangeDetectorRef) {
    this.subscribefordata();
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    if (this.parameterSubscription) {
          this.parameterSubscription.unsubscribe();
    }
  }

  private subscribefordata() {

    this.parameterSubscription = this.aiAssistCacheService.activeParamListObservable.subscribe((data) => {
      this.parameters = data;
      this.totalItems = this.parameters.length;
      this.updatePaginationVisibility();
      this.onPageChange({ page: 1, itemsPerPage: this.itemsPerPage });
    });

    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });

  }

  onAddParameter() {
    if (this.paramName && this.paramValue) {
      if(!this.parameters)
      this.parameters = new Array<ParamField>();
      let paramField = new ParamField();
      paramField.paramName = this.paramName;
      paramField.paramValue = this.paramValue;
      this.parameters.push(paramField);
      this.aiAssistCacheService.parametersChanged(this.parameters);
    }
    this.paramName = null;
    this.paramValue = null;
  }

  removeParameter(paramField: ParamField) {
    let index = this.parameters.indexOf(paramField);
    if (index > -1) {
      this.parameters.splice(index,1);
      this.aiAssistCacheService.parametersChanged(this.parameters);
    }

  }

  updatePaginationVisibility() {
    if (this.parameters != null && this.parameters.length > 0)
      this.showhidePagination = false;
    else
      this.showhidePagination = true;
  }

  onPageChange(page: any): void {
    let start = (page.page - 1) * page.itemsPerPage;
    let end = page.itemsPerPage > -1 ? (start + page.itemsPerPage) : this.parameters.length;
    this.rows = this.parameters.slice(start, end);
    this.cd.detectChanges();
  }

}
