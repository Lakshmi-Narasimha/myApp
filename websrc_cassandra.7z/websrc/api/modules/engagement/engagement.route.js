var express = require('express');
var https = require('https');
var http = require('http');
var querystring = require('querystring');

var router = express.Router();
var engagementModel = require('./engagement.model');
var getMessageModel = require('../getMessage/getMessage.model');
var dataPassModel = require('../dataPass/dataPass.model');

var apiUtils = require('../../common/apiUtils');

/* Trigerring the Engagement API on request from Client */
// API Route
router.route('/mfchat/rest/engagement')
    .post(function(req, res) {

        req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID];
        req.session.agentGroupID = req.body.RequestParams.agentGroupID;
        req.session.nickName = req.body.RequestParams.nickName;
        req.session.accRole = req.body.RequestParams.accRole;
        req.session.MDN = req.body.RequestParams.MDN;

        /* Trigerring the Engagement API internally to TC */
        var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + '&InitialMessage=' + initialMessage,
                headers: {
                    'Cookie': req.sessionCookie,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            },

            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    chunk = JSON.parse(chunk);
                    console.log('EngmntResponse:', chunk.engagementID);

                    if (chunk.engagementID) {
                        engagementModel.response.Page.status = (chunk.status === "queued" ? "accepted" : chunk.status);
                        engagementModel.response.Page.engagementID = req.engagementID = req.session.engagementID = chunk.engagementID; /// storing engagementID into the session
                        engagementModel.response.Page.customerID = req.session.customerID = chunk.customerID; /// storing customerID into the session

                        /* After three times GET Call */
                        apiUtils.getMsgMultiCall(req, res, function(chunk) {
                            chunk = JSON.parse(chunk);
                            //console.log("FinalResponse:", chunk);
                            //console.log('GetMessageResponse:',engagementModel.response.ModuleMap.Support.msgList[0].messageType);
                            //console.log("chunk.messages[0]",chunk.messages[0]);
                            if (chunk.messages[0] && chunk.messages[0].agentID || req.session.agentID) {
                                engagementModel.response.Page.agentName = req.session.agentName = (req.session.agentName || chunk.messages[0]['agent.alias']); /// storing agentName into the session
                                engagementModel.response.Page.agentID = req.session.agentID = (req.session.agentID || chunk.messages[0].agentID); /// storing agentID into the session
                                //console.log('session contains:', req.session);
                                engagementModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                engagementModel.response.ModuleMap.Support.msgList[0].agentGroupID = chunk.messages[0].agentGroupID;
                                engagementModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                engagementModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                engagementModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['agent.alias'] + "joined the conversation";
                                engagementModel.response.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0]['agent.alias'];
                                engagementModel.response.ModuleMap.Support.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0]['agent.alias'];
                            }
                        });

                        /* Condition to make the DataPass call */
                        if (req.session.agentGroupID !== 'WirelessSales') {
                            apiUtils.dataPass(req, res, function(res) {
                                console.log("Data Pass Call Trigerred");
                                /*apiUtils.generateToken(req, res, function(tokenResponse) {
                                    console.log("generateToken Call Trigerred");
                                    engagementModel.response.Page.token = tokenResponse.data.token;
                                    engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                                    engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                                    res.send(engagementModel.response);
                                });*/
                                res.send(engagementModel.response);
                            });
                        } else {
                            generateToken(req, res, function(tokenResponse) {
                                engagementModel.response.Page.token = tokenResponse.data.token;
                                engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                                engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                                res.send(engagementModel.response);
                            });
                        }
                    } else {
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }
                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
