/**
 * @ngdoc property
 * @name Main Controller
 * @requires $scope
 * @requires $state
 * @requires $localStorage
 * @description
 *
 * - It has the scope for entire application. Initially it contains the configuarations of Idle Provider 
 * and logout functionality
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter

function headerCtrl(fticMenuModel, globalMenuInitLoader, $scope, $localStorage, $state, $http, headerConstants, constants, events, eventConstants, $timeout, appConfig, configUrlModel, $window, $cookies, $filter, $sce) {
        $scope.$on('$stateChangeSuccess',function(event){
            $scope.searchtext = '';
        });
        $scope.showSubMenuItem = true;
        // if($cookies.get("userType") =='20' || $cookies.get("userType") =='30' || $cookies.get("userType") =='40'){
        if($cookies.get("userType") == $filter('translate')(constants.ADVISOR_MAIN_USER) || $cookies.get("userType") == $filter('translate')(constants.ADVISOR_SUB_USER1) || $cookies.get("userType") == $filter('translate')(constants.ADVISOR_SUB_USER2)){ 
           $scope.showSubMenuItem = false;
        }
        $scope.advisorDashboard = $cookies.get("userRedirectURI");
        $scope.textCopied = false;
        $scope.latestObject = {};
        $scope.myObject = [];
        $scope.userNameInputObject = {
                key : "loginusername",
                text : '',
                value : "",
                name : "loginName",
                type : "text",
                isRequired : true    
            };
        $scope.pwdInputObject = {
                key : "loginpassword",
                text : '',
                value : "",
                name : "loginPwd",
                type : "password",
                isRequired : true    
        };
        $scope.MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
        $scope.GUEST_URL = appConfig[configUrlModel.getEnvUrl('GUEST_URL')]; 
        $scope.$on(eventConstants.ON_MENU_DETAILS,function(event,data){        
            // var MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
            // var GUEST_URL = appConfig[configUrlModel.getEnvUrl('GUEST_URL')];  
            var data = fticMenuModel.getHeaderData();
            $scope.menus = data["utility-links"]["dropdown"];   
            $scope.header = data["header-common"]["logo"];
            $scope.header.url = $scope.MARKETING_URL+$scope.header.url;
            $scope.header.img = $scope.MARKETING_URL+$scope.header.img;
            $scope.mobilelogo = data["header-mobile-logo"];
            $scope.mobilelogo.url = $scope.MARKETING_URL+$scope.mobilelogo.url;
            $scope.mobilelogo.img = $scope.MARKETING_URL+$scope.mobilelogo.img;
            $scope.searchplaceholder = data["header-common"]["search"]["placeholder"];
            angular.forEach($scope.menus,function(obj){
                $scope.latestObject[obj.text]=[obj];
            });
            $scope.menus = $scope.latestObject;
            angular.forEach(data["nav-bar"]["nav-links"]["first-level-link"],function(firstlevelobj){
                angular.forEach(firstlevelobj["second-level-link"]["nav-link"],function(secondlevelobj){
                    angular.forEach(secondlevelobj["third-level-link"]["link"],function(thirdlevelobj){ 
                        if(thirdlevelobj.url.indexOf('http') !== '-1'){
                            if((thirdlevelobj.type=='guest')||(thirdlevelobj.type=='guestadviser')){
                                thirdlevelobj.url = $scope.GUEST_URL+"/#"+thirdlevelobj.url;
                            }else if(thirdlevelobj.type=='marketing'){
                                thirdlevelobj.url = $scope.MARKETING_URL+thirdlevelobj.url;
                            }
                            // else if(thirdlevelobj.type=='advisor'){
                            //     thirdlevelobj.url = appConfig.MARKETING_URL+"/#"+thirdlevelobj.url;
                            // }
                        }  
                    });
                });
            });
            angular.forEach(data["nav-bar"]["nav-links"]["first-level-link"],function(obj){
                $scope.myObj={};
                $scope.myObj[obj.text]=obj["second-level-link"]["nav-link"]; 
                $scope.myObject.push($scope.myObj);
            });
            $scope.loginDetails = data["nav-bar"]["login"];
            $scope.loginDetails["forgot-username-url"] = $scope.GUEST_URL+"/#"+$scope.loginDetails["forgot-username-url"];
            $scope.loginDetails["forgot-password-url"] = $scope.GUEST_URL+"/#"+$scope.loginDetails["forgot-password-url"];
            $scope.userNameInputObject.text = $scope.loginDetails["username-placeholder"];
            $scope.pwdInputObject.text = $scope.loginDetails["password-placeholder"];
        });
        /*$scope.$on("INPUT_CHANGED",function(event,data){
            if(data.key == 'loginusername'){
                $scope.email = data.value;
            }
            if(data.key == 'loginpassword'){
                $scope.password = data.value;
            }   
        });*/
        // $scope.loginInputChanged = function(){
        //     $scope.email = $scope.userNameInputObject.value;
        //     $scope.password = $scope.pwdInputObject.value;
        //     debugger
        // }
        $scope.megamenus = $scope.myObject;
        $scope.getMenuName = function(obj){
                var value = "";
                obj = angular.copy(obj);
                angular.forEach(obj, function(property, key){
                    value = key;
                });
                return value;
        };

        $scope.searchtext = '';
        $scope.smartsolutionsData = [];
        $scope.fundsData = [];
        $scope.siteSearchFundRecords = [];
        $scope.fudIdList = {};
 
        $http.get($scope.MARKETING_URL+"/en-in-retail/investor/index.page?bid=india.smart-solutions").then(function (data){
            $scope.smartsolutionsData = data.data['links-list']['link'];
            angular.forEach($scope.smartsolutionsData,function(obj){
                obj.href = $scope.GUEST_URL+"/#"+obj.href;
            });
        }); 
    
        $http.get($scope.MARKETING_URL+"/en-in-retail/investor/index.page?bid=india.fund-nav-div-search-list").then(function (data){
            $scope.fundsData = data.data.globalProductsValue.navDetailsList;
            for(var i=0;i<$scope.fundsData.length;i++){
                var obj = {};
                obj.fundID = $scope.fundsData[i].fundID;
                obj.fundName = $scope.fundsData[i].fundName.val;
                obj.planType = $scope.fundsData[i].planType.alt;
                obj.searchType = 'funds';
                $scope.siteSearchFundRecords.push(obj);
            }
        });
 
        // //          START CODE FOR FROM LOCAL JSON    //
 
        // $http.get(constants.JSON_SERVICES+'/smartSolutionsSearch.json').then(function (data){
        //     $scope.smartsolutionsData = data.data['links-list']['link'];
        //     angular.forEach($scope.smartsolutionsData,function(obj){
        //         obj.href = $scope.GUEST_URL+"/#"+obj.href;
        //     });
        // });   
 
        // $http.get(constants.JSON_SERVICES+'/fundsDataSearch.json').then(function (data){
        //     $scope.fundsData = data.data.globalProductsValue.navDetailsList;
        //     for(var i=0;i<$scope.fundsData.length;i++){
        //         var obj = {};
        //         obj.fundID = $scope.fundsData[i].fundID;
        //         obj.fundName = $scope.fundsData[i].fundName.val;
        //         obj.planType = $scope.fundsData[i].planType.alt;
        //         obj.searchType = 'funds';
        //         $scope.siteSearchFundRecords.push(obj);
        //     }
        // });
        // $scope.filterFundData = function(){
        //     $scope.matchedFudData = [];
        //     $scope.filteredSmarts = [];
        //     $scope.fudIdList = {
        //       "result": {
        //         "fundid": 19810
        //       }
        //     };
 
        //     // angular.forEach($scope.fudIdList.result.fundid.split(','),function(obj1){
        //     //     angular.forEach($scope.siteSearchFundRecords,function(obj2){
        //     //         if(obj1==obj2.fundID){
        //     //             $scope.matchedFudData.push(obj2);
        //     //         }
        //     //     });
        //     // });
        //     if($scope.fudIdList.result){
        //         angular.forEach($scope.siteSearchFundRecords,function(obj1){
        //             angular.forEach($scope.fudIdList.result.fundid.toString().split(','),function(obj2){
        //                 if(obj1.fundID==obj2){
        //                     $scope.matchedFudData.push(obj1);
        //                 }
        //             });
        //         });
        //     }
        //     $scope.filteredSmarts = $filter('filter')($scope.smartsolutionsData, {
        //         "icon-class" : $scope.searchtext
        //     });
        // };
        // //       END CODE FOR FROM LOCAL JSON    //
 
        $scope.filterFundData = function(){
            $scope.matchedFudData = [];
            $scope.filteredSmarts = [];
            if($scope.searchtext.length>=3){
                $http.get($scope.MARKETING_URL+"/en-in-retail/investor/resources.page?bid=india.fund-search&query="+ $scope.searchtext).then(function (fundresult){
                    $scope.fudIdList = fundresult.data;
                    // angular.forEach($scope.fudIdList.result.fundid.split(','),function(obj1){
                    //     angular.forEach($scope.siteSearchFundRecords,function(obj2){
                    //        if(obj1==obj2.fundID){
                    //             $scope.matchedFudData.push(obj2);
                    //         }
                    //     });
                        if($scope.fudIdList.result){
                            angular.forEach($scope.siteSearchFundRecords,function(obj1){
                                angular.forEach($scope.fudIdList.result.fundid.toString().split(','),function(obj2){
                                    if(obj1.fundID==obj2){
                                        $scope.matchedFudData.push(obj1);
                                    }
                                });
                            });
                        }
                        $scope.filteredSmarts = $filter('filter')($scope.smartsolutionsData, {
                            "icon-class" : $scope.searchtext
                        });
                        // var fundmatched = $filter('filter')($scope.siteSearchFundRecords, { fundID: obj }, true);
                        // $scope.matchedFudData.push(fundmatched);
                    });
            }
        };
 
        $scope.highlight = function(text, search) {
            if (!search) {
                return $sce.trustAsHtml(text);
            }
            return $sce.trustAsHtml(text.replace(new RegExp(search, 'gi'), '<span class="highlightedText">$&</span>'));
        };
        $scope.navigateSearch = function(type,val){
            if(val == ''){
                if(angular.isObject(type)){
                    // var url = $scope.MARKETING_URL+"/en-in-retail/investor/mutual-funds/overview.page?" + "FundID=" + type.fundID;
                    var url = $scope.MARKETING_URL+"/en-in-retail/investor/funds-and-solutions/funds-explorer/fund-overview.page?" + "FundID=" + type.fundID;
                    $window.location.href = url;
                }else{
                    var url = $scope.MARKETING_URL+"/en-in-retail/investor/search.page?" + "query=" + $scope.searchtext + "&filter=" + type;
                    $window.location.href = url;
                }
            }else{
                $window.location.href = type.href;
            }
        };

        // $scope.navigateSearch = function(type){
        //     if(angular.isObject(type)){
        //         var url = $scope.MARKETING_URL+"/en-in-retail/investor/mutual-funds/overview.page?" + "FundID=" + type.fundID;
        //         $window.location.href = url;
        //     }else{
        //         var url = $scope.MARKETING_URL+"/en-in-retail/investor/search.page?" + "query=" + $scope.searchtext + "&filter=" + type;
        //         $window.location.href = url;
        //     }
        // };

        $scope.keyEntered = function(keyEvent) {
          if (keyEvent.which === 13){
            $scope.navigateSearch('all','');
          }
        };

        $scope.navigationToggle = function () {
                !function (n) {
                    function t() {
                        s.hasClass(f) && i.toggleClass(l)
                    }

                    function e() {
                        s.hasClass(f) && (i.addClass(l), s.animate({
                            left: "0px"
                        }, d), o.animate({
                            left: v
                        }, d), r.animate({
                            left: v
                        }, d))
                    }

                    function a() {
                        s.hasClass(f) && (i.removeClass(l), s.animate({
                            left: "-" + v
                        }, d), o.animate({
                            left: "0px"
                        }, d), r.animate({
                            left: "0px"
                        }, d))
                    }

                    var s = n(".fti-nav-container"),
                        i = n("body"),
                        o = n("#fti-wrapper"),
                        r = n(".fti-nav-push"),
                        f = "fti-nav-left",
                        l = "fti-nav-open-left",
                        m = n(".fti-nav-overlay"),
                        c = n(".menu-btn, .fti-nav-link"),
                        d = 200,
                        v = s.width() + "px",
                        u = function () {
                            var n = document.createElement("p"),
                                t = !1,
                                e = {
                                    webkitTransform: "-webkit-transform",
                                    OTransform: "-o-transform",
                                    msTransform: "-ms-transform",
                                    MozTransform: "-moz-transform",
                                    transform: "transform"
                                };
                            document.body.insertBefore(n, null);
                            for (var a in e) void 0 !== n.style[a] && (n.style[a] = "translate3d(1px,1px,1px)", t = window.getComputedStyle(n).getPropertyValue(e[a]));
                            return document.body.removeChild(n), void 0 !== t && t.length > 0 && "none" !== t
                        }();
                    if (u) s.css({
                        visibility: "visible"
                    }), c.on("click", function () {
                        t()
                    }), m.on("click", function () {
                        t()
                    });
                    else {
                        i.addClass("no-csstransforms3d"), s.hasClass(f) && s.css({
                            left: "-" + v
                        }), s.css({
                            visibility: "visible"
                        }), o.css({
                            "overflow-x": "hidden"
                        });
                        var p = !1;
                        c.on("click", function () {
                            p ? (a(), p = !1) : (e(), p = !0)
                        }), m.on("click", function () {
                            p ? (a(), p = !1) : (e(), p = !0)
                        })
                    }
            }(jQuery);
    };
    $scope.navigationToggle();
    
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.

headerCtrl.$inject = ['fticMenuModel', 'globalMenuInitLoader', '$scope', '$localStorage', '$state', '$http', 'headerConstants', 'constants', 'events', 'eventConstants', '$timeout', 'appConfig', 'configUrlModel', '$window', '$cookies', '$filter', '$sce'];
module.exports = headerCtrl;