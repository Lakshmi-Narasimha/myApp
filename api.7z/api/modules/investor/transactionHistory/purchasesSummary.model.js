// purchasesSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var PurchasesSummarySchema = new mongoose.Schema({
    purchasesSummaryDetails: {
        type: Array,
        'default': []
    }
});

var PurchasesSummaryLookUp = mongoose.model('PurchasesSummaryLookUp', PurchasesSummarySchema);

var PurchasesSummary = new PurchasesSummaryLookUp({
    'purchasesSummaryDetails': {
        "invTrxnSummary": [{
            "folioId": "17259162",
            "modeofHolding": "joint",
            "holders": {
                "firstHoldersName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
                "secondHoldersName": "Kishan ram kiran",
                "thirdHoldersName": " "
            },
            "rows": [{
                "accountNo": "0029903636631",
                "amount": "35,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "No",
                "fundDesc": "Franklin India Prima Plus - Dividend",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }]
        }, {
            "folioId": "17024206",
            "modeofHolding": "joint",
            "holders": {
                "firstHoldersName": "AASHISH SADANAND NARKAR NARYAN SHANTA",
                "secondHoldersName": "Kishan ram kiran",
                "thirdHoldersName": " "
            },
            "rows": [{
                "accountNo": "0069903636631",
                "amount": "20,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "Yes",
                "fundDesc": "Franklin India Bluechip Fund - Dividend",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }, {
                "accountNo": "0359903636631",
                "amount": "149,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "Yes",
                "fundDesc": "Franklin India Taxshield - Dividend",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }, {
                "accountNo": "3049903636631",
                "amount": "110,000.00",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "No",
                "fundDesc": "Franklin Asian Equity Fund - Growth",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "",
                "ucFundDesc": "",
                "ucUnits": ""
            }]
        }]
    }

});

PurchasesSummaryLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating PurchasesSummaryLookUp table, please contact admin...');
    } else {
        PurchasesSummaryLookUp.remove({}, function(err) {
            console.log('PurchasesSummaryLookUp collection removed' + err);
            PurchasesSummary.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PurchasesSummaryLookUp table, please contact admin...');
                }
                console.log('PurchasesSummaryLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PurchasesSummaryLookUp;
