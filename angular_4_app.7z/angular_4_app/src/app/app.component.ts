import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params, RoutesRecognized } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  id: any;
  private envList = [{ id: 1, name: 'ENV1' }, { id: 2, name: 'ENV2' }, { id: 3, name: 'ENV3' }];
  constructor(private route: ActivatedRoute, private router: Router) {
  }
  ngOnInit(): void {
    this.router.events.subscribe(val => {
      if (val instanceof RoutesRecognized) {
        this.id = val.state.root.firstChild.params.id;
      }
    });
  }
}
