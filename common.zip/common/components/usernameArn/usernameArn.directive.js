/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var usernameArnDetails = function($timeout,constants,advisorRegistrationModelService,$filter) {
	return {
            template: require('./usernameArn.html'),
            restrict: 'E',
            replace: true,
            scope: {
                formObj:'='
            },
            controller:['$scope', function($scope){
                $scope.dateOptions = {
                    yearRows: 4,
                    yearColumns: 3,
                    fulldatepickerMode:'year',
                    formatMonth: 'MMM',
                    formatYear: 'yyyy',
                    formatDayTitle: 'MMM yyyy',
                    datepickerMode: 'day',
                    startingDay:0,
                    showWeeks: false
                }
                $scope.formData={};
                $scope.usernameArnObject = {
                        key : 'username',
                        text : 'Username',
                        value : '',
                        name : 'username',
                        isRequired: true,
                        type: 'text'
                       }; 
               $scope.$on('usrNamesubmitted',function(event){
                $scope.formData.userId=$scope.usernameArnObject.value;
                $scope.formData.dobOrRegDate =$filter('date')($scope.arnRegistrationDate, "dd/MM/yyyy");
                /*$scope.formData.regType = "Adviser";*/
                advisorRegistrationModelService.setUNameData($scope.formData);
              });

            }]
        };
};

usernameArnDetails.$inject = ['$timeout','constants','advisorRegistrationModelService','$filter'];
module.exports = usernameArnDetails;