/**
 * @ngdoc directive
 * @name otpVerificationForm
 * 
 * @description
 *
 * - It will verify the user with OTP that sent to registered mobile of the user
 **/
'use strict';

var otpVerificationForm = function($state, transactModel, stpDetailsModel, reviewSwpDetailsModel, redeemModel, switchDtlsToReviewModel, sipDetailsModel, bankDtlsModel, fundDetails, SipModifyDetailModel, otpVerificationModelGuest, authenticationService, $cookies, toaster, TransactConstant, $filter,ifscModel, investorRegistrationModel, fticStateChange) {

    return {
        template: require('./otpVerification.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function($scope) { 

            $scope.panObject = {
                key: TransactConstant.investorleg.AADHAR,
                text: TransactConstant.investorleg.AADHAR,
                value: '',
                type: "text",
                isRequired: true
            };
            $scope.otpObject = {
                key: TransactConstant.investorleg.OTP,
                text: TransactConstant.investorleg.OTP,
                value: '',
                isRequired: true
            };
            $scope.verifyDetails = {
                heading: TransactConstant.investorleg.HEADING
            };
            $scope.msgObjects = [/*{
                text: TransactConstant.investorleg.SUCCESSFULLY_AUTHENTICATED,
                image: TransactConstant.investorleg.IMG_SOURCE
            },*/ {
                text: TransactConstant.investorleg.OTP_SENT,
                image: TransactConstant.investorleg.IMG_SOURCE
            }];

            $scope.submitOTP = function($event) {
                $event.preventDefault();
                $event.stopPropagation();

                // As suggested by FT service team changing the flag to A in all cases.
                var requestObject = {
                    folioPanAccNo: $scope.panObject.value,
                    folioPanFlag: "A", 
                    guId: transactModel.getValidateWebRefResponse().guId, //"someGUID",
                    otp: $scope.otpObject.value,
                   // emailId: transactModel.getValidateWebRefResponse().emailId,
                    webRefNo: transactModel.getWebRefNo()
                };
                if (!$scope.panObject.value) {
                    toaster.error(TransactConstant.investorleg.ENTER_AADHAR);
                }
                if (!$scope.otpObject.value) {
                    toaster.error(TransactConstant.investorleg.ENTER_OTP);
                }
                if ($scope.otpVerificationForm.$valid) {
                    var postOTPSuccess = function(successResp) {

                        if(successResp.isFolioValidated == 'false'){
                            $scope.getTxnDetails();
                           toaster.error("The OTP entered is incorrect, Select resend button for resending the OTP");   
                        }else{
                            $scope.getTxnDetails();
                        }
                        
                    }; 
                    var postOTPFailure = function(errorResp) {
                        $scope.getTxnDetails();                                                  
                        toaster.error(errorResp.data[0].errorDescription);
                    };
                    otpVerificationModelGuest.validateOtp(requestObject).then(postOTPSuccess, postOTPFailure);
                }
            };

            $scope.generateAndSendOTP = function() {

                var requestObject = {
                    mobileNo: transactModel.getValidateWebRefResponse().mobile,
                    emailId: transactModel.getValidateWebRefResponse().emailId,
                    guId: transactModel.getValidateWebRefResponse().guId
                };
                var postGenerateOTPSuccess = function(successResp) {
                    toaster.success('Your OTP has been resent successfully');
                };
                var postGenerateOTPFailure = function(errorResp) {
                    toaster.error(errorResp.data[0].errorDescription);
                };
                otpVerificationModelGuest.generateAndSendOTP(requestObject).then(postGenerateOTPSuccess, postGenerateOTPFailure);
            }


            $scope.txnDetailsResponseObject = {};
            $scope.getTxnDetails = function() {
                $scope.webRefNo = {
                    webRefNo: transactModel.getWebRefNo(),
                    guId: transactModel.getValidateWebRefResponse().guId
                };

                //postTxnSuccess(some);
                //function postTxnSuccess(data){

                var postTxnSuccess = function(data) {
                    
                    $scope.txnDetailsResponseObject = data;

                    if($scope.txnDetailsResponseObject.isRIA === "YES" || $scope.txnDetailsResponseObject.isRIA === "Yes"){
                        transactModel.setIsRIAUser(true);
                    }

                    var loadReviewDetails = function() {

                        var authobj = authenticationService.getUser()
                        authobj.userType = $scope.txnDetailsResponseObject.source;
                        authenticationService.setUser(authobj);

                        var firstHolderKycRegistered = false,
                            secondHolderKycRegistered = false,
                            thirdHolderKycRegistered = false,
                            goToreviewFlow = false;

                        var holdersInfo = $scope.txnDetailsResponseObject.customerInfoVo;
                        //to be removed starts...
                        //holdersInfo.firstHolderName = "asdkjhkj";
                        //holdersInfo.firstHolderKycStatus = "dfdg"
                        //holdersInfo.secondHolderName = "asdkjhkj";
                        //holdersInfo.secondHolderKycStatus = "juhh";
                        //holdersInfo.thirdHolderName = "sdfsf";
                        //holdersInfo.thirdHolderKycStatus = "juhh";
                        //to be removed ends...

                        if (holdersInfo.holdingType == "Single") { 
                            if ((holdersInfo.firstHolderName != " " || holdersInfo.firstHolderName != "") && holdersInfo.firstHolderKycStatus === "KYC - Registered") {
                                firstHolderKycRegistered = true;
                                goToreviewFlow = true;
                            } 
                        } else { 

                            if (holdersInfo.firstHolderName != "" && holdersInfo.firstHolderKycStatus === "KYC - Registered"){
                                firstHolderKycRegistered = true;
                            } 
                            if ((holdersInfo.secondHolderName != "" && holdersInfo.secondHolderKycStatus === "KYC - Registered") || holdersInfo.secondHolderName ==='') {
                                secondHolderKycRegistered = true;
                            }
                            if ((holdersInfo.thirdHolderName != "" && holdersInfo.thirdHolderKycStatus === "KYC - Registered") || holdersInfo.thirdHolderName ==='') {
                                thirdHolderKycRegistered = true;
                            }
                            if (firstHolderKycRegistered && secondHolderKycRegistered && thirdHolderKycRegistered) {
                                   goToreviewFlow = true; 

                            } else {
                                goToreviewFlow = false;
                            }

                        }                                         
                        var investorDetails = {
                            "holders": [{
                                    "aadhar": $scope.txnDetailsResponseObject.customerInfoVo.firstHolderAadhaar,
                                    "pan": $scope.txnDetailsResponseObject.customerInfoVo.firstHolderPanNo,
                                    "kycregistered": holdersInfo.firstHolderKycStatus,
                                    "type": "Firstholder",
                                    "name": $scope.txnDetailsResponseObject.customerInfoVo.firstHolderName
                                },

                                {
                                    "aadhar": $scope.txnDetailsResponseObject.customerInfoVo.secondHolderAadhaar,
                                    "pan": $scope.txnDetailsResponseObject.customerInfoVo.secondHolderPanNo,
                                    "kycregistered": holdersInfo.secondHolderKycStatus,
                                    "type": "secondholder",
                                    "name": $scope.txnDetailsResponseObject.customerInfoVo.secondHolderName
                                },

                                {
                                    "aadhar": $scope.txnDetailsResponseObject.customerInfoVo.thirdHolderAadhaar,
                                    "pan": $scope.txnDetailsResponseObject.customerInfoVo.thirdHolderPanNo,
                                    "kycregistered": holdersInfo.thirdHolderKycStatus,
                                    "type": "thirdholder",
                                    "name": $scope.txnDetailsResponseObject.customerInfoVo.thirdHolderName
                                }
                            ],
                            "city": $scope.txnDetailsResponseObject.customerInfoVo.city,
                            "email": $scope.txnDetailsResponseObject.customerInfoVo.email,
                            "mobile": $scope.txnDetailsResponseObject.customerInfoVo.mobile,
                            "holdingType": $scope.txnDetailsResponseObject.customerInfoVo.holdingType,
                            "folioId": $scope.txnDetailsResponseObject.folioId,
                            "aadhar": $scope.txnDetailsResponseObject.aadhaar,
                            "pan": $scope.txnDetailsResponseObject.customerInfoVo.firstHolderPanNo,
                            "custName": $scope.txnDetailsResponseObject.customerInfoVo.custName,
                            "$$hashKey": "uiGrid-000C",
                            "type": $scope.txnDetailsResponseObject.customerInfoVo.holdingType,
                            "userType": $scope.txnDetailsResponseObject.customerInfoVo.socialStatus,
                            "distId": "",
                            "customerInfoVo": $scope.txnDetailsResponseObject.customerInfoVo,
                            "subBrokerArn": $scope.txnDetailsResponseObject.subBrokerArn,
                            "euin": $scope.txnDetailsResponseObject.euin,
                            "renewal_flag": $scope.txnDetailsResponseObject.renewal_flag,
                            "euin_flag": $scope.txnDetailsResponseObject.euin_flag,
                            "urn_no": $scope.txnDetailsResponseObject.urn_no,
                            "umrn_no":$scope.txnDetailsResponseObject.umrn_no,
                            "txn_no": $scope.txnDetailsResponseObject.txn_no,
                            "batch_code": $scope.txnDetailsResponseObject.batch_code,
                            "source": $scope.txnDetailsResponseObject.source,
                            "transaction_flag": $scope.txnDetailsResponseObject.transaction_flag,
                            "branch_code": $scope.txnDetailsResponseObject.branch_code,
                            "start_date": $scope.txnDetailsResponseObject.start_date,
                            "end_date": $scope.txnDetailsResponseObject.end_date,
                            "frequency": $scope.txnDetailsResponseObject.frequency
                        };                        

                        $scope.init = function() {
                            var data = {}
                            $scope.showError = false;
                            transactModel.setInvestorDetails(data); //making investor details data null                             
                            transactModel.setFundDetails(data); //making fund details data null
                            transactModel.setIsInvestorLeg('INVESTORLEG');
                        };

                        $scope.init();

                        transactModel.setInvestorDetails(investorDetails); // setting investor details which is common for all type of transactions                        

                        //if ($scope.txnDetailsResponseObject.customerInfoVo.firstHolderKycStatus != "KYC - Registered" || $scope.txnDetailsResponseObject.customerInfoVo.secondHolderKycStatus != "KYC - Registered" || $scope.txnDetailsResponseObject.customerInfoVo.thirdHolderKycStatus != "KYC - Registered") {

                
                        /*if(goToreviewFlow == false){
                            //redirect to verify unit holder details page.
                            $state.go('txnmaster.verifydetails.unitholderDetails');
                        } else {*/
                            var paymentMode = angular.copy($scope.txnDetailsResponseObject.paymentOption),
                                newInvestor = ($scope.txnDetailsResponseObject.mf_code) ? true : false;
                                
                            transactModel.setIsNewFolio(newInvestor);
                            bankDtlsModel.setIfscCode($scope.txnDetailsResponseObject.ifscCode);                            
                            bankDtlsModel.setPaymentMode(paymentMode);
                            
                            investorRegistrationModel.setNewInvestorFolioId($scope.txnDetailsResponseObject.folioId);
                           // bankDtlsModel.setBranchName($scope.txnDetailsResponseObject.);
                          //  bankDtlsModel.setBranchAddress($scope.txnDetailsResponseObject.);
 

                          if($scope.txnDetailsResponseObject.paymentOption === 'Z' && $scope.txnDetailsResponseObject.umrn_no!=''){
                              $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.EXISTING_PAY_MANDATE;
                          } else {
                             switch ($scope.txnDetailsResponseObject.paymentOption) {

                                case TransactConstant.common.NET_BANKING_CODE:

                                    $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.NET_BANKING
                                    break;

                                case TransactConstant.common.DEBIT_CARD_CODE:
                                    $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.DEBIT_CARD
                                    break;

                                case TransactConstant.common.EMANDATE_CODE:
                                    $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.SETUP_NEW_MANDATE
                                    break;

                                case TransactConstant.common.BILL_PAY_CODE:
                                    $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.BILL_PAY
                                    break;

                                case TransactConstant.common.NEFT_CODE:
                                    $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.NEFT_RTGS
                                    break;

                                case TransactConstant.common.AUTO_DEBIT_CODE:
                                    $scope.txnDetailsResponseObject.paymentOption = TransactConstant.transact.AUTO_DEBIT
                                    break;
                                default:
                                    break;
                            }
                          }
                           
                            bankDtlsModel.setPaymentMethod($scope.txnDetailsResponseObject.paymentOption);
                            fundDetails.removeFundDetails();
                            angular.forEach($scope.txnDetailsResponseObject.fundOptions, function(obj, ind) {
                                if($scope.txnDetailsResponseObject.txn_source == TransactConstant.investorleg.SIP){
                                    obj.futureDate = $scope.txnDetailsResponseObject.fundOptions[ind].startDate;
                                    obj.startDate = $scope.txnDetailsResponseObject.trxn_requested_date.split(" ")[0];                                    
                                    fundDetails.setFundDetails(obj);
                                }else{
                                    fundDetails.setFundDetails(obj);
                                }                                                            
                            })

                            // fundDetails.setFundDetails($scope.txnDetailsResponseObject.fundOptions);

                            //redirect to the specific type transaction page.
                            var emptydata = {},
                                reqObjParams = {};
                            var date = ($scope.txnDetailsResponseObject.trxn_requested_date).split(" ");
                            var time = $scope.txnDetailsResponseObject.trxn_requested_time;
                            var dateAndTime = date[0] + ' ' + time;
                            transactModel.setTxnDateAndTime(dateAndTime);
                            bankDtlsModel.setEmAmount($scope.txnDetailsResponseObject.emandateAmount);
                            bankDtlsModel.setUntilCancelled($scope.txnDetailsResponseObject.untillCancel);

                            var splited_bank_Details = $scope.txnDetailsResponseObject.customerInfoVo.bankdetails.split("/");                            
                            var bankObj = {}
                            bankObj.ifscCode = $scope.txnDetailsResponseObject.ifscCode;
                            bankObj.bankDetails = splited_bank_Details[2];
                            bankObj.bnkAdd = splited_bank_Details[3];
                            ifscModel.setIfscGridResDet(bankObj); 
                            //$scope.$emit('ifscSrchRes'); 
                            //$scope.$broadcast('ifscSrchRes'); 

                            switch ($scope.txnDetailsResponseObject.txn_source) {

                                case TransactConstant.investorleg.SIP:

                                    //redirect to the SIP transaction page.
                                    //transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions);
                                    
                                    var SIPstartDate = ($scope.txnDetailsResponseObject.trxn_requested_date).split(" ")[0];
                                    for (var i = 0; i < $scope.txnDetailsResponseObject.fundOptions.length; i++) {
                                        var srtDate = "";
                                        srtDate = $scope.txnDetailsResponseObject.fundOptions[i].futureDate;
                                        $scope.txnDetailsResponseObject.fundOptions[i].futureDate = $filter('date')(srtDate, "dd/MM/yyyy");
                                        $scope.txnDetailsResponseObject.fundOptions[i].startDate = $filter('date')(SIPstartDate, "dd/MM/yyyy");
                                        $scope.txnDetailsResponseObject.fundOptions[i].endDate = $filter('date')($scope.txnDetailsResponseObject.fundOptions[i].endDate, "dd/MM/yyyy");     
                                    }
                                    var multiplemode = false;
                                    if($scope.txnDetailsResponseObject.nextPaymentMode === 'O' || $scope.txnDetailsResponseObject.nextPaymentMode === 'M'){
                                        multiplemode = true;
                                        if($scope.txnDetailsResponseObject.nextPaymentMode === 'O'){
                                            bankDtlsModel.setFutureInstPayMethod(TransactConstant.transact.BILL_PAY);
                                            bankDtlsModel.setNextPaymentMode(TransactConstant.common.BILL_PAY_CODE);  
                                        }else if($scope.txnDetailsResponseObject.nextPaymentMode === 'M'){
                                            bankDtlsModel.setFutureInstPayMethod(TransactConstant.transact.AUTO_DEBIT) 
                                            bankDtlsModel.setNextPaymentMode(TransactConstant.common.AUTO_DEBIT_CODE);
                                        }
                                        
                                    } 
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions);
                                    //fundDetails.setFundDetails($scope.txnDetailsResponseObject.fundOptions[0]);                                    
                                    bankDtlsModel.setIsMultiPayMode(multiplemode)
                                    transactModel.setTotalFundDetails($scope.txnDetailsResponseObject.fundOptions);
                                    sipDetailsModel.setSipDetails(emptydata); //making SIP details model data null                                  
                                    bankDtlsModel.setSelectedBank($scope.txnDetailsResponseObject.invPaymentBank + '-' + $scope.txnDetailsResponseObject.paymentBankAccNo);                                    
                                    bankDtlsModel.setBankDetails($scope.txnDetailsResponseObject.invPaymentBank);
                                    bankDtlsModel.setTotalAmount($scope.txnDetailsResponseObject.invAmount);
                                    transactModel.setTransactType('SIP');
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    bankDtlsModel.setAccountType($scope.txnDetailsResponseObject.accountType);
                                    bankDtlsModel.setBankAccNumber($scope.txnDetailsResponseObject.paymentBankAccNo);
                                    bankDtlsModel.setBankName($scope.txnDetailsResponseObject.invPaymentBank);
                                    bankDtlsModel.setAccountNo($scope.txnDetailsResponseObject.paymentBankAccNo);
                                    bankDtlsModel.setAchRefNo($scope.txnDetailsResponseObject.invAmount);
                                    bankDtlsModel.setDistId($scope.txnDetailsResponseObject.brokerCode);
                                    bankDtlsModel.setStartDate($scope.txnDetailsResponseObject.emandateFromdate);
                                    bankDtlsModel.setEndDate($scope.txnDetailsResponseObject.emandateTodate);
                                    //bankDtlsModel.setFrequency($scope.txnDetailsResponseObject.emandateFrequency);
                                    if($scope.txnDetailsResponseObject.emandateFrequency === 'A') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.AS_AND_WHEN);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'M') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.MNTHLY);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'Q') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.QUATERLY);
                                    };
                                    //bankDtlsModel.setAmountType($scope.txnDetailsResponseObject.emandateDebitType);  
                                    if($scope.txnDetailsResponseObject.emandateDebitType === 'U') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.MAXIMUM);
                                    } else if($scope.txnDetailsResponseObject.emandateDebitType === 'F') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.FIXED);
                                    };

                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsSIP');
                                    if(goToreviewFlow === false){
                                        //redirect to verify unit holder details page.
                                        fticStateChange.stateChange($state, 'txnmaster.verifydetails.unitholderDetails');
                                        //$state.go('txnmaster.verifydetails.unitholderDetails');
                                    } else {
                                        fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsSIP', {
                                            key: TransactConstant.transact.Payment_Key,
                                            from: 'INVESTORLEG'
                                        });
                                        /*$state.go('txnmaster.review.reviewDetailsSIP', {
                                            key: TransactConstant.transact.Payment_Key,
                                            from: 'INVESTORLEG'
                                        });*/
                                    }

                                    reqObjParams = {
                                        "paymentMode" : paymentMode,
                                        "bankName" : bankDtlsModel.getBankName(),
                                        "webRefNo" : transactModel.getWebRefNo(),
                                        "fundOptions" : fundDetails.getFundDetails(),
                                        "bankAccountNumber" : bankDtlsModel.getBankAccNumber(),
                                        "folioId" : transactModel.getInvestorDetails().folioId,
                                        "emFromDate" : bankDtlsModel.getStartDate(),
                                        "emToDate" : bankDtlsModel.getEndDate(),
                                        "emFrequency" : bankDtlsModel.getFrequency(),
                                        "debitType" : bankDtlsModel.getAmountType()
                                    };

                                    transactModel.setSipReqParams(reqObjParams);
                                    break;

                                case TransactConstant.investorleg.SWP:
                                    //redirect to the SWP transaction page.
                                    $scope.txnDetailsResponseObject.fundOptions[0].tschvalAccno = $scope.txnDetailsResponseObject.fundOptions[0].accNo;                                   
                                    $scope.txnDetailsResponseObject.fundOptions[0].minSwpAmount = $scope.txnDetailsResponseObject.fundOptions[0].minSWPAmt;
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions[0]);
                                    reviewSwpDetailsModel.setReviewSwpObj(emptydata); //making SWP model data null

                                    var freq;
                                    var amount_type;

                                    if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "D") {
                                        freq = TransactConstant.investorleg.DAILY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "W") {
                                        freq = TransactConstant.investorleg.WEEKLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "M") {
                                        freq = TransactConstant.investorleg.MONTHLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "Q") {
                                        freq = TransactConstant.investorleg.QUARTERLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "A" || $scope.txnDetailsResponseObject.fundOptions[0].frequency == "Y") {
                                        freq = TransactConstant.investorleg.ANNUALLY
                                    }

                                    if ($scope.txnDetailsResponseObject.all_units_flag == "Y") {
                                        amount_type = TransactConstant.investorleg.CAPITAL
                                    } else if ($scope.txnDetailsResponseObject.all_units_flag == "P") {
                                        amount_type = TransactConstant.investorleg.FIXED
                                    }

                                    var branch1 = $scope.txnDetailsResponseObject.customerInfoVo.bankdetails.split('/');
                                    var payment_selection = "";
                                    if($scope.txnDetailsResponseObject.paymentOption == "DC"){
                                        payment_selection = TransactConstant.investorleg.DIRECT_CREDIT
                                    }else if($scope.txnDetailsResponseObject.paymentOption == "Q"){
                                        payment_selection = TransactConstant.investorleg.CHEQUE
                                    }                                                                 

                                    var swpDetails = {
                                        "isEditSWP": true,
                                        "amountType": amount_type,
                                        "selectedType":amount_type,
                                        //"amountType":"fixed",                                
                                        //"amountType":"capital",
                                        "bankDetails": branch1[1] ? (branch1[1] + ' - ' + branch1[0]) : 'NA',
                                        //"selectedMode": "cheque",
                                        "selectedMode": payment_selection,
                                        "startDate": $scope.txnDetailsResponseObject.fundOptions[0].startDate,
                                        "endDate": $scope.txnDetailsResponseObject.fundOptions[0].endDate,
                                        "frequency": freq,
                                        "fundOption": $scope.txnDetailsResponseObject.fundOptions[0].fundOption,
                                        "swpAmtValue": $scope.txnDetailsResponseObject.fundOptions[0].amount,
                                        "fundAccNo":$scope.txnDetailsResponseObject.fundOptions[0].accNo,
                                        "noofInstallments": $scope.txnDetailsResponseObject.no_of_installments,
                                        "city": $scope.txnDetailsResponseObject.customerInfoVo.city,
                                        "branch": branch1[2],
                                        "webRefno": $scope.txnDetailsResponseObject.web_refno,
                                        "all_units_flag": $scope.txnDetailsResponseObject.all_units_flag,
                                        "amount_unit_flag": $scope.txnDetailsResponseObject.amount_unit_flag,
                                        "dividend_option": $scope.txnDetailsResponseObject.dividend_option,
                                        "urn_no": $scope.txnDetailsResponseObject.urn_no,
                                        "lbd_flag": $scope.txnDetailsResponseObject.lbd_flag,
                                        "source": $scope.txnDetailsResponseObject.source,
                                        "umrn_no": $scope.txnDetailsResponseObject.umrn_no,
                                        "subBrokerARN": $scope.txnDetailsResponseObject.subBrokerARN,
                                        "branch_code": $scope.txnDetailsResponseObject.branch_code,
                                        "txn_source": $scope.txnDetailsResponseObject.txn_source,
                                        "trxn_units": $scope.txnDetailsResponseObject.trxn_units,
                                        "batchCode": $scope.txnDetailsResponseObject.batch_code,
                                        "ifscCode": $scope.txnDetailsResponseObject.ifscCode,
                                        "paymentMode" : $scope.txnDetailsResponseObject.paymentMode
                                    }

                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    transactModel.setTxnDate($scope.txnDetailsResponseObject.trxn_requested_date);

                                    reviewSwpDetailsModel.setReviewSwpObj(swpDetails); 
                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsSWP');
                                    
                                    //$state.go('txnmaster.review.reviewDetailsSWP');
                                    fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsSWP', {
                                        key: "INVESTORSWP",
                                        from: 'INVESTORLEG'
                                    });
                                    /*$state.go('txnmaster.review.reviewDetailsSWP', {
                                        key: "INVESTORSWP",
                                        from: 'INVESTORLEG'
                                    });*/ 

                                    break;

                                case TransactConstant.investorleg.STP:
                                    //redirect to the STP transaction page.
                                    $scope.txnDetailsResponseObject.fundOptions[0].tschvalAccno = $scope.txnDetailsResponseObject.fundOptions[0].accNo;
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions[0]);
                                    stpDetailsModel.setStpDetails(emptydata); //making STP details model data null

                                    //Frequency M represents Monthly, Y\A for Annually and Q for Quarterly
                                    var freq;
                                    if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "D") {
                                        freq = TransactConstant.investorleg.DAILY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "W") {
                                        freq = TransactConstant.investorleg.WEEKLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "M") {
                                        freq = TransactConstant.investorleg.MONTHLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "Q") {
                                        freq = TransactConstant.investorleg.QUARTERLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "A" || $scope.txnDetailsResponseObject.fundOptions[0].frequency == "Y") {
                                        freq = TransactConstant.investorleg.ANNUALLY
                                    }
                                    var stpDetails = {

                                        "destinationFund": $scope.txnDetailsResponseObject.destinationFundDesc || 'NA',
                                        "stpAmount": $scope.txnDetailsResponseObject.fundOptions[0].amount,
                                        "frequency": freq,
                                        "stpStartDate": $scope.txnDetailsResponseObject.fundOptions[0].startDate,
                                        "stpEndDate": $scope.txnDetailsResponseObject.fundOptions[0].endDate,
                                        "noofInstallments": $scope.txnDetailsResponseObject.no_of_installments,
                                        "accountNo": $scope.txnDetailsResponseObject.account_number,
                                        "webRefno": $scope.txnDetailsResponseObject.web_refno,
                                        "batchCode": $scope.txnDetailsResponseObject.batch_code,
                                        "units": $scope.txnDetailsResponseObject.trxn_units,
                                        "dividendOption": $scope.txnDetailsResponseObject.fundOptions[0].dividendFlag,
                                        "amountUnitFlag": $scope.txnDetailsResponseObject.amount_unit_flag,
                                        "urnNo": $scope.txnDetailsResponseObject.urn_no, 
                                        "source": $scope.txnDetailsResponseObject.source,
                                        "umrnNo": $scope.txnDetailsResponseObject.umrn_no,
                                        "destinationFundOption": $scope.txnDetailsResponseObject.destination_fund_option,
                                        "destinationAccountNumber": $scope.txnDetailsResponseObject.destination_account_number,
                                        "euin": $scope.txnDetailsResponseObject.euin,
                                        "subBrokerARN": $scope.txnDetailsResponseObject.subBrokerARN,
                                        "branchCode": $scope.txnDetailsResponseObject.branch_code,
                                        "subDistributorId": $scope.txnDetailsResponseObject.sub_distributor_id
                                    }
                                    var date = ($scope.txnDetailsResponseObject.trxn_requested_date).split(" ");
                                    var time = $scope.txnDetailsResponseObject.trxn_requested_time;
                                    var dateAndTime = date[0] + ' ' + time;
                                    transactModel.setTxnDateAndTime(dateAndTime);
                                    stpDetailsModel.setStpDetails(stpDetails);
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    bankDtlsModel.setStartDate($scope.txnDetailsResponseObject.emandateFromdate);
                                    bankDtlsModel.setEndDate($scope.txnDetailsResponseObject.emandateTodate);
                                    //bankDtlsModel.setFrequency($scope.txnDetailsResponseObject.emandateFrequency);
                                    if($scope.txnDetailsResponseObject.emandateFrequency === 'A') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.AS_AND_WHEN);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'M') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.MNTHLY);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'Q') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.QUATERLY);
                                    };
                                    //bankDtlsModel.setAmountType($scope.txnDetailsResponseObject.emandateDebitType);
                                    if($scope.txnDetailsResponseObject.emandateDebitType === 'U') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.MAXIMUM)
                                    } else if($scope.txnDetailsResponseObject.emandateDebitType === 'F') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.FIXED)
                                    };
                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsStp');
                                    
                                    fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsStp');
                                    //$state.go('txnmaster.review.reviewDetailsStp');                                    

                                    break; 

                                    // p for buy    
                                case TransactConstant.investorleg.TXN_SOURCE_P:
                                    // redirect to the BUY transaction page.
                                    //$scope.txnDetailsResponseObject.fundOptions[0].tschvalAccno = $scope.txnDetailsResponseObject.fundOptions[0].accNo;
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions);
                                    // fundDetails.setFundDetails($scope.txnDetailsResponseObject.fundOptions[0]);

                                    transactModel.setTotalFundDetails($scope.txnDetailsResponseObject.fundOptions);

                                    transactModel.setTransactType(TransactConstant.investorleg.BUY);

                                    bankDtlsModel.setSelectedBank($scope.txnDetailsResponseObject.invPaymentBank + '-' + $scope.txnDetailsResponseObject.paymentBankAccNo);
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    bankDtlsModel.setAccountType($scope.txnDetailsResponseObject.accountType);
                                    bankDtlsModel.setBankAccNumber($scope.txnDetailsResponseObject.paymentBankAccNo);                                    
                                    bankDtlsModel.setBankDetails($scope.txnDetailsResponseObject.invPaymentBank);
                                    bankDtlsModel.setBankName($scope.txnDetailsResponseObject.invPaymentBank);
                                    bankDtlsModel.setAccountNo($scope.txnDetailsResponseObject.paymentBankAccNo); 
                                    bankDtlsModel.setTotalAmount($scope.txnDetailsResponseObject.invAmount); 
                                    bankDtlsModel.setAchRefNo($scope.txnDetailsResponseObject.invAmount);
                                    //bankDtlsModel.setPaymentMode($scope.txnDetailsResponseObject.paymentOption);                          
                                    bankDtlsModel.setStartDate($scope.txnDetailsResponseObject.emandateFromdate);
                                    bankDtlsModel.setEndDate($scope.txnDetailsResponseObject.emandateTodate);
                                    //bankDtlsModel.setFrequency($scope.txnDetailsResponseObject.emandateFrequency);
                                    if($scope.txnDetailsResponseObject.emandateFrequency === 'A') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.AS_AND_WHEN);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'M') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.MNTHLY);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'Q') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.QUATERLY);
                                    };
                                    //bankDtlsModel.setAmountType($scope.txnDetailsResponseObject.emandateDebitType);
                                    if($scope.txnDetailsResponseObject.emandateDebitType === 'U') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.MAXIMUM)
                                    } else if($scope.txnDetailsResponseObject.emandateDebitType === 'F') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.FIXED)
                                    };
                                    var date = ($scope.txnDetailsResponseObject.trxn_requested_date).split(" ");
                                    var time = $scope.txnDetailsResponseObject.trxn_requested_time;
                                    var dateAndTime = date[0] + ' ' + time;
                                    transactModel.setTxnDateAndTime(dateAndTime);
                                    bankDtlsModel.setDistId($scope.txnDetailsResponseObject.brokerCode);

                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsBuy');
                                    if(goToreviewFlow === false){
                                        //redirect to verify unit holder details page.
                                        fticStateChange.stateChange($state, 'txnmaster.verifydetails.unitholderDetails');
                                        //$state.go('txnmaster.verifydetails.unitholderDetails');
                                    } else {
                                        fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsBuy', {
                                            key: TransactConstant.transact.Payment_Key,
                                            from: 'INVESTORLEG'
                                        });
                                        /*$state.go('txnmaster.review.reviewDetailsBuy', {
                                            key: TransactConstant.transact.Payment_Key,
                                            from: 'INVESTORLEG'
                                        });*/
                                    }

                                    reqObjParams = {
                                        "paymentMode" : paymentMode,
                                        "bankName" : bankDtlsModel.getBankName(),
                                        "webRefNo" : transactModel.getWebRefNo(),
                                        "fundOptions" : fundDetails.getFundDetails(),
                                        "bankAccountNumber" : bankDtlsModel.getBankAccNumber(),
                                        "folioId" : transactModel.getInvestorDetails().folioId,
                                        "emFromDate" : bankDtlsModel.getStartDate(),
                                        "emToDate" : bankDtlsModel.getEndDate(),
                                        "emFrequency" : bankDtlsModel.getFrequency(),
                                        "debitType" : bankDtlsModel.getAmountType()
                                    };
                                    transactModel.setBuyReqParams(reqObjParams);                                    
                                    break;

                                case TransactConstant.investorleg.TXN_SOURCE_S:
                                    //redirect to the SWITCH transaction page.

                                    $scope.txnDetailsResponseObject.fundOptions[0].tschvalAccno = $scope.txnDetailsResponseObject.fundOptions[0].accNo;
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions[0]);
                                    //transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions);
                                    switchDtlsToReviewModel.setDataObj(emptydata) // making switch details model data null

                                    var switchDetails = {
                                        "destinationFund": $scope.txnDetailsResponseObject.destinationFundDesc || 'NA',
                                        "switchType": $scope.txnDetailsResponseObject.all_units_flag,
                                        "amount": $scope.txnDetailsResponseObject.fundOptions[0].amount,
                                        "toAccount": $scope.txnDetailsResponseObject.destination_account_number,
                                        "toFundOption": $scope.txnDetailsResponseObject.destination_fund_option,
                                        //"dividendOption" :$scope.txnDetailsResponseObject.dividend_option,
                                        "dividendOption": $scope.txnDetailsResponseObject.fundOptions[0].dividendFlag,
                                        "subDist": $scope.txnDetailsResponseObject.sub_distributor_id,
                                        "subBrokerARN": $scope.txnDetailsResponseObject.subBrokerARN,
                                        "amountUnitFlag": $scope.txnDetailsResponseObject.amount_unit_flag,
                                        "txnType": $scope.txnDetailsResponseObject.trtype,
                                        "fundOption": $scope.txnDetailsResponseObject.fundOptions[0].fundOption,
                                        "units": $scope.txnDetailsResponseObject.trxn_units,
                                        "accNo": $scope.txnDetailsResponseObject.fundOptions[0].accNo
                                    }

                                    var date = ($scope.txnDetailsResponseObject.trxn_requested_date).split(" ");
                                    var time = $scope.txnDetailsResponseObject.trxn_requested_time;
                                    var dateAndTime = date[0] + ' ' + time;
                                    transactModel.setTxnDateAndTime(dateAndTime);

                                    switchDtlsToReviewModel.setDataObj(switchDetails)
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsSwitch');                                    
                                    fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsSwitch');
                                    //$state.go('txnmaster.review.reviewDetailsSwitch');                                    

                                    break;

                                case TransactConstant.investorleg.TXN_SOURCE_R:
                                    //redirect to the REDEEM transaction page.
                                    $scope.txnDetailsResponseObject.fundOptions[0].tschvalAccno = $scope.txnDetailsResponseObject.fundOptions[0].accNo;
                                    $scope.txnDetailsResponseObject.fundOptions[0].tschvalScheme = $scope.txnDetailsResponseObject.fundOptions[0].fundOption;
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions[0]);
                                    var redeemFullAmtUnitType;
                                    if ($scope.txnDetailsResponseObject.all_units_flag == "Y") {
                                        redeemFullAmtUnitType = TransactConstant.investorleg.FULL;
                                    } else if ($scope.txnDetailsResponseObject.all_units_flag == "P" || $scope.txnDetailsResponseObject.all_units_flag == "N") {
                                        if($scope.txnDetailsResponseObject.fundOptions[0].amount && $scope.txnDetailsResponseObject.fundOptions[0].amount !== ' '){
                                            redeemFullAmtUnitType = TransactConstant.investorleg.AMOUNT;
                                        }else if($scope.txnDetailsResponseObject.trxn_units){
                                            redeemFullAmtUnitType = TransactConstant.investorleg.UNIT; 
                                        }                                                                                                                        
                                    }
                                    var redeemPayMode = "";
                                    if($scope.txnDetailsResponseObject.paymentOption == "DC"){
                                        redeemPayMode = TransactConstant.investorleg.DIRECT_CREDIT
                                    }else if($scope.txnDetailsResponseObject.paymentOption == "Q"){
                                        redeemPayMode = TransactConstant.investorleg.CHEQUE
                                    }                                     

                                    //making Redeem model data null
                                    redeemModel.setType('');
                                    redeemModel.setAmount('');
                                    redeemModel.setUnits('');
                                    redeemModel.setBank('');
                                    redeemModel.setMode('');
                                    redeemModel.setSource('');
                                    redeemModel.setFolioAccNo('');
                                    redeemModel.setBatchCode('');

                                    var bankDetails1 = $scope.txnDetailsResponseObject.customerInfoVo.bankdetails
                                    var res = bankDetails1.split("/");
                                    var bankDetails2 = res[1] + ' - ' + res[0];
                                    var redeem_amount ='';
                                    var redeem_unit ='';
                                    if($scope.txnDetailsResponseObject.fundOptions[0].amount !== ' '){
                                        redeem_amount = Number($scope.txnDetailsResponseObject.fundOptions[0].amount);
                                    }
                                    if($scope.txnDetailsResponseObject.trxn_units && $scope.txnDetailsResponseObject.trxn_units !=='0'){
                                        redeem_unit = Number($scope.txnDetailsResponseObject.trxn_units);
                                    }
                                    redeemModel.setIsRedeemEdit(true);                    
                                    redeemModel.setBatchCode($scope.txnDetailsResponseObject.batch_code);
                                    redeemModel.setFolioAccNo($scope.txnDetailsResponseObject.fundOptions[0].accNo);
                                    redeemModel.setType(redeemFullAmtUnitType);
                                    redeemModel.setAmount(redeem_amount);
                                    redeemModel.setUnits(redeem_unit);
                                    redeemModel.setSource($scope.txnDetailsResponseObject.source);
                                    redeemModel.setBank($scope.txnDetailsResponseObject.invPaymentBank + ' - ' + $scope.txnDetailsResponseObject.paymentBankAccNo);
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    transactModel.setTxnDate($scope.txnDetailsResponseObject.trxn_requested_date);
                                    redeemModel.setMode(redeemPayMode);
                                    var date = ($scope.txnDetailsResponseObject.trxn_requested_date).split(" ");
                                    var time = $scope.txnDetailsResponseObject.trxn_requested_time;
                                    var dateAndTime = date[0] + ' ' + time;
                                    transactModel.setTxnDateAndTime(dateAndTime);
                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsRedeem');                                    
                                    fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsRedeem');
                                    //$state.go('txnmaster.review.reviewDetailsRedeem');                                    

                                    break;

                                case TransactConstant.investorleg.TXN_SOURCE_SIPSUP:
                                case TransactConstant.investorleg.TXN_SOURCE_SIPDTC:
                                case TransactConstant.investorleg.TXN_SOURCE_SIPFLX:
                                case TransactConstant.investorleg.TXN_SOURCE_SIPAMC:
                                case TransactConstant.investorleg.TXN_SOURCE_SIPPAS:
                                case TransactConstant.investorleg.TXN_SOURCE_SIPCAN:
                                case TransactConstant.investorleg.TXN_SOURCE_SIPSUC:

 
                                    var reqstdate = $scope.txnDetailsResponseObject.trxn_effective_date.split(" ");

                                    var splitreqstdate = reqstdate[0];
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    transactModel.setFundDetails($scope.txnDetailsResponseObject.fundOptions);
                                    for (var i = 0; i < $scope.txnDetailsResponseObject.fundOptions.length; i++) {
                                        $scope.txnDetailsResponseObject.fundOptions[i].startDate = $filter('date')(splitreqstdate, "dd/MM/yyyy");
                                        $scope.txnDetailsResponseObject.fundOptions[i].endDate = $filter('date')($scope.txnDetailsResponseObject.fundOptions[i].endDate, "dd/MM/yyyy");
                                        if ($scope.txnDetailsResponseObject.fundOptions[i].amount === "0") {
                                            $scope.txnDetailsResponseObject.fundOptions[i].amount = $scope.txnDetailsResponseObject.trxn_units;
                                        }
                                    }
                                    fundDetails.removeFundDetails();
                                    angular.forEach($scope.txnDetailsResponseObject.fundOptions, function(obj, ind) {
                                       obj.amount = $scope.txnDetailsResponseObject.trxn_units; 
                                       fundDetails.setFundDetails(obj);                                                         
                                    })

                                    var freq;
                                    if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "M") {
                                        freq = TransactConstant.investorleg.MONTHLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "Q") {
                                        freq = TransactConstant.investorleg.QUARTERLY
                                    } else if ($scope.txnDetailsResponseObject.fundOptions[0].frequency == "A" || $scope.txnDetailsResponseObject.fundOptions[0].frequency == "Y") {
                                        freq = TransactConstant.investorleg.ANNUALLY
                                    }
                                    var sipObj = {
                                        "accNo": $scope.txnDetailsResponseObject.fundOptions[0].accNo,
                                        "fund": $scope.txnDetailsResponseObject.fundOptions[0].fundOptDesc,
                                        "sipAmount": $scope.txnDetailsResponseObject.trxn_units,
                                        "startDate": $scope.txnDetailsResponseObject.fundOptions[0].startDate,
                                        "endDate": $scope.txnDetailsResponseObject.fundOptions[0].endDate,
                                        "frequency": freq,
                                        "branch_code": $scope.txnDetailsResponseObject.branch_code,
                                        "trxn_requested_date": $scope.txnDetailsResponseObject.trxn_requested_date,
                                        "trxn_requested_time": $scope.txnDetailsResponseObject.trxn_requested_time,
                                        "txn_source": $scope.txnDetailsResponseObject.txn_source,
                                        "batch_code": $scope.txnDetailsResponseObject.batch_code,
                                        "paymentBankAccNo": $scope.txnDetailsResponseObject.paymentBankAccNo,
                                        "bankName": $scope.txnDetailsResponseObject.invPaymentBank,
                                        "paymentMode": $scope.txnDetailsResponseObject.paymentMode,
                                        "source": $scope.txnDetailsResponseObject.source,
                                        "accountNo": $scope.txnDetailsResponseObject.account_number,
                                        "fundOption": $scope.txnDetailsResponseObject.fundOptions[0].fundOption,
                                        "refTxn": $scope.txnDetailsResponseObject.ref_txn_no,
                                        "effectiveDate": $filter('date')($scope.txnDetailsResponseObject.trxn_effective_date, "dd/MM/yyyy"),
                                        "stepUpType": $scope.txnDetailsResponseObject.fundOptions[0].stepUpType,
                                        "stepUpValue": $scope.txnDetailsResponseObject.fundOptions[0].stepUpValue,
                                        "amount": $scope.txnDetailsResponseObject.fundOptions[0].amount

                                    };

                                    var multiplemode = false;
                                    if($scope.txnDetailsResponseObject.nextPaymentMode === 'O' || $scope.txnDetailsResponseObject.nextPaymentMode === 'M'){
                                        multiplemode = true;
                                        if($scope.txnDetailsResponseObject.nextPaymentMode === 'O'){
                                            bankDtlsModel.setFutureInstPayMethod(TransactConstant.transact.BILL_PAY);
                                            bankDtlsModel.setNextPaymentMode(TransactConstant.common.BILL_PAY_CODE);  
                                        }else if($scope.txnDetailsResponseObject.nextPaymentMode === 'M'){
                                            bankDtlsModel.setFutureInstPayMethod(TransactConstant.transact.AUTO_DEBIT) 
                                            bankDtlsModel.setNextPaymentMode(TransactConstant.common.AUTO_DEBIT_CODE);
                                        }                                        
                                    } 

                                    var modifyType;

                                    switch ($scope.txnDetailsResponseObject.txn_source) {
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPDTC:
                                            modifyType = TransactConstant.investorleg.SIP_DATE_CHANGE;
                                            break;
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPFLX:
                                            modifyType = TransactConstant.investorleg.FLEXIBLE_SIP;
                                            break;
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPAMC:
                                            modifyType = TransactConstant.investorleg.CHANGE_SIP_AMOUNT;
                                            break;
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPPAS:
                                            modifyType = TransactConstant.investorleg.PAUSE_SIP;
                                            break;
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPCAN:
                                            modifyType = TransactConstant.investorleg.SIP_CANCELLATION;
                                            break;
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPSUC:
                                            modifyType = TransactConstant.investorleg.STEPUP_CANCELLATION;
                                            break;
                                        case TransactConstant.investorleg.TXN_SOURCE_SIPSUP:
                                            modifyType = TransactConstant.investorleg.STEPUP_SIP;
                                            break;
                                        default:
                                            break;
                                    }
                                    var datevalue = $scope.txnDetailsResponseObject.trxn_effective_date.split(" ");
                                    var splitDate = datevalue[0];
                                    $scope.obj = {
                                            type: modifyType,
                                            amount: $scope.txnDetailsResponseObject.fundOptions[0].amount,
                                            msg: "Effective for all installments starting from " + $filter('date')(splitDate, "dd MMM yyyy"),
                                            increaseby: $scope.txnDetailsResponseObject.fundOptions[0].stepUpValue,
                                            effectDate: $filter('date')(splitDate, "dd MMM yyyy"),
                                            month: $filter('date')(splitDate, "MMM yyyy")
                                                // newDate : $scope.txnDetailsResponseObject.trxn_requested_date
                                        }
                                        // setting the SipModifyDetailModel using response object
                                    SipModifyDetailModel.setModifySipInpDetails(sipObj);
                                    SipModifyDetailModel.setModifySipDetails($scope.obj);
                                    bankDtlsModel.setPaymentMethod($scope.txnDetailsResponseObject.paymentOption);
                                    bankDtlsModel.setBankDetails($scope.txnDetailsResponseObject.invPaymentBank);
                                    bankDtlsModel.setTotalAmount($scope.txnDetailsResponseObject.fundOptions[0].amount);
                                    bankDtlsModel.setBankName($scope.txnDetailsResponseObject.invPaymentBank);
                                    bankDtlsModel.setAccountNo($scope.txnDetailsResponseObject.paymentBankAccNo);
                                    bankDtlsModel.setSelectedBank($scope.txnDetailsResponseObject.invPaymentBank + '-' + $scope.txnDetailsResponseObject.paymentBankAccNo);
                                    bankDtlsModel.setModifysipEditable(true);
                                    transactModel.setTransactType('MODIFYSIP');
                                    bankDtlsModel.setStartDate($scope.txnDetailsResponseObject.emandateFromdate);
                                    bankDtlsModel.setEndDate($scope.txnDetailsResponseObject.emandateTodate);
                                    //bankDtlsModel.setFrequency($scope.txnDetailsResponseObject.emandateFrequency);
                                    if($scope.txnDetailsResponseObject.emandateFrequency === 'A') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.AS_AND_WHEN);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'M') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.MNTHLY);
                                    } else if($scope.txnDetailsResponseObject.emandateFrequency === 'Q') {
                                        bankDtlsModel.setFrequency(TransactConstant.transact.QUATERLY);
                                    };
                                    //bankDtlsModel.setAmountType($scope.txnDetailsResponseObject.emandateDebitType);
                                    if($scope.txnDetailsResponseObject.emandateDebitType === 'U') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.MAXIMUM)
                                    } else if($scope.txnDetailsResponseObject.emandateDebitType === 'F') {
                                        bankDtlsModel.setAmountType(TransactConstant.transact.FIXED)
                                    };
                                    //alert($scope.txnDetailsResponseObject.invPaymentBank);
                                    var paymentObj = {
                                        "bankdetail": bankDtlsModel.getSelectedBank(),
                                        "paymode": bankDtlsModel.getPaymentMethod(),
                                        "totalAmount": bankDtlsModel.getTotalAmount()
                                    }
                                    bankDtlsModel.setPaymentDetails(paymentObj);
                                    //console.log($scope.txnDetailsResponseObject);
                                    transactModel.setWebRefNo($scope.txnDetailsResponseObject.web_refno);
                                    bankDtlsModel.setAchRefNo($scope.txnDetailsResponseObject.invAmount);
                                    bankDtlsModel.setDistId($scope.txnDetailsResponseObject.brokerCode);
                                    bankDtlsModel.setFutureInstBank($scope.txnDetailsResponseObject.invPaymentBank + '-' + $scope.txnDetailsResponseObject.paymentBankAccNo);
                                    ifscModel.setIfscBank($scope.txnDetailsResponseObject.invPaymentBank);
                                    //bankDtlsModel.setIfscCode('HDFC0000127');

                                    transactModel.setInvestorReviewState('txnmaster.review.reviewDetailsModifySip');
                                    if(goToreviewFlow === false){
                                        //redirect to verify unit holder details page.
                                        fticStateChange.stateChange($state, 'txnmaster.verifydetails.unitholderDetails');
                                        //$state.go('txnmaster.verifydetails.unitholderDetails');
                                    } else {
                                        fticStateChange.stateChange($state, 'txnmaster.review.reviewDetailsModifySip', {
                                            key: TransactConstant.transact.Payment_Key,
                                            from: 'INVESTORLEG'
                                        });
                                        /*$state.go('txnmaster.review.reviewDetailsModifySip', {
                                            key: TransactConstant.transact.Payment_Key,
                                            from: 'INVESTORLEG'
                                        });*/
                                    }

                                    break;
                                default:
                                    break;
                            }
                        //}

                    }



                    var advisorDetails = {
                        distValue: $scope.txnDetailsResponseObject.brokerCode,
                        distFlag: "NC",
                        guId: transactModel.getValidateWebRefResponse().guId
                    }

                    var postAdvisorDetailsSuccess = function() {

                        var typeHeader;
                        var advisorHeader;
                        var det;
                        if ($scope.txnDetailsResponseObject.brokerCode === "0000000000"){
                            advisorHeader = "DIRECT";
                        }else{
                            det = $scope.txnDetailsResponseObject.brokerName.split('~');
                            advisorHeader = det[0] + " | " + det[1] + " | " + det[2];
                        }                        

                        switch ($scope.txnDetailsResponseObject.txn_source) {
                            case TransactConstant.investorleg.TXN_SOURCE_P:
                                typeHeader = TransactConstant.investorleg.BUY;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIP:
                                typeHeader = TransactConstant.investorleg.SIP;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_S:
                                typeHeader = TransactConstant.investorleg.SWITCH;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_R:
                                typeHeader = TransactConstant.investorleg.REDEEM;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPDTC:
                                typeHeader = TransactConstant.investorleg.SIP_DATE_CHANGE;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPFLX:
                                typeHeader = TransactConstant.investorleg.FLEXIBLE_SIP;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPAMC:
                                typeHeader = TransactConstant.investorleg.CHANGE_SIP_AMOUNT;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPPAS:
                                typeHeader = TransactConstant.investorleg.PAUSE_SIP;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPCAN:
                                typeHeader = TransactConstant.investorleg.SIP_CANCELLATION;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPSUC:
                                typeHeader = TransactConstant.investorleg.STEPUP_CANCELLATION;
                                break;
                            case TransactConstant.investorleg.TXN_SOURCE_SIPSUP:
                                typeHeader = TransactConstant.investorleg.STEPUP_SIP;
                                break;
                            default:
                                typeHeader = $scope.txnDetailsResponseObject.txn_source
                                break;
                        }


                        var trasactionHeader = [{
                            key: TransactConstant.investorleg.TRANSACTIONS,
                            value: typeHeader
                        }, {
                            key: TransactConstant.investorleg.INITIATED_BY,
                            value: advisorHeader
                        }]

                        transactModel.setTransactHeader(trasactionHeader);

                        loadReviewDetails();
                    }

                    /*var postAdvisorDetailsFailure = function(errorResp) {
                        toaster.error(errorResp.data[0].errorDescription);
                    }*/
                    /*if ($scope.txnDetailsResponseObject.brokerCode != "0000000000"){
                        transactModel.fetchGuestAdvisorDetails(advisorDetails).then(postAdvisorDetailsSuccess, postAdvisorDetailsFailure);
                    }else{
                        postAdvisorDetailsSuccess();
                    }*/

                    postAdvisorDetailsSuccess();
                    /*if(true){ // RIA user based userType
                        transactModel.setIsRIAUser(true)  
                    }*/
                    
                };
                var postTxnFailure = function(errorResp) {
                    toaster.error(errorResp.data[0].errorDescription);
                };

                stpDetailsModel.fetchTxnDetailsStp($scope.webRefNo).then(postTxnSuccess, postTxnFailure);

            }
        }]
    }
}

otpVerificationForm.$inject = ['$state', 'transactModel', 'stpDetailsModel', 'reviewSwpDetailsModel', 'redeemModel', 'switchDtlsToReviewModel', 'sipDetailsModel', 'bankDtlsModel', 'fundDetails', 'SipModifyDetailModel', 'otpVerificationModelGuest', 'authenticationService', '$cookies', 'toaster', 'TransactConstant', '$filter','ifscModel','investorRegistrationModel', 'fticStateChange'];

module.exports = otpVerificationForm;
