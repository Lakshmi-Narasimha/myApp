/**
 * @ngdoc property
 * @name Footer Controller
 * @requires $scope
 * @requires $state
 * @requires $localStorage
 * @description
 *
 * - It has the scope for Footer. Initially it contains the service for footer constants 
 * 
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function footerCtrl(fticMenuModel, $scope, $localStorage, $state, $http, constants, globalMenuInitLoader, events, eventConstants, $timeout, appConfig, configUrlModel) {

        //  if(globalMenuInitLoader._isServicesData){
        //     $timeout(function() {
        //         events.publishMenuDetails($scope);
        //     },0);
        // } else {
        //     globalMenuInitLoader.loadAllServices($scope);
        //     globalMenuInitLoader._isServicesData = true;
        // }

        $scope.$on(eventConstants.ON_MENU_DETAILS,function(event,data){     
            var MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
            var GUEST_URL = appConfig[configUrlModel.getEnvUrl('GUEST_URL')];            
            $scope.footer = fticMenuModel.getFooterData();
            $scope.footerLinks = $scope.footer["footer-links"]["link"];
            angular.forEach($scope.footerLinks,function(footerobj){
                if(footerobj.url.indexOf('http') == '-1'){
                    if(footerobj.type=='guest'){
                        footerobj.url = GUEST_URL+"/#"+footerobj.url;  
                    }else if(footerobj.type=='marketing'){
                        footerobj.url = MARKETING_URL+footerobj.url;
                    } 
                }
            });
            $scope.footerLinks1= $scope.footerLinks.slice(0, 6);
            $scope.footerLinks2 = $scope.footerLinks.slice(6, 11);
            $scope.footerIcons = $scope.footer.socialmedia;
            $scope.footerCopyright = $scope.footer["copyright-info"];
            $scope.footerCopyright['home-page']['url'] = MARKETING_URL+$scope.footerCopyright['home-page']['url'];
            $scope.footerlogo = MARKETING_URL+$scope.footer["footer-logo"];
        });
};

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
footerCtrl.$inject = ['fticMenuModel', '$scope', '$localStorage', '$state', '$http', 'constants', 'globalMenuInitLoader', 'events', 'eventConstants', '$timeout', 'appConfig', 'configUrlModel'];
module.exports = footerCtrl;