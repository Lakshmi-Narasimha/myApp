/**
 * @ngdoc filter
 * @name Filter paymentMode
 * @description
 *
 * - Filter method to format number to 2 digits.
 *
 */


'use strict';

var paymentMode = function() {

	return function(value) {
		if(!value) {
            return '';
        } else if(value === 'Directly To Bank' || value === 'DC') {
            return 'Direct Credit';
        } else {
            return 'Cheque';
        }
	};
};

paymentMode.$inject = [];
module.exports = paymentMode;
