/**
 * @ngdoc property
 * @name fticSelectFolio directive
 * @description
 *
 *
 **/
'use strict';


var fticSelectFolio = function (invPanFolioKycModel, eventConstants, $state, transactModel, $stateParams, transactNowModel, authenticationService, TransactConstant, folioDetailsModel, transactEventConstants, invSelectFolioFormDataFactory, $uibModal, toaster, $loader) {

    return {
        template: require('./selectFolioForm.html'),
        restrict: 'E',
        scope: {},
        controller: function ($scope, $element, $attrs, $state) {
            $scope.configDataLost = {};
            $scope.configDataLost.showNotification = false;
            $scope.radios = {};
            $scope.radios.selectedVal = "";
            $scope.newFolioTxt = TransactConstant.common.NEW_FOLIO;
            $scope.isShowNewFolio = false;
            $scope.showNotification = false;
            $scope.selectedFolio = null;
            $scope.holderDtls = [];
            var _userProfileDetails = authenticationService.getInvDashboardDetails();
            // var params = {
            // 	"panNo" : authenticationService.getUser().pan,
            // 	"guId" : authenticationService.getUser().guId,
            // };
            var _params = {
                'panNo': (_userProfileDetails && _userProfileDetails.pan) ? _userProfileDetails.pan: '',
                'fsFlag': '',
                'txnAccess': 'Y'
            };
            var panFolioKycSuccess = function (data) {
                if (data) {
                    invPanFolioKycModel.setPanFolioKycData(data);
                    $scope.init(data.panFolioKyc);
                }

            };
            var promiseFailure = function (error) {
                if (error && error.data && error.data.length > 0) {
                    toaster.error(error.data[0].errorDescription);
                }
            };
            $loader.start();
            invPanFolioKycModel.getPanFolioKycDetails(_params)
                .then(panFolioKycSuccess, promiseFailure)
                .finally(function() {
                    $loader.stop();
                });
            // folioDetailsInitialLoader.loadAllServices($scope,params);

            //var transactType = transactModel.getTransactType();
            // $scope.isShowNewFolio = true;
            // if(transactType === TransactConstant.renewSip.RENEWSIP) {
            // 	$scope.isShowNewFolio = false;
            // }

            $scope.init = function (data) {
                $scope.investorDetails = data;
                //folioDetailsModel.setFolioDetails(data);
                $scope.holderDtls = invSelectFolioFormDataFactory.getFormattedHolderDetails(data);

            };
              $scope.$on('stateChanged', function () {
                console.log($scope.radios.selectedVal);
                $scope.radios.selectedVal = "";
                transactModel.setInvestorDetails({});
                invSelectFolioFormDataFactory.setFormattedCurrentFolio({});
                transactModel.setSelectedFolioDts({});
                transactModel.setSelectedFolioDts({});
             });
            $scope.listenChange = function (value, index, flag) {
                $scope.selectedFolio = value;
                if (value !== 'Newfolio') {
                    value.index = index;
                }
                $scope.index = index;
                if ((transactNowModel.isFolioEditClicked || $stateParams.key === 'Investor') && flag) {
                    $scope.referenceFolioId = transactModel.getSelectedFolioDts().folioId;
                    $scope.prevSelectedOptionDetails = transactModel.getInvestorDetails();
                }
                if (!invSelectFolioFormDataFactory.getCurrentSelectedFolioData($scope.selectedFolio.folioId)) {
                    invSelectFolioFormDataFactory.setFormattedCurrentFolio($scope.selectedFolio);
                }
                transactModel.setSelectedFolioDts(invSelectFolioFormDataFactory.getCurrentSelectedFolioData($scope.selectedFolio.folioId));
                transactModel.setInvestorDetails($scope.selectedFolio);
                //transactModel.setSelectedFolioDts(value);
            };

            // function goNexttab() {
            // 	if(transactModel.getSelectedFolioDts() == "Newfolio"){
            // 		$state.go('transactnow.newFolioNnewInvestor');
            // 	}
            // 	else if( $scope.selectedFolio.holderDetails){
            // 	 	for(var i=0; i < $scope.selectedFolio.holderDetails.length; i++){
            // 	 		if($scope.selectedFolio.holderDetails[i].kycStatus !== "KYC Registered-New KYC" && $scope.selectedFolio.holderDetails[i].kycStatus !== 'MF KYC Registered'){
            // 	 			$scope.showNotification = true;
            // 	 			$scope.headerOnPopUp="";
            // 			    $scope.noBtnTxt="Cancel";
            // 			    $scope.yesBtnTxt="Continue with KYC";
            // 			    $scope.txtOnPopUp="Please complete KYC registration of all the holders to proceed with the transaction.";
            // 			    $scope.popUpMainHeader="";
            // 			    return;
            // 	 		}
            // 	 		else if ($scope.selectedFolio.holderDetails[i].kycStatus == "KYC Registered-New KYC" || $scope.selectedFolio.holderDetails[i].kycStatus == 'MF KYC Registered'){
            // 	 			//open investment preference
            // 	 			$scope.folioDetailsObj = {
            // 	 				"index":$scope.index,
            // 	 				"folioId" : $scope.selectedFolio.folioId,
            // 	 				"firstHolder" : $scope.holderDtls[$scope.index].firstHolderName,
            // 	 				"pan" : unitHolderDetailsModel.getUnitHolder().pan,
            // 	 				"email" : unitHolderDetailsModel.getUnitHolder().emailId,
            // 	 				"mobile": unitHolderDetailsModel.getUnitHolder().mobile,
            // 	 				"secondHolder" : $scope.holderDtls[$scope.index].secondHolderName,
            // 	 				"thirdHolder" : $scope.holderDtls[$scope.index].thirdHolderName
            // 	 			}

            // 	 		}
            // 	 	}
            //  		transactModel.setFolioDetailsObj($scope.folioDetailsObj);
            // 		$scope.$emit('setFolioDetailsTl');
            // 	}
            // 	$scope.previousData = transactModel.getSelectedFolioDts();
            // }
            $scope.navigateToNextStep = function () {

                $scope.$emit(transactEventConstants.transact.INV_FOLIO_SELECTED_CON);
            };

            $scope.continue = function() {
            	console.log($state)
                // if(transactModel.getTransactType == "TransactConstant.renewSip.RENEWSIP")
                // {
                // 	transactNowModel.isInvPreferHasInitialData = true;
                // 	transactNowModel.hasSelectSipData = false;
                // }
                // transactModel.setIsNewFolio(false);
             
                if (($state.current.url === "/stp") && ($scope.selectedFolio["firstHolderKyc"] == "KYC - Not Registered" || $scope.selectedFolio["secondHolderKyc"] == "KYC - Not Registered" || $scope.selectedFolio["thirdHolderKyc"] == "KYC - Not Registered")) {
                    $scope.showFundView = false;
                    $scope.showKycConfirmPopup();

                }
                 if (($state.current.url === "/dtp") && ($scope.selectedFolio["firstHolderKyc"] == "not registered" || $scope.selectedFolio["secondHolderKyc"] == "not registered" || $scope.selectedFolio["thirdHolderKyc"] == "not registered")) {
                    $scope.showFundView = false;
                    $scope.showKycConfirmPopup();

                }
                // if($stateParams.key == "Folio" || transactNowModel.isFolioEditClicked){
                // 	transactNowModel.isFolioEditClicked = false;
                //     var result = _.isEqual($scope.referenceFolioId, $scope.selectedFolio.folioId);
                //         if (!result) {
                //             $scope.configDataLost.showNotification = true;
                //             var destroyHandler =  $scope.$on('yes', function () {
                //             	transactNowModel.hasInvPreferData = false;
                //                 goNexttab();
                //                 $scope.configDataLost.showNotification = false;
                //                 destroyHandler();
                //               });

                //               $scope.$on('no', function () {
                //                 $scope.configDataLost.showNotification = false;
                //                 $scope.radios.selectedVal = $scope.folioDetailsObj.folioId;
                //                 $scope.selectedFolio = $scope.previousData;
                //                 $scope.index = $scope.selectedFolio.index;
                //                 transactModel.setSelectedFolioDts($scope.previousData);
                //               });
                //         }
                //         else{
                //                 goNexttab();
                //             }
                // }else{
                // 		transactNowModel.hasInvPreferData = false;
                //         goNexttab();
                //     }
                else if ($stateParams.key === 'Investor' || transactNowModel.isFolioEditClicked) {

                    transactNowModel.isFolioEditClicked = false;
                    var result = _.isEqual($scope.referenceFolioId, $scope.selectedFolio.folioId);
                    if (!result) {
                        $scope.configDataLost.showNotification = true;
                        var destroyHandler = $scope.$on('yes', function () {
                            //transactNowModel.hasInvPreferData = false;
                            transactModel.INV_FOLIO_EDIT_FLAG = false;
                            $scope.navigateToNextStep();
                            $scope.configDataLost.showNotification = false;
                            destroyHandler();
                        });

                        $scope.$on('no', function () {
                            transactModel.INV_FOLIO_EDIT_FLAG = true;
                            $scope.configDataLost.showNotification = false;
                            $scope.radios.selectedVal = $scope.prevSelectedOptionDetails.folioId;
                            $scope.selectedFolio = $scope.prevSelectedOptionDetails;
                            $scope.index = $scope.selectedFolio.index;
                            transactModel.setSelectedFolioDts($scope.prevSelectedOptionDetails);
                            transactModel.setInvestorDetails($scope.prevSelectedOptionDetails);
                        });
                    } else {
                        transactModel.INV_FOLIO_EDIT_FLAG = true;
                        $scope.navigateToNextStep();
                    }
                } else {
                    $scope.navigateToNextStep();
                }

            };

            $scope.showKycConfirmPopup = function() {
                    //$scope.kycRegNeeded = true;
                    $scope.$emit(transactEventConstants.transact.KYC_NOT_REG_FLOW);
                    /*$scope.kycTxtOnPopUp="Please complete KYC registration of all the holders to proceed with thetransaction";
                    $scope.cancelBtnTxt="cancel";
                    $scope.continueBtnTxt="continue with KYC";*/
                     var modalInstance;  
                  
                    modalInstance = $uibModal.open({
                                  template : require('../kycModal/kycConfirmModal.html'),
                                  scope : $scope
                              });
                };
                // $scope.$on(eventConstants.transactNow.FOLIO_DETAILS,function(value, data){
                // 	$scope.init(data.result);
                // });

            // $scope.$on('yes', function () {
            // 	$scope.showNotification = false;
            // 	 $state.go("transactnow.ekycRegistration"); 
            // });

            // $scope.$on('no', function () {
            // 	$scope.showNotification = false;
            // });

            // $scope.goToLandingPage = function() {
            // 	if(transactNowModel.getIsFromTransactNow()){
            // 		$state.go('smartsolutions.planSmartSolution.goalSheetSummary')
            // 	}
            // 	else {
            // 		$state.go('transactnow.transactType');
            // 	}
            // };

            // $scope.$on("showSelectFolioPanel",function(event){
            //     $scope.folioSelObj = transactModel.getSelectedFolioDts();
            //     if ($scope.folioSelObj !== null){
            //         $scope.radios.selectedVal = $scope.folioSelObj.folioId;
            //     }
            //     $scope.listenChange($scope.folioSelObj,$scope.folioSelObj.index);
            // });
            var onEditSetDataForSelectFolio = function () {
                $scope.folioSelObj = transactModel.getInvestorDetails();
                $scope.radios.selectedVal = $scope.folioSelObj.folioId;
                $scope.listenChange($scope.folioSelObj, $scope.folioSelObj.index, true);
            };
            console.log($stateParams);
            // if($stateParams.key == "Folio"){
            // 	$scope.folioSelected = transactModel.getSelectedFolioDts();
            // 	$scope.referenceFolioId = transactModel.getSelectedFolioDts().folioId;
            // 	 if ($scope.folioSelected !== null){
            //         $scope.radios.selectedVal = $scope.folioSelected.folioId;
            //     }
            // 	$scope.listenChange($scope.folioSelected,$scope.folioSelected.index);
            // }
            if ($stateParams.key === 'Investor') {
                onEditSetDataForSelectFolio();
            }
            $scope.$on(transactEventConstants.transact.Edit_Button_Clicked, function () {
                onEditSetDataForSelectFolio();
            });

        },
        link: function () {}
    };
};


fticSelectFolio.$inject = ['invPanFolioKycModel', 'eventConstants', '$state', 'transactModel', '$stateParams', 'transactNowModel', 'authenticationService', 'TransactConstant', 'folioDetailsModel', 'transactEventConstants', 'invSelectFolioFormDataFactory', '$uibModal', 'toaster', '$loader'];

module.exports = fticSelectFolio;
