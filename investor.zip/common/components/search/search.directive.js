/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var fticSearch = function() {
	return {
            template: require('./search.html'),
            restrict: 'E',
            replace: true,
            scope: {
                searchClass : '=',
                modelValue : '=?'
            },
            controller: function($scope, $element, $attrs){
                $scope.$on('$stateChangeSuccess',function(event){
                    $scope.modelValue = '';
                });
            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

fticSearch.$inject = [];
module.exports = fticSearch;