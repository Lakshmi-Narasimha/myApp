/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var resetUserTypes = function() {
      
	return {
            template: require('./resetUserTypes.html'),
            restrict: 'E',
            replace: true,
            scope: {
                
            },
            controller:['$scope', function($scope){
                $scope.distributorSelected=function($event){
                  $event.preventDefault();
                  $scope.$emit('distributorSelected');
                };
                $scope.investorfpSelected=function($event){
                  $event.preventDefault();
                  $scope.$emit('investorfpSelected');
                };
            }]
        };
};

 module.exports = resetUserTypes;