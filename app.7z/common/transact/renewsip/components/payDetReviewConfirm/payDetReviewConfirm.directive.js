/**
 * @ngdoc property
 * @name fticPayDetReviewConfirm Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Details.
 *
 **/
'use strict';

var fticPayDetReviewConfirm = function (bankDtlsModel,eventConstants, TransactConstant, $state, fundDetails) {
    return {
        template: require('./payDetReviewConfirm.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: ['$scope', function($scope){
            if($state.current.name == "invTransact.review.renewsip"){
               bankDtlsModel.setTotalAmount(fundDetails.getFundDetails()[0].sipAmount);
            }
            $scope.keyValuePairs = [
                {
                    text: TransactConstant.transact.BANK_DETAILS,
                    value: bankDtlsModel.getSelectedBank()
                },
                {
                    text: TransactConstant.transact.MODE_OF_PAYMENT,
                    value: bankDtlsModel.getPaymentMethod()
                },
                ,
                {
                    text: TransactConstant.transact.TOTAL_INVSTMNT_AMT,
                    value: '<span class="icon-fti_rupee"></span>'+bankDtlsModel.getTotalAmount()
                }
            ];
            
            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){  

                //$scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: TransactConstant.transact.Payment_Key});
                $scope.$emit("NAVIGATE_TO_TRANSACT", {key: TransactConstant.transact.Payment_Key});
                $event.stopPropagation(); 
            });
        }]
    };
};

fticPayDetReviewConfirm.$inject = ['bankDtlsModel','eventConstants', 'TransactConstant', '$state', 'fundDetails'];
module.exports = fticPayDetReviewConfirm;