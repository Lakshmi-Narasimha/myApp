'use strict';

describe('Directive : Capital gains folio details grid', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, cgAccDetModel;

    var cgFolioData = {
        'foliodet': [{
            'fundName': 'Franklin India Pension Plan-GROWTH',
            'accountNo': '0100007823616',
            'purchase': {
                'fundWiseData': null,
                'txType': 'Purchase',
                'txDate': '2008-06-24 00:00:00.0',
                'indexedVal': '8797.27'
            },
            'redemption': {
                'txType': 'Switch Out',
                'txDate': '16 dec 2014',
                'amount': '9791.1'
            },
            'capital': {
                'shorterm': '993.83',
                'longterm': '4791.089025'
            },
            'taxded': {
                'total': '',
                'stt': '0'
            }
        },
        {
            'fundName': 'Franklin India Pension Plan-GROWTH',
            'accountNo': '0100007823616',
            'purchase': {
                'fundWiseData': null,
                'txType': 'Purchase',
                'txDate': '2008-06-24 00:00:00.0',
                'indexedVal': '8797.27'
            },
            'redemption': {
                'txType': 'Switch Out',
                'txDate': '16 dec 2014',
                'amount': '9791.1'
            },
            'capital': {
                'shorterm': '993.83',
                'longterm': '4791.089025'
            },
            'taxded': {
                'total': '',
                'stt': '0'
            }
        }],
        'folioNumber': '65376478585'
    };
    cgAccDetModel = {
        getAccFolioNumber: function() {
            return cgFolioData.folioNumber
        },
        getCgFoliodetails: function () {
            return cgFolioData.foliodet
        }
    }

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('cgAccDetModel', cgAccDetModel);
        });
    });
    var getCompiledElement = function() {
        var element = angular.element('<ftic-capital-gains-folio-details></ftic-capital-gains-folio-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _cgAccDetModel_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            cgAccDetModel = _cgAccDetModel_;

            directiveEle = getCompiledElement();
            isolatedScope = directiveEle.isolateScope();
        });
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have folioNumber from isolated scope', function() {
        expect(isolatedScope.folioNumber).toBe('65376478585');
    });

    it('should render data in the view', function() {
        expect(isolatedScope.accountStatementData).toBeDefined();
        expect(isolatedScope.accountStatementData[0].fundName).toBe('Franklin India Pension Plan-GROWTH');
        expect(isolatedScope.accountStatementData[0].accountNo).toBe('0100007823616');
        expect(isolatedScope.accountStatementData[0].capital).toBeDefined();
        expect(isolatedScope.accountStatementData[0].purchase).toBeDefined();
        expect(isolatedScope.accountStatementData[0].redemption).toBeDefined();
        expect(isolatedScope.accountStatementData[0].taxded).toBeDefined();
    });

    it('should have defined columnDefs from isolated scope', function() {
        expect(isolatedScope.gridOptions.columnDefs).toBeDefined();
    });
});
