// ProductFilterDetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ProductFilterDetailsSchema = new mongoose.Schema({
    ProductFilterDetails: {
        type: Array,
        "default": []
    }
});

var ProductFilterDetailsLookUp = mongoose.model('ProductFilterDetailsLookUp', ProductFilterDetailsSchema);
/*json order: investor book-*/
var productDetailsModel = new ProductFilterDetailsLookUp({
  "ProductFilterDetails": [
  {
    "label": "Time value of money & when to start investement",
    "id": 1,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 2,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 3,
    "data":"https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 4,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "investing in equalites",
    "id": 5,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 6,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  }
]
});

ProductFilterDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ProductFilterDetailsLookUp table, please contact admin...');
    } else {
        ProductFilterDetailsLookUp.remove({}, function(err) {
            console.log('ProductFilterDetailsLookUp collection removed');
           productDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ProductFilterDetailsLookUp table, please contact admin...');
                }
                console.log('ProductFilterDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ProductFilterDetailsLookUp;
