define(['jquery', 'backbone', 'appmodules/hoc/app/data/hoc-matrix', 'services/dataservice', 'appcommon/globalcontext', 'spinner', 'appmodules/contactprofile/app/models/cpviewmodel', 'appcommon/commonutility', 'errorLog'], function ($, Backbone, HOCMatrix, DataService, GlobalContext, Spinner, CPViewModel, CommonUtility, ErrorLog) {
    var self = null;
    var modelAction = Backbone.Model.extend({
        defaults: {
            "actionId": null,
            "actionTitle": null,
            "actionDesc": null,
            "actionType": null,//other options drop down could have more options later
            "external": false,//applicable only for links,
            "url": null,//applicable only for links,
            "dropdownOptions": [],//applicable only for drop down,
            "orderIndex": null
        }

    });
    var modelItem = Backbone.Model.extend({
        defaults: {
            "itemTypCd": null,
            "orderIndex": null,//sorting of gapItems are based on this orderIndex, this should read from mapping matrix
            "itemTypDesc": null,
            "values": [],
            "helperText": null,
            "actions": [],
            "orderIndex": null,
            "customValues": {}
        }
    });

    var modelSection = Backbone.Model.extend({
        defaults: {
            "sectionId": null,
            "sectionTitle": null,
            "sectionDesc": null,
            "customValues": null,
            "sectionColumns": [],//this will decide the UI layout 
            "orderIndex": null,
            "gapItems": []
        }
    });

    var modelCategory = Backbone.Model.extend({
        defaults: {
            "ctgCd": null,//unique id for each category (most probably id from server )
            "ctgDesc": null,
            "ctgTitle": null,
            "orderIndex": null,
            "sections": []
        }
    });
    var hocModel = Backbone.Model.extend({
        defaults: {
            "categories": []
        },
        initialize: function () {
            self = this;
        },
        hocGetItemsSuccessHandler: function (response) { },
        setModel: function (response, clientAge) {
            try {
                this.clearModel();
                this.set('clientAge', clientAge);
                var _sections = this.createSections(1),
                    _sevsOpprtntySections = this.createSections(2),
                    _takeActionNeeded = {
                        "ctgCd": "1",
                        "ctgDesc": HOCMatrix.categories.find(function (row) { return row.ctgCd == "1" }).ctgDesc,
                        "ctgTitle": "Take Action", "orderIndex": 1,
                        "sections": [
                            _sections.open,
                            _sections.postPoned,
                            _sections.closed,
                            _sections.dataNotFound
                        ]
                    },
                    _servsOprtnts = {
                        "ctgCd": "2",
                        "ctgDesc": HOCMatrix.categories.find(function (row) { return row.ctgCd == "2" }).ctgDesc,
                        "ctgTitle": "Service Oppertunities", "orderIndex": 2,
                        "sections": [
                            _sevsOpprtntySections.open,
                            _sevsOpprtntySections.postPoned,
                            _sevsOpprtntySections.closed,
                            _sevsOpprtntySections.dataNotFound
                        ]
                    };
                this.set("categories", [_takeActionNeeded, _servsOprtnts]);
                self.parseItems(response);
                this.get("categories").forEach(function (ctgry) {
                    self.sortSections(ctgry.sections);
                });
            } catch (e) {
                 ErrorLog.ErrorUtils.myError(e);
            }
        },
        clearModel: function () {
            this.clear().set(this.defaults);
        },
        parseItems: function (response) {
            var _response = response,
                 _seconValObj,
                 _CPData = CPViewModel.getInstance().getData().cola,
                _clLastNm = _CPData.personClient.get("clLastNm"),
                _isOrgClient = (_clLastNm === null || _clLastNm === undefined || _clLastNm === "") ? true : false,
                _orgClient,
                _formofBusnsCd,
                _showFiduciaryItem,
                _fiduciaryOrgRoleArray = ["01", "07", "08"],
                _catgrySections,
                 _takeActionSectionsModel = this.get("categories").find(function (ctgry) {
                    return ctgry.ctgCd == 1;
                }).sections,
                _servcOppSectionsModel = this.get("categories").find(function (ctgry) {
                    return ctgry.ctgCd == 2;
                }).sections;
                //additional check for orgclient for fiduciary
            if (_isOrgClient) {
                _orgClient = _CPData.orgClient;
                _formofBusnsCd = _orgClient.get("formOfBusOwnshpCd");
                if (_fiduciaryOrgRoleArray.indexOf(_formofBusnsCd) === -1) {
                    _showFiduciaryItem = false;
                }
            }
            self.set({
                'isOrgClient': _isOrgClient,
                'showFiduciaryItem': _showFiduciaryItem
            });
            if (_response.value != undefined && _response.value != null) {
                _items = _response.value;
                $.each(_items, function (index, item) {
                    if (item.itemStatCd == "opn" || item.itemStatCd == "psp" || item.itemStatCd == "ni" || item.itemStatCd == "dna") {
                        var _custValues, hocItemMatrix = self.getMatrixItem(item);
                        var hocItemMatrix = self.getMatrixItem(item);
                        if (hocItemMatrix.item.viewDisplay == true) {
                            var _newGapItem = new modelItem(), _itemSecondaryVals = [];;
                            _newGapItem.set({
                                'itemTypCd': item.itemTypCd, 'itemTypDesc': hocItemMatrix.item.itemTypDesc, "orderIndex": hocItemMatrix.item.orderIndex, "hideSecondaryItems": hocItemMatrix.item.hideSecondaryItems
                            });
                            switch (item.itemTypCd) {
                            	case "unclaimedProperty":
                            		_custValues = {};
                            		if (item.cpLstItmIds.length > 0) {
                            			$.each(item.cpLstItmIds, function (i, list) {
                            				var positionFlag = false, _unclaimedObj = [
                            					{ "propNm": "impactToClient", "propVal": "" },
                            					{ "propNm": "actionSteps", "propVal": "" },
                            					{ "propNm": "contactRange", "propVal": "" }];
                            				var _props = list.props;
                            				$.each(_props, function (j, prop) {
                            					if (prop.propNm == "impactToClient") {
                            						_itemSecondaryVals.unshift([prop]);
                            					} else if (prop.propNm == "actionSteps") {
                            						_unclaimedObj[0].propVal = prop.propVal;
                            					} else if (prop.propNm == "uniqueId") {
                            						_custValues.uniqueId = prop.propVal;
                            					} else if (prop.propNm == "contactRange") {
                            						_newGapItem.set("itemTypDesc", "No client contact in over " + prop.propVal + " months");
                            					}
                            				});
                            				_itemSecondaryVals.push(_unclaimedObj);
                            			});
                            		}
                            		_newGapItem.set('customValues', _custValues);
									break;
                            	case "diligenceAdvAcct":
                            		_custValues = {};
                            		if (item.cpLstItmIds.length > 0) {
                            			$.each(item.cpLstItmIds, function (i, list) {
                            				var positionFlag = false, _secondDiligAdvObj =[{ "propNm": "acctImpDesc", "propVal": "" }, { "propNm": "acctNbr", "propVal": "" }, { "propNm": "tkrSmbl", "propVal": "" }, { "propNm": "type", "propVal": "" }, { "propNm": "frequency", "propVal": "" }, { "propNm": "value", "propVal": ""
                            			}];
                            				var _props = list.props, typeStatus;
                            				$.each(_props, function (j, prop) {
                            					if (prop.propNm == "acctImpDesc") {
                            						_itemSecondaryVals.unshift([prop]);
                            					} else if (prop.propNm == "acctNbr") {
                            						_secondDiligAdvObj[0].propVal = "Account# " + self.formatDOLAccountNum(prop.propVal);
                            						_custValues.acctNbr = prop.propVal;
                            					} else if (prop.propNm == "tkrSmbl") {
                            						_secondDiligAdvObj[1].propVal = "Ticker Symbol: " + prop.propVal;
                            					} else if (prop.propNm == "uniqueId") {
                            						_custValues.uniqueId = prop.propVal;
                            					} else if (prop.propNm == "type") {
                            						typeStatus = prop.propVal;
													if(typeStatus.indexOf('Open Buy Order') >= 0) {
														positionFlag = true;
													}
                            						_secondDiligAdvObj[2].propVal = "Type: " + typeStatus;
                            						if (prop.propVal == "Systematic Purchase" || positionFlag) {
                            							var _frequency = _props.find(function (_prop) { return _prop.propNm == "frequency"; }),
                            							_frequencyVal = _frequency ? _frequency.propVal : "";
                            							_secondDiligAdvObj[3].propVal = "Frequency: " + _frequencyVal;
                            						}
                            					} else if (prop.propNm == "value") {
                            						_secondDiligAdvObj[4].propVal = "Value: " + prop.propVal.formatMoney();
                            					}
                            				});

                            				var _acctImpactDesc = _props.find(function (_prop) { return _prop.propNm == "acctImpDesc"; }),
                            					_acctImpactDescVal = _acctImpactDesc ? _acctImpactDesc.propVal : "", impactAccountFlag = 0;
                            				if (_acctImpactDescVal == "Position no longer meets due diligence standards, therefore, position no longer permitted in SPS Advantage and SPS Advisor. Client letter in late October, positional unwrap process begins in early December.") {
                            					impactAccountFlag = 1;
                            				} else if (_acctImpactDescVal == "Hold and service position no longer permitted in SPS Advantage and SPS Advisor. Client letter in late October, positional unwrap process begins in early December.") {
                            					impactAccountFlag = 2;
                            				}

                            				if (typeStatus == "Position" && impactAccountFlag == 1) {
                            					_newGapItem.set("itemTypDesc", "Position no longer meets due diligence standards");
                            				} else if (typeStatus == "Position" && impactAccountFlag == 2) {
                            					_newGapItem.set("itemTypDesc", "Hold and service position no longer permitted in SPS Advantage and SPS Advisor");
                            				} else if (typeStatus == "Systematic Purchase" || typeStatus == "Open Buy Order" || positionFlag) {
                            					_newGapItem.set("itemTypDesc", "Future purchases of positions that no longer meet the due diligence standards will not be permitted");
                            				}
                            				_itemSecondaryVals.push(_secondDiligAdvObj);
                            			});
                            		}
                            		_newGapItem.set('customValues', _custValues);
                            		break;
                            	case "diligenceBrokerageAcct":
                            		_custValues = {};
                            		if (item.cpLstItmIds.length > 0) {
                            			$.each(item.cpLstItmIds, function (i, list) {
                            				var positionFlag = false, _secondDiligBrkgObj =[{ "propNm": "acctImpDesc", "propVal": "" }, { "propNm": "acctNbr", "propVal": "" }, { "propNm": "tkrSmbl", "propVal": "" }, { "propNm": "type", "propVal": "" }, { "propNm": "frequency", "propVal": "" }, { "propNm": "value", "propVal": ""
                            			}];
                            				var _props = list.props, typeStatus;
                            				$.each(_props, function (j, prop) {
                            					if (prop.propNm == "acctImpDesc") {
                            						_itemSecondaryVals.unshift([prop]);
                            					} else if (prop.propNm == "acctNbr") {
                            						_secondDiligBrkgObj[0].propVal = "Account# " + self.formatDOLAccountNum(prop.propVal);
                            						_custValues.acctNbr = prop.propVal;
                            					} else if (prop.propNm == "tkrSmbl") {
                            						_secondDiligBrkgObj[1].propVal = "Ticker Symbol: " + prop.propVal;
                            					} else if (prop.propNm == "uniqueId") {
                            						_custValues.uniqueId = prop.propVal;
                            					} else if (prop.propNm == "type") {
                            						typeStatus = prop.propVal;
													if(typeStatus.indexOf('Open Buy Order') >= 0) {
														positionFlag = true;
													}
                            						_secondDiligBrkgObj[2].propVal = "Type: " +typeStatus;
													if (prop.propVal == "Systematic Purchase" || positionFlag) {
                            							var _frequency = _props.find(function (_prop) { return _prop.propNm == "frequency"; }),
                            							_frequencyVal = _frequency ? _frequency.propVal : "";
                            							_secondDiligBrkgObj[3].propVal = "Frequency: " + _frequencyVal;
                            						}
                            					} else if (prop.propNm == "value") {
                            						_secondDiligBrkgObj[4].propVal = "Value: " + prop.propVal.formatMoney();
                            					}
                            				});
                            				if (typeStatus == "Position") {
                            					_newGapItem.set("itemTypDesc", "Position no longer meets due diligence standards");
                            					} else if (typeStatus == "Systematic Purchase" || typeStatus == "Open Buy Order" || positionFlag) {
                            					_newGapItem.set("itemTypDesc", "Future purchases of positions that no longer meet the due diligence standards will not be permitted");
                            				}
                            				_itemSecondaryVals.push(_secondDiligBrkgObj);
                            			});
                            		}
                            		_newGapItem.set('customValues', _custValues);
                            		break;
                                case "shrkarr":
                                    _custValues = {
                                        "actionStatus": "",
                                        "uniqueId": ""
                                    }
                            			if (item.cpLstItmIds.length > 0) {
                            				$.each(item.cpLstItmIds, function (i, list) {
                            				    var _secondColumbiaObj = [{ "propNm": "arrNtTxt", "propVal": "" }, { "propNm": "arrTypDesc", "propVal": "" }, { "propNm": "arrFrAcctNbr", "propVal": "" }, { "propNm": "arrToAcctNbr", "propVal": "" }];
                            					var _props = list.props,_actnStts;
                            					$.each(_props, function (j, prop) {
                            					    if (prop.propNm == "arrNtTxt") {
                            					        _secondColumbiaObj[0].propVal = prop.propVal;
                            						} else if (prop.propNm == "arrTypDesc") {
                            						    _secondColumbiaObj[1].propVal = prop.propVal;
                            						} else if (prop.propNm == "arrFrAcctNbr") {
                            						    var _frmAdmnCd = _props.find(function (_prop) { return _prop.propNm == "arrFrAdmCd"; }),
                                                            _fromAccountVal = "From account# " + self.formatColumbiaACcountNum(prop.propVal, _frmAdmnCd ? _frmAdmnCd.propVal : ""/*admnCd*/);
                            						    _secondColumbiaObj[2].propVal = _fromAccountVal;
                            						} else if (prop.propNm == "arrToAcctNbr") {
                            						    var _toAdmnCd = _props.find(function (_prop) { return _prop.propNm == "arrToAdmCd"; }),
                                                            _toAccountVal = "To account# " + self.formatColumbiaACcountNum(prop.propVal, _toAdmnCd ? _toAdmnCd.propVal : ""/*admnCd*/);
                            						    _secondColumbiaObj[3].propVal = _toAccountVal;
                            						} else if (prop.propNm == "uniqueId") {
                            						    _custValues.uniqueId = prop.propVal;
                            						} else if (prop.propNm == "actionStatus") {
                            						    _actnStts = prop.propVal ? prop.propVal.toUpperCase() : "";
                            						    _custValues.actionStatus = _actnStts;
                            						}
                            					});
                            /*if actoion status is expired change desc text and add a new secondary static text*/
                            					if (_actnStts && _actnStts == "EXPIRED") {
                            					    _newGapItem.set("itemTypDesc", "Arrangement did not transfer to the new brokerage account during legacy Columbia mutual fund conversion");
                            					    _itemSecondaryVals.push([{
                            					        "propNm": "exprdSecText",
                            					        "propVal": "Action you may have taken outside of the designated workflow may not be reflected in this view."
                            					    }]);
                                                }
                            					_itemSecondaryVals.push(_secondColumbiaObj);
                            				});
                            			}
                            			_newGapItem.set('customValues', _custValues);
                            		break;
                                case "phyaddrundl":
                                    if (item.ctgCd == "1") {
                                        if (item.cpLstItmIds.length > 0) {
                                            $.each(item.cpLstItmIds, function (i, addressBlock) {
                                                _seconValObj = [{ "propNm": "addrLn1", "propVal": "" }, { "propNm": "addrLn2", "propVal": "" }, { "propNm": "addrLn3", "propVal": "" }, { "propNm": "cityStateZip", "propVal": "" }, { "propNm": "cntryNm", "propVal": "" }];
                                                var _props = addressBlock.props;
                                                var _cityStateZip = {
                                                    "propNm": "cityStateZip",
                                                    "propVal": ""
                                                }
                                                var _city = "", _state = "", _zip = "";
                                                $.each(_props, function (j, prop) {
                                                    if (prop.propNm == "addrLn1") {
                                                        _seconValObj[0].propVal = prop.propVal;
                                                    }
                                                    else if (prop.propNm == "addrLn2") {
                                                        _seconValObj[1].propVal = prop.propVal;
                                                    } else if (prop.propNm == "addrLn3") {
                                                        _seconValObj[2].propVal = prop.propVal;
                                                    } else if (prop.propNm == "cntryNm") {
                                                        _seconValObj[4].propVal = prop.propVal;
                                                    } else if (prop.propNm == "ctyNm") {
                                                        _city = prop.propVal;
                                                    } else if (prop.propNm == "stCd") {
                                                        _state = prop.propVal;
                                                    } else if (prop.propNm == "postlCd") {
                                                        _zip = prop.propVal;
                                                    }
                                                });
                                                _cityStateZip.propVal = _city + " " + _state + " " + _zip;
                                                _seconValObj[3] = _cityStateZip;
                                                _itemSecondaryVals.push(_seconValObj);
                                            });
                                        }
                                    }
                                    break;
                                case "nonfunceml":
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "emlAddr") {
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    });
                                    break;

                                case "rmdremain":
                                    //if (item.itemStatCd == "opn") {
                                    var prop1 = {
                                        "propNm": "line1",
                                        "propVal": "Review all eligible accounts with Ameriprise or other firms to determine remaining RMD amount.<br><br>If an annuitization has occurred this year, you must verify whether this impacts the RMD distribution calculation."
                                    }
                                    _itemSecondaryVals.push([prop1]);
                                    //}
                                    break;

                                case "rmdunkwn":
                                    //if (item.itemStatCd == "opn") {
                                        var prop1 = {
                                            "propNm": "line1",
                                            "propVal": "Review all eligible Ameriprise accounts or other firms to determine remaining RMD amount.<br><br>Once RMD is fulfilled, this item will continue to display until you manually postpone it."
                                        }
                                        _itemSecondaryVals.push([prop1]);
                                    //}
                                    break;

                                case "bnkreauth":
                                    var _bank = "";
                                    var _accb = "";
                                    var _prop = {
                                        'propNm': "BankDetails",
                                        'propVal': ''

                                    }
                                    $.each(item.cpLstItmIds, function (i, data) {
                                       _bank = "";
                                       _accb = "";
                                       _prop = {
                                           'propNm': "BankDetails",
                                           'propVal': ''

                                       };
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "finInstnNm") {
                                                _bank = prop.propVal;
                                            }
                                            if (prop.propNm == "finInstnMskBnkAcctId") {
                                                _accb = prop.propVal;
                                                //_accb = _accb.replace( /\*/g, "");
                                            }
                                            //var _bank = data.props[0].propVal;
                                            //var _accb = data.props[1].propVal.substring(3, 7)
                                            //prop.propVal = _bank +" "+ _accb;
                                                                              
                                        });
                                        _prop.propVal = _bank + " - " + _accb;
                                        _itemSecondaryVals.push([_prop]);
                                    });

                                    break;

                                case "bnkrenw":
                                    var _bank = "";
                                    var _accb = "";
                                    var _prop = {
                                        'propNm': "BankDetails",
                                        'propVal': ''

                                    }
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        _bank = "";
                                        _accb = "";
                                        _prop = {
                                            'propNm': "BankDetails",
                                            'propVal': ''

                                        };
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "finInstnNm") {
                                                _bank = prop.propVal;
                                            }
                                            if (prop.propNm == "finInstnMskBnkAcctId") {
                                                _accb = prop.propVal;
                                                //_accb = _accb.replace(/\*/g, "");
                                            }
                                            //var _bank = data.props[0].propVal;
                                            //var _accb = data.props[1].propVal.substring(3, 7)
                                            //prop.propVal = _bank +" "+ _accb;

                                        });
                                        _prop.propVal = _bank + " - " + _accb;
                                        _itemSecondaryVals.push([_prop]);
                                    });

                                    break;
                                case "acctsuitmis":
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "acctId") {
                                                var _adminCd = prop.propVal.substr(0, 3);
                                                prop.adminCd = _adminCd;
                                                prop.acctId = prop.propVal;
                                                if (_adminCd == 134) {
                                                    prop.propVal = "CARRIER #NA";
                                                } else {
                                                    prop.propVal = "Account# " + self.formatACcountNum(prop.propVal);
                                                }
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    });
                                    break;
                                case "missacctbeneinfo":
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "acctId") {
                                                var _adminCd = prop.propVal.substr(0,3);
                                                prop.adminCd = _adminCd;
                                                prop.acctId = prop.propVal;
                                                if (_adminCd == 134) {
                                                    prop.propVal = "CARRIER #NA";
                                                } else {
                                                prop.propVal = "Account# " + self.formatACcountNum(prop.propVal);
                                                }
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    });
                                    break;
                                case "nobenecliovr":
                                    var _secondaryItemCounter = 0;
                                    var _prop = {
                                        propNm: "acctId",
                                        propVal: "<p>The client has eligible account(s) that don't have beneficiary designations.</p><p>Note: It is recommended that all eligible accounts have beneficiary designations, even if a designation may not be required.</p>"
                                    };
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "acctId") {
                                                var _adminCd = prop.propVal.substr(0, 3);
                                                prop.adminCd = _adminCd;
                                                prop.acctId = prop.propVal;
                                                if (_adminCd == 134) {
                                                    prop.propVal = "CARRIER #NA";
                                                } else {
                                                    prop.propVal = "Account# " + self.formatACcountNum(prop.propVal);
                                                }
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    });
                                    if (_secondaryItemCounter > 0) {
                                        _itemSecondaryVals.unshift([_prop]);
                                    }
                                    break;
                                case "fidrepapreq":
                                   
                                        var _secondaryItm = { "propNm": "staticText", "propVal": "If your client has an established Power of Attorney or has a legally appointed Guardian or Conservator, please submit the correct paperwork to the Corporate Office as soon as possible.<br>Please note that if your client has a springing POA and is not yet incapacitated, nothing is needed at this time." };
                                        // Condition commented for Defect 1290 - Fiduciary repaper need to allow all the other type of entity also.
                                        /*if (_isOrgClient) {
                                            //corporation = 01, trust = 07,08
                                            if (_formofBusnsCd == "01") {
                                                _newGapItem.set("itemTypDesc", "No Authorized Signers are documented with the corporate office");
                                                _secondaryItm.propVal = "Your client's corporation or entity does not have a documented Corporate or Entity Resolution on file. <br/>";
                                                _secondaryItm.propVal += "If your client has completed the Ameriprise Corporate or Entity Resolution (form #402400), please submit to the corporate office via eFile delivery.<br/>";
                                                _secondaryItm.propVal += "If your client has not completed the Ameriprise Corporate or Entity Resolution form, please have them complete one ASAP.<br/>";
                                            } else if (_formofBusnsCd == "07" || _formofBusnsCd == "08") {
                                                _newGapItem.set("itemTypDesc", "No Trustees are documented with the corporate office");
                                                _secondaryItm.propVal = "Your client's trust does not have a documented Certificate of Trust on file.<br/>";
                                                _secondaryItm.propVal += "If your client has completed the Ameriprise Certificate of Trust (form #131202), please submit to the corporate office via eFile delivery.<br/>";
                                                _secondaryItm.propVal += "If your client has not completed the Ameriprise Certificate of Trust, please have them complete one ASAP.<br/>";
                                            }
                                            else if (_formofBusnsCd == "02" || _formofBusnsCd == "03" || _formofBusnsCd == "04" || _formofBusnsCd == "05" || _formofBusnsCd == "06" || _formofBusnsCd == "09" || _formofBusnsCd == "10" || _formofBusnsCd == "99" || _formofBusnsCd == "0") {
                                                _newGapItem.set("viewDisplay", false);
                                                
                                            }
                                        }*/
                                        if (_isOrgClient) {
                                           if (_formofBusnsCd == "07" || _formofBusnsCd == "08") {
                                                _newGapItem.set("itemTypDesc", "No Trustees are documented with the corporate office");
                                                _secondaryItm.propVal = "Your client's trust does not have a documented Certificate of Trust on file.<br/>";
                                                _secondaryItm.propVal += "If your client has completed the Ameriprise Certificate of Trust (form #131202), please submit to the corporate office via eFile delivery.<br/>";
                                                _secondaryItm.propVal += "If your client has not completed the Ameriprise Certificate of Trust, please have them complete one ASAP.<br/>";
                                            } else  {
                                                _newGapItem.set("itemTypDesc", "No Authorized Signers are documented with the corporate office");
                                                _secondaryItm.propVal = "Your client's corporation or entity does not have a documented Corporate or Entity Resolution on file. <br/>";
                                                _secondaryItm.propVal += "If your client has completed the Ameriprise Corporate or Entity Resolution (form #402400), please submit to the corporate office via eFile delivery.<br/>";
                                                _secondaryItm.propVal += "If your client has not completed the Ameriprise Corporate or Entity Resolution form, please have them complete one ASAP.<br/>";                                                
                                            }
                                        }
                                        _itemSecondaryVals.push([_secondaryItm]);
                                    
                                    break;
                                case "lstbeneupdt":
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "lastUpdtDate" && prop.propVal != null) {
                                                var date = prop.propVal;
                                                prop.propVal = date.substring(4, 6) + "/" + date.substring(6, 8) + "/" + date.substring(0, 4);
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    }); break;

                                case "clisuitmis":
                                    var _secondaryItems = HOCMatrix.secondaryItems[item.itemTypCd];
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (_secondaryItems != undefined && _secondaryItems[prop.propNm] != undefined) {
                                                prop.propVal = _secondaryItems[prop.propNm];
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    });
                                    break;
                                case "clisuitupdt":
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "lstUpdtTs" && prop.propVal !=null) {
                                                var date=prop.propVal;
                                                prop.propVal=date.substring(5, 7) + "/" + date.substring(8, 10) + "/" + date.substring(0, 4);
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    }); break;
                                case "emplinfomis":
                                    var _secondaryItems = HOCMatrix.secondaryItems[item.itemTypCd];
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (_secondaryItems != undefined && _secondaryItems[prop.propNm] != undefined) {
                                                prop.propVal = _secondaryItems[prop.propNm];
                                                _itemSecondaryVals.push([prop]);
                                            }


                                        });
                                    });
                                    break;
                                case "uncrttin":
                                    var _secondaryItems = HOCMatrix.secondaryItems[item.itemTypCd];
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (_secondaryItems != undefined && _secondaryItems[prop.propVal] != undefined) {
                                                prop.propVal = _secondaryItems[prop.propVal];
                                                _itemSecondaryVals.push([prop]);
                                            }
                                        });
                                    });
                                    break;
                                case "ytd":
                                    var _secondaryItems = HOCMatrix.secondaryItems[item.itemTypCd];
                                    /* define utility methods for getting the details */
                                    // gets the value of a specified property
                                    var getItemYear = function (item, property) {
                                        var year;
                                        $.each(item.props, function (j, prop) {
                                            if (prop.propNm == "ytdYear") {
                                               year = prop.propVal;
                                            }
                                        });
                                        return year;
                                    };
                                    // function used to get a detail string for an item
                                    var getItemString = function (item) {
                                        var _planDesc = "", _cntbAmt = "", _cntbTyp = ""
                                        $.each(item.props, function (j, prop) {
                                            switch (prop.propNm) {
                                                case "planDesc":
                                                    _planDesc = prop.propVal ? prop.propVal : "";
                                                    break;
                                                case "cntbAmt":
                                                    _cntbAmt = Number(prop.propVal).toFixed(2);
                                                    break;
                                                case "cntbTyp":
                                                    if (_secondaryItems != undefined && _secondaryItems[prop.propVal] != undefined) {
                                                        _cntbTyp = _secondaryItems[prop.propVal];
                                                    }
                                                    break;
                                                default:
                                                    break;
                                            }
                                        });
                                        return _planDesc + " - $" + _cntbAmt + " " + _cntbTyp;
                                    }

                                    // determine the current year
                                    // the current year is always the later year
                                    var years = [];
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        if (-1 == years.indexOf(getItemYear(data))) {
                                            years.push(getItemYear(data));
                                        }
                                    });
                                    var currentYear, prevYear;
                                    if (years.length > 1 ){ 
                                        if (years[0] < years[1]) {
                                            currentYear = years[1];
                                            prevYear = years[0];
                                        } else {
                                            currentYear = years[0];
                                            prevYear = years[1];
                                        }
                                    } else {
                                        currentYear = years[0];
                                    }
                                    // create the section header(s)
                                    var curYearStr, prevYearStr = "";
                                    curYearStr= "<div class='pt-data-label'>Current Year (" + currentYear + ")</div>"
                                    if (prevYear != undefined) {
                                        prevYearStr = "<div class='pt-data-label'>Prior Year (" + prevYear + ")</div>"
                                    }
                                    // put the details for each item under the appropriate header
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        if (getItemYear(data) === currentYear) {
                                            curYearStr += "<div>" + getItemString(data) + "</div>";
                                        } else {
                                            prevYearStr += "<div>" + getItemString(data) + "</div>";
                                        }
                                    });
                                    // push each section to display it
                                    _itemSecondaryVals.push([{ "propNm": "curYearDtls", "propVal": curYearStr }]);
                                    // only push prev year if present
                                    if (prevYearStr != undefined) { // only push prev year if present
                                        _itemSecondaryVals.push([{ "propNm": "prevYearDtls", "propVal": prevYearStr }]);
                                    }
                                    break;
                                case "nofidwthclnt":
                                    if (_showFiduciaryItem) {
                                        var _secondaryItm = { "propNm": "staticText", "propVal": "If your client has an established Power of Attorney or has a legally appointed Guardian or Conservator, submit the correct paperwork to the Corporate Office as soon as possible.<br/>If your client has a springing POA and is not yet incapacitated, nothing is needed at this time." };
                                        if (_isOrgClient) {
                                            //corporation = 01, trust = 07,08
                                            if (_formofBusnsCd == "01") {
                                                _newGapItem.set("itemTypDesc", "No Authorized Signers are documented with the Corporate Office");
                                                _secondaryItm.propVal = "Your client's trust does not have a documented Corporate or Entity Resolution on file.<br/>";
                                                _secondaryItm.propVal += "If your client has completed the Ameriprise Corporate or Entity Resolution (Form #402400), submit to the Corporate Office via eFile Delivery.<br/>";
                                                _secondaryItm.propVal += "If your client has not completed the Ameriprise Corporate or Entity Resolution form, have them complete one as soon as possible.<br/>";
                                            } else if (_formofBusnsCd == "07" || _formofBusnsCd == "08") {
                                                _newGapItem.set("itemTypDesc", "No Trustees are documented with the Corporate Office");
                                                _secondaryItm.propVal = "Your client's trust does not have a documented Certificate of Trust on file.<br/>";
                                                _secondaryItm.propVal += "If your client has completed the Ameriprise Certificate of Trust (Form #131202), submit to the Corporate Office via eFile Delivery.<br/>";
                                                _secondaryItm.propVal += "If your client has not completed the Ameriprise Certificate of Trust, have them complete one as soon as possible.<br/>";
                                            }      
                                        }
                                        _itemSecondaryVals.push([_secondaryItm]);
                                    }
                                    break;
                                case "ppaconsent":
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            if (prop.propNm == "acctId") {
                                                var _adminCd = prop.propVal.substr(0,3);
                                                prop.adminCd = _adminCd;
                                                prop.acctId = prop.propVal;
                                                if (_adminCd == 134) {
                                                    prop.propVal = "CARRIER #NA";
                                                } else {
                                                prop.propVal = "Account# " + self.formatACcountNum(prop.propVal);
                                                }
                                                _itemSecondaryVals.push([prop]);
                                            }

                                        });
                                    });
                                    break;
                                case "brkgCliFee":
                                        _custValues = {};
                                        if (item.cpLstItmIds.length > 0) {
                                            $.each(item.cpLstItmIds, function (i, clientFeeBlck) {
                                                _seconValObj = [
                                                {
                                                    "propNm": "acctInfo",
                                                    "propVal": "Account#:&ndash;",
                                                    "propValFromServc":null
                                                }, {
                                                    "propNm": "prevFee",
                                                    "propVal": "",
                                                    "propValFromServc": null
                                                }, {
                                                    "propNm": "newFee",
                                                    "propVal": "",
                                                    "propValFromServc": null
                                                }, {
                                                    "propNm": "changeDetail",
                                                    "propVal": "",
                                                    "propValFromServc": null
                                                }
                                            ];
                                                var _props = clientFeeBlck.props, _duplicateSecItem, _planActtInfo = [];
                                                $.each(_props, function (j, prop) {
                                                    if (prop.propNm == "acctNbr") {
                                                        var _planIdProp = _props.find(function (scndrItem) {
                                                            return scndrItem.propNm == "planId";
                                                        }),
                                                        _planId = _planIdProp ? _planIdProp.propVal.trim() : "";
                                                        if (_planId) {
                                                            try {
                                                                _duplicateSecItem = _itemSecondaryVals.find(function (secItems) {
                                                                    return secItems.find(function (item) {
                                                                        return item.propValFromServc == _planId;
                                                                    });
                                                                });
                                                                _planActtInfo.push({
                                                                    "propNm": "acctInfo",
                                                                    "propVal": "Account#: " + (CommonUtility.hasValue(prop.propVal) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;'),
                                                                    "propValFromServc": null
                                                                });
                                                            } catch (e) {
                                                                ErrorLog.ErrorUtils.myError(e);
                                                            }
                                                            _seconValObj[0].propValFromServc = _planId;
                                                            _seconValObj[0].propVal = "Plan ID: " + (_planId ? _planId.formatAccountIdOrPlanId() : '&ndash;');

                                                        } else {
                                                            _seconValObj[0].propVal = "Account#: " + (CommonUtility.hasValue(prop.propVal) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;');
                                                        }

                                                    } else if (prop.propNm == "actionStatus") {
                                                    _custValues.actionStatus = prop.propVal?prop.propVal.toUpperCase():"";
                                                    } else if (prop.propNm == "prevFee") {
                                                        _seconValObj[1].propVal = "Old Fee: " + (CommonUtility.hasValue(prop.propVal) ? prop.propVal.formatMoney(): '&ndash;');
                                                    } else if (prop.propNm == "newFee") {
                                                        _seconValObj[2].propVal = "New Fee: " +(CommonUtility.hasValue(prop.propVal) ? prop.propVal.formatMoney(): '&ndash;');
                                                    } else if (prop.propNm == "acctImpact") {
                                                        _seconValObj[3].propVal = "Impact to account: " + (CommonUtility.hasValue(prop.propVal) ? prop.propVal : '&ndash;');
                                                    } else if (prop.propNm == "uniqueId") {
                                                        _custValues.uniqueId = prop.propVal;
                                                    }
                                                });
                                                try {
                                                    var _duplicatePlanActtInfo;
                                                    if (_duplicateSecItem) {
                                                        _duplicatePlanActtInfo = _duplicateSecItem.splice(0, 1).concat(_planActtInfo);
                                                        _duplicateSecItem.unshift.apply(_duplicateSecItem, _duplicatePlanActtInfo);
                                                    } else {
                                                        if (_planActtInfo) {
                                                            _duplicatePlanActtInfo = _seconValObj.splice(0, 1).concat(_planActtInfo);
                                                            _seconValObj.unshift.apply(_seconValObj, _duplicatePlanActtInfo);
                                                        }
                                                        _itemSecondaryVals.push(_seconValObj);
                                                    }
                                                } catch (e) {
                                                    ErrorLog.ErrorUtils.myError(e);
                                                }
                                            });
                                        }
                                        _newGapItem.set('customValues', _custValues);
                                    break;
                                case "admnFeeChg":
                                case "mngChg":
                                case "rmvNonBillPos":
                                case "sersClos":
                                case "ctiPosUnwrp":
                                        _custValues = {};
                                        if (item.cpLstItmIds.length > 0) {
                                            $.each(item.cpLstItmIds, function (i, clientAcctBlck) {
                                                var _props = clientAcctBlck.props;
                                                $.each(_props, function (j, prop) {
                                                    if (prop.propNm == "changeDetail" && item.itemTypCd != "ctiPosUnwrp" && item.itemTypCd != "brkgCliFee") {
                                                        _itemSecondaryVals.unshift([prop]);
                                                    } if (prop.propNm == "actionStatus") {
                                                        _custValues.actionStatus = prop.propVal?prop.propVal.toUpperCase(): "";
                                                    } else if (prop.propNm == "acctNbr") {
                                                        var _acctInfo = { "propNm": "acctInfo", "propVal": "" },
                                                            _prodName = _props.find(function (_prop) { return _prop.propNm == "prodName"; }),
                                                            _accountVal = "Account# " + self.formatDOLAccountNum(prop.propVal) + ' - ' + (_prodName ? _prodName.propVal : "");
                                                        _acctInfo.propVal = _accountVal;
                                                        _itemSecondaryVals.push([_acctInfo]);
                                                    } else if (prop.propNm == "uniqueId") {
                                                        _custValues.uniqueId = prop.propVal;
                                                    }
                                                });
                                            });
                                        }
                                        _newGapItem.set('customValues', _custValues);
                                        break;
                                case "febSpsAdvRpt":
                                case "marSpsAdvRpt":
                                case "maySpsAdvRpt":
                                    _custValues = {};
                                    if (item.cpLstItmIds.length > 0) {
                                        $.each(item.cpLstItmIds, function (i, secItems) {
                                            _seconValObj = [
                                            {
                                                "propNm": "acctInfo",
                                                "propVal": "Account#:&ndash;",
                                                "propValFromServc": null
                                            },
                                            {
                                                "propNm": "tkrSmbl",
                                                "propVal": "",
                                                "propValFromServc": null
                                            },
                                            {
                                                "propNm": "trdAmt",
                                                "propVal": "",
                                                "propValFromServc": null
                                            }
                                            ];
                                            $.each(secItems.props, function (j, prop) {
                                                if (prop.propNm == "changeDetail") {
                                                    _itemSecondaryVals.unshift([prop]);
                                                } else if (prop.propNm == "acctNbr") {
                                                    _seconValObj[0].propVal = "Account# " + (CommonUtility.hasValue(prop.propVal) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;');
                                                } else if (prop.propNm == "tkrSmbl") {
                                                    _seconValObj[1].propVal = "Ticker symbol: " + (CommonUtility.hasValue(prop.propVal) ? prop.propVal : '&ndash;');
                                                } else if (prop.propNm == "trdAmt") {
                                                    _seconValObj[2].propVal = "Trade amount: " + (CommonUtility.hasValue(prop.propVal) ? prop.propVal.formatMoney() : '&ndash;');
                                                } else if (prop.propNm == "uniqueId") {
                                                    _custValues.uniqueId = prop.propVal;
                                                } else if (prop.propNm == "actionStatus") {
                                                    _custValues.actionStatus = prop.propVal ? prop.propVal.toUpperCase() : "";
                                                }
                                            });
                                            _itemSecondaryVals.push(_seconValObj);
                                        });

                                    }
                                    if (item.itemStatCd == "ni" && !_custValues.actionStatus) {
                                        if (item.itemTypCd == "febSpsAdvRpt") {
                                            _newGapItem.set("itemTypDesc", "Periodic Mutual Fund arrangement impacted during the SPS <i>Advantage</i> share class conversion in February");
                                        }
                                        if (item.itemTypCd == "marSpsAdvRpt") {
                                            _newGapItem.set("itemTypDesc", "Periodic Mutual Fund arrangement impacted during the SPS <i>Advantage</i> share class conversion in March");
                                        }
                                    }
                                    _newGapItem.set('customValues', _custValues);

                                    break;
                                case "convColumbiaAcct":
                                    
                                        _custValues = {};
                                        if (item.cpLstItmIds.length > 0) {
                                            $.each(item.cpLstItmIds, function (i, secItems) {
                                                _seconValObj = [
                                                {
                                                    "propNm": "frmAcctNbr",
                                                    "propVal": "",
                                                    "propValFromServc": null
                                                },
                                                {
                                                    "propNm": "toAcctNbr",
                                                    "propVal": "",
                                                    "propValFromServc": null
                                                }
                                                ];
                                                $.each(secItems.props, function (j, prop) {
                                                    if (prop.propNm == "changeDetail") {    //
                                                        //_seconValObj[0].propVal = prop.propVal;
                                                        _itemSecondaryVals.unshift([prop]);
                                                    }
                                                    else if (prop.propNm == "frmAcctNbr") { //
                                                        _seconValObj[0].propVal = "From account# " + (CommonUtility.hasValue(prop.propVal) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;');
                                                    }
                                                    else if (prop.propNm == "toAcctNbr") {  //
                                                        _seconValObj[1].propVal = "To account# " + (CommonUtility.hasValue(prop.propVal) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;');
                                                    } else if (prop.propNm == "uniqueId") {
                                                        _custValues.uniqueId = prop.propVal;
                                                    } else if (prop.propNm == "actionStatus") {
                                                        _custValues.actionStatus = prop.propVal ? prop.propVal.toUpperCase() : "";
                                                    }
                                                });
                                                _itemSecondaryVals.push(_seconValObj);
                                            });

                                        }
                                        if (item.itemStatCd == "ni" && (_custValues.actionStatus == "Action Needed" || _custValues.actionStatus == "Open")) {
                                            _newGapItem.set("itemTypDesc", "Action Taken - CONSOLIDATED UNLESS OPTED OUT: Converted Columbia Account Consolidation");
                                        }
                                        _newGapItem.set('customValues', _custValues);
                                        break;
                                case "lgcyColMutFund2":
                                    _custValues = {};
                                    if (item.cpLstItmIds.length > 0) {
                                        $.each(item.cpLstItmIds, function (i, secItems) {
                                            _seconValObj = [
                                            {
                                                "propNm": "arrTypDesc",
                                                "propVal": "",
                                                "propValFromServc": null
                                            },
                                             {
                                                 "propNm": "frmAcctNbr",
                                                 "propVal": "",
                                                 "propValFromServc": null
                                             },
                                            {
                                                "propNm": "toAcctNbr",
                                                "propVal": "",
                                                "propValFromServc": null
                                            }
                                            ];
                                            $.each(secItems.props, function (j, prop) {
                                                if (prop.propNm == "acctImpDesc") { 
                                                    _itemSecondaryVals.unshift([prop]);
                                                }
                                                else if (prop.propNm == "arrTypDesc") { 
                                                    _seconValObj[0].propVal = "Arrangement Type: " + (CommonUtility.hasValue(prop.propVal) ? prop.propVal : '&ndash;');
                                                }
                                                else if (prop.propNm == "frmAcctNbr") {
                                                    _seconValObj[1].propVal = "From account# " + ((CommonUtility.hasValue(prop.propVal) ) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;');
                                                }
                                                else if (prop.propNm == "toAcctNbr") {
                                                    _seconValObj[2].propVal = "To account# " + ((CommonUtility.hasValue(prop.propVal)) ? self.formatDOLAccountNum(prop.propVal) : '&ndash;');
                                                } else if (prop.propNm == "uniqueId") {
                                                    _custValues.uniqueId = prop.propVal;
                                                } 
                                            });
                                            _itemSecondaryVals.push(_seconValObj);
                                        });

                                    }
                                    _newGapItem.set('customValues', _custValues);
                                    break;

                                case "clientRetentionRisk":                                  
                                    var _descProp = [{
                                        'propNm': "staticTxt",
                                        'propVal': 'Directional data suggests this client may be at risk of leaving Ameriprise.  Take action to deepen your relationship with the client.'
                                    }]
                                    var _finalIndicators = [{
                                        'propNm': "finalIndicators",
                                        'propVal': ''
                                    }]                                    
                                    var _finalIndicatorText = "", actionStatus = "", plannedAction = "";
                                    var _contactIndText = "", _acctActivityIndText = "", _relationshipDepthText = "", _digitalIndText = "", _demographicIndText = "";
                                    _custValues = {};

                                    $.each(item.cpLstItmIds, function (i, secItems) {                                       
                                        var tmpProp;
                                        $.each(secItems.props, function (j, prop) {
                                            tmpProp = [{ 'propNm': '', 'propVal': '' }];
                                            if ((prop.propNm == "contactInd")) {
                                            	var accActivityInd = CommonUtility.hasValue(prop.propVal) ? prop.propVal : '';
                                            	if (accActivityInd != '') {
                                            		var arrayIndicators = prop.propVal.split('|');
                                            		for (i = 0; i < arrayIndicators.length; i++) {
                                            			_contactIndText = _contactIndText + '<li>' + arrayIndicators[i] + '</li>';
                                            		}
                                            	}
                                            }
                                            if ((prop.propNm == "acctActivityInd")) {
                                            	var accActivityInd = CommonUtility.hasValue(prop.propVal) ? prop.propVal : '';
                                            	if (accActivityInd != '') {
                                            		var arrayIndicators = prop.propVal.split('|');
                                            		for (i = 0; i < arrayIndicators.length; i++) {
                                            			_acctActivityIndText = _acctActivityIndText + '<li>' + arrayIndicators[i] + '</li>';
                                            		}
                                            	}
                                            }
                                            if ((prop.propNm == "relationshipDepthInd")) {
                                            	var accActivityInd = CommonUtility.hasValue(prop.propVal) ? prop.propVal : '';
                                            	if (accActivityInd != '') {
                                            		var arrayIndicators = prop.propVal.split('|');
                                            		for (i = 0; i < arrayIndicators.length; i++) {
                                            			_relationshipDepthText = _relationshipDepthText + '<li>' + arrayIndicators[i] + '</li>';
                                            		}
                                            	}
                                            }
                                            if ((prop.propNm == "digitalInd")) {
                                            	var accActivityInd = CommonUtility.hasValue(prop.propVal) ? prop.propVal : '';
                                            	if (accActivityInd != '') {
                                            		var arrayIndicators = prop.propVal.split('|');
                                            		for (i = 0; i < arrayIndicators.length; i++) {
                                            			_digitalIndText = _digitalIndText + '<li>' + arrayIndicators[i] + '</li>';
                                            		}
                                            	}
                                            }
                                            if ((prop.propNm == "demographicInd")) {
                                            	var accActivityInd = CommonUtility.hasValue(prop.propVal) ? prop.propVal : '';
                                            	if (accActivityInd != '') {
                                            		var arrayIndicators = prop.propVal.split('|');
                                            		for (i = 0; i < arrayIndicators.length; i++) {
                                            			_demographicIndText = _demographicIndText + '<li>' + arrayIndicators[i] + '</li>';
                                            		}
                                            	}
                                            }
                                            else if (prop.propNm == "uniqueId") {
                                                _custValues.uniqueId = prop.propVal;
                                            }
                                            else if (prop.propNm == "actionStatus") {
                                                actionStatus = prop.propVal;
                                            }
                                            else if (prop.propNm == "plannedAction") {
                                                plannedAction = prop.propVal;
                                            }

                                        });                                                                               
                                    });                                   
                                    _finalIndicatorText = _contactIndText + _acctActivityIndText + _relationshipDepthText + _digitalIndText + _demographicIndText;

                                    var currentActions = [];
                                    if (actionStatus == "ACTION NEEDED") {
                                        _newGapItem.set("itemTypDesc", "Deepen Client Relationship");
                                        $.each(hocItemMatrix.actions, function (index, action) {
                                            if ((action.actionId != "hocAction35") && (action.actionId != "hocAction57")) {
                                                currentActions.push(action);
                                            }
                                        }); 
                                    } else if (actionStatus == "ACTION IN PROGRESS") {
                                        _newGapItem.set("itemTypDesc", "Complete Planned Action");
                                        if (plannedAction != null && plannedAction != "") {
                                            _descProp[0].propVal = "Planned Action: " + plannedAction;
                                        }
                                        $.each(hocItemMatrix.actions, function (index, action) {
                                            if (action.actionId != "hocAction56") {
                                                currentActions.push(action);
                                            }
                                        });
                                    }

                                    if (currentActions.length > 0) {
                                        hocItemMatrix.actions = currentActions;
                                    }

                                    if (_finalIndicatorText != "") {
                                        _finalIndicators[0].propVal = '<ul class="list-style-disc padding-left-18">' + _finalIndicatorText + '</ul>';
                                        _itemSecondaryVals.push(_descProp);
                                        _itemSecondaryVals.push(_finalIndicators);
                                        _newGapItem.set('customValues', _custValues);
                                    }
                                    break;
                                default:
                                    $.each(item.cpLstItmIds, function (i, data) {
                                        $.each(data.props, function (j, prop) {
                                            _itemSecondaryVals.push([prop]);
                                        });
                                    })
                                    break;
                            }
                            _newGapItem.set("values", _itemSecondaryVals);
                            _newGapItem.set("actions", hocItemMatrix.actions);
                            if (item.ctgCd == "1") {
                                _catgrySections = _takeActionSectionsModel;
                            } else if (item.ctgCd == "2") {
                                _catgrySections = _servcOppSectionsModel;
                            }
                            if (_catgrySections) {
                                self.updateSection(item, _newGapItem, _catgrySections);
                            }

                        }

                    }
                });
                
            }
        },
        updateCategory: function (ctgCd,ctgryListItemsResponse) {
            var _ctgry = this.get("categories").find(function (ctgry) {
                return ctgry.ctgCd == ctgCd;
            });
            $.each(_ctgry.sections, function(sectnIndx,section) {
                section.set("gapItems", []);
            });
            self.parseItems(ctgryListItemsResponse);
            self.sortSections(_ctgry.sections);
        },
        updateSection: function (item, _newGapItem, sections) {
            var _isOrgClient = self.get('isOrgClient'),
                _showFiduciaryItem = self.get('showFiduciaryItem'),
                _CPData = CPViewModel.getInstance().getData().cola,
                clientAge = self.get('clientAge');
            if (item.ctgCd == "1") {
                if(item.itemStatCd == "opn") {
                    sections.find(function(sectn) {
                        return sectn.get("sectionId") == "opn";
                    }).get("gapItems").push(_newGapItem);
                } else if (item.itemStatCd == "psp") {
                    sections.find(function(sectn) {
                        return sectn.get("sectionId") == "psp";
                    }).get("gapItems").push(_newGapItem);
                } else if (item.itemStatCd == "ni") {
                    if (item.itemTypCd == "nonfunceml") {
                        if (_CPData.clientEmails.length > 0) {
                            sections.find(function(sectn) {
                                return sectn.get("sectionId") == "ni";
                            }).get("gapItems").push(_newGapItem);
                        }
                    } else if ((item.itemTypCd == "rmdremain") && (_isOrgClient == true)) {
                        _newGapItem.set("viewDisplay", false);//do not show in validated section
                    } else {
                        sections.find(function(sectn) {
                            return sectn.get("sectionId") == "ni";
                        }).get("gapItems").push(_newGapItem);
                    }

                } else if (item.itemStatCd == "dna") {
                    sections.find(function(sectn) {
                                return sectn.get("sectionId") == "dna";
                    }).get("gapItems").push(_newGapItem);
                }
            }
            else if (item.ctgCd == "2") {
                var _orgNm = _CPData.orgClient.get("orgNm");
                if (!(item.itemTypCd == "nobenecliovr" && _isOrgClient) && !(item.itemTypCd == "nofidwthclnt" && !_showFiduciaryItem)) {
                    if(item.itemStatCd == "opn") {
                        sections.find(function(sectn){
                            return sectn.get("sectionId") == "opn";
                        }).get("gapItems").push(_newGapItem);
                    } else if (item.itemStatCd == "psp") {
                        sections.find(function(sectn) {
                            return sectn.get("sectionId") == "psp";
                        }).get("gapItems").push(_newGapItem);
                    } else if (item.itemStatCd == "ni") {
                        if ((item.itemTypCd == "edelivpref" || item.itemTypCd == "totlvwreg" || item.itemTypCd == "myfareg") && (_isOrgClient == true || (clientAge != undefined && clientAge < 18))) {
                                _newGapItem.set("viewDisplay", false);
                        } else if (item.itemTypCd == "myfareg" && item.itemStatDesc == "No Issue" && _orgNm == null && _CPData.clientPersonal.attributes.decsdInd === "Y") {
                                _newGapItem.set("viewDisplay", false);
                        } else if(((item.itemTypCd == "nobenecliovr") && (clientAge != undefined && clientAge < 70))) { //do not show in validated section
                                    _newGapItem.set("viewDisplay", false);
                        } else {
                            sections.find(function(sectn) {
                                return sectn.get("sectionId") == "ni";
                            }).get("gapItems").push(_newGapItem);
                        }
                    } else if (item.itemStatCd == "dna") {
                        sections.find(function(sectn) {
                                return sectn.get("sectionId") == "dna";
                        }).get("gapItems").push(_newGapItem);
                    }
                }

            }
        },
        sortSections: function (sections) {
            $.each(sections, function (i, section) {
                    section.get("gapItems").sort(function (a, b) {
                        if(a.get("orderIndex") == b.get("orderIndex")) return 0;
                        if (a.get("orderIndex") > b.get("orderIndex")) return 1;
                        return -1;
                    });
            });
        },
        createSections: function (ctgCd) {
            var _openSection = new modelSection(),
                _postPonedSection = new modelSection(),
                _closedSection = new modelSection(),
                _dataNotFoundSection = new modelSection(),
                _fyiSection = new modelSection(),
                _sections;
            var _matrixOpenSectn = this.getMatrixSection({ "ctgCd": ctgCd, "sectionId": "opn" });
            _openSection.set({
                "sectionId": 'opn',
                "viewDisplay": _matrixOpenSectn.viewDisplay,
                "sectionColumns": _matrixOpenSectn.sectionColumns,
                "sectionDesc": _matrixOpenSectn.sectionDesc,
                "gapItems": []
            });
            var _matrixClosedSectn = this.getMatrixSection({ "ctgCd": ctgCd, "sectionId": "ni" });
            _closedSection.set({
                "sectionId": 'ni',
                "viewDisplay": _matrixClosedSectn.viewDisplay,
                "sectionColumns": _matrixClosedSectn.sectionColumns,
                "sectionDesc": _matrixClosedSectn.sectionDesc,
                "gapItems": []
            });
            var _matrixPostPoneddSectn = this.getMatrixSection({ "ctgCd": ctgCd, "sectionId": "psp" });
            _postPonedSection.set({
                "sectionId": 'psp',
                "viewDisplay": _matrixPostPoneddSectn.viewDisplay,
                "sectionColumns": _matrixPostPoneddSectn.sectionColumns,
                "sectionDesc": _matrixPostPoneddSectn.sectionDesc,
                "gapItems": []
            });
            var _matrixDataNotFoundSectn = this.getMatrixSection({ "ctgCd": ctgCd, "sectionId": "dna" });
                _dataNotFoundSection.set({
                    "sectionId": 'dna',
                    "viewDisplay": _matrixDataNotFoundSectn.viewDisplay,
                    "sectionColumns": _matrixDataNotFoundSectn.sectionColumns,
                    "sectionDesc": _matrixDataNotFoundSectn.sectionDesc,
                    "gapItems": []
                });
            _sections = {
                "open": _openSection,
                "closed": _closedSection,
                "dataNotFound": _dataNotFoundSection
            };
            _sections.postPoned = _postPonedSection
            return _sections;
        },
        getMatrixItem: function (gapItem) {
            var _category = HOCMatrix.categories.find(function (row) { return row.ctgCd == gapItem.ctgCd }), _section = {}
            var _matrixData = { "section": {}, "item": {}, "actions": [] };
            if (_category != null && _category != undefined) {
                _matrixData.section = _category.sections.find(function (row) {
                    return row.sectionId == gapItem.itemStatCd
                });
                _matrixData.item = _matrixData.section.items.find(function (row) { return row.itemTypCd == gapItem.itemTypCd });
                if (_matrixData.item != undefined && _matrixData.item != null) {
                    $.each(_matrixData.item.actions, function (i, action) {
                        var _action = HOCMatrix.actions.find(function (row) { return row.actionId == action.actionId });
                        if (_action != null && _action != undefined) {
                            _matrixData.actions.push(_action);
                        }
                    });
                } else {
                    _matrixData.item = {
                        "orderIndex": (_matrixData.section.items.length + 1)
                    };
                }

            }
            return _matrixData
        },
        getMatrixSection: function (options) {
            var _category = HOCMatrix.categories.find(function (row) { return row.ctgCd == options.ctgCd })
            return _category.sections.find(function (row) { return row.sectionId == options.sectionId });
        },
        sortItems: function (items) {
            items.sort(function (a, b) {
                if (a.get("orderIndex") == b.get("orderIndex")) return 0;
                if (a.get("orderIndex") > b.get("orderIndex")) return 1;
                return -1;
            });
        },
        formatACcountNum: function (acctNumber) {
            var _admnCd = acctNumber.substr(0, 3), _acctNum = acctNumber.substr(acctNumber.length - 12);
            var _fmtAcctNum = _acctNum.substr(0, 4) + " " + _acctNum.substr(4, 4) + " " + _acctNum.substr(8, 4) + " " + _admnCd;
            return _fmtAcctNum;
        },
        formatColumbiaACcountNum: function (acctNumber, admnCd) {
            if (!CommonUtility.hasValue(acctNumber) || isNaN(acctNumber) || !CommonUtility.hasValue(admnCd) || isNaN(admnCd)) {
                return "&ndash;";
            }
            var _shrkActNumlength = 12, _admnCdLength = 3, _accountNumPaddedToRequiredLnth = CommonUtility.padZeros(_shrkActNumlength, acctNumber.replace(/\s/g, ''));
            return _accountNumPaddedToRequiredLnth.substr(0, 4) + " " + _accountNumPaddedToRequiredLnth.substr(4, 4) + " " + _accountNumPaddedToRequiredLnth.substr(8, 4) + " " + CommonUtility.padZeros(_admnCdLength, admnCd);
        },
        formatDOLAccountNum: function (acctNumber) {
            var _fmtdAcctNum = "";
            if (CommonUtility.hasValue(acctNumber)) {
                if (acctNumber.indexOf("N/A") > -1) {
                    return "N/A";
                }
                var _accountNumPaddedToRequiredLnth = CommonUtility.padZeros(15, acctNumber.replace(/\s/g, ''));
                _fmtdAcctNum = _accountNumPaddedToRequiredLnth.substr(0, 4) + " " + _accountNumPaddedToRequiredLnth.substr(4, 4) + " " + _accountNumPaddedToRequiredLnth.substr(8, 4)
                                + " " + _accountNumPaddedToRequiredLnth.substr(12, 3);
            }
            return _fmtdAcctNum;
        },
        formatDate: function (date) {
            var _lastUpdateDate = date.substring(4, 6) + "/" + date.substring(6, 8) + "/" + date.substring(0, 4);
            return _lastUpdateDate;
        }
    });
    return new hocModel();
});