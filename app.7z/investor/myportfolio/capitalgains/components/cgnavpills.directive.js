/**
 * @ngdoc property
 * @name fticCgNavPills Directive
 * @requires advisorConstants 
 * @requires advisorEventConstants 
 * @requires fticLoggerMessage 
 * @requires loggerConstants 
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Capital Gains Account Statement details for selected Folio Number and Account Number
 *
 **/
'use strict';

var fticCgNavPills = function($scope, fticLoggerMessage, loggerConstants, $state, advisorEventConstants, fticgAccDetLoadInitialService, advisorEvents) {
    return {
        template: require('./cgaccfilter.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function ($scope, $element, $attrs) {
           $scope.navPillsOptions = [
        {
            btnName : 'Folio View',
            uibValue : 'folioview'
        },
        {
            btnName : 'Account View',
            uibValue : 'accountview'
        }
    ];

    $scope.btnColor = 'btn-group-sm green-btn-group pull-left';
    $scope.modelVal = 'folioview';  

    // $scope.modelValues = {
    //                 modelVal: 'folioview'                                        
    //             }

    $scope.pillSelect = function (param) {          
            $scope.modelVal = param;
           if(param == 'folioview'){
                $state.go("myinvestors.statements.capitalgains.cgfolioView");
            }  
            else if(param == 'accountview'){
                $state.go("myinvestors.statements.capitalgains.cgactview");
            }                                      
    }
     $state.go("myinvestors.statements.capitalgains.cgfolioView");
        },

        link: function(scope, iElement, iAttrs, controller) {}
    };
};

fticCgNavPills.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state','advisorEventConstants', 'fticgAccDetLoadInitialService', 'advisorEvents'];
module.exports = fticCgNavPills;