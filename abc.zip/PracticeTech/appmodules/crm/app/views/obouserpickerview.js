﻿define([
    'jquery',
    'underscore',
    'backbone',
    'appcommon/commonutility',
    'text!appmodules/crm/app/templates/obouserpickerview.html',
    'appcommon/analytics'
], function ($, _, Backbone, Util, OBOUserPickerTemplate) {
    /* Renders the list of OBO Users the signed on user can view and allows user to pick one */
    var OBOUserPickerView = Backbone.View.extend({
        userList: [],  // [{name: String, fmid: String}]
        selectedUserFmid: null,
        userSelected: null,  // callback with 1 parameter (String, user's FMID)
        template: _.template(OBOUserPickerTemplate),
        initializeElementVars: function () {
            this.$userList = this.$('[pt-obo-user-picker-list="' + this.pickerId() + '"]');
        },
        events: {
            "click [pt-obo-user-choice]": "handleUserPicked",
            "mouseover [pt-obo-user-choice]": "handleMouseOver"
        },
        initialize: function (options) {
            _.bindAll(this, 'renderView', 'handleKeyDown');
        },
        beforeClose: function () {
            this.hidePageOverlay();
        },
        render: function () {
            if (this.userList.length > 0) {
                // sort....signed on user must be first
                var signedOnFMID = Util.userFMID();
                this.userList.sort(function (a, b) {
                    if (a.fmid == signedOnFMID) {
                        return -1;
                    } else if (b.fmid == signedOnFMID) {
                        return 1;
                    } else {
                        return a.name.localeCompare(b.name);
                    }
                });
                this.renderView();
            }
        },
        renderView: function () {
            this.$el.html(this.template({ pickerId: this.pickerId(), users: this.userList, selectedFmid: this.selectedUserFmid }));
            this.initializeElementVars();
            this.showPageOverlay(this.pickerId());
            this.$userList.slideDown();
        },
        handleKeyDown: function (e) {
            if (e.which == 13) {
                this.handleEnter(e)
            } else if (e.which == 27) { // escape
                this.handleEscape(e);
            }
        },
        pickerId: function () {
            return this.$el.prop('id');
        },
        handleEnter: function (r) {
            this.handleSelection();
        },
        handleEscape: function (e) {
            this.dismiss();
        },
        handleUserPicked: function (e) {
            var $selectedUserElement = e.target.nodeName == "LI" ? this.$(e.target) : this.$(e.target).closest('li');
            this.selectedUserFmid = $selectedUserElement.attr('pt-obo-user-choice');
            this.handleSelection();
        },
        handleSelection: function () {
            this.refreshSelection();
            this.userSelected(this.selectedUserFmid);
            this.dismiss();
        },
        handleMouseOver: function (e) {
            var $selectedUserElement = e.target.nodeName == "LI" ? this.$(e.target) : this.$(e.target).closest('li');
            this.$('li').removeClass('active');
            $selectedUserElement.addClass('active');
            this.selectedUserFmid = $selectedUserElement.attr('pt-obo-user-choice');
        },
        dismiss: function () {
            this.$userList.slideUp();
            this.hidePageOverlay(this.pickerId());
            this.close();
        },
        showPageOverlay: function (userPicker) { // adds a transparent div that listens for any tap on page outside of the picker
            var self = this;
            var userPickerOverlay = userPicker+"-overlay"
            self.hidePageOverlay(this.pickerId());
            $('body').append("<div id=" + userPickerOverlay + " class='pt-transparent-overlay'></div>");
            $('#' + userPickerOverlay).on('click', function () {
                self.dismiss();
            });
            $('body').on('keydown', self.handleKeyDown);
        },
        hidePageOverlay: function (userPicker) {
            var userPickerOverlay = userPicker + "-overlay"
            var $overlay = $('#' + userPickerOverlay);
            if ($overlay.length > 0) {
                this.$el.css('z-index', 'auto');
                $overlay.remove();
                $('body').off('keydown', self.handleKeyDown);
            }
        },
        refreshSelection: function () {
            this.$userList.find('[pt-obo-user-choice]').removeClass('pt-default');
            this.$userList.find('[pt-obo-user-choice="' + this.selectedUserFmid + '"]').addClass('pt-default');
        }
    });
    return OBOUserPickerView;
});