/**
 * @ngdoc property
 * @name swpTxnController Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function DtpTxnController($scope, fticLoggerMessage, loggerConstants, $state, transactModel) {
    //console.info("SWP Txn Details Controller!!"+ $scope.header);
    //$scope.config.txnFormDetails.title = "Transaction Details";
    $scope.redirect = function () {
    	//transactModel.resetSetters(); 
        //transactModel.isNewInvestor = false;
    	//$state.go("invTransact.base.dtp");
    }
}

DtpTxnController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'transactModel'];
module.exports = DtpTxnController;