
if (typeof console == "undefined" || typeof console == undefined) {
	console = {};
	console.log = function() {
	};
}
define(
		[ 'jquery', 'underscore', 'backbone', 'backbonesubroute',
				'appcommon/memmorymgr',
				'appmodules/ncst/app/js/lib/validate-4.2',
				'appmodules/ncst/app/js/utils', 'config',
				'appmodules/ncst/app/js/utils','appcommon/globalcontext' ],
		function($, _, Backbone, backbonesubroute, Memorymangr, Validator,
				Utils, Config, Utils,GlobalContext) {
			Utils.setConfigProperty('BASE_URL', Config.odataServiceName);
			// console.log(Config,"Config")
			requirejs(
					[
					 'appmodules/ncst/app/js/models/model-client',
					'appmodules/ncst/app/data/country-list'],
					function(ClientModel,DropdownOptions) {
						 var ClientDetailsModel = ClientModel.get('details');
						requirejs(
								[

										'appmodules/ncst/app/js/views/view-address-entry',
										'appmodules/ncst/app/js/views/view-address-validation',
										'appmodules/ncst/app/js/views/view-client-details',
										'appmodules/ncst/app/js/views/view-employment',
										'appmodules/ncst/app/js/views/view-income-investment',
										'appmodules/ncst/app/js/views/view-verification',
										'appmodules/ncst/app/js/views/view-confirmation' ],
								function() {
									var APP_VERSION = Utils
											.getConfigProperty('APP_VERSION');
									// set the bas eurl in cutils js

									// add the version num and date
									// in footer only for e1
									var _versDateStng = APP_VERSION + '-'
											+ new Date().toDateString();
									$('#version-display').html(_versDateStng);
									document.addEventListener("touchstart",
											function() {
											}, true);
									initializeCustomSelect();
									initStepnavLinks();
									// bind events to obo select
									// list
									$(document)
											.off('keyup','#ncst-app input[type="text"]:not(.special-text-fields)')
											.on('keyup','#ncst-app input[type="text"]:not(.special-text-fields)',
													function(e) {
														e.which = e.which || e.keyCode;
														if (e.which == 13) {
															$('#ncst-app .next-button:visible').click();
														}});
									function initializeCustomSelect() {
										// plugin for custom select//
										$.fn.customizeSelect = function() {
											//$(this).wrap('<span class="select-wrapper"></span>');
											//$(this).after('<span class="holder pt-h5"></span>');
											$(this).trigger('change');
										};
										/*$(document)
												.off('change', '#ncst-user-home-view .custom-select')
												.on('change', '#ncst-user-home-view .custom-select',
														function() {
															var _$this = $(this), _class = "default-option-text";
															var _selectedOption = _$this
																	.find(':selected')
																	.text(), _selectedVal = _$this
																	.val();
															if (_selectedVal != "") {
																_$this
																		.next('.holder')
																		.text(
																				_selectedOption);

																_$this
																		.parent()
																		.removeClass(_class);

															} else {
																_$this
																		.next('.holder')
																		.text(
																				_selectedOption);
																_$this.parent().addClass(
																		_class);
															}

														}).trigger('change');*/
										// plugin for custom
										// select//
									}
									function initStepnavLinks() {
										$(document)
												.off('click',
														'.ncst-step:not(.active) .step-nav-links')
												.on(
														'click',
														'.ncst-step:not(.active) .step-nav-links',
														doStepNaviagation);
										$(document).off('click', '.ncst-step:not(.active)')
												.on(
														'click',
														'.ncst-step:not(.active)',
														function(e) {
															e.stopPropagation();
															$(this).find('a').trigger(
																	'click');
														});
										// rearrange navigation menu links

									}
									function doStepNaviagation(e) {
										var _context = GlobalContext.getInstance().getGlobalContext().Context;
	                                    var _qryStrng =  _context.QueryString ?_context.QueryString:'';
										e.stopPropagation();
										var _$this = $(this),$elForm;
										$elForm = $("#ncst-app").find("form");
										if(_$this.hasClass('click-disabled')){
											return;
										}
										
										var _returnVal = true;
										var historyFragment = Backbone.history.fragment;
										historyFragment = historyFragment.indexOf('/') > 0 ? historyFragment
												.substring(historyFragment.indexOf('/') + 1)
												: historyFragment;
										var _currentStep = Number($(
											'.ncst-step.active .step-nav-links').attr(
											'data-step-no'));
										var _qryStrng =_context.QueryString?_context.QueryString:'';
										historyFragment= historyFragment.substring(0,historyFragment.indexOf('?') !=-1?historyFragment.indexOf('?'):historyFragment.length);
										var _clickedStep = Number(_$this.attr('data-step-no')), _urlHash = 'ncst/' + _$this.attr('data-hash')+_qryStrng;
										if (historyFragment == 'confirmation' || (_currentStep != 6 && _clickedStep == 7) || (_currentStep != 7 && _clickedStep == 8)) {
											//window.scrollTo(0, 0);
											return;
										}

										switch (_currentStep) {
										case 1:
											// pass a true as
											// parameter to validate
											// the required
											// field
										    var _$container = $('#client-info-view');                             // removing server error classes
										    _$container.find('.inconsistent, .invalidAdvId, .entity-assoc-client').removeClass('inconsistent entity-assoc-client invalidAdvId');
											_returnVal = Utils.getView('clientInfo').modelSaver(true);
											break;
										case 2:
                                                                                        $('#address-entry .inconsistent').removeClass('inconsistent');
    											_returnVal = Utils.getView('addressEntry').modelSaver();
											break;
										case 4:
											_returnVal = Utils.getView('clientDetails').modelSaver();
											break;
										case 5:
											_returnVal = Utils.getView('employment').modelSaver();
											break;
										case 6:
											_returnVal = Utils.getView('income').modelSaver();
											break;
										}
										_clickedStep = _returnVal ? Number(_$this
												.attr('data-step-no')) : 0;
										// Not allowing user to navigate if false is
										// returned
										if (_clickedStep == 8 || !_returnVal) {
											return;
										}
										
										// Not allowing user to step3 if step2 not completed
										if (_clickedStep == 3) {
											if (_currentStep == 2
													&& !Validator
															.checkforMandatoryFields('address-entry')) {
												$('.ncst-step.step3').addClass('pending')
														.removeClass('finished');
												// highlighting incomplete enrties if create
												// client
												// attempt is made
												if (ClientModel.get('clientCreated') == 'failed') {
													Validator.validateInputs(
															'address-entry', true);
												}
												return false;
											} else if (_currentStep != 2
													&& $.inArray('address-entry',
															ClientModel
																	.get('stepsCompleted')) < 0) {
												$('.ncst-step.step3').addClass('pending')
														.removeClass('finished');
												// highlighting incomplete enrties if create
												// client
												// attempt is made
												if (ClientModel.get('clientCreated') == 'failed') {
													Validator.validateInputs($elForm
															.attr('id'), true); /*Fix $("form") changed by Shibin
															Since multiple form tags exists in DOM. To get form under ncst app, change is made */
												}
												return false;
											} else if (_currentStep == 2
													&& Validator
															.checkforMandatoryFields('address-entry')) {
												Utils.getView('addressEntry').navigateToStep3();
											}
										}
                                                                                if (_currentStep == 1) {
											Utils.getView('clientInfo').navigateFromStep1(_urlHash,
													_clickedStep);
											return;
										}
										// removing any previous complete status of step3if
										// step2fails
										// and user navigates to any other steps other than
										// step3
										if (_currentStep == 2
												&& !Validator
														.checkforMandatoryFields('address-entry')) {
											$('.ncst-step.step3').removeClass(
													'finished pending');
										}
										if (_currentStep == 4
												&& !ClientDetailsModel.get('clientListData')) {
											//return false;
										}
			                                                        // navigation handled within clientDetails view (mail address validation)
										if (_currentStep == 4) {
											Utils.getView('clientDetails').navigateFromStep4(_urlHash,_clickedStep);
											return;
										}
										if (_clickedStep == 7) {
											Utils.getView('income').navigateToStep7();
											return;
										}if (_clickedStep == 8) {
											Utils.getView('verification').navigateToStep8();
											return;
										}
										markActiveStep(_clickedStep);
										// scroll the clicked stepinto view start//.ncst-steps-wrapper
										var _$wrapper = $('.stepPanel-steps-wrapper'), _$step = $('.ncst-step.step'
												+ _clickedStep), _toScrollLeft;
										var _wrapper = _$wrapper[0], _stepWdth = _$step
												.width(), _stepOffLeft = _$step.offset().left, _scrollWdth = ($(
												'.ncst-steps-container').width() - _$wrapper
												.width());
										_toScrollLeft = (_wrapper.scrollLeft + _stepOffLeft
												+ _stepWdth / 2 - _scrollWdth / 2);
										_wrapper.scrollLeft = _toScrollLeft;
										if (!(_clickedStep == 3 && _currentStep == 2)
												&& _currentStep != 1) {
											// scroll the clicked stepinto view en//
											Backbone.history.navigate( _urlHash, true);
											window.scrollTo(0, 0);
										}
									}
									function markActiveStep(_clickedStep) {
										$('.ncst-step').removeClass('active');
										// add the variaable setup needed forcorresponding
										// step
										switch (_clickedStep) {
										case 1:
											$('.icon-info').popover('hide');
											$('.ncst-step.step1').addClass('active')
													.removeClass('finished');
											break;
										case 2:
											$('.ncst-step.step2').addClass('active')
													.removeClass('finished');
											break;
										case 3:
											$('.ncst-step.step3').addClass('active')
													.removeClass('finished');
											break;
										case 4:
											$('.ncst-step.step4').addClass('active')
													.removeClass('finished');
											break;
										case 5:
											$('.ncst-step.step5').addClass('active')
													.removeClass('finished');
											break;
										case 6:
											$('.ncst-step.step6').addClass('active')
													.removeClass('finished');
											break;
										case 7:
											$('.ncst-step.step7').addClass('active')
													.removeClass('finished');
											break;
										case 8:
											$('.ncst-step.step8').addClass('active')
													.removeClass('finished');
											break;

										default:
											break;
										}
									}

								});

						
					});

		});