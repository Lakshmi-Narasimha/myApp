// getAccountView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AccountViewSchema = new mongoose.Schema({
    accountViewObject: {
        type: Array,
        "default": []
    }
});

var AccountViewLookUp = mongoose.model('AccountViewLookup', AccountViewSchema);

var AccountViewModel = new AccountViewLookUp({

    "accountViewObject": [{
        "unitHolderDetails" : {
          "invname" : "Shankar",
          "address" : {
            "line1":"B-34 Acrot Street No 161 Yerapalli street",
            "line2":"Vadapallani",
            "line3":"Chennai 763001"
          },
          "firstholder" : {
            "name" : "Shankar",
            "pan" : "XXXXXX9L",
            "kyc" : "KYC registered"
          },
          "secondholder" : {
            "name" : "Meenakshi",
            "pan" : "XXXXXX8P",
            "kyc" : "KYC registered"
          },
          "status" : "Individual",
          "bankDetails" : "1261729102 / ICICI Bank Chennai",
          "addBankDetails":[
            {
              "bankCode": "635864358346/ Yes Bank",
              "bankAdd": "Nunbakkam Chennai"

            },
            {
              "bankCode": "635864358346/ HDFC Bank",
              "bankAdd": "Nunbakkam Chennai"

            },
             {
              "bankCode": "635864358346/ ICICI Bank",
              "bankAdd": "Nunbakkam Chennai"

            }
          ],
          "modeofoperation" : "Anyone or survivor",
          "modeofpayment" : "Directly to bank"
        },
        "accountDetails" : {
          "accountNumber" : "883472380",
          "accountName" : "Franklin India Bluechip Dividend Fund",
          "gridData" :{
            "openingBalance" : {              
              "balanceUnits" : "134.89"
            },  
            "rows" : [
              {
                "date" : "15 Nov 2015",
                "transaction" : "Systematic Investment Purchase",
                "amount" : "6656",
                "nav" : "123.56",
                "units" : "34.9",
                "balanceUnits" : "234.89"
              },
              {
                "date" : "15 Nov 2015",
                "transaction" : "Systematic Investment Purchase",
                "amount" : "6656",
                "nav" : "123.56",
                "units" : "34.9",
                "balanceUnits" : "234.89"
              },
              {
                "date" : "15 Nov 2015",
                "transaction" : "Systematic Investment Purchase",
                "amount" : "6656",
                "nav" : "123.56",
                "units" : "34.9",
                "balanceUnits" : "234.89"
              }
            ]            
          }                   
        }  
    }]

});

AccountViewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AccountViewLookUp table, please contact admin...');
    } else {
        AccountViewLookUp.remove({}, function(err) {
            console.log('AccountViewLookUp collection removed');
            AccountViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AccountViewLookUp table, please contact admin...');
                }
                console.log('AccountViewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AccountViewLookUp;
