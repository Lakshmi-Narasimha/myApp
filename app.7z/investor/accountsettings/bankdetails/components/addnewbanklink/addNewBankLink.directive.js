/**
 * @ngdoc directive
 * @name fticSubscriptionLink Directive
 * @description
 *
 * - This directive in the subscription tab which contains the new subscription link.
 *
 **/
'use strict';

var fticAddNewBankLink = function () {
    return {
        template: require('./addNewBankLink.html'),
        restrict: 'E',
        scope: {},
        controller: function () {
            
        },

        link: function () {
        }
    };
};

fticAddNewBankLink.$inject = [];
module.exports = fticAddNewBankLink;