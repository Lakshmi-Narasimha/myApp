﻿// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
   'backbonesubroute',
  'appcommon/memmorymgr',
  'appcommon/commonutility',
  'appcommon/analytics',
  'appcommon/globalcontext',
  'appmodules/crm/app/views/calendarview',
  'appmodules/crm/app/views/smartpadlistview',
  'appmodules/crm/app/views/addsmartpadview',
  'appmodules/crm/app/views/notedetailview',
  'appmodules/crm/app/views/editsmartpadview',
  'appmodules/crm/app/views/tasklistview',
  'appmodules/crm/app/views/taskeditview'
], function ($, _, Backbone, backbonesubroute, MemmoryMgr, CommonUtil, Analytics, GlobalContext, CalendarView, SmartPadListView, AddSmartpadView, NoteDetailView, EditSmartpadView, TaskListView, TaskEditView) {
    var crmRouter = Backbone.SubRoute.extend({
        routes: {
            // Default
        	"new-activity": "handleTheRequest",
            "smartpad": "showSmartpad",
            "addsmartpad": "showaddSmartpad",
            "editsmartpad/:smartPadId": "showeditSmartpad",
            "notedetail/:smartPadId": "showNoteDetail",
            "tasks": "showTaskList",
            'addtask(/:subject)': 'showAddTask',
            "edittask/:activityId": "showTaskEdit",
            "": 'defaultAction',
        },
        defaultAction: function (action) {
        	action = action || "";
            var globalcontext = GlobalContext.getInstance();
            var calendarView = new CalendarView();
            MemmoryMgr.setcurrentview(calendarView);
            var options = {
                fmId: globalcontext.getGlobalContext().Context.AdvisorFMID || CommonUtil.readCookie('FMID'),
                selectedContactId: globalcontext.getGlobalContext().Context.ContactId,
                selectedContactType: globalcontext.getGlobalContext().Context.ContactType,
                action:action
            };
            calendarView.render(options);
        },
        handleTheRequest : function(param){
        	this.defaultAction("newActivity");
        	
        },
        showSmartpad: function () {
            var globalcontext = GlobalContext.getInstance();
            var smartpadListview = new SmartPadListView();
            MemmoryMgr.setcurrentview(smartpadListview);
            var options = {
                fmId: globalcontext.getGlobalContext().Context.AdvisorFMID,
                selectedContactId: globalcontext.getGlobalContext().Context.ContactId,
                selectedContactType: globalcontext.getGlobalContext().Context.ContactType
            };
            smartpadListview.render(options);
        },
        showeditSmartpad: function (smartPadId) {
            var globalcontext = GlobalContext.getInstance();
            var editSmartpadView = new EditSmartpadView();
            MemmoryMgr.setcurrentview(editSmartpadView);
            var _options = {
                    fmId: globalcontext.getGlobalContext().Context.AdvisorFMID || CommonUtil.readCookie('FMID'),
                    selectedContactId: globalcontext.getGlobalContext().Context.ContactId,
                    selectedContactType: globalcontext.getGlobalContext().Context.ContactType,
                    smartPadId: smartPadId,
                };
            editSmartpadView.render(_options);
        },
        showaddSmartpad: function () {
            var globalcontext = GlobalContext.getInstance();
            var addSmartpadView = new AddSmartpadView();
            MemmoryMgr.setcurrentview(addSmartpadView);
            var options = {
                fmId: globalcontext.getGlobalContext().Context.AdvisorFMID || CommonUtil.readCookie('FMID'),
                selectedContactId: globalcontext.getGlobalContext().Context.ContactId,
                selectedContactType: globalcontext.getGlobalContext().Context.ContactType
            };
            addSmartpadView.render(options);
        },
        showNoteDetail: function (smartPadId) {
            var globalcontext = GlobalContext.getInstance();
            var noteDetailView = new NoteDetailView();
            MemmoryMgr.setcurrentview(noteDetailView);
            var options = {
                fmId: globalcontext.getGlobalContext().Context.AdvisorFMID || CommonUtil.readCookie('FMID'),
                smartPadId: smartPadId,
            };
            noteDetailView.render(options);
        },
        showTaskList:function(){
            var _globalcontext = GlobalContext.getInstance();
            var _taskListview = new TaskListView();
            MemmoryMgr.setcurrentview(_taskListview);
            var options = {
                fmId: _globalcontext.getGlobalContext().Context.AdvisorFMID,
                selectedContactId: _globalcontext.getGlobalContext().Context.ContactId,
                selectedContactType: _globalcontext.getGlobalContext().Context.ContactType
            };
            _taskListview.render(options);
        },

        showAddTask: function (subject, isInsight, activityId) {
            Analytics.analytics.recordAction('Addtask:clicked');
            var decode = atob(subject);

            var globalcontext = GlobalContext.getInstance();
            var _options = {
                selectedContactId: globalcontext.getGlobalContext().Context.ContactId,
                selectedContactType: globalcontext.getGlobalContext().Context.ContactType,
                activityId: activityId,
                insightSubject: decode
            };
            var editTaskView = new TaskEditView(_options);
            MemmoryMgr.setcurrentview(editTaskView);
            editTaskView.render();
        },

        showTaskEdit: function(activityId) {
            var globalcontext = GlobalContext.getInstance();
            var _options = {
                selectedContactId: globalcontext.getGlobalContext().Context.ContactId,
                selectedContactType: globalcontext.getGlobalContext().Context.ContactType,
                activityId: activityId
            };
            var editTaskView = new TaskEditView(_options);
            MemmoryMgr.setcurrentview(editTaskView);
            editTaskView.render();
        }
    });
    return { crmRouter: crmRouter };
});
