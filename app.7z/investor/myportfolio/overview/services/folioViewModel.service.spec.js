'use strict';
describe('Services: investor folio view model factory', function() {

    var folioViewModelData, httpBackend, Restangular, $window, params, folioViewDetailsDataObj;

    beforeEach(angular.mock.module('investor'));

    beforeEach(inject(function(_folioViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
        folioViewModelData = _folioViewModel_;
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        $window = _$window_;
        $window.ga = function() {};

        folioViewDetailsDataObj = {
            'unitHolderDetails': {
                'invName': 'YASMIN'
            },
            'folioDetails': {
                'folioNumber': '17877097',
                'gridData': {
                    'rows': [{
                        'currentValue': '29408.34',
                        'currentCost': '22499.85',
                        'accno': '0379904865101',
                        'returns': '16.81%',
                        'fund': 'Franklin India Prima Plus - Growth',
                        'totalUnits': '66.411',
                        'divInvAmount': '0.00',
                        'purchaseAmount': '22499.85'
                    }],
                    'footer': {
                        'totalUnits': '285.758',
                        'currentCost': '82498.74',
                        'currentValue': '122163.91'
                    }
                }
            }
        };
    }));

    it('should folioViewModel to be defined', function() {
        expect(folioViewModelData).toBeDefined();
    });

    describe('Services: load folio view details services', function() {
        var params;
        
        beforeEach(inject(function() {
            httpBackend.expectGET('http://localhost:3030/clients/clientStatement?flag=F&guId=878').respond(folioViewDetailsDataObj);
            params = {};
        }));

        it('should load getFolioViewObj with success data and retreive the data using getter', function() {
            folioViewModelData.getFolioViewDetails(params).then(function(result) {
                expect(result.folioDetails).toBeDefined();
            });
            httpBackend.flush();
        });

        it('should retrive getFolioViewObj data using getter', function() {
            folioViewModelData.setFolioViewObj(folioViewDetailsDataObj);
            expect(folioViewModelData.getFolioViewObj().folioDetails.folioNumber).toEqual('17877097');
        });

    });

});
