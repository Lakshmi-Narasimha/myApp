define([ 'jquery', 'underscore', 'backbone', 'backboneRelational' ], function(
		$, _, Backbone, backboneRelational) {
	var _newClient = Backbone.RelationalModel.extend({
		defaultValues : function(){
			return {// client validate request model
				'fromBackbutton':false,
				"newClientModel" : {
					// client validate request model
					"customerTypeCd" : "P",
					"dstrId" : null,
					"dstrCtx" : "DMU.DIST",
					"orgClient" : null,
					"personClient" : {
						"hrnfNm" : null,
						"firstNm" : null,
						"midNm" : null,
						"lastNm" : null,
						"sfxTxt" : null,
						"persTypCd" : null,
						"taxPayerId" : null,
						"genderCd" : null,
						"mrtlStatCd" : null,
						"mrtlStatDesc" : null,
						"bthDt" : null,
						"dpdtCnt" : null,
						"ctzp" : null,
						"ctznCntryCd" : null,
						"firstCtznCntryNm": null,
						"secCtznCntryCd": null,
						"secCtznCntryNm": null,
						"drvLicNbr" : null,
						"drvLicStCd" : null,
						"drvLicStNm" : null,
						"psprtNbr" : null,
						"finInstnEmplCd" : null,
						"finInstnEmplDesc" : null,
						"ownrOfcrCd" : null,
						"ownrOfcrDesc" : null,
						"emplStatCd" : null,
						"emplStatDesc" : null,
						"occpDescTxt" : null,
						"emprNm" : null,
						"emprAddrLn1" : null,
						"emprAddrLn2" : null,
						"emprCityNm" : null,
						"emprStCd" : null,
						"emprPostlCd" : null,
						"emprCntryCd" : null,
						"emprCntryNm" : null,
						"prmSrcOfIncmCd" : null,
						"prmSrcOfIncmDesc" : null,
						"postalAddresses" : [],
						"emails" : [],
						"prospectInfo" : null,
						"financialInfo" : null,
						"productExpe" : [],
						"telephones" : [],
						"associatedClient" : null
					}

				}

			}
		}
	});
	return new _newClient();
});