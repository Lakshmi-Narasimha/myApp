'use strict';
var express = require('express'),
    router = express.Router(),
    InvPersonalInfoModel = require('./personalinfo/getPersonalInfo.model'),
    SubscriptionDetailsModel = require('./subscriptions/subscriptionDetails.model'),
    ManageSubscriptionDetailsModel = require('./subscriptions/manageSubscriptionDetails.model'),
    FundDtlsForNewFund = require('./subscriptions/fundDetails.model'),
    ValidateKycModel = require('./kycstatus/validateKyc.model'),
    OtpValidationModel = require('./kycstatus/otpValidation.model'),
    PanFolioKycModel = require('./kycstatus/panFolioKyc.model');

// api route

var error = {
    status: 300,
    message: 'Something went wrong!!'
}; /* Error messge object */
var successObj = {
    'transactionStatus': 'S'
};
var errorManageSubscriptions = [{
    'errorCode': '2008',
    'errorSource': 'PFAPP',
    'errorDescription': 'The following field(s) can contain only numbers. They cannot contain alphabets or other characters: Mobile Number'
}];

router.route('/profile/myProfile')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        InvPersonalInfoModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].myProfileObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0]);
            }

        });
    });

router.route('/updateMobileNumber/*')
    .post(function (req, res) {

        if (req.params[0]) {
            res.json(successObj);
        }

    });

router.route('/clients/subscription')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SubscriptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].subscriptionDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].subscriptionDetails);
            }

        });
    });

router.route('/clients/userAccountSubscription')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ManageSubscriptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].subscriptionDetails.length === 0) {
                res.send(errorManageSubscriptions);
            } else {
                res.json(data[0].subscriptionDetails[0].accountSubscriptionObject);
            }

        });
    });

router.route('/clients/navSubscription')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ManageSubscriptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].subscriptionDetails.length === 0) {
                res.send(errorManageSubscriptions);
            } else {
                res.json(data[0].subscriptionDetails[0].navSubscriptionObject);
            }

        });
    });

router.route('/clients/weeklyMarketSubscription')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ManageSubscriptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].subscriptionDetails.length === 0) {
                res.send(errorManageSubscriptions);
            } else {
                res.json(data[0].subscriptionDetails[0].weeklyMarketSubscriptionObject);
            }

        });
    });

router.route('/clients/unsubscription')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ManageSubscriptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].subscriptionDetails.length === 0) {
                res.send(errorManageSubscriptions);
            } else {
                res.json(data[0].subscriptionDetails[0].unSubscriptionObject);
            }

        });
    });

router.route('/changePassword')
    .post(function (req, res) {
        console.log(req);
        if (req.body.currentpassword && req.body.newpassword) {
            res.json(successObj);
        }

    });

//Fund details for new fund selection
router.route('/transact/fundsList')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        FundDtlsForNewFund.find(function (err, data) {
            if (err) {
                res.send(err);
            } else if (data[0].length === 0) {
                res.send(error);
            } else {
                res.json(data[0].FundDetails[0]);
            }

        });
    });
//KYC Flow Routes
router.route('/transact/validateKYC')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ValidateKycModel.find(function (err, data) {
            if (err) {
                res.send(err);
            } else if (data[0].length === 0) {
                res.send(error);
            } else {
                if (req.query.panNo === 'AFPL10258F4') {
                    res.json(data[0].kycStatusObj);
                } else {
                    data[0].kycStatusObj.kycValidation.kycSource = '';
                    res.json(data[0].kycStatusObj);
                }
            }
        });
    });

router.route('/transact/panFolioKYC')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        PanFolioKycModel.find(function (err, data) {
            if (err) {
                res.send(err);
            } else {
                res.json(data[0].folioDetails);
            }
        });
    });

router.route('/transact/eKYCOTPGeneration')
    .post(function (req, res) {
        res.json({
            'eKYCOTP': {
                'status': 'S'
            }
        });
    });
router.route('/transact/eKYCOTPValidation')
    .post(function (req, res) {
        OtpValidationModel.find(function (err, data) {
            console.log(data);
            res.json(data[0].validateOtpObj);
        });

    });

module.exports = router;
