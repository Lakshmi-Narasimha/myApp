//var probe = require('ca-apm-probe').start();
var express = require('express');
var https = require('https');
var bodyParser = require('body-parser');
//var cookieParser = require('cookie-parser');
var querystring = require('querystring');
var session = require('express-session');
var MemoryStore = require('session-memory-store')(session);
//var uuid = require('node-uuid');
//var timeout = require('connect-timeout');
var logger = require('./config/logger');
var proxy = require('./config/proxy');
const NodeCache = require( "node-cache" );
const myCache = new NodeCache( {} );
module.exports = myCache;

//url config file
var config = require('/app/conf/properties/mfchatnode/config');

var app = express();

// set our portsess
var port = process.env.PORT || 9800;

// get all data/stuff of the body (POST) parameters
// parse application/json
app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: false
}));

// initialize the session
app.use(session({
  secret: '123456ABCDEFG',
  saveUninitialized: true,
  resave: true,
  store: new MemoryStore({
    expires: 60*60*2, //20 mins
    checkperiod: 60*5 //5 mins
  })
}));

//app.UseCors(CorsOptions.AllowAll);
// app.use(function(req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//     next();
// });

// initialize the session

// app.use(cookieParser('123456ABCDEFG'));
// app.use(session({
//     secret: '123456ABCDEFG',
//     secure: false,
//     cookie:{
//       maxAge: 60000000
//     },
//     saveUninitialized: true,
//     resave: true,
//     rolling:true,
//     store: new MemoryStore({
//         expires: 1000*60*30, //30 mins
//         checkperiod: 1000*60*30 //30 mins
//     })
// }));
// set the static files location
app.use(express.static((__dirname + '/')));




// app.use(session({
//     store: new RedisStore({}),
//     secret: '123456ABCDEFG',
//      saveUninitialized: true,
//      resave: true,
//      rolling:true
// }));


/*
var assignId = function(req, res, next) {
    req.session.id = uuid.v4();
    next();
};
app.use(assignId);*/
// setup the logger
//app.use(logger.express);
app.use(logger.winstonExpress);

// connection timeout
//app.use(timeout(20000));
//app.use(haltOnTimedout);

// function haltOnTimedout(req, res, next) {
//     if (!req.timedout) next();
// }

// authenticate touchcommerce
var authenticateTouchCommerce = function(req, res, next) {
    // authenticate
    var post_data = querystring.stringify({
        'j_username': config.TC_API_USERNAME,
        'j_password': config.TC_API_PASSWORD,
        'submit': 'login'
    });

    var reqObj = {
        host: config.TC_SERVER_NAME,
        //host:'api-verizon-dev.touchcommerce.com',
        method: 'POST',
        path: config.TC_FORM_LOGIN_URI,
        agent: proxy.agent,
        ca:proxy.ca,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(post_data)
        },
        rejectUnauthorized: true
    };

    logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));

    var proxyRequest = https.request(reqObj, function(proxyResponse) {
        var sessionCookie = proxyResponse.headers["set-cookie"].toString().split(";");
        proxyResponse.setEncoding('utf8');

        proxyResponse.on('data', function(chunk) {
            if (sessionCookie) {
                req.session.sessionCookie = sessionCookie[0];
                //logger.access.info('Authenticated to Touchcommerce');
                logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                next();
            } else {
                if(req.session && req.session.sessionCookie){
                    //req.session.sessionCookie = null;
                }
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
        });
        proxyResponse.on('error', function(err) {
            if(req.session && req.session.sessionCookie){
                //req.session.sessionCookie = null;
            }
            logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
            res.send(err);
        });
    });

    proxyRequest.write(post_data);
    proxyRequest.end();
};


// Check authentication Touchcommerce
var isAuthenticated = function(req, res, next) {
    if (req.session && req.session.sessionCookie) {
        logger.general.info(logger.formatInfoMsg(req.session.id, req.session.sessionCookie + " is Authenticated!"));
        next();
    } else {
        logger.general.info(logger.formatInfoMsg(req.session.id, "redirect to authenticate"));
        authenticateTouchCommerce(req, res, next);
    }
};

// routes
var agentAvailabilityRoute = require('./api/modules/agentAvailability/agentAvailability.route');
var engagementRoute = require('./api/modules/engagement/engagement.route');
var getMessageRoute = require('./api/modules/getMessage/getMessage.route');
var customerIsTypingRoute = require('./api/modules/customerIsTyping/customerIsTyping.route');
var sendMessageRoute = require('./api/modules/sendMessage/sendMessage.route');
var dataPassRoute = require('./api/modules/dataPass/dataPass.route');
var dataPassForSalesRoute = require('./api/modules/dataPass/dataPassForSales.route');
var udmConnection = require('./api/modules/udmConnection/udmConnection.route');
var conversionRoute = require('./api/modules/conversion/conversion.route');

// api services
app.post('/mfchatnode/rest/agent', isAuthenticated, agentAvailabilityRoute);
app.post('/mfchatnode/rest/engagement', isAuthenticated, engagementRoute);
app.post('/mfchatnode/rest/message/:engagementID', isAuthenticated, getMessageRoute);
app.post('/mfchatnode/rest/message', isAuthenticated, sendMessageRoute);
app.post('/mfchatnode/rest/customerIsTyping', isAuthenticated, customerIsTypingRoute);
app.post('/mfchatnode/rest/dataPassForSales', isAuthenticated, dataPassForSalesRoute);
app.post('/mfchatnode/rest/dataPass', isAuthenticated, dataPassRoute);
app.post('/mfchatnode/rest/udmConnection', udmConnection);
app.post('/mfchatnode/rest/conversion', isAuthenticated, conversionRoute);

app.get('/mfchatnode/isAlive', function(req, res) {
    res.send(200).end();
});

process.env.UV_THREADPOOL_SIZE = 128;
app.listen(port);
logger.access.info(process.env.NODE_ENV.trim());
console.log('Application is running on this port http://localhost:' + port);
