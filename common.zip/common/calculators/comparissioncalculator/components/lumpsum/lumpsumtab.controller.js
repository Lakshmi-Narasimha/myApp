function lumpsumtabController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, comparisonCalculatorInitialService, comparisonCalculatorModel, calculatorsEventConstants) {

  $scope.init = function() {
    comparisonCalculatorInitialService.loadAllServices($scope);
  };

  $scope.init();
  $scope.selectOptions = {
    'Fund': []
  };


  $scope.$on(calculatorsEventConstants.COMPARISON_FUND_DETAILS, function() {
    if ($scope.radios.selectedVal === $state.current.parent + '.lumpsum') {
      $scope.selectOptions.Fund.push({
        'title': 'Select Fund',
        'category': '',
        'minLumpsumAmount': 5000
      });
      var fundlist = comparisonCalculatorModel.getFundDetails().allfunds.newFunds;
      for (var fd = 0, len = fundlist.length; fd < len; fd++) {
        $scope.selectOptions.Fund.push({
          'title': fundlist[fd].fundDesc,
          'category': fundlist[fd].fundOption,
          'minLumpsumAmount': fundlist[fd].minNewPurAmt,
        });
      }
    }
  });


  $scope.inputObject = {
    Fund: {
      required: true,
      name: 'fundSelection',
      label: 'Select Fund'
    }
  };

  $scope.userInput = {
    Amount: {
      key: '',
      text: 'Investment Amount <span class=\'icon-fti_rupee\'></span>',
      value: '',
      pattern: /^[0-9]*$/,
      message: '',
      isMasked: false,
      isRequired: true,
      type: 'text',
      name: 'amount'
    },
    Tenure: {
      key: '',
      text: 'Investment Tenure',
      value: '',
      pattern: /^[0-9]*$/,
      message: '',
      isMasked: false,
      isRequired: true,
      type: 'text',
      name: 'tenure'
    },
    Annual: {
      key: '',
      text: 'Enter Expected Rate of Return',
      value: '',
      // pattern: /^[0-9]*$/,
      message: '',
      isMasked: false,
      isRequired: false,
      maxlength: 6,
      disable: true,
      type: 'text',
      name: 'annual'
    }
  };

  $scope.reload = true;
  $scope.selectedType = 'fundType';
  $scope.listenChange = function() {
    $scope.TypeSelected = $scope.selectedType;
    if ($scope.selectedType === 'fundType') {
      $scope.userInput.Annual.disable = true;
      $scope.userInput.Annual.isRequired = false;
      $scope.inputObject.Fund.disable = false;
      $scope.inputObject.Fund.required = true;
      $scope.userInput.Annual.value = '';
      $scope.reload = true;
    } else {
      $scope.userInput.Annual.disable = false;
      $scope.userInput.Annual.isRequired = true;
      $scope.inputObject.Fund.disable = true;
      $scope.inputObject.Fund.required = false;
      $scope.fundType.fundCode = '';
      $scope.reload = false;
      $timeout(function() {
        $scope.reload = true;
      }, 0);
    }
  };

  $scope.calculatorReq = [];
  $scope.fundType = [];
  $scope.fundType.fundCode = '';
  $timeout(function() {
    $scope.$on('selectedFund', function(event, data) {
      $scope.lumpsumCalculatorForm.$submitted = false;
      $scope.fundType.fundName = data.title;
      $scope.fundType.fundCode = data.category;
      $scope.fundType.minLumpsumAmount = data.minLumpsumAmount;
    });
  }, 0);

  $scope.resetForm = function() {
    $scope.selectedType = null;
    $scope.reload = false;
    $scope.$broadcast(calculatorsEventConstants.COMPARISON_RESET_DATA);
    $timeout(function() {
      $scope.selectedType = 'fundType';
      $scope.reload = true;
      $scope.userInput.Tenure.value = '';
      $scope.userInput.Amount.value = '';
      $scope.fundType.fundCode = '';
      $scope.userInput.Annual.value = '';
      $scope.inputObject.Fund.disable = false;
      $scope.inputObject.Fund.required = true;
      $scope.userInput.Annual.disable = true;
      $scope.userInput.Annual.isRequired = false;
      $scope.calculatorReq = {};
      $scope.tenureErrorvalue = $scope.userInput.Tenure.value;
    }, 0);
  };

  $scope.onSubmit = function() {
    $scope.$broadcast(calculatorsEventConstants.COMPARISON_RESET_DATA);
    $scope.tenureErrorvalue = parseInt($scope.userInput.Tenure.value);
    if ($scope.userInput.Amount.value < $scope.fundType.minLumpsumAmount || $scope.userInput.Amount.value > 999999999 || $scope.userInput.Tenure.value > 40 ||
      $scope.userInput.Tenure.value < 1 || (($scope.userInput.Annual.value > 99 || $scope.userInput.Annual.value < 1) && ($scope.userInput.Annual.isRequired))) {
      return;
  }else if (!$scope.checkWholeNumPattern($scope.userInput.Tenure.value) || !$scope.checkWholeNumPattern($scope.userInput.Amount.value) ){
        return;
}else if($scope.userInput.Annual.isRequired && !$scope.checkWholeNumPattern($scope.userInput.Annual.value)) {
    return;
}else {
    $scope.calculatorReq = [{
      'investmentTenure': $scope.userInput.Tenure.value,
      'annualizedReturn': $scope.userInput.Annual.value,
      'fundName': $scope.fundType.fundCode,
      'frequency': '',
      'trxnType': 'Lumpsum',
      'lumpsumInvestmentAmount': $scope.userInput.Amount.value,
    }];
    $scope.$emit(calculatorsEventConstants.COMPARISON_FUND_SUBMIT, $scope.calculatorReq);
  }
};
$scope.checkWholeNumPattern = function(field){
    var patt = /^[0-9]*$/;
    // var result = patt.test($scope.userInput.Tenure.value);
    var result = patt.test(field);                
    return result;
};
$scope.inputChanged = function(data){
  $scope.lumpsumCalculatorForm.$submitted = false;
  $scope.tenureErrorvalue = parseInt(data.value);
};
$scope.annualValue = function(){
    $scope.lumpsumCalculatorForm.$submitted = false;
};
}

lumpsumtabController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'comparisonCalculatorInitialService', 'comparisonCalculatorModel', 'calculatorsEventConstants'];
module.exports = lumpsumtabController;