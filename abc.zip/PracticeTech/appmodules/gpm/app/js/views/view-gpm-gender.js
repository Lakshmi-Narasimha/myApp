define(['jquery', 'underscore', 'backbone', 'spinner','appcommon/globalcontext', 'appcommon/analytics','appmodules/gpm/app/js/lib/validate.js', 'appmodules/ncst/app/js/utils','moment', 'appmodules/ncst/app/data/country-list','appmodules/contactprofile/app/models/cpviewmodel','appmodules/gpm/app/js/views/view-drivers-licence',
		'text!appmodules/gpm/app/templates/gpmgendersection.html'], function ($, _, Backbone, Spinner, GlobalContext, Analytics, Validator, Utils,Moment, StateList, CPViewModel, DriversLicenceView, GenderTemplate) {
		    var _genderView = Backbone.View.extend({
		    	el: $("#gpm-form-update-field-container"),
			    id: 'gpm-form-update-field-container',
		        events: {},
		        initialize: function () {
		        	this.data = {};
		        },
		        template:_.template(GenderTemplate),
		        render: function (updateMode) {

		            var self = this;
		        	try{
		        		
		        		if(!this.model.get('currentItemSet')){
		        			var CPData = CPViewModel.getInstance().getData();
		        			this.data.fieldsInfo = {"genderCd":(CPData && CPData.cola && CPData.cola.clientPersonal)?CPData.cola.clientPersonal.get('genderCd'):""};
		        			this.model.setCurrentValue(updateMode,{data:this.data});
		        		}
		        		var _compiledTemplate = this.template({data:this.model});
		        		$("#"+this.id).html(_compiledTemplate).promise().done(function(){
		        		});
			        	
			        	

		        	}
		        	catch(error){
		        		console.log(error);
		        	}
		        	
		        
		        },
		        validateAndNavigateFromStep1:function(){
		        	
		        	if(this.model.validate('gpm-update-form',true)){
		        		this.model.setChangedValue();
		        		this.navigateToStep2();
		        	}
		        },navigateToStep2:function(){
		        	var _self = this, _gpmModel = this.model;
		        	var _items = this.model.get('items');
		        	var _gender = _items.find(function(row){return row.get("itemType") == "genderCd"});
		        	_gpmModel.set('submittedTime',moment(new Date()).format('MM/DD/YYYY hh:mm a'));
		        	var _completedSteps = _gpmModel.get('completedSteps');
		        	_gpmModel.set('updateCompleted',true);
		        	$('.gpm-step.step1').addClass("finished").removeClass("active");
		        	$('.gpm-step.step2').addClass("active");
		        	if(_completedSteps.indexOf(1) == -1){
		        		_gpmModel.get('completedSteps').push(1);
					}
		        	Backbone.history.navigate('gpm/confirm/'+_gpmModel.get('updateMode'), true);
		        }
		        
		    });
		    return _genderView;
		});