function getUrlParams(){
     	var regex = /[?&]([^=#]+)=([^&#]*)/g, url = window.location.href, params = {}, match;
     	while (match = regex.exec(url)) {
 			params[match[1]] = match[2];
 		}
 		return params;
     }
var urlParams = getUrlParams(),
    route = urlParams['route'],
    srcSystem = urlParams['srcSystem'],
    contextId = urlParams['contextid'] ? urlParams['contextid'] : (urlParams['contextId'] ? urlParams['contextId'] : null);
	switch (route) {
	    case 'contactprofile':
	        var queryParams = "mode=nav" + (contextId ? "&ContextId=" + contextId : "");
	        if (srcSystem && srcSystem != null && srcSystem != undefined) {
	            queryParams += "&srcSystem=" + srcSystem;
	        }
	        window.location = "index.html?" + queryParams + "#contactprofile/";
	        break;
	    case 'contactprofile/':
	    case 'contactprofile/preferences':
	    case 'contactprofile/beneficiary':
	    case 'contactprofile/fiduciary':
	    case 'contactprofile/contributions':
	    case 'contactprofile/distributions':
	    case 'hoc/takeAction':
	    case 'hoc/serviceopportunities':
	    case 'hoc/dol':
	        var queryParams = "mode=nav" + (contextId ? "&ContextId=" + contextId : "");
	        
	        if (srcSystem && srcSystem != null && srcSystem != undefined) {
	            queryParams += "&srcSystem=" + srcSystem;
	        }
	        window.location = "index.html?" + queryParams + "#" + route;
		    break;
	    case 'ncst':
		    if(urlParams['ProspectID']){
			    window.location = "index.html#ncst?mode=standalone&ProspectID="+urlParams['ProspectID'];
		    }else{
			    window.location = "index.html#ncst?mode=standalone";
		    }
		    break;
	    case 'coa':
	        window.location = "index.html#coa/?ContextId=" + contextId + "&mode=standalone";
		    break;
	    default:
	        window.location = "index.html#crm";
	        break;
	}