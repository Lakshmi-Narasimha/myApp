define(['jquery',
    'lodash',
    'backbone'
], function ($, _, Backbone) {

    var csrLDAPGroups = "alsb_ecat_aefa_csr,aefa_home_office_employees,afi-nbst-csr-grp,aefa_home_office_fsc,AFI_ADVISORMOBILE_CSR_ACCESS_DEP,AFI_ADVISORMOBILE_CSR_ACCESS".split(',');
    var aacLDAPGroups = "aefa_home_office_fsc".split(',');
    var submitLDAPGroups = "aefa_field_p1_advisors,aefa_field_p1_leaders,aefa_field_p2_advisors,aefa_field_p2_fvp,aefa_field_svp,aefa_home_office_fsc,aefa_field_gvp,aefa_field_afa,aefa_field_p2_assistants,aefa_field_employees,AFI_ALT_ACCT_LifeEvents,AFI_eFormsMM_Pilot,AFI_ALT_ACCT_NewBusiness,aefa_field_dual_brokerage_users,afi-nbst-csr-grp".split(',');

    var UserModel = Backbone.Model.extend({
        defaults: {
            guid: "", // String
            fmid: "", // String  ... 9-char FMID
            peopleSoftId: "", // String
            /*
             personType:
                 Corporate Employee "E"
                 Contractor "C"
                 Group 1 and RSAs "Q"
                 Advisors "00" , "01", "02", "04" based on DMU platform type
                 LRP "L"
             */
            personType: "", // String
            ldapGroups: [] // [String]
        },
        initialize: function () {
            self = this;
        },
        populateFromSsoResponse: function (userResponse) {
            var signedOnUserResponse = userResponse;
            // Setting User information in Model from SSO service
            var signOnToUser = {
                "SSO.GUID": "guid",
                "DMU.DIST": "fmid",
                "PPLSFT.PERS": "peopleSoftId",
                "PersonTypeCd": "personType",
                "LDAP Groups": "ldapGroups"
            };
            _.each(signedOnUserResponse.identifiers.results, function (val) {
                for (key in signOnToUser) {
                    if (key == val.idCtx) {
                        self.set(signOnToUser[key], val.id);
                    }
                }
            });
            _.each(signedOnUserResponse.properties.results, function (val) {
                for (key in signOnToUser) {
                    if (key == val.propNm) {
                        self.set(signOnToUser[key], val.propVal);
                    }
                }
            });
            var ldadpGroups = this.get('ldapGroups');
            this.set('ldapGroups', ldadpGroups ? ldadpGroups.split(",") : []);
            return this;
        },
        isCSR: function() {
            return this.isMemberOfGroups(csrLDAPGroups);
        },
        isAACMember: function() {
            return this.isMemberOfGroups(aacLDAPGroups);
        },
        isMemberOfGroups: function(groups /* [String] */) {
            return _.intersection(this.get('ldapGroups'), groups).length > 0;
        }
    });
    return UserModel;
});
