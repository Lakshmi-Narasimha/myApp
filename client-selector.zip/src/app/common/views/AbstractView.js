define(['jquery', 'lodash', 'backbone', 'bootstrap-dialog', 'ampfComponents', 'config', 'app/common/spinner',
    'app/application/app', 'text!app/common/templates/ServerErrorDialogContents.html'
], function ($, _, Backbone, BootstrapDialog, ampfComponents, config, spinner, app, ServerErrorDialogContentsHtml) {

    var AbstractView = ampfComponents.AggregateView.extend({
        nestedViews: null,
        modalDialog: null,
        initialize: function(options) {
            this.nestedViews = {};
            _.bindAll(this, 'modalDialogShown', 'modalDialogHidden', 'handleServiceError');
        },
        handleNetworkRequestStarting: function() {
            spinner.show();
        },
        showError: function(errorTitle, errorDescription, completion) {
            BootstrapDialog.show({
                size: 'small',
                title: errorTitle,
                closable: false,
                message: errorDescription,
                nl2br: !(_.includes(errorDescription, '<') && _.includes(errorDescription, '>')),
                buttons: [{
                    label: 'OK',
                    cssClass: 'btn',
                    action: function(dialog){
                        dialog.close();
                        if (completion) {
                            completion();
                        }
                    }
                }],
                onshown: this.modalDialogShown,
                onhidden: this.modalDialogHidden
            });
        },
        showServerError: function(errorDescription, errorSolver, buttonDescription) {
            var self = this;
            var template = _.template(ServerErrorDialogContentsHtml);
            BootstrapDialog.show({
                size: 'small',
                title: 'Server Error',
                message: template({details: errorDescription, action: errorSolver, buttonDetails: buttonDescription}),
                onshown: function (dialog) {
                    self.modalDialogShown(dialog);
                    if (buttonDescription== 'Reload Page') {
                        $('[data-tag-id="app-server-error-refresh-button"]').off("click").on('click', function () {
                            window.location.reload();
                        });
                    }
                },
                onhidden: self.modalDialogHidden
            });
        },
		showConfirm: function(title, detail, confirmHandler) {
			BootstrapDialog.show({
				size: 'small',
				title: title,
				closable: false,
				message: detail,
				buttons: [
					{
						label: 'OK',
						cssClass: 'btn',
						action: function(dialog){
							dialog.close();
							if (confirmHandler) {
								confirmHandler();
							}
						}
					},
					{
						label: 'Cancel',
						cssClass: 'btn',
						action: function(dialog){
							dialog.close();
						}
					}
				],
				onshown: this.modalDialogShown,
				onhidden: this.modalDialogHidden
			});
		},
        handleServiceError: function(error) {
            console.log(error);
            if (error.isSSORejection) {
                this.restartApp();
            } else if (error.status === 401) {   //Unauthorized
                this.hideSpinner();
                this.showUnauthorizedError();
            } else {
                this.hideSpinner();
                this.showServerError(error);
            }
        },
        showUnauthorizedError: function (errorTitle, errorDescription) {
            errorTitle = errorTitle || "Authorization Error";
            errorDescription = errorDescription || "Sorry, you are not authorized to view/update these details.";
            this.showError(errorTitle, errorDescription);
        },
        restartApp: function() {
			// AUDIT-IGNORE-WINDOW-REF-RULE
            window.location.href = window.location.href.split('#')[0];
        },
        removeFromDom: function () {
            if (this.beforeRemoveFromDom) {
                this.beforeRemoveFromDom();
            }
            this.clearModalDialog();
            this.clearNestedViews();
            this.undelegateEvents();
            this.$el.empty();
            this.stopListening();
        },
        showSpinner: function() {
            spinner.show();
        },
        hideSpinner: function() {
            spinner.hide();
        },
        addNestedView: function(name, view) { 
            this.removeNestedView(name);
            this.nestedViews[name] = view;
        },
        removeNestedView: function(name) { 
            if (this.nestedViews[name]) {
                this.nestedViews[name].removeFromDom();
                delete this.nestedViews[name];
            }
        },
        getNestedView: function(name) { 
            return this.nestedViews[name];
        },
        clearNestedViews: function() {
            for (var viewName in this.nestedViews) {
                this.removeNestedView(viewName);
            }
        },
        modalDialogShown: function(dialog) {
            this.modalDialog = dialog;
        },
        modalDialogHidden: function(dialog) {
            this.modalDialog = null;
        },
        clearModalDialog: function() {
            if (this.modalDialog) {
                this.modalDialog.close();
            }
        },
        setupElementary: function() {
            $(window).trigger('runElementary'); /* Should be called after render completes to initialize elementary resizing */
        },
        isVisible($element) {
            return $element.is(':visible');
        },
        isHidden($element) {
            return !this.isVisible($element);
        },
        getAccount() {
            return Account.getActiveAccount();
        },
		setStepComplete(appStep, complete = true) {
			this.getAccount().setStepComplete(appStep, complete);
		},
        configurePopOver: function () {
            $('[data-toggle="popover"]').popover({
                html: true,
                placement: "top"
            });
        },
        scrollToTop: function () {
            $(window).scrollTop(0);
        },
        scrollToFirstError: function(errorSelectors) {
            var selectors = errorSelectors ? errorSelectors : ['.error-field'], $errorField;
            $errorField = $(selectors.join(', '));
            if ($errorField.length) {
                window.scroll(0,$errorField.position().top);
            }
        },
		getApp: function() {
			return app;
        },
		getAppView: function() {
			return app.appView;
		}
    });

    return AbstractView;

});
