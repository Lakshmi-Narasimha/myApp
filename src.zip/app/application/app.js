define([
    'jquery',
    'lodash',
    'app/common/util',
], function ($, _, util){

    var Application = function () {
        this.appView = null;
        //this.userInformation = {};
        this.start = function () {
            var self = this;
            require(['app/application/views/AppView', 'app/application/router', 'app/services/awmService'], function (AppView, router, awmService) {
                const params = util.getUrlParams() || {};
                const contextId = params.contextId || null;
                console.log('contextId:'+contextId);

                if(contextId){
                   awmService.promiseToGetInterAppContext(contextId).then(data => {
                        data = data.toJSON();
                        console.log(data);
                        app.selOboId = data.fmids[0];
                        app.selClientId = data.clientIds[0];
                        app.selGroupId = data.groupIds[0] ?  data.groupIds[0].grpId : null;
                        self.renderView(AppView,router);
                    }, function(error){
                        if (error.status === 401){
                            app.showAuthError = true;
                        }
                        self.renderView(AppView, router);
                    });
                } else{
                    self.renderView(AppView, router);
                }
                
            });
        };
        this.renderView = function(AppView, router){
            var self = this;
            self.appView = new AppView();
            self.appView.initiateAppRouter = function() {
                router.start();
            };
            self.appView.render();
        }
    };
    var app =  new Application();
    return app;
});
