﻿/* Custom Menu */
define([
  'jquery', 'config', 'errorLog'
], function ($, config, ErrorLog) {
    function ajaxProcessing(Config){
    	window.loginProcessStarted = false;
        $.ajaxSetup({
            timeout: 30000 //Time in milliseconds
        });

        $.ajaxPrefilter(function (options) {
            options.beforeSend = function (xhr) {
                xhr.setRequestHeader('consumer', Config.consumerId);
                if (options.maxAge != undefined) {
                	if(options.maxAge == 0){
                		xhr.setRequestHeader('cache-control', 'max-age=0');
                	}else if(options.maxAge == 300){
                		xhr.setRequestHeader('cache-control', 'max-age=300');
                	}
					
				} 
            }
        });
        $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
            var _data = options.data;
            if (options.customTimeout == true) {
                options.timeout = options.timeout;
            } else {
                if (options.type == "GET") {
                    options.timeout = 30000;
                } else {
                    options.timeout = 45000;
                }
            }
            options.reqStartTime = new Date().getTime();
            originalOptions._error = originalOptions.error;
            jqXHR.config = { url: options.url };
            var dfd = $.Deferred(); 
            jqXHR.done(dfd.resolve);

            options.error = function (_jqXHR, _textStatus, _errorThrown) {
                jqXHR.data = _data;
                var args = Array.prototype.slice.call(arguments);
                if ((jqXHR.status == 200 ||  jqXHR.status == '12017' || jqXHR.status == 12017 || jqXHR.status == '302' || jqXHR.status == 302 || jqXHR.status == '0') ) {
                    var _respContType = jqXHR.getResponseHeader('Content-Type');
                    if (_respContType && _respContType.indexOf('text/html') > -1) {
                        window.location.reload();
                    }
                    if ((jqXHR.status == 200) && (jqXHR.statusText == "error")) {
                     	window.location.reload();
                     }
                    if (options.retry) {
                        if (originalOptions._error) {
                            dfd.fail(originalOptions._error);
                        }
                        if (jqXHR.statusText == "error")
                        {
                            arguments[0].responseText = "SSO idle timeout";
                        }
                        else {
                            arguments[0].responseText = "operation timed out";
                        }
                        dfd.rejectWith(jqXHR, args);
                        return;
                    }
                    var _esigSignDocumentUrl = Config.eSigConfig.serviceUrl+"signDocument", _endTime = new Date().getTime();
                    if (options.type == "GET" || (options.type == "POST" && _esigSignDocumentUrl == options.url && (_endTime - options.reqStartTime) < 40000)) {
                        if (jqXHR.status == '0' && jqXHR.statusText && jqXHR.statusText == "error") {
                                jqXHR.statusText = jqXHR.statusText + ": Call Aborted in " + (_endTime - options.reqStartTime) + "(ms)";
                        }
                        ErrorLog.ErrorUtils.myError(jqXHR, true);
                        if (options.type == "POST" && _esigSignDocumentUrl == options.url){
                            var _customLog = {
                                "message": "Custom log - sign document retry on abort",
                                "stack": {
                                    "description": "Aborted in " + (_endTime - options.reqStartTime) + "(ms)"
                                }
                            }
                            ErrorLog.ErrorUtils.myError(_customLog, true);
                         }
                        var newOpts = $.extend({}, originalOptions, {
					         retry: true
                        }), _waitTime = options.type == "GET" ? 0 : 1000;
                        setTimeout(function () {
                            $.ajax(newOpts).then(dfd.resolve, dfd.reject);
                        }, _waitTime);
					     
					}else {
	                    if (originalOptions._error)
	                        dfd.fail(originalOptions._error);
	                    dfd.rejectWith(jqXHR, args);
	                }
                   
                } else {
                    if (originalOptions._error)
                        dfd.fail(originalOptions._error);
                    dfd.rejectWith(jqXHR, args);
                    return;
                };
            };
            return dfd.promise(jqXHR);
        });
    }
    return ajaxProcessing(config);
}); 
