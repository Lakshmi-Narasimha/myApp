var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var dataPassModel = require('./dataPass.model');
var apiUtils = require('../../common/apiUtils');
var myCache = require('../../../api-server');
var proxy = require('../../../config/proxy')

// api route
router.route('/mfchatnode/rest/dataPassForSales')
    .post(function(req, res) {
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.uri = dataPassModel.createRequestUri;        
        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": myCache.get(req.session.engagementID+'.agentID')
        };

        post_data.Datapass = myCache.get(req.session.engagementID+'.Datapass');
        var postBody = querystring.stringify(post_data);        
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.session.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };      
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {            
            proxyResponse.setEncoding('utf8');            
            logger.general.info(logger.formatOutBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
            if (proxyResponse.statusCode === 200) {
                res.send(dataPassModel.response);
                logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
            } else {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id)); 
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(dataPassModel.response);
            }
            proxyResponse.on('error', function(err) {
               logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
               logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
               res.send(dataPassModel.response);
            });
        });

        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
