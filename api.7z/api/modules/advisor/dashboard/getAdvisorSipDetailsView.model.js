// getAdvisorSipDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AdvisorSipDetailsSchema = new mongoose.Schema({
    advisorSipDetailsObject: {
        type: Array,
        "default": []
    }
});

var AdvisorSipDetailsLookUp = mongoose.model('AdvisorSipDetailsLookup', AdvisorSipDetailsSchema);

var AdvisorSipDetailsModel = new AdvisorSipDetailsLookUp({

  "advisorSipDetailsObject": [
    {
   "allFunds":[
      {
         "sdv1":[
            {
               "ytm":[
                  {
                     "date":null,
                     "activeSip":"111",
                     "sipThroughput":" Rs 10",
                     "perpetualSip":"10",
                     "avgTicketSize":"Rs 1000",
                     "uniqueInvestor":"10",
                     "sipsDueRenewal":"10"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "activeSip":"222",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"20",
                     "avgTicketSize":"Rs 2000",
                     "uniqueInvestor":"20",
                     "sipsDueRenewal":"20"
                  }
               ]
            }
         ],
         "sdv2":[
            {
               "ytm":[
                  {
                     "date":null,
                     "newSipsAdded":"1111",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "newSipsAdded":"2222",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "lastBusinessDay":[
                  {
                     "date":null,
                     "newSipsAdded":"3333",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ]
            }
         ]
      }
   ],
   "diversifiedEquity":[
      {
         "sdv1":[
            {
               "ytm":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ]
            }
         ],
         "sdv2":[
            {
               "ytm":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "lastBusinessDay":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ]
            }
         ]
      }
   ],
   "debtAndLiquid":[
      {
         "sdv1":[
            {
               "ytm":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ]
            }
         ],
         "sdv2":[
            {
               "ytm":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "lastBusinessDay":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ]
            }
         ]
      }
   ],
   "fundOfFunds":[
      {
         "sdv1":[
            {
               "ytm":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"   
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ]
            }
         ],
         "sdv2":[
            {
               "ytm":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "lastBusinessDay":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ]
            }
         ]
      }
   ],
   "balanced":[
      {
         "sdv1":[
            {
               "ytm":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ]
            }
         ],
         "sdv2":[
            {
               "ytm":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "lastBusinessDay":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ]
            }
         ]
      }
   ],
   "sectorEquity":[
      {
         "sdv1":[
            {
               "ytm":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "activeSip":"1234",
                     "sipThroughput":" Rs 20",
                     "perpetualSip":"30",
                     "avgTicketSize":"Rs 2500",
                     "uniqueInvestor":"30",
                     "sipsDueRenewal":"30"
                  }
               ]
            }
         ],
         "sdv2":[
            {
               "ytm":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "monthEnd":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ],
               "lastBusinessDay":[
                  {
                     "date":null,
                     "newSipsAdded":"1234",
                     "sipmMatured":"1234",
                     "sipmCancelled":"1234",
                     "sipStepUp":"30",
                     "sipPauses":"1234",
                     "sipInstallmentReject":"1234"
                  }
               ]
            }
         ]
      }
   ]
}
  ]

});

AdvisorSipDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AdvisorSipDetailsLookUp table, please contact admin...');
    } else {
        AdvisorSipDetailsLookUp.remove({}, function(err) {
            console.log('AdvisorSipDetailsLookUp collection removed');
            AdvisorSipDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AdvisorSipDetailsLookUp table, please contact admin...');
                }
                console.log('AdvisorSipDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AdvisorSipDetailsLookUp;
