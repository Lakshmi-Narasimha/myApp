'use strict';
describe('Controller: redeemController', function() {
	var $controller,$scope,redeemController;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();

		$scope.config = {"txnFormDetails":{}};	
		$scope.header = {"title": ""};
		loadController();			
	}));	

	function loadController(){
        redeemController = $controller('RedeemCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(redeemController).toBeDefined();
    });

    it('should define the variables config,header',function(){
    	expect($scope.config.txnFormDetails.title).toBe('Redemption Details');
    	expect($scope.header.title).toBe('Redeem');
    	expect($scope.selectedInvestor).toBeDefined();
    	expect($scope.investorDetails).toBeDefined();    	
    });

    it('should listen the event selectInvestor when triggered',function(){
    	$scope.$broadcast('selectInvestor',{"userId":"test123"});
    	expect($scope.selectedInvestor).toEqual({"userId":"test123"});
    });
});