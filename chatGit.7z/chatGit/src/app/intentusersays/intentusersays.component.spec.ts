/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { IntentusersaysComponent } from './intentusersays.component';

describe('IntentusersaysComponent', () => {
  let component: IntentusersaysComponent;
  let fixture: ComponentFixture<IntentusersaysComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntentusersaysComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentusersaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
