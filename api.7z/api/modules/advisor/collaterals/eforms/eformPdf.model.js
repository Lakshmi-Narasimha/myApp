// Eforms.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var EformPdfModelSchema = new mongoose.Schema({
    EformPdf: {
        type: Array,
        "default": []
    }
});

var EformPdfModelLookUp = mongoose.model('EformPdfModelLookUp', EformPdfModelSchema);

var EformPdfModel = new EformPdfModelLookUp({
    "EformPdf" : 
        {
            'pdfUrl':'abc.pdf'
        }    
});

EformPdfModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating EformPdfModelLookUp table, please contact admin...');
    } else {
        EformPdfModelLookUp.remove({}, function(err) {
            console.log('EformPdfModelLookUp collection removed');
            EformPdfModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating EformPdfModelLookUp table, please contact admin...');
                }
                console.log('EformPdfModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = EformPdfModelLookUp;