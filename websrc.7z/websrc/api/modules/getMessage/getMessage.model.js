var config = require('../../../config/config');

var getMessageModelConfig = {
    response: {
      "sessionOver": false,
      "ResponseInfo": {
          "locale": "en",
          "buildNumber": "207",
          "code": "00000",
          "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
          "type": "Success"
      },
      "Page": {
          "status": "accepted",
          "pageType": "livechat",
          "parentPageType": "myData",
          "callType": "getMessage",
          "timeToWait": null,
          "showChatHistory": false,
          "agentBusy": false
      },
      "ModuleMap": {
            "Support": {
              "startMsgId": 10004,
              "searchStartIndex": 10000,
                "msgList": [
                  {
                  "animationDuration": 800,
                  "msgId": 10004,
                  "type" : "chat",
                  "messageList": [
                    {
                        "loginReq": false,
                    }
                  ]
                }
              ],
              "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
                    "type": "Success"
                }
            }
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_GET_MSG_URI
    }
};

module.exports = getMessageModelConfig;
