'use strict';

/* jasmine specs for controllers go here */

describe('genderFilter', function() {

	var genderFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    genderFilter = $injector.get('$filter')('gender');
	}));

	//--- Test for definition

	it('should expect genderFilter to be defined...', function(){
		expect(genderFilter).toBeDefined();
	});

	//--- Test currency filter

	it('should check for gender CASE 1', function(){
		expect(genderFilter('M')).toEqual('Male');
	});

	it('should check for gender CASE 2', function(){
		expect(genderFilter('F')).toEqual('Female');
	});

	it('should check for gender CASE 3', function(){
		expect(genderFilter('U')).toEqual('');
	});


});

describe('nullCheckFilter', function() {

	var nullCheckFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    nullCheckFilter = $injector.get('$filter')('nullCheck');
	}));

	//--- Test for definition

	it('should expect nullCheckFilter to be defined...', function(){
		expect(nullCheckFilter).toBeDefined();
	});

	//--- Test nullCheck filter

	it('should check for nullCheck CASE 1', function(){
		expect(nullCheckFilter('')).toEqual('');
	});


});

describe('dateSuffixFilter', function() {

	var dateSuffixFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    dateSuffixFilter = $injector.get('$filter')('dateSuffix');
	}));

	//--- Test for definition

	it('should expect nullCheckFilter to be defined...', function(){
		expect(dateSuffixFilter).toBeDefined();
	});

	//--- Test nullCheck filter

	it('should check for dateSuffixFilter CASE 1', function(){
		expect(dateSuffixFilter('05/02/2015')).toEqual('05/02/2015th');
	});

	it('should check for dateSuffixFilter CASE 2', function(){
		expect(dateSuffixFilter(null)).toEqual('nullth');
	});



});


describe('formatDisplayDateFilter', function() {

	var formatDisplayDateFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    formatDisplayDateFilter = $injector.get('$filter')('formatDisplayDate');
	}));

	//--- Test for definition

	it('should expect nullCheckFilter to be defined...', function(){
		expect(formatDisplayDateFilter).toBeDefined();
	});

	//--- Test nullCheck filter

	it('should check for formatDisplayDateFilter CASE 1', function(){
		expect(formatDisplayDateFilter('2015-02-19T20:04:03.286 Z')).toEqual('02/19/2015');
	});

	it('should check for formatDisplayDateFilter CASE 2', function(){
		expect(formatDisplayDateFilter('2015-02-19')).toEqual('2015/02/19');
	});

	it('should check for formatDisplayDateFilter CASE 2', function(){
		expect(formatDisplayDateFilter('2015/02/19')).toEqual('2015/02/19');
	});



});