/**
 * @ngdoc Controller
 * @name CGFolioViewCtrl
 * @requires $scope
 * @requires cgAccDetModel
 * @requires investorEventConstants
 * @description
 * -Capital Gains Folio View Controller
 **/


'use strict';
function CGFolioViewCtrl($state,$scope,fticgAccDetLoadInitialService,investorEventConstants) {
    $scope.showcgFolioData = false;
    $scope.$on('cgfolioapply',function(event,cgfolioFilter){
        fticgAccDetLoadInitialService.loadAllServices($scope, cgfolioFilter);
    });
    $scope.$on(investorEventConstants.MyPortfolio.CG_FOLIO_DETAILS_LIST, function(){
        $scope.showcgFolioData = true;
    });
}
CGFolioViewCtrl.$inject = ['$state','$scope','fticgAccDetLoadInitialService','investorEventConstants'];
module.exports = CGFolioViewCtrl;