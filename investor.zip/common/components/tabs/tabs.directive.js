'use strict';

var tabs = function($state, $timeout, $stateParams) {
	return {
            template: require('./tabs.html'),
            restrict: 'E',
            replace: true,
            scope: {
              tabs: "=tabdata",
              showTab :'=?',
              tabActive:'='
            },
            controller: function($scope, $element, $attrs){                
            },
            link: function(scope, iElement, iAttrs, controller){
                if(scope.showTab !== null || scope.showTab !== undefined)
                {      
                    scope.activeJustified = scope.showTab;                 
                    if(scope.showTab >= 0 && scope.showTab < 4) {
                       $state.go(scope.tabs[scope.showTab].uiref);
                    }
                    scope.$on("showTabView",function(event,tabNo){
                        // scope.showTab = tabNo;          
            
                        if(tabNo > -1 && tabNo < 4) //Move to Constants               
                        {
                            if(scope.showTab == tabNo) {
                                $state.go(scope.tabs[tabNo].uiref, {'xParam': $stateParams.xParam == 1 ? 0 : 1});
                                scope.$emit("updateKeyValueListPan");
                            }
                            else {
                                $state.go(scope.tabs[tabNo].uiref);                                      
                            }
                                
                            scope.activeJustified = tabNo;
                        }
                        else
                        {
                            $state.go(scope.tabs[0].uiref);
                        }                    
                    })

                    scope.stopDefaultEvent = function($event,tabNo){
                        scope.$emit("getTabNo",tabNo)
                        if(scope.showTab === -1)
                        {
                            $event.stopPropagation();
                            $event.preventDefault();
                        }                                                
                    }                         

                }                    
                else
                {
                    $state.go(scope.tabs[0].uiref);
                }                                                                        

            }
        };
};

tabs.$inject = ["$state",'$timeout', '$stateParams'];
module.exports = tabs;