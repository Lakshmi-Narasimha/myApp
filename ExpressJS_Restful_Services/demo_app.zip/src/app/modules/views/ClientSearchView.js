define([
    'jquery',
    'lodash',
    'backbone',
    'bootstraptypeahead',
    'q',
    'app/common/spinner',
    'app/common/shadowLayer',
    'app/common/util',
    'app/common/constants',
    'app/common/views/AbstractView',
	'app/application/router',
    'app/application/app',
    'app/services/awmService',
    'app/common/models/InterAppContext',
    'text!app/modules/templates/ClientSearchView.html',
    'app/services/currentContext'
], function($, _, Backbone, BootstrapTypeahead, Q, Spinner, shadow, util, constants, AbstractView, router, app, awmService, InterAppContext, Template, currentContext) {

    return AbstractView.extend({
        el: '#sem-app-primary-view',
        events: {
            "click #switchToAnotherAdvisor": "switchToAnotherAdvisor"
        },
        initialize: function () {
            Backbone.publishSubscribeEvents.on('oboChanged',this.render, this);
            var self = this;
            $(document).on('click touchstart', function (e) {
                var targetId = e.target.id;
                if(targetId != 'no-results' && targetId != "client-search-typeahead"){
                    self.$('input[type="text"].typeahead').val('');
                    self.$('#clsel-no-results').hide();
                }
                e.stopPropagation();
            });
        },
        render: function() {
            this.getClientList();
        },
        switchToAnotherAdvisor: function(e){
            e.stopPropagation();
            $('#cs-obo-dropdown').find('[data-toggle=dropdown]').dropdown('toggle');
        },
        getClientList: function(){
            let self = this;
            self.showSpinner();
            Spinner.show({
                parentElement: "appview",
            });
            let clientList= [];
            const oboId =  app.userInformation ? app.userInformation.formattedFmid : '';
            awmService.promiseToGetClientList(oboId).then((data) =>{
                let list =  data.attributes ? data.attributes.clientList : [];
                _.forEach(list, function(obj) {
                    obj.name = obj.fmtNm + ' ' + obj.id.substr(15);
                    clientList.push(obj);
                });
                self.populateUI(clientList);

                //William Joseph - 000053697
                if(oboId == '000053697'){
                    $("#oboSubscriptionErrorNote").removeClass('hidden');
                    $("#clientSearchContainer").addClass('hidden');
                }else{
                    $("#oboSubscriptionErrorNote").addClass('hidden');
                    $("#clientSearchContainer").removeClass('hidden');
                }

                Spinner.hide();
            }).fail(error=>this.handlerServiceError(error));

        },
        handlerServiceError: function(){
            Spinner.hide();
            this.populateUI();
        },
        populateUI: function(clientList) {
            var self = this;
            this.$el.html(Template);
            var $input = $(".typeahead");
            $input.typeahead({
                source: clientList,
                minLength:3,
                highlight: true,
                items: 'all',
                matcher:  function(item) {
                    if (item.fmtNm.toLowerCase().indexOf(this.query.toLowerCase()) != -1) {
                        return true;
                    }
                },
                highlighter: function(item) {
                    const query = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');

                    //split to separate HTML tags
                    let item_parts = item.split(/(<[^>]+>)/g);

                    //Highlight only if it's not a tag
                    let ret = "";
                    for (let i = 0; i < item_parts.length; i++){
                        if (item_parts[i].match(/(<[^>]+>)/)){
                            //this is a tag.
                            ret += item_parts[i];
                        } else {
                            //highlight if necessary
                            ret += item_parts[i].replace(new RegExp('(' + query + ')', 'ig'), function ($1, match) {
                                return '<strong>' + match + '</strong>';
                            });
                        }
                    }
                    return ret;
                }
            }).on('keyup', this, function(event){
                if($input.val().length >= 3) {
                    shadow.show({
                        parentElement: self.$el
                    });
                }
                else {
                    shadow.hide({
                        parentElement: self.$el
                    });
                }
            }).on('blur', this, function(event){
                shadow.hide({
                    parentElement: self.$el
                });
            });
            self.$('#clsel-no-results').hide();
            $input.keyup( () =>{
                if(($input.val()).length < 3){
                    self.$('#clsel-no-results').hide();
                }
                if (($input.val()).length >= 3) {
                    if (($('.typeahead.dropdown-menu').css("display") != 'block')) {
                        self.$('#clsel-no-results').show();
                    }
                    else {
                        self.$('#clsel-no-results').hide();
                    }
                }
            });
            $input.change(() =>{
                self.$('#clsel-no-results').hide();
                let current = $input.typeahead("getActive");
                if (current &&(current.name == $input.val())) {
                    let selectedClientArr = current.name.split(' ');
                    self.callPutContextService(current.id);
                }
            });
        },
        callPutContextService: function(_clientId) {
			currentContext.context.set('fmids', [app.userInformation.formattedFmid]);
			currentContext.context.set('clientIds',[_clientId]);
			awmService.promiseToCreateInterAppContext(currentContext.context).then(function (contextId) {
				router.routeTo('clientView');
				router.updateContextId(contextId);
			}).fail(error => {
				console.log('ERROR: unable to put to context service...routing anyway');
				router.routeTo('clientView');
			});
        }
    });

});