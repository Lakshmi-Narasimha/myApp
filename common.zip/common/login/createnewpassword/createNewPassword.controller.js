function createNewPasswordController($scope, $state, constants, advisorRegistrationModelService, $window, toaster, $cookies, appConfig, fticStateChange, authenticationService) {

    $scope.newPasswordObj = {
        key: 'newpassword',
        text: 'New password',
        value: '',
        name: 'newpassword',
        isRequired: true,
        type: 'text'
    };

    $scope.headingObj = {
        text: 'Forgotten Password',
        displayBack: true
    };

    $scope.confirmPasswordObj = {
        text: 'Confirm password',
        key: 'confirmpassword',
        name: 'confirmpassword',
        isRequired: true,
        value: '',
        type: 'text'
    };

    $scope.backBtn = function($event) {
        $event.preventDefault();
        fticStateChange.stateChange($state, 'loginmaster.userverification.securityquestion');
        //$state.go('loginmaster.userverification.securityquestion');
    };
    $scope.submitPassword = function(data) {
        var postObj = {};
        postObj.guId = advisorRegistrationModelService.getUserData().guId; //
        postObj.newPwd = data.newpassword.$viewValue;
        postObj.confirmNewPwd = data.confirmpassword.$viewValue;
        if ((data.newpassword.$viewValue === data.confirmpassword.$viewValue) && data.newpassword.$viewValue) {
            var resetSuccess = function(successResp) {
                toaster.success('Thankyou, your Password has been reset Successfully.');                
                $cookies.remove('accessToken', { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.remove('guId', { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.remove('userType', { 'domain': appConfig.DOMAIN_CONFIG });
                window.name = "loggedIn";
                $cookies.put("windowName",window.name,{ 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('accessToken', successResp.data.accessToken, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('guId', successResp.data.guId, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('userType', successResp.data.userType, { 'domain': appConfig.DOMAIN_CONFIG });
                authenticationService.backButton = true;
                $window.location.href = successResp.data.userRedirectURI;
            };
            var resetFailure = function(errResp) {
                toaster.error(errResp.data[0].errorDescription);
            };
            advisorRegistrationModelService.postPassword(postObj).then(resetSuccess, resetFailure);
        }

    };
}

createNewPasswordController.$inject = ['$scope', '$state', 'constants', 'advisorRegistrationModelService', '$window', 'toaster', '$cookies', 'appConfig', 'fticStateChange', 'authenticationService'];
module.exports = createNewPasswordController;
