 'use strict';
 // Controller naming conventions should start with an uppercase letter
 function otpVerificationController($scope, $state, $filter, constants, advisorRegistrationModelService, toaster, configUrlModel, fticStateChange) {
     $scope.formData = {};
     $scope.otpObject = {
         key: 'otp',
         text: 'OTP',
         value: '',
         name: 'otp',
         isRequired: true
     };
     $scope.otpMessageText = {
         text: $filter('translate')(constants.login.OTP_TEXT),
         image: '../' + configUrlModel.getImagesUrl() +'/OTP_Tick.svg'
     };


     $scope.submitOTP = function() {
         $scope.$submitted = true;
         $scope.formData.OTP = $scope.otpObject.value;
         $scope.formData.guId = advisorRegistrationModelService.getUserData().guId;
         if ($scope.otpVerificationForm.$valid) {
             var postSuccess = function() {
                 if (advisorRegistrationModelService.getUserForgotTypeDetails() === 'username') {
                     advisorRegistrationModelService.postAcknowledgeCall($scope.formData.guId);
                     fticStateChange.stateChange($state, 'loginmaster.thankyou');
                     //$state.go('loginmaster.thankyou');
                 } else {
                     fticStateChange.stateChange($state, 'loginmaster.newpassword');
                     //$state.go('loginmaster.newpassword');
                 }
             };
             var handleFailure = function(errorResp) {
                     toaster.error(errorResp.data[0].errorDescription);
            };
                 //advisorRegistrationModelService.postOtpDetails($scope.formData).then(postSuccess, handleFailure);
             advisorRegistrationModelService.postAnsForSecurityQn($scope.formData).then(postSuccess, handleFailure);

         }
     };
     $scope.resendOtp = function($event) {
         $event.preventDefault();
         var otpObj = {};
         var userData = advisorRegistrationModelService.getUserData();
         otpObj.mobileNo = userData.mobile; //"9440415681";
         otpObj.emailId = userData.emailId;
         otpObj.type = userData.userType;
         otpObj.guId = userData.guId;
         var postSuccess = function() {

         };

         var handleFailure = function() {


         };
         advisorRegistrationModelService.postRequestForOtpDetails(otpObj).then(postSuccess, handleFailure);

     };

 };

 otpVerificationController.$inject = ['$scope', '$state', '$filter', 'constants', 'advisorRegistrationModelService', 'toaster', 'configUrlModel', 'fticStateChange'];
 module.exports = otpVerificationController;
