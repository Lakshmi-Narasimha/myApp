'use strict';
var recommendedFundsModelService= function(Restangular, $q, fticLoggerMessage, loggerConstants,authenticationService) {
    var _resp = null;
    var recommendedFundPlanModel = {
        fetchRecommendedFundDetails : function () {
            var params = {};
           
            params.ageFrom = 60;
            params.ageTo = 200;
            params.tenureFrom = 0;
            params.tenureTo= 1;
            params.equityFrom=0;
            params.equityTo=0;
            params.guId = authenticationService.getUser().guId;
            var deferred = $q.defer();
            Restangular.one('smartsolution/smartSolutionFunds').get(params).then(function (recommendedFund) {
                console.log(recommendedFund.fundName);
                deferred.resolve(recommendedFund);
               
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getRecommendedFundPlanDtls : function () {
            //console.log("resp in get",_resp)
                 return _resp;
        },
        setRecommendedFundPlanDtls : function (recommendedResp) {
            //console.log(recommendedResp)
            _resp = recommendedResp;
        }
    };
    return recommendedFundPlanModel;
};
recommendedFundsModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService'];
module.exports = recommendedFundsModelService;
