﻿define(['jquery',
    'underscore',
    'backbone',
    'spinner',
    'appcommon/globalcontext',
    'appcommon/constants',
    'services/dataservice',
    'appmodules/gpm/app/js/utils',
    'appmodules/nav/app/models/contactdetails',
    'appmodules/crm/app/models/contactpickerdatasource',
    'appmodules/crm/app/views/contactpickerview',
    'text!appmodules/gpm/app/templates/gpmreportclientsdivorce.html'
], function ($, _, Backbone, Spinner, GlobalContext, Constants, DataService, Utils, AppContactDetails, ContactPickerDataSource, ContactPickerView, ReportClientsDivorceTemplate) {
    var clientsdivorce = Backbone.View.extend({
        el: $("#gpm-form-update-field-container"),
        id: 'gpm-form-update-field-container',
        isEdit: false,
        contactPickerView: null,
        bindEvents:function(){
            var _self = this;
            $(document).off("click", ".is-divorce").on("click", ".is-divorce", _self.toggleIsDivorce);
            $(document).off("change", "input[type='radio']").on("change", "input[type='radio']", _self.toggleRadioClassActive);
        },
        template: _.template(ReportClientsDivorceTemplate),
        clientId: '',
        initialize: function (data) {
            this.data = data;
            this.isEntity = false;
        },
        render: function (updateMode) {
            try {
                var self = this;

                /* Need to remove below code for 04/29 release */
                if (location.href.indexOf("reportclientsdivorce") > -1) {
                    $('.gpm-update-steps-container').attr('id', 'static-step-container');
                }

                if (!this.model.get('currentItemSet')) {
                    this.model.setCurrentValue(updateMode, { data: this.data});
                }

                var _dataSet = this.model.get('items');
                $("#" + this.id).html(this.template({ data: _dataSet, divorcepartyName: this.model }));
                self.populateView(self);
                if (this.contactPickerView && this.contactPickerView.selectedContact) {
                    this.setTaskProperty(task, 'ContactName', this.contactPickerView.selectedContact.displayName);
                }

                var divorcingParty = self.model.get('items').find(function (row) { return row.get("itemType") == "divorcingParty" }).get('changedItemValue')[1];
                if (divorcingParty != null) {
                	divorcingParty = divorcingParty.split("-");
                	this.contactPickerView.$contactPicker.toggleClass("active", this.contactPickerView.isSearchEnabled);
                	this.contactPickerView.$textInput.val(divorcingParty[0]);
                	this.contactPickerView.updateClearButton();
                }
                window.scrollTo(0, 0);
            }
            catch (error) {
                console.log(error);
            }
            this.bindEvents();
        },
        populateView: function (view) {
            if (!view.isEdit) {
                view.renderContactPicker(view);
            }
        },
        beforeClose: function () {
            if (this.contactPickerView) {
                this.contactPickerView.close();
            }
        },
        toggleIsDivorce: function (evt) {
            var _self = this;
            var _$clickedButton = $(evt.currentTarget);
            if (_$clickedButton.hasClass('active')) {
                return false;
            } else {
                var _btnTxt = _$clickedButton.text();
                $('.is-divorce').removeClass('active');
                _$clickedButton.addClass('active');
            }
        },
        toggleRadioClassActive: function (event) {
            var _radio = $(event.target);
            var _radioHolder = _radio.parents('div.radio-grp-holder');
            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
            _radio.parents('div.radio-group-conatiner').addClass('active');
        },
        renderContactPicker: function (view) {
            var fmid = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
            var dataSource = new ContactPickerDataSource(fmid);
            // if we have one...use the client list the app already retrieved
            var isDynamicSearch = AppContactDetails.advsiorContacts.getContactSearchType(fmid);
            if (!isDynamicSearch) {
                var fixedClientList = AppContactDetails.advsiorContacts.GetContactDetails(fmid, Constants.contactType.Client);
                dataSource.setFixedClientListFromAppClientList(fixedClientList);
            }
            view.contactPickerView = new ContactPickerView({ el: $('#pt-cli-divorce-contact').get(0), dataSource: dataSource });
            var _userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
            if (_userRoles.indexOf("aac") > -1) {
                view.contactPickerView.enableClientIdSearch = true;
            }
            var _isNonCMUser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMUser) {
                view.contactPickerView.isNonCMUser = true;
            }
            view.contactPickerView.render();
            view.contactPickerView.isFreeformAllowed = false;
            /* Required Field Validation For Contact Picker */
            $("#pt-cli-divorce-contact input").attr("id", "cli-divorce-contact").addClass("needed required");
        },
        validateAndNavigateFromStep1: function () {
            var _self = this;
            var _model = this.model;
            function valuesModified() {
                var _isModified = true;
                var _items = _self.model.get('items');
                var _divorceParty = _items.find(function (row) { return row.get("itemType") == "divorcingParty" }),
                    _divorceReqLetter = _items.find(function (row) { return row.get("itemType") == "divorceReqLetter" });
                    //_divorcePartyClientID = _items.find(function (row) { return row.get("itemType") == "divorcingPartyClientID" });
                if (_divorceParty.get('valueChanged') == false && _divorceReqLetter.get('valueChanged') == false) {
                    _isModified = false;
                }
                return _isModified;
            }
            function validateSteps() {
                if (valuesModified() && _model.validate('gpm-update-form', true)) {
                    $('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                   
                    Backbone.history.navigate('gpm/verification/' + _model.get('updateMode'), true);
                }
            }


            if ($('.pt-contact-picker input').is(":focus")) {
                return;
            } else {

            	var clientId = this.contactPickerView.selectedContact;
            	if ((clientId != undefined || clientId != null) && clientId.isClient == false) {
            			$("#pt-cli-divorce-contact input").attr('data-contactType', 'nonclient');
				}

            	if ((clientId != undefined || clientId != null) && clientId.contactType == "nonclient") {
            		$("#pt-cli-divorce-contact input").attr('data-contactType', 'nonclient');
            	}

            this.model.setChangedValue();

            if ($('#pt-cli-divorce-contact input').val() != "") {
            	var clientId = this.contactPickerView.selectedContact;
            	if ((clientId != undefined || clientId != null) && clientId.contactType == "nonclient") {
            		$("#pt-cli-divorce-contact input").attr('data-contactType', 'nonclient');
            	}

            	if ((clientId != undefined || clientId != null) && clientId.contactType == "client") {
            		var otherDisplayNm = clientId.displayName;
    				clientId = clientId.id;
            		Spinner.show();
            		DataService.getClientgroup(clientId).then(function (response) {
            			Spinner.hide();
            			var _items = _self.model.get('items');
            			var fmtId = (response[0] == null || response[0].get == null) ? null : response[0].get('fmtId');
            			var _divorceParty = _items.find(function (row) { return row.get("itemType") == "divorcingParty" });
            			//var _divorcePartyClientID = _items.find(function (row) { return row.get("itemType") == "divorcingPartyClientID" });

            			var contactArray = [];
            			//var oldString = _divorceParty.get('changedItemValue')[1];
            			var newString = otherDisplayNm.concat(" - ", fmtId);
            			var clientName = _divorceParty.get('changedItemValue')[0];

            			clientName = clientName.replace(/\w\S*/g, function (clientName) { return clientName.charAt(0).toUpperCase() + clientName.substr(1).toLowerCase(); });
            			contactArray.push(clientName);
            			newString = newString.replace(/\w\S*/g, function (newString) { return newString.charAt(0).toUpperCase() + newString.substr(1).toLowerCase(); });
            			contactArray.push(newString);

            			_divorceParty.set('changedItemValue', contactArray);
            			_divorceParty.set('changedItemValueId', contactArray);

            			//_divorcePartyClientID.get('customValues').clientId = clientId;

            			validateSteps();
            		}).fail(function (error) {
            			self.handleServiceError(error);
            		});

            	} else {
            		validateSteps();
            	}
            } else {
            	validateSteps();
            }
            }
            
        }
    });
    return clientsdivorce;
});