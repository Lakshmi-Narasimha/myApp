define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appmodules/accountviewer/avcommon',
  'appcommon/globalcontext',
  'appcommon/constants',
  'services/dataservice',
  '../models/recentactivitymodel',
  'text!appmodules/accountviewer/app/templates/activitylistview.html',
  'errorLog',
  'appcommon/commonutility'
], function ($, _, Backbone, Spinner, accountviewCommon, GlobalContext, Constants, Dataservice, RecentactivityModel, ActivityListViewTemplate, ErrorLog, CommonUtility) {
    var brkgProdClsCds = CommonUtility.getBrkgProdClsCds();
    var activitylistview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click .activity-sorting, .reset-sorting": "sortActivityList"
        },
        initialize: function () {
        	this.recentActivityCollection = [];
        	this.accountInfoServiceCounter = 0;
        },
        sortActivityList: function (e) {
        	
        	if(this.recentActivityCollection.length<1){
        		return;
        	}
        	
        	
        	var $this = $(e.currentTarget);
            var $thisSpan = $this.find("span.sorticons");
            var sortOrder = "";
            var sortField = $this.attr('data-sort');
                if(!$this.hasClass("reset-sorting")){
                    if ($thisSpan.hasClass("desc-icon")) {
                        $thisSpan.removeClass("desc-icon").addClass("asc-icon").addClass("act");
                        sortOrder = "asc";
                        
                    }
                    else if ($thisSpan.hasClass("asc-icon")) {
                        $thisSpan.removeClass("asc-icon").addClass("desc-icon").addClass("act");
                        sortOrder = "desc";
                    }
		            else {
		                  $thisSpan.addClass("asc-icon").addClass("act");
		                  sortOrder = "asc";
		            } 
		        }       
                $(".activity-sorting").each(function () {
                  
                    var $innerThisSpan = $(this).find('span.sorticons');               
                    if (!$thisSpan.is($innerThisSpan) && $innerThisSpan.hasClass("act")) {
                        if ($innerThisSpan.hasClass("asc-icon")) {
                            $innerThisSpan.removeClass("asc-icon").removeClass("act");
                        }
                        if ($innerThisSpan.hasClass("desc-icon")) {
                            $innerThisSpan.removeClass("desc-icon").removeClass("act");
                        }

                    }

                });
                var options = {
                		groupId:GlobalContext.getInstance().getGlobalContext().Context.GroupId,
                		fmId:accountviewCommon.readCookie('FMID'),
                		sortField:sortField,
                		sortOrder:sortOrder
                };
                
                this.render(options);
                
                $(".activity-sorting[data-sort='"+sortField+"']").find('span.sorticons').addClass(sortOrder+"-icon").addClass("act");


        },
        findAccountInfo : function(accountInfoArry,accountId){
        	var _row ={};
        	$.each(accountInfoArry,function(key, row){
        		if(row.id == accountId){
        			_row.accountProduct = row.get('accountProduct');
        			_row.adminCd = row.get('adminCd');
        			_row.productCd = row.get('productCd');
        			
        		}
        	});
        	return _row;
        },
        fetchAccountProductInfo : function(options){
        	var _that = this;
        	Spinner.show();
        	if(_that.recentActivityCollection && _that.recentActivityCollection.length>0){
        		
        		Dataservice.getAccountView(options.groupId, options.fmId, options.clientId)
    			.then(function(response){
    				
    				if(response && response[0]){
            			response = response[0]['attributes'];
            		}else{
            			response = response['results'][0]['attributes'];
            		}
    				if(response.overviewAccount && response.overviewAccount.length>0){
    					$.each(_that.recentActivityCollection,function(key,row){
    						var _data = _that.findAccountInfo(response.overviewAccount,row.get('acctId'));
    						var accountInfo = _data.accountProduct;
    						if(accountInfo){
    							_that.recentActivityCollection[key].set('adminCd', _data.adminCd);
    							_that.recentActivityCollection[key].set('productCd', _data.productCd);
    							var productCd = _data.productCd;
    							var mediumNm = "";
    							if(productCd == "00221" || productCd == "00222" || productCd == "00223" || productCd == "00225" || productCd == "00235" || productCd == "00238" || productCd == "00239"){
    								mediumNm = accountInfo.get('mediumNm').substr(0,18)+" ("+accountInfo.get('shortNm')+")";
    							}else{
    								mediumNm = accountInfo.get('mediumNm');
    							}
        						_that.recentActivityCollection[key].set('mediumNm',mediumNm);
            					_that.recentActivityCollection[key].set('longNm', accountInfo.get('longNm'));
            					_that.recentActivityCollection[key].set('strategyNm', accountInfo.get('strategyNm'));
            					_that.recentActivityCollection[key].set('brkgProdClsNm', accountInfo.get('brkgProdClsNm'));
            					_that.recentActivityCollection[key].set('brkgProdClsCd', accountInfo.get('brkgProdClsCd'));
    						}
    						
    	        		});
    					_that.renderDataInTempalte();
    					Spinner.hide();
    				}else{
    					_that.renderDataInTempalte();
    					Spinner.hide();
    				}
    			})
    			.fail(function(err){
    				console.log(err,"ddddd");
    				Spinner.hide();
    			})
        	}
        	
        	
        },
        renderDataInTempalte : function(collection){
        	collection = (!collection) ? this.recentActivityCollection : collection;
        	var activitylistviewTemplate = _.template(ActivityListViewTemplate);
        	$(".acc-tmp-conatiner").html(activitylistviewTemplate({ "brkgProdClsCds": brkgProdClsCds, data: collection }));
        },
        render: function (options) {
        	try{
        		var _that = this;
        		if(_that.recentActivityCollection.length>0){
        			
        			if(options.sortField == "tran-amt"){
        				var tmpObjCollectionNotNull  = [];
        				var tmpObjCollectionNull  = [];
        				$.each(_that.recentActivityCollection,function(key,row){
        					if(row.attributes.tranAmt === "" ||
        							row.attributes.tranAmt === null){
        						tmpObjCollectionNull.push(row);
        					}else{
        						tmpObjCollectionNotNull.push(row);
        					}
        				});
        				RecentactivityModel.applySortToRecentActivity(tmpObjCollectionNotNull,options.sortField, options.sortOrder);
        				tmpObjCollectionNotNull = tmpObjCollectionNotNull.concat(tmpObjCollectionNull);
        				_that.renderDataInTempalte(tmpObjCollectionNotNull);
        			}else{
        				RecentactivityModel.applySortToRecentActivity(_that.recentActivityCollection,options.sortField, options.sortOrder);
        				_that.renderDataInTempalte();
        			}
        			        			
        			
        		}
        		else{
        			Spinner.show();
        			if (options.groupId == undefined || options.groupId == null) {
        				var activitylistviewTemplate = _.template(ActivityListViewTemplate);
        				$(".acc-tmp-conatiner").html(activitylistviewTemplate({ data: options.groupId }));
        				Spinner.hide();
        			} else {
        				Dataservice.getAccountRecentActivity(options.groupId, options.fmId, options.clientId)
                			.then(function (response) {
                				if (response[0]['dstrRcntFinTran'] && response[0]['dstrRcntFinTran'].length > 0) {
                					RecentactivityModel.fillRecentActivityData(_that.recentActivityCollection, response[0]['dstrRcntFinTran']);
                					RecentactivityModel.applySortToRecentActivity(_that.recentActivityCollection);
                					_that.fetchAccountProductInfo(options);
                				}
                				else {
                					_that.renderDataInTempalte();
                					Spinner.hide();
                				}
                			}).fail(function (err) {
                				Spinner.hide();
                			});
        			}               	
        		}
        		$(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
        		$(".hdr-tab-buttons-wrap .av-recents").addClass("hdr-tab-active");
        	}catch(error){
        		ErrorLog.ErrorUtils.myError(error);
        	}
        }
 
    });
    return activitylistview;
});