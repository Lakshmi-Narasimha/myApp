'use strict';
describe('Controller: account view controller', function() {
    var $controller, $scope, event, accountViewController, folioViewModel, folioViewInitialLoader, accountViewInitialLoader, investorEventConstants, timeout;
    var accountFilter = { folioPanAccNo: '0119900830298', dayFlag: 'DE' };

    beforeEach(angular.mock.module('investor'));

    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _folioViewModel_, _folioViewInitialLoader_, _accountViewInitialLoader_, _investorEventConstants_, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);
        
        folioViewInitialLoader = _folioViewInitialLoader_;
        accountViewInitialLoader = _accountViewInitialLoader_;
        investorEventConstants = _investorEventConstants_;
        folioViewModel = _folioViewModel_;

        accountViewController = $controller('accountViewController', { $scope: $scope });
    }));

    it('should expect to be defined', function() {
        expect(accountViewController).toBeDefined();
    });

    it('should load initial services is called on load and services data is available', function() {
        expect(folioViewInitialLoader._isServicesData).toBeFalsy();
        expect(accountViewInitialLoader._isServicesData).toBeFalsy();
    });

    it('should trigger myPortfolioFolioAccounts', function() {
        $scope.$broadcast('myPortfolioFolioAccounts');
        expect($scope.viewObj.showFolioAccounts).toBeTruthy();
    });

    it('should emit event changeNavPill', function() {
        spyOn($scope, '$emit');
        $scope.$emit('changeNavPill', 'accview');
        expect($scope.$emit).toHaveBeenCalledWith('changeNavPill', 'accview');
    });

    it('should trigger event apply and load services', function() {
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('apply', event, accountFilter);
        expect($scope.showActData).toBeFalsy();
    });

    it('should trigger accountStmtsAccountView', function() {
        $scope.$broadcast('accountStmtsAccountView');
        expect($scope.showActData).toBeTruthy();
    });    
});
