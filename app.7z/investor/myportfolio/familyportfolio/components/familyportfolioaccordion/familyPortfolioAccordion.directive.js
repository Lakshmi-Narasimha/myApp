/**
 * @ngdoc property
 * @name Family Portfolio Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var familyPortfolioAccordion = function(familyPortfolioInitialLoader,familyPortfolioModel,panViewModel,investorEventConstants,$loader,toaster,fticDateUtils,$filter,$uibModal) {
	return {
            template: require('./familyPortfolioAccordion.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
                userDetails: '=',
                isToggleDisabled: '=',
                primaryOwnerPan: '='
            },
            controller: function($scope){
               
                $scope.userDetails = [
                    {key:$scope.userDetails.custName,value:$scope.userDetails.pan},
                    {key:'Current Cost',value:$scope.userDetails.currentCost, isRupee: true},
                    {key:'Current Value',value:$scope.userDetails.currentValue, isRupee: true},
                    {pan:$scope.userDetails.pan}
                ];
            },
            link: function(scope){
                scope.mgClick = function(data,status){
                        var filter = {};
                        if(status){
                            return false;
                        }
                        if(!familyPortfolioModel.getFamilyPFInvestmentSummary()){
                            filter ={
                                folioPanAccNo:data[0].value,
                                flag:'PA',
                                dayFlag:'SI',
                                toDate:$filter('date')(fticDateUtils.getYesterday(), 'dd/MM/yyyy')
                            };
                            $loader.start();
                            panViewModel.fetchPanViewDetails(filter).then(function(list){
                                var newObj = {},
                                str = data[0].value+'';
                                newObj[str] = list.investmentSummary;
                                familyPortfolioModel.setFamilyPFInvestmentSummary(newObj);
                                scope.$emit(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_PANVIEW_EVENT,data[0].value);
                            }, function(error){
                                if(error && error.data && error.data.length > 0) {
                                    toaster.error(error.data[0].errorDescription);
                                }
                            }).finally(function(){
                                $loader.stop();
                            });
                        }else{
                            var keys = Object.keys(familyPortfolioModel.getFamilyPFInvestmentSummary());
                            if((keys.indexOf(data[0].value) >= 0)){
                                scope.$emit(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_PANVIEW_EVENT,data[0].value);
                            }
                            else{
                                filter ={
                                    folioPanAccNo:data[0].value,
                                    flag:'PA',
                                    dayFlag:'SI',
                                    toDate:$filter('date')(fticDateUtils.getYesterday(), 'dd/MM/yyyy')
                                };
                                $loader.start();
                                panViewModel.fetchPanViewDetails(filter).then(function(list){
                                    var str = data[0].value+'',
                                    familyportfolioInvSumList = [];
                                    familyportfolioInvSumList = familyPortfolioModel.getFamilyPFInvestmentSummary();
                                    familyportfolioInvSumList[str] = list.investmentSummary;
                                    familyPortfolioModel.setFamilyPFInvestmentSummary(familyportfolioInvSumList);
                                    scope.$emit(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_PANVIEW_EVENT,data[0].value);
                                }, function(error){
                                    if(error && error.data && error.data.length > 0) {
                                        toaster.error(error.data[0].errorDescription);
                                    }
                                }).finally(function(){
                                    $loader.stop();
                                });
                            }
                        }
                    };
                scope.removeMember = function($event , data){
                    var modalInstance;
                    modalInstance = $uibModal.open({
                        template : require('../removememberconfirmpopup/remMemConfPopup.html'),
                        scope : scope
                    });
                    $event.stopPropagation();
                    scope.$on(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_REMOVE_CONF_EVENT, function(){
                        var filter ={
                            'pan':data[0].value,
                            'status':'RM'
                        };
                        $loader.start();
                        familyPortfolioModel.acceptOrRejectOrRemoveFamilyPFReq(filter)
                        .then(function(){
                            familyPortfolioInitialLoader._isServicesData = false;
                            familyPortfolioInitialLoader.loadAllServices(scope);
                        },function(error){
                            if(error && error.data && error.data.length > 0) {
                                toaster.error(error.data[0].errorDescription);
                            }
                        }).finally(function(){
                            $loader.stop();
                        });
                        
                    });
                };
            }
        };
};
familyPortfolioAccordion.$inject = ['familyPortfolioInitialLoader','familyPortfolioModel','panViewModel','investorEventConstants','$loader','toaster','fticDateUtils','$filter','$uibModal'];
module.exports = familyPortfolioAccordion;