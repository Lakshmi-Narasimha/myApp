/**
* @ngdoc service
* @name Investor Dashboard Details Model
* @requires Restangular
* @requires $q
* @requires fticLoggerMessage
* @requires loggerConstants
* @description
*
* - Handles getting the investor details, smart solutions, and investment details
*
*/
'use strict';

var investorDashboardDetailsModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, $http, $cookies, investorConstants, authenticationService) {
    var _dashboardDetails = {};

    var _getter = function(param) {
        return function() {
            return param ? (_dashboardDetails[param] ? _dashboardDetails[param] : {}) : _dashboardDetails;
        };
    };
    var _setter = function(param, data) {
        _dashboardDetails[param] = data || {};
    };

    var investorDashboardDetailsModel = {
        getDashboardDetails: function(params) {

            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INVESTOR_DASHBOARD_DETAILS_MODEL + ' | getDashboardDetails' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var _params = {};
            _params.guId = params.guId;
            Restangular.one(investorConstants.dashboard.INV_DASHBOARD_URL).get(_params).then(function(userInformationDetails) {
                deferred.resolve(userInformationDetails);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getSmartSaveAccAndOneTouchDetails: function(params) {

            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INVESTOR_DASHBOARD_DETAILS_MODEL + ' | getSmartSaveAccAndOneTouchDetails' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var _params = {};
            _params.guId = params.guId;
            Restangular.one(investorConstants.dashboard.INV_SMART_SAV_ACC_ONE_TOUCH_URL).get(_params).then(function(accountDetails) {
                deferred.resolve(accountDetails);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getSmartSolDetails: function(params) {

            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INVESTOR_DASHBOARD_DETAILS_MODEL + ' | getSmartSolDetails' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var _params = {};
            _params.guId = params.guId;
            Restangular.one(investorConstants.dashboard.INV_SMART_SOL_URL).get(_params).then(function(smartSolDetails) {
                var response = angular.isArray(smartSolDetails) ? smartSolDetails[0] : smartSolDetails;
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        
        },

          getInvestPopUpDetails: function(params) {
            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INVESTOR_DASHBOARD_DETAILS_MODEL + ' | getSmartSolDetails' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var _params = {};
            _params.guId = params.guId;
            Restangular.one('dashboard/getInvestDetails').get(params).then(function(response) {
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        
        },

          postConfirmInvestDetails: function(params) {
            var deferred = $q.defer();
            var preferences = {"guId": authenticationService.getUser().guId};
            Restangular.one('/dashboard/confirmInvestDetails').customPOST(params, "", preferences, {}).then(function (successFlag) {
                deferred.resolve(successFlag);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setDashboardData: function (dashboardDetails) {
            _setter('investorDashboardObject', dashboardDetails);
            authenticationService.setInvDashboardDetails(dashboardDetails);
        },
        setSmartSaveAccAndOneTouchData: function(smartSaveAccAndOneTouchDetails) {
            _setter('SmartSaveAccAndOneTouch', smartSaveAccAndOneTouchDetails);
        },
        setSmartSolutions: function(smartSolutionsData) {
            _setter('smartSolutions', smartSolutionsData);
        },
        setInvestData: function(investDetails) {
            _setter('investDetails', investDetails);
        },
        setConfirmData: function(confirmData) {
            _setter('confirmData', confirmData);
        },
        getInvestData:_getter('investDetails'),
        getConfirmData:_getter('confirmData'),
        getSmartSolutions: _getter('smartSolutions'),
        getDashboardData: _getter('investorDashboardObject'),
        getSmartSaveAccAndOneTouchData: _getter('SmartSaveAccAndOneTouch')

    };
    return investorDashboardDetailsModel;

};

investorDashboardDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', '$http', '$cookies', 'investorConstants', 'authenticationService'];
module.exports = investorDashboardDetailsModel;
