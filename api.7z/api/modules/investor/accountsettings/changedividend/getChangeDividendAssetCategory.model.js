// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var ChangeDividendAssetCategorySchema = new mongoose.Schema({
    changeDividendAssetCategoryObject: {
        type: Object,
        "default": {}
    }
});

var InvchangeDividendAssetCategoryLookUp = mongoose.model('InvchangeDividendAssetCategoryLookUp', ChangeDividendAssetCategorySchema);

var InvchangeDividendAssetCategoryModel = new InvchangeDividendAssetCategoryLookUp({

  changeDividendAssetCategoryObject : {
          "codeValueList": [
          {
          "code": "ELSS",
          "value": "ELSS"
          },
          {
          "code": "EQUITY",
          "value": "EQUITY"
          },
          {
          "code": "FIXED INCOME",
          "value": "FIXED INCOME"
          },
          {
          "code": "HYBRID",
          "value": "HYBRID"
          },
          {
          "code": "INTERNATIONAL",
          "value": "INTERNATIONAL"
          },
          {
          "code": "LIQUID",
          "value": "LIQUID"
          }
          ]
          }

});

InvchangeDividendAssetCategoryLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvchangeDividendAssetCategoryLookUp table, please contact admin...');
    } else {
        InvchangeDividendAssetCategoryLookUp.remove({}, function(err) {
            console.log('InvchangeDividendAssetCategoryLookUp collection removed');
            InvchangeDividendAssetCategoryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvchangeDividendAssetCategoryLookUp table, please contact admin...');
                }
                console.log('InvchangeDividendAssetCategoryLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvchangeDividendAssetCategoryLookUp;
