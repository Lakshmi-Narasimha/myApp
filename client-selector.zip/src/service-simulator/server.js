var express = require('express');
var cors = require('cors');
var app = express();
var bodyParser = require('body-parser');
app.use(cors());
app.use(bodyParser.json({limit: '1mb', extended: true})); // support json encoded bodies
app.use(bodyParser.urlencoded({limit: '1mb', extended: true})); // support encoded bodies
app.use(function (req, res, next) {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    res.header('Content-Type', 'application/json');
    next();
});

var config = require('./config.js');
var signOnService = require('./services/getSignOnInformation.js');
var OBOService = require('./services/OBOServlet.js');

app.get('/simservice/', function (req, res) {
   res.send('Seminar and Events app simulated services');
});

/* Sign on information service */

app.get('/simservice/getSignOnInformation', function (req, res) {
    var requestData = {
        fileName: config.loggedInUserType + "-" + config.loggedInUserId,     // specify the file name for reading data for different user types
        inclSglSgnOnGrpInd: req.query.inclSglSgnOnGrpInd
    };
	signOnService.getSignOnInformation(requestData, function(signOnInfo) {
		res.send(signOnInfo);
	}, function(error) {
		res.status(404).send('Not found');
	});
});

/* OBO Servlet service */

app.get('/simservice/OBOServlet', function (req, res) {        
    var requestData = {
        fileName: config.loggedInUserType + "-" + config.loggedInUserId      // specify the file name for reading data for different user types
    };
	OBOService.getOBOServletInfo(requestData, function(data) {
		res.send(data);
	}, function(error) {
		res.status(404).send('Not found');
	});
});

/* compensation team */

app.get('/simservice/CompTeam*', function (req, res) {
    getCompTeamMembersService.getCompTeamMembers(req.url, function(data) {
        res.send(data);
    }, function(error) {
        res.status(404).send('Not found');
    });
});

/* STARTUP SERVER */

var server = app.listen(9040, function () {

  var host = server.address().address;
  var port = server.address().port;

  console.log("Service Simulator listening at http://%s:%s", host, port);

});