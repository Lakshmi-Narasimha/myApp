// swp.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ValidateSwpModelSchema = new mongoose.Schema({
    validateSwpResp: {
        type: Object,
        'default': {}
    }
});

var ValidateSwpModelLookUp = mongoose.model('ValidateSwpModelLookUp', ValidateSwpModelSchema);

var ValidateSwpModel = new ValidateSwpModelLookUp({
    validateSwpResp: {
        'accountNo': '0380000217154',
        'folioId': '13884342',
        'transactionValidated': 'true',
        'webRefNo': 'SWD000893'
    }
});

ValidateSwpModelLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidateSwpModelLookUp table, please contact admin...');
    } else {

        ValidateSwpModelLookUp.remove({}, function () {
            console.log('SwpModelLookUp collection removed');
            ValidateSwpModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating ValidateSwpModelLookUp table, please contact admin...');
                }
                console.log('ValidateSwpModelLookUp table created in mongoose...');
            });
        });
    }
});

module.exports = ValidateSwpModelLookUp;