'use strict';
describe('Controller: stpTransDetailsController', function() {
	var $controller,$scope,stpTransDetailsController,$filter,transactModel,$state;

    var selectedFundObject = {
        "tschvalScheme": "006",
        "fmDescription": "Franklin India Bluechip Fund - Dividend",
        "fundCategory": "EQUITY",
        "fundType": "EQUITY",
        "tschvalAccno": "0069901064910",
        "balUnits": "2463.841",
        "marketValue": "349183.18",
        "tschvalFsFlag": "N",
        "investmentGoal": ""
    };

    var stpObjectWithAmountSelected = {
        "stpAmount" : {
            "amount" : 51000,
            "type" : "fixedAmount"
        },
        "destinationFund" : {
            "accNo": "0010008062712",
            "fundName": "Franklin India PRIMA FUND"
        },
        "startDate":"Wed Dec 28 2016 18:44:13 GMT+0530 (India Standard Time)",
        "endDate":"Fri Dec 30 2016 22:44:13 GMT+0530 (India Standard Time)",
        "frequency":"Weekly",
        "noofInstallments" : 6
    };

    var stpObjectWithCapitalAppreciationSelected = {
        "stpAmount" : {
            "amount" : "Capital Appreciation",
            "type" : "capitalAppreciation"
        },
        "startDate":"Wed Jan 9 2016 18:44:13 GMT+0530 (India Standard Time)",
        "endDate":"Fri Aug 3 2016 22:44:13 GMT+0530 (India Standard Time)",
        "frequency":"Monthly",
        "destinationFund" : {    
            "accNo": "0010008062712",       
            "fundName": "Franklin India PRIMA FUND"
        },
        "noofInstallments" : 6
    };

    var investorDetails =  {
        "custName": "Shankar Narayanan",                    
        "pan": "ABCD1234KL",
        "aadhar" : 123456789123,
        "folioId": 3456572,
        "holdingType": "Joint",
        "mobile": 9039758625,
        "emailId": "shankarnarayanan@gmail.com",
        "city":"P O BOX 170 170",
        "kycStatus":true,
        "holders": [
            {
            "name": "Shankar Narayanan",
            "type": "Firstholder",
            "kycregistered" : true,
            "pan": "ABCD1234KL",
            "aadhar" : 123456789123
            }, {
            "name": "JHON SMITH GOERGE",
            "type": "Secondholder",
            "kycregistered" : true,
            "pan": "ABCD1234KA",
            "aadhar" : 123456789120
            }, {
            "name": "KRISTIANA GOERGE",
            "type": "Thirdholder",
            "kycregistered" : true,
            "pan": "ABCD1234KB",
            "aadhar" : 123456789121
            }
        ]
    };

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_$state_,_$filter_,_transactModel_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();		
		
		$filter = _$filter_;
        $state = _$state_;		
        transactModel = _transactModel_;		
		
        transactModel.setTransactDetails({
            "stpDetails" : stpObjectWithCapitalAppreciationSelected
        });     
        transactModel.setFundDetails(selectedFundObject);
        transactModel.setInvestorDetails(investorDetails);
        transactModel.setTransactConfirm({
            'accountNo': '0010008062712',                     
            'transactionRefNo': 'SWI001166',
            'transDateTime':'Oct 16,2016'
        });
		$scope.config = {};
		loadController();			
	}));	

	function loadController(){
        stpTransDetailsController = $controller('stpTransactionDetailsController', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(stpTransDetailsController).toBeDefined();
    });
 
    it('should define the variables on load',function(){
        expect($scope.destinationFund).toBe("Franklin India PRIMA FUND");
        expect($scope.stpAmount).toBe("Capital Appreciation");
        expect($scope.invDetails).toEqual(investorDetails);
    });

    it('should define the variable keyValuePairs on load(if user chooses capital appreciation)',function(){
        expect($scope.keyValuePairs[0].value).toBe(3456572);
        expect($scope.keyValuePairs[1].value).toBe("Franklin India Bluechip Fund - Dividend");
        expect($scope.keyValuePairs[2].value).toBe("Franklin India PRIMA FUND");
        expect($scope.keyValuePairs[3].value).toBe("capitalAppreciation");
        expect($scope.keyValuePairs[4].value).toBe("Capital Appreciation");
        expect($scope.keyValuePairs[5].value).toBe("Monthly");
        expect($scope.keyValuePairs[6].value).toBe($filter('date')(new Date(stpObjectWithCapitalAppreciationSelected.startDate),'dd MMMM yyyy'));
        expect($scope.keyValuePairs[7].value).toBe($filter('date')(new Date(stpObjectWithCapitalAppreciationSelected.endDate),'dd MMMM yyyy'));
        expect($scope.keyValuePairs[8].value).toBe("SWI001166");
        expect($scope.keyValuePairs[9].value).toBe("Oct 16,2016");
    });

    it('should define the variable keyValuePairs on load(if user chooses amount)',function(){
        transactModel.setTransactDetails({"stpDetails":stpObjectWithAmountSelected});     
        loadController();     
        expect($scope.keyValuePairs[0].value).toBe(3456572);
        expect($scope.keyValuePairs[1].value).toBe("Franklin India Bluechip Fund - Dividend");
        expect($scope.keyValuePairs[2].value).toBe("Franklin India PRIMA FUND");
        expect($scope.keyValuePairs[3].value).toBe("fixedAmount");
        expect($scope.keyValuePairs[4].value).toBe(51000);
        expect($scope.keyValuePairs[5].value).toBe("Weekly");
        expect($scope.keyValuePairs[6].value).toBe($filter('date')(new Date(stpObjectWithAmountSelected.startDate),'dd MMMM yyyy'));
        expect($scope.keyValuePairs[7].value).toBe($filter('date')(new Date(stpObjectWithAmountSelected.endDate),'dd MMMM yyyy'));
        expect($scope.keyValuePairs[8].value).toBe("SWI001166");
        expect($scope.keyValuePairs[9].value).toBe("Oct 16,2016");
    });

    it('should call the function initiateAnotherStp on click of the link initiateAnotherStp',function(){
        spyOn(transactModel,"resetSetters");
        spyOn($state,"go");
        $scope.initiateAnotherStp();  
        expect(transactModel.resetSetters).toHaveBeenCalled();
        expect(transactModel.isNewInvestor).toBe(false);
        expect($state.go).toHaveBeenCalledWith('transact.base.stp', { key: null });
    });
});