'use strict';

var express = require('express');
var router = express.Router();
var eformTypes = require('./getEforms.model');
var eformsDetails = require('./getEformDetails.model');
var folioAccounts = require('./getFolioAccounts.model');
var paymentBanks = require('./getPaymentBanksByFolio.model');
var InvDividendChangeAssetCategoryModel = require('../accountsettings/changedividend/getChangeDividendAssetCategory.model');

// api route
router.route('/services/paramCodes')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        if (req.query.groupId === 'fundcategory') {
            InvDividendChangeAssetCategoryModel.find(function (err, data) {
                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute 
                if (err) {
                    res.send(err);
                } else if (data[0].changeDividendAssetCategoryObject.length === 0) {
                    res.send(error);
                } else {
                    res.json(data[0].changeDividendAssetCategoryObject);
                }

            });
        } else {
            eformTypes.find(function (err, data) {
                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute 
                if (err) {
                    res.send([{
                        errorCode: 'A0003',
                        errorMessage: 'Something went wrong'
                    }]);
                } else {
                    console.log(req.query);
                    if (req.query.groupId === 'SWPFreqFA' || req.query.groupId === 'SWPFreqCA') {
                        res.json({
                            'codeValueList': [{
                                'code': 'M',
                                'value': 'Monthly'
                            }, {
                                'code': 'Q',
                                'value': 'Quarterly'
                            }]
                        });
                    } else if (req.query.groupId === 'STPFreqFA' || req.query.groupId === 'STPFreqCA') {
                        res.json({
                            'codeValueList': [{
                                'code': 'M',
                                'value': 'Monthly'
                            }, {
                                'code': 'Q',
                                'value': 'Weekly'
                            }, {
                                'code': 'Q',
                                'value': 'Daily'
                            }, {
                                'code': 'Q',
                                'value': 'Quarterly'
                            }]
                        });
                    } else if (req.query.groupId === 'OCCUPATION') {
                        res.json({
                            'codeValueList': [{
                                'code': 'Agriculture',
                                'value': '17'
                            }, {
                                'code': 'Business',
                                'value': '05'
                            }, {
                                'code': 'Current Or Former Head Of State',
                                'value': '16'
                            }, {
                                'code': 'Employed At MNC',
                                'value': '01'
                            }, {
                                'code': 'Employed At Private Sector',
                                'value': '02'
                            }, {
                                'code': 'Employed At Public Sector',
                                'value': '03'
                            }, {
                                'code': 'Fx Dealer',
                                'value': '11'
                            }, {
                                'code': 'Government Services',
                                'value': '19'
                            }, {
                                'code': 'Housewife',
                                'value': '07'
                            }, {
                                'code': 'Minor',
                                'value': '12'
                            }, {
                                'code': 'Occupational',
                                'value': '15'
                            }, {
                                'code': 'Others',
                                'value': 'O'
                            }, {
                                'code': 'Others-SUB',
                                'value': 'Z'
                            }, {
                                'code': 'PEP',
                                'value': '13'
                            }, {
                                'code': 'Politician',
                                'value': '10'
                            }, {
                                'code': 'Professional',
                                'value': '04'
                            }, {
                                'code': 'Retired',
                                'value': '06'
                            }, {
                                'code': 'Salaried',
                                'value': '18'
                            }, {
                                'code': 'Self Employed',
                                'value': '14'
                            }, {
                                'code': 'Student',
                                'value': '09'
                            }]
                        });
                    } else if (req.query.groupId === 'WebFinStatus') {
                        res.json({
                            'codeValueList': [{
                                'code': '1 Cr - 5 Cr',
                                'value': '4'
                            }, {
                                'code': '1 Lac - 5 Lac',
                                'value': '12'
                            }, {
                                'code': '10 Lac - 25 Lac',
                                'value': '14'
                            }, {
                                'code': '25 Lac - 1 Cr',
                                'value': '16'
                            }, {
                                'code': '5 Cr - 10 Cr',
                                'value': '18'
                            }, {
                                'code': '5 Lac - 10 Lac',
                                'value': '13'
                            }, {
                                'code': 'Above 10 Cr',
                                'value': '19'
                            }, {
                                'code': 'Below Rs. 1 Lac',
                                'value': '11'
                            }]
                        });
                    } else {
                        res.json({
                            'codeValueList': data[0].codeValueList
                        });
                    }
                    //res.send(500, error);

                }

            });

        }
    });

router.route('/others/invEformDetails')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        eformsDetails.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {

                res.json(data[0]);
                //res.send(500, error);

            }

        });
    });

router.route('/clients/folioAccounts')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        folioAccounts.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {

                res.json(data[0].accountDetails);
                //res.json(data);
                //res.send(500, error);

            }

        });
    });

router.route('/transact/paymentBanksByFolio')
    .get(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        paymentBanks.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send([{
                    errorCode: 'A0003',
                    errorMessage: 'Something went wrong'
                }]);
            } else {

                res.json(data[0].accountDetails);
                //res.send(500, error);

            }

        });
    });

router.route('/services/instantMailback')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        res.send({
            status: 'S'
        });
    });
module.exports = router;