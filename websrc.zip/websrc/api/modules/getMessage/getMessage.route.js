var express = require('express');
var https = require('https');
var config = require('../../../config/config');

var router = express.Router();
var getMessageModel = require('./getMessage.model');

// api route
router.route('/mfchat/rest/message/:engagementID')
    .post(function(req, res) {
        req.uri = customerIsTypingModel.createRequestUri;
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + req.params.engagementID + '&instantResponse=true' + '&requestEntireTranscript=true',
                headers: {
                    'Cookie': req.sessionCookie
                }
            },
            function(proxyResponse) {
                console.log("statusCode: ", proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                if (res.statusCode === 200) {
                    proxyResponse.on('data', function(chunk) {
                        chunk = JSON.parse(chunk);
                        getMessageModel.response.Page.agentName = chunk.agentName;// Added explictly not available in model
                        //getMessageModel.response.agentIsTyping-state = chunk.agentIsTyping-state
                        getMessageModel.response.page.agentID = chunk.agentID;
                        getMessageModel.response.page.command = chunk.command;//Added explictly not available in model
                        getMessageModel.response.page.from = chunk.from;//Added explictly not available in model
                        getMessageModel.response.page.message = chunk.message;//Added explictly not available in model
                        getMessageModel.response.page.messageText = chunk.messageText;//Added explictly not available in model
                        res.send(getMessageModel.response);
                    });
                }
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
