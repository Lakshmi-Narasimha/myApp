/**
 * @ngdoc property
 * @name payment 2 Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details Lumpsum controller for Advisor module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function payment2Ctrl($scope, $state, buildPlanModelService,buildPlanInitialLoader,keyValueGridConfig,TransactConstant,transactModel,$timeout,fundDetails, planSmartSolution) { 	
	
    $scope.isNewInvestor = transactModel.isNewInvestor;
        
    $scope.sipFundDetails = planSmartSolution.getSIPFunds();
    $scope.sipcolumnDefs = keyValueGridConfig.fundGridConfig[TransactConstant.guest.SMARTSIPINV];
    
    var flag = false;

    $scope.accordionClicked=function(){
        
        transactModel.setTransactType(TransactConstant.sip.SIP);
        $scope.showComp = true;
        if(!flag) {
            $timeout(function () {
                $scope.$broadcast("Go_To_Payment_Dtls");
            }, 0);
            flag = true;
        }

        $timeout(function(){
            $scope.$broadcast("hideContinue",{accordion:"sip"})   
        },0);

        console.log("planSmartSolution.getSIPFunds()",planSmartSolution.getSIPFunds());

        fundDetails.removeFundDetails();
        
        angular.forEach(planSmartSolution.getSIPFunds(),function(obj,ind){            
            fundDetails.setFundDetails(obj);
        })        

        transactModel.setSipFundDtls(fundDetails.getFundDetails()); 
    };


}
payment2Ctrl.$inject = ['$scope', '$state', 'buildPlanModelService','buildPlanInitialLoader', 'keyValueGridConfig','TransactConstant','transactModel','$timeout','fundDetails', 'planSmartSolution'];
module.exports = payment2Ctrl;