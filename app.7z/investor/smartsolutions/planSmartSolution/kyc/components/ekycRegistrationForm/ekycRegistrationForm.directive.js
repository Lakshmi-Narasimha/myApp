/**
 * @ngdoc directive
 * @name ekycRegistratonForm
 * 
 * @description
 *
 * - ekycRegistratonForm will be place a registration form to get registered by the investor.
 **/
 'use strict';


var registrationForm = function(formDetailsModel, $state, $timeout, transactModel, kycFormModel) {
	return {
						template: require('./ekycRegistrationForm.html'),
						restrict: 'E',
						scope: {
							formData:"=",
							formEkyc : "="
						},
						controller: function($scope, $element, $attrs){ 
								var taxIdDetails,cnt=1;
								$scope.inputData = [];
								//var inputData = transactModel.getInstantKyc();
								//$scope.inputData = transactModel.getInstantKyc();
								$scope.fromStateVariable = transactModel.getTransactType();

								console.log("$scope.fromStateVariable....", $scope.fromStateVariable);


								$scope.userNameObject = {
									key : "name",
									text : "Name Of the Applicant",
									name : "userName",
									isRequired : true,
									type : "text",
									value : $scope.formData.name
								};
								$scope.panObject = {
									key : "pan",
									text : "PAN/PEKRN",
									name : "pan",
									type : "text",
									pattern : /^([A-Z]){5}([0-9]){4}([A-Z]){1}?$/,
									isRequired : true,
									minlength : 10,
									maxlength :10,
									value : $scope.formData.pan
								};
								$scope.aadhaarObject = {
									key : "aadhar",
									text : "Aadhaar",
									name : "Aadhaar",
									isRequired : true,
									type  : "number",
									isEditable : false,
									maxlength : 12,
									minlength : 12,
									value : $scope.formData.aadhar
								};
								$scope.mobileObject = {
									key : "Mobile",
									text : "Mobile",
									name : "mobile",
									type: "number",
									isRequired : true,
									maxlength : 10,
									minlength : 10,
									value : $scope.formData.mobile
								};
								$scope.emailObject = {
									key : "Email",
									text : "Email",
									name : "mail",
									type : "email",
									pattern : /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/,
									isRequired : true,
									value : $scope.formData.email
								};

						 
								$scope.cntryObject = {
									key : "country",
									text : "Country of Birth",
									type : "text",
									name : "country",
									isRequired : true,
									value : ''
								};
								$scope.placeObject = {
									key : "place",
									text : "Place of Birth",
									type : "text",
									name : "place",
									isRequired : true,
									value : ''
								};
								$scope.netWorthDetails = {
									key : "worth",
									text:"Net Worth",
									name : "netWorth",
									type : "text",
									isRequired : $scope.selectedIncomeOption,
									value : '', 
									pattern: /^[0-9]/
								};
								taxIdDetails = {
									key : "taxId",
									text:"Tax Identification Number",
									name : "taxId"+cnt,
									type : "text",
									isRequired : true,
									value : ''
							 };
								
								var occupation = formDetailsModel.getOccupationDetails();
								console.log("occupation", occupation);
								$scope.occupationDetails = [
									{
										title:"Occupation",
										message : "",
										value:"", 
										name : "occupationDetails",
										selected : "",
										isRequired : true
									 }
								];
								$scope.incomeDetails = [
									{
										title:"Gross Annual Income",
										message : "",
										value:"",
										name : "incomeDetails",
										selected : "",
										isRequired : true
									 }
								];
								$scope.taxResidentDetails = [
									{
										title:"Tax resident country",
										message : "",
										value:"",
										name : "taxResidentDetails",
										selected : "",
										isRequired : true
									 }
								];


								$scope.wishBtnList = ["Yes", "No"];
								$scope.radios = {};
								$scope.radios.selectedVal = "No";
								$scope.toggle = function(){
									if($scope.radios.selectedVal==$scope.wishBtnList[0]){
										$scope.isTaxResidentDisable = true;
									}
									else{
										$scope.isTaxResidentDisable = false;
									}
									return $scope.isTaxResidentDisable;
								}
								
								$scope.templates = []
								$scope.templates.push(taxIdDetails)
								$scope.anotherTemplate = function(){
									cnt++;
									taxIdDetails = {
										key : "taxId",
										text:"Tax Identification Number",
										name : "taxId"+cnt,
										type : "text",
										isRequired : true,
										value : ''
								 };
									$scope.templates.push(taxIdDetails)
								}
					 
								//Datepicker configuration
								$scope.today = function() {
									$scope.transactStartDate = new Date();
									$scope.transactEndDate = new Date();
								};
								$scope.today();

								$scope.popup1 = {
									opened: false
								};

								$scope.popup2 = {
									opened: false
								};

								$scope.open1 = function() {
									$scope.popup1.opened = true;
								};

								$scope.open2 = function() {
										$scope.popup2.opened = true;
								};

								//Frequency select box options
								$scope.frequencyOptions = [
										{
											title : "Daily"
										},
										{
											title : "Weekly"
										},
										{
											title : "Monthly"
										},
										{
											title : "Quarterly"
										}
								];

									//Default Values

								$scope.stpDetails = {
										frequency : $scope.frequencyOptions[0].title,
										startDate : $scope.transactStartDate,
										endDate : $scope.transactEndDate,
										noofInstallments : $scope.noOfInstallments
								};
								$scope.checkPolitical1={
									label:"Politically exposed person",
									value:""
								}
								$scope.checkPolitical2={
									label:"Related to Politically exposed person",
									value:""
								}
								$scope.checkBoxLabel = {
									label:"I/we hereby declare that the information provided above is to the best of my knowledge & belief, is accurate and complete. I agree to notify Franklin Templeton Asset Management (l)Private Limited immediately in the event the information is the self certification changing.",
									value:false,
									name : "checkBox",
									required : true
								}

								$scope.$on('transactFrequency', function(event, selectedValue){
									$scope.stpDetails.frequency = selectedValue.title;
								});

								kycFormModel.fetchFormOcupDetails().then(occuDtlsSuccess, occuDtlsFailure);
								function occuDtlsSuccess(data) {
									formDetailsModel.setOccupationDetails(data.codeValueList);
									var occuDtls = formDetailsModel.getOccupationDetails();
									for(var i=0; i<occuDtls.length; i++) {
											$scope.occupationDetails.push({title: occuDtls[i].code, value : occuDtls[i].value});
									}
									/*kycFormModel.setOccupationDetails(data[0].occupation.occuDetails);
									var occuDtls = kycFormModel.getOccupationDetails();
										for(var i=0; i<occuDtls.length; i++) {
												$scope.occupationDetails.push({title: occuDtls[i].name});
										}*/
								}

								function occuDtlsFailure(data) {
									console.log('handleFailure');
								}


								kycFormModel.fetchFormIncDetails().then(IncDtlsSuccess, IncDtlsFailure);
								function IncDtlsSuccess(data) {
									formDetailsModel.setGrossIncome(data.codeValueList);
									var incomeDtls = formDetailsModel.getGrossIncome();
									for(var i=0; i<incomeDtls.length; i++) {
											$scope.incomeDetails.push({title: incomeDtls[i].code, value : incomeDtls[i].value});
									}
									/*kycFormModel.setGrossIncome(data[0].grossIncome.grossIncomeDetails);
									var incomeDtls = kycFormModel.getGrossIncome();
									for(var i=0; i<incomeDtls.length; i++) {
											$scope.incomeDetails.push({title: incomeDtls[i].range});
									}*/
								}

								function IncDtlsFailure(data) {
									console.log('handleFailure');
								}


								kycFormModel.fetchFormResidentDetails().then(ResidentDtlsSuccess, ResidentDtlsFailure);
								function ResidentDtlsSuccess(data) {
									formDetailsModel.setTaxResidentCntry(data.codeValueList);
									var taxResidentDtls = formDetailsModel.getTaxResidentCntry();
									for(var i=0; i<taxResidentDtls.length; i++) {
										$scope.taxResidentDetails.push({title: taxResidentDtls[i].code, value : taxResidentDtls[i].value});
									}
									/*kycFormModel.setTaxResidentCntry(data[0].taxResidentCountry.taxResidentCountryDetails);
									var taxResidentDtls = kycFormModel.getTaxResidentCntry();
									for(var i=0; i<taxResidentDtls.length; i++) {
											$scope.taxResidentDetails.push({title: taxResidentDtls[i].country});
									}*/
										
								}

								function ResidentDtlsFailure(data) {
									console.log('handleFailure');
								}
								$scope.$on('occupationValue', function(event, data){ 
											var occupationObj = {};
											occupationObj.selectedOccupation =data.title;
											console.log("selectedOccupation", occupationObj.selectedOccupation);
											kycFormModel.setOccuMethod(occupationObj);
											// $scope.occupation1 = formDetailsModel.getOccuMethod();
											// console.log("OCCUPATION...", $scope.occupation1);
											if(occupationObj.selectedOccupation == "Occupation"){
											 $scope.occupationDDShow = true;
											}
											else{
												$scope.occupationDDShow = false;
											}
								});
								$scope.$on('incomeValue', function(event, data){
											var incomeObj = {};
											incomeObj.selectedIncome =data.title;
											kycFormModel.setIncmMethod(incomeObj);
											// $scope.income1 = formDetailsModel.setIncmMethod();
											// console.log("INCOME...", $scope.income1);
											if(incomeObj.selectedIncome == "Gross Annual Income"){
												$scope.incomeDDShow = true;
											}
											else{
												$scope.incomeDDShow = false;
											}
								});
								$scope.$on('taxResidentValue', function(event, data){ 
											var tsxResidentObj = {};  
											$scope.taxResidentDetails.selected = data.title;
											tsxResidentObj.selectedTaxResidentCountry =data.title;
											kycFormModel.setTaxMethod(tsxResidentObj);
											// $scope.tax1 = formDetailsModel.setTaxMethod();
											// console.log("TAX...", $scope.tax1);
											if(tsxResidentObj.selectedTaxResidentCountry == "Tax resident country"){
												$scope.taxResidentDDShow = true;
											}
											else{
												$scope.taxResidentDDShow = false;
											}
								});


								$scope.selectedIncomeOption = function(){
								 	if($scope.incomeDDShow==false){
								 		$scope.netWorthDetails.isRequired == false;
								 	}
								 	else{
								 		$scope.netWorthDetails.isRequired == true;
								 	}
								 	return $scope.netWorthDetails.isRequired;
								 }

								$scope.ekycFormDataObj = [];
								/*$scope.$on('goEkycDirec', function(event, args){
									if($scope.ekycForm.$valid){

											if($scope.radios.selectedVal == "No"){
												if($scope.occupationDDShow == false){
													if(($scope.incomeDDShow == true && $scope.netWorthDetails.value.length > 0 ) || ($scope.incomeDDShow == false && $scope.netWorthDetails.value.length == 0)){
														transactModel.setStateValue({key:"Fund"});
														if($scope.fromStateVariable == "BUYFUND"){
															$state.go('transact.base.buy', {key:"Fund"});
														}
														else{
															$state.go('transact.base.sip', {key: "Fund"});
														}
													}
												}
											}
											else{
												if($scope.taxResidentDDShow == false){
													if($scope.occupationDDShow == false){
														if(($scope.incomeDDShow == true && $scope.netWorthDetails.value.length > 0 ) || ($scope.incomeDDShow == false && $scope.netWorthDetails.value.length <= 0)){
															transactModel.setStateValue({key:"Fund"});
															if($scope.fromStateVariable == "BUYFUND"){
																$state.go('transact.base.buy', {key:"Fund"});
															}
															else{
																$state.go('transact.base.sip', {key: "Fund"});
															}
														}
													}
												}
											}
									}
									else{
											console.log("Invalid Form");
										}


										var obj = {};    
										obj.userName = $scope.userNameObject.value;
										obj.panNum  = $scope.panObject.value;
										obj.aadharNum = $scope.aadhaarObject.value;
										obj.mobNum =  $scope.mobileObject.value;
										obj.mail = $scope.emailObject.value;
										obj.countryName = $scope.cntryObject.value;
										obj.placeName = $scope.placeObject.value;
										obj.netWorth =$scope.netWorthDetails.value;
										obj.taxId = taxIdDetails.value;
										//console.log("formData..", obj);																		
										formDetailsModel.setPersonalDetails(obj);
										$scope.formData = formDetailsModel.getPersonalDetails();
										console.log("FormData...", $scope.formData);
								});*/

								/*var obj = {};    
										obj.userName = $scope.userNameObject.value;
										obj.panNum  = $scope.panObject.value;
										obj.aadharNum = $scope.aadhaarObject.value;
										obj.mobNum =  $scope.mobileObject.value;
										obj.mail = $scope.emailObject.value;
										obj.countryName = $scope.cntryObject.value;
										obj.placeName = $scope.placeObject.value;
										obj.netWorth =$scope.netWorthDetails.value;
										obj.taxId = taxIdDetails.value;
										//console.log("formData..", obj);																		
										formDetailsModel.setPersonalDetails(obj);
										$scope.formData = formDetailsModel.getPersonalDetails();
										console.log("FormData...", $scope.formData);*/
					 }
			};
};

registrationForm.$inject = ['formDetailsModel', '$state', '$timeout', 'transactModel', 'kycFormModel'];
module.exports = registrationForm;











