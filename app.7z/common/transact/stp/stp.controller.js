/**
 * @ngdoc property
 * @name Stp Controller
 * @requires $scope
 * @requires TransactConstant
 * @description
 *
 * - 
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function stpController($scope, TransactConstant) {
	$scope.header.title = TransactConstant.stp.STP_HEADING;  
    $scope.config.txnFormDetails.title = "STP Details";
}

stpController.$inject = ['$scope', 'TransactConstant'];
module.exports = stpController;