/**
 * @ngdoc property
 * @name Forgot Password controller
  * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function forgotPasswordController ($scope, $state, constants,advisorRegistrationModelService) {
	 $scope.forgotType="password";
   advisorRegistrationModelService.setUserForgotTypeDetails($scope.forgotType);
			$scope.headingObj = {
			 	text : constants.login.FORGOTTEN_PASSWORD//'Forgotten Password'
			 }
       $scope.$on('investorfpSelected',function(event){
           $state.go("loginmaster.forgotpassword.investor");

      });
       $scope.$on('distributorSelected',function(event){ 
         $state.go("loginmaster.forgotpassword.distributor"); 
      });
  $scope.$emit("setBreadCrumb",{
        cat : "forgotpwd",
        breadCrumb :{
            label:'Forgot Password',
            state : ''
        }       
    });

}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
forgotPasswordController.$inject = ['$scope', '$state' , 'constants','advisorRegistrationModelService'];
module.exports = forgotPasswordController;