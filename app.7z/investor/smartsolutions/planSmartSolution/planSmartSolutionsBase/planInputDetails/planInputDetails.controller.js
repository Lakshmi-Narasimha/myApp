/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
'use strict';
function planInputDetailsController($scope, $state,recommendedPlanModelService, planSmartSolution, buildPlanModelService, toaster) {

 	$scope.config.stepsConfig.activeStep = 1;
	reset();

	// $scope.planButton = function()
	// {
	//   	// $state.go("smartSol.planSmartSolution.ssBase.recommendations");
	//   	//$scope.$broadcast('goPlanInputDtlsFormDirec');
	//   	console.log("Validations");
	//   	if ($scope.planInputDtlsForm.$valid) {
	//   		$state.go("smartSol.planSmartSolution.ssBase.recommendations.recommendedplan");
	//   	}

	// }
	$scope.$on('planInputDetailsBtn',function(){
		var planInputObj = {};
		planInputObj = angular.copy(recommendedPlanModelService.getPlanInputDtls());
		planInputObj.fundRecom = "O";
		planInputObj.investmentAmount = planSmartSolution.replaceComma(planInputObj.investmentAmount);
		planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
			planSmartSolution.setSmartSolutionDetails(data);
			$state.go("smartSol.planSmartSolution.ssBase.recommendations.recommendedplan");
		}, function (data) {
			console.log("Error");
			if(data.data && data.data[0].errorDescription) {
				toaster.error(data.data[0].errorDescription);
			}

		});

	});

	function reset() {
		buildPlanModelService.isFromModify = false;
		buildPlanModelService.isFromCustomize = false;
		buildPlanModelService.tabname  = 'recommendedplan';
		planSmartSolution.isFromPlan = true;
		buildPlanModelService.setInvestmentType(null);
	}

	$scope.planButton = function() {
		$state.go('smartSol.planSmartSolution.invProceedToBuy.invPBInvestmentPref');
	};
}
planInputDetailsController.$inject = ['$scope', '$state','recommendedPlanModelService', 'planSmartSolution', 'buildPlanModelService', 'toaster'];
module.exports = planInputDetailsController;