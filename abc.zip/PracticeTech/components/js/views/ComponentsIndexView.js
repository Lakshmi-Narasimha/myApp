﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'text!components/template/ComponentsIndex.html',
  'appcommon/abstractview',
  'components/js/views/EmpCompView',
  'components/js/model/EmpCompModel',
  'components/js/views/RadioButtonView',
  'appmodules/ncst/app/js/lib/validate-4.2'
], function ($, _, Backbone, Spinner, ComponentsIndex, AbstractView, EmpCompView, EmpCompModel, RadioButtonsView, Validator) {
    var self;
    var ComponentsIndexView = AbstractView.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        componentId: 0,
        events: {
            'click #validate-button': 'validateComponent',
            'click #initial-render-button': 'renderWithInitialInfo',
            'click #get-render-button': 'handleGetEmpCompInfo'
        },
        initialize: function () {
            self = this;
            this.employerCompData = new EmpCompModel();
            AbstractView.prototype.initialize.apply(this, arguments);
        },
        render: function () {
            this.$el.empty();
            var compiledTemplate = _.template(ComponentsIndex);
            this.$el.html(compiledTemplate);

            // Render Employer Template
            this.renderEmployerCompView();
        },
        renderEmployerCompView: function () {
            var showOccupation = (self.getCount('employer') == 1) ? true : false;
            var employerCompView = new EmpCompView({ el: self.$("#employer"), componentName: "Employer", componentId: 0, compData: this.employerCompData.toJSON(), showOccupation: showOccupation });
            this.addNestedView("sampleTestView1", employerCompView);
            employerCompView.render();

            /*
            //Company Template
            var companyView = new EmpCompView({ el: self.$("#company"), componentName: "Company" });
            companyView.render();
            */
        },
        getCount: function (divId) {
            return $('#' + divId + ' .pt-empcomp:visible').length;
        },
        /*renderWithInitialInfo: function () {
            const sampleTestView = this.SampleTestView();
            sampleTestView.setEmployerCompanyInfo(this.createTestContact(this.componentId));
            sampleTestView.render();
        },*/
        /*SampleTestView() {
            var sampleTestView = new EmpCompView({ el: self.$("#employer"), componentName: "Employer", componentId: 0 });
            this.addNestedView("sampleTestView1", sampleTestView);
            return sampleTestView;
        },*/
        /*createTestContact(compId) {
            //Sample Test Data
            //return new EmpCompModel({ employerName: 'Joe Schmoe', addressType: 'Foreign', address1: '123 Grand Street',  address2: 'Apt 104',  countryCode: 'IN',  city: 'Minneapolis',  state: 'MN',  zipCode: '55355',  primaryOccupation: 'SE', tickerSymbol: 'ABCD' });

            var modelObj = ({
                employerName: $('#pt-empcomp-name-' + compId).val(),
                addressType: $('#pt-empcomp-addrs-type-' + compId + ' input[name="select-choice-pt-empcomp-addrs-type-' + compId + '"]:checked').val(),
                address1: $('#pt-empcomp-addrs1-' + compId).val(),
                address2: $('#pt-empcomp-addrs2-' + compId).val(),
                countryCode: $('#pt-empcomp-country-list-' + compId + ' option:selected').val(),
                city: $('#pt-empcomp-city-' + compId).val(),
                state: $('#pt-empcomp-state-list-' + compId + ' option:selected').val(),
                zipCode: $("#pt-empcomp-zipcode-" + compId).val(),
                primaryOccupation: $('#pt-empcomp-prioccupation-' + compId + ' option:selected').val(),
                tickerSymbol: $('#pt-empcomp-ticker-symbol-' + compId).val()
            });
            
            var employerCompModel = new EmpCompModel(modelObj);
            employerCompModel.setModel(modelObj);
        },
        handleGetEmpCompInfo: function () {
            const empComp = this.getNestedView("sampleTestView1").getEmployerCompanyInfo();
            console.log(empComp);
        },*/
        validateComponent: function () {
            var empComp = this.getNestedView("sampleTestView1"), dataModel;
            if (empComp.validateComponent()) {
                dataModel = empComp.employerCompanyInfo;
                this.employerCompData.set(dataModel);
                console.log(this.employerCompData, "this.employerCompData");
            }
        }
    });
    return ComponentsIndexView;
});