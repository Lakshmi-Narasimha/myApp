define(
		[ 'backbone', 'config', 'spinner', 'appmodules/eSig/app/js/utils',
				'appmodules/eSig/app/js/models/sign-page-model',
				'appmodules/eSig/app/js/models/sign-doc-page-model',
				'appmodules/eSig/app/js/views/customer-list-view',
				'appmodules/eSig/app/js/views/sign-document-page-view',
				'appmodules/eSig/app/js/collections/customer-collection',
				'appmodules/eSig/app/js/collections/signature-collection',
				'appmodules/eSig/app/js/audit',
				'text!appmodules/eSig/app/templates/signDocument.html', 'appcommon/applauncher/device'],
		function(Backbone, Config, Spinner, eSigUtils, SignPageModel,
				SignDocPageModel, CustListView, SignDocPageView,
				CustCollection, SignCollection, AuditLog, TempView, Device) {
			var lastSigned = {}, Self = null, _$window = $(window);
			var BOX_SHADOW_WIDTH = 10;
			var signDocumentView = Backbone.View
					.extend({
						el : $("#practicetech-subapp"),
						id : 'practicetech-subapp',
						template : _.template(TempView),
						signId : "",
						events : {
							'click #startSign' : 'btnStartSignClick',
							'click #cancelSign' : 'btnCancelSignClick',
							'click #accept-button-sign-pad' : 'acceptSignPad',
							'touchmove #overlay-upper' : 'disableScroll',
							'click .sign-link' : 'handleLinkClick',
							'click #close-button-sign-pad' : 'closeSignPad',
							'touchend #close-button-sign-pad' : 'closeSignPad',
							'click #clear-button-sign-pad' : 'clearSignPad',
							'click #page-refresh':'loadPage'
						},
						/*
						 * Two functions for this function 1. Initialise
						 * variables, it is maintained as a seperate function to
						 * accomodate multi client flow 2. Bind orientation
						 * event with the adjustSignature function 3. If
						 * orientation event is not supported (like devices
						 * Surface tablet) resize handler is added
						 */
						initialize: function (params) {
						    Device.physicalDevice();
							Self = this;
							var _that = this;
							this.deviceinfo = Device.info;
							this.intialiseVariables();
							$("#sign-doc-title-contnr, #client-role-info-popup").invokeInfoPopup();

							//this.initInfoPopup();
							this.docId = null;
                           $(document).off('touchmove',".esig-sign-valdtn-contnr");
                           $(document).on('touchmove',".esig-sign-valdtn-contnr",Self.disableBgScroll);
							if (eSigUtils.isMobile()
									|| eSigUtils.isWindowsPlatform()) {
								if (eSigUtils.isWindowsPlatform()) {
									/*
									 * Resize handler for devices which does not
									 * trigger orientation change event
									 */
									this.endResize();
									setTimeout(
											function() {
												_that
														.startResize(function(
																event) {

															if (eSigUtils
																	.getPrevWidth() !== _$window.width()) {
																eSigUtils
																		.setPreviousWidth(_$window.width());
																eSigUtils
																		.setBodySectionHt(false);
																eSigUtils
																		.setOverlay();
																_that
																		.setLeftPanelHeight();
																setTimeout(
																		function() {
																			_that
																					.adjustSignature();
																		}, 110);
															}

														});
											}, 0);
								} else {
									var _timeout = 110;

									this.endOrientation();
									this.startOrientation(function(event) {
										// fix for android orientaion chnage
										// delay;
										if (navigator.userAgent
												.indexOf('Android') > -1) {
											_timeout = 200;
										}
										setTimeout(function() {
											eSigUtils.setBodySectionHt(false);
											eSigUtils.setOverlay();
											_that.setLeftPanelHeight();
											setTimeout(function() {
												_that.adjustSignature();
											}, 110);
										}, _timeout);
									});
								}
							} else {
								eSigUtils.setBodySectionHt(false);
							}
							// _that.render(params)
						},
						intialiseVariables : function() {
							this.currentPage = 1; /* deprecated can be removed */
							this.insertPosArr = [];
							this.currentSignatureIndex = 0;
							this.signerId = "";
							this.signature = null;
							this.totalSignCount = null;
							this.signedSignatureCount = 0;
							this.currentImgHeight = 0;
							this.prevImgHeight = 0;
							/*
							 * constant values 1. Total coordinates of document
							 * 2. Offset if required
							 */
							this.documentX = 8.08819445;
							this.documentY = 10.76;
							this.documentYh = 10.86;
							this.documentYl = 10.56;
							this.refY = 4;
							this.refYh = 4.5;
							this.refYl = 3.5;
							this.signOffsetX = 0;
							this.signOffsetY = 0;
							this.dateOffsetX = 0;
							this.dateOffsetY = 0;
						},
                        /*
						initInfoPopup : function() {
							var _self = this;
							var _placement = 'left';

							$('.popover.info-popup').remove();
							$('#sign-doc-title-contnr .help-icon.info-popup')
									.popover('destroy');
							$('#sign-doc-title-contnr .help-icon')
									.popover(
											{
												container : 'body',
												html : true,
												placement : _placement,
												viewport : 'body',
												title : 'Change type <i class="esig-icon-popover-close pt-h6"></i>',
												template : '<div class="popover esig-help-popup info-popup" role="tooltip"><div class="arrow">'
														+ '</div><h2 class="popover-title"></h2><div class="popover-content"></div></div>'
											});
							var _isOpen = true;
							$('#sign-doc-title-contnr .help-icon').on(
									'hidden.bs.popover', function() {
										// enable the scrolling of dcocument
										// when modal popup is closed
										$('#inner').css('overflow','auto');
										$('body').removeAttr('style');
										$('#esig-help-modal').modal('hide');
										_isOpen = false;
									});
							$('#sign-doc-title-contnr .help-icon')
									.on(
											'shown.bs.popover',
											function() {
												// blok the scrolling of
												// dcocument when modal popup is
												// open
												$('#inner').css('overflow','hidden');
												$('#esig-help-modal').modal(
														'show');
												// add info popup class to title
												// so that popup wont get closed
												// when user click on title
												$('.popover-title').addClass(
														'info-popup');
												_isOpen = true;
												$('body').css({
													'position' : 'fixed',
													'overflow' : 'hidden',
													'width' : '100%'
												});
												// set the popup height if winow
												// height less than 440
												if (_$window.height() < 440) {
													var _headerHt = $(
															'#afinav-navbar')
															.height();
													var _infoPadding = 77;
													var _popupHt = _$window.height()
															- (_headerHt + _infoPadding);
													$('#eSig-bg')
															.find('.info-popup')
															.css(
																	{
																		'height' : _popupHt
																				+ 'px',
																		'overflow' : 'auto'
																	})
												}
												if (!$('esig-icon-popover-close').length) {
													$('.popover-title')
															.append(
																	'<i class="esig-icon-popover-close pt-h6">Close</i>');
												}
												$(".esig-icon-popover-close")
														.off("click")
														.on(
																"click",
																function(e) {
																	$('body')
																			.removeAttr(
																					'style');
																	$(
																			'#esig-help-modal')
																			.modal(
																					'hide');
																	$(
																			'.help-icon')
																			.popover(
																					'hide');
																	_isOpen = false;
																});
												var _event = eSigUtils
														.isMobile() ? 'touchend'
														: 'click';
												$(document)
														.off(_event, 'body')
														.on(
																_event,
																'body',
																function(e) {
																	var _$targetElm = $(e.target);
																	if (_isOpen
																			&& !_$targetElm
																					.hasClass('info-popup')) {
																		// to
																		// avoid
																		// the
																		// blink
																		// in
																		// while
																		// closing
																		// the
																		// modal
																		// popup
																		setTimeout(function(){
																			$(
																			'body')
																			.removeAttr(
																					'style');
																	$(
																			'#client-role-info-popup')
																			.popover(
																					'hide');
																	$(
																			'#esig-help-modal')
																			.modal(
																					'hide');
																		},100);
																		_isOpen = false;
																	}
																});
											});

							var _evt = eSigUtils.isWindowsPlatform() ? 'resize'
									: 'orientationchange';
							$(window).off(_evt, _self.infoOrientationHandler)
									.on(_evt, _self.infoOrientationHandler);

						},
                        */
						infoOrientationHandler : function(view) {
							var _timeout = 0;
							if (navigator.userAgent.indexOf('Android') > -1) {
								_timeout = 200;
							}
							setTimeout(
									function() {
									    var _activePopup = $('#sign-doc-title-contnr .help-icon[aria-describedby]');
									    $("#sign-doc-title-contnr").invokeInfoPopup();
										//Self.initInfoPopup();
										setTimeout(function() {
											_activePopup.click();
										}, 10);

									}, _timeout);
						},
						render : function(signerId, docId) {
							var _self = this, _currTime = new Date().getTime();
							this.docId = docId;
							this.intialiseVariables();
							this.signerId = signerId;
							this.loadPage();
							return this;
						},
						loadPage : function(){
							var _self = this, _currTime = new Date().getTime();
							var docId = this.docId;
							//this.intialiseVariables();
							var signerId = this.signerId ;
							Spinner.show();
							SignCollection.fetch({
								url : Config.eSigConfig.serviceUrl
										+ 'getDocument?' + 'docid=' + docId
										+ '&time=' + _currTime,
								success : function(response) {
									if(response.length > 0 ){
										$('#page-refresh').addClass('hidden');
										SignCollection.fetched = true;
										_self.model = SignCollection
											.get(signerId);
										_self.loadAllPages();
										_self.setlogAuditParams();
									}else{
									_self.model = null;
									_self.$el.html(_self.template);
									$("#sign-doc-title-contnr").invokeInfoPopup();
									//_self.initInfoPopup();
									$('#page-refresh').removeClass('hidden');
									Spinner.hide();
									$('#start-sign-div,#inner').hide();
									eSigUtils.showErrorMsg('#doc-retrieve-fail-error');
									}
								},
								error : function(error,xhr) {
									_self.model = null;
									_self.$el.html(_self.template);
									$("#sign-doc-title-contnr").invokeInfoPopup();
									//_self.initInfoPopup();
									Spinner.hide();
									$('#start-sign-div,#inner').hide();
									$('#page-refresh').removeClass('hidden');
									eSigUtils.logError(xhr, true);
									eSigUtils.showErrorMsg('#sign-doc-page-sysytem-error');
//								  if(xhr.status == 500 || xhr.status == 400){
//									  
//                                  }
								}
							});
						
						},
						/* Page methods */
						loadAllPages : function() {
							/*
							 * Logic: Loads all the pages check for images
							 * loaded by maintaining a counter. If all images
							 * are loaded final handler is invoked
							 */
							//hide the footer
							$(".practicetech-footer").hide();
							var _self = this, docImgs, docImgArrLen, container, imageCounter;
							this.$el.empty();
							this.$el.html(_self.template);
							docImgs = _self.model.get('images');
							docImgArrLen = docImgs.length;
							container = document.createDocumentFragment();
							imageCounter = docImgArrLen;
							

							for ( var i = 0; i < docImgArrLen; i++) {
								var _pageno = docImgs[i].pageNumber;
								var _imgSrc = Config.eSigConfig.serviceUrl
										+ docImgs[i].url + "?"
										+ (new Date().getTime()); // disable
								// the cache
								// to get
								// the
								// signed
								// image
								var _signDocPageModel = new SignDocPageModel();
								_signDocPageModel.set('pageNumber', _pageno);
								_signDocPageModel.set('imageSrc', _imgSrc);

								this.insertPosArr.push(_pageno);
								var _page = container
										.appendChild(new SignDocPageView({
											"id" : "data-" + _pageno,
											"model" : _signDocPageModel
										}).render().el);
								$(_page).find('img').on('load', imageLoad);
								$(_page).find('img').on('error', imageLoad);
							}
							this.$('#inner').append(container);

							function finalHandler() {
								var params;
								Spinner.hide();
								setImageHeight();
								// placeSignaturesSigned();
								/*
								 * Commented as of now since the image comes
								 * with appended signature
								 */
								_self.setLeftPanelHeight();
								
								_self.logAudit(102);
							}
							;
							function imageLoad(event) {
								imageCounter--;
								if (imageCounter == 0) {
									finalHandler();
								}
							}
							;
							function setImageHeight() {
								_self.currentImgHeight = $('#data-1 img')
										.height();
								_self.prevImgHeight = _self.currentImgHeight;
							}
							function placeSignaturesSigned() {
								// TODO: Note here the signature of the advisor
								// also comes in
								// Right now we are skipping the sign of the
								// advisor
								SignCollection.models
										.forEach(function(model) {
											for ( var i = 0; i < model['attributes']['documentSignerSignature'].length; i++) {
												if ((model['attributes']['signerStatus'] == 'Completed')
														&& model['attributes']['documentSignerSignature'][i].signed) {
													_self
															.placeSignature(
																	model['attributes']['documentSignerSignature'][i],
																	model['attributes']['signerId']);
												}

											}
										});
							}
						    //_self.initInfoPopup();
							$("#sign-doc-title-contnr").invokeInfoPopup();
						},
						
						setlogAuditParams: function(){
							var signerName,_self = this;
							signerName = _self.model.get('firstName')+" "+_self.model.get('middleName')+" "+_self.model.get('lastName');
							var params = {
								//"docid": _self.docId,
								"signerId": _self.signerId,
								"signerName": signerName,
								 "pageName": "reviewAndSign"
							}
							AuditLog.setAuditLogParams(params);
						},
						
						logAudit: function(eventid){
						    AuditLog.setAuditLogParams({
						        "eventId": eventid
						    });
						    AuditLog.sendAudit();
						},

						
						btnStartSignClick : function(e) {
							/*
							 * Logic: 1.Find current page 2.Get all the
							 * signature list from the current model 3.Loop
							 * through the signList and find the following 3.1.
							 * Check current array item greater than or equal to
							 * currentpage and current array item is unsigned
							 * 3.2 If yes return the page number and navigate to
							 * that page 3.3 Another check to each array item is
							 * signed or not. If unsigned push that to
							 * unsignedArray 4. If loop finished without any
							 * items found means current page may be the end and
							 * so return the first item from unsigned array
							 */
							var _currentPage, _signList, _self = this, _$el = $(e.currentTarget);

							if (_$el.attr('data-action').toLowerCase() == "start") {
							    if (this.deviceinfo.hardware.type == "Phone") {
									BootstrapDialog.alert('eSig is not supported in this device.',null, 'eSig', 'esigPortrtWarng');
									return;
								}
								_$el.html('Next <i class="icon-arrow-right-white"></i>');
								_$el.attr('data-action', 'next');
								createLinksOnStartClick();
								setTimeout(
										function() {
											// handleButtonNavigation();
											try {
												var _fisrtSignature = _self.model
														.get('documentSignerSignature')[0];
												$('#linkArea-'
														+ _fisrtSignature.signatureSequenceId)[0]
														.scrollIntoView(false);
												setTimeout(function(){
													var _scroller = document.getElementById('inner');
													_scroller.scrollTop = _scroller.scrollTop + 50;
												}, 25);
											} catch (e) {
											}
										}, 200);

							} else {
								handleButtonNavigation();
							}

							/* Create all link when user clicks start button */
							function createLinksOnStartClick() {
								var _signatures = _self.model
										.get('documentSignerSignature');
								_self.totalSignCount = _signatures.length;
								for ( var i = 0; i < _signatures.length; i++) {
									var _sigPage = _signatures[i];
									_self.createSignatureLink(_sigPage);
								}
							}

							function handleButtonNavigation() {
								_currentPage = _self.findCurrentPage();
								_signList = _self.model
										.get('documentSignerSignature');

								// Changes added for sorting the response based
								// on signature page number

								_signList
										.sort(function(a, b) {
											if (a.signaturePageNumber > b.signaturePageNumber) {
												return 1;
											}
											if (a.signaturePageNumber < b.signaturePageNumber) {
												return -1;
											}
											// a must be equal to b
											return 0;
										});

								var nextSign = getNextSign(_signList,
										_currentPage);
								/*
								 * New requirement: When the user signs the last
								 * signature navigation on done button click
								 * needs to go to the submit doc page rather
								 * than client picker page. In the multiclient
								 * scenario this should happen only if all the
								 * signers sign it and after the last client
								 * signs all his signature
								 */
								if (Array.isArray(nextSign)
										&& nextSign.length < 1) {

									/*
									 * One user has signed all his signature, so
									 * call signDocument service here
									 */
									var _url = Config.eSigConfig.serviceUrl
											+ "signDocument";
									var _contentType = "application/x-www-form-urlencoded";
									var _base64Content = _self.signature
											.split(",");

									var _data = {
										"docid" : _self.docId,
										"signerId" : _self.signerId,
										"signatureRawData" : _base64Content[1]
									}

									Spinner.show();
									eSigUtils
											.post(
													_url,
													_data,
													function(response) {
														Spinner.hide();
														if (response.status && response.status.statCd == 0) {
															SignCollection.fetched = false;
															/*
															 * If one user signs
															 * then we need to
															 * call the service
															 * again to get the
															 * new image with
															 * signature
															 * embedded
															 */
															var clientModel = CustCollection
																	.get(_self.signerId);
															clientModel
																	.set(
																			"signerStatus",
																			"Completed");
															_self.model
																	.set(
																			"signerStatus",
																			"Completed");
															SignCollection
																	.set(
																			_self.model,
																			{
																				remove : false
																			});
															var someOneToSign = SignCollection
																	.search("signerStatus","Pending");

															if (someOneToSign) {
																Backbone.history
																		.navigate(
																				"eSig/req-signers-list/"
																						+ _self.docId,
																				true);
															} else {

																Backbone.history
																		.navigate(
																				"eSig/sign-submitted",
																				true);

															}
														} else {
															Spinner.hide();
															$('#start-sign-div,#main-outer,.esig-sign-cancel').hide();
															eSigUtils.logError(response, true);
															eSigUtils.showErrorMsg('#sign-doc-page-sysytem-error');
															//$('#page-refresh').removeClass('hidden');
														    //_self.initInfoPopup();
															$("#sign-doc-title-contnr").invokeInfoPopup();
														}

													},
													function(err) {
														Spinner.hide();
														$('#start-sign-div,#main-outer,.esig-sign-cancel').hide();
														eSigUtils.logError(err, true);
														eSigUtils.showErrorMsg('#sign-doc-page-sysytem-error');
													    //$('#page-refresh').removeClass('hidden');
														$("#sign-doc-title-contnr").invokeInfoPopup();
														//_self.initInfoPopup();
													}, null, null, _contentType);

								} else {
									$('#linkArea-'
											+ nextSign.signatureSequenceId)[0]
											.scrollIntoView(false);
									setTimeout(function(){
										var _scroller = document.getElementById('inner');
										_scroller.scrollTop = _scroller.scrollTop + 50;
									}, 25);
								}

							}

							function getNextSign(signList, currentPage) {
								// TODO Optimize the code
								function getUnsignedList() {
									var _unsgndLst = [];
									for ( var k = 0; k < signList.length; k++) {

										if (!signList[k].signed) {
											_unsgndLst.push(signList[k]);
										}

									}
									return _unsgndLst;
								}
								var _unsignedArr = getUnsignedList();
								if (_unsignedArr.length == 1) {
									_unsignedArr = [ 0 ]
								} else if (_unsignedArr.length == 0) {
									return _unsignedArr;
								} else {
									for ( var j = 0; j < _unsignedArr.length; j++) {

										if (_unsignedArr[j].signaturePageNumber == lastSigned.pageNo) {

											if (_unsignedArr[j].signatureSequenceId > lastSigned.signNo) {
												nextSignFound = true;
												break;
											}

										} else if (_unsignedArr[j].signaturePageNumber > lastSigned.pageNo) {
											nextSignFound = true;
											break;
										}
									}
									if (nextSignFound) {
										return _unsignedArr[j];
									} else {
										return _unsignedArr[0];
									}
								}
								/* Can be removed->Start */
								var _unsignedList = [], nextSignFound = false;
								for ( var i = 0; i < signList.length; i++) {
									if ((Number(signList[i].signaturePageNumber) >= currentPage)
											&& (!signList[i].signed)) {
										if ((Number(signList[i].signaturePageNumber) == currentPage)) {
											if (Number(signList[i + 1])) {
												if (!Number(signList[i + 1].signed)) {
													nextSignFound = true;
													break;
												}
											} else {
												_unsignedList.push(signList[i]);
											}
										} else {
											nextSignFound = true;
											break;
										}

									}
									if (!signList[i].signed) {
										_unsignedList.push(signList[i]);
									}
								}
								if (nextSignFound) {
									return signList[i];
								} else {
									if (_unsignedList.length > 0) {
										return _unsignedList[0];
									} else {
										console.log("All signature signed");
										return _unsignedList;
									}
								}
								/* Can be removed->end */
							}
							;

						},
						findCurrentPage : function() {
							var _currPage = null, _scrollTop, _imgHeight;
							var _innerCntr = $('#inner');
							_scrollTop = _innerCntr.scrollTop();
							_imgHeight = $('#data-1 img').height();
							if (_scrollTop == 0) {
								_currPage = 1;
							} else {
								_currPage = Math.ceil(_scrollTop / _imgHeight);
							}
							return _currPage;
						},
						btnCancelSignClick : function() {
							/*
							 * Need to reset the models which was changed when
							 * placing signature function invoked. Once if
							 * placeSignature() is invoked the signed attribute
							 * inside the model will be set as true. So we need
							 * a reset as user signs once and then cancels the
							 * flow.
							 */
							var _self = this;
							if (_self.signedSignatureCount > 0) {
								BootstrapDialog
										.confirm(
												"Cancel",
												"All your work will be lost.  Are you sure you want to cancel?",
												function(confirm) {
													if (confirm) {
														_self.clearSignStatusAndNavigate();
														_self.logAudit(104);
													}
												},'esig-cancel-modal');
							} else {
								_self.clearSignStatusAndNavigate();
								_self.logAudit(104);
							}
						},

						clearSignStatusAndNavigate : function() {
							var _self = this;
							if(this.model){
								var _el = this.model.get('documentSignerSignature');
								for ( var i = 0; i < _el.length; i++) {
									_el[i].signed = false;
									_el[i].signatureData = "";
								}
								this.model.set('documentSignerSignature', _el);
							}
							// this.cleanup(); //not sure to uncomment
							Backbone.history.navigate("eSig/req-signers-list/"
									+ _self.docId, true);
						},

						createSignatureLink : function(signatureObject, isFirst) {
							var linkArea, imgWidth, imgHeight, coordinates, linkX, linkY;
							linkArea = document.createElement("a");
							imgWidth = $(
									'#data-'
											+ signatureObject.signaturePageNumber
											+ ' img').width();
							imgHeight = $(
									'#data-'
											+ signatureObject.signaturePageNumber
											+ ' img').height();
							coordinates = this
									.calculateCoordinates(signatureObject.signatureSequenceId);
							linkX = parseInt((coordinates[0] * imgWidth)
									- (this.signOffsetX));
							linkY = parseInt((coordinates[1] * imgHeight)
									- (this.signOffsetY));

							$(".data-" + signatureObject.signaturePageNumber)
									.append(linkArea);
							linkArea.setAttribute("id", "linkArea-"
									+ signatureObject.signatureSequenceId);
							linkArea
									.setAttribute("href", "javascript:void(0);");
							linkArea.setAttribute("class", "sign-link");
							// linkArea.innerText = "Sign here";
							linkArea.setAttribute("data-page",
									signatureObject.signaturePageNumber);
							linkArea.setAttribute("data-sequence",
									signatureObject.signatureSequenceId);
							var _percentLinkX = (linkX/imgWidth)*100;
							var _percentLinkY = (linkY/imgHeight)*100;

							document.getElementById("linkArea-"
									+ signatureObject.signatureSequenceId).style.left = 'calc('+_percentLinkX+'% + 15px)';
							document.getElementById("linkArea-"
									+ signatureObject.signatureSequenceId).style.bottom = _percentLinkY +'%';
							document.getElementById("linkArea-"
									+ signatureObject.signatureSequenceId).style.height = Math
									.min(25, imgHeight * 4 * 0.01)
									+ 'px';
						},
						calculateCoordinates : function(signatureSeqId,
								signerId) {
							var _signX, _signY, _signs, _dateX, _dateY, _signXRatio, _signYRatio, _dateXRatio, _dateYRatio, coordinates;
							signatureSeqId = Number(signatureSeqId);

							if (signerId) {
								var signedClient = SignCollection.get(signerId);
								_signs = signedClient
										.get('documentSignerSignature');
							} else {
								_signs = this.model
										.get('documentSignerSignature');
							}

							for (i = 0; i < _signs.length; i++) {
								if ((_signs[i].signatureSequenceId == signatureSeqId)) {// &&
									// (!_signs[i].signed)
									_signX = _signs[i].signatureX;
									_signY = _signs[i].signatureY;
									_dateX = _signs[i].dateX;
									_dateY = _signs[i].dateY;
									break;
								}
							}
							var _y = this.documentY;
							if (_signY >= this.refYh) {
								_y = this.documentYh;
							}
							if (_signY <= this.refYl) {
								_y = this.documentYl;
							}
							_signXRatio = ((_signX / this.documentX));
							_signYRatio = ((_signY / _y));
							_dateXRatio = ((_dateX / this.documentX));
							_dateYRatio = ((_signY / _y));
							coordinates = [ _signXRatio, _signYRatio,
									_dateXRatio, _dateYRatio ];
							return coordinates;
						},
						handleLinkClick : function(e) {
							var _self = this;
							// function to do
							// 1. Checks whether previous signature has made
							// 1.1 If yes apply the previous signature and place
							// it
							// 1.2 If no choose
							// var _linkAttr = $(e.target).attr('data-attr');
							var _linkPage = {
								"pageNo" : $(e.target).attr('data-page'),
								"signSequence" : $(e.target).attr(
										'data-sequence')
							};
							if (!this.signature) { /*
													 * check if signature is
													 * captured earlier
													 */
							    if (this.deviceinfo.hardware.type == "Phone") {
									BootstrapDialog.alert('eSig is not supported in this device.', null, 'eSig','esigPortrtWarng');
								} else {
									if(_self.model.get('documentSignerSignature')[0].signerContextCd == "COLA" && _self.model.get('additionalVerficationNeeded') =="true"){
										var _dialogBody = '<div class="esig-warn-container"><h3 class="pt-warning-head">Signature verification required</h3>'
															+'<p class="pt-warning-para">Before transactions are processed, all signatures will be reviewed to verify the authenticity of the transaction.'
															+' To ensure timely processing, make sure a legible signature is collected.</p></div>'
															+'<div class="esig-tips-wrapper"><ul class="esig-sign-tips pt-para-medium">Tips for signature collection when signing:'
															+'<li>Always use a stylus</li>'
															+'<li>Lay the device on a hard surface</li>'
															+'<li>Review your signature in capture window before clicking Accept. If you need to re-sign, click Clear Signature.</li>'
															+'</ul></div>';
//										BootstrapDialog.confirm( "Sign Validation",
//												_dialogBody,function(confirm) {
//												 if (confirm) {
//													 _self.showSignaturePad(_linkPage);
//													 _self.initialiseSignaturePad();
//												 }
//										},'',"Cancel","Accept");
										
										
										BootstrapDialog.show({
											title : 'Important instructions',
											message : _dialogBody,
											closeByBackdrop: false,
											cssClass : 'esig-sign-valdtn-contnr',
											buttons : [
													{
														label : 'Cancel '
																+ '<i class="icon-arrow-right"></i>',
														cssClass : 'generic-button cancel-button',
														action : function(dialog) {
															dialog.close();
														}
													},
													{
														label : 'Accept',
														cssClass : 'generic-button accept-button',
														id : '',
														action : function(dialog) {
															
															 _self.showSignaturePad(_linkPage);
															 _self.initialiseSignaturePad();
//															Backbone.history
//																	.navigate("eSig/req-signers-list/"+_self.selectedDocId,true);
															dialog.close();
														}
													} ]
										});
										
										
										
									}else{
										this.showSignaturePad(_linkPage);
										this.initialiseSignaturePad();
									}
									
								}

							} else {
							    var _sel = this;
							    setTimeout(function () {
							        _sel.placeSignature(_linkPage);
							        _sel.logAudit(107);
							    },110);
								
							}
						},
						placeSignature : function(signObject, signerId) {
							/*
							 * Note: placeSignature() can be invoked in 3 ways
							 * 1. From accept button click of the signature pad
							 * 2. From the link in the document, if the user
							 * already signed once in the sign pad 3. After
							 * loading all pages this function may be invokeed
							 * to place the signatures of the clients who had
							 * signed the same document. For eg: two clients
							 * husband and wife. When husband signs and if wife
							 * logs in she need to see the sign of the husband
							 * in the document.
							 */

							var _el, _self = this, _pageNo, imgWidth, imgHeight, _canvas, _imgURL, coordinates, signX, signY, dateX, dateY, sigArea, dateArea, _seqNo, groupArea, _sH, _sW, _dH, _dW;

							if (signObject && signObject.signed) {
								_imgURL = signObject.signatureData;
								_pageNo = signObject.signaturePageNumber;
								_seqNo = Number(signObject.signatureSequenceId);
								calculateSignAndDatePosition(signerId);
								positionSignAndDate();

							} else {
								_el = this.model.get('documentSignerSignature');
								_canvas = $('.sign-pad-canvas')[0];
								/*
								 * If signature is placed then use that
								 * signature
								 */// "image/png"
								this.signature = (this.signature != null) ? this.signature
										: _canvas.toDataURL("image/png");
								_imgURL = this.signature;

								lastSigned.pageNo = signObject.pageNo;
								lastSigned.signNo = signObject.signSequence;
								_pageNo = signObject.pageNo;
								_seqNo = Number(signObject.signSequence);
								_self.currentSignatureIndex = getIndexOf(_el,
										"signatureSequenceId", _seqNo);

								calculateSignAndDatePosition();
								positionSignAndDate();

								_self.closeSignPad();
								_self.signedSignatureCount += 1;
								_el[_self.currentSignatureIndex].signed = true;
								_el[_self.currentSignatureIndex].signatureData = _imgURL;
								_self.model.set('documentSignerSignature', _el);
								_self.changeButtonLabels();
								$('#linkArea-' + _seqNo).remove();
							}

							function calculateSignAndDatePosition(signerId) {
								imgWidth = $('#data-' + _pageNo + ' img')
										.width();
								imgHeight = $('#data-' + _pageNo + ' img')
										.height();

								coordinates = _self.calculateCoordinates(
										_seqNo, signerId);
								signX = parseInt((coordinates[0] * imgWidth)
										- (_self.signOffsetX)); // 300/72
								signY = parseInt((coordinates[1] * imgHeight)
										- (_self.signOffsetY));
								dateX = parseInt((coordinates[2] * imgWidth))
										- (_self.dateOffsetX);
								dateY = parseInt((coordinates[3] * imgHeight))
										- (_self.dateOffsetY);

								/* date and signature height and width */
								_sH = Math.min(25, imgHeight * 4 * 0.01);
								if(navigator.userAgent.match(/Trident/)){
									_sH = 40; 
						        }
								var _signWdthConst = 40, _dateWdthConst = 10;
								if (_$window.width() < 650) {
									_signWdthConst = 35;
									_dateWdthConst = 25;
								}
								_sW = Math.min(
										imgWidth * _signWdthConst * 0.01, 200);
								_dH = Math.min(25, imgHeight * 4 * 0.01);
								_dW = imgWidth * _dateWdthConst * 0.01;

							}

							function positionSignAndDate() {
								groupArea = document.createElement("div");
								$(".data-" + _pageNo).append(groupArea);
								groupArea.setAttribute("class",
										"sign-area-group");
								groupArea.setAttribute("id", "sign-group-"
										+ _seqNo);
								groupArea.setAttribute("data-group", _seqNo);
								sigArea = document.createElement("img");
								// $(".data-" + _pageNo).append(sigArea);
								$("#sign-group-" + _seqNo).append(sigArea);

								sigArea.setAttribute("id", "sigArea-" + _seqNo);
								sigArea.setAttribute("class", "signArea");
								sigArea.setAttribute("src", _imgURL);
								sigArea.style.height = _sH + 'px';
								sigArea.style.width = _sW + 'px';
								var _percentX = (signX/imgWidth)*100;
								var _percentY = (signY/imgHeight)*100;
								dateArea = document.createElement("label");
								// $(".data-" + _pageNo).append(dateArea);
								$("#sign-group-" + _seqNo).append(dateArea);
								dateArea.setAttribute("id", "dateArea-"
										+ _seqNo);
								dateArea.setAttribute("class", "dateArea");
								dateArea.style.height = _dH + 'px';
								dateArea.style.width = _dW + 'px';

								groupArea.style.height = (_sH) + 'px';
								groupArea.style.width = (_sW + _dW) + 'px';
								$("#sign-group-" + _seqNo).css('left',
										(_percentX) + '%');
								$("#sign-group-" + _seqNo).css('bottom',
										(_percentY) + '%');
								$("#sign-group-" + _seqNo + " .dateArea").text(
										_self.dateTime());
								$("#sigArea-" + _seqNo).css("left", "2px");
								$("#dateArea-" + _seqNo).css("right", "2px");

							}
							

							function getIndexOf(arr, key, val) {
								for ( var i = 0; i < arr.length; i++) {
									if (arr[i][key] === val) {
										return i;
									}
								}
								return -1;
							}

						},
						adjustSignature : function() {
							/*
							 * Adjust the signature on orientation change On
							 * orientation change three parts needs change 1
							 * Link area 2 Placed signature 3 Date area
							 * 
							 * Logic: 1. Get image height and width on
							 * orientation change 2. Get the signed signatures
							 * from model 3. Loop through each signature object
							 * 3.1 Fetch coordinates, pageNumber for isSigned =
							 * true 3.2 Calculate ratio of coordinates 3.3 Place
							 * signature,date 4. Get the link coordinates from
							 * model
							 * 
							 */

							var _self = this, _currPage, _imgHeight, _imgWidth, _signModel, _signX, _signY, _dateX, _dateY, _linkX, _linkY, _signXRatio, _signYRatio, _dateXRatio, _dateYRatio, _linkPage, _linkXRatio, _linkYRatio, _signArea, _linkArea, _dateArea, _groupArea; // TODO

							var _signWidthConst, _dateWidthConst, _sH, _sW, _dH, _dW;

							_currPage = this.findCurrentPage();
							_imgWidth = $('#data-' + _currPage + ' img')
									.width();
							_imgHeight = $('#data-' + _currPage + ' img')
									.height();

							/* date and signature height and width */
							_sH = Math.min(25, _imgHeight * 4 * 0.01);
							if(navigator.userAgent.match(/Trident/)){
								_sH = 40; 
					        }
							_signWidthConst = 40, _dateWidthConst = 10;
							if (_$window.width() < 650) {
								_signWidthConst = 35;
								_dateWidthConst = 25;
							}
							_sW = Math.min(_imgWidth * _signWidthConst * 0.01,
									200);
							_dH = Math.min(25, _imgHeight * 4 * 0.01);
							_dW = _imgWidth * _dateWidthConst * 0.01;

							/* date and signature height and width */
							SignCollection.models
									.forEach(function(model, index, array) {
										_signModel = model
												.get('documentSignerSignature');
										for ( var i = 0; i < _signModel.length; i++) {
											var _y = _self.documentY;
											if (_signModel[i].signatureY >= _self.refYh) {
												_y = _self.documentYh;
											}
											if (_signModel[i].signatureY <= _self.refYl) {
												_y = _self.documentYl;
											}
											if (_signModel[i].signed) {
												_signXRatio = ((_signModel[i].signatureX / _self.documentX));
												_signYRatio = ((_signModel[i].signatureY / _y));
												_dateXRatio = ((_signModel[i].dateX / _self.documentX));
												_dateYRatio = ((_signModel[i].dateY / _y));

												_signX = parseInt((_signXRatio * _imgWidth)
														- (_self.signOffsetX));
												_signY = parseInt((_signYRatio * _imgHeight)
														- (_self.signOffsetY));
												_dateX = parseInt((_dateXRatio * _imgWidth)
														- (_self.dateOffsetX));
												_dateY = parseInt((_dateYRatio * _imgHeight)
														- (_self.dateOffsetY))

												_groupArea = document
														.getElementById("sign-group-"
																+ _signModel[i].signatureSequenceId);
												_groupArea = document
														.getElementById("sign-group-"
																+ _signModel[i].signatureSequenceId);
												_signArea = document
														.getElementById("sigArea-"
																+ _signModel[i].signatureSequenceId);
												_dateArea = document
														.getElementById("dateArea-"
																+ _signModel[i].signatureSequenceId);

												if (_signArea) {
													_signArea.style.left = 2 + 'px';
													_signArea.style.height = _sH
															+ 'px';
													_signArea.style.width = _sW
															+ 'px';
												}
												if (_dateArea) {
													_dateArea.style.right = 2 + 'px';
													_dateArea.style.height = _dH
															+ 'px';
													_dateArea.style.width = _dW
															+ 'px';
												}
												var _percentX = (_signX/_imgWidth)*100;
												var _percentY = (_signY/_imgHeight)*100;
												if (_groupArea) {
													_groupArea.style.left = _percentX
															+ '%';
													_groupArea.style.bottom = _percentY
															+ '%';
													_groupArea.style.height = _sH
															+ 'px';
													_groupArea.style.width = (_sW + _dW)
															+ 'px';
												}

											} else {
												_linkXRatio = ((_signModel[i].signatureX / _self.documentX));
												_linkYRatio = ((_signModel[i].signatureY / _y));
												_linkX = parseInt((_linkXRatio * _imgWidth)
														- (_self.signOffsetX));
												_linkY = parseInt((_linkYRatio * _imgHeight)
														- (_self.signOffsetY));
												_linkArea = document
														.getElementById("linkArea-"
																+ _signModel[i].signatureSequenceId);
												var _percentX = (_linkX/_imgWidth)*100;
												var _percentY = (_linkY/_imgHeight)*100;
												if (_linkArea) {
													_linkArea.style.left = 'calc('+_percentX+'% + 15px)';
													_linkArea.style.bottom = _percentY
															+ '%';
													_linkArea.style.height = Math
															.min(
																	25,
																	_imgHeight * 4 * 0.01)
															+ 'px';
												}

											}
										}
									});

							adjustScrollTop();

							function adjustScrollTop() {
								// TODO: Find a proper solution Find the
								// scrolltop ratio using some equation
								var _prevScrollTop, scrollTopRatio, _currentScrollTop;
								_self.prevImgHeight = Number(_self.currentImgHeight);
								_self.currentImgHeight = Number(_imgHeight);

								_prevScrollTop = $('#inner').scrollTop();
								scrollTopRatio = (_self.currentImgHeight / _self.prevImgHeight);
								_currentScrollTop = (scrollTopRatio * _prevScrollTop);
								$('#inner').scrollTop(_currentScrollTop);
							}
							;
						},
						changeButtonLabels : function() {
							var _self = this, _$el = $('#startSign');
							var _$el = $('#startSign');
							if (_self.signedSignatureCount === _self.totalSignCount) {
								_$el.text('Done');
								_$el.attr('data-action', 'done');

							} else if (_self.signedSignatureCount < _self.totalSignCount) {
								_$el
										.html('Next <i class="icon-arrow-right-white"></i>');
								_$el.attr('data-action', 'next');
							}
						},
						/* Signature Pad methods */
						initialiseSignaturePad : function() {
							var _$canvas = $('.sign-pad-canvas');
							if (_$window.width() < 767) {
								var _availableWidth = window.innerWidth;
								var _availableHeight = window.innerHeight;
								var _minWidth = Math.min(_$window.width(),
										_$window.height());
								var _maxWidth = Math.max(_$window.width(),
										_$window.height());
								if (_minWidth < 420) {
								    var _signPadHeight = (_availableHeight - 40);
								    var _marginTop = $('body')[0].scrollTop;
								    if (eSigUtils.isMobile()) {
								        $('#signature-pad').css({
								            // width 70%
								            'width': Math.max(400, _availableWidth * .95) + 'px',
								            'height': Math.max(_signPadHeight, 99)
													+ 'px',
								            'margin-top': _marginTop+'px'
								        });
										
									}else{
								        $('#signature-pad').css({
								            // width 70%
								            'width': Math.max(400, _maxWidth * .95) + 'px',
								            'height': Math.max(_$window.height() * 0.8, 99)
													+ 'px'
								        });
									}
									
								}
								_$canvas.attr({
									'width' : _$canvas.width(),
									'height' : _$canvas.height()
								});
							} else {
								_$canvas.attr({
									'width' : '656',
									'height' : '199'
								});
							}
							this.signaturePad = new SignaturePad(_$canvas[0]);
						},
						clearSignPad : function(e) {
							this.signaturePad.clear();
						},
						acceptSignPad : function(e) {
							var _linkObj = {
								"pageNo" : $('#accept-button-sign-pad').attr(
										'data-page'),
								"signSequence" : $('#accept-button-sign-pad')
										.attr('data-sequence')
							};
							if (this.signaturePad.isEmpty()) {
								//alert("Please provide your Signature to Submit.");
							} else {
							    var _sel = this;
							    setTimeout(function () {
							        _sel.placeSignature(_linkObj);
							        _sel.logAudit(103);
							    }, 110);
								
							}
						},
						closeSignPad : function(event) {
							$('#accept-button-sign-pad')
									.removeAttr('data-page');
							// event.stopPropagation();
							$("#overlay-upper").hide();
							this.signaturePad.clear();
						},
						showSignaturePad : function(linkObj) {
							// ADD body overflow hidden
							var _acceptButton = $('#accept-button-sign-pad');
							_acceptButton.attr('data-page', linkObj.pageNo);
							_acceptButton.attr('data-sequence',
									linkObj.signSequence);
							document.getElementById("overlay-upper").style.display = "block";
							document.getElementById("signature-pad").style.display = "block";
						},
						dateTime : function() {
							var today = new Date();
							var dd = this.addZero(today.getDate());
							var mm = this.addZero(today.getMonth() + 1);
							var yyyy = this.addZero(today.getFullYear());
							var today = yyyy + '.' + mm + '.' + dd;
							var dateString = today.toString();
							return dateString;
						},
						addZero : function(i) {
							if (i < 10) {
								i = "0" + i;
							}
							return i;
						},
						disableScroll : function(e) {
							e.stopPropagation();
							if (e.originalEvent.touches)
								if (e.originalEvent.touches.length == 1) {
									e.preventDefault();
									e.stopPropagation();
								}

						},
						disableBgScroll:function(e) {
							e.preventDefault();
							e.stopPropagation();
						},
						endOrientation : function(handler) {
							$(window).off("orientationchange", handler);
						},
						startOrientation : function(handler) {
							$(window).on("orientationchange", handler);
						},
						startResize : function(handler) {
							$(window).resize(handler);
						},
						endResize : function(handler) {
							$(window).off("resize", handler);
						},
						cleanup : function() {
							// this.undelegateEvents();
							this.$el.empty();
						},
						setLeftPanelHeight : function() {
							

						    setTimeout(function () {
						        var $el = $('#practicetech-subapp');
						        var screenHt = Math.floor(_$window.height());
						        var headerHt = Math.floor($('#afinav-navbar')
                                        .height());
						        
						        var _boxShadow = "0 0 "+BOX_SHADOW_WIDTH+"px 5px #ccc";
						        /*
								 * Steps to do: Calculate the boxshadow spread
								 * area for #main-outer div assign that as a
								 * padding to the cancel button This is required
								 * to properly align the cancel button at the
								 * bottom
								 */
						        $el.find("#main-outer").css({
							        "-moz-box-shadow":_boxShadow,
							    	"-webkit-box-shadow":_boxShadow,
							    	"box-shadow": _boxShadow
						        });
						        $el.find( '.esig-sign-cancel').css({"margin-top":BOX_SHADOW_WIDTH+"px"});
						        
						        var _userAgent = navigator.userAgent.toLowerCase();
						        if(_userAgent.indexOf('android') > -1){
						        	var _statusBarHeight = 25;
						            if (_$window.height() < _$window.width()) {
						                if ((screen.height - _statusBarHeight) != window.innerHeight) {
						                    screenHt = screenHt + (screen.height - _statusBarHeight - window.innerHeight);
						                }
						                    
										}
						        }
						        var pageHeaderHt = Math
                                        .floor($el.find('#sign-doc-title-contnr')
                                                .outerHeight(true));
						        var subHeaderHt = Math.floor($el.find(
                                        '.esign-sign-nav').outerHeight(true));
						        var cancelBtnHeight = Math.floor($el.find(
                                        '.esig-sign-cancel').outerHeight(true));

						        // var footerHt =
								// Math.floor($('.footer').height());
						        // //commented since footer should not be shown
						        var bodyHt = screenHt
                                        - (headerHt + pageHeaderHt + subHeaderHt + cancelBtnHeight)
                                        - 1;
						        $('#main-outer').height(bodyHt);

							}, 100)

						}
					});
			return signDocumentView;
		});