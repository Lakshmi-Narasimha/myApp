define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailbeneficiariesview.html'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetAccountBeneficiaries(this.accountSummary.accountId)
                .then(function(beneficiariesData) {
                  var beneficiaries = {};
                  
                  if (beneficiariesData.beneLines && beneficiariesData.beneLines.results && beneficiariesData.beneLines.results.length > 0) {
                  	beneficiaries = beneficiariesData.beneLines.results;
                  }

                  self.renderSection(SectionTemplateHtml, {beneficiaries: beneficiaries, isNonQualified: self.isNonQualified()});
                })
                .fail(this.handleServiceError);
        }
    });

    return SectionView;
});