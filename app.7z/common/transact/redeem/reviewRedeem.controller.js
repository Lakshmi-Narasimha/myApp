/**
 * @ngdoc property
 * @name Review Redeem Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewController($scope, fticLoggerMessage, loggerConstants, $state, eventConstants, redeemModel, redeemReviewDetailsFactory) {
    // $scope.config.toTxnDetailsState = 'transact.txnDetails.redeem';
    $scope.config.toTxnDetailsState = redeemReviewDetailsFactory.getCurrentTxnToState();
    // $scope.config.toState = 'transact.base.redeem';
    $scope.config.toState = redeemReviewDetailsFactory.getCurrentToState();
    $scope.config.fromState = $state.current.name;
    redeemModel.setIsRedeemEdit(false);
    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function() {
        $scope.$emit('NAVIGATE_TO_TRANSACT', { key: 'Redeem' });
    });
}

reviewController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'eventConstants', 'redeemModel', 'redeemReviewDetailsFactory'];
module.exports = reviewController;
