// getNomineeDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var InvNomineeDetailsSchema = new mongoose.Schema({
    nomineeSummary: {
        type: Array,
        'default': []
    }
});

var InvNomineeDetailsLookUp = mongoose.model('InvNomineeDetailsLookUp', InvNomineeDetailsSchema);

var InvNomineeDetailsModel = new InvNomineeDetailsLookUp({
	nomineeSummary:[
      {
         "folioId":"14448928",
         "rows":[
         {
               "accountNo":"00200072629280",
               "nomineeDetails":[
                  {
                     "nomineeName":"SHARADBHAI SUDHIR SONTAKKE",
                     "percentage":"50%",
                     "type":"N1"
                  },
                  {
                     "nomineeName":"HOSANG BOMANJI AJIT TAMHANKAR",
                     "percentage":"20%",
                     "type":"N2"
                  },
                  {
                     "nomineeName":"SISANGIA PADMA JAYASHANKER KESAVBHAI ",
                     "percentage":"30%",
                     "type":"N3"
                  }
               ]
            },
             {
               "accountNo":"00200072629282",
               "nomineeDetails":[
                  {
                     "nomineeName":"SHARADBHAI SUDHIR SONTAKKE",
                     "percentage":"25%",
                     "type":"N1"
                  },
                  {
                     "nomineeName":"HOSANG BOMANJI AJIT TAMHANKAR",
                     "percentage":"25%",
                     "type":"N2"
                  },
                  {
                     "nomineeName":"SISANGIA PADMA JAYASHANKER KESAVBHAI ",
                     "percentage":"50%",
                     "type":"N3"
                  }
               ]
            },
             {
               "accountNo":"00200072629281",
               "nomineeDetails":[
                  {
                     "nomineeName":"SHARADBHAI SUDHIR SONTAKKE",
                     "percentage":"30%",
                     "type":"N1"
                  },
                  {
                     "nomineeName":"HOSANG BOMANJI AJIT TAMHANKAR",
                     "percentage":"30%",
                     "type":"N2"
                  },
                  {
                     "nomineeName":"SISANGIA PADMA JAYASHANKER KESAVBHAI ",
                     "percentage":"10%",
                     "type":"N3"
                  }
               ]
            }
            ]
      },
      {
         "folioId":"24448928",
         "rows":[
            {
               "accountNo":"0020007262928",
               "nomineeDetails":[
                  {
                     "nomineeName":"SHARADBHAI SUDHIR SONTAKKE",
                     "percentage":"25%",
                     "type":"N1"
                  },
                  {
                     "nomineeName":"HOSANG BOMANJI AJIT TAMHANKAR",
                     "percentage":"65%",
                     "type":"N2"
                  },
                  {
                     "nomineeName":"SISANGIA PADMA JAYASHANKER KESAVBHAI ",
                     "percentage":"10%",
                     "type":"N3"
                  }
               ]
            }
         ]
      },
      {
         "folioId":"34448928",
         "rows":[
            {
               "accountNo":"0030007262938",
               "nomineeDetails":[
                  {
                     "nomineeName":"SHAH TILES&POT (M) SUDHIR SONTAKKE",
                     "percentage":"44%",
                     "type":"N1"
                  },
                  {
                     "nomineeName":"SHROFF B KUSHNOOR AJIT TAMHANKAR",
                     "percentage":"28%",
                     "type":"N2"
                  },
                  {
                     "nomineeName":"PUTTASWAMY JAYASHANKER SISANGIA",
                     "percentage":"28%",
                     "type":"N3"
                  }
               ]
            }
         ]
      }
   	]

// POST - changeNominee
	// 'changeNominee' : {
	// 	"folioId": "18330087",
	// 	"accountNo": "1689905857315",
	// 	"webRefNo": "",
	// 	"txnType": "CHGNOM",
	// 	"userType": "10",
	// 	"makerId":"",
	// 	"firstNominee":"ramakanth1",
	// 	"fpercent":"34",
	// 	"secondNominee":"ramakanth2",
	// 	"spercent":"34",
	// 	"thirdNominee":"ramakanth3",
	// 	"tpercent":"32",
	// 	"validation":"Y"//Y-validate (or) N-Register
	// }
});

InvNomineeDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvNomineeDetailsLookUp table, please contact admin...');
    } else {
        InvNomineeDetailsLookUp.remove({}, function(err) {
            console.log('InvNomineeDetailsLookUp collection removed');
            InvNomineeDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvNomineeDetailsLookUp table, please contact admin...');
                }
                console.log('InvNomineeDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvNomineeDetailsLookUp;