var config = require('../../../config/config');

var getMessageModelConfig = {
    response: {
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
            "type": "Success"
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "timeToWait": null,
            "showChatHistory": false,
            "agentBusy": false
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 10004,
                "searchStartIndex": 10000,
                "msgList": [{
                    "animationDuration": 800,
                    "msgId": 10004,
                    "type": "chat",
                    "messageList": [{
                        "loginReq": false,
                    }]
                }],
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
                    "type": "Success"
                }
            }
        }
    },
    endResponse: {
        "ModuleMap": {
            "Support": {
                "msgList": [{
                    "messageList": [{
                        "nextmsgId": 20001,
                        "loginReq": false,
                        "messageText": "Thank you for chatting with Verizon Wireless"
                    }],
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "type": "header",
                    "msgId": 20000,
                    "messageType": "stateChange",
                    "state": "closed"
                }, {
                    "sequenceNumberInt": 20000,
                    "msgId": 20001,
                    "animationDuration": 800,
                    "type": "bot",
                    "messageList": [{
                        "nextmsgId": -1,
                        "loginReq": false,
                        "messageText": "Let me know if you need anything else. I'm always here for you."
                    }]
                }],
                "startMsgId": 20000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "2edfe2c1-970f-4cfe-974d-d458d5f2525a",
                    "type": "Success"
                }
            }
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "timeToWait": null,
            "customerID": "-1196452972424641378",
            "engagementID": "-1196452972424366591",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "2edfe2c1-970f-4cfe-974d-d458d5f2525a",
            "type": "Success"
        }
    },
    surveyResponse: {
        "sessionOver": false,
        "Page": {
            "pageType": "livechat",
            "parentPageType": "myData",
            "engagementID": "-2376958956590268469",
            "customerID": "-2376958956590543256",
            "surveyUrl": "https://app.keysurvey.com/f/1011097/56e5/?LQID=1&BRName=MobileApp-MVTrans&custID=-2376958956590543256&agentID=4594496532@verizon&chatID=-2376958956590268469&busUnitID=19000866&agentGroupID=10004687&clientID=10004593",
            "callType": "getMessage",
            "showChatHistory": false,
            "agentBusy": false
        },
        "ResponseInfo": {
            "locale": "en",
            "requestId": "8da766fd-e3c2-477b-989f-80d1802817fc",
            "buildNumber": "198",
            "code": "00000",
            "type": "Success"
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 20000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "requestId": "8da766fd-e3c2-477b-989f-80d1802817fc",
                    "buildNumber": "198",
                    "code": "00000",
                    "type": "Success"
                },
                "msgList": [{
                    "messageList": [{
                        "nextmsgId": 20001,
                        "loginReq": false,
                        "messageText": "Thank you for chatting with Verizon Wireless"
                    }],
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "type": "header",
                    "msgId": 20000,
                    "messageType": "stateChange",
                    "state": "closed"
                }, {
                    "sequenceNumberInt": 20000,
                    "msgId": 20001,
                    "animationDuration": 800,
                    "type": "bot",
                    "messageList": [{
                        "nextmsgId": 20002,
                        "loginReq": false,
                        "messageText": "Let me know if you need anything else. I'm always here for you."
                    }]
                }, {
                    "type": "link",
                    "msgId": 20002,
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "messageList": [{
                        "messageText": "Hey MzSherri, did Charlie help you out? <a> Take a survey </a>",
                        "nextmsgId": -1,
                        "loginReq": false,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://app.keysurvey.com/f/1011097/56e5/?LQID=1&BRName=MobileApp-MVTrans&custID=-2376958956590543256&agentID=4594496532@verizon&chatID=-2376958956590268469&busUnitID=19000866&agentGroupID=10004687&clientID=10004593",
                                "pageType": "Chat Survey", //custID = customerID// //chatID = engagementID//  //clientID = siteID
                                "actionType": "openURL",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false
                            }
                        }
                    }]
                }, {
                    "type": "bot",
                    "msgId": 20001,
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "messageList": [{
                        "messageText": "Let me know if you need anything else. I'm always here for you.",
                        "nextmsgId": 20002,
                        "loginReq": false
                    }]
                }]
            }
        }
    },
    loginNeededResponse: {
      "ModuleMap" : {
        "Support" : {
          "msgList" : [
            {
              "messageList" : [
                {
                  "loginReq" : false,
                  "messageText" : "login needed"
                }
              ],
              "sequenceNumberInt" : 3,
              "animationDuration" : 800,
              "type" : "chat",
              "msgId" : 10001,
              "messageType" : "chatLine",
              "sequenceNumber" : "3"
            },
            {
              "sequenceNumberInt" : 20000,
              "msgId" : 30000,
              "animationDuration" : 800,
              "type" : "chatContent",
              "messageList" : [
                {
                  "childType" : "contentTitle",
                  "content" : "Please login",
                  "nextmsgId" : -1,
                  "loginReq" : false
                },
                {
                  "ButtonMap" : {
                    "FeedLink" : {
                      "actionType" : "openPage",
                      "pageType" : "enterChatPassword",
                      "extraParameters" : {
                        "alreadyInChat" : "true"
                      },
                      "presentationStyle" : "push",
                      "tryToReplaceFirst" : false,
                      "disableAction" : false,
                      "appContext" : "mobileFirstSS"
                    }
                  },
                  "childType" : "contentOption",
                  "content" : "Yes",
                  "nextmsgId" : -1,
                  "loginReq" : false
                },
                {
                  "childType" : "contentOption",
                  "content" : "No",
                  "nextmsgId" : -1,
                  "loginReq" : false
                }
              ]
            }
          ],
          "startMsgId" : 30000,
          "searchStartIndex" : 10000,
          "ResponseInfo" : {
            "locale" : "en",
            "buildNumber" : "231",
            "code" : "00000",
            "requestId" : "15ca646a-6e04-4e08-b199-19e9acddba3e",
            "type" : "Success"
          }
        }
      },
      "Page" : {
        "status" : "accepted",
        "pageType" : "livechat",
        "parentPageType" : "myData",
        "callType" : "getMessage",
        "timeToWait" : null,
        "showChatHistory" : false,
        "agentBusy" : false
      },
      "sessionOver" : false,
      "ResponseInfo" : {
        "locale" : "en",
        "buildNumber" : "231",
        "code" : "00000",
        "requestId" : "15ca646a-6e04-4e08-b199-19e9acddba3e",
        "type" : "Success"
      }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_GET_MSG_URI
    },
    createSurveyUri: function(params) {
        var types = {
            Billing: {
                path: '&BRName=' + config.BR_Billing + '&custID=' + params.customerID + '&agentID=' + params.agentID + '&chatID=' + params.engagementID + '&clientID=' + config.TC_SITE_ID + '&busUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Billing,
            },
            WirelessSales: {
                path: '&BRName=' + config.BR_WirelessSales + '&custID=' + params.customerID + '&agentID=' + params.agentID + '&chatID=' + params.engagementID + '&clientID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessSales + '&agentGroupID=' + config.AG_WirelessSales,
            },
            Device: {
                path: '&BRName=' + config.BR_Device + '&custID=' + params.customerID + '&agentID=' + params.agentID + '&chatID=' + params.engagementID + '&clientID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Device,
            },
            Global: {
                path: '&BRName=' + config.BR_Global + '&custID=' + params.customerID + '&agentID=' + params.agentID + '&chatID=' + params.engagementID + '&clientID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Global,
            },
            MVTrans: {
                path: '&BRName=' + config.BR_MVTrans + '&custID=' + params.customerID + '&agentID=' + params.agentID + '&chatID=' + params.engagementID + '&clientID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_MVTrans,
            }
        };

        return config.Mobile_CareNoNPS_URL + types[params.agentGroupID].path;
    },

    getSurveyMsg: function(name, agentName) {

        return "Hey " + name + ", did " + agentName + " help you out? <a> Take a survey </a>";
    }
};

module.exports = getMessageModelConfig;
