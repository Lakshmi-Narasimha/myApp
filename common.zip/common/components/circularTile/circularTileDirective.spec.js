/* eslint-disable */
'use strict';

describe('Directive: circular tile', function() {

  var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('commmon.components'));

    
    beforeEach(function() {

    angular.mock.inject(function($rootScope, $compile) {
        scope = $rootScope.$new();
        compile = $compile;
        scope.tiledataWithOneProp ={
        	colorClass:"circular-tile-orange",
        	prop1:"20",
        	lable:"email"
        }  

        scope.tiledataWithTwoProp ={
        	colorClass:"circular-tile-orange",
        	prop1:"900",
        	prop2:"9.43",
        	lable:"Total SIPs"
        }

        scope.type = "rg";
        
        //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-circular-tile type="type" tiledata="tiledataWithTwoProp"></ftic-circular-tile>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

  it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should define circular-tile element', function() {
        expect(directiveEle.html()).toBeDefined();
    });

    // it('should define colorClass to circular-tile-orange', function() {       
    //     expect(isoScope.tiledataWithTwoProp.colorClass).toEqual('circular-tile-orange');
    // });

    // it('should define tiledata as an object', function() {       
    //     expect(isoScope.tiledataWithTwoProp).toEqual(tiledataWithTwoProp);
    // });

	 // it('should change commission paid details on click of last month day button', function() {
	 //    	isoScope.type = 'rg';
	 //    	var value = directiveEle.find('.prop-2');
	 
	 //    	// isoScope.changeCommissionPaidDetails(isoScope.commissionPaidDetials);
	 //    	// expect(isoScope.commissionPaidBindingDetials.commissionPaid).toBe("Rs 3L");
	 //    	// expect(isoScope.commissionPaidBindingDetials.date).toBe('Jan 2016');
	 //    });

   

});