define([
  'jquery',
  'underscore',
  'backbone',
  'config',
  'spinner',
  'typeahead',
  'appcommon/constants',
  'appmodules/nav/app/models/contactdetails',
  'appcommon/commonutility',
  'services/dataservice',
  'appcommon/globalcontext',
  'errorLog',
], function ($, _, Backbone, Config, Spinner, Typeahead, Constants, ContactDetailsModel, CommonUtility, DataService, GlobalContext, ErrorLog) {
    var _self = null;
	var calendContactSearcharview = Backbone.View.extend({
    	el: $("#practicetech-subapp"),
        id: '#practicetech-subapp',
        events: {
            "focus #calsearch": "txtBoxOnFocus",
            "blur #calsearch": "txtBoxOnBlur",
            "input #calsearch": "serachBoxChangeHandler",
            "click #cal-search-clear": "clearSearch",
            "click #cal-clients-list, #cal-prospects-list": "calContactSearch",
            /*"click #cal-contact-add-free-txt": "freeTxtHandler",*/
            "click #contact-del":"contactDelete"
        },
        initialize: function () {
        	this.globalContext = GlobalContext.getInstance();
        	this.calContactSearchBox = $("#calsearch");
        	this.searchTimeout = null;
            this.lastKeyword = null;
        	this.contactSearchType = "client";
        	this.keywordSearchRequired = ContactDetailsModel.advsiorContacts.getContactSearchType(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID);
        	 _self = this;
        	$(document).off("click",".cal-contact-add-free-txt").on("click",".cal-contact-add-free-txt",function(e){_self.freeTxtHandler();});
        	
        },
        setClientSelectedAlways : function(){
        	$("#cal-contact-search-div a").removeClass('hdr-tab-active');
            $("#cal-clients-list").addClass('hdr-tab-active');
        	this.contactSearchType = $("#cal-clients-list").data("search-type");
        	this.noRecordsFound(false);
            this.lastKeyword = null;
        },
        calContactSearch: function (e) {
            e.preventDefault();
            var target = e.target || e.currentTarget;
            var contactLnks = $("#cal-contact-search-div a");
            //if (contactLnks.hasClass('hdr-tab-active')) {
                contactLnks.removeClass('hdr-tab-active');
                $(target).addClass('hdr-tab-active');
            //}
            this.contactSearchType = $(target).data("search-type");
            $(".typeahead").hide();
            this.noRecordsFound(false);
            this.lastKeyword = null;
            ContactDetailsModel.advsiorContacts.clearContacts(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID,((this.keywordSearchRequired) ? true : false));
            this.calContactSearchBox.focus();
            if(this.calContactSearchBox.val().length>0){
            	this.calContactSearchBox.trigger("keyup");
            }
          //function to call show/hide contact search tabs / no records found
            
        },
        clearSearch: function (e) {
            var $contSearchDiv = $('#cal-contact-search-div');
        	this.calContactSearchBox.val('').focus();
            if (!$contSearchDiv.is(':visible')) { $contSearchDiv.show(); /*$contSearchDiv.css('border-radius', '6px 6px 6px 6px');*/ }
            if ($(".typeahead").is(':visible')) { $(".typeahead").hide(); }
            if ($("#cal-no-records-found").is(':visible')) { $("#cal-no-records-found").hide(); }
        },
        contactDelete: function (e) {
            var parentTgt = e.currentTarget.parentElement.id;
            if (!($('#' + parentTgt).hasClass('hidden'))) { $('#' + parentTgt).addClass('hidden'); $(".more-opts-arrow.sel-contact").attr("id", "").html(""); }
            $("form#calContactSearch .typeahead").css('max-height', '402px');
        },
        keywordSearch : function(process){
        	var _that = this;
        	var serachKey = _that.calContactSearchBox.val();
        	if(_that.searchTimeout){
    			clearTimeout(_that.searchTimeout);
    		}
    		_that.searchTimeout = setTimeout(function(){
    			serachKey = _that.calContactSearchBox.val();
    			if(serachKey && serachKey.length>2){
    				_that.lastKeyword = serachKey;
    				_that.processTheKeywordSearch(serachKey,process);
    			}
    		},Config.contactListTimeout);
        },
        searchInExistingKey : function(key){
            if (key) {
                try{
                    if(key.search(new RegExp("^"+this.lastKeyword+"", "i")) == -1){
                        return true;
                    }
                }
                catch (err) {
                    var _customLog = {
                        "message": "Custom log - searchInExistingKey()",
                        "stack": {
                            "description": "Key: " + key + "; Error: " + err.message
                        }
                    }
                    ErrorLog.ErrorUtils.myError(_customLog, true);
                    return true;
                }
        	}
        	return false;        	
        },
        processTheKeywordSearch : function(serachKey,process){
        	var _that = this;
        	if(_that.contactSearchType == "client"){
				_that.searchClientList(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID,serachKey,process);
			}else if(_that.contactSearchType == "nonclient"){
				_that.searchProspectList(CommonUtility.readCookie('FMID'),serachKey,process);
			}
        },
        noRecordsFound: function (show,msg) {
        	msg = msg || 'No records found.';
            if(show) {
            	 $("#cal-no-records-found span:first").text(msg);
                 $("#cal-no-records-found").show();
                 _self.delegateEvents();
            } else {
                $("#cal-no-records-found").hide();
            }
        },
        searchClientList: function (fmid,keyWord, process) {
            var that = this;
            var filter = undefined;
           // if (!ContactDetailsModel.advsiorContacts.isExist(fmid)) {
                if(keyWord){
                    //Spinner.show({ inline: true, parentElement: 'calContactSearch', serachBox: true });
                    Spinner.show({ inline: true, parentElement: 'cal-contact-search-div', serachBox: false });
                    
                	filter = "startswith(firstNm,'"+keyWord+"') eq true  or startswith(lastNm,'"+keyWord+"') eq true";
                	DataService.getClients(fmid,Config.contactListLimit,filter,[404]).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);
                }
                function gotoAsyncCallSuccess(result) {
                	var actualResult = (result[0] && result[0]['results']) ? result[0]['results'] : null;
                	//function to call show/hide contact search tabs / no records found
                	if(!actualResult){
                		that.noRecordsFound(true,'No client records found for the selected advisor.');
                	}else{
                        that.noRecordsFound(((actualResult && actualResult.length >0) ? false : true));
                	}
                    

                    if (result[0]) {
                    	ContactDetailsModel.advsiorContacts.AddContactDetails(fmid, actualResult, Constants.contactType.Client,true);
                    	if(process){
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(fmid,Constants.contactType.Client));
                    	}
                    }
                    DataService.clearCacheManager(Constants.subAppName.Navigator);
                    //Spinner.hide({ inline: true, parentElement: 'calContactSearch' });
                    Spinner.hide({ inline: true, parentElement: 'cal-contact-search-div' });
                };
                function gotoAsyncCallError(err) {
                    //Spinner.hide({ inline: true, parentElement: 'calContactSearch' });
                    Spinner.hide({ inline: true, parentElement: 'cal-contact-search-div' });
                };
            //}
        },
        searchProspectList : function (fmid,keyWord, process) {
            var that = this;
            var filter = undefined;
           // if (!ContactDetailsModel.advsiorContacts.isExist(fmid)) {
                if(keyWord){
                    //Spinner.show({ inline: true, parentElement: 'calContactSearch', serachBox: true });
                    Spinner.show({ inline: true, parentElement: 'cal-contact-search-div', serachBox: false });
                    
                	DataService.getNonClients(fmid,false,keyWord).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);
                }
                function gotoAsyncCallSuccess(result) {
                	var actualResult = result[0].get("clientRefs") || null;
                    //function to call show/hide contact search tabs / no records found
                    that.noRecordsFound(((actualResult && actualResult.length < 1) ? true : false));
                    
                    if(actualResult) {
                    	ContactDetailsModel.advsiorContacts.AddContactDetails(fmid, actualResult, Constants.contactType.NonClient,true);
                    	if(process){
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(fmid,Constants.contactType.NonClient));
                    	}
            }
                    DataService.clearCacheManager(Constants.subAppName.Navigator);
                    //Spinner.hide({ inline: true, parentElement: 'calContactSearch' });
                    Spinner.hide({ inline: true, parentElement: 'cal-contact-search-div' });
                };
                function gotoAsyncCallError(err) {
                    //Spinner.hide({ inline: true, parentElement: 'calContactSearch' });
                    Spinner.hide({ inline: true, parentElement: 'cal-contact-search-div' });
                };
            //}
        },
        changeClientsCource: function () {

            //var that = this;
            _self.calContactSearchBox.typeahead({
                items: 1000,
                minLength: 3,
                highlighter: function (items) {

                    /* For Add/Edit/Delete contact from Add Appointment */
                    if (!$('.pinned-client-in-add-appt').hasClass('hidden')) { $("form#calContactSearch .typeahead").css('max-height', '345px'); }

                    var matchSpan = '<span class="highlight">';
                    var leftAlign = '<span class="pull-left clearfix truncate pt-dropdown-client-name">';
                    var rightAlign = '<span class="pull-right clearfix pt-dropdown-client-id">';
                    var endSpan = '</span>';
                    var clientID = '';
                    if (items.indexOf("Contact.") >= 0) {
                        clientName = items.substr(0, items.indexOf("Contact.") - 1);
                        clientID = items.substr(items.indexOf("Contact."));
                    }
                    else {
                        clientName = items.substr(0, items.length - 9);
                        clientID = items.substr(items.length - 8);
                    }
                    var queryclientName = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                    var tmpclientName = clientName.replace(new RegExp('(' + queryclientName + ')', 'ig'), function ($1, match) {
                        return matchSpan + match + '</span>';
                    });
                    var queryclientID = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                    var tmpclientID = clientID.replace(new RegExp('(' + queryclientID + ')', 'ig'), function ($1, match) {
                        return matchSpan + match + '</span>';
                    });

                    if (items.indexOf("Contact.") >= 0) {
                        return leftAlign + tmpclientName + endSpan + '<span id="mySpan" hidden = "hidden">' + clientID + '</span>';
                    }
                    else {
                        return leftAlign + tmpclientName + endSpan + rightAlign + tmpclientID + endSpan + '<span id="contactSpanId" hidden = "hidden">' + clientID + '</span>';
                    }
                },
                sorter: function (items) {
                	if(items.length === 0){
                		_self.noRecordsFound(true);
                	}
                    return items.sort();
                },
                source: function (query, process) {
                    var serachKey = _self.calContactSearchBox.val();
                    _self.contactSearchType = $('#cal-prospects-list').hasClass('hdr-tab-active')?'nonclient':'client';
                    var currentAdvisor = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
                    if(serachKey && _self.keywordSearchRequired && _self.contactSearchType == "client"){
                    	if(serachKey.length>=3 && _self.searchInExistingKey(serachKey)){
                    		_self.keywordSearch(process);
                    	}else{
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(currentAdvisor,_self.contactSearchType));
                    	}
                    }else if(serachKey && !_self.keywordSearchRequired && _self.contactSearchType == "client"){
                    	var fetchedContacts = ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(currentAdvisor,_self.contactSearchType);
                    	if(fetchedContacts && fetchedContacts.length>0){
                    		process(fetchedContacts);
                    	}else{
                    		_self.noRecordsFound(true,'No client records found for the selected advisor.');
                    	}
                    }else if(serachKey && _self.contactSearchType == "nonclient"){
                    	if(serachKey.length>=3 && _self.searchInExistingKey(serachKey)){
                    		_self.keywordSearch(process);
                    	}else{
                    		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(CommonUtility.readCookie('FMID'),_self.contactSearchType));
                    	}
                    }else{
                		process(ContactDetailsModel.advsiorContacts.GetTypeAheadSourceInFormat(currentAdvisor));
                	}
                },
                matcher: function (item) {
                    var queryclientName = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
                    if (item.indexOf("Contact.") >= 0) {
                        if (item.substr(0, item.indexOf("Contact.") - 1).search(new RegExp(queryclientName, "i")) != -1) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    }
                    else {
                        if (item.search(new RegExp(queryclientName, "i")) != -1) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    }
                },
                updater: function (item) {
                    var selContactId = '';
                    var contactType;
                    if (item.indexOf("Contact.") >= 0) {
                    	setTimeout(function(){
                    		selContactId = item.substr(item.indexOf("Contact."));
                            item = item.substr(0, item.indexOf("Contact."));
                            contactType = Constants.contactType.NonClient;
                            //_self.calContactSearchBox.val(" " + item + " ");
                            _self.calContactSearchBox.val("");
                            if ($('.pinned-client-in-add-appt').hasClass('hidden')) { $('.pinned-client-in-add-appt').removeClass('hidden'); }
                            $(".more-opts-arrow.sel-contact").attr("id", selContactId);
                            $(".more-opts-arrow.sel-contact, .pinned-client-in-add-appt .val").html(item);
                            $("form#calContactSearch .typeahead").css('max-height','345px');
                            _self.setClientSelectedAlways();
                            //$("#newEvent").click();
                    	},200);
                    }
                    else {
                        var clientId = ContactDetailsModel.advsiorContacts.getSelectedContactId(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID, item, Constants.contactType.Client);
                        contactType = Constants.contactType.Client;
                        Spinner.show();
                        DataService.getContactDetailsbyClientId(CommonUtility.readCookie('FMID'),clientId).done(function(response){
                        	Spinner.hide();
                        	if(response && response[0] && response[0].attributes && response[0].attributes.contactId){
                        		selContactId = response[0].get('contactId');
                        		if ($('.pinned-client-in-add-appt').hasClass('hidden')) { $('.pinned-client-in-add-appt').removeClass('hidden'); }
                        		$(".more-opts-arrow.sel-contact").attr("id", selContactId);
                        		$(".more-opts-arrow.sel-contact, .pinned-client-in-add-appt .val").html(item.substring(0, item.length - 9));
                        		$("form#calContactSearch .typeahead").css('max-height', '345px');
                        	    //_self.calContactSearchBox.val(item.substring(0, item.length - 9));
                                _self.calContactSearchBox.val("");
                                _self.setClientSelectedAlways();
                                //$("#newEvent").click();
                        	}else{
                        		 BootstrapDialog
    							 .confirm("Cannot Add to Appointment","The client cannot be found in Contact Manager. The client might not have an active account or might be hidden. Choose OK to save contact to the appointment as text only.",
    							 function(confirm) {
    								 if (confirm) {
    	                                _self.calContactSearchBox.val("");
    	                                if ($('.pinned-client-in-add-appt').hasClass('hidden')) { $('.pinned-client-in-add-appt').removeClass('hidden'); }
    	                                $(".more-opts-arrow.sel-contact").attr("id", "");
    	                                $(".more-opts-arrow.sel-contact, .pinned-client-in-add-appt .val").html(item.substring(0, item.length - 9));
    	                                $("form#calContactSearch .typeahead").css('max-height', '345px');
    	                                _self.setClientSelectedAlways();
    	                                //$("#newEvent").click();
    	                                $('#calsearch').blur();
    								 } else {
    	                        		_self.calContactSearchBox.val("");
    								 }
    							 },"","Cancel","OK");
                        	}
                        });
                    }
                    return item;
                }
            });
        },
        freeTxtHandler : function(){
            $(".more-opts-arrow.sel-contact").html(this.calContactSearchBox.val());
            $(".more-opts-arrow.sel-contact").attr("id","");
            if ($('.pinned-client-in-add-appt').hasClass('hidden')) { $('.pinned-client-in-add-appt').removeClass('hidden'); }
            $('.pinned-client-in-add-appt .val').html(this.calContactSearchBox.val());
            $("form#calContactSearch .typeahead").css('max-height', '345px');
            this.calContactSearchBox.val("");
            this.setClientSelectedAlways();
            //$("#newEvent").click();
        },
        txtBoxOnFocus: function (e) {
            if (e.target.id == "calsearch") {
                if (!$('#cal-contact-search-div').is(':visible')) { $('#cal-contact-search-div').show(); }
            }
        },
        txtBoxOnBlur: function (e) {
            if (e.target.id == "calsearch") {
            	//this.calContactSearchBox.css('border-radius', '4px 4px 4px 4px')
            }
        },
        serachBoxChangeHandler : function(){
        	if(this.calContactSearchBox.val().length === 0){
            	ContactDetailsModel.advsiorContacts.clearContacts(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID,((this.keywordSearchRequired) ? true : false));
            	this.lastKeyword = null;
        	}
        	this.noRecordsFound(false);
        	
        },
        render: function (options) {
            try {
            	this.changeClientsCource();
            } catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        },
        clearView:function(){
        	this.undelegateEvents();// Unbind all local event
        }
    });
    return calendContactSearcharview;
});