/**
 * @ngdoc property
 * @name Recommended Plan Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Recommended Plan for Advisor module.
 *
 **/
'use strict';
function recommendedPlanController($scope, $state, recommendedPlanInitialLoader, recommendedPlanModelService, $timeout, buildPlanInitialLoader, buildPlanModelService, transactModel, recommendedFundsInitialLoader, planSmartSolution, sipCalculatorModel, smartSolnFundDetailsModel, recommendedFundCardModelService, $uibModal,$window,appConfig,configUrlModel) {

    var planInputDetails = null;
    $scope.init = function () {
        $scope.recommendationText = "Show another Recommendation";
        $scope.isToggle = false;
        buildPlanModelService.tabname = "recommendedplan";
        $scope.recommendationDetails = {
            installmentDetails: [],
            details: {}
        };
        planInputDetails = recommendedPlanModelService.getPlanInputDtls();
        if(planSmartSolution.isFromPlan) {
            loadRecommendedPlan();
            fundCardModal(planSmartSolution.getSmartSolutionDetails().fundDetails.productCode);
            planSmartSolution.isFromPlan = false;
        }
        else {
            getSmartSolutionDetails();
        }
        //getSmartSolutionDetails();

    };

    $scope.init();

    
    $scope.customizeBtn = function () {
        $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rcustomizePlan');
    };

    $scope.toggleRecommendataions = function () {
        var planInputObj = {};
        planInputObj = recommendedPlanModelService.getPlanInputDtls();
        planInputObj.investmentAmount = planSmartSolution.replaceComma(planInputObj.investmentAmount);
        $scope.recommendationText == "Show another Recommendation" ? (planInputObj.fundRecom = "A", $scope.recommendationText = "Show Original Recommendation") : (planInputObj.fundRecom = "O", $scope.recommendationText = "Show another Recommendation");
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
            $scope.isToggle = true;
            planSmartSolution.setSmartSolutionDetails(data);
            fundCardModal(planSmartSolution.getSmartSolutionDetails().fundDetails.productCode);
            loadRecommendedPlan();
            $timeout(function () {
                $scope.goalChartData = {};
                $scope.goalChartData.data = null;
                $scope.fundCardDetails = null;
            }, 0);
            loadInvestmentSimulation();

        }, function (data) {
            console.log("Error")
        });
    };

    $scope.$on("investmentType", function ($event, data) {
        buildPlanModelService.setInvestmentType(data);
    });

    $scope.$on("investmentValue", function ($event, data) {
        $scope.radioSelectedData = buildPlanModelService.setInvestmentValue(data);
        $scope.fundDetails();
    });

    $scope.fundDetails = function () {
        $scope.investmentType = buildPlanModelService.getInvestmentType();
        $scope.investmentValue = buildPlanModelService.getInvestmentValue();

        if ($scope.investmentType == "Monthly" || $scope.investmentType == "Annually") {
            planSmartSolution.setTransactType("SIP");
        }
        else if ($scope.investmentType == "One time") {
            planSmartSolution.setTransactType("Lumpsum");
        }
        else {
            planSmartSolution.setTransactType("Combo");
        }

        $scope.goalDetails = [];
        $scope.totalGoalDetails = {};
        $scope.instalMentDtls = {
            monthly: "",
            annually: "",
            oneTime: ""
        };

        $scope.totalGoalDetails["allocation"] = "100%";
        if ($scope.investmentType == "Monthly") {
            $scope.instalMentDtls.monthly = $scope.investmentValue;
            $scope.totalGoalDetails["monthly"] = $scope.investmentValue;
        }
        if ($scope.investmentType == "Annually") {
            $scope.instalMentDtls.annually = $scope.investmentValue;
            $scope.totalGoalDetails["annually"] = $scope.investmentValue;
        }
        if ($scope.investmentType == "One time") {
            $scope.instalMentDtls.oneTime = $scope.investmentValue;
            $scope.totalGoalDetails["oneTime"] = $scope.investmentValue;
        }
        $scope.goalDetails.push({
            "fundName": $scope.smartSolnDetials.fundDetails.fundOptDesc,
            "allocation": $scope.smartSolnDetials.allocPer + "%",
            "installmentDetails": $scope.instalMentDtls,
            "dividendFlag" : 'G',//$scope.smartSolnDetials.dividendFlag,
            "fundOption" : $scope.smartSolnDetials.rtCode || 'NA',
            "nfoFlag" : $scope.smartSolnDetials.fundDetails.nfoFlag || 'NA',
            "fundType": $scope.smartSolnDetials.fundDetails.fundType || 'NA',
            "accNo" : $scope.smartSolnDetials.fundDetails.fundType == "N" ? "NEW" : 'NEW',
            "perpetualFlag" : 'N' || '',//$scope.smartSolnDetials.perpetualFlag
            "stepUpFrequency": $scope.smartSolnDetials.fundDetails.stepUpFrequency || 'NA',
            "stepUpType" : $scope.smartSolnDetials.fundDetails.stepUpType || 'NA',
            "stepUpValue" : $scope.smartSolnDetials.fundDetails.stepUpValue || 'NA',
            "stepUpSip" : 0
        });


    };

    $scope.goalData = [];
    $scope.goalsheetBtn = function () {
        buildPlanModelService.setGoalPlanData($scope.goalDetails);
        buildPlanModelService.setGoalTotalPlanData($scope.totalGoalDetails);
        $state.go('smartSol.planSmartSolution.ssBase.goalSheetSummary');
        buildPlanModelService.setGoalSummaryFromState($state.current.name);
    };

    function loadInvestmentSimulation () {

        var calculatorReq = [{
            "investmentTenure": planInputDetails.investmentTenure,
            "annualizedReturn": null,
            "investmentAmount": planSmartSolution.replaceComma($scope.smartSolnDetials.monthlySIP),
            "fundName": $scope.smartSolnDetials.rtCode,
            "frequency" : "Monthly",
            "calculatorType": "SIP",
            "trxnType": "SIP"
        }];
        sipCalculatorModel.callSipCalculatorData({"calculatorReq": calculatorReq}, true, "PS").then(function (data) {
            var investMentSimulation = angular.copy(data.calculatorResp[0].returnData[0].periodicReturnData);
            $scope.goalChartData = {
                "data": [],
                "goalAmount": null
            };
            angular.forEach(investMentSimulation, function (value, key) {
                var chart = {};
                chart.years = value.duration;
                chart.amount = value.valueOfAmount;
                $scope.goalChartData.data.push(chart);
            });
            $scope.goalChartData.goalAmount = planInputDetails.investmentAmount;
            planSmartSolution.setInvestmentSimulation($scope.goalChartData);
        }, function (data) {

        });
    };

    function loadRecommendedPlan () {
        $scope.smartSolnDetials = planSmartSolution.getSmartSolutionDetails();
        if (!$scope.isToggle) {
            loadInvestmentSimulation();
            $scope.recommendationDetails =
            {
                installmentDetails: [
                    {text: 'Monthly', value: $scope.smartSolnDetials.monthlySIP},
                    {text: 'Annually', value: $scope.smartSolnDetials.annualSIP},
                    {text: 'One time', value: $scope.smartSolnDetials.lumpsum}],
                details: {
                    "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                    "investmentAmount": $scope.smartSolnDetials.investmentAmount
                }
            };
            planSmartSolution.setRecommendedDetails($scope.recommendationDetails);
            $scope.fundOptDesc = $scope.smartSolnDetials.fundDetails.fundOptDesc;
        }
        else {
            $scope.recommendationDetails.installmentDetails = null;
            $scope.fundOptDesc = null;
            $timeout(function () {
                $scope.recommendationDetails =
                {
                    installmentDetails: [
                        {text: 'Monthly', value: $scope.smartSolnDetials.monthlySIP},
                        {text: 'Annually', value: $scope.smartSolnDetials.annualSIP},
                        {text: 'One time', value: $scope.smartSolnDetials.lumpsum}],
                    details: {
                        "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                        "investmentAmount": $scope.smartSolnDetials.investmentAmount
                    }
                };
                planSmartSolution.setRecommendedDetails($scope.recommendationDetails);
                $scope.fundOptDesc = $scope.smartSolnDetials.fundDetails.fundOptDesc;
            }, 0);

        }

    };

    function getSmartSolutionDetails () {
        var planInputObj = {};
        planInputObj = angular.copy(recommendedPlanModelService.getPlanInputDtls());
        planInputObj.fundRecom = "O";
        planInputObj.investmentAmount = planSmartSolution.replaceComma(planInputObj.investmentAmount);
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
            planSmartSolution.setSmartSolutionDetails(data);
            fundCardModal(planSmartSolution.getSmartSolutionDetails().fundDetails.productCode);
            loadRecommendedPlan();
        }, function (data) {
            console.log("Error")
        })
    };


    function fundCardModal(fundCode) {
        recommendedFundCardModelService.fetchRecommendedFundCard(fundCode).then(function (data) {
            $scope.fundCardDetails = data.fundDetails;
        }, function () {

        });
    };

    var modalInstance;
    $scope.$on('openFundCardModelPlan', function (event, fundCodes) {
        recommendedFundCardModelService.setFundCardId(fundCodes);
        // modalInstance = $uibModal.open({
        //     template: require('../../../../../../common/components/smartSolFundCardModelDetails/smartSolFundCardModel.html'),
        //     scope: $scope
        // });
        // $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/funds-and-solutions/funds-explorer/fund-overview?FundID='+fundCodes;
        $window.open(
          appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/funds-and-solutions/funds-explorer/fund-overview?FundID='+fundCodes,
          '_blank');
    });
}

recommendedPlanController.$inject = ['$scope', '$state', 'recommendedPlanInitialLoader', 'recommendedPlanModelService', '$timeout', 'buildPlanInitialLoader', 'buildPlanModelService', 'transactModel', 'recommendedFundsInitialLoader', 'planSmartSolution', 'sipCalculatorModel', 'smartSolnFundDetailsModel', 'recommendedFundCardModelService', '$uibModal','$window','appConfig','configUrlModel'];
module.exports = recommendedPlanController;