/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accordion = function($state, eventConstants, selectInvestorModel,selectInvestorInitialLoader,$timeout,transactEventConstants,transactEvents,transactModel, $stateParams, TransactConstant, toaster) {
  return {
            template: require('./bsSelectInvestor.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              accordionData: "=",
              lable: "=",
              count: "="
            },
            controller:['$scope', function($scope){ 
                
                var isPANChecked = false,
                    isAadharChecked = false,
                    editIconChanged = false,
                    previousSearchValue = "",
                    previousSearchText = "",
                    selectedInvestorDtls = null,
                    folioId = "",
                    oldData = null,
                    searchData = {},
                    pageRange = {},
                    pageOffset = 1,
                    limit = 5,
                    previousPage = 0
                    ;
                pageRange.limit = 5;
                pageRange.offset = 1;
                $scope.paginationObject = {
                    currentPage : 1
                }
                $scope.pageChanged = function() {
                    $scope.showSearchResult = false;
                    if($scope.paginationObject.currentPage === 1){
                        pageRange.offset = 1;
                    }else{
                        pageRange.offset = (pageRange.limit * ($scope.paginationObject.currentPage-1)) + 1;
                    }                    
                    init();                    
                };                                                                      

                $scope.searchOptions = [
                  {
                    lable: "PAN"
                  },
                  {
                    lable: "Folio No."
                  },
                  {
                    lable: "Account No."
                  },
                  {
                    lable: "Unit Holder Name"
                  },
                  {
                    lable: "Mobile"
                  },
                  {
                    lable: "Email"
                  },
                  {
                    lable: "Aadhaar"
                  },
                  {
                    lable: "CAN"
                  },
                  {
                    lable: "IIN"
                  }
                ];
                function checkKYCMode(holders){
                    transactModel.setKYCMode(false);
                    angular.forEach(holders,function(obj,ind){                     
                        transactModel.checkRegistrationMode(obj.modeOfKyc);
                    });                          
                    $scope.$emit("kycMode");
                }
                $scope.$on(eventConstants.HIDE_SEARCH_RESULT, function (event, args) {                 
                    $scope.showSearchResult = false;
                    $scope.selectInvestorGrid = [];
                });
                function init() {

                    var statusTemplate = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.folioId}}" name="selectedInvestor" ng-click="grid.appScope.$emit(\'selectInvestor\', row.entity)" />';

                    $scope.config = {};
                    $scope.config.showNotification = false;                                        
                    $scope.disableContinue = true;   
                    $scope.showSearchResult = false;                                      
                    selectedInvestorDtls = null;                                
                    $scope.selectInvestorGrid = [];
                    $scope.configDataLost = {};
                    $scope.configDataLost.showNotification = false;
                    $scope.gridOptions = {};
                    $scope.gridOptions.columnDefs = [
                      { field: 'checkBox',displayName:'', value:folioId, width:"50", cellTemplate:statusTemplate , enableSorting:false, pinnedLeft:true},
                      { field: 'custName', displayName: 'Unit Holder Name', width:"180", enableSorting:false, pinnedLeft:true, footerCellTemplate: '<div class="ui-grid-cell-contents">Total</div>'},                        
                      { field: 'pan', displayName: 'PAN', width:"140", enableSorting:false},
                      { field: 'folioId', displayName: 'Folio No.', width:"154", enableSorting:false},
                      { field: 'holdingType', displayName: 'Mode of Holding', width:"180",  enableSorting:false},
                      { field: 'mobile', displayName: 'Mobile', width:"154", enableSorting:false},
                      { field: 'emailId', displayName: 'Email', width:"254",  enableSorting:false},
                      { field: 'city', displayName: 'City', width:"254",  enableSorting:false}                  
                    ];                                                                 
                    selectInvestorInitialLoader.loadAllServices($scope,searchData,pageRange);                                      
                };                                                                                                                                                              
                

                var listener = $scope.$on(transactEventConstants.transact.Select_Investor, function (event) {
                    
                    var data = selectInvestorModel.getInvestors(),
                        database = selectInvestorModel.getDatabase();
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;
                    transactModel.setSelectInvestorValue(searchData.searchText);
                    if(data[0].holders[0].kycStatus !== "")
                    {
                        $scope.selectInvestorGrid = selectInvestorModel.getInvestors();                                  
                        $scope.$emit(transactEventConstants.transact.Open_Grid);
                        $scope.showSearchResult = true;                                
                        previousSearchValue = searchData.searchOption;
                        previousSearchText = searchData.searchText;
                    }
                    else if(data[0].holders[0].kycStatus === "" && data[0].kycStatus === "KYC-Registered")
                    {
                        transactModel.isNewInvestor = true;
                        var newInvestorDataObj = {
                            fromKRA : true,
                            data : selectInvestorModel.getInvestors()[0]
                        }
                        transactModel.setInvestorDetails(selectInvestorModel.getInvestors()[0]);
                        transactModel.setNewInvestorData(newInvestorDataObj);    
                        checkKYCMode(data[0].holders);                            
                        $state.go("transact.base.newFolioNnewInvestor");
                        return;
                    }
                    else if(data[0].holders[0].kycStatus === "" && data[0].kycStatus === "KYC–Not Registered")
                    {
                        if(searchData.searchOption === "PAN" || searchData.searchOption === "Aadhaar")
                        {                          
                            if(!isPANChecked && !isAadharChecked)
                            {
                                $scope.popupText = (searchData.searchOption === "PAN") ? "No record found basis PAN, please try searching through Aadhaar.":"No record found basis Aadhaar, please try searching through PAN.";
                                $scope.yesText = "OK";
                                $scope.showPopup = true;                              
                            }                          
                            (searchData.searchOption === "PAN") ? isPANChecked = true : isAadharChecked = true ;
                        }          
                        
                        if(isPANChecked && isAadharChecked)
                        {                            
                            transactModel.isNewInvestor = true;
                            var newInvestorDataObj = {
                              fromKRA : false,
                              data : {
                                panORaadhar : searchData.searchText,
                                searchOption : searchData.searchOption
                              }
                            }
                            transactModel.setNewInvestorData(newInvestorDataObj);   
                            checkKYCMode(data[0].holders);                             
                            $state.go("transact.base.newFolioNnewInvestor");
                            return;                         
                        }
                    }                                               
                    
                    //listener();  //removed for as it causing error while loading data in pagenation
                });
                                     

                function setExistingData(){
                    folioId = transactModel.getInvestorDetails().folioId;
                    searchData = {
                      searchOption : transactModel.getSearchOption(),
                      searchText : transactModel.getSearchText()
                    };                    
                }                        

                if($stateParams.key === "Investor")
                {                                                            
                    setExistingData();                    
                    init();                    
                    selectedInvestorDtls = transactModel.getInvestorDetails();
                    $scope.disableContinue = false;
                    editIconChanged = true;
                }                                                                                                
                
                $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) {

                    searchData = {
                      searchOption : args.searchOption,
                      searchText : args.searchText
                    };

                    if(previousSearchValue !== args.searchOption || previousSearchText !== args.searchText)
                    {
                        var loadData = true;
                        if(editIconChanged == true)
                        {                            
                            editIconChanged = false;
                            loadData = false;
                            folioId = "";
                            $scope.config.showNotification = true;
                            $scope.$on('yes', function () {                                                                                                                                                         
                                init();                                
                            })                                                        
                        }                        
                        if(loadData)                              
                        {                                                                                                                  
                            init();                        
                        }                                          
                    }                        
                });

                $scope.$on(transactEventConstants.transact.Edit_Button_Clicked, function (event, args) { 
                    setExistingData();                    
                    init();                    
                    selectedInvestorDtls = transactModel.getInvestorDetails();                 
                    $scope.disableContinue = false;
                    editIconChanged = true;   
                });

                $scope.$on('selectInvestor', function (event, rowEntity) {                    
                                         
                    selectedInvestorDtls = rowEntity;
                    console.log("selectedInvestorDtls",selectedInvestorDtls);
                    if((selectedInvestorDtls.emailId ===""|| selectedInvestorDtls.emailId ==="null" || selectedInvestorDtls.emailId ===" ") && (selectedInvestorDtls.mobile ===""||selectedInvestorDtls.mobile ==="null" || selectedInvestorDtls.mobile ===" ")){
                    toaster.error("The user doesn’t have a registered mobile and e-mail. Please select a different folio to proceed with the transaction");
                    $scope.disableContinue = true; 
                  }
                  else{
                    $scope.disableContinue = false;                    
                    transactModel.setInvestorDetails(selectedInvestorDtls);
                    selectInvestorModel.setSelectedInvestorDtls(selectedInvestorDtls);
                  }
                    
                }); 
                
                $scope.$on("yes",function(){
                    $scope.config.showNotification = false;
                    $scope.showPopup = false;
                });

                $scope.$on('no', function () {                            
                    $scope.config.showNotification = false;
                    $scope.showPopup = false; 
                });


                var holders = null,
                    kycregistered = null;

                function goNexttab(){
                    selectInvestorModel.setSelectedInvestorDtls(selectedInvestorDtls); 
                    selectInvestorModel.setSelectedInstantInvstrDtls(selectedInvestorDtls);
                    //This is added to change the configuration of fund or sip Tile.
                    if($state.current.url == "/buy") {
                        transactModel.setTransactType(TransactConstant.buy.BUYFUND);
                    }else if($state.current.url == "/sip") {
                        transactModel.setTransactType(TransactConstant.sip.FUNDSIP);
                    }

                    transactModel.setKYCMode(false);
                    angular.forEach(holders,function(obj,ind){
                        if(obj.kycStatus === "KYC - Not Registered") {
                            kycregistered = false;                                                                                   
                        }                        
                        transactModel.checkRegistrationMode(obj.modeOfKyc);
                    });                          
                    $scope.$emit("kycMode");
                    if(!kycregistered)
                    {                        
                        $scope.popupText = "Please complete KYC registration of all holders to proceed with the transaction."
                        $scope.yesText = "Continue with KYC";
                        $scope.noText = "Cancel";
                        $timeout(function(){$scope.showPopup = true;},0) 
                        $scope.$on("yes",function(){ 
                          $scope.showPopup = false; 
                          $state.go("transact.base.ekycReg");
                          return;                              
                        });
                    }
                    else
                    {
                        $scope.$emit(transactEventConstants.transact.Investor_Details);
                    }
                }

                $scope.SIContnuBtn = function($event){
                    //$scope.noEventName = "Inv_Edit_No_Cont_Clicked";
                    holders = selectedInvestorDtls.holders;
                    kycregistered = true;
                    $scope.showPopup = false;
                    
                    transactModel.setSearchOption(searchData.searchOption);
                    transactModel.setSearchText(searchData.searchText);
                    if(searchData.searchOption === "Aadhaar") {
                        transactModel.setAadhaarNo(searchData.searchText);
                    }
                    if (editIconChanged) {
                        var result = _.isEqual(selectInvestorModel.getSelectedInstantInvstrDtls(), selectedInvestorDtls);
                        if (!result) {
                            $scope.configDataLost.showNotification = true;
                                var destroyHandler =  $scope.$on('yes', function () {
                                    goNexttab();
                                    destroyHandler();
                                });
                                $scope.$on('no', function () {
                                  $scope.configDataLost.showNotification = false;
                                });
                              /*$scope.$on('Inv_Edit_No_Cont_Clicked', function () {
                                $scope.configDataLost.showNotification = false;
                                folioId = selectInvestorModel.getSelectedInstantInvstrDtls().folioId;                 
                                init();                                
                                selectedInvestorDtls = selectInvestorModel.getSelectedInstantInvstrDtls(); 
                                transactModel.setInvestorDetails(selectedInvestorDtls);            
                                $scope.disableContinue = false;
                              });*/
                        }
                        else
                            goNexttab()
                    }
                    else
                       goNexttab() 
                                                                              
                } 

                $scope.gotoNewfolioNnewInvestor=function(){
                  $state.go("transact.newFolioNnewInvestor")
                }                                
                $scope.newFolioBtn=function(){
                    holders = selectedInvestorDtls.holders;
                    checkKYCMode(holders);
                    transactModel.isCreateFolio = true;
                    transactModel.setIsNewFolio(true);
                    $state.go("transact.base.newFolioNnewInvestor")
                }
            }]
        };
};

accordion.$inject = ['$state', 'eventConstants', 'selectInvestorModel','selectInvestorInitialLoader','$timeout','transactEventConstants','transactEvents','transactModel', '$stateParams', 'TransactConstant', 'toaster'];
module.exports = accordion;
