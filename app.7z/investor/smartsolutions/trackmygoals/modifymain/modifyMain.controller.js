
'use strict';
function smartSolsModifyCtrl($scope, $state, smartSolnFundDetailsInitialLoader, investorGoalModelService, overviewModel) {
	$scope.modifySec = true;
	$scope.config = {};
	$scope.config.stepsConfig = {};
	$scope.config.stepsConfig.activeStep = 1;
	$scope.config.stepsConfig.noOfSteps = 2;
	$scope.config.stepIndImgs = [
     {
            key : "01",
            iconClass : 'icon-fti-recommend',
            label : "Recommendations"
        }, {
            key : '02',
            iconClass : 'icon-fti-goal',
            label : "Goal Sheet / Summary"
        }
        ];
	$scope.keyValueList= angular.copy(overviewModel.getHolderInformation());

	$scope.$on('topUpOptionsection',function(){
		$scope.modifySec = false;
	});
	$scope.$on('invEditIcon',function(){
		$scope.modifySec = false;
	});
	//	[{key:"First Holder",value:"Shankar Narayanan"},
	//{key:"Second Holder",value:"Shyama Shankar"},
	//{key:"Third Holder",value:"Anil Narayanan"},
	//{key:"Folio.No.",value:"4563152-FS"},
	//{key:"Mode Of Holding",value:"Joint"}
	//];
	smartSolnFundDetailsInitialLoader.loadAllServices($scope, true, investorGoalModelService.getSelectedInvestorDetails().folioId);

	
	$scope.goBack=function(){
		$state.go('smartSol.investor.cp');
	}
}

smartSolsModifyCtrl.$inject = ['$scope', '$state', 'smartSolnFundDetailsInitialLoader', 'investorGoalModelService', 'overviewModel'];
module.exports = smartSolsModifyCtrl;