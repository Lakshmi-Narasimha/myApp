﻿define([

], function (  ) {
    //Modules are defined as such
    var module = function () {

        /* Stateful Saving Support */
        state = function () { }
        state.prototype.expand = [];
        state.prototype.close  = [];
    
        state.prototype.load = function () {

        }

        state.prototype.save = function () {
           
        }

        var modules = function () { }
        modules.prototype.state = new state();
        
    }

    return module;
})