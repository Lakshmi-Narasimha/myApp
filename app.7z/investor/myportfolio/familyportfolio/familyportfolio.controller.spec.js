'use strict';
describe('Controller: family portfolio controller', function() {
    var $controller, $scope, event, $state, familyPortfolioController, familyPortfolioInitialLoader, myportfolioConstants, invInstantMailback, familyPortfolioModel, downloadService, timeout;
    var familyPortFolioData = {
            'familyPortFolioList': {
                'primaryPan': 'ABAPL1235D',
                'approved': [{
                    'refId': '123',
                    'name': 'Shankar Narayan',
                    'pan': 'ABAPL1235C',
                    'currentCost': '2,50,000.00',
                    'currentValue': '6,50,000.00'
                }, {
                    'refId': '234',
                    'name': 'Gayatri Narayan',
                    'pan': 'ABAPL1235D',
                    'currentCost': '2,50,000.00',
                    'currentValue': '6,50,000.00'
                }],
                'pending': [{
                    'refId': '345',
                    'name': 'Priya Venkatesh'
                },
                {
                    'refId': '342',
                    'name': 'GiriBabu'
                }]
            }
        }
    beforeEach(angular.mock.module('investor'));

    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _$state_, _familyPortfolioInitialLoader_, _invInstantMailback_, _myportfolioConstants_, _familyPortfolioModel_, _downloadService_, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        $state = _$state_;
        downloadService = _downloadService_;
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);

        familyPortfolioInitialLoader = _familyPortfolioInitialLoader_;
        familyPortfolioModel = _familyPortfolioModel_;
        invInstantMailback = _invInstantMailback_;
        myportfolioConstants = _myportfolioConstants_;

        familyPortfolioController = $controller('FamilyPortfolioController', { $scope: $scope });
    }));

    it('should be defined', function() {
        expect(familyPortfolioController).toBeDefined();
        console.log($scope);
    });

    it('should load appName and other details from scope', function() {
        var invAppName = myportfolioConstants.overview.INV_APP_NAME;
        expect($scope.appName).toBe(invAppName);
        expect($scope.isMobileDevice).toBeTruthy();
        expect($scope.portfolioType).toBe('familyportfolio');
        expect($scope.status).toBeDefined();
        expect($scope.status.open).toBeFalsy();
    });

    it('should load appName and other details from scope', function() {
        expect(familyPortfolioInitialLoader).toBeDefined();
        expect(familyPortfolioInitialLoader._isServicesData).toBeFalsy();
    });

    it('should load invInstantMailback and downloadService from scope', function() {
        expect(invInstantMailback.setMailBackData).toBeDefined();
        expect(downloadService.setQueryparams).toBeDefined();
    });

    it('should trigger changeNavPill to get modelVal', function() {
        familyPortfolioModel.setFamilyPFList(familyPortFolioData.familyPortFolioList); 
        $scope.$broadcast('familyportfoliolist');
        expect(familyPortfolioModel.getFamilyPFList().primaryPan).toBeDefined();
        expect($scope.pendingList).toBeDefined();       
        expect($scope.approvedList).toBeDefined(); 
    });

    it('should trigger pillSelect for state transition', function() {      
        var data = familyPortFolioData.familyPortFolioList;
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('familyportfolio', data);
        expect($scope.$broadcast).toHaveBeenCalledWith('familyportfolio', data);
        expect($scope.$broadcast).toHaveBeenCalledWith('familyportfoliopanview', data);
    });
});
