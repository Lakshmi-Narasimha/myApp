/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolInvestmentOptions = function($state, $timeout,buildPlanModelService) {
	return {
          template: require('./smartSolInvestmentOptions.html'),
           restrict: 'E',
           replace: true,
           scope:{ 
            investData :'=',
            isCustomize : "=?"
          },
          controller: function($scope, $element, $attrs){
          $scope.navPillsOptions = [
           {
            btnName : "Recommended Plan",

          }, 
          {
            btnName : "Build my Plan",

          }
          ];

          $scope.installment = $scope.investData.installmentDetails;
          $scope.tenorDetails = $scope.investData.details;
          $scope.btnColor = 'btn-group-sm green-btn-group pull-left'; 
          $scope.radios = {};

          $scope.radios.selectedVal = "Monthly";
          $scope.defaultRadioVal = $scope.installment[0].value;

          if(buildPlanModelService.getInvestmentType() == "Annually" ) {
            $scope.radios.selectedVal = buildPlanModelService.getInvestmentType(); 
          };

          if(buildPlanModelService.getInvestmentType() == "Monthly" ) {
            $scope.radios.selectedVal = buildPlanModelService.getInvestmentType(); 
          };
          
          if(buildPlanModelService.getInvestmentType() == "One-time" ) {
            $scope.radios.selectedVal = "One time";  
          }

          $scope.listenChange = function (index,radioValue) {
            $scope.activeClass = index;

            $scope.$emit("investmentType",$scope.radios.selectedVal);
            $scope.$emit("investmentValue",radioValue);
          }; 

          $scope.$emit("investmentType",$scope.radios.selectedVal);
          $scope.$emit("investmentValue", $scope.defaultRadioVal);
      },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

smartSolInvestmentOptions.$inject = ['$state', '$timeout','buildPlanModelService'];
module.exports = smartSolInvestmentOptions;