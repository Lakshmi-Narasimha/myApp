define(["jquery"],function ($) {
    function ShadowLayer(){
        this.defaultOptions = {
            parentElement: undefined, //HTMLElement... element to which the background should overlay
            childElementId: 'cs-shadow-box', //DOM id of the element which will appear above the overlay
            zIndex: 1
        };
        this.show = function(options){
            if(!options) options = {};
            options = this.extendDefaultOptions(this.defaultOptions, options);

            var parent = $(options.parentElement);
            var _shadowBox = "<div id="+options.childElementId+"></div>";

            if($('#'+options.childElementId).length == 0){
                parent.append(_shadowBox);
            }
            $('#'+options.childElementId).show().css({ 'z-index': options.zIndex });
        };
        this.hide = function(options){
            if(!options) options = {};
            options = this.extendDefaultOptions(this.defaultOptions, options);
            $('#'+options.childElementId).hide().css({ 'z-index': options.zIndex });
        };

        this.extendDefaultOptions = function(parentObj, chileObj) {
            if(typeof parentObj != "object" && typeof parentObj != "object"){
                return {};
            }
            var _tmpObj = {};
            for(var key in parentObj)_tmpObj[key] = (chileObj[key] == null) ? parentObj[key] : chileObj[key];
            return _tmpObj;
        };
    }
    return new ShadowLayer();
});