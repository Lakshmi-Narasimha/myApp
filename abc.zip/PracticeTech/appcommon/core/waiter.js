﻿define([

], function (  ) {
    //waiter integration
    var waiter = function () {

    }
    waiter.prototype.global = {


    }
    waiter.prototype.start = function (options) {
        var options = options || {};
        options.limit = options.limit || 10000;
        options.spinner = options.spinner || document.getElementById('spinner-overlay');

        this.global.id = options.spinner;

        this.show(options);

        spinnerTimeInstance = (options.limit > 0) ? window.setTimeout(waiter.prototype.hide, options.limit) : "";

    }
    waiter.prototype.show = function (options) {
        var options = options || {};
        options.style = options.style || null;
        options.target = options.target || "global";
        options.blocker = options.blocker || "standard";
        options.blockerStyle = options.blockerStyle || null;
        options.blockTarget = options.BlockTarget || "global";
        options.spinner = options.spinner || document.getElementById('spinner-overlay');
       
        this.global.id = options.spinner;
        $(options.spinner).show();
    }
    waiter.prototype.hide = function () {
        try { $(waiter.prototype.global.id).hide(); } catch (error) { console.log("Attempt to close modal failed. No such modal Exists"); console.dir(error) }
    }

    waiter.prototype.stop = function (when) {
        when = when || '0';
    }


    return waiter;
})