/**
 * @ngdoc service
 * @name FTI Nominee Details Initial Load Service
 * @requires cgAccDetModel
 * @requires investorEvents
 * @requires eventConstants
 * @requires toaster
 * @requires $timeout
 * investorEventConstants
 * fticLoggerMessage
 * loggerConstants
 * toaster
 * $loader
 * @description
 *
 * - Handles the services and model for Advisor content details & widgets
 *
 */
'use strict';


var nomineeDetailsInitialLoader = function(nomineeDetailsModel, investorEvents, eventConstants, $timeout, investorEventConstants, fticLoggerMessage, loggerConstants, toaster, $loader) {
	var nomineeDetailsInitialLoader = {
		_isServicesData: false,
		loadAllServices : function (scope) {
			nomineeDetailsModel.getNomineeDetails() 
			.then(folioNumbersListSuccess, promiseFailure).finally(stopLoader);
			function folioNumbersListSuccess(data){
				//console.log(data);
				nomineeDetailsModel.setFolioNumbersList(data.nomineeSummary);
				investorEvents.accountSettings.getNomineeDetails(scope);
			};
			function promiseFailure (data) {
				nomineeDetailsInitialLoader._isServicesData = false;
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			};
			function stopLoader() {
                $loader.stop();
            };
            $loader.start();
		}
	};
	return nomineeDetailsInitialLoader;
};


nomineeDetailsInitialLoader.$inject = ['nomineeDetailsModel', 'investorEvents', 'eventConstants', '$timeout', 'investorEventConstants', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader'];

module.exports = nomineeDetailsInitialLoader;
