/**
 * @name scrollDown directive
 * @author - Ahmed Pasha Mohammed
 * @description Simple directive to scrollDown to the latest message in the chat box.
 * usage - <div mdm-spinner="true|false"></div>
 * @param mdm-spinner
 *  - Boolean to show and hide spinner
 *  - Default - hidden
 **/
module.exports = function() {
    return {
        scope: {
            schrollBottom: "="
        },
        link: function(scope, element) {
            scope.$watchCollection('schrollBottom', function(newValue) {
                if (newValue) {
                    $(element).scrollTop($(element)[0].scrollHeight);
                }
            });
        }
    };
};
