import { Agent } from '../_models/index';
import { Intent } from '../_models/index';
import { UserExpression } from '../_models/userexpression';

const secretKey:string = "sf34r23rwefdwet34sewr34";

export class ReqBodyHelper {
  reqAgent:Agent;
  reqIntent:Intent;
  reqUserExpressions : Array<UserExpression> = [];

  getRequestBody(){
    let reqBody:any = {};
    reqBody.secretKey = "sf34r23rwefdwet34sewr34";//secretKey;
    if( this.reqAgent != null && this.reqAgent != undefined) {
      reqBody.agentVO = {};
      reqBody.agentVO.name = this.reqAgent.name;
      reqBody.agentVO.description = this.reqAgent.description;
      if(this.reqAgent.agentId != null && this.reqAgent.agentId != undefined) {
        reqBody.agentId = this.reqAgent.agentId;
      }
    }
     if(this.reqIntent != undefined) {
     console.log(this.reqIntent.name);
     console.log(this.reqIntent.agentId);}
    if( this.reqIntent != null && this.reqIntent != undefined && this.reqIntent.name != null && this.reqIntent.agentId != null) {
      reqBody.intentVO = {};
      reqBody.intentVO.name = this.reqIntent.name;
      reqBody.intentVO.agentId = this.reqIntent.agentId;
      if(this.reqIntent.actionName != null && this.reqIntent.actionName != undefined)
        reqBody.intentVO.action = this.reqIntent.actionName;
      if(this.reqIntent.intentId != null && this.reqIntent.intentId != undefined) {
        reqBody.intentId = this.reqIntent.intentId;
      }
    }

    if( this.reqUserExpressions != null && this.reqUserExpressions != undefined && this.reqUserExpressions.length > 0) {
      reqBody.userExpressionVOList =[];
      for(var i = 0; i < this.reqUserExpressions.length; i++) {
        reqBody.userExpressionVOList[i] = {};
        if(this.reqUserExpressions[i].expression != null && this.reqUserExpressions[i].expression != undefined)
          reqBody.userExpressionVOList[i].expression = this.reqUserExpressions[i].expression;
        if(this.reqUserExpressions[i].userExpressionId != null && this.reqUserExpressions[i].userExpressionId != undefined)
          reqBody.userExpressionVOList[i].userExpressionId = this.reqUserExpressions[i].userExpressionId;
        if(this.reqUserExpressions[i].intentId != null && this.reqUserExpressions[i].intentId != undefined)
          reqBody.userExpressionVOList[i].intentId = this.reqUserExpressions[i].intentId;
      }
    }

    return reqBody;
  }

}
