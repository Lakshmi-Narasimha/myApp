/**
 * @ngdoc property
 * @name review lumpsum Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the review lumpsum controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewLumpsumController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout, bankDtlsModel, transactModel, $filter,planSmartSolution, fundDetails, $uibModal, $location, authenticationService, eventConstants, investorRegistrationModel)
{           

    var reqParams,paymentMethod,totalAmount,queryParams = $location.search();

    $scope.reviewStandards = function() {

        var modalInstance = $uibModal.open({
            template: require('../../../transact/review/components/serviceStandards/serviceStandards.html'),
            scope: $scope,
            size: 'lg'
        });
    };
    
    $scope.accordionClicked = function(){

        $scope.showLumpsumComponents = true;

        if (queryParams.successFlag === 'false' && queryParams.retryFlag === 'false') {
            return;
        }

        reqParams = transactModel.getBuyReqParams();
        paymentMethod = '';
        totalAmount = 0;

        angular.forEach(reqParams.fundOptions, function(obj) {
            totalAmount = totalAmount + parseInt(obj.amount);
        });

        fundDetails.removeFundDetails();
        angular.forEach(transactModel.getLumpsumFundDtls(), function(obj) {
            fundDetails.setFundDetails(obj);
        });

        // Review Details
        $scope.showFundDtls = true;
        $scope.isNewInvestor = transactModel.isNewInvestor;

        transactModel.setTransactType(TransactConstant.buy.BUY);

        switch (reqParams.paymentMode) {
            case TransactConstant.common.EMANDATE_CODE:
                paymentMethod = TransactConstant.transact.SETUP_NEW_MANDATE;
                break;
            case TransactConstant.common.NET_BANKING_CODE:
                paymentMethod = TransactConstant.transact.NET_BANKING;
                break;
            case TransactConstant.common.NEFT_CODE:
                paymentMethod = TransactConstant.transact.NEFT_RTGS;
                break;
            case TransactConstant.common.DEBIT_CARD_CODE:
                paymentMethod = TransactConstant.transact.DEBIT_CARD;
                break;
            case TransactConstant.common.AUTO_DEBIT_CODE:
                paymentMethod = TransactConstant.transact.AUTO_DEBIT;
                break;
            case TransactConstant.common.BILL_PAY_CODE:
                paymentMethod = TransactConstant.transact.BILL_PAY;
                break;
        }
        /**
         * Changed the order of Key Value Pairs - Defect - Investor
         * 
         */
        $scope.keyValuePairs = [
            {
                text: TransactConstant.transact.MODE_OF_PAYMENT,
                value: paymentMethod
            },
            {
                text: TransactConstant.transact.BANK_DETAILS,
                value: reqParams.bankName
            },
            {
                text: TransactConstant.transact.TOTAL_INVSTMNT_AMT,
                value: totalAmount ? '<span class="icon-fti_rupee"></span>' + totalAmount : 'NA'
            }        
        ];          
        
        // Transaction details    
        var tranasactNowFolioId = '', transactNowFirstHolder = '', transactNowInvestorDtls = '';
        if($state.current.name === 'transactnow.reviewNow.smartSol.investment' && transactModel.getInvestorDetails() === 'Newfolio'){
            transactNowFirstHolder = transactModel.getFolioDetailsObj().firstHolder;
            tranasactNowFolioId = investorRegistrationModel.getNewInvestorFolioId();
            tranasactNowFolioId = transactModel.getFolioDetailsObj().folioId;
        }else if($state.current.name === 'transactnow.reviewNow.smartSol.investment' && transactModel.getInvestorDetails()){
            transactNowInvestorDtls = transactModel.getInvestorDetails();
            if(!transactNowInvestorDtls.custName){
                transactNowInvestorDtls.custName = transactModel.getFolioDetailsObj().firstHolder;
            }
            transactModel.setInvestorDetails(transactNowInvestorDtls);
        }
        $scope.SIPkeyValueList = [
            {key: 'Folio. No.', value: tranasactNowFolioId ? tranasactNowFolioId : transactModel.getInvestorDetails().folioId},
            {key: 'First Holder', value: transactNowFirstHolder ? transactNowFirstHolder : transactModel.getInvestorDetails().custName}
        ]; 

        $scope.infoObj=[];
        var lumpsumDtls = fundDetails.getFundDetails();
        angular.forEach(lumpsumDtls, function(obj){
            $scope.infoObj.push([
            {
                text: "Fund Name",
                value: obj.fundName
            },
            {
                text: "Investment Amount",
                value: obj.amount
            },
            {
                text: "Dividend",
                value: obj.dividend
            }
            ]);
        });
                    
        $scope.showDtls.keyValueList = [
            {key:'Transaction Reference Number',value:transactModel.getLumpsumWebRefNo()},
            {key:'Request Date and Time',value:$scope.showDtls.requestDateAndTime},
            {key:'Total Investment Amount',value:totalAmount}
        ];          
    };

    $scope.postTransactDataLumpsum = function() {
        $scope.postReviewDetails('lumpsum');
    };
    $scope.termsNconditions = function() {
        $uibModal.open({
            template: require('../components/termsNconditions/termsNconditions.html'),
            scope: $scope,
            size: 'lg'
        });
    }

    $scope.accordionClicked();
    $scope.isOpenInvGrid = {
        'open': true      
    };

    $scope.$on(eventConstants.INV_OPEN_LUMP_ACC, function(){
        $scope.accordionClicked();
        $scope.isOpenInvGrid = {
            'open': true      
        };
    });

    $scope.$on(eventConstants.INV_OPEN_SIP_ACC, function(){
        $scope.isOpenInvGrid = {
            'open': false                
        };
    });

    $scope.saveTransaction = function() {
        var details = {};
        details.bankDetails = reqParams.bankName + '-' + reqParams.bankAccountNumber;
        details.paymentMethod = paymentMethod;
        details.fundDetails = [];
        angular.forEach(fundDetails.getFundDetails(), function(obj) {
            var fundObj = {};
            fundObj.fund = obj.fundName;
            fundObj.invAmount = obj.amount;
            fundObj.dividend = obj.dividendFlag === 'R' ? 'Re-Investment' : (obj.dividendFlag === 'P' ? 'Payout' : 'NA');
            details.fundDetails.push(fundObj);
        });
        $scope.submit.saveTransaction(details);
    };

}

reviewLumpsumController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','$timeout','bankDtlsModel', 'transactModel', '$filter','planSmartSolution', 'fundDetails', '$uibModal', '$location', 'authenticationService', 'eventConstants', 'investorRegistrationModel'];
module.exports = reviewLumpsumController;