'use strict';
describe('directive : my investments ', function() {
    var $rootScope, $scope, $compile, $provide, validHTML, compiledElement, investorDashboardDetailsModel, investorDashboardModelDataObj;

    var investmentData = {
		'myInvestments': {
            'currentCost': '2,50,000.00',
            'currentValue': '6,50,000.00',
            'fundValues': [{
                'fundCategory': 'Equity',
                'fund': '3,25,000'
            }, {
                'fundCategory': 'Balanced',
                'fund': '1,00,000'
            }, {
                'fundCategory': 'ELSS',
                'fund': '1,25,000'
            }]
        },
        'profileDetails': {
            'pan': 'DRCQR7575C'
        }
    };

    investorDashboardModelDataObj = {
	    getDashboardData: function() {
	        return investmentData;
	    }
	};

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('investorDashboardDetailsModel', investorDashboardModelDataObj);
        });
    });

    beforeEach(function() {
        angular.mock.inject(function($compile, $rootScope) {
            $rootScope = $rootScope;
            $compile = $compile;
            $scope = $rootScope.$new();

            validHTML = angular.element('<ftic-inv-my-investments></ftic-inv-my-investments>');
            compiledElement = $compile(validHTML)($scope);
            $scope.$digest();
        });
    });

    it('should be defined', function() {
        expect(compiledElement).toBeDefined();
    });

    it('should be available with data on dashboard info event and populate view', function() {
		$scope.$broadcast('investorDashboardInformation');
		expect(compiledElement.scope().isDataAvaiable).toBeDefined();
		expect(compiledElement.scope().chartOptions).toBeDefined();
		compiledElement.scope().$digest();
		expect($(compiledElement).find('.panel .panel-heading span').text()).toEqual('For PAN DRCQR7575C');
	});

	it('should be shown error when data on dashboard is unavailable', function() {
		expect(compiledElement.scope().isDataAvaiable).toBeFalsy();
	});
});
