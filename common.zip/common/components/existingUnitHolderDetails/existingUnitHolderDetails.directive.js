/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var existingUnitHolderDetails = function($timeout, eventConstants, ekycVerificationModel, authenticationService, $state,toaster, transactModel, fticStateChange) {
  return {
            template: require('./existingUnitHolderDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
              holderDetails:"=?"
            }, 
            controller:['$scope', function($scope){
              $scope.unit = {"open":true};
              $scope.displayMsg = "Please provide consent for Aadhaar Verification for the below Unit Holders";                
              $scope.continueMsg = "Please Enter OTP received from Aadhaar for the below Unit Holders";

              $scope.firstHolderStatus = false;
              $scope.secondHolderStatus = false;
              $scope.thirdHolderStatus = false;

              $scope.firstHolderKYCStatus = false;
              $scope.secondHolderKYCStatus = false;
              $scope.thirdHolderKYCStatus = false;

              $scope.firstHolderInputStatus = false;
              $scope.secondHolderInputStatus = false;
              $scope.thirdHolderInputStatus = false;

              $scope.isSubmitted = false;

              $scope.firstHolderAadhar = "";
              $scope.secondHolderAadhar = "";
              $scope.thirdHolderAadhar = "";

              $scope.showConsentCheckError = false;
              var kycStatus = "";

              $scope.inputFieldsForFirstHolder = [
                {
                  text: "Aadhaar",
                  value: $scope.holderDetails[0].aadhar,
                  message: "",
                  disable:true,
                  isRequired: true
                },
                {
                  text: "One-time Password (OTP)",
                  value: "",
                  message: "",
                  isRequired: true
                }
              ];                                                  

              $scope.inputFieldsForSecondHolder = [
                {
                  text: "Aadhaar",
                  value: $scope.holderDetails[1].aadhar,
                  message: "",
                  disable:true,
                  isRequired: true
                },
                {
                  text: "One-time Password (OTP)",
                  value: "",
                  message: "",
                  isRequired: true
                }
              ];

              $scope.inputFieldsForThirdHolder = [
                {
                  text: "Aadhaar",
                  value: $scope.holderDetails[2].aadhar,
                  message: "",
                  disable:true,
                  isRequired: true                
                },
                {
                  text: "One-time Password (OTP)",
                  value: "",
                  message: "",
                  isRequired: true
                }
              ];
        
              // condition for message..
              if($scope.holderDetails[0].kycregistered === false){
                $scope.firstHolderKYCStatus = true;
              }else if($scope.holderDetails[1].kycregistered === false){
                $scope.secondHolderKYCStatus = true;
              }else if($scope.holderDetails[2].kycregistered === false){
                $scope.thirdHolderKYCStatus = true;
              }

              // condition for showing no of holders..
              if($scope.holderDetails[0].name){
                $scope.firstHolderStatus = true;
                $scope.firstHolderAadhar = $scope.inputFieldsForFirstHolder[0].value;
              }

              if($scope.holderDetails[1].name){
                $scope.secondHolderStatus = true;
                $scope.secondHolderAadhar = $scope.inputFieldsForSecondHolder[0].value;
              }

              if($scope.holderDetails[2].name){
                $scope.thirdHolderStatus = true;
                $scope.thirdHolderAadhar = $scope.inputFieldsForThirdHolder[0].value;
              }

              // condition for showing and hiding input feilds like Aadhaar and OTP of holders..
              if($scope.holderDetails[0].name !="" && !$scope.holderDetails[0].kycregistered){
                $scope.firstHolderInputStatus = true;
              }

              if($scope.holderDetails[1].name !="" && !$scope.holderDetails[1].kycregistered){
                $scope.secondHolderInputStatus = true;
              }

              if($scope.holderDetails[2].name !="" && !$scope.holderDetails[2].kycregistered){
                $scope.thirdHolderInputStatus = true;
              }

              kycStatus = $scope.holderDetails[0].kycregistered ? "Registered" : "Not Registered";
              $scope.firstHolderDetails = transactModel.setInvTileData($scope.holderDetails[0].name, $scope.holderDetails[0].pan, $scope.holderDetails[0].aadhar, kycStatus, "First Holder Name");

              kycStatus = $scope.holderDetails[1].kycregistered ? "Registered" : "Not Registered";
              $scope.secondHolderDetails = transactModel.setInvTileData($scope.holderDetails[1].name, $scope.holderDetails[1].pan, $scope.holderDetails[1].aadhar, kycStatus, "Second Holder");
              
              kycStatus = $scope.holderDetails[2].kycregistered ? "Registered" : "Not Registered";
              $scope.thirdHolderDetails = transactModel.setInvTileData($scope.holderDetails[2].name, $scope.holderDetails[2].pan, $scope.holderDetails[2].aadhar, kycStatus, "Third Holder");              
                                            
              $scope.KYCsubmit = function(){  
                $scope.showConsentCheckError = false;               
                if($scope.consentCheck){
                    $scope.aadhaarDetails = [];
                    if($scope.firstHolderInputStatus){
                      $scope.aadhaarDetails.push({"adrPANPkrn": $scope.inputFieldsForFirstHolder[0].value})
                    }
                    if($scope.secondHolderInputStatus){                  
                      $scope.aadhaarDetails.push({"adrPANPkrn": $scope.inputFieldsForSecondHolder[0].value})
                    }
                    if($scope.thirdHolderInputStatus){                               
                      $scope.aadhaarDetails.push({"adrPANPkrn": $scope.inputFieldsForThirdHolder[0].value})
                    }                    
                    $scope.generateAndSendEkycOtp();
                }else{
                  $scope.showConsentCheckError = true;
                }  
                                            
              } 

              $scope.continueFunction = function(){
                var firstHolderOTP= true,
                    secondHolderOTP = true,
                    thirdHolderOTP = true;
                    $scope.otpDetails=[];
                    if($scope.inputFieldsForFirstHolder[1].value){
                        if(!$scope.inputFieldsForFirstHolder[1].value) {
                              firstHolderOTP = false;
                        }
                         $scope.otpDetails.push({"adrPANPkrn":$scope.inputFieldsForFirstHolder[0].value, "otp": $scope.inputFieldsForFirstHolder[1].value});
                    } 
                    if($scope.inputFieldsForSecondHolder[1].value){
                        if(!$scope.inputFieldsForSecondHolder[1].value) {
                               secondHolderOTP = false;
                          
                        }
                         $scope.otpDetails.push({"adrPANPkrn":$scope.inputFieldsForSecondHolder[0].value, "otp": $scope.inputFieldsForSecondHolder[1].value});
                    } 
                    if($scope.inputFieldsForThirdHolder[1].value){
                        if(!$scope.inputFieldsForThirdHolder[1].value) {
                             thirdHolderOTP = false;
                        } 
                         $scope.otpDetails.push({"adrPANPkrn":$scope.inputFieldsForThirdHolder[0].value, "otp": $scope.inputFieldsForThirdHolder[1].value});
                    } 
                    if(firstHolderOTP && secondHolderOTP && thirdHolderOTP){
                     $scope.validateEkycOtp();  
                    } else{
                      toaster.error('Please enter OTP');
                    }           
                    
              }

              //validating otp function...
              $scope.validateEkycOtp = function(){
               
                var requestObject = {
                    paramObj:  {"guId" : authenticationService.getUser().guId},
                    bodyObj: {
                      "validateOTPeKYC":$scope.otpDetails
                    }
                  } 
                var validateSuccess = function(successResp){
                  /* var successResp = {
                                "eKYCOTPValidation":[ {
                                  "name": "Srinivas ELlandula",
                                  "dob": "27/03/1989",
                                  "gender": "Male",
                                  "phone": "7675878984",
                                  "email": "srinivas.ellandula07@gmail.com",
                                  "careOf": "Srinivas Ellandula",
                                  "houseNo": "6-3-11451",
                                  "street": "BS Maktha",
                                  "landMark": "Keerthilal Jewellers",
                                  "locality": "Hyderabad",
                                  "vtc": "",
                                  "subDist": "",
                                  "district": "Warangal",
                                  "pinCode": "506313",
                                  "postOffice": "Warangal",
                                  "statusCode": "K105",
                                  "statusDescription": "Invalid Kyc XML from CIDR. kycres missing in the response"
                                },
                              {
                                  "name": "Venkatesh Margulla",
                                  "dob": "15/03/1990",
                                  "gender": "Male",
                                  "phone": "7675878984",
                                  "email": "srinivas.ellandula07@gmail.com",
                                  "careOf": "",
                                  "houseNo": "5-8-1145/1",
                                  "street": "MG Road",
                                  "landMark": "Near Bus station",
                                  "locality": "Mahaboob Nagar",
                                  "vtc": "",
                                  "subDist": "",
                                  "district": "Mahaboob Nagar",
                                  "pinCode": "502665",
                                  "postOffice": "Mahaboob Nagar",
                                  "statusCode": "K105",
                                  "statusDescription": "Invalid Kyc XML from CIDR. kycres missing in the response"
                                }]

                              }; */
                              if(successResp.eKYCOTPValidation){
                                  if(!successResp.eKYCOTPValidation.length){
                                      if(successResp.eKYCOTPValidation.statusDescription === 'SUCCESS'){
                                         ekycVerificationModel.setHolderDetails(successResp);
                                          fticStateChange.stateChange($state, 'txnmaster.verifydetails.aadharDetails');
                                          //$state.go("txnmaster.verifydetails.aadharDetails");
                                      }else{
                                          toaster.error('Please enter valid OTP');
                                      }
                                  } else{
                                         ekycVerificationModel.setHolderDetails(successResp);
                                      fticStateChange.stateChange($state, 'txnmaster.verifydetails.aadharDetails');
                                         //$state.go("txnmaster.verifydetails.aadharDetails");
                                  }
                              }else{
                                  toaster.error('Please enter valid OTP');
                              }
                         
                };

                var validateFailure = function(errorResp){
                   toaster.error(errorResp.data[0].errorDescription);
                };
                ekycVerificationModel.validateEkycOtp(requestObject).then(validateSuccess,validateFailure);
              }

              $scope.generateAndSendEkycOtp = function($event){
                  
                  if($event){
                      $event.preventDefault();
                  }
                  var requestObject = {
                      paramObj: {"guId" : authenticationService.getUser().guId},
                      bodyObj: {
                        "validateOTPeKYC":$scope.aadhaarDetails
                      }
                    }  
      
                  var otpSuccess = function(successResp){
                          $scope.isSubmitted = true;
                          $scope.displayMsg = $scope.continueMsg;
                          toaster.success('Your OTP has been resent successfully');
                  };

                  var otpFailure = function(errorResp){
                          toaster.error(errorResp.data[0].errorDescription);
                  }; 
                  ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpSuccess, otpFailure);
              }

            }]
        };
};

existingUnitHolderDetails.$inject = ['$timeout', 'eventConstants', 'ekycVerificationModel', 'authenticationService','$state','toaster', 'transactModel', 'fticStateChange'];
module.exports = existingUnitHolderDetails;