'use strict';

var fticShareSocial = function($window) {
	return {
        template: require('./shareSocial.html'),
        restrict: 'E',
        scope: {
        	data:"="
        }
    };
};

fticShareSocial.$inject = ['$window'];
module.exports = fticShareSocial;