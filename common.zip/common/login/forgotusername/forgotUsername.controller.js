/**
 * @ngdoc property
 * @name Forgot Password controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function forgotUsernameController($scope, $state, constants, advisorRegistrationModelService, fticStateChange) {
    $scope.forgotType = 'username';
    advisorRegistrationModelService.setUserForgotTypeDetails($scope.forgotType);
    $scope.headingObj = {
        text: constants.login.FORGOTTEN_USERNAME //'Forgotten Password'
    };
    $scope.$on('investorfpSelected', function() {
        fticStateChange.stateChange($state, 'loginmaster.forgotusername.investor');
        //$state.go('loginmaster.forgotusername.investor');

    });
    $scope.$on('distributorSelected', function() {
        fticStateChange.stateChange($state, 'loginmaster.forgotusername.distributor');
        //$state.go('loginmaster.forgotusername.distributor');
    });
    $scope.$emit('setBreadCrumb', {
        cat: 'forgotusername',
        breadCrumb: {
            label: 'Forgot Username',
            state: ''
        }
    });


}

forgotUsernameController.$inject = ['$scope', '$state', 'constants', 'advisorRegistrationModelService', 'fticStateChange'];
module.exports = forgotUsernameController;
