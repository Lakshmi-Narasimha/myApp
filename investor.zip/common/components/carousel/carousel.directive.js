/**
 * @ngdoc directive
 * @name fticCarousel
 * @requires ui.bootstrap
 * @description
 *
 * - This carousel directive creates a carousel similar to bootstrap's image carousel.
   - This carousel also offers support for touchscreen devices in the form of swiping. 
   - To enable swiping, load the ngTouch module as a dependency.
 *
 **/
'use strict';

var carousel = function() {
    return {
        template: require('./carousel.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            active: '@?',
            interval: '@?',
            noPause: '@?',
            noTransition: '@?',
            noWrap: '@?',
            data: '='
        },
        link: function(scope) {
            scope.config = {
                active: scope.active || 0,
                interval: scope.interval || 3000,
                noPause: scope.noPause || false,
                noTransition: scope.noTransition || false,
                noWrap: scope.noWrap || false,
            };
        }
    };
};

carousel.$inject = [];
module.exports = carousel;
