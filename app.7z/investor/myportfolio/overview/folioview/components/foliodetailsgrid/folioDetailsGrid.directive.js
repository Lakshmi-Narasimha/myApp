/**
 * @ngdoc directive
 * @name folioDetailsGrid
 * @requires investorEventConstants
 * @requires investorEventConstants
 * @requires folioViewModel
 * @description
 *
 * - It displays the grid view details of the account statements at Folio level
 * 
 *
 **/
'use strict';

var folioDetailsGrid = function(investorEventConstants, folioViewModel, myportfolioConstants) {
    return {
        template: require('./folioDetailsGrid.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {
            $scope.isFolioDataAvailable = (folioViewModel.getFolioViewObj() ? folioViewModel.getFolioViewObj().folioDetails : false);
            $scope.gridData = [];
            
            if ($scope.isFolioDataAvailable) {
                var folioDetails = folioViewModel.getFolioViewObj().folioDetails;
                $scope.folioNumber = folioDetails.folioNumber;

                var folioDetailsData = folioDetails.gridData.rows;

                $scope.ccpopover = [];
                $scope.gridData = [];

                angular.forEach(folioDetailsData, function(obj, key) {
                    $scope.ccpopover.push(
                        [
                            { text: 'Investment Amount', value: folioDetails.gridData.rows[key].purchaseAmount },
                            { text: 'Dividend Reinvested', value: folioDetails.gridData.rows[key].divInvAmount }
                        ]
                    );
                    var row = {};
                    row.accno = obj.accno;
                    row.fund = obj.fund;
                    row.totalunits = obj.totalUnits;
                    row.currentcost = obj.currentCost;
                    row.currentvalue = obj.currentValue;
                    row.returns = obj.returns;
                    $scope.gridData.push(row);
                });
                var footer = {};
                footer.accno = 'GRAND TOTAL';
                footer.fund = '';
                footer.totalunits = folioDetails.gridData.footer.totalUnits;
                footer.currentcost = folioDetails.gridData.footer.currentCost;
                footer.currentvalue = folioDetails.gridData.footer.currentValue;
                footer.returns = '';
                $scope.gridData.push(footer);
            }


            $scope.returnsText = myportfolioConstants.overview.RETURNS_TOOLTIP_TEXT;

            var statusTemplate = '<div uib-popover-template="\'veiwCompTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                '<script type="text/ng-template" id="veiwCompTemplate.html">' +
                '<div><button type="button" ng-click="grid.appScope.$emit(\'showAccountView\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Account Statement</button><button type="button" ng-click="grid.appScope.$emit(\'BuySIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Buy</button><button type="button" ng-click="grid.appScope.$emit(\'StartASIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Start a SIP</button><button type="button" ng-click="grid.appScope.$emit(\'RedeemSIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Redeem</button><button type="button" ng-click="grid.appScope.$emit(\'SwitchSIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Switch</button></div></script>';
            var infoTemplate = '<ftic-popover class="ftic-accjoint-popover" placement="left" ng-if="col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)]" popovercontent="col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)]" popover-trigger="outsideClick"></ftic-popover>';
            var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue"></span></div>' +
                '<script type="text/ng-template" id="returnTemplate.html">' +
                '<div class="overview-tool-tip">{{col.colDef.returnsText}}</div></script>';

            $scope.columnDefs = [
                { field: 'accdetails', displayName: '', folioNo: $scope.folioNumber, width: '45', cellTemplate: statusTemplate, headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting: false, pinnedLeft: true },
                { field: 'accno', displayName: 'Account Number', width: '140', pinnedLeft: true },
                { field: 'fund', displayName: 'Funds', width: '190' },
                { field: 'totalunits', displayName: 'Units', width: '100' },
                { field: 'currentcost', displayName: 'Current Cost', cellClass:'text-right', width: '110', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'currentcost', displayName: '', data: $scope.ccpopover, width: '40', cellTemplate: infoTemplate },
                { field: 'currentvalue', displayName: 'Current Value', width: '110',cellClass:'text-right', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'returns', displayName: '', width: '100', returnsText: $scope.returnsText, headerCellTemplate: returnsTemplate }
            ];

        }
    };
};

folioDetailsGrid.$inject = ['investorEventConstants', 'folioViewModel', 'myportfolioConstants'];
module.exports = folioDetailsGrid;
