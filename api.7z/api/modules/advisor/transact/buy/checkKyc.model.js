// checkKyc.model.js
// grab the mongoose module
// define our model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var CheckKycModelSchema = new mongoose.Schema({
    CheckKycResp: {
        type: Array,
        "default": []
    }
});

var CheckKycModelLookUp = mongoose.model('CheckKycModelLookUp', CheckKycModelSchema);

var CheckKycModel = new CheckKycModelLookUp({
    "CheckKycResp":
        [{
            "result":
                [
                    {
                        "aadhar":"123456789120",
                        "pan":"THEPS6178R",
                        "kycStatus":"KYC - Registered",
                        "type":"Secondholder",
                        "name":"JHON SMITH GOERGE"
                    }
                ]
        }]
});

CheckKycModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating CheckKycModelLookUp table, please contact admin...');
    } else {
        CheckKycModelLookUp.remove({}, function(err) {
            console.log('CheckKycModelLookUp collection removed');
            CheckKycModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating CheckKycModelLookUp table, please contact admin...');
                }
                console.log('CheckKycModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = CheckKycModelLookUp;