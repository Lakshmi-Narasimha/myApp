
define(['jquery', 'underscore', 'backbone','backboneRelational'], function($, _, Backbone,backboneRelational) {
	Backbone.RelationalModel.extend({
		defaults : {},
		validate : function() {
		},
	});
});