'use strict';

var smartSolnsBuildMyplan = function ($state, $uibModal, $uibModalStack, buildPlanModelService, buildPlanInitialLoader, fundDetailsModel, transactEventConstants) {
    return {
        template: require('./smartSolnsBuildMyplan.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            smartSolInvestor: '@'
        },
        controller:['$scope', function ($scope) {
            // buildPlanInitialLoader.loadAllServices($scope);
            console.log(fundDetailsModel.getFundDetails());
            var modalInstance;
            $scope.indexOfFund = null;

            $scope.selectfund = [
                {
                    label: "Choose Fund",
                    value: "firstFund"
                },
                {
                    label: "Choose Fund",
                    value: "secondFund"
                },
                {
                    label: "Choose Fund",
                    value: "thirdFund"
                }
            ];
            if($scope.smartSolInvestor === 'smartSolInvestor') {
                $scope.fundObject = [
                {
                    key: "firstFund",
                    text: "",
                    name: "firstFund",
                    type: "text",
                    // isRequired:true,
                   // pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                },
                {
                    key: "secondFund",
                    text: "",
                    name: "secondFund",
                    type: "text",
                    // isRequired:true,
                    //pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                },
                {
                    key: "thirdFund",
                    text: "",
                    name: "thirdFund",
                    type: "text",
                    // isRequired:true,
                    //pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                }
            ];
            } else {
                $scope.fundObject = [
                {
                    key: "firstFund",
                    text: "",
                    name: "firstFund",
                    type: "number",
                    // isRequired:true,
                    // pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    pattern: /^\d+$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                },
                {
                    key: "secondFund",
                    text: "",
                    name: "secondFund",
                    type: "number",
                    // isRequired:true,
                    // pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    pattern: /^\d+$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                },
                {
                    key: "thirdFund",
                    text: "",
                    name: "thirdFund",
                    type: "number",
                    // isRequired:true,
                    // pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    pattern: /^\d+$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                }
            ];
            }
            

            var enabledIndices = [0],
                dataRecieved = false;
            $scope.dataRecieved = true;

            $scope.$on(transactEventConstants.transact.NEW_FUND_DETAILS,function(){
                dataRecieved = true;
                $scope.dataRecieved = false;
            });

            $scope.selectFund = function ($index) {
                $scope.indexOfFund = $index;                
                // if (isSelectFundEnabled($index) && dataRecieved) {
                if (dataRecieved) {                    
                    modalInstance = $uibModal.open({
                        template: require('../newFundsModal/newFundsModal.html'),
                        scope: $scope
                    });
                }
            };

            function isSelectFundEnabled(index) {
                for (var i = 0; i < enabledIndices.length; i++) {
                    if (enabledIndices[i] == index) {
                        return true;
                    }
                }
                return false;
            }

            $scope.closeModal = function () {
                $uibModalStack.dismissAll();
            };

            $scope.fundDetails = [];

            $scope.$on('singleSelectionDone', function (event, obj) {
                $scope.selectfund[$scope.indexOfFund].label = obj.selectedOne.fundName;
                $scope.selectfund[$scope.indexOfFund].isSelected = true;
                $scope.fundObject[$scope.indexOfFund].disable = false;
                $scope.fundDetails[$scope.indexOfFund] = obj.selectedOne;
                $scope.closeModal();                
                fundDetailsModel.setFundDetails($scope.fundDetails);
            });


            /*$scope.$on("INPUT_BLUR", function (event, obj) {
                if (getSum() >= 5) {
                    if (getSum() < 100) {                        
                        enabledIndices.push(enabledIndices.length)
                    }
                    else if(getSum() >= 100){
                        is100AllFunds();
                    }
                }

            });*/

            $scope.buildInputChanged =  function(){
                angular.forEach($scope.fundObject, function(fundObj){
                    fundObj.value = fundObj.value.replace(/[&\/\\#,+()$~%.'":*?!_\-<>{}^@a-zA-Z]/g,'')
                });                
            };

            function disableEmpty() {
                for (var i = 0; i < $scope.fundObject.length; i++) {
                    if ($scope.fundObject[i].value === "" || $scope.fundObject[i].value === null) {
                        $scope.fundObject[i].disable = true;
                    }
                }
            }

            function getSum() {
                var count = 0;
                for (var i = 0; i < $scope.fundObject.length; i++) {
                    if(!!parseInt($scope.fundObject[i].value))
                    {
                        count = count + parseInt($scope.fundObject[i].value);
                    }                    
                }
                return count;
            }

            function is100AllFunds() {
                var count = 0;
                for (var i = 0; i < $scope.fundObject.length; i++) {
                    if(!!parseInt($scope.fundObject[i].value))
                    {
                        count = count + parseInt($scope.fundObject[i].value);
                    }
                    if(count==100 && i<($scope.fundDetails.length-1))
                    {
                        resetOtherFunds(i+1);
                        return;
                    }
                }                
            }

            function resetOtherFunds(startIndex){
                for (var i = startIndex; i < $scope.fundObject.length; i++) {
                    $scope.fundObject[i].disable = true;
                    $scope.fundObject[i].value = "";
                    $scope.selectfund[i].label = "Choose Fund";
                    $scope.selectfund[i].isSelected = false;                    
                }
                $scope.fundDetails.splice(startIndex);
                enabledIndices.splice(startIndex);
            }
            
            if (buildPlanModelService.isFromModify && fundDetailsModel.getFundDetails() != null) {
                $scope.fundDetails = fundDetailsModel.getFundDetails();
                for (var i = 0; i < $scope.fundDetails.length; i++) {
                    $scope.selectfund[i].label = $scope.fundDetails[i].fundName;
                    $scope.fundObject[i].value = buildPlanModelService.getAllocationDetails()[i];
                    $scope.selectfund[i].isSelected = true;
                    $scope.fundObject[i].disable = false;
                    $scope.$emit("INPUT_BLUR");

                }
            } else {
                buildPlanModelService.isFromCustomize = false;
            }

            $scope.buildPlan = function () {

                var allocation = [];

                $scope.showSumError = false;

                if (getSum() != 100) {
                    $scope.showSumError = true;
                }

                var selectedFundOptions = [];
                
                $scope.showDuplicateError = false;

                angular.forEach($scope.fundDetails,function(obj,ind){
                    selectedFundOptions.push(obj.fundOption);
                })

                angular.forEach(selectedFundOptions,function(val,ind){
                    if(selectedFundOptions.indexOf(val,(ind+1)) > 0)
                    {                        
                        $scope.showDuplicateError = true;
                    }
                })
                

                if ($scope.buildMyPlan.$valid && !$scope.showSumError && !$scope.showDuplicateError) {
                    for (var i = 0; i < $scope.fundObject.length; i++) {
                        allocation.push($scope.fundObject[i].value);
                    }
                    buildPlanModelService.setAllocationDetails(allocation);
                    $scope.$emit('goBuildMyPlanCntrl');
                }
            }

        }]
    };
};
smartSolnsBuildMyplan.$inject = ['$state', '$uibModal', '$uibModalStack', 'buildPlanModelService', 'buildPlanInitialLoader', 'fundDetailsModel', 'transactEventConstants'];
module.exports = smartSolnsBuildMyplan;