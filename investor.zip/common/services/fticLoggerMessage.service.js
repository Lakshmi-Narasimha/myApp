/**
 * @ngdoc service
 * @name Common FTIC Display Error Message
 * @description
 *
 * - Common method for write logger message to backend as well as to console.
 *
 */


'use strict';

var fticLoggerMessage = function(fticLogger) {
    return {
    	 
        displayLoggerMessage : function (errData) {
            var log = fticLogger.getLogger('fticLogger' + (Math.random() * Math.random()));
            if(!errData.level){
            	log.warn(errData.message); // Default logger when no logger level is set
        	} else {
        		log[errData.level](errData.message);
        	}
        }
    };

};

fticLoggerMessage.$inject = ['fticLogger'];
module.exports = fticLoggerMessage;
