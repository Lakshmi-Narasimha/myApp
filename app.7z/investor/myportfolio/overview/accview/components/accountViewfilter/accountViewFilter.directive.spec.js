'use strict';

describe('Directive: Account View filter', function() {

    var rootScope, compile, scope, $window, event, directiveEle, isolatedScope, invFolioDetails, timeout;
    var invFolioAccountDetails = {
            'accountDetails': {
            'panNo': 'CMLQR5320A',
            'panFolioAccounts': [{
                'folioId': '17877097',
                'latestFolio': 'N',
                'folioAccounts': [
                    '1349904865101',
                    '2389904865101',
                    '4379904865101'
                ]
            }, {
                'folioId': '27877097',
                'latestFolio': 'N',
                'folioAccounts': [
                    '1134990486511',
                    '11389904865101',
                    '11379904865101'
                ]
            }, {
                'folioId': '13592223',
                'latestFolio': 'N',
                'folioAccounts': [
                    '1549900759695'
                ]
            }, {
                'folioId': '13461754',
                'latestFolio': 'N',
                'folioAccounts': [
                    '0069900759695'
                ]
            }, {
                'folioId': '12413948',
                'latestFolio': 'N',
                'folioAccounts': [
                    '0019900759695'
                ]
            }, {
                'folioId': '13027781',
                'latestFolio': 'N',
                'folioAccounts': [
                    '0539900759695'
                ]
            }, {
                'folioId': '14503662',
                'latestFolio': 'Y',
                'folioAccounts': [
                    '0119900830298',
                    '0119901265437',
                    '0349900830474',
                    '0359900830474',
                    '0359901264215'
                ]
            }]
        }
    };
    var accountFilter = { folioPanAccNo: '0119900830298', dayFlag: 'DE' };

    var getCompiledElement = function() {
        var element = angular.element('<ftic-account-view-filter></ftic-account-view-filter>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.inject(function(_$rootScope_, _$compile_, _invFolioDetailsModel_, _$timeout_, _$window_) {            
            rootScope = _$rootScope_;
            scope = rootScope.$new();
            compile = _$compile_;
            invFolioDetails = _invFolioDetailsModel_;
            $window = _$window_;
            $window.ga = function() {};
            timeout = _$timeout_;
            event = document.createEvent("MouseEvent");
            event.initMouseEvent("click", true, true);
        });

        invFolioDetails.setFolioAccountData({
            'panFolioAccounts': invFolioAccountDetails.accountDetails.panFolioAccounts
        })

        directiveEle = getCompiledElement();
        isolatedScope = directiveEle.isolateScope();
        spyOn(scope, '$broadcast');
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have defined sectionOptionsFolio from isolated scope', function() {
        var sectionOptionsFolio = isolatedScope.sectionOptionsFolio;
        expect(sectionOptionsFolio).toBeDefined();
        expect(sectionOptionsFolio[0].folioNumber).toBe('17877097');
        expect(sectionOptionsFolio[0].title).toBe('Folio No. 17877097');
        expect(sectionOptionsFolio[0].folioAccList[0]).toBe('1349904865101');
    });

    it('should have defined selectedFolioOpt from isolated scope', function() {
        var selectedFolioOpt = isolatedScope.selectedFolioOpt;
        expect(selectedFolioOpt).toBeDefined();
        expect(selectedFolioOpt.folioNumber).toBe('14503662');
        expect(selectedFolioOpt.title).toBe('Folio No. 14503662');
        expect(selectedFolioOpt.folioAccList[0]).toBe('0119900830298');
    });

    it('should have defined selectedAccOpt from isolated scope', function() {
        var selectedAccOpt = isolatedScope.selectedAccOpt;
        expect(selectedAccOpt).toBeDefined();
        expect(selectedAccOpt.accontNumber).toBe('0119900830298');
        expect(selectedAccOpt.title).toBe('Account No. 0119900830298');
    });

    it('should have defined dateOptions from isolated scope', function() {
        var dateOptions = isolatedScope.dateOptions;
        expect(dateOptions).toBeDefined();
        expect(dateOptions[0].key).toBe('DE');
        expect(dateOptions[0].label).toBe('Default(Last 6 Transactions)');
        expect(dateOptions[0].type).toBe('defineddate');
    });

    it('should have defined selectedObj from isolated scope', function() {
        var selectedObj = isolatedScope.selectedObj;
        expect(selectedObj).toBeDefined();
        expect(selectedObj.key).toBe('DE');
        expect(selectedObj.label).toBe('Default(Last 6 Transactions)');
        expect(selectedObj.type).toBe('defineddate');
    });

    it('should have defined hideSelect from isolated scope', function() {
        var hideSelect = isolatedScope.hideSelect;
        expect(hideSelect).toBeTruthy();
    });

    it('should call selectedFolio event from isolated scope', function() {
        scope.$broadcast('selectedFolio', event, isolatedScope.selectedFolioOpt);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedFolio', event, isolatedScope.selectedFolioOpt);
    });

    it('should call selectedAcc event from isolated scope', function() {
        spyOn(isolatedScope, 'emitApply');
        scope.$broadcast('selectedAcc', event, isolatedScope.selectedAccOpt);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedAcc', event, isolatedScope.selectedAccOpt);
        expect(isolatedScope.initFlag).toBe(true);
        timeout.flush();
        expect(isolatedScope.emitApply).toHaveBeenCalled();
    });

    it('should call selectedValue event from isolated scope', function() {
        scope.$broadcast('selectedValue', event, isolatedScope.selectedObj);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedValue', event, isolatedScope.selectedObj);
    });

    it('should emit apply event through emitApply event from isolated scope', function() {
        spyOn(isolatedScope, 'emitApply').and.callThrough();
        spyOn(isolatedScope, '$emit');
        isolatedScope.emitApply();
        expect(isolatedScope.emitApply).toHaveBeenCalled();
        expect(isolatedScope.$emit).toHaveBeenCalledWith('apply', accountFilter);
    });

});
