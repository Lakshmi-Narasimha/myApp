// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var EmandateDetailsSchema = new mongoose.Schema({
    regEmandate: {
        type: Object,
        "default": {}
    }
});

var RegEmandateLookUp = mongoose.model('RegEmandateLookUp', EmandateDetailsSchema);

var regEmandateModel = new RegEmandateLookUp({
      regEmandate: {
          "accountNo": "",
          "folioId": "",
          "transactionValidated": "True",
          "webRefNo": "EM12564",
          "trDate": "",
          "urnNo": ""
        }
});

RegEmandateLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating RegEmandateLookUp table, please contact admin...');
    } else {
        RegEmandateLookUp.remove({}, function(err) {
            console.log('removeEmandateModel collection removed');
            regEmandateModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RegEmandateLookUp table, please contact admin...');
                }
                console.log('RegEmandateLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RegEmandateLookUp;
