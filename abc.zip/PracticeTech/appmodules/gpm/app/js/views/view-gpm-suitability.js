define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'appcommon/data', 'appmodules/contactprofile/app/models/cpviewmodel', 'text!appmodules/gpm/app/templates/gpmsuitability.html', 
    'appcommon/constants', 'components/js/views/RadioButtonView', 'components/js/views/CheckBoxView', 'appcommon/abstractview'
], function ($, _, Backbone, Utils, GPMData, CPViewModel, SuitabilityTemplate, Constants, RadioButtonView, CheckBoxView, AbstractView) {
	var assetTypesHeldCollection = [], doesClientHaveAssetsVal = {}, doesClientHaveInvestment;
	var investExpCollection = [], sourceIncomeCollection = [], preSelectedYear = null, preSelectedYearDesc = null, preSelectedTrans = null, preSelectedTransDesc = null, preSelectedYearCd = null, preSelectedTransCd = null;
    var suitabilityView = AbstractView.extend({
    		el: "#gpm-form-update-field-container",
    		id: 'gpm-form-update-field-container',
    		investmentCheckboxViewName: 'investmentCheckboxViewName',
    		doesClientHaveAssetsViewName: 'doesClientHaveAssetsViewName',
    		assetTypeCheckboxViewName: 'assetTypeCheckboxViewName',
    		sourceOfIncomeCheckViewName: 'sourceOfIncomeCheckViewName',
    		events: {
		            'change input[type="checkbox"]': 'toggleCheckboxClassActive',
		            'change input[type="radio"]': 'toggleRadioClassActive',
		            'click .gpm-product-exp': 'handleNoneOptionClick',
		            'click .prod-opt': 'handleOtherOptionClick',
		            'keypress #income-indi-annual,#income-indi-net,#income-indi-liquid': 'numValidator',
		            'focus #income-indi-annual,#income-indi-net,#income-indi-liquid': 'formatCurrencyToNormal',
		            'blur #income-indi-annual,#income-indi-net,#income-indi-liquid': 'formatCurrency',
		            "click .has-invest-exp": "toggleInvestmentExp"
    },
    		template: _.template(SuitabilityTemplate),
    		initialize: function (data) {
		        	AbstractView.prototype.initialize.apply(this, arguments);
		        	this.data = data;
		        	this.isEntity = false;
		        	AbstractView.prototype.initialize.apply(this, arguments);
    },
    		render: function (updateMode) {
    		    try {
    		        var self = this;
    		        var _data = null;//ClientModel.toJSON();
    		        this.initializeElementVars();

    		        if (!this.model.get('currentItemSet')) {
    		            var CPData = CPViewModel.getInstance().getData();
    		            var productExperincesCollection = [];
    		            var productExperincesCollectionCodes = [];
    		            doesClientHaveInvestment = 'No';
    		            this.isEntity = (CPViewModel.getInstance().getData().cola.orgClient.get("orgNm") != null ? true : false);

    		            //Investment experience
    		            investExpCollection = [];
    		            if (CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('clientProductExpes') && CPData.cola.clientPersonal.get('clientProductExpes').length > 0) {
    		                var _invtExperinces = CPData.cola.clientPersonal.get('clientProductExpes');
    		                _.each(_invtExperinces, function (key, row) {
    		                    var _invExp = (_.find(Constants.sortedInvestmentExpList, function (obj) {
    		                        return obj.mapCode == key.get('prodExpeTypeCd');
    		                    }));

    		                    if (_invExp) {
    		                        var _invExpeYrCd = (_.find(Constants.sortedInvExpYearRadioList, function (yrCdobj) {
    		                            return yrCdobj.mapCode == key.get('invExpeYrCd');
    		                        }));

    		                        var _annlTrnsCd = (_.find(Constants.sortedNoOfTransRadioList, function (trnsCdobj) {
    		                            return trnsCdobj.mapCode == key.get('annlTransCd');
    		                        }));

    		                        if (_invExpeYrCd && _annlTrnsCd) {
    		                            doesClientHaveInvestment = "Yes";
    		                            investExpCollection.push([{
    		                                "code": _invExp.code,
    		                                "displayOrder": _invExp.displayOrder,
    		                                "description": _invExp.description,
    		                                "mapCode": _invExp.mapCode,
    		                                "years": {
    		                                    "defaultValue": "0 years",
    		                                    "selectedValue": (_invExpeYrCd ? _invExpeYrCd.mapCode : ""),
    		                                    "description": (_invExpeYrCd ? _invExpeYrCd.description : ""),
    		                                    "mapCode": (_invExpeYrCd ? _invExpeYrCd.mapCode : "")
    		                                },
    		                                "transaction": {
    		                                    "defaultValue": "0 annual transactions",
    		                                    "selectedValue": (_annlTrnsCd ? _annlTrnsCd.mapCode : ""),
    		                                    "description": (_annlTrnsCd ? _annlTrnsCd.description : ""),
    		                                    "mapCode": (_annlTrnsCd ? _annlTrnsCd.mapCode : "")
    		                                }

    		                            }]);
    		                        }
    		                    }
    		                });
    		                investExpCollection = _.flatten(investExpCollection);
    		            }

    		            if (CPData.cola && CPData.cola.clientPersonal) {
    		                sourceIncomeCollection = [];
    		                var firstSourceIncome = (_.find(Constants.sortedSourceOfIncomeList, function (obj)
    		                { return obj.mapCode == CPData.cola.clientPersonal.get('firstSrcOfIncmCd') }));

    		                if (firstSourceIncome) {
    		                    sourceIncomeCollection.push([{
    		                        "mapCode": firstSourceIncome.mapCode,
    		                        "description": firstSourceIncome.description,
    		                        "displayOrder": firstSourceIncome.displayOrder
    		                    }]);
    		                }

    		                var secondSourceIncome = (_.find(Constants.sortedSourceOfIncomeList, function (obj)
    		                { return obj.mapCode == CPData.cola.clientPersonal.get('scndSrcOfIncmCd') }));

    		                if (secondSourceIncome) {
    		                    sourceIncomeCollection.push([{
    		                        "mapCode": secondSourceIncome.mapCode,
    		                        "description": secondSourceIncome.description,
    		                        "displayOrder": secondSourceIncome.displayOrder
    		                    }]);
    		                }
    		                var thirdSourceIncome = (_.find(Constants.sortedSourceOfIncomeList, function (obj)
    		                { return obj.mapCode == CPData.cola.clientPersonal.get('thirdSrcOfIncmCd') }));

    		                if (thirdSourceIncome) {
    		                    sourceIncomeCollection.push([{
    		                        "mapCode": thirdSourceIncome.mapCode,
    		                        "description": thirdSourceIncome.description,
    		                        "displayOrder": thirdSourceIncome.displayOrder
    		                    }]);
    		                }
    		                sourceIncomeCollection = _.flatten(sourceIncomeCollection);
    		            }

    		            var federalTaxBracket = (_.find(GPMData.federalTaxBrackets, function (obj) { return obj.serviceValue == ((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('fedTxBrktPct')) ? parseInt(CPData.cola.clientPersonal.get('fedTxBrktPct')).toFixed(2) : "") }) || {
    		                name: "", code: "", serviceValue: ""
    		            });
    		            //var investExpCollection = (_.find(GPMData.investmentExperince, function (obj) { return obj.serviceValue.indexOf(((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('invExpeYrCd')) ? CPData.cola.clientPersonal.get('invExpeYrCd') : "")) != "-1" }) || {
    		            //    name: "", code: "", serviceValue: ""
    		            //});
    		            //var doesClientHaveInvestment = 'Yes';
    		            /*	var doesClientHaveInvestment = ((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('clientHasInvestment')) ? CPData.cola.clientPersonal.get('clientHasInvestment') : "");
                            var incomeInvestment = (CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('incomeInvestment')) ? CPData.cola.clientPersonal.get('incomeInvestment') : "";
                            var incomeInvestmentVal = (CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('incomeInvestmentVal')) ? CPData.cola.clientPersonal.get('incomeInvestmentVal') : "";
                        var incomeInvestmentCollectionModel =[];*/

    		            var doesClientHaveAssets = ((CPData.cola && CPData.cola.heldAway && CPData.cola.heldAway.heldAwayInfoCd) ? CPData.cola.heldAway.heldAwayInfoCd : "");
    		            assetTypesHeldCollection = [];

    		            if (CPData.cola && CPData.cola.heldAway && CPData.cola.heldAway.detail) {
    		                var heldAwaySrvData = CPData.cola.heldAway.detail;
    		                var assetTypeConstItems = Constants.sortedAssetTypeHeldList;
    		                _.each(assetTypeConstItems, function (assetTypeList, index) {
    		                    if (heldAwaySrvData.hasOwnProperty(assetTypeList.servName)) {
    		                        if (heldAwaySrvData[assetTypeList.servName] != null && heldAwaySrvData[assetTypeList.servName] != 0) {
    		                            assetTypesHeldCollection.push([{
    		                                "code": assetTypeList.code,
    		                                "displayOrder": assetTypeList.displayOrder,
    		                                "description": assetTypeList.description,
    		                                "mapCode": assetTypeList.mapCode,
    		                                "servName": assetTypeList.servName,
    		                                "assetVal": { "defaultValue": "", "enteredValue": heldAwaySrvData[assetTypeList.servName] }
    		                            }]);
    		                        }
    		                    }
    		                });
    		                assetTypesHeldCollection = _.flatten(assetTypesHeldCollection);
    		            }
    		            this.data.fieldsInfo = {
    		                fedTxBrktPct: federalTaxBracket,
    		                annlIncm: ((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('annlIncm')) ? parseFloat(CPData.cola.clientPersonal.get('annlIncm')) : ""),
    		                netWorth: ((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('netWorth')) ? parseFloat(CPData.cola.clientPersonal.get('netWorth')) : ""),
    		                liqNetWorth: ((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('liqNetWorth')) ? parseFloat(CPData.cola.clientPersonal.get('liqNetWorth')) : ""),
    		                sourceOfIncome: { names: sourceIncomeCollection },
    		                invExpeYrCd: investExpCollection,
    		                doesClientHaveInvestment: doesClientHaveInvestment,
    		                clientProductExpes: { names: investExpCollection },
    		                isEntityClient: self.isEntity,
    		                doesClientHaveAssets: doesClientHaveAssets,
    		                assetTypeHeldCollec: { names: assetTypesHeldCollection }
    		            };
    		            this.model.setCurrentValue(updateMode, { data: this.data });
    		        }
    		        var _dataSet = this.model.get('items');
    		        var _isDevice = this.model.get('isDevice');

    		        $("#" + this.id).html(this.template({ data: _dataSet, isDevice: _isDevice, investmentExpList: GPMData.investExpCollection, productExperinceList: GPMData.productExperince, isEntityClient: self.isEntity })).promise().done(function () {
    		            var fedTxBrktPct = _dataSet.find(function (row) {
    		                return row.get("itemType") == "fedTxBrktPct"
    		            });
    		            $("#income-fed-tax").val(fedTxBrktPct.get("changedItemValue"));
    		            //var prmSrcOfIncmCd = _dataSet.find(function (row) {
    		            //    return row.get("itemType") == "prmSrcOfIncmCd"
    		            //	});
    		            //		self.loadPrimarySourceIncomeList(prmSrcOfIncmCd.get("changedItemValueId"));
    		            var fedTxBrktPct = _dataSet.find(function (row) {
    		                return row.get("itemType") == "fedTxBrktPct"
    		            });
    		            self.loadFederaltaxBracketList(fedTxBrktPct.get("changedItemValueId"));
    		            var doesClientHaveAssets = (_dataSet.find(function (row) { return row.get("itemType") == "doesClientHaveAssets" })).get("changedItemValueId");
    		            self.renderDoesClientHaveAssetsRadioBtns(doesClientHaveAssets);

    		            var assetTypesHeldColl = (_dataSet.find(function (row) { return row.get("itemType") == "heldAwayAssets" })).get("changedItemValueId");

    		            if (doesClientHaveAssets != undefined && doesClientHaveAssets == "A") {
    		                $('#asset-type-held').removeClass('hidden');
    		                self.renderAssetTypeHeldChkBoxes(assetTypesHeldColl);
    		            }
    		            else {
    		                $('#asset-type-held').addClass('hidden');
    		            }
    		        });
    		        var _doesClientHaveInvestment = _dataSet.find(function (row) { return row.get("itemType") == "doesClientHaveInvestment" });

    		        var clientProductExpes = (_dataSet.find(function (row) { return row.get("itemType") == "clientProductExpes" })).get("changedItemValueId");
    		        if (_doesClientHaveInvestment.get('changedItemValue') == "Yes") {
    		            //trigger yes
    		            $('#invest-exp-container').removeClass('hidden');
    		            this.renderInvestmentExpCheckbox(clientProductExpes);
    		        }

    		        var sourceOfIncome = (_dataSet.find(function (row) { return row.get("itemType") == "sourceOfIncome" })).get("changedItemValueId");

    		        if (sourceOfIncome && sourceOfIncome.length > 0) {
    		            this.renderSourceOfIncomeCheckbox(sourceOfIncome)
    		        } else {
    		            this.renderSourceOfIncomeCheckbox(null);
    		        }
    		    }
    		    catch (error) {
    		        console.log(error);
    		    }
        },
        
        renderSourceOfIncomeCheckbox: function (incomeSourceData) {
            var self = this, sourceOfIncomeCheckView, componentId = "source-of-income-checkbox", incomeConstList = Constants.sortedSourceOfIncomeList;
            sourceOfIncomeCheckView = new CheckBoxView({
                el: $('#' + componentId),
                items: incomeConstList,
                sideCompIndex: 0
            });
            if (incomeSourceData && incomeSourceData != null) {
                sourceOfIncomeCheckView.selectedItems = incomeSourceData;
            }
            sourceOfIncomeCheckView.itemSelectionComplete = function (selectedItems, itemId) {
                if (selectedItems.length > 0 && selectedItems.length < 4) {
                    if (selectedItems.length > 0 && selectedItems[0].displayOrder == '9' && selectedItems[0].description == "None") {
                        sourceIncomeCollection = selectedItems = _.without(selectedItems, selectedItems[0]);
                    } else {
                        _.filter(selectedItems, function (item) {
                            if (item.description == "None" && item.displayOrder == '9') {
                                sourceIncomeCollection = selectedItems = [item];
                            } else {
                                sourceIncomeCollection = selectedItems;
                            }
                        });
                    }
                    sourceOfIncomeCheckView.selectedItems = selectedItems;
                    sourceOfIncomeCheckView.reRender();
                    sourceIncomeCollection = selectedItems;
                }

                if (selectedItems.length > 3) {
                    selectedItems = _.filter(selectedItems, function (item) {
                        return item.displayOrder != (itemId + 1);
                    });
                    sourceOfIncomeCheckView.selectedItems = selectedItems;
                    sourceOfIncomeCheckView.reRender();
                    sourceIncomeCollection = selectedItems;
                } else {
                    sourceIncomeCollection = selectedItems;
                }
            };
            this.addNestedView(this.sourceOfIncomeCheckViewName, sourceOfIncomeCheckView);
            sourceOfIncomeCheckView.render();
    },
       
    		toggleInvestmentExp: function (obj) {
		        	var _$clickedButton = $(obj.currentTarget);
            investExpCollection = [];
		        	if (_$clickedButton.hasClass('active')) {
		        		return false;
		        	} else {
		        		$('.has-invest-exp').removeClass('active');
		        		_$clickedButton.addClass('active');
    		}
		        	if (_$clickedButton.val() == "Yes") {
		        		$('#invest-exp-container').removeClass('hidden');
		        	    doesClientHaveInvestment = "Yes";
		        		this.renderInvestmentExpCheckbox(investExpCollection);
		        	} else {
		        		$('#invest-exp-container').addClass('hidden');
		        	    doesClientHaveInvestment = "No";
		        		var investConstItems = Constants.sortedInvestmentExpList;
		        		_.each(investConstItems, function (list, key) {
                    list["years"] = {
                        defaultValue: "0 years", description: ""
		        		};
                    list["transaction"] = {
                        defaultValue: "0 annual transactions", description: ""
		        		};
		        	});
		        		investExpCollection = investConstItems;
		        		preSelectedYear = null; preSelectedYearDesc = null; preSelectedTrans = null; preSelectedTransDesc = null, preSelectedTransCd = null, preSelectedYearCd = null;
    		}
    },
    		renderInvestmentExpCheckbox: function (investExpModelData) {
		        	var self = this, investmentCheckboxView, componentId = "gpm-investment-exp-checkbox", investConstItems = Constants.sortedInvestmentExpList;
		        	investmentCheckboxView = new CheckBoxView({
                el: $('#' + componentId),
		        			items: investConstItems,
		        		sideCompIndex: 4
    		});
		        	if (investExpModelData != "" && investExpModelData.length > 0) {
                var selectedList = [];
		        		_.each(investExpModelData, function (investList) {
		        			_.find(investConstItems, function (investConstList) {
		        			    if (investConstList.mapCode == investList.mapCode) {
		        				    selectedList.push(investConstList);
		        			}
		        		});
		        	});
		        		investmentCheckboxView.selectedItems = selectedList;
    		}
		        	investmentCheckboxView.itemSelectionComplete = function (selectedItem, itemId) {
		        		self.captureInvestmentSelection(selectedItem, componentId, itemId, true);
    		};
		        	this.addNestedView(this.investmentCheckboxViewName, investmentCheckboxView);
		        	investmentCheckboxView.render();

		        	if (investExpModelData != null || investExpModelData.length > 0) {
		        		_.each(investExpModelData, function (list) {
                    self.captureInvestmentSelection([list], componentId, (list.displayOrder - 1), false);
		        	});
    		}
    },
    		captureInvestmentSelection: function (selectedItem, componentId, itemId, dataFromModelFlag) {
            var activeComp = $('#' + itemId + '-' + componentId),
						activeParent = activeComp.parents().eq(1),
						checkFlag = activeComp.is(":checked"),
						sideComp = componentId + '-sidecontainer-' + itemId;
		        	    transTitle = "Avg. number of buy and sell trades per year",
                        investConstItems = Constants.sortedInvestmentExpList;

		        	    if (investConstItems[itemId].mapCode == "D") {
		        	        transTitle = transTitle + " (not including DRIP arrangements)";
		        	    }
		        	    else if (investConstItems[itemId].mapCode == "B") {
		        	        transTitle = transTitle + " (not including systematic arrangements)";
		        	    }

		        	if (checkFlag || dataFromModelFlag == false) {
		        		this.renderInvExpTitle(sideComp);
		        		this.renderInvestYearRadio(itemId, componentId, selectedItem);
		        		this.renderTransTitle(sideComp, transTitle);
		        		this.renderTransYearRadio(itemId, componentId, selectedItem);
		        		this.addCSSClasses(activeComp, activeParent);
		        		if (dataFromModelFlag) {
		        			this.appendSelectedInvestExp(selectedItem, componentId, itemId, dataFromModelFlag);
		        		} else {
		        		    var componentYearName = 'select-choice-' + componentId + '-sidecontainer-' + itemId + '2';		        		   		        		   		        		   		        
		        		    preSelectedYearDescTemp = selectedItem[0].years.description;
		        		    $('input:radio[name="' + componentYearName + '"]').filter('[value="' + preSelectedYearDescTemp + '"]').attr('checked', true);
		        		    
		        		    var componentTransName = 'select-choice-' + componentId + '-sidecontainer-' + itemId + '4';
		        		    preSelectedTransDescTemp = selectedItem[0].transaction.description;		        		    
		        		    $('input:radio[name="' + componentTransName + '"]').filter('[value="' + preSelectedTransDescTemp + '"]').attr('checked', true);		        		   		        		   
		        	}
		        	} else {
		        		_.filter(investExpCollection, function (list, key) {
                    if (list.code == (itemId + 1)) {
		        				investExpCollection.splice(key, 1);
		        		}
		        	});
		        		this.clearInvestExpModel(investExpCollection);
		        		this.removeCSSClasses(activeComp, activeParent);
		        		for (i = 1; i <= 4; i++) {
		        			$('div[ampf-radio-buttons="' + sideComp + i + '"]').remove();
		        	}
    		}
    },
    		clearInvestExpModel: function (investExpCollection) {
		        	if (investExpCollection.length == 0) {
		        		preSelectedYear = null; preSelectedYearDesc = null; preSelectedTrans = null; preSelectedTransDesc = null;
    		}
    },
    		appendSelectedInvestExp: function (selectedItem, componentId, index, dataFromModelFlag) {
            var items = [{
		        		"code": "",
		        		"displayOrder": "",
		        		"description": "",
		        		"mapCode": "",
		        		"years": {
		        			"defaultValue": "0 years",
		        			"selectedValue": "",
    		            "description": "",
    		            "mapCode": ""
		        	},
		        		"transaction": {
		        			"defaultValue": "0 annual transactions",
		        			"selectedValue": "",
    		            "description": "",
    		            "mapCode": ""
		        	}
    		}];

            items[0].code = selectedItem[(selectedItem.length - 1)].code;
            items[0].description = selectedItem[(selectedItem.length - 1)].description;
            items[0].displayOrder = selectedItem[(selectedItem.length - 1)].displayOrder;
            items[0].mapCode = selectedItem[(selectedItem.length - 1)].mapCode;

		        	if ((preSelectedYear == null || preSelectedYear == "") && investExpCollection.length > 0) {
		        		preSelectedYear = investExpCollection[0].years.selectedValue;
		        		preSelectedYearDesc = investExpCollection[0].years.description;
    		        preSelectedYearCd = investExpCollection[0].years.mapCode;
    		}
		        	if ((preSelectedYear != null || preSelectedYear != "") && investExpCollection.length > 0) {
    		        var componentName = componentId + '-sidecontainer-' + index + '2';
		        		items[0].years.selectedValue = preSelectedYear;
		        		items[0].years.description = preSelectedYearDesc;
    		        items[0].years.mapCode = preSelectedYearCd;
    		        $('input:radio[name="select-choice-' + componentName + '"]').filter('[value="' + preSelectedYearDesc + '"]').attr('checked', true);

                    //Preselect years based on prior selection
    		        for (var key in this.nestedViews) {
    		            if (key.indexOf("investmentCheckboxView") > -1) {
    		                var _that = this;
    		                nestedViewId = this.nestedViews[key].el.id;
    		                _.each(this.nestedViews[key].selectedIndexes, function (itemDesc, idx) {
    		                    for (i = 1; i <= 2; i++) {
    		                        var radioBtnViewName = "testRadioBtnViewName" + itemDesc + i;
    		                        if (_that.nestedViews[radioBtnViewName]) {
    		                            var nestedRadioBtnId = _that.nestedViews[radioBtnViewName].el.id;    		                            
    		                            if (nestedRadioBtnId == componentName) {
    		                                $.each(Constants.sortedInvExpYearRadioList, function (key) {
    		                                    if (Constants.sortedInvExpYearRadioList[key].description == preSelectedYearDesc) {
    		                                        _that.nestedViews[radioBtnViewName].selectedItem = Constants.sortedInvExpYearRadioList[key];
    		                                    }
    		                                });    		                                
    		                            }
    		                        }
    		                    }
    		                });
    		            }
    		        }

    		}

		        	if ((preSelectedTrans == null || preSelectedTrans == "") && investExpCollection.length > 0) {
		        		preSelectedTrans = investExpCollection[0].transaction.selectedValue;
		        		preSelectedTransDesc = investExpCollection[0].transaction.description;
    		        preSelectedTransCd = investExpCollection[0].transaction.mapCode;
    		}
		        	if ((preSelectedTrans != null || preSelectedTrans != "") && investExpCollection.length > 0) {
    		        var componentName = componentId + '-sidecontainer-' + index + '4';
		        		items[0].transaction.selectedValue = preSelectedTrans;
		        		items[0].transaction.description = preSelectedTransDesc;
    		        items[0].transaction.mapCode = preSelectedTransCd;
    		        $('input:radio[name="select-choice-' + componentName + '"]').filter('[value="' + preSelectedTransDesc + '"]').attr('checked', true);

    		        //Preselect #transactions based on prior selection
    		        for (var key in this.nestedViews) {
    		            if (key.indexOf("investmentCheckboxView") > -1) {
    		                var _that = this;
    		                nestedViewId = this.nestedViews[key].el.id;
    		                _.each(this.nestedViews[key].selectedIndexes, function (itemDesc, idx) {
    		                    for (i = 1; i <= 2; i++) {
    		                        var radioBtnViewName = "testRadioBtnViewName" + itemDesc + i;
    		                        if (_that.nestedViews[radioBtnViewName]) {
    		                            var nestedRadioBtnId = _that.nestedViews[radioBtnViewName].el.id;
    		                            if (nestedRadioBtnId == componentName) {
    		                                $.each(Constants.sortedNoOfTransRadioList, function (key) {
    		                                    if (Constants.sortedNoOfTransRadioList[key].description == preSelectedTransDesc) {
    		                                        _that.nestedViews[radioBtnViewName].selectedItem = Constants.sortedNoOfTransRadioList[key];
    		                                    }
    		                                });
    		                            }
    		                        }
    		                    }
    		                });
    		            }
    		        }

    		}
		        	investExpCollection.push(items);
		        	investExpCollection = _.flatten(investExpCollection);
    },
    		addCSSClasses: function (activeComp, activeParent) {
		        	activeParent.find('div.radio-group-conatiner').addClass('no-ui-bg');
		        	activeComp.parent().addClass('custom-radio-labelUI');
		        	activeParent.addClass('custom-chkbox-width');
		        	activeParent.find('div.sideComp-container').addClass('sideComp-divUI');
    },
    		removeCSSClasses: function (activeComp, activeParent) {
		        	activeComp.parent().removeClass("custom-radio-labelUI");
		        	activeParent.removeClass('custom-chkbox-width');
		        	activeParent.find('div.sideComp-container').removeClass('sideComp-divUI');
    },
    		renderInvExpTitle: function (sideComp) {
    		    var html = sideComp + '1';
    		    var investExpPop = "<i id='invest-exp-info-popup' class='icon-info info-popup' data-toggle='popover' title='Investment experience'" +
                                                " data-content=\"<p class='info-popup'> Investment experience is cumulative, not the number of years since the first purchase.</p> " +
                                                "<p>Ex: If client purchased options actively in 2007 and 2008 but hasn\'t since that time = 2 years.</p> " +
                                                "<p>If years of experience has not crossed the minimum of the range, select the lower range, with the exception of anything greater than none falling into 1-2 years.</p> " +
                                                "<p>Ex: 8 months = 1-2 years <br/> 2.5 years = 1-2 years <br/> 5.5 years = 3-5 years  </p> " +
                                                "\" > &nbsp; </i> ";
    		    $('#' + html).html('<div class="pt-pad-btm-5px" ampf-radio-buttons="' + html + '">Investment experience ' + investExpPop + ' </div>');
    		    $("#gpm-update-form-container").invokeInfoPopup();
    },
    		renderTransTitle: function (sideComp, transTitle) {
    		    var html = sideComp + '3';
    		    $('#' + html).html('<div class="pt-pad-btm-5px pt-pad-top-10px" ampf-radio-buttons="' + html + '">' + transTitle + '</div>');
    },
    		renderInvestYearRadio: function (index, invComponentId, selectedInvExpItem) {
		        	var radioButtonsView, self = this;
		        	radioButtonsView = new RadioButtonView({
		        			el: self.$('#' + invComponentId + '-sidecontainer-' + index + '2'),
		        			items: Constants.sortedInvExpYearRadioList
    		});
		        	
		        	if (selectedInvExpItem && selectedInvExpItem.length > 0 && selectedInvExpItem[0].years) {
		        	    $.each(Constants.sortedInvExpYearRadioList, function (key) {
		        	        if (Constants.sortedInvExpYearRadioList[key].description == selectedInvExpItem[0].years.description) {
		        	            radioButtonsView.selectedItem = Constants.sortedInvExpYearRadioList[key];
		        	        }
		        	    });
		        	}

		        	radioButtonsView.itemSelectionComplete = function (selectedItem) {
		        		self.captureInvestYearRadio(selectedItem, index);
    		};
		        	testRadioBtnViewName = 'testRadioBtnViewName' + index + '1';
		        	this.addNestedView(testRadioBtnViewName, radioButtonsView);
		        	radioButtonsView.render();
    },
    		captureInvestYearRadio: function (selectedItem, index) {
		        	_.filter(investExpCollection, function (list) {
                if (list.code == (index + 1)) {
		        			list.years.selectedValue = selectedItem.code;
		        			list.years.description = selectedItem.description;
		        			list.years.mapCode = selectedItem.mapCode;
		        	}
    		});
    },
    		renderTransYearRadio: function (index, invComponentId, selectedTransYrsItem) {
		        	var radioButtonsView, self = this;
		        	radioButtonsView = new RadioButtonView({
		        			el: self.$('#' + invComponentId + '-sidecontainer-' + index + '4'),
		        			items: Constants.sortedNoOfTransRadioList
    		});

		        	if (selectedTransYrsItem && selectedTransYrsItem.length > 0 && selectedTransYrsItem[0].transaction) {
		        	    $.each(Constants.sortedNoOfTransRadioList, function (key) {
		        	        if (Constants.sortedNoOfTransRadioList[key].description == selectedTransYrsItem[0].transaction.description) {
		        	            radioButtonsView.selectedItem = Constants.sortedNoOfTransRadioList[key];
		        	        }
		        	    });
		        	}

		        	radioButtonsView.itemSelectionComplete = function (selectedItem) {
		        		self.captureTransYearRadio(selectedItem, index);
    		};
		        	testRadioBtnViewName = 'testRadioBtnViewName' + index + '2';
		        	this.addNestedView(testRadioBtnViewName, radioButtonsView);
		        	radioButtonsView.render();
    },
    		captureTransYearRadio: function (selectedItem, index) {
		        	_.filter(investExpCollection, function (list) {
                if (list.code == (index + 1)) {
		        			list.transaction.selectedValue = selectedItem.code;
		        			list.transaction.description = selectedItem.description;
		        			list.transaction.mapCode = selectedItem.mapCode;
		        	}
    		});
    },
    		toggleCheckboxClassActive: function (event) {
		            var _checkbox = $(event.target);
		            if (_checkbox.is(':checked')) {
		                _checkbox.parents('div.radio-group-conatiner').addClass('active');
		            } else {
		                _checkbox.parents('div.radio-group-conatiner').removeClass('active');
    		}
    },
    		handleNoneOptionClick: function (e) {
		        	var targetEl = $(e.target);
		        	var tagetContainer = targetEl.parent().parent();
		            if (targetEl.data("value") == "None") {
		                $('.prod-opt').not(targetEl).prop('checked', false);
		                $('.other-opt-cls').not(tagetContainer).removeClass('active');
		            } else {
		            	var noneEL = $("input[data-value='None']");
		            	var noneELContainer = noneEL.parent().parent();
		            	noneEL.prop('checked', false);
		            	noneELContainer.removeClass('active');
    		}
    },
    		handleOtherOptionClick: function () {
            if ($(".prod-opt").is(':checked')) {
		                $('#none-opt').prop('checked', false);
		                $('.none-opt-cls').removeClass('active');
    		}
    },
    		toggleRadioClassActive: function (event) {
		            var _radio = $(event.target);
		            var _radioHolder = _radio.parents('div.radio-grp-holder');
		            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
		            _radio.parents('div.radio-group-conatiner').addClass('active');
    },
    		validateAndNavigateFromStep1: function () {
		            if (this.model.validate('gpm-update-form', true)) {
		                var assetTypeConstItems = Constants.sortedAssetTypeHeldList;
		                _.each(assetTypeConstItems, function (assetTypeList, index) {
		                    _.find(assetTypesHeldCollection, function (list) {
		                        if (list.code == assetTypeList.code) {
                            list.assetVal.enteredValue = $('#asset-type-held-chkboxes-input-' + index).val();
		                    }
		                });
		                });		                
		                this.model.setChangedValue({
		                sourceOfIncomeCollecModel: sourceIncomeCollection, doesClientHaveAssets: doesClientHaveAssetsVal, assetTypesHeldCollecModel: assetTypesHeldCollection, doesClientHaveInvestmentModel: doesClientHaveInvestment, incomeInvestmentCollectionModel: investExpCollection
		            });
                if (this.model.getChangedItems().length > 0) {
						$('.gpm-step.step1').addClass("finished").removeClass("active");
						$('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
		            } else {
		            		Utils.showNoChangesMessageToUser();
    		}
    		}
			this.validateComponents();

		        },
		        	numValidator: function (obj) {
						var _regxNumOnly = /^\d*$/;
						var _str = String.fromCharCode(event.keyCode);
						var _maxlength = obj.currentTarget.maxLength;
						var _value = obj.currentTarget.value;
						if (!_regxNumOnly.test(_str)
								|| _value.length >= _maxlength) {
		                obj.stopPropagation();
		                if (event.preventDefault)
		                    event.preventDefault();
							return false;
    }
		        },
		        	loadPrimarySourceIncomeList: function (selIncome) {
	                var _incomeList = GPMData.primarySourceOfIncome;
	                var _selectbox = "#income-primary-source";
	                var _options = {
	                	selectBox: _selectbox,
	                	optionsList: _incomeList,
	                	selectedVal: selIncome,
	                	noEmptyOption: false,
	                	isOptional: false,
	                	/*noneOption:{
							value:"None",
							label:"None"
						}*/
		        	}
	                Utils.loadSelectbox(_options);
		        },
		        	loadFederaltaxBracketList: function (selFedTax) {
	                var _federalTaxList = GPMData.federalTaxBrackets;
	                var _selectbox = "#income-fed-tax";
	                var _options = {
	                	selectBox: _selectbox,
	                		optionsList: _federalTaxList,
	                	selectedVal: selFedTax,
	                	noEmptyOption: false,
		        	}
	                Utils.loadSelectbox(_options);
		        },

		        	initializeElementVars: function () {
						this.$assetTypeHeld = this.$('#asset-type-held');
		        },
		        	validateComponents: function () {
						var nestedViewId = '';
						var showErrFlag = false;
						var radioErrFlag = false;
						var hasErrorInAssetsInputBox = false;
						for (var key in this.nestedViews) {
						    if (key.indexOf("doesClientHaveAssetsViewName") > -1) {
						        if (this.nestedViews[key].selectedItem == null) {
						            nestedViewId = this.nestedViews[key].el.id;
						            showErrFlag = true;
						        } else {
						            showErrFlag = false;
						        }
						    } else if (key.indexOf("sourceOfIncomeCheckViewName") > -1 || key.indexOf("investmentCheckboxView") > -1) {
						        if (this.nestedViews[key].allSelectedItems.length == 0) {
						            nestedViewId = this.nestedViews[key].el.id;
						            showErrFlag = true;
						        } else {
						            showErrFlag = false;
						        }

						        if (key.indexOf("investmentCheckboxView") > -1) {
						            var _that = this;
						            nestedViewId = this.nestedViews[key].el.id;
						            _.each(this.nestedViews[key].selectedIndexes, function (itemDesc, idx) {
						                for (i = 1; i <= 2; i++) {
						                    var radioBtnViewName = "testRadioBtnViewName" + itemDesc + i;
						                    if (_that.nestedViews[radioBtnViewName]) {
						                        var nestedRadioBtnId = _that.nestedViews[radioBtnViewName].el.id;
						                        var nestedRadioDiv = $("div [ampf-radio-buttons=" + nestedRadioBtnId + "]");
						                        if (_that.nestedViews[radioBtnViewName] && _that.nestedViews[radioBtnViewName].selectedItem == null) {
						                            _that.nestedViews[radioBtnViewName].showError(true);
						                            nestedRadioDiv.addClass('error');
						                            radioErrFlag = true;
						                        }
						                        else {
						                            _that.nestedViews[radioBtnViewName].showError(false);
						                            nestedRadioDiv.removeClass('error');
						                        }
						                    }
						                }
						            });
						        }
						    } else if (key.indexOf("assetTypeCheckboxViewName") > -1) {
						        var count = 0;

						        $('input.assetTypeHeldInput').each(function () {
						            if ($(this).val() == "") {
						                hasErrorInAssetsInputBox = true;
						                count++;
						                return false;
						            }
						        });

						        if (this.nestedViews[key].allSelectedItems.length == 0 || count > 0) {
						            nestedViewId = this.nestedViews[key].el.id;
						            showErrFlag = true;
						        } else {
						            showErrFlag = false;
						        }
						    }

						    if (showErrFlag) {
						        $("div [data-for=" + nestedViewId + "]").addClass('error');
						        $("div [data-for=" + nestedViewId + "] .ncst-adjust-left").removeClass('hidden');
						        this.nestedViews[key].showError(true);
						    }

						    if (hasErrorInAssetsInputBox) {
						        $("div [ampf-checkbox-buttons=" + nestedViewId + "] > label").text('');
						    } else {
						        hasErrorInAssetsInputBox = false;
						    }
						}
						showErrFlag = showErrFlag || radioErrFlag;
						return !(showErrFlag);
		        },
		        	
		        	renderDoesClientHaveAssetsRadioBtns: function (clientHaveAssetsRadioModelData) {
						var self = this, componentId = "does-client-have-assets-radiobuttons", radioButtonsView, assetsConstItems = Constants.sortedDoesClientHaveAssetsList;

		            radioButtonsView = new RadioButtonView({
                el: self.$('#' + componentId),
		            		items: assetsConstItems
		        	});

		            if (clientHaveAssetsRadioModelData != "") {
		                _.find(assetsConstItems, function (assetsConstList) {
		                    if (assetsConstList.code == clientHaveAssetsRadioModelData) {
		                        radioButtonsView.selectedItem = assetsConstList;
		                }
});
		        	}

		            radioButtonsView.itemSelectionComplete = function (selectedItem, index) {
		                self.captureDoesClientHasAssetsRadio(selectedItem, index);
		        	};

		            this.addNestedView(this.doesClientHaveAssetsViewName, radioButtonsView);
		            radioButtonsView.render();
		        },
		        	captureDoesClientHasAssetsRadio: function (selectedItem, index) {
						doesClientHaveAssetsVal.desc = selectedItem.description;
						doesClientHaveAssetsVal.id = selectedItem.code;
		            //assetTypeHeldCollection =[];
		            if (selectedItem.code == 'A') {
		            	//this.$assetTypeHeld.removeClass('error hidden');
		                this.$('#asset-type-held').removeClass('error hidden');
		                this.renderAssetTypeHeldChkBoxes(assetTypesHeldCollection);
		            } else {
		            	//this.$assetTypeHeld.addClass('hidden');
		                this.$('#asset-type-held').addClass('hidden');
		                assetTypesHeldCollection.length = 0;
    }
		        },
		        	renderAssetTypeHeldChkBoxes: function (assetTypeHeldModelData) {
						var self = this, assetTypeCheckboxView, componentId = "asset-type-held-chkboxes", assetTypeConstItems = Constants.sortedAssetTypeHeldList;
						assetTypeCheckboxView = new CheckBoxView({
                el: $('#' + componentId),
								items: assetTypeConstItems,
							sideCompIndex: 1
		        	});
		            if (assetTypeHeldModelData != "" && assetTypeHeldModelData.length > 0) {
                var selectedList = [];
		                _.each(assetTypeHeldModelData, function (assetTypeList) {
		                    _.find(assetTypeConstItems, function (assetTypeConstList) {
		                        if (assetTypeConstList.code == assetTypeList.code) {
		                            selectedList.push(assetTypeConstList);
		                    }
		                });
		        	});
		                assetTypeCheckboxView.selectedItems = selectedList;
		        	}
		            assetTypeCheckboxView.itemSelectionComplete = function (selectedItem, itemId) {
		                self.captureAssetTypeHeldSelection(selectedItem, componentId, itemId, true);
		        	};
		            this.addNestedView(this.assetTypeCheckboxViewName, assetTypeCheckboxView);
		            assetTypeCheckboxView.render();

		            if (assetTypeHeldModelData != null || assetTypeHeldModelData.length > 0) {
		                _.each(assetTypeHeldModelData, function (list) {
                    self.captureAssetTypeHeldSelection([list], componentId, (list.displayOrder - 1), false);
});
    }
		        },
		        	captureAssetTypeHeldSelection: function (selectedItem, componentId, itemId, dataFromModelFlag) {
            var activeComp = $('#' + itemId + '-' + componentId),
							activeParent = activeComp.parents().eq(1),
							checkFlag = activeComp.is(":checked"),
                sideComp = componentId + '-sidecontainer-' + itemId;
            var id = componentId + '-input-' + itemId;

		            if (checkFlag || dataFromModelFlag == false) {
		                this.renderAssetTypeHeldInputBox(itemId, componentId);
		                this.addCSSClasses(activeComp, activeParent);
		                if (dataFromModelFlag) {
		                    this.appendSelectedAssetType(selectedItem, componentId, itemId, dataFromModelFlag);
		                } else {
                    $('input#' + id).val(selectedItem[0].assetVal.enteredValue);
}
} else {
		                _.filter(assetTypesHeldCollection, function (list, key) {
                    if (list.code == (itemId + 1)) {
		                        assetTypesHeldCollection.splice(key, 1);
		                }
});
		                this.removeCSSClasses(activeComp, activeParent);
                $("#" + componentId + "-sidecontainer-" + itemId + "1").empty();
    }
		        },
		        	renderAssetTypeHeldInputBox: function (index, componentId) {
						var radioButtonsView, self = this;
            var inputBoxViewId = self.$('#' + componentId + '-sidecontainer-' + index + '1');
            var txtornumber = Utils.isMobile() ? 'tel' : 'text';
            var inputBoxViewHTML = '<label class="error hidden margin-left-16">Incomplete required field.</label><div><label class="field-label float-left dollar-margin pt-h4 pt-pad-lt-zero">$</label><input type="' + txtornumber + '" id="' + componentId + '-input-' + index + '" maxlength="19" data-max-maxlength="19" data-min-maxlength="15" class="form-control comma-number width-195px maxlength pt-h5 needed required assetTypeHeldInput" value=""><span class="help-block inc-help-field pt-h7 clear-none">Whole numbers only.</span></div>';
            $('#' + componentId + '-sidecontainer-' + index + '1').html(inputBoxViewHTML);
		        },
		        	appendSelectedAssetType: function (selectedItem, componentId, index, dataFromModelFlag) {
		        	    var items = [{
		        	        "code": "",
		        	        "displayOrder": "",
		        	        "description": "",
		        	        "mapCode": "",
		        	        "servName": "",
		        	        "assetVal": {
		        	            "defaultValue": "",
		        	            "enteredValue": ""
		        	        }
		        	    }];

            items[0].code = selectedItem[(selectedItem.length - 1)].code;
            items[0].description = selectedItem[(selectedItem.length - 1)].description;
            items[0].displayOrder = selectedItem[(selectedItem.length - 1)].displayOrder;
            items[0].mapCode = selectedItem[(selectedItem.length - 1)].mapCode;
            items[0].servName = selectedItem[(selectedItem.length - 1)].servName;

		            if (assetTypesHeldCollection.length > 0) {
		                items[0].assetVal.enteredValue = assetTypesHeldCollection[0].assetVal.enteredValue;
		        	}

		            assetTypesHeldCollection.push(items);
		            assetTypesHeldCollection = _.flatten(assetTypesHeldCollection);
		        },
		        	addCSSClasses: function (activeComp, activeParent) {
						activeParent.find('div.radio-group-conatiner').addClass('no-ui-bg');
						activeComp.parent().addClass('custom-radio-labelUI');
						activeParent.addClass('custom-chkbox-width');
						activeParent.find('div.sideComp-container').addClass('sideComp-divUI');
		        },
		        	removeCSSClasses: function (activeComp, activeParent) {
						activeComp.parent().removeClass("custom-radio-labelUI");
						activeParent.removeClass('custom-chkbox-width');
						activeParent.find('div.sideComp-container').removeClass('sideComp-divUI');
		        },
		        	formatCurrencyToNormal: function (evt) {
                	var _$el = $(evt.currentTarget);
                	var _elVal = _$el.val();
                	_$el.val(_elVal.toString().replace(/,/g, ''));
                	_$el.attr('maxlength', _$el.attr('data-min-maxlength'));

    },
                	formatCurrency: function (evt) {
                	var _$el = $(evt.currentTarget);
                	var _elVal = _$el.val();
                	_$el.val(_elVal.formatCurrency());
                	_$el.attr('maxlength', _$el.attr('data-max-maxlength'));
                		//formatCurrency()
    },


		    });
		    return suitabilityView;
		});