/**
 * @ngdoc property
 * @name Destination Fund Directive
 * @requires smartSolnFundDetailsModel
 * @requires $uibModal
 * @requires selectFundModel
 * @description
 *
 * - Destination Fund directive represents the existing funds of investor along with a chance to create a new fund. 
 *
 **/
 'use strict';

 var kycMode = function(transactEventConstants) {
 	return {
 		template: require('./kycMode.html'),
 		restrict: 'E',
 		scope:{
 			parentForm:"=",
 			groupName:"="
 		},
 		controller: function($scope, $element, $attrs){  
 			$scope.groupName==undefined || null?$scope.type = "type":$scope.type = $scope.groupName.type;
 			$scope.modesOfEkyc = [{
 				label : "Instant KYC through AADHAR",
 				value : $scope.type +"aadharNo",
 				nameLbl : $scope.type,
 				check: true,
 				model:"",
 				checkedVal:'aadharNo'
 			},{
 				label : "Physical KYC",
 				value : $scope.type +"Physical",
 				nameLbl : $scope.type,
 				check: true,
 				model:"",
 				checkedVal:'Physical'
 			}];



 			$scope.listenChange = function(val,chcekedval,index){
 				if (chcekedval == 'aadharNo') {
 					$scope.instantKyc = true;
 				} 
 				else{
 					$scope.instantKyc = false;
 				}
 				angular.forEach($scope.modesOfEkyc, function(obj, key){
 					$scope.modesOfEkyc[key].model = val;
 				});
 			}
 			$scope.aadharNo = {
 				key : "Aadhar No",
 				text : "Aadhar No",
 				name : $scope.type + "aadhar",
 				isRequired : true,
 				type: "number",
 				maxlength:12,
 				minlength:12,
 				value:""
 			}
 			$scope.mobileNo = {
 				key : "Mobile",
 				text : "Mobile",
 				name : $scope.type + "mobile",
 				type: "number",
 				isRequired : true,
 				maxlength:10,
 				minlength:10,
 				value:""
 			}
 			$scope.email = {
 				key : "Email",
 				text : "Email",
 				name : $scope.type + "mail",
 				type : "email",
 				pattern : /^[a-z0-9._]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/,
 				isRequired : true,
 				value:""
 				
 			}		

 			
 			$scope.parentForm.kycVal=[];
			// to capture instant kyc aadhar OTP values
 			$scope.$on(transactEventConstants.transact.INSTANT_KYC, function(event){
 				$scope.parentForm.kycVal.push({
					'name':$scope.groupName==undefined || null?"":$scope.groupName.name,
					'pan':$scope.groupName==undefined || null?"":$scope.groupName.pan,
					'aadhar': $scope.aadharNo.value,
					'mobile':$scope.mobileNo.value,
					'email':$scope.email.value,
					'type':$scope.type,
					'Title':$scope.groupName==undefined || null?"":($scope.type=='Secondholder'?"Second Holder Details" :"Third holder Details" && $scope.type =='Firstholder'?"First Holder Details" :"Third holder Details") 
				});		
 			});



 		}
 	};

 };

 kycMode.$inject = ['transactEventConstants'];
 module.exports = kycMode;