var getMessageModel = require('../modules/getMessage/getMessage.model');
var engagementModel = require('../modules/engagement/engagement.model');
var dataPassModel = require('../modules/dataPass/dataPass.model');
var assistedModel = require('../modules/assisted/assisted.model');
var https = require('https');
var http = require('http');
var logger = require('../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var querystring = require('querystring');
var myCache = require('../../api-server');
var proxy = require('../../config/proxy');
var request = require('request');

var apiUtils = {
    dataPass: function(req, res, dataPassCallback) {
        //  logger.access.info(req.body);
        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": req.session.agentID
        };
        req.uri = dataPassModel.createRequestUri;
        post_data.VATranscript = myCache.get(req.session.engagementID+'.VATranscript');
        if(!req.session.isSales){
            post_data.Datapass =  myCache.get(req.session.engagementID+'.Datapass');
        }
        var postBody = querystring.stringify(post_data);
        //  logger.access.info(postBody);
        //console.log(postBody);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.session.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatOutBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
            if (proxyResponse.statusCode === 200) {
                dataPassCallback(res);
                //res.status(200).end();
            } else {
               var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });

        proxyRequest.write(postBody);
        proxyRequest.end();
    },
    getMsg: function(req, res, callBack) {
        req.uri = getMessageModel.createRequestUri;
        var reqObj = {
            method: 'GET',
            url: 'https://'+req.uri.host + req.uri.path + req.session.engagementID,
            agentOptions: {
                ciphers: 'DES-CBC3-SHA'
            },
            agent: proxy.agent,
            ca:proxy.ca,
            timeout: 35*1000,
            headers: {
                'Cookie': req.session.sessionCookie,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        request(reqObj,function(error, response, body){
            if(error){
                logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
                callBack(JSON.parse('{}'));
            }else if(response.statusCode !== 204 && response.statusCode !== 200){
                 logger.error.error(logger.formatResMsg(reqObj, reqObj, req.session.id));
                 logger.error.error(logger.formatResMsg(reqObj, errObj, req.session.id));
                  callBack(JSON.parse('{}'));
            }else if (myCache.get(req.session.engagementID+".mqtt")===true && response.statusCode === 204) {
               if(myCache.get(req.session.engagementID+".chatTimer")){
                   var lastMsg = myCache.get(req.session.engagementID+".chatTimer");
                   console.log("Timeout time: "+ (new Date().getTime()-lastMsg));
                   if((new Date().getTime()-lastMsg)>5*1000*60){
                       myCache.set(req.session.engagementID+".timeout", 'true');
                   }
               }
               logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.emptyResponse));
               //logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));               
               callBack(JSON.parse('{}'));
            }else {
                logger.general.info(logger.formatInfoMsg(req.session.id, "getMessage response with engagementID ("+
                                req.session.engagementID+")from TC "+ JSON.stringify(body)));
                callBack(body);
            }
        });
    },
    generateToken: function(req, res, callBackToken) {
        var postBody = { "deviceId": req.session.MDN};
        var reqObj = {
           // host: 'sclmdm03wsi.sdc.vzwcorp.com',
            host: config.UDM_SERVER_NAME,
            //port: '6001',
            port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/saveToken',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatInfoMsg(req.session.id, "generateToken Call Trigerred"));
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    //  logger.access.info(chunk);
                    callBackToken(chunk);
                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    sendCmd: function(req, res, callBackSendCmd) {
        //req.session.udm.isConnected = req.session.udm.isConnected;
        //console.log('UDM::',req.session.udm)

        var postBody = {
            "castType": "multicast",
            "cmd": "DROP_MSG",
            "requestor": "chatServer",
            "deviceList": [{
                "deviceId": req.session.MDN
            }],
            "sessionId": req.session.engagementID,
            "data": req.session.getMsgRes
        };
        var reqObj = {
            //host: 'sclmdm03wsi.sdc.vzwcorp.com',
            host: config.UDM_SERVER_NAME,
            //port: '6001',
            port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/sendCommand',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, req.session.getMsgRes, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            //console.log("sendCmd:", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    //console.log(req.session.getMsgRes);
                    //console.log("send commnad chunk", chunk);

                    res.status(200).end();
                    if(req.session.chatClosed){
                        //console.log("End msg", req.session.getMsgRes.ModuleMap.Support.msgList[0].messageList[0].messageText);
                        req.session.destroy(function(){
                            //console.log('SESSION DESTROYED!!!!!');
                        });
                    }

                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    assisted: function(req, res) {
        //  logger.access.info(req.body);
        var post_data = {
            "tcCustomerID": req.session.customerID,
            "engagementID": req.session.engagementID,
            "businessRuleID": req.session.businessRuleID,
            "siteID": config.TC_SITE_ID,
            "viewID": "36219496"
        };

        //var postBody = querystring.stringify(post_data);
        //  logger.access.info(postBody);
        //console.log(postBody);
        var reqObj = {
            host: config.TC_SERVER_NAME,
            method: 'POST',
            path: config.TC_ASSISTED_URI,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/json',
                'Cookie': req.session.sessionCookie,
                //'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatOutBoundResMsg(reqObj, {statusCode: proxyResponse.statusCode}, req.session.id));
            if (proxyResponse.statusCode === 200) {
                //assistedCallback(res);
                res.status(200).end();
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });

        proxyRequest.write(JSON.stringify(post_data));;
        proxyRequest.end();
    },
    saveMDN: function(req, res, callBack) {
        //  logger.access.info(req.body);
        var postBody = {
            "customerId": req.session.customerID,
            "mdn": req.session.MDN
        };
        var reqObj = {
            host: config.NLP_SERVER_URL,
            port: config.NLP_SERVER_PORT,
            method: 'POST',
            path: config.NLP_MDN_SAVE_URI,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var data = {};
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');

            if (proxyResponse.statusCode !== 200) {
                 var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);

            }

            proxyResponse.on('data', function(chunk) {
               // logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                data = chunk;
            });
            proxyResponse.on('end', function() {
               logger.general.info(logger.formatOutBoundResMsg(reqObj, data, req.session.id));
               callBack(data);
            });

            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    conversion: function(req, res, callBack) {
        //  logger.access.info(req.body);
        var postBody = {
            "mdn": req.session.MDN
        };
        var reqObj = {
            host: config.NLP_SERVER_URL,
            port: config.NLP_SERVER_PORT,
            method: 'POST',
            path: config.NLP_MDN_SAVE_URI,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var data = {};
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');

            if (proxyResponse.statusCode !== 200) {
                 var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);

            }

            proxyResponse.on('data', function(chunk) {
               // logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                data = chunk;
            });
            proxyResponse.on('end', function() {
               logger.general.info(logger.formatOutBoundResMsg(reqObj, data, req.session.id));
               callBack(data);
            });

            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    surveyEligibility: function(req, res, callBack) {
        //  logger.access.info(req.body);
        var postBody = {
            "mdn": req.session.MDN
        };
        var reqObj = {
            host: config.NLP_SERVER_URL,
            port: config.NLP_SERVER_PORT,
            method: 'POST',
            path: config.NLP_SURVEY_ELIGIBILITY_URI,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');

            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {

                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    callBack(chunk);
                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    formatOrderNum:function(orderString) {
        var s = "";
        if(orderString){
            s = orderString.substring(orderString.indexOf("#")+2);
            s = s.substring(0,s.indexOf(" "));
        }
        return s;
    },
    getProducts: function(req){
        var products = [];
        if(req.body.RequestParams.monthly && req.body.RequestParams.monthly.Devices){
            for(i=0;i<req.body.RequestParams.monthly.Devices.length;i++){
                var device = req.body.RequestParams.monthly.Devices[i];
                for(j=0;j<req.body.RequestParams.monthly.Devices[i].lineItems.length;j++){
                    var item = req.body.RequestParams.monthly.Devices[i].lineItems[j];
                    var obj = {};
                    obj.count = 1;
                    obj.product = device.deviceTitle==null?"":device.deviceTitle+ " - "+ item.title;
                    obj.price = item.amount;
                    products.push(obj);
                }

            }
        }

        if(req.body.RequestParams.monthly && req.body.RequestParams.dueToday.Devices){
            for(i=0;i<req.body.RequestParams.dueToday.Devices.length;i++){
                var device = req.body.RequestParams.dueToday.Devices[i];
                for(j=0;j<req.body.RequestParams.dueToday.Devices[i].lineItems.length;j++){
                    var item = req.body.RequestParams.dueToday.Devices[i].lineItems[j];
                    var obj = {};
                    obj.count = 1;
                    obj.product = device.deviceTitle==null?"":device.deviceTitle+ " - "+ item.title;
                    obj.price = item.amount;
                    products.push(obj);
                }
            }
        }
        return products;
    },
    getVATranscript:function(VATranscript){
        var transcript = "<br><div>";
        for(i=0;i<VATranscript.length;i++){
            transcript +="<p><b>" + VATranscript[i].type + ":</b>" + VATranscript[i].message +"</p>";
        }
        transcript += "</div>";
        return transcript;
    },
    getUserInfo:function(req){
        var validated = '';
        var postData = '';
        var result = "<div><br><p><b> - Role: </b>"+ req.body.RequestParams.accRole;
        var accRole = req.body.RequestParams.accRole.replace(' ','');

        if(accRole.trim().toUpperCase()==='ACCOUNTMANAGER'||
            accRole.trim().toUpperCase()==='ACCOUNTHOLDER'||
            accRole.trim().toUpperCase()==='ACCOUNTOWNER'){
            validated = 'Y';
        }else{
            validated = 'N';
        }
        postData = "viewName=customerSearchNewView&noheader=true&validated=" + validated + "&Originsystem=TC&mdnSearched="
                     + req.body.RequestParams.MDN + "&fromScreen=TOOLBAR&hiddCustMdnSearch=mdn";
        result +=  "</p><p><b> - Mobile Number: </b>" + "<font color=\"#0000CC\"><u><a href=\"event:acss:"+ postData + "\">"+apiUtils.formatMDN(req.body.RequestParams.MDN) +"</a></u></font>" ;
        result += "</p><p><b> - Greeting Name: </b>" + req.body.RequestParams.nickName;
        if(validated === 'Y'){
            result += "</p><p><b> - Security: </b><font color=\"#008000\">Validated</font></p>";
        }else{
            result += "</p><p><b> - Security: </b><font color=\"#ff0000\">Not Validated</font></p>";
        }
        if(req.body.RequestParams.agentGroupID.indexOf('_EMP')!=-1){
             result += "</p><p><b> - ECPD ID: </b>" + req.body.RequestParams.ecpdId + "</p></div>" ;
        }else{
             result += "</p></div>";
        }

        return result;

    },
    formatMDN:function(mdn){
        return "(" + mdn.substring( 0,3 ) + ") " + mdn.substring( 3,6 ) + "-" + mdn.substring( 6,10 );
    },
    handleGetMessageRes: function(req, res, chunk){
         try{
            chunk = JSON.parse(chunk);
         }catch(e){
            logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json"));
            req.session.getMsgRes = getMessageModel.emptyResponse;            
            return false;
         }
        chunk.messages = chunk.messages || [{}];
        if(chunk.messages[0] && chunk.messages[0].state){
            if(chunk.messages[0].state === 'assigned'){
                req.session.agentID = engagementModel.response.Page.agentID = chunk.messages[0]['agentID'];
                myCache.set(req.session.engagementID+".agentID", chunk.messages[0]['agentID']);
                req.session.agentName = getMessageModel.response.Page.agentName = chunk.messages[0]['agent.alias'];
                engagementModel.response.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                engagementModel.response.Page.customerID = req.session.customerID ; /// storing customerID into the session
                engagementModel.ResponseInfo.topMessage = "You're chatting with "+ chunk.messages[0]['agent.alias'];
                engagementModel.ResponseInfo.type = "Success";
                engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                engagementModel.msgList[0].messageList[0].messageText =  chunk.messages[0]['agent.alias'] + " joined the conversation";
                engagementModel.response.ModuleMap.Support.startMsgId = 10000;
                engagementModel.response.ModuleMap.Support.msgList = engagementModel.msgList;
                engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                req.session.getMsgRes = engagementModel.response;
                apiUtils.sendCmd(req, res, function(response) {});
                apiUtils.dataPass(req, res,function(response) {});
                logger.general.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                logger.conversation.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                return false;
            }else if (chunk.messages[0].state === 'closed'){
                myCache.set(req.session.engagementID+".mqtt", false);
                if (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
                    apiUtils.surveyEligibility(req, res, function(response) {
                        if(response.eligible === true){
                            var surveyUrl = getMessageModel.createSurveyUri(req.session);
                            var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                            getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                            getMessageModel.surveyResponse.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                            getMessageModel.surveyResponse.Page.customerID = req.session.customerID ; /// storing customerID into the session
                            getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                            getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                            req.session.getMsgRes = getMessageModel.surveyResponse;
                            apiUtils.sendCmd(req, res, function(response) {});
                            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.surveyResponse));
                            logger.conversation.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                        }else{
                            req.session.getMsgRes = getMessageModel.endResponse;
                            apiUtils.sendCmd(req, res, function(response) {});
                            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                            logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                            logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                        }
                        apiUtils.cleanMFCCache(req.session.engagementID);
                    });
                }else{
                       req.session.getMsgRes = getMessageModel.endResponse;
                       apiUtils.sendCmd(req, res, function(response) {});
                       logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                       logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID " +req.session.engagementID));
                       logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID "+req.session.engagementID));
                       apiUtils.cleanMFCCache(req.session.engagementID);
                }
                res.end();
                return true;
            }else if(chunk.messages[0].state === 'agentIsTyping'){
                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = 50000;
                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = 50000;
                getMessageModel.response.ModuleMap.Support.msgList[0].msgId = 50000;
                getMessageModel.response.ModuleMap.Support.startMsgId = 50000;
                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                req.session.getMsgRes = getMessageModel.response;
                apiUtils.sendCmd(req, res, function(response) {});
                return false;
            }else{
                console.log('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%1');
                return false;
            }
        }else if(chunk.messages[0] && chunk.messages[0].messageType === 'chatLine' && parseInt(chunk.messages[0].sequenceNumber,10) >=3 ){
            var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
            myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1);
            myCache.set(req.session.engagementID+".chatTimer", new Date().getTime());
            if (chunk.messages[0].messageText.toLowerCase() === 'login needed') {
                getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;
                req.session.getMsgRes = getMessageModel.loginNeededResponse;
            }else{
                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                getMessageModel.response.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                getMessageModel.response.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                req.session.getMsgRes = getMessageModel.response;
            }
           if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                 parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 &&
                 parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
                   myCache.set(req.session.engagementID+".isAssisted", true);
                    apiUtils.assisted(req,res,function(response) {});
                    apiUtils.saveMDN(req,res,function(response) {});
            }
            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.response));
            logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Get Message: ' + chunk.messages[0].messageText);
            apiUtils.sendCmd(req, res, function(response) {});
            return false;
        }else{
            console.log('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2');
            return false;
        }
    },
    cleanMFCCache(engagementID){
        myCache.del(engagementID+".chatGetMsgCounter");
        myCache.del(engagementID+".chatSendMsgCounter");
        myCache.del(engagementID+".isAssisted");
        myCache.del(engagementID+".closed");
        myCache.del(engagementID+".isRecurEnabled");
        myCache.del(engagementID+".Datapass");
        myCache.del(engagementID+".VATranscript");
        myCache.del(engagementID+".agentID");
        myCache.del(engagementID+".chatTimer");
        myCache.del(engagementID+".timeout");
        myCache.del(engagementID+".mqtt");
    },
        formattedGetMsg: function(req, res, getMsgCallback, isSendCallback) {
        //logger.access.info(req.body);
        req.uri = getMessageModel.createRequestUri;
        //console.log("Get Message API is trigerred", req.session);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + req.session.engagementID,
                headers: {
                    'Cookie': req.session.sessionCookie,
                }
            },
            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                console.log(proxyResponse.statusCode);
                console.log('res.statusCode' + res.statusCode);
                if (res.statusCode === 200) {
                    if (proxyResponse.statusCode === 200 || proxyResponse.statusCode === 204) {
                        // console.log("after the proxyResponse");
                        proxyResponse.on('data', function(chunk) {
                            chunk = JSON.parse(chunk);
                            console.log("Get Message API Response:", chunk.messages[0].messageText);
                            //logger.conversation.info(' Engagement ID: ' + req.body.RequestParams.engagementID + ' Get Message: ' + chunk.messages[0].messageText);
                            getMessageModel.response.Page.engagementID = req.session.engagementID;
                            //getMessageModel.response.Page.status = engagementModel.response.Page.status;
                            if (chunk.messages[0] && chunk.messages[0].state) {
                                // console.log("if state exist:", chunk);
                                getMessageModel.response.Page.agentID = (chunk.messages[0]['user.id'] || req.session.agentID);
                                getMessageModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['display.text'];
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                            } else if (chunk.messages[0]) {
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                            }
                            req.session.chatGetMsgCounter = (req.session.chatGetMsgCounter || 0 );
                            //console.log(getMessageModel.response.ModuleMap.Support.msgList[0].messageType);
                            var counter = getMessageModel.response.ModuleMap.Support.msgList[0].messageType === 'chatLine' ? req.session.chatGetMsgCounter++ : req.session.chatGetMsgCounter;
                            //console.log(apiUtils.customerInfo.chatGetMsgCounter);
                            //console.log(apiUtils.customerInfo.chatSendMsgCounter);
                            if (chunk.messages[0].messageText === 'login needed') {
                                getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                                getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                                getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;
                                //logger.access.info(getMessageModel.loginNeededResponse);
                                getMsgCallback(getMessageModel.loginNeededResponse);
                            } else if (chunk.messages[0] && chunk.messages[0].state === "closed") {
                                //  console.log("The chat state is now:", chunk.messages[0].state);

                                /*Calculating the time difference between the last end chat Date&time and the current date&Time*/
                                var timeDiff = apiUtils.checkSurveyStatus(apiUtils.customerInfo.pastChatEndTime, new Date());

                                /*Fixing the conditions of 2/2  for the Get/Send messages to initiate the Survey API */
                                var checkSurveyEligible = (req.session.chatGetMsgCounter >= 2 && req.session.chatGetMsgCounter >= 2);
                                console.log("req.session.chatGetMsgCounter", req.session.chatGetMsgCounter);
                                console.log("req.session.chatGetMsgCounter ", req.session.chatGetMsgCounter);
                                /*Checking the time and 2/2 condition*/
                                //if (checkSurveyEligible && (apiUtils.customerInfo.pastChatEndTime || (timeDiff > 86400000))) {
                                if (checkSurveyEligible) {
                                    //  console.log('Send survey url');
                                    var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                    //var surveyUrlEncoded = encodeURI(surveyUrl);
                                    //  console.log('surveyURL:', surveyUrl);
                                    var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                    //    console.log('surveyMsg:', surveyMsg);

                                    getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                    //    console.log('page.surveyUrl:', surveyUrl);
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                    //    console.log('FeedLink.browserUrl:', surveyUrl);
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                    //    console.log('messageList[0].messageText:', surveyMsg);

                                    apiUtils.customerInfo.pastChatEndTime = new Date();

                                    /*Sending the Thank you and Survey in the Response on End Chat*/
                                  //  logger.access.info(getMessageModel.surveyResponse);
                                    getMsgCallback(getMessageModel.surveyResponse);
                                    req.session.getMsgRes = getMessageModel.surveyResponse;
                                    console.log('req.session.mqtt' + req.session.mqtt);
                                    req.session.destroy();
                                    //console.log("the repsosne not on survey end:", getMessageModel.surveyResponse);
                                } else {
                                    console.log("this is hte point where end msg sent");
                                    /* Sending the Thank You response on End Chat*/
                                //    logger.access.info(getMessageModel.endResponse);
                                    getMsgCallback(getMessageModel.endResponse);
                                    req.session.getMsgRes = getMessageModel.endResponse;
                                    console.log('req.session.mqtt' + req.session.mqtt);
                                    req.session.destroy();
                                    //console.log("the repsosne not on non-servey end:", getMessageModel.endResponse);
                                }
                            } else {
                                /*Sending the message sent form the TC to the Client*/
                              //  logger.access.info(getMessageModel.response);
                                getMsgCallback(getMessageModel.response);
                            }

                        });
                        if(req.session.mqtt && proxyResponse.statusCode === 204){
                          getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = '';
                          //logger.access.info(getMessageModel.response);
                          getMsgCallback(getMessageModel.response);
                        }
                        /*if (req.session.mqtt && proxyResponse.statusCode === 200) {
                            req.session.getMsgRes = getMessageModel.response;

                            console.log('req.session.mqtt' + req.session.mqtt);
                            apiUtils.sendCmd(req, res, function(response) {
                                console.log("Send Command CAll");
                                apiUtils.formattedGetMsg(req, res, function() {
                                    res.status(200).end();
                                });
                            });
                        } else {
                            apiUtils.formattedGetMsg(req, res, function() {
                                res.status(200).end();
                            }, false);
                        }*/
                    } else {
                      // //logger.error.error({
                      //     message: 'ERROR!!! Something went wrong while retrieving data.',
                      //     statusCode: res.statusCode
                      // });
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }
                } else {
                  // //  logger.error.error({
                  //       message: 'ERROR!!! Something went wrong while retrieving data.',
                  //       statusCode: res.statusCode
                  //   });
                    res.send({
                        message: 'ERROR!!! Something went wrong while retrieving data.',
                        statusCode: res.statusCode
                    });
                }
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                    //logger.error.error(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    }
};

module.exports = apiUtils;
