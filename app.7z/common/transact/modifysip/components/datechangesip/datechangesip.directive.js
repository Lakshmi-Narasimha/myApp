/**
 * @ngdoc property
 * @name fticDateChangeSip Directive
 * 
 * @description
 *
 * - This directive is responsible for acquiring the Flexi SIP details.
 *
 **/
'use strict';


var fticDateChangeSip = function (SipModifyDetailModel,eventConstants,$filter,transactModel,transactEventConstants,fundDetails,TransactConstant) {

    return {
        template: require('./datechangesip.html'),
        restrict: 'E',
        replace: true,
        scope: {
            sipType:"@"
        },
        controller:['$scope', function ($scope) {
            
            var susObj = transactModel.getFundDetails();
            var datefilter = $filter('date');
            var nextInsDate;
            var leadDays = susObj.leadDays;
            var nextInstlDate = datefilter(susObj.nextTriggerDate, 'dd MMM yyyy');
            var selctedDate = null;
            var condCheck = false;
            var currentDate = new Date();
            var eligibleDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()+parseInt(leadDays));
            var todayMonth = datefilter(currentDate, 'MMM yyyy');
            var dayFlag = "";
            $scope.dateChange = {};
            $scope.nextInstlElligibleDate = null;
            $scope.actvDays = [];

            if (currentDate.getMonth() == 11) {
                var nextMonth = datefilter(new Date(currentDate.getFullYear() + 1, 0, 1),'MMM yyyy');
            } else {
                var nextMonth = datefilter(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1),'MMM yyyy');
            }

            for(var dateVal=1;dateVal<=30; dateVal++){
                $scope.actvDays.push({"title": dateVal});   
            } 
            $scope.EnableConfirm = false;
            $scope.$on(eventConstants.CHECKBOX_CHECKED, function($event, checkboxObject){
                if (checkboxObject.value) {
                    $scope.EnableConfirm = true;
                } else {
                    $scope.EnableConfirm = false;
                }
            });
            
            $scope.$on("sipDateChange", function(event,selectedOption){
                if (parseInt(selectedOption.title) >= parseInt(currentDate.getDate())){
                    $scope.dateChange.newSipDate = selectedOption.title + " " + todayMonth;
                } else{
                    $scope.dateChange.newSipDate = selectedOption.title + " " + nextMonth;
                }
                selctedDate = new Date($scope.dateChange.newSipDate);
                var newDate= selctedDate;
                $scope.nextInstlElligibleDate = null;
                if (eligibleDate < selctedDate){
                    $scope.nextInstlElligibleDate = datefilter(selctedDate,'dd MMM yyyy');
                } else{
                    $scope.nextInstlElligibleDate = datefilter(new Date(newDate.setMonth(selctedDate.getMonth() + 1)),'dd MMM yyyy');
                }
                dayFlag = selectedOption.title;
            });
            $scope.config = {};
            $scope.config.showNotification = false;
            $scope.getSelections = function(){
                $scope.dateChange.sipModifyType = $scope.sipType;
                $scope.dateChange.txnSource = "SIPDTC";
                $scope.dateChange.sipOptionName = "SIP Date Change";
                $scope.dateChange.strtDate = $scope.nextInstlElligibleDate;
                $scope.dateChange.dayFlag = dayFlag;
                //$scope.dateChange.nextInstlElligibleDate = $scope.nextInstlElligibleDate;
                SipModifyDetailModel.setModifySipDetails($scope.dateChange);

                

                if(susObj.paymentMode === TransactConstant.common.EMANDATE_CODE || susObj.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                    var dateSplit = [];
                    dateSplit= susObj.achToDate.split("/");
                    var eMandateExpiryDate = new Date(dateSplit[2],dateSplit[1]-1,dateSplit[0]);
                    if(selctedDate > eMandateExpiryDate){
                        condCheck = true;
                    } else{
                        condCheck = false;
                    }
                }
                if(condCheck){
                    //$scope.payMethod && $scope.minSipAmnt && $scope.endDate
                    //payMethod is true for all except net banking
                    $scope.config.showNotification = true;
                }else{
                    $scope.$emit(transactEventConstants.transact.Set_Modify_Sip_Details);
                } 
            }
            $scope.$on('yes', function(event, data){
                $scope.config.showNotification = false;
                $scope.$emit(transactEventConstants.transact.Set_Key_Value_Object);  
                $scope.$emit(transactEventConstants.transact.Payment_Detail);

            }); 
            $scope.$on('no', function(event, data){
                 $scope.config.showNotification = false;
            });
        }]
    };
};


fticDateChangeSip.$inject = ['SipModifyDetailModel','eventConstants','$filter','transactModel','transactEventConstants','fundDetails','TransactConstant'];
module.exports = fticDateChangeSip;