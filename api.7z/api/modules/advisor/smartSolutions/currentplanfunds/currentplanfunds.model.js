// currentplanfunds.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var currentPlanFundsSchema = new mongoose.Schema({
    currentPlanDetails: {
        type: Array,
        "default": []
    }
});

var currentPlanFundsLookUp = mongoose.model('currentPlanFundsLookUp', currentPlanFundsSchema);

var currentPlanFundsModel = new currentPlanFundsLookUp({
    "currentPlanDetails":{
  "goalChart": {
    "data": [{
      "years": "2016",
      "amount": "418781.89"
    }, {
      "years": "2015",
      "amount": "359463.03"
    }, {
      "years": "2014",
      "amount": "268378.91"
    }, {
      "years": "2013",
      "amount": "114388.49"
    }, {
      "years": "2012",
      "amount": "53360.12"
    }],
    "goalAmount": "1214372.4"
  },
  "fsGoalDetails": [{
    "accountNumber": "0389904429621",
    "invamount": "117500.49",
    "mktvalue": "174132.91",
    "funddesc": "Franklin India BLUECHIP FUND",
    "returns": "14.35%",
    "sno": "1"
  }, {
    "accountNumber": "0369904429620",
    "invamount": "122499.57",
    "mktvalue": "244648.98",
    "funddesc": "Franklin India PRIMA FUND",
    "returns": "26.75%",
    "sno": "2"
  }, {
    "accountNumber": "0369904429620",
    "invamount": "122499.57",
    "mktvalue": "244648.98",
    "funddesc": "Franklin India PRIMA FUND",
    "returns": "26.75%",
    "sno": "1"
  }, {
    "accountNumber": "0389904429621",
    "invamount": "117500.49",
    "mktvalue": "174132.91",
    "funddesc": "Franklin India BLUECHIP FUND",
    "returns": "14.35%",
    "sno": "2"
  }]
}
});

currentPlanFundsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating currentPlanFundsLookUp table, please contact admin...');
    } else {
        currentPlanFundsLookUp.remove({}, function(err) {
            console.log('currentPlanFundsLookUp collection removed');
            currentPlanFundsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating currentPlanFundsLookUp table, please contact admin...');
                }
                console.log('currentPlanFundsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = currentPlanFundsLookUp;
