'use strict';

var recommendedPlan= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _recommendedPlanResp = null,
        _selectedSmartSoln = null,
        _planInputDetails = null,
        _customizePlanData = null,
        _goalDataResp = null,
        _panLevelSummaryFS = null,
        _panLevelSummaryNFS = null,
        _recomPlanFromState = null;

    var recommendedPlanModel = {
        fetchRecommendedPlan : function () {
            var deferred = $q.defer();
            Restangular.one('getRecommendedPlan').get().then(function (recommendedPlanResp) {
               // console.log(recommendedPlanResp);
                deferred.resolve(recommendedPlanResp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getPanLevelSummary : function (params) {
            var deferred = $q.defer();
            Restangular.one('smartsolution/panLevelSummary').get(params).then(function (panLevelSummary) {
                deferred.resolve(panLevelSummary);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;  
        },
        getPlanInputDtls : function () {
                 return _planInputDetails;
        },
        setPlanInputDtls : function (planInputDtls) {
            _planInputDetails = planInputDtls;
        },
        getRecommendedPlanDtls : function () {
                 return _recommendedPlanResp;
        } ,
        setRecommendedPlanDtls : function (recommendedPlanResp) {
            _recommendedPlanResp = recommendedPlanResp;
            console.log("the details are",_recommendedPlanResp );
        },
        getSelectedSmartSoln : function () {
                 return _selectedSmartSoln;
        },
        setSelectedSmartSoln : function (selectedOption) {
            _selectedSmartSoln = selectedOption;
        },
        setCustomizePlanData : function(customizePlanData) {
            _customizePlanData = customizePlanData;
        },
        getCustomizePlanData : function () {
                 return _customizePlanData;
        },
        setGoalPlanData : function (goalPlanResp) {
            _goalDataResp = goalPlanResp;
        },
         getGoalPlanData : function () {
                 return _goalDataResp;
        },
        setpanLevelSummaryFS : function (data) {
            _panLevelSummaryFS = data;
        },
        getpanLevelSummaryFS : function () {
                 return _panLevelSummaryFS;
        },
        setpanLevelSummaryNFS : function (data) {
            _panLevelSummaryNFS = data;
        },
        getpanLevelSummaryNFS : function () {
                 return _panLevelSummaryNFS;
        },
        setRecommendedFromState : function(fromState){
            _recomPlanFromState = fromState;
        },
        getRecommendedFromState : function(){
           return _recomPlanFromState;
        }

    };
    return recommendedPlanModel;

};

recommendedPlan.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = recommendedPlan;
