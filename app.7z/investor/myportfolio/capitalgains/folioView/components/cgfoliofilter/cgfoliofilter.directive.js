/**
 * @ngdoc property
 * @name fticCapitalGainFolioFilter Directive
 * @requires investorEventConstants 
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Capital Gains Account Statement details for selected Folio Number
 *
 **/
'use strict';

var fticCapitalGainFolioFilter = function($state, $timeout,investorEventConstants,cgAccDetModel,fticgAccDetLoadInitialService,investorConstants,invInstantMailback, downloadService) {
    return {
        template: require('./cgfoliofilter.html'),
        restrict: 'E',
        replace: true,
        scope: {
            cgFolioData:'='
        },
        controller: function($scope) {
            var cgfolioFilter = {};
            $scope.sectionOptsFolio = [],
            $scope.selectedOption = null;
            $scope.$on(investorEventConstants.MyPortfolio.CG_FOLIO_NUMBER_LIST,function(){
                $scope.folioViewFolioNumberList = cgAccDetModel.getFolioNumbersList().length;
                _.each(cgAccDetModel.getFolioNumbersList(), function(element){
                    var folioObj = null;
                    folioObj = {
                        title : 'Folio No. ' + element.folioId,
                        folioNumber : element.folioId
                    };
                    if(element.latestFolio === 'Y'){
                        $scope.selectedOption = folioObj;
                        cgAccDetModel.setAccFolioNumber(element.folioId);
                    }
                    $scope.sectionOptsFolio.push(folioObj);
                });
                if(!fticgAccDetLoadInitialService._isInitialLoad && $scope.folioViewFolioNumberList){
                    fticgAccDetLoadInitialService._isInitialLoad = true;
                    cgfolioFilter.folioPanAccNo = $scope.selectedOption.folioNumber;
                    cgfolioFilter.dayFlag = 'CF';
                    fticgAccDetLoadInitialService.getCgFolioDetails($scope,cgfolioFilter);
                }
                $scope.dateOptions = [
                    {
                        id: 1,
                        label: investorConstants.myportfolio.CURRENT_FINANCIAL_YR,
                        type: 'definedate',
                        key: 'CF'
                    },
                    {
                        id: 2,
                        label: investorConstants.myportfolio.LAST_FINANCIAL_YR,
                        type: 'definedate',
                        key: 'LF'
                    }
                ];

            });
            $scope.hideSelect = true;
            $scope.$emit('cgfolioapply',cgfolioFilter);
            $scope.$on('selectedValue', function(event, data){
                if(data.key !== null) {
                    cgfolioFilter.dayFlag = data.key;
                }
            });
            $scope.$on('cgfolio', function(event, data){
                cgfolioFilter.folioPanAccNo = data.folioNumber;
            });
            $scope.emitcgApply = function(){
                $scope.cgFolioData = false;
                invInstantMailback.setMailBackData({
                    folioPanAcc: cgfolioFilter.folioPanAccNo,
                    fromDate: '',
                    toDate: '',
                    periodType: cgfolioFilter.dayFlag
                });
                downloadService.setQueryparams({
                    strInputData: cgfolioFilter.folioPanAccNo,
                    inputFlag: 'F',
                    periodType: cgfolioFilter.dayFlag,
                });
                cgAccDetModel.setAccFolioNumber(cgfolioFilter.folioPanAccNo);
                fticgAccDetLoadInitialService.getCgFolioDetails($scope,cgfolioFilter);
            };
        },
    };
};

fticCapitalGainFolioFilter.$inject = ['$state', '$timeout','investorEventConstants','cgAccDetModel','fticgAccDetLoadInitialService','investorConstants', 'invInstantMailback', 'downloadService'];
module.exports = fticCapitalGainFolioFilter;