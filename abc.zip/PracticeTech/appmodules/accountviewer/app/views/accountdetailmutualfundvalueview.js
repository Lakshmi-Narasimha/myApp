define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailmutualfundvalueview.html',
  'appcommon/commonutility',
  'moment'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml, Utils, moment) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
          var self = this;
          var servicePromises = [];
          servicePromises.push(dataService.promiseToGetMutualFundBalance(this.accountSummary.accountId));
          servicePromises.push(dataService.promiseToGetMutualFundSpecialDetails(this.accountSummary.accountId));
          Q.all(servicePromises)
            .then(function(responseValues){
              var balanceData = responseValues[0];
              var specialDetailsData = responseValues[1];

              var accountValues = {};
              var asOfMsSinceEpoch = balanceData.asOfTS;
              if (Utils.isEmpty(asOfMsSinceEpoch)) {
                accountValues.asOfDate = '';
              } else {
                var asOfDate = asOfMsSinceEpoch.getDateFromMS();
                accountValues.asOfDate = moment(asOfDate).format("MM/DD/YYYY");
              }
              var specialDetail = specialDetailsData.spclDetail;
              if (specialDetail) {
                accountValues.goodFundsAmount = specialDetail.goodFndsAmt ? specialDetail.goodFndsAmt.formatMoney() : '';
                accountValues.notGoodFundAmount = specialDetail.notGoodFndsAmt ? specialDetail.notGoodFndsAmt.formatMoney() : '';
                accountValues.availForRedemptionAmount = accountValues.goodFundsAmount;
                accountValues.availWithoutCDSCAmount = accountValues.freeAssetAmt;
                accountValues.collaterallyAssignedCode = specialDetail.colAsgndCd ? specialDetail.colAsgndCd : 'N/A';
              } else {
                accountValues.goodFundsAmount = '';
                accountValues.notGoodFundAmount = '';
                accountValues.availForRedemptionAmount = accountValues.goodFundsAmount;
                accountValues.availWithoutCDSCAmount = '';
                accountValues.collaterallyAssignedCode = '';
              }

              self.renderSection(SectionTemplateHtml, {accountValues: accountValues});
          })
          .fail(this.handleServiceError);
        }
    });

    return SectionView;
});