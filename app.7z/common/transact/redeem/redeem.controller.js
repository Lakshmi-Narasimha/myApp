/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function redeemController($scope) {
    console.info('redeem Controller!!' + $scope.header);
    $scope.investorDetails = [];
    $scope.config.txnFormDetails.title = 'Redemption Details';
    //$scope.fundDetails = [];
    $scope.header.title = 'Redeem';

    $scope.selectedInvestor = {};
    $scope.$on('selectInvestor', function(event, args) {
        console.log(args);
        $scope.selectedInvestor = args;
    });
}

redeemController.$inject = ['$scope'];
module.exports = redeemController;
