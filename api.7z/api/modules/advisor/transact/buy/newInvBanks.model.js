// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var NewInvBankModelSchema = new mongoose.Schema({
    NewInvBankResp: {
        type: Array,
        "default": []
    }
});

var NewInvBankModelLookUp = mongoose.model('NewInvBankModelLookUp', NewInvBankModelSchema);

var NewInvBankModel = new NewInvBankModelLookUp({
    NewInvBankResp : {
        'banks' : {
            "newEmandates": [
                {
                    "pbBankName": "HDFC BANK LTD",
                    "pbPersonalAccountNumber": "3574063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "HDFC BANK LTD",
                    "paymentType": "NE"
                },
                {
                    "pbBankName": "Axis Bank",
                    "pbPersonalAccountNumber": "4578063201671",
                    "pbAccountType": "SA",
                    "accTypeDesc": "HDFC BANK LTD",
                    "paymentType": "NE"
                }
            ],
            'payeeDetails': [
                {
                    'name' : 'Franklin Templeton Mutual Fund',
                    'bankName' : 'CITIBANK',
                    'ifscCode' : 'CITI0100000',
                    'branchName' : 'Fort, Mumbai',
                    'accountNumber' : '5050AHTPG6546Y',
                    'accountType' : 'Current'
                }
            ],
            'preRgstdBanks':[
            	{
            		"pbBankName": "HDFC BANK",
                    "netBanking" : "enabled",
                    "debit" : "disabled",
                    "newEmandates" : "enabled",
                    "neftRtgs" : "enabled",
                    "multiPayMode" : "enabled"
            	},
            	{
            		"pbBankName": "Axis Bank",
                    "netBanking" : "disabled",
                    "debit" : "enabled",
                    "newEmandates" : "enabled",
                    "neftRtgs" : "disabled",
                    "multiPayMode" : "disabled"
            	},
            	{
            		"pbBankName": "SBI Bank",
                    "netBanking" : "enabled",
                    "debit" : "disabled",
                    "newEmandates" : "disabled",
                    "neftRtgs" : "disabled",
                    "multiPayMode" : "enabled"
            	}
            ]
        }
    }
});

NewInvBankModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating NewInvBankModelLookUp table, please contact admin...');
    } else {
        NewInvBankModelLookUp.remove({}, function(err) {
            console.log('NewInvBankModelLookUp collection removed');
            NewInvBankModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating NewInvBankModelLookUp table, please contact admin...');
                }
                console.log('NewInvBankModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = NewInvBankModelLookUp;