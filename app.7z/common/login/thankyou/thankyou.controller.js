 function thankYouController($scope,constants, appConfig, configUrlModel){
	 $scope.headingObj = {
	 	text :constants.login.LOGIN_THANKYOU
	};
	 $scope.imagePath = configUrlModel.getImagesUrl()
	$scope.thankYouMessage = {
	 	text : constants.login.THANKYOU_MESSAGE,
	 	image:"../"+configUrlModel.getImagesUrl()+"/ThankYou_small.png"
	 }
	 $scope.goLogin = function(){
	 	var configURL = configUrlModel.getEnvUrl('MARKETING_URL');   
        location.href = appConfig[configURL];  
	 }
}
thankYouController.$inject = ['$scope','constants','appConfig', 'configUrlModel'];
module.exports = thankYouController;