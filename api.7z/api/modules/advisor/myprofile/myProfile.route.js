var express = require('express'),
    router = express.Router(),
    PersonalInfoModel = require('./personalinfo/getPersonalInfo.model'),
    GrantAccessSubUserDetails = require('./grantaccess/getGrantAccessSubUserDetails.model');
    

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */
var successObj = {"transactionStatus": "S"};

    router.route('/getpersonalinfo')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        PersonalInfoModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].personalInfoObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].personalInfoObject);
            }

        });
    });

    router.route('/updateMobileNumber/*')
    .post(function (req, res) {
        
        if(req.params[0]){
            res.json(successObj);
        }

    });

    router.route('/changePassword')
    .post(function(req, res) {
        
        if(req.body.currentpassword && req.body.newpassword){
            res.json(successObj);
        }

    });

    router.route('/getGrantAccessSubUserDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GrantAccessSubUserDetails.find(function (err, data) {
    
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].grantAccessSubUserDetailsArray.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].grantAccessSubUserDetailsArray);
            }

        });
    });


    router.route('/createSubUser')
    .post(function(req, res) {

        if(req.body.username){
            res.json(successObj);
        } else {
            res.send(error);
        }   
    });

    router.route('/updateSubUserDetails')
    .post(function(req, res) {
        if(req.body.username){
            res.json(successObj);
        } else {
            res.send(error);
        }
    });

    router.route('/deleteSubUser')
    .post(function(req, res) {
        if(req.params[0]){
            res.json(successObj);
        } else {
            res.send(error);
        }
    });


    router.route('/unlockSubUser')
    .post(function(req, res) {
        if(req.body.username){
            res.json(successObj);
        } else {
            res.send(error);
        }
    });
   
module.exports = router;
