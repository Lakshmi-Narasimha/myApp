/**
 * @ngdoc property
 * @name paperLessModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - paperLessModel is a service model which consists the list of services required for paper less module.
 *
 **/
'use strict';


var investorRegistrationModel = function(Restangular, $q, fticLoggerMessage, loggerConstants) {

    var  _investorRegistrationDetails = null, _newInvFolioId;
    var investorRegistrationDetails = {

        fetchinvestorRegDetails : function (reqObj) {
            var deferred = $q.defer();
            Restangular.one('transact/investorRegistration').customPOST(reqObj.bodyObj, "", reqObj.paramObj, {}).then(function (invRegDetails) {
                console.log(invRegDetails);
                deferred.resolve(invRegDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setinvestorRegDetails : function(invRegDetails){
        	_investorRegistrationDetails = invRegDetails;
        },   
        getinvestorRegDetails : function(){
        	return _investorRegistrationDetails;
        },   

        setNewInvestorFolioId : function(folioId){
            _newInvFolioId = folioId;
        },   
        getNewInvestorFolioId : function(){
            return _newInvFolioId;
        }      
    };

    return investorRegistrationDetails;

    
};

investorRegistrationModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = investorRegistrationModel;
