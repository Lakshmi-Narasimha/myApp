// Amount.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AmountModelSchema = new mongoose.Schema({
    AmountResp: {
        type: Array,
        "default": []
    }
});

var AmountModelLookUp = mongoose.model('AmountModelLookUp', AmountModelSchema);

var AmountModel = new AmountModelLookUp({
    AmountResp : {
        'amount' : {
            'value': '550.12'
        }
    }
});

AmountModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AmountModelLookUp table, please contact admin...');
    } else {
        AmountModelLookUp.remove({}, function(err) {
            console.log('AmountModelLookUp collection removed');
            AmountModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating AmountModelLookUp table, please contact admin...');
                }
                console.log('AmountModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AmountModelLookUp;