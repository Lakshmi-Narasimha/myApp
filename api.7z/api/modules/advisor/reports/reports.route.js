var express = require('express'),
    router = express.Router(),
    EmailIdsModel = require('./instantreports/UserEmailIds.model'),
    NotificationReportModel = require('./notifications.model'),
    RecommendationReportModel = require('./recommendations.model'),
    BasisDateModel = require('./transactionStatus/basisDate.model'),
    TransactionStatusDetailsModel = require('./transactionStatus/transactionStatusDetails.model'),
    InvestorSearchResultModel = require('./transactionStatus/investorSearchResult.model'),
    BasisInvestorModel = require('./transactionStatus/basisInvestor.model'),
    AssetFundDetailsModel = require('./transactionStatus/AssetFundDetails.model');

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */

//User EmaiIds
router.route('/services/emailList')
    .get(function (req, res) {
        EmailIdsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].emailObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].emailObject[0]);
            }

        });

});
    
router.route('/getNotificationReport')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        NotificationReportModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].notificationReportResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].notificationReportResp);
                //res.send(500, error);
            }

        });
});

    router.route('/getRecommendationReport')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        RecommendationReportModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].recommendationReportResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].recommendationReportResp);
                //res.send(500, error);
            }

        });
});

router.route('/getBasisDateTransactions')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        BasisDateModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            
            if(req.query.isFinancial === "true"){
                if (err) {
                    res.send(err);
                } else if (data[0].basisDateDetails[0].basisDateFinancialTransactions === undefined) {
                    res.send(error);
                } else {
                    res.json(data[0].basisDateDetails[0].basisDateFinancialTransactions);
                    //res.send(500, error);
                }
            }else if(req.query.isFinancial === "false"){
                if (err) {
                    res.send(err);
                } else if (data[0].basisDateDetails[0].basisDateNonFinancialTransactions === undefined) {
                    res.send(error);
                } else {
                    res.json(data[0].basisDateDetails[0].basisDateNonFinancialTransactions);
                    //res.send(500, error);
                }
            }

        });
});

router.route('/getTransactionStatusDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        TransactionStatusDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].transactionDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].transactionDetails);
                //res.send(500, error);
            }

        });
});

router.route('/getInvestorSearchDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvestorSearchResultModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].investorSearchResult.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].investorSearchResult);
                //res.send(500, error);
            }

        });
});

router.route('/getBasisInvestorTransactions')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        BasisInvestorModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].basisInvestorDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].basisInvestorDetails);
                //res.send(500, error);
            }

        });
});

router.route('/getAssetFundDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        AssetFundDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            console.log(req.query);
            if (err) {
                res.send(err);
            } else if (data[0].AssetFundDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].AssetFundDetails);
                //res.send(500, error);
            }

        });
});
   
module.exports = router;
