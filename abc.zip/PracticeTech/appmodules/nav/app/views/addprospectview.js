﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appmodules/accountviewer/avcommon',
 'appcommon/commonutility',
  'services/dataservice',
  'appmodules/nav/app/models/addprospect',
  'apipublic/navapi',
  'appcommon/constants',
  'appmodules/nav/navvalidate',
  'text!appmodules/nav/app/templates/addprospect.html',
  'appcommon/analytics',
  'errorLog'
], function ($, _, Backbone, Spinner, accountviewCommon, CommonUtils, Dataservice, AddprospectModel, NavApi, Constants, NavValidator, AddProspectTemplate, Analytics, ErrorLog) {
    var addprospect = Backbone.View.extend({
        template: _.template(AddProspectTemplate),
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events : {
        	"click #add-prospect-save" : "saveProspect",
        	"click #add-prospect-cancel" : "handleCancel",
        	"click #back-tocontact-list" : "backToContactList",
        	"keyup .jump" : "autoJumpToFields",
        	"keypress #add-prospect .number": "isNumber",
        	"change #prospect-type": "checkType",
        	//"focus input[type='tel']" : "highlightTheField",
        	"click input[type='tel']" : "highlightTheField",
        	"click  .container-fluid": "hideIOSKeyboard",
        	"click .cd-inter-checkbox": "internationalNumberCheck",
        	"click .cd-pref-checkbox": "preferredNumberCheck"
        },
        initialize: function () {
            console.log('View Initialized');
        },      
        handleCancel : function(){

			BootstrapDialog
					.confirm(
							"Cancel",
							"All your work will be lost.  Are you sure you want to cancel?",
							function(confirm) {
								if (confirm) {
									window.scrollTo(0,0);
									Analytics.analytics.recordAction('addContactCancel:clicked');
						        	Backbone.history.navigate("#navigator/contactlist",true);
								}

							}, 'add-prospect');
		
        
        
        },
        backToContactList : function(){

			BootstrapDialog
					.confirm(
							"Cancel",
							"All your work will be lost.  Are you sure you want to continue?",
							function(confirm) {
								if (confirm) {
									window.scrollTo(0,0);
						        	Backbone.history.navigate("#navigator/contactlist",true);
								}

							}, 'add-prospect');
		
        
        
        },
        //function to handle the international home phone number
        internationalNumberCheck: function (event) {
            var _currTgt = $(event.currentTarget), internationalInputId, currBlock;
            internationalInputId = _currTgt.data('toggle');
            currBlock = _currTgt.data('block');

            var currElem = this.$('.cp-add-pros-second-sec').find('div.' + currBlock + '');
            currElem.find('input[type=tel]').val("");

            if (_currTgt.find('input').prop('checked')) {
                currElem.find('.textwrapnational').addClass('hidden');
                currElem.find('.textwrapinternational').removeClass('hidden');
            } else {
                currElem.find('.textwrapinternational').addClass('hidden');
                currElem.find('.textwrapnational').removeClass('hidden');
            }
        },
        preferredNumberCheck: function (event) {
            var _currTgt = $(event.currentTarget);
            var _checkbox = $(event.currentTarget).find('input[type="checkbox"]'), _checked = _checkbox.prop('checked');

            this.$('.cp-add-pros-second-sec').find('.cd-pref-checkbox input[type="checkbox"]').prop('checked', false);
            //this.$main.find('.cd-pref-checkbox input[type="checkbox"]').prop('checked', false);

            _currTgt.find('input[type="checkbox"]').prop('checked', true)
            _checkbox.prop('checked', _checked);
        },
        saveProspect : function(){
            try {
                var _that = this;

                var phSection = $(".prospcheck");
                phSection.find('input').removeClass('required');
                $.each(phSection, function (key, section) {
                    var ibox = $(section).find("input[type=tel]:visible");
                    var prefbox = $(section).find('.cd-pref-checkbox :checked');
                });
                var currBlk = $('.prospcheck').find('.cd-pref-checkbox :checked').data('block');
                var currElem = this.$('.cp-add-pros-second-sec').find('div.' + currBlk + '');
                var currInp = currElem.find('input.valid:visible');
                $(currInp).each(function () {
                    if ($(this).val() == "") {
                        $(this).addClass('required');
                    } 
                });

                if (!NavValidator.validateInputs('add-prospect')) {
                    return;
                }

                var contact = new AddprospectModel.Prospect();
                contact.set("contactType", $("#prospect-type").val());
                contact.set("marketSource", $("#prospect-source").val());
                //Phone numbers
                var phones = [];

                var prefno = "0";
                var homeCountryCode = $("#home-phone-int-1").val();
                if ($('#home-phone-pref').is(':checked')) {prefno = "1" } else {prefno = "0"}
                if (homeCountryCode == "") {
                    var homePhone = $("#home-phone-part-2").val() + $("#home-phone-part-3").val();
                    var homeArea = $("#home-phone-part-1").val();
                    var homeExtn = $("#home-phone-ext").val();
                    phones.push(new AddprospectModel.Phones().set({ "AreaCode": homeArea, "Number": homePhone, "PhoneType": "1", "Extension": homeExtn, "CountryCode": "", "Preferred": prefno }));
                } else {
                    var homeIntNumber = $("#home-phone-int-2").val();
                    var homeIntExtension = $("#home-phone-int-ext").val();
                    phones.push(new AddprospectModel.Phones().set({ "CountryCode": homeCountryCode, "Number": homeIntNumber, "PhoneType": "1", "Extension": homeIntExtension, "Preferred": prefno }));
                }

                var businessCountryCode = $("#business-phone-int-1").val();
                var prefno = "0";
                if ($('#business-phone-pref').is(':checked')) {prefno = "1"} else {prefno = "0"}
                if (businessCountryCode == "") {
                    var businessPhone = $("#business-phone-part-2").val() +$("#business-phone-part-3").val();
        		    var businessArea = $("#business-phone-part-1").val();
                    var businessExtn = $("#business-phone-ext").val();
                    phones.push(new AddprospectModel.Phones().set({ "AreaCode": businessArea, "Number": businessPhone, "PhoneType": "2", "Extension": businessExtn, "CountryCode": "", "Preferred": prefno
                }));
                } else {
                    var businessIntNumber = $("#business-phone-int-2").val();
                    var businessIntExtension = $("#business-phone-int-ext").val();
                    phones.push(new AddprospectModel.Phones().set({"CountryCode": businessCountryCode, "Number": businessIntNumber, "PhoneType": "2", "Extension": businessIntExtension, "Preferred": prefno
                }));
            }

                var mobileCountryCode = $("#mobile-phone-int-1").val();
                var prefno = "0";
                if($('#mobile-phone-pref').is(':checked')) {prefno = "1"} else {prefno = "0"}
                if (mobileCountryCode == "") {
                     var mobilePhone = $("#mobile-phone-part-2").val() +$("#mobile-phone-part-3").val();
                     var mobileArea = $("#mobile-phone-part-1").val();
                     var mobileExtn = $("#mobile-phone-ext").val();
        		    phones.push(new AddprospectModel.Phones().set({
        		        "AreaCode": mobileArea, "Number": mobilePhone, "PhoneType": "10", "Extension": mobileExtn, "CountryCode": "", "Preferred": prefno
                }));
                } else {
                    var mobileIntNumber = $("#mobile-phone-int-2").val();
                    var mobileIntExtension = $("#mobile-phone-int-ext").val();
                    phones.push(new AddprospectModel.Phones().set({
                        "CountryCode": mobileCountryCode, "Number": mobileIntNumber, "PhoneType": "10", "Extension": mobileIntExtension, "Preferred": prefno
                }));
            }

                var other1CountryCode = $("#other1-phone-int-1").val();
                var prefno = "0";
                if($('#other1-phone-pref').is(':checked')) {prefno = "1"} else {prefno = "0"}
                if (other1CountryCode == "") {
                    var other1Phone = $("#other1-phone-part-2").val() +$("#other1-phone-part-3").val();
        		    var other1Area = $("#other1-phone-part-1").val();
        		    var other1Extn = $("#other1-phone-ext").val();
                    phones.push(new AddprospectModel.Phones().set({"AreaCode": other1Area, "Number": other1Phone, "PhoneType": "16006", "Extension": other1Extn, "CountryCode": "", "Preferred": prefno
                }));
                } else {
                    var other1IntNumber = $("#other1-phone-int-2").val();
                    var other1IntExtension = $("#other1-phone-int-ext").val();
                    phones.push(new AddprospectModel.Phones().set({"CountryCode": other1CountryCode, "Number": other1IntNumber, "PhoneType": "16006", "Extension": other1IntExtension, "Preferred": prefno
                }));
            }

                var other2CountryCode = $("#other2-phone-int-1").val();
                var prefno = "0";
                if($('#other2-phone-pref').is(':checked')) {prefno = "1"} else {prefno = "0"}
                if (other2CountryCode == "") {
                    var other2Phone = $("#other2-phone-part-2").val() +$("#other2-phone-part-3").val();
        		    var other2Area = $("#other2-phone-part-1").val();
                    var other2Extn = $("#other2-phone-ext").val();
        		    phones.push(new AddprospectModel.Phones().set({"AreaCode": other2Area, "Number": other2Phone, "PhoneType": "16007", "Extension": other2Extn, "CountryCode": "", "Preferred": prefno
                }));
                } else {
                    var other2IntNumber = $("#business-phone-int-2").val();
                    var other2IntExtension = $("#business-phone-int-ext").val();
                    phones.push(new AddprospectModel.Phones().set({"CountryCode": other2CountryCode, "Number": other2IntNumber, "PhoneType": "16007", "Extension": other2IntExtension, "Preferred": prefno
                }));
            }

                contact.set("Phones", phones);

                

                //Addresses
        		var addresses =[];
        		addresses.push(new AddprospectModel.Addresses().set({
        			"AddressTypeDesc": "Home",
        			"AddressType": "1",
        			"Line1": $("#address-one").val(),
        			"Line2": $("#address-two").val(),
        			"City": $("#city").val(),
        			"State": $("#state-dd").val(),
        			"Postal": $("#zip").val()
            }));
        		contact.set("Addresses", addresses);
                //Personal info
        		var person = new AddprospectModel.PersonContact();
        		person.set({"clGreeting": $("#greeting").val(),
        					"clFirstNm": $("#prospect-first-name").val(),
        					"clMidNm": $("#middle-name").val(),
        					"clLastNm": $("#last-name").val(),
        					"clSfxTxt": $("#suffix").val()
            });
        		contact.set("PersonContact", person);
                //Email section
        		var email =[];
        		email.push(new AddprospectModel.WebAddresses().set({"Address": $("#add-emailaddr").val()
            }));
        		contact.set("WebAddresses", email);
        		var data = contact.toJSON();
        		Spinner.show();
        		Dataservice.addProspectContact(accountviewCommon.readCookie('FMID'), data)
            	.then(function (response) {
            		//if (response.toLowerCase().indexOf("contact.") >= 0) {
            		if(response.status != "Error"){
            	        var contact = {
            	                firstNm: data.PersonContact.attributes.clFirstNm,
            	                lastNm: data.PersonContact.attributes.clLastNm,
            	                contactType: Constants.contactType.NonClient,
            	                id: response
            	    };
            	        NavApi.addNewContact(accountviewCommon.readCookie('FMID'), contact);

            	        NavApi.changeContactAndLauchCP(response, Constants.contactType.NonClient);
            	        $("body").click();
            	    }
            	    else {
            	    	ErrorLog.ErrorUtils.myError(response);
            	       // alert("System is unavilable.");
            	}
            	    //console.log(response);
            	    Analytics.analytics.recordAction('addContactSave:clicked');
            	    //Spinner.hide();
            	    //_that.backToContactList();
        		})
            	.fail(function (Error) {
            		Spinner.hide();
            		ErrorLog.ErrorUtils.myError(Error);
            });
        	}
        	catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        	
        },
        isNumber : function(evt){
        	 evt = (evt) ? evt : window.event;
        	    var charCode = (evt.which) ? evt.which : evt.keyCode;
        	    if(isNaN(String.fromCharCode(charCode))){
        	    	return false;
        	    }
        	    return true;
        }, highlightTheField : function (e) {
        	var _target = e.currentTarget || e.target;
        		$(_target).select();
        		try {
        			_target.setSelectionRange(0,99);
				} catch (error) {
	                ErrorLog.ErrorUtils.myError(error);
	            }
        },
        autoJumpToFields : function(e){
        	//block the jump if it is a tab or shift+tab
        	e.which = e.which || e.keyCode;
        	if(e.which == 9 || e.which == 16){
        		return;
        		}
        	var _target = e.currentTarget || e.target;
        	var _el = $(_target);
        	var _maxLength = _el.attr("maxlength");
        	var _nxtFld = _el.data("jumpto");
        	if(_el.val() && _el.val().length == _maxLength){
        		$("#"+_nxtFld).focus();
        	}
        },
        checkType : function(e){
            if ($("#prospect-type").val() == "Other") {
                $("#cp-add-source").hide();
            }
            else {
                $("#cp-add-source").show();
            }
        },
        hideIOSKeyboard: function (e) {
            CommonUtils.hideIOSKeyboard(e);
        },
        render: function () {
            var that = this;
            that.$el.html(that.template());
        }

    });
    return addprospect;
});