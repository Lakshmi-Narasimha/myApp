/**
 * @ngdoc service
 * @name sipDetailsModel
 * @description
 *
 * - It has setter and getter methods to set/get SIP details data and default SIP  details.
 *
 */

'use strict';

var sipDetailsModel = function (Restangular, $q, authenticationService, transactModel) {
    var _sipDetails = null;
    var _totalSipAmount = 0;

    var _defaultSipDetails = {
        endDateOption : "Until Cancelled",
        showStepUpSip : false,
        sipAmount : "",
        frequency : "Monthly",
        futureInstallmentDay : 1
    };

    var sipDetailsModel = {

        fetchTxnDetailsSip : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('getTxnDetailsSip').get(params).then(function (sipDetails) {
                deferred.resolve(sipDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setSipDetails : function(sipDetails) {
            _sipDetails = sipDetails;
        },

        getSipDetails : function() {
            return _sipDetails;
        },

        setDefaultSipDetails : function(defaultSipDetails1) {
            _defaultSipDetails = defaultSipDetails1;
        },

        getDefaultSipDetails : function() {
            return _defaultSipDetails;
        },
        setSipTotalAmount : function(sipAmount) {
            _totalSipAmount = angular.copy(sipAmount);
        },

        getSipTotalAmount : function() {
            return angular.copy(_totalSipAmount);
        }

    };
    return sipDetailsModel;
};

sipDetailsModel.$inject = ['Restangular', '$q', 'authenticationService', 'transactModel'];

module.exports = sipDetailsModel;