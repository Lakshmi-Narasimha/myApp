/**
 * @ngdoc property
 * @name fticConfirmModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function fticConfirmModalController($scope, $uibModalStack, $filter, nomineeDetailsModel, authenticationService, investorConstants, investorEvents, toaster, $timeout) {
    var translateFilter = $filter('translate');
    $scope.checkConfirmPassword = true;
    $scope.confirmPassword = {
        key : 'confirmPassword',
        text : translateFilter(investorConstants.myprofile.CNF_PWD),
        value : '',
        name : 'confirmPassword',
        type : 'password',
        min : '',
        message : '',
        isRequired : true
    };

    $scope.isReloadDrop = true;   
    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    };
    $scope.validatePwd = function(){
        var creds = {'guId':authenticationService.getUser().guId,'password':$scope.confirmPassword.value};
        nomineeDetailsModel.checkConfirmPasswordPost(creds).then(function(){
            $uibModalStack.dismissAll();
            $scope.$emit("confirmValidatePwd");
         }, function(error){
            toaster.error(error.data[0].errorDescription);
        });

    };
}
fticConfirmModalController.$inject = ['$scope', '$uibModalStack', '$filter', 'nomineeDetailsModel', 'authenticationService', 'investorConstants', 'investorEvents', 'toaster', '$timeout'];

module.exports = fticConfirmModalController;