/**
 * @ngdoc property
 * @name fticPaymentDateOptions Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Period, Start date and End date options.
 *
 **/
'use strict';

var fticMultiplePayMode = function (bankDtlsModel, $stateParams, transactModel,authenticationService, TransactConstant, paperlessModel, sipDetailsModel, fundDetails, paymentDetailsUtility) {
    return {
        template: require('./multiplePayMode.html'),
        restrict: 'E',
        replace: true,
        scope: {
            parentForm: '='
        },
        controller:['$scope', function ($scope) {
            $scope.isNewInvestor = transactModel.isNewInvestor;
            $scope.isNewFolio = transactModel.getIsNewFolio();

            $scope.formDetails = {
                paymentForm: $scope.parentForm
            };

            $scope.mode = {};
            $scope.mode.selectedVal = null;

        	$scope.multiMethod = {};
            $scope.multiMethod.netBankSel = null;
            $scope.multiMethod.debitBankSel = null;
            $scope.multiMethod.neftSel = null;
            $scope.multiMethodReqd = true;
            $scope.futureInstMethodReqd = true;
            
            $scope.multiNetBanking = {disable : true, name : 'multiNetBanking'};
            $scope.multiDebitCard = {disable : true, name : 'multiDebitCard'};
            $scope.multiNeft = {disable : true, name : 'multiNeft'};

            $scope.showNoBankError = false;
            $scope.showNoFutBankError = false;
            $scope.showMultiBankError = false;
            bankDtlsModel.setIsMultiBankError($scope.showMultiBankError);

            $scope.isSIP = false;
            $scope.isModifySIP = false;
            $scope.isBuy = false;

            var isEmpty = false;

            $scope.netBankOptions = [
                {
                    title: TransactConstant.transact.SELECT_BANK, 
                    key : 'select'
                }
            ];

            $scope.debitBankOptions = [
                {
                    title: TransactConstant.transact.SELECT_BANK, 
                    key : 'select'
                }
            ];

            $scope.neftBankOptions = [
                {
                    title: TransactConstant.transact.SELECT_BANK, 
                    key : 'select'
                }
            ];

            var bankOptions = null,
                txnType = paymentDetailsUtility.getTxnType();

            $scope.isSIP = transactModel.getIsSip();
            $scope.isBuy = transactModel.getIsBuy();
            $scope.isModifySIP = transactModel.getIsModifySIP();            
            
            if(!$scope.isNewInvestor && !$scope.isNewFolio) {
                if(bankDtlsModel.getBankDetails() !== null) {
                    //Net Banking Options
                    bankOptions = bankDtlsModel.getBankDetails().netBanking;
                    for(var i=0; i<bankOptions.length; i++) {
                        $scope.netBankOptions.push({title: bankOptions[i].pbBankName + '-' + bankOptions[i].pbPersonalAccountNumber, key : bankOptions[i].pbPersonalAccountNumber, refNo : bankOptions[i].achRefNo, bankName : bankOptions[i].pbBankName});
                    }

                    //Debit Card Options
                    bankOptions = bankDtlsModel.getBankDetails().debit;
                    for(var i=0; i<bankOptions.length; i++) {
                        $scope.debitBankOptions.push({title: bankOptions[i].pbBankName + '-' + bankOptions[i].pbPersonalAccountNumber, key : bankOptions[i].pbPersonalAccountNumber, refNo : bankOptions[i].achRefNo, bankName : bankOptions[i].pbBankName});
                    }

                    //NEFT / RTGS Options
                    bankOptions = bankDtlsModel.getBankDetails().neftRtgs;
                    for(var i=0; i<bankOptions.length; i++) {
                        $scope.neftBankOptions.push({title: bankOptions[i].pbBankName + '-' + bankOptions[i].pbPersonalAccountNumber, key : bankOptions[i].pbPersonalAccountNumber, refNo : bankOptions[i].achRefNo, bankName : bankOptions[i].pbBankName});
                    }
                }
            }

            $scope.payMethodChanged = function(value) {
                bankDtlsModel.setPaymentMethod(value);
                $scope.showPayeeDetails = false;                
                $scope.showNewAccount = false;
                $scope.methodRequired = false;
                $scope.showNoBankError = false;
                isEmpty = false;
                
                $scope.multiMethod.netBankSel = $scope.netBankOptions[0];
                $scope.multiMethod.debitBankSel = $scope.debitBankOptions[0];
                $scope.multiMethod.neftSel = $scope.neftBankOptions[0];

                var bankOptions = bankDtlsModel.getBankDetails();
                switch(value) { 
                    case TransactConstant.transact.NET_BANKING:
                        if(!$scope.isNewInvestor && !$scope.isNewFolio) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.netBanking);
                            if(bankOptions && !isEmpty) {
                                $scope.multiNetBanking.disable = false;
                                $scope.multiDebitCard.disable = true;
                                $scope.multiNeft.disable = true;
                            }
                        } else {
                            $scope.multiNetBanking.disable = false;
                            $scope.multiDebitCard.disable = true;
                            $scope.multiNeft.disable = true;
                        }
                        break;
                    case TransactConstant.transact.DEBIT_CARD:
                        if(!$scope.isNewInvestor && !$scope.isNewFolio) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.debit);
                            if(bankOptions && !isEmpty) {
                                $scope.multiDebitCard.disable = false;
                                $scope.multiNetBanking.disable = true;
                                $scope.multiNeft.disable = true;
                            }
                        } else {
                            $scope.multiDebitCard.disable = false;
                            $scope.multiNetBanking.disable = true;
                            $scope.multiNeft.disable = true;
                        }
                        break;
                    case TransactConstant.transact.NEFT_RTGS:
                        if(!$scope.isNewInvestor && !$scope.isNewFolio) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.neftRtgs);
                            if(bankOptions && !isEmpty) {
                                $scope.multiNeft.disable = false;
                                $scope.multiDebitCard.disable = true;
                                $scope.multiNetBanking.disable = true;
                            }
                        } else {
                            $scope.multiNeft.disable = false;
                            $scope.multiDebitCard.disable = true;
                            $scope.multiNetBanking.disable = true;
                        }
                };

                if($scope.isNewInvestor || $scope.isNewFolio) {
                    if(value === TransactConstant.transact.NEFT_RTGS) {
                        $scope.showPayeeDetails = true;
                    }
                }                
                if(isEmpty) {
                    $scope.showNoBankError = true;
                }
                bankDtlsModel.setIsNoBankError($scope.showNoBankError);
            };

            $scope.futureInstMethodChanged = function(value) {
                bankDtlsModel.setFutureInstPayMethod(value);
                $scope.showAutoDebit = false;
                $scope.showNoFutBankError = false;                
                isEmpty = false;
                
                var bankOptions = bankDtlsModel.getBankDetails();
                switch(value) {
                    case TransactConstant.transact.AUTO_DEBIT:
                        if(!$scope.isNewInvestor && !$scope.isNewFolio) {
                            var autoDebitBanks = [];
                            bankOptions = bankOptions.emandate;
                            for(var i=0; i<bankOptions.length;i++) {
                                if(bankOptions[i].paymentType === 'M') {
                                    autoDebitBanks.push(bankOptions[i]);
                                }
                            }
                            isEmpty = paymentDetailsUtility.isEmptyBankList(autoDebitBanks);                           
                            if(!isEmpty) {
                                $scope.showAutoDebit = true;                                
                            }
                        } else {
                            $scope.showAutoDebit = true;                            
                        }
                        break;
                    case TransactConstant.transact.BILL_PAY:                        
                        bankDtlsModel.setIsAutoBankError(false);
                };
                if(isEmpty) {
                    $scope.showNoFutBankError = true;
                }
                bankDtlsModel.setIsNoBankError($scope.showNoFutBankError);
            };

            $scope.$on('multiNetBankChanged', function(event, data) {
                var payMethod = bankDtlsModel.getPaymentMethod();
                bankDtlsModel.setAchRefNo(data.refNo);
                $scope.showMultiBankError = false;
                if(bankDtlsModel.getBankDetails() !== null && data.key !== 'select') {
                    var bankDtls = bankDtlsModel.getBankDetails().netBanking;
                    setPayment(bankDtls, data);
                } else if(payMethod !== TransactConstant.transact.AUTO_DEBIT && data.key === 'select') {
                    $scope.showMultiBankError = true;
                }
                bankDtlsModel.setIsMultiBankError($scope.showMultiBankError);
            });

            $scope.$on('multiDebitBankChanged', function(event, data) {
                var payMethod = bankDtlsModel.getPaymentMethod();
                bankDtlsModel.setAchRefNo(data.refNo);
                $scope.showMultiBankError = false;                            
                if(bankDtlsModel.getBankDetails() !== null && data.key !== 'select') {
                    var bankDtls = bankDtlsModel.getBankDetails().debit;
                    setPayment(bankDtls, data);
                } else if(payMethod !== TransactConstant.transact.AUTO_DEBIT && data.key === 'select') {
                    $scope.showMultiBankError = true;
                }
                bankDtlsModel.setIsMultiBankError($scope.showMultiBankError);
            });

            $scope.$on('multiNeftBankChanged', function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                $scope.showMultiBankError = false;
                var payMethod = bankDtlsModel.getPaymentMethod();
                if(bankDtlsModel.getBankDetails() !== null && data.key !== 'select') {
                    var bankDtls = bankDtlsModel.getBankDetails().neftRtgs;
                    setPayment(bankDtls, data);
                    $scope.showPayeeDetails = true;
                } else if(payMethod !== TransactConstant.transact.AUTO_DEBIT && data.key === 'select') {
                    $scope.showPayeeDetails = false;
                    $scope.showMultiBankError = true;
                }
                bankDtlsModel.setIsMultiBankError($scope.showMultiBankError);
            });

            function setPayment(bankDtls, data) {
                var i = 0;
                if(bankDtls !== undefined && data.key !== 'select') {
                    while(bankDtls[i].pbPersonalAccountNumber !== data.key) {
                        i++;
                    }
                    bankDtlsModel.setSelectedBank(data.title);
                    bankDtlsModel.setAccountNo(data.key);
                    bankDtlsModel.setPaymentMode(bankDtls[i].paymentType);
                    bankDtlsModel.setBankName(data.bankName);
                    
                    var payMethod = bankDtlsModel.getPaymentMethod();
                    if(payMethod !== TransactConstant.transact.SETUP_NEW_MANDATE && payMethod !== TransactConstant.transact.AUTO_DEBIT) {
                        if($scope.isSIP) {
                            bankDtlsModel.setTotalAmount(sipDetailsModel.getSipTotalAmount());
                        } else if($scope.isBuy) {
                            bankDtlsModel.setTotalAmount(fundDetails.getBuyTotalAmount());
                        }
                    }
                }
            }

            //Save previous selections

            //For Transact Module
            if($stateParams.key === TransactConstant.transact.Payment_Key) {
                saveMultipleModeOptions();
            }

            //For Paperless Module
            if(paperlessModel.paymentDtls.hasData) {
                saveMultipleModeOptions();
            }

            function saveMultipleModeOptions(){
                var payMethod = bankDtlsModel.getPaymentMethod();
                var futureInstPayMethod = bankDtlsModel.getFutureInstPayMethod();
                $scope.mode.selectedVal = payMethod;
                $scope.mode.checkedVal = futureInstPayMethod;

                if(futureInstPayMethod === TransactConstant.transact.AUTO_DEBIT) {
                    $scope.showAutoDebit = true;
                    $scope.showMultiBankError = false;
                    bankDtlsModel.setIsMultiBankError($scope.showMultiBankError);
                }

                var period = bankDtlsModel.getPeriod();
                $scope.selectedPeriod = period;

                if(period === TransactConstant.transact.DATE_RANGE) {
                    var date = bankDtlsModel.getEndDate();
                    $scope.endDate = date.valueOf();
                    $scope.endDateDisable = false;
                } else {
                    var currentDate = new Date();
                    var tenYrDate = currentDate.setFullYear(currentDate.getFullYear() + 10);
                    $scope.endDate = tenYrDate;
                }

                //Set Selected Bank
                var payMethod = bankDtlsModel.getPaymentMethod();
                var selectedBank = bankDtlsModel.getSelectedBank();
                $scope.showMultiBankError = false;
                bankDtlsModel.setIsMultiBankError(false);
                switch(payMethod) {
                     case TransactConstant.transact.NET_BANKING:
                        $scope.multiNetBanking.disable = false;
                        $scope.showMultiBankError = false;
                        for(var i=0; i<$scope.netBankOptions.length; i++) {
                            if($scope.netBankOptions[i].title === selectedBank) {
                                $scope.multiMethod.netBankSel = $scope.netBankOptions[i];
                            }
                        }
                        break;
                    case TransactConstant.transact.DEBIT_CARD:
                        $scope.multiDebitCard.disable = false;
                        $scope.showMultiBankError = false;
                        for(var i=0; i<$scope.debitBankOptions.length; i++) {
                            if($scope.debitBankOptions[i].title === selectedBank) {
                                $scope.multiMethod.debitBankSel = $scope.debitBankOptions[i];
                            }
                        }
                        break;
                    case TransactConstant.transact.NEFT_RTGS:
                        $scope.multiNeft.disable = false;
                        $scope.showMultiBankError = false;
                        for(var i=0; i<$scope.neftBankOptions.length; i++) {
                            if($scope.neftBankOptions[i].title === selectedBank) {
                                $scope.multiMethod.neftSel = $scope.neftBankOptions[i];
                            }
                        }
                };
            }
        }]
    };
};

fticMultiplePayMode.$inject = ['bankDtlsModel', '$stateParams', 'transactModel','authenticationService','TransactConstant', 'paperlessModel', 'sipDetailsModel', 'fundDetails', 'paymentDetailsUtility'];
module.exports = fticMultiplePayMode;