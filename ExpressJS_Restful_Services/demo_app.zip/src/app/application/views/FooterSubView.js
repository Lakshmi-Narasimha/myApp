define([
    'jquery',
    'lodash',
    'app/common/views/AbstractView',
    'text!app/application/templates/footer.html'
], function ($, _, AbstractView, FooterTemplate) {

    return AbstractView.extend({
        el: '#sem-footer',
        template: _.template(FooterTemplate),
        events: {},
        render: function () {
            this.$el.html(this.template());
        }
    });

});
