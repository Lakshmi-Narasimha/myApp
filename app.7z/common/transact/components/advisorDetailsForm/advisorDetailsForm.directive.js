 /**
 * @ngdoc property
 * @name fticAdvisorForm Directive
 * @requires transactModel
 * @requires transactEventConstants
 * @description
 *
 * - It will done validation for the adavisor details form fields and bonds the data to a advisorDetails object.
 *
 **/
'use strict';



var fticAdvisorForm = function ($state,transactModel,transactEventConstants,$timeout, transactEvents, paperlessModel, advisorSearchModel, authenticationService,transactNowModel, TransactConstant, profileDetailsModel) {

    return {
        template: require('./advisorDetailsForm.html'),
        restrict: 'E',
        scope: {
            advisorDetails : "=?",
            advisorForm : '=',
            advisorNames : '=',
            isGuest : '=?',
            setForm : '=?'
        },
        controller:['$scope', function ($scope) { 
            $scope.advisorDetails = {};
            $scope.invPref = {};
         	if(!$scope.isGuest && profileDetailsModel.getProfileDtls()) {
                $scope.advisorDetails.arnCode = profileDetailsModel.getProfileDtls().profileDetails.ARN +" | "+ profileDetailsModel.getProfileDtls().profileDetails.userFirstName ;   
            }
            $scope.slectedAdvisor = false;
            var guIdParam = authenticationService.getUser().guId, noEuin = TransactConstant.transact.NO_EUIN, defaultEuin, isEdit = false;
            var params = {
                "guId" : guIdParam
            }, namesData, advNamesArray;

            $scope.$on('cancelEditPurchase', function(){
                $scope.advisorDetails = {};
                $scope.invPref = {};
            });

            $scope.euinServiceCall = function(searchQuery){
                transactModel.fetchEUINDetails(searchQuery).then(function (data) {
                transactModel.setEUINDetails(data.euins)
                transactEvents.transact.publishEUINDetails($scope);                
                }, function (data) {

                });
                params = {};
                params.guId = guIdParam;
            }
            //geting data from the Inital loader/service
            $scope.init = function () { 
                if(!$scope.isGuest){
                    $scope.euinServiceCall(params);
                }
            };
            
            $scope.init();
            //Function to find the given "value" in a given object array
            $scope.findItemInFilter = function(objArr, value){
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                        return x.title == value;
                }))[0];
                return obj;
            }

            $scope.euinOptions = []; //service
            defaultEuin = [{
                title : noEuin
            }];
            
            $scope.$on(transactEventConstants.transact.EUIN_DTLS,function(event){
                $scope.euinData = transactModel.getEUINDetails(); //service
                for(var i=0; i< $scope.euinData.length;i++) {      
                    $scope.euinOptions.push({title : $scope.euinData[i]});      
                }
                transactModel.isEuinServiceSuccess = true;
                transactModel.setFormattedEUINDetails($scope.euinOptions);
                $scope.defaultEuinSelected = $scope.findItemInFilter($scope.euinOptions, $scope.euinOptions[0].title);          
                $scope.advisorDetails.euin = $scope.euinOptions[0].title; 
                if($scope.advisorDetails.euin === noEuin){
                    $scope.showNoEuinTnC = true;
                }
            }); 

            $scope.sectionFilterOptions = {
                required : true,
                name : "euin"
            };

            $scope.$on('EUIN_CHANGED', function(event, selectedValue){
                if(selectedValue.title){
                    $scope.showNoEuinTnC = false;   
                    $scope.advisorDetails.euin = selectedValue.title; 
                    $scope.defaultEuinSelected = selectedValue;
                    if(selectedValue.title == noEuin){
                        $scope.advisorForm.$setPristine();
                        $scope.showNoEuinTnC = true;
                    } 
                }              
            });

            $scope.advisorDetails.code = $scope.arnCode;
            //onAdvisor Select Function handling

             $scope.onAdvisorSelect = function ($model) {
                if($model){
                    $scope.$emit(transactEventConstants.transact.guest.invPref.NEW_ADVISOR_SELECTED);
                    $scope.advisorForm.$setPristine();
                    $scope.slectedAdvisor = true;
                    $scope.advisorDetails.code = $model;
                    advNamesArray =  $model.split('~');
                    params.distId = advNamesArray[1];
                    if(!isEdit){
                        $scope.euinOptions = angular.copy(defaultEuin);
                        $scope.advisorDetails.euin = $scope.euinOptions[0].title;
                        $scope.defaultEuinSelected = $scope.euinOptions[0];
                        $scope.advisorDetails.subBrokerCode = "";
                        $scope.advisorDetails.subBrokerArn = "";
                        $scope.advisorDetails.checkNoEuin = false;
                        transactModel.isEuinServiceSuccess = false;
                        $scope.euinServiceCall(params);
                    }else if(isEdit && transactModel.isEuinServiceSuccess){
                        $scope.euinOptions = angular.copy(transactModel.getFormattedEUINDetails());
                        $scope.defaultEuinSelected = $scope.findItemInFilter($scope.euinOptions, $scope.advisorDetails.euin);          
                        isEdit = false;
                    }else{
                        $scope.euinOptions = angular.copy(defaultEuin);
                        $scope.defaultEuinSelected = $scope.findItemInFilter($scope.euinOptions, $scope.advisorDetails.euin);          
                        isEdit = false;
                    }                  
                }

            };

            //advisorNameChanged Function handling
            $scope.advisorNameChanged = function(){
                $scope.slectedAdvisor = false;
                $scope.$emit(transactEventConstants.transact.guest.invPref.ADVISOR_NAME_CHANGED);
            }

            $scope.getAdvisorNames = function(value){
                params.distFlag = 'NC';
                params.distValue = value;
                if(value.length >=3){
                    return advisorSearchModel.fetchAdvisorNameDetails(params).then(function(data){
                        params = {};
                        params.guId = guIdParam;
                        return data.distName;
                    });
                }
            }
            
            //Edit Handling
            $scope.editAdvisorData = function(){
                $scope.advisorDetails = transactModel.getAdvDetails();
                var oldAdvisorData = angular.copy($scope.advisorDetails);
                transactModel.setOldAdvisorData(oldAdvisorData);
                if($scope.advisorDetails && paperlessModel.investorPreferenceOption === "financial"){ 
                    $scope.invPref.arnCode = $scope.advisorDetails.code;
                    isEdit = true;
                    $scope.onAdvisorSelect($scope.invPref.arnCode);
                }
            }

            //Paperless - Edit
            if(paperlessModel.invPreference.hasData){
                $scope.editAdvisorData();
            }

            //transact now Edit
            if(transactNowModel.hasInvPreferData ){
                $scope.editAdvisorData();
            }
            $scope.$on("reset_no_data",function(event,data){
                $scope.editAdvisorData();
            });
            
            transactModel.setAdvDetails($scope.advisorDetails);
        }]   
    };
};

fticAdvisorForm.$inject = ['$state','transactModel','transactEventConstants','$timeout', 'transactEvents', 'paperlessModel', 'advisorSearchModel', 'authenticationService','transactNowModel', 'TransactConstant','profileDetailsModel'];
module.exports = fticAdvisorForm;