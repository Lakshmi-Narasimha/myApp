define(['backbone'], function(Backbone) {
    var signDocPageModel = Backbone.Model.extend({
        defaults: {
            "pageNumber": "",
            "imageSrc": "",
            "signature": ""
        }
    });
    return signDocPageModel;
});