// newFolioDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var NewFolioDtlsModelSchema = new mongoose.Schema({
    NewFolioDtlsResp: {
        type: Array,
        "default": []
    }
});

var NewFolioDtlsModelLookUp = mongoose.model('NewFolioDtlsModelLookUp', NewFolioDtlsModelSchema);

var NewFolioDtlsModel = new NewFolioDtlsModelLookUp({
  "NewFolioDtlsResp": 
              [{
                "result":
                          {
                              "pan":"AMRPB4446B",
                              "firstHolderName": "Shankar Narayana",
                              "kyc": "Registered"
                          }            
              }]
    });

NewFolioDtlsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating NewFolioDtlsModelLookUp table, please contact admin...');
    } else {
        NewFolioDtlsModelLookUp.remove({}, function(err) {
            console.log('NewFolioDtlsModelLookUp collection removed');
            NewFolioDtlsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating NewFolioDtlsModelLookUp table, please contact admin...');
                }
                console.log('NewFolioDtlsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = NewFolioDtlsModelLookUp;