// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var OtpValidationSchema = new mongoose.Schema({
    'validateOtpObj': {
        'type': Object,
        'default': {}
    }
});

var OtpValidationLookup = mongoose.model('OtpValidationLookup', OtpValidationSchema);

var OtpValidationModel = new OtpValidationLookup({
    'validateOtpObj': {
        'eKYCOTPValidation': {
            'name': 'Gudipati Sai Chander Reddy',
            'dob': '30-01-1991',
            'gender': 'M',
            'phone': '9494728088',
            'email': 'chandugudipati230@gmail.com',
            'careOf': 'S/O: Gudipati Sridhar Reddy',
            'houseNo': 'LIG 36/6',
            'street': '',
            'landMark': 'LIG FLATS 3RD PHASE',
            'locality': 'K P H B COLONY',
            'vtc': 'Tirumalagiri',
            'subDist': 'Tirumalagiri',
            'district': 'Hyderabad',
            'pinCode': '500072',
            'postOffice': 'Kukatpally',
            'statusCode': '0',
            'statusDescription': 'SUCCESS'
        }

    }
});

OtpValidationLookup.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating OtpValidationLookup table, please contact admin...' + err);
    } else {
        OtpValidationLookup.remove({}, function (err) {
            console.log('OtpValidationLookup collection removed' + err);
            OtpValidationModel.save(function (err) {
                if (err) {
                    console.log('Having toruble in creating OtpValidationLookup table, please contact admin...');
                }
                console.log('OtpValidationLookup table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = OtpValidationLookup;
