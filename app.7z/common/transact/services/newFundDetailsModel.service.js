'use strict';

var newFundDetails = function (Restangular, $q, authenticationService) {    
    var _newFundDetails = null, _existingFundDetails = null, _maxFundLimit, _maxTransactionAmt, _selectedExistingFund = null;    

    var newFundDetailsModel = {
        
        fetchNewFundDetails : function (selectedInv) {
            var params = {};
            params.fundCategory = "";
            params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            params.folioId = selectedInv.folioId;
            params.userType = selectedInv.userType || "EA";
            var deferred = $q.defer();
            Restangular.one('transact/fundsList').get(params).then(function (newFundDetails) {
                deferred.resolve(newFundDetails);
            }, function (resp) {
                deferred.reject(resp); 
                console.log('error');
            });
            return deferred.promise;
        },
        
        getFundDetails: function() {
            return _newFundDetails;
        },
        
        setFundDetails: function(newFundDetails) {
            var fundCategory = _.uniq(_.map(newFundDetails.allfunds.newFunds, 'fundCategory'));
            _newFundDetails = {};
            _newFundDetails.allFunds = newFundDetails.allfunds.newFunds;
            for (var i in fundCategory){
                _newFundDetails[fundCategory[i].toLowerCase()] = [];
                for(var j in newFundDetails.allfunds.newFunds){
                    if(fundCategory[i] === newFundDetails.allfunds.newFunds[j].fundCategory){
                        _newFundDetails[fundCategory[i].toLowerCase()].push(newFundDetails.allfunds.newFunds[j]);
                    }
                }
            }
        },

        setExistingFundDetails : function(fundDetails){
            _existingFundDetails = fundDetails.allfunds.existingFunds;
        },

        getExistingFundDetails: function() {
            return _existingFundDetails;
        },

        setMaxFundLimit : function(limit){
            _maxFundLimit = limit;
        },

        getMaxFundLimit: function() {
            return _maxFundLimit;
        },

        setMaxTransactionAmt : function(amount){
            _existingFundDetails = fundDetails.allfunds.existingFunds;
        },

        getMaxTransactionAmt: function() {
            return _existingFundDetails;
        },
        getSelectedExistingFund : function(){
            return _selectedExistingFund;
        },
        setSelectedExistingFund : function(selectedOption){
            _selectedExistingFund = selectedOption;
        }

    };
    return newFundDetailsModel;
};

newFundDetails.$inject = ['Restangular', '$q', 'authenticationService'];

module.exports = newFundDetails;