define(
		[
            'text!appmodules/ncst/app/templates/empoyement.html',
			'appmodules/ncst/app/js/lib/validate-4.2',
			'appmodules/ncst/app/js/utils',
            'appcommon/commonutility',
            'appmodules/ncst/app/js/models/model-client',
            'appcommon/analytics',
            'appcommon/abstractview',
			'appcommon/constants',
            'text!components/template/EmpCompTemplate.html',
            'text!components/template/EmpCompViewTemplate.html',
            'components/js/views/EmpCompView',
            'components/js/views/CheckBoxView',
            'components/js/model/EmpCompModel',
            'errorLog'
        ],
		function (Template, Validator, Utils, CommonUtility, ClientModel, Analytics, AbstractView, Constants, EmployerCompanyTemplate, EmployerCompanyViewTemplate, EmpCompView, CheckBoxView, EmpCompModel, ErrorLog) {
			var IncomeModel = ClientModel.get('income');
			var empBtn = '', ofcBtn = '';
			var newEmployerComponentCount = 0;
			var newCompanyComponentCount = 0;
			var newFinraCompanyComponentCount = 0;
			var FINRAData = [], shareHolderData = [], employmentData = [], shareHolderCheckbox = {}, finraCheckbox = {};
			var self = null;
			var maxCount = 3; //Including 0 this should be 4
			var employmentView = AbstractView.extend({
			        el: '#ncst-app',
			        componentId: 0,
			        employerDynamicCheckboxView: 'employerDynamicCheckboxView',
			        companyDynamicCheckboxView: 'companyDynamicCheckboxView',
		        selectSameAsSectionCheckboxes: 'select-same-as-section-checkboxes',
		        selectWhichEmployerCheckboxes: 'select-which-employer-checkboxes',
		        statsTemplate: _.template(Template),
					initialize: function () {
					    self = this;
					    newEmployerComponentCount = 0;
					    newCompanyComponentCount = 0;
					    newFinraCompanyComponentCount = 0;
					    this.$main = this.$('#client-info');
					    this.employerComponentNm = "Employer";
					    this.companyComponentNm = "Company";
					    this.finraCompanyComponentNm = "Company";
					    this.employerCompData = new EmpCompModel().toJSON();
					    this.isOfficerCheckboxToCompViewMapping = {};
					    this.isOfficerAddrssCompViews = [];
						AbstractView.prototype.initialize.apply(this, arguments);
						
					},
		        events: {
		                'click #back-to-step4,#m-back-to-step4': 'navigateToStep4',
		                'click #step5-next-button,#m-step5-next-button': 'navigateToStep6',
		                'click .is-employed': 'toggleEmployed',
		                'click .is-officer': 'toggleOfficer',
		                'change input[name="empStatus"]': 'handleEmpStatusChange',
					    'click .sad-text.sad-step5': 'handleSAD',
					    'click #add-another-employer-btn': 'handleAddingAnotherEmployer',
					    'click #add-another-company-btn': 'handleAddingAnotherCompBtnClick',
					    'click #finra-add-another-company-btn': 'handleFinraAddingAnotherCompany',
					    'change select#pt-emp-select-industry': 'handleEmpIndustryOptions'
					},
					initializeElementVars: function () {
					    this.$addAnotherEmployerBtn = this.$("[data-for='add-another-employer-btn']");
					    this.$addAnotherCompanyBtn = this.$("[data-for='add-another-company-btn']");
					    this.$finraAddAnotherCompanyBtn = this.$("[data-for='finra-add-another-company-btn']");
					    this.$addAnotherCompanyContainer = $('#add-another-company-cntr');
					    this.$empComponentContainer = $("#employer-component");
					    this.$isEmployedBtnsHolder = $('[data-for="is-employed"]');
					    this.$isOfficerBtnCHolder = $('[data-for="is-officer"]');
					    this.$finraContainer = $('#finra-add-company-component');
					    this.$shareHolderContainer = $("#company-component");
					},
		        handleSAD: function () {
						Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
						this.captureData();
						this.model.setModel(employmentData, FINRAData, finraCheckbox, shareHolderData, shareHolderCheckbox);
						Utils.lockForm();
		            ClientModel.createDraft().done(function (response) {
							Utils.unlockForm();
							ClientModel.showDraftSaveSuccesMessage(response);
		            }).fail(function (error) {
							Utils.unlockForm();
							Utils.showDraftSaveErrorMessage();
						});
					},
		        clearView: function () {
						this.undelegateEvents();// Unbind all local event
						// bindings
						this.model.unbind('change', this.render, this); // Unbind reference to the model
					},
		        render: function () {
		            var _data = ClientModel.toJSON();
						var _dataEmp = _data.employement;
						var empStatus = _dataEmp.get('employmentStatus');
						var employmentAddrData = _dataEmp.get('employmentAddrCollection');
		                var finraAddrData = _dataEmp.get('FINRAAddrCollection');
						var finraStatus = _dataEmp.get('isEmployed');
						var finraCheckbox = _dataEmp.get('finraCheckbox');
						var shareHolderAddrData = _dataEmp.get('shareHolderAddrCollection');
						var shareHolderStatus = _dataEmp.get('isClientODSP');
						var shareHolderCheckbox = _dataEmp.get('shareHolderCheckbox');

						_data.client = ClientModel;
						this.$main.html(this.statsTemplate(_data));
						this.initializeElementVars();
                        
						if ((empStatus == "Employed" || empStatus == "Self employed") && employmentAddrData.length > 0) {
		                $("#employer-component").removeClass('hidden');
							for (i = 0; i < employmentAddrData.length; i++) {
								if (i > 0) {
									this.handleAddingAnotherEmployer(undefined, employmentAddrData[i], true);
								} else {
								    this.renderEmployerCompView(employmentAddrData[i], 0/*rendering the first emp address component, so index is 0*/);
								}								
							}
						}
		            //Show or Hide 'Which Employer' Section
						self.renderWhichEmployerSection("employer", "which-employer");

		            //Show or Hide 'Which Employer' Section
						self.renderSameAsSection("company", "same-as-section");

						if (finraStatus == "Yes" && finraAddrData.length > 0) {
							$('#finra-add-company-component').removeClass('hidden');
							for (i = 0; i < finraAddrData.length; i++) {
								if (finraAddrData[i].doNotDisplay && finraAddrData[i].doNotDisplay == true) {
								} else {
								    this.handleFinraAddingAnotherCompany(finraAddrData[i]);
								}								
							}
						}
						
						if (shareHolderStatus == "Yes" && shareHolderAddrData.length > 0) {
							$('#company-component').removeClass('hidden');
							for (i = 0; i < shareHolderAddrData.length; i++) {
							    var launchMode = shareHolderAddrData[i].launchMode,
							        addressViewName;
							    addressViewName= this.handleAddingAnotherCompany(shareHolderAddrData[i], launchMode, shareHolderCheckbox.sameAsCompanyArr);
							    if (launchMode == "view") {
							        this.isOfficerCheckboxToCompViewMapping[shareHolderAddrData[i]["EmpAddComUIRefId"]] = addressViewName;
                                }
							}
						}
						if (empStatus == "Self employed") {
							$('#emp-industry-classification').removeClass('hidden');
							CommonUtility.loadSelectbox(["#pt-emp-select-industry"], Constants.industryClassifications);
							if (_dataEmp && _dataEmp.get('industryClassifyEmp') != "") {
								var industryValue = _dataEmp.get('industryClassifyEmp');
								var industryInput = $('#pt-emp-industry-other-input');

								indText = this.industryClassification(industryValue);

								$('#pt-emp-select-industry').val(indText);
								if (industryValue == "Other") {
									$('#pt-emp-industry-other').removeClass('hidden');
									industryInput.val(_dataEmp.get('industryClassifyEmpOther'));													
								} else {
		                        industryInput.val("");
							}
		                }
						} else {
							$('#emp-industry-classification, #pt-emp-industry-other').addClass('hidden');
						}
						return this;
		        },
		        industryClassification: function (indsClsCd) {
		        	var mappingCode = Constants.industryClassifications;
		        	var indsName = "";
		        	_.each(mappingCode, function (list) {
		        		if (list.name == indsClsCd) {
		        			indsName = list.code;
		        		}
		        	});
		        	return indsName;
		        },
				handleEmpIndustryOptions: function () {
						var selectedOption = $('#pt-emp-select-industry :selected').text();
						if (selectedOption == "Other") {
							$('#pt-emp-industry-other').removeClass('hidden');
							$('#pt-emp-industry-other-input').val("");
						} else {
							$('#pt-emp-industry-other').addClass('hidden');
						}
					},
				updateEmployerComponentUIIndex: function () {
					this.$empComponentContainer.find(".pt-empcomp").each(function (i) {
					    $(this).attr("ui-index", i);
					});
				},
				isItemSelected: function (view, refId) {
				    var selectedItems = view.allSelectedItems,
				        selectedItem = _.find(selectedItems, function (item) {
				            return item.empRefId == refId;
				        });
				    return selectedItem;

				},
				    handleEmpCompCancelBtn: function (params/*compType, viewName, view*/) {
				        var view = params.view,
                            compType = params.compType,
                            viewName = params.viewName,
                            isAddressValid = view.isTheAddressValid(),
                            el = view.el,
                            uiIndex = $(el).find(".pt-empcomp").attr("ui-index"),
                            isEmployedSelected,
                            isOfficerSelected,
                            countOfContainers = self.getCount('employer'),
                            corrspndngCmpnyView,
                            selectedItem,
                            companyDynamicCheckboxView = this.getNestedView(this.companyDynamicCheckboxView),
                            employerDynamicCheckboxView = this.getNestedView(this.employerDynamicCheckboxView);

					    if (compType == "employer") {
					        isEmployedSelected = this.$isEmployedBtnsHolder.find(".toggle-button-yes").hasClass("active"); 
					        isOfficerSelected = this.$isOfficerBtnCHolder.find(".toggle-button-yes").hasClass("active");
					        self.removeNestedView(viewName);
					        $(el).remove();
					        self.updateEmployerComponentUIIndex();
					        if (isAddressValid) {
					            if (isEmployedSelected) {
					                if (employerDynamicCheckboxView) {
					                    self.triggerUncheckEventOfCheckbox(employerDynamicCheckboxView, view.employerCompanyInfo.id);					                    
					                }
					                //re render which employed check box
					                self.renderIsEmployerCheckBox();
					            }
					            if (isOfficerSelected) {
					                if (companyDynamicCheckboxView) {
					                    self.triggerUncheckEventOfCheckbox(companyDynamicCheckboxView, view.employerCompanyInfo.id);
					                }
					                //re render is office check box
					                self.renderOfficerSameAsCheckBox();
					            }
					        }

					        
					        function hideFinraSection() {
					            //Hide Finra Add Company
					            $('#finra-add-company').empty(); //Clear off the content
					            $('#finra-add-company-component').addClass('hidden'); //hide the parent container
					            //Uncheck if anything is checked
					            self.unCheckAllCheckBoxes(this.selectWhichEmployerCheckboxes);
					            self.resetAllSelectedItems(this.employerDynamicCheckboxView);
					            $("#which-employer").addClass('hidden');
					        }
					        
					    } else {
					        if (view.launchMode == "view") {
                                //view mode is only for Same As section
					            self.triggerUncheckEventOfCheckbox(companyDynamicCheckboxView, view.employerCompanyInfo.relatedModelRefId);
					        } else {
					            self.removeNestedView(viewName);
					            $(el).remove();
					        }
					    }

				    },
				    triggerUncheckEventOfCheckbox: function (checkBoxView, relatedModelRefId) {
				        var selectedItem = self.getSelectedItemByRelatedModelId(checkBoxView, relatedModelRefId);
				        if (selectedItem) {
				            $("#" + selectedItem.id).trigger("click");
				        }
				    },
				    employerAddressCompFieldChangeHandler: function (empCompView) {
				        var compType = empCompView.componentName.toLowerCase(),
                            dataModel = empCompView.employerCompanyInfo,
                            whichEmployerPlaceHolder = "which-employer",
                            sameAsPlaceHolder = "same-as-section",
                            companyPlaceHolder = "company",
                            isAddressValid = false,
                            companyDynamicCheckboxView = self.getNestedView(self.companyDynamicCheckboxView),
                            employerDynamicCheckboxView = self.getNestedView(self.employerDynamicCheckboxView);

				        var getEmployerSectionCount = self.getCount(compType); //employer
				        var isFinraQuesSelected = $('.is-employed').filter('.active').val();
				        var isShareHolerQuesSelected = $('.is-officer').filter('.active').val();

				        if ((getEmployerSectionCount > 0 && compType == 'employer') && ((isFinraQuesSelected != 'No' && isFinraQuesSelected != null) || (isShareHolerQuesSelected != 'No' && isShareHolerQuesSelected != null))) {
				            isAddressValid = empCompView.isTheAddressValid();
				                if (isFinraQuesSelected == "Yes") {
				                    self.renderWhichEmployerSection(compType, whichEmployerPlaceHolder, dataModel);
				                }
				                if (isShareHolerQuesSelected == "Yes") {
				                    if (!isAddressValid) {
				                        //trigger uncheck event if checked
				                        self.uncheckIsOfficerCheckbox(self.getNestedView(self.companyDynamicCheckboxView), empCompView.employerCompanyInfo.id);
				                        self.renderSameAsSection(compType, sameAsPlaceHolder, dataModel); 
				                    } else {
				                        self.renderSameAsSection(compType, sameAsPlaceHolder, dataModel);
				                        self.updateSameAsSection(empCompView);
				                    }

				                }
				        }
				    },
				    updateSameAsSection: function (empCompView) {
				        var isThisItemSelected,
                            corrspndngCompanyView;
				        isThisItemSelected = self.getSelectedItemByRelatedModelId(self.getNestedView(self.companyDynamicCheckboxView), empCompView.employerCompanyInfo.id);
				        if (!!isThisItemSelected) {
				            //manually call the on change event
				            corrspndngCompanyView = self.getEmployeComViewByViewModelProp("relatedModelRefId", empCompView.employerCompanyInfo.id);
				            corrspndngCompanyView.employerCompanyInfo = $.extend(corrspndngCompanyView.employerCompanyInfo, _.omit(empCompView.employerCompanyInfo, ["relatedModelRefId", "id", "tickerSymbol", "launchMode"]));
				            corrspndngCompanyView.reRender();
				        }
				    },
				    uncheckIsOfficerCheckbox: function (view, relatedModelRefId) {
				        var selectedItems,
                            selectedItem = self.getSelectedItemByRelatedModelId(view, relatedModelRefId),
                            itemIndex;
				        if (!!selectedItem) {
				            selectedItems = _.filter(view.allSelectedItems, function (item) {
				                return item.relatedModelRefId != relatedModelRefId;
				            });
				            view.selectedItems = selectedItems;
				            view.allSelectedItems = [];
				            itemIndex = Number(selectedItem.id.charAt(0));
				            view.reRender();
				            //manually call the on change event
				            view.itemSelectionComplete(selectedItems, itemIndex, selectedItem);
				        }
				    },
				    getSelectedItemByRelatedModelId: function (view, relatedModelRefId) {
				        var chckboxItems,
                            chboxItemCorrspndngToEmpView,
                            isThisItemSelected,
                            selectedItems;
				        if (view && view.allSelectedItems) {
				            selectedItems = $.extend([], view.allSelectedItems);
				            chckboxItems = view.items;
				            chboxItemCorrspndngToEmpView = _.find(chckboxItems, function (item) {
				                return item.relatedModelRefId == relatedModelRefId;
				            });
				            isThisItemSelected = _.find(view.allSelectedItems, function (item) {
				                return chboxItemCorrspndngToEmpView && chboxItemCorrspndngToEmpView.id == item.id;
				            });
				        }
				        return isThisItemSelected;
				    },
					renderEmpCompView: function (componentRenderingOptions, launchMode) {
					    var self = this;
					    var launchMode = (launchMode == '') ? 'view' : launchMode;
					    var empCompView = new EmpCompView(componentRenderingOptions.compConstrParams);
					    this.addNestedView(componentRenderingOptions.nestedViewName, empCompView);
					    
                        //Trigger an event on all fields change
					    empCompView.triggerFieldEvents = function (modelPropNm, changedVal) {
					        self.employerAddressCompFieldChangeHandler(empCompView, modelPropNm, changedVal);
					        self.checkForAddressMaxNumLimit(["company", "finra-add-company-component"]);
					    };
					    //Trigger an event on Cancel button click
					    empCompView.triggerCancelBtnEvt = function (selectedItem) {
                            //update the UI index on removing one comp from UI
					        self.handleEmpCompCancelBtn({
					            "compType": componentRenderingOptions.compType,
					            "viewName": componentRenderingOptions.nestedViewName,
					            "view": empCompView
					        });
					        self.addDynamicLabels(componentRenderingOptions.compType);
					        self.checkForAddressMaxNumLimit(["employer", "company", "finra-add-company-component"]);
					        //self.removeSectionFrmMultiplicity(componentRenderingOptions.compConstrParams.componentName.toLowerCase(), selectedItem, componentRenderingOptions.nestedViewName);
					        //self.handleBlurEvntOnEmployerName();
					    };
					    empCompView.compType = componentRenderingOptions.compType;
					    empCompView.launchMode = launchMode;
					    empCompView.render();
                        //add the UI Index only for Employer component
					    if (componentRenderingOptions.compType) {
					        empCompView.$el.attr("ui-index", componentRenderingOptions.uiIndex);
                        }
					},
					getEmployeComViewByViewModelProp: function (modelProp, modelPropVal) {
					    var nestedViews = self.nestedViews,
					        requestedView;
					    for (viewName in nestedViews) {
					        var view = nestedViews[viewName];
					        if (viewName.indexOf('pt-temp-') > -1) {
					            if (view.employerCompanyInfo && view.employerCompanyInfo[modelProp] && view.employerCompanyInfo[modelProp] ==  modelPropVal) {
					                requestedView = view;
                                }
                            }
                        }
					    return requestedView;
					},
					renderEmployerCompView: function (compData, comonentUiIndex) {
					    newEmployerComponentCount++;
					    var launchMode = 'edit';
					    var compReferenceNm = self.employerComponentNm.toLowerCase(); //Employer - to - employer
						var mainCompReferenceId = $("#" + compReferenceNm); //$("#employer")
		                var count = self.getCount(compReferenceNm) + 1;
						var dynamicPlaceHolder = self.employerComponentNm + "-comp-" + newEmployerComponentCount;
		                mainCompReferenceId.append("<div id='" + dynamicPlaceHolder + "'></div>");
		                var compReferenceId = self.$("#" + dynamicPlaceHolder);

		                var componentViewOptions = {
		                    "nestedViewName": "pt-temp-employer-" + newEmployerComponentCount + "-" + comonentUiIndex,
		                    "compConstrParams": {
		                        showJobTitleField: false, showPrimOccpatn: (comonentUiIndex === 0 ? true : false), el: compReferenceId, componentName: self.employerComponentNm, componentId: newEmployerComponentCount, compData: this.employerCompData, count: count, compData: compData ? compData : null
		                    },
		                    "compType": compReferenceNm,
		                    "uiIndex": comonentUiIndex
		                };
					    
		                this.renderEmpCompView(componentViewOptions, launchMode);
		                this.updateEmployerComponentUIIndex();
					},
					removeSectionFrmMultiplicity: function (componentName, selectedItem, nestedViewNm) {
					    var $parentContainer = $('#pt-temp-' + selectedItem).parent();
					    var referenceIndexId = $parentContainer.attr('data-reference-id');
    
					    var replaceEmpToComp = selectedItem.replace('employer', 'company');
					    //var $companyContainer = $('#pt-temp-' + replaceEmpToComp).is(':visible');
					    var $companyParentContainer = $('#pt-temp-' + replaceEmpToComp).parent();

					    var selectedItemSplit = selectedItem.split('-');
					    var compNm = selectedItemSplit[0];
					    var compId = selectedItemSplit[1];

					    //Handle when Cancel button clicked in Company Section - which is orginated from Same As section
		                if (componentName == 'company') {
					        var sameAsCheckBoxReferenceId = $parentContainer.attr('data-reference-id');
					        var sameAsCheckBoxReferenceNm = $parentContainer.attr('data-reference-name');
					        var dataIdentifier, companyArrId, companyArr;
		                    //pt-employer-name-1
					        if (referenceIndexId != undefined || sameAsCheckBoxReferenceId != undefined || sameAsCheckBoxReferenceNm != undefined) {
					            if (this.getNestedView('companyDynamicCheckboxView') != undefined) {
                                    companyArr = this.nestedViews["companyDynamicCheckboxView"].allSelectedItems;
					            }
					            dataIdentifier = sameAsCheckBoxReferenceId - 1;
		                        dataIdentifierEleId = $('input[name=' + this.selectSameAsSectionCheckboxes + ']').filter('[data-identifier=' + dataIdentifier + ']').attr('id');
		                        companyArrId = dataIdentifierEleId;

					            self.uncheckAndDisableCheckBox(dataIdentifierEleId);

					            self.spliceIt(companyArr, companyArrId);
					        }
		                } else if (componentName == 'employer') { //Handle when Cancel button clicked in Employer Section - which is orginated from Actual Employer section
		                    var nestedViewsData = this.nestedViews["companyDynamicCheckboxView"];
		                    if ($('input[name=' + this.selectSameAsSectionCheckboxes + ']').filter('[data-identifier="pt-' + compNm + '-name-' + compId + '"]').prop('checked')) {
		                        this.removeNestedView($('div [data-reference-name="' + compNm + '"][data-reference-id="' + compId + '"]').children().attr('id'));
		                        $('div [data-reference-name="' + compNm + '"][data-reference-id="' + compId + '"]').remove();
		                    }
		                    if (this.getNestedView('companyDynamicCheckboxView') != undefined) {
		                        //this.nestedViews["employerDynamicCheckboxView"].allSelectedItems.splice(parseInt(referenceIndexId -1), 1);
		                        nestedViewsData.allSelectedItems.splice(parseInt(compId - 1), 1);
		                        nestedViewsData.selectedIndexes.splice(parseInt(compId - 1), 1);
		                        nestedViewsData.items.splice(parseInt(compId - 1), 1);
		                        nestedViewsData.allItems.splice(parseInt(compId - 1), 1);
                            }
                        }

		                this.removeNestedView(nestedViewNm);
					    $parentContainer.remove(); // Remove the section

					    //if company div exists remove that
					    //$companyParentContainer.remove();

					    //Show or Hide 'Which Employer' Section
					    //this.renderSameAsSection("company", "same-as-section");

					    /*var getCountLength = self.getCount(componentName);
					    if (getCountLength <= maxCount) {
					        this.enableAddButtons(componentName);
					    }*/

					    var containersArr = ["employer", "company", "finra-add-company-component"];

					    $.each(containersArr, function (index, value) {
					        var getCountLength = self.getCount(value);
					        if (getCountLength <= maxCount) {
					            self.enableAddButtons(value);
					        }
					    });

					    this.addDynamicLabels(componentName);
					},
					addDynamicLabels: function (componentName) {
					    //Dynamically edit the label
					    var containerId = (componentName == 'finra') ? "finra-add-company" : componentName;
					    var componentTitle = (componentName == 'finra' || componentName == 'finra-add-company') ? "company" : componentName;

					    $('#' + containerId + " .pt-empcomp").each(function (i) {
                            i = ++i;
					        if (i == 1) {
					            $(this).find(".dynamic-label").html(componentTitle).css('text-transform', 'capitalize');
                            } else {
					            $(this).find(".dynamic-label").html(componentTitle + " " + i).css('text-transform', 'capitalize');
					        }
                        });
                    },
                        spliceIt: function (arr, refArrId) {
                            $.each(arr, function (i, el) {
                                if (this.id == refArrId) { //0-same-as-section-checkboxes
                    arr.splice(i, 1);
					        }
					    });
					    return arr;
					},
		            unCheckAllCheckBoxes: function (chkBoxSectionId) {
		                $('input[name=' + chkBoxSectionId + ']')
                                .attr('checked', false)
                                .prop('disabled', false)
                                .closest('.radio-group-conatiner')
                                .removeClass('active');
		            },
					uncheckAndDisableCheckBox: function (identifierId) {
					    $('#' + identifierId)
                                .attr('checked', false)
                                .prop('disabled', true)
                                .closest('.radio-group-conatiner')
                                .removeClass('active');
					},
					renderCompanyCompView: function () {
					    newCompanyComponentCount++;
					    var compReferenceNm = self.companyComponentNm.toLowerCase(); //Employer - to - employer
						var mainCompReferenceId = $("#" + compReferenceNm); //$("#employer")
						var dynamicPlaceHolder = self.companyComponentNm + "-comp-" + newCompanyComponentCount;
		                mainCompReferenceId.append("<div id='" + dynamicPlaceHolder + "'></div>");
		                var compReferenceId = self.$("#" + dynamicPlaceHolder);
					    
					    var componentViewOptions = {
					        "nestedViewName": "pt-temp-company-" + newCompanyComponentCount,
					        "compConstrParams": { el: compReferenceId, componentName: self.companyComponentNm, componentId: newCompanyComponentCount },
					        "compType": compReferenceNm
					    }

                        //Call common render of Employer Company Function
					    this.renderEmpCompView(componentViewOptions, launchMode);
			        },
					handleEventsOfSameAsSectionChkBox: function (selectedItems, itemId, launchMode) {
					    var referenceId = parseInt(itemId), createdAddresviewName;
					    for (var key in this.nestedViews) {
					        if (key.indexOf("pt-temp") > -1) {
					            var nestedViewName = this.nestedViews[key];
					            if (nestedViewName.componentName == 'Employer' && Number(key.substr(-1)) == referenceId) {
					                var compData = new EmpCompModel().toJSON();
					                compData.EmpAddComUIRefId = itemId;
					                compData.relatedModelRefId = nestedViewName.employerCompanyInfo.id;
					                createdAddresviewName = self.handleAddingAnotherCompany($.extend(compData, _.omit(nestedViewName.employerCompanyInfo, ["relatedModelRefId", "id"])), launchMode);
					            }
					        }
					    }
					    return createdAddresviewName;
					},
					handleEventsOfWhichEmployerChkBox: function (selectedItems, itemId) {
					    var referenceId = parseInt(itemId);
					    for (var key in this.nestedViews) {
					        if (key.indexOf("pt-temp") > -1) {
					            var nestedViewName = this.nestedViews[key];
					            if (nestedViewName.componentName == 'Employer' && Number(key.substr(-1)) == referenceId) {
					                self.handleAddingAnotherCompany(nestedViewName.employerCompanyInfo);
					            }
					        }
					    }
					},
					handleAddingAnotherEmployer: function (evt, compData, doNotRenderDynamicCheckBoxes) {
					    var launchMode = 'edit',
					        getCountLength = self.getCount('employer'),
					        compReferenceNm = self.employerComponentNm.toLowerCase(),
                            uiIndex = $("#employer").find(">div").length;

					    if (getCountLength < maxCount) {
					        $(self.$addAnotherEmployerBtn).removeClass('hidden');
			            }
					    if (getCountLength == maxCount || getCountLength >= maxCount) {
					        $(self.$addAnotherEmployerBtn).addClass('hidden');
			            }

					    newEmployerComponentCount++;

                        var componentViewOptions = {
                            "nestedViewName": "pt-temp-employer-" + newEmployerComponentCount + "-" + uiIndex,
                            "compConstrParams": {
                                el: self.$("#employer"),
                                componentId: newEmployerComponentCount,
                                componentName: 'Employer',
                                selectedAddrsType: '',
                                count: getCountLength + 1,
                                compData: compData ? compData : null
                            },
                            "compType": compReferenceNm
                        }

                        self.renderMultipleEmployerTemplate(componentViewOptions, $('#employer'), launchMode);
                        if (!doNotRenderDynamicCheckBoxes) {
                            //Show or Hide 'Which Employer' Section
                            self.renderWhichEmployerSection("employer", "which-employer");

                            //Show or Hide 'Which Employer' Section
                            self.renderSameAsSection("company", "same-as-section");
                        }
                        this.updateEmployerComponentUIIndex();

					    //Dynamically adjust the label counter
                        this.addDynamicLabels("employer");
                        self.checkForAddressMaxNumLimit(["employer", "company", "finra-add-company-component"]);
			        },
					renderMultipleEmployerTemplate: function (componentRenderingOptions, $employercontainer, launchMode) {
					    var self = this;
					    var launchModeVal = (launchMode == '') ? 'view' : launchMode;
					    var compNm = componentRenderingOptions.compConstrParams.componentName;
					    var compId = componentRenderingOptions.compConstrParams.componentId;
					    var compDataId = componentRenderingOptions.compConstrParams.compData ? componentRenderingOptions.compConstrParams.compData.compId:undefined
					    var compDataNm = componentRenderingOptions.compConstrParams.compData ? componentRenderingOptions.compConstrParams.compData.compNm : undefined;
					    var refId = componentRenderingOptions.compConstrParams.compData ? componentRenderingOptions.compConstrParams.compData.EmpAddComUIRefId : componentRenderingOptions.uiIndex;
					    var dynamicPlaceHolder = compNm + "-comp-" + compId;
					    if (compNm == 'Company' && compDataId != undefined) {
					        $employercontainer.append("<div id='" + dynamicPlaceHolder + "' data-reference-name=" + compDataNm + " data-reference-id=" + refId + "></div>");
					    } else {
			                $employercontainer.append("<div id='" + dynamicPlaceHolder + "'></div>");
					    }

			            componentRenderingOptions.compConstrParams.el = self.$("#" + dynamicPlaceHolder);

			            this.renderEmpCompView(componentRenderingOptions, launchModeVal);
					},
					handleFinraAddingAnotherCompany: function (compData, launchMode) {
					    var launchModeVal = (launchMode == undefined) ? 'edit' : launchMode;
					    var getCountLength = self.getCount('finra-add-company') + 1;
                        var compReferenceNm = self.finraCompanyComponentNm.toLowerCase();
		                var noOfCheckBoxesChecked = $('input[name=' +self.selectWhichEmployerCheckboxes + ']:checked').size();
		                var countOfChkBoxesChkedAndNoOfContainersAdded = noOfCheckBoxesChecked + getCountLength;

					    newFinraCompanyComponentCount++;
					    var componentViewOptions = {
					        "nestedViewName": "pt-temp-finra-" + newFinraCompanyComponentCount,
					        "compConstrParams": {
					            el: self.$("#finra-add-company"),
					            componentId: newFinraCompanyComponentCount,
					            componentName: 'finra',
					            selectedAddrsType: '',
					            count: getCountLength,
					            componentNameAsFinra: 'finra',
					            compData: compData ? compData : null
					        },
					        "compType": compReferenceNm
					    }

					    self.renderMultipleEmployerTemplate(componentViewOptions, $('#finra-add-company'), launchModeVal);

                        if (countOfChkBoxesChkedAndNoOfContainersAdded < 4) {
                            self.$finraAddAnotherCompanyBtn.removeClass('hidden');
                        } else if(countOfChkBoxesChkedAndNoOfContainersAdded >= 4) {
					        self.$finraAddAnotherCompanyBtn.addClass('hidden');
					        self.disableCheckboxes(self.selectWhichEmployerCheckboxes);
                        }

                        this.addDynamicLabels('finra-add-company');
                        self.checkForAddressMaxNumLimit(["finra-add-company-component"]);
					},
					handleAddingAnotherCompBtnClick: function () {
					    this.handleAddingAnotherCompany();
					    self.checkForAddressMaxNumLimit(["company"]);
					},
					handleAddingAnotherCompany: function (compData, launchMode) {
					    var launchModeVal = (launchMode == undefined) ? 'edit' : launchMode;
			            var getCountLength = self.getCount('company')+1;
			            var compReferenceNm = self.companyComponentNm.toLowerCase();
			            //var noOfCheckBoxesChecked = $('input[name=' + self.selectSameAsSectionCheckboxes + ']:checked').size();
		                //var countOfChkBoxesChkedAndNoOfContainersAdded = noOfCheckBoxesChecked + getCountLength;

			            newCompanyComponentCount++;

			            var componentViewOptions = {
			                "nestedViewName": "pt-temp-company-" + newCompanyComponentCount,
			                "compConstrParams": {
			                    el: self.$("#employer"),
			                    componentId: newCompanyComponentCount,
			                    componentName: 'Company',
			                    selectedAddrsType: '',
			                    count: getCountLength,
			                    compData: compData ? compData : null
			                },
			                "compType": compReferenceNm
			            }

			            self.renderMultipleEmployerTemplate(componentViewOptions, $('#company'), launchModeVal);

			            if (getCountLength < 4) {
			                    self.$addAnotherCompanyBtn.removeClass('hidden');
			            } else if (getCountLength >= 4) {
			                    self.$addAnotherCompanyBtn.addClass('hidden');
			                    self.disableCheckboxes(self.selectSameAsSectionCheckboxes);
			            }

			            this.addDynamicLabels('company');
			            return componentViewOptions.nestedViewName;
			        },
			        getCount: function (divId) {
			            return $('#' + divId + ' .pt-empcomp:visible').length;
			        },
			        afterRender: function () {
			            var $employmentContainer = $("#client-employement"),
                            $isEmployedContainer = $employmentContainer.find('div[data-for="is-employed"]'),
                            $isofficerContainer = $employmentContainer.find('div[data-for="is-officer"]'),
                            noCompanyErrorMessage = "At least one employer or company is required.",
                            $isEmployed = $('.emp-yes.active');
                            
						$('input[name="empStatus"]:checked').parent()
								.parent().addClass('active');
                        //If either "yes" clicked, hide radio buttons
						if ($isEmployed.length) {
							
						    //hide retired. hide other.
						    $('#ce-not-employed').hide().removeClass('active');
						    $('#not-employed').attr('checked', false);
							$('#ce-retired').hide().removeClass('active');
							$('#retired').attr('checked', false);
							$('#ce-other').hide().removeClass('active');
							$('#other').attr('checked', false);
		                }
						if (ClientModel.get('clientCreated') == 'failed') {
							Validator.validateInputs('client-employement', true);

		                var $priOccupationSelectBox = $("[pt-empcomp-prioccupation]");
		                if ($priOccupationSelectBox.val() == 'Other') {
		                    if ($("#pt-employer-prioccupation-other-1").val() == "") {
		                        $("[data-for='pt-employer-prioccupation-1']").addClass('error');
		                    }
		                }
						if (!$('#pt-emp-industry-other').hasClass('hidden')) {
							if ($('#pt-emp-industry-other-input').val().length == 0) {
								$('#emp-industry-classification').addClass('error');
								}
						}
						if(this.model.get("isEmployed") == "Yes"){
						    if (FINRAData.length === 0) {
						        $isEmployedContainer.addClass("error").find("label.error").removeClass("hidden").text(noCompanyErrorMessage);
						    }
						}
						if (this.model.get("isClientODSP") == "Yes") {
						    if (shareHolderData.length === 0) {
						        $isofficerContainer.addClass("error").find("label.error").removeClass("hidden").text(noCompanyErrorMessage);
						    }
						} 
					}
						
					},
					renderWhichEmployerSection: function (containerNm, sectionId, dataModel) {
					    var isEmployed = $('.is-employed').filter('.active').val();
					    var checkIsEmployedIsActive = (isEmployed != '' && isEmployed == 'Yes') ? true : false;
					    var countOfContainers = self.getCount('employer');
					    var sectionNmId = $("#" + sectionId); //#which-employer (or) #same-as-section
					    var firstEmployerNmInput = $("#pt-" + self.employerComponentNm.toLowerCase() + "-name-1");
					    var showSection = (countOfContainers > 0) ? true : false; //employer
					    var showFinraAddCompanySection = (countOfContainers >= 0) ? true : false,
					        showWhichEmployerChkbox = false;
					    for (var key in self.nestedViews) {
					        var view = self.nestedViews[key];
					        if (key.indexOf("pt-temp-employer") > -1) {
					            if (view.isTheAddressValid()) {
					                showWhichEmployerChkbox = true;
					                break;
					            }
					        }
					    }

					    if (checkIsEmployedIsActive) {
					        if (firstEmployerNmInput != "" && showSection) {
					            if (showWhichEmployerChkbox) {
					                //Show the container first then render the template inside that
					                sectionNmId.removeClass('hidden');
					            } else {
					                sectionNmId.addClass('hidden');
                                }
					            self.renderIsEmployerCheckBox(containerNm, sectionId, dataModel);
					        }
					        if (showFinraAddCompanySection) {
					            //Show the container first then render the template inside that
					            $('#finra-add-company-component').removeClass('hidden');
					        }
					    } else {
					        //Hide Finra Add Company
		                    $('#finra-add-company').empty(); //Clear off the content
		                    $('#finra-add-company-component').addClass('hidden'); //hide the parent container
		                    //Uncheck if anything is checked
		                    self.unCheckAllCheckBoxes(this.selectWhichEmployerCheckboxes);
		                    self.resetAllSelectedItems(this.employerDynamicCheckboxView);
					        sectionNmId.addClass('hidden');
					    }
					},
					renderSameAsSection: function (containerNm, sectionId, dataModel) {
					    var isOfficer = $('.is-officer').filter('.active').val();
					    var checkIsOfficerIsActive = (isOfficer != '' && isOfficer == 'Yes') ? true : false;
					    var countOfContainers = self.getCount('employer');
					    var sectionNmId = $("#" + sectionId); //#which-employer (or) #same-as-section
					    var firstEmployerNmInput = $("#pt-" + self.employerComponentNm.toLowerCase() + "-name-1");
					    var showSection = (countOfContainers > 0) ? true : false; //employer
					    var showSameAsAddCompanySection = (countOfContainers >= 0) ? true : false;

					    if (checkIsOfficerIsActive) {
					        if (firstEmployerNmInput != "" && showSection) {
					            if (!sectionNmId.is(':Visible') && sectionNmId.hasClass('hidden')) {
					                //Show the container first then render the template inside that
					                sectionNmId.removeClass('hidden');
					            }
					            self.renderOfficerSameAsCheckBox(containerNm, sectionId, dataModel);
					        }
					        if (showSameAsAddCompanySection) {
					            //Show the container first then render the template inside that
					            $('#company-component').removeClass('hidden');
					        }
					    } else {
		                    //Hide Same As Add Company
		                    $('#company').empty(); //Clear off the content
		                    $('#company-component').addClass('hidden'); //hide the parent container
		                    self.unCheckAllCheckBoxes(this.selectSameAsSectionCheckboxes);
		                    self.resetAllSelectedItems(this.companyDynamicCheckboxView);
					        sectionNmId.addClass('hidden');
					    }
					},
					reRenderDynamicChkboxSectionOnEmpAddressChange: function (employerAddressView, relatedModelRefId) {
					    var dynamicCheckboxViews = [this.getNestedView("employerDynamicCheckboxView"), this.getNestedView("companyDynamicCheckboxView")];
					    try{
					        _.each(dynamicCheckboxViews, function (dynamicCheckboxView) {
					            var checkboxItemCorspndngToEmpAddrsView,
                                slectedItems,
                                allItems,
                                isThisEmpAddrsChecked = false;
					            if (dynamicCheckboxView && dynamicCheckboxView.allItems && dynamicCheckboxView.allItems[index]) {
					                allItems = dynamicCheckboxView.allItems;
					                checkboxItemCorspndngToEmpAddrsView = allItems[index];
					                slectedItems = dynamicCheckboxView.allSelectedItems;
					                isThisEmpAddrsChecked = !!_.find(slectedItems, function (item) {
					                    return item.id == checkboxItemCorspndngToEmpAddrsView.id;
					                });
					            }
					            if (isThisEmpAddrsChecked) {
					                var itemIndex,
                                        selectedItem;
					                slectedItems = _.filter(dynamicCheckboxView.allSelectedItems, function (item) {
					                    return item.id != checkboxItemCorspndngToEmpAddrsView.id;
					                });
					                itemIndex = Number(checkboxItemCorspndngToEmpAddrsView.id.charAt(0));
					                dynamicCheckboxView.selectedItems = slectedItems;
					                dynamicCheckboxView.allSelectedItems = slectedItems;
					                selectedItem = dynamicCheckboxView.items[itemIndex];
					                dynamicCheckboxView.reRender();
					                //manually call the on change event
					                dynamicCheckboxView.itemSelectionComplete(slectedItems, itemIndex, selectedItem);
					            }
					        });
					    } catch (error) {
					        ErrorLog.ErrorUtils.myError(error);
					    }
					    this.renderWhichEmployerSection("employer", "which-employer");
					    this.renderSameAsSection("company", "same-as-section");
					        
					},
		            resetAllSelectedItems: function (dynamicCheckboxView) {
		                var getNestedCheckBoxView = this.getNestedView(dynamicCheckboxView);
		                if (getNestedCheckBoxView != undefined) {
		                    getNestedCheckBoxView.allSelectedItems = [];
		                    getNestedCheckBoxView.selectedIndexes = [];
		                    getNestedCheckBoxView.selectedItems = [];
		                }
		            },
		            getComponentIdForEmpCheckBoxes: function (chckBoxType) {
		                return (chckBoxType == "which-employer") ? "which-employer-checkboxes" : "same-as-section-checkboxes";
		            },
		            getValidEmployerOptions: function (chckBoxType) {
		                var nestedViews = this.nestedViews,
		                    isEmployer = (chckBoxType == "which-employer") ? true : false,
					        componentId = this.getComponentIdForEmpCheckBoxes(chckBoxType),
		                    employerCheckBoxOptions = [],
                            view,
					        employerName,
		                    checkBoxUiIndex = 0,
					        relatedEmployerModel,
                            companyModel = new EmpCompModel().toJSON();
		                for (var key in nestedViews) {
		                    view = nestedViews[key];
		                    if (key.indexOf("pt-temp-employer") > -1) {
		                        relatedEmployerModel = view.employerCompanyInfo;
		                        companyModel = $.extend(companyModel, _.omit(relatedEmployerModel, ["relatedModelRefId", "id"]));
		                        companyModel.relatedModelRefId = relatedEmployerModel.id;
		                        if (view.isTheAddressValid()) {
		                            employerName = view.employerCompanyInfo.employerName;
		                            employerCheckBoxOptions.push({
		                                description: isEmployer ? employerName : "Same as " + employerName,
		                                id: checkBoxUiIndex + "-" + componentId,
		                                empRefId: Number($(view.el).find(".pt-empcomp").attr("ui-index")),
		                                relatedModelRefId: companyModel.relatedModelRefId,
		                                modelId: companyModel.id
		                            });
		                            checkBoxUiIndex++;
		                        }
		                    }
		                }
		                return employerCheckBoxOptions;
		            },
		            getSelectedItemsFromViewForEmpCheckboxes: function (viewName, items) {
		                var view = this.getNestedView(viewName),
                            selectedItems = [];
		                if (view) {
		                    selectedItems = view.allSelectedItems;
		                } else {
		                    if(viewName == this.employerDynamicCheckboxView){
		                        selectedItems = this.getSelectedItemsForWhichEmplChkboxFromModel();
		                    }else{
		                        selectedItems = this.getSelectedItemsForIsOffcSameAsChkboxFromModel();
		                    }
		                }
		                for (var i = 0; i < items.length; i++) {
		                    for (var k = 0; k < selectedItems.length; k++) {
		                        if (items[i].relatedModelRefId === selectedItems[k].relatedModelRefId) {
		                            selectedItems[k] = items[i];
		                        }
		                    }
		                }
		                return selectedItems;
		            },
		            getSelectedItemsForWhichEmplChkboxFromModel: function () {
		                var selectedItems = [],
		                    finraSectionInfo = this.model.get('finraCheckbox');
		                if (finraSectionInfo != undefined && finraSectionInfo.finraCheck) {
		                    selectedItems = finraSectionInfo.finraSectionArr;
		                }
		                return selectedItems;
		            },
		            getSelectedItemsForIsOffcSameAsChkboxFromModel: function () {
		                var selectedItems = [],
		                    shareHolderInfo = this.model.get('shareHolderCheckbox');
		                if (shareHolderInfo != undefined && shareHolderInfo.sameAsCompanyCheck) {
		                    selectedItems = shareHolderInfo.sameAsCompanyArr;
		                }
		                return selectedItems;
		            },
		            isOfficerSameAsCheckboxChangeHandler: function (selectedItems, itemId, changedItem) {
		                var launchMode = 'view',
		                    count = 0,
                            mappedAddressViewName,
                            selectedItem,
		                    containerNm = self.getComponentIdForEmpCheckBoxes("is-officer");//"same-as-section-checkboxes"
		                    selectedItem = _.filter(selectedItems, function (item) {
		                        return item.id == (itemId + "-" + containerNm)
		                    });
		                count = self.getCount(containerNm);
		                if (selectedItem.length > 0 && count <4) {
		                    mappedAddressViewName = self.handleEventsOfSameAsSectionChkBox(selectedItems, changedItem.empRefId, launchMode);
		                    self.isOfficerCheckboxToCompViewMapping[changedItem.empRefId] = mappedAddressViewName;
		                    self.addDynamicLabels(containerNm);
		                    count = self.getCount(containerNm);
		                    if (count == 4) {
		                        $(this.getNestedView(this.companyDynamicCheckboxView).el)
                                    .find("input:not(:checked)")
                                    .attr('checked', false)
                                    .prop('disabled', true);
		                    }
		                } else {
		                    var correspondingCompAddressView = self.isOfficerCheckboxToCompViewMapping[changedItem.empRefId];
		                    if (!!correspondingCompAddressView) {
		                        self.getNestedView(correspondingCompAddressView).$el.remove();
		                        self.removeNestedView(correspondingCompAddressView); //pt-temp-company-1
		                        self.enableCheckboxes(self.selectSameAsSectionCheckboxes); //Enable checkbox if it is in disable mode
		                        self.addDynamicLabels(containerNm);
		                    }
		                    count = self.getCount(containerNm);
		                    if (count < 4) {
		                        self.enableAddButtons(containerNm);
		                    }
		                }
		                self.checkForAddressMaxNumLimit(["company"]);
		            },
		            whichEmployerCheckboxChangeHandler: function (selectedItems, itemId, changedItem) {
		                var containerNm = self.getComponentIdForEmpCheckBoxes("which-employer"),
                            selectedItem = _.filter(selectedItems, function (item) {
                                return item.id == (itemId + "-" + containerNm)
                            });
		                self.enableCheckboxes(self.selectWhichEmployerCheckboxes);

		                whichEmployerCount = self.getCount("finra-add-company");
		                sumOfWhichEmployerAndAddFinraCount = selectedItems.length + whichEmployerCount;

		                if (sumOfWhichEmployerAndAddFinraCount == 4) {
		                    self.disableCheckboxes(self.selectWhichEmployerCheckboxes);
		                    self.$finraAddAnotherCompanyBtn.addClass('hidden');
		                } else {
		                    whichEmployerCount = self.getCount("finra-add-company");
		                    sumOfWhichEmployerAndAddFinraCount = selectedItems.length + whichEmployerCount;
		                    if (sumOfWhichEmployerAndAddFinraCount < 4) {
		                        self.$finraAddAnotherCompanyBtn.removeClass('hidden');
		                    }
		                }
		                self.checkForAddressMaxNumLimit(["finra-add-company-component"]);
		            },
		            renderOfficerSameAsCheckBox: function (dataModel) {
		                var chckOptions = this.getValidEmployerOptions("is-officer"),
                            renderingOptions = {
		                        viewName: this.companyDynamicCheckboxView,
		                        items: chckOptions,
		                        elId: this.getComponentIdForEmpCheckBoxes("is-officer"),
		                        selectedItems: this.getSelectedItemsFromViewForEmpCheckboxes(this.companyDynamicCheckboxView, chckOptions),
		                        selectionChangeCallback: this.isOfficerSameAsCheckboxChangeHandler
		                    };
		                this.renderCheckBoxView(renderingOptions);
		                $('#which-employer-checkboxes input').removeClass('needed required-group');
		                //After render, append data-identifier attribute to Same As checkboxes
		                $.each(chckOptions, function (i, item) {
		                    $("#same-as-section-checkboxes input[pt-checkbox-button]:eq(" + i + ")").attr("data-identifier", chckOptions[i].empRefId);
		                });
		            },
		            renderIsEmployerCheckBox: function () {
		                var items = this.getValidEmployerOptions("which-employer"),
                            renderingOptions = {
		                        viewName: this.employerDynamicCheckboxView,
		                        items: items,
		                        elId: this.getComponentIdForEmpCheckBoxes("which-employer"),
		                        selectedItems: this.getSelectedItemsFromViewForEmpCheckboxes(this.employerDynamicCheckboxView, items),
		                        selectionChangeCallback: this.whichEmployerCheckboxChangeHandler
		                };
		                this.renderCheckBoxView(renderingOptions);
		                $('#which-employer-checkboxes input').removeClass('needed required-group');
		                if (items.length == 0) {
		                    self.resetSections("which-employer");
		                }
		            },
		            renderCheckBoxView: function (params /*viewName, items, elId, selectedItems, selectionChangeCallback, triggerOnPreselction-optional */) {
		                var checkboxView = new CheckBoxView({
		                    el: $('#' + params.elId),
		                    items: params.items
		                });
		                checkboxView.selectedItems = params.selectedItems;
		                checkboxView.itemSelectionComplete = params.selectionChangeCallback /*selectedItems, itemId, changedItem*/;
		                this.addNestedView(params.viewName, checkboxView);
		                checkboxView.render();
		            },
					disableCheckboxes: function (chkBoxName) {
					    $("input:checkbox[name="+chkBoxName+"]").each(function () {
                            if(!$(this).prop('checked')) {
                                $(this).prop('disabled', true)
                                       .closest('.radio-group-conatiner')
                                       .removeClass('active');
	                        }
	                    })
					},
					enableCheckboxes: function (chkBoxName) {
					    $("input:checkbox[name=" +chkBoxName+"]").each(function () {
					        if ($(this).prop('disabled')) {
					            $(this).prop('disabled', false)
					                   .closest('.radio-group-conatiner')
					                   .removeClass('active');
					        }
					    });
                    },
					enableAddButtons: function (containerNm) {
					    if (containerNm == 'employer') {
					        self.$addAnotherEmployerBtn.removeClass('hidden'); // Show 'Add another employer' btn
					    } else if (containerNm == 'company') {
					        self.$addAnotherCompanyBtn.removeClass('hidden'); // Show 'Add another company' btn
					    } else {
					        self.$finraAddAnotherCompanyBtn.removeClass('hidden'); // Show 'Add another company' finra btn
					    }
					},
					disableAddAnotherButton: function (sectionType) {
					    switch (sectionType) {
					        case "employer":
					            self.$addAnotherEmployerBtn.addClass('hidden'); // Show 'Add another employer' btn
					            break;
					        case "company":
					            self.$addAnotherCompanyBtn.addClass('hidden'); // Show 'Add another company' btn
					            break;
					        case "finra-add-company-component":
					            self.$finraAddAnotherCompanyBtn.addClass('hidden'); // Show 'Add another company' finra btn
					            break;
					        default:
					            break;
					    }
					},
					checkForAddressMaxNumLimit: function (sectionTypes /*employer, company, finra-add-company-component*/) {
					    var maxAddrssCount = 4;
					    _.each(sectionTypes, function (sectionType) {
					        var addrsCompCount = self.getCount(sectionType),
                            enableDisableChkbox = false,
					        chkboxNm,
                            sectionEnabled = false;
					        switch (sectionType) {
					            case "employer":
					                sectionEnabled = true;
					                break;
					            case "company":
					                sectionEnabled = self.$shareHolderContainer.is(":visible");
					                enableDisableChkbox = true;
					                chkboxNm = self.selectSameAsSectionCheckboxes;
					                break;
					            case "finra-add-company-component":
					                sectionEnabled = self.$finraContainer.is(":visible");
					                addrsCompCount += $('input[name=' + self.selectWhichEmployerCheckboxes + ']:checked').length;
					                enableDisableChkbox = true;
					                chkboxNm = self.selectWhichEmployerCheckboxes;
					                break;
					            default:
					                break;
					        }
					        if (sectionEnabled) {
					            if (addrsCompCount < maxAddrssCount) {
					                self.enableAddButtons(sectionType);
					                if (enableDisableChkbox) {
					                    self.enableCheckboxes(chkboxNm);
					                }
					            } else {
					                self.disableAddAnotherButton(sectionType);
					                if (enableDisableChkbox) {
					                    self.disableCheckboxes(chkboxNm);
					                }
					            }
					        }
					    });
					    
					},
                    //"Is client employed.." button [YES/NO] button toggle
					toggleEmployed: function (obj) {
					    var _$clickedButton = $(obj.currentTarget),
					        $finarComponent = $('#finra-add-company-component');
					    var _btnTxt = _$clickedButton.text();
					    var isOfferToggleButton = $('.is-officer').filter('.active').text();
					    if (isOfferToggleButton == 'Yes') { ofcBtn = 'Y'; } else { ofcBtn = 'N'; }

						$('.is-employed').removeClass('active');
						_$clickedButton.addClass('active');
						if (_btnTxt == 'Yes') { empBtn = 'Y'; } else { empBtn = 'N'; }
    		            if (_btnTxt === 'Yes' && empBtn === 'Y') {
    		                $('#ce-not-employed').hide().removeClass('active');
    		                $('#not-employed').attr('checked', false);
    		                //hide retired. hide other.
    		                $('#ce-retired').hide().removeClass('active');
    		                $('#retired').attr('checked', false);
    		                $('#ce-other').hide().removeClass('active');
    		                $('#other').attr('checked', false);

    		                //Reset the counter
    		                newFinraCompanyComponentCount = 0;

    		                //If Add button is hidden, make it visible
    		                if (self.$finraAddAnotherCompanyBtn.hasClass('hidden') && self.isEmployedOrSelfEmployedChecked()) {
    		                    self.$finraAddAnotherCompanyBtn.removeClass('hidden');
    		                }
    		                //Show or Hide 'Which Employer' Section
    		                if (self.isEmployedOrSelfEmployedChecked()) {
    		                    self.renderWhichEmployerSection("finra-add-company", "which-employer");
    		                }
    		            }
    		            else //when "client employed" is "no"
    		            {
    		                //show when switch back to no
    		                $('#ce-not-employed, #ce-retired, #ce-other').show();
    		                if (!(isOfferToggleButton === 'Yes' && ofcBtn === 'Y')) {
    		                    $('.is-employed-alert').addClass('clientofficer-status-hide');
    		                }
					    }

    		            if (_btnTxt === 'Yes') {
    		                $finarComponent.removeClass('hidden');
    		                $('.is-employed-alert').removeClass('clientofficer-status-hide');
    		            } else {
    		                $('.is-employed-alert').addClass('clientofficer-status-hide');
    		                $finarComponent.addClass('hidden');
    		                self.clearWhichEmployerRelatedViewsAndData();
                        }						
					},
                    //"Is the client an officer.." [YES/No] button
					toggleOfficer: function (obj) {
						var _$clickedButton = $(obj.currentTarget);
						var companyComponentId = $("#company-component");

						if (_$clickedButton.hasClass('active')) {
							return false;
						} else {
						    var _btnOfcTxt = _$clickedButton.text();
						    var isEmployedToggleButton = $('.is-employed').filter('.active').text();
						    if (isEmployedToggleButton == 'Yes') { empBtn = 'Y'; } else { empBtn = 'N'; }

						    $('.is-officer').removeClass('active');
						    _$clickedButton.addClass('active');
							if (_btnOfcTxt == 'Yes') { ofcBtn = 'Y'; } else { ofcBtn = 'N'; }
						    //if ((_btnOfcTxt === 'Yes' && ((empBtn === 'Y' && ofcBtn === 'Y') || (empBtn === 'N' && ofcBtn === 'Y') || (empBtn === '' && ofcBtn === 'Y'))) || (_btnOfcTxt === 'No' && empBtn === 'Y')) {
							if (_btnOfcTxt === 'Yes' && ofcBtn === 'Y') {
							    //$('#ce-retired, #ce-other').removeClass('active').hide();
							    //$('#retired, #other').attr('checked', false);
							    companyComponentId.removeClass('hidden');
							    //Reset the counter
							    newCompanyComponentCount = 0;
							    self.$addAnotherCompanyContainer.removeClass('hidden');
							    self.renderSameAsSection("company", "same-as-section");
							    
							} else {
							    ////show when switch back to no
							    if (isEmployedToggleButton === 'Yes' && empBtn === 'Y') {
							        $('#ce-not-employed, #ce-retired, #ce-other').hide();
							    } else {
							        $('#ce-not-employed, #ce-retired, #ce-other').show();
							    }
							    
                                if (companyComponentId.is(':Visible') && !companyComponentId.hasClass('hidden')) {
			                        //Show the container first then render the template inside that
							        companyComponentId.addClass('hidden');
                                }
                                self.clearIsOfficerRelatedViewsAndData();
							}
						}
						
						
                },
				isEmployedOrSelfEmployedChecked: function () {
				    //Check if Employed and Self Employed are checked or not
				    var isEmployedChecked = $('input[name="empStatus"]#employed').prop('checked');
				    var isSelfEmployedChecked = $('input[name="empStatus"]#self-employed').prop('checked');
				    return (isEmployedChecked || isSelfEmployedChecked);
				},
				isNotEmployedChecked: function () {
				    return $('#not-employed').prop('checked');
				},
		        navigateToStep4: function () {
		            //this.captureData();
		            $('.ncst-step.step4').find('.step-nav-links').click();
		        },
		        navigateToStep6: function () {
		            if (this.modelSaver()) {
		                $('.ncst-step.step6').find('.step-nav-links').click();
		            }
					},
		        captureData: function () {
		            employmentData = [], FINRAData = [], finraCheckbox = {}, shareHolderData = [], shareHolderCheckbox = {};
						employmentData.length = 0, FINRAData.length = 0,  shareHolderData.length = 0;
						for (var key in this.nestedViews) {
							if (key.indexOf("pt-temp") > -1) {
								var nestedViewName = this.nestedViews[key];
								switch (nestedViewName.componentName) {
									case 'Employer':
										employmentData.push(nestedViewName.employerCompanyInfo);
										break;
									case 'finra':
										FINRAData.push(nestedViewName.employerCompanyInfo);
										break;
								    case 'Company':
										shareHolderData.push(nestedViewName.employerCompanyInfo);
										break;
									default: break;
								}
							}
						
							if (key.indexOf("employerDynamicCheckboxView") > -1) {
								finraCheckbox["finraCheck"] = true;
								var selectedItemArr = this.nestedViews[key].allSelectedItems;
								finraCheckbox["finraSectionArr"] = selectedItemArr;
								_.each(selectedItemArr, function (list) {
									var index = parseInt(list.id);
								    var cloneEmpData = employmentData[index],
                                        refId = cloneEmpData.id,
								        finraDat = $.extend({}, _.omit(cloneEmpData, ["relatedModelRefId", "id"]));
								    finraDat.relatedModelRefId = refId;
								    finraDat.doNotDisplay = true;
									FINRAData.push(finraDat);
								});
							} 
						
							if (key.indexOf("companyDynamicCheckboxView") > -1) {
								shareHolderCheckbox["sameAsCompanyCheck"] = true;
								//shareHolderCheckbox["sameAsCompanyArr"] = this.nestedViews[key].allSelectedItems;
								var selectedItemArr = this.nestedViews[key].allSelectedItems;

								//if (selectedItemArr.length == 0 || selectedItemArr) {
								//	var sameAsCheckboxArr = [];
								//	var sameAsLen = $('#same-as-section-checkboxes .checkbox-group > div').length;
								//	for (i = 0; i < sameAsLen; i++) {
								//		var sameAsCheckboxId = i + '-same-as-section-checkboxes';
								//		if ($('#' + sameAsCheckboxId).parents().eq(1).hasClass('active') == true) {
								//			sameAsCheckboxArr.push({
								//				"description": $('#' + sameAsCheckboxId).val(), "id": sameAsCheckboxId
								//			});
								//		}
								//	}
								//	shareHolderCheckbox["sameAsCompanyArr"] = selectedItemArr = sameAsCheckboxArr;
								//} else {
								//	shareHolderCheckbox["sameAsCompanyArr"] = selectedItemArr;
							    //}
								shareHolderCheckbox["sameAsCompanyArr"] = selectedItemArr;

							}
						}
					},
					modelSaver: function () {
					    if (this.model.validate(true)) {
					        this.captureData();
					        this.model.setModel(employmentData, FINRAData, finraCheckbox, shareHolderData, shareHolderCheckbox);
					        this.model.setCompletionStatus(Validator.checkforMandatoryFields('client-employement') && this.customModelValidation());
					        return true;
					    }
					},
					customModelValidation: function () {
					    var isFIRAValid = true,
                            isShareHolderValid = true;
					    if (this.model.get("isEmployed") == "Yes") {
					        if (FINRAData.length == 0) {
					            isFIRAValid = false;
                            }
					    }
					    if (this.model.get("isClientODSP") == "Yes") {
					        if (shareHolderData.length == 0) {
					            isShareHolderValid = false;
					        }
					    }
					    return isShareHolderValid && isFIRAValid;
					},
					handleBlurEvntOnEmployerName: function () {
					    var getCountOfEmployers = self.getCount('employer');
					    if (getCountOfEmployers >= 1) {
					        self.renderWhichEmployerSection("employer", "which-employer");
					        self.renderSameAsSection("company", "same-as-section");
					    } else {
					        //Reset Sections
					        //this.resetSections("company-component", "company");
					        this.resetSections("which-employer");
					        this.resetSections("same-as-section");
					        //this.resetSections("finra-add-company-component");

					        //Reset Buttons
					        //this.resetButtons("is-employed");
					        //this.resetButtons("is-officer");
					    }
					},
					handleEmpStatusChange: function (el) {
					    employmentData = [], FINRAData = [], finraCheckbox = {}, shareHolderData = [], shareHolderCheckbox = {};
						employmentData.length = 0, FINRAData.length = 0, shareHolderData.length = 0;
					    var empStatusEleId = el.currentTarget.id;
					    var employerComponentId = $("#employer-component"),
					        notEMployed = empStatusEleId == "not-employed",
                            isEmplyedOrSelfEmployed = empStatusEleId == "employed" || empStatusEleId == "self-employed",
					        clearFinraViews = !isEmplyedOrSelfEmployed;
					    //if (empStatusEleId == "employed" || empStatusEleId == "self-employed" || empStatusEleId == "not-employed") {
					            this.clearSameAsAndWhichEmployerCheckBoxViews(clearFinraViews);
					            this.resetSections("employer-component", "employer");
					            this.resetSections("which-employer");
					            if (isEmplyedOrSelfEmployed && !employerComponentId.is(':Visible') && employerComponentId.hasClass('hidden')) {
					            //Show the container first then render the template inside that
					            var $employerComps = $("#employer").find(">div");
					            employerComponentId.removeClass('hidden');
					            //Render Employer Template
					            this.renderEmployerCompView(undefined, 0/*rendering the first emp address component, so index is 0*/);
					            
					        }
					    //}

					    //else {
					    //    //Reset Sections & New Employer Component Counter
					    //    if (this.nestedViews.length == 0) {
					    //        newEmployerComponentCount = 0;
					    //    }
					    //    this.clearNestedViews();
                        //    this.resetSections("employer-component", "employer");
                        //    this.resetSections("company-component", "company");
                        //    this.resetSections("which-employer");
                        //    this.resetSections("same-as-section");
					    //}
					    if (empStatusEleId == "self-employed") {
					    	$('#emp-industry-classification').removeClass('hidden');
					    	CommonUtility.loadSelectbox(["#pt-emp-select-industry"], Constants.industryClassifications);
					    } else {
					    	$('#emp-industry-classification, #pt-emp-industry-other').addClass('hidden');
					    }
						ClientModel.set('stepsCompleted', Utils.arraySplice(ClientModel.get('stepsCompleted'), 'income'));
						$('.ncst-step.step6').removeClass('active pending finished');
						if (this.model.get('isNotFirstLaunch')) {
							IncomeModel.clear().set(IncomeModel.defaults);
					    }
						this.model.set('isNotFirstLaunch', true);
						self.checkForAddressMaxNumLimit(["employer", "company", "finra-add-company-component"]);
					},
					resetButtons: function ($elId) {
		            var $ToggleBtn = $("div[data-for=" + $elId + "] button.toggle-button");
					    if ($ToggleBtn.hasClass('active')) {
					        $ToggleBtn.removeClass('active');
					    }
                    
		            if ($elId == 'is-employed') {
					        $('.is-employed-alert').addClass('clientofficer-status-hide');
					    }

					},
					clearSameAsAndWhichEmployerCheckBoxViews: function (clearFinraViews) {
					    var nestedViews = this.nestedViews,
					        nestedViewNames;
					    for (key in nestedViews) {
					        if (key.indexOf("pt-temp-employer") > -1) {
					            this.removeNestedView(key);
                            }
					    }
					    for (key in nestedViews) {
					        if (key.indexOf("pt-temp-company") > -1 && nestedViews[key].launchMode=="view") {
					            nestedViews[key].$el.find('.cancel-the-section-btn').click();
					            //nestedViews[key].removeFromDom();
					        }
					    }
					    for (key in nestedViews) {
					        if (key.indexOf("pt-temp-company") > -1 && nestedViews[key].launchMode == "view" || clearFinraViews && key.indexOf("pt-temp-finra") > -1) {
					            this.removeNestedView(key);
					        }
					    }
                        
					    var sameAsCheckboxView = this.getNestedView(this.companyDynamicCheckboxView),
                            whichEmployerChkboxView = this.getNestedView(this.employerDynamicCheckboxView);
					    if (sameAsCheckboxView) {
					        this.removeNestedView(this.companyDynamicCheckboxView);
					    }
					    if (whichEmployerChkboxView) {
					        this.removeNestedView(this.employerDynamicCheckboxView);
					    }
					},
					clearIsOfficerRelatedViewsAndData: function () {
					    var nestedViews = this.nestedViews,
					        sameAsCheckboxView, 
					        empModel = ClientModel.get("employement");
					    for (key in nestedViews) {
					        if (key.indexOf("pt-temp-company") > -1) {
					            nestedViews[key].$el.find('.cancel-the-section-btn').click();
					        }
					    }
					    for (key in nestedViews) {
					        if (key.indexOf("pt-temp-company") > -1) {
					            this.removeNestedView(key);
					        }
					    }
					    sameAsCheckboxView = this.getNestedView(this.companyDynamicCheckboxView);
					    if (sameAsCheckboxView) {
					        this.removeNestedView(this.companyDynamicCheckboxView);
					    }
					    this.resetSections("company-component", "company");
					    //clear is officer related model
					    empModel.set('shareHolderAddrCollection', undefined);
					    empModel.set('shareHolderCheckbox', undefined);
					},
					clearWhichEmployerRelatedViewsAndData: function () {
					    var nestedViews = this.nestedViews,
					        whichEmployerChkboxView,
					        empModel = ClientModel.get("employement");
					    for (key in nestedViews) {
					        if (key.indexOf("pt-temp-finra") > -1) {
					            nestedViews[key].$el.find('.cancel-the-section-btn').click();
					            this.removeNestedView(key);
					        }
					    }
					    whichEmployerChkboxView = this.getNestedView(this.employerDynamicCheckboxView);
					    if (whichEmployerChkboxView) {
					        this.removeNestedView(this.employerDynamicCheckboxView);
					    }
					    this.resetSections("finra-add-company-component", "company");
					    this.resetSections("which-employer");
					    //clear is which employer related model
					    empModel.set('FINRAAddrCollection', undefined);
					    empModel.set('finraCheckbox', undefined);
					},
					resetSections: function (hideSection, clearElements) {
					    var $hideSectionDiv = $("#" + hideSection);
					    var $emptyInsideContent = $("#" + clearElements);

					    if (!$hideSectionDiv.hasClass('hidden')) {
					        if (clearElements != '' || clearElements != undefined) {
					            $emptyInsideContent.empty();
					        }
					        $hideSectionDiv.addClass('hidden');
					    }
                    },
		        handlerForCancel: function () {
						BootstrapDialog
								.confirm(
										"Cancel",
										"All your work will be lost.  Are you sure you want to cancel?",
                                    function (confirm) {
											if (confirm) {
												window.open('', '_self');
												window.close();
											}
										});

					}
				});
			return employmentView;
		});