'use strict';

<<<<<<< HEAD
function messages($translateProvider) {
    $translateProvider.translations('en_US', {
        //InstantReport Types
        COMM_DETAILS: 'Commission Details',
        INVESTOR_DETAILS: 'Investor Details',
        SPECIAL_PRODUCTS: 'Special Products',
        TRANSACTION_DETAILS: 'Transaction Details',
        ACC_STMTS_LIMIT: 'Maximum 10 Folio\'s can be selected at a time',
        ACC_STMT_DATE_RANGE_ERR: 'StartDate should be less than or equal to EndDate',
        ACC_STMT_NO_DATA_ERR_MSG: 'No Results were found, Please try again.',
        ACC_STMT_INVALID_KEY: 'The entered format of keyword is incorrect, Please try again',
        SEARCH_RESULTS: 'Search Results',

        //Frequency filter options
        ONE_MONTH: '1 Month',
        THREE_MONTHS: '3 Months',
        ONE_YEAR: '1 Year',
        PERIOD: 'Period',

        //Instant reports buttons
        EMAIL_REPORTS: 'Email Reports',
        NEXT: 'Next',
        RESET: 'Reset',

        //login
        TERMS_N_CONDITION_ONLINE_ADV: 'I/We have read and accept all the online adviser ',
        TERMS_N_CONDITION_ONLINE_INV: 'I/We have read and accept all the online investor ',
        TERMS_N_CONDITION_INV: 'I/We have read and accepted all the ',
        SCHEME_INFORMATION_DOCUMENTS: 'Scheme Information Documents',
        TERMS_N_CONDITION_TEXT: 'Terms & Conditions.',
        OTP_TEXT: 'One time Password (OTP) has been sent to your registered email/Mobile no.',
        WARNING_TEXT: 'Kindly note that this code will be valid for the next 20 minutes only.',
        RESEND_OTP_TEXT: 'Resend  OTP?',
        SUBMIT_TEXT: 'Submit',
        CONTINUE_TEXT: 'Continue',
        TERMS_AND_CONDITIONS: 'Terms and Conditions',
        I_ACCEPT: 'I Accept',
        I_DONOT_ACCEPT: 'I do not Accept',
        SUBMIT_USER: 'Submit',
        MY_ACCOUNT: 'My Account',
        //Instant reports accordion label
        SELECTED: 'Selected',
        CLICK_HERE: 'Click here to ',
        LOGIN: 'Login',
        INVESTOR_TEXT: 'I\'m an Investor',
        ADVISOR_TEXT: 'I\'m an  Adviser',
        PLEASE_ENTER_YOUR_TEXT: 'Please enter your',
        AND_TEXT: 'and',
        OTP_TEXT_AFTER_GETTINGOTP: 'Please enter your One Time Password (OTP):',
        ENTER_SECURITY_QUESTION: 'Please enter your Answer to secret Question',
        CHOOSE_OPTION: 'Choose either options to retrieve your username ',
        ANSWER_QUESTION: 'Answer Secret Question ',
        SEND_OTP: 'Send One Time Password (OTP)',
        OR: 'OR',
        SELECT_SECURITY_QUESTION: 'Please Enter the Valid Security Answer',
        ARN_VALIDATION_TEXT: 'ARN field cannot be empty',
        USERNAME_VALIDATION_TEXT: 'Username field cannot be empty',
        OTP_VALIDATION_TEXT: 'Please Enter OTP',
        ENTER_OTP: 'Please enter OTP',
        ENTER_PAN_FORUN: 'Please enter Pan',
        ENTER_ARN_REGISTRATION_DATE: 'Please enter ARN registration date',
        ENTER_DOB: 'Please enter date of birth',
        CHOOSE_OPTIONS: 'Choose either options to retrieve your password',
        VIEW_ALL_RECOMMENDATIONS_TEXT: 'View All Recommendations',
        VIEW_ALL_NOTIFICATIONS_TEXT: 'View All Notifications',

        //common notification events
        NOTIFI_CLICKED_TEXT: 'noticlicked',
        RECOM_CLICKED_TEXT: 'recomclicked',
        NOTIFICATION_CLICKED_TEXT: 'notificationClicked',
        RECOMMENDATION_CLICKED_TEXT: 'recommendationClicked',

        //advisor components
        RECOMM_CLICK_FOR_DETLS_TEXT: 'recmmonClickFrDtls',

        //Investor Module Message Translatables
        SMART_SAVINGS_ACCOUNT: 'Smart Savings Account',
        ONE_TOUCH_INVEST: 'One Touch Invest',


        // Advisor Registration
        LOGIN_USER_NAME_FORMAT: 'Username should contain a minimum of 6 characters',

        //Header Search
        HEADER_SEARCH_RESULTS: 'Search Results',
        HEADER_VIEW_ALL: 'View All',
        HEADER_SEARCH_RESULTS_SUGGESTION_FIRST: 'Search results for',
        HEADER_SEARCH_RESULTS_SUGGESTION_LAST: 'in Page results',
        HEADER_FUND_RESULTS: 'Funds',

        //SWP Flow
        SWP_INST_START: 'Installments can start on any business day only after 7 days from today',
        SWP_MIN_INST: 'Minimum 6 installments',
        HEADER_SMART_RESULTS: 'Family Solutions',
        HEADER_NO__RESULTS: 'No Results found for',
        TXT_FOR_EXT_PAYMENT_MANDATE: 'Your existing physical & electronic auto debit (NACH / E Mandate) mandate instructions are available here for you to choose from while investing.',
        TXT_FOR_NET_BANKING: 'Invest via net banking from our list of pre-registered banks. Do refer to the T&Cs for the complete list of banks. If your registered bank is not there in this list, we request you to choose another mode of payment',
        TXT_FOR_NEW_E_MANDATE: 'We have tied up with select banks for you to register online for auto debit instructions.  This gives you greater convenience and flexibility as you may register once and invest anytime using this mandate. You bank may charge you a nominal non-refundable fee of Re.1/- or Rs. 5/- per registration.',
        TXT_FOR_AUTO_DEBIT: 'You may choose to register a one-time mandate using this option. Do note that the amount that you enter for the mandate should be equal to or more than the investment amount. Once you complete the transaction, we will send a pre-filled form to your email ID. You would have to submit the duly filled form at any of our investor service centers for processing. Kindly note that this is a paper based transaction unlike the convenient online methods stated above.',
        TXT_FOR_BILL_PAY: 'This is an online option available for popular banks. You need to register FT as a biller using a unique registration number which we will provide on completion of your online transaction.'
    });
=======
function messages ($translateProvider) {
    $translateProvider.translations('en_US',{
    	//InstantReport Types
		COMM_DETAILS : 'Commission Details',
		INVESTOR_DETAILS : 'Investor Details',
		SPECIAL_PRODUCTS : 'Special Products',
		TRANSACTION_DETAILS : 'Transaction Details',
		ACC_STMTS_LIMIT : "Maximum 10 Folio's can be selected at a time",
		ACC_STMT_DATE_RANGE_ERR : "StartDate should be less than or equal to EndDate",
		ACC_STMT_NO_DATA_ERR_MSG : 'No Results were found, Please try again.',
		ACC_STMT_INVALID_KEY : 'The entered format of keyword is incorrect, Please try again',
		SEARCH_RESULTS : 'Search Results',

		//Frequency filter options
		ONE_MONTH : '1 Month',
		THREE_MONTHS : '3 Months',
		ONE_YEAR : '1 Year',
		PERIOD : 'Period',

		//Instant reports buttons
		EMAIL_REPORTS : 'Email Reports',
		NEXT : 'Next',
		RESET : 'Reset',

		//login
		TERMS_N_CONDITION_ONLINE_ADV:'I/We have read and accept all the online ',
		TERMS_N_CONDITION_ONLINE_INV:'I/We have read and accept all the online investor ',
		TERMS_N_CONDITION_INV:'I/We have read and accepted all the ',
		SCHEME_INFORMATION_DOCUMENTS: 'Scheme Information Documents',
		TERMS_N_CONDITION_TEXT:'Terms & Conditions.',
		OTP_TEXT:'One time Password (OTP) has been sent to your registered email/Mobile no.',
		WARNING_TEXT:'Kindly note that this code will be valid for the next 20 minutes only.',
		RESEND_OTP_TEXT:'Resend  OTP?',
		SUBMIT_TEXT:'Submit',
		CONTINUE_TEXT:'Continue',
		TERMS_AND_CONDITIONS_REGISTER:'Terms and Conditions',
		I_ACCEPT:'I Accept',
		I_DONOT_ACCEPT:'I do not Accept' ,
		SUBMIT_USER:'Submit', 
		MY_ACCOUNT : 'My Account',
		//Instant reports accordion label
		SELECTED : 'Selected',
		CLICK_HERE : 'Click here to ',
		LOGIN : 'Login',
		INVESTOR_TEXT:"I'm an Investor",
		ADVISOR_TEXT:"I'm an  Adviser",
		PLEASE_ENTER_YOUR_TEXT:'Please enter your',
		AND_TEXT:'and',
		OTP_TEXT_AFTER_GETTINGOTP:'Please enter your One Time Password (OTP):',
		ENTER_SECURITY_QUESTION : 'Please enter your Answer to secret Question',
		CHOOSE_OPTION : 'Choose either options to retrieve your username ',
		ANSWER_QUESTION : 'Answer Secret Question ',
		SEND_OTP : 'Send One Time Password (OTP)',
		OR:'OR',
		SELECT_SECURITY_QUESTION : 'Please Enter the Valid Security Answer',
		ARN_VALIDATION_TEXT:'ARN/RIA Code field cannot be empty',
		USERNAME_VALIDATION_TEXT:'Username field cannot be empty',
		OTP_VALIDATION_TEXT:'Please Enter OTP',
		ENTER_OTP:'Please enter OTP',
		ENTER_PAN_FORUN:'Please enter Pan',
		ENTER_ARN_REGISTRATION_DATE:'Please enter ARN/RIA Registration date',
		ENTER_DOB:'Please enter date of birth',
		CHOOSE_OPTIONS: 'Choose either options to retrieve your password',
		VIEW_ALL_RECOMMENDATIONS_TEXT:'View All Recommendations',
		VIEW_ALL_NOTIFICATIONS_TEXT:'View All Notifications',

		//common notification events
		NOTIFI_CLICKED_TEXT:'noticlicked',
		RECOM_CLICKED_TEXT:'recomclicked',
		NOTIFICATION_CLICKED_TEXT:'notificationClicked',
		RECOMMENDATION_CLICKED_TEXT:'recommendationClicked',

		//advisor components
		RECOMM_CLICK_FOR_DETLS_TEXT:'recmmonClickFrDtls',
		INV_SEARCH_ERROR:'No results found. Please try searching with another criteria',
		//Investor Module Message Translatables
		SMART_SAVINGS_ACCOUNT:'Smart Savings Account',
		ONE_TOUCH_INVEST: 'One Touch Invest',


		// Advisor Registration
		LOGIN_USER_NAME_FORMAT : 'Username should contain a minimum of 6 characters',

		//Header Search
        HEADER_SEARCH_RESULTS : 'Search Results',
        HEADER_VIEW_ALL : 'View All',
        HEADER_SEARCH_RESULTS_SUGGESTION_FIRST : 'Search results for',
        HEADER_SEARCH_RESULTS_SUGGESTION_LAST : 'in Page results',
        HEADER_FUND_RESULTS : 'Funds',

		//SWP Flow
		SWP_INST_START : 'Installments can start on any business day only after 7 days from today',
        SWP_MIN_INST: 'Minimum 6 installments',
        HEADER_SMART_RESULTS : 'Family Solutions',
        HEADER_NO__RESULTS : 'No Results found for',
		TXT_FOR_EXT_PAYMENT_MANDATE : 'Your existing physical & electronic auto debit (NACH / E Mandate) mandate instructions are available here for you to choose from while investing.',
		TXT_FOR_NET_BANKING: 'Invest via net banking from our list of pre-registered banks. Do refer to the T&Cs for the complete list of banks. If your registered bank is not there in this list, we request you to choose another mode of payment',
		TXT_FOR_NEW_E_MANDATE: 'We have tied up with select banks for you to register online for auto debit instructions.  This gives you greater convenience and flexibility as you may register once and invest anytime using this mandate. You bank may charge you a nominal non-refundable fee of Re.1/- or Rs. 5/- per registration.',
		TXT_FOR_AUTO_DEBIT: 'You may choose to register a one-time mandate using this option. Do note that the amount that you enter for the mandate should be equal to or more than the investment amount. Once you complete the transaction, we will send a pre-filled form to your email ID. You would have to submit the duly filled form at any of our investor service centers for processing. Kindly note that this is a paper based transaction unlike the convenient online methods stated above.',
		TXT_FOR_BILL_PAY: 'This is an online option available for popular banks. You need to register FT as a biller using a unique registration number which we will provide on completion of your online transaction.',
		RESET_PWD:'Reset Password',
		ENT_CURR_PWD:'Enter current password',
		ENT_NEW_PWD:'Enter new password',
		ENT_CON_NEW_PWD:'Enter confirm new password',
		CONF_PWD_NOT_MAT:'The Confirm Password field does not match New Password, Please try again',
		CANCEL:'Cancel',
		RST_PWD_TOOL_TIP:'8 - 12 characters with at least 1 alphabet and 1 Numeric and 1 capital letter',
		RST_PWD_MSG:'For security reasons, your password expires on regular intervals. Your password has now expired. Please reset your password.',
		ALREADY_EXISTING_INVESTOR_SS: 'The entered PAN is already your existing Investor. Kindly choose existing Investor option in Plan a Smart Solutions.',
		CONSENT_TEXT:'I / We hereby give you my/our consent to share/provide the transactions data feed/portfolio holdings/ NAV etc. in respect of my/our investments under Direct Plan of all Schemes managed by you, to the SEBI-Registered Investment Adviser whose code is mentioned herein.'
	});
>>>>>>> ftic-inv-sprint6

    /* Determine automatically the preferred language based on users window.navigator object */
    $translateProvider.determinePreferredLanguage();

    /*If a translation id is not present in the particular language translation table, angular-translate
    will search for it in the registered fallback language i.e english translation table */
    $translateProvider.fallbackLanguage('en_US');

    $translateProvider.useSanitizeValueStrategy('sanitize');
}

messages.$inject = ['$translateProvider'];
module.exports = messages;