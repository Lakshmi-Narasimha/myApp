﻿define([
    'jquery',
    'appcommon/applauncher/appregistration',
    'underscore',
    'appcommon/globalcontext',
    'appcommon/applauncher/message',
    'config'], function ($, AppRegistration, _, Context, Message,Config) {
    var additionalParams;
    function processmessage(e) {

        if (e.preventDefault) { e.preventDefault(); }
        else { e.returnValue = false; }

        if (!_.contains(Config.urlWhiteList, e.origin))
            return;
        if (e.data == undefined)
            return
        //deserialize the json message to object
        var recievedMessage = JSON.parse(e.data);

        //If context is sent to applauncher to be passed on to target app 
        if (recievedMessage.Type == "LaunchApplication") {
            var appInfo = AppRegistration.GetAppInfo(recievedMessage.TargetApp.Id);
            var route = recievedMessage.TargetApp.Resource;
            triggerNavigation(route, "launchAction");
        }
        else if (recievedMessage.Type == "GetContextRequest") {
            var globalContext = Context.getInstance().getGlobalContext();
            if (globalContext != undefined) {
                var message = buildContextResponseMessage(location.hash.substring(1), globalContext.Context);
                additionalParams = null; //reset additional params
                e.source.postMessage(JSON.stringify(message), e.origin);
            }
        }
        else {
            var message = new Message.ErrorNotification("Request Type not supported", e.data);
            e.source.postMessage(JSON.stringify(message), e.origin);
        }
    };

    var buildContextResponseMessage = function (originUrl, currentContext) {
        if (originUrl == undefined)
            return;
        var contextRequired = AppRegistration.GetAppContextByRouteName(originUrl);
        if (contextRequired == undefined)
            throw new Error('Requestor origin not supported');
        var message;
        var context = new Object();
        switch (contextRequired) {
            case 'contact':
                context.ContactId = currentContext.ContactId;
                context.ContactType = currentContext.ContactType;
                context.ContactSource = currentContext.ContactSource;
                break;
            case 'group':
                context.GroupId = currentContext.GroupId;
                break;
            case 'user':
                break;
            case 'advisor':
                break;
            default:
                context = currentContext;
                break;
        }
        message = new Message.GetContextResponse(context);
        return message;
    };
    var triggerNavigation = function (route, type,eventType) {
        if (route == undefined)
            return;
        if (type == undefined)
            return;
        $.event.trigger({
            type: type,
            message: route,
            time: new Date(),
            data: eventType
        });
    };

    var GetTargetAppUrl = function (routerName) {
        var appInfo = AppRegistration.GetAppInfoByRouteName(routerName)
        return AppRegistration.GetTargetURLByRouteName(appInfo, routerName);

    };

    var VerifyAdditionalParams = function (params) {
        var verified = false;
        var returnURL;
        var appInfo = AppRegistration.GetAppInfo(params.appid);
        if (verified === true) {
            returnURL = appInfo.targeturl;
        }
        return { Verified: verified, ReturnURL: returnURL }
    };

    var ActionContextChange = function (e) {
        var contextChanged = JSON.parse(e.message);
        var currentRoute = location.hash.substring(1);
        currentRoute = currentRoute.split("/").slice(0,2).join("/");
        var launchTarget = AppRegistration.GetLaunchTargetByRouteName(currentRoute);
        var newRoute, eventType;
        if (launchTarget.NotifyChange == false) {
            _.each(launchTarget.Actions, function (Action) {
                if (_.contains(contextChanged, Action.Event)) {
                    newRoute = Action.Redirect;
                    eventType = Action.Event;
                }
            })
            if (newRoute != undefined) {
                if (currentRoute === newRoute) {
                    triggerNavigation(newRoute, "refreshAction", eventType);
                }
                else {
                    triggerNavigation(newRoute, "launchAction");
                }
            }
        }
    };

    var initialize = function () {
        $(document).on("changeAction", ActionContextChange);
    };
    return { Initialize: initialize, GetTargetAppUrl: GetTargetAppUrl }
});