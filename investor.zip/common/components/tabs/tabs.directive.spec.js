'use strict';

describe('Directive: Tab Panes', function() {

	var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

 		angular.mock.inject(function($rootScope, $compile, $httpBackend) {
            scope = $rootScope.$new();
  			compile = $compile;  			        	
        });
        scope.tabs = [
            { title:'Monthly Bussiness Overview', disabled: false, uiref: "portfolio.mb", tabViewName:"mb"},
            { title:'Lumpsum Book',  disabled: false, uiref: "portfolio.lb", tabViewName:"lb"},
            { title:'SIP Book', disabled: false, uiref: "portfolio.sb", tabViewName:"sb"},
            { title:'Investor Details',  disabled: false, uiref: "portfolio.id", tabViewName:"id"}
        ];
        var element = angular.element('<ftic-tabs tabdata="tabs"></ftic-tabs>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();                
        scope.$digest();
    });
    

    it('should be defined',function(){
		expect(directiveEle).toBeDefined();
	})

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

});