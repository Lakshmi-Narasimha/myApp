﻿/* iFrame resizing */
define([
  'jquery',
  'bootstrap', 'Base64', "appcommon/applauncher/device", "config", 'appmodules/ncst/app/data/country-list', 'moment', 'appcommon/nativeadaptor'
], function ($, bootstrap, Base64, Device, Config, CountryList, Moment, NativeAdaptor) {
    var ABPMobileWindow = null, 
        brkgProdClsCds = ["BFA", "BFAO", "BCF", "BCFA", "529", "B529", "SPST", "SPDQ", "BRKQ", "STQ+", "STQ-", "TSCA"];
    $(document).ready(function () {
        window.scroll(0,0);
        $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
                $('.scrollToTop').fadeIn();
            } else {
                $('.scrollToTop').fadeOut();
            }
        });
        $(document).off("click", ".scrollToTop").on("click", ".scrollToTop", function () {
            $('html, body').animate({ scrollTop: 0 }, 500);
            return false;
        });
        
        String.prototype.formatMoney = function (decimalsPoints) {
        	var decimals = ((decimalsPoints) ? decimalsPoints : 2);
            var num = parseFloat(this).toFixed(decimals);
            if (isNaN(num) === false) {
            	var money = '$' + num.toString().replace(/(\d)(?=(\d{3})+\b)/g, '$1,');
            	if(num < 0){
            		money = "("+money.replace("-", "") + ")";
            	}
                return money;
            }
            else {
                return this;
            }
        };
        
        String.prototype.getDateFromMS = function () {
        	var _actualDate = null;
        	try {
        	    var _tempDate = (eval("new "+this.toString().replace(/\//g,"")));
        	    _actualDate = (_tempDate.getMonth()+1)+"/"+_tempDate.getDate()+"/"+_tempDate.getFullYear();
        	}
        	catch(err) {
        		_actualDate =  null;
        	}
        	finally{
        		return _actualDate;
        	}
        };
        
        String.prototype.formatDateFrmString = function () {
        	var _actualDate = null;
        	try {
        		if(new Date(this) != "Invalid Date"){
        		    _actualDate = moment(this.toString()).format("MM/DD/YYYY");
        		}
        		else{
        			var _tempDate = new Date(Date.parse(this.split(" ").join("T")+"Z"));
            	    _actualDate = (_tempDate.getMonth()+1)+"/"+_tempDate.getDate()+"/"+_tempDate.getFullYear();
        		}
        			
        	}
        	catch(err) {
        		_actualDate =  null;
        	}
        	finally{
        		return _actualDate;
        	}
        };
        Object.defineProperty(Object.prototype, "formatDateMMddYYYY", {
            value: function () {
                if (this instanceof String) {
                    try {
                        return this.split("-").reverse().swap(0, 1).join("/");
                    } catch (err) {
                        return this;
                    }
                } else {
                    try {
                        var _customLog = {
                            "message": "Custom log - formatDateMMddYYYY issue",
                            "stack": {
                                "description": "This is log is to analyse more on the root cause of formatDateMMddYYYY issue",
                                "details": {
                                    "objectValue": this,
                                    "errorStack": {}
                                }
                            }
                        }
                        require(['errorLog'], function (ErrorLog) {
                            ErrorLog.ErrorUtils.myError(_customLog,true);
                        });
                    } catch (error) {
                        require(['errorLog'], function (ErrorLog) {
                            ErrorLog.ErrorUtils.myError(error, true);
                        });
                    } finally {
                        return "";
                    }
                }
            },
            enumerable: false
        });

        String.prototype.formatDateMMddYYYY = function () {        	
            try {
                return this.split("-").reverse().swap(0, 1).join("/");
            } catch (err) {
                return this;
            } 
        };
        String.prototype.formatAccountIdOrPlanId = function () {        	
        	try{
        		/*Format account num with 27 length*/
        		if(this && this.length == 27){
        			return this.slice(15,19)+" "+this.slice(19,23)+" "+this.slice(23,27)+" "+this.slice(0,3);
        		}
        		/*Format plan id with 20 length*/
        		else if(this && this.length == 20){
        			return this.substr(10,10).match(/[A-Z]{4}|(?:(?:\d{4}|\d{3})(?=(\d{3})*$))/g).join(" ")
        		}/*Format plan id with 27 length*/
        		else if(this && this.length == 10){
        			return this.match(/[A-Z]{4}|(?:(?:\d{4}|\d{3})(?=(\d{3})*$))/g).join(" ")
        		}
        		else{
                    return this;
                }
        	}catch(err){
        		return this;
        	}
        };
        String.prototype.formatDateWithSlashes = function () {
            var formattedString = this.formatDateMMddYYYY();
            return formattedString.split("-").join("/");
        };
        
        Array.prototype.clean = function() {
        	var _compareAgainst = [undefined, null, 0, false, '', ""];
        	  for (var i = 0; i < this.length; i++) {
        	    if (_compareAgainst.indexOf(this[i]) > -1) {        
        	      this.splice(i, 1);
        	      i--;
        	    }
        	  }
        	  return this;
        	};
        Array.prototype.swap = function (x,y) {
      		  var b = this[x];
      		  this[x] = this[y];
      		  this[y] = b;
      		  return this;
      		};
      		
      		if (!Array.prototype.find) {
      		  Array.prototype.find = function(predicate) {
      		    if (this === null) {
      		      throw new TypeError('Array.prototype.find called on null or undefined');
      		    }
      		    if (typeof predicate !== 'function') {
      		      throw new TypeError('predicate must be a function');
      		    }
      		    var list = Object(this);
      		    var length = list.length >>> 0;
      		    var thisArg = arguments[1];
      		    var value;

      		    for (var i = 0; i < length; i++) {
      		      value = list[i];
      		      if (predicate.call(thisArg, value, i, list)) {
      		        return value;
      		      }
      		    }
      		    return undefined;
      		  };
      		}
      		
      		String.prototype.lpad = function(padString, length) {
      		    var str = this;
      		    while (str.length < length)
      		        str = padString + str;
      		    return str;
      		}
      		
      		//Formating currency withgout symbol for input boxes
      		String.prototype.formatCurrency = function(n, x) {
        	    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
        	    return this.replace(new RegExp(re, 'g'), '$&,');
        	};
        	Number.prototype.formatCurrency = function(n, x) {
        	    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
        	    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
        	};

    });

    function preparePutAdvContextPayLoad(v2Compatible, GlobalContext, groupFlag,donotPassAdvsrId,grpId) {
    	var _data = {
    		putAdvsSessCntxAcctIds: null,
    		putAdvsSessCntxClIds: null,
    		putAdvsSessCntxDstrIds: null,
    		putAdvsSessCntxGrpIds: null

    	};
    	if (v2Compatible) {
    		_data.clCntxIdTypCd = "IDs";
    	}
    	var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
    	var _clientId = _gContext.ContactId;
    	var _clientCtx = {
    		clId: _clientId,
    		clCtx: "COLA.CL",
    		clRole: "PrimaryClient"
    	};
    	_data.putAdvsSessCntxClIds = [_clientCtx];
    	var _dstrCtx = null;
    	
    	if (!donotPassAdvsrId) {
    	    _dstrCtx =  {
    	        dstrId: _gContext.AdvisorFMID,
    	        dstrCtx: "DMU.DIST"
    	    };
    	    _data.putAdvsSessCntxDstrIds = [_dstrCtx];
    	}
    	
    	if (groupFlag == true) {
    	    var _grpId = grpId ? grpId : _gContext.GroupId;
			var _grpCtx = {
			    grpId: _grpId,
    			grpCtx: "COLA.GRP"
    			};
			_data.putAdvsSessCntxGrpIds =[_grpCtx];
    	}
		return _data;
    };
    function readCookie(name,options) {
        try {
        	var options = options || {};
            var nameEQ = name + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ')
                    c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) {
                	if(options.decode){
                		var _substring = decodeURIComponent(Base64.decode(c.substring(nameEQ.length, c.length)));
                	}else{
                		var _substring = decodeURIComponent(c.substring(nameEQ.length, c.length));
                	}
                    return _substring;

                }
            }
        } catch (e) {
            console.log("error reading cookie "  + name + " " + e);
        }

        return null;
    };
    function writeCookie(name, val, options, encoded) {
		encoded = encoded || false;			
		val = encoded ? Base64.encode(val) : val;
		options = options || {};
		options.expires = options.expires || 0;
		options.path = options.path || "/";
		if(options.expires != 0) {
            document.cookie = name + '=' + val + '; expires=' + options.expires + '; path=' + options.path;
        } else if (options.maxage) {
                document.cookie = name + '=' + val + '; max-age=' + options.maxage + '; path=' + options.path;
		}else{
			document.cookie = name + '=' + val + '; path=' + options.path;
		}
		
	};
    function formatClientId(clientId) {
        if (!clientId || clientId.length === 0) {
            return null;
        }
        var _clientIdFmtd = parseInt(clientId.substr(3)).toString();
        return _clientIdFmtd;
    };

    var heartBeatRefresh = function () {
        var src = "content/images/check.png" + '?cache-buster=' + new Date().getTime()
        var heartbeatImg = document.createElement('img');
        heartbeatImg.src = src;
    };
    function getUrlParams(deepUrl){
    	var regex = /[?&]([^=#]+)=([^&#]*)/g, params = {}, match, url = null,options = {};
    	options.decode = true;
    	if(readCookie("QuearyParams", options) && readCookie("QuearyParams", options)!= ""){
    		url = readCookie("QuearyParams", options);
    	}
    	else if(deepUrl && deepUrl.indexOf("?") != -1){
    		url = deepUrl.substr(deepUrl.indexOf("?"));
    	}else if(window.location.href.indexOf("?") != -1){
    		url = window.location.href.substr(window.location.href.indexOf("?"));
    	}else{
    		url = "";
    	}
		while (match = regex.exec(url)) {
			params[match[1]] = match[2];
		}
		return params;
    }  
    function setQueryParams(){
    	if(window.location.href.indexOf("?") != -1){}
    };
    function getQueryParams(){
    	var url = "", options = {};
    	options.decode = true;
    	if(readCookie("QuearyParams",options) && readCookie("QuearyParams", options)!= ""){
    		url = readCookie("QuearyParams", options);
    	}
    	else if(window.location.href.indexOf("?") != -1){
    		var url = window.location.href.substr(window.location.href.indexOf("?"));
    	}else{
    		var url = "";
    	}
    	
    	return url;
    };
    function hideIOSKeyboard(e) {};
    function sortMultiColumn() {
        var fields = [],
          n_fields = arguments.length,
          field, name, reverse, cmp;

        var default_cmp = function (a, b) {
            if (a === b) return 0;
            return a < b ? -1 : 1;
          },
          getCmpFunc = function (primer, reverse) {
            var dfc = default_cmp,
              // closer in scope
              cmp = default_cmp;
            if (primer) {
              cmp = function (a, b) {
                return dfc(primer(a), primer(b));
              };
            }
            if (reverse) {
              return function (a, b) {
                return -1 * cmp(a, b);
              };
            }
            return cmp;
          };

        // preprocess sorting options
        for (var i = 0; i < n_fields; i++) {
          field = arguments[i];
          if (typeof field === 'string') {
            name = field;
            cmp = default_cmp;
          } else {
            name = field.name;
            cmp = getCmpFunc(field.primer, field.reverse);
          }
          fields.push({
            name: name,
            cmp: cmp
          });
        }

        // final comparison function
        return function (A, B) {
          var a, b, name, result;
          for (var i = 0; i < n_fields; i++) {
            result = 0;
            field = fields[i];
            name = field.name;

            result = field.cmp(A[name], B[name]);
            if (result !== 0) break;
          }
          return result;
        };
      }
    function normalizeWS(s) {
        s = s.match(/\S+/g);
        return s ? s.join(' ') : '';
    }
    function setABPMobileWindow(ABPWindow){
    	ABPMobileWindow = ABPWindow;
    }
    function getABPMobileWindow(){
    	return ABPMobileWindow;
    }
    function isEmpty(anObject) {
        if (anObject) {
            switch(typeof anObject) {
                case 'string':
                    return $.trim(anObject) == '';
                case 'number':
                    return anObject == 0;
                case 'boolean':
                    return !anObject;
                default:
                    return _.isEmpty(anObject);
            }
        }
        return true;
    }
    function hasValue(data) {
        if (data === "" || data === undefined || data === null) {
            return false;
        }
        return true;
    }
    function userFMID() {
        return readCookie('FMID');
    }
   function getReferrer( backModifier ) {
        //backModifier is added to allow stepping back through the history further than -1 step (or 0 steps)
       backModifier = backModifier || -1;
       (typeof backModifier === 'undefined') ? backModifier = -1 : "";
       var history = {};
       if (typeof Backbone.history.list === 'undefined') { return false }
       switch (Backbone.history.list.slice(backModifier)[0]) {
            case "hoc/takeAction":
                history.context = "Insights";
                history.referer = "#hoc/";
                break;
           case "hoc/serviceopportunities":
               history.context = "Insights";
               history.referer = "#hoc/serviceopportunities";
               break;
           case "hoc/dol":
               history.context = "Insights";
               history.referer = "#hoc/dol";
               break;
       		case "gpm/confirm/maritalstatus":
            case "contactprofile/":
                history.context = "Profile";
                history.referer = "#contactprofile/";
                break;
           case "contactprofile/preferences":
               history.context = "Profile";
               history.referer = "#contactprofile/";
               break;
           case "accountviewer/accountstatements":
               history.context = "Statements";
               history.referer = "#accountviewer/accountstatements";
               break;
            default:
                history.context = "unknown"; 
                history.referer = "#crm/";
        }
        return history;
   }
   function launchThomsonSmart(options, errorcallback) {
       Device.browser();
       var _deviceInfo = Device.info;
       if (_deviceInfo.browser && _deviceInfo.browser.name == "ie") {
           try {
               try {
                   var t1Automation = T1SC.getT1Automation();
                   window.status = "T1 Startup...";
               }
               catch (expT1ActiveX) {
                   throw expT1ActiveX;
               }

               t1Automation.startThomsonOne(
                   function () {
                       window.status = "T1 Started";
                       var _acctNumParam = [], _contextArray = [options.strRefreshThomletId];
                       if (options.strAccNum !== "" && options.strAccNum !== null && options.strAccNum !== undefined) {
                           _acctNumParam = [{ name: "Account", value: options.strAccNum }];
                           _contextArray = [options.strRefreshThomletId, options.strThomledId];
                       }
                       t1Automation.navigateToFirstInWorkspace(_contextArray, _acctNumParam, options.strTabId);
                   }
               );
           }
           catch (expThomson) {
               errorcallback();
               if (expThomson.description.search(/Automation server can't create object/) != -1) {
                   alert("Thomson One is not installed on this system. Please install Thomson One before trying again. Technical Error: " + expThomson.description);
               }
               else {
                   alert("Thomson One application is failed to respond properly. Please try again. Technical Error: " + expThomson.description);
               }
           }
       } else {
           errorcallback();
       }
   }
   function openT1GenericLink() {
       var ABPMobileWindow = getABPMobileWindow(), _url = Config.t1URL;
       var _options = {
           "strAccNum": "",
           "strTabId": "",
           "strThomledId": "",
           "strRefreshThomletId": 123,
       }
       launchThomsonSmart(_options, openT1Link);
       function openT1Link() {
           if (ABPMobileWindow) {
               ABPMobileWindow.close();
           }
           ABPMobileWindow = window.open(_url);
           setABPMobileWindow(ABPMobileWindow);
       }
   }
   function sumoLog(message, uid) {
       uid = uid != undefined ? uid : "";
       message = message.replace(/ /g, '');
       a= new Date();
       new Image().src = "images/error_log_image.png?sumo_action_" + uid + "=" + encodeURIComponent(message)+"&timestamp="+a.getTime();
   }

   

   function isEbixContactId(contactId) {
      return contactId == null ? false : contactId.indexOf("Contact.") > -1
   }

   function sortClientGroup(clientgroups, pingrpid) {
       if (pingrpid == undefined) {
           return _(clientgroups.get('activeGroups')).sortBy(
               function (group) {
                   return [group.get('adminCode'), group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
               });
       }
       else {
           var sortedGrp = _(clientgroups.get('activeGroups')).sortBy(
           function (group) {
               return [group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
           });
           var movGrp = _.filter(sortedGrp, function (grp, index) {
               return grp.get('id') == pingrpid;
           });
           if (movGrp.length > 0) {
               var index = sortedGrp.indexOf(movGrp[0]);
               sortedGrp.splice(index, 1);
               sortedGrp.splice(0, 0, movGrp[0]);
           } else {
               return _(clientgroups.get('activeGroups')).sortBy(
                                  function (group) {
                                      return [group.get('adminCode'), group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
                                  });
           }
           return sortedGrp;
       }
   }

   function plDrawerToggle(obj) {
       var $drawerTrgt = $(obj.currentTarget);
       var $drawerTrgtId = $(obj.currentTarget).attr('data-id');
       var $drawerTrgtDataCont = $("[data-content=" + $drawerTrgtId + "]");
       var isCollapsed = $drawerTrgtDataCont.css('display') == 'none';

       if ($drawerTrgt.hasClass("closed")) {
       	$drawerTrgtDataCont.slideDown('slow');
       	$drawerTrgt.removeClass("closed");
       	$drawerTrgt.parent().next().find('[data-toggle]').removeClass('hidden');
       } else {
           $drawerTrgtDataCont.slideUp('slow');
           $drawerTrgt.addClass("closed");
           $drawerTrgt.parent().next().find('[data-toggle]').addClass('hidden');
       }
   }

   function plShowHide(obj, showTxt, hideTxt, effects) {
       var $drawerTrgt = $(obj.currentTarget);
       var $drawerTrgtId = $(obj.currentTarget).attr('data-id');
       var $drawerTrgtDataCont = $("[data-content=" + $drawerTrgtId + "]");
       var isClosed = $drawerTrgtDataCont.css('display') == 'none';
       var isDefined = (showTxt != undefined || showTxt != '') && (hideTxt != undefined || hideTxt != '') ? true : false;

       if (isClosed) {
           switch(effects) {
               case 'slidedown':
                   $drawerTrgtDataCont.slideDown('slow');
                   break;
               default:
                   $drawerTrgtDataCont.removeClass('hidden');
           }
           if (isDefined) { $drawerTrgt.html(hideTxt); }
       } else {
           switch (effects) {
               case 'slidedown':
                   $drawerTrgtDataCont.slideUp('slow');
                   break;
               default:
                   $drawerTrgtDataCont.addClass('hidden');
           }
           if (isDefined) { $drawerTrgt.html(showTxt); }
       }
   }

   function toggleViewEdit(obj) {
       var currentContainerVal = $(obj.currentTarget).closest('[data-container]').attr('data-container');
       var $pencilIcons = $('[data-content=' + currentContainerVal + '] .pt-edit-icon,.view-edit-based-display-items');
       $("[data-toggle='plToggleViewEdit'] .pl-view-edit").removeClass('active');
       $(obj.currentTarget).addClass('active');

       if ($(obj.currentTarget).text().toLowerCase() == 'view') {
           $pencilIcons.addClass('hidden');
       } else {
           $pencilIcons.removeClass('hidden');
       }
   }
   
   function isWindows() {
       var _isWindows = false;
       Device.operatingSystem();
       Device.physicalDevice();
       Device.browser();
       var _deviceInfo = Device.info;
       var _deviceType = _deviceInfo.hardware.make;
       if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface"))) {
           _isWindows = true;
       }
       return _isWindows;
   }

   function horizontalScrollToView(parentContainer, actualView) {
       $(parentContainer).animate({ scrollLeft: $(actualView).position().left }, 100);
   }
   function padZeros(padToLength/*minimumRequiredLength*/, numValue/*number to be padded with zeros*/) {
       var _zeroPad = "";
       if (numValue.length < padToLength) {
           _zeroPad = Math.pow(10, (padToLength - numValue.length)).toString().substr(1);
       }
       return _zeroPad + "" + numValue;
   }

   function checkVPN(successHandler, errorHandler) {
       var _img,
           _time = new Date().getTime(),
           _vpnCheckURL = Config.getConfigProperty("dnsPreCheckVPNLink") + "?_=" + _time;
       try {
           _img = new Image();
           _img.src = _vpnCheckURL;
           _img.onload = successHandler;
           _img.onerror = errorHandler ? errorHandler : vpnErrorHandler;
       } catch (err) {
           ErrorLog.ErrorUtils.myError(err);
       }
   }
   function vpnErrorHandler() {
       BootstrapDialog.alert("This functionality is only available when using an internal network or VPN.", null, "Function unavailable");
   }
   function toggleNonCMmsg(messageType) {
       if (messageType == "login") {
           var showCMMessage = undefined;
           if (readCookie('nonCMuserFirstLaunch') != undefined && readCookie('nonCMuserFirstLaunch') != null && readCookie('nonCMuserFirstLaunch') == "true") {
               if (readCookie('nonCMuserDoNotShowMessage') == "true") {
                   showCMMessage = false;
               }
               else {
                   showCMMessage = true;
               }
               writeCookie('nonCMuserFirstLaunch', "false");
           }
           if (showCMMessage == true) {
               BootstrapDialog.show({
                   title: "Important Message",
                   onhide: function () {
                       var _expires = new Date();
                       _expires.setTime(_expires.getTime() + (365 * 24 * 60 * 60 * 1000));//setting cookie expiry as 1 year from now
                       if ($('#non-cm-user-donotshow-message:checked').length > 0) {
                           writeCookie('nonCMuserDoNotShowMessage', "true",{"expires": _expires.toGMTString()});
                       }
                   },
                   message: "Our records show that you do not use Contact Manager in your practice. " +
                            "Based on this information, we will present Advisor Mobile to you without Contact Manager's calendar, tasks and SmartPad notes." +
                            "<br/><br/>" +
                            "If you would like to begin using Contact Manager's calendar, tasks and SmartPad notes in Advisor Mobile, " +
                            "you can request access. &nbsp; <a href='https://www.advisorcompass.com/web/advisorcompass/displaycontent?contID=761141&contType=AC-DeepContent' target='_blank'>Learn how to request access</a>" +
                            "<br/><br/>",
                   buttons: [
                           {
                               label: 'OK',
                               cssClass: 'btn pt-btn-yes generic-button btn-primary',
                               action: function (dialog) {
                                   dialog.close();
                               }
                           }],
                   onshow: function (dialogRef) {
                       dialogRef.getModalFooter()
                       .css({ display: 'inline' })
                       .find('.bootstrap-dialog-footer')
                       .append('<div class="pt-modal-dialog-msg footer-left">' +
                       '<br/> <div class=" pad-left15" ><input type="checkbox" value="" id="non-cm-user-donotshow-message"> Do not show me this again on this device</input></div><br/>');
                   }
               });
           }
       }
       else if (messageType == "function") {
           BootstrapDialog.show({
               title: "Functionality Unavailable",
               message: "This is a Contact Manager feature. If you would like to begin using Contact Manager's calendar, tasks, prospects and SmartPad notes in Advisor Mobile, you can request access." +
                           
                           " <a href='https://www.advisorcompass.com/web/advisorcompass/displaycontent?contID=761141&contType=AC-DeepContent' target='_blank'>Learn how to request access</a>" +
                           "<br/>",
               buttons: [
                       {
                           label: 'OK',
                           cssClass: 'btn pt-btn-yes generic-button btn-primary',
                           action: function (dialog) {
                               dialog.close();
                           }
                       }]
           })
       }
   }
   var parseHOCListemsResponse = function (responses) {
       var hocListResp = { "value": [] };
       if (responses && responses.length > 0) {
           if (responses[0] && responses[0].value && responses[0].value.value && responses[0].value.value.length > 0) {
               hocListResp.value = hocListResp.value.concat(responses[0].value.value);
           }
           if (responses[1] && responses[1].value && responses[1].value.value && responses[1].value.value.length > 0) {
               hocListResp.value = hocListResp.value.concat(responses[1].value.value);
           }
       }
       return hocListResp;
   }
   function getTimezoneAbbreviation() {
        var _tZone,
            _tZoneAbvtn,
            _todaysDate = new Date(),
                //Date string for non ios - Wed Jan 11 2017 12:09:38 GMT-0600 (Central Standard Time)
                //Date string for non ios - Wed Jan 11 2017 12:09:38 GMT-0600 (CST)
            _deviceInfo = getDeviceInfo().info;
        _tZone = _todaysDate.toString().split("(")[1];
        _tZone = _tZone.replace(")", "");
        if (_deviceInfo.os.type.indexOf('ios') !== -1 || _deviceInfo.os.type.indexOf('android') !== -1 || _deviceInfo.os.type.indexOf("macOSX") !== -1 || _deviceInfo.os.type.indexOf("macOSgeneric") !== -1) {
            _tZoneAbvtn = _tZone;
        } else {
            _tZoneAbvtn = CountryList.timeList["0"][_tZone];
        }
        return _tZoneAbvtn;
   }

   function getDeviceInfo() {
       Device.operatingSystem();
       Device.physicalDevice();
       Device.browser();
       return Device;
   }
    function getBrkgProdClsCds() {
        return brkgProdClsCds;
    }
   function logFisrtViewLoadTime(pageId, errorLogUtil) {
       var _firstViewLoaded = readCookie("firstviewLoaded"),
           _urlContext = getUrlParams();
       if (_urlContext["mode"] == "nav") {
           if (_firstViewLoaded != "true") {
               writeCookie("firstviewLoaded", "true");
               logViewRenderTime(pageId, errorLogUtil);
           }
       }
       
   }
   function logViewRenderTime(pageId, errorLogUtil) {
       var _customLog,
           _viewRenderedTime = new Date(),
           _pageLoadStartTime = Number(readCookie("pageLoadStartTime")),
           _staticFileLoadCompleteTime = Number(readCookie("staticFileLoadCompleteTime")),
           _timeTakenToLoadStaticFiles = _staticFileLoadCompleteTime - _pageLoadStartTime,
           _timeTakenToRenderViewAfterStaticFileLoad = _viewRenderedTime.getTime() - _staticFileLoadCompleteTime,
           _urlParams = getUrlParams(),
           _totalTimeTaken = (_timeTakenToLoadStaticFiles+_timeTakenToRenderViewAfterStaticFileLoad),
           _srcSystm = _urlParams && _urlParams["srcSystem"] ? _urlParams["srcSystem"]: "AM";
       _customLog = {
           "message": "This is not an error log, this is for the Permformance analysis",
           "stack": {
               "logType": "View Load",
               "pageId":pageId,
               "pageLoadStartTime": new Date(_pageLoadStartTime).toString(),
               "staticFileLoadCompleteTime": new Date(_staticFileLoadCompleteTime).toString(),
               "viewLoadCompletetime": _viewRenderedTime.toString(),
               "timeTakenToLoadStaticFiles": _timeTakenToLoadStaticFiles,
               "timeTakenToRenderViewAfterStaticFileLoad": _timeTakenToRenderViewAfterStaticFileLoad,
               "totalTimeTaken":_totalTimeTaken,
               "sourceSystem": _srcSystm
           }
       }
       console.log(_customLog, "_customLog_customLog_customLog_customLog_customLog_customLog_customLog_customLog_customLog_customLog_customLog")
       errorLogUtil.ErrorUtils.myError(_customLog, true);
   }
  /* var getActive147AccountsCount = function (overviewAccount) {
       var _active147AccountsCount = 0;
       if (overviewAccount) {
           $.each(overviewAccount, function (i, acct) {
               if (acct && acct.get('adminCd') == "147" && acct.get("statusCd") == "ACTIVE") {
                   _active147AccountsCount++;
               }
           });
       }
       return _active147AccountsCount;
   }*/
   function loadSelectbox(selectBox, optionData, selectedVal, noEmptyOption) {
        var _optionsData = optionData;
        var _options = '';
        if (!noEmptyOption) {
            _options += '<option value="" >Choose one</option>'
        }
        $.each(_optionsData, function (key, row) {
            var _val = row.code || row.value
            if(selectedVal == _val){
                _options += '<option selected name="' + row.name + '" value="'
                + _val + '" >' + row.name + '</option>';
            }else{
                _options += '<option name="' + row.name + '" value="'
                + _val + '" >' + row.name + '</option>';
            }      
        });
        if (Array.isArray(selectBox)) {
            $(selectBox.join(',')).html(_options);
        } else {
            $(selectBox).html(_options);
        }
   }
   function numValidator(obj) {
        var _regxNumOnly = /^\d*$/;
        var _str = String.fromCharCode(event.keyCode);
        if (!_regxNumOnly.test(_str)) {
            obj.stopPropagation();
            if (event.preventDefault)
                event.preventDefault();
            return false;
        }
   }
    var utility = {
            writeCookie: writeCookie,
            readCookie: readCookie,
            formatClientId: formatClientId,
            getUrlParams: getUrlParams,
            setQueryParams: setQueryParams,
            getQueryParams: getQueryParams,
            hideIOSKeyboard: hideIOSKeyboard,
            sortMultiColumn: sortMultiColumn,
            normalizeWS: normalizeWS,
            setABPMobileWindow: setABPMobileWindow,
            getABPMobileWindow: getABPMobileWindow,
            isEmpty: isEmpty,
            userFMID: userFMID,
            getReferrer: getReferrer,
            launchThomsonSmart: launchThomsonSmart,
            sumoLog: sumoLog,
            isEbixContactId: isEbixContactId,
            preparePutAdvContextPayLoad: preparePutAdvContextPayLoad,
            sortClientGroup: sortClientGroup,
            plDrawerToggle: plDrawerToggle,
            plShowHide: plShowHide,
            toggleViewEdit: toggleViewEdit,
            isWindows: isWindows,
            hasValue: hasValue,
            horizontalScrollToView: horizontalScrollToView,
            padZeros: padZeros,
            checkVPN: checkVPN,
            toggleNonCMmsg: toggleNonCMmsg,
            openT1GenericLink: openT1GenericLink,
            parseHOCListemsResponse: parseHOCListemsResponse,
            getTimezoneAbbreviation: getTimezoneAbbreviation,
            getBrkgProdClsCds: getBrkgProdClsCds,
            logFisrtViewLoadTime: logFisrtViewLoadTime,
            //getActive147AccountsCount: getActive147AccountsCount,
            loadSelectbox: loadSelectbox,
            numValidator: numValidator
   };
    return utility;
});
