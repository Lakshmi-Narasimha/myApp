'use strict';

var buildPlan= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _buildPlanResp = null,
        _setInvestorSearch = null,
        _selectedFundDetails = null,
        _allocationDetails = null,
        _goalDataResp = null,
        _invType = null,
        _invValue = null,
        _goalPlanTotalResp = null,
        _paymentType = null,
        _invSelect = null,
        _goalSheetFromstate = null,
        _newInvestorFirstHolderDtls = null,
        _newInvestorHolderDtls = null,
        _goalDesc = null;


    var buildPlanModel = {
        fetchBuildPlan : function () {
            var deferred = $q.defer();
            Restangular.one('getBuildMyPlan').get().then(function (buildPlanResp) {
               //console.log(buildPlanResp);
                deferred.resolve(buildPlanResp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getBuildPlanDtls : function () {
                 return _buildPlanResp;
        } ,
        setBuildPlanDtls : function (buildPlanResp) {
            _buildPlanResp = buildPlanResp;
        },
        setInvestorSearch : function(invSearchResp)
        {
            _setInvestorSearch = invSearchResp;
        },
        getInvestorSearch : function () {
                 return _setInvestorSearch;
        },
        setFundDetails : function(fundDetails) {
            console.log("setFundDetails",fundDetails);
            _selectedFundDetails = fundDetails;
        },
        getFundDetails : function() {
            return _selectedFundDetails;
        },
        setAllocationDetails : function(allocationDetails) {
            _allocationDetails = allocationDetails;
            console.log("the alloc details are",_allocationDetails);
        },
        getAllocationDetails : function() {
            return _allocationDetails;
        },
        setGoalPlanData : function (goalPlanResp) {
            _goalDataResp = goalPlanResp;
        },
        getGoalPlanData : function () {
           return _goalDataResp;
        },
          setSelectInvType : function (inv) {
            _invSelect = inv;
        },
        getSelectInvType : function () {
           return _invSelect;
        },
        setGoalTotalPlanData : function (goalPlanTotalResp) {
            _goalPlanTotalResp = goalPlanTotalResp;
        },
        getGoalTotalPlanData : function () {
         return _goalPlanTotalResp;
        },
        setInvestmentType : function (invType) {
            _invType = invType;
        },
        getInvestmentType : function () {
           return _invType;
        },
        setInvestmentValue : function (invValue) {
            _invValue = invValue;
        },
        getInvestmentValue : function () {
           return _invValue;
        },
        getPaymentType : function() {
            if(_invType == "Monthly" || _invType =="Annually")
                _paymentType = "SIP";
            else if(_invType == "One Time")
                _paymentType = "Lumpsum";
            else if(_invType == "Combo")
                _paymentType = "Combo";
            return _paymentType;
        },

        getGoalSummaryFromState :function(){
            return _goalSheetFromstate;
        },
        setGoalSummaryFromState : function(fromState){
            _goalSheetFromstate = fromState;
        },


        setNewInvestorFirstHolderDtls : function(newInvestorFirstHolderDtls){
            _newInvestorFirstHolderDtls = newInvestorFirstHolderDtls;
        },
        getNewInvestorFirstHolderDtls : function(){
            return _newInvestorFirstHolderDtls;
        },
        setNewInvestorHolderDetails : function(newInvestorHolderDtls){
            _newInvestorHolderDtls = newInvestorHolderDtls;
        },
        getNewInvestorHolderDetails : function(){
            if(!angular.isDefined(_newInvestorHolderDtls)){
                    return null
            }   
            return _newInvestorHolderDtls;
        },
        kycNotRegPan : null,
        kycNotRegName : null,
        kycNotRegType : null,
        modeOfHolding : null,
        setGoalDesc :function(goalDescription){
            _goalDesc = goalDescription;
        },
        getGoalDesc : function(){
            return _goalDesc;
        }

    };
     

    return buildPlanModel;

};

buildPlan.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = buildPlan;
