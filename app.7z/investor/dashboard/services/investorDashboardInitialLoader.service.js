/**
 * @ngdoc service
 * @name FTI Dashboard Initial Load Service
 * @requires investorDashboardDetailsModel
 * @requires eventConstants
 * @requires toaster
 * @requires dashboardConstants
 * @requires $timeout
 * @description
 *
 * - Handles the services and model for investor content details & widgets
 *
 */
'use strict';

var investorDashboardInitialServices = function(eventConstants, toaster, fticLoggerMessage, loggerConstants, $cookies, investorDashboardDetailsModel, investorEvents, $loader) {

    var investorDashboardInitialServices = {
        _isServicesData: false,
        loadAllServices: function(scope) {

             var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var guid = '';
            if($cookies.get('guId')) {
				guid = $cookies.get('guId');
            }

            function dashboardDetailsSuccess(data) {
                
                investorDashboardDetailsModel.setDashboardData(data.investorDashboardObject);
                // Broadcasting an event
                investorEvents.dashboard.investorDashboardInformation(scope);
            }

            function SmartSavAccAndOneTouchDetailsSuccess(data) {
                
                investorDashboardDetailsModel.setSmartSaveAccAndOneTouchData(data);
                // Broadcasting an event
                investorEvents.dashboard.investorSmartSaveAccAndOneTouch(scope);
            }

            function smartSolutionsSuccess(data) {

                investorDashboardDetailsModel.setSmartSolutions(data);
                
                // Broadcasting an event
                investorEvents.dashboard.investorSmartSolutions(scope);
            }

            function promiseFailure(error) {
                
                var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_DASHBOARD_INITIAL_LOADER_SERVICE + ' | promiseFailure' /* Function Name */; 
                fticLoggerMessage.displayLoggerMessage({level:'error', 'message': message});
                if(error.data.length > 0) {
                    toaster.error(error.data[0].errorDescription);
                }
                investorDashboardInitialServices._isServicesData = false;
            }

            function stopLoader(){
                $loader.stop();
            }

            $loader.start();
            investorDashboardDetailsModel.getDashboardDetails({'guId': guid})
                .then(dashboardDetailsSuccess, promiseFailure).finally(stopLoader);

            $loader.start();
            investorDashboardDetailsModel.getSmartSolDetails({'guId': guid})
                .then(smartSolutionsSuccess, promiseFailure).finally(stopLoader);
                
            $loader.start();
            investorDashboardDetailsModel.getSmartSaveAccAndOneTouchDetails({'guId': guid})
                .then(SmartSavAccAndOneTouchDetailsSuccess, promiseFailure).finally(stopLoader);
        }
    };
    return investorDashboardInitialServices;
};

investorDashboardInitialServices.$inject = ['eventConstants', 'toaster', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'investorDashboardDetailsModel', 'investorEvents', '$loader'];
module.exports = investorDashboardInitialServices;
