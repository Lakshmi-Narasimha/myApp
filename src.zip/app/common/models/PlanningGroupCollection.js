define(['jquery', 'lodash', 'backbone', 'app/common/models/PlanningGroup'
], function ($, _, Backbone, PlanningGroup) {
    var PlanningGroupCollection = Backbone.Collection.extend({
        model: PlanningGroup,
        populateFromPlanningGroupListResponse: function (PlanningGroupRes) {
            const PlanningGroupList = PlanningGroupRes.value;
            if (PlanningGroupList && PlanningGroupList.length > 0) {
                var self = this;
                _.each(PlanningGroupList, function (group) {
                    self.add(new PlanningGroup().populateFromServiceResponse(group));
                });
            }
            return this;
        }
    });
    return PlanningGroupCollection;
});