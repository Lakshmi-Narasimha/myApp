var componentModule = angular.module('component.loader', []);
componentModule.directive('loader', ['$loader', function($loader) {
    return {
        restrict: 'E',
        template: "<span id='maincover'><div class='loader'></div><i class='fa fa-spinner fa-spin'></i></span>",
        link: function(scope, elm, attrs) {
            scope.isLoading = function() {
                return $loader.getVal() > 0;
            };
            scope.$watch(scope.isLoading, function(v) {
                if (v) {
                    elm.show();
                } else {
                    elm.hide();
                }
            });
        }
    };

}]);

componentModule.factory('$loader', [function() {
    var counter = 0;
    return {
        start: function() {
            counter++;
        },
        stop: function() {
            counter--;
        },
        getVal: function() {
            return counter;
        }
    };
}]);
