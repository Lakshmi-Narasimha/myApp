var HttpsProxyAgent = require('https-proxy-agent');
var fs = require('fs');

var proxy = {
      "agent" : new HttpsProxyAgent("http://server.proxy.vzwcorp.com:9290"),
      "ca" : [
        fs.readFileSync("/app/conf/certs/mfchatnodecerts/"+"GoDaddyRootCertificateAuthority-G2.crt"),
        fs.readFileSync("/app/conf/certs/mfchatnodecerts/"+"GoDaddySecureCertificateAuthority-G2.crt"),
        fs.readFileSync("/app/conf/certs/mfchatnodecerts/"+"touchcommercecom.crt"),
        fs.readFileSync("/app/conf/certs/mfchatnodecerts/"+"COMODORSACertificationAuthority.crt"),
        fs.readFileSync("/app/conf/certs/mfchatnodecerts/"+"COMODORSAOrganizationValidationSecureServerCA.crt"),
        fs.readFileSync("/app/conf/certs/mfchatnodecerts/"+"livepersonnet.crt")
       ]
}

module.exports = proxy;