/*

 Code audits

 */

var fs = require('fs');
var path = require('path');
var _ = require('lodash');

module.exports = {

	runAllAudits: function () {
		var ok = true;
		ok = this.auditRequireDefines() ? ok : false;
		ok = this.auditXSSEscaping() ? ok : false;
		ok = this.auditDebugger() ? ok : false;
		ok = this.auditWindowRef() ? ok : false;
		return ok;
	},

	auditRequireDefines: function () {
        /* verify that no require define values have .js suffixes
         Example:
         Good:
         define(['app/components/views/AbstractView', .....
         Bad:
         define(['app/components/views/AbstractView.js', .....
         */
		var ok = true;
		visitDirectory('./src/app', function(fileName, path, fullFilePath) {
			if (isRequireModuleWithInvalidDefine(fullFilePath)) {
				ok = false;
				console.log('AUDIT ERROR: ' + fullFilePath + ' module has a .js suffix in the define array');
			}
		});
		console.log('require define audit done');
		return ok;
	},

	auditXSSEscaping: function () {
		// verify that there are no unescaped outputs of data in the templates (should be using <%- not <%= )

        /*
         NOTE: You can disable escape checking for a template by adding the string AUDIT-IGNORE-ESCAPING-RULE
         anywhere in the file.
         */

		var ok = true;
		visitDirectory('./src/app', function(fileName, path, fullFilePath) {
			if (isHtmlTemplateWithNonEscapedOutput(fullFilePath)) {
				ok = false;
				console.log('AUDIT ERROR: template ' + fullFilePath + ' has a non-escaped output');
			}
		});
		console.log('xss escaping audit done');
		return ok;
	},

	auditDebugger: function () {
		// verify that there are no "debugger" lines in the code

        /*
         NOTE: You can disable escape checking a js file by adding the string AUDIT-IGNORE-DEBUGGER-RULE
         anywhere in the file.
         */

		var ok = true;
		visitDirectory('./src/app', function(fileName, path, fullFilePath) {
			if (isJSWithDebuggerLine(fullFilePath)) {
				ok = false;
				console.log('AUDIT ERROR: javascript ' + fullFilePath + ' has "debugger" in the file');
			}
		});
		console.log('js debugger audit done');
		return ok;
	},


	auditWindowRef: function () {
		// verify that there is no setting of objects in the window object

        /*
         NOTE: You can disable escape checking a js file by adding the string AUDIT-IGNORE-WINDOW-REF-RULE
         anywhere in the file.
         */

		var ok = true;
		visitDirectory('./src/app', function(fileName, path, fullFilePath) {
			if (isJSWithWindowReference(fullFilePath)) {
				ok = false;
				console.log('AUDIT ERROR: javascript ' + fullFilePath + ' is setting a property of the window in the file');
			}
		});
		console.log('js window property setting audit done');
		return ok;
	}

};

/* HELPER FUNCTIONS */

// visit all files recursively...visit function called for each file (fileName, path, fullFilePath)
function visitDirectory(dirPath, visit) {
	var filesAndDirs = fs.readdirSync(dirPath);
	_.each(filesAndDirs, function(childName) {
		var pathName = path.join(dirPath, childName);
		var stats = fs.statSync(pathName);
		if (stats.isDirectory()) {
			visitDirectory(pathName, visit);
		} else if (stats.isFile()) {
			visit(childName, dirPath, pathName);
		}
	});
}

function isRequireModuleWithInvalidDefine(fullFilePath) {
	if (_.endsWith(fullFilePath, '.js')) {
		var contents = fs.readFileSync(fullFilePath, 'utf8');
		return contents.match(/define\((.|\n)*\[(.|\n)*\.js("|'|`|\n)*\]/);
	}
	return false;
}

function isHtmlTemplateWithNonEscapedOutput(fullFilePath) {
	if (_.endsWith(fullFilePath, '.html')) {
		var contents = fs.readFileSync(fullFilePath, 'utf8');
		if (contents.match(/<%=/)) {
			return !contents.match(/AUDIT-IGNORE-ESCAPING-RULE/);
		}
	}
	return false;
}

function isJSWithDebuggerLine(fullFilePath) {
	if (_.endsWith(fullFilePath, '.js')) {
		var contents = fs.readFileSync(fullFilePath, 'utf8');
		if (contents.match(/debugger/)) {
			return !contents.match(/AUDIT-IGNORE-DEBUGGER-RULE/);
		}
	}
	return false;
}

function isJSWithWindowReference(fullFilePath) {
	if (_.endsWith(fullFilePath, '.js')) {
		var contents = fs.readFileSync(fullFilePath, 'utf8');
		if (contents.match(/window\..*=/)) {
			return !contents.match(/AUDIT-IGNORE-WINDOW-REF-RULE/);
		}
	}
	return false;
}