// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PurchaseDetailsModelSchema = new mongoose.Schema({
    PurchaseDetailsResp: {
        type: Array,
        "default": []
    }
});

var PurchaseDetailsModelLookUp = mongoose.model('PurchaseDetailsModelLookUp', PurchaseDetailsModelSchema);

var PurchaseDetailsModel = new PurchaseDetailsModelLookUp({
    PurchaseDetailsResp : {
        "purchase": {
            "fundWiseData": [
                {
                    "purchaseDate": "18 Feb 2016",
                    "purchaseAmount": "120.52",
                    "nav": "120.52",
                    "units": "98.87",
                    "status": "Processed"
                },
                {
                    "purchaseDate": "20 Feb 2016",
                    "purchaseAmount": "525.52",
                    "nav": "652.52",
                    "units": "90.87",
                    "status": "Processed"
                },
                {
                    "purchaseDate": "14 Feb 2016",
                    "purchaseAmount": "120.52",
                    "nav": "120.52",
                    "units": "98.87",
                    "status": "Processed"
                },
                {
                    "purchaseDate": "16 Feb 2016",
                    "purchaseAmount": "525.52",
                    "nav": "652.52",
                    "units": "90.87",
                    "status": "Processed"
                }
            ],
            "fundInfo": {
                "fund": "Franklin India Equity Fund - Growth",
                "folioNo": "2341621",
                "accountNo": "00023262322",
                "modeOfHolding": "Joint",
                "goal": "Wealth creation",
                "goalDetails": "Buying a House"
            }
        }
    }
});

PurchaseDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating PurchaseDetailsModelLookUp table, please contact admin...');
    } else {
        PurchaseDetailsModelLookUp.remove({}, function(err) {
            console.log('PurchaseDetailsModelLookUp collection removed');
            PurchaseDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PurchaseDetailsModelLookUp table, please contact admin...');
                }
                console.log('PurchaseDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PurchaseDetailsModelLookUp;
