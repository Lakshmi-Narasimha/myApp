// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SWPRegdModelSchema = new mongoose.Schema({
    swpRegdResp: {
        type: Array,
        "default": []
    }
});

var SWPRegdModelLookUp = mongoose.model('SWPRegdModelLookUp', SWPRegdModelSchema);

var SWPRegdModel = new SWPRegdModelLookUp({
    swpRegdResp : {
      "swpDetails": {
        "fundWiseData": [
          {
            "folioNo": "1141621",
            "fund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "10,000"
          },
          {
            "folioNo": "1142621",
            "fund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Monthly",
            "amount": "15,000"
          },
          {
            "folioNo": "1143621",
            "fund": "Franklin India Equity Fund - Growth",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "18,000"
          },
          {
            "folioNo": "1144621",
            "fund": "Franklin India Prima Plus",
            "familySolution": "Yes",
            "frequency": "Weekly",
            "amount": "18,000"
          }
        ],
        "grandTotal": "43,000"
      }
    }
}
);

SWPRegdModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SWPRegdModelLookUp table, please contact admin...');
    } else {
        SWPRegdModelLookUp.remove({}, function(err) {
            console.log('SWPRegdModelLookUp collection removed');
            SWPRegdModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SWPRegdModelLookUp table, please contact admin...');
                }
                console.log('SWPRegdModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SWPRegdModelLookUp;
