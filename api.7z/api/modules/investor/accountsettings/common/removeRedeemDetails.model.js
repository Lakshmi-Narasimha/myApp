// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var RemoveRedeemDetailsSchema = new mongoose.Schema({
    removeRedeemResp: {
        type: Object,
        "default": {}
    }
});

var RemoveRedeemLookUp = mongoose.model('RemoveRedeemLookUp', RemoveRedeemDetailsSchema);

var RemoveRedeemModel = new RemoveRedeemLookUp({
      removeRedeemResp: {
      "status": "true",
      "webRefNo": "EM00001025"
    }
});

RemoveRedeemLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating RemoveRedeemLookUp table, please contact admin...');
    } else {
        RemoveRedeemLookUp.remove({}, function(err) {
            console.log('RemoveRedeemModel collection removed');
            RemoveRedeemModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RemoveRedeemLookUp table, please contact admin...');
                }
                console.log('RemoveRedeemLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RemoveRedeemLookUp;
