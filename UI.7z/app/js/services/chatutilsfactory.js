module.exports = function(chatServices) {

    var chatUtils = {
        callInitServices: function(searchCallback, supportCallback) {
            var reqObj = {
                "InitialParams": {
                    "appName": "com.vzw.hss.myverizon",
                    "appVersion": "12.8.0",
                    "carrier": "verizon",
                    "model": "SM-G900V",
                    "osName": "Android",
                    "osVersion": "6.0.1",
                    "deviceName": "kltevzw",
                    "formFactor": "handset",
                    "sourceServer": "None",
                    "timeZone": "EST",
                    "wifi": true,
                    "sourceID": "mvmrc",
                    "showFirstBillInterstitial": false,
                    "SSO": {
                        "ssoToken": "iIFu97qeLT1lDLGGbqz0IVlFAkgydummyssovalue=",
                        "mdn": "2397766050"
                    },
                    "sim_operator_code": "311480",
                    "countryName": "us"
                },
                "RequestParams": {
                    "continueToApp": "",
                    "deepLink": true,
                    "firstTimeTnCSkipped": false,
                    "userNamePwdFlow": true,
                    "password": "abcd1234",
                    "preOrderLoadTestFlag": "false",
                    "rememberMe": false,
                    "setReminder": false,
                    "userName": "2397766050"
                }
            };

            chatServices.search(reqObj).then(function(data) {
                searchCallback(data);

            }, function(err) {
                console.log(err);
            });

            var reqObjSup = {
                "RequestParams": {
                    "supportRequestState": 101,
                    "searchSource": "API_AI"
                }
            };

            chatServices.getSupport(reqObjSup).then(function(data) {
                supportCallback(data);

            }, function(err) {
                console.log(err);
            });

        }

    };

    return chatUtils;
};
