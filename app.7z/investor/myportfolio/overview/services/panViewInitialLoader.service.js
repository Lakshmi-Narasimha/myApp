'use strict';

var PanViewInitLoader = function(panViewModel, investorEvents, toaster, $loader) {

    var PanViewInitLoader = {
        _isServicesData: false,
        loadAllServices: function(scope, panFilter) {

            function panViewrDetailsSuccess(data) {
                panViewModel.setPanViewDtls(data);
                investorEvents.myPortfolio.publishPanViewVDetails(scope);
            }

            function handleFailure(data) {
                console.error('handleFailure');
                PanViewInitLoader._isServicesData = false;
                toaster.error(data.data[0].errorDescription);

            }
            

            $loader.start();
            panViewModel.fetchPanViewDetails(panFilter)
                .then(panViewrDetailsSuccess, handleFailure).finally(function(){
                $loader.stop();
            });

        }
    };
    return PanViewInitLoader;
};

PanViewInitLoader.$inject = ['panViewModel', 'investorEvents', 'toaster', '$loader'];
module.exports = PanViewInitLoader;
