// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TransRedumptionDetailsModelSchema = new mongoose.Schema({
    RedumptionDetailsResp: {
        type: Array,
        "default": []
    }
});

var TransRedumptionDetailsModelLookUp = mongoose.model('TransRedumptionDetailsModelLookUp', TransRedumptionDetailsModelSchema);

var TransRedumptionDetailsModel = new TransRedumptionDetailsModelLookUp({
    RedumptionDetailsResp : {
    "redeem": {
        "fundWiseData": [{
            "redemptionDate": "13 jul 2011",
            "redemptionAmount": "5,543.66",
            "nav": "40.7451",
            "units": "136.057",
            "bankName": "HDFC BANK LTD",
            "bankAccountNo": "32798632569181",
            "payoutType": "Directly To Bank",
            "fundDesc": ""
        },{
            "redemptionDate": "21 jul 2011",
            "redemptionAmount": "5,543.66",
            "nav": "40.7451",
            "units": "136.057",
            "bankName": "HDFC BANK LTD",
            "bankAccountNo": "32798632569181",
            "payoutType": "Directly To Bank",
            "fundDesc": ""
        }],
        "fundInfo": {
            "fund": "Franklin India Dynamic P E Ratio Fund Of Funds - Growth",
            "accountNo": "4529900835384",
            "folioId": "16286393",
            "modeOfHolding": "Anyone Or Survivor",
            "goal": "",
            "goalDetails": "",
            "distId": ""
        }
    }
}
});

TransRedumptionDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating TransRedumptionDetailsModelLookUp table, please contact admin...');
    } else {
        TransRedumptionDetailsModelLookUp.remove({}, function(err) {
            console.log('TransRedumptionDetailsModelLookUp collection removed');
            TransRedumptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransRedumptionDetailsModelLookUp table, please contact admin...');
                }
                console.log('TransRedumptionDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransRedumptionDetailsModelLookUp;
