'use strict';
describe('Factory: invTransactionDetailsFactory', function() {
	var invTransactionDetailsFactory,httpBackend,$window,Restangular,$q,deferred,transactModel,transDetailsModel,$window,fticCommonUtils, FileSaver,toaster;

	var selectedInvestorDetailsObj = {
		custName:"RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI",
		email:"",
		firstHolderKyc:"KYC - Registered",
		firstHolderName:"RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI",
		folioId:"17023676",
		index:1,
		isFolioKYCReg:true,
		labelFolioId:"Folio 17023676",
		mobile:"",
		modeofHolding:"Single",
		pan:"",
		secondHolderKyc:"NA",
		secondHolderName:"NA",
		thirdHolderKyc:"NA",
		thirdHolderName:"NA",
		holders:[{
			aadharNo:"null",
			balAmount:"",
			kycSource:"CVLKRA",
			kycStatus:"KYC - Registered",
			modeOfKyc:"",
			name:"RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI",
			pan:"CHDQR9223F",
			type:"Firstholder"	
		}]
	};

	var selectedFundDetailsObj = {balUnits:"2463.841",
		fmDescription:"Franklin India Bluechip Fund - Dividend",
		fundCategory:"EQUITY",
		fundType:"EQUITY",
		index:"1",
		investmentGoal:"",
		marketValue:"349183.18",
		tschvalAccno:"0069901064910",
		tschvalFsFlag:"N",
		tschvalScheme:"006"
	};

	var destinationFundResponse = {
	    "accNo": "0010008062712",
	    "amount": "1000",
	    "direct": null,
	    "dividendFlag": "R",
	    "endDate": "4 sep 2020",
	    "frequency": "monthly",
	    "fundCategory": "EQUITY",
	    "fundName":"Franklin India PRIMA FUND",
	    "fundOptDesc": "Franklin India PRIMA FUND",
	    "fundOption": "001",
	    "fundType": "E",
	    "minAddPurAmt": "1000",
	    "minNewPurAmt": "1000",
	    "minSipAmt": "500",
	    "multiples": "1",
	    "nfoFlag": "N",
	    "payoutFlag": "N",
	    "reinvestmentFlag": "N",
	    "startDate": "1 mar 2014",
	    "nextInstlDate": "10 aug 2016",
	    "nextAnnualDate": "1 mar 2017",
	    "stepUpType": "",
	    "stepUpValue": "2500",
	    "leadDays": "15",
	    "title":"0010008062712 - Franklin India PRIMA FUND",
	    "paymentDet":{
	    	"payModeEmand": "true",
	        "eMandateType":"maximum",
	        "eMandateVal": "3400",
	        "eMandateExpiryDate": "10 oct 2016" 
	    }
	};

	var switchDetailsObj = {
		"switchType":"Full",
		"type":"Full",
		"units":8371.015,
		"destinationFund": destinationFundResponse
	};

	var stpDetailsObj = {
		"destinationFund": destinationFundResponse,
		endDate:"Tue Jun 20 2017 16:29:06 GMT+0530 (India Standard Time)",
		frequency:"Monthly",
		noofInstallments:6,
		startDate:"Thu Dec 22 2016 16:29:06 GMT+0530 (India Standard Time)",
		stpAmount:{
			amount:"Capital Appreciation",
			type:"capitalAppreciation"
		}	
	};

	var swpDetailsObj = {
		_ifscCode:"HDFC0000835",
		bankDetails:"CITI BANK - 7335300411",
		brnch:"BANDRA EAST - KALANAGAR",
		city:"022-61606161",
		endDate: "Wed Jun 13 2018 16:36:51 GMT+0530 (India Standard Time)",
		frequency:"Monthly",
		noofInstallments:6,
		selectedMode:"direct-credit",
		selectedType:"capital",
		startDate: "Tue Dec 20 2016 16:36:51 GMT+0530 (India Standard Time)",
		swpAmtValue:"Capital Appreciation"
	};

	var redeemDetailsObj = {
		amount:"",
		bank:"CITI BANK - 7335300411",
		mode:"Cheque",
		type:"Full",
		units:"8371.015"
	};

	var transactionConfirmObj = {transactionRefNo: "SWI001166", transDateTime: "14 December 2016, 08:18 PM"};

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.transact'));	

	var transactModel = {		
		getTransactDetails: function() {			
            return {"switchDetails":switchDetailsObj,
            		"stpDetails":stpDetailsObj,
            		"swpDetails":swpDetailsObj,
            		"transactDetails": redeemDetailsObj,
            		"investorDetails":selectedInvestorDetailsObj,
            		"fundDetails":selectedFundDetailsObj};
        },
        getInvestorDetails : function(){
        	return selectedInvestorDetailsObj;
        },
        getFundDetails: function() {			
            return selectedFundDetailsObj;
        },
        getTransactConfirm : function(){
        	return transactionConfirmObj;
        },
        getAdvDetails : function(){
        	return {};
        },
        downloadTransactDetails : function(){        	
        	return {};
        }
	};

	var failureResponse = [{
                    'errorCode': 'E123',
                    'errorDescription': 'Something went wrong...'
                }];

	beforeEach(function() {		
        angular.mock.module(function($provide) {
            $provide.value('transactModel', transactModel);
        });
    });

	beforeEach(inject(function(_invTransactionDetailsFactory_,_transactModel_,_transDetailsModel_,$httpBackend,$q,Restangular,_$window_,_fticCommonUtils_,_FileSaver_,_toaster_){				
		Restangular = Restangular;
		$q = $q;		
		transactModel = _transactModel_;
		transactModel.downloadTransactDetails = function(body){
			var end = "transact/downloadTransSlip";
			var params = {};
			params.guId = "878";
			var deferred = $q.defer();
			Restangular.one(end).customPOST(body, "", params, {}).then(function (downloadDetails) {			  
			  deferred.resolve(downloadDetails);
			}, function (resp) {
			  deferred.reject(resp);			  
			});
			return deferred.promise;	
		};
		transDetailsModel = _transDetailsModel_;
		invTransactionDetailsFactory = _invTransactionDetailsFactory_;		
		httpBackend = $httpBackend;		
		$window = _$window_;
        $window.ga = function() {};			
        fticCommonUtils = _fticCommonUtils_;
        FileSaver = _FileSaver_;
        toaster = _toaster_;
	}));	
	
	function dataSetterTest(type){
		expect(invTransactionDetailsFactory.type).toBe(type);
		expect(invTransactionDetailsFactory.headerText).toBe(type.toUpperCase()+" Details");				
		expect(transDetailsModel.getTransactionDetails(type)[0].value).toBe("17023676");		
	}

	it("dataSetter should be defined",function(){
		expect(invTransactionDetailsFactory.dataSetter).toBeDefined();
	});

	it("callPDFService should be defined",function(){
		expect(invTransactionDetailsFactory.callPDFService).toBeDefined();
	});

	it("dtpDateSetter should be defined",function(){
		expect(invTransactionDetailsFactory.dtpDateSetter).toBeDefined();
	});	

	it("should set the data for the switch transaction",function(){
		invTransactionDetailsFactory.dataSetter("switch");
		dataSetterTest("switch");
	});

	it("should set the data for the stp transaction",function(){
		invTransactionDetailsFactory.dataSetter("stp");
		dataSetterTest("stp");
	});

	it("should set the data for the swp transaction",function(){
		invTransactionDetailsFactory.dataSetter("swp");
		dataSetterTest("swp");
	});

	it("should set the data for the cancel an stp transaction",function(){
		invTransactionDetailsFactory.dataSetter("cancelStp");
		dataSetterTest("cancelStp");
	});

	it("should set the data for the redeem transaction",function(){
		invTransactionDetailsFactory.dataSetter("redeem");
		dataSetterTest("redeem");
	});

	it("should set the data for the dtp transaction",function(){
		invTransactionDetailsFactory.dtpDateSetter("dtp");
		expect(invTransactionDetailsFactory.type).toBe("dtp");		
		expect(transDetailsModel.getTransactionDetails("dtp")[0].value).toBe("17023676");		
	});	

	it("should handle the pdf service successfully",function(){		
		spyOn(FileSaver,"saveAs").and.callFake(function(){});
		httpBackend.expectPOST('http://localhost:3030/transact/downloadTransSlip?guId=878').respond(200,{
    		'download':{
        		'strDocBase64':'JVBERi0xLjUNJeLjz9MNCjgzMSAwIG9iajw8L0hbNDUzNiA0MTk4XS9MaW5lYXJpemVkIDEvRSAxNTA5NTAvTCAyODYwNDE5L04gOC9PIDg0NC9UIDI4NDM3NTE+Pg1lbmRvYmoNICAgICAgICAgICAgDQp4cmVmDQo4MzEgMjEyDQowMDAwMDAwMDE2IDAwMDAwIG4NCjAwMDAwMDg3MzQgMDAwMDAgbg0KMDAwMDAwNDUzNiAwMDAwMCBuDQowMDAwMDA5MDg5IDAwMDAwIG4NCjAwMDAwMTI0MTIgMDAwMDAgbg0KMDAwMDAxMjQ2NSAwMDAwMCBuDQowMDAwMDEyNTE4IDAwMDAwIG4NCjAwMDAwMTI1NzEgMDAwMDAgbg0KMDAwMDAxMjYyNCAwMDAwMCBuDQowMDAwMDEyNjc3IDAwMDAwIG4NCjAwMDAwMTI3MzAgMDAwMDAgbg0KMDAwMDAxMjc4MyAwMDAwMCBuDQowMDAwMDEyODM2IDAwMDAwIG4NCjAwMDAwMTI4ODkgMDAwMDAgbg0KMDAwMDAxMzM0NiAwMDAwMCBuDQowMDAwMDEzODIyIDAwMDAwIG4NCjAwMDAwMTM5NzIgMDAwMDAgbg0KMDAwMDAxNDEyNCAwMDAwMCBuDQowMDAwMDE0Mjc1IDAwMDAwIG4NCjAwMDAwMTQ0MjYgMDAwMDAgbg0KMDAwMDAxNDU3OCAwMDAwMCBuDQowMDAwMDE0NzMwIDAwMDAwIG4NCjAwMDAwMTQ4ODIg'
    		}});
		invTransactionDetailsFactory.callPDFService("switch");				
		httpBackend.flush();
		expect(FileSaver.saveAs).toHaveBeenCalledWith(fticCommonUtils.convertBase64ToBlob('JVBERi0xLjUNJeLjz9MNCjgzMSAwIG9iajw8L0hbNDUzNiA0MTk4XS9MaW5lYXJpemVkIDEvRSAxNTA5NTAvTCAyODYwNDE5L04gOC9PIDg0NC9UIDI4NDM3NTE+Pg1lbmRvYmoNICAgICAgICAgICAgDQp4cmVmDQo4MzEgMjEyDQowMDAwMDAwMDE2IDAwMDAwIG4NCjAwMDAwMDg3MzQgMDAwMDAgbg0KMDAwMDAwNDUzNiAwMDAwMCBuDQowMDAwMDA5MDg5IDAwMDAwIG4NCjAwMDAwMTI0MTIgMDAwMDAgbg0KMDAwMDAxMjQ2NSAwMDAwMCBuDQowMDAwMDEyNTE4IDAwMDAwIG4NCjAwMDAwMTI1NzEgMDAwMDAgbg0KMDAwMDAxMjYyNCAwMDAwMCBuDQowMDAwMDEyNjc3IDAwMDAwIG4NCjAwMDAwMTI3MzAgMDAwMDAgbg0KMDAwMDAxMjc4MyAwMDAwMCBuDQowMDAwMDEyODM2IDAwMDAwIG4NCjAwMDAwMTI4ODkgMDAwMDAgbg0KMDAwMDAxMzM0NiAwMDAwMCBuDQowMDAwMDEzODIyIDAwMDAwIG4NCjAwMDAwMTM5NzIgMDAwMDAgbg0KMDAwMDAxNDEyNCAwMDAwMCBuDQowMDAwMDE0Mjc1IDAwMDAwIG4NCjAwMDAwMTQ0MjYgMDAwMDAgbg0KMDAwMDAxNDU3OCAwMDAwMCBuDQowMDAwMDE0NzMwIDAwMDAwIG4NCjAwMDAwMTQ4ODIg', 'application/pdf'),'switch.pdf');
	});		

	it("should show the error when pdf service is failed",function(){		
		spyOn(toaster,"error");
		httpBackend.expectPOST('http://localhost:3030/transact/downloadTransSlip?guId=878').respond(400,failureResponse);
		invTransactionDetailsFactory.callPDFService("switch");				
		httpBackend.flush();
		expect(toaster.error).toHaveBeenCalledWith(failureResponse[0].errorDescription);		
	});	
});

		  