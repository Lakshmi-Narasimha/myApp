/**
 * @ngdoc property
 * @name soChart Directive
 
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Displays the Portfolio Composition bar graph with AUM displayed against the various asset categories.
 *
 **/
 'use strict';


 var fticInvGoalCurrentPlansFunds = function(fticLoggerMessage, loggerConstants, currentPlanFundsService, investorEventConstants) { 
  return {
    template: require('./invGoalCurrentPlans.html'),
    restrict: 'E',
    controller: ['$scope', function($scope){
      $scope.currentPlans = [];
      $scope.smartSolnsCurrentPlanData = [];
      $scope.$on(investorEventConstants.smartSolutions.CURR_FUNDS_DATA, function($event) {
          $scope.currentPlans = currentPlanFundsService.getCurrentPlanFunds();
          angular.forEach($scope.currentPlans,function(obj){
            var gridRow = {};
            gridRow.fund = obj.funddesc;
            gridRow.investmentamount = obj.invamount;
            gridRow.currentvalue = obj.mktvalue //currentvalue;
            gridRow.returns = obj.returns;
            $scope.smartSolnsCurrentPlanData.push(gridRow);
          }); 
      }); 
      
      
      var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemp.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti_Info"></span></div>'+
                '<script type="text/ng-template" id="returnTemp.html">' +
                '<div><button type="button" class="btn panel-orange-btn m0">Returns calculation will be displayed</button></div></script>';
      $scope.smartSolnsCurrentPlanColumnDefs = [
          { field: 'fund', displayName: 'Fund', width:'250', pinnedLeft: true},
          { field: 'investmentamount', displayName: 'Investment Amount', width:'255', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass: 'text-right'},
          { field: 'currentvalue', displayName: 'Current Value', width:'250', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass: 'text-right'},
          { field: 'returns', displayName: 'Returns', width:"120",headerCellTemplate:returnsTemplate,headerCellClass:'fti-grid-headercell text-right media-vtop pt- pr-', cellClass:'text-right'}
      ]; 

    }]
  }
};     


fticInvGoalCurrentPlansFunds.$inject = ['fticLoggerMessage', 'loggerConstants','currentPlanFundsService', 'investorEventConstants'];
module.exports = fticInvGoalCurrentPlansFunds;   
