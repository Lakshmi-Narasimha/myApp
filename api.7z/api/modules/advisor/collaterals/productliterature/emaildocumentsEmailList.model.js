// emailDetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var emailDetailsSchema = new mongoose.Schema({
    emailDetails: {
        type: Array,
        "default": []
    }
});

var emailDetailsLookUp = mongoose.model('emailDetailsLookUp', emailDetailsSchema);
/*json order: investor book-*/
var emailDetailsModel = new emailDetailsLookUp({
  "emailDetails": [{
    "title":"advisor email 1",
    "key":0
  },{
    "title":"advisor email 2",
    "key":1
  },{
    "title":"advisor email 3",
    "key":2
  }]
});

emailDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating emailDetailsLookUp table, please contact admin...');
    } else {
        emailDetailsLookUp.remove({}, function(err) {
            console.log('emailDetailsLookUp collection removed');
           emailDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating emailDetailsLookUp table, please contact admin...');
                }
                console.log('emailDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = emailDetailsLookUp;
