'use strict';

var invTrendsModelService= function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _invTreDtls = null;

    var invTrendsModel = {
        fetchInvTrendsDtls : function (params) {
            var params = {};
            params.guId = authenticationService.getUser().guId;
            var deferred = $q.defer();
            Restangular.one('smartsolution/investorTrends').get(params).then(function (intDetails) {
                deferred.resolve(intDetails);
                console.log("Investor Trends Data",intDetails[0]);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getInvTrendsDtls : function () {
                 return _invTreDtls;
        } ,
        setInvTrendsDtls : function (invTrendsData) {
            _invTreDtls = invTrendsData;
        }

    };
    return invTrendsModel;

};

invTrendsModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = invTrendsModelService;
