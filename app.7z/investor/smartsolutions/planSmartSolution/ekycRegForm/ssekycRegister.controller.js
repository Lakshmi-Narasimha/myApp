'use strict';
// Controller naming conventions should start with an uppercase letter

function ekycRegstrController($scope, $state, transactModel, folioValidationInitialLoader, folioValidationModelService, transactEventConstants, selectInvestorModel, investorRegistrationModel, formDetailsModel, $filter, authenticationService, fundDetails, TransactConstant, toaster) {
    console.info("Ekyc Register Controller!!");
    $scope.isFirstAccordianOpened = {};
    $scope.isFirstAccordianOpened.open = true;
    $scope.header.title = "E-KYC";
    $scope.showError = false;
    $scope.holderData = [];
    var requestObject = {};
    //$scope.fromStateVariable = transactModel.getTransactType();
     $scope.inputObj = transactModel.getSelectedFolioDts().holderDetails;
    transactModel.setStateValue({ key: "Fund" })
    $scope.isInvestor = authenticationService.isInvestorLoggedIn();
    // $scope.formMaha = formEkyc.cntryObject.value;
    // console.log("formMaha....", $scope.formMaha);
    
    $scope.holderData = transactModel.getInstantKyc();
    $scope.isNewFolio = transactModel.getIsNewFolio();
    console.log("$scope.fromStateVariable....", $scope.holderData);
    angular.forEach($scope.holderData, function(obj, k) {
        if (obj.name == null && obj.type == "Firstholder") {
            var dtls = {
                custName: "",
                pan: "",
                emailId: "",
                mobile: "",
                holders: [{
                    name: ""
                }, {
                    name: ""
                }, {
                    name: ""
                }]
            }
            transactModel.setInvestorDetails(dtls);
        }

    })
    $scope.formDataObject = [];
    // console.log("holderDataTitle....", $scope.holderData[0].Title);
    console.log("holderData.....", $scope.holderData);
    $scope.checkEkyc = function() {

        function invRegSuccess(data) {
            console.log(data)
            investorRegistrationModel.setNewInvestorFolioId(data.folioId);
            var investorDetailsNew = transactModel.getInvestorDetails();
            if (transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
                investorDetailsNew.folioId = data.folioId;
            }
            transactModel.setInvestorDetails(investorDetailsNew);
            transactModel.setWebRefNo(data.webRefNo);
            fundDetails.removeFundDetails();
           
                $state.go('smartSol.planSmartSolution.ssBase.planInputDetails');
            
        }

        function invRegFailure(data) {
            console.log("Investor Registration Failure");
            var resetFatcaArray = [];
            $scope.kycForm.fatcaArray = resetFatcaArray;
            transactModel.setFatcaDetail(resetFatcaArray);
            toaster.error(data.data[0].errorDescription);
        }
        //test data - buy new folio
        $scope.kycForm.$valid = true;

        if ($scope.kycForm.$valid) {
            var fatcaDetails = {};
            transactModel.openFundTab = true;
            //test data - need to remove - buy new folio
            transactModel.setFatcaDetail([{ "name": "lalskdkdkkd", "pan": "CRZQW9295E", "aadhar": 123412341234, "mobile": 9876543214, "email": "abcjrioeororkosdddkf@gmail.com", "dob": "2005-01-02T18:30:00.000Z", "country": "India", "birthPlace": "hyderabad", "netWorth": 12312, "political": true, "relatedPolitical": "", "occDetails": "KYC application form � non-individuals", "incDetails": "KYC change details form � individuals", "taxDetailsArr": [{ "title": "MBARF", "value": "Multiple bank account registration form", "id": "taxId1" }], "taxIDNumArr": [{ "key": "taxId", "text": "Tax Identification Number", "name": "taxId1", "type": "text", "isRequired": true, "value": "" }], "termsCheck": true, "residentRadios": "no", "netWorthDate": "2016-12-15T04:49:48.311Z" }, { "name": "SHAILENDRA GODBOLE", "pan": "CGHQF6533E", "aadhar": 123412341234, "mobile": 9876543211, "email": "dgfbskjghgfddddkgsljglgj@gma.com", "dob": "2005-01-23T18:30:00.000Z", "country": "India", "birthPlace": "hyderabad", "netWorth": 12131, "political": true, "relatedPolitical": true, "occDetails": "KYC application form � non-individuals", "incDetails": "KYC change details form � individuals", "taxDetailsArr": [{ "title": "MBARF", "value": "Multiple bank account registration form", "id": "taxId1" }], "taxIDNumArr": [{ "key": "taxId", "text": "Tax Identification Number", "name": "taxId1", "type": "text", "isRequired": true, "value": "" }], "termsCheck": true, "residentRadios": "no", "netWorthDate": "2016-12-15T04:49:48.461Z", "type": "Secondholder" }]);

            $scope.$broadcast(transactEventConstants.transact.FATCA_DETAILS);
            requestObject.bodyObj = {};
            if (transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
                // $scope.$broadcast(transactEventConstants.transact.FATCA_DETAILS);
                fatcaDetails = transactModel.getFatcaDetail();
                var invDtls = {};
                invDtls.custName = fatcaDetails[0].name;
                invDtls.pan = fatcaDetails[0].pan;
                invDtls.emailId = fatcaDetails[0].email;
                invDtls.mobile = fatcaDetails[0].mobile;
                invDtls.holders = [];
                //invDtls.folioId = "";
                invDtls.holdingType = fatcaDetails.length == 1 ? "Single" : "Joint";
                requestObject.bodyObj.holdingType = fatcaDetails.length == 1 ? "S" : "A";
                angular.forEach(fatcaDetails, function(obj, key) {
                    invDtls.holders.push({ 'name': obj.name });
                });
                selectInvestorModel.setSelectedInvestorDtls(invDtls);
                transactModel.setInvestorDetails(invDtls);
            }

            /*Fatca form service integration - start*/
            requestObject = {};
            var investorDetailsObj = {
                holderDetails: transactModel.getFatcaDetail(),
                holdingType: '',
                isNomineeExists: false,
                isFolioExists: false
            };
            if (transactModel.transactModeOfHolding) {
                investorDetailsObj.holdingType = (transactModel.transactModeOfHolding === 'eitherRSurvivor') ? TransactConstant.common.EITHER_SURVIVOR_HOLDING_CODE : ((transactModel.transactModeOfHolding === 'single') ? TransactConstant.common.SINGLE_HOLDING_CODE : '');
            } else {
                investorDetailsObj.holdingType = (transactModel.getInvestorDetails() && transactModel.getInvestorDetails().holders.length > 1) ? TransactConstant.common.EITHER_SURVIVOR_HOLDING_CODE : TransactConstant.common.SINGLE_HOLDING_CODE;
            }

            if (transactModel.getInvestorDetails().folioId && !transactModel.isNewInvestor && !transactModel.getIsNewFolio()) {
                investorDetailsObj.isFolioExists = true;
                investorDetailsObj.folioId = transactModel.getInvestorDetails().folioId;
            }
            requestObject = investorRegistrationModel.postFatcaDetails(investorDetailsObj);
            investorRegistrationModel.fetchinvestorRegDetails(requestObject).then(invRegSuccess, invRegFailure);
            /*Fatca form service integration - close*/
        }
        console.log("validations");


    }

    $scope.$on('yes', function() {
        transactModel.setIsNewFolio(true);
        if (!$scope.isInvestor) {
            // if ($scope.fromStateVariable == "BUYFUND") {
            //     $state.go('transact.base.buy');
            // } else {
            //     $state.go('transact.base.sip');
            // }
        } else {
            // if ($scope.fromStateVariable == "BUY") {
            //     $state.go('transact.base.buy');
            //     //buy new folio
            //     // var keyValueList = [
            //     //     { key: 'Investment Preference', value: 'Financial Advisor' },
            //     //     { key: 'Adviser Name', value: code },
            //     //     { key: 'ARN Code', value: advisorArnCode }
            //     // ];
            //     // transactNowModel.setkeyValueInvPreferData(keyValueList);
            //     // $scope.$emit('setInvestorPreference', keyValueList);
            // }
        }
    });
    $scope.$on('no', function() {
        transactModel.setIsNewFolio(false);
        angular.forEach(transactModel.getFolioDet(), function(value, key) {
            if (value.folioId === folioValidationModelService.getFolioValidationDtls().folioNo) {
                value.index = key;
                transactModel.setSelectedFolioDts(value);
            }
        });
        if (!$scope.isInvestor) {
            // if ($scope.fromStateVariable == "BUYFUND") {
            //     $state.go('transact.base.buy');
            // } else {
            //     $state.go('transact.base.sip');
            // }
        } else {
            // if ($scope.fromStateVariable == "BUY") {
            //     $state.go('transact.base.buy');
            //     var keyValueList = [
            //         { key: 'Investment Preference', value: 'Financial Advisor' },
            //         { key: 'Adviser Name', value: code },
            //         { key: 'ARN Code', value: advisorArnCode }
            //     ];
            //     transactNowModel.setkeyValueInvPreferData(keyValueList);
            //     $scope.$emit('setInvestorPreference', keyValueList);
            // }
        }
    });
}

ekycRegstrController.$inject = ['$scope', '$state', 'transactModel', 'folioValidationInitialLoader', 'folioValidationModelService', 'transactEventConstants', 'selectInvestorModel', 'investorRegistrationModel', 'formDetailsModel', '$filter', 'authenticationService', 'fundDetails', 'TransactConstant', 'toaster'];
module.exports = ekycRegstrController;
