/**
 * @ngdoc property
 * @name fticBuyReviewDetails Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Details.
 *
 **/
'use strict';

var fticBuyReviewDetails = function (bankDtlsModel,eventConstants, TransactConstant) {
    return {
        template: require('./buyReviewDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {

            $scope.keyValuePairs = [
                {
                    text: TransactConstant.transact.TOTAL_INVSTMNT_AMT,
                    value: '<span class="icon-fti_rupee"></span>'+bankDtlsModel.getTotalAmount()
                },
                {
                    text: TransactConstant.transact.MODE_OF_PAYMENT,
                    value: bankDtlsModel.getPaymentMethod()
                },
                {
                    text: TransactConstant.transact.BANK_DETAILS,
                    value: bankDtlsModel.getSelectedBank()
                }
            ];            
            
            var listener = $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){ 
                $scope.$emit("NAVIGATE_TO_TRANSACT", {key: TransactConstant.transact.Payment_Key});  
            }); 
        }]
    };
};

fticBuyReviewDetails.$inject = ['bankDtlsModel','eventConstants', 'TransactConstant'];
module.exports = fticBuyReviewDetails;