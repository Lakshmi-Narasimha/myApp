/**
 * @ngdoc directive
 * @name fticKeyValueTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticKeyValueTile will display the kye value tiles for "My profile - Grant Access" .
 * 
 *
 **/

'use strict';

var keyValueTile = function() {
    return {
            template: require('./keyValueTile.html'),
            restrict: 'E',
            replace: true,
            // transclude: true,           
            scope: {
                keyValueObject: '='
            }
        };
};

keyValueTile.$inject = [];
module.exports = keyValueTile;