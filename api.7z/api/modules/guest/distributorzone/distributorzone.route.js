var express = require('express'),
    router = express.Router(),
    AccountStatementModel = require('./accountStatement/accountStatement.model');
    

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */

router.route('/getAccountStatementDtls')
.get(function (req, res) {
    AccountStatementModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].accountStatementObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].accountStatementObject);
        }

    });

});

router.route('/registerOnline')
.post(function (req, res) {
    if(req.body){
        res.json({'transactionStatus': 'S'});
    } else {
        res.send(error);
    }

});

   
module.exports = router;
