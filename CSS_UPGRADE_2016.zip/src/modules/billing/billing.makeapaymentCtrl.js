/**
 * @ngdoc property
 * @name Billing MakePayment
 * @requires $rootScope
 * @requires submitPaymentDetailsService
 * @requires sendEmailService
 * @description
 *
 * -This is Makepayment controller in Billing module.
 *
 */
(function() {
    'use strict';

    function makeapaymentCtrl($scope, billingUtils, $state, submitPaymentDetailsService, sendEmailService, $loader, $rootScope, errorDefaultConstant) {
        var paymentVM = this;
        paymentVM.billingdata = billingUtils.getBillingData();
        paymentVM.submitResObj = {};
        $rootScope.bgcolor = true;

        if (!paymentVM.billingdata) {
            $state.transitionTo('billing.authentication');
        }

        // This is for send Email modal popup
        /*paymentVM.isValid = function(Emailform) {
            $scope.$emit("submitted", paymentVM.email);
            paymentVM.email = {};
            paymentVM.closeModal = function(isCancelClicked) {
                document.getElementById("EmailAddressForm").reset();
            };
        };*/

        $scope.$on('submit-paybill', function(event, billingInfo) {
            paymentVM.submitPayment(billingInfo, function(data) {
                if (paymentVM.submitResObj.isSubmitSuccess) {
                    billingInfo.confirmationNumber = data.confirmationNumber;
                    billingInfo.message = 'Your confirmation number is #' + billingInfo.confirmationNumber;
                    billingInfo.billingview = 'confirm';
                } else {
                    billingInfo.confirmationNumber = null;
                    billingInfo.message = data.uiErrorDisplayMessage || errorDefaultConstant.fileNotFound.defaultMessage;
                    billingInfo.billingview = 'unsuccessful';
                }

            });
        });

        function successSubmitPayment(data, successCallback) {
            if (data.confirmationNumber && angular.lowercase(data.transactionStatus) === 's') {
                paymentVM.submitResObj.data = data;
                paymentVM.submitResObj.isSubmitSuccess = true;
                paymentVM.paymentSuccessfullData.confirmationNumber = data.confirmationNumber;
            } else {
                var errCode = data.transactionCode;
                $state.transitionTo('billing.authentication', {
                    errorData: data
                });

                /*if (errCode && (errCode >= 2000 && errCode <= 3000)) {
                    $state.transitionTo('billing.authentication', {
                        errorData: data
                    });
                }*/
            }
            successCallback(data);
        }

        function failureSubmitPayment(data, successCallback) {
            paymentVM.paymentSuccessfullData = null;
            paymentVM.submitResObj.isSubmitSuccess = false;
            $state.transitionTo('billing.authentication', {
                errorData: data
            });
        }

        paymentVM.submitPayment = function(data, successCallback) {
            paymentVM.paymentSuccessfullData = data;
            var dataObj = {
                "functionName": "Prelogin",
                "userId": null,
                "loginId": null,
                "agentOfRecord": data.agentOfRecord,
                "billingAccountNumber": data.billingAccountNumber,
                "paymentType": "DP", //to do
                "transactionAmount": data.amountPayingNow,
                "transactionCurrency": "USD",
                "postedDate": data.payingDateNow,
                "bankOrCreditCardIndicator": data.paymentListNow.isCard ? 'CC' : 'EFT',
                "cardType": null, //todo data.paymentListNow.cardtype
                "lastFourDigitofCardNumber": (data.paymentListNow.isCard ? (data.paymentListNow.digitsCardNum || null) : null),
                "cardNumber": null,
                "cardBrand": null,
                "cardValidFrom": null,
                "cardExpirationdate": null,
                "cardHolderName": (data.paymentListNow.isCard ? (data.paymentListNow.cardHolderName || null) : null),
                "cardZipCode": (data.paymentListNow.isCard ? (data.paymentListNow.zipCode || null) : null),
                "bankAccountNumber": (!data.paymentListNow.isCard ? (data.paymentListNow.accountNumber || null) : null),
                "bankRoutingNumber": data.paymentListNow.routingnumber || null,
                "bankAccountType": (!data.paymentListNow.isCard ? (data.paymentListNow.bankAccountType === 'SAV' ? 'S' : 'C') : null),
                "bankAccountHolderName": (!data.paymentListNow.isCard ? (data.paymentListNow.accountHolderName || null) : null),
                "lastFourDigitsOfBankAccountNumber": (!data.paymentListNow.isCard ? (data.paymentListNow.digitsCardNum || null) : null),
            };

            dataObj.cardNumber = (data.paymentListNow.isCard ? data.paymentListNow.cardNumber : null);
            var cardcategory = angular.uppercase(data.paymentListNow.cardCategoryDisplay);
            dataObj.cardBrand = (cardcategory && cardcategory === 'DS') ? 'DI' : cardcategory;

            var expDateMonth = data.paymentListNow.expMonth || null;
            var expDateYear = data.paymentListNow.expYear || null;
            dataObj.cardExpirationdate = expDateMonth && expDateYear ? ((expDateMonth + '').length > 1 ? (expDateYear + '-' + expDateMonth + '-01') : (expDateYear + '-0' + expDateMonth + '-01')) : null;

            $loader.start();
            submitPaymentDetailsService.submitPaymentDetails(dataObj).then(function(data) {
                successSubmitPayment(data, successCallback);
            }, function(data) {
                failureSubmitPayment(data, successCallback);
            }).finally(function() {
                $loader.stop();
            });
        };

        var sendEmail = function(emailAdd) {
            var sendEmailQuery = {
                "userType": null,
                "userId": null,
                "sourceSystem": null,
                "policyContractNumber": null,
                "paymentMethod": null,
                "paymentDate": null,
                "paymentConfirmationNumber": null,
                "password": null,
                "loginId": null,
                "Link_URL": null,
                "lastName": null,
                "functionName": "SendPaymentConfirmationEmail",
                "firstName": null,
                "email": null,
                "ecn": null,
                "clientNumber": null,
                "billingAccountNumber": null,
                "amountPaid": null,
                "agentLastName": null,
                "agentFirstName": null
            };

            sendEmailQuery.paymentMethod = (!paymentVM.paymentSuccessfullData.paymentListNow.isCard ? paymentVM.paymentSuccessfullData.paymentListNow.cardDisplayType : paymentVM.paymentSuccessfullData.paymentListNow.creditCardCategoryDisplay) + '(..' + (paymentVM.paymentSuccessfullData.paymentListNow.digitsCardNum) + ')';
            sendEmailQuery.paymentDate = paymentVM.paymentSuccessfullData.payingDateNow;
            sendEmailQuery.paymentConfirmationNumber = paymentVM.paymentSuccessfullData.confirmationNumber;
            sendEmailQuery.email = emailAdd;
            sendEmailQuery.amountPaid = paymentVM.paymentSuccessfullData.amountPayingNow;
            sendEmailQuery.billingAccountNumber = paymentVM.paymentSuccessfullData.billingAccountNumber;

            var emailReponseHandler = function(data) {
                $scope.$broadcast('submit-email', data);
            };

            sendEmailService.sendEmail(sendEmailQuery).then(emailReponseHandler, emailReponseHandler);
        };

        $scope.$on('print-details', function(event, printdata) {
            paymentVM.paymentSuccessfullData = printdata;
        });

        $scope.$on('send-email', function(event, emailAdd) {
            sendEmail(emailAdd);
        });

    }

    angular
        .module('CSS.billing')
        .controller('makeapaymentCtrl', ['$scope', 'billingUtils', '$state', 'submitPaymentDetailsService', 'sendEmailService', '$loader', '$rootScope', 'errorDefaultConstant', makeapaymentCtrl]);

})();
