/**
 * @ngdoc property
 * @name eMandateDetails Directive
 * @requires investorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Transaction Summary data in a ui-grid.
 *
 **/
'use strict';

var eMandateDetails = function(eMandateModel, investorEventConstants, fticLoggerMessage, loggerConstants, mytransactionsConstants, $timeout, $state, eMandateIntialLoadService, $filter, investorEvents) {
    return {
        template: require('./eMandateDetails.html'),
        restrict: 'E',
        replace: true,
        controller: function($scope) {
        	console.log('eMandateDetails controller');
        	var _emandate = null;
        	$scope.showConfirmation = false;
            $scope.loadGetEmandate = false;
        	$scope.popupText = 'Are you sure you want to remove this e-mandate ?';
        	$scope.popUpText = ' ';
        	$scope.yesText = "OK";
            $scope.noText = "Cancel";

        	var eMandateDetails = eMandateModel.getEMandateDetails();
        	//$scope.availablebanks = eMandateDetails.availableBanks;
            angular.forEach(eMandateDetails.emandateDetails, function(eachEMandate){                
                eachEMandate.startDate = $filter('date')(new Date(eachEMandate.startDate), 'dd MMM yyyy');
                eachEMandate.endDate = $filter('date')(new Date(eachEMandate.endDate), 'dd MMM yyyy');
            });
        	$scope.emandates = eMandateDetails.emandateDetails;

        	$scope.deleteEmandate = function(emandate) {
        		console.log(emandate);
        		_emandate = emandate;
        		$scope.showConfirmation = true;        		
        	},
            $scope.$on(investorEventConstants.accountSettings.LOAD_NEW_EMANDATE_DATA_EVENT, function(){
                $scope.loadGetEmandate = true;
            });

        	$scope.newEmandate = function(){
        		console.log('newEmandate');
                //eMandateIntialLoadService.getFolios($scope);                
                $state.go('newEmandate');
        	},
        	$scope.$on("yes", function () {
                console.log(_emandate);
	            $scope.showConfirmation = false;
	            eMandateIntialLoadService.removeEmandates($scope, _emandate);
	            return;
	        }),
	        $scope.$on("no", function () {
	            $scope.showConfirmation = false;
	            return;
	        });
            $scope.$on(investorEventConstants.accountSettings.LOAD_EMANDATE_DATA_EVENT, function(){                
                $scope.eMandate.loadGetEmandate = false;
                $scope.$emit('loadingWithNewEmandates');
                
            });


        },
        link: function(scope, element, attrs, ctrl){
        	
        }
    };
};


eMandateDetails.$inject = ['eMandateModel', 'investorEventConstants', 'fticLoggerMessage', 'loggerConstants', 'mytransactionsConstants', '$timeout', '$state', 'eMandateIntialLoadService', '$filter', 'investorEvents' ];
module.exports = eMandateDetails;
