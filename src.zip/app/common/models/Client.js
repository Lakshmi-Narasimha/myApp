define(['jquery', 'lodash', 'backbone'], function ($, _, Backbone) {
    var Client = Backbone.Model.extend({
        defaults: function () {
            return {
                "id": undefined,
                "ctx": undefined,
                "firstNm": undefined,
                "lastNm": undefined,
                "orgNm": undefined,
                "fmtNm": undefined,
                "name": undefined
            };
        },
        populateFromServiceResponse: function (clientEntity) {
            const client = {
                "id": clientEntity.id,
                "ctx": clientEntity.ctx,
                "firstNm": clientEntity.firstNm,
                "lastNm": clientEntity.lastNm,
                "orgNm": clientEntity.orgNm,
                "fmtNm": clientEntity.fmtNm,
                "name": clientEntity.fmtNm + ' ' + (clientEntity.id ? clientEntity.id.substr(15) : '')
            }
            this.set(client);
            return this;
        }
    });
    return Client;
});