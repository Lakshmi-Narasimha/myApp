/**
 * @ngdoc property
 * @name paperLessModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - paperLessModel is a service model which consists the list of services required for paper less module.
 *
 **/
'use strict';


var otpModel = function(Restangular, $q, fticLoggerMessage, loggerConstants) {

    var  _aadharDetails = null;
    var otpVerModel = {

        fetchAadharDetails : function (searchQuery) {
            var deferred = $q.defer();
            Restangular.all('/ekycOTPVerification').getList(searchQuery).then(function (aadharDetails) {
                deferred.resolve(aadharDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setAadharDetails : function(aadharDetails){
        	_aadharDetails = aadharDetails;
        	return _aadharDetails;
        },   
        getAadharDetails : function(){
        	return _aadharDetails;
        },     
    };

    return otpVerModel;

    
};

otpModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = otpModel;
