/**
 * @ngdoc property
 * @name change Password Controller
 * @requires $state
 * @requires $scope
 * @description
 *
 * - change password controller deals with calling the services to load to change the current password to required password.
 *
 **/


'use strict';

function BankDetailsController($state, $scope,basisBankAccInitialLoader,basisBankAccModel,investorEventConstants, toaster, $filter, investorConstants,$timeout,eventConstants, $uibModal) {
    var BANK_DETAILS = $filter('translate')(investorConstants.accountsettings['BANK_DETAILS']),
        BASIS_BANK_ACCOUNT = $filter('translate')(investorConstants.accountsettings['BASIS_BANK_ACCOUNT']),
        BASIS_FOLIO = $filter('translate')(investorConstants.accountsettings['BASIS_FOLIO']),
        BANK_ACC_MATCH = $filter('translate')(investorConstants.accountsettings['BANK_ACC_MATCH']),
        EDIT_SUCCESS = $filter('translate')(investorConstants.accountsettings['EDIT_SUCCESS']),
        IMAGE_SIZE = $filter('translate')(investorConstants.accountsettings['IMAGE_SIZE']);

    $scope.statusTypes = [
        {
            label:BASIS_BANK_ACCOUNT,
            value:BASIS_BANK_ACCOUNT,
            selected: false
        },
        {
            label:BASIS_FOLIO,
            value:BASIS_FOLIO,
            selected: false
        }
    ];  
    $scope.radios = {selectedVal : BASIS_BANK_ACCOUNT};  

    $scope.listenChange = function () {
        $scope.showTab = null;
        if($scope.radios.selectedVal === BASIS_BANK_ACCOUNT)
        {
            $state.go('bankdetails');
            $timeout(function(){$scope.showTab = false;});
        }
        else if($scope.radios.selectedVal === BASIS_FOLIO)
        {
            $timeout(function(){$scope.showTab = true;});
        };       
    };        

    

    $scope.loadAddNewBank = function() {
        var modalInstance = $uibModal.open({
                  template : require('./components/confirmmodal/confirmModal.html'),
                  scope : $scope
                });
    }     
}
// $inject is necessary for minification. 
BankDetailsController.$inject = ['$state','$scope','basisBankAccInitialLoader','basisBankAccModel','investorEventConstants','toaster','$filter','investorConstants','$timeout','eventConstants','$uibModal'];
module.exports = BankDetailsController;