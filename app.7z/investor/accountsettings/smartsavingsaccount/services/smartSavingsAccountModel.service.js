/**
 * @
 *
 * - It will call restangular(network service) and resolve the data to wrapper.
 *   Also works like model with setters and getters.
 */

'use strict';

var smartSavingsAccountModel = function($q, Restangular) {
    var _selectedInvestorDtls = null;
    var _selectedInvestorRedeemDtls = null;
    var _selectedpaymentDtls = null;
    var smartSavingsAccountModel = {

        getSelectedInvestorDtls: function() {
            return _selectedInvestorDtls;
        },
        setSelectedInvestorDtls: function(selectedInvestorDtls) {
            _selectedInvestorDtls = selectedInvestorDtls;
        },
        getSelectedRedeemDtls: function() {
            return _selectedInvestorRedeemDtls;
        },
        setSelectedRedeemDtls: function(selectedInvestorDtls) {
            _selectedInvestorRedeemDtls = selectedInvestorDtls;
        },
        getSelectedPaymentDtls: function() {
            return _selectedpaymentDtls;
        },
        setSelectedPaymentDtls: function(selectedInvestorDtls) {
            _selectedpaymentDtls = selectedInvestorDtls;
        },

    };
    return smartSavingsAccountModel;
};

smartSavingsAccountModel.$inject = ["$q", "Restangular"];
module.exports = smartSavingsAccountModel;
