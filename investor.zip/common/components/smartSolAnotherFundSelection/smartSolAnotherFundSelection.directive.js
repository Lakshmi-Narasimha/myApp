/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolAnotherFundSelection = function($state) {
	return {
          template: require('./smartSolFundSelection.html'),
           restrict: 'E',
           replace: true,
            controller: function($scope, $element, $attrs){
              $scope.anotherfundSelection = "Franklin India Flexi Fund";
              },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

smartSolAnotherFundSelection.$inject = [];
module.exports = smartSolAnotherFundSelection;