/**
 * @ngdoc property
 * @name InvInvestmentPrefController
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Saved Smart Solutions controller for smartSolutions module.
 *
 **/

'use strict';

function InvInvestmentPrefController($scope, investorConstants, $state) {
    
    $scope.info = {
        heading: investorConstants.smartSolutions.INV_INVESTMENT_PREF
    };

    

    $scope.$on('setInvestorPreference', function() {

        $state.go('smartSol.planSmartSolution.invProceedToBuy.invPBFundDetails');
    });
}

InvInvestmentPrefController.$inject = ['$scope', 'investorConstants', '$state'];
module.exports = InvInvestmentPrefController;
