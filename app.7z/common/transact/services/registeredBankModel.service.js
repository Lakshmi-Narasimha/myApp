/**
 * @ngdoc service
 * @name registeredBankModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var registeredBankModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, transactModel, selectInvestorModel, $state) {
    var _registeredBank = null,
    _defaultBank = null;

    var registeredBankModel = {
        
        fetchRegisteredBank : function () {
            var params = {};
            params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            params.folioId = selectInvestorModel.getSelectedInvestorDtls().folioId;
            if($state.current.name === "transact.base.redeem"){
                params.trxnType = "R";
            }else if($state.current.name === 'transact.base.swp' || $state.current.name === 'invTransact.base.swp'){
                params.trxnType = 'SWP';
            }
            params.paymentMethod = "N";
            
            var deferred = $q.defer();
            Restangular.one('transact/paymentBanksByFolio').get(params).then(function (registeredBank) {
                deferred.resolve(registeredBank);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        getRegisteredBank: function() {
            return _registeredBank;
        },

        setRegisteredBank: function(registeredBank) {
            _registeredBank = registeredBank;
        },

        setDefaultBankDetails: function(registeredBank){
            _defaultBank = registeredBank;
        },

        getDefaultBankDetails: function() {
            return _defaultBank;
        }

    };
    return registeredBankModel;
};

registeredBankModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', 'transactModel', 'selectInvestorModel', '$state'];

module.exports = registeredBankModel;