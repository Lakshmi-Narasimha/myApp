/**
 * @ngdoc property
 * @name SIP Calculator Controller
 * @requires $scope
 * @requires $state
 * @requires constants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function taxAdvantageCalculatorController($scope, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, taxCalculatorModel, taxCalculatorInitialService, sipCalculatorModel, calculatorsEventConstants, $state) {
  $scope.init = function () {
    if($state.current && $state.current.data && $state.current.data.isAdvisor) {
      $scope.isAdvisor = $state.current.data.isAdvisor;
    }
    $scope.$emit("setBreadCrumb",{
     cat : "funds",
     subcat : "tools",
     breadCrumb :{
      label:'Tax Advantage Calculator',
      state : ''
    }   
  });
    taxCalculatorInitialService.loadAllServices($scope);
  };

  $scope.init();   
    $scope.selectOptions = {
      "Fund" : []
    };
    $scope.$on(calculatorsEventConstants.FUND_DETAILS, function(event, data){
      $scope.selectOptions.Fund.push({"title":"Select Fund", "category" : ""});  
      var fundlist = sipCalculatorModel.getFundDetails().codeValueList;
      for(var fd=0, len=fundlist.length;fd<len;fd++) {
        $scope.selectOptions.Fund.push({
          "title" : fundlist[fd].value,
          "category" :  fundlist[fd].code
        })    
      }
    });
    $scope.inputObject = {
        Fund :{
            required: true,
            name : "fundSelection",
            label: "Select Fund"
        }
    };
    
    $scope.userInput= { 
      Amount: {
            key: "", 
                text: "Investment Amount <span class='icon-fti_rupee'></span>",
                value: "",
                pattern:/^[0-9]*$/,
                message: "",
                isMasked: false,
                isRequired: true,
                type: "number"
                
              },
      Tenure : {
            key: "", 
                text: "Investment Tenure",
                value: "",
                pattern:/^[0-9]*$/,
                message: "year",
                isMasked: false,
                isRequired: true ,
                type: "number"              
          }
    };


    $scope.$on(calculatorsEventConstants.TAX_CALCULATE,function(event,calculatorReq) {
      taxCalculatorModel.callTaxCalculatorData({"taxAdvantageCalculatorReq": calculatorReq},$scope.isAdvisor)
        .then(function (data) {
          taxCalculatorModel.setTaxCalculations(data.taxAdvantageCalculatorResp);
          $scope.$broadcast(calculatorsEventConstants.TAX_CALCULATE_GRID);
        }, function (data) {
          console.log("ERROR");
        })
    });

    $scope.$on(calculatorsEventConstants.RESET_DATA, function(event) {
    $scope.$broadcast(calculatorsEventConstants.TAX_RESET_DATA);
  }); 
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
taxAdvantageCalculatorController.$inject = ['$scope', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'taxCalculatorModel', 'taxCalculatorInitialService', 'sipCalculatorModel', 'calculatorsEventConstants', '$state'];
module.exports = taxAdvantageCalculatorController;