'use strict';
describe('Controller: cancelStpController', function() {
    var $controller,$scope,cancelStpController;

    beforeEach(angular.mock.module('advisor'));             

    beforeEach(inject(function($rootScope,_$controller_){  
        $controller = _$controller_;
        $scope = $rootScope.$new(); 
        
        $scope.header = {};
        loadController();           
    }));    

    function loadController(){
        cancelStpController = $controller('cancelStpController', { $scope: $scope });
    }

    it('should be defined',function(){
        expect(cancelStpController).toBeDefined();
    });

    it('should define the variables title,isShowReedemGrid',function(){
        expect($scope.header.title).toBe('Cancel an STP');
        expect($scope.isShowReedemGrid).toBe(false);  
    });
});


