'use strict';
describe('directive : my sips', function() {
    var $rootScope, $scope, $compile, validHTML, compiledElement, investorDashboardModelDataObj;

    var investmentData = {
		'mySips': {
            'hasInvested': 'Y',
            'description': '<p class="custom-bold">You have not yet invested in SIP.</p><p>1 line explaining the benefits of investing in SIPs-To be suggested by FT team.</p>',
            'totalActiveSips': 3,
            'monthlyInvestments': '3,000.00',
            'quarterlyInvestments': '15,000.00',
            'annualInvestments': '36,000.00'
        }
    };

    investorDashboardModelDataObj = {
	    getDashboardData: function() {
	        return investmentData;
	    }
	};

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('investorDashboardDetailsModel', investorDashboardModelDataObj);
        });
    });

    beforeEach(function() {
        angular.mock.inject(function($compile, $rootScope) {
            $rootScope = $rootScope;
            $compile = $compile;
            $scope = $rootScope.$new();

            validHTML = angular.element('<ftic-inv-my-sips></ftic-inv-my-sips>');
            compiledElement = $compile(validHTML)($scope);
            $scope.$digest();
        });
    });

    it('should be defined', function() {
        expect(compiledElement).toBeDefined();
    });

    it('should be available with data on dashboard info event and populate view', function() {
		$scope.$broadcast('investorDashboardInformation');
		expect(compiledElement.scope().isDataAvaiable).toBeDefined();
		expect(compiledElement.scope().mySipsConfig.hasInvested).toBeTruthy();
		expect(compiledElement.scope().mySipsConfig.totalActiveSips).toEqual(3);
        compiledElement.scope().$digest();
        expect($(compiledElement).find('.fti-active-sips .prop-1').text().trim()).toEqual('03');
	});

	it('should be shown error when data on dashboard is unavailable', function() {
		expect(compiledElement.scope().isDataAvaiable).toBeFalsy();
	});
});
