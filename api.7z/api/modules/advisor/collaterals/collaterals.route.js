var express = require('express'),
    router = express.Router(),
    EformSearchResultModel = require('./eforms/eformSearchResult.model'),
    EformPdfModel = require('./eforms/eformPdf.model'),
    TransSlipExistingFundsModel = require('./eforms/transactionSlipExistingFund.model');
    productDetailsModel = require('./productliterature/productLiteratureDetails.model');
    productLiteratureThemesModel = require('./productliterature/productLiteratureThemesTypes.model');
    emailDetailsModel = require('./productliterature/emaildocumentsEmailList.model');
    productLiteratureAllFundsModel = require('./productliterature/productLiteratureAllFunds.model');
    productFilterDetailsModel = require('./productliterature/productLiteratureFilterDetails.model');
    ProductLiteratureEmailDocumentsModel = require('./productliterature/productLiteratureEmailDocuments.model');

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */

//User Eform Search result
router.route('/getEformSearchResult')
    .get(function (req, res) {
        EformSearchResultModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].EformSearchResult.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].EformSearchResult);
            }

        });

});

//User Eform pdf
router.route('/getEformPdf')
    .get(function (req, res) {
        EformPdfModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].EformPdf.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].EformPdf);
            }

        });

});

router.route('/getTransSlipExistingFunds')
    .get(function (req, res) {
        TransSlipExistingFundsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].TransSlipExistingFundsObj.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].TransSlipExistingFundsObj);
            }

        });

});

router.route('/getProductDetailsData')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        productDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else {
                res.json(data[0].ProductDetails);
            }

        });
    });  

router.route('/getProductLiteratureThemesTypes')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        productLiteratureThemesModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].themeTypes.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].themeTypes);
            }

        });
    });  

    router.route('/getEmailList')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        emailDetailsModel.find(function (err, data) {
            if (err) {
                res.send(err);

            } else if (data[0].emailDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].emailDetails);
            }
         });    
    }); 


router.route('/getProductLiteratureAllFunds')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        productLiteratureAllFundsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);

            } else if (data[0].ProductLiteratureAllFunds.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].ProductLiteratureAllFunds);
            }

        });
    }); 

router.route('/getFilteredProductDetails')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        productFilterDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].ProductFilterDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].ProductFilterDetails);
            }

        });
    }); 

router.route('/postEmailDocuments')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ProductLiteratureEmailDocumentsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].ProductLiteratureEmailDocuments.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].ProductLiteratureEmailDocuments);
            }

        });
    });          
   
module.exports = router;
