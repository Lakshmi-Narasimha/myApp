// validateDtp.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ValidateDtpModelSchema = new mongoose.Schema({
    ValidateDtpResp: {
        type: Array,
        'default': []
    }
});

var ValidateDtpModelLookUp = mongoose.model('ValidateDtpModelLookUp', ValidateDtpModelSchema);

var ValidateDtp = new ValidateDtpModelLookUp({
    ValidateDtpResp: {
        'accountNo': '0389906480558',
        'folioId': '18556824',
        'webRefNo': 'STP000693'
    }
});

ValidateDtpModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidateDtpModelLookUp table, please contact admin...');
    } else {
        ValidateDtpModelLookUp.remove({}, function(err) {
            console.log('ValidateDtpModelLookUp collection removed');
            ValidateDtp.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating ValidateDtpModelLookUp table, please contact admin...');
                }
                console.log('ValidateDtpModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ValidateDtpModelLookUp;
