/**
 * @ngdoc directive
 * @name text-button
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - It is used as a common directive for displaying the text and the button. This directive accept the text ,  button text , background color (background color of the button), button link(navigation link , to which location it will redirect) and amount. 
 *  
 * 
 *
 **/

'use strict';

var fticTextButton = function() {
    return {
        template: require('./textbutton.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            buttonText: '@',
            buttonLink: '@',
            amount: '=',
            buttonBgColor: '@'
        },
        link: function(scope, Element, Attr, controller, transclude) {
            /*scope.onButtonClick = function(){
                $state.transitionTo(scope.buttonLink);
            };*/
            transclude(scope, function(transcludeEl) {
                angular.element(Element[0].querySelector('.transcluded-content')).append(transcludeEl);
            });
        }
    };
};

fticTextButton.$inject = [];
module.exports = fticTextButton;
