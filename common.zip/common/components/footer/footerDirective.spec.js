/* eslint-disable */
'use strict';

/*Unit test case for fticFooter*/

describe('directive: fticFooter', function() {

    var scope, compile, validHTML, httpBackend, timeout,
    footerObject = {
   "footer":[
      {
         "footerLinks":[
            {
               "text":"Careers",
               "url":""
            },
            {
               "text":"Media",
               "url":""
            },
            {
               "text":"Feedback",
               "url":""
            },
            {
               "text":"Reports",
               "url":""
            },
            {
               "text":"Risk Factors",
               "url":""
            },
            {
               "text":"Terms & Conditions",
               "url":""
            },
            {
               "text":"Disclaimer",
               "url":""
            },
            {
               "text":"Security & Privacy ",
               "url":""
            },
            {
               "text":"Help",
               "url":""
            }, 
            {
               "text":"Anti Corruption Policy",
               "url":""
            },
            {
               "text":"Voting Policy",
               "url":""
            },
             {
               "text":"Disclosure of Voting",
               "url":""
            }
           
         ],
         "footerIconLinks":[
            {
               "icon":"icon-fti_facebook"
            },
            {
               "icon":"icon-fti_twitter"
            },
            {
               "icon":"icon-fti_youtube"
            },
            {
               "icon":"icon-fti_linkedin"
            }
         ],
         "footerLogo":[
            {
               "image":"images/fti_footer_logo.jpg",
               "alt":"Franklin Templeton Logo"
            }
         ],
         "copyRight":[
            {
               "text":"Franklin Templeton Investments",
               "year":"1999-2016",
               "link":""
            }
         ]
      }
   ]
};

    validHTML = '<ftic-footer></ftic-footer>';
    beforeEach(angular.mock.module('common','common.elements.ftiFooter'));

    beforeEach(angular.mock.inject(function($compile, $rootScope, $httpBackend, $timeout) {
        scope = $rootScope.$new();
        httpBackend = $httpBackend;
        timeout = $timeout;
        compile = $compile;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();
        return compiledElem;
    }

    it('should not create seperate isolated scope', function() {
        httpBackend.expectGET('jsonservices/footer.json').respond(200, footerObject);
        var el = create(),
        isoScope = el.isolateScope();
        timeout.flush();
        httpBackend.flush();
        expect(isoScope).toBeUndefined();
    });

    it('should have first link text as in the object', function(){
        httpBackend.expectGET('jsonservices/footer.json').respond(200, footerObject);
        scope.footerLinks1 = [
            {
               "text":"Careers",
               "url":"careers"
            },
            {
               "text":"Media",
               "url":""
            },
            {
               "text":"Feedback",
               "url":""
            }];
            
        var ele = create();
        
        timeout.flush();
        httpBackend.flush();
        expect(angular.element(ele[0].querySelectorAll('div.fti-footerLink-row ul li a')[0]).text()).toEqual('Careers');

    });


});
