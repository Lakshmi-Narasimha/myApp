/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter


function ReviewSwitchController($scope, fticLoggerMessage, loggerConstants, switchDtlsToReviewModel, eventConstants, $filter, TransactConstant, $state, authenticationService) {

    
    var switchDetailsObj,amtOrUnits,amtOrUnitsVal;
    
    switchDetailsObj = switchDtlsToReviewModel.getData();
    
    

    if(switchDetailsObj.amount)
    {
        amtOrUnits = $filter('translate')(TransactConstant.transact.AMT_CAP);
        amtOrUnitsVal = switchDetailsObj.amount;
    }
    else if(switchDetailsObj.units)
    {
        amtOrUnits = $filter('translate')(TransactConstant.transact.UNITS_CAP);      
        amtOrUnitsVal = switchDetailsObj.units;
    }
    $scope.switchDetailsObj = [
          {
              text: $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
              value: switchDetailsObj.destinationFund.fundOptDesc
          },
          {
              text: $filter('translate')(TransactConstant.transact.ACC_NUM),
              value: switchDetailsObj.destinationFund.accNo
          },
          {
              text: $filter('translate')(TransactConstant.transact.SWITCH_TYPE),
              value: switchDetailsObj.switchType
          },            
          {
              text: amtOrUnits,
              value: amtOrUnitsVal
          }
    ];

    if(authenticationService.isInvestorLoggedIn()){
      $scope.config.toTxnDetailsState = "invTransact.txnDetails";
      $scope.config.toState = "invTransact.base.switch";
    } else{
      $scope.config.toTxnDetailsState = "transact.txnDetails.switch";
      $scope.config.toState = "transact.base.switch";
    }
    
    $scope.config.fromState = $state.current.name;
    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function(){
      switchDtlsToReviewModel.isSwitchEdited = true;
      $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'switch'});
    });

}
ReviewSwitchController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'switchDtlsToReviewModel', 'eventConstants', '$filter', 'TransactConstant','$state', 'authenticationService'];
module.exports = ReviewSwitchController;
