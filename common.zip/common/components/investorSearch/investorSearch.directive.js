/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var investorSearch = function($state, searchResultModel, eventConstants,$compile, unitHolderModel,$uibModal) {
	return {
            template: require('./investorSearch.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              channelSearchOptions: "="
            },
            controller:['$scope', function($scope){

              var pageRange = {},
                    pageOffset = 1,
                    limit = 5,
                    previousPage = 0
                    ;
                pageRange.limit = 5;
                pageRange.offset = 1;
                $scope.paginationObject = {
                    paginationTotal : 1,
                    currentPage : 1
                };
                $scope.pageChanged = function() {
                  $scope.showSearchResult = false;
                  if($scope.paginationObject.currentPage === 1){
                      pageRange.offset = 1;
                  }else{
                      pageRange.offset = (pageRange.limit * ($scope.paginationObject.currentPage-1)) + 1;
                  }
                  searchResultModel.fetchSearchResult($scope.searchQuery,pageRange).then (function (data) {
                    $scope.searchResult = [];
                    $scope.searchResult=data;
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;
                    
                    angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                        
                    })
                    
                    $scope.showSearchResult = true;
                  }, function (data) {
                      $scope.searchResult = [];
                  });
                }; 
                
                $scope.includeZeroBalanceAccounts = {};
                $scope.closePop = {};
                $scope.showSearchResult = false;
                $scope.ShowAllFundsGrid = false;
                $scope.activeVar = false;
                $scope.holder = [];
              
                // $scope.isOpen = true;
                var isStatusTemplate = '<div uib-popover-template="\'isVeiwCompTemplate.html\'" popover-is-open="col.colDef.value[row.entity.index]" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                              '<script type="text/ng-template" id="isVeiwCompTemplate.html">' +
                              '<div class="fti-popClass">' +
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:0,data:row.entity})" class="btn panel-orange-btn mt0">Valuation/Statements</button>' + 
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:1,data:row.entity})" class="btn panel-orange-btn">Systematic plans</button>' + 
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:2,data:row.entity})" class="btn panel-orange-btn">Transactions</button>' + 
                              '<button type="button" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'showTab\', {tabNo:3,data:row.entity})" class="btn panel-orange-btn">Subcriptions</button>' + 
                              '</div></script>';

                var infoTemplate = '<a class="icon-fti_moreInfo pull-left ui-grid-cell-contents" ng-if="row.entity.showHolderTT" ng-click="grid.appScope.$emit(\'openHolderModal\', row.entity.latestArr)"></a>';

              
                $scope.searchResult = [];
                $scope.fundDetailsGrid = [];
                $scope.gridOptions={};
               

                //var arr = [false,false,false,false];
                var arr = []

                $scope.gridOptions.columnDefs = [

                  { field: 'custName',displayName:'', width:"5%", value:arr,cellTemplate: isStatusTemplate, enableSorting:false, pinnedLeft:true},
                  { field: 'custName', displayName: 'Unit Holder Name', width:"180", cellTemplate: '<div class="ui-grid-cell-contents ftic-uhName" ng-click="col.colDef.value[row.entity.index] = !col.colDef.value[row.entity.index];grid.appScope.$emit(\'unitHolderNameRedirect\', {tabNo:0,data:row.entity})">{{grid.getCellValue(row, col)}}</div>', enableSorting:false, pinnedLeft:true, footerCellTemplate: '<div class="ui-grid-cell-contents">Total</div>'},                        
                  { field: 'pan', displayName: 'PAN', width:"140", enableSorting:false},
                  { field: 'folioDisplay', displayName: 'Folio No.', width:"154", enableSorting:false},
                  { field: 'holdingType', displayName: 'Mode of Holding', width:"180", cellClass:'text-right fti-modeOfHold', headerCellClass:'text-right fti-modeHeader', enableSorting:false},
                  { field: 'holdingType', displayName: '', cellTemplate:infoTemplate},
                  { field: 'mobile', displayName: 'Mobile No', width:"154", enableSorting:false},
                  { field: 'emailId', displayName: 'Email ID', width:"254",  enableSorting:false},
                  { field: 'city', displayName: 'City', width:"154",  enableSorting:false}
                  
                ];

                $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) {                  
                  $scope.searchQuery = {};
                  if(args.searchOption === "Unit Holder Name"){
                    $scope.searchQuery.searchType = "N";
                  }else if(args.searchOption === "PAN"){
                    $scope.searchQuery.searchType = "P";
                  }else if(args.searchOption === "Folio No."){
                    $scope.searchQuery.searchType = "F";
                  }else if(args.searchOption === "Mobile No."){
                    $scope.searchQuery.searchType = "M";
                  }else if(args.searchOption === "Email ID"){
                    $scope.searchQuery.searchType = "E";
                  }else if(args.searchOption === "Aadhaar No."){
                    $scope.searchQuery.searchType = "U";
                  }else if(args.searchOption === "Account No."){
                    $scope.searchQuery.searchType = "A";
                  }else if(args.searchOption === "CAN"){
                    $scope.searchQuery.searchType = "C";
                  }else if(args.searchOption === "IIN"){
                    $scope.searchQuery.searchType = "I";
                  }
                  $scope.$emit('disableEvent');
                  $scope.searchQuery.searchValue = args.searchText;
                  $scope.showSearchResult = false;
                  $scope.includeZeroFlag = true;
                  $scope.noSearchData = false;
                  $scope.searchQuery.active = "Y";
                  $scope.includeZeroBalanceAccounts.zeroBalAccounts = false;
                  searchResultModel.fetchSearchResult($scope.searchQuery,pageRange).then (function (data) {
                    $scope.searchResult = [];
                    $scope.searchResult=data;
                    searchResultModel.setsearchresult(data);
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;
                    angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                        obj.latestArr = [];
                        obj.showHolderTT = false;
                        
                        if(obj.holdingType === 'Joint' ||  obj.holdingType ==='Anyone Or Survivor') {
                            obj.showHolderTT = true;
                        }

                        var holderArray = obj.holders;
                        angular.forEach(holderArray,function(data,key){   
                          obj.latestArr.push({text:data.type,value:data.name});
                        });
                    });
                    $scope.$emit('showText', true);
                    $scope.showSearchResult = true;
                  }, function (data) {
                      $scope.searchResult = [];
                      if($scope.searchResult.length === 0) {
                        $scope.showSearchResult = true;
                        $scope.noSearchData = true;
                        $scope.$emit('showText', true);
                      }
                  });
                  
                }); 

				$scope.$on('setmyinvestorexistdata',function(){
					$scope.showSearchResult = false;
                  	$scope.noSearchData = false;
                  	$scope.includeZeroBalanceAccounts.zeroBalAccounts = false;                  	
					$scope.searchResult = searchResultModel.getsearchresult();
					angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                    });
                    $scope.$emit('showText', true);
                    $scope.showSearchResult = true;
				});

                $scope.zeroBalanceAccounts = function(){
                  
                  $scope.searchResult = false;
                  if($scope.includeZeroBalanceAccounts.zeroBalAccounts){
                    $scope.active = "N";
                  }else{
                    $scope.active = "Y";
                  }
                  $scope.$emit('disableEvent');

                  $scope.searchQuery.active = $scope.active;
                  // $scope.showSearchResult = false;

                  searchResultModel.fetchSearchResult($scope.searchQuery,pageRange).then (function (data) {
                    $scope.noSearchData = false;
                    $scope.searchResult = true;
                    $scope.searchResult = [];
                    $scope.searchResult=data;
                    $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                    $scope.paginationObject.count = data[0].recordCount;

                    angular.forEach($scope.searchResult,function(obj,ind){
                        obj.index = ind;
                        obj.latestArr = [];
                        obj.showHolderTT = false;
                        if(obj.holdingType === 'Joint' || obj.holdingType ==='Anyone Or Survivor') {
                            obj.showHolderTT = true;
                        }
                        var holderArray = obj.holders;
                        angular.forEach(holderArray,function(data,key){   
                          obj.latestArr.push({text:data.type,value:data.name});
                        });
                    });

                    $scope.showSearchResult = true;
                    
                  }, function (data) {
                      $scope.searchResult = [];
                      $scope.noSearchData = true;
                  });
                };

                $scope.$on(eventConstants.HIDE_SEARCH_RESULT, function (event, args) {                 
                  $scope.showSearchResult = false;
                  $scope.searchResult = [];
                  //$scope.$emit('disableEvent');
                  
                });

                $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, function (event, args) {                  
                  $scope.showSearchResult = true;
                  $scope.searchResult = [];
                  $scope.ShowAllFundsGrid = false;
                  $scope.$emit('disableEvent');
                });

                 $scope.$on(eventConstants.GET_SUGGESTIONS, function (event, args) {
                    $scope.$emit('showText', false);
                    $scope.showSearchResult = true;
                    $scope.searchResult = [];
                    $scope.$emit('disableEvent');

                  // $scope.$broadcast(eventConstants.SET_SUGGESTIONS, {"suggestions": suggestions});                                       
                });

            }],

            link: function(scope){
              
                scope.$on('unitHolderNameRedirect', function(event, data){
                  if(unitHolderModel.setUnitHolderNameClickabl){
                    scope.$emit("showTab", data);
                  }
                });
                            

                scope.$on('showTab', function(event, data){
                  scope.activeVar = true;
                  scope.$emit('activeEvent',scope.activeVar);
                }); 

                scope.$on('openHolderModal', function($event, data){

                  scope.holderData = data;
                  $uibModal.open({
                    template: '<div class="holderDataModal p+">'+
                                '<div class="clearfix">'+
                                  '<p class="col-md-4 col-xs-6 mb0 p">First Holder</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[0]!==undefined">{{holderData[0].value}}</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[0]===undefined">N/A</p>'+
                                '</div>'+
                                '<div class="clearfix">'+
                                  '<p class="col-md-4 col-xs-6 mb0 p">Second Holder</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[1]!==undefined">{{holderData[1].value}}</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[1]===undefined">N/A</p>'+
                                '</div>'+
                                '<div class="clearfix">'+
                                  '<p class="col-md-4 col-xs-6 mb0 p">Third Holder</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[2]!==undefined">{{holderData[2].value}}</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[2]===undefined">N/A</p>'+
                                '</div>'+
                                '<div class="clearfix">'+
                                  '<p class="col-md-4 col-xs-6 mb0 p">Minor Guardian</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[3]!==undefined">{{holderData[3].value}}</p>'+
                                  '<p class="col-md-8 col-xs-6 mb0 p custom-bold" ng-if="holderData[3]===undefined">N/A</p>'+
                                '</div>'+
                                
                              '</div>',
                    backdrop: true,
                    keyboard: true,
                    scope: scope,
                    windowClass: 'center-modal'
                  });
                  
                });
            }
        };
};

investorSearch.$inject = ['$state','searchResultModel', 'eventConstants','$compile', 'unitHolderModel','$uibModal'];
module.exports = investorSearch;