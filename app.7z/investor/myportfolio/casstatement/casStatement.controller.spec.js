'use strict';
describe('Controller: cas statement controller', function() {
    var $controller, $scope, CASController, myportfolioConstants;
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.module('investor.myportfolio'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _$window_, _myportfolioConstants_) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        myportfolioConstants = _myportfolioConstants_;
        CASController = $controller('CASController', { $scope: $scope });       

    }));

    it('should expect CASController to be defined', function() {
        expect(CASController).toBeDefined();
    });

    it('should expect camsURL and karvyURL to be defined on scope', function(){
        var camsURL = myportfolioConstants.cas.camsURL;
        var karvyURL = myportfolioConstants.cas.karvyURL;
        expect($scope.karvyURL).toBe(karvyURL);
        expect($scope.camsURL).toBe(camsURL);        
    });
});
