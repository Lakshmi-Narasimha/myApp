'use strict';
describe('Controller: overview controller', function() {
    var $controller, $scope, event, $state, overviewController, myportfolioConstants, invInstantMailback, timeout;
    
    beforeEach(angular.mock.module('investor'));

    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _$state_, _invInstantMailback_, _myportfolioConstants_, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        $state = _$state_;
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);

        invInstantMailback = _invInstantMailback_;
        myportfolioConstants = _myportfolioConstants_;
        $state.$current.data = {
            'viewFlag': myportfolioConstants.flagOptions.PAN_FLAG
        }

        overviewController = $controller('OverviewController', { $scope: $scope });
    }));

    it('should be defined', function() {
        expect(overviewController).toBeDefined();
    });

    it('should load appName and other details from scope', function() {
        var navPillOptions = myportfolioConstants.overview.NAV_PILLS_OPTIONS;
        expect($scope.appName).toBe('Investor');
        expect($scope.navPillsOptions).toBe(navPillOptions);
        expect($scope.btnColor).toBe('btn-group-sm green-btn-group pull-left');
        expect($scope.modelValues.modelVal).toBe('panview');
        expect($scope.viewFlag).toBe($state.$current.data.viewFlag);
    });

    it('should trigger changeNavPill to get modelVal', function() {
        var modelVal = 'accountview';
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('changeNavPill', modelVal);
        expect($scope.$broadcast).toHaveBeenCalledWith('changeNavPill', modelVal);
        expect($scope.modelValues.modelVal).toBe('accountview');
    });

    it('should trigger pillSelect for state transition', function() {
        var param = 'panview';
        spyOn($scope, 'pillSelect');
        spyOn($state, 'go');
        $scope.pillSelect(event, param);
        expect($scope.pillSelect).toHaveBeenCalledWith(event, param);
        expect($scope.viewFlag).toBe('PA');
        $state.go('overview.panview');
        expect($state.go).toHaveBeenCalledWith('overview.panview');
    });

    it('should trigger investor mailback success', function() {
        var data = {
            'type': 'F'
        };
        var params = {
            'options': [myportfolioConstants.overview.optionCode],
            'formats': [data.type],
            'flag': $scope.viewFlag
        }
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('invMailbackSuccess', data);
        expect($scope.$broadcast).toHaveBeenCalledWith('invMailbackSuccess', data);
        invInstantMailback.postInstantMailBackDetails(params).then(function(result) {
                expect(result).toBeDefined();
        });
    });
});
