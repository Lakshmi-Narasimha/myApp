/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var existingInvestor = function ($state, eventConstants, selectInvestorModel, selectInvestorInitialLoader, $timeout, advisorEventConstants, advisorEvents, transactModel, $stateParams, $filter, advisorConstants, buildPlanModelService, TransactConstant, transactEventConstants, recommendedPlanInitialLoader, toaster) {
    return {
        template: require('./existingInvestor.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: true,
        controller: ['$scope', function($scope){
            var editIconChanged = false,
                previousSearchValue = "",
                previousSearchText = "",
                index = "",
                searchData = {},
                pageRange = {}
                ;
            pageRange.limit = 5;
            pageRange.offset = 1;
            $scope.gridOptions = {};
            $scope.selectedInvestorDtls = [];
            $scope.config = {};
            $scope.config.showNotification = false;
            $scope.holderInfoArray = [];
            $scope.isDisabled = true;
            $scope.searchOptions = [
                {
                    lable: "PAN"
                },
                {
                    lable: "Folio No."
                },
                {
                    lable: "Account No."
                },
                {
                    lable: "Unit Holder Name"
                },
                {
                    lable: "Mobile"
                },
                {
                    lable: "Email"
                },
                {
                    lable: "Aadhaar"
                },
                {
                    lable: "CAN"
                },
                {
                    lable: "IAN"
                }
            ];

            $scope.paginationObject = {
                currentPage: 1
            };

            $scope.pageChanged = function () {
                $scope.showSearchResult = false;
                if ($scope.paginationObject.currentPage === 1) {
                    pageRange.offset = 1;
                } else {
                    pageRange.offset = (pageRange.limit * ($scope.paginationObject.currentPage - 1)) + 1;
                }
                selectInvestorInitialLoader.loadAllServices($scope, searchData, pageRange);
            };

            $scope.init = function (searchData) {
                $scope.selectedInvestorDtls = null;
                $scope.selectInvestorGrid = [];
                $scope.showSearchResult = false;
                var pageRange = {};
                pageRange.limit = 5;
                pageRange.offset = 1;
                selectInvestorInitialLoader.loadAllServices($scope, searchData, pageRange);
                var statusTemplate = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}" name="selectedInvestor" ng-click="grid.appScope.$emit(\'selectInvestor\', row.entity)" />';

                $scope.gridOptions.columnDefs = [
                    {
                        field: 'checkBox',
                        displayName: '',
                        value: index,
                        width: "50",
                        cellTemplate: statusTemplate,
                        enableSorting: false,
                        pinnedLeft: true
                    },
                    {
                        field: 'custName',
                        displayName: 'Unit Holder Name',
                        width: "180",
                        enableSorting: false,
                        pinnedLeft: true,
                        footerCellTemplate: '<div class="ui-grid-cell-contents">Total</div>'
                    },
                    {field: 'pan', displayName: 'PAN', width: "140", enableSorting: false},
                    {field: 'folioId', displayName: 'Folio No.', width: "154", enableSorting: false},
                    {field: 'holdingType', displayName: 'Mode of Holding', width: "180", enableSorting: false},
                    {field: 'mobile', displayName: 'Mobile', width: "154", enableSorting: false},
                    {field: 'emailId', displayName: 'Email', width: "254", enableSorting: false},
                    {field: 'city', displayName: 'City', width: "254", enableSorting: false}
                ];
            };

            function setExistingData() {
                index = transactModel.getInvestorDetails().index;
                searchData = {
                    searchOption: transactModel.getSearchOption(),
                    searchText: transactModel.getSearchText()
                };
                $timeout(function () {
                    $scope.selectedInvestorDtls = transactModel.getInvestorDetails();
                }, 0);
            }

            if ($stateParams.key === TransactConstant.transact.Investor_Key) {
                setExistingData();
                $scope.init(searchData);
                editIconChanged = true;
                listenForData(searchData);
            }

            function listenForData(args) {
                var destroyGrid = $scope.$on(transactEventConstants.transact.Select_Investor, function (event) {
                    $timeout(function () {
                        $scope.holderInfo = false;
                        $scope.selectInvestorGrid = selectInvestorModel.getInvestors();
                        angular.forEach($scope.selectInvestorGrid, function (obj, ind) {
                            obj.index = ind + 1;
                        });

                        $scope.$emit(transactEventConstants.transact.Open_Grid);
                    });
                    $scope.showSearchResult = true;
                    previousSearchValue = args.searchOption;
                    previousSearchText = args.searchText;
                    destroyGrid();
                });
            }

            $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) {

                if (editIconChanged == true) {
                    editIconChanged = false;
                    if (previousSearchValue !== args.searchOption || previousSearchText !== args.searchText) {
                        $scope.config.showNotification = true;
                        $scope.$on('yes', function () {
                            index = "";
                            console.log($scope.config.showNotification);
                            searchData = {
                                searchOption: args.searchOption,
                                searchText: args.searchText
                            };
                            $scope.config.showNotification = false;
                            $scope.init(searchData);
                            listenForData(searchData);
                        });
                        $scope.$on('no', function () {
                            $scope.config.showNotification = false;
                        });
                    }
                }
                else {
                    searchData = {
                        searchOption: args.searchOption,
                        searchText: args.searchText
                    };
                    $scope.init(searchData);
                    listenForData(searchData);
                }
            });

            $scope.$on(transactEventConstants.transact.Edit_Button_Clicked, function (event, args) {
                setExistingData();
                editIconChanged = true;
                $scope.init(searchData);
                listenForData(searchData);
            });

            $scope.$on(transactEventConstants.transact.TRANS_SELECT_INVESTOR, function (event, args) {
                $scope.selectedInvestorDtls = args;
                buildPlanModelService.setInvestorSearch(args);
                transactModel.setInvestorDetails(args);
                $scope.$emit('investorSearch', $scope.holderInfo);
            });

            $scope.$on(transactEventConstants.transact.Trans_Select_Option_Changed, function (event, args) {
                $scope.showSearchResult = false;
                $scope.selectInvestorGrid = null;
            });
            $scope.$on("investorSearch", function () {
                $scope.investorDetails = transactModel.getInvestorDetails();//buildPlanModelService.getInvestorSearch();
                if (($scope.investorDetails.emailId === "" || $scope.investorDetails.emailId === "null" || $scope.investorDetails.emailId === " ") && ($scope.investorDetails.mobile === "" || $scope.investorDetails.mobile === "null" || $scope.investorDetails.mobile === " ")) {
                    toaster.error("The user doesn’t have a registered mobile and e-mail. Please select a different folio to proceed with the transaction");
                    $scope.isDisabled = true;
                }
                else {
                    $scope.isDisabled = false;
                    $scope.holderInfo = true;
                    $scope.holderInfoArray = null;
                    $scope.holderInfoArray = [
                        {key: "First Holder Name", value: $scope.investorDetails.custName},
                        {
                            key: "Second Holder Name",
                            value: $scope.investorDetails.holders[1] ? $scope.investorDetails.holders[1].name : "NA"
                        },
                        {
                            key: "Third Holder Name",
                            value: $scope.investorDetails.holders[2] ? $scope.investorDetails.holders[2].name : "NA"
                        },
                        {key: "Folio. No.", value: $scope.investorDetails.folioId},
                        {key: "Mode of Holding", value: $scope.investorDetails.holdingType}
                    ];
                    recommendedPlanInitialLoader.loadPanlLevelServices($scope.investorDetails.pan);
                }

            });

            $scope.ssContinue = function ($event) {
                //$scope.$parent.goalDescError = null;
                var holders = $scope.selectedInvestorDtls.holders, kycregistered = true;
                $scope.showPopup = false;

                angular.forEach(holders, function (obj, ind) {
                    if (obj.kycStatus === "KYC - Not Registered") {
                        kycregistered = false;
                    } else {
                        transactModel.setKYCMode(false);
                        transactModel.checkRegistrationMode(obj.modeOfKyc);
                    }
                });
                /*  angular.forEach(holders, function (obj, ind) {
                 if (!obj.kycregistered) {
                 kycregistered = false;
                 }
                 });*/
                if (!kycregistered) {
                    $scope.popupText = "Please complete KYC registration of all holders to proceed with the transaction.";
                    $scope.yesText = "Continue with KYC";
                    $scope.noText = "Cancel";
                    $timeout(function () {
                        $scope.showPopup = true;
                    }, 0);
                    $scope.$on("yes", function () {
                        $scope.showPopup = false;
                        $state.go("smartSol.planSmartSolution.ekycRegStatus");
                        // $state.go("smartSol.planSmartSolution.ssBase.planInputDetails");
                        return;
                    });
                }
                else {
                    $scope.$emit("kycEvent");

                }
            }
            $scope.panLevelInv = function () {
                $scope.$emit('showPANLevelInvModal');
            };
        }]
    };
};

existingInvestor.$inject = ['$state', 'eventConstants', 'selectInvestorModel', 'selectInvestorInitialLoader', '$timeout', 'advisorEventConstants', 'advisorEvents', 'transactModel', '$stateParams', '$filter', 'advisorConstants', 'buildPlanModelService', 'TransactConstant', 'transactEventConstants', 'recommendedPlanInitialLoader', 'toaster'];
module.exports = existingInvestor;