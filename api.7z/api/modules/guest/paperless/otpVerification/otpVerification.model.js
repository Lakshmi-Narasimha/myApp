// advisorSearch.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var OtpVerificationSchema = new mongoose.Schema({
	OtpVerificationObject: {
		type: Array,
		"default": []
	}
});

var OtpVerificationLookUp = mongoose.model('OtpVerificationLookUp', OtpVerificationSchema);

var OtpVerificationModel = new OtpVerificationLookUp({

	OtpVerificationObject: {
		"aadharHolderDetails": {
			name : 'Shankar N',
            aadhar : 'UBSS6170Y',
            dob : '29/10/1980',
            gender : 'Male',
            address:'A/203 Kalpataru towers, Somajiguda, Hyderabad 500082',
            mobile:'8754129635',
            email:'Shankar.n@gmail.com',
            image:'images/person.jpg'
		}
		
	}
});

OtpVerificationLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
    	console.log('Having toruble in creating OtpVerificationLookUp table, please contact admin...');
    } else {
    	OtpVerificationLookUp.remove({}, function(err) {
    		console.log('OtpVerificationLookUp collection removed');
    		OtpVerificationModel.save(function(err) {
    			if (err) {
    				console.log('Having toruble in creating OtpVerificationLookUp table, please contact admin...');
    			}
    			console.log('OtpVerificationLookUp table created in mongoose...');
    		});
    	});
    	console.log(data.length);
    }
});

module.exports = OtpVerificationLookUp;
