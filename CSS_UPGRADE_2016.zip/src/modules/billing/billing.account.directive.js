(function() {
    'use strict';
    angular.module('CSS.billing').directive('billingAccount', ['billingUtils', '$filter', 'billingConstants', '$timeout', '$rootScope', function(billingUtils, $filter, billingConstants, $timeout, $rootScope) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: window.UIC.sitePrefix + 'modules/billing/partials/billing.account.html',
            controller: billingAccountController,
            controllerAs: 'billingAcctVM',
            link: billingAccountLinkFunc,
            bindToController: true,
            scope: {}
        };
    }]);

    function billingAccountLinkFunc(scope, element, attr) {
        // console.log(scope.billingAcctVM);
    }

    function billingAccountController($scope, billingUtils, $filter, billingConstants, $timeout, $rootScope) {
        var billingAcctVM = this;
        billingAcctVM.externallink = window.loginURL || 'https://www.farmers.com';
        billingAcctVM.paymentsLink = window.UIC.paymentsLink;
        billingAcctVM.billingAccount = {};
        billingAcctVM.billingAccount = billingUtils.getBillingData() || {};
        billingAcctVM.billingAccount.transitionLinks = "";
        billingAcctVM.billingAccount.transitionState = null;

        billingAcctVM.printData = {
            accountNumber: null,
            paymentDate: null,
            confirmationNumber: null,
            amountPaid: null,
            submittedBy: null,
            submittedOn: null,
            paymentList: null
        };
        billingAcctVM.billingAccount.billingcarosuelArray = [];

        var setPaySelection = function(billingInfo) {
            var data;
            billingInfo.billingcarosuelArray = billingAcctVM.billingAccount.policies;
            billingInfo.billingview = "default";
            billingInfo.isPaymentAddressed = false;
        };

        var setScrollToTop = function(){
            $("html, body").animate({
                scrollTop: 0
            }, 10);
        };

        /*var checkUserType = function(billingInfo) {
            var warnMessageFlag = false;
            if ((window.userType === window.UIC.USER_TYPES["customer"]) || (window.userType === window.UIC.USER_TYPES["superCsr"])) {
                warnMessageFlag = true;
            }
            billingInfo.isUserPayable = !warnMessageFlag;
            return warnMessageFlag;
        };*/

        var resetHanlder = function(billingInfo) {
            if (billingInfo) {
                billingInfo.amountPayingNow = billingInfo.minPaymentDueAmount != null ? parseFloat(billingInfo.minPaymentDueAmount).toFixed(2) : "0.00";
                billingInfo.sysdate = billingInfo.systemDateTime;
                billingInfo.payingDateNow = $filter('formatDate')(billingInfo.systemDateTime);
                // billingInfo.payingDateNow = (billingInfo.systemDateTime);
                billingInfo.showingPaymentText = "Payment Due";
                billingInfo.valueEntered = false;
                billingInfo.isUserPayable = false;
            }

            billingInfo.submitPaybill = false;
            billingInfo.payBillButton = true;

            /*if (billingInfo.payBillClicked) {
                billingInfo.payBillButton = true;
            } else {
                billingInfo.payBillButton = false;
            }*/

            billingInfo.paymentMethodsNotAvailable = true;
            billingInfo.payBillClicked = false;

            billingInfo.atPaymentMethodsNow = [];
            billingInfo.paymentListNow = null;
            billingInfo.accountInActiveFlag = false;
            billingInfo.isSelectedPayment = false;
            billingInfo.isPayDateAfterDueDateWarning = false;
            billingInfo.isShort = false;
            billingInfo.isMinPaymentFlag = false;
            billingInfo.maxAmountFlag = false;
            billingInfo.overPaymentFlag = false;
            billingInfo.isDueDateToday = true;
            billingInfo.allowPayment = false;
            
            setPaySelection(billingInfo);
        };

        resetHanlder(billingAcctVM.billingAccount);

        /*var tooltipInitiate;
        if (!tooltipInitiate) {
            $('body').tooltip({
                selector: '.submitTooltip',
                container: 'body',
                trigger: 'manual'
            });
        }*/

        billingAcctVM.switchPayBills = function(billingInfo, selection) {

            if (selection === "paybill") {
                billingInfo.isSelectedPayment = true;
                billingInfo.payBillClicked = true;
                billingInfo.payBillButton = false;
                
                billingAcctVM.setTimeStart(billingInfo);
                billingInfo.billingview = billingConstants.payment_switch_constants.paybill;
                billingInfo.paymentMethodsNotAvailable = (billingInfo.paymentListNow ? false : true);

            } else if (selection === billingConstants.payment_switch_constants.defaultPayment) {
                angular.element('#cancelThisBill').modal('show'); //added for checking
                billingInfo.cancelPayment = true;
            } else if (selection === billingConstants.payment_switch_constants.verify) {
                if (!billingInfo.paymentMethodsNotAvailable) {
                    billingAcctVM.isValidAmount(billingInfo);
                    billingAcctVM.isAmountShort(billingInfo);
                    billingAcctVM.isAmountLarger(billingInfo);
                    billingAcctVM.isOverPayment(billingInfo);
                    billingAcctVM.isPayDateAfterDueDate(billingInfo);
                    billingAcctVM.validateSubmitPayment(billingInfo);
                }
                if(billingInfo.allowPayment) {
                    billingInfo.billingview = billingConstants.payment_switch_constants.verify;
                }
            } else if (selection === billingConstants.payment_switch_constants.confirm) {
                var checkSubmit;
                /*if (!billingInfo.submitPaybill && !angular.element('.billing-content').find(".submitTip .tooltip").is(":visible")) {
                    angular.element('.billing-content').find('.submitTooltip').tooltip('show');
                }*/
                if (billingInfo.submitPaybill && !billingInfo.isMinPaymentFlag) {
                    $scope.$emit('submit-paybill', billingInfo);
                    billingInfo.transitionLinks = (billingInfo.registerURL ? billingInfo.registerURL : (billingInfo.loginURL || window.loginURL ));
                    billingInfo.transitionState =  (billingInfo.registerURL ? 'Register for My Farmers' : 'Login to My Farmers' );
                }
            } else if (selection === billingConstants.payment_switch_constants.editPayment) {
                billingInfo.submitPaybill = billingAcctVM.isMultipaySubmit = false;
                billingInfo.billingview = billingConstants.payment_switch_constants.paybill;
            }
        };

        billingAcctVM.setTimeStart = function(billingInfo) {
            var datetimeArray = (billingInfo.systemDateTime).split("T");
            var timeArray = datetimeArray[1].split(".");
            billingInfo.newDateTimeString = datetimeArray[0] + " " + timeArray[0];
            billingInfo.systemTime = new Date(billingInfo.newDateTimeString);
            billingInfo.paymentStartTime = new Date(billingInfo.newDateTimeString);
        };

        billingAcctVM.isOverPayment = function(billingInfo) {
            billingInfo.overPaymentFlag = false;

            var datetimeArray = (billingInfo.systemDateTime).split("T");
            billingInfo.presentEndTime = new Date(datetimeArray[0]);
            var suffix, hours;
            suffix = ((billingInfo.presentEndTime).getHours() < 12 ? "AM" : "PM");
            var hourDiff = billingInfo.presentEndTime - billingInfo.paymentStartTime;
            var diffHrs = Math.floor((hourDiff % 86400000) / 3600000);
            var diffMins = Math.round(((hourDiff % 86400000) % 3600000) / 60000);
            if (diffHrs >= 0 && diffMins >= 0) {
                billingInfo.paymentStartTime.setHours((billingInfo.paymentStartTime).getHours() + diffHrs);
                billingInfo.paymentStartTime.setMinutes((billingInfo.paymentStartTime).getMinutes() + diffMins);
                hours = (suffix === "AM" ? billingInfo.paymentStartTime.getHours() : (billingInfo.paymentStartTime.getHours() - 12));
            }
            if (suffix === "PM") {
                if (hours === 3 || hours === 4) {
                    billingInfo.overPaymentFlag = true;
                }
            }

            return true;
        };

        billingAcctVM.validateSubmitPayment = function(billingInfo) {
            var validPay = false;
            if (!billingInfo.paymentMethodsNotAvailable && !billingInfo.isMinPaymentFlag && !billingInfo.maxAmountFlag) {
                validPay = true;
            }

            billingAcctVM.billingAccount.allowPayment = validPay;

            return validPay;
        };

        billingAcctVM.isValidAmount = function(billingInfo) {
            billingInfo.isMinPaymentFlag = (billingInfo.amountPayingNow === undefined || billingInfo.amountPayingNow === null) || billingInfo.amountPayingNow < 1;
        };

        billingAcctVM.isAmountShort = function(billingInfo) {
            var isShort = false;
            if (angular.isDefined(billingInfo.amountPayingNow) && Number(billingInfo.amountPayingNow) > 0) {
                if (Number(billingInfo.amountPayingNow) <= 0) {
                    isShort = true;
                }
            }
            billingInfo.isShort = isShort;
        };

        billingAcctVM.isAmountLarger = function(billingInfo) {
            var maxAmountFlag = false;
            if (angular.isDefined(billingInfo.amountPayingNow)) {
                if (Number(billingInfo.amountPayingNow) > 25000) {
                    maxAmountFlag = true;
                }
            }
            billingInfo.maxAmountFlag = maxAmountFlag;
        };

        billingAcctVM.isPayDateAfterDueDate = function(billingInfo) {
            billingInfo.isPayDateAfterDueDateWarning = false;
            if (angular.isDefined(billingInfo.payingDateNow)) {
                var payingDate = new Date(billingInfo.payingDateNow);
                if (billingInfo.paymentDueDate && billingInfo.minPaymentDueAmount) {
                    var paymentDueDate = new Date($filter('formatDate')(billingInfo.paymentDueDate));
                    if (payingDate > paymentDueDate && Number(billingInfo.minPaymentDueAmount) > 0) {
                        billingInfo.isPayDateAfterDueDateWarning = true;
                    }
                }
            }

        };

        billingAcctVM.paymethodQuery = {
            "cardHolderNickName": null,
            "cardNumber": null,
            "creditOrDebit": null,
            "cardType": null,
            "expMonth": null,
            "expYear": null,
            "cardHolderName": null,
            "zipCode": null,
            "termscheck": null,
            "bankOrCard": null,
            "cardcategory": null,
            "indicatorForAddOrEditPaymentMethod": null,
            "bankAccountHolderNickName": null,
            "bankAccountType": null,
            "routingnumber": null,
            "accountNumber": null,
            "accountHolderName": null,
        };

        $rootScope.$on("submitted", function(event, paymethodData) {
            angular.merge(billingAcctVM.paymethodQuery, paymethodData);
            billingAcctVM.billingAccount.paymentListNow = billingUtils.setPaymentMethodDetails(billingAcctVM.paymethodQuery);
            billingAcctVM.billingAccount.paymentMethodsNotAvailable = (billingAcctVM.billingAccount.paymentListNow ? false : true);
            billingAcctVM.validateSubmitPayment(billingAcctVM.billingAccount);
        });

        $rootScope.$on('cancelPaymentMethod', function(event) {
            billingAcctVM.billingAccount.paymentListNow = null;
            billingAcctVM.billingAccount.paymentMethodsNotAvailable = (billingAcctVM.billingAccount.paymentListNow ? false : true);
            billingAcctVM.validateSubmitPayment(billingAcctVM.billingAccount);
        });

        billingAcctVM.cancelHandler = function(view) {
            if(billingAcctVM.billingAccount.paymentMethodsNotAvailable) {
                window.location.href = window.UIC.paymentsLink;
            }
            else {
                angular.element('#popupModal').modal({
                    show: true,
                    backdrop: 'static'
                });
            }
        };

        billingAcctVM.printConfirmation = function() {
            var paymentData = billingAcctVM.billingAccount;
            billingAcctVM.billingAccount.submittedBy = '_';
            billingAcctVM.billingAccount.submittedOn = paymentData.payingDateNow;
            billingAcctVM.billingAccount.accountHolder = paymentData.paymentListNow.isCard ? paymentData.paymentListNow.cardHolderName : paymentData.paymentListNow.accountHolderName;
            $scope.$emit('print-details', billingAcctVM.billingAccount);
        };
    }

    angular.module('CSS.billing').directive('billingPayAmount', ['billingUtils', function(billingUtils) {
        return {
            restrict: 'E',
            replace: true,
            require: "^billingAccount",
            templateUrl: window.UIC.sitePrefix + 'modules/billing/partials/billing.pay.amount.html',
            controller: billingAmountController,
            link: billingAmountLinkFunc,
            controllerAs: 'billingAmtVM',
            bindToController: true,
            scope: {}
        };
    }]);

    function billingAmountController(billingUtils) {
        var billingAmtVM = this;

        billingAmtVM.numberValidation = function(event) {
            // if (event.keyCode === 13) 
            billingAmtVM.getSelectedAmount(billingAmtVM.otherPayAmount);
        };

        function checkPattern(selAmount) {
            var result = billingAmtVM.valueEntered = new RegExp(/^[0-9]+(\.[0-9]{1,2})?$/).test(selAmount);
            return result;
        }

        billingAmtVM.getSelectedAmount = function(selAmount) {
            var selectedPay = billingAmtVM.amountSelected;
            billingAmtVM.isEnabledOtherAmt = (selectedPay === "Other Amount");
            if (selAmount !== "" && selAmount !== undefined) {
                if (selectedPay === "Other Amount") {
                    if (checkPattern(selAmount)) {
                        billingAmtVM.updatAmount(selAmount);
                    } else {
                        billingAmtVM.updatAmount("0.00");
                    }
                } else {
                    billingAmtVM.updatAmount(selAmount);
                }
            } else {
                if (!checkPattern(selAmount)) {
                    billingAmtVM.updatAmount("0.00");
                }

            }
        };

        billingAmtVM.updatAmount = function(selAmount) {
            billingAmtVM.billingAccount.amountPayingNow = selAmount;
            billingAmtVM.billingAccount.showingPaymentText = billingAmtVM.amountSelected;
            if(!billingAmtVM.billingAccount.paymentMethodsNotAvailable) {
                billingAmtVM.ctrls.isValidAmount(billingAmtVM.billingAccount);
                billingAmtVM.ctrls.isAmountShort(billingAmtVM.billingAccount);
                billingAmtVM.ctrls.isAmountLarger(billingAmtVM.billingAccount);
            }
            // billingAmtVM.ctrls.validateSubmitPayment(billingAmtVM.billingAccount);
        };
    }

    function billingAmountLinkFunc(scope, element, attrs, ctrls) {
        var billingAmtVM = scope.billingAmtVM;
        billingAmtVM.ctrls = ctrls;
        billingAmtVM.billingAccount = ctrls.billingAccount;
        billingAmtVM.isEnabledOtherAmt = false;
        billingAmtVM.currentBalanceProcessed = billingAmtVM.billingAccount.outStandingAmount > 0 ? billingAmtVM.billingAccount.outStandingAmount : 0;
        billingAmtVM.amountSelected = billingAmtVM.billingAccount.showingPaymentText;
        if(billingAmtVM.amountSelected === "Other Amount") {
            billingAmtVM.otherPayAmount = billingAmtVM.billingAccount.amountPayingNow;
            billingAmtVM.isEnabledOtherAmt = true;
        }
    }

    angular.module('CSS.billing').directive('billingPayMethod', ['billingUtils', function(billingUtils) {
        return {
            restrict: 'E',
            replace: true,
            require: "^billingAccount",
            templateUrl: window.UIC.sitePrefix + 'modules/billing/partials/billing.pay.method.html',
            controller: billingMethodController,
            link: billingMethodLink,
            controllerAs: 'billingMethodVM',
            bindToController: true,
            scope: {}
        };
    }]);

    function billingMethodController($scope, billingUtils) {
        var billingMethodVM = this;

        billingMethodVM.updateBillingAccount = function(billingInfo) {
            billingMethodVM.billingAccount.billingAccountNumber = billingInfo.billingAccountNumber;
        };

        billingMethodVM.getSelectedMethod = function(event, method) {
            billingMethodVM.billingAccount.paymentListNow = billingMethodVM.checkedPaymentMethod(method);
            billingMethodVM.billingAccount.paymentMethodsNotAvailable = (billingMethodVM.billingAccount.paymentListNow ? false : true);
            billingMethodVM.paymentDetails = billingMethodVM.billingAccount.atPaymentMethodsNow;
            billingMethodVM.nickName = billingMethodVM.billingAccount.paymentListNow.nickName;
            billingMethodVM.digitsCardNum = billingMethodVM.billingAccount.paymentListNow.digitsCardNum;
            billingMethodVM.visible = (billingMethodVM.visible ? false : billingMethodVM.visible);
        };

        billingMethodVM.changePaymentMethod = function() {
            if(billingMethodVM.billingAccount.paymentMethodsNotAvailable) {
                angular.element('#addnewPaymentModal').modal({
                    show: true,
                    backdrop: 'static'
                });
            }
            else {
                billingMethodVM.visible = !billingMethodVM.visible;
            }
        };

        billingMethodVM.selectedPaymentType = function(methodType) {
            if(methodType === 'change') {
                methodType = billingMethodVM.billingAccount.paymentListNow.isCard ? 'Payment card' : 'Bank account'; 
            }
            billingMethodVM.billingAccount.paymentMethodsNotAvailable = true;
            billingMethodVM.billingAccount.paymentListNow = null;

            $scope.$emit('methodSelected', methodType);
        };
    }

    function billingMethodLink(scope, element, attrs, ctrls) {
        var billingMethodVM = scope.billingMethodVM;
        billingMethodVM.ctrls = ctrls;
        billingMethodVM.billingAccount = ctrls.billingAccount;

        billingMethodVM.visible = false;
        billingMethodVM.paymode = "selection";
        billingMethodVM.paymentDetails = billingMethodVM.billingAccount.atPaymentMethodsNow;
        billingMethodVM.path = window.sitePrefix + 'assets/style/images/backgrounds/';
    }

    angular.module('CSS.billing').directive('paymentReceiptPrint', ['$window', function($window) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: $window.UIC.sitePrefix + 'modules/billing/partials/paymentreceipt.print.html',
            controller: paymentReceiptController,
            controllerAs: 'paymentReceiptVM',
            link: billingAccountLinkFunc,
            bindToController: true,
            scope: {
                printData:"="
            }
        };
    }]);

    function paymentReceiptController() {
        var paymentReceiptVM = this;
        paymentReceiptVM.printcontent = function(divelement){
            var printContents = angular.element("#modalPrintReceipt").clone();
            angular.element(printContents).find('.printcontent').remove();
            printContents = angular.element(printContents).html();
            var popupWin = window.open('', '_blank', 'width=900,height=900');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + printContents + '</html>');
            popupWin.document.close();
        };
    }

})();
