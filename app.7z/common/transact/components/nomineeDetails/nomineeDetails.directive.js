'use strict';

var fticNomineeDetails = function(formDetailsModel,eventConstants, transactModel, transactEventConstants, TransactConstant, paperlessModel, $state, $stateParams) {
    return{
        template: require('./nomineeDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
          nomineeForm:"="
        },
        controller:['$scope', function($scope){
          $scope.isPaperLess = transactModel.isPaperless;
          $scope.isEkycForm = $state.current.url;
          $scope.isFromSmartSol = false;
          if ($state.current.url == "/newInvestorFatcaKyc" || $state.current.url == "/ssEkycForm") {
            $scope.isFromSmartSol = true;  
          }          
          $scope.isShowNominee = true;
          $scope.ifNominee = {
                label : "I do not wish to nominate any one",
                value : false
            }
          $scope.nomineeInput = [
            {
              text: "",
              value: "",
              message: "",
              isRequired: true,
              min:"",
              type:"text",
              name:"nomInput0",
              disable:false,
              maxlength:"80"
            },
             {
              text: "",
              value: "",
              message: "",
              isRequired: true,
              min:"",
              type:"number",
              name:"nomInput1",
              disable:false

              
            },
            {
              text: "",
              value: "",
              message: "",
              isRequired: false,
              min:"",
              type:"text",
              name:"nomInput2",
              disable:false,
              maxlength:"80"
            },
             {
              text: "",
              value: "",
              message: "",
              isRequired: false,
              min:"",
              type:"number",
              name:"nomInput3",
              disable:false
              
            },{
              text: "",
              value: "",
              message: "",
              isRequired: false,
              min:"",
              type:"text",
              name:"nomInput4",
              disable:false,
              maxlength:"80"
            },
             {
              text: "",
              value: "",
              message: "",
              isRequired: false,
              min:"",
              type:"number",
              name:"nomInput5",
              disable:false
            }

          ];
          $scope.showSecond=false;
          $scope.showThird=false;
          $scope.ifChecked = false;
          $scope.showNotification=false;
          $scope.errMsg="You are exceeding the percentage allocation limit of 100 %";
            $scope.validPer=true;

          $scope.addNominee=function(){
            $scope.nomineeForm.$setPristine();
            if(!$scope.ifChecked){
              if($scope.nomineeInput[1].value+$scope.nomineeInput[3].value+$scope.nomineeInput[5].value >=100){
                console.log("show notification here");
                $scope.showNotification=true;
                $scope.popUpHeader="";
                $scope.popUpText="You can not add nominee as you are exceeding the percentage allocation limit of 100 %.";
                $scope.btnNo="OK";
                $scope.btnYes="";
                $scope.mainHeader="";
              } 
              else{
                $scope.showNotification=false;          
                if($scope.showSecond)
                {
                  $scope.nomineeInput[4].isRequired=true;
                  $scope.nomineeInput[5].isRequired=true;
                  $scope.nomineeInput[4].disable=false;
                  $scope.nomineeInput[5].disable=false;
                  $scope.showThird=true;
                } 
                $scope.nomineeInput[2].isRequired=true;
                $scope.nomineeInput[3].isRequired=true; 
                $scope.nomineeInput[2].disable=false;
                $scope.nomineeInput[3].disable=false;
                $scope.showSecond=true;
              } 
            }
          };
          
          $scope.hideThird=function () {
           $scope.showThird=false;
           $scope.nomineeInput[4].value="";
           $scope.nomineeInput[5].value="";
          }
          $scope.hideSecond=function () {
           $scope.showSecond=false;
           $scope.nomineeInput[2].value="";
           $scope.nomineeInput[3].value="";
          }
          $scope.$on(transactEventConstants.transact.PAPERLESS_NOMINEE_CONTINUE, function(){
            $scope.continue();
          });
          $scope.continue=function(){
            $scope.totalPerValue=0;
            $scope.nomineeArray=[];
              if(!$scope.ifChecked && $scope.nomineeInput[0].value!== "" && $scope.nomineeInput[1].value !==""){
                $scope.nomineeArray.push({
                  "nomName":$scope.nomineeInput[0].value,
                  "nomPerValue":$scope.nomineeInput[1].value
                });
                $scope.totalPerValue=$scope.totalPerValue+$scope.nomineeInput[1].value;
                 if($scope.showSecond){
                  $scope.nomineeArray.push({
                    "nomName":$scope.nomineeInput[2].value,
                    "nomPerValue":$scope.nomineeInput[3].value
                  });
                  $scope.totalPerValue=$scope.totalPerValue+$scope.nomineeInput[3].value;
                 }
                 if($scope.showThird){
                  $scope.showError=false
                    $scope.nomineeArray.push({
                      "nomName":$scope.nomineeInput[4].value,
                      "nomPerValue":$scope.nomineeInput[5].value
                  });
                  $scope.totalPerValue=$scope.totalPerValue+$scope.nomineeInput[5].value;
                 }
                if( $scope.totalPerValue==100) {
                  
                  //$scope.$emit("nomineeDetailsCont");
                  $scope.validPer = true;
                } 
                else if($scope.totalPerValue>100 || $scope.totalPerValue<100) {
                  $scope.showError = true;
                  $scope.errMsg = $scope.totalPerValue>100? "You are exceeding the percentage allocation limit of 100 %." : "You should have allocation percentage equal to 100%";
                  $scope.validPer = false;
                  $scope.nomineeForm.$valid = false;
                  $scope.nomineeForm.$invalid = true;
                  return;
                }
              }
            if($scope.nomineeForm.$valid){
              formDetailsModel.setNomineeDetails($scope.nomineeArray);
              $scope.$emit("nomineeDetailsCont");
              paperlessModel.isNomineeSuccess = true;
              console.log("Nomineee directive success");

            }
          }
          $scope.$on('yes', function () {
            $scope.showNotification = false;
          });
     
          $scope.$on('no', function () {
            $scope.showNotification = false;
          });

          $scope.$on(eventConstants.CHECKBOX_CHECKED, function (event, data) {
            transactModel.isNotWishToNominee = data.value;
            if ($scope.isShowNominee) {
              $scope.isShowNominee = false;
            }else{
              $scope.isShowNominee = true;
            }
            $scope.ifChecked=data.value;
            if(data.value==true){
              for(var i=0; i<6;i++){
                $scope.nomineeInput[i].disable=true;
                 $scope.nomineeInput[i].isRequired=false;
                 $scope.nomineeInput[i].value="";
              }
            }
            else{
              $scope.nomineeInput[0].disable=false;
              $scope.nomineeInput[1].disable=false;
              $scope.nomineeInput[0].isRequired=true;
              $scope.nomineeInput[1].isRequired=true;
              if($scope.showSecond){
                $scope.nomineeInput[2].disable=false;
                $scope.nomineeInput[3].disable=false;
                $scope.nomineeInput[2].isRequired=true;
                $scope.nomineeInput[3].isRequired=true;
              }
              if($scope.showThird){
                $scope.nomineeInput[4].disable=false;
                $scope.nomineeInput[5].disable=false;
                $scope.nomineeInput[4].isRequired=true;
                $scope.nomineeInput[5].isRequired=true;
              }

            }



          });
             $scope.$on("INPUT_CHANGED", function (event, inpObj) {
               $scope.validPer=true;
                
            }); 
            $scope.$on("nomineeValidation", function(){
              $scope.continue();
            })
            if(paperlessModel.invDetails.hasData || $stateParams.key == TransactConstant.transact.NOMINEE_KEY){
              if(transactModel.isNotWishToNominee){
                $scope.isShowNominee = false;
                $scope.ifNominee.value = true;
              }else{
                var nomineeDetails = formDetailsModel.getNomineeDetails();
                if(nomineeDetails){
                  angular.forEach(nomineeDetails, function(obj, key){
                        if(key==0){
                          $scope.nomineeInput[0].value = obj.nomName;
                          $scope.nomineeInput[1].value = obj.nomPerValue;
                        }else if(key==1){
                          $scope.showSecond = true;
                          $scope.nomineeInput[2].value = obj.nomName;
                          $scope.nomineeInput[3].value = obj.nomPerValue;
                        }else if(key==2){
                          $scope.showThird = true;
                          $scope.nomineeInput[4].value = obj.nomName;
                          $scope.nomineeInput[5].value = obj.nomPerValue;
                        }
                  })
                }
              }
            }
        }]
    }

};

fticNomineeDetails.$inject = ['formDetailsModel','eventConstants', 'transactModel', 'transactEventConstants', 'TransactConstant','paperlessModel', '$state', '$stateParams'];
module.exports = fticNomineeDetails;
