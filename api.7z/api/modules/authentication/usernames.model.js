// usernames.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var UsernamesSchema = new mongoose.Schema({
    usernamesObject: {
        type: Array,
        "default": []
    }
});

var UsernamesLookUp = mongoose.model('UsernamesLookup', UsernamesSchema);

var UsernamesModel = new UsernamesLookUp({

    "usernamesObject": [
      {
        "arnCode" : "cts123",
        "emailAddress" : "user@cts.com"
      },
      {
        "arnCode" : "cts456",
        "emailAddress" : "ft@cts.com"
      },
      {
        "arnCode" : "fti123",
        "emailAddress" : "cts@cts.com"
      },
      {
        "arnCode" : "gue123",
        "emailAddress" : "cognizant@cts.com"
      }
    ]

});

UsernamesLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating UsernamesLookUp table, please contact admin...');
    } else {
        UsernamesLookUp.remove({}, function(err) {
            console.log('UsernamesLookUp collection removed');
            UsernamesModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating UsernamesLookUp table, please contact admin...');
                }
                console.log('UsernamesLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = UsernamesLookUp;
