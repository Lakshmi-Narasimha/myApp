var fticUtilityDropdownMenu = function(appConfig, configUrlModel) {
    return {
        template: require('./utilityDropdown.html'),
        restrict: 'E',
        transclude: true,
        scope: {
            url: '@',
            text: "@"
        },
        controller: ['$scope','$element','$attrs',
        function($scope, $element, $attrs) {     
                var MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                var GUEST_URL = appConfig[configUrlModel.getEnvUrl('GUEST_URL')];             
                var menu = $scope.$parent.menu[0];
                if (menu.link && angular.isArray(menu.link)) {
                    if(menu.text == "" || menu.text == null || menu.text=== undefined){
                        $scope.dropdownImage = menu.image;    
                    }
                    else {
                        $scope.dropdownMTitle = menu.text;
                        $scope.dropdownTitle = menu.text;  
                        $scope.dropdownUrl = menu.url;  
                    }

                    angular.forEach(menu.link,function(firstobj){
                        if(firstobj.url.indexOf('http') !== '-1'){
                            if(firstobj.type=='guest'){
                                firstobj.url = GUEST_URL+"/#"+firstobj.url;
                            }else if(firstobj.type=='marketing'){
                                firstobj.url = MARKETING_URL+firstobj.url;
                            }
                        }
                    });
                    $scope.menuItems = menu.link;

                    // $scope.uicId = dropdownTitle;
                    /*angular.forEach(menuItems, function(menuItem, menuKey) {
                        $scope.isMobile = menuItem.isMobile;
                        $scope.isMobileclass = menuItem.mClass;
                        $scope.mobileHref = menuItem.url;
                    });*/

                }else{
                    if(menu.type[0] == "link"){
                        $scope.dropdownTitle = menu.text;
                        // $scope.feedbackUrl = menu.url;  
                         if(menu.url.indexOf('http') !== '-1'){
                            if(menu.type[1] == 'guest'){
                                $scope.feedbackUrl = GUEST_URL+"/#"+menu.url;
                            }else if(menu.type[1] == 'marketing'){
                                $scope.feedbackUrl = MARKETING_URL+menu.url;
                            }
                        }
                        // var enviromentUrl = (menu.type[1] == "guest")?GUEST_URL:(menu.type[1] == "marketing")?MARKETING_URL:'';
                        // $scope.feedbackUrl = enviromentUrl+"/#"+menu.url;
                        $scope.menuItems = [];
                    }
                    if(menu.type == "country"){
                       $scope.dropdownImage = menu["choose-country-link"];
                       $scope.dropdownCountryLabel = menu["choose-country-label"];
                       $scope.dropdownCoutry = menu["country-name"];
                       $scope.countryUrl = menu["choose-country-link"];
                       $scope.altText = menu["country-image-alt-text"];
                    }
                }
            //});
            }
        ],

        link: function(scope, iElement, iAttrs, navCtrl, $transclude) {
            
        }
    };
};

fticUtilityDropdownMenu.$inject = ['appConfig','configUrlModel'];
module.exports = fticUtilityDropdownMenu;
