// userEmailIds.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var emailSchema = new mongoose.Schema({
    emailObject: {
        type: Array,
        "default": {}
    }
});

var emailLookUp = mongoose.model('emailLookUp', emailSchema);

var emailModel = new emailLookUp({

  "emailObject": {
      "distEmailIds": ["Shankar.n@abc.com", "Shankar.narayan@abc.com", "Narayan@abc.com",  "S.narayan@abc.com"]
    }
});

emailLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating emailLookUp table, please contact admin...');
    } else {
        emailLookUp.remove({}, function(err) {
            console.log('emailLookUp collection removed');
            emailModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating emailLookUp table, please contact admin...');
                }
                console.log('emailLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = emailLookUp;
