// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var CancelStpFundDetailsModelSchema = new mongoose.Schema({
    cancelStpResp: {
        type: Object,
        "default": {}
    }
});

var CancelStpFundDetailsModelLookUp = mongoose.model('CancelStpFundDetailsModelLookUp', CancelStpFundDetailsModelSchema);

var CancelStpFundDetailsModel = new CancelStpFundDetailsModelLookUp({

    cancelStpResp :{  
   "folioId":"14512366",
   "stpSummary":[  
      {  
         "alertDays":"7",
         "alertFlag":"Y",
         "amount":"2000",
         "balInsallNo":"31",
         "cancelDate":"28/04/2017",
         "destAccNo":"1729900886175",
         "destFundDesc":"Franklin India Savings Plus Fund Retail Option",
         "endDate":"28/10/2019",
         "frequency":"Monthly",
         "nextTiggerDate":"28/04/2017",
         "sourceAccNo":"1689900886175",
         "sourceFundDesc":"Franklin India Dynamic P E Ratio Fund Of Funds",
         "startDate":"28/11/2010",
         "totalInsallNo":"155",
         "trxnNo":"SS000176"
      },
      {  
         "alertDays":"7",
         "alertFlag":"N",
         "amount":"2000",
         "balInsallNo":"30",
         "cancelDate":"07/05/2017",
         "destAccNo":"1729900886175",
         "destFundDesc":"Franklin India Savings Plus Fund Retail Option",
         "endDate":"07/10/2019",
         "frequency":"Monthly",
         "nextTiggerDate":"07/05/2017",
         "sourceAccNo":"1689900886175",
         "sourceFundDesc":"Franklin India Dynamic P E Ratio Fund Of Funds",
         "startDate":"07/12/2010",
         "totalInsallNo":"90",
         "trxnNo":"SS000976"
      }
     
   ]
}  
});

CancelStpFundDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating CancelStpFundDetailsModelLookUp table, please contact admin...');
    } else {
        CancelStpFundDetailsModelLookUp.remove({}, function(err) {
            console.log('cancelStpDetailsModelLookUp collection removed');
            CancelStpFundDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating CancelStpFundDetailsModelLookUp table, please contact admin...');
                }
                console.log('CancelStpFundDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = CancelStpFundDetailsModelLookUp;