module.exports = function (grunt) {
    /*

     Build output folders:

     build/package => output of build
     build/stage => temporary location for creation of artifacts during build without worry about detritus

     if doing a versioned build pass the build version as parameter, e.g.,
     grunt build --ntTAG=v1.2.3
     OR
     grunt build --ntTAG=v1.2.3 --ptDESCRIPTION=Stuff

     */

    //------ Build Parameters ----------------
    var devBuildTag = 'DevOnly-' + new Date().toISOString();
    var buildTag = grunt.option('ntTAG');
    if (buildTag == null || (buildTag.indexOf('customRevision') > -1 )) {
        buildTag = devBuildTag;
    }
    var versionDescription = grunt.option('ptDESCRIPTION');
    if (!versionDescription) {
        versionDescription = 'No Information';
    }
    var mainJsFileName = 'main';
    var cacheBuster = 'cachebuster=' + buildTag;


    //------ Config ----------------
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        // Build clean
        clean: {
            stage: ['build/stage1/**/*', 'build/stage2/**/*'],
            package: ["build/package/**/*"]
        },
        // Build copying
        copy: {
            static: {
                cwd: 'src',
                timestamp: true,
                src: ['images/**/*', 'fonts/**/*', 'css/**/*', 'lib/**/*', '*.html', 'keepalive*.*'],
                dest: 'build/package',
                expand: true
            },
            environmentconfigs: {
                cwd: 'src',
                timestamp: true,
                src: ['*config.js'],
                dest: 'build/package',
                expand: true
            },
            defaultconfigforoptimize: {
                expand: true,
                dot: true,
                cwd: 'src',
                src: 'base-config.js',
                dest: 'build/stage1/',
                expand: true,
                rename: function(dest, src) {
                    return dest + src.replace('base-','');
                }
            },
            stage: {
                cwd: 'src',
                timestamp: true,
                src: ['app/**/*', 'lib/**/*', 'main.js', '*config.js'],
                dest: 'build/stage1',
                expand: true
            },
            optimizedMain: {
                cwd: 'build/stage2',
                timestamp: true,
                src: ['main.js'],
                dest: 'build/package',
                expand: true
            }
        },
        // Build replacements
        replace: {
            // version page (update the version.html with the version parameter passed to this script )
            versionHtml: {
                src: ['build/package/version.html'],
                overwrite: true,
                replacements: [
                    {
                        from: '$APP-VERSION',
                        to: buildTag + ' (built ' + Date().toString() + ')'
                    },
                    {
                        from: '$VERSION-DESCRIPTION',
                        to: versionDescription
                    },
                ]
            },
            cacheBustingReplace: {
                src: ['build/package/index.html'],
                overwrite: true,
                replacements: [
                    {
                        from: /<!--BUILD-REMOVE-START-->[\s\S]+?<!--BUILD-REMOVE-END-->/,
                        to: '<script type="text/javascript">var require = {urlArgs: "' + cacheBuster + '", waitSeconds: 60};</script>'
                    }
                ]
            }
        },
        // linting JavaScript files.
        eslint: {
            target: ['Gruntfile.js', 'src/app/**/*.js', 'src/app/**/**/*.js']
        },
        // compile sass stylesheets to css
        sass: {
            options: {
                sourceMap: true
            },
            dist: {
                files: {
                    'src/css/*.css': 'src/scss/*.scss',
                    'src/css/components/*.css': 'src/scss/components/*.scss',
                    'src/css/partials/*.css': 'src/scss/partials/*.scss',
                    'src/css/partials/components/*.css': 'src/scss/partials/components/*.scss',
                    'src/css/vendor/*.css': 'src/scss/vendor/*.scss',
                    'src/css/main.css': 'src/scss/main.scss'
                }
            }
        },
        // linting SASS files.
        stylelint: {
            simple: {
                options: {
                    configFile: '.stylelintrc'
                },
                src: ['src/scss/*.scss', 'src/scss/partials/*/*.scss', 'src/scss/partials/*.scss']
            }
        },

        //Linting HTML files
        htmlhintplus: {
            options: {
                rules: {
                    "attr-value-double-quotes": false,
                    "doctype-first": false,
                    "tag-pair": false,
                    "spec-char-escape": false,
                    "img-alt-require": false,
                    "doctype-html5": false,
                    "id-class-value": false,
                    "space-tab-mixed-disabled": false,
                    "id-class-ad-disabled": false,
                    "href-abs-or-rel": false,
                    "attr-unsafe-chars": false
                },
                extendRules: true
            },
            build: {
                options: {
                    force: false
                },
                src: ['src/app/*/templates/*.html', 'src/app/modules/saa/templates/*.html']

            }
        },
        // watch all specified files for any changes and run the corresponding tasks
        watch: {
            // for stylesheets, watch CSS and SASS files for any change, run sass and stylelint if change occurs
            stylesheets: {
                files: ['src/css/*.{css}', 'src/scss/*.{css,scss}', 'src/scss/partials/*/*.scss', 'src/scss/partials/*.scss'],
                tasks: ['sass', 'stylelint']
            },
            // for scripts, watch js files for any change, run jshint if change occurs
            scripts: {
                files: ['src/app/**/*.js', 'src/app/**/**/*.js', 'src/test/*.js'],
                tasks: ['eslint']
            }
        },
        /* requirejs optimizer: (concatenate all of the require loaded artifacts into a single js) */
        requirejs: {
            optimize: {
                options: {
                    baseUrl: "build/stage1",
                    dir: "build/stage2",
                    removeCombined: false,
                    keepBuildDir: false,
                    optimize: "none",
                    findNestedDependencies: true,
                    stubModules: ['text'],
                    optimizeAllPluginResources: false,
                    uglify2: {
                        output: {
                            beautify: {
                                semicolons: false
                            }
                        },
                        compress: false,
                        warnings: true,
                        mangle: false
                    },
                    generateSourceMaps: false,
                    preserveLicenseComments: false,
                    paths: {
                        jquery: 'lib/jquery.min-2.2.4',
                        elementary:'lib/elementary-1.0.0',
                        lodash: 'lib/lodash.min-4.13.0',
                        q: 'lib/q.min-1.4.1',
                        backbone: 'lib/backbone.min-1.3.3',
                        backbonesubroute: 'lib/backbone.subroute.min-0.4.5',
                        text: 'lib/text.min-2.0.12',
                        moment: 'lib/moment.min-2.13.0',
                        momentTimezone: 'lib/moment-timezone.min-0.5.4',
                        bootstrap: 'lib/bootstrap.min-3.3.6',
                        bootstraptypeahead: 'lib/bootstrap3-typeahead.min',
                        'bootstrap-dialog': 'lib/bootstrap-dialog.min-1.35.1',
                        CryptoJS: 'lib/sha1.min-3.1.2',
                        ampfComponents: 'lib/ampf-components',
						page: 'lib/page-1.7.1'
                    },
                    modules: [
                        {
                            name: "main",
                            exclude:[
                                'config',
                                'jquery',
                                'elementary',
                                'backbone',
                                'lodash',
                                'underscore',
                                'q',
                                'backbone',
                                'backbonesubroute',
                                'text',
                                'moment',
                                'momentTimezone',
                                'bootstrap',
                                'bootstrap-dialog',
                                'CryptoJS'
                            ]
                        }
                    ],
                    map: {
                        '*': {
                            // backbone requires underscore...lodash is a superset of underscore
                            underscore: 'lodash'
                        }
                    }
                }
            }
        },
        babel: {
            options: {
                sourceMap: true,
                presets: ['babel-preset-es2015']
            },
            dist: {
                files: [
                    {
                        expand: true,
                        cwd: 'src/',
                        src: ['app/**/*.js'],
                        dest: 'build/stage1/'
                    }
                ]
            }
        },
    });

    grunt.loadNpmTasks('grunt-eslint');
    grunt.loadNpmTasks('grunt-sass');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-stylelint');
    grunt.loadNpmTasks('grunt-htmlhint-plus');
    grunt.loadNpmTasks('grunt-babel');
    grunt.loadNpmTasks('grunt-contrib-clean');

    grunt.registerTask('build', 'Creates a folder for deployment at build/package', function (name) {


        grunt.loadNpmTasks('grunt-contrib-copy');
        grunt.loadNpmTasks('grunt-contrib-requirejs');
        grunt.loadNpmTasks('grunt-text-replace');

        console.log('Build Tag: '+ buildTag);
        grunt.task.run('clean');
        grunt.task.run('test');
        grunt.task.run('copy:static');
        grunt.task.run('copy:environmentconfigs');
        grunt.task.run('replace:versionHtml');
        grunt.task.run('replace:cacheBustingReplace');
        grunt.task.run('copy:stage');
        grunt.task.run('babel');
        grunt.task.run('copy:defaultconfigforoptimize');
        grunt.task.run('requirejs:optimize');
        grunt.task.run('copy:optimizedMain');
        grunt.task.run('sass');


    });
    grunt.registerTask('audit', function() {
        var auditor = require('./audits.js');
        var ok = auditor.runAllAudits();
        if (ok) {
            console.log('code audit successful');
        } else {
            grunt.fail.fatal('code audits failed');
        }
    });

    grunt.registerTask('transpile', ['clean', 'babel']);
    grunt.registerTask('test', ['eslint', 'stylelint']);
    grunt.registerTask('default', ['eslint', 'sass', 'stylelint']);


};