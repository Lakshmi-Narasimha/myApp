(function() {
    'use strict';

    var commonModule = angular.module('CSS.commonfilter', []);
    commonModule.filter('phoneFormatBracket', [function() {
        return function(number) {
            if (!number) {
                return '';
            }
            number = String(number);
            number = number.split('-').join('');
            var formattedNumber = number;
            var c = (number[0] === '1') ? '1 ' : '';
            number = (number[0] === '1' && number.length > 10) ? number.slice(1) : number;
            number = (number[0] === '-') ?  number.slice(1) : number; 

            // (###) ###-#### as c (area) front-end
            var area = number.substring(0, 3);
            var front = number.substring(3, 6);
            var end = number.substring(6, 10);

            if (front) {
                formattedNumber = ("(" + area + ") " + front);
            }
            if (end) {
                formattedNumber += ("-" + end);
            }
            return formattedNumber;
        };
    }]);
    commonModule.filter('phoneFormat', [function() {
        return function(number) {
            if (!number) {
                return '';
            }

            number = String(number);
            number = number.split('-').join('');
            var formattedNumber = number;
            number = (number[0] === '1' && number.length > 10) ? number.slice(1) : number;
            number = (number[0] === '-') ?  number.slice(1) : number; 
            //###-###-#### as c (area) front-end
            var area = number.substring(0, 3);
            var front = number.substring(3, 6);
            var end = number.substring(6, number.length);

            if (front) {
                formattedNumber = ("" + area + "-" + front);
            }
            if (end) {
                formattedNumber += ("-" + end);
            }
            return formattedNumber;
        };
    }]);

    /* Filter to display string in ###-##-#### format */
    commonModule.filter('policyContractNumberFormat', [function() {
        return function(number) {
            if (!number) {
                return '';
            }

            number = String(number);
            var numberLn = number.length;
            //console.log(number.length);
            //format string like #####-##-## 
            var front = number.substring(0, 5);
            var middle = number.substring(5, 7);
            var end = number.substring(7, numberLn);

            number = middle ? ("" + front + "-" + middle) : number;
            number = end ? (number+"-"+end) : number;
            return number;
        };
    }]);

    /**
     * Filter to display date in mm/dd/yyyy format
     */
    commonModule.filter('formatDate', [function() {
        return function(param, dashedformat) {
            var result = "";
            if (param != null) {
                var formatDate = (param).split("T")[0].split('-');
                if (formatDate.length > 1) {
                    result = formatDate[1] + '/' + formatDate[2] + '/' + formatDate[0];
                } else {
                    result = param;
                }
            }
            return result;
        };
    }]);

    /**
     * Filter to display date in mm-dd-yyyy format
     */
    // commonModule.filter('formatDateDashed', [function() {
    //     return function(param) {
    //         var result = "";
    //         if (param != null) {
    //             var formatDate;
    //             var len = (param).split("T").length;

    //             if (len > 1) {
    //                 formatDate = param.split('T')[0].split('-');
    //                 result = formatDate[1] + "-" + formatDate[2] + "-" + formatDate[0];
    //             } else {
    //                 formatDate = param.split('-');
    //                 if (param.split('-').length > 1) {
    //                     result = formatDate[1] + "-" + formatDate[2] + "-" + formatDate[0];
    //                 } else if(param.split('/').length > 1) {
    //                     result = param.replace(/\//g, "-");
    //                 }
    //                 else {
    //                     result = param;
    //                 }
    //             }
    //         }
    //         return result;
    //     };
    // }]);


    /**
     * Filter to display proper currency format
     */
    commonModule.filter('currencyFix', ['numberFilter', function(numberFilter) {
        return function(input, curSymbol, decPlaces, thouSep, decSep) {
            if (input === null || input === undefined) {
                return "$0.00";
            } // input; this may be bad, we shall see 
            curSymbol = curSymbol || "$";
            decPlaces = decPlaces || 2;
            thouSep = thouSep || ",";
            decSep = decSep || ".";

            input = input.toString();
            // Check for invalid inputs
            var amount = input.split(' '),
                suffix = '',
                dollarValue = amount[0];
            if (amount.length > 1) {
                suffix = amount[1];
            }
            var out = isNaN(dollarValue) || dollarValue === '' || dollarValue === null ? 0.0 : dollarValue;

            //Deal with the minus (negative numbers)
            var minus = dollarValue < 0;
            out = Math.abs(out);
            out = numberFilter(out, decPlaces);

            // Replace the thousand and decimal separators.
            // This is a two step process to avoid overlaps between the two
            if (thouSep !== ",") {
                out = out.replace(/\,/g, "T");
            }
            if (decSep !== ".") {
                out = out.replace(/\./g, "D");
            }
            out = out.replace(/T/g, thouSep);
            out = out.replace(/D/g, decSep);

            var finalValue = ($.trim(suffix) === '') ? curSymbol + out : curSymbol + out + ' ' + suffix;

            // Add the minus and the symbol
            if (minus) {
                return "-" + finalValue;
            } else {
                return finalValue;
            }
        };
    }]);



    commonModule.filter('monthDay', [function() {
        return function(param, monthname) {
            var monthDayYear, data;
            if (!param) {
                return;
            }
            data = param.replace(/-/gi, '/');
            var formatDate = new Date(data);
            var monthindex = formatDate.getMonth();
            formatDate = formatDate.toDateString();
            formatDate = formatDate.split(" ");
            monthDayYear = formatDate[1] + " " + formatDate[2] + ", " + formatDate[3];

            var months = ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ];

            if (monthname) {
                monthDayYear = months[monthindex] + " " + formatDate[2] + ", " + formatDate[3];
            }

            return monthDayYear;
        };
    }]);

    /***Paymethod with NickName ending XXXX***/
    commonModule.filter('payMethodFormat', [function() {
        return function(payMethod) {
            if (_.isUndefined(payMethod)) {
                return '';
            }
            var firstString = '',
                number = '';
            if (payMethod.systemGeneratedEncryptedNumberForBank !== null && payMethod.systemGeneratedEncryptedNumberForBank !== undefined) {
                if (payMethod.bankAccountHolderNickName !== null && payMethod.bankAccountHolderNickName !== undefined) {
                    firstString = payMethod.bankAccountHolderNickName;
                } else if (payMethod.accountHolderName !== null && payMethod.accountHolderName !== undefined) {
                    firstString = payMethod.accountHolderName;
                } else if (payMethod.bankAccountType !== null && payMethod.bankAccountType !== undefined) {
                    firstString = payMethod.bankAccountType;
                }
                if (payMethod.maskedValueForValueForBank !== null && payMethod.maskedValueForValueForBank !== undefined) {
                    number = payMethod.maskedValueForValueForBank;
                    number = number.substring(number.length, number.length - 4);
                }
            } else {
                if (payMethod.cardNickName !== null && payMethod.cardNickName !== undefined) {
                    firstString = payMethod.cardNickName;
                } else if (payMethod.cardCategory !== null && payMethod.cardCategory !== undefined) {
                    firstString = payMethod.cardCategory;
                } else if (payMethod.cardType !== null && payMethod.cardType !== undefined) {
                    firstString = payMethod.cardType;
                }
                if (payMethod.maskedValueForEncryptedValueForCreditCard !== null && payMethod.maskedValueForEncryptedValueForCreditCard !== undefined) {
                    number = payMethod.maskedValueForEncryptedValueForCreditCard;
                    number = number.substring(number.length, number.length - 4);
                }
            }

            return firstString + ' ending ' + number;
        };
    }]);

    commonModule.filter('dateSuffix', ['$filter', function($filter) {
        var suffixes = ["th", "st", "nd", "rd"];
        return function(input) {
            var dtfilter = input;
            var day = input ? input : '';
            var relevantDigits = (day < 30) ? day % 20 : day % 10;
            var suffix = (relevantDigits <= 3) ? suffixes[relevantDigits] : suffixes[0];
            return dtfilter + suffix;
        };
    }]);

    commonModule.filter('formatDisplayDate', [function() {
        return function(param) {
            var result = "";
            if (param != null) {
                var formatDate;
                var len = (param).split("T").length > 1;
                if (len >= 1) {
                    formatDate = param.split('T')[0].split('-');
                    result = formatDate[1] + "/" + formatDate[2] + "/" + formatDate[0];
                } else {
                    formatDate = param.split('-');
                    if (formatDate.length > 1) {
                        result = param.replace(/-/g, "/");
                    } else {
                        result = param;
                    }
                }

            }
            return result;
        };
    }]);


    /***Paymethod with NickName (...XXXX)***/
    commonModule.filter('payMethodDottedFormat', [function() {
        return function(payMethod) {
            if (_.isUndefined(payMethod)) {
                return '';
            }
            var firstString = '',
                number = '';
            if (payMethod.bankAccountType) {
                if (payMethod.bankAccountHolderNickName) {
                    firstString = payMethod.bankAccountHolderNickName;
                } else if (payMethod.bankAccountType) {
                    firstString = window.UIC.PAYMENT_METHOD_CODES[payMethod.bankAccountType];
                }
                if (payMethod.maskedValueForValueForBank) {
                    number = payMethod.maskedValueForValueForBank;
                    number = number.substring(number.length, number.length - 4);
                } else {
                    number = 'XXXX';
                }
            } else {
                if (payMethod.cardNickName) {
                    firstString = payMethod.cardNickName;
                } else if (payMethod.cardType) {
                    firstString = window.UIC.PAYMENT_METHOD_CODES[payMethod.cardType];
                }
                if (payMethod.maskedValueForEncryptedValueForCreditCard) {
                    number = payMethod.maskedValueForEncryptedValueForCreditCard;
                    number = number.substring(number.length, number.length - 4);
                } else {
                    number = 'XXXX';
                }
            }
            return firstString + ' (...' + number + ')';
        };
    }]);

    commonModule.filter('autoPayMethodDottedFormat', [function() {
        return function(payMethod) {
            if (_.isUndefined(payMethod)) {
                return '';
            }
            var firstString = '',
                number = '';
            if (payMethod.automaticSetupFlagForBankDetails !== null && payMethod.automaticSetupFlagForBankDetails === 'Y') {

                if (payMethod.bankAccountHolderNickName !== null && payMethod.bankAccountHolderNickName !== undefined) {
                    firstString = payMethod.bankAccountHolderNickName;
                } else if (payMethod.bankAccountType) {
                    firstString = window.UIC.PAYMENT_METHOD_CODES[payMethod.bankAccountType];
                }

                if (payMethod.maskedValueForValueForBank !== null && payMethod.maskedValueForValueForBank !== undefined) {
                    number = payMethod.maskedValueForValueForBank;
                    number = number.substring(number.length, number.length - 4);
                } else {
                    number = 'XXXX';
                }
            } else {
                if (payMethod.cardNickName !== null && payMethod.cardNickName !== undefined) {
                    firstString = payMethod.cardNickName;
                } else if (payMethod.cardType) {
                    firstString = window.UIC.PAYMENT_METHOD_CODES[payMethod.cardType];
                }
                if (payMethod.maskedValueForEncryptedValueForCreditCard !== null && payMethod.maskedValueForEncryptedValueForCreditCard !== undefined) {
                    number = payMethod.maskedValueForEncryptedValueForCreditCard;
                    number = number.substring(number.length, number.length - 4);
                } else {
                    number = 'XXXX';
                }
            }
            return firstString + ' (...' + number + ')';
        };
    }]);

    /***Is default payment method? ***/
    commonModule.filter('paymentMethodDefault', [function() {
        return function(payMethod) {
            var str = '';

            if (payMethod && (payMethod.defaultOrLastPaymentMethodType === 'Y')) {
                str = ' - Default';
            }
            return str;
        };
    }]);

    /*** Display card/bank type ***/
    commonModule.filter('paymentType', [function() {
        return function(payMethod) {
            var str = '';

            if (payMethod && payMethod.bankAccountType !== null) {
                str = window.UIC.PAYMENT_METHOD_CODES[payMethod.bankAccountType];
            } else {
                if (payMethod && payMethod.cardType !== null) {
                    str = window.UIC.PAYMENT_METHOD_CODES[payMethod.cardType];
                }
            }
            return str;
        };
    }]);

    /*** Display card/bank holder name ***/
    commonModule.filter('paymentHolderName', [function() {
        return function(payMethod) {
            var str = '';

            if (payMethod && payMethod.accountHolderName !== null) {
                str = payMethod.accountHolderName;
            } else {
                if (payMethod && payMethod.cardHolderName !== null) {
                    str = payMethod.cardHolderName;
                }
            }
            return str;
        };
    }]);

    // commonModule.filter('filterFormatNextDate', [function() {
    //     return function(param, yearVal, monthVal, dayVal) {
    //         var result = "";

    //         if (param != null) {
    //             var input = (param).split("T");
    //             if (input.length > 0) {
    //                 var date = input[0].split("-");
    //                 result = new Date(String(Number(date[0]) + Number(yearVal)), String(Number(date[1]) + Number(monthVal)), String(Number(date[2]) + Number(dayVal)));
    //             }
    //         }
    //         return result;
    //     };
    // }]);

    commonModule.filter('formattedPaymentMethod', [function() {
        return function(paymentMethod) {
            var str = "";
            if (paymentMethod) {
                if (paymentMethod.cardNickName != null || paymentMethod.bankAccountHolderNickName != null) {
                    str = paymentMethod.cardNickName != null && paymentMethod.cardNickName.length > 0 ? paymentMethod.cardNickName + "*" + paymentMethod.maskedValueForEncryptedValueForCreditCard.replace(/\*/g, '') : paymentMethod.bankAccountHolderNickName + "*" + paymentMethod.maskedValueForValueForBank.replace(/\*/g, '');
                } else {
                    if (paymentMethod.maskedValueForEncryptedValueForCreditCard != null && paymentMethod.maskedValueForEncryptedValueForCreditCard.length > 0) {
                        str = paymentMethod.maskedValueForEncryptedValueForCreditCard;
                    } else {
                        str = paymentMethod.maskedValueForValueForBank;
                    }
                }
            }
            return str;
        };
    }]);


    /*** Display gender fully ***/
    commonModule.filter('gender', [function() {
        return function(str) {
            if (str !== 'U' && str) {
                str = (str === 'M') ? 'Male' : 'Female';
            } else {
                str = "";
            }
            return str;
        };
    }]);

    /*** Display empty string instead of null ***/
    commonModule.filter('nullCheck', [function() {
        return function(str) {
            if (!str) {
                str = "";
            }
            return str;
        };
    }]);

    commonModule.filter('detectCardCategory', [function() {
        return function(cardNumber) {
            var cards = {
                visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
                mastercard: /^5[1-5][0-9]{14}$/,
                amex: /^3[47][0-9]{13}$/,
                discover: /^6(?:011|5[0-9]{2})[0-9]{12}$/,
            };
            if (cards.visa.test(cardNumber)) {
                return 'VISA';
            } else if (cards.mastercard.test(cardNumber)) {
                return 'MASTERCARD';
            } else if (cards.amex.test(cardNumber)) {
                return 'AMEX';
            } else if (cards.discover.test(cardNumber)) {
                return 'DISCOVER';
            } else {
                return undefined;
            }
        };
    }]);

    // commonModule.filter('titlecase',[function(){
    //     return function(input) {
    //       input = input || '';
    //       return input.replace(/\w\S*/g, function(txt){return txt.charAt(0).toLowerCase().toUpperCase() + txt.substr(1).toLowerCase();});
    //     };          
    // }]);

    commonModule.filter('isValidCreditCard', ['detectCardCategoryFilter', function(detectCardCategoryFilter) {
        return function(cardnumber) {
            var cardcode = detectCardCategoryFilter(cardnumber);
            var supportedCardTypes = [
                window.UIC.SUPPORTED_CREDIT_CARDS.AMEX,
                window.UIC.SUPPORTED_CREDIT_CARDS.DISCOVER,
                window.UIC.SUPPORTED_CREDIT_CARDS.VISA,
                window.UIC.SUPPORTED_CREDIT_CARDS.MASTERCARD
            ];

            if (cardcode === undefined) {
                return false;
            }
            //require card number and card type 
            if (cardnumber === null || cardcode === null || cardnumber === undefined || cardcode === undefined) {
                return false;
            }
            //only validate master card or visa type 
            if ($.inArray(cardcode.toUpperCase(), supportedCardTypes) === -1) {
                return false;
            }

            var ccErrorNo = 0;
            var ccErrors = [];

            ccErrors[0] = "Unknown card type";
            ccErrors[1] = "No card number provided";
            ccErrors[2] = "Credit card number is in invalid format";
            ccErrors[3] = "Credit card number is invalid";
            ccErrors[4] = "Credit card number has an inappropriate number of digits";
            ccErrors[5] = "Warning! This credit card number is associated with a scam attempt";


            // Array to hold the permitted card characteristics
            var cards = [];

            // Define the cards we support. You may add addtional card types as follows.

            //  Name:         As in the selection box of the form - must be same as user's
            //  Length:       List of possible valid lengths of the card number for the card
            //  prefixes:     List of possible prefixes for the card
            //  checkdigit:   Boolean to say whether there is a check digit

            cards[0] = {
                name: "Visa",
                code: window.UIC.SUPPORTED_CREDIT_CARDS.VISA,
                length: "13,16",
                prefixes: "4",
                checkdigit: true
            };
            cards[1] = {
                name: "MasterCard",
                code: window.UIC.SUPPORTED_CREDIT_CARDS.MASTERCARD,
                length: "16",
                prefixes: "51,52,53,54,55",
                checkdigit: true
            };
            cards[2] = {
                name: "American Express",
                code: window.UIC.SUPPORTED_CREDIT_CARDS.AMEX,
                length: "15",
                prefixes: "34,37",
                checkdigit: true
            };
            cards[3] = {
                name: "Discover",
                code: window.UIC.SUPPORTED_CREDIT_CARDS.DISCOVER,
                length: "16",
                prefixes: "6011,622,64,65",
                checkdigit: true
            };


            // Establish card type
            var cardType = -1;
            for (var i = 0; i < cards.length; i++) {

                // See if it is this card (ignoring the case of the string)
                if (cardcode.toLowerCase() === cards[i].code.toLowerCase()) {
                    cardType = i;
                    break;
                }
            }

            // If card type not found, report an error
            if (cardType === -1) {
                ccErrorNo = 0;
                return false;
            }

            // Ensure that the user has provided a credit card number
            if (cardnumber.length === 0) {
                ccErrorNo = 1;
                return false;
            }

            // Now remove any spaces from the credit card number
            cardnumber = cardnumber.replace(/\s/g, "");

            // Check that the number is numeric
            var cardNo = cardnumber;
            var cardexp = /^[0-9]{13,19}$/;
            if (!cardexp.exec(cardNo)) {
                ccErrorNo = 2;
                return false;
            }

            // Now check the modulus 10 check digit - if required
            if (cards[cardType].checkdigit) {
                var checksum = 0; // running checksum total
                var mychar = ""; // next char to process
                var j = 1; // takes value of 1 or 2

                // Process each digit one by one starting at the right
                var calc;
                for (i = cardNo.length - 1; i >= 0; i--) {

                    // Extract the next digit and multiply by 1 or 2 on alternative digits.
                    calc = Number(cardNo.charAt(i)) * j;

                    // If the result is in two digits add 1 to the checksum total
                    if (calc > 9) {
                        checksum = checksum + 1;
                        calc = calc - 10;
                    }

                    // Add the units element to the checksum total
                    checksum = checksum + calc;

                    // Switch the value of j
                    if (j === 1) {
                        j = 2;
                    } else {
                        j = 1;
                    }
                }

                // All done - if checksum is divisible by 10, it is a valid modulus 10.
                // If not, report an error.
                if (checksum % 10 !== 0) {
                    ccErrorNo = 3;
                    return false;
                }
            }

            // Check it's not a spam number
            if (cardNo === '5490997771092064') {
                ccErrorNo = 5;
                return false;
            }

            // The following are the card-specific checks we undertake.
            var LengthValid = false;
            var PrefixValid = false;

            // We use these for holding the valid lengths and prefixes of a card type
            var prefix = [];
            var lengths = [];

            // Load an array with the valid prefixes for this card
            prefix = cards[cardType].prefixes.split(",");

            // Now see if any of them match what we have in the card number
            for (i = 0; i < prefix.length; i++) {
                var exp = new RegExp("^" + prefix[i]);
                if (exp.test(cardNo)) {
                    PrefixValid = true;
                }
            }

            // If it isn't a valid prefix there's no point at looking at the length
            if (!PrefixValid) {
                ccErrorNo = 3;
                return false;
            }

            // See if the length is valid for this card
            lengths = cards[cardType].length.split(",");
            for (var v = 0; v < lengths.length; v++) {
                if (cardNo.length === parseInt(lengths[v], 10)) {
                    LengthValid = true;
                }
            }

            // See if all is OK by seeing if the length was valid. We only check the length if all else was
            // hunky dory.
            if (!LengthValid) {
                ccErrorNo = 4;
                return false;
            }

            // The credit card is in the required format.
            return true;

        };
        /*================================================================================================*/

        /*********************************************/
    }]);
    
    /* Filter to display paymentCardNumber string in ...XXXX format */
    // commonModule.filter('paymentCardNumberFormat', [function() {
    //     return function(string) {
    //         if (!string) {
    //             return '';
    //         }

    //         if(string === '_') {
    //             return '';
    //         }

    //         var stringLn = string.length;
    //         //format string like ...XXXX 
    //         string = '...' + string.substring(stringLn - 4, stringLn);
    //         return string;
    //     };
    // }]);

    // commonModule.filter('zipcodeformat',[function(){
    //     var mask1 = new StringMask('00000-0000'),
    //         mask2 = new StringMask('00000');
    //     function applyZipMask(value) {
    //         var processed1 = mask1.process(value),
    //             processed2 = mask2.process(value);
    //         var formatedValue = processed1.result || processed2.result || '';
    //         return formatedValue.trim().replace(/[^0-9]$/, '');
    //     }
    //     return function(code){

    //         if(!code){
    //             return code;
    //         }
    //         else{
    //             return applyZipMask(code);
    //         }
    //     };
    // }]);

    // /* Filter to display Phone Number in XXXX.XXX(dot) format */
    // commonModule.filter('phoneDotFormat', [function() {
    //     return function(number) {
    //         if (!number) {
    //             return '';
    //         }
    //         number = String(number);
    //         var formattedNumber = number;
    //         //###.###.#### as c (area) front-end
    //         var area = number.substring(0, 3);
    //         var front = number.substring(3, 6);
    //         var end = number.substring(6, 10);
    //         if (front) {
    //             formattedNumber = ("" + area + "." + front);
    //         }
    //         if (end) {
    //             formattedNumber += ("." + end);
    //         }
    //         return formattedNumber;
    //     };
    // }]); 

    commonModule.filter('truncateNickname', [function() {
        return function(value) {
            if (!value) {
                return '';
            }

            value = String(value);
            var valueLn = value.length;
            if(valueLn > 9) {
                value = value.substring(0, 8);
            }

            return value;
        };
    }]);

})();
