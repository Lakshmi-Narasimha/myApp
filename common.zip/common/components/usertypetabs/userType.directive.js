/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var userType = function($timeout,constants) {
	return {
            template: require('./userType.html'),
            restrict: 'E',
            replace: true,
            scope: {
                
            },
            controller:['$scope', function($scope){
                $scope.investorSelected=function($event){
                  $event.preventDefault();
                  $scope.$emit('investorSelected');
                }
                $scope.advisorSelected=function($event){
                  $event.preventDefault();
                  $scope.$emit('advisorSelected');
                }
            }]
        };
};

userType.$inject = ['$timeout','constants'];
module.exports = userType;