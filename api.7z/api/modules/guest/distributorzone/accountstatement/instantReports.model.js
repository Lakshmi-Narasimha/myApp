// instantReports.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InstantReportsSchema = new mongoose.Schema({
    instantReportsObject: {
        type: Array,
        "default": []
    }
});

var InstantReportsLookUp = mongoose.model('InstantReportsLookUp', InstantReportsSchema);

var InstantReportsModel = new InstantReportsLookUp({

  "instantReportsObject": [
    {
        "instantReportsDetails": [
            {   
                "reportName":"Commission Details",
                "reportData": [{
                    "title": "Distributor Payment Ledger Commission Type",
                    "report_id": 7894,
                    "Estimated Turnaround Time": "Jan 2016 to Feb 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Distributor-Payment-Ledger-Commission-Type.pdf",
                    "rangeType": "Month",
                    "availableFormat": ["Text", "DBF"]
                }, {
                    "title": "Held Payments",
                    "report_id": 8956,
                    "Estimated Turnaround Time": "Jun 2016 to Aug 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/Held-Payments.jpg",
                    "rangeType": "Frequency",
                    "availableFormat": ["Excel", "DBF", "Text"]
                }, {
                    "title": "Trail Payable",
                    "report_id": 1256,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Trail-Payable.pdf",
                    "rangeType": "As On Date",
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "First Year Trail",
                    "report_id": 1122,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/First-Year-Trail.pdf",
                    "rangeType": "Last Range",
                    "availableFormat": ["DBF", "Text"]
                }, {
                    "title": "Long Term",
                    "report_id": 2233,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/long-term.jpg",
                    "rangeType": "none",
                    "availableFormat": ["Excel", "Text"]
                }]
            },

            {   
                "reportName":"Investor Details",
                "reportData":[{
                    "title": "Clients Month-End Balances",
                    "report_id": 1234,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/ClientsMonth-EndBalances.pdf",
                    "rangeType": "Month",
                    "availableFormat": ["Excel", "DBF"]
                }, {
                    "title": "Client Wise AUM or Whose Balance Exceeds 'N'",
                    "report_id": 2345,
                    "Estimated Turnaround Time": "Jan 2016 to Mar 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/client-wise-aum.jpg",
                    "rangeType": "Next Month",
                    "availableFormat": ["Excel", "DBF", "Text"]
                }, {
                    "title": "No PAN Investors",
                    "report_id": 1254,
                    "Estimated Turnaround Time": "Mar 2016 to Apr 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/No-PAN-Investors.pdf",
                    "rangeType": "Month",
                    "availableFormat": ["Excel", "DBF"]
                }, {
                    "title": "KYC Status Report",
                    "report_id": 4524,
                    "Estimated Turnaround Time": "Feb 2016 to May 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/ClientsMonth-EndBalances.pdf",
                    "rangeType": "Frequency",
                    "availableFormat": ["Text", "DBF"]
                }, {
                    "title": "Recently exited (zero balance) investors",
                    "report_id": 5875,
                    "Estimated Turnaround Time": "June 2016 to Aug 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/recently-exted-investors.jpg",
                    "rangeType": "Period",
                    "availableFormat": ["DBF", "Excel"]
                }, {
                    "title": "Client-wise RPO Report",
                    "report_id": 1245,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Client-wise-RPO-Report.pdf",
                    "rangeType": "As On Date",
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Top 200 Clients",
                    "report_id": 2576,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/top-200-clients.jpg",
                    "rangeType": "Select",
                    "availableFormat": ["Text", "Excel"]
                }]
            },
            {
                "reportName":"Special Products",
                "reportData": [{
                    "title": "Product Investors",
                    "report_id": 3333,
                    "Estimated Turnaround Time": "Jan 2016 to Feb 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/Product-Investors.jpg",
                    "rangeType": "Select",
                    "availableFormat": ["Text", "Excel"]
                }, {
                    "title": "special products2",
                    "report_id": 2222,
                    "Estimated Turnaround Time": "Feb 2016 to May 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/special-products2.pdf",
                    "rangeType": "Frequency",
                    "availableFormat": ["Excel", "DBF"]
                }, {
                    "title": "Recent Products",
                    "report_id": 7878,
                    "Estimated Turnaround Time": "June 2016 to Aug 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/recent-products.jpg",
                    "rangeType": "Period",
                    "availableFormat": ["DBF", "Excel"]
                }]
            },
            {
                "reportName":"Transaction Details",
                "reportData": [{
                    "title": "Transaction Details1",
                    "report_id": 5566,
                    "Estimated Turnaround Time": "Oct 2016 to Dec 2016",
                    "sampleType": "image",
                    "sampleSource": "../images/Transaction-Details1.jpg",
                    "rangeType": "Next Month",
                    "availableFormat": ["Excel", "DBF", "Text"]
                }, {
                    "title": "Transaction Details2",
                    "report_id": 2255,
                    "Estimated Turnaround Time": "Feb 2016 to Apr 2016",
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Transaction-Details2.pdf",
                    "rangeType": "As On Date",
                    "availableFormat": ["Excel", "Text"]
                }]
            }
        ]
    }
]

});

InstantReportsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InstantReportsLookUp table, please contact admin...');
    } else {
        InstantReportsLookUp.remove({}, function(err) {
            console.log('InstantReportsLookUp collection removed');
            InstantReportsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InstantReportsLookUp table, please contact admin...');
                }
                console.log('InstantReportsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InstantReportsLookUp;
