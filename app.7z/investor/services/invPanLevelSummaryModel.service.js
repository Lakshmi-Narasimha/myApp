/**
 * @ngdoc service
 * @name invPanLevelSummaryModel service
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Eform Model deals with the fetching data from the service and returning the promise object as well as setting and getting the data. 
 *
 */

'use strict';

var invPanLevelSummaryModel = function (Restangular, $q, authenticationService, investorConstants, loggerConstants, fticLoggerMessage) {
    
    var _panLevelSummary = null;
    var params;
    var invPanLevelSummaryModel = {

        getPanLevelSummaryDetails: function(paramsObj) {
            // var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_EFORMS_MODULE + ' | ' + loggerConstants.INV_COMMON_FOLIO_DETAILS_MODEL + ' | getFolioAccountDetails' /* Function Name */;
            // fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            params = paramsObj || {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one(investorConstants.myprofile.INV_PAN_LEVEL_SUM_URL).get(params).then(function(response) {
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setPanLevelSummaryData: function(data) {
            _panLevelSummary = data.investmentSummary;
        },
        getPanLevelSummaryData: function() {
            return _panLevelSummary;
        }
    };
    return invPanLevelSummaryModel;
};

invPanLevelSummaryModel.$inject = ['Restangular', '$q', 'authenticationService', 'investorConstants', 'loggerConstants', 'fticLoggerMessage'];

module.exports = invPanLevelSummaryModel;
