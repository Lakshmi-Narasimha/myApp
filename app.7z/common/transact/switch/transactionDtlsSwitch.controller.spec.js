'use strict';
describe('Controller: switchTransDetailsController', function() {
	var $controller,$scope,switchTransDetailsController,TransactConstant,switchDtlsToReviewModel,transactModel,$state;

	var switchBaseDtlsObjWithAmountEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Amount",        
        amount : 8000
	};

	var switchBaseDtlsObjWithUnitsEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Amount",              
        units : 3000
	};	

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_TransactConstant_,_switchDtlsToReviewModel_,_transactModel_,_$state_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();
		
		TransactConstant = _TransactConstant_;		
        transactModel = _transactModel_;
		$state = _$state_;

		switchDtlsToReviewModel = _switchDtlsToReviewModel_;			
		switchDtlsToReviewModel.setDataObj(switchBaseDtlsObjWithAmountEntered);
        transactModel.setTransactConfirm({
            'accountNo': '0010008062712',                     
            'transactionRefNo': 'SWI001166',
            'transDateTime':'Oct 16,2016'
        });

		loadController();			
	}));	

	function loadController(){
        switchTransDetailsController = $controller('transactionDtlsSwitchCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(switchTransDetailsController).toBeDefined();
    });

    it('should show the switch transaction details consisting of amount if user selected',function(){
        expect($scope.keyValuePairs[0].value).toBe("Franklin India PRIMA FUND");
        expect($scope.keyValuePairs[1].value).toBe("SWI001166");
        expect($scope.keyValuePairs[2].value).toBe("Oct 16,2016");
        expect($scope.keyValuePairs[3].value).toBe(8000);
    });

    it('should show the switch transaction details consisting of units if user selected',function(){
        switchDtlsToReviewModel.setDataObj(switchBaseDtlsObjWithUnitsEntered);
        loadController();
        expect($scope.keyValuePairs[0].value).toBe("Franklin India PRIMA FUND");
        expect($scope.keyValuePairs[1].value).toBe("SWI001166");
        expect($scope.keyValuePairs[2].value).toBe("Oct 16,2016");
        expect($scope.keyValuePairs[3].value).toBe(3000);
    });

    it('should call initiateAnotherSwitch function if initiateAnotherSwitch link is clicked on',function(){
        spyOn($state,"go");
        spyOn(transactModel,"resetSetters");
        $scope.initiateAnotherSwitch();
        expect(transactModel.resetSetters).toHaveBeenCalled();
        expect(transactModel.isNewInvestor).toBe(false);
        expect($state.go).toHaveBeenCalledWith('transact.base.switch',{key:null});
    });
});