/**
 * @ngdoc directive
 * @name ftickeyValueVerticalTileList
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - ftickeyValueVerticalTileList will display the vertical tiles for "My profile - Grant Access" .
 * 
 *
 **/
'use strict';

var keyValueVerticalTileList = function() {
	return {
            template: require('./keyValueVerticalTileList.html'),
            restrict: 'E',
            replace: true,
            scope: {
                list: '=',
                noofcols:'@'
            }
        };
};

keyValueVerticalTileList.$inject = [];
module.exports = keyValueVerticalTileList;