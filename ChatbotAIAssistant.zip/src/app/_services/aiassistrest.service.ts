import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/catch';

import { Agent } from '../_models/index';
import { Intent } from '../_models/index';
import { UserExpression } from '../_models/userexpression';
import { ReqBodyHelper } from '../_helpers/reqBodyHelper';

@Injectable()
export class AIAssistRestService {
    constructor(private http: Http) { }
    urlSecKey:string ="sf34r23rwefdwet34sewr34";
    baseURL:string = 'http://localhost:8080';
    //baseURL:string='http://10.177.253.68:8080';
    //baseURL:string='http://10.177.205.63:8080';
    engineURL:string = '/ChatBotEngine';

    getAllAgents() {
        let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
        //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
        return this.http.post(this.baseURL + this.engineURL + '/config/getAllAgents',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    getAgentById(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
      return this.http.post(this.baseURL + this.engineURL + '/config/getAgentById',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    // private helper methods
    createAgent(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
       return this.http.post(this.baseURL + this.engineURL + '/config/createAgent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    removeAgent(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
       return this.http.post(this.baseURL + this.engineURL + '/config/deleteAgent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    createIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
       return this.http.post(this.baseURL + this.engineURL + '/config/createIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    removeIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
       return this.http.post(this.baseURL + this.engineURL + '/config/deleteIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    getIntentById(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      //console.log(JSON.stringify(pIntent));
      reqBodyGenerator.reqIntent = pIntent;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
      return this.http.post(this.baseURL + this.engineURL + '/config/getIntentById',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    createUserExpressions(pUserExpressions: Array<UserExpression>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      //console.log("Inside createUserExpressions in rest");
      //console.log(JSON.stringify(pUserExpressions));
      reqBodyGenerator.reqUserExpressions = pUserExpressions;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
      return this.http.post(this.baseURL + this.engineURL + '/config/createUserExpression',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    deleteUserExpressions(pUserExpression: Array<UserExpression>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      //console.log("Inside deleteUserExpressions in rest");
      //console.log(JSON.stringify(pUserExpression));
      reqBodyGenerator.reqUserExpressions = pUserExpression;
      //console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
      return this.http.post(this.baseURL + this.engineURL + '/config/deleteUserExpression',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());//.subscribe((data) => console.log(data));
    }

    private jwt() {
        // create authorization header with jwt token
            let headers = new Headers({});
            return new RequestOptions({ headers: headers });

    }

 private extractData(res: Response) {
        let body = res.json();
        return body.data || { };
    }

   private handleError (error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

    /**
        getAllAgentsFromServer() {
          let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
          console.log(reqBodyGenerator.getRequestBody());
            return this.http.post(this.baseURL + '/config/getAllAgents',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json()).subscribe(
              (data) => console.log(data),err => console.log(err),
        () => console.log('yay'));
        }
        **/

    /*    getAllAgents() : Observable<Agent>{
            return this.http.get('/api/users', this.jwt()).map(this.extractData);
        }*/

}
