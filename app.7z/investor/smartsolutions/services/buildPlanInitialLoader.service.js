'use strict';

var buildPlanInitialLoader = function (buildPlanModelService, investorEvents) {

    var buildPlanInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope) {

            buildPlanModelService.fetchBuildPlan()
                .then(buildPlanSuccess, handleFailure);

            function buildPlanSuccess(data) {
                buildPlanModelService.setBuildPlanDtls(data[0]);
                investorEvents.smartSolutions.publishBuildPlan(scope,buildPlanModelService.getBuildPlanDtls());

            }

            function handleFailure(data){
                console.error('handleFailure');
                buildPlanInitialLoader._isServicesData = false;
            }
        }

    };
    return buildPlanInitialLoader;
};

buildPlanInitialLoader.$inject = ['buildPlanModelService', 'investorEvents'];

module.exports = buildPlanInitialLoader;