/**
 * @ngdoc property
 * @name fticInvestorSelectFolio directive
 * @description
 *
 *
 **/
'use strict';


var fticInvestorSelectFolio = function(invPanFolioKycModel, transactModel, transactNowModel, authenticationService, TransactConstant, transactEventConstants, invSelectFolioFormDataFactory, investorConstants) {

    return {
        template: require('./investorSelectFolio.html'),
        restrict: 'E',
        scope: {
            folioSelect : '='
        },
        controller: function($scope, $element, $attrs) {
            //$scope.radios = {};
            //$scope.folioSelect.folioselectedVal = "";
            $scope.KYC_STS_REG = investorConstants.accountsettings.KYC_STS_REG;
            $scope.selectedFolio = null;
            $scope.holderDtls = [];

            var _params = {
                'panNo': authenticationService.getUser().pan,
                'fsFlag': '',
                'txnAccess': 'Y'
            };

            var panFolioKycSuccess = function(data) {
                if (data) {
                    invPanFolioKycModel.setPanFolioKycData(data);
                    $scope.init(data.panFolioKyc);
                }
            };

            var promiseFailure = function(error) {
                if (error && error.data && error.data.length > 0) {
                    toaster.error(error.data[0].errorDescription);
                }
            };

            invPanFolioKycModel.getPanFolioKycDetails(_params)
                .then(panFolioKycSuccess, promiseFailure);

            $scope.init = function(data) {
                $scope.investorDetails = data;
                $scope.holderDtls = invSelectFolioFormDataFactory.getFormattedHolderDetails(data);
            };

            
           $scope.$on('purchaseGetDetails',function(data){
                if(data && data.targetScope && data.targetScope.invPurchaseData){
                     $scope.folioSelect.folioselectedVal = data.targetScope.invPurchaseData.folioNo;
                      _.each($scope.holderDtls, function(element,value){
                        if($scope.folioSelect.folioselectedVal === element.folioId){
                            $scope.selectedFolio = element;
                            $scope.index = value;
                            $scope.listenChange($scope.selectedFolio, $scope.index);
                        }
                    });
                }
            });



            $scope.listenChange = function(value, index) {
                $scope.selectedFolio = value;
                $scope.index = index;
                if (transactNowModel.isFolioEditClicked) {
                    $scope.referenceFolioId = transactModel.getSelectedFolioDts().folioId;
                    $scope.prevSelectedOptionDetails = transactModel.getSelectedFolioDts();
                }
                if (!invSelectFolioFormDataFactory.getCurrentSelectedFolioData($scope.selectedFolio.folioId)) {
                    invSelectFolioFormDataFactory.setFormattedCurrentFolio($scope.selectedFolio);
                }
                transactModel.setSelectedFolioDts(invSelectFolioFormDataFactory.getCurrentSelectedFolioData($scope.selectedFolio.folioId));
                $scope.$emit(transactEventConstants.transact.INV_FOLIO_SELECTED_CON);
            };

        },
        link: function(scope, iElement, iAttrs, controller, state) {}
    };
};


fticInvestorSelectFolio.$inject = ['invPanFolioKycModel', 'transactModel', 'transactNowModel', 'authenticationService', 'TransactConstant', 'transactEventConstants', 'invSelectFolioFormDataFactory', 'investorConstants'];

module.exports = fticInvestorSelectFolio;
