/**
 * @ngdoc service
 * @name stpDetailsModel
 * @description
 *
 * - It has setter and getter methods to set/get stp details data.
 *
 */

'use strict';

var stpDetailsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, transactModel, fundDetailsModel, TransactConstant) {
    var _stpDetails = null;

    var stpDetailsModel = {

        fetchTxnDetailsStp : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('transact/txnDetails').get(params).then(function (stpDetails) {
                deferred.resolve(stpDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
       
        setStpDetails : function(stpDetails) {
            _stpDetails = stpDetails;
        },

        getStpDetails : function() {
            return _stpDetails;
        },

        validateSTP : function(){
            var deferred = $q.defer();
            var params = {};
            var body = {};
            body.folioId = transactModel.getTransactDetails().investorDetails.folioId;
            body.amount =  transactModel.getTransactDetails().stpDetails.stpAmount.amount.toString();

            if(body.amount === 'Capital Appreciation'){
                // body.amount = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[1].substring(0, 2);
                var intAmount = Math.round((fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits) * 100) / 100;
                var stringAmount =  intAmount.toString();               
                body.amount = stringAmount;
                body.amountUnitFlag =  "C";
            }else{
                body.amountUnitFlag =  "A";
            }
            body.units =  "";
            body.txnSource =  'STP';
            body.txnType =  'STP';
            body.fundOption =  transactModel.getTransactDetails().fundDetails.tschvalAccno.substring(0,3);
            body.accountNo =  transactModel.getTransactDetails().fundDetails.tschvalAccno;
            var startDate = new Date(transactModel.getTransactDetails().stpDetails.startDate);
            var dd = startDate.getDate();
            var mm = startDate.getMonth()+1; //January is 0!
            var yyyy = startDate.getFullYear();
            if(dd<10){
              dd='0'+dd;
            } 
            if(mm<10){
              mm='0'+mm;
            } 
            var startDate = dd+'/'+mm+'/'+yyyy;
            body.startDate =  startDate;
            var endDate = new Date(transactModel.getTransactDetails().stpDetails.endDate);
            var dd = endDate.getDate();
            var mm = endDate.getMonth()+1; //January is 0!
            var yyyy = endDate.getFullYear();
            if(dd<10){
              dd='0'+dd;
            } 
            if(mm<10){
              mm='0'+mm;
            } 
            var endDate = dd+'/'+mm+'/'+yyyy;
            body.endDate =  endDate;
            if(transactModel.getTransactDetails().stpDetails.frequency === 'Weekly'){
                body.frequency =  'W';
            }else if(transactModel.getTransactDetails().stpDetails.frequency === 'Monthly'){
                body.frequency =  'LM';
            }else if(transactModel.getTransactDetails().stpDetails.frequency === 'Daily'){
                body.frequency =  'D';
            }else if(transactModel.getTransactDetails().stpDetails.frequency === 'Quarterly'){
                body.frequency =  'Q';
            }
            
            body.investmentGoalFlag =  "";
            body.dividendOption = transactModel.getTransactDetails().stpDetails.destinationFund.dividendFlag;
            body.urnNo =  "";
            body.source =  TransactConstant.common.USER_TYPE_ADVISOR;
            body.umrnNo =  "";
            body.subBrokerARN =  "";
            body.branchCode = "";
            body.toFundOption = transactModel.getTransactDetails().stpDetails.destinationFund.fundOption;
            if(transactModel.getTransactDetails().stpDetails.destinationFund.accNo){
                body.toAccount = transactModel.getTransactDetails().stpDetails.destinationFund.accNo;
            }else{
                body.toAccount = 'NEW';
                body.trxnType = 'NEW';
            }
            body.euin = "";
            body.dcLastX = "";
            body.dcName = "";
            body.subDist = "";
            body.batchCode = TransactConstant.common.BATCH_CODE;
            //body.installments = transactModel.getTransactDetails().stpDetails.noofInstallments.toString();
            params.guId = authenticationService.getUser().guId;
            Restangular.one('/transact/validateStp').customPOST(body, "", params, {}).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        }
    };
    return stpDetailsModel;
};

stpDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', 'transactModel', 'fundDetailsModel', 'TransactConstant'];
module.exports = stpDetailsModel;