import { ENV } from './env';

export const CONSTANTS = {
    ENV
};
