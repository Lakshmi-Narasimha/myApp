'use strict';

var slider = function(planSmartSolution) {
    // planSmartSolution.setSliderMaxLimit(100);
   
<<<<<<< HEAD
    return {
=======
	return {
>>>>>>> ftic-inv-sprint6
            template: require('./slider.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            controller:['$scope', function($scope){
                var maxSliderLength =  planSmartSolution.getSliderMaxLimit();
                var sliderDisable = planSmartSolution.getSliderDisable(); 
                $scope.slider_floor_ceil = {
              value:0,
                options: {
                    floor: 0,
                    ceil: 100,
                    step: 5,
                    disabled : sliderDisable,
                    maxLimit: maxSliderLength ? maxSliderLength : 100,
                    showSelectionBar: true,
                    getSelectionBarColor: function(value) {
                        return '#4fbd20';
                    }
                }
            };
            
            }]
        };
};
slider.$inject = ['planSmartSolution'];
module.exports = slider;