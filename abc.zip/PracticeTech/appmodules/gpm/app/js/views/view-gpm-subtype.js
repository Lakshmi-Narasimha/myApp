﻿define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'spinner','appcommon/commonutility','services/dataservice','appmodules/contactprofile/app/models/cpviewmodel', 'text!appmodules/gpm/app/templates/gpmsubtype.html',
], function ($, _, Backbone, Utils, Spinner, CommonUtils, Dataservice, CPViewModel, subtypeTemplate) {
    var subtypeView = Backbone.View.extend({
        el: "#gpm-form-update-field-container",
        id: 'gpm-form-update-field-container',
        events: {
        },
        template: _.template(subtypeTemplate),
        initialize: function (data) {
            this.data = data;

        },
        _subtypeOptions : [],
        /* Below code is for fetching subtype options - Need help on this one */
        
        renderTemplateWithDetails: function (data) {
            var _$subTypeSelectBox = $('#sub-contact-type'), _currentSubType = data.currentSubType, _subTypeOptions = data.subTypes;
            if (_currentSubType != "" && _currentSubType != undefined && _currentSubType != null) {
                if (_subTypeOptions.indexOf(_currentSubType) == -1) {
                    _subTypeOptions.unshift(_currentSubType);
                }
            }
            _subTypeOptions.sort(function (a, b) {
                a = a.toLowerCase();
                b = b.toLowerCase();
                if (a == b) return 0;
                if (a > b) return 1;
                return -1;
            });
            var _options = '<option value="">Choose one</option>';
           
            for (var i = 0; i < _subTypeOptions.length; i++) {

                _options += '<option value="' + _subTypeOptions[i] + '">' + _subTypeOptions[i] + '</option>';

                this._subtypeOptions[i] = {
                    code: _subTypeOptions[i],
                    name: _subTypeOptions[i],
                    serviceValue: _subTypeOptions[i]
                }
             }
           /* _$subTypeSelectBox.html(_options);
            if (_currentSubType != "" && _currentSubType != undefined && _currentSubType != null) {
                _$subTypeSelectBox.val(_currentSubType);
            }*/
        },
        render: function (updateMode) {
            try {
                var self = this;
                
                Spinner.show();
                Dataservice.getContactSubTypes(CommonUtils.readCookie('FMID'))
                .done(function(response){
                	
                	var _contactSubTypes = [];
      				if(response && response['contactSubTypes']){
            			var _subTypes = response['contactSubTypes'];
            			for(var _subType in _subTypes){
            				_contactSubTypes.push(_subTypes[_subType]);
            			}
            		  }
      				if(!self.model.get('currentItemSet')){
      					var CPData = CPViewModel.getInstance().getData();
      					self.data.fieldsInfo = {contactSubType: ((CPData.ebix && CPData.ebix.contactSubType) ? CPData.ebix.contactSubType : "")};
          				self.model.setCurrentValue(updateMode,{data:self.data});
      				}
      				var _dataSet = self.model.get('items');
      				var _subtype = _dataSet.find(function(row){return row.get("itemType") == "contactSubType"}).get("changedItemValueId");

      				$("#"+self.id).html(self.template()).promise().done(function () {
      					
                       self.renderTemplateWithDetails({currentSubType:_subtype==" "?"":_subtype, subTypes: _contactSubTypes });
                    });

      				self.loadSubTypeList(_subtype, self._subtypeOptions);


                	Spinner.hide();
                })
                .fail(function(error){
                	Spinner.hide();
                });
                
            }
            catch (error) {
                console.log(error);
            }
        },
        loadSubTypeList: function ( selStateCd, subtypelist ) {
            var _subtypeList = subtypelist;
            var _selectbox = "#sub-contact-type";          
            //Utils.loadSelectbox(_selectbox, _stateList, selStateCd, false);

            var _options = {
                selectBox: _selectbox,
                optionsList: _subtypeList,
                selectedVal: selStateCd,
                noEmptyOption: false,
                isOptional: true,
                noneOption: {
                    value: " ",
                    label: "None"
                }
            }
            Utils.loadSelectbox(_options);

        },
        validateAndNavigateFromStep1 :function(){
        	if(this.model.validate('gpm-update-form',true)){
        		this.model.setChangedValue();
        		if(this.model.getChangedItems().length>0){
        			$('.gpm-step.step1').addClass("finished").removeClass("active");
    	        	$('.gpm-step.step2').addClass("active");
    	        	Backbone.history.navigate('gpm/verification/'+this.model.get('updateMode'), true);
        		}else{
        			Utils.showNoChangesMessageToUser();
        		}
	        	
        	}
        },
    });
    return subtypeView;
});