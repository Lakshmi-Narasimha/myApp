/**
 * @ngdoc filter
 * @name fticNACheckFilter
 * @description
 *
 * - This common filter is used to display NA  instead of null/space/empty.
 *
 */

'use strict';

var fticNACheck = function() {
    return function(str) {
        if (!str.trim()) {
            str = 'NA';
        }
        return str;
    };
};

fticNACheck.$inject = [];
module.exports = fticNACheck;
