'use strict';

describe('Directive: Account View filter', function() {

  var compile, scope, event, $window, directiveEle, timeout, isoScope, cgAccDetModel, fticgAccDetLoadInitialService;

    var accData = {
                "panFolioAccounts": [{
                    "folioId": "18507834",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "0019906346498"
                    ]
                }, {
                    "folioId": "18507836",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "0019906346500"
                    ]
                }, {
                    "folioId": "12984431",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "1529900982051"
                    ]
                }, {
                    "folioId": "18587899",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "4069906573525"
                    ]
                }]
        };
        var data = {
            'accountNumber': '4069906573525',
            'key': 'CY'
        };
        var accFolioObj = {
            'folioPanAccNo': '4069906573525',
            '_isInitialLoad': true,
            'dayFlag': 'CY',
        }
    cgAccDetModel = {
        getFolioNumbersList: function() {
            return accData.panFolioAccounts
        }
    }
    fticgAccDetLoadInitialService = {
        getcgaccountdetails: function(scope, accFolioObj) {
            return accData.panFolioAccounts
        }
    }
    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('cgAccDetModel', cgAccDetModel);
            $provide.value('fticgAccDetLoadInitialService', fticgAccDetLoadInitialService);
        });
    });
    
    beforeEach(function() {

    angular.mock.inject(function($rootScope, $compile, _$timeout_, _$window_, _cgAccDetModel_, _fticgAccDetLoadInitialService_) {
        scope = $rootScope.$new();
        compile = $compile;
        cgAccDetModel = _cgAccDetModel_;
        fticgAccDetLoadInitialService = _fticgAccDetLoadInitialService_;
        timeout = _$timeout_;
        $window = _$window_;
        $window.ga = function() {};
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);
        });

        var element = angular.element('<ftic-capital-gain-ac-filter></ftic-capital-gain-ac-filter>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();
    });

  it('should create separate isolated scope', function() {
        expect(isoScope).toBeDefined();
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should triggewr cgFolio on cgFolioNumbersList call', function() {  
        spyOn(scope, '$broadcast').and.callThrough();
        scope.$broadcast('cgFolioNumberList', event);
        expect(scope.$broadcast).toHaveBeenCalledWith('cgFolioNumberList', event);
        expect(isoScope.selectedInvFolioOpt).toBeDefined();
        expect(isoScope.sectionInvOptsfolio).toBeDefined();
        spyOn(isoScope, '$emit');
        isoScope.$emit('cgfolio', isoScope.selectedInvFolioOpt);
        expect(isoScope.$emit).toHaveBeenCalledWith('cgfolio', isoScope.selectedInvFolioOpt);
        expect(isoScope.selectedFolioNumber).toBe('18587899');
        timeout.flush();
        expect(isoScope.selectedInvAccOpt).toBeDefined();
        expect(isoScope.selectedInvAccOpt.accontNumber).toBe('4069906573525');
        expect(isoScope.sectionInvOptsaccount).toBeDefined();
        expect(isoScope.sectionInvOptsaccount[0].accontNumber).toBe('4069906573525');
    });

    it('should emit cgapplyac event', function() {  
        spyOn(isoScope, '$emit');
        isoScope.$emit('cgapplyac', {});
        expect(isoScope.$emit).toHaveBeenCalledWith('cgapplyac', {});
    });

    it('should trigger cgac', function() {  
        spyOn(isoScope, '$broadcast');
        isoScope.$broadcast('cgac', data);
        expect(isoScope.$broadcast).toHaveBeenCalledWith('cgac', data);
    });

    it('should trigger selectedValue and set data values', function() {  
        spyOn(isoScope, '$broadcast');
        isoScope.$broadcast('selectedValue', data);
        expect(isoScope.$broadcast).toHaveBeenCalledWith('selectedValue', data);
        expect(data.key).not.toBe(null);
    });

    it('should trigger emitcgaApply', function() {  
        spyOn(isoScope, 'emitcgaApply').and.callThrough();
        isoScope.emitcgaApply();
        expect(isoScope.emitcgaApply).toHaveBeenCalled();
        expect(isoScope.cgAccountData).toBeFalsy();
    });
});