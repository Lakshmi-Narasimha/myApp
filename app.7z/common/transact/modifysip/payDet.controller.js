/**
 * @ngdoc property
 * @name PayDetController
 * @requires $scope
 * @requires TransactConstant
 * @description
 *
 * - modifysipTxnDetails
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function PayDetController($scope,bankDtlsModel,$filter,$state, TransactConstant, ftiModifySipInitialLoader, transactEventConstants,SipModifyDetailModel, transactModel,authenticationService) {    
    
    $scope.config.detailsHeading = TransactConstant.modifySip.MODIFY_SIP_HEADING;  
    $scope.config.txnFormPayDetails.title = "Payment Details";
    $scope.config.toTxnDetailsState = "transact.txnDetails.modifysip";
    $scope.$on(transactEventConstants.transact.Set_Modify_Sip_Details,function(event,data){
        var modifySipDetailModel = {};
        var datefilter = $filter('date');
        modifySipDetailModel.investorDetails = transactModel.getInvestorDetails();
        modifySipDetailModel.fundDetails = transactModel.getFundDetails(); 
        modifySipDetailModel.modifySipDetail = SipModifyDetailModel.getModifySipDetails();
        var sipParams = transactModel.getReqParams();
        
        transactModel.setTransactDetails(modifySipDetailModel);

        var transactionDetails = {
            "refTxn":modifySipDetailModel.fundDetails.transactionNum,
            "folioId":modifySipDetailModel.investorDetails.folioId || "",
            "startDate":datefilter(Date.parse(modifySipDetailModel.fundDetails.sipStartDate), 'dd/MM/yyyy') || "",
            "endDate":sipParams.fundOptions[0].endDate || "",
            "frequency":sipParams.fundOptions[0].frequency || "",
            "units":modifySipDetailModel.fundDetails.amount || "",
            "batchCode":TransactConstant.common.BATCH_CODE,
            "accountNo":modifySipDetailModel.fundDetails.accountNumber || "",
            "fundOption":modifySipDetailModel.fundDetails.fundOption || "",
            "effectiveDate": datefilter(Date.parse(modifySipDetailModel.modifySipDetail.strtDate),'dd/MM/yyyy'),
            "stepUpType": sipParams.fundOptions[0].stepUpType || "",
            "stepUpValue": sipParams.fundOptions[0].stepUpValue || "",
            "amount": modifySipDetailModel.modifySipDetail.newSipAmount ? modifySipDetailModel.modifySipDetail.newSipAmount.toString() : "0",
            "txnSource": modifySipDetailModel.modifySipDetail.txnSource,
            "source": TransactConstant.common.USER_TYPE_ADVISOR,
            "paymentMode": sipParams.paymentMode || "",
            "emFrequency": sipParams.emFrequency || "",
            "emAmount": sipParams.emAmount || "",
            "bankAccountNumber": sipParams.bankAccountNumber || "",
            "bankName": sipParams.bankName || "",
            "emFromDate": sipParams.emFromDate || "",
            "emToDate": sipParams.emToDate || "",
            "dayFlag" : modifySipDetailModel.modifySipDetail.dayFlag ? modifySipDetailModel.modifySipDetail.dayFlag.toString() : "", 
            "webRefNo" : transactModel.getWebRefNo(),
            "dividendOption" : modifySipDetailModel.fundDetails.dividendFlag || "",
            "perpetualFlag" : modifySipDetailModel.fundDetails.perpetualFlag || ""
        };
        if(sipParams.paymentMode === TransactConstant.common.EMANDATE_CODE){
            transactionDetails.untillCancel = sipParams.untillCancel || "" ;
            transactionDetails.debitType = sipParams.debitType || "";
        }
        var datefilter = $filter('date');
        var today = new Date();
        $scope.requestDateAndTime = datefilter(today, 'dd MMMM yyyy, hh:mm a');
        SipModifyDetailModel.postModifyTransactDetails(transactionDetails).then(postSuccess, handleFailure);
        
        function postSuccess(data) {
            
            var transConfirm = {
                "transactionRefNo" : data.Reference_Number,
                "transDateTime" : $scope.requestDateAndTime
            };
            transactModel.setTransactConfirm(transConfirm);
            if(authenticationService.isInvestorLoggedIn()){
                $state.go('invTransact.txnDetails',{stateType: $state.current.url.toString().substring(1, $state.current.url.toString().length)}); 
            }else{
                $state.go($scope.config.toTxnDetailsState);
            }            
        }
        function handleFailure(data) {
            
        }

    })    
  
}

PayDetController.$inject = ['$scope','bankDtlsModel','$filter','$state', 'TransactConstant', 'ftiModifySipInitialLoader', 'transactEventConstants','SipModifyDetailModel', 'transactModel','authenticationService'];
module.exports = PayDetController;