/**
 * @ngdoc directive
 * @name fticLoader
 * @requires $loader factory
 * @description
 *
 * - This loader directive enables loading image with transparent background while getting service response.
 **/
'use strict';

var loader = function($loader) {
    return {
        template: require('./loader.html'),
        restrict: 'E',
        replace: true,
        link: function(scope) {
            scope.loader = {};
            scope.isLoading = function() {
                return $loader.getVal() > 0;
            };
            scope.$watch(scope.isLoading, function(val) {
                if (val) {
                    scope.loader.showLoader = true;
                } else {
                    scope.loader.showLoader = false;
                    $loader.reset();
                }
            });
        }
        
    };
};

loader.$inject = ['$loader'];
module.exports = loader;
