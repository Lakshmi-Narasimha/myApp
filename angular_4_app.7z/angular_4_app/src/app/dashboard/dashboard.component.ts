import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { DashboardService } from "../services/dashboard.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  providers: [DashboardService]
})

export class DashboardComponent implements OnInit {
  dashboardData: any;
  selectedTabData: any;
  deploymentDetails: any;
  appTabs: any[];
  deploymentTileList: any[] = [{ type: 'UAT', description: 'UAT BUILD DEPLOYMENT' }, { type: 'SIT', description: 'SIT BUILD DEPLOYMENT' }, { type: 'PROD', description: 'PROD BUILD DEPLOYMENT' }];
  tileClass: String = 'col-xs-' + (12 / this.deploymentTileList.length);
  constructor(private DashboardService: DashboardService) {
  }

  onTabChange(selTab: any): void {
    selTab.active = true;
    this.selectedTabData = selTab;
    this.DashboardService.getLatestProjectDeploymentDeatils(selTab.key)
      .subscribe(
      resultArray => this.deploymentSuccessCallback(resultArray),
      error => console.log("Error :: " + error)
      );
  }

  getApplications(): void {
    this.DashboardService.getApplications()
      .subscribe(
      resultArray => this.appSuccessCallback(resultArray),
      error => console.log("Error :: " + error)
      );
  }
  appSuccessCallback(resultArray: any): void {
    this.appTabs = resultArray.projects.project;
    this.onTabChange(resultArray.projects.project[0]);
  }

  deploymentSuccessCallback(resultArray: any): void {
    this.deploymentDetails = resultArray.results.result[0];
    this.selectedTabData.buildInfo = this.deploymentDetails;
    this.deploymentTileList.forEach((tile: any, k: any) => {
      tile.buildInfo = this.selectedTabData.buildInfo;
    })
    this.DashboardService.getLatestBuildDeatils(this.deploymentDetails.key)
      .subscribe(
      result => this.buildSuccessCallback(result),
      error => console.log("Error :: " + error)
      );
  }
  buildSuccessCallback(result: any): void {
    this.appTabs.map(tab => {
      if (tab.key == result.planName) {
        tab.buildInfo = result;
      }
    });
  }

  ngOnInit(): void {
    this.getApplications();
  }

}
