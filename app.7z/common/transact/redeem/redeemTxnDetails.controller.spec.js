'use strict';
describe('Controller: RedeemTxnDetailsCtrl', function() {
	var $controller,$scope,RedeemTxnDetailsCtrl,transactModel,$state,authenticationService;

    var advisor = false;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_transactModel_,_$state_,_authenticationService_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();

        transactModel = _transactModel_;
        $state = _$state_;
        authenticationService = _authenticationService_;

        if(advisor){
            authenticationService.setUser({                                        
                "userId" : "test123"        
            }); 
        }

		loadController();			
	}));	

	function loadController(){
        RedeemTxnDetailsCtrl = $controller('RedeemTxnDetailsCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(RedeemTxnDetailsCtrl).toBeDefined();
    });

    it('should set the variables isInvestorType to be true if investor logged in',function(){    	
    	expect($scope.isInvestorType).toBe(true);    
        advisor = true;     
    });

    it('should set the variables isInvestorType to be false if advisor logged in',function(){       
        expect($scope.isInvestorType).toBe(undefined);           
    });

    it('should call the function redirect when clicked on Initiate Another Redemption button',function(){
    	spyOn($state,"go");
        spyOn(transactModel,"resetSetters");        
        $scope.redirect();
    	expect(transactModel.resetSetters).toHaveBeenCalled();
        expect($state.go).toHaveBeenCalledWith('transact.base.redeem', { key: null });
    });
});