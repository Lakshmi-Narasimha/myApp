/**
 * @ngdoc property
 * @name Destination Fund Directive
 * @requires newFundDetailsModel
 * @requires $uibModal
 * @requires selectFundModel
 * @description
 *
 * - Destination Fund directive represents the existing funds of investor along with a chance to create a new fund. 
 *
 **/
 'use strict';

 var kycMode = function(transactEventConstants, $filter, TransactConstant, paperlessModel, transactModel, configUrlModel, appConfig,$http,$window, selectInvestorModel) {
 	return {
 		template: require('./kycMode.html'),
 		restrict: 'E',
 		scope:{
 			parentForm:"=",
 			groupName:"=",
 			isGuest : '=?'
 		},
 		controller:['$scope', function($scope){  
 			var translateFilter = $filter('translate'), kycDetails, aadhaarNo = "";
 			$scope.groupName == (undefined || null)?$scope.type = "type":$scope.type = $scope.groupName.type;
            if ($scope.groupName) {
                if ($scope.groupName.type == "Guardian-1") {
                    $scope.type = "type";
                }
            }
            var pdfTemplate = '<span class="icon-fti_pdf"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span></span>';
 			$scope.modesOfEkyc = [{
                key : 'instant',
 				label : "AADHAAR through OTP",
 				value : $scope.type +"aadharNo",
 				nameLbl : $scope.type,
 				check: true,
                isBindHtml : false,
 				model:"",
 				checkedVal:'aadharNo'
 			},{
                key : 'physical',
 				label : "Physical KYC"+pdfTemplate,
 				value : $scope.type +"Physical",
 				nameLbl : $scope.type,
 				check: true,
                isBindHtml : true,
 				model:"",
 				checkedVal:'Physical'
 			}];

            $scope.tnc = {
                userConLabel : translateFilter(TransactConstant.transact.AADHAR_USER_CONSENT) 
            };



 			$scope.listenChange = function(val,chcekedval,index){
 				$scope.parentForm.kycMode = chcekedval;
 				transactModel.kycValue = val;
 				$scope.parentForm.$setPristine();
 				$scope.$emit(transactEventConstants.transact.MODE_OF_KYC_SELECTED, chcekedval);
 				if (chcekedval == 'aadharNo') {
 					$scope.instantKyc = true;
 				} 
 				else{
 					$scope.instantKyc = false;
 				}
 				angular.forEach($scope.modesOfEkyc, function(obj, key){
 					$scope.modesOfEkyc[key].model = val;
 				});
 			}
            
            if(selectInvestorModel.getSelectedInvestorDtls()) {
                var invDtls = selectInvestorModel.getSelectedInvestorDtls().holders;                
                if($scope.type === "Firstholder") {
                    aadhaarNo = invDtls[0].aadharNo;
                } else if($scope.type === "Secondholder") {
                    aadhaarNo = invDtls[1].aadharNo;
                } else if($scope.type === "Thirdholder") {
                    aadhaarNo = invDtls[2].aadharNo;
                }
            } else if(transactModel.getAadhaarNo()) {
                aadhaarNo = $scope.type === "Firstholder" ? transactModel.getAadhaarNo() : "";
            }
 			$scope.aadharNo = {
 				key : "Aadhar No",
 				text : "Aadhaar No",
 				name : $scope.type + "aadhar",
 				isRequired : true,
 				type: "number",
 				maxlength:12,
 				minlength:12,
 				value: parseInt(aadhaarNo) || "",
                disable: aadhaarNo || false
 			}
 			$scope.mobileNo = {
 				key : "Mobile",
 				text : "Mobile",
 				name : $scope.type + "mobile",
 				type: "number",
 				isRequired : true,
 				maxlength:10,
 				minlength:10,
 				value:""
 			}
 			$scope.email = {
 				key : "Email",
 				text : "Email",
 				name : $scope.type + "mail",
 				type : "email",
 				pattern : /^[A-Za-z0-9._]+[A-Za-z0-9._]+@[A-Za-z]+\.[A-Za-z.]{2,5}$/,
 				isRequired : true,
 				value:""
 			}		

 			
 			$scope.parentForm.kycVal=[];
            transactModel.setKYCMode(false);

			// to capture instant kyc aadhar OTP values
 			$scope.$on(transactEventConstants.transact.INSTANT_KYC, function(event){
 				transactModel.setKYCMode(true); // KYC Not-registered flow
 				$scope.parentForm.kycVal.push({
					'name':$scope.groupName==undefined || null?"":$scope.groupName.name,
					'pan':$scope.groupName==undefined || null?"":$scope.groupName.pan,
					'aadhar': $scope.aadharNo.value,
					'mobile':$scope.mobileNo.value,
					'email':$scope.email.value,
					'type':$scope.type,
					'Title':$scope.groupName==undefined || null?"":($scope.type=='Secondholder'?"Second Holder Details" :"Third holder Details" && $scope.type =='Firstholder'?"First Holder Details" :"Third holder Details") 
				});		
 			});

            //Back/Edit Functionality
            if(paperlessModel.insKyc.hasData){
                kycDetails = paperlessModel.insKyc.getKycDetails();
                if(kycDetails){
                	$scope.aadharNo.value = kycDetails.aadhar;
                	$scope.mobileNo.value = kycDetails.mobile;
                	$scope.email.value = kycDetails.email;
                	$scope.listenChange(transactModel.kycValue, kycDetails.kycMode);
                }
            }
 		}]
 	};

 };

 kycMode.$inject = ['transactEventConstants', '$filter', 'TransactConstant', 'paperlessModel', 'transactModel', 'configUrlModel', 'appConfig','$http','$window', 'selectInvestorModel'];
 module.exports = kycMode;