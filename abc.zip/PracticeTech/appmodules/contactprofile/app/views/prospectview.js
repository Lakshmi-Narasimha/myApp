define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
     'moment',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'text!appmodules/contactprofile/app/templates/prospectgeneral.html',
    'text!appmodules/contactprofile/app/templates/prospectphone.html',
    'text!appmodules/contactprofile/app/templates/prospectaddress.html',
    'text!appmodules/contactprofile/app/templates/prospectemail.html',
    'text!appmodules/contactprofile/app/templates/prospectrelations.html',
    'appcommon/globalcontext',
    'appcommon/analytics',
    'errorLog',
    'apipublic/navapi',
    'appcommon/constants',
    'appcommon/commonutility',
    'appcommon/nativeadaptor',
], function ($, _, Backbone, Spinner, Moment, cpCommon, DataService, prospectGeneralTemplate, prospectPhoneTemplate, prospectAddressTemplate,
        prospectEmailTemplate, prospectRelationsTemplate, Context, Analytics, ErrorLog, NavApi, Constants, CommonUtilis, NativeAdaptor) {

    var prospectView = Backbone.View.extend({
        el: $("#cp-content-container"),
        id: 'cp-content-container',
        events: {
        },
        initialize: function () {
            this.loggedInFmId = '';
            this.contactId = null;
            var that = this;
            $(document).off("click", ".cp-edit-client-details").on("click", ".cp-edit-client-details", function (e) {
                that.editclient(e);
                Analytics.analytics.recordAction('prospectProfileEditContactDetails:clicked');
            });
            $(document).off("click", ".cp-additional-info > h2").on("click", ".cp-additional-info > h2", function (e) {
                that.contactProfileAdditionalClick(e);
            });
            $(document).off("click", ".ncst-link").on("click", ".ncst-link", function (e) {
                that.launchNCST(e);
            });
            $(document).off("click", ".keyRelationsCP").on("click", ".keyRelationsCP", function (e) {
                that.gotoClientProfile(e);
            })
        },
        launchNCST: function (e) {
            CommonUtilis.writeCookie('nocontextlaunch', false);
            e.preventDefault();
            Backbone.history.navigate('ncst/', true);
        },
        contactProfileAdditionalClick: function (e) {
            $("#additionalInfoContainer").toggle();
            if ($(".cp-additional-info > h2").hasClass("closed")) {
                $(".cp-additional-info > h2").removeClass("closed");
                Analytics.analytics.recordAction('prospectProfileDetails:clicked');
            }
            else {
                $(".cp-additional-info > h2").addClass("closed");
            }
        },
        editclient: function (e) {
            if (this.contactId) {
                var url = "navigator/editcontact/" + this.contactId;
                Backbone.history.navigate(url, true);
                NativeAdaptor.notifyContactUpdated();
            } else {
                BootstrapDialog.alert("This user is not exist in Ebix");
            }

        },
        gotoClientProfile: function (e) {
        	Analytics.analytics.recordAction('Group Members: Contact Profile Key Relations:clicked');
            e.preventDefault();
            var that = this;
            var contactId = e.target.id;
            if (contactId.indexOf("Contact.") > -1) {
                ContactType = Constants.contactType.NonClient;

            } else {
                ContactType = Constants.contactType.Client;
            }

            if (contactId == "undefined" || contactId == "" || contactId === null) {
                BootstrapDialog.alert("Contact was saved to appointment as text only. No profile exists for this contact.", "", "Contact not found");
            } else {
                $('#viewEventModal').modal('hide');
                NavApi.changeContactAndLauchCP(contactId, ContactType);
            }


        },
        render: function (clId, smuId) {
            var that = this;
            that.contactId = clId;
            var tmpTemplate = '';
            window.scrollTo(0, 0);
            this.loggedInFmId = cpCommon.readCookie('FMID');
            Spinner.show();
            DataService.getNonClientEbixDetails(this.loggedInFmId, clId, smuId).then(gotoNonClientSuccess).fail(gotononClientError);
            function gotoNonClientSuccess(nonClient) {
                try {
                    if (nonClient[0] != undefined) {
                        if (nonClient[0].get('nextActivityOn') != null && nonClient[0].get('nextActivityOn').length > 0) {
                            nonClient[0].set({ 'nextActivityOn': moment(nonClient[0].get('nextActivityOn')).format('MM/DD/YYYY') }, { silent: true });
                        }
                        var generalTemplate = _.template(prospectGeneralTemplate);
                        $("#cp-content-container").html(generalTemplate(nonClient[0].toJSON()));
                        var tmpClientTlphones = nonClient[0].get('Phones');
                        if (tmpClientTlphones !== null && tmpClientTlphones !== undefined && tmpClientTlphones.length > 0) {
                            var phoneTemplate = _.template(prospectPhoneTemplate);
                            var preferredTemplate = '';
                            var nonBadPhoneNumberFound = false;
                            var phoneCount = 0;
                            tmpClientTlphones.forEach(
                                function (ClientTelephone) {
                                    if (ClientTelephone.attributes.BadPhoneNumber !== "1") {
                                        phoneCount++;
                                        nonBadPhoneNumberFound = true;
                                        if (ClientTelephone.attributes.Preferred === "1") {
                                            ClientTelephone.attributes.preferredPhone = true;
                                        }
                                        tmpTemplate = tmpTemplate + phoneTemplate(ClientTelephone.toJSON());
                                    }
                                });
                            if (nonBadPhoneNumberFound) {
                                $(".phone").show();
                            }
                            else {
                                $(".cp-main-info.cp-prospect").css({ "border-top": "0px" });

                            }
                            $(".cp-telephone").append(tmpTemplate);

                            $("a[href*='tel']").each(function () {
                                $(this).click(function () {
                                    Analytics.analytics.recordAction('prospectProfilePhone:clicked');
                                })
                            })

                            $(".phone.cp-prospect h2").text("Phone");
                        }
                        else {
                            $(".cp-main-info.cp-prospect").css({ "border-top": "0px" });
                        }
                        var tmpPostalAddresses = nonClient[0].get('Addresses');//Postal address
                        if (tmpPostalAddresses !== null && tmpPostalAddresses !== undefined && tmpPostalAddresses.length > 0) {
                            tmpTemplate = '';
                            var preferredTemplate = '';
                            var addrTemplate = _.template(prospectAddressTemplate);
                            var addrCount = 0;
                            tmpPostalAddresses.forEach(
                                function (clientPostalAddresses) {
                                    addrCount++;
                                    if (clientPostalAddresses.attributes.Preferred === "1") {
                                        clientPostalAddresses.attributes.preferredAddress = true;
                                        preferredTemplate = preferredTemplate + addrTemplate(clientPostalAddresses.toJSON());
                                    }
                                    else if (clientPostalAddresses.attributes.AddressTypeDesc !== null && clientPostalAddresses.attributes.AddressTypeDesc.match(/home/i)) {
                                        tmpTemplate = addrTemplate(clientPostalAddresses.toJSON()) + tmpTemplate;
                                    } else {
                                        tmpTemplate = tmpTemplate + addrTemplate(clientPostalAddresses.toJSON());
                                    }
                                });
                            $(".cp-address").append(preferredTemplate + tmpTemplate);
                            $(".address.cp-prospect h2").text("Address");
                            $(".cp-main-info.cp-prospect").css({ "border-top": "1px solid #ccc" });

                            $("a[href*='maps.google.com']").each(function () {
                                $(this).click(function () {
                                    Analytics.analytics.recordAction('prospectProfileAddress:clicked');
                                })
                            })
                        }
                        else {
                            $(".cp-main-info.cp-prospect").css({ "border-bottom": "0px" });

                        }
                        var tmpClientEmails = nonClient[0].get('WebAddresses');//Emails
                        if (tmpClientEmails !== null && tmpClientEmails !== undefined && tmpClientEmails.length > 0) {
                            tmpTemplate = '';
                            var preferredTemplate = '';
                            var emailTemplate = _.template(prospectEmailTemplate);
                            var emailCount = 0;
                            tmpClientEmails.forEach(
                                function (clientEmails) {
                                    if (clientEmails.attributes.WebAddressTypeDesc.toLowerCase() === "email") {
                                        emailCount++;
                                        if (clientEmails.attributes.Preferred === "1") {
                                            clientEmails.attributes.preferredEmail = true;
                                            preferredTemplate = preferredTemplate + emailTemplate(clientEmails.toJSON());
                                        } else {
                                            tmpTemplate = tmpTemplate + emailTemplate(clientEmails.toJSON());
                                        }
                                    }
                                });
                            if (emailCount !== 0) {
                                $(".cp-email").append(preferredTemplate + tmpTemplate);

                                $("a[href*='mailto']").each(function () {
                                    $(this).click(function () {
                                        Analytics.analytics.recordAction('prospectProfileEmail:clicked');
                                    })
                                })
                                $(".email.cp-prospect h2").text("Email");
                            } else {}
                        }
                        else {}

                        var firstSectionElementFound = false;

                        var tmpRelations = nonClient[0].get('Relations');
                        if (tmpRelations !== null && tmpRelations !== undefined && tmpRelations.length > 0) {
                            tmpTemplate = '';
                            var relationsTemplate = _.template(prospectRelationsTemplate);
                            var numRelations = 0;
                            tmpRelations.forEach(
                                function (prospectRelations) {
                                    if (prospectRelations.attributes.RelatedToFirstName !== null && /\S/.test(prospectRelations.attributes.RelatedToFirstName) &&
                                        prospectRelations.attributes.RelatedToLastName !== null && /\S/.test(prospectRelations.attributes.RelatedToLastName) &&
                                        prospectRelations.attributes.FullRelatedToName !== null && /\S/.test(prospectRelations.attributes.FullRelatedToName)) {
                                        tmpTemplate = tmpTemplate + relationsTemplate(prospectRelations.toJSON());
                                        numRelations++;
                                        firstSectionElementFound = true;
                                    }
                                }
                            );
                            $(".cp-relations").append(tmpTemplate);
                            if (numRelations < 1) {
                                $(".relations").hide();
                            }
                            else if (numRelations > 1) {
                                $(".cp-fid-fulldiv.relations").addClass("multiple-relations");
                            }
                        }
                        else {
                            $(".relations").hide();
                        }

                        var otherInfoFound = false;
                        var employmentInfoFound = false;

                        if (nonClient[0].get('contactSubType') !== null && nonClient[0].get('contactSubType') !== "") {
                            $(".subtype").show();
                            otherInfoFound = true;
                        } else {
                            $(".subtype").hide();
                        }

                        if (nonClient[0].get('primaryAgent') !== null && nonClient[0].get('primaryAgent') !== undefined && nonClient[0].get('primaryAgent') !== "") {
                            $(".primary-advisor").show();
                            otherInfoFound = true;
                        } else {
                            $(".primary-advisor").hide();
                        }

                        if (nonClient[0].get('referredByObj') !== null && nonClient[0].get('referredByObj') !== undefined && nonClient[0].get('referredByObj') !== "") {
                            $(".referred-by").show();
                            otherInfoFound = true;
                        } else {
                            $(".referred-by").hide();
                        }

                        if (nonClient[0].get('remarks') !== null && nonClient[0].get('remarks') !== "") {
                            $(".remarks a").removeAttr("href");
                            $(".remarks a").attr("onclick", "return false");
                            $(".remarks a").css("color", "rgb(51, 51, 51)");
                            $(".remarks").show();
                            otherInfoFound = true;
                        } else {
                            $(".remarks").hide();
                        }

                        if (nonClient[0].get('nextActivityOn') !== null && nonClient[0].get('nextActivityOn') !== "") {
                            $(".nextactivity").show();
                            otherInfoFound = true;
                        } else {
                            $(".nextactivity").hide();
                        }

                        if (nonClient[0].get('BusinessContact').get('orgNm') !== null) {
                            $(".cp-entity").removeClass('hidden');
                            $(".cp-person").addClass('hidden');

                            if (nonClient[0].get('BusinessContact').get('clTaxId') !== null && nonClient[0].get('BusinessContact').get('clTaxId') !== "") {
                                $(".entity-taxid").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".entity-taxid").hide();
                            }
                        } else {
                            $(".cp-entity").addClass('hidden');
                            $(".cp-person").removeClass('hidden');

                            if (nonClient[0].get('PersonContact').get('clTaxId') !== null && nonClient[0].get('PersonContact').get('clTaxId') !== "") {
                                $(".person-taxid").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".person-taxid").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clCitizenShip') !== null && nonClient[0].get('PersonContact').get('clCitizenShip') !== "" && nonClient[0].get('PersonContact').get('clCitizenShip').toUpperCase() !== "UNKNOWN") {
                                $(".citizenship").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".citizenship").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clDob') !== null && nonClient[0].get('PersonContact').get('clDob') !== "") {
                                $(".birthdate").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".birthdate").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clGender') !== null && nonClient[0].get('PersonContact').get('clGender') !== "" && nonClient[0].get('PersonContact').get('clGender').toUpperCase() !== "UNKNOWN") {
                                $(".gender").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".gender").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clMarital') !== null && nonClient[0].get('PersonContact').get('clMarital') !== "" && nonClient[0].get('PersonContact').get('clMarital').toUpperCase() !== "UNKNOWN") {
                                $(".marital").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".marital").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clNoOfChildren') !== null && nonClient[0].get('PersonContact').get('clNoOfChildren') !== "" && nonClient[0].get('PersonContact').get('clNoOfChildren').toUpperCase() !== "UNKNOWN") {
                                $(".dependents").show();
                                firstSectionElementFound = true;
                            } else {
                                $(".dependents").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clJobTitle') !== null && nonClient[0].get('PersonContact').get('clJobTitle') !== "") {
                                $(".jobtitle").show();
                                employmentInfoFound = true;
                            } else {
                                $(".jobtitle").hide();
                            }
                            if (nonClient[0].get('PersonContact').get('clOccupation') !== null && nonClient[0].get('PersonContact').get('clOccupation') !== "") {
                                $(".occupation").show();
                                employmentInfoFound = true;
                            } else {
                                $(".occupation").hide();
                            }

                            if (nonClient[0].get('employerName') !== null && nonClient[0].get('employerName') !== "") {
                                $(".employer").show();
                                employmentInfoFound = true;
                            } else {
                                $(".employer").hide();
                            }

                            if (nonClient[0].get('EmplyerInfo') !== undefined && nonClient[0].get('EmplyerInfo') !== null) {
                                if (nonClient[0].get('EmplyerInfo').get('line1') !== null) {
                                    $(".employer-address").show();
                                    employmentInfoFound;
                                } else {
                                    $(".employer-address").hide();
                                }
                            } else {
                                $(".employer-address").hide();
                            }

                            if (nonClient[0].get('DriverLicence') !== undefined && nonClient[0].get('DriverLicence') !== null) {
                                if (nonClient[0].get('DriverLicence').get('driverLicNo') !== null && nonClient[0].get('DriverLicence').get('driverLicNo') !== "") {
                                    $(".driverlicno").show();
                                    firstSectionElementFound = true;
                                } else {
                                    $(".driverlicno").hide();
                                }
                                if (nonClient[0].get('DriverLicence').get('driverLicState') !== null && nonClient[0].get('DriverLicence').get('driverLicState') !== "") {
                                    $(".driverlicstate").show();
                                    firstSectionElementFound = true;
                                } else {
                                    $(".driverlicstate").hide();
                                }
                            } else {
                                $(".driverlicno").hide();
                                $(".driverlicstate").hide();
                            }
                        }

                        if (firstSectionElementFound || otherInfoFound || employmentInfoFound) {
                            if (!firstSectionElementFound) {
                                $(".prospect-first-section").hide();
                            }
                            if (!otherInfoFound) {
                                $(".prospect-other").hide();
                            }
                            if (!employmentInfoFound) {
                                $(".prospect-employment").hide();
                                $(".prospect-other").css({ "border-bottom": "0px" });
                                if (!otherInfoFound) {
                                    $(".prospect-first-section").css({ "border-bottom": "0px" });
                                }
                            }
                        } else {
                            $(".cp-additional-info.cp-prospect").hide();
                        }
                    }
                    if ($("#additionalInfoContainer .prospect-first-section").height() == 0) {
                        if (otherInfoFound == false && employmentInfoFound == false) {
                            $("#additionalInfoContainer .prospect-first-section").html("<div class='col-xs-12 col-sm-12 col-md-12 text-center pt-data-sublabel-size21'>No contact details found.</div>");
                        }
                        else {
                            $("#additionalInfoContainer .prospect-first-section").remove();
                        }
                    }

                    $('.expand-collapse').addClass('closed'); $('#additionalInfoContainer').css('display', 'none');

                    if ($('#additionalInfoContainer>div>div:visible').length == 0) {}
                    if ($('.prospect-first-section>div:visible').length == 0) {}
                    $(".prospect-other .cp-fid-fulldiv:visible:last,.prospect-other .cp-fid-fulldiv:visible:last>h3, .prospect-other .cp-fid-fulldiv:visible:last>div>p").css("margin-bottom", 0);
                    $(".prospect-employment .cp-fid-fulldiv:visible:last,.prospect-employment .cp-fid-fulldiv:visible:last>h3, .prospect-employment .cp-fid-fulldiv:visible:last>div>p").css("margin-bottom", 0);
                    Spinner.hide();
                } catch (error) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.myError(error);
                }
            }
            function gotononClientError(Error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.myError(Error);
            }
        }
    });
    return prospectView;
});