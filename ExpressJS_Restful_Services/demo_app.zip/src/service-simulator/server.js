var express = require('express');
var cors = require('cors');
var app = express();
var bodyParser = require('body-parser');
app.use(cors());
app.use(bodyParser.json({limit: '1mb', extended: true})); // support json encoded bodies
app.use(bodyParser.urlencoded({limit: '1mb', extended: true})); // support encoded bodies
app.use(function (req, res, next) {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    res.header('Content-Type', 'application/json');
    console.log(req.url);
    if(req.url.indexOf('clientRefs') > -1){
        req.url = '/simservice/ClientLists'
    }
    if(req.url.indexOf('Client(') > -1){
        req.url = '/simservice/Client'
    }
    if(req.url.indexOf('Group') > -1){
        req.url = '/simservice/Group'
    }
    next();
});

var config = require('./config.js');
var signOnService = require('./services/getSignOnInformation.js');
var OBOService = require('./services/OBOServlet.js');
var contextSharingService = require('./services/contextSharing.js');
var createMGPLaunchTokenForDistributorService = require('./services/createMGPLaunchTokenForDistributor.js');
var clientList = require('./services/clientList.js');
var client = require('./services/client.js');
var group = require('./services/group.js');

app.get('/simservice/', function (req, res) {
   res.send('Seminar and Events app simulated services');
});


app.get("/simservice/ClientLists", function (req, res) {
	clientList.getClientList(req, function(result) {
		res.send(result);
	}, function(error) {
		res.status(404).send('Not found');
	});
});

app.get("/simservice/Client", function (req, res) {
	client.getClient(req, function(result) {
		res.send(result);
	}, function(error) {
		res.status(404).send('Not found');
	});
});

app.get("/simservice/Group", function (req, res) {
    group.getGroup(req, function(result) {
        res.send(result);
    }, function(error) {
        res.status(404).send('Not found');
    });
});

/* Sign on information service */

app.get('/simservice/getSignOnInformation', function (req, res) {
    var requestData = {
        fileName: config.loggedInUserType + "-" + config.loggedInUserId,     // specify the file name for reading data for different user types
        inclSglSgnOnGrpInd: req.query.inclSglSgnOnGrpInd
    };
	signOnService.getSignOnInformation(requestData, function(signOnInfo) {
		res.send(signOnInfo);
	}, function(error) {
		res.status(404).send('Not found');
	});
});

/* createMGPLaunchTokenForDistributor service (aka App Launcher) */

app.post('/simservice/createMGPLaunchTokenForDistributor', function (req, res) {

    createMGPLaunchTokenForDistributorService.getLaunchInformation(req, function(launchInformation) {
        res.send(launchInformation);
    }, function(error) {
        res.status(404).send('Not found');
    });
});

/* Context Sharing Service */

// url - http://localhost:9040/simservice/putAdvisorSessionContext
/* post payload - {"putAdvsSessCntxAcctIds" : null,
    "putAdvsSessCntxClIds" : [{"clId": "00100000000000070763554", "clCtx": "COLA.CL", "clRole": "PrimaryClient"}],
    "putAdvsSessCntxDstrIds" : [{"dstrId": "000030601", "dstrCtx": "DMU.DIST"}],
    "putAdvsSessCntxGrpIds" : null
}
post payload deux- {"putAdvsSessCntxAcctIds" : [{"acctId":"001000000000000000000123456","acctCtx":"COLA.ACCT"}],
    "putAdvsSessCntxClIds" : [{"clId": "00100000000000070763554", "clCtx": "COLA.CL", "clRole": "PrimaryClient"}],
    "putAdvsSessCntxDstrIds" : [{"dstrId": "000030601", "dstrCtx": "DMU.DIST"}],
    "putAdvsSessCntxGrpIds" : [{"grpId":"0010000000123","grpCtx":"COLA.GRP"}]
}
*/
app.post('/simservice/putAdvisorSessionContext', function (req, res){
    contextSharingService.putAdvsSessCntx(req.body, function(data) {
        res.send(data);
    }, function(error) {
        console.log('Error: ' + error);
        res.status(500).send('Some error');
    });
});

// url - http://localhost:9040/simservice/putAdvsSessCntxClIds
// post payload - [{"clId":"00100000000000070142686","clCtx":"COLA.CL","clRole":"PrimaryClient"}]
app.post('/simservice/putAdvsSessCntxClIds', function (req, res){
    contextSharingService.putAdvsSessCntx(req.body, function(data) {
        res.send(data);
    }, function(error) {
        console.log('Error: ' + error);
        res.status(500).send('Some error');
    });
});

// url - http://localhost:9040/simservice/putAdvsSessCntxDstrIds
// post payload - [{"dstrId":"12345","dstrCtx":"DMU.DIST"}]
app.post('/simservice/putAdvsSessCntxDstrIds', function (req, res){
    contextSharingService.putAdvsSessCntx(req.body, function(data) {
        res.send(data);
    }, function(error) {
        console.log('Error: ' + error);
        res.status(500).send('Some error');
    });
});

// url - http://localhost:9040/simservice/putAdvsSessCntxGrpIds
// post payload - [{"grpId":"0010000000123","grpCtx":"COLA.GRP"}]
app.post('/simservice/putAdvsSessCntxGrpIds', function (req, res){
    contextSharingService.putAdvsSessCntx(req.body, function(data) {
        res.send(data);
    }, function(error) {
        console.log('Error: ' + error);
        res.status(500).send('Some error');
    });
});

// url - http://localhost:9040/simservice/putAdvsSessCntxAcctIds
// post payload - [{"acctId":"001000000000000000000123456","acctCtx":"COLA.ACCT"}]
app.post('/simservice/putAdvsSessCntxAcctIds', function (req, res){
    contextSharingService.putAdvsSessCntx(req.body, function(data) {
        res.send(data);
    }, function(error) {
        console.log('Error: ' + error);
        res.status(500).send('Some error');
    });
});


// url - http://localhost:9040/simservice/getAdvisorSessionContext?cntxId=FEWOjuL6mQCk5own
app.get('/simservice/getAdvisorSessionContext', function (req, res) {
    contextSharingService.getAdvisorSessionContext(req, function(data) {
        res.send(data);
    }, function(error) {
        res.status(404).send('Not found');
    });
});

/* OBO Servlet service */

app.get('/simservice/OBOServlet', function (req, res) {        
    var requestData = {
        fileName: config.loggedInUserType + "-" + config.loggedInUserId      // specify the file name for reading data for different user types
    };
	OBOService.getOBOServletInfo(requestData, function(data) {
		res.send(data);
	}, function(error) {
		res.status(404).send('Not found');
	});
});

/* compensation team */

app.get('/simservice/CompTeam*', function (req, res) {
    getCompTeamMembersService.getCompTeamMembers(req.url, function(data) {
        res.send(data);
    }, function(error) {
        res.status(404).send('Not found');
    });
});

/* STARTUP SERVER */

var server = app.listen(9040, function () {

  var host = server.address().address;
  var port = server.address().port;

  console.log("Service Simulator listening at http://%s:%s", host, port);

});