'use strict';

var notification = function($state,fticRecommAndNotifiModel,constants,$filter,$window,eventConstants, $cookies) {
    return {
            template: require('./notification.html'),
            restrict: 'E',
            replace: true,
            scope: {                
                
            },
            controller:['$scope', function($scope){   
                //$scope.notificationToDisplay = [];
                    $scope.$on(eventConstants.RECOMM_AND_NOTIFI_DATA,function(event,data){
                        $scope.notificationsCount = 0;
                        $scope.notificationsWRSN = [];
                        $scope.recommandNotifiData = fticRecommAndNotifiModel.getRecommAndNotifiReport();

                    $scope.notifications = $scope.recommandNotifiData.notifications;
                        /*angular.forEach($scope.notifications,function(obj){
                    if(obj.readStatus == "N"){
                        $scope.notificationToDisplay.push(obj);
                    }

                     });*/
                    if($scope.notifications !='' && $scope.notifications != null){
                        for(var i=0;i<$scope.notifications.length;i++){
                            if($scope.notifications[i].readStatus === 'N'){
                                $scope.notificationsCount = $scope.notificationsCount+1;
                                $scope.notificationsWRSN.push($scope.notifications[i]);
                            }
                        }  
                    }
                    
                        //$scope.notificationsCount = $scope.notifications.length;
                        
                    });
                    var redirectAdvisorApp = $cookies.get('userRedirectURI');
                    $scope.allNotifications = function(){
                        // $state.go('notificationsreport');
                        $scope.$emit(eventConstants.NAVIGATE_CHECK, redirectAdvisorApp+'#/notificationsreport');
                        //$window.location.href=redirectAdvisorApp+"/#/notificationsreport";
                        $scope.closePop=false;
                    };
                    $scope.notificationClick = function(index){
                         //$state.go('notificationsreport');
                        //$window.location.href=redirectAdvisorApp+"/#/notificationsreport";
                        $scope.$emit(eventConstants.NAVIGATE_CHECK, redirectAdvisorApp+'#/notificationsreport');
                        $scope.closePop=false;
                        $scope.$emit($filter('translate')(constants.NOTIFI_CLICKED_TEXT),$scope.notificationsWRSN[index]);
                    };
              
            }]
        };
};

notification.$inject = ['$state','fticRecommAndNotifiModel','constants','$filter','$window','eventConstants', '$cookies'];
module.exports = notification;