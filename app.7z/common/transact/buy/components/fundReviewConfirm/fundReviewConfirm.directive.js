



    /**
 * @ngdoc property
 * @name Switch Form Directive
 * @requires $state
 * @requires $timeout
 * @requires 
 * @description
 *
 * - Switch form directive will represent the form details of switch module in transact controller.
 *
 **/
 'use strict';

 var fundReviewConfirm = function(fundDetails,eventConstants,$state, transactEventConstants, transactModel) {
 	return {
 		template: require('./fundReviewConfirm.html'),
 		restrict: 'E',
        scope: {
            editRedirectState : "="
        },
 		controller:['$scope', function($scope){  	
            
            //$scope.tileDetails = fundDetails.getFundDetails();
 			$scope.tileDetails = fundDetails.getFundDetails() || transactModel.getFundDetails();
            $scope.infoObj=[];
            angular.forEach($scope.tileDetails, function(obj, key){
                $scope.infoObj.push([
                    {
                        text: "Fund Name",
                        value: $scope.tileDetails[key].fundName
                    },
                    {
                        text: "Investment Amount",
                        value: '<span class="icon-fti_rupee"></span>'+$scope.tileDetails[key].amount
                    },
                    {
                        text: "Dividend",
                        value: $scope.tileDetails[key].dividend
                    }
                ]);
            })
            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){    
                transactModel.isBuyFolioEditState = true;                                             
                $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'Fund'});    
                $scope.$emit(transactEventConstants.transact.guest.PAPERLESS_REVIEW_EDIT_TRIGGERED, {state:$scope.editRedirectState});
                $scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: 'Fund'});     
                $event.stopPropagation();                
            });

            $scope.presentState = false;
            if($state.current.name == "transact.txnDetails.buy") {
                $scope.presentState = true;
            }
            $scope.buyFundInfo = false;
            if($scope.tileDetails.length === 1) {
                $scope.buyFundInfo = true;
            }
 		}]
 	};

 };

 fundReviewConfirm.$inject = ['fundDetails','eventConstants','$state', 'transactEventConstants', 'transactModel'];
 module.exports = fundReviewConfirm;