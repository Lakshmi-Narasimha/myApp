define(['backbone', 'config', 'spinner', 'appmodules/eSig/app/js/utils',
        'appmodules/eSig/app/js/audit',
		'text!appmodules/eSig/app/templates/signSubmitted.html' ], function(
		Backbone, Config, Spinner, Utils, AuditLog, TempView) {
	var SignSubmittedView = Backbone.View.extend({
		tagName : 'div',
		template : _.template(TempView),
		initialize : function() {
			/* DCN zero padding constant */
			this.DCN_ZERO_PAD_LENGTH = 10;
		    this.$main = $(this.el);
		    AuditLog.setAuditLogParams({
		        "pageName": "Submit",
		        "signerId":null,
		        "signerName":null
		    });
		},
		events : {
			'click #back-todoc-list-contnr' : 'handlebacktoDocList'
		},
		render : function(docId) {
			var _self = this,_dcnText;
			this.$el.html(_self.template);
			$("#practicetech-subapp").html(_self.$el);
			_dcnText = 'ESG'+_self.zeropad(docId,_self.DCN_ZERO_PAD_LENGTH);
			$('#submit-DCN').find('span').text(_dcnText);
			$('#esig-app-container').removeAttr('style');
			Spinner.hide(); // temp fix
			Utils.setBodySectionHt(true);
		},
		afterRender : function() {
			var _self = this,_dcnText;
			_dcnText = 'ESG'+_self.zeropad(docId,_self.DCN_ZERO_PAD_LENGTH);
			$('#submit-DCN').find('span').text(_dcnText);
		},
		handlebacktoDocList : function() {
		    location.hash = '#navigator/draftspage';
		    AuditLog.setAuditLogParams({
		        "eventId": 105
		    });
		    AuditLog.sendAudit();
		},
		zeropad: function(num, numLength){
			var n = Math.abs(num);
		    var zeros = Math.max(0, numLength - Math.floor(n).toString().length );
		    var zeroString = Math.pow(10,zeros).toString().substr(1);
		    if( num < 0 ) {
		        zeroString = '-' + zeroString;
		    }

		    return zeroString+n;
		}
	});
	return SignSubmittedView;
});