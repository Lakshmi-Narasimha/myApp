﻿define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'appcommon/analytics',
    'appmodules/contactprofile/app/models/cpviewmodel',
    'text!appmodules/contactprofile/app/templates/contactpreferences.html',
    'text!appmodules/contactprofile/app/templates/contactpreferenceonlineaccess.html',
    'text!appmodules/contactprofile/app/templates/contactpreferencealert.html',
    'text!appmodules/contactprofile/app/templates/contactpreferncecommn.html',
	'errorLog','appmodules/contactprofile/app/models/preferenceviewmodel',
	'appcommon/nativeadaptor',
     'appmodules/gpm/app/js/utils',
     'appcommon/globalcontext',
     'appcommon/commonutility',
], function ($, _, Backbone, Spinner, cpCommon, Dataservice, Analytics, CPViewModel, preferencesTemplate, preferenceOnlineAccessTemplate, preferencesAlertsTemplate, preferencesCommnTemplate, ErrorLog, PreferenceViewModel, NativeAdaptor, Utils, GlobalContext, CommonUtils) {
	var $scroller, globalClid, storeAmeriReg = '', storePriEmail = '', storePriEmailUnReg = false, shareHolderDocPref = '', acntStatmntsDocPref = '', financialDocPref = '', addDocTypePref = '', totalViewEnrolled = '', _grpIdVal = undefined;
    var preferencesView = Backbone.View.extend({
        template: _.template(preferencesTemplate),
        alerttemplate: _.template(preferencesAlertsTemplate),
        commntemplate: _.template(preferencesCommnTemplate),
        initialize: function () {
            var that = this;
            PreferenceViewModel.clearData();
            $(document).off("click", ".cp-pref-container .exp-col-class").on("click", ".cp-pref-container .exp-col-class", function (e) {
                that.expandCollpaseSection(e);
            });
            $(document).off("click", "#cp-alerts").on("click", "#cp-alerts", function (e) {
                that.expandCollpaseAlertSection(e);
            });
            $(document).off("click", "#cp-commnpref").on("click", "#cp-commnpref", function (e) {
                that.expandCollpaseCommnPrfr(e);
            });
            $(document).off("click", "#alertNoEmailLink").on("click", "#alertNoEmailLink", function (e) {
                that.showAlertNoEmailLink(e);
            });
            $(document).off("click", "#alertNoEmailLink2").on("click", "#alertNoEmailLink2", function (e) {
                that.showAlertNoEmailLink(e);
        });
            $(document).off("click", "#cpUpdateLink").on("click", "#cpUpdateLink", function (e) {
                that.showcpUpdateLink(e);
            });
            $(document).off("click", "#cpUpdateLink2").on("click", "#cpUpdateLink2", function (e) {
                that.showcpUpdateLink(e);
            });
            $(document).off("click", ".cp-launchgpm").on("click", ".cp-launchgpm", function (e) {
                that.routeToGPM(e);
            });
            $(document).off("click", "#total-view-email-invite").on("click", "#total-view-email-invite", function (e) {
                that.routeToGPM(e);
            });
            $(document).off("click", "#SecureSiteRegLink").on("click", "#SecureSiteRegLink", function (e) {
                that.routeToGPM(e);
            }); 
            $(document).off("click", "#set-prefrences-email-invite").on("click", "#set-prefrences-email-invite", function (e) {
                that.routeToGPM(e);
            });
            $(document).off('click', '.js-savestate').on('click', '.js-savestate', function (e) {
                that.loadOrSave(e);
            });
            $(document).off("keydown").on("keydown", function (e) {
                that.analyticsPrefPrint(e);
            });
            window.onafterprint = function () {
            	if (window.location.hash === '#contactprofile/preferences') {
            		Analytics.analytics.recordAction('Print:PreferencesTab');
            	}
            };
        },
        analyticsPrefPrint: function (e) {
        	if (window.location.hash === '#contactprofile/preferences' && (window.chrome)) {
                if (e.ctrlKey && e.keyCode == 80) {
                    Analytics.analytics.recordAction('Print:PreferencesTab');
                }
            }
        },
        showAlertNoEmailLink: function (e) {
            BootstrapDialog.alert("<div class='box-with pt-error-icon'> Your request can not be completed because the client is missing a primary email address. To add an email address, click the Edit button under Email addresses and complete the workflow.</div>");
        },
        showcpUpdateLink: function (e) {
            BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be completed because the client is not registered on the Secure Site on ameriprise.com</div>", function () {
            }, "Information");
        },
        expandCollpaseSection: function (e, fastLoad) {

    	    var targetBtn = $(e.target).attr('id') || $(e.currentTarget).attr('id');
    	    var targetContainer = targetBtn + '-desc';
    	    $('#'+targetBtn).toggleClass('collapse-icon');
    	    (typeof e.originalEvent === 'undefined') ? $("#" + targetContainer).slideToggle(0) : $("#" + targetContainer).slideToggle("slow");
    	},
    	expandCollpaseAlertSection: function (e) {
           var that = this;
        

           if ($('#cp-alerts').hasClass('collapse-icon') == true) {
               (typeof e.originalEvent === 'undefined') ? $('#cp-alerts-desc').slideToggle(0) : $('#cp-alerts-desc').slideToggle("slow");
               $('#cp-alerts').removeClass('collapse-icon');
               $('#cp-alerts').addClass('pref-alert-closed');
               $('#cp-alerts-desc').addClass('border-none');

               Analytics.analytics.recordAction('contactProfileAlertDrawerClosed' );
               
               Spinner.hide();
           } else {
               Spinner.show();
               Analytics.analytics.recordAction('contactProfileAlertDrawerOpened');

               (typeof e.originalEvent === 'undefined') ? $('#cp-alerts-desc').slideToggle(0) : $('#cp-alerts-desc').slideToggle("slow");
               $('#cp-alerts').addClass('collapse-icon');
               $('#cp-alerts').removeClass('pref-alert-closed');
               $('#cp-alerts-desc').removeClass('border-none');
               $('#cp-alerts-desc').remove(); 
               
               Dataservice.getAlertContactProfile(globalClid).then(function (result) {
            	   if(result && result.d){
            		   var _prefModel = {
		            		"clId":result.d.clId,
		            		"clPrfrs":result.d.clPrfrs,
		            		"dlvAddrs":result.d.dlvAddrs
            		   }
            		   
            	   }
            	   if (_prefModel && _prefModel.clPrfrs && _prefModel.clPrfrs.results.length == 0 &&  _prefModel.dlvAddrs && _prefModel.dlvAddrs.results.length == 0) {
            	       $('#client-prfrnc-alerts').append('<div id="cp-alerts-desc"><button id="pref-edit-alert" type="button" class="btn btn-primary pt-med-btn pt-h6 margin-bottom-15 cp-rider cp-launchgpm">Edit</button><div class="additionalInfoContainer successalertDiv"><div class="cp-info"><p class="pt-para-medium padding-margin-zero" >No email address on record for this client</p></div></div></div>');
                   }else{
                	   that.setPreferenceModel("alertsAndCommunication",_prefModel);
                	   var tmpAlertField = result;
                       $('#client-prfrnc-alerts').append(that.alerttemplate({
                           alertField: tmpAlertField,
                           alertRegister: storeAmeriReg
                       }));
                       
                   }
                   Spinner.hide();
               }).fail(function (err) {
                    if (err.status==0){
                        $('#client-prfrnc-alerts').append('<div id="cp-alerts-desc"><div id="alertNoEmailLink" class="cp-updateLink cp-entrypoint cp-rider font-booksize"></div><div class="additionalInfoContainer successalertDiv"><div class="cp-info text-center pt-data-sublabel-size21">The system is currently unavailable. Please try again later.</div></div></div>');                      
                    }
                    if (err.status = 500 && err.responseJSON && err.responseJSON && err.responseJSON.error && err.responseJSON.error.innererror == "Could not retrieve Primary Email") {
                       $('#client-prfrnc-alerts').append('<div id="cp-alerts-desc"><div id="alertNoEmailLink" class="cp-updateLink cp-entrypoint cp-rider font-booksize">Update</div><div class="additionalInfoContainer successalertDiv"><div class="cp-info"><p class="pt-para-medium padding-margin-zero" >No email address on record for this client</p></div></div></div>');
                    }
                   Spinner.hide();
               });
           }
    	},
    	setPreferenceModel:function(property,value){
    		PreferenceViewModel.setData(property,value);
    	},
    	expandCollpaseCommnPrfr: function (e) {
    	    var that = this;
    	   

    	    if ($('#cp-commnpref').hasClass('collapse-icon') == true) {
    	        (typeof e.originalEvent === 'undefined') ? $('#cp-commnPrfr-desc').slideToggle(0) : $('#cp-commnPrfr-desc').slideToggle("slow");
    	        $('#cp-commnpref').removeClass('collapse-icon');
    	        $('#cp-commnpref').addClass('pref-alert-closed');
    	        $('#cp-commnPrfr-desc').addClass('border-none');
    	
    	        Analytics.analytics.recordAction('contactProfileCommunicationPrefDrawerClosed');
    	    
    	    } else {
    	        Spinner.show();
    	        
    	        Analytics.analytics.recordAction('contactProfileCommunicationPrefDrawerOpened');

    	        (typeof e.originalEvent === 'undefined') ? $('#cp-commnPrfr-desc').slideToggle(0) : $('#cp-commnPrfr-desc').slideToggle("slow");
    	        $('#cp-commnpref').addClass('collapse-icon');
    	        $('#cp-commnpref').removeClass('pref-alert-closed');
    	        $('#cp-commnPrfr-desc').removeClass('border-none');
    	
    	        $('#cp-commnPrfr-desc').remove();
    	        Dataservice.getAlertContactProfile(globalClid).then(function (result) {
    	        	 if(result && result.d){
              		   var _prefModel = {
		            		"clId":result.d.clId,
		            		"clPrfrs":result.d.clPrfrs,
		            		"dlvAddrs":result.d.dlvAddrs
            		   }
              		   
              	   }
    	        	 if (_prefModel && _prefModel.clPrfrs && _prefModel.clPrfrs.results.length == 0 &&  _prefModel.dlvAddrs && _prefModel.dlvAddrs.results.length == 0) {
    	        		 $('#client-prfrnc-commn').append('<div id="cp-commnPrfr-desc"><button id="pref-edit-communication-preference" type="button" class="btn btn-primary pt-med-btn pt-h6 margin-bottom-15 cp-rider cp-launchgpm">Edit</button><div class="additionalInfoContainer successalertDiv"><div class="cp-info"><p class="pt-para-medium padding-margin-zero" >No email address on record for this client</p> </div></div></div>');
                     }else{
                    	 that.setPreferenceModel("communication",_prefModel);
	    	            var tmpCommnField = result;
	    	            $('#client-prfrnc-commn').append(that.commntemplate({
                    	     commnField: tmpCommnField,
                    	     alertRegister: storeAmeriReg

	    	            }));
                     }
    	            Spinner.hide();
    	        }).fail(function (err) {
                    if (err.status==0){
                        $('#client-prfrnc-commn').append('<div class="additionalInfoContainer successalertDiv"  id="cp-commnPrfr-desc"><div class="cp-info text-center pt-data-sublabel-size21">The system is currently unavailable. Please try again later.</div></div>');
                    }
    	            if (err.status = 500 && err.responseJSON && err.responseJSON && err.responseJSON.error && err.responseJSON.error.innererror == "Could not retrieve Primary Email") {
    	                $('#client-prfrnc-commn').append('<div class="additionalInfoContainer successalertDiv"  id="cp-commnPrfr-desc"><div class="cp-info"><p class="pt-para-medium padding-margin-zero" >No email address on record for this client</p> </div></div>');
    	            }
    	            Spinner.hide();
    	        });
    	    }
    	},
    	validateClientAndShowMsg: function (isGPPMEditCustomMsg) {
    		var CPData = CPViewModel.getInstance().getData();
    		
    		
            if (!CPData.ebix) {
            	if(isGPPMEditCustomMsg){
            	    BootstrapDialog.alert("<div class='box-with pt-error-icon'>Some updates cannot be made because the client cannot be found in Contact Manager.  The client might not have an active account or might be hidden.</div>");
            	}else{
            	    BootstrapDialog.alert("<div class='box-with pt-error-icon'>This client cannot be found in Contact Manager. The client might not have an active account or might be hidden. <a href='https://www.askameriprise.com/app/answers/detail/a_id/26890/kw/client%20not%20in%20contact%20manager' target='_blank'>Tell me more.</a></div>", "", "Client not found");
            	}
                return false;
            }
            return true;
        },
       render: function (clId, smuId) {
            var that = this;
            var _serviceCallsStack = [], _activeClients = [], _grpId = GlobalContext.getInstance().getGlobalContext().Context.GroupId,_isSoleGrpMember = false , grpIdVal=null;
            function clientServicePrefSuccess(preferences) {
                globalClid = clId;              
                var _dataClientEmails;
                var _dataClientServPref;
                try {
                    var _results = preferences['results'][0];
                    if (_results && _results.attributes) {
                        _dataClientEmails = _results.attributes.clientEmails;
                        _dataClientServPref = _results.attributes.clientServPreferences;
                    }                   
                    var tmpClintDocDelivery = {
                        prfrcServEmailDeliveredTo: null,
                        prefrcSerEmailShow: false,
                        prfrcShareHolderDocs: null,
                        prfrcAccountStatements: null,
                        prfrcFinancialConfirms: null,
                        prfrcAddsnlDocumentType: null
                    };
                    var tmpClientEmailAddresses = {
                        prfrcPrimaryEmail: null,
                        prfrcPrimaryLastUpdated: null,
                        prfrcSecondaryEmail: null,
                        prfrcSecondayLastUpdated: null,
                        prfrcPrimaryUndeliver: null,
                        prfrcSecondaryUndeliver: null
                    };
                    if (_dataClientServPref && _dataClientServPref.length > 0) {

                        $.each(_dataClientServPref, function (key, row) {
                            //Update Share holder document status
                            if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Shareholder Communication") {
                                tmpClintDocDelivery.prfrcShareHolderDocs = "Online";
                                tmpClintDocDelivery.prefrcSerEmailShow = true;
                            } else if (row.typCd === "Paper Suppression" && row.subTypCd === "Shareholder Communication") {
                                tmpClintDocDelivery.prfrcShareHolderDocs = "U.S. mail";
                            }
                            //Update Account statements status
                            if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Consolidated Statement") {
                                tmpClintDocDelivery.prfrcAccountStatements = "Online";
                                tmpClintDocDelivery.prefrcSerEmailShow = true;
                            } else if (row.typCd === "Paper Suppression" && row.subTypCd === "Consolidated Statement") {
                                tmpClintDocDelivery.prfrcAccountStatements = "U.S. mail";
                            }
                            //Update Financial Confirmations status
                            if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Financial Confirmations") {
                                tmpClintDocDelivery.prfrcFinancialConfirms = "Online";
                                tmpClintDocDelivery.prefrcSerEmailShow = true;
                            } else if (row.typCd === "Paper Suppression" && row.subTypCd === "Financial Confirmations") {
                                tmpClintDocDelivery.prfrcFinancialConfirms = "U.S. mail";
                            }
                            //Update Additional document types status
                            if (row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Other Documents") {
                                tmpClintDocDelivery.prfrcAddsnlDocumentType = "Online";
                                tmpClintDocDelivery.prefrcSerEmailShow = true;
                            } else if (row.typCd === "Paper Suppression" && row.subTypCd === "Other Documents") {
                                tmpClintDocDelivery.prfrcAddsnlDocumentType = "U.S. mail";
                            }
                        });
                        if (tmpClintDocDelivery.prefrcSerEmailShow) {
                            tmpClintDocDelivery.prfrcServEmailDeliveredTo = "Primary email";
                        }

                    }
                    that.setPreferenceModel("documentDelivery", tmpClintDocDelivery);
                    storePriEmail = "";
                    storePriEmailUnReg = false;
                    if (_dataClientEmails && _dataClientEmails.length > 0) {
                        var _clEmails = [];
                        $.each(_dataClientEmails, function (key, row) {
                            //Update Primary email
                            if (row.attributes.emlUseCd === "Primary") {
                                tmpClientEmailAddresses.prfrcPrimaryEmail = row.attributes.emlAddr;
                                var lstUpdated = row.attributes.endTs;
                                var _primaryEmail = {
                                    emlUseCd: "Primary",
                                    emailId: tmpClientEmailAddresses.prfrcPrimaryEmail,
                                    undeliverable: false,
                                }
                                if (row.attributes.emlVldStatCd !== 'Valid' || row.attributes.emlFuncStatCd !== 'Functional') {
                                    tmpClientEmailAddresses.prfrcPrimaryUndeliver = 'Undeliverable';
                                    _primaryEmail.undeliverable = true;
                                    storePriEmailUnReg = true;
                                }
                                _clEmails.push(_primaryEmail);
                            }
                            //Update Secondary email
                            if (row.attributes.emlUseCd === "Secondary") {
                                tmpClientEmailAddresses.prfrcSecondaryEmail = row.attributes.emlAddr;
                                var lstUpdated = row.attributes.endTs;
                                var _secondaryEmail = {
                                    emlUseCd: "Secondary",
                                    emailId: tmpClientEmailAddresses.prfrcSecondaryEmail,
                                    undeliverable: false,
                                }
                                //Undeliverable functionality
                                if (row.attributes.emlVldStatCd !== 'Valid' || row.attributes.emlFuncStatCd !== 'Functional') {
                                    tmpClientEmailAddresses.prfrcSecondaryUndeliver = 'Undeliverable';
                                    _secondaryEmail.undeliverable = true;
                                }
                                _clEmails.push(_secondaryEmail);
                            }
                        });
                        PreferenceViewModel.setData("emails", _clEmails);
                        storePriEmail = tmpClientEmailAddresses.prfrcPrimaryEmail;
                    };

                    $('#cp-content-container').html(that.template({
                        emailAddresses: tmpClientEmailAddresses,
                        onlineAccess: {},
                        documentDelivery: tmpClintDocDelivery,
                        isSoleGrpMember: _isSoleGrpMember,
                        grpIdVal: _grpIdVal

                    }));

                    $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                    $(".hdr-tab-buttons-wrap .bt-pref").addClass("hdr-tab-active");


                    //Fetching the Online access preferences
                    if (_results && _results.attributes) {
                        if (_results.attributes.capabilityRegistrations === null) {
                            Spinner.show();

                            Dataservice.getClientOnlineAccessPreference(clId).then(function (result) {
                                if (result && result != undefined) {
                                    _results.set({ 'capabilityRegistrations': result[0]['results'] }, { silent: true });
                                    renderOnlineAccessPreference(result[0]['results']);
                                }
                                Spinner.hide();
                            }).fail(function (err) {
                                Spinner.hide();
                                ErrorLog.ErrorUtils.myError(xhr, true);
                            });
                        } else { renderOnlineAccessPreference(_results.attributes.capabilityRegistrations); }
                    }
                    else {
                        Spinner.hide();
                    }
                }catch(err){
            		ErrorLog.ErrorUtils.myError(err);
            	}

                //set the delievry preferences
            	shareHolderDocPref = tmpClintDocDelivery.prfrcShareHolderDocs;
            	acntStatmntsDocPref = tmpClintDocDelivery.prfrcAccountStatements;
            	financialDocPref = tmpClintDocDelivery.prfrcFinancialConfirms;
            	addDocTypePref = tmpClintDocDelivery.prfrcAddsnlDocumentType;
            };

            function renderOnlineAccessPreference(collection) {
                storeAmeriReg = "";
                try {
                    var _tpl = _.template(preferenceOnlineAccessTemplate);
                    var tmpClientOnlineAccess = {
                        prefernceSiteRegistered: null,
                        prefernceDateRegistered: null,
                        totalViewEnrolled: null
                    };
                    if (collection && collection.length > 0) {
                        $.each(collection, function (key, row) {
                            if (row.status === "Active" && row.rsrcCd === "MYFA") {
                                tmpClientOnlineAccess.prefernceSiteRegistered = "Yes";
                                storeAmeriReg = "Yes";
                                var dateReistered = row.sttTs;
                                tmpClientOnlineAccess.prefernceDateRegistered = dateReistered.getDateFromMS();
                            }
                            if (row.status === "Active" && row.rsrcCd === "CE") {
                                tmpClientOnlineAccess.totalViewEnrolled = "Yes";
                            }
                        });
                    }
                    that.setPreferenceModel("onlineAccess", tmpClientOnlineAccess);
                    var _collection = { onlineAccess: tmpClientOnlineAccess };
                    //Total-view : 
                    totalViewEnrolled = tmpClientOnlineAccess.totalViewEnrolled;
                    //Render the template content to the main template
                    $('#client-prfrnc-online-access').html(_tpl(_collection));

                    //Fetching the Message Center preferences
                    Dataservice.getClientSecureMsgCenterPreference(clId, [400, 401, 404, 500]).then(function (result) {
                        if (result && result[0]) {
                            var smcRegCd = result[0].SMCRegCd;
                            var smcEmail = result[0].emails[0];
                            if (smcRegCd == '01') {
                                $("#smcRegCd").html("<p class='pt-data-value-medium'>Yes</p>");
                                $("#smcEmail").html('<p class="pt-data-value-medium"><a href="mailto:' + result[0].emails[0].emlAddr + '">' + result[0].emails[0].emlAddr + '</a></p>');
                            } else {
                                $("#smcRegCd").html("<p class='pt-data-value-medium'>No</p>");
                                $("#smcEmail").html('<p>&ndash;</p>');
                            }
                        } else {
                            $("#smcRegCd, #smcEmail").html('<p class="pt-data-value-medium">Not available</p>');
                        }
                    }).fail(function (err) {
                        $("#smcRegCd, #smcEmail").html('<p class="pt-data-value-medium">Not available</p>');
                        ErrorLog.ErrorUtils.prepareAndLogError(error, true);
                    });

                } catch (err) {
                    ErrorLog.ErrorUtils.myError(err);
                } finally {
                    that.afterRender();
                }
            	
            }
            _serviceCallsStack.push(Dataservice.getContactprofileInfoCache(clId));
           _serviceCallsStack.push(Dataservice.getClientgroupLocal(clId));
            
            Q.all(_serviceCallsStack)
            	.then(function(response){
            	    if (response && response.length > 0) {
            	        if (response && response[1]) {
            	            var _grpRepns = response[1].results[0];
            	            if (_grpRepns && _grpRepns.get("activeGroups")) {
            	                console.log(response[1], 'group response');
            	                try {
            	                    _grpId = GlobalContext.getInstance().getGlobalContext().Context.GroupId;
                                    _grpIdVal=_grpId;
            	                    var _selectedgroup = _grpRepns.get("activeGroups").find(function (grp, indx) {
            	                        return grp.get("id") == _grpId;
            	                    });
            	                    _activeClients = _selectedgroup.get('activeClients');
            	                    _adminCd = _selectedgroup.get('adminCode');
            	                    if ((_activeClients.length == 1 || (_adminCd == "002" && !Array.isArray(_activeClients)))) {
            	                        _isSoleGrpMember = true;
            	                    }
            	                }catch(error){
            	                    console.log("group services are not ready");
            	                }
            	            }
            	            
            	        }
            			if(response[0]){
            			    clientServicePrefSuccess(response[0]);
            			   
        				}
        				
            		}
            	})
            	.fail(function (error) {
            		ErrorLog.ErrorUtils.myError(error);
	            })
            	.done();     
            

       },
       afterRender: function () {
           Spinner.hide();
           (practicetech.modules.contactprofile) ? ((practicetech.modules.contactprofile.state) ? this.loadFromSavedStatePr() : "") : "";
           CommonUtils.logFisrtViewLoadTime("CP:Preferences", ErrorLog);
       },
       routeToGPM: function (e) {
			NativeAdaptor.notifyContactUpdated();
			var targetRoute = null;
			var that = this;

            switch (e.target.id) {
                case 'pref-edit-email':
                	Analytics.analytics.recordAction('contactProfile:emailAddressesUpdate:clicked');
                	targetRoute = "gpm/email";
                    break;
                case 'pref-edit-alert':
                    if (this.validateDocDelivAndShowMsg()) {
                    targetRoute = "gpm/alert"
                    }
                    	break;
                case 'pref-edit-communication-preference':
                	if (this.validateDocDelivAndShowMsg()) {
                		 targetRoute = "gpm/communicationPreference";
                    }

                    break;
                case 'pref-edit-communicationprefs':
                    targetRoute = "gpm/communicationprefs"
                    break;
                case 'pref-edit-docdelivery':
                    Analytics.analytics.recordAction('contactProfile:documentDeliveryEdit:clicked');
                    if (this.validateDocDelivAndShowMsg()) {
                        targetRoute = "gpm/documentDelivery";
                    }
                    break;
                case 'total-view-email-invite':
                    Analytics.analytics.recordAction('contactProfile:totalViewEmailInvite:clicked');                    
                    if(this.validateTotalViewInviteInfo()) {
                        that.sendTotalViewEmail();
                    }
                        break;

                case 'SecureSiteRegLink':
                    Analytics.analytics.recordAction('contactProfile:SecureSiteRegistration:clicked');
                    if (this.validateSecureSiteRegg()) {
                        that.SecureSiteReg();
                    }
                    break;

                case 'set-prefrences-email-invite':
                    Analytics.analytics.recordAction('contactProfile:setPreferenceEmailInvite:clicked');
                    if (this.validateSetPreferencesEmailInviteInfo()) {
                        that.sendDeliveryPrefEmail();
                    }
                    break;
                default:
                    console.log("error: edit field operator error")
                    alert('link not yet available')
                    break;
            }
            if (targetRoute) {
                (typeof practicetech.modules.contactprofile === 'undefined') ? practicetech.modules.contactprofile = new practicetech.createNew.module() : "";
                practicetech.modules.contactprofile.state = this.saveState(e);
                practicetech.modules.contactprofile.state.routeToTabEnforce = true;
                practicetech.modules.contactprofile.state.target = e.target.id;
            	Backbone.history.navigate(targetRoute, true);
            }
            
            return false;
        },
        sendTotalViewEmail: function () {
        	var payload = { "actnCd": "Acct Agg Registered Client Advisor Invite", "cmunTypCd": "Notification", "EMSApplCd": "ADVISORMOBILE"
        };
            Spinner.show();
            Dataservice.getTotalViewDelvPrefService(globalClid, payload).then(function (xhr, result) {
                Spinner.hide();
                if (result === "success") {
                    BootstrapDialog.alert('<div>'
                      + '<div class="left-box right-tick pull-left"></div>'
                      + '<div class="row right-box pull-left">'
                          +  '<div>The client will be sent an email link to enroll in Total View within the next business day.</div><br/>'
                          +  '<div class="pt-action-icon-header">Client Next Steps</div>'
                          +  '<div>They will need to login to the Secure Site on ameriprise.com and click on the Total View tab to enroll.</div><br/>'
                          +  '<div class="pt-action-icon-header">Advisor Next Steps</div>'
                          +  '<div> Let the client know to expect the email and encourage them to learn more and enroll.</div>'
                          +  '<div class="clearfix"></div>'
                      +  '</div>'
                      +  '<div class="clearfix"></div>'
                    + '</div>', function(){},"Invitation email sent");
                } 
            }).fail(function (err) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(err);
                });
           },
        sendDeliveryPrefEmail: function () {
            var payload = { "actnCd": "Pending Preference Change", "cmunTypCd": "Notification", "EMSApplCd": "ADVISORMOBILE" };
            Spinner.show();
            Dataservice.getTotalViewDelvPrefService(globalClid, payload).then(function (xhr, result) {
                Spinner.hide();
                if (result === "success") {
                    BootstrapDialog.alert('<div>'
                        + '<div class="left-box right-tick pull-left"></div>'
                        + '<div class="row right-box pull-left">'
                            + '<div>The client will be sent an email to register with the Secure Site on ameriprise.com within the next business day.</div><br/>'
                            + '<div class="pt-action-icon-header">Client Next Steps</div>'
                            + '<div>They will need to login to the Secure Site on ameriprise.com and update and confirm their preferences. A repeat email wil be sent if changes are not confirmed within 10 days.</div><br/>'
                            + '<div class="pt-action-icon-header">Advisor Next Steps</div>'
                                                         + '<div>Let the client know to expect the email.</div>'
                            + '<div class="clearfix"></div>'
                                            + '</div>'
                        + '<div class="clearfix"></div>'
                    + '</div>', function () {
                    }, "Invitation email sent");
                }
            }).fail(function (err) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(err);
            });

        },

        SecureSiteReg: function () {
            var payload = { "regTypCd":"NEW" };
            Spinner.show();
        	Dataservice.SecureSiteService(globalClid, payload).then(function (status, result, xhr) {
        		var tokenId = status.d.results[0].tokenId;
        		if (tokenId != null && tokenId != "") {
        			var tokenPayload = {
        				"actnCd": "Registration Reminder",
        				"cmunTypCd": "Notification",
        				"EMSApplCd": "ADVISORMOBILE",
        				"token": {
        					"tokenId": tokenId
        				}
        			}
        			Dataservice.getTotalViewDelvPrefService(globalClid, tokenPayload).then(function (status, result, xhr) {
        				Spinner.hide();
        				if (result == "success") {
        					BootstrapDialog.alert('<div>'
							   + '<div class="left-box right-tick pull-left"></div>'
							  + '<div class="row right-box pull-left">'
								  + '<div>The client will be sent an email to register with the Secure Site on ameriprise.com within the next business day.</div><br/>'
								  + '<div class="pt-action-icon-header">Client Next Steps</div>'
								  + '<div>They will need to go online the Secure Site on ameriprise.com and complete registration.</div><br/>'
								  + '<div class="pt-action-icon-header">Advisor Next Steps</div>'
								  + '<div> Let the client know to expect the email and encourage them to sign up for eDelivery.</div>'
								  + '<div class="clearfix"></div>'
							  + '</div>'
							  + '<div class="clearfix"></div>'
							+ '</div>', function () { }, "Invitation email sent");
        				}
        			}).fail(function (xhr) {
        				Spinner.hide();
        				ErrorLog.ErrorUtils.prepareAndLogError(xhr);
        			});
        		} else {
        			Spinner.hide();
					ErrorLog.ErrorUtils.prepareAndLogError(xhr);
        		}
            }).fail(function(err){
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(err);
            });

        },


        validateDocDelivAndShowMsg: function () {
            var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            var ampfRegVal = $('#ampfReg').text();
            var colaData = CPViewModel.getInstance().getData().cola;
            var dob = CPViewModel.getInstance().getData().cola.clientPersonal.attributes.bthDt;
            var today = new Date();
            if (dob != null) {
                var year = Number(dob.substr(0, 4));
                var month = Number(dob.substr(5, 2)) - 1;
                var day = Number(dob.substr(9, 2));
                var age = today.getFullYear() - year;
                if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) { age--; }
            }
            else {
                var age = 18;
            }
            if (CPData == null && colaData.clientPersonal.attributes.decsdInd === "Y") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because deceased clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            }
            if (age != null && age<18) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because clients must be 18 or older to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            }
            if (CPData != null) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Information");
                return false;
            } else if (storePriEmail == "") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'> Your request can not be completed because the client is missing a primary email address.  To add an email address, click the Edit button under Email addresses and complete the workflow.</div>", function () {
                }, "Information");
                return false;
            } else if (ampfRegVal == "No") { //not register
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be completed because the client is not registered on the Secure Site on ameriprise.com</div>", function () {
                }, "Information");
                return false;
            } else if (ampfRegVal == "" || ampfRegVal == null) { //not register and service fails
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because we are unable to determine if the client is registered on the Secure Site on ameriprise.com Please try again at a later time.</div>", function () {
                }, "Information");
                return false;
            } else if (storePriEmailUnReg == true) { // undelivered mail
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client’s email address on file is undeliverable. You must make necessary corrections before proceeding.</div>", function () {
                }, "Information");
                return false;
            }

            return true;
        },
        validateTotalViewInviteInfo: function () {
            var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            if (CPData != null) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible for Total View.</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storePriEmail == "") { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storeAmeriReg == "" || storeAmeriReg == "No") { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client needs to register for the Secure Site on ameriprise.com to use Total View.<br/></div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storeAmeriReg == "" || storeAmeriReg == null) { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Service fails</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storePriEmailUnReg == true) { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", function () {
                }, " Invitation email not sent ");
                return false;
            } else if (totalViewEnrolled == "Yes") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client is already enrolled in Total View.</div>", function () {
                }, " Invitation email not sent ");
                return false;
            }
            return true;
        },
        validateSetPreferencesEmailInviteInfo: function () {
            var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            var colaData = CPViewModel.getInstance().getData().cola;
            var dob = CPViewModel.getInstance().getData().cola.clientPersonal.attributes.bthDt;
            var year=Number(dob.substr(0,4));
            var month=Number(dob.substr(5,2))-1;
            var day=Number(dob.substr(9,2));
            var today=new Date();
            var age=today.getFullYear()-year;
            if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) { age--; }
            if (CPData == null && colaData.clientPersonal.attributes.decsdInd === "Y") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because deceased clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            }
            if (age != null && age<18) { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because clients must be 18 or older to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            }
            if (CPData != null) { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storePriEmail == "") { 
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storePriEmailUnReg == true) { // undelivered mail
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", function () { }, " Invitation email not sent ");
                return false;
            } else if (!(shareHolderDocPref === "U.S. mail" && acntStatmntsDocPref === "U.S. mail" && financialDocPref === "U.S. mail" && addDocTypePref === "U.S. mail")) {// U.S.MAIL as document delivery pref.
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client has already selected online document delivery. Use the update link within the appropriate section to make changes.</div>", function () {
                }, " Invitation email not sent ");
                return false;
            }

            return true;
        },



        validateSecureSiteRegg: function () {
            var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            var _colaData = CPViewModel.getInstance().getData().cola;
            var dob = CPViewModel.getInstance().getData().cola.clientPersonal.attributes.bthDt;
            var age;
            try{
                var year=Number(dob.substr(0,4));
                var month=Number(dob.substr(5,2))-1;
                var day=Number(dob.substr(9,2));
                var today=new Date();
                age=today.getFullYear()-year;
                if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) { age--; }
            }
            catch (err) {
                var _customLog = {
                    "message": "Custom log - validateSecureSiteRegg()",
                    "stack": { "description": "dob: " + dob }
                }
                ErrorLog.ErrorUtils.myError(_customLog, true);
                age = 18;
            }

            if (CPData == null && _colaData.clientPersonal.attributes.decsdInd === "Y") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because deceased clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            }
            if (age != null && age<18) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because clients must be 18 or older to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            } 
            if (CPData != null) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storePriEmail == "") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", function () {
                }, "Invitation email not sent");
                return false;
               } else if (storeAmeriReg == "Yes") { 
                   BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is already registered on the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storeAmeriReg == null) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Service fails</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (storePriEmailUnReg == true) {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", function () { }, " Invitation email not sent ");
                return false;
           }
                return true;
        },
        validateClientAndShowMsg: function (isGPPMEditCustomMsg) {

        	var _functionalEmailCount = 0;
        	$.each(PreferenceViewModel.getData().emails,function(index,email){
        		    if(email.undeliverable == false){
        			    _functionalEmailCount++;
        		    }
                });
        	if (storeAmeriReg != "Yes") {
        	    BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client is not registered on Secure Site on ameriprise.com. The client must register before proceeding.</div>", function () {
        	    }, "Information");
        	    return false;
        	}
        	else if (_functionalEmailCount == 0) {
        	    BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client's email address on file is undeliverable. You must make necessary corrections before proceeding.</div>", function () {
        	        }, "Information");
        	    return false;
        	}
        return true;
        },
        loadFromSavedStatePr: function () {
            that = this;
            var _prefrnsWorkflowArray = [];
            var state = practicetech.modules.contactprofile.state || {};
            retainSave = ["contactprofile/"];
            if (retainSave.indexOf(Backbone.history.list.slice(-2)[0]) === -1 && /gpm/.test(Backbone.history.list.slice(-2)[0]) === false) { return false }
            if (retainSave.indexOf(Backbone.history.list.slice(-2)[0]) > -1 && /gpm/.test(Backbone.history.list.slice(-3)[0]) === true && state.subTabFalg === true) {
                state = practicetech.modules.contactprofile.state;

            } else {
                state = {};
            }
            if (state.expand !== undefined ) {
                state.expand.forEach(
                    function (expandId) {
               
                        ($('#' + expandId).hasClass('collapse-icon') || $('#' + expandId).hasClass('pref-alert-closed')) ? $('#' + expandId).click() : "";
                    }
                )
            }

            if (state.collapse !== undefined) {
                state.collapse.forEach(
                    function (collapseId) {
                        ($('#' + collapseId).hasClass('collapse-icon') || $('#' + collapseId).hasClass('pref-alert-closed')) ? "" : $('#' + collapseId).click();
                    }
                )
            }
            if (typeof state.target !== 'undefined' && $(state.target.offset) !== 'undefined' && state.target.length > 0) {
                if (state.target === 'pref-edit-alert') {
                    $(window).scrollTop($("#cp-alerts").offset().top - 50)
                } else if (state.target === 'pref-edit-communication-preference') {
                    $(window).scrollTop($("#cp-commnpref").offset().top +100)               
                } else {
                    var _stateTarget = $("#" + state.target);
                    if (_stateTarget.length > 0) {
                        $(window).scrollTop(_stateTarget.offset().top - 50);
                    }
                    
                }
            }
            practicetech.modules.contactprofile.state.routeToTabEnforce = false;
        },
        saveState: function (e) {
   
            state = state || {};
            state.routeToTab = "preferences";
            state.scroll = $(window).scrollTop();
            state.expand = state.expand || [];
            state.collapse = state.collapse || [];
            state.subTabFalg = true;

            ($("#cp-pref-info").hasClass('collapse-icon')) ? SaveDrawerState("cp-pref-info", "collapse") : SaveDrawerState("cp-pref-info", "expand");
            ($("#cp-online-access").hasClass('collapse-icon')) ? SaveDrawerState("cp-online-access", "collapse") : SaveDrawerState("cp-online-access", "expand");
            ($("#cp-doc-delivery").hasClass('collapse-icon')) ? SaveDrawerState("cp-doc-delivery", "collapse") : SaveDrawerState("cp-doc-delivery", "expand");
            ($("#cp-alerts").hasClass('pref-alert-closed')) ? SaveDrawerState("cp-alerts", "collapse") : SaveDrawerState("cp-alerts", "expand");
            ($("#cp-commnpref").hasClass('pref-alert-closed')) ? SaveDrawerState("cp-commnpref", "collapse") : SaveDrawerState("cp-commnpref", "expand");
           
            function SaveDrawerState(target, action) {
                if (typeof target === 'undefined' || typeof action === 'undefined') {
                    return false
                };

                var targetExpandedIndex = state.expand.indexOf(target);
                var targetCollapsedIndex = state.collapse.indexOf(target);

                (targetExpandedIndex !== -1  && action === "collapse") ? state.expand.splice(targetExpandedIndex, 1): "";
                (targetCollapsedIndex === -1 && action === "collapse") ? state.collapse.push(target): "";
                (targetCollapsedIndex !== -1 && action === "expand") ? state.collapse.splice(targetCollapsedIndex, 1) : "";
                (targetExpandedIndex === -1 && action === "expand") ? state.expand.push(target) : "";

            }

            return state;
        },
        loadOrSave: function (e) {
            that = this;
            if (Backbone.history.fragment === "contactprofile/preferences") {
                (practicetech.modules.contactprofile) ? "" : practicetech.modules.contactprofile = {}
                practicetech.modules.contactprofile.state = {}
                practicetech.modules.contactprofile.state.target = e.target.id;
            }
        },
    });
    return preferencesView;
});
