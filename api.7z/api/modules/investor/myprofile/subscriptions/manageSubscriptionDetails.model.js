// manageSubscriptionDetail.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var ManageSubscriptionDetailsModelSchema = new mongoose.Schema({
    subscriptionDetails: {
        type: Array,
        'default': []
    }
});

var ManageSubscriptionDetailsModelLookUp = mongoose.model('ManageSubscriptionDetailsModelLookUp', ManageSubscriptionDetailsModelSchema);

var ManageSubscriptionDetailsModel = new ManageSubscriptionDetailsModelLookUp({
    subscriptionDetails: [{
        'accountSubscriptionObject': {
            'status': 'Valuation/Statement subscription has been created successfully.'
        },
        'navSubscriptionObject': {
            'status': 'NAV subscription has been created successfully.'
        },
        'weeklyMarketSubscriptionObject': {
            'status': 'Weekly Market subscription has been created successfully.'
        },
        'unSubscriptionObject': {
            'status': 'subscription has been deleted successfully.'
        }
    }]
});

ManageSubscriptionDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ManageSubscriptionDetailsModelLookUp table, please contact admin...');
    } else {
        ManageSubscriptionDetailsModelLookUp.remove({}, function() {
            console.log('ManageSubscriptionDetailsModelLookUp collection removed');
            ManageSubscriptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating ManageSubscriptionDetailsModelLookUp table, please contact admin...');
                }
                console.log('ManageSubscriptionDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ManageSubscriptionDetailsModelLookUp;
