/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details Lumpsum controller for Advisor module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function fundDtlsLumpsumCtrl($scope, buildPlanModelService, planSmartSolution) {
    // transactModel.setTransactType("Lumpsum");
    $scope.fundDetails = buildPlanModelService.getGoalPlanData();
    $scope.lumpsumFundDetails = [];
    angular.forEach($scope.fundDetails, function (obj) {
        var gridRow = {};
        gridRow.fundName = obj.fundName;
        gridRow.dividend = planSmartSolution.dividendFlagCheck(obj.dividendFlag);
        gridRow.fundOption = obj.fundOption;
        gridRow.dividendFlag = obj.dividendFlag;
        gridRow.amount = parseInt(obj.installmentDetails.oneTime);
        gridRow.nfoFlag = obj.nfoFlag;
        gridRow.fundType = obj.fundType;
        gridRow.accNo = obj.accNo;
        $scope.lumpsumFundDetails.push(gridRow);
    });
    planSmartSolution.setLumpsumFunds($scope.lumpsumFundDetails);
    $scope.lumpsumColumnDefs = [
        {field: 'fundName', displayName: 'Invest Into', width: '250', pinnedLeft: true},
        {
            field: 'amount',
            displayName: 'Buy Amount',
            width: '213',
            headerCellClass: 'fti-grid-rupeeIcon text-right',
            cellClass: 'text-right'
        },
        {field: 'dividend', displayName: 'Dividend Option', width: '350'}
    ];
}
fundDtlsLumpsumCtrl.$inject = ['$scope', 'buildPlanModelService', 'planSmartSolution'];
module.exports = fundDtlsLumpsumCtrl;