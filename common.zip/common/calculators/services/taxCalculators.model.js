/**
 * @ngdoc service
 * @name advisor alerts model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Setting the default $cacheFactory options for http call
 *
 */
'use strict';

var taxCalculatorModel = function (Restangular, $q, fticLoggerMessage, loggerConstants,authenticationService,toaster) {
    var _taxCalculation = null;    
    var taxCalculatorModel = {
        
        callTaxCalculatorData : function (params, isAdvisor) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.ADVISOR_ALERTS_MODEL + ' | callSipCalculatorData' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var body = params;
            params = {};
            if(isAdvisor) {
            params = {

                'guId' : authenticationService.getUser().guId,
            };
        }
           
            Restangular.one('smartsolution/taxAdvtCalculator').customPOST(body, '', params, {}).then(function (taxcalculations) {
                deferred.resolve(taxcalculations);
            }, function (resp) {
                deferred.reject(resp);
                toaster.error(resp.data[0].errorDescription);
            });
            return deferred.promise;
        },
        setTaxCalculations:function(taxcalculations){
            _taxCalculation = taxcalculations;

        },
        getTaxCalculations:function(){
            if(!angular.isDefined(_taxCalculation))
            {
                return null;
            }

            return _taxCalculation;
        }
    };
    return taxCalculatorModel;
};

taxCalculatorModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService','toaster'];

module.exports = taxCalculatorModel;