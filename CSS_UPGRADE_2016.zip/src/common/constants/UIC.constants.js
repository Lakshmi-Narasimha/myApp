var UIC = {};

UIC.sitePrefix = "";

UIC.USER_TYPES = {

        customer: '0001',
        agent: '0002',
        csr: '0003',
        superCsr: '0999'
    };

 UIC.PAYMENT_METHOD_CODES = {
        'VI': 'Visa',
        'MC': 'MasterCard',
        'CR': 'Credit',
        'DB': 'Debit',
        'CHK': 'Checking',
        'CH': 'Checking',
        'SAV': 'Savings',
        'SA': 'Savings',
        'DS': 'Discover',
        'AX': 'Amex'
    };
    UIC.CARDTYPE = {
        'DEBIT': 'D',
        'CREDIT': 'C',
        'SAVINGS': 'B',
        'CHECKING': 'B'
    };
    UIC.SUPPORTED_CREDIT_CARDS = {
        'DISCOVER': 'DISCOVER',
        'AMEX': 'AMEX',
        'VISA': 'VISA',
        'MASTERCARD': 'MASTERCARD'
    };
    UIC.CARD_CODES = {
        'DISCOVER': 'DS',
        'AMEX': 'AX',
        'VISA': 'VI',
        'MASTERCARD': 'MC'
    };

UIC.paymentsLink =  (window.loginURL || 'https://www.farmers.com') + '/payments/';