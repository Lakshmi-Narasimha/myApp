﻿define(['jquery', 'bootstrap', 'appcommon/analytics'], function ($, bootstrap, Analytics) {
    var drawerToggle = function (drawerEvtObj) {
        var $drawerEvtObj = $(drawerEvtObj);
        var $parentDrawerToggle = ($drawerEvtObj.next('.pt-drawer-container').length != 0) ? $drawerEvtObj.next('.pt-drawer-container') : $drawerEvtObj.parent().parent().next('.pt-sub-drawer-columns');

        var _currentTabURL = '';
        if (window.location.hash === '#hoc/takeAction') { _currentTabURL = "TakeAction" }
        if (window.location.hash === '#hoc/serviceopportunities') { _currentTabURL = "ServiceOpportunity" }
        if (window.location.hash === '#hoc/dol') { _currentTabURL = "DOL" }

        if ($drawerEvtObj.hasClass("closed")) {
            $parentDrawerToggle.toggleClass('hidden').slideDown('slow');
            $drawerEvtObj.removeClass("closed");
            if ($parentDrawerToggle.hasClass("pt-sub-drawer-columns")) {
                if (_currentTabURL != "DOL") {
                    Analytics.analytics.recordAction('Drawer Opened-' + $drawerEvtObj.data('section') + ' - ' + _currentTabURL);
                }
            }
        } else {
            $parentDrawerToggle.slideUp('slow', function () { $(this).toggleClass('hidden'); });
            $drawerEvtObj.addClass("closed");
            if ($parentDrawerToggle.hasClass("pt-sub-drawer-columns")) {
                if (_currentTabURL != "DOL") {
                    Analytics.analytics.recordAction('Drawer Closed-' + $drawerEvtObj.data('section') + ' - ' + _currentTabURL);
                }
            }
        }
    }

    var hoccommon = {
        drawerToggle: drawerToggle
    };

    return hoccommon;
});