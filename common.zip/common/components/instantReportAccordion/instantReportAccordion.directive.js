/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var instantReportAccordion = function() {
	return {
            template: require('./instantReportAccordion.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              accordionData: '=',
              isToggleDisabled: '='
            },
            controller:['$scope', function($scope){ 
                $scope.status = {
                    open:true
                };
                 
            }],
            link: function(){ 
                var temp = angular.element(document.querySelectorAll('.panel-group .panel a[role="button"]'));
                 angular.forEach(temp,function(obj){
                   temp.attr('href','javascript:void(0)'); 
                });
               
            }
        };
};

instantReportAccordion.$inject = [];
module.exports = instantReportAccordion;