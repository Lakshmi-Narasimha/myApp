'use strict';


describe('directive: manage payments directive', function() {

    var scope, compile, validHTML, phoneFormat, addEditPaymentVM;

    
    validHTML = '<add-edit-payment-modal system-date-time="paymentVM.billingdata.systemDateTime"></add-edit-payment-modal>';

    beforeEach(module('CSS.billing'));
    beforeEach(module('CSS.common'));
    beforeEach(module('component.tile'));
    beforeEach(module('templates'));
    beforeEach(module('templates'));
    beforeEach(inject(function($compile, $rootScope) {
        scope = $rootScope.$new();
        compile = $compile;

        // scope.addEditPaymentVM = {};
        // scope.addEditPaymentVM.systemDateTime = "2016-01-01T11:59:04.159Z";

    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        document.body.appendChild(elem[0]);
        compiledElem = compile(elem)(scope);
        scope.$digest();

        return compiledElem;
    }   

    // xit('add payment bank account', function() {
    //     var elem = create();
    //     var isoScope = elem.isolateScope();

    //     scope.$broadcast("addMode");
    //     expect(isoScope.cardPayment).toBe(true);

    //     elem.find(".terms-conditons-section").find("button:contains('SAVE')").trigger("click");
        
    //     isoScope.user = {
    //         "bankAccountHolderNickName": "Test",
    //         "bankAccountType": "SAV",
    //         "routingnumber": "123456789",
    //         "accountNumber": "123456789",
    //         "accountHolderName": "Test",
    //         "termscheck": true
    //     };

    //     expect(isoScope.submitted).toBe(true);   
    //     isoScope.submit(true);
    //     expect(isoScope.pastDate).toBe(false);         

    // });

    // xit('add payment select payment card mode', function() {
    //     var elem = create();
    //     var isoScope = elem.isolateScope();

    //     scope.$broadcast("addMode");
        
    //     isoScope.cardPayment = false;
    //     isoScope.selectPaymentType("Card");
    //     expect(isoScope.cardPayment).toBe(true);  

    //     isoScope.selectPaymentType("Card");
    //     expect(isoScope.cardPayment).toBe(true);  
    // });

    // xit('add payment select payment bank mode', function() {
    //     var elem = create();
    //     var isoScope = elem.isolateScope();

    //     scope.$broadcast("addMode");
        
    //     isoScope.selectPaymentType("Account");
    //     expect(isoScope.cardPayment).toBe(false);         

    // });

    it('edit payment - bank mode', function() {
        var elem = create();
        var isoScope = elem.isolateScope();

        var editData = {
            "indicatorForBankOrCreditCard": "B",
            "systemGeneratedEncryptedNumberForBank": "pXcMJAHMy+mx6GJm/vG44w==",
            "statusOnBillingAccountNumber": "S",
            "scheduleFlagForCreditCard": null,
            "scheduleFlagForBankDetails": "Y",
            "paymentDivision": "0000029121,2043123652",
            "paymentCardsValidTo": null,
            "paymentCardsValidFrom": null,
            "paymentCardID": null,
            "maskedValueForValueForBank": "**********7890",
            "maskedValueForEncryptedValueForCreditCard": null,
            "encryptedNumberForCreditCard": null,
            "descriptionOfStatus": "",
            "defaultOrLastPaymentMethodType": "N",
            "creditCardType": null,
            "cityPostalCode": null,
            "cardType": null,
            "cardIdNumber": null,
            "cardHolderName": null,
            "bankKeysRoutingNumber": "101000187",
            "bankNickName": "My Savings account",
            "cardNickName": null,
            "bankAccountType": "CHK",
            "bankAccountHolderNickName": "EFT",
            "automaticSetupFlagForCreditCard": null,
            "automaticSetupFlagForBankDetails": "N",
            "accountIdNumber": "2001",
            "accountHolderName": "Account User",
            "$$hashKey": "05T"
        };

        scope.$broadcast("editMode", editData);
        expect(isoScope.addEditPaymentVM.paymentMthd.editIndicator).toBe(false); 
    });

    it('edit payment - card mode', function() {
        var elem = create();
        var isoScope = elem.isolateScope();

        var editData = {
            "indicatorForBankOrCreditCard": "C",
            "systemGeneratedEncryptedNumberForBank": null,
            "statusOnBillingAccountNumber": "N",
            "scheduleFlagForCreditCard": "N",
            "scheduleFlagForBankDetails": null,
            "paymentDivision": "0000029121,2043123652",
            "paymentCardsValidTo": "2015-12",
            "paymentCardsValidFrom": "2010-12",
            "paymentCardID": "2002",
            "creditCardType": "VI",
            "maskedValueForCreditCard": "****1234",
            "maskedValueForEncryptedValueForCreditCard": "************2668",
            "encryptedNumberForCreditCard": "safsaftysrzxxvsgydfxgytwdysi",
            "descriptionOfStatus": "",
            "defaultOrLastPaymentMethodType": "N",
            "cityPostalCode": "1234",
            "cardType": "CR",
            "bankNickName": null,
            "cardNickName": "VISA_CC",
            "cardIdNumber": ":uUEpHt6UbUGH7oTCOguo8/vtl3ASO7Ba:",
            "cardHolderName": "cardHolderName",
            "bankKeysRoutingNumber": "101000187",
            "bankAccountType": null,
            "bankAccountHolderNickName": "EFT",
            "automaticSetupFlagForCreditCard": "N",
            "automaticSetupFlagForBankDetails": null,
            "accountIdNumber": null,
            "accountHolderName": null,
            "$$hashKey": "05U"
        };

        scope.$broadcast("editMode", editData);
        expect(isoScope.addEditPaymentVM.paymentMthd.editIndicator).toBe(false);  
    });


    it('should define the CloseModal function', function() {

        var el = create();
        var isoScope = el.isolateScope();

        el.find(".fa-close").trigger('click');
        expect(isoScope.addEditPaymentVM.submitted).toBeFalsy();
    });

    it('should define the addEditPaymentVM.submit function', function() {

        var el = create();
        var isoScope = el.isolateScope();

        el.find(".btn-farmers-blue").trigger('click');
        expect(isoScope.addEditPaymentVM.submitted).toBeTruthy();
    });

    it('should define the addEditPaymentVM.selectPaymentType function', function() {

        var el = create();
        var isoScope = el.isolateScope();

        el.find(".text-uppercase").trigger('click');
        expect(isoScope.addEditPaymentVM.cardPayment).toBeFalsy();
    });

    it('should define the addEditPaymentVM.populateDateDD function', function() {

        var el = create();
        var isoScope = el.isolateScope();
        isoScope.addEditPaymentVM.populateDateDD( function(){
            // addEditPaymentVM.months = [10];
            // addEditPaymentVM.years = [10];
        });
        el.find("#addExpirationMonth").trigger('click');
        // expect(isoScope.addEditPaymentVM.cardPayment).toBeFalsy();
    });
    
    // xit('cancel adding payment', function() {
    //     var elem = create();
    //     var isoScope = elem.isolateScope();

    //     scope.$broadcast("addMode");
    //     expect(isoScope.cardPayment).toBe(true);
                       
    //     elem.find(".terms-conditons-section").find("button:contains('CANCEL')").trigger("click");
    //     expect(isoScope.submitted).toBe(false);
    // });    
});