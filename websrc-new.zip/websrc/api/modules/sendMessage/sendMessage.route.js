var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var sendMessageModel = require('./sendMessage.model');
var getMessageModel = require('../getMessage/getMessage.model');
var apiUtils = require('../../common/apiUtils');
var apiLPUtils = require('../../common/apiLPUtils');
var async = require("async");
var myCache = require('../../../api-server');
var proxy = require('../../../config/proxy');
var request = require('request');

// api route
router.route('/mfchatnode/rest/message')
    .post(function(req, res) {       
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.uri = sendMessageModel.createRequestUri;
        req.body.RequestParams = req.body.RequestParams || {};
        if(req.body.RequestParams.mqtt && !myCache.get(req.session.engagementID+".isRecurEnabled")){
            myCache.set(req.session.engagementID+".mqtt",req.body.RequestParams.mqtt); 
            myCache.set(req.session.engagementID+".isRecurEnabled", true);
            if(req.session.isTMP){
                logger.general.info(logger.formatInfoMsg(req.session.id, "LPGet Message loop started with EngagementID: "+ req.session.engagementID)); 
                logger.conversation.info(logger.formatInfoMsg(req.session.id, "LPGet Message loop started with EngagementID: "+req.session.engagementID));                 
                function getLPMsgReccursive(){
                    apiLPUtils.formattedGetLPMsg(req, res, function(chunk) {                       
                        res.status(200).end();
                        if(chunk){
                            req.session.isGetMsgRecur = false;
                            return;
                        }else{
                            setTimeout(function () {
                                req.session.isGetMsgRecur = true;
                                getLPMsgReccursive();
                            }, 5000);                            
                        }                        
                    });

                }                     
                getLPMsgReccursive();
                res.send(sendMessageModel.response);
            }else{
                logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop started with EngagementID: "+ req.session.engagementID)); 
                logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop started with EngagementID: "+req.session.engagementID)); 
                // polling started
                //apiUtils.getMsgRecursive(req, res, function(){});
                function getMsgReccursive(){ 
                    apiUtils.formattedGetMsg(req, res, function(chunk) {                       
                        res.status(200).end();
                        if(chunk){
                            req.session.isGetMsgRecur = false;  
                            return;
                        }else{
                            req.session.isGetMsgRecur = true;
                            getMsgReccursive();
                        }                        
                    });

                }                     
                getMsgReccursive();
                res.send(sendMessageModel.response);
            }            
        }else{
            var msgCount = parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"),10) || 0;
            myCache.set(req.session.engagementID+".chatSendMsgCounter", msgCount+1);  
            //console.log("SM count++: "+myCache.get(req.session.engagementID+".chatSendMsgCounter"));
            if(req.body.RequestParams.state && req.body.RequestParams.state === 'closed'){
                myCache.set(req.session.engagementID+".closed", true);
                myCache.set(req.session.engagementID+".chatSendMsgCounter", parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"),10)-1);  
                //console.log("SM count-: "+myCache.get(req.session.engagementID+".chatSendMsgCounter"));
                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + "{'state': 'closed'}" + ' MQTT:' + myCache.get(req.session.engagementID+".mqtt"));
            }else{
                if(req.body.RequestParams.messageText)
                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + req.body.RequestParams.messageText);
            }
            if(req.session.isTMP){
                var post_data = {};
                if(req.body.RequestParams.state && req.body.RequestParams.state === 'closed'){
                    post_data = sendMessageModel.lpEndChatReq;
                }else{
                    sendMessageModel.lpReq.event.text = '';
                    sendMessageModel.lpReq.event.text = req.body.RequestParams.messageText;
                    post_data = sendMessageModel.lpReq;
                }
                
                var reqObj = {
                    //method: 'GET',
                    url: req.session.location+'/events?v=1' + config.LP_APP_KEY_PARAM,
                    agent: proxy.agent,
                    ca:proxy.ca,            
                    headers: {                
                        'Content-Type' : 'application/json; charset=utf8',
                        //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                        'Accept' : 'application/json' 
                    },                
                    body: JSON.stringify(post_data)
                };
                logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                request.post(reqObj,function(err,response,body){
                    if(err){ 
                        logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
                        res.send(sendMessageModel.response);
                    }else if(response.statusCode !== 200 && response.statusCode !== 201){
                        logger.error.error(logger.formatResMsg(reqObj, reqObj, req.session.id));
                        logger.error.error(logger.formatResMsg(reqObj, response.body, req.session.id));
                        res.send(sendMessageModel.response);                        
                    }else {
                        logger.general.info(logger.formatInfoMsg(req.session.id, "LP send message response: "+ response));                
                        res.send(sendMessageModel.response);
                    }               
                });      
            }else{
                var post_data = req.body.RequestParams; 
                var reqObj = {
                    url:'https://'+req.uri.host + req.uri.path,
                    agent: proxy.agent,            
                    ca:proxy.ca,            
                    headers: {                
                        'Cookie': req.session.sessionCookie,
                        'Content-Type': 'application/json'
                        },
                    form:post_data
                }            
                logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                request.post(reqObj,function(err,response,body){
                    if(err){ 
                            logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                    }else{                    
                            logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));                    
                    }
                    if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                        parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && 
                        parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 2) {
                            myCache.set(req.session.engagementID+".isAssisted", true);
                            apiUtils.assisted(req,res,function(response) {});
                            apiUtils.saveMDN(req,res,function(response) {});
                    }
                    res.send(sendMessageModel.response);
                });    
            }
                  
        }      
    });

module.exports = router;
