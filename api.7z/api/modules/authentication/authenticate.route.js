var express = require('express'),
    router = express.Router(),
    CryptoJS = require('crypto-js'),
    Usernames = require('./usernames.model');

// api route

var error = {status: 300, message: 'Authentication Failed'}; /* Error messge object */


router.route('/login')
    .post(function(req, res) {
        console.log(req.body);
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        Usernames.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].usernamesObject.length === 0) {
                res.send(error);
            } else {
                var users = data[0].usernamesObject, flag = false;
                for(var i = 0, j = users.length; i < j; i++) {
                    if (req.body.arncode == users[i].arnCode.toString()) {
                        // var encryptedPassword = CryptoJS.MD5(users[i].password);
                        if (req.body.emailaddress == users[i].emailAddress) {
                            flag = true;
                            res.send({status: 100, message: 'User Authenticated Successfully', data: users[i]});
                            return;
                        } else {
                            flag = false;
                        }
                    } else {
                        flag = false;
                    }
                }

                if(!flag) {
                    res.send(error);
                }
            }

        });
    });


module.exports = router;
