/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function kycController($scope, $state) {
 	console.log('kycController');
 	
}
kycController.$inject = ['$scope', '$state'];
module.exports = kycController;