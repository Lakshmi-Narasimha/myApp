/**
 * @ngdoc directive
 * @name fticKeyValueTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticKeyValueTile will display the kye value tiles for "My profile - Grant Access" .
 * 
 *
 **/

'use strict';

var smartSolKeyValuePanel = function() {
    return {
            template: require('./smartSolKeyValuePanel.html'),
            restrict: 'E',
            replace: true,
            // transclude: true,           
            scope: {
                keyValueObject: "="
            },
            controller: function($scope, $element, $attrs){          
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

smartSolKeyValuePanel.$inject = [];
module.exports = smartSolKeyValuePanel;