/**
 * @ngdoc directive
 * @name stmtUnitHolder
 * @requires investorEventConstants 
 * @requires folioViewModel
 * @description
 *
 * - It displays the account statement holder view of the account statements at Folio level
 * 
 *
 **/
'use strict';

var stmtUnitHolder = function(investorEventConstants, folioViewModel, myportfolioConstants, $filter) {
    return {
        template: require('./stmtUnitHolder.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {
            $scope.isUnitHolderDataAvailable = (folioViewModel.getFolioViewObj() ? folioViewModel.getFolioViewObj().unitHolderDetails : false);
            $scope.verticalTileRows = [];

            if ($scope.isUnitHolderDataAvailable) {
                $scope.stmtUnitHolderData = folioViewModel.getFolioViewObj().unitHolderDetails;

                for (var holder in $scope.stmtUnitHolderData.holders) {
                    var holderArr = null;
                    if ($scope.stmtUnitHolderData.holders[holder].type === 'Firstholder') {
                        holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.FIRST_HOLDER), value: $scope.stmtUnitHolderData.holders[holder].pan }, { key: $scope.stmtUnitHolderData.holders[holder].name, value: $scope.stmtUnitHolderData.holders[holder].kycStatus }];
                        $scope.verticalTileRows.push(holderArr);
                    }
                    if ($scope.stmtUnitHolderData.holders[holder].type === 'Secondholder') {
                        holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.SECOND_HOLDER), value: $scope.stmtUnitHolderData.holders[holder].pan }, { key: $scope.stmtUnitHolderData.holders[holder].name, value: $scope.stmtUnitHolderData.holders[holder].kycStatus }];
                        $scope.verticalTileRows.push(holderArr);
                    }
                    if ($scope.stmtUnitHolderData.holders[holder].type === 'Thirdholder') {
                        holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.THIRD_HOLDER), value: $scope.stmtUnitHolderData.holders[holder].pan }, { key: $scope.stmtUnitHolderData.holders[holder].name, value: $scope.stmtUnitHolderData.holders[holder].kycStatus }];
                        $scope.verticalTileRows.push(holderArr);
                    }
                    if ($scope.stmtUnitHolderData.holders[holder].type === 'Fourthholder') {
                        holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.FOURTH_HOLDER), value: $scope.stmtUnitHolderData.holders[holder].pan }, { key: $scope.stmtUnitHolderData.holders[holder].name, value: $scope.stmtUnitHolderData.holders[holder].kycStatus }];
                        $scope.verticalTileRows.push(holderArr);
                    }
                    if ($scope.stmtUnitHolderData.holders[holder].type === 'Fifthholder') {
                        holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.FIFTH_HOLDER), value: $scope.stmtUnitHolderData.holders[holder].pan }, { key: $scope.stmtUnitHolderData.holders[holder].name, value: $scope.stmtUnitHolderData.holders[holder].kycStatus }];
                        $scope.verticalTileRows.push(holderArr);
                    }
                }

                $scope.keyValuesArr = [
                    { text: $filter('translate')(myportfolioConstants.overview.STATUS), value: $scope.stmtUnitHolderData.status },
                    { text: $filter('translate')(myportfolioConstants.overview.MODE_OF_OPERATION), value: $scope.stmtUnitHolderData.modeofOperation }
                ];
            }

        }
    };
};

stmtUnitHolder.$inject = ['investorEventConstants', 'folioViewModel', 'myportfolioConstants', '$filter'];
module.exports = stmtUnitHolder;
