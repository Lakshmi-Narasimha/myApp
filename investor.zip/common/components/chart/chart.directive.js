/**
 * @ngdoc directive
 * @name ftic-chart
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - Used to configure different types of charts by sending the config series object in the directive attribute.
 * 
 *
 **/

'use strict';

var chart = function($timeout){
	return{
		template : require('./chart.html'),
		scope: {
            chartOptions: '=',
		},
		link: function ($scope, iElement, iAttrs, controller) {			
			$timeout(function () {
			 $(iElement[0].firstChild).highcharts($scope.chartOptions);
			}, 0);
				
        }
	};
}

chart.$inject = ['$timeout'];
module.exports = chart;