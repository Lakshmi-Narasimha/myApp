/**
 * @ngdoc Controller
 * @name PanViewController
 * @requires $scope
 * @requires authenticationService
 * @requires investorDashboardDetailsModel
 * @requires investorGoalModelService
 * @description
 *
 **/


'use strict';

function TrackMyGoalsController($scope, $timeout, $state, investorEventConstants,investorEvents, loggerConstants, fticLoggerMessage, authenticationService, investorDashboardDetailsModel, investorGoalModelService) {

  $scope.selectGoal = false;
  $scope.selectGoalTileList = false;
  $scope.selectedGoal = {};

  if(!$scope.isGoalSummuryDataReady){
  	  	var params = {
			"guId" : authenticationService.getUser() ? authenticationService.getUser().guId : null
		};
		var userDetails = investorDashboardDetailsModel.getDashboardData();
	    if(userDetails) {
	        params.folioPanNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
	    }
		//investorGoalModelService.folioId = $scope.selectedInvestor.folioId;
		investorGoalModelService.fetchGoalTrackingDtls(params)
			.then(function (data) {
				investorGoalModelService.setGoalInvestorData(data.fsGoalSummary);
				//investorGoalModelService.getGoalInvestorData();
				$scope.selectGoal = true;
			}, function (data) {
				console.log("ERROR");
			});
  }
  $scope.$on('selectGoal',function(event,args){
  		//on selecting radio button in goal grid this event will trigger
		$scope.selectedGoal = angular.copy(investorGoalModelService.getGoalInvestorData()[args]);
		investorGoalModelService.setSelectedGoalData($scope.selectedGoal);
	});

  $scope.$on('smartSolSelectGoal',function(){
  		//on clicks on continue button below goals grid this event will trigger
		$scope.selectGoalTileList = true;
		$scope.selectGoal = false;
		$scope.goalKeyValueList=[
					{key:"Goal",value:$scope.selectedGoal.goal},
                    {key:"Goal Details",value:$scope.selectedGoal.goalDetails},
                    {key:"Tenure (in Yrs.)",value:$scope.selectedGoal.timeFrame},
                    {key:"% Tenure Completed",value:($scope.selectedGoal.timeFrame - $scope.selectedGoal.pendingTimeFrame)},
                    {key:"Target Amount",value:$scope.selectedGoal.targetAmount},
                    {key:"Goal Achived Till Date",value:($scope.selectedGoal.achieved.split("%")[0] * $scope.selectedGoal.targetAmount) /100},
                    {key:"% Achieved",value:$scope.selectedGoal.achieved},
                    {key:"No of Yrs. Remaining (in Yrs.)",value:$scope.selectedGoal.pendingTimeFrame}
          	];
      	$state.go("smartSol.trackmygoals.cp");
      	$scope.currentPlanDtls = true;
	});
 

}

TrackMyGoalsController.$inject = ['$scope', '$timeout', '$state','investorEventConstants', 'investorEvents', 'loggerConstants', 'fticLoggerMessage', 'authenticationService', 'investorDashboardDetailsModel', 'investorGoalModelService'];
module.exports = TrackMyGoalsController;