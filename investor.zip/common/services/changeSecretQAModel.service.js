/**
 * @ngdoc property
 * @name changeSecretQAModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - changeSecretQAModel is a service model which consists the list of services required for Change secret Q & A page in My profile module.
 *
 **/
'use strict';


var changeSecretQAModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, appConfig, authenticationService) {

    var _secretQuestions = null;
    var _responseMsg = null;
        
	var changeSecretQADetails = {
        getSecretQDetails : function (queryObj) {
            var deferred = $q.defer();
            var end = '';
            end = 'profile/secretQuestionnaire';
            Restangular.one(end).get(queryObj).then(function (questionDetails) {
                deferred.resolve(questionDetails);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        setUpdatedMsg: function(responseMsg){
            _responseMsg = responseMsg;
        },
        getUpdatedMsg: function(){
            return _responseMsg;
        },
        getSecretQuestions: function(){
            return _secretQuestions.securityQuestions;
        },
        setSecretQuestions: function(secretQuestions){
            _secretQuestions = secretQuestions;
        },
        changeSecretQA : function (queryObj) {
            var deferred = $q.defer();
            var end = 'profile/changeSecretQA';
            var params = {
                'guId' : authenticationService.getUser().guId,
                'strQuestion' : queryObj.question,
                'strAnswer' : queryObj.answer,
                'strVerifyAns' : queryObj.confirmanswer 
            }
            Restangular.one(end).customPOST({}, "", params, {}).then(function (changeSecretQADetails) {
                deferred.resolve(changeSecretQADetails);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },

    };

    return changeSecretQADetails;

};

changeSecretQAModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'appConfig', 'authenticationService'];
module.exports = changeSecretQAModel;
