define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailbrokeragevalueview.html'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetBrokerageAccountDetails(this.accountSummary.accountId)
                .then(function(accountDetails) {
                  var accountValues = {};
                  var EODBalance = accountDetails.EODBalDetail
                  if (EODBalance) {
                    accountValues.asOfDate = EODBalance.asOfDt ? EODBalance.asOfDt.formatDateMMddYYYY() : '';
                    accountValues.cashValue = EODBalance.cashVal ? EODBalance.cashVal.formatMoney() : '';
                    var productCd = self.accountSummary.productCd; 
                    if (EODBalance.mrgVal && !(productCd == "00017" || productCd == "00019" || productCd == "00022" || productCd == "00023")) {
                        accountValues.marginValue = EODBalance.mrgVal.formatMoney();
                    }
                    accountValues.totalSecuritiesValue = EODBalance.secrVal ? EODBalance.secrVal.formatMoney() : '';
                    accountValues.totalAccountValue = EODBalance.totAcctVal ? EODBalance.totAcctVal.formatMoney() : '';
                  }  
                  self.renderSection(SectionTemplateHtml, {accountValues: accountValues});
                })
                .fail(this.handleServiceError);
        }

    });

    return SectionView;
});
