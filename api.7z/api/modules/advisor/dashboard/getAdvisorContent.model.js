// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AdvisorContentSchema = new mongoose.Schema({
    advisorContentObject: {
        type: Array,
        "default": []
    }
});

var AdvisorContentLookUp = mongoose.model('AdvisorContentLookup', AdvisorContentSchema);

var AdvisorContentModel = new AdvisorContentLookUp({

  "advisorContentObject": [
    {
        "quickLinks": [{
            "title": "Account Statement",
            "link": null,
            "image": "brand-delices-carte.jpg",
            "clas": "icon-fti_advisorAccountStatement"
        }, {
            "title": "Portfolio Valuation",
            "link": null,
            "image": "brand-delices-flyer.jpg",
            "clas": "icon-fti_advisorPortfolioValuation"
        }, {
            "title": "Capital Gains Statement",
            "link": null,
            "image": "brand-delices-carte.jpg",
            "clas": "icon-fti_advisorCapitalGain"
        }, {
            "title": "Pre-filled Transaction Slips",
            "link": null,
            "image": "brand-delices-carte.jpg",
            "clas": "icon-fti_advisorPrefilled"
        }, {
            "title": "Build My Report",
            "link": null,
            "image": "brand-delices-carte.jpg",
            "clas": "icon-fti_advisorBuildMyReport"
        }],
        "advisorContentWidgets": [{
            "title": "Fund Manager Speaks",
            "name": "Srikesh Nair",
            "topic": "On Equity Fund",
            "image": "../images/person.jpg",
            "brief": "Do not react to temporary market movements, stick to your asset allocation plan",
            "link": "url",
            "linkname": "Watch Video"

        }, {
            "title": "New Offering",
            "name": "Presenting Franklin Retirement savings fund",
            "image": "images/frank.jpg",
            "brief": "NFO period 6th April to 18th April",
            "link": "url",
            "linkname": "View Scheme Details"
        }]
}
    ]

});

AdvisorContentLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AdvisorContentLookUp table, please contact admin...');
    } else {
        AdvisorContentLookUp.remove({}, function(err) {
            console.log('AdvisorContentLookUp collection removed');
            AdvisorContentModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AdvisorContentLookUp table, please contact admin...');
                }
                console.log('AdvisorContentLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AdvisorContentLookUp;
