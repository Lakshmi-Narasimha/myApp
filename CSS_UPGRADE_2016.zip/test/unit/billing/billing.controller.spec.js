(function() {
    'use strict';
    describe('billing controller', function() {
        beforeEach(module('CSS.billing'));

        var billingCtrl, $controller, billingVM;

        beforeEach(inject(function($controller, $injector) {
            billingCtrl = $controller('billingCtrl');
        }));

        describe('billingCtrl', function() {
            it('should expect billing.billingCtrl to be defined...', function() {
                expect(billingCtrl).toBeDefined();
            })
        })

    })
})();
