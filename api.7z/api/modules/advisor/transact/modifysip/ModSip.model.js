// modSip.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ModSipModelSchema = new mongoose.Schema({
    ModSipResp: {
        type: Array,
        "default": []
    }
});

var ModSipModelLookUp = mongoose.model('ModSipModelLookUp', ModSipModelSchema);

var ModSipModel = new ModSipModelLookUp({
    ModSipResp : {
  "retrieveSip": [
        {
      "transactionNum": "PT40746876",
      "accountNumber": "0029903795354",
      "fundOptionDesc": "Franklin India PRIMA PLUS",
      "checkNum": "SIP-ECS",
      "sipStartDate": "07/SEP/2015",
      "sipEndDate": "07/AUG/2035",
      "amount": "5000",
      "totalInstallmentNum": "240",
      "balanceInstallmentNum": "207",
      "frequency": "Monthly",
      "sipStatusDesc": "Active",
      "instrumentType": "ECS",
      "sipStatusCode": "N",
      "fundOption": "002",
      "fundCategory": "EQUITY",
      "directPlan": "null",
      "bankDetails": "UNION BANK OF INDIA/535502010000772",
      "nextTriggerDate": "07/JUN/2018",
      "sipCancelDate": "07/JUN/2018",
      "alertFlag": "N",
      "leadDays": "15",
      "amountInMultiplesOf": "500",
      "paymentMode": "",
      "isStepUpActive": "N",
      "stepUpAmount": null,
      "achAmount": null,
      "achFrequency": null,
      "achFromDate": null,
      "achToDate": null,
      "achDebitType": null,
      "sipAnnualCycle": "07/OCT/2018",
      "status":"Expired"
    }
  ]
}

});

ModSipModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ModSipModelLookUp table, please contact admin...');
    } else {
        ModSipModelLookUp.remove({}, function(err) {
            console.log('ModSipModelLookUp collection removed');
            ModSipModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating ModSipModelLookUp table, please contact admin...');
                }
                console.log('ModSipModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ModSipModelLookUp;