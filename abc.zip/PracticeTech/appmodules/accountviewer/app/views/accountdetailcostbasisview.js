define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailcostbasisview.html',
  'appcommon/commonutility',
  'moment'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml, Utils, moment) {

    var SectionView = AccountDetailSectionView.extend({

        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetMutualFundBalance(this.accountSummary.accountId)
                .then(function(balanceData) {
                  var accountValues = {};

                  if (!Utils.isEmpty(balanceData.cvrShrQty)) {
                    accountValues.lotType = 'Covered';
                    accountValues.shares = balanceData.cvrShrQty;
                    accountValues.value = balanceData.cvrMktVal ? balanceData.cvrMktVal.formatMoney() : '';
                    accountValues.costBasis = balanceData.cvrCostBaseAmt ? balanceData.cvrCostBaseAmt.formatMoney() : '';
                  } else if (!Utils.isEmpty(balanceData.uncvrShrQty)) {
                    accountValues.lotType = 'Not Covered';
                    accountValues.shares = balanceData.uncvrShrQty;
                    accountValues.value = balanceData.uncvrMktVal ? balanceData.uncvrMktVal.formatMoney() : '';
                    accountValues.costBasis = balanceData.uncvrCostBaseAmt ? balanceData.uncvrCostBaseAmt.formatMoney() : '';
                  }
                  accountValues.lotReliefMethod = 'Average Cost';
                  accountValues.costBasisInformation = 'Money movement transactions will exhaust non-covered tax lots of your mutual fund shares before the covered tax lots in accordance with IRS regulations.';

                  self.renderSection(SectionTemplateHtml, {accountValues: accountValues});
                })
                .fail(this.handleServiceError);
        }

    });

    return SectionView;
});