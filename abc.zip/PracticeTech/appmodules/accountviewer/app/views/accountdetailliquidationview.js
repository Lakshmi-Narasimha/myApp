define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailliquidationview.html',
  'appcommon/commonutility',
  'moment'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml, Utils, moment) {

    var SectionView = AccountDetailSectionView.extend({

        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetMutualFundBalance(this.accountSummary.accountId)
                .then(function(balanceData) {
                  var accountValues = {};
                  if (Utils.isEmpty(balanceData.asOfTS)) {
                    accountValues.asOfDate = '';
                  } else {
                    var asOfDate = balanceData.asOfTS.getDateFromMS();
                    accountValues.asOfDate = moment(asOfDate).format("MM/DD/YYYY");
                  }
                  accountValues.qty = Utils.isEmpty(balanceData.qty) ? '' : balanceData.qty;
                  accountValues.marketPrice = Utils.isEmpty(balanceData.mktPrc) ? '' : balanceData.mktPrc.formatMoney();
                  accountValues.marketValue = Utils.isEmpty(balanceData.mktVal) ? '' : balanceData.mktVal.formatMoney(); 
                  accountValues.accrDivdAmt = Utils.isEmpty(balanceData.accrDivdAmt) ? '' : balanceData.accrDivdAmt.formatMoney();
                  accountValues.grossValue = Utils.isEmpty(balanceData.grsVal) ? '' : balanceData.grsVal.formatMoney();
                  accountValues.salesLoadAmt = Utils.isEmpty(balanceData.salesLoadAmt) ? '' : balanceData.salesLoadAmt.formatMoney();
                  accountValues.liqVal = Utils.isEmpty(balanceData.liqVal) ? '' : balanceData.liqVal.formatMoney();
                  self.renderSection(SectionTemplateHtml, {accountValues: accountValues});
                })
                .fail(this.handleServiceError);
        }

    });

    return SectionView;
});