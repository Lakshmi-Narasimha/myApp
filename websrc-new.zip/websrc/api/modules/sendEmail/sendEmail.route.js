var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var sendMessageModel = require('../sendMessage/sendMessage.model');
var apiUtils = require('../../common/apiUtils');
var myCache = require('../../../api-server');
var proxy = require('../../../config/proxy');
var request = require('request');

// api route
router.route('/mfchatnode/rest/sendEmail')
    .post(function(req, res) {
        logger.general.info(logger.formatInBoundReqMsg(req));        
        var emailSpecID = "";  

        if(req.session.isSales){
            emailSpecID = config.VZ_EMAIL_SPECID_SALES;
        }else if(req.session.isEmp){
            emailSpecID = config.VZ_EMAIL_SPECID_EA;
        }else{
            emailSpecID = config.VZ_EMAIL_SPECID_CARE;
        }

        var post_data = {
            "engagementID": req.session.engagementID,
            "emailAddress": req.body.RequestParams.emailAddress,
            "customerID": req.session.customerID,
            "emailSpecID": emailSpecID,            
            "siteID": config.TC_SITE_ID          
        };
    
        var reqObj = {
            url:'https://'+ config.TC_SERVER_NAME + config.TC_SEND_EMAIL_URI,
            agent: proxy.agent,            
            ca:proxy.ca,            
            headers: {                
                'Cookie': req.session.sessionCookie,
                'Content-Type': 'application/json'
                },
            form:post_data
        }
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        request.post(reqObj,function(err,response,body){
               if(err){ 
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
               }else{                   
                    logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));  
               }
               res.send(sendMessageModel.response);
        });        
        
    });

module.exports = router;
