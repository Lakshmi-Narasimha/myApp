/**
 * @ngdoc property
 * @name fticRedemptionReviewDetails Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Details.
 *
 **/
'use strict';

var fticRedemptionReviewDetails = function(redeemModel, redeemReviewDetailsFactory) {
    return {
        template: require('./redeemreviewdetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            $scope.keyValuePairs = redeemReviewDetailsFactory.getFormattedReviewDetails(redeemModel);
            
        }]
    };
};

fticRedemptionReviewDetails.$inject = ['redeemModel', 'redeemReviewDetailsFactory'];
module.exports = fticRedemptionReviewDetails;
