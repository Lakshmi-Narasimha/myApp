'use strict';

var pageHeader = function(eventConstants, events, fticMailBackOption) {
    return {
        template: require('./pageHeader.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            lable: '@lable',
            showDownload: '=',
            showMailback: '=',
            showTimestamp: '=',
            moduleName: '@?',
            emandateText: '@?',
           dividendsMailBack : '@',
           headerObj: '='
        },
        link: function(scope) {

            scope.mailbackOptions = {
                text: 'Portfolio snapshot for Jun 2016',
                mailBackType: fticMailBackOption.getMailbackOptions(scope.lable)
            };
            scope.formatDate = function(date) {
                var monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                    'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
                ];
                var hours = date.getHours();
                var minutes = date.getMinutes();
                var seconds = date.getSeconds();
                var ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                minutes = minutes < 10 ? '0' + minutes : minutes;
                seconds = seconds < 10 ? '0' + seconds : seconds;
                var strTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
                var object = {};
                object._date = date.getDate() + ' ' + monthNames[date.getMonth()] + ' ' + date.getFullYear();
                object._time = strTime;
                return object;
            };

            scope.date_Time = scope.formatDate(new Date());
            scope._date = scope.date_Time._date;
            scope._time = scope.date_Time._time;
            scope.$on(eventConstants.INV_MAILBACK_CLICKED, function(event, data) {

                events.emitMailbackSuc(scope, data);
            });
        }
    };
};

pageHeader.$inject = ['eventConstants', 'events', 'fticMailBackOption'];
module.exports = pageHeader;
