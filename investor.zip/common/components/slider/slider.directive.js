'use strict';

var slider = function($state) {
	return {
            template: require('./slider.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            controller: function($scope, $element, $attrs,$state){
                $scope.slider_floor_ceil = {
              value:10,
                options: {
                    floor: 0,
                    ceil: 100,
                    step: 25,
                    maxLimit: 50,
                    showSelectionBar: true,
                    getSelectionBarColor: function(value) {
                        return '#4fbd20';
                    }
                }
            };
            
            },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};
slider.$inject = [];
module.exports = slider;