'use strict';

var calculatorsEventConstants = (function() {
    return {
    	FUND_DETAILS : "fundDetails",
    	SIP_FUND_SUBMIT : "SIPFund",
    	FUND_DETAILS_CHART : "FundDetailsChart",
    	LUMPSUM_FUND_SUBMIT : "LUMPSUMFund",
    	TAX_CALCULATE : "TAX_CALCULATE",
    	TAX_CALCULATE_GRID : "TAX_CALCULATE_GRID",
    	COMMISSION_CALCULATE_GRID : "COMMISSION_CALCULATE_GRID",
    	COMMISSION_CALCULATE_SUBMIT : "COMMISSION_CALCULATE_SUBMIT",
        COMPARISON_FUND_SUBMIT : "ComparisonFund",
        COMPARISON_FUND_CHART : "comparisonFundDetails",
        COMPARISON_FUND_DETAILS : "fundDetailsComparison",
        COMPARISON_RESET_DATA : "resetComparisonFund",
        RESET_DATA : "resetChartData",
        SIP_RESET_DATA : "resetSIPChartData",
        LUMPSUM_RESET_DATA : "resetLumpsumChartData",
        TAX_RESET_DATA : "resetTaxData",
        COMMISSION_RESET_DATA : "resetCommissionData",
    };
}());

calculatorsEventConstants.$inject = [];
module.exports = calculatorsEventConstants;