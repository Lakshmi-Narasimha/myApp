/**
 * @ngdoc property
 * @name fticAmountFrequencyOptions Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Amount and Frequency Options.
 *
 **/
'use strict';

var fticAmountFrequencyOptions = function (fundDetails, bankDtlsModel, $stateParams, transactModel, TransactConstant, paperlessModel) {
    return {
        template: require('./amountFrequencyOptions.html'),
        restrict: 'E',
        replace: true,
        scope: {
            parentForm: '=',
            emandateClasses: '@?',
            purchaseDisable: '@?'
        },
        controller:['$scope', function ($scope) {
            $scope.formDetails = {
                paymentForm: $scope.parentForm
            };
            $scope.emandateClasses = false;            
            $scope.amountType = {key : 'amountType', label : TransactConstant.transact.AMOUNT_TYPE, disable : false, isRequired : true};
            $scope.frequency = {key : 'frequency', label : TransactConstant.transact.FREQUENCY, disable : false, isRequired : true};
            $scope.showAmountText = false;
            $scope.showFreqText = false;
            $scope.showFundAmountError = false;
            $scope.isSIP = false;
            $scope.isModifySIP = false;
            $scope.showSipFreqError = false;
            $scope.showInvalidAmtErr = false;

            $scope.amountObject = {
                key : 'amount',
                text : TransactConstant.transact.AMOUNT,
                value : '',
                name : 'amountInput',
                isRequired: true,
                type: 'number',
               // pattern: /^(?!\.?$)\d{0,9}(\.\d{1,2})?$/
                pattern: /^[0-9]*$/
            };

            if($scope.purchaseDisable){
                $scope.amountType.disable = true;
                $scope.frequency.disable = true;
                delete $scope.amountObject.pattern;
            }
            $scope.amountTypeOptions = [
                {
                    title: TransactConstant.transact.MAXIMUM, 
                    key : 'Maximum',
                    value : TransactConstant.transact.MAXIMUM
                },
                {
                    title: TransactConstant.transact.FIXED,
                    key : 'Fixed',
                    value : TransactConstant.transact.FIXED
                }
            ];

            $scope.frequencyOptions = [
                {
                    title: TransactConstant.transact.AS_AND_WHEN,
                    key : 'As & When',
                    value : TransactConstant.transact.AS_AND_WHEN
                },
                {
                    title: TransactConstant.transact.MNTHLY,
                    key : 'Monthly',
                    value : TransactConstant.transact.MNTHLY
                },
                {
                    title: TransactConstant.transact.QUATERLY, 
                    key : 'Quaterly',
                    value : TransactConstant.transact.QUATERLY
                }
            ];

            var transactType = transactModel.getTransactType();
            
            //Check flow
            if(transactType === TransactConstant.sip.SIP || transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.renewSip.RENEWSIP) {
                $scope.isSIP = true;
            } else if(transactType === TransactConstant.modifySip.MODIFYSIP) {
                $scope.isModifySIP = true;
            }
            
            var fundDetailsObj = fundDetails.getFundDetails();
            var fundObjLength = fundDetailsObj.length;            

            $scope.$on('amountTypeChanged', function(event, data) {
                bankDtlsModel.setAmountType(data.value);
                $scope.showAmountText = false;

                if(fundObjLength > 1) { //In case of multiple funds
                    $scope.amountTypeSel = $scope.amountTypeOptions[0];
                    bankDtlsModel.setAmountType($scope.amountTypeSel);
                    $scope.amountType.disable = true;
                } else {
                    if(data.value !== TransactConstant.transact.MAXIMUM) {
                        $scope.showAmountText = true;
                    }
                }

                if($scope.isSIP || $scope.isModifySIP) {
                    for(var i=0; i<fundObjLength; i++) {
                        if(fundObjLength === 1 && fundDetailsObj[i].stepUpSip !== 'NA') {
                            $scope.amountTypeSel = $scope.amountTypeOptions[0];
                            bankDtlsModel.setAmountType($scope.amountTypeSel);
                            $scope.amountType.disable = true;
                        }
                    };
                }
            });

            $scope.$on('frequencyChanged', function(event, data) {
                bankDtlsModel.setFrequency(data.value);
                $scope.showFreqText = false;
                $scope.showSipFreqError = false;
                
                if(fundObjLength > 1) { //In case of multiple funds
                    $scope.frequencySel = $scope.frequencyOptions[0];
                    bankDtlsModel.setFrequency(data.value);
                    $scope.frequency.disable = true;
                } else if(data.value !== TransactConstant.transact.AS_AND_WHEN) {
                    $scope.showFreqText = true;
                }

                if($scope.isSIP || $scope.isModifySIP) {
                    for(var i=0; i<fundObjLength; i++) {
                        if(fundObjLength === 1 && fundDetailsObj[i].frequency === TransactConstant.transact.MNTHLY) {
                            if(data.value === TransactConstant.transact.QUATERLY) {
                                $scope.showFreqText = false;
                                $scope.showSipFreqError = true;
                            }
                        }
                    };
                }
                bankDtlsModel.setIsSipFreqError($scope.showSipFreqError);
            });

            $scope.$on('INPUT_CHANGED', function(event, data) {
                bankDtlsModel.setTotalAmount(data.value);
                $scope.showFundAmountError = false;
                $scope.showFixedAmountError = false;
                $scope.showInvalidAmtErr = false;

                var fundTotal = 0,
                    enteredAmount = parseInt(data.value);

                if($scope.parentForm.$error.pattern || $scope.parentForm.$error.number) {
                    $scope.showInvalidAmtErr = true;
                }
                bankDtlsModel.setIsInvalidAmtError($scope.showInvalidAmtErr);
                
                if($scope.isSIP || $scope.isModifySIP) {
                    for(var i=0; i<fundObjLength; i++) {
                        fundTotal += parseInt(fundDetailsObj[i].sipAmount);
                    }
                } else {
                    for(var i=0; i<fundObjLength; i++) {
                        fundTotal += parseInt(fundDetailsObj[i].amount);
                    }
                }

                if(enteredAmount < fundTotal) {
                    $scope.showFundAmountError = true;
                }

                //In case of a single fund and Amount Type as Fixed, entered amount should be equal to selected fund amount
                if(fundDetailsObj.length === 1) {
                    var amountType = bankDtlsModel.getAmountType();
                    if(amountType === TransactConstant.transact.FIXED) {
                        $scope.showFundAmountError = false;
                        if(!isNaN(enteredAmount) && enteredAmount !== fundTotal) {
                            $scope.showFixedAmountError = true;
                        }
                    } else {
                        $scope.showFixedAmountError = false;
                    }
                }

                if($scope.isSIP || $scope.isModifySIP) {
                    for(var i=0; i<fundObjLength; i++) {
                        if(fundObjLength === 1 && fundDetailsObj[i].stepUpSip !== 'NA') {
                            if(amountType === TransactConstant.transact.FIXED) {
                                $scope.showFundAmountError = false;
                                if(!isNaN(enteredAmount) && enteredAmount !== fundTotal) {
                                    $scope.showFixedAmountError = true;
                                }
                            } else {
                                $scope.showFixedAmountError = false;
                            }
                        }
                    };
                }
                bankDtlsModel.setIsFundAmountError($scope.showFundAmountError);
                bankDtlsModel.setIsFixedAmountError($scope.showFixedAmountError);
            });

            //Save previous selections
            function savePreviousFreqOptions(){
                var amountType = bankDtlsModel.getAmountType();
                //Set Amount Type
                if(amountType === TransactConstant.transact.MAXIMUM) {
                    $scope.amountTypeSel = $scope.amountTypeOptions[0];
                } else if(amountType === 'Fixed'){
                    $scope.amountTypeSel = $scope.amountTypeOptions[1];
                }

                //Set Frequency
                var frequency = bankDtlsModel.getFrequency();
                if(frequency === TransactConstant.transact.AS_AND_WHEN) {
                    $scope.frequencySel = $scope.frequencyOptions[0];
                } else if(frequency === TransactConstant.transact.MONTHLY) {
                    $scope.frequencySel = $scope.frequencyOptions[1];
                } else if(frequency === TransactConstant.transact.QUARTERLY) {
                    $scope.frequencySel = $scope.frequencyOptions[2];
                }

                //Set Amount
                $scope.amountObject.value = angular.isNumber(bankDtlsModel.getTotalAmount())? bankDtlsModel.getTotalAmount() : parseInt(bankDtlsModel.getTotalAmount());
            }

            //For Transact Module
            if($stateParams.key === TransactConstant.transact.Payment_Key) {
                savePreviousFreqOptions();
            }

            //For Paperless Module
            if(paperlessModel.paymentDtls.hasData) {
                savePreviousFreqOptions();
            }
        }]
    };
};

fticAmountFrequencyOptions.$inject = ['fundDetails', 'bankDtlsModel', '$stateParams', 'transactModel', 'TransactConstant','paperlessModel'];
module.exports = fticAmountFrequencyOptions;