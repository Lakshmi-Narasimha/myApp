/**
 * - This directive is responsible for displaying the review switch advisor Form.
 *
 **/
 'use strict';

 var fticEkycReg = function (transactModel, transactEventConstants) {
    return {
        template: require('./ekycRegistration.html'),
        restrict: 'E',
        scope:{
            ekycRegForm:"=",
            inputObj:"="
        },
        controller:['$scope', function ($scope) { 
          console.info("EKyc directive Registration Controller!!");

          
            $scope.ekycMainObj = []; //investor main obj 

            angular.forEach($scope.inputObj, function(obj, key){
                $scope.inputObj[key].formattedKycStatus = (obj.kycStatus==="A" || obj.kycStatus==="KYC - Registered" || obj.kycStatus==="KYC Registered-New KYC" || obj.kycStatus==="MF KYC Registered")?"Registered" :"Not Registered";
                var holderKey = $scope.inputObj[key].type =='Secondholder'?"Second Holder Name":"Holder Name" &&  $scope.inputObj[key].type=='Guardian-1'?"Guardian Holder Name":"Holder Name" && $scope.inputObj[key].type =='Firstholder'?"First Holder Name":"Holder Name" && $scope.inputObj[key].type =='Thirdholder'?"Third holder name":"Holder Name" &&  $scope.inputObj[key].type=='Guardian-2'?"Guardian Holder Name":"Holder Name",
                    kycStatus = ($scope.inputObj[key].kycStatus==="A" || $scope.inputObj[key].kycStatus==="KYC - Registered" || $scope.inputObj[key].kycStatus==="KYC Registered-New KYC" || $scope.inputObj[key].kycStatus==="MF KYC Registered")?"Registered" :"Not Registered",
                    invTileData = transactModel.setInvTileData($scope.inputObj[key].name, $scope.inputObj[key].pan, $scope.inputObj[key].aadharNo, kycStatus, holderKey);
                $scope.ekycMainObj.push(invTileData);
            });            
        }]    
    };
};

fticEkycReg.$inject = ['transactModel','transactEventConstants'];
module.exports = fticEkycReg;