/**
 * @ngdoc service
 * @name redeemModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var redeemModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, selectInvestorModel, $state, transactModel, fundDetailsModel, TransactConstant) {
    var _redeemDetails = null,
        _type = null, 
        _amount = null, 
        _units = null, 
        _mode = null,
        _bank = null,
        _bankDetails = null,
        _advisorDetails = null,
        _isRedeemEdit = false,
        _paymentType = null,
        _source = null,
        _folioAccNo = null,
        _btCode = null;

    var redeemModel = {

        fetchTxnDetailsRedeem : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('getTxnDetailsRedeem').get(params).then(function (redeemDetails) {
                deferred.resolve(redeemDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        validateRedeem: function(){ 
            var deferred = $q.defer();
            var params = {};
            var body = {};
            body.folioId = transactModel.getTransactDetails().investorDetails ? transactModel.getTransactDetails().investorDetails.folioId : '';
            body.amount = transactModel.getTransactDetails().transactDetails.type === 'Amount' ? transactModel.getTransactDetails().transactDetails.amount : '';
            body.units = transactModel.getTransactDetails().transactDetails.type === 'Units' ? transactModel.getTransactDetails().transactDetails.units : '';
            console.log('body.amount', body.amount);
            console.log('body.units', body.units);
            body.accountNo = transactModel.getTransactDetails().fundDetails.tschvalAccno;
            body.txnType = "R";
            body.batchCode = TransactConstant.common.BATCH_CODE;
            body.fundOption = transactModel.getTransactDetails().fundDetails.tschvalAccno.substring(0,3);
            body.paymentBankAccNo = transactModel.getTransactDetails().transactDetails.bank.split("-")[1].trim();
            body.paymentBankName = transactModel.getTransactDetails().transactDetails.bank.split("-")[0].trim();
            body.bankAccountNumber = transactModel.getTransactDetails().transactDetails.bank.split("-")[1].trim();
            body.bankName = transactModel.getTransactDetails().transactDetails.bank.split("-")[0].trim();
            body.allUnitsFlag = transactModel.getTransactDetails().transactDetails.type === 'Full' ? "Y" : "N";
            if(body.allUnitsFlag !== 'Y'){
                if(transactModel.getTransactDetails().transactDetails.type === 'Amount'){
                     body.amountUnitFlag = "A";
                 }else{
                    body.amountUnitFlag = "U";
                    body.units = transactModel.getTransactDetails().transactDetails.units;
                 }
                }else{
                var totalAvlUnits = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits;
                totalAvlUnits = totalAvlUnits ? totalAvlUnits.replace(/,/g, "") : totalAvlUnits;
                body.units = totalAvlUnits;
                body.amountUnitFlag = body.amount ? "A" : "U";
            }
            body.webRefNo = '';
            var bankDtls = _bankDetails.paymentBank;
            for(var i=0; i<bankDtls.length; i++) {
                if(bankDtls[i].pbPersonalAccountNumber === body.paymentBankAccNo){
                    body.paymentMode = bankDtls[i].paymentType;
                    _paymentType = bankDtls[i].paymentType;
                }
            }
            body.source = authenticationService.getUser().userType;
            params.guId = authenticationService.getUser().guId;
            Restangular.one('transact/validateSell').customPOST(body, "", params, {}).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {       
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        fetchBankDetails : function () {
            var params = {};
            params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            params.folioId = selectInvestorModel.getSelectedInvestorDtls().folioId;
            //console.log($state.current.name,"investor");
            params.paymentMethod = "N";
            if($state.current.name === "transact.base.redeem" || $state.current.name === "invTransact.base.redeem" || $state.current.name === "txnmaster.review.reviewDetailsRedeem"){
                params.trxnType = "R";
                params.paymentMethod = "W";
            }
            // params.paymentMethod = "N";
            
            var deferred = $q.defer();
            Restangular.one('transact/paymentBanksByFolio').get(params).then(function (registeredBank) {
                deferred.resolve(registeredBank);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setRedeemDetails : function(redeemDetails) {
            _redeemDetails = redeemDetails;
        },

        getRedeemDetails : function() {
            return _redeemDetails;
        },

        setType : function(type) {
            _type = type;
        },

        getType : function() {
            return _type;
        },

        setAmount : function(amount) {
            _amount = amount;
        },

        getAmount : function() {
            return _amount;
        },

        setUnits : function(units) {
            _units = units;
        },

        getUnits : function() {
            return _units;
        },

        setMode : function(mode) {
            _mode = mode;
        },

        getMode : function() {
            return _mode;
        },

        setBank : function(bank) {
            _bank = bank;
        },

        getBank : function() {
            return _bank;
        },

        setBankDetails : function(bankDetails) {
            _bankDetails = bankDetails;
        },

        getBankDetails : function() {
            return _bankDetails;
        },/*,
        setAdvisorDetails : function(){
            _advisorDetails = advisorDetails;
        },
        getAdvisorDetails : function(){
            return _advisorDetails;
        }*/
        setIsRedeemEdit : function(stateVal) {
            _isRedeemEdit = stateVal;
        },
        getIsRedeemEdit : function() {
            return _isRedeemEdit;
        },
        getPaymentType : function(){
            return _paymentType;
        },
        setSource : function(src) {
            _source = src;
        },
        getSource : function() {
            return _source;
        },
        setFolioAccNo : function(acc) {
            _folioAccNo = acc;
        },
        getFolioAccNo : function() {
            return _folioAccNo;
        },
        setBatchCode : function(code) {
            _btCode = code;
        },
        getBatchCode : function() {
            return _btCode;
        },
        isFormEdited:false
        
        
    };
    return redeemModel;
    
};

redeemModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', 'selectInvestorModel', '$state', 'transactModel', 'fundDetailsModel', 'TransactConstant'];

module.exports = redeemModel;