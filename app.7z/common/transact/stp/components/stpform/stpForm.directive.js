/**
* @ngdoc property
* @name fticStpForm Directive
* @requires TransactConstant
* @requires $state
* @requires $filter
* @requires TransactConstant
* @requires stpDetailsModel
* @requires transactModel
* @description
*
* - I handles the basic form validation and bind the details to the stpDetailsModel and transactModel on form submit
*
**/
'use strict';



var fticStpForm = function ($state, stpDetailsModel, $filter, transactModel, TransactConstant, toaster, $timeout, transactEvents, transactEventConstants, frequencyOptionsModel,newFundDetailsModel,  fundDetailsModel, $stateParams, authenticationService) {
    return {
        template: require('./stpForm.html'),
        restrict: 'E',
        scope: {},
        controller:['$scope', '$element', function ($scope, $element) { 
            $scope.radios = {};
            $scope.radios.selectedVal = "";
            $scope.capitalAprrSelected = false;
            $scope.$input = $element[0].querySelector('.fixed-amount-label input');
            $scope.isInvestor = authenticationService.isInvestorLoggedIn();
            $scope.stpDetails={};
            $scope.showDividendOpt = false;
            var stpDetailsObj = null;
            var availAmtStatus = false;
            $scope.destinationFund = {};
            $scope.config = {};
            $scope.config.showNotification = false;
            $scope.stpCtnBtnDisable = true;
             $scope.dividendOptns = [$filter('translate')(TransactConstant.transact.RE_INVESTMENT), $filter('translate')(TransactConstant.transact.PAYOUT)];
            $scope.fieldNames = {
                label1 : $filter('translate')(TransactConstant.stp.STP_START_DATE),
                label2 : $filter('translate')(TransactConstant.stp.STP_END_DATE)
            }
            $scope.inputObject = {
                key : "fixedAmount",
                text : $filter('translate')(TransactConstant.stp.FIXED_AMOUNT) +" <span class='icon-fti_rupee'></span>",
                value : "",
                name : "stpFixedAmount",
                type : "number",
                min : 1000,
                pattern : /^[0-9]*$/,
                isRequired : false      
            };

            //STP Amount Functionality
            $scope.stpAmtTypes = [
            {
                label: '',
                value: 'fixedAmount',
                selected: false
            },
            {
                label: TransactConstant.stp.STP_CAPITAL_APPRECIATION,
                value: 'capitalAppreciation',
                selected: false
            }
            ];
             $scope.$on(transactEventConstants.transact.STP_FORM_RESET, function (event) {

                /**
                 * Condition Added for the below code to persist data on edit - Investor - Transact - SWP
                 *
                 */
                if(!transactModel.STP_MAIN_FLAG) {
                    $scope.$broadcast(transactEventConstants.transact.FREQUENCY_FORM_RESET);
                    resetSTPForm();
                }
            });
            function SetDetailsGoReview(){
               stpDetailsModel.validateSTP().then(function(data){
                transactModel.setWebRefNo(data.webRefNo);                                                
                stpDetailsModel.setStpDetails(stpDetailsObj);
                if(authenticationService.isInvestorLoggedIn()) {
                    $state.go('invTransact.review.stp');
                } else {
                    $state.go('transact.review.stp');                                                                    
                }

            },function(error){
                toaster.error(error.data[0].errorDescription);
            }); 
           }

        $scope.inputObject.disable = true;
        $scope.listenFixedAmountChange = function ($event) {
            $scope.stpCtnBtnDisable = false;
            $scope.inputObject.disable = false;   
            $scope.$broadcast('AMT_SELECTED_STP', {
                        type: 'fixed'
                    },transactModel.STP_MAIN_FLAG);    
            angular.element($scope.$input).triggerHandler('focus');

            $scope.inputObject.isRequired = true;
            frequencyOptionsModel.setAmountFormType('FIXEDAMOUNT', 'STPFORM');
            transactEvents.transact.publishAmountSelected($scope);
             
        }
        $scope.listenCapitalApprChange = function ($event) {

            $scope.stpCtnBtnDisable = false;
            $scope.inputObject.isRequired = false;
            $scope.inputObject.value = "";
             $scope.$broadcast('AMT_SELECTED_STP', {
                        type: 'capital'
                    },transactModel.STP_MAIN_FLAG);
            angular.element($scope.$input).triggerHandler('blur');  
            $scope.inputObject.disable = true;
            frequencyOptionsModel.setAmountFormType('CAPITAL', 'STPFORM');
            transactEvents.transact.publishAmountSelected($scope);
             
        }

        $scope.initialFlag = true; 
        if($scope.initialFlag)
        {
            $timeout(function () {                    
                frequencyOptionsModel.setAmountFormType('FIXEDAMOUNT', 'STPFORM');
                transactEvents.transact.publishAmountSelected($scope);
                $scope.initialFlag = false;    
            });
        };

         $scope.$on('existingOptionSelected',function(event, data){
            console.log(data);
            if(data.payoutFlag=='N' && data.reinvestmentFlag=='Y'){
                    $scope.showDividendOpt=true;
                    $scope.radios.selectedVal = $scope.dividendOptns[0];
                }else if(data.payoutFlag=='Y' && data.reinvestmentFlag=='N'){
                       $scope.showDividendOpt=true;
                    $scope.radios.selectedVal = $scope.dividendOptns[1];
                }
          });
            $scope.$on('dividendOptionsStp',function(event,obj){
            /*    console.log(obj)
                if(obj.dividendFlag=='R'){
                    $scope.showDividendOpt=true;
                    $scope.radios.selectedVal = $scope.dividendOptns[1];
                }else if(obj.dividendFlag=='P'){
                     $scope.showDividendOpt=true;
                    $scope.radios.selectedVal = $scope.dividendOptns[1];
                    $scope.hideReinvestmentOpt=false;
                }else if(obj.dividendFlag=='G'){
                    $scope.showDividendOpt=false;
                }*/
                $scope.reinvestmentDisable=false;
                $scope.payoutDisable=false;
                $scope.showDividendOpt=true;
                $timeout(function() {
                     if (obj.fundType === 'E') {
                            if (obj.payoutFlag == 'Y' && obj.reinvestmentFlag == 'Y') {
                                if (obj.dividendFlag == 'P') {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                                    $scope.reinvestmentDisable=true;
                                    $scope.payoutDisable=true;
                                } else if (obj.dividendFlag == 'R') {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                    $scope.reinvestmentDisable=true;
                                    $scope.payoutDisable=true;
                                }
                            } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'N') {
                                //$scope.sipDetails.dividend = 'NA';
                                $scope.showDividendOpt=false;
                            } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'Y') {
                                $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                $scope.reinvestmentDisable=true;
                                    $scope.payoutDisable=true;
                            } else {
                                $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                              $scope.reinvestmentDisable=true;
                                    $scope.payoutDisable=true;
                            }
                        } else if (obj.fundType === 'N') {
                            if (obj.payoutFlag == 'Y' && obj.reinvestmentFlag == 'Y') {
                                if (obj.dividendFlag == 'P') {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                                } else if (obj.dividendFlag == 'R') {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                }
                            } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'N') {
                                //$scope.sipDetails.dividend = 'NA';
                                $scope.showDividendOpt=false;
                            } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'Y') {
                                $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                            } else {
                                $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                            }
                        }
                    },0)
               $scope.minStpAmt = obj.minSWPAmt;

               
             });
            //Handling Form Submit
            $scope.postStpDetails = function(){
                $scope.isSameFund = false;
                
                var stpModel = {};
                $scope.stpDetails.stpAmount = {};            
                

                if(newFundDetailsModel.getSelectedExistingFund()){
                    if(transactModel.getFundDetails().tschvalScheme === newFundDetailsModel.getSelectedExistingFund().fundOption){
                        $scope.isSameFund = true;
                    };

                }

                //If form is valid
                if($scope.stpForm.$valid && $scope.destinationFund && !$scope.isSameFund){
                    $scope.stpDetails.destinationFund = $scope.destinationFund;
                    $scope.stpDetails.stpAmount.type =  $scope.radios.selectedVal;

                    if($scope.radios.selectedVal == "fixedAmount"){
                        $scope.stpDetails.stpAmount.amount = $scope.inputObject.value;

                        var availableUnitsVal = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits;                        

                        var amount = $scope.stpDetails.stpAmount.amount;                        

                        if(availableUnitsVal < amount){                            
                            $scope.stpDetails.stpAmount.amount = amount;
                            availAmtStatus = true;
                            
                        }
                        if(availAmtStatus){
                            toaster.error(TransactConstant.stp.STP_FIXED_AMT_ERR);          
                        }
                    }
                    else if($scope.radios.selectedVal == "capitalAppreciation"){
                        $scope.stpDetails.stpAmount.amount = "Capital Appreciation";
                        availAmtStatus = false;
                    }
                    

                    stpDetailsObj = $scope.stpDetails;
                    //stpDetailsModel.setStpDetails(stpDetailsObj);
                    stpModel.investorDetails = transactModel.getInvestorDetails();
                    stpModel.fundDetails = transactModel.getFundDetails();
                    stpModel.stpDetails = stpDetailsObj; 


                    if ($stateParams.key == 'stp') {
                        var result = _.isEqual(transactModel.getTransactDetails().stpDetails, stpModel.stpDetails);


                        if (!result) {
                            $scope.config.showNotification = true;
                            var destroyHandler =  $scope.$on('yes', function () {
                                $scope.config.showNotification = false;
                                transactModel.setTransactDetails(angular.copy(stpModel));
                                transactModel.setStpFixedAmtStatus(availAmtStatus);
                                SetDetailsGoReview();
                                destroyHandler();
                            });

                            $scope.$on('no', function () {
                                $scope.config.showNotification = false;
                                setPreviousData();
                            });
                        }
                        else{
                            transactModel.setTransactDetails(angular.copy(stpModel));
                            transactModel.setStpFixedAmtStatus(availAmtStatus);
                            SetDetailsGoReview();
                        }
                    }else{
                        transactModel.setTransactDetails(angular.copy(stpModel));
                        transactModel.setStpFixedAmtStatus(availAmtStatus);
                        SetDetailsGoReview();
                    }   

                };         
                $scope.$emit("stpFormSubmit");
                
            }
             $scope.$on('EDIT_STP_FORM', function() {
                setPreviousData();
            });
            
            //  if(transactModel.getFundDetails().tschvalAccno == newFundDetailsModel.getSelectedExistingFund()){
            //     $scope.stpDisableBtn = true;
            // };

            // for Advisor module edit STP details...
            if($stateParams.key == 'stp' || transactModel.resetForm){
                setPreviousData();
                //$scope.minStpAmt = transactModel.getFundDetails().minSwpAmount;
            }

            function resetSTPForm() {
                $scope.isEditing = false;

               
                $scope.inputObject.value = "";
                // $scope.selections.bankDetails = "Dena Bank -001234567890";
                $scope.radios.selectedVal =" ";
                // Added Code for Investor
                // $scope.city = 'Mumbai';
                // $scope.brnch = 'Idgah Hill'; 
                
                $scope.inputObject.value = null;
                //angular.element($element[0].querySelectorAll('.floatLabels')).removeClass('focused');
            }
            function setPreviousData(){
                var stpDetails = transactModel.getTransactDetails().stpDetails;
                
                if(Object.keys(stpDetails).length > 0) {
                    $scope.$emit("Select_Fund_Continue"); 
                    $scope.$broadcast("CALL_FOR_FREQ_POPULATE_STP");
                    $scope.fundObj = {};
                    $scope.fundObj = stpDetails.destinationFund;
                    $timeout(function(){
                        $scope.$broadcast(transactEventConstants.transact.EDIT_FUND, {fundObj: $scope.fundObj});                 
                    },0);
                    $scope.radios.selectedVal = stpDetails.stpAmount.type; 
                    if ($scope.radios.selectedVal == 'fixedAmount') {
                        $scope.inputObject.value = stpDetails.stpAmount.amount;
                        $scope.listenFixedAmountChange();
                    }else if ($scope.radios.selectedVal == 'capitalAppreciation'){
                        $scope.listenCapitalApprChange();
                    }
                    $scope.stpCtnBtnDisable = false;
                } else {

                    resetSTPForm();
                }
            }

            /**
             * Event listener to reset stp form on change of Inv pref- Defect #3542 - Start
             */
            $scope.$on('RESET_STP_FORM_ON_CALL', function() {

                $scope.$broadcast(transactEventConstants.transact.FREQUENCY_FORM_RESET);
                resetSTPForm();
                transactModel.getTransactDetails().stpDetails = {};
            });
            /**
             * Event listener to reset stp form on change of Inv pref - Defect #3542 - Start
             */
        }]
    };
};



fticStpForm.$inject = ['$state', 'stpDetailsModel', '$filter', 'transactModel', 'TransactConstant', 'toaster', '$timeout', 'transactEvents', 'transactEventConstants', 'frequencyOptionsModel','newFundDetailsModel', 'fundDetailsModel','$stateParams', 'authenticationService'];
module.exports = fticStpForm;