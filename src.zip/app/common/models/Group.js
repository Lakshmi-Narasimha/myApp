define(['jquery', 'lodash', 'backbone'], function ($, _, Backbone) {
    var Group = Backbone.Model.extend({
        defaults: function () {
            return {
                'id': undefined,
                'ctx': undefined,
                'grpCtgCd': undefined,
                'fmtId': undefined,
                'MFGrfthrCd': undefined,
                'activeClients': null
            };
        },
        populateFromServiceResponse: function (groupEntity) {
            const group = {
                'id': groupEntity.id,
                'ctx': groupEntity.ctx,
                'grpCtgCd': groupEntity.grpCtgCd,
                'fmtId': groupEntity.fmtId,
                'MFGrfthrCd': groupEntity.MFGrfthrCd,
                'activeClients': groupEntity.activeClients
            }
            this.set(group);
            return this;
        }
    });
    return Group;
});