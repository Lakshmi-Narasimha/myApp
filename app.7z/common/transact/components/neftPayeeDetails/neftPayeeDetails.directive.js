/**
 * @ngdoc property
 * @name fticPaymentForm Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Redemption Form.
 *
 **/
'use strict';


var fticNeftPayeeDetails = function (bankDtlsModel, transactModel, $state , TransactConstant, authenticationService) {

    return {
        template: require('./neftPayeeDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            var transactType = transactModel.getTransactType(),
                txnType = null,
                payee = null;

            var payee = bankDtlsModel.getneftDetails();
            if(payee !== null) {
                $scope.neftDetailsObj = bankDtlsModel.formatNeftDetails(payee);
                $scope.payeeDetails = [
                    {
                        key : 'name',
                        text : TransactConstant.transact.NAME,
                        value : $scope.neftDetailsObj.orgName
                    },
                    {
                        key : 'bankName',
                        text : TransactConstant.transact.BANK_NAME,
                        value : $scope.neftDetailsObj.nameOfBank
                    },
                    {
                        key : 'ifscCode',
                        text : TransactConstant.transact.IFSC_CODE,
                        value : $scope.neftDetailsObj.ifsc_Cd
                    },
                    {
                        key : 'branchName',
                        text : TransactConstant.transact.BRANCH_NAME,
                        value : $scope.neftDetailsObj.nameOfBranch
                    },
                    {
                        key : 'accountNumber',
                        text : TransactConstant.transact.ACCOUNT_NUMBER,
                        value : $scope.neftDetailsObj.accNum
                    },
                    {
                        key : 'accountType',
                        text : TransactConstant.transact.ACCOUNT_TYPE,
                        value : $scope.neftDetailsObj.acc_Typ
                    }
                ];
            }
        }]
    };
};

fticNeftPayeeDetails.$inject = ['bankDtlsModel', 'transactModel', '$state', 'TransactConstant', 'authenticationService'];
module.exports = fticNeftPayeeDetails;