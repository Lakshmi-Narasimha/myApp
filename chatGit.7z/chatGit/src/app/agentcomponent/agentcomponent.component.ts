import { Component, OnInit, ViewChild } from '@angular/core';
import { Agent } from '../_models/index';
import { ModalDirective } from 'ng2-bootstrap';

import { AIAssistCacheService } from '../_services/aiassistcache.service';

@Component({
  selector: 'agentcomponent',
  templateUrl: './agentcomponent.component.html',
  styleUrls: ['./agentcomponent.component.css']
})
export class AgentcomponentComponent implements OnInit {

  newAgentmodel: any = {};

   @ViewChild('newAgentModal') public newAgentModel:ModalDirective;
   @ViewChild('removeAgentModal') public removeAgentModel:ModalDirective;
    agentsList : Array<Agent> = [];
    selectedAgent: Agent = null;
    showAgentDropdown: any = false;
    private agentDropdownList: Array < any > = [];
    constructor(private aiAssistCacheService : AIAssistCacheService) { this.subscribefordata();}
    public selected(value: any): void {
    }
    private subscribefordata() {
      this.aiAssistCacheService.agentListObservable.subscribe((data) => {
        this.agentsList = data || [];
        this.showAgentDropdown = true;
        this.agentsList.forEach((agent: {name: string,agentId: string}) => {
            this.agentDropdownList.push({
                id: agent.agentId,
                text: agent.name
            });
        });
      });
      this.aiAssistCacheService.activeAgentObservable.subscribe( (data) => {
        this.selectedAgent = data;
      });
    }

    public hideNewAgentModal():void {
    this.newAgentModel.hide();
  }

  public hideRemoveAgentModal() : void {
    this.removeAgentModel.hide();
  }

  public createNewAgent(){
    this.aiAssistCacheService.createAgent(this.newAgentmodel);
    this.hideNewAgentModal();
  }

  public removeCurrentAgent() {
    this.aiAssistCacheService.removeActiveAgent();
    this.hideRemoveAgentModal();
  }
  private value:any = {};
  private _disabledV:string = '0';
  private disabled:boolean = false;

 private get disabledV():string {
   return this._disabledV;
 }

 private set disabledV(value:string) {
   this._disabledV = value;
   this.disabled = this._disabledV === '1';
 }

 public changeAgent(value:any):void {
   let selAgent = this.agentsList.filter(x => x.agentId === value.agentId)[0];
   this.aiAssistCacheService.updateActiveAgent(value) ;
 }

 public removed(value:any):void {
 }

 public typed(value:any):void {
 }

 public refreshValue(value:any):void {
   this.value = value;
 }

  ngOnInit() {
  }

}
