/**
 * @ngdoc property
 * @name fticTransactionSummary Directive
 * @requires transactionModel
 * @requires transactionsGridConfig
 * @requires mytransactionsConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Transaction Summary data in a ui-grid.
 *
 **/
'use strict';

var paymentDetails = function($timeout, $state, bankDtlsModel, $loader, TransactConstant, authenticationService, transactEventConstants, invEformPaymentBanksUtility, toaster) {
    return {
        template: require('./paymentDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
            paymentSelect: '='
        },
        link: function($scope) {
            var accordion = "",
                validateParams = {},
                params = {},
                custBankParams = {},
                txnType = "",
                bankOptions = null,
                isNewAct = false,
                isValidForm = false,
                payMethod = "",
                isEmpty = false,
                editIconChanged = false;
            init();
            initPayMethod();
            var stopLoader = function() {
                $loader.stop();
            };

            $loader.start();
            var params = {};
            params.folioId = "122334";
            params.trxnType = 'P';
            params.guId = authenticationService.getUser().guId;
            bankDtlsModel.fetchBankDetails(params).then(function(data) { //Populate PaymentBanks

                bankDtlsModel.setBankDetails(data);
                bankOptions = bankDtlsModel.getBankDetails();
                setBankFilters(bankOptions);

            }, function(error) {
                if (error.data && error.data.length > 0) {
                toaster.error(error.data[0].errorDescription);
                }
            }).finally(stopLoader);

            function setBankFilters(bankOptions) {
                if (bankOptions) {
                    //fourth option for Open mandates are those mandates where the frequency of the mandate is ‘As & When’ and the Amount type is ‘Maximum’
                    invEformPaymentBanksUtility.populateBanks('emandate', bankOptions.emandate, $scope.eMandateOptions, 'openMandates'); //E-Mandate Bank Options 
                    invEformPaymentBanksUtility.populateBanks('netBanking', bankOptions.netBanking, $scope.netBankOptions); //Net Banking Options
                    invEformPaymentBanksUtility.populateBanks('newEmandates', bankOptions.newEmandates, $scope.newMandateOptions); //New E-Mandate Options
                }
            }

            function init() {
                $scope.showContinue = true;
                $scope.method = {};
                //$scope.method.eMandateSel = null;
                //$scope.method.netBankSel = null;
                //$scope.method.debitBankSel = null;
                //$scope.method.newMandateSel = null;
                //$scope.method.neftSel = null;
                $scope.mode = {};
                $scope.methodRequired = true;
                $scope.showMandateDetails = false;
                $scope.showNewMandate = false;
                $scope.showPayeeDetails = false;
                $scope.showNewAccount = false;
                $scope.isNewAccount = false;
                $scope.isNewMandate = false;
                $scope.showMultiPayMode = false;
                $scope.showAutoDebit = false;
                $scope.showBankError = false;
                $scope.showNoBankError = false;
                $scope.continueButton = true;
                $scope.disableContinue = true;
                $scope.configDataLost = {};
                $scope.configDataLost.showNotification = false;
                $scope.eMandateOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.netBankOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.newMandateOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                disablePayOptsInit();
            }

            function initPayMethod() {
                $scope.showMandateDetails = false;
                $scope.showNewMandate = false;
                $scope.showPayeeDetails = false;
                $scope.showNewAccount = false;
                $scope.isNewMandate = false;
                $scope.isNewAccount = false;
                $scope.showMultiPayMode = false;
                $scope.showAutoDebit = false;
                $scope.showNoBankError = false;
                if (!$scope.paymentSelect) {
                    $scope.paymentSelect = {};
                }
                $scope.paymentSelect.eMandateSel = $scope.eMandateOptions[0];
                $scope.paymentSelect.netBankSel = $scope.netBankOptions[0];
                $scope.paymentSelect.newMandateSel = $scope.newMandateOptions[0];
                console.log($scope.paymentSelect);
            }

            function disablePayOptsInit() {
                $scope.existingMandate = { disable: true, name: 'eMandate' };
                $scope.netBanking = { disable: true, name: 'netBank' };
                $scope.newMandate = { disable: true, name: 'nMandate' };
            }

            $scope.$on('setpayment', function(data) {
                initPayMethod();
            });

            $scope.$on('purchaseGetDetails', function(data) {
                if(data && data.targetScope && data.targetScope.invPurchaseData){
                    $scope.paymentSelect.paymentselectedVal = data.targetScope.invPurchaseData.paymentMethod;
                    var eMandateValue = data.targetScope.invPurchaseData.selectedBank;
                    if ($scope.paymentSelect.paymentselectedVal === 'Existing Payment Mandate') {
                        _.each($scope.eMandateOptions, function(element, value) {
                            if (eMandateValue === element.title) {
                                enableBankFilter($scope.paymentSelect.paymentselectedVal);
                                var data = element;
                                $scope.paymentSelect.eMandateSel = data;
                                $scope.index = value;
                                $scope.$emit(transactEventConstants.transact.EMANDATE_CHANGED, data);
                            }
                        });
                    } else if ($scope.paymentSelect.paymentselectedVal === 'Net Banking') {
                        var netBankValue = data.targetScope.invPurchaseData.selectedBank;
                        _.each($scope.netBankOptions, function(element, value) {
                            if (netBankValue === element.title) {
                                enableBankFilter($scope.paymentSelect.paymentselectedVal);
                                var data = element;
                                $scope.paymentSelect.netBankSel = data;
                                $scope.index = value;
                                $scope.$emit(transactEventConstants.transact.NETBANK_CHANGED, data);
                            }
                        });
                    }
                }
            });


            $scope.$on(transactEventConstants.transact.EMANDATE_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if (bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.emandate;
                    if (bankDtls) {
                        var selectedIdx = invEformPaymentBanksUtility.setPayment(bankDtls, data);
                        $scope.showMandateDetails = true;
                        bankDtlsModel.setEmandateDetails(bankDtls[selectedIdx]);
                    }
                } else if (data.key === 'select') {
                    $scope.showMandateDetails = false;
                }
            });

            $scope.$on(transactEventConstants.transact.NETBANK_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                console.log(data);
                if (bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.netBanking;
                    invEformPaymentBanksUtility.setPayment(bankDtls, data);
                }
            });

            $scope.$on(transactEventConstants.transact.NEWMANDATE_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                $scope.showNewAccount = false;
                $scope.isNewAccount = false;
                $scope.isNewMandate = true;

                if (bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    if (data.key === 'newAccount') {
                        $scope.showNewAccount = true;
                        $scope.isNewAccount = true;
                        bankDtlsModel.setPaymentMode(TransactConstant.common.EMANDATE_CODE); //Set payment mode for Setup a new e-mandate - new account option
                    } else if (data.key !== 'select') {
                        var bankDtls = bankOptions.newEmandates;
                        invEformPaymentBanksUtility.setPayment(bankDtls, data);
                    }
                    bankDtlsModel.setIsNewAccount($scope.isNewAccount);
                    $scope.$broadcast('bankChanged', data);
                }
            });



            function enableBankFilter(value) {
                var isEmpty = false;
                switch (value) {
                    case TransactConstant.transact.EXISTING_PAY_MANDATE:
                        if (bankOptions) {
                            isEmpty = isEmptyBankList(bankOptions.emandate);
                            if (!isEmpty) {
                                $scope.existingMandate.disable = false;

                            }
                        }
                        break;
                    case TransactConstant.transact.NET_BANKING:
                        if (bankOptions) {
                            isEmpty = isEmptyBankList(bankOptions.netBanking);
                            if (!isEmpty) {
                                $scope.netBanking.disable = false;

                            }
                        }
                        break;

                    case TransactConstant.transact.SETUP_NEW_MANDATE:
                        if (bankOptions) {
                            isEmpty = isEmptyBankList(bankOptions.newEmandates);
                            if (!isEmpty) {
                                $scope.newMandate.disable = false;

                                $scope.showNewMandate = true;
                            }
                        }
                        break;
                    case TransactConstant.transact.MULTIPLE_PAY_MODE:
                        isEmpty = false;
                        $scope.disableContinue = false; // Enable continue button
                        $scope.showMultiPayMode = true;
                        $scope.methodRequired = false;
                };
                if (isEmpty) {
                    $scope.showNoBankError = true;
                }
                bankDtlsModel.setIsNoBankError($scope.showNoBankError);
            }

            function isEmptyBankList(bankList) {
                var showNoBankError = false;
                if (bankList.length === 0) {
                    showNoBankError = true;
                }
                return showNoBankError;
            }

            $scope.payMethodChanged = function(value) {
                initPayMethod();
                disablePayOptsInit();
                bankDtlsModel.setIsNewAccount($scope.isNewAccount);
                bankDtlsModel.setPaymentMethod(value);
                bankDtlsModel.setSelectedBank(null); //Clear any previous bank selections            
                enableBankFilter(value);


                if (TransactConstant.transact.SETUP_NEW_MANDATE !== value) {
                    bankDtlsModel.setIsNewAccBankError(false);
                }
                if (TransactConstant.transact.EXISTING_PAY_MANDATE !== value) {
                    bankDtlsModel.setIsExhausted(false);
                }
                bankDtlsModel.setIsMultiPayMode($scope.showMultiPayMode);
            };

            $scope.$on('savePurchaseDetails', function() {
                $scope.paymentForm.$setSubmitted();
                bankDtlsModel.setPaymentMethodError($scope.paymentForm.$invalid);
                $scope.$broadcast('continueClicked');
                if($scope.paymentSelect.paymentselectedVal == TransactConstant.transact.SETUP_NEW_MANDATE && $scope.paymentSelect.newMandateSel && $scope.paymentSelect.newMandateSel.key === 'select'){
                    $scope.showBankError = true;
                    bankDtlsModel.setPaymentMethodError($scope.showBankError);
                }
            });
            /*$scope.$on('callPurchaseEdit', function() {
                $scope.paymentObj = invEformPaymentBanksUtility.getPayDetails($scope);
                //$scope.radios.selectedVal = $scope.paymentObj.paymentMethod;
               $scope.payMethodChanged($scope.paymentObj.paymentMethod);
            });*/

        }
    };
};

paymentDetails.$inject = ['$timeout', '$state', 'bankDtlsModel', '$loader', 'TransactConstant', 'authenticationService', 'transactEventConstants', 'invEformPaymentBanksUtility', 'toaster'];
module.exports = paymentDetails;
