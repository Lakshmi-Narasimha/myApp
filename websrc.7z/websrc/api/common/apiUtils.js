var getMessageModel = require('../modules/getMessage/getMessage.model');
var dataPassModel = require('../modules/dataPass/dataPass.model');
var https = require('https');
var http = require('http');
var logger = require('../../config/logger');
var config = require('../../config/config');
var querystring = require('querystring');

var apiUtils = {
    dataPass: function(req, res, dataPassCallback) {
        //  logger.access.info(req.body);
        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": req.session.agentID,
            "Role": req.session.accRole,
            "Mobile Number": req.session.MDN,
            "Greeting Name": req.session.nickName
        };

        req.uri = dataPassModel.createRequestUri;
        console.log("requestURI:", req.uri);

        var postBody = querystring.stringify(post_data);
        //  logger.access.info(postBody);
        //console.log(postBody);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            console.log("statusCode: ", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, reqObj, req.session.id));
            if (proxyResponse.statusCode === 200) {
                dataPassCallback(res);
                //res.status(200).end();
            } else {
                var errObj = {
                    message: 'ERROR!!! Something went wrong while retrieving data.',
                    statusCode: res.statusCode
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatResMsg(req, err));
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
            });
        });

        proxyRequest.write(postBody);
        proxyRequest.end();
    },
    getMsg: function(req, res, callBack) {
        console.log("request for the getmsg");
        req.uri = getMessageModel.createRequestUri;
        var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path + req.session.engagementID,
            headers: {
                'Cookie': req.sessionCookie,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res,  req.session.id));

        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');

            var data = '{}';
            if (req.session.mqtt && proxyResponse.statusCode === 204) {
              console.log('No msgList', req.session.chatSendMsgCounter)
                req.session.chatGetMsgCounter =   req.session.chatGetMsgCounter;
                req.session.chatSendMsgCounter = req.session.chatSendMsgCounter;
               //res.end();
            }
            proxyResponse.on('data', function(chunk) {
                console.log('response in increments', chunk);
                logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk, req.session.id));
                data = chunk;
                //callBack(chunk);
            });
            proxyResponse.on('end', function() {
                console.log('END');
                logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, data, req.session.id));
                callBack(data);
            });
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatResMsg(req, err));
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();

    },
    getMsgMultiCall: function(req, res, callBack) {
        for (var i = 0; i < 3; i++) {
            (function(i) {
                apiUtils.getMsg(req, res, function(chunk) {
                    if (i === 2) {
                        callBack(chunk);
                    }
                });
            })(i);
        }
    },
    getMsgMultiRecursiveCall: function(req, res, callBack) {
            //(function() {
                req.session.isRecurEnabled = true;
                apiUtils.getMsg(req, res, function(chunk) {
                    if (!req.session.chatClosed) {
                      chunk = JSON.parse(chunk);
                      if(chunk.messages && chunk.messages[0].state === 'closed'){
                        console.log('IN CLOSE:', req.session.chatSendMsgCounter, req.session.chatGetMsgCounter);
                        req.session.chatClosed = true;
                        res.end();
                        return;
                      } else{
                        console.log(chunk);

                        if (chunk.messages && chunk.messages[0].messageType === 'chatLine') {
                          req.session.chatGetMsgCounter = (req.session.chatGetMsgCounter || 1);
                          req.session.chatGetMsgCounter++;
                          console.log('IN CHATLINE:', req.session.chatSendMsgCounter, req.session.chatGetMsgCounter)

                        }
                        apiUtils.getMsgMultiRecursiveCall(req, res);
                        req.session.save();
                        res.end();

                      }
                    }
                });
            //})();
    },
    generateToken: function(req, res, callBackToken) {
        var postBody = { "deviceId": req.session.MDN };
        console.log(postBody);
        var reqObj = {
            host: 'sclmdm03wsi.sdc.vzwcorp.com',
            //host: 'udm-dev.vzwcorp.com',
            port: '6001',
            //port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/saveToken',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            console.log("req:", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    console.log("chunk:", chunk);
                    //  logger.access.info(chunk);
                    callBackToken(chunk);
                });
            } else {
                var errObj = {
                    message: 'ERROR!!! Something went wrong while retrieving data.',
                    statusCode: res.statusCode
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatResMsg(req, err));
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    sendCmd: function(req, res, callBackSendCmd) {
        //req.session.udm.isConnected = req.session.udm.isConnected;
        //console.log('UDM::',req.session.udm)
        var postBody = {
            "castType": "multicast",
            "cmd": "DROP_MSG",
            "requestor": "chatServer",
            "deviceList": [{
                "deviceId": req.session.MDN
            }],
            "data": req.session.getMsgRes
        };
        var reqObj = {
            host: 'sclmdm03wsi.sdc.vzwcorp.com',
            //host: 'udm-dev.vzwcorp.com',
            port: '6001',
            //port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/sendCommand',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {

            console.log("sendCmd:", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');

            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    //logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk, req.session.id));
                    logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk));
                    chunk = JSON.parse(chunk);
                    // req.session.udm = {
                    //     isConnected: chunk.status
                    // };
                    //console.log("chunk.status", req.session.udm.isConnected);
                    console.log("send commnad chunk", chunk);

                    //if (req.session.closeChat) {
                        //req.session.destroy();
                        //res.status(200).end();
                    //} else{
                      res.status(200).end();
                      if(req.session.theEnd){
                        console.log("##########################the end chat ########################################");
                        req.session.destroy();
                      }else{
                      callBackSendCmd(chunk);
                    }

                    //}
                });
            } else {
                var errObj = {
                    message: 'ERROR!!! Something went wrong while retrieving data.',
                    statusCode: res.statusCode
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatResMsg(req, err));
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    formattedGetMsg: function(req, res, getMsgCallback, isSendCallback) {

        //logger.access.info(req.body);
        req.uri = getMessageModel.createRequestUri;
        req.session.chatGetMsgCounter = (req.session.chatGetMsgCounter || 0);
        console.log('Send Msg Counter: in apiUtils' + req.session.chatSendMsgCounter);
        var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path + req.session.engagementID,
            headers: {
                'Cookie': req.sessionCookie
            }
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, reqObj, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            console.log(proxyResponse.statusCode);
            console.log('res.statusCode' + res.statusCode);
            req.session.save();
            if (res.statusCode === 200) {
                if (proxyResponse.statusCode === 200 || proxyResponse.statusCode === 204) {
                   //res.send(proxyResponse.statusCode).end();
                    console.log("after the proxyResponse");
                    proxyResponse.on('data', function(chunk) {
                      console.log('****************** chat before req counter', req.session.chatGetMsgCounter);
                      // console.log('****************** chat on Proxy res counter------ get message counter', req.session.chatGetMsgCounter);
                        logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk, req.session.id));
                        chunk = JSON.parse(chunk);
                        console.log("Get Message API Response:", chunk);
                        getMessageModel.response.Page.engagementID = req.session.engagementID;
                        // console.log('****************** chat on data counter', req.session.chatGetMsgCounter);
                        //getMessageModel.response.Page.status = engagementModel.response.Page.status;
                        chunk.messages = chunk.messages || [{}];
                        if (chunk.messages[0] && chunk.messages[0].state) {
                            // console.log("if state exist:", chunk);
                            getMessageModel.response.Page.agentID = (chunk.messages[0]['user.id'] || req.session.agentID);
                            getMessageModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                            getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                            getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                            getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                            getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['display.text'];
                            getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                        } else if (chunk.messages[0]) {
                            delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                            getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                            getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                            getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                            getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                            getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                            delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;

                            req.session.chatGetMsgCounter++;
                            console.log('****************** chat line counter---- get msg counter', req.session.chatGetMsgCounter);
                        }

                        // console.log(getMessageModel.response.ModuleMap.Support.msgList[0].messageType);
                        // if (getMessageModel.response.ModuleMap.Support.msgList[0].messageType === 'chatLine') {
                        //     req.session.chatGetMsgCounter++;
                        //     console.log('****************** chat line counter---- get msg counter', req.session.chatGetMsgCounter);
                        // }
                        //console.log("get mesg countr", req.session.chatGetMsgCounter);
                        //console.log(apiUtils.customerInfo.chatSendMsgCounter);
                        if (chunk.messages[0].messageText === 'login needed') {
                            getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                            getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                            getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;
                            //logger.access.info(getMessageModel.loginNeededResponse);
                            getMsgCallback(getMessageModel.loginNeededResponse);
                        } else if (chunk.messages[0] && chunk.messages[0].state === "closed") {
                            req.session.closeChat = chunk.messages[0].state;
                            req.session.mqtt = false;
                            var chatGetMsgCounter = getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber -3;
                            console.log('Get Msg Counter:'+chatGetMsgCounter + ' Send Msg Counter:' + req.session.chatSendMsgCounter);
                            var checkSurveyEligible = (chatGetMsgCounter >= 2 && req.session.chatSendMsgCounter >= 2);

                            if (checkSurveyEligible) {
                                var surveyUrl = getMessageModel.createSurveyUri(req.session);

                                var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);

                                getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                /*Sending the Thank you and Survey in the Response on End Chat*/
                                console.log("********************", surveyUrl, surveyMsg);
                                //getMsgCallback(getMessageModel.surveyResponse, true);
                                req.session.getMsgRes = getMessageModel.surveyResponse;
                                console.log('req.session.mqtt' + req.session.mqtt);
                                if (!req.session.mqtt) {
                                    req.session.destroy();
                                }
                            } else {
                                console.log("this is hte point where end msg sent");
                                /* Sending the Thank You response on End Chat*/
                                //    logger.access.info(getMessageModel.endResponse);
                                //getMsgCallback(getMessageModel.endResponse, true);
                                req.session.getMsgRes = getMessageModel.endResponse;
                                console.log('req.session.mqtt' + req.session.mqtt);
                                if (!req.session.mqtt) {
                                    req.session.destroy();
                                }
                            }
                        } else {
                            /*Sending the message sent form the TC to the Client*/
                            //  logger.access.info(getMessageModel.response);
                            //getMsgCallback(getMessageModel.response);
                            // if(req.session.mqtt){
                            //   apiUtils.formattedGetMsg(req, res, function(chunk){
                            //     res.status(200).end();
                            //   });
                            // }
                        }

                    });
                    if (req.session.mqtt && proxyResponse.statusCode === 204) {
                        getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = '';
                        //logger.access.info(getMessageMoSdel.response);
                        //getMsgCallback(getMessageModel.response);
                        // if(req.session.mqtt){
                        //   apiUtils.formattedGetMsg(req, res, function(chunk){
                        //     res.status(200).end();
                        //   });
                        // }
                    }
                } else {
                    var err = {
                        message: 'ERROR!!! Something went wrong while retrieving data.',
                        statusCode: res.statusCode
                    };
                    res.send(errObj);
                    if (req.session) {
                        logger.error.error(logger.formatResMsg(req, errObj));
                    }

                }
            } else {
                var errObj = {
                    message: 'ERROR!!! Something went wrong while retrieving data.',
                    statusCode: res.statusCode
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
                logger.error.error(logger.formatResMsg(req, err));
            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    }
};

module.exports = apiUtils;
