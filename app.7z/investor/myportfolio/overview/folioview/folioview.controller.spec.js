'use strict';
describe('Controller: myportfolio folioview controller', function() {
    var $controller, $scope, $state, event, folioViewController, mockFolioViewInitialLoader, timeout, httpBackend, $window;
    var accountFilter = { folioPanAccNo: '0119900830298', dayFlag: 'DE' };
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.module('investor.myportfolio'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _$state_,  folioViewInitialLoader, _$httpBackend_, _$window_) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        httpBackend = _$httpBackend_;
        $state = _$state_;
        mockFolioViewInitialLoader = folioViewInitialLoader;

        $window = _$window_;
        $window.ga = function() {};
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);
        httpBackend.expectGET('http://localhost:3030/clients/folioAccounts?flag=P&guId=878').respond({success: true});

        folioViewController = $controller('FolioViewController', { $scope: $scope });

    }));

    it('should expect FolioViewController to be defined', function() {
        expect(folioViewController).toBeDefined();
    });

    it('should expect folioAccounts call on load and to be success', function() {
        httpBackend.flush();
        expect($scope.viewObj.showFolioAccounts).toBeTruthy();
    });

    it('should trigger folioViewDetails services on apply event and should populate data', function() {
        httpBackend.flush();

        httpBackend.expectGET('http://localhost:3030/clients/clientStatement?flag=F&guId=878').respond({success: true});
        $scope.$emit('apply', {}, {});
        httpBackend.flush();
        
        expect($scope.showFolioData).toBeTruthy();
        expect($scope.viewObj.populateFolioData).toBeTruthy();
    });

    it('should trigger myPortfolioFolioAccounts', function() {
        $scope.$broadcast('myPortfolioFolioAccounts');
        expect($scope.viewObj.showFolioAccounts).toBeTruthy();
    }); 

    it('should trigger myPortfolioFolioView', function() {
        $scope.$broadcast('myPortfolioFolioView');
        expect($scope.viewObj.populateFolioData).toBeTruthy();
        expect($scope.showFolioData).toBeTruthy();
    }); 

    it('should trigger myPortfolioFolioView', function() {
        spyOn($scope, '$broadcast');
        $scope.$broadcast('showAccountView', accountFilter);
        spyOn($scope, "$emit");  
        $scope.$emit('changeNavPill', 'accountview')      ;
        expect($scope.$emit).toHaveBeenCalledWith('changeNavPill', 'accountview');
        spyOn($state, 'transitionTo');
        $state.transitionTo('overview.accview', accountFilter);
        expect($state.transitionTo).toHaveBeenCalledWith('overview.accview', accountFilter)
    }); 
});
