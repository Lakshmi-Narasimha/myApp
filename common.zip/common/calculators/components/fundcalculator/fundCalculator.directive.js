/**
 * @ngdoc property
 * @name Fund Calculators Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Displays the Fund calculator options fot sip, lumpsum.
 *
 **/
'use strict';


var fticFundCalculator = function() { 
  return {
    template: require('./fundCalculator.html'),
    restrict: 'E',
    replace: true,
    scope: {}
  };

};
fticFundCalculator.$inject = [];
module.exports = fticFundCalculator;   