define(['jquery', 'underscore', 'backbone', 'appmodules/ncst/app/js/utils','appcommon/globalcontext', 'appcommon/analytics',
		'text!appmodules/ncst/app/templates/draftslist.html'], function ($,
		_, Backbone,Utils,GlobalContext, Analytics, DraftsTemplate) {
	// var moment = require('moment');
	var taskDetails = Backbone.View
			.extend({
				el : $("#task-detail-and-action-modal"),
				id : 'practicetech-subapp',
				events : {
					"click #normal-prospect-launch,#normal-luanch-btn-draftslist" : "launchNCSTWithoutDraft",
					"click .ncst-draft-launch,.draft-data-holder":"launchNCSTWithDraft",
					"click #draft-list-cancel-button":"handleCancelButtonClick"
				},
				render : function(data) {
					try {
						this.$el.html("");
					} catch (error) {
						ErrorLog.ErrorUtils.myError(error);
					}
				},
				handleCancelButtonClick:function(){
					this.hideModal();
					this.draftCancelButtonClicHandler();
				},
				renderDraftList:function(data,draftLuanchCallback,normalLaunchCallback,draftCancelButtonClickHandler){
					this.draftLaunchCallback =  draftLuanchCallback?draftLuanchCallback:function(){};
					this.normlaLaunchCallback =  normalLaunchCallback?normalLaunchCallback:function(){};
					this.draftCancelButtonClicHandler= draftCancelButtonClickHandler;
					var _self = this;
					var _tmpTemplate = _.template(DraftsTemplate);
					var _dataLoadedTemplate = _tmpTemplate(data);
	        		_self.$el.html(_dataLoadedTemplate);
	        		 var _top = $("body").css("top");
			         var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
	        		$('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top': '-' + _bodytop + 'px' });
					$('#task-detail-view-template').modal("show");
	        		//_self.adjustModalHeight();
				},adjustModalHeight: function (e) {
		            var objId = '';
		            var modalBody = $('.pt-event-modal .modal-body > div');
		            var _top = $("body").css("top");
		            var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
		            if (isNaN(_bodytop)) {
		                _bodytop = $("body").scrollTop();
		            }
		            setTimeout(function () {
		                //Body
		                $('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top': '-' + _bodytop + 'px' });
		                $(window).scrollTop(_bodytop);
		            }, 100);

		            modalBody.each(function (i, elem) {
		                if ($(elem).hasClass('active')) {
		                    objId = $(elem).attr('id');
		                    return false;
		                }
		            });
		            var appContHeight = $('#' + objId).height();

		            //Adjust the height if the container height is less than 500 for none IE browsers
		            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
		                $('.pt-event-modal .modal-body').css({ height: (appContHeight < 515) ? 230 : (appContHeight + 30) });
		            } else {
		                $('.pt-event-modal .modal-body').css({ height: (appContHeight < 500) ? 230 : (appContHeight + 15) });
		            }

		            
		            $(window).scrollTop(_bodytop);
		        },
				launchNCSTWithDraft:function(event){
					var _$el = $(event.currentTarget);
					this.hideModal();
					this.draftLaunchCallback(_$el.data('draft-id'));
					Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:existingDraft:clicked');
					
				},
				hideModal:function(){
					$('body').removeAttr("style");
					$('#task-detail-view-template').modal("hide");
				},
				launchNCSTWithoutDraft:function(){
					this.hideModal();
					this.normlaLaunchCallback();
					Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:startNewDraft:clicked');
				}
				
			});
	return taskDetails;
});