coa = coa || {};
define(
		['jquery', 'underscore', 'backbone','backboneRelational', 'appmodules/coa/app/js/collections/clients',
				'appmodules/coa/app/js/lib/validate-4.2', 'config',
				'appmodules/coa/app/js/utils','errorLog' ],
		function($, _, Backbone,backboneRelational,Clients, Validator, Config, Utils,ErrorLog) {
			var filteredAccounts = [];
			var BASE_URL = Config.odataServiceName;
			var CLIENT_ID = null;
			var FM_ID = Utils.readCookie('FMID');
			var API_COMMON_DATA_BODY = Utils
					.getConfigProperty('API_COMMON_DATA_BODY');
			coa.models.User = Backbone.RelationalModel
					.extend({
						defaults : {
							submitterId : null,
							name : null,
							currentAddress : null,
							addressType : 'U.S',
							address : [],
							country : null,
							city : null,
							state : null,
							province : null,
							zipCode : null,
							changeType : null,
							clients : [],
							isNRA : false,
							fromBackButton : false,
							existingAddress : false,
							addressChecked: true,
							verifyAddresSeqNum: null,
							verifyAddressConfirm: false,
							verifyAddressType: null,
							verifyAddressAccounts: [],
						    deleteAddressAccounts: [],
							mailingType: "new",
							"deleteAddresSeqNum": null,
							futureStartEndate: null,
							futureStartDate: null,
							futureEndDate: null,
							caseId: null,
							editCaseDetails: null,
							eworkflowCaseCloseFailed: false

						},
						push : function(arg, val) {
							var arr = _.clone(this.get(arg));
							arr.push(val);
							this.set(arg, arr);
						},
						relations : [ {
							type : Backbone.HasMany,
							key : 'address',
							relatedModel : coa.models.Address,
							reverseRelation : {
								key : 'user',
								includeInJSON : 'submitterId'
							}
						}, {
							type : Backbone.HasMany,
							key : 'clients',
							keySource : 'clients',
							relatedModel : coa.models.Client,
							reverseRelation : {
								key : 'user',
								includeInJSON : 'submitterId'
							}
						}, {
							type : Backbone.HasMany,
							key : 'accounts',
							keySource : 'accounts',
							relatedModel : coa.models.Account,
							reverseRelation : {
								key : 'user',
								includeInJSON : 'submitterId'
							}
						} ],
						erase : function() {
							var _fmId = coa.user.get('submitterId');
							coa.accountView = null;
							coa.Accounts.set([]);
							coa.addressList.set([]);
							coa.Clients.set([]);
							coa.user.clear().set({
								accounts:coa.Accounts,
								submitterId : _fmId,
								advisorName : null,
								id : null,
								name : null,
								address : coa.addressList,
								addressType : 'U.S',
								city : null,
								state : null,
								zipCode : null,
								changeType : 'Permanent',
								clients : coa.Clients,
								changeReason : '',
								fromBackButton : false,
								number : 'number',
								text : 'text',
								isNRA : false,
								existingAddress: false,
								verifyAddresSeqNum: null,
								verifyAddressConfirm: false,
							    verifyAddressType:null,
							    verifyAddressAccounts: [],
							    deleteAddressAccounts: [],
							    mailingType: "new",
							    "deleteAddresSeqNum": null,
							    futureStartEndate: null,
							    futureStartDate: null,
							    futureEndDate: null,
							    caseId: null,
							    editCaseDetails: null,
							    eworkflowCaseCloseFailed: false
							}) ;
						},
						validate : function() {
						    var _proceed = true, _$zipCode = $("#zipcode"), _$mailingType = $('input[name=mailingType]:checked'), _malingAddrError;
							var _selectedAddressType = $("input[name=addressType]:checked").val();
							if (_selectedAddressType == "Foreign") {
								if ($('#country-list-select').val() == "CA") {
								    _$zipCode.removeClass("number");
								    _$zipCode.addClass("canada-zipcode").removeClass("us-zipcode");
								} else {
								    _$zipCode.addClass("number");
								    _$zipCode.removeClass("canada-zipcode").addClass("us-zipcode");
								}
							}
							if (!Validator.validateInputs('addressEntry')) {
								_proceed = false;
							}
							var _$addressUpdateType = $('.changeTyperadio').find('input[type="radio"]:checked');
							var _$accountList = $('.account-list'), _$vaTableContainer = $('#va-table-container'), _deletemailingAddress = $('input[name="deleteMailingAddress"]:checked'),
						        _$deleteMATableContainer = $("#delete-mailing-address-account-contnr");
							if (_$accountList.is(":visible")&& _$accountList.find("input[type=checkbox]:checked").length == 0) {
							    _$accountList.addClass("error");
							    _$accountList.find(">label").removeClass("hidden");
								$(".client-list").removeClass("error");
								$(".client-list>label").addClass("hidden");
								if (_proceed == true) {
								    _$accountList[0].scrollIntoView();
								}
								_proceed = false;
							} else if (_$addressUpdateType.val() == "Verify" && _$vaTableContainer.find("input[type=radio]:checked").length == 0) {
							    _$vaTableContainer.addClass("error");
							    _$vaTableContainer.find(">label").removeClass("hidden");
							    _$accountList.removeClass("error");
							    _$accountList.find(">label").addClass("hidden");
							    if (_proceed == true) {
							        _$vaTableContainer[0].scrollIntoView();
							    }
							    _proceed = false;
							    } else if (_$addressUpdateType.val() == "Mailing" && _$mailingType.val() == "delete" && _deletemailingAddress.length == 0) {
							        if (_$deleteMATableContainer.find('tr').length == 1) {
							            BootstrapDialog.show({
							                title: 'Important information',
							            message: "This transaction cannot be completed because the client does not have a mailing address with an account(s) associated.",
							                cssClass: '',
							                buttons: [{
							            label: 'OK',
							                cssClass: 'btn pt-btn-yes generic-button btn-primary',
							                action: function (dialog) {
                                                            dialog.close();
                                }
						}]
						});
							        } else {
                                        _$deleteMATableContainer.addClass("error");
							            _$deleteMATableContainer.find(">label").removeClass("hidden");
							            _$accountList.removeClass("error");
							            _$accountList.find(">label").addClass("hidden");
							            if (_proceed == true) {
							                _$deleteMATableContainer[0].scrollIntoView();
                                        }
                                    }
                                  
							    _proceed = false;
							    }

							if (_proceed) {
							    var _addressLine1, _addressLine2, _addressLine3, _newState, _newCity, _newCountry, _newProvince, _newCountryNme;
							    // check for existing address use
							    _newCountry = '';
							    _newCountryNme = '';
							    _newProvince = '';
							    _newZip = "";
							    this.set({ "verifyAddresSeqNum": null,"verifyAddressConfirm":false,"verifyAddressType":null,"verifyAddressAccounts":[] });
							    if (_$addressUpdateType.val() == "Verify") {
							        var _$selectedAddressContainer = $('.verify-addres-tr.active'), _verifyAddressAccounts = [];
							        var _selectedverifyAddressType = _$selectedAddressContainer.data("address-type"),
                                        _verifyAddSeqNum = _$selectedAddressContainer.find('input[type="radio"]').val();
							            _malingAddrError = coa.user.get("mailingAcctAddresError");
							            this.resetModel();
							            coa.user.set("mailingAcctAddresError", _malingAddrError);
							        this.set({ "verifyAddresSeqNum": _$vaTableContainer.find("input[type=radio]:checked").val() });
							        coa.user.set('fromBackButton', true);
							        coa.user.set('changeType', _$addressUpdateType.val());
							        coa.user.set('verifyAddressConfirm', true);
							        if (_selectedverifyAddressType == "Mailing") {
							            var _userAccounts = coa.user.get('accounts').toJSON();
							            _userAccounts.forEach(function (account, index) {
							                if (account.addrSeqNum == _verifyAddSeqNum) {
							                    _verifyAddressAccounts.push(account);
							                }
							            });
							        }
							        this.set({"scrub":{ 'validationSuccess': true }, "verifyAddressType": _selectedverifyAddressType, "verifyAddressAccounts": _verifyAddressAccounts });
							    } else {
							        _malingAddrError = coa.user.get("mailingAcctAddresError");
							        this.resetModel();
							        coa.user.set("mailingAcctAddresError", _malingAddrError);
							        var _isExistingAddressSelected = $('div[data-for="existing-address"]').is(':visible');
							        if (_$addressUpdateType.val() == "Mailing" && (_$mailingType.val() == "delete" || _isExistingAddressSelected)) {
							            var _addressIndex = null, _existingAdrress = null;
							            if (_isExistingAddressSelected) {
							                _addressIndex = Number($('input[data-master-container="existing-address"]:checked').val());
							                coa.user.set('existingAddress', true);
							                coa.user.set('existingAddressIndex', _addressIndex);
							                _existingAdrress = coa.user.get('address').at(_addressIndex);
							                coa.user.set({
							                    'addressSeqNum': _existingAdrress.get('addrSeqNum'),
							                    'deleteAddresSeqNum':null
							                });
							            } else {
							                _addressIndex = Number($('input[name="deleteMailingAddress"]:checked').data('array-index'));
							                _existingAdrress = coa.user.get('address').at(_addressIndex);
							                var _userAccounts = coa.user.get('accounts').toJSON(), _deleteAddressAccounts=[];
							                _userAccounts.forEach(function(account, index) {
							                    if (account.addrSeqNum == _existingAdrress.get('addrSeqNum')) {
							                        _deleteAddressAccounts.push(account);
							                    }
							                });
							                coa.user.set({
							                    'deleteAddresSeqNum': _existingAdrress.get('addrSeqNum'),
							                    'addressSeqNum': null,
							                    'mailingType': _$mailingType.val(),
							                    "deleteAddressAccounts": _deleteAddressAccounts
							                });
								            
							            }
							            coa.user.set('scrub', { 'validationSuccess': true });
							            _addressLine1 = _existingAdrress.get('addrLn1');
							            _addressLine2 = _existingAdrress.get('addrLn2');
							            _addressLine3 = _existingAdrress.get('addrLn3');
							            _newState = _existingAdrress.get('stCd');
							            _newCity = _existingAdrress.get('ctyNm');
							            _newZip = _existingAdrress.get('postlCd');
							        } else {
							            coa.user.set('existingAddress', false);
							            coa.user.set('existingAddressIndex', -1);
							            _addressLine1 = $('#addressLine1').val();
							            _addressLine2 = $('#addressLine2').val();
							            _addressLine3 = $('#addressLine3').val();
							            _newState = $('#state-list-select').val();
							            _newCity = $('#city').val();
							            _newZip = $('#zipcode').val();
							            // user enterd value
							            coa.user.set('eAddressLine1', _addressLine1);
							            coa.user.set('eAddressLine2', _addressLine2);
							            coa.user.set('eAddressLine3', _addressLine3);
							            coa.user.set('eNewZip', _newZip);
							            coa.user.set('eNewCIty', _newCity);
							            coa.user.set('eNewState', _newState);
							        }
							        /*future date values start*/
							        if (_$addressUpdateType.val() == "Mailing" && _$mailingType.val() == "new") {
							            var _$futureStartEndDate = $('.future-date-toggle.active');
							            if (_$futureStartEndDate.length > 0) {
							                if (_$futureStartEndDate.hasClass("toggle-button-yes")) {
							                    coa.user.set('futureStartEndate', "yes");
							                    var _$startDate = $('#future-start-date'),_$endDate = $('#future-end-date');
							                    if (_$startDate.val() && _$startDate.val().length > 0) {
							                        coa.user.set('futureStartDate', _$startDate.val());
							                    }
							                    if (_$endDate.val() && _$endDate.val().length > 0) {
							                        coa.user.set('futureEndDate', _$endDate.val());
							                    }
							                } else {
							                    coa.user.set('futureStartEndate', "no");
							                }								            
							            } 
							        }
							        

							        coa.user.set('addressType', _selectedAddressType);
							        coa.user.set('addressLine1', _addressLine1);
							        coa.user.set('addressLine2', _addressLine2);
							        coa.user.set('addressLine3', _addressLine3);
							        if (coa.user.get('addressType') == "U.S") {
							            _newCountry = '';
							            _newCountryNme = '';
							            _newProvince = '';
							        } else {
							            _newCountry = $('#country-list-select').val();
							            _newCountryNme = $('#country-list-select option:selected').text();
							            if (_newCountry == "CA") {
							                _newProvince = $('#province').val() ? $('#province').val() : $('#province-list-select').val();
							            }
							        }

							        coa.user.set('newState', _newState);
							        coa.user.set('newZip', _newZip);
							        coa.user.set('newCIty', _newCity);
							        coa.user.set('newCountry', _newCountry);
							        coa.user.set('newCountryName', _newCountryNme);
							        coa.user.set('newProvince', _newProvince);
							        coa.user.set('changeType', $('input[name="changeType"]:checked').val());
							        coa.user.set('changeReason', $('input[name="changeReason"]:checked').val());
							        coa.user.set('fromBackButton', true);
							        
								}
							    var _addresTypeVal = _$addressUpdateType.val(), _mailingTypeVal = _$mailingType.val();
							    if (_$addressUpdateType.val() == "Mailing") {
							        if (_mailingTypeVal == "delete") {
							            coa.user.set('changeReason', "");
							            clearNewMailingAccountSelection();
							        }
							    } else if (_addresTypeVal == "Permanent") {
							        clearNewMailingAccountSelection();
							    } else if (_addresTypeVal == "Verify") {
							        coa.user.set('changeReason', "");
							        clearNewMailingAccountSelection();
							    }
							    function clearNewMailingAccountSelection() {
							        var _accounts = coa.user.get('accounts')
							        for (i = 0; i < _accounts.length; i++) {
							            var _acct = _accounts.at(i);
							            _acct.set("checked", false);
							        }
							    }
								return _proceed;

							} else {
								return _proceed;
							}
						},
						fetchClientOwnerDetails : function() {
							var _that = this;
							CLIENT_ID = coa.user.get('clId');
							var _url = BASE_URL + "Client(ctx='COLA.CL',id='"
									+ CLIENT_ID + "')";
							var _data = $.extend({
								$expand : 'clientPersonal'

							}, API_COMMON_DATA_BODY);
							Utils
									.get(
											_url,
											decodeURIComponent($.param(_data)),
											function(res) {
											    var _ownerClient = res.d;
											    
											    if (_that.getCustomerType(res) == "P") {
											        if (_ownerClient.personClient.clSfxTxt) {
											            if (/JR|SR|Senior|Junior/i.test(_ownerClient.personClient.clSfxTxt)) {
											                _ownerClient.personClient.clSfxTxt = Utils.lowerCase(_ownerClient.personClient.clSfxTxt);
											            }
											        }
													var _clientPersonal = _ownerClient.clientPersonal;
													try {
														if (_clientPersonal.usResStatCd == "F") {
															coa.user.set(
																	'isNRA',
																	true);
														} else {
															coa.user.set(
																	'isNRA',
																	false);
														}
													} catch (e) {
														console
																.log('client personal details fetch failed.');
													}

													coa.user.set(

                                                                    'name',

																	Utils.lowerCase(                                                                          
																			_ownerClient.personClient.clFirstNm
                                                                            + ' '
																			+ (_ownerClient.personClient.clMidNm ? _ownerClient.personClient.clMidNm.split("")[0] + " " : '')
																			+ _ownerClient.personClient.clLastNm
																			+ " "
                                                                    )
                                                                    

                                                                    + (_ownerClient.personClient.clSfxTxt ? _ownerClient.personClient.clSfxTxt + " " : "")
             
                                                                    + Utils.lowerCase((_ownerClient.personClient.clHrnfNm ? _ownerClient.personClient.clHrnfNm : ""))
                                                                );
												} else {
													coa.user
															.set(
																	'name',
																	_ownerClient.orgClient.orgNm);
												}
												coa.user.set('clId',
														_ownerClient.id);
												coa.user.set('id',
														_ownerClient.fmtId);
												coa.user.set('userType', _that
														.getCustomerType(res));
												coa.initialServiceCounter--;
												coa.appView
														.finalServiceSuccesshandler();

											},
											function(xhr) {
												console.log(xhr, "status");
												Utils.unlockForm();
												coa.initialServiceCounter--;
												var _errorCode = xhr.status;
												var _customMessage = 'errorCode:'
														+ _errorCode;
												if (_errorCode == "500"
														|| _errorCode == "502"
														|| _errorCode == "503") {
													_customMessage = _errorCode
															+ 'Fatal';
												} else if (_errorCode == "401") {
													_customMessage = _errorCode
															+ 'Unauthorized';
												}
												Utils
														.showSystemUnavailabelError(xhr,true);
												coa.initialServiceErrorCounter++;
												coa.appView
														.finalServiceSuccesshandler();
											}, -1);
							// passing -1 max age
						},
						fetchActiveGrps : function() {
							CLIENT_ID = coa.user.get('clId');
							var _url = BASE_URL + "Client(ctx='COLA.CL',id='"
									+ CLIENT_ID + "')/activeGroups";
							var _data = $.extend(API_COMMON_DATA_BODY, {});
							Utils
									.get(
											_url,
											decodeURIComponent($.param(_data)),
											function(res) {
												Array.min = function(array) {
													return Math.min.apply(Math,
															array);
												};
												var _householdGrps = res.d.results;
												var _activeGrpIdArray = [], _actvGrpId, _activeHouseholdGrp = {};
												for ( var i = 0; i < _householdGrps.length; i++) {
													var _grp = _householdGrps[i];
													_activeGrpIdArray
															.push(Number(_grp.id));
												}
												try {
													_actvGrpId = Array
															.min(_activeGrpIdArray);
													_activeHouseholdGrp = _householdGrps[_activeGrpIdArray
															.indexOf(_actvGrpId)];
													if (_activeHouseholdGrp) {
														coa.activeGrpId = _activeHouseholdGrp.id;
														coa.activeGrpFmtId = _activeHouseholdGrp.fmtId;
														coa.appView
																.fetchClients(coa.activeGrpId);
													} else {
														Utils.unlockForm();
														var _message = 'No active groups found:inside try block, fmid:'
															+ FM_ID
															+ ', clientd id:'
															+ CLIENT_ID
															+ ', Response:'
															+ JSON
																	.stringify(_householdGrps)
														var _error = {
																message : "COA - No active groups",
																url:_url,
																lineNum : 1,
																stack:_message
														};
														Utils.showSystemUnavailabelError(_error,false,true);
													}
												} catch (e) {
													Utils.unlockForm();
													var _message = 	'No active groups found:inside catch block, fmid:'
														+ FM_ID
														+ ', clientd id:'
														+ CLIENT_ID
														+ ', Response:'
														+ JSON
																.stringify(_householdGrps);
													var _error = {
														message : "COA - No active groups",
														url:_url,
														lineNum : 1,
														stack:_message
													}; 
													Utils.showSystemUnavailabelError(_error,true,true);
													ErrorLog.ErrorUtils.myError(e);
												}

											},
											function(xhr) {
												console.log(xhr, "status");
												coa.initialServiceCounter--;
												Utils.unlockForm();
												coa.initialServiceErrorCounter++;
												var _errorCode = xhr.status;
												var _customMessage = 'errorCode:'
														+ _errorCode;
												if (_errorCode == "500"
														|| _errorCode == "502"
														|| _errorCode == "503") {
													_customMessage = _errorCode
															+ 'Fatal';
												} else if (_errorCode == "401") {
													_customMessage = _errorCode
															+ 'Unauthorized';
												}
												Utils
														.showSystemUnavailabelError(xhr,true);
												coa.appView
														.finalServiceSuccesshandler();
											}, -1);
							// passing -1 max age
						},
						fetchActiveAccountList: function (successCallback, doNotShowWarning) {
							filteredAccounts = [];
							CLIENT_ID = coa.user.get('clId');
							var _url = BASE_URL + "Client(ctx='COLA.CL',id='"
									+ (CLIENT_ID) + "')/clientAcctRoles";
							var _data = $.extend({
								$expand : 'acctCore'
							}, API_COMMON_DATA_BODY);
							coa.Accounts
									.fetch({
										reset : true,
										url : _url,
										data : decodeURIComponent($
												.param(_data)),
										success : function(a) {
											coa.accountsProcessCount = 0;
											if (coa.Accounts.length < 1) {
												coa.appView.showAccountEmptyOrgError();
											} else {
											    coa.appView.fetchActiveAccountDetails(successCallback, doNotShowWarning);
											}

										},
										error : function(a, jqXhr, _request) {
												Utils.unlockForm();
												Utils.showSystemUnavailabelError(jqXhr,true);
										},
										maxAge : -1

									});
						},
						fetchActiveAccountDetails: function (successCallback, doNotShowWarning) {
						    CLIENT_ID = coa.user.get('clId');
						    var _calCount = 0;
							var _this = this, _accounts = coa.user.get('accounts');
							coa.accountsErrorCount = 0;
							coa.accountsProcessCount = 0;
							for ( var i = 0; i < _accounts.length; i++) {
								(function(indx) {
								    var _account = _accounts.at(indx);
									var _url = BASE_URL+ "Accounts(ctx='COLA.ACCT',id='"+ _account.get('accountId') + "')/";
									var _data = $.extend({$expand : 'accountRegistration,accountPostalAddress,accountProduct'	}, API_COMMON_DATA_BODY);
									Utils.get(_url,decodeURIComponent($.param(_data)),
													function(res) {
														coa.accountsProcessCount++;
														var _results = res.d;
														var _address = _results.accountPostalAddress, _acctType = '';
														if (_address.clId == coa.user.get('clId')) {
															_account.set('addrSeqNum',_address.addrSeqNum);
															try {
																if (_results.accountRegistration.legalTitle1Txt
																		&& _results.accountRegistration.legalTitle2Txt) {
																	_account.set('ownership',_results.accountRegistration.legalTitle1Txt+ ' '+ _results.accountRegistration.legalTitle2Txt);

																} else {
																	if (_results.accountRegistration.legalTitle1Txt) {
																		_account.set('ownership',_results.accountRegistration.legalTitle1Txt);
																	} else if (_results.accountRegistration.legalTitle2Txt) {
																		_account.set('ownership',_results.accountRegistration.legalTitle2Txt);
																	} else {
																		_account.set('ownership','Not available');
																	}
																}

															} catch (e) {
																_account.set('ownership','Not available');
															}
															try {
																_acctType = _results.accountProduct;
																if (_acctType.mediumNm) {
																	_account.set('type',_acctType.mediumNm);
																} else {
																	_account.set('type','Not available');

																}

															} catch (e) {
																_account.set('type','Not available');
															}

															_account.set('addrLn1',(_address.addrLn1 || ''));
															_account.set('addrLn2',(_address.addrLn2 || ''));
															_account.set('addrLn3',(_address.addrLn3 || ''));
															_account.set('ctyNm',(_address.ctyNm || ''));
															_account.set('stCd',(_address.stCd || ''));
															_account.set('cntryCd',(_address.cntryCd || ''));
															_account.set('postlCd',(_address.postlCd || ''));
															_account.set('currentAddress',
																			_account.get('addrLn1')
																					+ ', '
																					+ (_account.get('addrLn2') ? (_account.get('addrLn2') + ', '): '')
																					+ (_account.get('addrLn3') ? (_account.get('addrLn3') + ', '): '')
																					+ _account.get('ctyNm')
																					+ ' '
																					+ _account.get('stCd')
																					+ ' '
																					+ _account.get('postlCd'));

															_account.set('currentAddressModify',
																			_account.get('addrLn1')+ ', '
																					+ (_account.get('addrLn2') ? (_account.get('addrLn2') + ', '): '')
																					+ (_account.get('addrLn3') ? (_account.get('addrLn3') + ', '): '')
																					+ _account.get('ctyNm'));
															filteredAccounts.push(_account);
															_this.accountDetailsSuccess(successCallback, doNotShowWarning);
														} else {
														    _this.accountDetailsSuccess(successCallback, doNotShowWarning);
														}
													},
													function(xhr) {
														coa.accountsProcessCount++;
														coa.accountsErrorCount++;
														_this.accountDetailsSuccess(successCallback, doNotShowWarning);
														ErrorLog.ErrorUtils.myError(xhr, true);
													}, -1);
									// passing max age -1
								})(i);

							}
						},
						accountDetailsSuccess: function (successCallback, doNotShowWarning) {
							if (coa.accountsProcessCount == coa.validAccountsCount) {
							    if (coa.accountsErrorCount != coa.validAccountsCount) {
							        coa.user.set("mailingAcctAddresError", false);
							        coa.user.set('accounts', filteredAccounts);
							        if (filteredAccounts.length == 0) {
							            if (successCallback) {
							                successCallback();
							            } else {
							                coa.appView.showAccountEmptyOrgError();
							            }
							        } else {
							            if (successCallback) {
							                successCallback();
							            } else {
							                if (!coa.accountView) {
							                    coa.accountView = new coa.views.accountView(
                                                        {
                                                            el: $("table.account-list-table tbody")
                                                        });
							                } else {
							                    coa.accountView.render();
							                }
							                coa.appView.renderDeleteMailingAddressList();
							            }

							            Utils.unlockForm();
							            Utils.hideSystemUnavailabelError();
							            if (coa.accountsErrorCount > 0) {
							                coa.user.set("mailingAcctAddresError", true);
							                if (!doNotShowWarning) {
							                    Utils.showSystemWarningError();
							                }
							            }
							        }
							    } else {
							        coa.user.set("mailingAcctAddresError", false);
							        Utils.showSystemUnavailabelError(null, true);
							        coa.Accounts.reset();
							    }

							}
						},
						getCustomerType : function(resp) {
							var custTypeInfo = {};
							if (resp.d.customerTypeCd.toLocaleLowerCase() == "o") {
								return "O";
							} else {
								return "P";
							}
						},
						resetModel: function () {
						    this.set({
						        "city": "",
						        "state": "",
						        "zipCode": "",
						        "changeType": "",
						        "changeReason": "",
						        "isNRA": false,
						        "existingAddress": false,
						        "eNewState": "",
						        "eAddressLine1": "",
						        "eAddressLine2": "",
						        "eAddressLine3": "",
						        "eNewZip": "",
						        "eNewCIty": "",
						        "existingAddress":false,
						        "existingAddressIndex":-1,
						        "addressLine1": "",
						        "addressLine2": "",
						        "addressLine3": "",
						        "newState": "",
						        "newZip": "",
						        "newCIty": "",
						        "newCountry": "",
						        "newCountryName": "",
						        "newProvince": "",
						        "mailingType": "new",
						        "deleteAddresSeqNum": null,
						        "futureStartEndate": null,
						        "futureStartDate": null,
						        "futureEndDate": null,
                                "mailingAcctAddresError":false
						    });
						}
					});
			coa.user = new coa.models.User({
				submitterId : null,
				advisorName : null,
				id : null,
				name : null,
				address : coa.addressList,
				addressType : 'U.S',
				city : null,
				state : null,
				zipCode : null,
				changeType : 'Permanent',
				clients : coa.Clients,
				changeReason : '',
				fromBackButton : false,
				number : 'number',
				text : 'text',
				isNRA : false,
				existingAddress: false,
			    verifyAddresSeqNum:null,
			    verifyAddressConfirm: false,
			    verifyAddressType: null,
			    verifyAddressAccounts: [],
			    deleteAddressAccounts: [],
			    mailingType: "new",
			    "deleteAddresSeqNum": null,
			    "futureStartEndate": null,
			    futureStartDate: null,
			    futureEndDate: null,
			    caseId: null,
			    editCaseDetails: null,
			    eworkflowCaseCloseFailed: false,
                mailingAcctAddresError:false
			});
		});