/**
 * @ngdoc service
 * @name Common Service
 * @requires getPaymentDetailsSevice
 * @description
 *
 * - Get Payment Details JSON  / Method
 */

(function() {
    'use strict';

    angular.module('CSS.common').service('getPaymentDetailsSevice', ['$http', '$q', function($http, $q) {

        this.getPaymentDetails = function(queryData) {
            var deferred = $q.defer();
            var config;
            config = {
                method: 'post',
                url: 'http://localhost:9900/getPaymentDetails/getPaymentDetails',
                data: queryData,
            };

            $http(config)
                .success(function(data, status, headers, config) {
                    deferred.resolve(data);
                })
                .error(function(data) {
                    deferred.reject(data);
                });

            return deferred.promise;
        };        
        
    }]);

})();