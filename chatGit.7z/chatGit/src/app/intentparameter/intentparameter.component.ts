import { Component, Directive, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Parameter } from '../_models/parameter';
import { ModalDirective } from 'ng2-bootstrap';
import { DragulaModule, DragulaService } from 'ng2-dragula/ng2-dragula';
//import { PopoverModule } from 'ngx-popover';
import {AboutComponent} from '../about/about.component'
@Component({
  selector: 'intentparameter',
  templateUrl: './intentparameter.component.html',
  styleUrls: ['./intentparameter.component.css'],
})

export class IntentparameterComponent implements OnInit {


  public radioModel: string = null;
  //public html:string = '<div style="color=black"><select><option>test</option><option>sfasf</option><option>adsfasdf</option><option>dadsfa</option></select></div>';
  editMode : boolean = true;
  paramTypes : Array<string> = [];
  currentParamMap : any = {};
  selectedParamName : string = null;
  paramList : Array<Parameter> = [];
  responseParameter : Array<Parameter> = [];
  allowAddition : boolean = false;
  editingParam : any = {};

  @ViewChild('respParamEditModal') public respParamEditModal:ModalDirective;

  constructor(private aiAssistCacheService: AIAssistCacheService, private dragulaService: DragulaService) {
    this.subscribefordata();
    this.initDragulaComponent();
  }

  ngOnInit() {
  }

  hideRespParamEditModal() {
    this.respParamEditModal.hide();
  }
 getDynamicInput(){  
    return AboutComponent;
}
  private subscribefordata() {
    this.aiAssistCacheService.activeParamListObservable.subscribe((data) => {
      this.paramTypes = data;
    });
    this.aiAssistCacheService.activeParamMapObservable.subscribe((data) => {
      this.currentParamMap = data;
      this.selectedParamName = null;
    });
    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });
  }

  private initDragulaComponent() {
    this.dragulaService.drag.subscribe((value) => {
      this.onDrag(value.slice(1));
    });
    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
    this.dragulaService.over.subscribe((value) => {
      this.onOver(value.slice(1));
    });
    this.dragulaService.out.subscribe((value) => {
      this.onOut(value.slice(1));
    });
  }

  public onResponseParamClick(param:any) {
    this.editingParam = param;
    this.respParamEditModal.show();
    // console.log(param);
  }

  private hasClass(el: any, name: string) {
    return new RegExp('(?:^|\\s+)' + name + '(?:\\s+|$)').test(el.className);
  }

  private addClass(el: any, name: string) {
    if (!this.hasClass(el, name)) {
      el.className = el.className ? [el.className, name].join(' ') : name;
    }
  }

  private removeClass(el: any, name: string) {
    if (this.hasClass(el, name)) {
      el.className = el.className.replace(new RegExp('(?:^|\\s+)' + name + '(?:\\s+|$)', 'g'), '');
    }
  }

  private onDrag(args) {
    let [e, el] = args;
    this.removeClass(e, 'ex-moved');
    // console.log("onDrag method");
    // console.log(args);
  }

  private onDrop(args) {
    let [e, el] = args;
    this.addClass(e, 'ex-moved');
    // console.log("onDrop method");
    // console.log(args);
    // console.log(this.responseParameter);
    if (args[1].id == "addedResponse") {
      if ( this.currentParamMap[this.selectedParamName].responseParameter == null || this.currentParamMap[this.selectedParamName].responseParameter == undefined ) {
        this.currentParamMap[this.selectedParamName].responseParameter = new Array<Parameter>();
      }
      //this.currentParamMap[this.selectedParamName].responseParameter.push({});
      // console.log("added to AddedResponse");
    } else {

      // console.log("removed from AddedResponse");
    }
  }

  private onOver(args) {
    let [e, el, container] = args;
    this.addClass(el, 'ex-over');
    // console.log("onOver method");
    // console.log(args);
  }

  private onOut(args) {
    let [e, el, container] = args;
    this.removeClass(el, 'ex-over');
    // console.log("onOut method");
    // console.log(args);
    // if(args[1].id == "addedResponse") {
    //   console.log("added to AddedResponse");
    // } else
    //   console.log("removed from AddedResponse");
  }

  public showParameter(paramType: any) {
    if ( this.selectedParamName != null && this.selectedParamName != undefined && this.responseParameter != null &&  this.responseParameter.length > 0 )
        this.currentParamMap[this.selectedParamName].responseParameter  = this.responseParameter;
    this.selectedParamName = paramType;
    this.paramList = this.currentParamMap[paramType].paramList;
    this.allowAddition = this.currentParamMap[paramType].allowAddition;
    this.editingParam = {};
    if (this.currentParamMap[paramType].isModified == null || this.currentParamMap[paramType].isModified == undefined)
      this.currentParamMap[paramType].isModified = false;
    if ( this.currentParamMap[this.selectedParamName].responseParameter == null || this.currentParamMap[this.selectedParamName].responseParameter == undefined ) {
      this.currentParamMap[this.selectedParamName].responseParameter = new Array<Parameter>();
    }
    this.responseParameter = this.currentParamMap[this.selectedParamName].responseParameter;
    for (var i = 0; i < this.paramList.length; i++) {
      this.getParsedValues(this.paramList[i]);
    }
  }

  onTextChange(pParameter: Parameter, pEvent: any) {
    if (pParameter.textValue !== pParameter.paramValue) {
      pParameter.isModified = true;
      pParameter.paramValue = pParameter.textValue;
      this.currentParamMap[this.selectedParamName].isModified = true;
      this.aiAssistCacheService.parametersModified(this.currentParamMap);
    }
  }

  onSelectChange(pParameter: Parameter, pEvent: any) {
    if (pParameter.selectValue !== pParameter.paramValue) {
      pParameter.isModified = true;
      pParameter.paramValue = pParameter.selectValue;
      this.currentParamMap[this.selectedParamName].isModified = true;
      this.aiAssistCacheService.parametersModified(this.currentParamMap);
    }
  }

  onRadioChange(pParameter: Parameter, pEvent: any) {
    if (pParameter.radioValue !== pParameter.paramValue) {
      pParameter.isModified = true;
      pParameter.paramValue = pParameter.radioValue;
      this.currentParamMap[this.selectedParamName].isModified = true;
      this.aiAssistCacheService.parametersModified(this.currentParamMap);
    }
  }

  onCheckValueChange(pParameter: Parameter, pEvent: any) {
    if (pParameter.paramValue == null || pParameter.paramValue == undefined) {
      pParameter.isModified = true;
      pParameter.paramValue = pParameter.checkValue == true ? "Y" : "N";
      this.currentParamMap[this.selectedParamName].isModified = true;
      this.aiAssistCacheService.parametersModified(this.currentParamMap);
    } else if ((pParameter.paramValue == "N" && pParameter.checkValue == true) || (pParameter.paramValue == "Y" && pParameter.checkValue == false)) {
      pParameter.isModified = true;
      pParameter.paramValue = pParameter.checkValue == true ? "Y" : "N";
      this.currentParamMap[this.selectedParamName].isModified = true;
      this.aiAssistCacheService.parametersModified(this.currentParamMap);
    }
  }

  public getParsedValues(pParameter: Parameter) {
    if (pParameter != null && pParameter != undefined) {
      if (pParameter.fieldType == "select") {
        if (pParameter.parsedFieldValues == null || pParameter.parsedFieldValues == undefined || (pParameter.parsedFieldValues != null && pParameter.parsedFieldValues.length == 0)) {
          pParameter.parsedFieldValues = [];
          var data = pParameter.fieldValues.replace("[", "").replace("]", "");
          var arrData = data.split(",");
          for (var i = 0; i < arrData.length; i++) {
            var keyvalue = arrData[i].split(":");
            pParameter.parsedFieldValues.push({ id: keyvalue[0], label: keyvalue[1] });
          }
        }
        if (pParameter.selectValue == null || pParameter.selectValue == undefined)
          pParameter.selectValue = pParameter.paramValue;
      }
      if (pParameter.fieldType == "radio") {
        if (pParameter.parsedFieldValues == null || pParameter.parsedFieldValues == undefined || (pParameter.parsedFieldValues != null && pParameter.parsedFieldValues.length == 0)) {
          pParameter.parsedFieldValues = [];
          var arrData = pParameter.fieldValues.split(":");
          for (var i = 0; i < arrData.length; i++) {
            pParameter.parsedFieldValues.push({ id: arrData[i], label: arrData[i] });
          }
        }
        if (pParameter.radioValue == null || pParameter.radioValue == undefined)
          pParameter.radioValue = pParameter.paramValue;
      }
      if (pParameter.fieldType == "checkbox") {
        if (pParameter.checkValue == null || pParameter.checkValue == undefined)
          pParameter.checkValue = pParameter.paramValue == "Y" ? true : false;
      }
    }
    return pParameter.parsedFieldValues;
  }

}
