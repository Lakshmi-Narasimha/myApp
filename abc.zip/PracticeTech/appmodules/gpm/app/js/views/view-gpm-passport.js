﻿define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils',
     'appmodules/contactprofile/app/models/cpviewmodel',
    'text!appmodules/gpm/app/templates/gpmpassport.html', 
], function ($, _, Backbone, Utils, CPViewModel, PassportTemplate) {
    var passport = Backbone.View.extend({
        el: $("#gpm-form-update-field-container"),
        id: 'gpm-form-update-field-container',
        events: {
            
         //   'keypress #cd-passport-number': 'numValidator',
        },
        template: _.template(PassportTemplate),
        initialize: function (data) {
            this.data = data;

        },
        render: function (updateMode) {
            try {
                var self = this;
                if (!this.model.get('currentItemSet')) {
                    var CPData = CPViewModel.getInstance().getData();
                   
                    this.data.fieldsInfo = { passport: ((CPData.cola && CPData.cola.clientPersonal) ? CPData.cola.clientPersonal.get('psprtNbr') : "") }
                    this.model.setCurrentValue(updateMode, { data: this.data });
                }

                var _dataSet = this.model.get('items');
                $("#" + this.id).html(this.template({ data: _dataSet }));

                //var passport = self.data.fieldsInfo.passport;
                //this.$el.html(this.template({ data: this.data })).promise().done(function () {
                //    $("#cd-passport-number").val(passport);
                //});
                //this.model.setCurrentValue(updateMode, { data: this.data });
            }
            catch (error) {
                console.log(error);
            }
        },

        validateAndNavigateFromStep1: function () {
            if (this.model.validate('gpm-update-form', true)) {
                this.model.setChangedValue();
                if(this.model.getChangedItems().length>0){
                	$('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                }else{
                	Utils.showNoChangesMessageToUser();
                }
                
            }
        },
        numValidator: function (obj) {
            var _regxNumOnly = /^\d*$/;
            var _str = String.fromCharCode(event.keyCode);
            var _maxlength = obj.currentTarget.maxLength;
            var _value = obj.currentTarget.value;
            if (!_regxNumOnly.test(_str)
                    || _value.length >= _maxlength) {
                obj.stopPropagation();
                if (event.preventDefault)
                    event.preventDefault();
                return false;
            }
        },

    });
    return passport;
});