﻿define(['jquery', 'underscore', 'backbone', 'services/dataservice', 'errorLog', 'appcommon/globalcontext', 'spinner', 'appmodules/contactprofile/cpcommon',
    'appmodules/contactprofile/app/models/cpviewmodel', 'appcommon/groupui/app/views/groupuiview', 'appcommon/constants'],
		function ($, _, Backbone, DataService, ErrorLog, GlobalContext, Spinner, cpCommon, CPViewModel, GroupUi, constants) {
		    var loadModule = function () {
		        var self = this;
		        this.getAccounts = function () {

		        };
		        this.getCPData = function (successCallback, errorCallback) {
		            var _successCallbackResponse = {};
		            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
		            var _clientId = _gContext.ContactId, _serviceCallsStack = [], eBixcontactDetails;
		            //Service stack for main sections
		            _serviceCallsStack.push(DataService.getClientPersonal(_clientId, constants.clientPersonalMaxAgeVal/*max age value*/));
		            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
		            if (_isNonCMuser == false) {
		                _serviceCallsStack.push(DataService.getContactDetailsbyClientId(cpCommon.readCookie('FMID'), _clientId));
		            }

		            Spinner.show();
		            //Queuing the service requests
		            Q.allSettled(_serviceCallsStack).then(function (response) {
		                if (response && response.length > 0) {
		                    _serviceCallsStack = [];
		                    gototClientPersonalSuccess(response);
		                }
		            }).fail(function (error) {
		                Spinner.hide();
		                ErrorLog.ErrorUtils.myError(error);
		                if (errorCallback) {
		                    errorCallback();
		                }
		            });

		            function gototClientPersonalSuccess(response) {
		                var _serviceCallsStack = [], _clientPersonal, _contactDetails;
		                var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
		                try {
		                    if (response && response.length > 0) {
		                        _clientPersonal = response[0]['value'];
		                        if (_isNonCMuser == false) {
		                            _contactDetails = response[1]['value'] ? response[1]['value'] : null;
		                        }
		                    }
		                    _successCallbackResponse.clientPersonalResponse = response;
		                    _serviceCallsStack.push(DataService.getContactprofileInfo(_clientId, constants.clientMaxAgeVal));		                    
		                    if (_contactDetails && _contactDetails[0] && _contactDetails[0].attributes && _contactDetails[0].attributes.contactId) {
		                        self.contactId = _contactDetails[0].get('contactId');
		                        if (_isNonCMuser == false) {
		                            _serviceCallsStack.push(DataService.getNonClientEbixDetails(cpCommon.readCookie('FMID'), _contactDetails[0].get('contactId')));
		                        }
		                    }
		                    Spinner.show();
		                    Q.allSettled(_serviceCallsStack).then(function (response) {
		                        if (response && response.length > 0) {
		                            _serviceCallsStack = [];
		                            gototClientProfileSuccess(response);
		                        }

		                    }).fail(function (error) {
		                        Spinner.hide();
		                        ErrorLog.ErrorUtils.myError(error);
		                        if (errorCallback) {
		                            errorCallback();
		                        }
		                    });
		                    function gototClientProfileSuccess(profileResponse) {
		                        _successCallbackResponse.clientProfileResponse = profileResponse;
		                        if (profileResponse && profileResponse.length > 0) {
		                            var clientInfo = profileResponse[0]['value'];		                          
		                            if (profileResponse[1] && profileResponse[1]['value']) {
		                                eBixcontactDetails = profileResponse[1]['value'];
		                            }
		                            if (clientInfo != undefined && clientInfo[0] != undefined && _clientPersonal != undefined && _clientPersonal[0] != undefined) {
		                                if ((clientInfo[0].get('clientPersonal').attributes == undefined) || (clientInfo[0].get('id') != clientInfo[0].get('clientPersonal').get('clId'))) {
		                                    clientInfo[0].set({ 'clientPersonal': _clientPersonal[0] }, { silent: true });
		                                }
		                                var data = {};
		                                CPViewModel.getInstance().clearData();
		                                data.cola = clientInfo[0].toJSON();
		                                CPViewModel.getInstance().setData({ 'cola': data.cola });
		                                data.ebix = {};
		                                if (eBixcontactDetails) {
		                                    data.ebix = eBixcontactDetails[0].toJSON();
		                                    CPViewModel.getInstance().setData({ 'ebix': data.ebix });
		                                }
		                                data.cola.personClient.attributes.clSfxTxt = data.cola.personClient.attributes.clSfxTxt || null;
		                                if (data.cola.personClient.attributes.clMidNm !== 'undefined' && data.cola.personClient.attributes.clMidNm !== "null" && data.cola.personClient.attributes.clMidNm !== null) {
		                                    practicetech.clientContext.setCaplistFullName(data.cola.personClient.attributes.clFirstNm + ':' + data.cola.personClient.attributes.clMidNm + ':' + data.cola.personClient.attributes.clLastNm + ':' + data.cola.personClient.attributes.clSfxTxt);
		                                } else {
		                                    practicetech.clientContext.setCaplistFullName(data.cola.personClient.attributes.clSfxTxt);
		                                }		                               
		                            }
		                            successCallback(_successCallbackResponse);
		                        }

		                    }
		                } catch (e) {
		                    Spinner.hide();
		                    ErrorLog.ErrorUtils.myError(e);
		                    if (errorCallback) {
		                        errorCallback();
		                    }
		                }
		            }
		        };
		        this.getAccountsAndSaveToModel = function () { };
		    }
		    return new loadModule();
		});