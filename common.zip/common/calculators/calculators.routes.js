'use strict';

function calculatorsRoutes($stateProvider) {
    var sipcalculator = {
        name: 'sipcalculators', // state name
        url: '/sipcalculators', // url path that activates this state
        template: require('./sipcalculator/sipCalculator.html'),
        controller: 'sipCalculatorController',
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'SIP Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here' // meta description in <head>
        }
    };

    var lumpsumcalculator = {
        name: 'lumpsumcalculators', // state name
        url: '/lumpsumcalculators', // url path that activates this state
        template: require('./lumpsumcalculator/lumpsumCalculator.html'),
        controller: 'lumpsumCalculatorController',
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Lumpsum Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here' // meta description in <head>
        }
    };

    var comparissioncalculator = {
        name: 'comparissioncalculators', // state name
        url: '/comparissioncalculators', // url path that activates this state
        template: require('./comparissioncalculator/comparissionCalculator.html'),
        controller: 'comparissionCalculatorController',
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Comparission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here' // meta description in <head>
        }
    };

     var sip = {
        parent: 'comparissioncalculators',
        name: 'comparissioncalculators.sip', // state name
        url: '/sip', // url path that activates this state       
        views: {
            'comparissioncalculatorrouter': {
                template: require('./comparissioncalculator/components/sip/sip.html'),
                controller: 'siptabController'
            }
        }
    };
   
    var lumpsum = {
        parent: 'comparissioncalculators',
        name: 'comparissioncalculators.lumpsum', // state name
        url: '/lumpsum', // url path that activates this state
        views: {
            'comparissioncalculatorrouter': {       
                template: require('./comparissioncalculator/components/lumpsum/lumpsum.html'),
                controller: 'lumpsumtabController'
              }
        }
    };

  
    var taxadvantagecalculator = {
        name: 'taxadvantagecalculators', // state name
        url: '/taxadvantagecalculators', // url path that activates this state
        template: require('./taxadvantagecalculator/taxAdvantageCalculator.html'),
        controller: 'taxAdvantageCalculatorController',
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Tax Advantage Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here' // meta description in <head>
        }
    };
    var commissioncalculator = {
        name: 'commissioncalculators', // state name
        url: '/commissioncalculators', // url path that activates this state
        template: require('./commissioncalculator/commissionCalculator.html'),
        controller: 'commissionCalculatorController',
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Commission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here' // meta description in <head>
        }
    };

     var commissionSip = {
        parent: 'commissioncalculators',
        name: 'commissioncalculators.sip', // state name
        url: '/sip', // url path that activates this state       
        views: {
            'commissioncalculatorrouter': {
                template: require('./commissioncalculator/components/sip/sip.html'),
                controller: 'commissionSipController'
            }
        }
    };
   
    var commissionLumpsum = {
        parent: 'commissioncalculators',
        name: 'commissioncalculators.lumpsum', // state name
        url: '/lumpsum', // url path that activates this state
        views: {
            'commissioncalculatorrouter': {       
                template: require('./commissioncalculator/components/lumpsum/lumpsum.html'),
                controller: 'commissionLumpsumController'
              }
        }
    };

/*
*   Advisor Routing for Calculators
*/

    var simulators = {
        parent: 'home',
        name: 'simulators', // state name
        url: 'simulators', // url path that activates this state
        views: {
            'dashboard@home': {       
                template: require('./components/simulators/simulators.html'),
                controller: 'simulatorsController'
              }
        }
    };

    var sipcalculatorAdvisor = {
        parent: 'home',
        name: 'sipcalculator', // state name
        url: 'sipcalculator', // url path that activates this state
        
        views : {
            'dashboard@home' : {
                template: require('./sipcalculator/sipCalculator.html'),
                controller: 'sipCalculatorController'
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'SIP Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };

    var lumpsumcalculatorAdvisor = {
        parent: 'home',
        name: 'lumpsumcalculator', // state name
        url: 'lumpsumcalculator', // url path that activates this state
        views : {
            'dashboard@home' : {
                template: require('./lumpsumcalculator/lumpsumCalculator.html'),
                controller: 'lumpsumCalculatorController'
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Lumpsum Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };

    var taxadvantagecalculatorAdvisor = {
        parent: 'home',
        name: 'taxadvantagecalculator', // state name
        url: 'taxadvantagecalculator', // url path that activates this state
        views : {
            'dashboard@home' : {
                template: require('./taxadvantagecalculator/taxAdvantageCalculator.html'),
                controller: 'taxAdvantageCalculatorController'
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Tax Advantage Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };

    var comparissioncalculatorAdvisor = {
        parent : 'home',
        name: 'comparissioncalculator', // state name
        url: 'comparissioncalculator', // url path that activates this state
        views : {
            'dashboard@home' : {
                template: require('./comparissioncalculator/comparissionCalculator.html'),
                controller: 'comparissionCalculatorController'
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Comparission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };

     var sipAdvisor = {
        parent: 'comparissioncalculator',
        name: 'comparissioncalculator.sip', // state name
        url: '/sip', // url path that activates this state       
        views: {
            'comparissioncalculatorrouter': {
                template: require('./comparissioncalculator/components/sip/sip.html'),
                controller: 'siptabController'
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Comparission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };
   
    var lumpsumAdvisor = {
        parent: 'comparissioncalculator',
        name: 'comparissioncalculator.lumpsum', // state name
        url: '/lumpsum', // url path that activates this state
        views: {
            'comparissioncalculatorrouter': {       
                template: require('./comparissioncalculator/components/lumpsum/lumpsum.html'),
                controller: 'lumpsumtabController'
              }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Comparission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };

    var commissioncalculatorAdvisor = {
        parent : 'home',
        name: 'commissioncalculator', // state name
        url: 'commissioncalculator', // url path that activates this state
        views : {
            'dashboard@home' : {
                template: require('./commissioncalculator/commissionCalculator.html'),
                controller: 'commissionCalculatorController'    
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Commission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };

     var commissionSipAdvisor = {
        parent: 'commissioncalculator',
        name: 'commissioncalculator.sip', // state name
        url: '/sip', // url path that activates this state       
        views: {
            'commissioncalculatorrouter': {
                template: require('./commissioncalculator/components/sip/sip.html'),
                controller: 'commissionSipController'
            }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Commission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };
   
    var commissionLumpsumAdvisor = {
        parent: 'commissioncalculator',
        name: 'commissioncalculator.lumpsum', // state name
        url: '/lumpsum', // url path that activates this state
        views: {
            'commissioncalculatorrouter': {       
                template: require('./commissioncalculator/components/lumpsum/lumpsum.html'),
                controller: 'commissionLumpsumController'
              }
        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'home', // assign a page-specific class to the <body> tag
            pageTitle: 'Commission Calculators', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here', // meta description in <head>,
            isAdvisor : 'true'
        }
    };


    $stateProvider
    .state(sipcalculator)
    .state(lumpsumcalculator)
    .state(comparissioncalculator)
    .state(taxadvantagecalculator)
    .state(sip)
    .state(lumpsum)
    .state(commissioncalculator)
    .state(commissionSip)
    .state(commissionLumpsum)
    .state(simulators)
    .state(sipcalculatorAdvisor)
    .state(lumpsumcalculatorAdvisor)
    .state(taxadvantagecalculatorAdvisor)
    .state(comparissioncalculatorAdvisor)
    .state(sipAdvisor)
    .state(lumpsumAdvisor)
    .state(commissioncalculatorAdvisor)
    .state(commissionSipAdvisor)
    .state(commissionLumpsumAdvisor)
    ;
}

calculatorsRoutes.$inject = ['$stateProvider'];
module.exports = calculatorsRoutes;