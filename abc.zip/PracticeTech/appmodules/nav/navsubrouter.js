﻿// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'backbonesubroute',
  'appcommon/memmorymgr',
  'appmodules/nav/app/views/home',
   'appmodules/nav/app/views/navcontainerview',
   'appmodules/nav/app/views/contactlistview',
   'appmodules/nav/app/views/prospectlistview',
   'appmodules/nav/app/views/draftsview',
   'appmodules/nav/app/views/addprospectview',
   'appmodules/nav/app/views/editcontactview',
   'appmodules/nav/app/models/contactdetails',
   'appcommon/globalcontext',
], function ($, _, Backbone, Spinner, backbonesubroute, MemmoryMgr, Home, NavContainerView, ContactListView, ProspectListView, DraftsView, AddprospectView, EditcontactView, ContactDetailsModel, GlobalContext) {
    var navRouter = Backbone.SubRoute.extend({
        routes: {
            'contactlist': 'showContactList',
            'prospectlist': 'showProspectList',
            'draftspage': 'showDraftsPage',
            'addcontact': 'showAddProspect',
            'editcontact/:contactId': 'showEditContact',
            "": 'defaultAction',
        },
        initialize:function(params){
        	this.params = (params || {});
        	this.homeView = null;
        },
        defaultAction: function () {
            console.log("Navsubrouter default action>>>>>>>>>>>>>>>>>>>");
        	if(!this.homeView){
        		this.homeView = new Home(this.params); 
        	}
        	// MemmoryMgr.setcurrentview(home); 
        	this.homeView.render(); 
        	MemmoryMgr.setcurrentview(undefined);
            /*var navContainerView = new NavContainerView();
            MemmoryMgr.setcurrentview(navContainerView);
            navContainerView.render();*/
        },
        showContactList: function () {
            var advisorId = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
            var isContactSearchDynamic = ContactDetailsModel.advsiorContacts.getContactSearchType(advisorId);
            var contactListView = new ContactListView();
            MemmoryMgr.setcurrentview(contactListView);
            contactListView.render();
        },
        showProspectList: function () {
            var prospectListView = new ProspectListView();
            MemmoryMgr.setcurrentview(prospectListView);
            prospectListView.render();
        },
        showDraftsPage: function () {           
            var draftsView = new DraftsView();
            MemmoryMgr.setcurrentview(draftsView);
            draftsView.render();
        },
        showAddProspect : function () {
        	var addprospectView = new AddprospectView();
        	MemmoryMgr.setcurrentview(addprospectView);
        	addprospectView.render();
        },
        showEditContact: function (contactId) {
            var editcontactView = new EditcontactView();
            MemmoryMgr.setcurrentview(editcontactView);
            editcontactView.render(contactId);
        }
    });
    return { navRouter: navRouter };
});
