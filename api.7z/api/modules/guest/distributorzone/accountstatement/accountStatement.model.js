// accountStatement.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AccountStatementSchema = new mongoose.Schema({
    accountStatementObject: {
        type: Array,
        "default": []
    }
});

var AccountStatementLookUp = mongoose.model('AccountStatementLookUp', AccountStatementSchema);

var AccountStatementModel = new AccountStatementLookUp({

  accountStatementObject: {
	  "accountStatementDetails": [
	    {
	      "Name": "Shankar Narayanan",
	      "AccountNo": 9039758625,
	      "folioNo": 3456572,
	      "email": "shankarnarayanan@gmail.com",
	      "mobile": 9039758625,
	      "pan": "ABCD1234KL"
	    },
	    {
	      "Name": "Shankar BK",
	      "AccountNo": 3429758625,
	      "folioNo": 3896503,
	      "email": "shankar.bk@gmail.com",
	      "mobile": 9049758635,
	      "pan": "MKLK1234IJ"
	    },
	    {
	      "Name": "Shankar Bansal",
	      "AccountNo": 4219758625,
	      "folioNo": 2648571,
	      "email": "shankar.bansal@gmail.com",
	      "mobile": 9059758645,
	      "pan": "OIUH1234GH"
	    },
	    {
	      "Name": "Shankar S",
	      "AccountNo": 5679758625,
	      "folioNo": 3494892,
	      "email": "shankar.s@gmail.com",
	      "mobile": 9069758655,
	      "pan": "ELKI1234EF"
	    },
	    {
	      "Name": "Shankar KL",
	      "AccountNo": 5679758564,
	      "folioNo": 8987647,
	      "email": "shankar.kl@gmail.com",
	      "mobile": 9079758665,
	      "pan": "GFRW1234CD"
	    },
	    {
	      "Name": "Shankar Das",
	      "AccountNo": 5679758521,
	      "folioNo": 4098263,
	      "email": "shankar.das@gmail.com",
	      "mobile": 9089758675,
	      "pan": "PDVB1234AB"
	    }
	  ]
	}
});

AccountStatementLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AccountStatementLookUp table, please contact admin...');
    } else {
        AccountStatementLookUp.remove({}, function(err) {
            console.log('AccountStatementLookUp collection removed');
            AccountStatementModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AccountStatementLookUp table, please contact admin...');
                }
                console.log('AccountStatementLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AccountStatementLookUp;
