/**
 * @ngdoc service
 * @name advisor alerts model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Setting the default $cacheFactory options for http call
 *
 */
 'use strict';

 var comparisonCalculatorModel = function (Restangular, $q, fticLoggerMessage, loggerConstants,authenticationService,toaster) {
    var _comparisonCalculation = null,
    _fundDetails = null;
    var comparisonCalculatorModel = {

        callComparisonCalculatorData : function (params,isAdvisor) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.ADVISOR_ALERTS_MODEL + ' | callComparisonCalculatorData' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var body = params;
            var params = {};
            if(isAdvisor) {
                params = {

                    "guId" : authenticationService.getUser().guId,
                }
            }
            console.log(params);

            Restangular.one('smartsolution/comparisonCalculator').customPOST(body, "", params, {}).then(function (comparisoncalculations) {
                deferred.resolve(comparisoncalculations);
            }, function (resp) {
                deferred.reject(resp);
                toaster.error(resp.data[0].errorDescription);
                console.log('error');
            });
            return deferred.promise;
        },
        callFundDetailsData : function (isAdvisor) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.ADVISOR_ALERTS_MODEL + ' | CallFundDetails' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            var params = {};
            if(isAdvisor) {
                params = {
                    "groupId" : "FundsPerfCalc",
                    "guId": authenticationService.getUser() !== null ? authenticationService.getUser().guId : null
                }
            }
            else 
                params = {"groupId" : "FundsPerfCalc"};

            Restangular.one('services/paramCodes').get(params).then(function (comparisoncalculations) {
                deferred.resolve(comparisoncalculations);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setComparisonCalculations:function(comparisoncalculations){
            _comparisonCalculation = comparisoncalculations;

            console.log("the data", _comparisonCalculation);

        },
        getComparisonCalculations:function(){
            if(!angular.isDefined(_comparisonCalculation))
            {
                return null;
            }

            return _comparisonCalculation;
        },
        setFundDetails : function(fundDetails){
            _fundDetails = fundDetails;
        },
        getFundDetails : function(){
            if(!angular.isDefined(_fundDetails))
            {
                return null;
            }
            return _fundDetails;
        }

    };
    return comparisonCalculatorModel;
};

comparisonCalculatorModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService','toaster'];

module.exports = comparisonCalculatorModel;