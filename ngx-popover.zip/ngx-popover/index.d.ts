export * from "./Popover";
export * from "./PopoverContent";
export declare class PopoverModule {
}
