/**
 * @ngdoc property
 * @name ftictaxCalculatorForm Directive
 * @description
 *
 * ftictaxCalculatorChart directive 
 *
 **/
'use strict';

var fticCommissionCalculatorGrid = function($state,$timeout,eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, commissionCalculatorModel, taxCalculatorModel, calculatorsEventConstants, calculatorsConstants) {
	return {
        template: require('./commissionCalculatorGrid.html'),
        restrict: 'E',
        replace: true,
        scope:{},
        controller: function($scope, $element, $attrs){
            $scope.$on(calculatorsEventConstants.COMMISSION_CALCULATE_GRID, function(event){
            $scope.commissionGrid = {};
            $scope.commissionGridValues = [];
            $scope.fundName = commissionCalculatorModel.getCommissionCalculations().fundName;
            $scope.grossSaleValue = commissionCalculatorModel.getCommissionCalculations().grossSaleValue;
            var commissionResp = angular.copy(commissionCalculatorModel.getCommissionCalculations().returnData);
            $scope.formatGridArray(commissionResp);
            $scope.commissionGrid.columnDefs = [
            { field: 'year', displayName: $scope.fundName, width:"302", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'Upfront', displayName: 'Upfront 1st year', width:"241", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'Trail1', displayName: 'Trail 1st year', width:"241", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'Trail2', displayName: 'Trail 2nd year onwards', width:"241", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false},
            ];                
           });

            $scope.formatGridArray = function (commissionResp) {
                for(var grid=0, len = commissionResp.length; grid<len; grid++) {
                    if(commissionResp[grid].commissionType == 'Upfront'){
                        $scope.commissionGridValues[0] = {"year" : "Commission Rate", "Upfront": commissionResp[grid].commisionRate + "%"};
                        $scope.commissionGridValues[1] = {"year" : "Commission Amount", "Upfront": commissionResp[grid].commisionAmount};
                    }
                    else if (commissionResp[grid].commissionType == 'FirstYearTrail') {
                        $scope.commissionGridValues[0].Trail1 = commissionResp[grid].commisionRate + "%";
                        $scope.commissionGridValues[1].Trail1 = commissionResp[grid].commisionAmount;
                    }
                    else {
                        $scope.commissionGridValues[0].Trail2 = commissionResp[grid].commisionRate + "%";
                        $scope.commissionGridValues[1].Trail2 = commissionResp[grid].commisionAmount;   
                    }
                }
            }
             

            $scope.$on(calculatorsEventConstants.COMMISSION_RESET_DATA, function(event) {
         $scope.commissionGridValues = false;
          $scope.grossSaleValue = '';
     });
        },
        link: function(scope, element, attrs, ctrl){
        }
    };
};
fticCommissionCalculatorGrid.$inject = ['$state','$timeout','eventConstants','fticLoggerMessage', 'loggerConstants', '$cookies','authenticationService', 'commissionCalculatorModel','taxCalculatorModel', 'calculatorsEventConstants','calculatorsConstants'];
module.exports = fticCommissionCalculatorGrid;