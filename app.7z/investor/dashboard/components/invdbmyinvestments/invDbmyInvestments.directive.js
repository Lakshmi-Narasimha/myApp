/**
 * @ngdoc directive
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires investorEventConstants
 * @requires investorDashboardDetailsModel
 * @requires dashboardConstants
 * @requires filter
 * @requires investorDashboardConfig
 * @description
 *
 * - It displays the highchart bar for the types of fund investments and current cost, value accordingly.
 * 
 **/
'use strict';

var invDbMyInvestments = function(investorEventConstants, investorDashboardDetailsModel, dashboardConstants, $filter, investorDashboardConfig, loggerConstants, fticLoggerMessage) {
    return {
        restrict: 'AEC',
        template: require('./invDbmyInvestments.html'),
        replace: true,
        scope: true,
        controller: function($scope) {
            $scope.investmentsConfig = {
                header: { heading: dashboardConstants.dashboard.MY_INVESTMENTS, subContent: $filter('translate')(dashboardConstants.dashboard.FOR_PAN) },
                widgetClose: false,
                badge: false,
                currentData: []
            };

            $scope.isDataAvaiable = false;
            
            $scope.$on(investorEventConstants.Dashboard.INV_DB_INFO, function() {

                var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_MY_INVESTMENTS_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_INFO + ' event' /* Function Name */;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
                var panDetails = investorDashboardDetailsModel.getDashboardData().profileDetails;
                $scope.investmentsConfig.header.subContent = $scope.investmentsConfig.header.subContent + (panDetails && panDetails.pan ? ' ' + panDetails.pan : '');

                $scope.isDataAvaiable = investorDashboardDetailsModel.getDashboardData() ? investorDashboardDetailsModel.getDashboardData().myTransactions : false;

                if ($scope.isDataAvaiable) {
                    var investmentData = investorDashboardDetailsModel.getDashboardData().myTransactions;
                    var chartOptions = [],
                        chartCategories = [];
                    var chartColors = dashboardConstants.dashboard.INVEST_CHART_COLORS;

                    if (investmentData.fundValues && investmentData.fundValues.length > 0) {
                        angular.forEach(investmentData.fundValues, function(investmentFund, index) {
                            var fund = investmentFund.fund ? Number(($filter('fticInvStringToNumber')(investmentFund.fund) / 100000).toFixed(2)) : 0;
                            if(fund > 0) {
                                chartOptions.push({ y: fund, color: chartColors[index] });
                                chartCategories.push(investmentFund.fundCategory);
                            }
                        });
                    }

                    if(chartCategories.length > 0 || chartOptions.length > 0 ) {
                        $scope.chartOptions = investorDashboardConfig.chartConfig();
                        $scope.chartOptions.series[0].data = chartOptions;
                        $scope.chartOptions.xAxis.categories = chartCategories;
                    }

                    $scope.investmentsConfig.currentData = [{
                        'key': $filter('translate')(dashboardConstants.dashboard.CURRENT_COST),
                        'value': investmentData.currentCost,
                        'isRupee': true
                    }, {
                        'key': $filter('translate')(dashboardConstants.dashboard.CURRENT_VALUE),
                        'value': investmentData.currentValue,
                        'isRupee': true
                    }];
                }

            });
        }
    };
};

invDbMyInvestments.$inject = ['investorEventConstants', 'investorDashboardDetailsModel', 'dashboardConstants', '$filter', 'investorDashboardConfig', 'loggerConstants', 'fticLoggerMessage'];
module.exports = invDbMyInvestments;
