'use strict';

describe('Directive: Smart Savings Account', function() {

	var compile, scope, validHtml;
    validHtml = '<ftic-inv-db-smart-savings-account></ftic-inv-db-smart-savings-account>';
     //load all modules, including the html template, needed to support the test

    var create = function(html) {
        var element = angular.element(html);
        var compiledElem = compile(element)(scope);
        //isoScope = directiveEle.isolateScope();
        scope.$digest();
        return compiledElem;
    };

    beforeEach(angular.mock.module('investor'));

    describe('TestSuite-1 for smartSavingsAccount Directive', function() {
        
        var mockDashboardDetailModelSuccess = {
            getSmartSaveAccAndOneTouchData: function() {
                return {
                    smartSavingsAccount: {
                        description:'<span></span>',
                        currentValue:'5000'
                    }
                };
            }
        };
        beforeEach(function() {
            angular.mock.module(function($provide) {
                $provide.value('investorDashboardDetailsModel', mockDashboardDetailModelSuccess);
            });
        });
        beforeEach(function() {

            angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            });
            
        });
        it('Directive should be defined', function() {
            var directiveEle = create(validHtml);
            expect(directiveEle).toBeDefined();
        });

        it('directive should be created with scope:true',function(){
            var directiveEle = create(validHtml);
            expect(directiveEle.scope()).toBeDefined();
        });

        it('Case-1 When no data is available for smartSavingsAccount',function(){
            var directiveEle = create(validHtml);
            expect(directiveEle.scope()).toBeDefined();
            expect(scope.isDataAvailable).toBeFalsy();
        });

        it('Case-2 When data is available for smartSavingsAccount',function(){
        
            var directiveEle = create(validHtml);
            var dirScope = directiveEle.scope();
            expect(directiveEle.scope()).toBeDefined();
            scope.$broadcast('investorSmartSavAccAndOneTouch');
            expect(dirScope.initData.description).toBe('<span></span>');
            expect(dirScope.isDataAvailable).toBeTruthy();
            expect(dirScope.isTransactionStarted).toBe('Y');
            expect(dirScope.initData.currentValue).toBe('5000');
	    });
    });

    describe('TestSuite-2 for smartSavingsAccount Directive', function() {
        
        var mockDashboardDetailModelFailure = {
            getSmartSaveAccAndOneTouchData: function() {
                return {
                    smartSavingsAccount: {
                        description:undefined,
                        currentValue:undefined
                    }
                };
            }
        };
        beforeEach(function() {
            angular.mock.module(function($provide) {
                $provide.value('investorDashboardDetailsModel', mockDashboardDetailModelFailure);
            });
        });
        beforeEach(function() {

            angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            });
            
        });
        it('Case-3 When data is available for smartSavingsAccount(when service got success but no data)',function(){
        
            var directiveEle = create(validHtml);
            var dirScope = directiveEle.scope();
            expect(directiveEle.scope()).toBeDefined();
            scope.$broadcast('investorSmartSavAccAndOneTouch');
            expect(dirScope.initData.description).toBeFalsy();
            expect(dirScope.initData.currentValue).toBeFalsy();
            expect(dirScope.isDataAvailable).toBeTruthy();
            expect(dirScope.isTransactionStarted).toBe('N');
	    });
    });

    describe('TestSuite-3 for smartSavingsAccount Directive', function() {
        
        var mockDashboardDetailModelSuccess = {
            getSmartSaveAccAndOneTouchData: function() {
                return {
                    smartSavingsAccount: {
                        description:'<span></span>',
                        currentValue:'0'
                    }
                };
            }
        };
        beforeEach(function() {
            angular.mock.module(function($provide) {
                $provide.value('investorDashboardDetailsModel', mockDashboardDetailModelSuccess);
            });
        });
        beforeEach(function() {

            angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            });
            
        });
        it('Case-4 When data is available for smartSavingsAccount with currentvalue 0',function(){
        
            var directiveEle = create(validHtml);
            var dirScope = directiveEle.scope();
            expect(directiveEle.scope()).toBeDefined();
            scope.$broadcast('investorSmartSavAccAndOneTouch');
            expect(dirScope.initData.description).toBe('<span></span>');
            expect(dirScope.isDataAvailable).toBeTruthy();
            expect(dirScope.isTransactionStarted).toBe('N');
            expect(dirScope.initData.currentValue).toBe('0');
	    });
    });
});