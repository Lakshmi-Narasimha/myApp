var express = require('express');
var https = require('https');
var logger = require('../../../config/logger');
var router = express.Router();
var agentAvailabilityModel = require('./agentAvailability.model');


// api route
router.route('/mfchat/rest/agent')
    .post(function(req, res) {
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        req.uri = agentAvailabilityModel.createRequestUri[req.body.RequestParams.agentGroupID];
        var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path,
            headers: {
                'Cookie': req.sessionCookie
            }
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            console.log(req.uri.path);
            proxyResponse.setEncoding('utf8');
            proxyResponse.on('data', function(chunk) {
                logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, chunk));
                chunk = JSON.parse(chunk);
                console.log(chunk);
                req.session.statusCounter = (req.session.statusCounter || 0);
                if (chunk.status === "offline") {
                    req.session.statusCounter++;
                }
                if (req.session.statusCounter > 5) {
                    agentAvailabilityModel.response.Page.agentBusy = true;
                }
                console.log("statusCounter", req.session.statusCounter);
                agentAvailabilityModel.response.Page.availability = chunk.availability;
                if (agentAvailabilityModel.response.Page.availability === true) {
                    agentAvailabilityModel.response.Page.inHOP = true;
                    agentAvailabilityModel.response.Page.status = "online";
                } else {
                    agentAvailabilityModel.response.Page.inHOP = chunk.inHOP;
                    agentAvailabilityModel.response.Page.status = chunk.status;
                }
                logger.outBoundData.info(logger.formatResMsg(req, agentAvailabilityModel.response));
                res.send(agentAvailabilityModel.response);
            });
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatResMsg(req, err));
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);

            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
