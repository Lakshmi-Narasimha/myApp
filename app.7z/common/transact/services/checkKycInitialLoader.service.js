'use strict';

var checkKycInitialLoader = function (checkKycModelService, transactEvents, transactEventConstants) {

    var checkKycInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope,param) {

            checkKycModelService.fetchCheckKyc(param)
                .then(checkKycSuccess, handleFailure);

            function checkKycSuccess(data) {
                //checkKycModelService.setCheckKycDtls(data[0].result[0]);
                checkKycModelService.setCheckKycDtls(data);
                transactEvents.transact.publishCheckKyc(scope);

            }

            function handleFailure(data){
                console.error('handleFailure');
                checkKycInitialLoader._isServicesData = false;
            }
        }

    };
    return checkKycInitialLoader;
};

checkKycInitialLoader.$inject = ['checkKycModelService', 'transactEvents', 'transactEventConstants'];

module.exports = checkKycInitialLoader;