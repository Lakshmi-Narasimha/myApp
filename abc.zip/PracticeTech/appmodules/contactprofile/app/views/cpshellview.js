define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appcommon/memmorymgr',
    'services/dataservice',
    'appcommon/globalcontext',
    'appcommon/groupui/app/views/groupuiview',
    'appmodules/contactprofile/app/views/contactprofileview',
    'appmodules/contactprofile/app/views/prospectview',
    'appmodules/contactprofile/app/views/preferencesview',
    'appmodules/contactprofile/app/views/fiduciaryview',
    'appmodules/contactprofile/app/views/beneficiaryview',
	'appmodules/contactprofile/app/views/bankview',
    'appcommon/analytics',
    'errorLog',
    'appcommon/commonutility',
    'appcommon/constants',
    'text!appmodules/contactprofile/app/templates/contactprofileshell.html',
    'text!appmodules/contactprofile/app/templates/prospectshell.html',
        'appmodules/contactprofile/app/models/cpviewmodel',
          'appcommon/nativeadaptor'
        
], function ($, _, Backbone, Spinner, MemmoryMgr, DataService, GlobalContext, GroupUi, ContactProfileView, ProspectView, PreferencesView, FiduciaryView, BeneficiaryView, BankView, Analytics, ErrorLog, CommonUtils, Constants, CPShellTemplate, ProspectShellTemplate, CPViewModel, NativeAdaptor) {

    var cpShellView = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        CPData : CPViewModel.getInstance().getData(),
        CPDataName: function () {
            this.CPData = this.CPData || {};
            var clientName = "";
            if (typeof this.CPData !== 'undefined' && typeof this.CPData.cola !== 'undefined' && typeof this.CPData.cola.personClient !== 'undefined') {
                if (this.CPData.cola.personClient.get("clLastNm")) {
                    clientName = this.CPData.cola.personClient.get("clLastNm") + ", " + this.CPData.cola.personClient.get("clFirstNm");
                } else {
                    clientName = this.CPData.cola.orgClient.get("orgNm");
                }
            }
            clientName = clientName || null;

            return clientName;
        },
        events: {
            "click .scrollToTop": "scrollButtonClick",
            "click .launch-smart-pad": "launchSmartPad",
            "click .goto-hoc": "gotoHoc",
            "click .add-new-activity" : "addNewActivity",
            "click #signDocument" : "signDocument",
            "click #convertToClientLink": "convertToClientLinkClicked",
            "click .view-smart-pad": "gotoViewSmartPad",
            "click .add-new-task": "addNewTask",
            "click .view-acct-list": "viewAcctList"
        },
        initialize: function () {
            this.CPData.ebix = this.CPData.ebix || {};
            this.CPData.ebix.id = this.CPData.ebix.id || null; 
        	this.clientId = null;
        	this.contactId = null;
        	this.globalcontext = GlobalContext.getInstance();
        },
        scrollButtonClick: function (e) {
            $('html, body').animate({ scrollTop: 0 }, 800);
            return false;
        },
        validateClientAndShowMsg: function () {
            //Read ContactId from CPData instead of making Ebix service call.
            if (typeof this.CPData !== 'undefined'
               && typeof this.CPData.ebix !== 'undefined'
               && typeof this.CPData.ebix.id !== 'undefined') {
                this.contactId = this.CPData.ebix.id;
            }
            if (!CommonUtils.isEbixContactId(this.clientId) && !this.contactId) {
                BootstrapDialog.alert("This client cannot be found in Contact Manager. The client might not have an active account or might be hidden. <a href='https://www.askameriprise.com/app/answers/detail/a_id/26890/kw/client%20not%20in%20contact%20manager' target='_blank'>Tell me more.</a>", "", "Client not found");
        	return false;
        	}
        	return true;
        },
        launchSmartPad: function () {
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                CommonUtils.toggleNonCMmsg("function");
                return;
            } else {
                Analytics.analytics.recordAction('contactProfile:newSmartPadNote:clicked');
                if (!NativeAdaptor.notifyNewNoteRequested()) {
                    if (this.validateClientAndShowMsg()) {
                        Backbone.history.navigate("#crm/addsmartpad", true);
                    }
                }
            }
           
        },
        gotoHoc: function () {
            Analytics.analytics.recordAction('contactProfile:goToInsights:clicked');
            Backbone.history.navigate("#hoc/", true);
        },
        viewAcctList: function () {
            Analytics.analytics.recordAction('contactProfile:ReviewAccounts:clicked');
            Backbone.history.navigate("#accountviewer/", true);
        },
        addNewActivity : function(){
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                CommonUtils.toggleNonCMmsg("function");
                return;
            } else {
                Analytics.analytics.recordAction('contactProfile:newAppointment:clicked');
                if (!NativeAdaptor.notifyNewActivityRequested(null, false)) {
                    Backbone.history.navigate("#crm/new-activity", true);
                }
            }
        },
        gotoViewSmartPad: function () {
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                CommonUtils.toggleNonCMmsg("function");
                return;
            }
            else {
                if (this.validateClientAndShowMsg()) {
                    Backbone.history.navigate("#crm/smartpad", true);
                } 
            }
        },
        addNewTask: function (e) {
            e.preventDefault();
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                CommonUtils.toggleNonCMmsg("function");
                return;
            }
            else {
                if (!NativeAdaptor.notifyNewActivityRequested(null, true)) {
                    Analytics.analytics.recordAction('contactProfile:addNewTask:clicked');
                }
                location.hash = "crm/addtask"
            }
        },
        signDocument : function(){
        	Analytics.analytics.recordAction('contactProfile:signDocument:clicked');
        },
        convertToClientLinkClicked : function(){
        	Analytics.analytics.recordAction('contactProfile:convertToClient:clicked');
        },
        getEsigDocsCount : function() {
            var _options = {
                fmId: parseInt(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID),
                clientId: GlobalContext.getInstance().getGlobalContext().Context.ContactId
            };
            DataService.geteSigDraftList(_options).then(function (response) {
                var _draftsList = response.esignatureDocument, _docCount = 0;
                if (_draftsList && _draftsList.length > 0) {
                    for (var i = 0; i < _draftsList.length; i++) {
                        if (_draftsList[i].documentStatus != "Completed") {
                            _docCount++;
                        }
                    }
                    if (_docCount != 0) {
                        $('#esig-doc-count').removeClass('hidden').text(_docCount);
                    } else {
                        $('#esig-doc-count').addClass('hidden');
                    }
                } else {
                    $('#esig-doc-count').addClass('hidden');
                }
            }).fail(function (err) {});
        },
        renderCorrespondingSubTab: function (subtab, params) {
            if ((CommonUtils.readCookie('firstLaunch') != null) && (CommonUtils.readCookie('firstLaunch') == 'True')) {
                var showMessage = true;
                if (CommonUtils.readCookie('CVShowAlert') != undefined && CommonUtils.readCookie('CVShowAlert') != null
                    && CommonUtils.readCookie('CVShowAlert') == 'No') {
                    showMessage = false;
                }
            }

        	switch(subtab){
        	case "preferences":
        		 var preferencesView = new PreferencesView();
                 MemmoryMgr.setcurrentview(preferencesView);
                 preferencesView.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
                 break;
			case "bank":
				var bankView = new BankView();
				MemmoryMgr.setcurrentview(bankView);
				bankView.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
				break;
        	case "beneficiary":
	        	var beneficiaryView = new BeneficiaryView();
	            MemmoryMgr.setcurrentview(beneficiaryView);
	            beneficiaryView.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
            break;
        	case "fiduciary":
        		var fiduciaryView = new FiduciaryView();
                MemmoryMgr.setcurrentview(fiduciaryView);
                fiduciaryView.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
            break;
        	case "contributions":
        		params.view.initializeIRAView(params);
        		params.view.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
            break;
        	case "distributions":
        		params.view.initializeIRAView(params);
        		params.view.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
            break;
        	case "iradetails":
        		params.view.renderDetails(params.index, params.type, params.view);
            break;
        	case "contactprofile":
        	default:
    			var contactPrflView = new ContactProfileView();
    			 MemmoryMgr.setcurrentview(contactPrflView);   
    			 contactPrflView.render(GlobalContext.getInstance().getGlobalContext().Context.ContactId);
        		break;
        	}
        },
        render: function (clId, subtab, params) {
        	this.clientId = clId;
        	var that = this;
        	var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
        	
        	if (GlobalContext.getInstance().getGlobalContext().Context.ContactType == Constants.contactType.NonClient){
        		Spinner.show();
        		DataService.getNonClientEbixDetails(CommonUtils.readCookie('FMID'), clId)
        		.then(function(response){
        				var compiledTemplate = _.template(ProspectShellTemplate);
        				if(response[0]){
        					that.$el.html(compiledTemplate(response[0].toJSON())).promise().done(function(){
   		           			 var prosepectPrflView = new ProspectView();              
   		                        MemmoryMgr.setcurrentview(prosepectPrflView);              
   		                        prosepectPrflView.render(clId);
	   		           		});
        				}
	        			
	        			Spinner.hide();
        		})
        		.fail(function(error){
        			Spinner.hide();
            		ErrorLog.ErrorUtils.myError(error);
        		});
        	}else{
        		Spinner.show();
        		that.contactId = null;
        		that.$el.html(_.template(CPShellTemplate)).promise().done(function () {
        		    new GroupUi({ el: $('#sharedgrpdiv') }).render();
        		    that.renderCorrespondingSubTab(subtab, params);
        		    that.getEsigDocsCount();
        		});            	
        	}

            //For displaying corresponding tabs (To see active tab in mobile device)
        	if ($('.pt-sub-nav-shell').length > 0) {
        	    switch (subtab) {
        	        case "preferences":
        	            if ($('.bt-pref').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-pref'); }
        	            break;
        	        case "bank":
        	            if ($('.bt-bank').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-bank'); }
        	            break;
        	        case "beneficiary":
        	            if ($('.bt-ben').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-ben'); }
        	            break;
        	        case "fiduciary":
        	            if ($('.bt-fid').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-fid'); }
        	            break;
        	        case "contributions":
        	            if ($('.bt-contributions').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-contributions'); }
        	            break;
        	        case "distributions":
        	            if ($('.bt-distributions').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-distributions'); }
        	            break;
        	        case "iradetails":

        	            break;
        	        case "contactprofile":
        	        default:
        	            if ($('.bt-contact').length > 0) { CommonUtils.horizontalScrollToView('.pt-sub-nav-shell', '.bt-contact'); }
        	            break;
        	    }
        	}//Nav Shell
        	
        }
    });
    return cpShellView;
});