'use strict';
var express = require('express'),
    router = express.Router(),
    InvTrackMygoalFsGoalSummaryModel = require('./trackmygoals/getFsGoalSummary.model');
    

var error = {
    status: 300,
    message: 'Something went wrong!!'
}; /* Error messge object */
var errorManageSubscriptions = [{
    'errorCode': '2008',
    'errorSource': 'PFAPP',
    'errorDescription': 'The following field(s) can contain only numbers. They cannot contain alphabets or other characters: Mobile Number'
}];



router.route('/smartsolution/fsGoalSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        InvTrackMygoalFsGoalSummaryModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].dividendDetailsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].dividendDetailsObject);
            }

        });
    });





module.exports = router;
