'use strict';

/* jasmine specs for controllers go here */

describe('detectCardCategoryFilter', function() {

	var detectCardCategoryFilter;
	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    detectCardCategoryFilter = $injector.get('$filter')('detectCardCategory');
	}));

	//--- Test for definition

	it('should expect detectCardCategory to be defined...', function(){
		expect(detectCardCategoryFilter).toBeDefined();
	});

	//--- Test detectcardcategory filter

	it('should return proper card category for given card number', function(){
		expect(detectCardCategoryFilter('4012888888881881')).toEqual('VISA');
	});

	it('should return proper card category for given card number', function(){
		expect(detectCardCategoryFilter('5412888888888918')).toEqual('MASTERCARD');
	});

	it('should return proper card category for given card number', function(){
		expect(detectCardCategoryFilter('7434584784')).toBeUndefined();
	});

});