/**
 * @ngdoc property
 * @name stp details review Controller
 * @requires $scope
 * @requires stpDetailsModel
 * @requires TransactConstant
 * @requires $filter
 * @requires eventConstants
 * @description
 *
 * - It gets the data from stpDetailsModel and binds the data. 
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function cstpDetailsReviewController($scope,transactModel,$state,$filter,fticDateUtils) {
    //alert("came");
    //$scope.chkTnCs =true;
    $scope.headerText = "STP Cancellation Details";
    $scope.fundDetails = transactModel.getFundDetails(); 
   // var effDate = fticDateUtils.formateDatepickerValue($scope.fundDetails.nextTiggerDate);
//var cancellationEffectiveDate = $filter('date')(new Date(effDate),'dd MMMM yyyy');
      $scope.cstpKeyValuePairs = [
      {
          text : 'Cancellation Effective Date',
          value: $scope.fundDetails.nextTiggerDate
      }
  ];
 // $scope.config.toState = "invTransact.base.cstp"; 
 $scope.config.toState = "invTransact.base.cancelStp"; 
$scope.config.fromState = $state.current.name; 

  //$scope.config.toTxnDetailsState = "transact.txnDetails.cstp";
  
 // $scope.$emit('accptedTermsAndConditions');
  
    /*if($scope.amountStatus){
      toaster.error(TransactConstant.stp.STP_FIXED_AMT_MSG);      
    }*/
}
cstpDetailsReviewController.$inject = ['$scope', 'transactModel', '$state', '$filter', 'fticDateUtils'];
module.exports = cstpDetailsReviewController;