'use strict';

var cancelSipInitialLoader = function (fticCancelStpFundDetailsModel, transactEventConstants, transactEvents,toaster,$filter,fticDateUtils) {
    
    var cancelSipInitialLoader = {
    	loadAllServices : function (scope,selectedInv) {                    	

            fticCancelStpFundDetailsModel.fetchSelectFundDetails(selectedInv).then(cancelStpSuccess, handleFailure);

            function cancelStpSuccess (data) {
                /*var sfdetails = data.stpSummary;
                var givenStartDate,givenEndDate,cancellationEffectiveDate,cancelDate= null;
                for(var i=0;i<sfdetails.length;i++){
                     givenStartDate = fticDateUtils.formateDatepickerValue(sfdetails[i].startDate);
                     givenEndDate = fticDateUtils.formateDatepickerValue(sfdetails[i].endDate);
                     cancellationEffectiveDate = fticDateUtils.formateDatepickerValue(sfdetails[i].nextTiggerDate);
                     cancelDate = fticDateUtils.formateDatepickerValue(sfdetails[i].cancelDate);
                    data.stpSummary[i].startDate = $filter('date')(new Date(givenStartDate),'dd MMMM yyyy');
                    data.stpSummary[i].endDate = $filter('date')(new Date(givenEndDate),'dd MMMM yyyy');
                    data.stpSummary[i].nextTiggerDate = $filter('date')(new Date(cancellationEffectiveDate),'dd MMMM yyyy');
                    data.stpSummary[i].cancelDate = $filter('date')(new Date(cancelDate),'dd MMMM yyyy');
                }*/
                fticCancelStpFundDetailsModel.setSelectFundGridDtls(data);
                fticCancelStpFundDetailsModel.setSelectFundDtls(data);
               /* console.log("asd");
                console.log(fticCancelStpFundDetailsModel.getSelectFundDtls());*/
                transactEvents.transact.publishInvFundGrid(scope);
            }
            function handleFailure (data) {
                console.log('handleFailure');
                toaster.error(data.data[0].errorDescription)
            }
        }
    };
    return cancelSipInitialLoader;
};

cancelSipInitialLoader.$inject = ['fticCancelStpFundDetailsModel', 'transactEventConstants', 'transactEvents','toaster', '$filter', 'fticDateUtils'];
module.exports = cancelSipInitialLoader;
