﻿define([
  'jquery',
  'underscore',
  'backbone',
  'config',
  'appcommon/commonutility',
  'appcommon/globalcontext',
  'text!appmodules/nav/app/templates/navmegamenu.html',
  'apipublic/appregapi',
  'appcommon/hocindicator',
  'appmodules/nav/app/views/home'
], function ($, _, Backbone, Config, Utility, GlobalContext, megaMenuTemplate, AppRegistrationAPI, HOCIndicator, ShowFirstVisibleMenuItems) {
    var linkList;
    var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;

    //Expand Collapse Click Event
    $(document).off("click", "#nav-megamodal-content .nav-menu-sec-header").on("click", "#nav-megamodal-content .nav-menu-sec-header", function (e) { expandCollapseSections(e); });

    function expandCollapseSections(e) {
        try {
            var _target = e.target || e.currentTarget;
            var $this;

            if ($(_target).hasClass("nav-menu-sec-header")) {
                $this = $(_target).find("span.expand-collapse");
            } else {
                $this = $(_target).parent().find('span.expand-collapse');
            }

            if ($this.is(':Visible')) {
                if ($this.hasClass("collapse-icon")) {
                    //Collapsing
                    $('.' + $this.attr('data-target')).toggleClass('hidden-xs')
                    $this.removeClass("collapse-icon").addClass('expand-icon');
                }
                else {
                    //Expanding
                    $('.' + $this.attr('data-target')).removeClass('hidden-xs');
                    $this.removeClass('expand-icon').addClass("collapse-icon");
                }
            }

        } catch (error) {

        }
    }

    function create(_that, ContactDetailsModel) {
        var tmpTemplate = _.template(megaMenuTemplate);
        function megaMenuOrientationAdjust() {
            $('body').css('position', 'absolute');
            setTimeout(function () { $('body').css({ 'position': 'fixed', 'width': '100vw', 'padding-right': '0px' }); }, 10);
        }

        $('#nav-megamenu-modal').on('hidden.bs.modal', function () {
            $(document).off('orientationchange', megaMenuOrientationAdjust); $('#afinav-navbar').css('z-index', 1040);
        });
        $('#nav-megamenu-modal').on('shown.bs.modal', function () {
            var ww = window.innerWidth;
            if ($('.nav-menu-sec-header').length > 0) {
                if ($('.nav-menu-main-sec1, .mega-menu-lt-container').is(':visible')) {
                    $('.nav-menu-sec-header [data-target="client-tools"]').addClass('collapse-icon');
                    $('.nav-menu-links-container.client-tools').removeClass('hidden-xs');
                } else {
                    $('.nav-menu-sec-header [data-target="my-tools"]').removeClass('expand-icon').addClass('collapse-icon');
                    $('.nav-menu-links-container.my-tools').removeClass('hidden-xs');
                }
            }

            var sectionsVisible = $('.nav-megamenu-container').attr('data-target');
            var sectionsVisibleArr = sectionsVisible.split(',');
            if (ww >= 320 && ww <= 767) {
                for (var j = 0; j < sectionsVisibleArr.length; j++) {
                    $(".nav-megamenu-container " + sectionsVisibleArr).removeAttr('style');
                }
            } else {
                $(sectionsVisible).css('height', maxHeightOfColumn(sectionsVisibleArr));
            }
        });

        $(document).off('orientationchange', megaMenuOrientationAdjust).on('orientationchange', megaMenuOrientationAdjust);
        $("#nav-megamenu-modal-body").html(tmpTemplate).promise().done(function () {
            $('.nav-megamenu-container').attr('data-target', '.nav-menu-main-sec1, .nav-menu-main-sec2, .nav-menu-main-sec3, .nav-menu-main-sec4');
            $("#afinav-master").css('position', 'relative');
            $($(".fc-agenda-divider.fc-widget-header").next()[0]).css("overflow-y", "hidden");
            if (!_that.selContactDetails) {
                _that.selContactDetails = ContactDetailsModel.advsiorContacts.getSelectedContactDetails(_that.getAdvFMID(), _that.clientSearchEventModel.get('selectedclient'));
            }
            $('#contact-service').parent().removeClass('hidden');
            //Mega menu for a client 
            if (_that.clientSearchEventModel.get('selectedcontacttype') == "client") {
                $('.nav-megamenu-container').attr('data-target', '.nav-menu-main-sec1, .nav-menu-main-sec2, .nav-menu-main-sec3, .nav-menu-main-sec4');
                adjustMenu('client');
                $('.nav-menu-main-sec1 .txtHeader').html('Client Tools');
                if (_that.selContactDetails) {
                    $('#menu-client-name').html(_that.selContactDetails.orgNm != null ? _that.selContactDetails.orgNm : ((_that.selContactDetails.firstNm !== null && _that.selContactDetails.firstNm.length > 0) ? _that.selContactDetails.firstNm + " " + _that.selContactDetails.lastNm : _that.selContactDetails.lastNm));
                    $('#menu-client-id').html(_that.selContactDetails.id.slice(-8));
                }
                $('#hocMegamenuLink').removeClass('hidden');
                $(".nav-menu-main-sec2").css('border-left', '1px solid #cccccc');
            }
                //Mega menu for a non-client 
            else if (_that.clientSearchEventModel.get('selectedcontacttype') == "nonclient") {
                $('.nav-megamenu-container').attr('data-target', '.nav-menu-main-sec1, .nav-menu-main-sec2, .nav-menu-main-sec3');
                $('.nav-menu-main-sec1 .txtHeader').html('Prospect/Other Tools');
                if (_that.selContactDetails) {
                    $('#menu-client-name').html(_that.selContactDetails.orgNm != null ? _that.selContactDetails.orgNm : ((_that.selContactDetails.firstNm !== null && _that.selContactDetails.firstNm.length > 0) ? _that.selContactDetails.firstNm + " " + _that.selContactDetails.lastNm : _that.selContactDetails.lastNm));
                }
                adjustMenu('nonclient');
                $(".nav-menu-main-sec2").css('border-left', 'none');
                $(".nav-menu-main-sec2, .nav-menu-main-sec3").removeClass("col-sm-3").addClass("col-sm-4");
                $(".nav-menu-main-sec4").hide();
                $(".nav-menu-links-container #accounts").parent().addClass('hidden');
                if ($(".mega-menu-lt-container").hasClass('col-sm-3')) { $(".mega-menu-lt-container").removeClass('col-sm-3').addClass('col-sm-4'); }
                if ($(".mega-menu-rt-container").hasClass('col-sm-9')) { $(".mega-menu-rt-container").removeClass('col-sm-9').addClass('col-sm-8'); }
                if ($(".mega-menu-rt-container .nav-menu-main-sec2, .mega-menu-rt-container .nav-menu-main-sec3").hasClass('col-sm-4')) { $(".mega-menu-rt-container .nav-menu-main-sec2, .mega-menu-rt-container .nav-menu-main-sec3").removeClass('col-sm-4').addClass('col-sm-6'); }

                $('#hocMegamenuLink').addClass('hidden');
            }
                //Mega menu if none selected
            else {
                $('.nav-megamenu-container').attr('data-target', '.nav-menu-main-sec2,.nav-menu-main-sec3');
                adjustMenu('nonepinned');
                $(".nav-menu-main-sec2, .nav-menu-main-sec3").removeClass("col-sm-4").addClass("col-sm-6");
                $(".nav-menu-client-sec, .nav-menu-main-sec1, .mega-menu-lt-container, .nav-menu-main-sec4").hide();
                $(".mega-menu-rt-container").removeClass('col-sm-9').addClass('col-sm-12');
                $('#hocMegamenuLink').addClass('hidden');
                $('.nav-menu-main-sec2, .nav-menu-main-sec2 .nav-menu-sec').css('border', 'none');
            }

            setTimeout(function () {
                $("#nav-megamenu-modal").modal('show');
                var sh = window.innerHeight, _offsetHeight = 0, ww = window.innerWidth;
                if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
                    if ($(window).width() > $(window).height()) {
                        _offsetHeight = 110;
                    }
                    else if ($(window).height() > $(window).width()) {
                        _offsetHeight = 140;
                    }
                }
                else {
                    _offsetHeight = 110;
                }
                var reqheight = sh - _offsetHeight;
                $(".nav-megamenu-container").css({ "max-height": reqheight + "px" });
            }, 400);
            // timeout used to show menu after keyboard closes in Samsung
            // scroll within the megamenu modal
            setTimeout(function () {
                $('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px' });
                $('#afinav-navbar').css('z-index', 1050);                
            }, 600);
            applyAppRegistrationRules();
            HOCIndicator.showCount();
        });

        return true;
    }

    function maxHeightOfColumn(arrObj) {
        var eleArr = Array();
        for (var i = 0; i < arrObj.length ; i++) {
            eleArr.push($(arrObj[i]).height());
        }
        return Math.max.apply(this, eleArr);
    }

    function adjustMenu(obj) {
        var ww = window.innerWidth;
        var modalDialog = $("#nav-megamenu-modal .modal-dialog");
        if (obj == 'client' || obj == 'nonclient') {
            if (ww >= 320 && ww <= 736) { //For Mobiles Screen size < 736
                if (isPortrait()) { modalDialog.css("width", "93%"); } else { modalDialog.css("width", "95%"); }
            } else if (ww >= 736 && ww <= 1024) { //For Tablets Screen size < 1024
                if (isPortrait()) { modalDialog.css("width", "97%"); } else { modalDialog.css("width", "98%"); }
            } else { //For Desktop/Laptop Screen size
                modalDialog.css("width", "80%");
            }
        } else if (obj == 'nonepinned') {
            if (ww >= 320 && ww <= 736) { //For Mobiles Screen size < 736
                if (isPortrait()) { modalDialog.css("width", "93%"); } else { modalDialog.css("width", "95%"); }
            } else if (ww >= 736 && ww <= 1024) { //For Tablets Screen size < 1024
                if (isPortrait()) { modalDialog.css("width", "97%"); } else { modalDialog.css("width", "98%"); }
            } else { //For Desktop/Laptop Screen size
                modalDialog.css("width", "60%");
            }
        }
    }

    function isPortrait() {
        return window.innerHeight > window.innerWidth;
    }

    function isLandscape() {
        return (window.orientation === 90 || window.orientation === -90);
    }

    function applyAppRegistrationRules() {
        //itterate through the links found in the templated dom and provide display instruction
        var linkList = getLinksFromTemplate();

        linkList.each(function (index, val) {
            val.url = getRoute($(val).data('href') || val.href);
            if (appRegistrationHasEntry(getRoute(val.url))) {
                if (AppRegistrationAPI.routeIsAllowed(val.url)) {
                    $(val).parent().show();
                } else {
                    $(val).parent().hide();
                }
            } else {
                $(val).parent().show();
            }
        });
    }

    function getLinksFromTemplate() {
        var linkList = $('#nav-megamenu-modal-body a[href]');
        return linkList;
    }

    function getRoute(url) { //Used to get only the route of the url (anything after the TLD [.com]) 

        if (typeof url === 'undefined' || !url) { return '' }
        if (url.indexOf(Config.baseUri) > -1 && Config.baseUri !== '') {
            var regex = new RegExp('^[^_]*\\' + Config.baseUri + '/')
            return url.replace(regex, "");
        } else {
            return url.replace(/.*?:\/\/[^\/]+\//i, "");
        }
    }

    
    function getLinkType(url) { //currently unused
        linkList.each(function (index, val) {
            var valURL = val.href;

            linkList[index] = val;

            if (val.href == "javascript:void(0);") { 
                return 'voidLink';

            } else if (val.href == " " || val.href == "") { // handeled seperately, though the same as above
                return 'blank';
            } else {
                return 'default';
            }
        })
        return 'unknown'; //something went wrong
    }

    return menu = {
        create: create
    }
});