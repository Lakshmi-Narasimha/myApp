/**
 * @ngdoc service
 * @name fundDetailsModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var fundDetailsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, transactModel, investorRegistrationModel) {
    var _fundDetails = null, requestBodyObj = {};
    var _investorType = null;

    var fundDetailsModel = {
        
        fetchFundDetails : function () {
            var params = {};
            params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            params.accountNo = transactModel.getFundDetails().tschvalAccno;

            var deferred = $q.defer();
            Restangular.one('transact/balanceUnits').get(params).then(function (fundDetails) {
                deferred.resolve(fundDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setCommonInvProperties : function() {
            requestBodyObj = {};
            requestBodyObj.panNo = "";
            requestBodyObj.folioId = "";
            requestBodyObj.webRefNo = transactModel.getWebRefNo() || "";
            
            //Getting panNo for Advisor, Paperless and TransactNow
            if (transactModel.getInvestorDetails()) {
                requestBodyObj.panNo = transactModel.getInvestorDetails().pan;
            } else if (transactModel.getNewInvestorData()) {
                requestBodyObj.panNo = transactModel.getNewInvestorData().data.pan;
            } else if (transactModel.getSelectedFolioDts() !== "Newfolio") {
                requestBodyObj.panNo = transactModel.getSelectedFolioDts().holderDetails[0].pan;
            } else if (transactModel.getrawHolderDts()) {
                requestBodyObj.panNo = transactModel.getrawHolderDts()[0].pan;
            }

            //Getting folioId for Advisor, Paperless and TransactNow
            if (investorRegistrationModel.getNewInvestorFolioId()) {
                requestBodyObj.folioId = investorRegistrationModel.getNewInvestorFolioId();
            } else if (transactModel.getInvestorDetails()) {
                requestBodyObj.folioId = transactModel.getInvestorDetails().folioId;
            } else if (transactModel.getSelectedFolioDts()) {
                requestBodyObj.folioId = transactModel.getSelectedFolioDts().folioId;
            }

            return requestBodyObj;
        },
        getFundDetails: function() {
            return _fundDetails;
        },
        
        setFundDetails: function(fundDetails) {
            _fundDetails = fundDetails;
        },
        setInvestorType:function(investorType){
            _investorType = investorType;
        },
        getInvestorType:function(){
            return  _investorType;
        }
    };
    return fundDetailsModel;
};

fundDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', 'transactModel', 'investorRegistrationModel'];

module.exports = fundDetailsModel;