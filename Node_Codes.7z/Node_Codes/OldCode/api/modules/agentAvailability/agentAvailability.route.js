var express = require('express');
var https = require('https');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var proxy = require('../../../config/proxy')
var router = express.Router();
var agentAvailabilityModel = require('./agentAvailability.model');

// api route
router.route('/mfchatnode/rest/agent')
    .post(function(req, res) {
        req.session.statusCounter = (req.session.statusCounter+1 || 1);
        logger.general.info(logger.formatInfoMsg(req.session.id, "Agent Call #"+ req.session.statusCounter));        
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.body.RequestParams = req.body.RequestParams || {};
        req.uri = agentAvailabilityModel.createRequestUri[req.body.RequestParams.agentGroupID];
        
        var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Cookie': req.session.sessionCookie
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            var resbody = [];
            proxyResponse.setEncoding('utf8');
            proxyResponse.on('data', function(chunk) {
               resbody.push(chunk);
            }).on('end', function(){
                logger.general.info(logger.formatOutBoundResMsg(reqObj, resbody, req.session.id));
                chunk = JSON.parse(resbody);
                chunk = chunk || {};               
                if(chunk.availability && (chunk.availability === 'true')) {
                    agentAvailabilityModel.response.Page.availability = true;
                    agentAvailabilityModel.response.Page.inHOP = true;
                    agentAvailabilityModel.response.Page.status = "online";
                    agentAvailabilityModel.response.Page.agentBusy = false;
                    agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                } else {
                    agentAvailabilityModel.response.Page.availability = false;
                    agentAvailabilityModel.response.Page.inHOP = false;
                    agentAvailabilityModel.response.Page.status = "offline";
                    if(req.session.statusCounter >= 6){
                        req.session.statusCounter = 0;
                        agentAvailabilityModel.response.Page.agentBusy = true;
                        agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.msgList;
                        logger.general.info(logger.formatInfoMsg(req.session.id, "Reached max retry times, all agents are still busy, stopped calling find agent API."));                      
                    }else{
                        agentAvailabilityModel.response.Page.agentBusy = false;
                        agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                    }
                }
                logger.general.info(logger.formatInBoundResMsg(req, agentAvailabilityModel.response));
                res.send(agentAvailabilityModel.response);
            });
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                res.send(err);

            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
