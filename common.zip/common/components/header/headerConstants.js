'use strict';

var headerConstants = (function() {
    return {
      UICheader:[
         {
            'Funds & Solutions':[
               {
                  'text':'Family Solutions',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/smartsolutions',
                  'menuitem':'fundsnsolutions',
                  'submenuitem':'smartsolutions',
                  'submenu':[
                     {
                        'text':'Child\'s Education',
                        'url':'smartsolutions.planSmartSolution({param: \'Child\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Cash Management',
                        'url':'smartsolutions.planSmartSolution({param: \'Cash\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Retirement',
                        'url':'smartsolutions.planSmartSolution({param: \'Retire\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Dream Home',
                        'url':'smartsolutions.planSmartSolution({param: \'Dream\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Holiday',
                        'url':'smartsolutions.planSmartSolution({param: \'Holiday\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Wealth Creation',
                        'url':'smartsolutions.planSmartSolution({param: \'Wealth\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Tax Planning',
                        'url':'smartsolutions.planSmartSolution({param: \'Tax\'})',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Customize Your Plan',
                        'url':'smartsolutions.planSmartSolution({param: \'Customized\'})',
                        'menuitem':'fundsnsolutions'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':'Fund Explorer',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/fundsexplorer',
                  'menuitem':'fundsnsolutions',
                  'submenuitem':'fundsexplorer',
                  'submenu':[
                     {
                        'text':'Debit & Liquid Funds',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Diversified Equity Funds',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Funds Of Funds',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Hybrid Funds',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Sector Equity Funds',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     }
                  ],
                  'list':true,
                  'helpsection':false
               },
               {
                  'text':'NAVs and Dividends',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'https://www.farmers.com/quote/ffq/landingpage.jsf',
                  'externalURL':true,
                  'menuitem':'fundsnsolutions',
                  'submenuitem':'navsndividends',
                  'submenu':[
                     {
                        'text':'Latest NAV\'s & Dividents',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Bonus History',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'Dividents History',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'NAV History',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':'Tools',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'menuitem':'fundsnsolutions',
                  'submenuitem':'tools',
                  'submenu':[
                     {
                        'text':'Funds Compararator',
                        'url':'a',
                        'menuitem':'fundsnsolutions'
                     },
                     {
                        'text':'SIP Calculator',
                        'url':'sipcalculators',
                        'menuitem':'sipcalculators'
                     },
                     {
                        'text':'Lumpsum Calculator',
                        'url':'lumpsumcalculators',
                        'menuitem':'lumpsumcalculators'
                     },
                     {
                        'text':'SIP VS Lumpsum Calculator',
                        'url':'comparissioncalculators.sip',
                        'menuitem':'comparissioncalculators'
                     },
                     {
                        'text':'Tax Advantage Calculator',
                        'url':'taxadvantagecalculators',
                        'menuitem':'taxadvantagecalculators'
                     }, 
                     {
                        'text':'Commission Calculator',
                        'url':'commissioncalculators',
                        'menuitem':'commissioncalculators'
                     }
                  ],
                  'helpsection':false
               }
            ]
         },
         {
            'Investor Education':[
               {
                  'text':'Mutual Fund Basics',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/mutualfundbasics',
                  'menuitem':'investoreducation',
                  'submenuitem':'mutualfundbasics',
                  'submenu':[
                     {
                        'text':'Investing in Mutual Funds',
                        'url':'a',
                        'menuitem':'investoreducation'
                    },
                     {
                        'text':'Choosing Investments',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'Managing Portfolio',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'Investment Glossary',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'Learning videos and resources',
                        'url':'a',
                        'menuitem':'investoreducation'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':'Financial Planning',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/financialplanning',
                  'menuitem':'investoreducation',
                  'submenuitem':'financialplanning',
                  'submenu':[
                     {
                        'text':'SIP',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'SWP',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'STP',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'Lumpsum',
                        'url':'a',
                        'menuitem':'investoreducation'
                     },
                     {
                        'text':'Importance of Advisor',
                        'url':'a',
                        'menuitem':'investoreducation'
                     }
                  ],
                  'list':true,
                  'helpsection':false
               }
            ]
         },
         {
            'Distributor Zone':[
              {
                  'text':'Distributor Services',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/distributorservices',
                  'menuitem':'distributorZone',
                  'submenuitem':'distributorservices',
                  'submenu':[
                     {
                        'text':'Why Franklin Templeton?',
                        'url':'WhyFT',
                        'menuitem':'distributorZone'
                     },
                     {
                        'text':'Become an Adviser/ Empanel with us',
                        'url':'usertype',
                        'menuitem':'distributorZone'
                     },
                     {
                        'text':'Register for Online access',
                        'url':'registerForOnlineAccess',
                        'menuitem':'distributorZone'
                     },
                     {
                        'text':'Forms for Distributors',
                        'url':'formsForDistributors',
                        'menuitem':'distributorZone'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':'Mail back Services',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/mailbackservices',
                  'menuitem':'distributorZone',
                  'submenuitem':'mailbackservices',
                  'submenu':[
                     {
                        'text':'Instant Reports',
                        'url':'instantreports',
                        'menuitem':'distributorZone'
                     },
                     {
                        'text':'Account Statements',
                        'url':'accountStatement',
                        'menuitem':'distributorZone'
                     }
                  ],
                  'list':true,
                  'helpsection':false
               }
            ]
         },
         {
            'Market Insights':[
               {
                  'text':null,
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/market',
                  'menuitem':'marketinsights',
                  'submenuitem':null,
                  'submenu':[
                     {
                        'text':'Weekly Market Review',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'Fixed Income Market Update',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'Earnings Releases',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'Equity Market Update',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'News Articles',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'World News Summaries',
                        'url':'a',
                        'menuitem':'marketinsights'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':null,
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/market',
                  'menuitem':'marketinsights',
                  'submenuitem':null,
                  'submenu':[
                     {
                        'text':'Templeton Equity View',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'Emerging Markets Blog',
                        'url':'a',
                        'menuitem':'marketinsights'
                     },
                     {
                        'text':'Newsletters',
                        'url':'a',
                        'menuitem':'marketinsights'
                     }
                  ],
                  'helpsection':false
               }
            ]
         },
         {
            'Customer Services':[
               {
                  'text':'Instant Services',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/instantservices',
                  'menuitem':'customerservices',
                  'submenuitem':'instantservices',
                  'submenu':[
                     {
                        'text':'Account Statement',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Portfolio valuation',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Capital gains statement',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Devident Details',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Transaction Details',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Historic NAV',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'RTA level consolidated statement',
                        'url':'a',
                        'menuitem':'customerservices'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':'Account Subscriptions',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/accountsubscriptions',
                  'menuitem':'customerservices',
                  'submenuitem':'accountsubscriptions',
                  'submenu':[
                     {
                        'text':'Account Statement',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Portfolio valuation',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Daily / Weekly NAV',
                        'url':'a',
                        'menuitem':'customerservices'
                     }
                  ],
                  'list':true,
                  'helpsection':false
               },
               {
                  'text':'Account Services',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'url':'#/accountservices',
                  'externalURL':true,
                  'menuitem':'customerservices',
                  'submenuitem':'accountservices',
                  'submenu':[
                     {
                        'text':'Ways to transact with us',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'SMS Services',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Online Services',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Unclaimed Investments',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Transmission Policy',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Forms',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'FAQs',
                        'url':'a',
                        'menuitem':'customerservices'
                     }
                  ],
                  'helpsection':false
               },
               {
                  'text':'Find FT',
                  'twocolumn':'col-xs-12 col-sm-3',
                  'menuitem':'customerservices',
                  'submenuitem':'findft',
                  'submenu':[
                     {
                        'text':'Locate a branch',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'CAMS / KARVY Locations',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Find an advisor',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Grievance redressal',
                        'url':'a',
                        'menuitem':'customerservices'
                     },
                     {
                        'text':'Contact us',
                        'url':'a',
                        'menuitem':'customerservices'
                     }
                  ],
                  'helpsection':false
               }
            ]
         }
      ]
   };
}());

headerConstants.$inject = [];
module.exports = headerConstants;
