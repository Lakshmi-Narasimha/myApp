'use strict';

var recommendedFundCardInitialLoader = function (recommendedFundCardModelService, advisorEvents, advisorEventConstants) {

    var recommendedFundCardInitialLoader = {
        _isServicesData: false,
        loadAllServices : function(scope){
            
          recommendedFundCardModelService.fetchRecommendedFundCard().then(recommendedFundCardSuccess, handleFailure);

            function recommendedFundCardSuccess(data){
                recommendedFundCardModelService.setFundCardModelDtls(data[0]);
            }
            function handleFailure(data){
                console.error('handleFailure');
                recommendedFundCardInitialLoader._isServicesData = false;
            }  

         }
       
    };
       
    return recommendedFundCardInitialLoader;
};

recommendedFundCardInitialLoader.$inject = ['recommendedFundCardModelService', 'advisorEvents', 'advisorEventConstants'];

module.exports = recommendedFundCardInitialLoader;