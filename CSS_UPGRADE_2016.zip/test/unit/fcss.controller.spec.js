(function() {
    'use strict';
    describe('JustPayMainController', function() {
        beforeEach(module('CSS.justPay'));

        var JustPayMainController, $controller, billingVM;

        beforeEach(inject(function($controller, $injector) {
            JustPayMainController = $controller('JustPayMainController');
        }));

        describe('JustPayMainController', function() {
            it('should expect JustPayMainController to be defined...', function() {
                expect(JustPayMainController).toBeDefined();
            })
        })

    })
})();
