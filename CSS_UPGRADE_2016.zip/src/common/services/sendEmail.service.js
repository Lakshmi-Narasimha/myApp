/**
 * @ngdoc service
 * @name Common Service
 * @requires sendEmailService
 * @description
 *
 * - Send Email Details JSON  / Method
 */
(function() {
    'use strict';

    angular.module('CSS.common').service('sendEmailService', ['$http', '$q', function($http, $q) {

        this.sendEmail = function(queryData) {
            var deferred = $q.defer();
            var config;
            config = {
                method: 'post',
                url: 'http://localhost:9900/sendEmail/sendEmail',
                data: queryData,
            };

            $http(config)
                .success(function(data, status, headers, config) {
                    deferred.resolve(data);
                })
                .error(function(data) {
                    deferred.reject(data);
                });

            return deferred.promise;
        };        
        
    }]);

})();