/**
 * @ngdoc directive
 * @name fticUserInputFldMasked
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFldMasked will display floatable input control with Masked.
 * 
 *
 **/
'use strict';

var userInputFldMasked = function($timeout, eventConstants) {
<<<<<<< HEAD
    return {
        template: require('./userInputFldMasked.html'),
        restrict: 'E',
        replace: true,
        scope: {
            inputObject: "="
        },
        controller: ['$scope', '$element', function($scope, $element) {
            $scope.$input = $element[0].querySelector('input');
            $scope.isChanged = false;
            var el = angular.element(document.querySelector("input[name=userPassword]"));
            //var el = angular.element(document.querySelector(".ftic_readOnly_pwd"));
            el.removeAttr('readonly');
            $scope.toggleLabel = function($event) {
                angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || $scope.$input.value.length > 0));
                $scope.updateParent();
                var el = angular.element(document.querySelector("input[name=userPassword]"));
                //var el = angular.element(document.querySelector(".ftic_readOnly_pwd"));
                el.removeAttr('readonly');
            };
            $timeout(function() {
                angular.element($scope.$input).triggerHandler('blur');
                $scope.isChanged = true;
            }, 0);
=======
	return {
            template: require('./userInputFldMasked.html'),
            restrict: 'E',
            replace: true,
            scope: {
                inputObject: "="
            },
            controller: ['$scope', '$element', function($scope, $element){
                $scope.$input = $element[0].querySelector('input');
                $scope.isChanged = false;
                       var el = angular.element(document.querySelector(".ftic_readOnly_pwd"));
                       el.attr('readonly','true');
                       el.attr('autocomplete','off');
                       //var pwdPP = angular.element(document.querySelector("input[name=passwordForPP]"));
                       //pwdPP.attr('ng-readonly','true');
                       //var pwd = angular.element(document.querySelector("input[name=name]"));
                       //pwd.attr('readonly','true');
                       $scope.toggleLabel = function($event){
                    angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || $scope.$input.value.length > 0));
                    $scope.updateParent();
                         var el=angular.element(document.querySelector(".ftic_readOnly_pwd"));
                         el.removeAttr('readonly');
                         //var pwd = angular.element(document.querySelector("input[name=name]"));
                         //pwd.removeAttr('readonly');
                         //var elsecurity = angular.element(document.querySelector("input[name=securityQuestion]"));
                         //elsecurity.removeAttr('ng-readonly'); 

                         //var pwdPP=angular.element(document.querySelector("input[name=passwordForPP]"));
                         //pwdPP.removeAttr('ng-readonly');
                };

                $timeout(function(){
                    angular.element($scope.$input).triggerHandler('blur');
                    $scope.isChanged = true;
                        //var elsecurity = angular.element(document.querySelector("input[name=securityQuestion]"));
                       //elsecurity.attr('ng-readonly','true');
                       //var pwdPP = angular.element(document.querySelector("input[name=passwordForPP]"));
                       //pwdPP.attr('ng-readonly','true');
                       var ele = angular.element(document.querySelector(".ftic_readOnly_pwd"));
                       ele.attr('readonly','true');
                        
                }, 0);
>>>>>>> ftic-inv-sprint6

            $scope.updateParent = function() {
                if (!$scope.isChanged) {
                    return;
                } else {
                    $scope.$emit("INPUT_CHANGED", $scope.inputObject);
                }
            }
        }]
    };
};

userInputFldMasked.$inject = ['$timeout', 'eventConstants'];
module.exports = userInputFldMasked;
