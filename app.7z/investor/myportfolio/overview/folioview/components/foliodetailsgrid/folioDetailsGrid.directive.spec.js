'use strict';

describe('Directive: Folio details grid', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, folioViewModel;
	var folioData = {
		'folioDetails': {
	            'folioNumber': '17877097',
	            'gridData': {
	                'rows': [{
	                    'currentValue': '92755.57',
	                    'currentCost': '59998.89',
	                    'accno': '1349904865101',
	                    'returns': '20.46%',
	                    'fund': 'Franklin India Taxshield - Growth',
	                    'totalUnits': '219.347',
	                    'divInvAmount': '0.00', //invest
	                    'purchaseAmount': '59998.89' // reinvest
	                }, {
	                    'currentValue': '0.00',
	                    'currentCost': '0.00',
	                    'accno': '2389904865101',
	                    'returns': '0%',
	                    'fund': 'Franklin India Bluechip Fund - Growth',
	                    'totalUnits': '0.000',
	                    'divInvAmount': '0.00',
	                    'purchaseAmount': '0.00'
	                }, {
	                    'currentValue': '29408.34',
	                    'currentCost': '22499.85',
	                    'accno': '4379904865101',
	                    'returns': '16.81%',
	                    'fund': 'Franklin India Prima Plus - Growth',
	                    'totalUnits': '66.411',
	                    'divInvAmount': '0.00',
	                    'purchaseAmount': '22499.85'
	                }],
	                'footer': {
	                    'totalUnits': '285.758',
	                    'currentCost': '82498.74',
	                    'currentValue': '122163.91'
	                }
	            }
	        }
		}

    var statusTemplate = '<div uib-popover-template="\'veiwCompTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
        '<script type="text/ng-template" id="veiwCompTemplate.html">' +
        '<div><button type="button" ng-click="grid.appScope.$emit(\'showAccountView\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Account Statement</button><button type="button" ng-click="grid.appScope.$emit(\'BuySIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Buy</button><button type="button" ng-click="grid.appScope.$emit(\'StartASIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Start a SIP</button><button type="button" ng-click="grid.appScope.$emit(\'RedeemSIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Redeem</button><button type="button" ng-click="grid.appScope.$emit(\'SwitchSIP\', {accontNumber : row.entity.accno,folioNumber:col.colDef.folioNo})" class="btn panel-orange-btn">Switch</button></div></script>';
    var infoTemplate = '<ftic-popover class="ftic-accjoint-popover" placement="left" ng-if="col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)]" popovercontent="col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)]" popover-trigger="outsideClick"></ftic-popover>';
    var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti_Info"></span></div>' +
        '<script type="text/ng-template" id="returnTemplate.html">' +
        '<div class="overview-tool-tip">{{col.colDef.returnsText}}</div></script>';

	var getCompiledElement = function() {
        var element = angular.element('<ftic-folio-details-grid></ftic-folio-details-grid>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _folioViewModel_) {            
            rootScope = _$rootScope_;
            scope = rootScope.$new();
            compile = _$compile_;
            folioViewModel = _folioViewModel_;
        });

        folioViewModel.setFolioViewObj({
            'folioDetails': folioData.folioDetails
        })

        directiveEle = getCompiledElement();
        isolatedScope = directiveEle.isolateScope();
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create a separate isolate scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have isFolioDataAvailable to be defined and have folio number', function() {
        expect(isolatedScope.isFolioDataAvailable).toBeDefined();
        expect(isolatedScope.isFolioDataAvailable.folioNumber).toBe('17877097');
    });

    it('should have folioDetails in gridData', function() {
        expect(isolatedScope.gridData).toBeDefined();
        expect(isolatedScope.gridData[0].accno).toBe('1349904865101');
        expect(isolatedScope.gridData[0].currentcost).toBe('59998.89');
        expect(isolatedScope.gridData[0].currentvalue).toBe('92755.57');
        expect(isolatedScope.gridData[0].fund).toBe('Franklin India Taxshield - Growth');
        expect(isolatedScope.gridData[0].returns).toBe('20.46%');
        expect(isolatedScope.gridData[0].totalunits).toBe('219.347');
    });

    it('should have ccpopover to be defined from isolatedScope', function() {
        expect(isolatedScope.ccpopover).toBeDefined();
        expect(isolatedScope.ccpopover[0][0].text).toBe('Investment Amount');
        expect(isolatedScope.ccpopover[0][0].value).toBe('59998.89');
    });

    it('should have returnsText to be defined from isolatedScope', function() {
        expect(isolatedScope.returnsText).toBe('Returns basis XIRR i.e., rate of return basis your investments at various time periods in this fund.');
    });

    it('should be scope data rendered in template', function() {
        expect(isolatedScope.columnDefs).toBeDefined();
        expect(isolatedScope.columnDefs[0].cellTemplate).toBe(statusTemplate);
        expect(isolatedScope.columnDefs[5].cellTemplate).toBe(infoTemplate);
        expect(isolatedScope.columnDefs[7].headerCellTemplate).toBe(returnsTemplate);
    });

    it('should polpulate folioNumber in the view', function() {
        expect($(directiveEle).find('.fti-page-heading2 h2').prevObject[0].innerText).toContain('17877097');
    });
});