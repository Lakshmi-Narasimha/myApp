var fticUtilityDropdownMenu = function(appConfig, configUrlModel, eventConstants) {
    return {
        template: require('./utilityDropdown.html'),
        restrict: 'E',
        transclude: true,
        scope: {
            url: '@',
            text: '@'
        },
        controller: ['$scope', function($scope) {     
                var MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                var GUEST_URL = appConfig[configUrlModel.getEnvUrl('GUEST_URL')];
                $scope.imagePath = configUrlModel.getImagesUrl();
                var menu = $scope.$parent.menu[0];
                $scope.applyopenclass = false; 
                if (menu.link && angular.isArray(menu.link)) {
                    if(menu.text == '' || menu.text == null || menu.text=== undefined){
                        $scope.dropdownImage = menu.image;    
                    }
                    else {
                        $scope.dropdownMTitle = menu.text;
                        $scope.dropdownTitle = menu.text;  
                        $scope.dropdownUrl = menu.url;  
                    }

                    angular.forEach(menu.link,function(firstobj){
                        if(firstobj.url.indexOf('http') !== '-1'){
                            if(firstobj.type=='guest'){
                                firstobj.url = GUEST_URL+'/#'+firstobj.url;
                            }else if(firstobj.type=='marketing'){
                                firstobj.url = MARKETING_URL+firstobj.url;
                            }
                        }
                    });
                    $scope.menuItems = menu.link;

                    // $scope.uicId = dropdownTitle;
                    /*angular.forEach(menuItems, function(menuItem, menuKey) {
                        $scope.isMobile = menuItem.isMobile;
                        $scope.isMobileclass = menuItem.mClass;
                        $scope.mobileHref = menuItem.url;
                    });*/

                }else{
                    if(menu.type[0] == 'link'){
                        $scope.dropdownTitle = menu.text;
                        // $scope.feedbackUrl = menu.url;  
                         if(menu.url.indexOf('http') !== '-1'){
                            if(menu.type[1] == 'guest'){
                                $scope.feedbackUrl = GUEST_URL+'/#'+menu.url;
                            }else if(menu.type[1] == 'marketing'){
                                $scope.feedbackUrl = MARKETING_URL+menu.url;
                            }
                        }
                        // var enviromentUrl = (menu.type[1] == "guest")?GUEST_URL:(menu.type[1] == "marketing")?MARKETING_URL:'';
                        // $scope.feedbackUrl = enviromentUrl+"/#"+menu.url;
                        $scope.menuItems = [];
                    }
                    if(menu.type == 'country'){
                       $scope.dropdownImage = menu['choose-country-link'];
                       $scope.dropdownCountryLabel = menu['choose-country-label'];
                       $scope.dropdownCoutry = menu['country-name'];
                       $scope.countryUrl = menu['choose-country-link'];
                       $scope.altText = menu['country-image-alt-text'];
                    }
                }
            //});

                $scope.navigateCheck = function(toStateVal, submenu){
                    var notResourcesReset = toStateVal ? (toStateVal.split('/').length > 0 ? toStateVal.split('/')[toStateVal.split('/').length-1]  : null) : null;
                    if(notResourcesReset !== 'resources') {
                        $scope.$emit(eventConstants.NAVIGATE_CHECK, toStateVal);
                    }
                    else {
                        $scope.$emit(eventConstants.NAVIGATE_CHECK, toStateVal, submenu.text);
                    }
                },
                $scope.headerMenus = function(){
                    if(!$scope.applyopenclass) {
                        $scope.applyopenclass = true;
                    } else {
                        $scope.applyopenclass = false;
                    }
                };
        }],
    };
};

fticUtilityDropdownMenu.$inject = ['appConfig','configUrlModel','eventConstants'];
module.exports = fticUtilityDropdownMenu;
