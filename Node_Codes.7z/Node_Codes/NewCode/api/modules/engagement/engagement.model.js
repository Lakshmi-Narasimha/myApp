var config = require('/app/conf/properties/mfchatnode/config');

var engagementModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {                
                "startMsgId": -1,
                "searchStartIndex": 10000                
            }
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            //"agentName": "VZW MobApp Tester",
            //"agentID": "vzw-mobile-app-03",
            "callType": "engagement",
            "timeToWait": null,
            "engagementID": "-1196452972424366591",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false        
    },
    ResponseInfo: {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "dcc06d18-64cf-4823-a53b-05ed2733b2c0",
            "type": "Success",
            "topMessage": "You're chatting with VZW MobApp Tester"
    },
    
    msgList: [{
        "state": "assigned",       
        "sequenceNumberInt": 20000,
        "messageList": [{
            "loginReq": false,
            "messageText": " ",
            "nextmsgId": -1
        }],
        "animationDuration": 800,
        "type": "header",
        "msgId": 10000,
        "messageType": "stateChange",
        "sequenceNumber": "2"
    }],
    createRequestUri: {
        Billing: config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Billing,
       
        WirelessSales: config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_SALES_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_SALES_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessSales + '&agentGroupID=' + config.AG_WirelessSales,
        
        Device: config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Device,
       
        Global:config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Global,
       
        MVTrans: config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_MVTrans,
               
        Billing_EMP: config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_Billing_EMP,
          
        Device_EMP:config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_Device_EMP,
       
        Global_EMP:config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_Global_EMP,
       
        MVTrans_EMP: config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_MVTrans_EMP,
        
        Test:config.TC_ENGAGEMENT_URI + '&priority=' + config.TC_ENGAGEMENT_PRIORITY + '&queueThreshold='+ config.TC_ENGAGEMENT_QUEUE_THRESHOLD + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Test      

    },
    createLaunchType: {
        Billing: '&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_Billing,        
        WirelessSales:'&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_WirelessSales,
        Device:'&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_Device,
        Global: '&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_Global,
        MVTrans: '&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_MVTrans,
        Test:'',

        Billing_EMP: '&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_Billing_EMP,       
        Device_EMP:'&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_Device_EMP,
        Global_EMP: '&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_Global_EMP,
        MVTrans_EMP: '&launchType=' + config.EAPI_LAUNCH_TYPE_MOBILEAPP + '&businessRuleID='+ config.BR_MVTrans_EMP,

        Billing_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_Billing_IPAD,
        WirelessSales_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_WirelessSales_IPAD,
        Device_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_Device_IPAD,
        Global_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_Global_IPAD,
        MVTrans_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE__IPAD + '&businessRuleID='+ config.BR_MVTrans_IPAD,

        Billing_EMP_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_Billing_EMP_IPAD,   
        Device_EMP_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_Device_EMP_IPAD,
        Global_EMP_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE_IPAD + '&businessRuleID='+ config.BR_Global_EMP_IPAD,
        MVTrans_EMP_IPad: '&launchType=' + config.EAPI_LAUNCH_TYPE__IPAD + '&businessRuleID='+ config.BR_MVTrans_EMP_IPAD
    },
    businessRuleID: {
        Billing:config.BR_Billing,
        WirelessSales: config.BR_WirelessSales,
        Device: config.BR_Device,
        Global: config.BR_Global,
        MVTrans:config.BR_MVTrans,
        Test: '',
        
        Billing_EMP:config.BR_Billing_EMP,        
        Device_EMP: config.BR_Device_EMP,
        Global_EMP: config.BR_Global_EMP,
        MVTrans_EMP:config.BR_MVTrans_EMP,

        Billing_IPad:config.BR_Billing_IPAD,
        WirelessSales_IPad: config.BR_WirelessSales_IPAD,
        Device_IPad: config.BR_Device_IPAD,
        Global_IPad: config.BR_Global_IPAD,
        MVTrans_IPad:config.BR_MVTrans_IPAD,

        Billing_EMP_IPad:config.BR_Billing_EMP_IPAD,        
        Device_EMP_IPad: config.BR_Device_EMP_IPAD,
        Global_EMP_IPad: config.BR_Global_EMP_IPAD,
        MVTrans_EMP_IPad:config.BR_MVTrans_EMP_IPAD
    }
};

module.exports = engagementModelConfig;
