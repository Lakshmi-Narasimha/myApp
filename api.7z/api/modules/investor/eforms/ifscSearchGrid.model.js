// getIfscSearchGrid.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var IfscSearchGridSchema = new mongoose.Schema({
    IfscSearchGridObject: {
        type: Array,
        "default": []
    }
});

var IfscSearchGridLookUp = mongoose.model('IfscSearchGridLookUp', IfscSearchGridSchema);

var IfscSearchGridDetailsModel = new IfscSearchGridLookUp({
    "IfscSearchGridObject" : [{
        "gridifsc" : [          
            {
              "ifscCode": "DB1234590",
              "brName": "Fort",
              "bnkAddress": "Konark Building, Mumbai"
            },
            {
              "ifscCode": "DB1234230",
              "brName": "Idqah Fort",
              "bnkAddress": "24131 Building, Pune, Mumbai"
            }                   
        ]
        
    }]
});

IfscSearchGridLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating IfscSearchGridLookUp table, please contact admin...');
    } else {
        IfscSearchGridLookUp.remove({}, function(err) {
            console.log('IfscSearchGridLookUp collection removed');
            IfscSearchGridDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating IfscSearchGridLookUp table, please contact admin...');
                }
                console.log('IfscSearchGridLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = IfscSearchGridLookUp;
