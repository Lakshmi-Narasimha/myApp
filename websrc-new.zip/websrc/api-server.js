//var probe = require('ca-apm-probe').start();
var express = require('express');
var domainMiddleware = require('express-domain-middleware');
var https = require('https');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var querystring = require('querystring');
var session = require('express-session');
var config = require('/app/conf/properties/mfchatnode/config');
//var RedisStore = require('connect-redis')(session);
var MemoryStore = require('session-memory-store')(session);
var uuid = require('node-uuid');
var timeout = require('connect-timeout');
var logger = require('./config/logger');
var proxy = require('./config/proxy');
var CircularJSON = require('circular-json');
const NodeCache = require( "node-cache" );
const myCache = new NodeCache( { stdTTL: 120*60, checkperiod: 60*5 } );
module.exports = myCache;

var apiUtils = require('./api/common/apiUtils');
var apiLPUtils = require('./api/common/apiLPUtils');
//url config file
var config = require('/app/conf/properties/mfchatnode/config');

//Defining Express
var app = express();

// Using domain middleware to stop the app from crashing incase of 'UncaughtExceptions"
app.use(domainMiddleware);

// set our portsess
var port = process.env.PORT || 9800;

// get all data/stuff of the body (POST) parameters
// parse application/json
app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: false
}));

//app.UseCors(CorsOptions.AllowAll);
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// initialize the session
app.use(cookieParser('123456ABCDEFG'));
app.use(session({
    secret: '123456ABCDEFG',
    secure: false,
    cookie:{
       maxAge: 60000000
    },
    saveUninitialized: true,
    resave: true,
    rolling:true,
    store: new MemoryStore({
        expires: 1000*60*30, //30 mins
        checkperiod: 1000*60*30 //30 mins
    })
}));

// set the static files location
app.use(express.static((__dirname + '/')));

// app.use(session({
//     store: new RedisStore({}),
//     secret: '123456ABCDEFG',
//      saveUninitialized: true,
//      resave: true,
//      rolling:true,
//      expires: 1000*60*30, //30 mins
//      checkperiod: 1000*60*30 //30 mins
// }));
/*
var assignId = function(req, res, next) {
    req.session.id = uuid.v4();
    next();
};
app.use(assignId);*/


// setup the logger
app.use(logger.winstonExpress);

// connection timeout
app.use(timeout(40000));
app.use(haltOnTimedout);

function haltOnTimedout(req, res, next) {
    if (!req.timedout) next();
    else{
         logger.general.info(logger.formatInfoMsg(req.session.id, "request timeout.")); 
    }
}

// authenticate touchcommerce
var authenticateTouchCommerce = function(req, res, next) {
    var username, password = '';
    if(req.body.RequestParams && req.body.RequestParams.channel){
        req.session.loggedChannel = req.body.RequestParams.channel;      
        channelName = req.body.RequestParams.channel.toUpperCase()
        username = config['TC_API_USERNAME' + '_' + channelName];
        password = config['TC_API_PASSWORD' + '_' + channelName];
    }else{
        username = config.TC_API_USERNAME;
        password = config.TC_API_PASSWORD;
    }
    // authenticate
    var post_data = querystring.stringify({
        'j_username': username,
        'j_password': password,
        'submit': 'login'
    });
    var reqObj = {
        host: config.TC_SERVER_NAME,
        //host:'api-verizon-dev.touchcommerce.com',
        method: 'POST',
        path: config.TC_FORM_LOGIN_URI,
        agent: proxy.agent,
        ca:proxy.ca,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': Buffer.byteLength(post_data)
        },
        rejectUnauthorized: true
    };

    logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));

    var proxyRequest = https.request(reqObj, function(proxyResponse) {
        var sessionCookie = proxyResponse.headers["set-cookie"].toString().split(";");
        proxyResponse.setEncoding('utf8');

        proxyResponse.on('data', function(chunk) {
            if (sessionCookie) {
                req.session.sessionCookie = sessionCookie[0];
                //logger.access.info('Authenticated to Touchcommerce');
                logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                next();
            } else {
                if(req.session && req.session.sessionCookie){
                    //req.session.sessionCookie = null;
                }
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
        });
        proxyResponse.on('error', function(err) {
            if(req.session && req.session.sessionCookie){
                //req.session.sessionCookie = null;
            }
            logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
            res.send(err);
        });
    });

    proxyRequest.write(post_data);
    proxyRequest.end();
};

// Check authentication Touchcommerce
var isAuthenticated = function(req, res, next) {
    if (req.session && req.session.sessionCookie) {
        logger.general.info(logger.formatInfoMsg(req.session.id, req.session.sessionCookie + " is Authenticated!"));
        next();
    } else {
        logger.general.info(logger.formatInfoMsg(req.session.id, "redirect to authenticate"));
        authenticateTouchCommerce(req, res, next);
    }
};

// routes
var agentAvailabilityRoute = require('./api/modules/agentAvailability/agentAvailability.route');
var engagementRoute = require('./api/modules/engagement/engagement.route');
var getMessageRoute = require('./api/modules/getMessage/getMessage.route');
var customerIsTypingRoute = require('./api/modules/customerIsTyping/customerIsTyping.route');
var sendMessageRoute = require('./api/modules/sendMessage/sendMessage.route');
var dataPassRoute = require('./api/modules/dataPass/dataPass.route');
var dataPassForSalesRoute = require('./api/modules/dataPass/dataPassForSales.route');
var udmConnection = require('./api/modules/udmConnection/udmConnection.route');
var conversionRoute = require('./api/modules/conversion/conversion.route');
var sendEmailRoute = require('./api/modules/sendEmail/sendEmail.route');

// api services
app.post('/mfchatnode/rest/agent', isAuthenticated, agentAvailabilityRoute);
app.post('/mfchatnode/rest/engagement', isAuthenticated, engagementRoute);
app.post('/mfchatnode/rest/message/:engagementID', isAuthenticated, getMessageRoute);
app.post('/mfchatnode/rest/message', isAuthenticated, sendMessageRoute);
app.post('/mfchatnode/rest/customerIsTyping', isAuthenticated, customerIsTypingRoute);
app.post('/mfchatnode/rest/dataPassForSales', isAuthenticated, dataPassForSalesRoute);
app.post('/mfchatnode/rest/dataPass', isAuthenticated, dataPassRoute);
app.post('/mfchatnode/rest/udmConnection', udmConnection);
app.post('/mfchatnode/rest/conversion', isAuthenticated, conversionRoute);
app.post('/mfchatnode/rest/sendEmail', isAuthenticated, sendEmailRoute);

//IsALive for the App
app.get('/mfchatnode/isAlive', function(req, res) {
    res.send(200).end();
});

//Check for the req, res, error and pass on the next  ---- Catches the uncaught exceptions here.
app.use(function (err, req, res, next) {
    //res.send(500, "Something bad happened. :(");  /// Need to decide what do we need to do.
    if(req.session && req.session.isGetMsgRecur){
        if(req.session && req.session.isTMP){
            function getLPMsgReccursive(){                       
                apiLPUtils.formattedGetLPMsg(req, res, function(chunk) {                       
                    res.status(200).end();
                    if(chunk){
                        req.session.isGetMsgRecur = false;   
                        return;
                    }else{
                        setTimeout(function () {
                            req.session.isGetMsgRecur = true;
                            getLPMsgReccursive();
                        }, 5000);                            
                    }                        
                });
            }                     
            getLPMsgReccursive();
        }else{
            function getMsgReccursive(){                         
                apiUtils.formattedGetMsg(req, res, function(chunk) {                    
                    res.status(200).end();
                    if(chunk){
                        req.session.isGetMsgRecur = false;
                        return;
                    }else{
                        req.session.isGetMsgRecur = true;
                        getMsgReccursive();
                    }                        
                });
            }                     
            getMsgReccursive();
        } 

    }
    if(req.session){
        logger.error.error('SessionID: ' + req.session.id, 'Response Body',  CircularJSON.stringify(err.stack) , ' HTTP ' + req.method + " " + req.hostname + ' ' + req.path);
    } 
});
process.env.UV_THREADPOOL_SIZE = 128;
app.listen(port);


logger.access.info(process.env.NODE_ENV);
logger.general.info("Server restarted with build number: "+ "213");
console.log('Application is running on this port http://localhost:' + port);
logger.general.info("Current Environment #"+ config.Current_Env);
