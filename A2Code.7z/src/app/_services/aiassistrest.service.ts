import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/catch';

import { Agent } from '../_models/agent';
import { Intent } from '../_models/intent';
import { UserExpression } from '../_models/userexpression';
import { ReqBodyHelper } from '../_helpers/reqBodyHelper';
import { AIAssistCacheService } from './aiassistcache.service';

@Injectable()
export class AIAssistRestService {
  urlSecKey:string ="sf34r23rwefdwet34sewr34";
  baseURL:string = '';
  engineURL:string = '';
    constructor(private http: Http) {
    }

    updateEngineURL(appRootPath: string) {
      this.engineURL = appRootPath;
    }

    getAllAgents() {
        let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
        return this.http.post(this.baseURL + this.engineURL + 'config/getAllAgents',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    getAgentById(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
      return this.http.post(this.baseURL + this.engineURL + 'config/getAgentById',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    createAgent(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
       return this.http.post(this.baseURL + this.engineURL + 'config/createAgent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    removeAgent(pAgent:Agent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqAgent = pAgent;
       return this.http.post(this.baseURL + this.engineURL + 'config/deleteAgent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    createIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
       return this.http.post(this.baseURL + this.engineURL + 'config/createIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    removeIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
       return this.http.post(this.baseURL + this.engineURL + 'config/deleteIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    updateIntent(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
      return this.http.post(this.baseURL + this.engineURL + 'config/updateIntent', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    getIntentById(pIntent:Intent) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqIntent = pIntent;
      return this.http.post(this.baseURL + this.engineURL + 'config/getIntentById',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    createUserExpressions(pUserExpressions: Array<UserExpression>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqUserExpressions = pUserExpressions;
      return this.http.post(this.baseURL + this.engineURL + 'config/createUserExpression',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    deleteUserExpressions(pUserExpression: Array<UserExpression>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqUserExpressions = pUserExpression;
      return this.http.post(this.baseURL + this.engineURL + 'config/deleteUserExpression',reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    updateParmeter(pParamInfoVOList: Array<any>) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqParamInfoVOList = pParamInfoVOList;
      console.log(JSON.stringify(reqBodyGenerator.getRequestBody()));
      return this.http.post(this.baseURL + this.engineURL + 'config/updateParameter', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    publishIntents() {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      return this.http.post(this.baseURL + this.engineURL + 'config/publishIntents', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    publishSelectedIntents(pIntentsSelected: Array<Intent>, pPublishEnvironment: string) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.intentsToPublish = pIntentsSelected;
      reqBodyGenerator.reqPublishEnvironment = pPublishEnvironment;
      return this.http.post(this.baseURL + this.engineURL + 'config/publishIntents', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    getIntentsforPublish(pPublishEnvironment: string) {
      let reqBodyGenerator : ReqBodyHelper = new ReqBodyHelper();
      reqBodyGenerator.reqPublishEnvironment = pPublishEnvironment;
      return this.http.post(this.baseURL + this.engineURL + 'config/getUnPublishedIntents', reqBodyGenerator.getRequestBody(), this.jwt()).map((response: Response) => response.json());
    }

    private jwt() {
            //let headers = new Headers({});
            return new RequestOptions({ withCredentials: true });
    }

 private extractData(res: Response) {
        let body = res.json();
        return body.data || { };
    }

   private handleError (error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

}
