/**
 * @ngdoc property
 * @name investordetails Directive
 * @description
 *
 * investordetails - Displays the Review & Confirm - Select Investor Details
 *
 **/
'use strict';

var investordetails = function(transactModel, eventConstants) {    
	return {
        template: require('./investordetails.html'),
        restrict: 'EA',
        replace: true,
        scope:{

        },
        controller: function($scope, $element, $attrs){            

            var invDetails = transactModel.getInvestorDetails();

            $scope.investorObj = [
                {
                    text: "Folio No.",
                    value: invDetails.folioId
                },
                {
                    text: "First Holder Name",
                    value: invDetails.custName
                },
                {
                    text: "PAN",
                    value: invDetails.pan
                },            
                {
                    text: "E-Mail",
                    value: invDetails.emailId
                },            
                {
                    text: "Mobile",
                    value: invDetails.mobile
                },            
                {
                    text: "Second Holder Name",
                    value: (invDetails.holders.length>1)?invDetails.holders[1].name : "NA" //invDetails.holders[1].name
                },            
                {
                    text: "Third Holder name",
                    value: (invDetails.holders.length>2)?invDetails.holders[2].name : "NA" //invDetails.holders[2].name
                }
            ];
            
        },
        link: function(scope, element, attrs, ctrl){
        }
    }
};

investordetails.$inject = ['transactModel', 'eventConstants'];
module.exports = investordetails;