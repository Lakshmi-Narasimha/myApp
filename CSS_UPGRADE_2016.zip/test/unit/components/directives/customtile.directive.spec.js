'use strict';

/*Unit test case for custom tile*/

describe('directive: custom tile', function() {

    var scope, compile, validHTML, phoneFormat, componentConstant, elementSlickIndex, clickedContent, typeElement;

    validHTML = '<tile-element></tile-element>';
    beforeEach(module('CSS.billing'));
    // beforeEach(module('CSSRedesign.component'));
    beforeEach(module('component.tile'));
    beforeEach(module('templates'));

    beforeEach(function() {
        module(function($provide) {
            $provide.constant('componentConstant', {
                'policy_status_constants': {
                    'active': 'A',
                    'cancelled': 'C',
                    'expired': 'E'
                }
            });
        });
    });

    beforeEach(inject(function($compile, $rootScope) {
        scope = $rootScope.$new();
        compile = $compile;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();

        return compiledElem;
    }

    describe('when changing the scope values with single-tile', function() {
        var event;
        beforeEach(function() {
            event = document.createEvent("MouseEvent");
            //event.currentTarget ="<div class='tile'></div>";
            event.initMouseEvent("click", true, true);
            scope.content = {
                'zipCode': '90000',
                'umbrellaPolicyAmount': null,
                'subjectOfInsurance': null,
                'streetAddress2': null,
                'streetAddress1': '3041 Cochran St',
                'state': 'CA',
                'policyType': 'Condo',
                'policyStatus': 'C',
                'policyRoleType': 'PNI',
                'policyRenewalDate': '2015-02-05',
                'policyNickName': 'My Home',
                'policyEffectiveDate': '2014-12-07',
                'policyDescription': '401 College Park Rd',
                'policyContractnumber': 'A1234567',
                'policyClickable': false,
                'deathBenefitsValue': null,
                'cashSurrenderValue': null,
                'policyCancellationDate': '2015-02-05',
                'phoneNumber': '6665554444',
                'numberOfVehicles': null,
                'middleName': 'M',
                'lineOfBusiness': 'HOME',
                'lifePolicyPlanCode': null,
                'lifePolicyAmount': null,
                'lastName': 'Wall',
                'firstName': 'Joe',
                'ePolicyIndicator': 'N',
                'emailAddress': 'joe@gmail.com',
                'city': 'Simi valley',
                'beneficiaries': null,
                'billingInformation': {
                    'eBillingIndicator': 'Y',
                    'scheduledPaymentFlag': 'N',
                    'scheduledPaymentDate': null,
                    'scheduledPaymentAmount': null,
                    'reinstatementFlag': 'N',
                    'recuringPaymentDueDate': null,
                    'payplanLabel': 'Two',
                    'payplanCode': 'A2',
                    'paymentDueDate': null,
                    'paymentDueAmount': 0.0,
                    'paperlessFlag': 'Y',
                    'NOCFlag': 'Y',
                    'nextPaymentDueDate': '2017-02-01',
                    'mortgageeIndicator': 'N',
                    'IENFlag': 'N',
                    'dunningLevel': '00',
                    'CEAIndicator': 'N',
                    'billingAccountStatus': 'OK',
                    'billingAccountNumber': 'BA123456',
                    'autoPaymentMethod': null,
                    'autoPaymentFlag': 'N',
                    'agentofRecord': '2202102',
                    'accountBalanceAmount': 402.4
                },
                'agentOfRecordId': 'AG001',
                'addressType': 'HOME'
            };

            scope.agentInformationList = {
                'agentWebsiteURL': 'www.google.com',
                'agentPictureURL': 'https://www.farmersagent.com/Assets/Agents/dseymore/ProfileImages/dseymore.jpg',
                'agentPhone': '7776664444',
                'agentOfRecordId': 'AG002',
                'agentName': 'John Smith',
                'agentFax': '09988288383',
                'agentEmailAddress': 's123@t.com',
                'agentAddress': '3041 Cochran St'
            };

            validHTML = '<tile-element content="content" elementid="policySlideTile"  elementindex="0" agentslist="agentInformationList" type="policyType"></tile-element>';
            scope.$digest();

        });

        it('trigger click event and destroy element', function() {
            var el = create();
            var isoScope = el.isolateScope();
            el.isolateScope().expand(event);
        });

        it('trigger click event and define tileClass function', function() {
            var el = create();
            var isoScope = el.isolateScope();
            isoScope.parenttype = 'policydetailtype';
            el.isolateScope().tileClass();


        });

        it('trigger click event and define expandDetail function', function() {
            var el = create();
            var isoScope = el.isolateScope();
            el.isolateScope().expandDetail(elementSlickIndex, clickedContent);
            // angular.element(".policy-detail-head-carousel .slick-slide").trigger('click')

        });

        it('trigger click event and define tiletype function', function() {
            var el = create();
            var isoScope = el.isolateScope();
            isoScope.type = 'vehicletype';
            isoScope.contentType = 'auto';
            el.isolateScope().tiletype(typeElement);
        });
    });

    // xdescribe('when changing the scope values with multi-tile', function() {

    //     beforeEach(function() {

    //         scope.content = {
    //             'zipCode': '90000',
    //             'umbrellaPolicyAmount': null,
    //             'subjectOfInsurance': [{
    //                 'vehicleYear': '2014',
    //                 'vehicleVIN': 'IASDFGH1234567890',
    //                 'vehicleModel': 'ACCORD',
    //                 'vehicleMake': 'HONDA',
    //                 'vehicleImageURL': 'https://media.carbook.com/autoBuilderData/stockPhotos/6528.jpg ',
    //                 'vehicleID': 'V1000000001',
    //                 'expirationDate': '2015-02-05',
    //                 'firstName': null,
    //                 'lastName': null,
    //                 'dateOfBirth': null

    //             }, {
    //                 'vehicleYear': '2013',
    //                 'vehicleVIN': 'IASDFGH1234567899',
    //                 'vehicleModel': 'CIVIC',
    //                 'vehicleMake': 'HONDA',
    //                 'vehicleImageURL': 'https://media.carbook.com/autoBuilderData/stockPhotos/6528.jpg ',
    //                 'vehicleID': 'V100000002',
    //                 'expirationDate': '2015-02-05',
    //                 'firstName': null,
    //                 'lastName': null,
    //                 'dateOfBirth': null

    //             }],
    //             'streetAddress2': null,
    //             'streetAddress1': '3041 Cochran St',
    //             'state': 'CA',
    //             'policyType': 'AUTO',
    //             'policyStatus': 'A',
    //             'policyRoleType': 'PNI',
    //             'policyRenewalDate': '2015-02-05',
    //             'policyNickName': 'My Cars',
    //             'policyEffectiveDate': '2014-12-07',
    //             'policyDescription': '2014 Honda Accord',
    //             'policyContractnumber': 'A7654321',
    //             'policyCancellationDate': '2015-02-05',
    //             'phoneNumber': '6665554444',
    //             'deathBenefitsValue': null,
    //             'cashSurrenderValue': null,
    //             'numberOfVehicles': 2,
    //             'middleName': 'M',
    //             'lineOfBusiness': 'AUTO',
    //             'lifePolicyPlanCode': null,
    //             'lifePolicyAmount': null,
    //             'lastName': 'Wall',
    //             'firstName': 'Joe',
    //             'ePolicyIndicator': 'N',
    //             'emailAddress': 'joe@gmail.com',
    //             'city': 'Simi valley',
    //             'beneficiaries': null,
    //             'agentOfRecordId': 'AG001',
    //             'addressType': 'HOME',
    //             'billingInformation': {
    //                 'eBillingIndicator': 'Y',
    //                 'scheduledPaymentFlag': 'N',
    //                 'scheduledPaymentDate': null,
    //                 'scheduledPaymentAmount': null,
    //                 'reinstatementFlag': 'N',
    //                 'recuringPaymentDueDate': null,
    //                 'payplanLabel': 'Two',
    //                 'payplanCode': 'A2',
    //                 'paymentDueDate': null,
    //                 'paymentDueAmount': 0.0,
    //                 'paperlessFlag': 'Y',
    //                 'NOCFlag': 'Y',
    //                 'nextPaymentDueDate': '2017-02-01',
    //                 'mortgageeIndicator': 'N',
    //                 'IENFlag': 'N',
    //                 'dunningLevel': '00',
    //                 'CEAIndicator': 'N',
    //                 'billingAccountStatus': 'OK',
    //                 'billingAccountNumber': 'BA123456',
    //                 'autoPaymentMethod': null,
    //                 'autoPaymentFlag': 'N',
    //                 'agentofRecord': '2202102',
    //                 'accountBalanceAmount': 402.4
    //             },

    //         };
    //         scope.agentInformationList = {
    //             'agentWebsiteURL': 'www.google.com',
    //             'agentPictureURL': 'https://www.farmersagent.com/Assets/Agents/dseymore/ProfileImages/dseymore.jpg',
    //             'agentPhone': '7776664444',
    //             'agentOfRecordId': 'AG002',
    //             'agentName': 'John Smith',
    //             'agentFax': '09988288383',
    //             'agentEmailAddress': 's123@t.com',
    //             'agentAddress': '3041 Cochran St'
    //         };

    //         validHTML = '<tile-element content=content elementid="policySlideTile"  elementindex=0 agentslist=agentInformationList type="policyType"></tile-element>';
    //         scope.$digest();

    //     });



    //     it('should have ', function() {
    //         var el = create();
    //         var isoScope = el.isolateScope();
    //         // expect(el.hasClass('multi-tile')).toBeTruthy();
    //         expect(el.isolateScope().isCancelledpolicy).toBeFalsy();
    //     });
    // });

    // xdescribe('when changing the scope values with vehicleTile', function() {

    //     beforeEach(function() {

    //         scope.content = {
    //             'vehicleYear': '2013',
    //             'vehicleVIN': 'IASDFGH1234567899',
    //             'vehicleModel': 'CIVIC',
    //             'vehicleMake': 'HONDA',
    //             'vehicleImageURL': 'https://media.carbook.com/autoBuilderData/stockPhotos/6528.jpg ',
    //             'vehicleID': 'V100000002',
    //             'expirationDate': '2015-02-05',
    //             'firstName': null,
    //             'lastName': null,
    //             'dateOfBirth': null,
    //             'errorCode': null,
    //             'errorDescription': null,
    //             'transactionStatus': 'Success'

    //         };

    //         scope.elementid = 'vehicleTile';

    //         validHTML = '<tile-element content=content elementid=elementid elementidchange="true"  elementindex=10  type="vehicletype"></tile-element>';
    //         scope.$digest();

    //     });

    //     // it('should have vehicle-tile Class', function() {
    //     //     var el = create();
    //     //     var isoScope = el.isolateScope();
    //     //     console.log(el);
    //     //     expect(el.hasClass('vehicle-tile')).toBeTruthy();
    //     // });

    //     it('should have elementidchange ', function() {
    //         var el = create();
    //         var isoScope = el.isolateScope();
    //         expect(el.isolateScope().tileElementId).toMatch('vehicleTile-10');
    //     });
    // });
});
