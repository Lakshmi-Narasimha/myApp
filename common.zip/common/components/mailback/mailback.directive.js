'use strict';

var mailback = function(mailBackPostService, $state, dateDetailsModel, authenticationService, events) {
	return {
            template: require('./mailback.html'),
            restrict: 'E',
            replace: true,
            scope: {
                placement : '@?',
                mailBackOptions : '=?',
                reportCode:'=?',
                moduleName:'@?',
                dividendsMailBack:'@',
                recommDt:'=?'
            },
            controller:['$scope', function($scope){   

                $scope.showPDF = true;
                $scope.showExcel = true;
                $scope.setMonthAndYear = function(){
                    $scope.details = dateDetailsModel.getDateDtls();
                };

                if ($scope.mailBackOptions && $scope.mailBackOptions.mailBackType) {

                    $scope.showExcel = $scope.showPDF = false;

                    if($scope.mailBackOptions.mailBackType === 'excel' || $scope.mailBackOptions.mailBackType === 'EXCEL') {

                        $scope.showExcel = true;

                    } else if ($scope.mailBackOptions.mailBackType === 'pdf' || $scope.mailBackOptions.mailBackType === 'PDF') {

                        $scope.showPDF = true;

                    }
                }  
                
                if($state.current.parent === 'overview' || $state.current.parent ==='capitalgains' ){
                    $scope.showExcel = false; 
                }

                if($scope.reportCode == undefined) {
                    $scope.reportCode = ' ';
                }    
            }],
            link: function(scope){
                scope.mailback = function(type,rc,recommDt){

                    if($state.current.name === 'smartSol.planSmartSolution.ssBase.goalSheetSummary' || authenticationService.isFromGoalSheet){
                        scope.$emit('goalSheetEmail');
                    } else if(scope.moduleName === 'Investor') {
                        var data = {};
                        data.reportCode = rc;
                        data.type = type;
                        events.emitMailbackClick(scope, data);
                    } else{
                        mailBackPostService.postMailBackDetails(type,rc,'',recommDt);
                        scope.closePop = false;
                    }
                }   
            }
        };
};

mailback.$inject = ['mailBackPostService', '$state', 'dateDetailsModel', 'authenticationService', 'events'];
module.exports = mailback;