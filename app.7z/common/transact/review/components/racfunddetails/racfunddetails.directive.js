/**
 * @ngdoc property
 * @name fticracFundDetails Directive
 * @description
 *
 * fticracFundDetails - Displays the Review & Confirm - Select Fund Details
 *
 **/
'use strict';

var racFundDetails = function(transactModel, eventConstants, racFundDetailsFactory, authenticationService, $state) {
    return {
        template: require('./racfunddetails.html'),
        restrict: 'EA',
        replace: true,
        scope: {

        },
        controller: function($scope) {
            var _userType = authenticationService.getUser().userType;
            var fundDetails = transactModel.getFundDetails();
            var invDetails = transactModel.getInvestorDetails();
            $scope.headerText = racFundDetailsFactory.getExactHeaderText(_userType);
            console.log($state);
            if ($state.current.url === '/cancelStp') {
                $scope.fundObj = racFundDetailsFactory.getFormattedCstpFundDetails(_userType, invDetails, fundDetails);
            }else if($state.current.url === '/stp'){
                $scope.fundObj = racFundDetailsFactory.getFormattedSTPFundDetails(_userType, invDetails, fundDetails); 
            }
            else if($state.current.url === '/dtp'){
                $scope.fundObj = racFundDetailsFactory.getFormattedDtpFundDetails(_userType, invDetails, fundDetails); 
                
            }else if($state.current.url === '/renewsip'){
                $scope.fundObj = racFundDetailsFactory.getFormattedRenewFundDetails(_userType, invDetails, fundDetails); 
                
            }
            else {
                var isSwitchFund = ($state.current.url === '/switch');
                $scope.fundObj = racFundDetailsFactory.getFormattedFundDetails(_userType, invDetails, fundDetails, isSwitchFund);
            }
            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function() {
                $scope.$emit('NAVIGATE_TO_TRANSACT', { key: 'Fund' });
            });
        },
        link: function() {}
    };
};

racFundDetails.$inject = ['transactModel', 'eventConstants', 'racFundDetailsFactory', 'authenticationService', '$state'];
module.exports = racFundDetails;
