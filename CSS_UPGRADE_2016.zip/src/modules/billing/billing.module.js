(function() {
    'use strict';
    angular.module('CSS.billing', ['ui.bootstrap', 'ui.router', 'ngAnimate', 'CSS.common'])
        .config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
            $stateProvider
                .state('billing', {
                    url: '/billing',
                    abstract: true,
                    views: {
                        "main": {
                            controller: 'billingCtrl',
                            templateUrl: window.UIC.sitePrefix + 'modules/billing/billing.html'
                        }
                    },
                    data: {
                        pageTitle: 'billing'
                    }
                })
                .state('billing.authentication', {
                    url: '/authentication',
                    params: {errorData: null},
                    parent: 'billing',
                    views: {
                        "main": {
                            controller: 'authCtrl',
                            controllerAs: 'authVM',
                            templateUrl: window.UIC.sitePrefix + 'modules/billing/partials/authentication.html',
                        }
                    },
                    data: {
                        pageTitle: 'authentication'
                    }
                })
                .state('billing.makeapayment', {
                    url: '/makeapayment',
                    parent: 'billing',
                    views: {
                        "main": {
                            controller: 'makeapaymentCtrl',
                            controllerAs: 'paymentVM',
                            templateUrl: window.UIC.sitePrefix + 'modules/billing/partials/makeapayment.html',
                        }
                    },
                    data: {
                        pageTitle: 'makeapayment'
                    }
                });
        }]);
})();