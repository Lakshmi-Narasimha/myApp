﻿define(['appcommon/commonutility', 'Base64'], function (Util, Base64) {
   TaskContext = function () {
       // private instvars
        var currentTaskFMID = null;
        var userList = [];

       //Public
        this.getTaskFMID = function () {
            if (currentTaskFMID) {
                return currentTaskFMID;
            } else {
                return Util.userFMID();
            }
        }

        this.saveLastTaskFMID = function (fmid) {
            currentTaskFMID = fmid;
        }

        this.setUserList = function (users) {
            userList = users;
            var signedUserFMID = Util.userFMID();
            // safety....if signed on user is missing from the list add a user to represent him/her
            var signedUser = _.find(users, function (user) { return user.fmid == signedUserFMID; })
            if (!signedUser) {
                userList.push({
                    fmid: signedUserFMID,
                    name: "SignedOn User",
                    firstName: "SignedOn",
                    lastName: "User"
                });
            }
            // validate that the "current" user is still valid
            if (currentTaskFMID) {
                if (!(_.contains(_.pluck(self.taskUsers, 'fmid'), contextFMID))) {
                    TaskContext.saveLastTaskFMID(signedUserFMID);
                }
            }
        }

        this.isTaskSignedOnUser = function () {
            return this.getTaskFMID() == Util.userFMID();
        }

        this.getUserList = function () {
            return userList;
        }
    }
   return new TaskContext();
});