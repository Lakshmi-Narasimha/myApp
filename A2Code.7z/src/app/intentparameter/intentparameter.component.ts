import { Component, Directive, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Parameter } from '../_models/parameter';
import { ParamField } from '../_models/paramfield';
import { ModalDirective, ModalOptions } from 'ng2-bootstrap';
import { DragulaModule, DragulaService } from 'ng2-dragula/ng2-dragula';
import * as $ from 'jquery';

//declare var jQuery:any;


@Component({
  selector: 'intentparameter',
  templateUrl: './intentparameter.component.html',
  styleUrls: ['./intentparameter.component.css']
})

export class IntentparameterComponent implements OnInit {

  public radioModel: string = null;
  editMode: boolean = true;
  isParametersModified: boolean = false;
  paramCategories: Array<string> = [];
  //paramCategoryMap: any = {};
  cacheOriginParameters: Array<Parameter> = [];
  selectedParameters : Array<Parameter> = [];
  unSelectedParameter : Array<Parameter> = [];
  availParameters: Array<Parameter> = [];
  addedParameters: Array<Parameter> = [];
  selectedParamCategory: string = null;
  allowAddition: boolean = false;
  editingParam: any = {};
  formErrors : any = {};

  modalOptions : ModalOptions ={
  backdrop: "static",
  keyboard: false,
  focus: true,
  show: true,
  ignoreBackdropClick: false
};



  @ViewChild('respParamEditModal') public respParamEditModal: ModalDirective;

  /** --START-- Constructor and initial Functions or Methods*/

  constructor(private aiAssistCacheService: AIAssistCacheService, private dragulaService: DragulaService) {
    this.subscribefordata();
    this.initDragulaComponent();
  }

  ngOnInit() {
  }

  private subscribefordata() {

    this.aiAssistCacheService.activeParamListObservable.subscribe((data) => {
      this.paramCategories = data;
      this.initParameter();
    });

    // this.aiAssistCacheService.selectedListObservable.subscribe((data) => {
    //   this.selectedParameters = data;
    //   this.initParameter();
    // });

    // this.aiAssistCacheService.unSelectedListObservable.subscribe((data) => {
    //   this.unSelectedParameter = data;
    //   this.initParameter();
    // });

    // this.aiAssistCacheService.activeParamMapObservable.subscribe((data) => {
    //   this.paramCategoryMap = data;
    //   this.initParameter();
    // });

    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });

  }

initParameter() {
  this.availParameters = new Array<Parameter>();
  this.addedParameters = new Array<Parameter>();
// console.log("initParamter");
  // if (this.paramCategories && this.paramCategories.length > 0)
  //   if (!this.selectedParamCategory)
  //     this.selectedParamCategory = this.paramCategories[0];
  //
  // if (this.paramCategoryMap && this.selectedParamCategory && this.paramCategoryMap[this.selectedParamCategory])
  //   this.cacheOriginParameters = this.paramCategoryMap[this.selectedParamCategory];

  // if (this.cacheOriginParameters && this.cacheOriginParameters.length > 0) {
  //   for (var i = 0; i < this.cacheOriginParameters.length; i++) {
  //     this.initParameters(this.cacheOriginParameters[i]);

  if (this.selectedParameters && this.selectedParameters.length > 0) {
    for (var i = 0; i < this.selectedParameters.length; i++) {
      let i_parameter: Parameter = this.selectedParameters[i];
      if (i_parameter.response && !i_parameter.fieldText) {
        i_parameter.fieldText = i_parameter.response;
      }
      this.initLinkOfParameter(i_parameter);
      //console.log(i_parameter);
      if (i_parameter.paramList) {
        for (var j = 0; j < i_parameter.paramList.length; j++) {
          this.initParameters(i_parameter.paramList[j]);
        }
      }
    }
  }

  if (this.unSelectedParameter && this.unSelectedParameter.length > 0) {
    for (var i = 0; i < this.unSelectedParameter.length; i++) {
      let i_parameter: Parameter = this.unSelectedParameter[i];
      if (i_parameter.response && !i_parameter.fieldText)
        i_parameter.fieldText = i_parameter.response;
        this.initLinkOfParameter(i_parameter);
        //console.log(i_parameter);
      if (i_parameter.paramList) {
        for (var j = 0; j < i_parameter.paramList.length; j++) {
          this.initParameters(i_parameter.paramList[j]);
        }
      }
    }
  }

  // if (this.cacheOriginParameters[i].defaultFieldText && !this.cacheOriginParameters[i].fieldText)
  //   this.cacheOriginParameters[i].fieldText = this.cacheOriginParameters[i].defaultFieldText;

  this.addedParameters = this.selectedParameters;
  this.availParameters = this.unSelectedParameter;

  // if (this.cacheOriginParameters[i].alreadyAdded) {
  //   this.cacheOriginParameters[i].isAvailableParam = false;
  //   this.addedParameters.push(this.cacheOriginParameters[i]);
  // } else {
  //   this.cacheOriginParameters[i].isAvailableParam = true;
  //   this.availParameters.push(this.cacheOriginParameters[i]);
  // }
}

initLinkOfParameter(pParameter: Parameter) {
  // console.log(pParameter);
  // if (pParameter.fieldText && pParameter.fieldText.indexOf("<a>") > -1 && pParameter.fieldText.indexOf("</a>") > -1) {
  //   pParameter.isLinkAvailable = true;
  //   pParameter.linkText = pParameter.fieldText.substring(pParameter.fieldText.indexOf("<a>"));
  //   pParameter.linkText = pParameter.linkText.replace("<a>","").replace("</a>","");
  //   pParameter.fieldText = pParameter.fieldText.slice(0,pParameter.fieldText.indexOf("<a>"));
  //   // console.log(pParameter);
  //   // console.log(pParameter.linkText);
  //   // console.log(pParameter.fieldText);
  // }
  if (pParameter.paramList && pParameter.paramList.length > 0) {
    pParameter.isPopupRequired = true;
  }
}

  /** --END-- Constructor and initial Functions or Methods*/

  /** --START-- Functions or Methods related to DragulaComponent */

  private initDragulaComponent() {
    this.dragulaService.drag.subscribe((value) => {
      this.onDrag(value.slice(1));
    });
    this.dragulaService.drop.subscribe((value) => {
      this.onDrop(value.slice(1));
    });
    this.dragulaService.over.subscribe((value) => {
      this.onOver(value.slice(1));
    });
    this.dragulaService.out.subscribe((value) => {
      this.onOut(value.slice(1));
    });
  }

  private hasClass(el: any, name: string) {
    return new RegExp('(?:^|\\s+)' + name + '(?:\\s+|$)').test(el.className);
  }

  private addClass(el: any, name: string) {
    if (!this.hasClass(el, name)) {
      el.className = el.className ? [el.className, name].join(' ') : name;
    }
  }

  private removeClass(el: any, name: string) {
    if (this.hasClass(el, name)) {
      el.className = el.className.replace(new RegExp('(?:^|\\s+)' + name + '(?:\\s+|$)', 'g'), '');
    }
  }

  private onDrag(args) {
    let [e, el] = args;
    this.removeClass(e, 'ex-moved');
  }

  private onDrop(args) {
    let [e, el] = args;
    this.addClass(e, 'ex-moved');

    if (args[1].id == "addedResponse") {
      let movedParameter = this.findParameterObject(args[0].id, this.addedParameters);
      // console.log(movedParameter);
      // console.log("movedParameter");
      // console.log(movedParameter);
      if (movedParameter) {
        this.editingParam = movedParameter;
        this.formErrors = {};
        if (this.editingParam.paramList && this.editingParam.paramList.length > 0)
          this.respParamEditModal.show();
        else {
          this.editingParam.isModified = true;
          this.updateParametersModified();

          if (this.editingParam.isAvailableParam)
            this.editingParam.isAvailableParam = false;
        }
      }
    } else {
      let movedParameter = this.findParameterObject(args[0].id, this.availParameters);
      if (movedParameter) {
        this.editingParam.isModified = true;
        this.updateParametersModified();
        if (!movedParameter.isAvailableParam)
          movedParameter.isAvailableParam = true;
      }
    }
  }

  private onDropModel(args) {
    let [el, target, source] = args;
  }

  private onOver(args) {
    let [e, el, container] = args;
    this.addClass(el, 'ex-over');
  }

  private onOut(args) {
    let [e, el, container] = args;
    this.removeClass(el, 'ex-over');
  }

  /** --END-- Functions or Methods related to DragulaComponent */

  /** --START-- Functions or Methods related to DialogModal events and Handling Parameters modification */

  hideRespParamEditModal() {
    this.respParamEditModal.hide();
    $(document.body).removeClass("modal-open");
    $(".modal-backdrop").remove();
  }

  public onResponseParamClick(param: any) {
    this.editingParam = param;
    this.formErrors = {};
    this.respParamEditModal.show();
  }

  public textParameterModified(event,pParameter: Parameter) {
    pParameter.isModified = true;
    let htmlText = event.target.innerHTML;
    htmlText = htmlText.replace("&lt;a&gt;","<a>");
    htmlText = htmlText.replace("&lt;/a&gt;","</a>");
    pParameter.fieldText = htmlText;
    this.updateParametersModified();
  }

  public updateParametersModified() {
    this.isParametersModified = true;
    this.aiAssistCacheService.parametersModified(this.addedParameters, this.availParameters);
  }

  public findParameterObject(parameterName: string, parametersList: Array<Parameter>) {
    let resultParameter = parametersList.filter(parameter => {
      return parameter.paramType === parameterName;
    });
    if (resultParameter && resultParameter.length > 0)
      return resultParameter[0];
    else
      return null;
  }

  public initParameters(pParameter: ParamField) {
    if (pParameter != null && pParameter != undefined) {
      if (pParameter.fieldType == "text") {
        if (pParameter.paramValue)
          pParameter.textValue = pParameter.paramValue;
        else
          pParameter.textValue = pParameter.paramValue = "";
      }
      if (pParameter.fieldType == "select") {
        if (pParameter.parsedFieldValues == null || pParameter.parsedFieldValues == undefined || (pParameter.parsedFieldValues != null && pParameter.parsedFieldValues.length == 0)) {
          pParameter.parsedFieldValues = [];
          var data = pParameter.fieldValues.replace("[", "").replace("]", "");
          var arrData = data.split(",");
          if ( arrData && arrData.length > 0 ) {
            var firstValue = arrData[0].split(":");
            if (firstValue[1].toUpperCase() == "SELECT") {
              pParameter.parsedFieldValues.push({ id: "-1", label: "Select" });
            } else {
              pParameter.parsedFieldValues.push({ id: "-1", label: "Select" });
              pParameter.parsedFieldValues.push({ id: firstValue[0], label: firstValue[1] });
            }
            let i = 1;
            for (; i < arrData.length; i++) {
              var keyvalue = arrData[i].split(":");
              pParameter.parsedFieldValues.push({ id: keyvalue[0], label: keyvalue[1] });
            }
          }
        }
        if (pParameter.paramValue) {
          pParameter.selectValue = pParameter.paramValue;
        } else {
          if (pParameter.parsedFieldValues && pParameter.parsedFieldValues.length > 0)
            pParameter.selectValue = pParameter.parsedFieldValues[0].id;
          else
            pParameter.selectValue = "-1";
        }
      }
      if (pParameter.fieldType == "radio") {
        if (pParameter.parsedFieldValues == null || pParameter.parsedFieldValues == undefined || (pParameter.parsedFieldValues != null && pParameter.parsedFieldValues.length == 0)) {
          pParameter.parsedFieldValues = [];
          var arrData = pParameter.fieldValues.split(":");
          for (var i = 0; i < arrData.length; i++) {
            pParameter.parsedFieldValues.push({ id: arrData[i], label: arrData[i] });
          }
        }
        if (pParameter.radioValue == null || pParameter.radioValue == undefined)
          pParameter.radioValue = pParameter.paramValue;
      }
      if (pParameter.fieldType == "checkbox") {
        if (pParameter.checkValue == null || pParameter.checkValue == undefined)
          pParameter.checkValue = pParameter.paramValue == "Y" ? true : false;
      }
    }
    return pParameter.parsedFieldValues;
  }

  public onClickEditingParamModal_OK() {
  let somethingModified = false;
  let isRequiredModified = true;
  let isAnyRequiredField = 0;
  if (this.editingParam.paramList && this.editingParam.paramList.length > 0) {
    for (var i = 0; i < this.editingParam.paramList.length; i++) {
      let paramField: ParamField = this.editingParam.paramList[i];

      paramField.isRequired === "Y" ?isAnyRequiredField++:false;
      if (paramField.fieldType == "select") {
        if (paramField.selectValue != "-1" && paramField.selectValue != "Select") {
          if (paramField.paramValue != paramField.selectValue)
            paramField.paramValue = paramField.selectValue;
          paramField.isModified = true;
          this.updateParametersModified();
          somethingModified = true;
          //paramField.isAvailableParam = false;
          this.formErrors = {};
          paramField.validationMessage = "";
        } else {
          if (paramField.isRequired === "Y") {
            isRequiredModified = false;
            paramField.validationMessage = "Please select some value from list instead of \"Select\" for the field " +  paramField.fieldLabel;
            //this.formErrors.errormessage = "Please select some value from list instead of \"Select\"";
          }
        }
      } else if (paramField.fieldType == "radio") {

        if (paramField.paramValue != paramField.radioValue)
          paramField.paramValue = paramField.radioValue;

      } else if (paramField.fieldType == "checkbox") {

        // if (paramField.paramValue != paramField.checkValue)
        //   paramField.paramValue = paramField.checkValue;

      } else if (paramField.fieldType == "text") {
        if (paramField.textValue && paramField.textValue.trim().length > 0) {
          paramField.textValue = paramField.textValue.trim();
          if (paramField.paramValue != paramField.textValue)
            paramField.paramValue = paramField.textValue;
          somethingModified = true;
          paramField.isModified = true;
          this.updateParametersModified();
          //paramField.isAvailableParam = false;
          this.formErrors = {};
          paramField.validationMessage = "";
        } else {
          if (paramField.isRequired == "Y") {
            isRequiredModified = false;
            paramField.validationMessage = "Please enter valid value in the " + paramField.fieldLabel;
            //this.formErrors.errormessage = "Please enter valid value in the TextBox.";
        }
        }
      } else if (paramField.fieldType == "textarea") {
        if (paramField.textValue && paramField.textValue.trim().length > 0) {
          paramField.textValue = paramField.textValue.trim();
          if (paramField.paramValue != paramField.textValue)
            paramField.paramValue = paramField.textValue;
          somethingModified = true;
          paramField.isModified = true;
          this.updateParametersModified();
          //paramField.isAvailableParam = false;
          this.formErrors = {};
          paramField.validationMessage = "";
        } else {
          if (paramField.isRequired == "Y") {
            isRequiredModified = false;
            paramField.validationMessage = "Please enter valid value in the " + paramField.fieldLabel;
            // this.formErrors.errormessage = "Please enter valid value in the Text Area.";
          }
        }
      }
    }
  }

if(isAnyRequiredField > 0) {
  if (somethingModified && isRequiredModified) {
    this.hideRespParamEditModal();
    if(this.editingParam.displayImage && this.editingParam.paramList && this.editingParam.paramList.length > 0 && this.editingParam.paramList[0].paramValue)
      this.editingParam.fieldText = this.editingParam.paramList[0].paramValue;
  }
} else {
  this.hideRespParamEditModal();
}


}

  public onClickEditingParamModal_CANCEL() {
    var removeFromAvailParameter = false;
    // console.log(this.editingParam);
    if ( this.editingParam.paramList && this.editingParam.paramList.length > 0) {
      for(var i = 0; i < this.editingParam.paramList.length; i++) {
        let paramField : ParamField = this.editingParam.paramList[i];

                if (paramField.fieldType == "select") {

                  if (paramField.paramValue) {
                    paramField.selectValue = paramField.paramValue;
                  } else {
                    if (paramField.parsedFieldValues && paramField.parsedFieldValues.length > 0)
                      paramField.selectValue = paramField.parsedFieldValues[0].id;
                    else
                      paramField.selectValue = "-1";
                  }
                  if ( (paramField.selectValue == "-1" || paramField.selectValue == "Select") && paramField.isRequired=='Y')
                    removeFromAvailParameter = true;

                } else if (paramField.fieldType == "radio") {

                  if (paramField.paramValue)
                    paramField.radioValue = paramField.paramValue;
                  else
                    paramField.radioValue = null;

                } else if (paramField.fieldType == "checkbox") {

                  if (paramField.paramValue)
                    paramField.checkValue = (paramField.paramValue == "true");
                  else
                    paramField.checkValue = false;

                } else if (paramField.fieldType == "text") {

                  if (paramField.textValue)
                    paramField.textValue = paramField.textValue.trim();

                  if (paramField.paramValue)
                    paramField.textValue = paramField.paramValue;
                  else
                    paramField.paramValue = paramField.textValue = "";

                  if ( !paramField.paramValue && paramField.isRequired=='Y' )
                    removeFromAvailParameter = true;
                }
      }
    }

    this.hideRespParamEditModal();

    if (removeFromAvailParameter) {
      var param_index = this.addedParameters.indexOf(this.editingParam);
      if (param_index != -1)
        this.editingParam.isAvailableParam = true;
      this.addedParameters.splice(param_index, 1);
      this.availParameters.push(this.editingParam);
      this.editingParam = {};
      this.formErrors = {};
    } else {
      this.updateParametersModified();
    }

  }

  /** --END-- Functions or Methods related to DialogModal events and Handling Parameters modification */

}
