var config = require('/app/conf/properties/mfchatnode/config');

var customerIsTypingModelConfig = {
    response: {
        "sessionOver": false,
        "Page": {
            "pageType": "livechat",
            "parentPageType": "myData",
            "status": "accepted",
            "callType": "isTyping",
            "showChatHistory": false,
            "agentBusy": false
        },
        "ResponseInfo": {
            "locale": "en",
            "requestId": "e2dba9a3-0098-4eaf-889d-01d4f413087d",
            "buildNumber": "280",
            "code": "00000",
            "type": "Success"
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "requestId": "e2dba9a3-0098-4eaf-889d-01d4f413087d",
                    "buildNumber": "280",
                    "code": "00000",
                    "type": "Success"
                }
            }
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_CUTOMER_TYPING_URI
    }
};

module.exports = customerIsTypingModelConfig;
