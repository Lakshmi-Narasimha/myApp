/**
 * @ngdoc directive
 * @name ftickeyValueVerticalTileListScroll
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires advisorEventConstants
 * @requires unitHolderModel
 * @description
 *
 * - ftickeyValueVerticalTileListScroll will display the vertical tiles for "My profile - Grant Access" .
 * 
 *
 **/
'use strict';

var keyValueVerticalTileListScroll = function() {
	return {
            template: require('./keyValueVerticalTileListScroll.html'),
            restrict: 'E',
            replace: true,
            scope: {
                list: "="
            },
            controller: function($scope, $element, $attrs){  
                
                /*var handler = $scope.$on(advisorEventConstants.myInvestors.ACCT_STMTS_UNIT_HOLDER,function(event,data){        

                    var unitHolderDtls = unitHolderModel.getUnitHolderObj();
                    $scope.list = [
                        {key:'Unit Holder Name',value:unitHolderDtls.unitHolderName},
                        {key:'PAN',value:unitHolderDtls.pan},
                        {key:'Folio No',value:unitHolderDtls.folioNo},
                        {key:'Mode of Holding',value:unitHolderDtls.modeOfHolding},
                        {key:'Mobile',value:unitHolderDtls.mobile},
                        {key:'Email',value:unitHolderDtls.email},
                        {key:'City ',value:unitHolderDtls.city}
                    ]
                });*/

            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

keyValueVerticalTileListScroll.$inject = [];
module.exports = keyValueVerticalTileListScroll;