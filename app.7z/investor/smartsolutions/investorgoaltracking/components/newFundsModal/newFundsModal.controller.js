/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function newFundModalController($scope, $uibModalStack, advisorEventConstants, smartSolnFundDetailsModel, currentPlanFundsService) { 


 
 $scope.smartSolnsCurrentFundsData = [];
          var CurrentFundsrows = angular.copy(currentPlanFundsService.getCurrentFunds()).currenFunds;

          /*[
                  {
                    "fundname" : "Franklin India Blue-chip Fund",
                    "percentage" : "50%",
                    "monthly"     : "800",
                    "annual" : "8,000"
                    
                  },
                  {
                    "fundname" : "Franklin India Cash Management Account Fund",
                    "percentage" : "50%",
                    "monthly"     : "550",
                    "annual" : "4,500"
                  },
                  {
                    "fundname" : "Toatal",
                    "percentage" : "100%",
                    "monthly"     : "1350",
                    "annual" : "12,500"
                  }
                ];*/

                angular.forEach(CurrentFundsrows,function(obj){
                    var CurrentFundsgridRow = {};
                    CurrentFundsgridRow.fundOption = obj.fundOption;
                    CurrentFundsgridRow.percentage = obj.percentage;
                    CurrentFundsgridRow.monthly = obj.frequency;
                    CurrentFundsgridRow.annual = obj.amount;
                    CurrentFundsgridRow.onetime = obj.onetime;
                    $scope.smartSolnsCurrentFundsData.push(CurrentFundsgridRow);
                });


               $scope.smartSolnsCurrentFundsColumnDefs = [
                  { field: 'fundOption', displayName: 'Fund Name', width:"210", enableSorting:false, pinnedLeft:true},
                  { field: 'percentage', displayName: '%',width:"50"},
                  { field: 'monthly', displayName: 'Monthly', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right',width:"80"},
                  { field: 'annual', displayName: 'Annually', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right',width:"80"},
                  { field: 'onetime', displayName: 'One-time', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right',width:"100"}
               ];
  
    
    
    

    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
}


newFundModalController.$inject = ['$scope', '$uibModalStack', 'advisorEventConstants', 'smartSolnFundDetailsModel', 'currentPlanFundsService'];

module.exports = newFundModalController;