define(['backbone'], function(Backbone) {
    var signPageModel = Backbone.Model.extend({
        idAttribute: "signerId",
        defaults: {
            "lastName": "",
            "firstName": "",
            "signature": [],
            "images": [],
            "docid": "",
            "signerStatus":""
        }
    });
    return signPageModel;
});