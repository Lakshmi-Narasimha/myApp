/**
 * @ngdoc directive
 * @name investment preferences
 * @description
 *
 * - Investment preferences component will display the selection option for payments through financial advisor or direct.
 * 
 *
 **/
 'use strict';

var investorModeOfHolding = function(paperlessModel, $state, transactModel, constants, buildPlanModelService) {
  return {
            template: require('./modeOfHoldingSS.html'),
            restrict: 'E',
            replace: true,
            scope: {
            },
            controller: ['$scope', function($scope){

                $scope.init = function(){
                    $scope.isAddHolder = false;
                    $scope.isCheckKyc = true;
                    $scope.isRemoveOpen = true;
                    $scope.isRemoveKyc = true;         
                    $scope.panelHolders = [];
                    $scope.firstHolder = {};
                    $scope.jointHolders = [];  

                    if (buildPlanModelService.getNewInvestorFirstHolderDtls()) {
                        $scope.panNumber = buildPlanModelService.getNewInvestorFirstHolderDtls().appPanNo;
                        $scope.name = buildPlanModelService.getNewInvestorFirstHolderDtls().fullName;
                    }
                }
                $scope.init();
                

                            


                $scope.preferences = [{
                    label : "Single",
                    value : "single",
                    nameLbl : "holdingmode",
                    check: true,
                    model:""
                },{
                    label : "Either or Survivor",
                    value : "eitherorsurvivor",
                    nameLbl : "holdingmode",
                    check: true,
                    model:""
                }];

                $scope.listenChange = function(input){
                    transactModel.smartSolModeofHolding = input;
                    $scope.modeOfHoldingForm.$setPristine();
                    $scope.preferences[0].model = input;
                    $scope.preferences[1].model = input;
                    $scope.holdingmode = input;
                    $scope.init();
                    buildPlanModelService.modeOfHolding = (input=="single"?"Single":"Joint");
                    buildPlanModelService.setNewInvestorHolderDetails(null);
                }

                $scope.holderArrange = function(){
                    if ($scope.panelHolders.length>0) {
                        $scope.isAddHolder = true;
                        $scope.isCheckKyc = false;
                    }
                    if ($scope.panelHolders.length>1) {
                        $scope.isAddHolder = false;
                        $scope.isCheckKyc = false;
                    }
                }

                // Push holders
                $scope.pushHolders = function(data){
                    var holderKey = $scope.panelHolders.length > 0 ? "Third Holder" : "Second Holder",
                        kycStatus = data.kycStatus == "02" || "KYC - Registered"?"kyc-Registered":"kyc-Not Registered",
                        invTileData = transactModel.setInvTileData(data.fullName, data.userEnteredPan, data.aadharNo, kycStatus, holderKey);
                    data.aadharNo = data.aadharNo || ""; // /validateKYC service does not return aadhaarNo property currently. Actual property name will have to be changed once the service returns it                    
                    $scope.panelHolders.push(invTileData);
                    $scope.holderArrange();
                }

                $scope.addHolders = function(){
                    $scope.isAddHolder = false;
                    $scope.isCheckKyc = true;
                }

                $scope.removeKyc = function(){
                    $scope.isAddHolder = true;
                    $scope.isCheckKyc = false;
                }

                $scope.removeHolders = function(ind){
                    var array = buildPlanModelService.getNewInvestorHolderDetails();
                    if ((ind==0) && ($scope.panelHolders.length>1)) {
                        $scope.panelHolders[1][0].key = "Second Holder";
                        array[1].type = "Secondholder";
                    }
                    $scope.panelHolders.splice(ind,1);
                    array.splice(ind,1);
                    if ($scope.panelHolders.length == 0 || undefined) {
                        buildPlanModelService.setNewInvestorHolderDetails(null);
                    }
                    else{
                        buildPlanModelService.setNewInvestorHolderDetails(array);
                    }
                    $scope.holderArrange();
                }

                var holdersArray = buildPlanModelService.getNewInvestorHolderDetails();
                // Prepopulate on edit fatca data
                if(holdersArray){
                    angular.forEach(buildPlanModelService.getNewInvestorHolderDetails(), function(obj, key){
                        $scope.pushHolders(buildPlanModelService.getNewInvestorHolderDetails()[key]);
                    });
                    $scope.holdingmode = "eitherorsurvivor";
                    $scope.preferences[0].model = "eitherorsurvivor";
                    $scope.preferences[1].model = "eitherorsurvivor";
                }
                else if (buildPlanModelService.modeOfHolding == "single") {
                    $scope.holdingmode = "single";
                    $scope.preferences[0].model = "single";
                    $scope.preferences[1].model = "single";
                }


                // check kyc
                $scope.$on("holderDtls", function(args, hodlerData){
                    //hodlerData.kycStatus = true;
                    hodlerData.type= "Secondholder";  
                    
                    if (hodlerData.kycSource === "KRA Verified"){
                        if(buildPlanModelService.getNewInvestorHolderDetails()){
                            hodlerData.type= "Thirdholder";
                            $scope.jointHolders = buildPlanModelService.getNewInvestorHolderDetails();
                        } 
                        $scope.jointHolders.push(hodlerData);
                        buildPlanModelService.setNewInvestorHolderDetails($scope.jointHolders);
                        $scope.pushHolders(hodlerData);
                        console.log($scope.jointHolders);
                    }
                    else if(hodlerData.kycSource === "Not available"){
                        if(buildPlanModelService.getNewInvestorHolderDetails()){
                            hodlerData.type= "Thirdholder";
                            $scope.jointHolders = buildPlanModelService.getNewInvestorHolderDetails();
                        } 
                        buildPlanModelService.kycNotRegPan = hodlerData.userEnteredPan;
                        buildPlanModelService.kycNotRegName = "Shankar narayanan";
                        buildPlanModelService.kycNotRegType = hodlerData.type;
                        
                        hodlerData.fullName = "Shankar narayanan";

                        $scope.jointHolders.push(hodlerData);
                        buildPlanModelService.setNewInvestorHolderDetails($scope.jointHolders);
                        $scope.pushHolders(hodlerData);
                        $state.go("smartSol.planSmartSolution.kycRegSSNew");
                        console.log($scope.jointHolders);
                    }
                });


                $scope.continue = function(){
                    if ($scope.modeOfHoldingForm.$valid) {
                        $state.go("smartSol.planSmartSolution.fatcaFormSSNew");
                    }
                }

            }]
        };
};

investorModeOfHolding.$inject = ['paperlessModel','$state','transactModel','constants','buildPlanModelService'];
module.exports = investorModeOfHolding;