define([
    'jquery',
    'underscore',
    'backbone',
    'Q',
    'errorLog',
    'moment',
    'spinner',
    'services/dataservice',
    'appcommon/constants',
    'appcommon/globalcontext',
    'appcommon/commonutility',
    'appcommon/analytics',
    'appmodules/crm/crmcommon',
    'appmodules/crm/crmvalidate',
    'appmodules/crm/app/models/eventscollection',
    'appmodules/crm/app/models/task',
    'appmodules/crm/app/models/taskcontext',
    'appmodules/nav/app/models/contactdetails',
    'appmodules/crm/app/models/contactpickerdatasource',
    'appmodules/crm/app/views/contactpickerview',
    'text!appmodules/crm/app/templates/taskeditview.html'
], function ($, _, Backbone, Q, ErrorLog, moment, Spinner, Dataservice, Constants, GlobalContext, Util, Analytics, CRMConstants, Validator, EventsCollection, Task, TaskContext, AppContactDetails, ContactPickerDataSource, ContactPickerView, TaskEditViewHtml) {
    var self,TaskEditView = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        activityId: null,  // if edit
        originalTask: null,  // if edit
        originalContactNames: [],  // if edit
        selectedContactId: null,
        selectedContactType: null,
        insightSubject: "",
        potentialParticipants: [],
        isEdit: false,
        taskTypes: eval(CRMConstants.taskTypes),
        potentialKeywords: [],
        contactPickerView: null,
        events: {
            "click #pt-backto-task-list-button": "handleBacktoTaskListClick",
            "click [pt-task-cancel-button]": "handleCancelClick",
            "click #pt-task-save-button": "handleSaveClick",
            "click #pt-task-delete-button": "handleDeleteClick",
            "click [pt-task-edit-private-choice]" : "handlePrivateChange",
            'change input[name="pt-task-edit-priority-radio-group"]' : 'handlePriorityChange',
            "change #pt-task-participant-list input[type='checkbox']" : "handleParticipantChange",
            "change #pt-task-edit-type" : "handleTypeChange"
        },
        template: _.template(TaskEditViewHtml),
        initialize: function (options) {
            self = this;
            _.extend(this, _.pick(options, 'activityId', 'selectedContactId', 'selectedContactType', 'insightSubject'));  // copies constructor attributes to this
            this.isEdit = this.activityId != null;
            window.scroll(0, 0);
            $(window).on('resize orientationchange', this.repositionCurrentDatePicker);
        },
        beforeClose: function() {
            if (this.contactPickerView) {
                this.contactPickerView.close();
            }
        },
        render: function () {
            var self = this;
            var pageHistory = Backbone.history.list.slice(-1)[0];
            Spinner.show();
            var additionalParticipant = TaskContext.isTaskSignedOnUser() ? null : TaskContext.getTaskFMID();
            var servicePromises = [Dataservice.getParticipant(Util.userFMID(), true, additionalParticipant)];
            if (self.isEdit) {
                servicePromises.push(Dataservice.getTaskDetails(Util.userFMID(), this.activityId));
            } else if (pageHistory === "hoc/takeAction" || pageHistory === "hoc/serviceopportunities" || pageHistory === "hoc/dol") {
                self.originalTask = self.createTaskInsightWithDefaults(this.insightSubject);
            }else {
                self.originalTask = self.createTaskWithDefaults();
            }
            self.referer = pageHistory;
            if (pageHistory.indexOf("contactprofile/") !== -1) {
                self.backContext = "Profile"
            } else if (pageHistory === "hoc/takeAction") {
                self.backContext = "Insights";
            } else if (pageHistory === "hoc/serviceopportunities") {
                self.backContext = "Insights";
            } else if (pageHistory === "hoc/dol") {
            	self.backContext = "Insights";
            }
            else { //defaults for sanity purposes
            	self.backContext = "Task List"
            }

            Q.allSettled(servicePromises).then(function (results) {
                if(self.isEdit){
                    var breezeTask = results[1].value[0];
                    self.originalTask = new Task();
                    self.originalTask.populateFromBreezeEntity(breezeTask);
                    self.originalContactNames = self.formatOriginalContactNames(breezeTask);
                }
                var participants = results[0].value;
                self.potentialParticipants = self.createPotentialParticipantsList(participants);
     

                Spinner.hide();
                self.populateView(self);
            }).fail(self.handleServiceError);
        },
        populateView: function (view) {
            view.$el.html(this.template({ isEdit: view.isEdit, task: view.originalTask, contactNames: view.originalContactNames, potentialParticipants: view.potentialParticipants, candidateTaskTypes: view.candidateTaskTypes(view), backContext: view.backContext }));
            view.fetchKeywords();
            view.populateDatePickers();
            view.populateSubtypeSelect(view);
            view.populatePrivateChooser(view);
            view.populateParticipantSelectAll(view);
            if (!view.isEdit) {
                view.renderContactPicker(view);
            }
        },
        populatePrivateChooser: function(view) {
            view.populatePrivateChoice(view.getOriginalTaskProperty(view, 'isPrivate', false));
        },
        populatePrivateChoice: function(isPrivate) {
            $('[pt-task-edit-private-choice="yes"]').toggleClass('active', isPrivate);
            $('[pt-task-edit-private-choice="no"]').toggleClass('active', !isPrivate);
        },
        populateParticipantSelectAll: function(view) {
            var $selectAll = view.$('#pt-task-participant-select-all');
            $selectAll.prop('checked', view.selectedParticipants().length == view.potentialParticipants.length);
        },
        populateSubtypeSelect: function(view) {
            var originalSubType = view.getOriginalTaskProperty(view, 'subTypeId', null);
            // find the currently selected's type's subtypes
            var currentTypeCode = view.$('#pt-task-edit-type').val();
            var currentType = _.find(view.taskTypes, function(taskType) {
                return taskType.value.name == currentTypeCode;
            });
            var subtypes = currentType.value.value.slice(0);
            // add a NONE option
            var options = ['<option ' + (Util.isEmpty(originalSubType) ? 'selected=""' : '') + ' disabled="" value="">Choose one</option>'];
            var $subtypeSelect = view.$('#pt-task-edit-subtype');
            // populate the html
            _.each(subtypes, function(subtype) {
                var subtypeCode = subtype.value;
                var selected = subtypeCode == originalSubType ? 'selected' : '';
                options.push('<option value="' + subtypeCode + '" ' + selected +'>' + subtype.name +'</option>');
            });
            options.push('<option value="None">None</option>');
            $subtypeSelect.html(options.join());
        },
        populateKeywordsSelect: function(view) {
            var originalKeywords = view.getOriginalTaskProperty(view, 'actKeyword', null);
            var $keywordsSelect = view.$('#pt-task-edit-keywords');
            var options = ['<option ' + (Util.isEmpty(originalKeywords) ? 'selected=""' : '') + ' disabled="" value="">Choose one</option>'];
            for (keywordsCode in view.potentialKeywords) {
            	keywords = view.potentialKeywords[keywordsCode];
                var selected = keywords == originalKeywords ? 'selected' : '';
                options.push('<option value="' + keywordsCode + '" ' + selected +'>' + keywords +'</option>');
            }
            options.push('<option value="None">None</option>');
            $keywordsSelect.html(options.join());
        },
        populateDatePickers: function () {
            var startDate = this.isEdit ? this.originalTask.get('startDate') : null;
            this.initDatePicker($('#pt-task-edit-start-date'), this.getOriginalTaskDateProperty(this, 'startDate'), true, "Select start date", this.handleStartDateChange);
            this.initDatePicker($('#pt-task-edit-end-date'), this.getOriginalTaskDateProperty(this, 'endDate'), true, "Select end date", this.handleEndDateChange);
            this.initDatePicker($('#pt-task-edit-due-date'), this.getOriginalTaskDateProperty(this, 'dueDate'), false, "Select due date", this.handleDueDateChange);
        },
        initDatePicker: function ($dateInput, taskDate, dateRequired, text, changeCallback, showClear) {
            _self = this;
            var date = taskDate == null ? (dateRequired ? new Date() : null) : taskDate;
            $dateInput.datepicker({
                showOn: "button",
                buttonImage: "images/cal-icon.png",
                buttonImageOnly: true,
                buttonText: text,
                beforeShow: function(element, currentPicker) {
                    $("#ui-datepicker-div").addClass("pt-task-datepicker");
                },
                
                onSelect: function() {
                    changeCallback(_self);
                }
            });
            if (date) {
                $dateInput.datepicker("setDate", date);
            }
        },
        candidateTaskTypes: function(view) {  // returns array of {code:string, name:string}
            var types = [];
            _.each(view.taskTypes, function(activityType) {
                if (activityType.name != 'Appointment') {   // drop the Appointment option
                    types.push({code: activityType.value.name, name: activityType.name});
                }
            });
            return types;
        },
        getOriginalTaskProperty: function(view, propertyName, defaultValue) {
            if (view.originalTask) {
                var value = view.originalTask.get(propertyName);
                if (value) {
                    return value;
                }
            }
            return defaultValue;
        },
        getOriginalTaskDateProperty: function(view, propertyName) {
            if (view.originalTask) {
                var value = view.originalTask.get(propertyName);
                if (value) {
                    return moment(value, "MM-DD-YYYY").toDate();
                }
            }
            return null;
        },
        createPotentialParticipantsList: function(allParticipants) {
            // begin with the selected participants from the task (if editing)
            var potentialParticipants = [];
            if (this.isEdit) {
                var taskParticipants = this.originalTask.get('selectedParticipants');
                if (taskParticipants) {
                    potentialParticipants = taskParticipants;
                }
            }
            // merge any other candidate participants
            _.each(allParticipants, function(otherParticipant) {
                if ( _.find(potentialParticipants, function(selectedParticipant) {
                        return otherParticipant.get('id') == selectedParticipant.get('id');
                    }) == null ) {
                    potentialParticipants.push(otherParticipant.clone());
                }
            });
            // if we are adding, select the primary participant as a default participant
            if (!this.isEdit) {
                var defaultParticipant;
                if (!Util.isEmpty(TaskContext.getUserList())) {
                    var taskFMID = TaskContext.getTaskFMID();
                    defaultParticipant = _.find(TaskContext.getUserList(), function (user) {
                        return taskFMID == user.fmid;
                    });
                }
                var primaryParticipant;

                if (defaultParticipant) {
                    primaryParticipant = _.find(potentialParticipants, function (participant) { return participant.get('id') == defaultParticipant.ebixUserIdentifier });
                } else {
                    primaryParticipant = _.find(potentialParticipants, function (participant) { return participant.get('isPrimary') });
                }
                if (primaryParticipant) {
                    primaryParticipant.set('isSelected', true);
                }
            }
            potentialParticipants.sort(function(a, b) {
                if (a.get('isPrimary')) {
                    return -1;
                } else if (b.get('isPrimary')) {
                    return 1;
                } else  if (a.get('name') < b.get('name')) {
                    return -1;
                } else if (a.get('name') > b.get('name')) {
                    return 1;
                } else {
                    return 0;
                }
            });
            return potentialParticipants;
        },
        handleBacktoTaskListClick: function() {
            this.handleCancel(null);
        },
        handleCancelClick: function() {
            this.handleCancel(null);
        },
        handleCancel:function(analyticAction){
            var self = this;
            BootstrapDialog
                .confirm(
                "Cancel",
                "All your work will be lost.  Are you sure you want to continue?",
                function(confirm) {
                    if (confirm) {
                        if (analyticAction) {
                            Analytics.analytics.recordAction(analyticAction);
                        };
                        if (self.isEdit) {
                        	Analytics.analytics.recordAction('editTaskBackToTaskListOrCancelConfirmed:clicked');
                        } else {
                        	Analytics.analytics.recordAction('addTaskBackToTaskListOrCancelConfirmed:clicked');
                        };
                        self.goToReferer();
                    };
                    if (self.isEdit) {
                    	Analytics.analytics.recordAction('editTaskBackToTaskListOrCancelNotConfirmed:clicked');
                    } else {
                    	Analytics.analytics.recordAction('addTaskBackToTaskListOrCancelNotConfirmed:clicked');
                    };
                });
        },
        handleDeleteClick:function(){
            var self = this;
            BootstrapDialog
                .confirm(
                "Delete",
                "Are you sure you want to delete this task?",
                function(confirm) {
                    if (confirm) {
                    	Analytics.analytics.recordAction('deleteTaskFromEditTaskConfirmed:clicked');
                        Dataservice.deleteTask(Util.userFMID(), self.originalTask.get('activityId')).then(function(deleteResponse) {
                            //if (deleteResponse == 'Failed') {
                            //	ErrorLog.ErrorUtils.myError(new Error('Ebix returned fail when attempting to delete task'));
                            //}
                        }).then(self.goToReferer).fail(self.handleServiceError);
                    } else {
                    	Analytics.analytics.recordAction('deleteTaskFromEditTaskNotConfirmed:clicked');
                    }
                });
        },
        handleSaveClick: function () {
            Analytics.analytics.recordAction('SaveTaskandupdate:clicked');
            var self = this;
            if (Validator.validateInputs('pt-task-edit-form')) {
                if (self.validateSelectedParticipants()) {
                    Spinner.show();
                    var task = new Task();
                    self.updateTaskFromView(task);
                    if (self.isEdit || self.contactPickerView.selectedContact == null) {
                        self.saveTask(task);
                    } else {
                        var contact = self.contactPickerView.selectedContact;
                        if (contact) {
                            // if the contact is a client we need to get the ebix contact ID first
                            if (contact.contactType == Constants.contactType.Client) {
                                var clientId = contact.id;
                                Spinner.show();
                                Dataservice.getContactDetailsbyClientId(Util.userFMID(), clientId).then(function (response) {
                                    Spinner.hide();
                                    var contactId = (response[0] == null || response[0].get == null) ? null : response[0].get('contactId');
                                    if (contactId) {
                                        self.setTaskProperty(task, 'contactId', contactId);
                                        self.saveTask(task);
                                    } else {
                                        self.showClientNotInCMAlert();
                                    }
                                }).fail(function (error) {
                                    self.handleServiceError(error);
                                });
                            } else {
                                self.setTaskProperty(task, 'contactId', contact.id);
                                self.saveTask(task);
                            }
                        }
                    };
                    Analytics.analytics.recordAction('saved' + (self.isEdit ? 'Edit' : 'Add') + 'Task' + (self.contactPickerView && self.contactPickerView.selectedContact ? 'withParticpantType' + self.contactPickerView.selectedContact.contactType : 'NoParticipants'));
                } else {
                    BootstrapDialog.alert("Select at least one participant.", null, "Incomplete Task");
                }
            }
            if (practicetech.modules.tasks.state != undefined) {
            	practicetech.modules.tasks.state.add = false;
            }
            
        },
        saveTask: function(task) {
            var self = this;

                if (self.isEdit) {
                    Dataservice.updateTask(Util.userFMID(), task)
                        .then(function (response) {


                            Spinner.hide();
                            self.goToReferer();
                        }).fail(function (error) {
                            self.handleServiceError(error);
                        });
                } else {

                    Dataservice.createTask(Util.userFMID(), task)
                        .then(function () {
             
                            Spinner.hide();
                            self.goToReferer();
                        }).fail(function (error) {
                            self.handleServiceError(error);
                        });
                }
        },
        showClientNotInCMAlert: function() {
            BootstrapDialog.alert("This client cannot be found in Contact Manager. The client might not have an active account or might be hidden. <a href='https://www.askameriprise.com/app/answers/detail/a_id/26890/kw/client%20not%20in%20contact%20manager' target='_blank'>Tell me more.</a>", "", "Client not found");
        },
        handleStartDateChange: function(view) {
            var startDate = view.startDateSelected(view);
            var endDate = view.endDateSelected(view);
            // end date must be >= start date
            if (moment(endDate).isBefore(moment(startDate))) {
                view.$('#pt-task-edit-end-date').datepicker("setDate", startDate);
            }
        },
        handleEndDateChange: function(view) {
            var startDate = view.startDateSelected(view);
            var endDate = view.endDateSelected(view);
            // end date must be >= start date
            if (moment(endDate).isBefore(moment(startDate))) {
                view.$('#pt-task-edit-start-date').datepicker("setDate", endDate);
            }
        },
        handleDueDateChange: function(view) {
            var dueDate = view.dueDateSelected(view);
        },
        handlePrivateChange: function(e) {
            var choice = $(e.target).attr('pt-task-edit-private-choice');
            this.populatePrivateChoice(choice == 'yes');
        },
        handlePriorityChange: function(e) {
            var $priorityInput = $(e.target);
            var $priorityRadioButtonContainer = $priorityInput.closest('.radio-group-conatiner');
            this.$('.radio-group-conatiner').removeClass('active');
            $priorityRadioButtonContainer.addClass('active');
        },
        handleTypeChange: function(e) {
            this.originalTask.set('subTypeId', null);
            this.populateSubtypeSelect(this);
        },
        handleParticipantChange: function(e) {
            var $checkBox = $(e.target);
            this.renderParticipantCheckBoxContainer($checkBox);
            if ($checkBox.prop('id') == 'pt-task-participant-select-all') {
                var checked = $checkBox.prop('checked');
                this.selectAllParticipants(checked);
            } else {
                this.populateParticipantSelectAll(this);
            }
            this.validateSelectedParticipants();
        },
        handleServiceError: function(error) {
            Spinner.hide();
            ErrorLog.ErrorUtils.myError(error);
        },
        renderParticipantCheckBoxContainer: function($checkBox) {
            var $participantContainerDiv = $checkBox.closest('.radio-group-conatiner');
            $participantContainerDiv.toggleClass('active', $checkBox.is(':checked'));
        },
        renderContactPicker: function(view) {
        	var fmid = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
        	var dataSource = new ContactPickerDataSource(fmid, Util.userFMID());
            // if we have one...use the client list the app already retrieved
            var isDynamicSearch = AppContactDetails.advsiorContacts.getContactSearchType(fmid);
            if (!isDynamicSearch) {
                var fixedClientList = AppContactDetails.advsiorContacts.GetContactDetails(fmid, Constants.contactType.Client);
                dataSource.setFixedClientListFromAppClientList(fixedClientList);
            }
            view.contactPickerView = new ContactPickerView({el: $('#pt-task-edit-contact').get(0), dataSource: dataSource});
            // if the app has a pinned contact use if for initial selected contact when adding
            if (!this.isEdit) {
                view.contactPickerView.selectedContact = dataSource.pinnedContact();
            }
            view.contactPickerView.render();
        },
        goToTaskList: function() {
        	Dataservice.clearExistingTaskListfromBreeze();
            location.hash = 'crm/tasks';
        },
        goToReferer: function () {
            Dataservice.clearExistingTaskListfromBreeze();
            var _referer = self.referer;
            switch (_referer) {
                case 'contactprofile/':
            	case 'contactprofile/beneficiary':
            	case 'contactprofile/bank':
                case 'contactprofile/ira':
                case 'contactprofile/fiduciary':
                case 'contactprofile/preferences':
                case 'contactprofile/contributions':
                case 'contactprofile/distributions':
                    location.hash = _referer;
                    break;
                case "hoc/takeAction":
                    location.hash = "hoc/";
                    break;
                case "hoc/serviceopportunities":
                    location.hash = "hoc/serviceopportunities";
                    break;
            	case "hoc/dol":
            		location.hash = "hoc/dol";
            		break;
                default:
                    location.hash = 'crm/tasks';
            }
        },
        startDateSelected: function(view) {
            return view.$('#pt-task-edit-start-date').datepicker("getDate");
        },
        endDateSelected: function(view) {
            return view.$('#pt-task-edit-end-date').datepicker("getDate");
        },
        dueDateSelected: function(view) {
            return view.$('#pt-task-edit-due-date').datepicker("getDate");
        },
        repositionCurrentDatePicker: function () {
            if ($.datepicker._datepickerShowing) {
                var currentPicker = $.datepicker._curInst;
                currentPicker.dpDiv.position({ my: 'left top', of: currentPicker.input, at: 'left bottom' });
            }
        },
        fetchKeywords: function () {
            var self = this;
            Dataservice.getKeywords(Util.userFMID())
                .then(function (response) {
                    self.potentialKeywords = response.keywords;
                    self.populateKeywordsSelect(self);
                }).fail(function (error) {
                    self.handleServiceError(error);
                });
        },
        validateSelectedParticipants: function() {  // answer false if fails validation
            var isError = this.selectedParticipants().length == 0;
            this.$('#pt-task-participant-list').toggleClass('error', isError);
            this.$('#pt-task-participant-list label.error').toggleClass('hidden', !isError);
            return !isError;
        },
        selectedParticipants: function() {
            return this.$('#pt-task-participant-list input:not(#pt-task-participant-select-all)').filter(':checked').map(function(i, input) {
                return {
                    "id" : $(input).attr('pt-task-participant-id')
                }
            }).get();
        },
        updateTaskFromView: function(task) {
            this.setTaskProperty(task, 'subject', this.$('#pt-task-edit-subject').val());
            this.setTaskProperty(task, 'location', this.$('#pt-task-edit-location').val());
            this.setTaskProperty(task, 'description', this.$('#pt-task-edit-description').html());
            this.setTaskPropertyForOptionalDropdown(task, 'actKeyword', this.$('#pt-task-edit-keywords option:selected').text());
            this.setTaskProperty(task, 'startDate', moment(this.startDateSelected(this)));
            this.setTaskProperty(task, 'endDate', moment(this.endDateSelected(this)));
            var dueDate = this.dueDateSelected(this);
            if (dueDate) { this.setTaskProperty(task, 'dueDate', moment(dueDate)); } else { this.setTaskProperty(task, 'dueDate', ''); }
            this.setTaskProperty(task, 'selectedParticipants', this.selectedParticipants());
            this.setTaskProperty(task, 'typeId', this.$('#pt-task-edit-type').val());
            this.setTaskPropertyForOptionalDropdown(task, 'subTypeId', this.$('#pt-task-edit-subtype').val());
            var isPrivate = this.$('[pt-task-edit-private-choice="yes"]').hasClass('active');
            this.setTaskProperty(task, 'isPrivate', this.$('[pt-task-edit-private-choice="yes"]').hasClass('active'));
            this.setTaskProperty(task, 'priority', this.$('#pt-task-edit-priority input:checked').val());
            this.setTaskProperty(task, 'status', this.$('#pt-task-edit-status').val());
            this.setTaskProperty(task, 'activityId', this.activityId);
            if (this.contactPickerView && this.contactPickerView.selectedContact) {
                this.setTaskProperty(task, 'ContactName', this.contactPickerView.selectedContact.displayName);
            }
            if (this.isEdit) {
                this.setTaskProperty(task, 'contactId', this.originalTask.contactId);
            }
        },
        setTaskProperty: function(task, propertyName, value, isDropdown) {
            if (!Util.isEmpty(value)) {
                task.set(propertyName, value);
            }
        },
        setTaskPropertyForOptionalDropdown: function(task, propertyName, value) {
            if (!Util.isEmpty(value) && value != 'Choose one' && value != 'None') {
                task.set(propertyName, value);
            } else {
                task.set(propertyName, '');
            }
        },
        createTaskWithDefaults: function() {
            var task = new Task();
            task.set('priority', 'Medium');
            task.set('status', 'Active');
            task.set('typeId', '3');
            return task;
        },
        createTaskInsightWithDefaults: function (subject) {
            var task = new Task();
            var insightSubject = "Insight: " + subject;
            task.set('subject', insightSubject);
            task.set('priority', 'Medium');
            task.set('status', 'Active');
            task.set('typeId', '3');
            return task;
        },
        formatOriginalContactNames: function(breezeTask) {
            var names = [];
            if (Util.isEmpty(breezeTask.get('contactLastName'))) {
                if (!Util.isEmpty(breezeTask.get('contactName'))) {
                    names.push(breezeTask.get('contactName'));
                }
            } else {
                names.push(breezeTask.get('contactLastName') + ', ' + breezeTask.get('contactFirstName'));
            }
            return names;
        },
        selectAllParticipants: function(shouldSelectAll) {
            var self = this;
            var $participantCheckBoxes = this.$('#pt-task-participant-list input[type="checkbox"]:not(#pt-task-participant-select-all)');
            $participantCheckBoxes.each(function(index, checkbox) {
                var $checkBox = $(checkbox);
                $checkBox.prop('checked', shouldSelectAll);
                self.renderParticipantCheckBoxContainer($checkBox);
            });
        }
    });
    return TaskEditView;
});
