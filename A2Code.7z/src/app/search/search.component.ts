import { Component, ViewChild, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  viewModel: any = {
    toggleSearchView: 'API'
  };
  constructor() { }

  ngOnInit() {
  }

  @Output()
  closeSearch = new EventEmitter();
  @Output()
  openJsonModal = new EventEmitter();

  public hideSearch() : void {
    this.closeSearch.emit();
  }
  public showJsonModal(data) : void {
    data = {'dsgdfsg':12}
    this.openJsonModal.emit(data);
  }

}
