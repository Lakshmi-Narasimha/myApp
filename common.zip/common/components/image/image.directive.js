/**
 * @ngdoc directive
 * @name fticimage
 * @requires $state
 * @requires $window
 * @description
 *
 * - fticimage will be place image element.
 * 
 *
 **/
 'use strict';

var image = function() {
	return {
        template: require('./image.html'),
        restrict: 'AEC',
        replace: true,
        scope: {
            url: '@',
            title : '@',
            link : '@',
            imgClass : '@',
            target: '@?'
        },
        controller: function(){
        },
        link: function(){
        }
    };
};

image.$inject = [];
module.exports = image;