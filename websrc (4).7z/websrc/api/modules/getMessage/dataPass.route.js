var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var router = express.Router();
var dataPassModel = require('./dataPass.model');
var engagementModel = require('../engagement/engagement.model');

// api route
router.route('/mfchatnode/rest/dataPassForSales')
    .post(function(req, res) {
        req.uri = dataPassModel.createRequestUri;
        console.log("requestURI:", req.uri);
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        var post_data = {
            "engagementID": engagementModel.response.Page.engagementID,
            "agentID": engagementModel.response.Page.agentID,
            "Role": req.body.RequestParams.accRole,
            "Mobile Number": req.body.RequestParams.MDN,
            "Greeting Name": req.body.RequestParams.nickName
        };
        var postBody = querystring.stringify(post_data);
        console.log(postBody);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            console.log("statusCode: ", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, {statusCode: proxyResponse.statusCode}, req.session.id));
            if (proxyResponse.statusCode === 200) {
                res.status(200).end();
                logger.outBoundData.info(logger.formatResMsg(req, res));
            } else {
                var errObj = {
                    statusCode: proxyResponse.statusCode,
                    message: 'Something went wrong while retrieving data.'
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatResMsg(req, err));
            });
        });

        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
