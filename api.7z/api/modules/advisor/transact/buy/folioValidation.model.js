// FolioValidation.model.js
// grab the mongoose module
// define our model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FolioValidationModelSchema = new mongoose.Schema({
    FolioValidationResp: {
        type: Array,
        "default": []
    }
});

var FolioValidationModelLookUp = mongoose.model('FolioValidationModelLookUp', FolioValidationModelSchema);

var FolioValidationModel = new FolioValidationModelLookUp({
    "FolioValidationResp":
        [{
            "result":
                [
                    {
                        "patternExists":"true",

                        "folioNo":1234
                    }
                ]
        }]
});

FolioValidationModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FolioValidationModelLookUp table, please contact admin...');
    } else {
        FolioValidationModelLookUp.remove({}, function(err) {
            console.log('FolioValidationModelLookUp collection removed');
            FolioValidationModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating FolioValidationModelLookUp table, please contact admin...');
                }
                console.log('FolioValidationModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FolioValidationModelLookUp;