﻿/* Custom Menu */
define([
  'jquery',
  'bootstrap'
], function ($, bootstrap) {
    $(document).ready(function () {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
                $('.scrollToTop').fadeIn();
            }

            else {
                $('.scrollToTop').fadeOut();
            }
        });

        setIFrameSize();

        $(window).resize(function () {
            setIFrameSize();
        });
        function setIFrameSize() {
            var content_height = $(window).height() - 80;
            var content_width = $(window).width();
            if (document.getElementById('subapp_frame') != null) {
                document.getElementById('subapp_frame').style.height = content_height + "px";
            }
            if (document.getElementById('subapp_frame') != null) {
                document.getElementById('subapp_frame').style.width = content_width + "px";
            }

        }
    });
    
    var contactType=function () {
        var values = {
            Client: 'client',
            Prosepect: 'prospect',
            Other: 'other',
            NonClient: 'nonclient'
        }

        return values;
    }
    function readCookie(name) {
      	 try{
      		 var nameEQ = name + "=";
      			var ca = document.cookie.split(';');
      			for ( var i = 0; i < ca.length; i++) {
      				var c = ca[i];
      				while (c.charAt(0) == ' ')
      					c = c.substring(1, c.length);
      				if (c.indexOf(nameEQ) == 0){
      					var _substring = decodeURIComponent(c.substring(nameEQ.length, c.length));
      					return _substring;
      					
      				}
      			}
      	 }catch(e){
      		 
      	 }
   	
   	return null;
   }
    var _= {
    		formatClientId : function(clientId){
    			if(!clientId ||clientId.length  === 0){
    				return null;
    			}
    			//var _clientIdFmtd = parseInt(clientId.substr(3)).toString();
    			var _clientIdFmtd = clientId.substr(14);
    			return _clientIdFmtd;
    	},
    		readCookie: readCookie,
    		contactType: contactType
    };
    
    return _;
}); //helper function close
