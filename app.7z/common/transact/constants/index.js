/**
 *@ngdoc object
 *@name transact.module:home
 *@description
 * <p>
 * Calling the services those are for showing the pages
 * </p>
 * @project FTIC
 * @Date
 * @version 1
 * @author Suresh P
 */



'use strict';
// Home View
module.exports = angular.module('transact.constants', [])
	.config(require('./messages'))
	.constant('TransactConstant', require('./transact.constants'))
    .constant('transactEventConstants', require('./transactEvents.constants'))
    ;