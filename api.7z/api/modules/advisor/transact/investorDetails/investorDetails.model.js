// getCgFolio.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InvestorDtlsModelSchema = new mongoose.Schema({
    investorDtlsResp: {
        type: Array,
        "default": []
    }
});

var InvestorDtlsModelLookUp = mongoose.model('InvestorDtlsModelLookUp', InvestorDtlsModelSchema);

var InvestorDtlsModel = new InvestorDtlsModelLookUp({
  investorDtlsResp: 
              {
                "datbase" : "FT",
                "result":[
                        {
                          "custName": "Shankar Narayanan",                    
                          "pan": "ABCD1234KL",
                          "aadhar" : 123456789123,
                          "folioId": 3456572,
                          "holdingType": "Joint",
                          "mobile": 9039758625,
                          "emailId": "shankarnarayanan@gmail.com",
                          "city":"P O BOX 170 170",
                          "kycStatus":true,
                          "holders": [
                                      {
                                        "name": "Shankar Narayanan",
                                        "type": "Firstholder",
                                        "kycregistered" : true,
                                        "pan": "ABCD1234KL",
                                        "aadhar" : 123456789123
                                      }, {
                                        "name": "JHON SMITH GOERGE",
                                        "type": "Secondholder",
                                        "kycregistered" : true,
                                        "pan": "ABCD1234KA",
                                        "aadhar" : 123456789120
                                      }, {
                                        "name": "KRISTIANA GOERGE",
                                        "type": "Thirdholder",
                                        "kycregistered" : true,
                                        "pan": "ABCD1234KB",
                                        "aadhar" : 123456789121
                                      }
                                     ]
                        },

                        {
                          "custName": "Shankar Bansal",                    
                          "pan": "OIUH1234GH",
                          "aadhar" : 123456789456,
                          "folioId": 2648571,
                          "holdingType": "single",
                          "mobile": 9059758645,
                          "emailId": "shankar.bansal@gmail.com",
                          "city":"P O BOX 170 170",
                          "holders": [{
                                        "name": "Shankar Bansal",
                                        "type": "Firstholder",
                                        "kycregistered" : false,                    
                                        "pan": "OIUH1234GH",
                                        "aadhar" : 123456789456
                                      }, {
                                        "name": "JHON SMITH GOERGE 1",
                                        "type": "Secondholder",
                                        "kycregistered" : true,                    
                                        "pan": "OIUH1234GA",
                                        "aadhar" : 123456789450
                                      }, {
                                        "name": "KRISTIANA GOERGE 11",
                                        "type": "Thirdholder",
                                        "kycregistered" : true,                    
                                        "pan": "OIUH1234GB",
                                        "aadhar" : 123456789451
                                      }]
                        },

                        {
                          "custName": "Shankar S",                    
                          "pan": "ELKI1234EF",
                          "aadhar" : 123456789789,
                          "folioId": 3494892,
                          "holdingType": "single",
                          "mobile": 9069758655,
                          "emailId": "shankar.s@gmail.com",
                          "city":"P O BOX 170 170",
                          "holders": [{
                                        "name": "Shankar S",
                                        "type": "Firstholder",
                                        "kycregistered" : true,                    
                                        "pan": "ELKI1234EF",
                                        "aadhar" : 123456789789
                                      }, {
                                        "name": "JHON SMITH GOERGE 2",
                                        "type": "Secondholder",
                                        "kycregistered" : false,                    
                                        "pan": "ELKI1234EA",
                                        "aadhar" : 123456789780
                                      }, {
                                        "name": "KRISTIANA GOERGE 22",
                                        "type": "Thirdholder",
                                        "kycregistered" : true,                    
                                        "pan": "ELKI1234EB",
                                        "aadhar" : 123456789781
                                      }]
                        },

                        {
                          "custName": "Shankar KL",                    
                          "pan": "GFRW1234CD",
                          "aadhar" : 123456789012,
                          "folioId": 8987647,
                          "holdingType": "Joint",
                          "mobile": 9079758665,
                          "emailId": "shankar.kl@gmail.com",
                          "city":"P O BOX 170 170",
                          "holders": [{
                                        "name": "Shankar KL",
                                        "type": "Firstholder",
                                        "kycregistered" : true,                    
                                        "pan": "GFRW1234CD",
                                        "aadhar" : 123456789012
                                      }, {
                                        "name": "JHON SMITH GOERGE 3",
                                        "type": "Secondholder",
                                        "kycregistered" : true,                    
                                        "pan": "GFRW1234CA",
                                        "aadhar" : 123456789010
                                      }, {
                                        "name": "KRISTIANA GOERGE 33",
                                        "type": "Thirdholder",
                                        "kycregistered" : true,                    
                                        "pan": "GFRW1234CB",
                                        "aadhar" : 123456789011
                                      }]
                        },

                        {
                          "custName": "Shankar Das",                    
                          "pan": "PDVB1234AB",
                          "aadhar" : 123456789234,
                          "folioId": 4098263,
                          "holdingType": "single",
                          "mobile": 9089758675,
                          "emailId": "shankar.das@gmail.com",
                          "city":"P O BOX 170 170",
                          "holders": [{
                                        "name": "Shankar Das",
                                        "type": "Firstholder",
                                        "kycregistered" : false,                    
                                        "pan": "PDVB1234AB",
                                        "aadhar" : 123456789234
                                      }, {
                                        "name": "JHON SMITH GOERGE 4",
                                        "type": "Secondholder",
                                        "kycregistered" : false,                    
                                        "pan": "PDVB1234AA",
                                        "aadhar" : 123456789230
                                      }, {
                                        "name": "KRISTIANA GOERGE 44",
                                        "type": "Thirdholder",
                                        "kycregistered" : false,                    
                                        "pan": "PDVB1234AC",
                                        "aadhar" : 123456789231
                                      }]
                        },

                        {
                          "custName": "Shankar BK",                    
                          "pan": "MKLK1234IJ",
                          "aadhar" : 123456789567,
                          "folioId": 3896503,
                          "holdingType": "Joint",
                          "mobile": 9049758635,
                          "emailId": "shankar.bk@gmail.com",
                          "city":"P O BOX 170 170",
                          "holders": [{
                                        "name": "Shankar BK",
                                        "type": "Firstholder",
                                        "kycregistered" : true,                    
                                        "pan": "MKLK1234IJ",
                                        "aadhar" : 123456789567
                                      }, {
                                        "name": "JHON SMITH GOERGE 6",
                                        "type": "Secondholder",
                                        "kycregistered" : true,                    
                                        "pan": "MKLK1234IA",
                                        "aadhar" : 123456789560
                                      }, {
                                        "name": "KRISTIANA GOERGE 22",
                                        "type": "Thirdholder",
                                        "kycregistered" : true,                    
                                        "pan": "MKLK1234IB",
                                        "aadhar" : 123456789561
                                      }]
                        }
                      ]
              }
    });

InvestorDtlsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorDtlsModelLookUp table, please contact admin...');
    } else {
        InvestorDtlsModelLookUp.remove({}, function(err) {
            console.log('InvestorDtlsModelLookUp collection removed');
            InvestorDtlsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvestorDtlsModelLookUp table, please contact admin...');
                }
                console.log('InvestorDtlsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorDtlsModelLookUp;