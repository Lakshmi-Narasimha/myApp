define(['jquery', 'lodash', 'backbone', 'app/common/models/Advisor'
], function ($, _, Backbone, Advisor) {
    var AdvisorCollection = Backbone.Collection.extend({
        model: Advisor,

        populateFromOboListResponse: function (oboResponse) {
            var advisorList = [];
            // add user (not necessarily really an advisor but this is the only way we can get the user's name)
            var advisorUser = new Advisor();
            advisorUser.populateFromOboResponse(oboResponse);
            this.add(advisorUser);
            // add obos
            var responseOboArray = oboResponse.oboUserList;
            if (responseOboArray) {
                var self = this;
                _.each(responseOboArray, function(oboAdvisorResponse) {
                    self.add(new Advisor().populateFromOboResponse(oboAdvisorResponse));
                });
            }
            return this;
        },
        populateFromCompTeamMemberDetails: function (responseDataArray) {
            var advisors = [];
            for (var i = 0; i < responseDataArray.length; i++) {
                var advisor = new Advisor();
                advisors.push(advisor.populateFromCompTeamDetailsResponse(responseDataArray[i]));
            }
            this.reset(advisors);
            return this;
        },
        getSignedOnAdvisor: function() {
            return this.find(function(advisor) {
                return advisor.isUser();
            });
        },
        removeNonAdvisorUser: function() {
            var nonAdvisorUser = this.find(function(advisor) {
                return advisor.isUser() && advisor.get('userType') === "ASSISTANT";
            });
            if (nonAdvisorUser) {
                this.remove(nonAdvisorUser);
            }
            return this;
        },
        // return [Advisor]
        advisorsSortedByUserAndName: function() {
            var sortedList = this.models.sort(function(adv1, adv2) {
                if (adv1.isUser()) {
                    return -1;
                } else if (adv2.isUser()) {
                    return 1;
                } else {
                    return adv1.get('fullName').localeCompare(adv2.get('fullName'));
                }
            });
            return new AdvisorCollection(sortedList);
        }
    });

    return AdvisorCollection;
});


/* Sample OBO List service response

 {
     "fmid":"000028156",
     "userType":"ADVISOR",
     "firstName":"THOMAS",
     "middleName":"",
     "lastName":"STORRIE",
     "oboUserList":[
         {
             "fmid":"000116469",
             "firstName":"FN2138083",
             "middleName":"",
             "lastName":"LN2138083"
         },
         {
             "fmid":"000034990",
             "firstName":"FN3034990",
             "middleName":"",
             "lastName":"LN3034990"
         }
     ],
     "responseCode":200,
     "responseDescription":"Successful"
 }

 */

