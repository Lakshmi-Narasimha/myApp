/**
 * @ngdoc property
 * @name fticCapitalGainAcUnitDetails Directive
 * @requires advisorConstants 
 * @requires advisorEventConstants 
 * @requires fticLoggerMessage 
 * @requires loggerConstants 
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Capital Gains Account Statement Unit Holder details for selected Folio Number and Account Number
 *
 **/
'use strict';

var fticCapitalGainAcUnitDetails = function(fticLoggerMessage, loggerConstants, cgAccDetModel) {
    return {
        template: require('./cgunitholder.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {
            $scope.capGainunitHolder = cgAccDetModel.getcgaccountdetunitholder();
        }
    };
};

fticCapitalGainAcUnitDetails.$inject = ['fticLoggerMessage', 'loggerConstants', 'cgAccDetModel'];
module.exports = fticCapitalGainAcUnitDetails;