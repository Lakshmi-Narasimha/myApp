/**
 * @ngdoc directive
 * @name investmentSummaryGrids
 * @requires investorEventConstants
 * @requires 
 * @requires 
 * @requires 
 * @requires 
 * @description
 *
 **/
'use strict';
var investmentSummaryGrids = function(panViewModel,familyPortfolioModel,investorEventConstants,investorConstants) {
    return {
        template: require('./investmentSummaryGrids.html'),
        restrict: 'E',
        replace: true,
        scope: {
            type:'=?'
        },
        link: function(scope) {
            var summaryGrids = function(data){
                var folioObjs ,
                returnsTemplate;
                scope.folioObjs = [];
                scope.pocontent = [];
                folioObjs = data;
                angular.forEach(folioObjs, function(folioObj) {
                    var myFolioObj = {};
                    myFolioObj.folioNumber = folioObj.folioId;
                    myFolioObj.gridData = [];
                    angular.forEach(folioObj.rows, function(row) {
                        var myRow = {};
                        myRow.folioNo = myFolioObj.folioNumber;
                        myRow.Account = row.accountNo;
                        myRow.Scheme = row.scheme;
                        myRow.TotalUnits = row.totalUnits;
                        myRow.CurrentCost = row.currentCost;
                        myRow.CurrentValue = row.currentValue;
                        myRow.Return = row.returns;
                        myFolioObj.gridData.push(myRow);
                    });
                    myFolioObj.modeofHolding = folioObj.modeofHolding;
                    myFolioObj.pocontent = [];
                    for (var holder in folioObj.holders) {
                        if (folioObj.holders[holder].type === 'Firstholder') {
                            myFolioObj.pocontent.push({ text: 'First Holder Name', value: folioObj.holders[holder].name });
                        }
                        if (folioObj.holders[holder].type === 'Secondholder') {
                            myFolioObj.pocontent.push({ text: 'Second Holder Name', value: folioObj.holders[holder].name });
                        }
                        if (folioObj.holders[holder].type === 'Thirdholder') {
                            myFolioObj.pocontent.push({ text: 'Third Holder Name', value: folioObj.holders[holder].name });
                        }
                        if (folioObj.holders[holder].type === 'Fourthholder') {
                            myFolioObj.pocontent.push({ text: 'Fourth Holder Name', value: folioObj.holders[holder].name });
                        }
                        if (folioObj.holders[holder].type === 'Fifthholder') {
                            myFolioObj.pocontent.push({ text: 'Fifth Holder Name', value: folioObj.holders[holder].name });
                        }
                        if (folioObj.holders[holder].type === 'Minorguardian') {
                            myFolioObj.pocontent.push({ text: 'Minor Guardian Name', value: folioObj.holders[holder].name });
                        }
                    }
                    myFolioObj.grandTotal = folioObj.grandTotal;
                    var myLastRow = {};
                    myLastRow.Account = myFolioObj.grandTotal.account;
                    // myLastRow.Scheme = myFolioObj.grandTotal.Scheme;
                    myLastRow.TotalUnits = myFolioObj.grandTotal.totalUnits;
                    myLastRow.CurrentCost = myFolioObj.grandTotal.currentCost;
                    myLastRow.CurrentValue = myFolioObj.grandTotal.currentValue;
                    // myLastRow.Return = myFolioObj.grandTotal.Return;
                    if(scope.type  !== investorConstants.myportfolio.FAMILY_PORTFOLIO_TYPE){
                        myFolioObj.gridData.push(myLastRow);
                    }
                    scope.folioObjs.push(myFolioObj);
                });
                scope.showFolioViewTemplate = function(folioNumber) {
                    scope.$emit('showFolioView', folioNumber);
                };
                scope.options = {
                    virtualizationThreshold: 100
                };
                var statusTemplate = '<div uib-popover-template="\'accountViewTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                    '<script type="text/ng-template" id="accountViewTemplate.html">' +
                    '<div><button type="button" ng-click="grid.appScope.$emit(\'showAccountView\', {accontNumber : row.entity.Account,folioNumber:COL_FIELD})" class="btn panel-orange-btn">Account Statement</button><button type="button" ng-click="grid.appScope.$emit(\'BuySIP\', {accontNumber : row.entity.Account,folioNumber:COL_FIELD})" class="btn panel-orange-btn">Buy</button><button type="button" ng-click="grid.appScope.$emit(\'StartASIP\', {accontNumber : row.entity.Account,folioNumber:COL_FIELD})" class="btn panel-orange-btn">Start a SIP</button><button type="button" ng-click="grid.appScope.$emit(\'RedeemSIP\', {accontNumber : row.entity.Account,folioNumber:COL_FIELD})" class="btn panel-orange-btn">Redeem</button><button type="button" ng-click="grid.appScope.$emit(\'SwitchSIP\', {accontNumber : row.entity.Account,folioNumber:COL_FIELD})" class="btn panel-orange-btn">Switch</button></div></script>';
                returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue"></span></div>' +
                    '<script type="text/ng-template" id="returnTemplate.html">' +
                    '<div class="overview-tool-tip">Annualized Rate of return on  your current investments in this account considering all inflows and outflows.</div></script>';
                var schemeAccount = '<div class="ui-grid-cell-contents"><div class="custom-bold">{{row.entity.Scheme}}</div><div>  {{ row.entity.Account}}</div></div>';
                if(scope.type  !== investorConstants.myportfolio.FAMILY_PORTFOLIO_TYPE){
                     returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue"></span></div>' +
                    '<script type="text/ng-template" id="returnTemplate.html">' +
                    '<div class="overview-tool-tip">Returns basis XIRR i.e., rate of return basis your investments at various time periods in this fund.</div></script>';
                }
                
                if(scope.type  === investorConstants.myportfolio.FAMILY_PORTFOLIO_TYPE){
                    scope.columnDefs = [
                        { field: 'Account', displayName: 'Account Number', width: '150'},
                        { field: 'Scheme', displayName: 'Fund Name', width: '232'},
                        { field: 'TotalUnits', displayName: 'Total Units', width: '120' },
                        { field: 'CurrentCost', displayName: 'Current Cost',cellClass:'text-right', width: '85', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                        { field: 'CurrentValue', displayName: 'Current Value', cellClass:'text-right', width: '85', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                        { field: 'Return', displayName: '', width: '120', headerCellTemplate: returnsTemplate }
                    ];
                }
                else {
                    scope.columnDefs = [
                        { field: 'folioNo', displayName: ' ', width: '48', cellTemplate: statusTemplate, enableSorting: false, pinnedLeft: true },
                        { field: 'Account', displayName: 'Account', width: '139', pinnedLeft: true, footerCellTemplate: '<div class="ui-grid-cell-contents">GRAND TOTAL</div>' },
                        { field: 'Scheme', displayName: 'Scheme', width: '175' },
                        { field: 'TotalUnits', displayName: 'Total Units', width: '120' },
                        { field: 'CurrentCost', displayName: 'Current Cost',cellClass:'text-right', width: '125', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                        { field: 'CurrentValue', displayName: 'Current Value',cellClass:'text-right', width: '125', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                        { field: 'Return', displayName: '', width: '103', headerCellTemplate: returnsTemplate }
                    ];
                }
            };
            scope.$on(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_PANVIEW,function(event,data){
                summaryGrids(familyPortfolioModel.getFamilyPFInvestmentSummary()[data]);
            });
            if(!scope.type){
                summaryGrids(panViewModel.getPanViewDtls().investmentSummary);
            }
            
        }
    };
};
investmentSummaryGrids.$inject = ['panViewModel','familyPortfolioModel','investorEventConstants','investorConstants'];
module.exports = investmentSummaryGrids;
