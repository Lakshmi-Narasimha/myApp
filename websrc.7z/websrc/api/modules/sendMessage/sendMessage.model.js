var config = require('../../../config/config');

var sendMessageModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [{
                    "messageList": [{
                        "nextmsgId": 20001,
                        "loginReq": false,
                        "messageText": "Thank you for chatting with Verizon Wireless"
                    }],
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "type": "header",
                    "msgId": 20000,
                    "messageType": "stateChange",
                    "state": "closed"
                }, {
                    "sequenceNumberInt": 20000,
                    "msgId": 20001,
                    "animationDuration": 800,
                    "type": "bot",
                    "messageList": [{
                        "nextmsgId": -1,
                        "loginReq": false,
                        "messageText": "Let me know if you need anything else. I'm always here for you."
                    }]
                }],
                "startMsgId": 20000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "2edfe2c1-970f-4cfe-974d-d458d5f2525a",
                    "type": "Success"
                }
            }
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "timeToWait": null,
            "customerID": "-1196452972424641378",
            "engagementID": "-1196452972424366591",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "2edfe2c1-970f-4cfe-974d-d458d5f2525a",
            "type": "Success"
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_SEND_MSG_URI
    }
};

module.exports = sendMessageModelConfig;
