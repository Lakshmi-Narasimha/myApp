var express = require('express');
var https = require('https');
var config = require('../../../config/config');

var router = express.Router();
var getMessageModel = require('./getMessage.model');
//var engagementModel = require('../engagement/engagement.model');
//var sendMessageModel = require('../sendMessage/sendMessage.model');
var apiUtils = require('../../common/apiUtils');

// api route
/* Trigerring the Get Message API on request from Client */
router.route('/mfchat/rest/message/:engagementID')
    .post(function(req, res) {
        console.log("Get Message API is trigerred");
        req.uri = getMessageModel.createRequestUri;
        console.log("Get Message API is trigerred", req.uri);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + req.params.engagementID,
                headers: {
                    'Cookie': req.sessionCookie
                }
            },
            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                console.log(proxyResponse.statusCode);
                if (res.statusCode === 200) {
                    if (proxyResponse.statusCode === 200 || 204) {
                        proxyResponse.on('data', function(chunk) {
                            chunk = JSON.parse(chunk);
                            console.log("Get Message API Response:", chunk);
                            getMessageModel.response.Page.engagementID = req.params.engagementID;
                            //getMessageModel.response.Page.status = engagementModel.response.Page.status;
                            if (chunk.messages[0] && chunk.messages[0].state) {
                                getMessageModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['display.text'];
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                            } else if (chunk.messages[0]) {
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                getMessageModel.response.Page.agentID = chunk.messages[0]['user.id'];
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                            }
                            console.log(getMessageModel.response.ModuleMap.Support.msgList[0].messageType);
                            var counter = getMessageModel.response.ModuleMap.Support.msgList[0].messageType === 'chatLine' ? apiUtils.customerInfo.chatGetMsgCounter++ : apiUtils.customerInfo.chatGetMsgCounter;
                            console.log(apiUtils.customerInfo.chatGetMsgCounter);
                            console.log(apiUtils.customerInfo.chatSendMsgCounter);
                            if(chunk.messages[0].messageText === 'login needed'){
                              getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                              getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                              getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;
                              res.send(getMessageModel.loginNeededResponse);
                            }
                            else if (chunk.messages[0] && chunk.messages[0].state === "closed") {
                                console.log("The chat state is now:", chunk.messages[0].state);

                                /*Calculating the time difference between the last end chat Date&time and the current date&Time*/
                                var timeDiff = apiUtils.checkSurveyStatus(apiUtils.customerInfo.pastChatEndTime, new Date());

                                /*Fixing the conditions of 2/2  for the Get/Send messages to initiate the Survey API */
                                var checkSurveyEligible = (apiUtils.customerInfo.chatGetMsgCounter >= 2 && apiUtils.customerInfo.chatSendMsgCounter >= 2);

                                /*Checking the time and 2/2 condition*/
                                //if (checkSurveyEligible && (apiUtils.customerInfo.pastChatEndTime || (timeDiff > 86400000))) {
                                if (checkSurveyEligible) {
                                    console.log('Send survey url');
                                    var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                    //var surveyUrlEncoded = encodeURI(surveyUrl);
                                    console.log('surveyURL:', surveyUrl);
                                    var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                    console.log('surveyMsg:',surveyMsg);

                                    getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                    console.log('page.surveyUrl:', surveyUrl);
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                    console.log('FeedLink.browserUrl:', surveyUrl);
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                    console.log('messageList[0].messageText:', surveyMsg);

                                    apiUtils.customerInfo.pastChatEndTime = new Date();

                                    /*Sending the Thank you and Survey in the Response on End Chat*/
                                    res.send(getMessageModel.surveyResponse);
                                    //console.log("the repsosne not on survey end:", getMessageModel.surveyResponse);
                                } else{

                                   /* Sending the Thank You response on End Chat*/
                                    res.send(getMessageModel.endResponse);
                                    //console.log("the repsosne not on non-servey end:", getMessageModel.endResponse);
                                }

                            } else {

                                  /*Sending the message sent form the TC to the Client*/
                                   res.send(getMessageModel.response);
                                   //console.log("the repsosne not on end:", getMessageModel.response);
                            }
                        });

                    } else {
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }
                } else {
                    res.send({
                        message: 'ERROR!!! Something went wrong while retrieving data.',
                        statusCode: res.statusCode
                    });

                }
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });
        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });
module.exports = router;
