coa = coa || {};
define(
		['jquery',
		  'underscore',
		  'backbone',
          'appcommon/analytics',
          'text!appmodules/coa/app/templates/addressEntry.html',
				'appcommon/globalcontext', 'config',
				'appmodules/coa/app/js/utils', 'text!appmodules/coa/app/templates/deleteMailingAddressList.html', ],
		function($,
				_, Backbone,Analytics, Template, GlobalContext, Config, Utils,DeletemailingAddressList) {
			var _forgnToMalngSwitch = false;
			var BASE_URL = Config.odataServiceName;
			var CLIENT_ID = null, FM_ID = Utils.readCookie('FMID'), API_COMMON_DATA_BODY = Utils.getConfigProperty('API_COMMON_DATA_BODY'),
			 	queryString = GlobalContext.getInstance().getGlobalContext().Context.QueryString;
				queryString = queryString?queryString:'';
			function getContextId() {
				var regex = /[?&]([^=#]+)=([^&#]*)/g, url = window.location.href, params = {}, match;
				while (match = regex.exec(url)) {
					params[match[1]] = match[2];
				}
				return params.contextid;
			}
			coa.views.AppView = Backbone.View
					.extend({
						el : '#coa-app',
						statsTemplate : _.template(Template),
						initialize : function() {
							this.$main = this.$('#user-info');
							this.listenTo(coa.Clients, 'reset', this.addAll);							
						},
						events : {
							'change .changeTyperadio input[type="radio"]' : 'toggleRadioChangeType',
							'change input[type="radio"]' : 'toggleRadioClassActive',
							'change .client-list-table input[type="checkbox"]' : 'toggleCheckClassActive',
							'change .account-list-table input[type="checkbox"]' : 'toggleCheckClassActiveAccnt',
							'click #step1-next-button' : 'navigateToStep2',
							'click #m-step1-next-button' : 'navigateToStep2',
							'click .account-list-table tbody tr' : 'selectCurrentRow',
							'click .client-list-table tbody tr': 'selectCurrentRow',
							'click .address-list-table tbody tr': 'selectAddressRow',
							'click .delete-ma-table tbody tr': 'selectDeleteMailingAddressList',
							'change input[name=addressType]' : 'showForeignAddressBoxes',
							'change #country-list-select' : 'handleProvinceForCanada',
							'keypress #zipcode' : 'validateZipCodeForUS',
							'keypress #addressLine1,#addressLine2,#addressLine3,#city' : 'validateAddrCodeForUS',
							'click .existing-addres-toggle' : 'handleExistingAddressToggle',
							'keyup  input[type="text"]': 'handleEnterKey',
							"change input[name='mailingType']": "handleMailingAddressTyepeChange",
							'click .future-date-toggle': 'handleFutureStarEndDateToggle',

						},
						unbindBinEvents : function() {
							return;
							$(this.el)
									.undelegate('#step1-next-button', 'click');

						},
						render: function () {
						    this.$main.html(this.statsTemplate(this.model.toJSON()));
						},
						clearView : function() {
							this.undelegateEvents();							
							this.model.unbind('change', this.render, this); 
						},
						renderClient : function(client) {
							return;
							var _clientView = new coa.views.clientView({
								model : client
							});
							client.user = this.model.get('submitterId');
							this.$('div.client-list tbody').append(
									$(_clientView.render()));
						},
						readContext : function() {
							Utils.lockForm();
							try {
								var _globalContxt = GlobalContext.getInstance();
								var _context = _globalContxt.getGlobalContext().Context;
								CLIENT_ID = _context.ContactId;
								coa.user.set('clId', _context.ContactId);
								if (!CLIENT_ID) {
									this.callInitialServices(_context.ContextId);
								} else {
									this.callSecondaryServices();
								}

							} catch (e) {
								this.callInitialServices();
								console.log('coa.globalcontext undefined');
							}

						},
						callInitialServices : function(contextId) {
							var _contextId = contextId;
							var _data = {};
							_data = $.extend({
								cntxId : _contextId
							}, API_COMMON_DATA_BODY);
							var _that = this;
							var _url = BASE_URL + 'getAdvisorSessionContext';
							Utils
									.get(
											_url,
											decodeURIComponent($.param(_data)),
											function(resp) {
												if(resp && resp.d.clIds && (resp.d.clIds.results != null && resp.d.clIds.results != undefined && resp.d.clIds.results != "") && resp.d.clIds.results[0]){
													CLIENT_ID = resp.d.clIds.results[0].clId;
													coa.user.set('clId', CLIENT_ID);
													_that.callSecondaryServices();
												}else{
													Utils.showSystemUnavailabelError(resp,true);	
												}
												
											},
											function(xhr) {
												Utils.unlockForm();
												Utils.showSystemUnavailabelError(xhr,true);
											}, 0);

						},
						callSecondaryServices : function() {
							coa.appView.fetchClientOwnerDetails();
							coa.appView.fetchAddress();
							coa.appView.fetchActiveGrps();
						},
						loadCountryList : function() {
							var _countryList = coa.countryList;
							var _listAsOptions = '<option value="" >Choose one</option>';
							$.each(_countryList, function(key, row) {
								_listAsOptions += '<option data-val="'
										+ row.name.toLowerCase() + '" value="'
										+ row.code + '" >' + row.name
										+ '</option>';
							});
							$("#country-list-select").html(_listAsOptions);
						},
                                                loadUsStateList : function(){

                                                    var _stateList = coa.USStateslist;
                                                    var _listAsOptions = '<option value="" >Choose one</option>';
                                                    $.each(_stateList, function(key, row) {
                                                          _listAsOptions += '<option data-val="'
                                                                      + row.name.toLowerCase() + '" value="'
                                                                      + row.code + '" >' + row.name
                                                                      + '</option>';
                                                    });
                                                    $("#state-list-select").html(_listAsOptions);

						
						},
						fetchAddress : function() {
							var _data = $.extend({}, API_COMMON_DATA_BODY);
							var _that = this;
							var _url = BASE_URL + "Client(ctx='COLA.CL',id='"
									+ CLIENT_ID + "')/clientPostalAddresses";
							coa.addressList
									.fetch({
										url : _url,
										data : decodeURIComponent($
												.param(_data)),
										reset : true,
										success : function(a, b, c) {
											coa.initialServiceCounter--;
											var _permAddrs = coa.user.get(
													'address').toJSON()[0];
											if(_permAddrs == "" || _permAddrs == undefined || _permAddrs == null){
												Utils.unlockForm();
												coa.initialServiceErrorCounter++;
												Utils.showSystemUnavailabelError(a,true);
												_that.finalServiceSuccesshandler();
											}else{
												coa.user.set('city',
														_permAddrs.ctyNm);
												coa.user.set('zipCode',
														_permAddrs.postlCd);
												coa.user.set('state',
														_permAddrs.stCd);
												if (!coa.user.get('caseId')) {
												    coa.user.set('eNewState', _permAddrs.stCd);
												}
												$(window).scrollTop(0);
												_that.finalServiceSuccesshandler();
											}
											
										},
										error : function(a, jqXhr) {
											coa.initialServiceCounter--;
											Utils.unlockForm();
											coa.initialServiceErrorCounter++;
											var _errorCode = jqXhr.status;
											var _customMessage = 'errorCode:'
													+ _errorCode;
											if (_errorCode == "500"
													|| _errorCode == "502"
													|| _errorCode == "503") {
												_customMessage = _errorCode
														+ 'Fatal';
											} else if (_errorCode == "401") {
												_customMessage = _errorCode
														+ 'Unauthorized';
											}
											Utils.showSystemUnavailabelError(jqXhr,true);
											_that.finalServiceSuccesshandler();
										},
										maxAge : -1
									});
						},
						fetchClientOwnerDetails : function() {
							this.model.fetchClientOwnerDetails();

						},
						fetchClients : function(activeGrpId) {
							var _url = BASE_URL + "Group(ctx='COLA.GRP',id='"
									+ activeGrpId + "')/activeClients";
							var _that = this;
							var _data = $.extend({}, API_COMMON_DATA_BODY);
							coa.Clients.fetch({
								url : _url,
								data : decodeURIComponent($.param(_data)),
								reset : true,
								success : function(d, resp) {
									coa.initialServiceCounter--;
									_that.finalServiceSuccesshandler();

								},
								error : function(a, xhr) {
									coa.initialServiceCounter--;
									Utils.unlockForm();
									var _errorCode = xhr.status;
									var _customMessage = 'errorCode:'
											+ _errorCode;
									if (_errorCode == "500"
											|| _errorCode == "502"
											|| _errorCode == "503") {
										_customMessage = _errorCode + 'Fatal';
									} else if (_errorCode == "401") {
										_customMessage = _errorCode
												+ 'Unauthorized';
									}
									Utils.showSystemUnavailabelError(xhr,true);
									coa.initialServiceErrorCounter++;
									_that.finalServiceSuccesshandler();
								},
								maxAge : -1

							});
						},
						fetchActiveGrps : function() {
							this.model.fetchActiveGrps();

						},
						hideSystemError : function() {
							Utils.hideSystemUnavailabelError();
						},
						fetchActiveAccountList : function() {
							Utils.hideSystemUnavailabelError();
							// reset the toggle button and hide errors
							var _container = $('.existing-address-toggle-container');
							_container.removeClass('hidden error').find(
									'label.error').addClass('hidden');
							_container.find('span.coa-adjust-left').addClass(
									'hidden');
							_container.find('button[value="no"]').addClass(
									'active');
							// reset selected address
							var _eac = $('.existing-address-container');
							_eac.find('.radio-group-conatiner').removeClass(
									'hidden active');
							_eac.find('input[type="radio"]').prop('checked',
									false);
							if (!$("#changeTypeMailing").prop("data-accounts-loaded")) {
								Utils.lockForm();
								this.model.fetchActiveAccountList();
							} else {
							    if (coa.user.get('accounts').length == 0) {
							       this.showAccountEmptyOrgError();
							    } else {
							        if (!coa.accountView) {
							            coa.accountView = new coa.views.accountView({
                                                    el: $("table.account-list-table tbody")
                                                });
							        } else {
							            coa.accountView.render();
							        }
							        Utils.hideSystemUnavailabelError();
							        $('.select-all').removeAttr("disabled");
							        this.renderDeleteMailingAddressList();
							    }
									
							}

						},
						fetchActiveAccountDetails: function (successCallback, doNotShowWarning) {
							Utils.lockForm();
							this.model.fetchActiveAccountDetails(successCallback, doNotShowWarning);
						},
						finalServiceSuccesshandler : function() {
							if (coa.initialServiceCounter == 0
									&& coa.initialServiceErrorCounter == 0) {
								if(coa.user.get('userType') == "P"){
									Utils.unlockForm();
								}
								coa.appView.render();
								coa.appView.initCustom();
							} else if (coa.initialServiceCounter == 0) {
								Utils.unlockForm();
								Utils
										.showSystemUnavailabelError();
							}
						},
						handleExistingAddressToggle : function(e) {
							var _$target = $(e.target);
							$('.existing-addres-toggle').removeClass('active');
							if (this.model.get('address').length > 1) {
								if (_$target.hasClass('toggle-button-no')) {
									this.hideExistingAddressBlock();
								} else {
									this.showExistingAddressBlock();

								}
								_$target.addClass('active');
							} else {
								this.hideExistingAddressBlock();
								if (_$target.hasClass('toggle-button-no')) {
									this.hideExistingAddressBlock();
									this.hideExistCheckNoAddressError();
								} else {
									this.showExistCheckNoAddressError();

								}
								_$target.addClass('active');
							}

						},

						validateAddrCodeForUS : function(e) {
							var _$el = $(e.target);
							if (_$el.val().length >= 30) {
								e.stopPropagation();
								e.preventDefault();
								return false;
							}

						},

						validateZipCodeForUS : function(e) {
							_el = document.getElementById('zipcode');

							if ($('#addressTypeUs').prop('checked')) {
								var _regxNumOnly = new RegExp('^\\d*$');
								var _str = String.fromCharCode(e.keyCode);
								if (!_regxNumOnly.test(_str)) {
									e.stopPropagation();
									e.preventDefault();
									return false;
								}

								if ($('#zipcode').val().length >= 5
										&& _el.selectionStart == _el.selectionEnd) {
									e.stopPropagation();
									e.preventDefault();
									return false;
								}

							} else if ($('#country-list-select').val() == "CA") {
								if ($('#zipcode').val().length >= 6
										&& _el.selectionStart == _el.selectionEnd) {
									e.stopPropagation();
									e.preventDefault();
									return false;
								}
							}

						},
                        /*
						initInfoPopup:function(){
							var _self = this;
							var _placement = 'right';
							if (window.innerWidth < 768) {
								_placement = 'bottom';
							}
							$('.popover.info-popup').remove();
							$('#user-home-view .icon-info.info-popup').popover(
									'destroy');
							$('#user-home-view .icon-info')
									.popover(
											{
												container : 'body',
												html : true,
												placement : _placement,
												viewport : 'body',
												viewport : 'body',
												title : 'Change type <i class="icon-popover-close"></i>',
												template : '<div class="popover info-popup coa-popover" role="tooltip"><div class="arrow info-popup">'
														+ '</div><h2 class="popover-title info-popup"></h2><div class="popover-content info-popup"></div></div>'
											});
							var _isOpen = true;
							$('#user-home-view .icon-info').on(
									'hidden.bs.popover', function() {
										_isOpen = false;
									});
							$('#user-home-view .icon-info')
									.on(
											'shown.bs.popover',
											function() {
												_isOpen = true;
												if (!$('.icon-popover-close').length) {
													$('.popover-title')
															.append(
																	'<i class="icon-popover-close"></i>');
												}
												$(".icon-popover-close")
														.off("click")
														.on(
																"click",
																function(e) {
																	$(

																	'.icon-info')
																			.popover(
																					'hide');
																	_isOpen = false;
																});
												$(document)
														.off('click', 'body')
														.on(
																'click',
																'body',
																function(e) {
																	var _$targetElm = $(e.target);
																	if (_isOpen
																			&& !_$targetElm
																					.hasClass('info-popup')) {
																		$(
																				'#user-home-view .icon-info')
																				.popover(
																						'hide');
																		_isOpen = false;
																	}
																});

											});
							function isWinTablet() {
								return (navigator.userAgent.toLowerCase().indexOf(
										"windows nt") != -1 && navigator.userAgent
										.toLowerCase().indexOf("touch") != -1);
							}
							var _evt = isWinTablet() ? 'resize' : 'orientationchange';
							$(window)
									.off(_evt)
									.on(
											_evt,
											function(event) {
												var _timeout = 0;
												(function(_event) {
													if (navigator.userAgent
															.indexOf('Android') > -1) {
														_timeout = 200;
													}
													setTimeout(
															function() {
																var _activePopup = $('#user-home-view .icon-info[aria-describedby]');
																_self.initInfoPopup();
																setTimeout(function() {
																	_activePopup
																			.click();
																}, 10);
															}, _timeout);
												})(event);

											});
						
						},
                        */
						initCustom: function () {
						    this.initializeStartEndDatePickers();
						    $('#user-home-view .custom-select').customizeSelect();
						    $("#user-home-view").invokeInfoPopup();
							//this.initInfoPopup();
							var _changeTypeParent = $('#changeTypeMailing').parent().parent();
							var _$zipCode = $("#zipcode");
							_$zipCode.parent().parent().show();
							this.loadCountryList();
                            this.loadUsStateList();
							$('#country-list-select').val(coa.user.get('newCountry')).trigger('change');
							if (coa.user.get('addressType') == "Foreign") {
								$('#changeTypePermanent').click();
								$('#country-list-select').trigger('change');
								if (coa.user.get('newCountry') == "CA") {
									this.showCanadaFields();
									$('#province-list-select').val(coa.user.get('newProvince')).trigger('change');
								} else {
									this.hideCanadaFields();
								}
							} else {
							    if (coa.user.get('existingAddress')) {
									$('.change-address-fields').addClass('hidden');
									$($('input[data-master-container="existing-address"]')[Number(coa.user.get('existingAddressIndex')) - 1])
											.prop('checked', true).parent().parent().addClass('active');
								}
								_changeTypeParent.show();
							}

							if (coa.user.get('userType') == "O") {
							    $('#changeTypePermanent').parent().parent().hide();
							    if (coa.user.get('fromBackButton') != true) {
							        $('#changeTypeMailing').click();
							    }
								
							}

							$('.coa-step').removeClass('finished active');
							$('.coa-step.step1').addClass('active');
							if (coa.user.get('fromBackButton')) {
								if (coa.user.get('accounts').length > 0) {
									$("#changeTypeMailing").prop("data-accounts-loaded", true);
									var _$accountListTable = $('.account-list-table');
									if (coa.user.get('accounts').length == _$accountListTable.find('tbody input[type="checkbox"]:checked').length) {
										_$accountListTable.find('th input[type="checkbox"]').prop('checked', true);
									}

								}
								$('#state-list-select').val(coa.user.get('eNewState')).trigger('change');
								if (coa.user.get('addressType') == "U.S"|| (coa.user.get('addressType') == "Foreign" && coa.user.get('newCountry') == "CA")) {
									$('div[for="zipcode"]').show();
								} else {
									$('div[for="zipcode"]').hide();
								}								
							} else {
								if (coa.user.get("oldAddressType") == "U.S") {
									$('#state-list-select').val(coa.user.get('eNewState')).trigger('change');
								} else {
									$('#state-list-select').val('').trigger('change');
									var _country = coa.user.get('address').toJSON()[0].cntryNm;
									var _countryCd = $('#country-list-select option[data-val="'+ _country.toLowerCase()+ '"]').attr('value');
									coa.user.set('countryName', _country);
									coa.user.set('country', _countryCd);									
								}
							    if (coa.user.get('changeType') == "Mailing" && coa.user.get('mailingType') == "new") {
								    this.fetchActiveAccountList();
								}
							}
							$("#zipcode").val(coa.user.get("eNewZip"));
							if (coa.user.get('changeType') == "Mailing" && coa.user.get('mailingType') == "delete") {
							    this.handleMailingAddressTyepeChange(true);
							}
							if (coa.user.get('changeType') == "Mailing" && coa.user.get("mailingType") == "new" && coa.user.get("mailingAcctAddresError")) {
							    Utils.showSystemWarningError();
							}

						},
						hideInfoPopup : function() {
							$('#user-home-view .icon-info').popover('hide');
						},
						toggleRadioClassActive : function(event) {
							var _radio = $(event.target);
							var _radioHolder = _radio.parents('div.radio-group-conatiner').parent();
							_radioHolder.find('div.radio-group-conatiner').removeClass('active');
							_radio.parents('div.radio-group-conatiner').addClass('active');
							var _addressType = $('input[name=addressType]:checked').val();
							if (_addressType == "Foreign") {
							    $('#addressLine1, #addressLine2, #addressLine3').removeClass('us-address-1');
							} else {
							    $('#addressLine1, #addressLine2, #addressLine3').addClass('us-address-1');
							}
						},
						toggleRadioChangeType : function() {
						    this.showNonDeleteAddressFields();
						    this.hideSystemError();
							var _checkedradio = $('.changeTyperadio').find(
									'input[type="radio"]:checked');
							var _foreignAddressType = $('#addressTypeUsForeign')
									.parent().parent();
							var _addressType = $(
									'input[name=addressType]:checked').val();
							if (_addressType == "Foreign") {
								$('#zipcode').val('');
							}
							if (_checkedradio.val() == "Permanent") {
							    $('#Permanent').removeClass("hidden");
							    $('#verify').addClass("hidden");
							    $('#Mailing').addClass("hidden");
							}
							else if (_checkedradio.val() == "Mailing") {
                                 $('#Mailing').removeClass("hidden");
                                 $('#verify').addClass("hidden");
							    $('#Permanent').addClass("hidden");
							} else if (_checkedradio.val() == "Verify") {
							    $('#verify').removeClass("hidden");
							    $('#Mailing').addClass("hidden");
                                $('#Permanent').addClass("hidden");
							}
							if (_checkedradio.val() == "Mailing") {
							    var _$state = $("#state-list-select");
							    coa.user.set('eNewState', _$state.val());
							    $("#mailingTypeNew").click();
							    _forgnToMalngSwitch = true;
							    this.showMailingAddressRelatedFields();
							    if (coa.user.get('eNewState') != "") {
							        _$state.val(coa.user.get('eNewState'));
							    }
							} else if (_checkedradio.val() == "Permanent") {
							    this.hideDeleteMailingAddressFields();
							    $('.mailing-only-filed').addClass("hidden");
							    $('#pa-ma-fields-container').removeClass("hidden");
							    $('#va-fields-container').addClass("hidden");
								this.hideExistingAddressCheck();
								$('.client-list').show().removeClass("hidden");
								$('.static-text-client').show();
								$('.account-list').hide();

								this.hideCanadaFields(true);
								_foreignAddressType.show();
								if (coa.user.get('userType') == "P") {
									if (coa.user.get('oldAddressType') == "Foreign") {
										$('#addressTypeUsForeign').click();
								}
							}
								$('#addressLine1,#addressLine2,#addressLine3').addClass('po-box-check');
								$('div[for="addressLine1"],div[for="addressLine2"],div[for="addressLine3"]').find('span.help-block').text('No P.O. boxes allowed');
								$('div[for="addressLine1"],div[for="addressLine2"],div[for="addressLine3"]').find('span.label-help').text('(optional)');
							} else if (_checkedradio.val() == "Verify") {
							    this.hideDeleteMailingAddressFields();
							    $('.mailing-only-filed').addClass("hidden");
							    $('#pa-ma-fields-container').addClass("hidden");
							    $('#va-fields-container').removeClass("hidden");
							}
							this.resetErrorClasses();
							if (_checkedradio.val() == "Mailing" && coa.user.get("mailingAcctAddresError")) {
							    Utils.showSystemWarningError();
							}
						},
						showMailingAddressRelatedFields: function () {
						    var _foreignAddressType = $('#addressTypeUsForeign').parent().parent();
						    $('#pa-ma-fields-container,.mailing-only-filed:not(.delete-mailing-field)').removeClass("hidden");
						    $('#va-fields-container').addClass("hidden");
						    this.showExistingAddressCheck();
						    $('.account-list').show();
						    $('.static-text-client').hide();
						    $('.client-list').hide();
						    $('.select-all').attr("disabled", true);
						    $('input[name=addressType]').prop('checked',false);
						    $('#addressTypeUs').click();
						    this.fetchActiveAccountList();
						    _foreignAddressType.hide();
						    $('#addressLine1,#addressLine2,#addressLine3').removeClass('po-box-check');
						    $('div[for="addressLine1"],div[for="addressLine2"],div[for="addressLine3"]').find('span.help-block').text('');
                            $('div[for="addressLine1"],div[for="addressLine2"],div[for="addressLine3"]').find('span.label-help').text('(optional)');
						    $('#future-start-end-date-container').removeClass("hidden");
						},
						toggleCheckClassActive : function(event) {},
						toggleCheckClassActiveAccnt: function (event) {
						  
							event.stopPropagation();
							var _checkbox = $(event.target);
							if (_checkbox.attr('data-all') == "true") {
								var _model = this.model;
								var _checks = $('.account-list-table tbody').find('input');
								if (_checkbox.prop('checked') == true) {
									$('.account-list-table tbody').find('input').prop('checked', true);
									$(_checks).each(function(_datum, _index) {
										var _index = $(this).attr('data-index');
										$(this).parents('tr').addClass('active');
										_model.get('accounts').at(_index).set("checked",true);
									});
								} else {
									$('.account-list-table tbody').find('input').prop('checked',false);
									$(_checks).each(function(_datum) {
										var _index = $(this).attr('data-index');
										_model.get('accounts').at(_index).set("checked",false);
										$(this).parents('tr').removeClass('active');
									});
								}

							} 

						},
						navigateToStep2: function () {
						    var _$addressType = $('input[name="changeType"]:checked'), _$mailinType = $('input[name="mailingType"]:checked');
						    if (_$addressType.val() == "Mailing" && _$mailinType.val() == "delete" && coa.user.get('oldAddressType') == "Foreign") {
						        BootstrapDialog.show({
						            title: 'Important information',
						            message: "We are unable to unassign a mailing address because the client has a foreign permanent address.",
						            cssClass: '',
						            buttons: [{
						                label: 'OK',
						                cssClass: 'btn pt-btn-yes generic-button btn-primary',
						                action: function (dialog) {
						                    dialog.close();
						                }
						            }]
						        });
						        return;
						    }
							$('.icon-info').popover('hide');
							if ($('.use-existing-addres-toggle').is(':visible') && $('.existing-addres-toggle.toggle-button-yes').hasClass('active') && coa.user.get('address').length == 1) {
							    $(window).scrollTop(200);
							    return;
							}
							if (this.model.validate()) {
							    if (coa.user.get('changeType') == "Verify") {
							        if (!$("#validate-adress-confirm-check").prop("checked")) {
							            BootstrapDialog.show({
							                title: 'Important information',
							                message: "You must complete that you've received client confirmation.",
							                cssClass: '',
							                buttons: [{
                                                        label: 'OK',
                                                        cssClass: 'btn pt-btn-yes generic-button btn-primary',
                                                        action: function (dialog) {
                                                            dialog.close();
                                                        }
                                                    }]
							            });
							            return;
							        }
							    }							    
							    if (coa.user.get('addressType') == "Foreign" || coa.user.get('existingAddress') ||  coa.user.get('changeType') == "Verify" 
                                    || (coa.user.get('changeType') == "Mailing" && coa.user.get('mailingType') == "delete")) {
									this.skipValidateStep();
									return;
								}
								
								coa.user.set('scrub', {
									'validationFailure' : true,
									'systemFailure' : false,
								});

								var _url = BASE_URL+ "scrubAddress?format=json";
								var _data1 = {
									"addrCarrRteNbr" : null,
									"addrDlvPntBarCd" : null,
									"addrLn1Txt" : "",
									"addrLn2Txt" : null,
									"addrLn3Txt" : null,
									"addrLn4Txt" : null,
									"addrLn5Txt" : null,
									"AddrStandardizedCd" : null,
									"addrSubTypCd" : null,
									"addrTypCd" : "Postal Address",
									"addrVldCkDt" : null,
									"AddrVldCkRsltCd" : null,
									"addrVldCkStatCd" : null,
									"communeNbr" : null,
									"ctryCd" : null,
									"dwellingTypCd" : null,
									"localityNm" : null,
									"mailboxTxt" : null,
									"origAddrMchCd" : null,
									"poCdTxt" : "",
									"postTownNm" : "",
									"premiseNm" : null,
									"PrisionAddrCd" : null,
									"RegnAreaCd" : "",
									"standardizationvndrCd" : null,
									"StrNbr" : null,
									"StrNm" : null,
									"SubPremiseDescTxt" : null,
									"superiorLocalityNm" : null,
									"superiorStrNm" : null,
									"tmZoneCd" : null,
									"usCarrRteSeqNbr" : null,
									"vndrSuppldAddrCd": null
								};
								_data1.addrLn1Txt = coa.user.get('addressLine1');
								_data1.postTownNm = coa.user.get('newCIty');
								_data1.RegnAreaCd = coa.user.get('newState');
								_data1.poCdTxt = coa.user.get('newZip');
								if (coa.user.get('addressLine2') != "")
									_data1.addrLn2Txt = coa.user.get('addressLine2');
								if (coa.user.get('addressLine3') != "")
									_data1.addrLn3Txt = coa.user.get('addressLine3');
								if (coa.user.get('newCountry') != "")
									_data1.ctryCd = coa.user.get('newCountry');
								if (_data1.addrTypCd == "Foreign") {
									if (_data1.ctryCd == "CA") {
										_data1.poCdTxt = coa.user.get('newZip');								
									}
								}
								coa.user.set('addressChecked', false);
								Utils.lockForm();
								Utils.post(_url,JSON.stringify(_data1),
												function(resp) {
													Utils.unlockForm();
													var _statusValue = resp.d.status;
													var _postalAddress = resp.d.postalAddress;
													var _stCode = _statusValue.statCd;
													if (_stCode == "0000") {
														var _adline1 = _postalAddress.addrLn1Txt;
														var _adline2 = _postalAddress.addrLn2Txt;
														var _adline3 = _postalAddress.addrLn3Txt;
														var _adnewCity = _postalAddress.postTownNm;
														var _adnewState = _postalAddress.RegnAreaCd;
														var _adnewZip = _postalAddress.poCdTxt;
														var _adnewCountry = _postalAddress.ctryCd;

														coa.user.set('addressLine1',_adline1);
														coa.user.set('addressLine2',_adline2);
														coa.user.set('addressLine3',_adline3);
														coa.user.set('newCountry',_adnewCountry);
														coa.user.set('newCIty',_adnewCity);
														coa.user.set('newState',_adnewState);
														coa.user.set('newZip',_adnewZip);

														coa.user.set('scrub',{'validationSuccess' : true,'validationFailure' : false,});
													} else if (_stCode == "0001") {
														coa.user.set('scrub',{'validationSuccess' : false,'validationFailure' : true,});
													}

													else {
                                                        coa.user.set('scrub',{'validationSuccess' : false,'validationFailure' : true,});
													}
													navigate();
												},
												function() {
													Utils.unlockForm();
													coa.user.set('scrub',{'validationFailure' : true,'systemFailure' : false,'validationSuccess' : false,});
													navigate();
												}, 0);
								function navigate() {
									coa.Router.navigate('validation'+queryString, {
										trigger : true
									});
									$('.coa-step').removeClass('active finished');
									$('.coa-step.step2').addClass('active');
									$('.coa-step.step1').addClass('finished');
								}

							}
						},
						skipValidateStep : function() {
							coa.Router.navigate('verify'+queryString, {trigger : true});
							$('.coa-step').removeClass('active finished');
							$('.coa-step.step3').addClass('active');
							$('.coa-step.step1,.coa-step.step2').addClass('finished');
						},
						selectCurrentRow: function (e) {
						    var _isCheckBox = false;
							this.hideInfoPopup();
							e.stopPropagation();
							//e.preventDefault();
							if ($(e.target).prop("type") == "checkbox" ) {
							    _isCheckBox = true;
							}
							var _selectedRow = $(e.currentTarget);
							_selectedRow.toggleClass('active');
							var _checked = true, _selectedIndex;
							var checkBox = _selectedRow.find('input[type="checkbox"]');
							if ($(checkBox).prop("checked")) {
							    _checked = _isCheckBox ? true : false;
							    $(checkBox).prop("checked", _checked);
							} else {
							    _checked = _isCheckBox ? false : true;
							    $(checkBox).prop("checked", _checked);
							}
							if (_selectedRow.hasClass('client-view')) {
								var _clients = $('.client-list-table .client-view').find('input[type=checkbox]');
								_selectedIndex = _clients.index(checkBox);
								var _client = coa.user.get('clients').at(_selectedIndex);
								_client.set('checked', _checked);
							} else {
								var _accounts = $('.account-list-table .account-view').find('input[type=checkbox]');
								_selectedIndex = _accounts.index(checkBox);
								coa.user.get('accounts').at(_selectedIndex).set("checked", _checked);
								// For handling select all checkbox
								var _checkedNos = $('.account-list-table').find('input.value-selection:checked').length;
								var _totalNos = $('.account-list-table').find('input.value-selection').length;
								if (_totalNos == _checkedNos) {
									$('.account-list-table').find('input.select-all').prop('checked',true);
								} else {
									$('.account-list-table').find('input.select-all').prop('checked',false);
								}

							}

						},selectAddressRow: function (e) {
						        this.hideInfoPopup();
						        var _selectedRow = $(e.currentTarget), _selectedIndex = null,_$radioBox = null;
						        if (!_selectedRow.hasClass("active")) {
						            if (!$("#changeTypeMailing").prop("data-accounts-loaded") && _selectedRow.data("address-type") == "Mailing") {
						                Utils.lockForm();
						                this.model.fetchActiveAccountList(accountsCallSuccess, true);
						            }
						            _$radioBox = _selectedRow.find('input[type="radio"]');
						            $('.verify-addres-tr').removeClass("active");
						            if ($(e.target).prop("type") != "radio") {
						                if (_$radioBox.prop("checked")) {
						                    _$radioBox.prop("checked", false);
						                } else {
						                    _$radioBox.prop("checked", true);
						                }
						            }
						            if (_selectedRow.find('input[type="radio"]:checked').data("addres-type") == "Permanent") {
						                $('#verify-pa-disclosure').removeClass("hidden");
						                $('#verify-ma-disclosure').addClass("hidden");
						            } else {
						                $('#verify-ma-disclosure').removeClass("hidden");
						                $('#verify-pa-disclosure').addClass("hidden");
						            }
                                    
						            _selectedRow.addClass('active');
						        }
						        function accountsCallSuccess() {
						            if (coa.user.get("accounts").length > 0) {
						                $("#changeTypeMailing").prop("data-accounts-loaded", true);
						            }
						            Utils.unlockForm();
						        }
						},
						selectDeleteMailingAddressList: function (e) {
						    this.hideInfoPopup();
						    var _selectedRow = $(e.currentTarget), _selectedIndex = null, _$radioBox = null;
						    if (!_selectedRow.hasClass("active")) {
						        _$radioBox = _selectedRow.find('input[type="radio"]');
						        $('.delete-ma-tr').removeClass("active");
						        if ($(e.target).prop("type") != "radio") {
						            if (_$radioBox.prop("checked")) {
						                _$radioBox.prop("checked", false);
						            } else {
						                _$radioBox.prop("checked", true);
						            }
						        }
						        _selectedRow.addClass('active');
						    }
						},
						showForeignAddressBoxes : function() {
							this.resetErrorClasses();
							var _selectedAddressType = $(
									"input[name=addressType]:checked").val();
							var _$zipCode = $("#zipcode");
							if (!_forgnToMalngSwitch) {
								_$zipCode.val('');

							}
							_forgnToMalngSwitch = false;
							if (_selectedAddressType == "Foreign") {
								this.showForeignRelatedFields();
								this.hideCanadaFields();
								this.hideExistingAddressBlock();
								this.hideExistingAddressCheck();
								$('#addressLine1').addClass('address');
								$('#addressLine1').removeClass('us-address-1');

							} else {

								this.hideForeignRelatedFields();
								this.hideCanadaFields();
								$('#state-list-select').trigger('change');
								_$zipCode.parent().parent().show();
								$('#addressLine1').addClass('us-address-1');
								$('#addressLine1').removeClass('address');
							}
						},
						handleProvinceForCanada : function() {
							var _selectedCOuntry = $("#country-list-select")
									.val();
							var _$zipCode = $("#zipcode");
							if (_selectedCOuntry == "CA") {
								this.showCanadaFields();
							} else if (_selectedCOuntry != "") {
								this.hideCanadaFields();
							} else {
								_$zipCode.addClass("required");
							}
						},
						hideExistingAddressCheck : function() {
							$('.existing-address-toggle-container').addClass(
									'hidden');
							$('.existing-address-container').addClass('hidden');
							$('.change-address-fields').removeClass('hidden');
						},
						showExistingAddressCheck: function () {
						   
							$('.existing-address-toggle-container')
									.removeClass('hidden');
							$('.use-existing-addres-toggle button')
									.removeClass('active').find(
											'button.toggle-button-no')
									.addClass('active');
							$('.change-address-fields').removeClass('hidden');
							$('.existing-address-container').addClass('hidden');
						},
						hideExistingAddressBlock: function () {
						    Analytics.analytics.recordAction('COA:ExsitingAddressMailing:NO:clicked');

							// $("#zipcode").val('');
							$('.existing-address-container').addClass('hidden');
							$('.change-address-fields').removeClass('hidden');
							$('.existing-address-container').removeClass(
									'error');
							$('.existing-address-container')
									.find('label.error').addClass('hidden');
							$("#state-list-select").val(coa.user.get('state'))
									.trigger('change');
						},
						showExistingAddressBlock: function () {
						    Analytics.analytics.recordAction('COA:ExsitingAddressMailing:YES:clicked');
							var _$addrsContainer = $('.existing-address-container');
							_$addrsContainer.removeClass('hidden');
							_$addrsContainer.find('.radio-group-conatiner')
									.removeClass('active');
							_$addrsContainer.find('input[type="radio"]').prop(
									'checked', false);
							$('.change-address-fields').addClass('hidden');
						},
						showExistCheckNoAddressError : function() {
							$('.existing-address-toggle-container').addClass(
									'error').find(
									'span.coa-adjust-left,label.error')
									.removeClass('hidden');
						},
						hideExistCheckNoAddressError : function() {
							$('.existing-address-toggle-container')
									.removeClass('error').find(
											'span.coa-adjust-left,label.error')
									.addClass('hidden');
						},
						hideForeignRelatedFields : function() {
							this.hideCanadaFields();
							var _$zipCode = $("#zipcode");
							if (coa.isMobile) {
								_$zipCode.attr('type', 'number');
							} else {
								_$zipCode.attr('type', 'text');
							}
							_$zipCode.parent().parent().hide();
							$("div[for=country-list-select]").hide();
							$(".coa-fn-text-container").hide();
							$('#state-list-select').val('').trigger('change');
							$("div[for=state-list-select]").show();
						},
						showForeignRelatedFields : function(isCanada) {
							var _$zipCode = $("#zipcode");
							_$zipCode.attr('type', 'text').val('');
							_$zipCode.parent().parent().hide();
							$("div[for=state-list-select]").hide();
							$('#country-list-select').val('').trigger('change');
							$("div[for=country-list-select]").show();
							$(".coa-fn-text-container").show();

						},
						showCanadaFields : function() {
							var _$zipCode = $("#zipcode");
							_$zipCode.val('');
							$("div[for=province]").show();
							$('#province-list-select').val('')
									.trigger('change').show();
							$("div[for=zipcode]div").eq(0).find("label").eq(0)
									.text("Postal code");
							_$zipCode.parent().parent().show();
							_$zipCode.addClass("required canada-zipcode")
									.removeClass('us-zipcode');
							_$zipCode.val('');

						},
						hideCanadaFields : function(isUS) {
							var _$zipCode = $("#zipcode");
							$("div[for=province]").hide();
							$('#province-list-select').val('')
									.trigger('change').hide();
							$("div[for=zipcode]div").eq(0).find("label").eq(0)
									.text("Zip code");
							if (isUS) {
								_$zipCode.parent().parent().show();
							} else {
								_$zipCode.parent().parent().hide();
							}

							_$zipCode.addClass("required us-zipcode")
									.removeClass('canada-zipcode');
						},

						resetErrorClasses : function() {
							$('div.error').removeClass('error');
							$('label.error').addClass('hidden');
							$('span.coa-adjust-left').addClass('hidden');
						},
						showAccountEmptyOrgError : function(message, url,
								lineNumber) {
							Utils.unlockForm();
							$('#use-existing-address , #future-start-end-date-container , #unassign-mailing-address, #new-mailing-address-account-contnr, #msg-mailing, #unassign-mail-address-info' ).addClass('hidden');
						},
						handleEnterKey : function(e) {
							e.which = e.which || e.keyCode;
							if (e.which == 13) {
								$('#coa-app #step1-next-button').trigger('click');
							}
						},
						handlerForCancel : function() {
							$('#coa-cancel-modal').modal('show');							
						}, hidePermanentAddressFileds: function () {
						}, hideMailingAddressFields: function () {
						}, hideVerifyAddressFields: function () {
						}, showPermanentAddressFileds: function () {
						}, showMailingAddressFields: function () {
						}, showVerifyAddressFields: function () {
						}, renderDeleteMailingAddressList: function () {
						    var _compiledTemplate = _.template(DeletemailingAddressList);
						    $('#delete-ma-accounts-list').html(_compiledTemplate(this.model.toJSON()));
						}, handleMailingAddressTyepeChange: function (programmaticInvoke) {
						    var _mailingType = $('input[name="mailingType"]:checked'), _$state = $("#state-list-select");
						    if (_mailingType.val() == "new") {
						        this.showMailingAddressRelatedFields();
						        this.hideDeleteMailingAddressFields();
						        this.showNonDeleteAddressFields();
						        if (programmaticInvoke !== true) {
						            if (coa.user.get('eNewState') != "") {
						                _$state.val(coa.user.get('eNewState'));
						            }
						        }
						        if (coa.user.get("mailingAcctAddresError")) {
						            Utils.showSystemWarningError();
						        }
						    } else {
						        if (programmaticInvoke !== true) {
						            coa.user.set('eNewState', _$state.val());
						        }
						        this.hideNewMailingAddressFields();
						        this.showDeleteMailingAddressFields();
						        this.hideNonDeleteAddressFields();
						        if (coa.user.get('oldAddressType') == "Foreign") {
						            BootstrapDialog.show({
						                title: 'Important information',
						                message: "We are unable to unassign a mailing address because the client has a foreign permanent address.",
						                cssClass: '',
						                buttons: [{
						                    label: 'OK',
						                    cssClass: 'btn pt-btn-yes generic-button btn-primary',
						                    action: function (dialog) {
						                        dialog.close();
						                    }
						                }]
						            });
						        }
						        if (coa.user.get("mailingAcctAddresError")) {
						            Utils.hideSystemUnavailabelError();
						        }
						    }
						    
						},
						showNewMailingAddressFields: function () {
						    $('#new-mailing-address-account-contnr').show();
						    this.hideExistingAddressBlock();
						},
						hideNewMailingAddressFields: function () {
						    $('.existing-address-toggle-container,.existing-address-container,.change-address-fields,#future-start-end-date-container').addClass("hidden");
						    this.hideExistCheckNoAddressError();
						    $('#new-mailing-address-account-contnr').hide();
						},
						showDeleteMailingAddressFields: function () {
						    $('.static-text-account').addClass("hidden");
						    $('#delete-mailing-address-account-contnr,.mailing-only-filed.delete-mailing-field').removeClass("hidden");
						},
						hideDeleteMailingAddressFields: function () {
						    $('#delete-mailing-address-account-contnr').addClass("hidden");
						},
						hideNonDeleteAddressFields: function () {
						    $('.non-delete-mailing-general').addClass("hidden");
						},
						showNonDeleteAddressFields: function () {
						    $('.non-delete-mailing-general').removeClass("hidden");
						},
						initializeStartEndDatePickers: function () {
						    $("#future-start-date").datepicker({
						        minDate: 1,
                                maxDate:547,
						        showOn: "button",
						        buttonImage: "images/cal-icon.png",
						        buttonImageOnly: true,
						        beforeShow: function () {
						        }
						    });
						    
						    $("#future-end-date").datepicker({
						        minDate: 1,
						        showOn: "button",
						        buttonImage: "images/cal-icon.png",
						        buttonImageOnly: true,
						        beforeShow: function () {
						        }
						    });

						    var today = new Date();
						    var startDate = $('#future-start-date').val();
						    var endDate = $('#future-end-date').val();

						    $("#future-start-date,#future-end-date").datepicker('setDate', null);

						    if (startDate == "" || (moment(today).isSame(startDate, 'day') || moment(today).isAfter(startDate,'day')) &&
                                moment(endDate).isAfter(today, 'day')) {
						        //Prefill End
						        $("#future-end-date").datepicker('setDate', endDate);
						    }

						    if (moment(startDate).isAfter(today,'day') && endDate == "") {
						        //Prefill Startd
						        $("#future-start-date").datepicker('setDate', startDate);
						    }

						    if (moment(startDate).isAfter(today,'day') && moment(endDate).isAfter(today,'day')) {
						        // Prefill Both
						        $("#future-start-date").datepicker('setDate', startDate);
						        $("#future-end-date").datepicker('setDate', endDate);
						    }

						},

						handleFutureStarEndDateToggle: function (e) {
						    var _$target = $(e.target);
						    resetDatepicker();
						    $('.future-date-toggle').removeClass('active');
						    if (_$target.hasClass('toggle-button-no')) {
						        $(".future-datepicker-ctnr").addClass("hidden");
						    } else {
						        $(".future-datepicker-ctnr").removeClass("hidden");
						    }
						    _$target.addClass('active');
						    function resetDatepicker() {
						        $("#future-start-date,#future-end-date").datepicker('setDate', null);
						    }
						}
					});
		});