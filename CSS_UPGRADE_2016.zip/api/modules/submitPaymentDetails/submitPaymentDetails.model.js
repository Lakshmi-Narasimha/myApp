// submitPaymentDetails.model.js
// grab the mongoose module
// define our submitPaymentDetails.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var submitDetailsSchema = new mongoose.Schema({
    submitObject: {
        type: Array,
        "default": []
    }
});


var submitDetails = mongoose.model('submitDetails', submitDetailsSchema);

var submitDetailsModel = new submitDetails({
    submitObject: [{
        "functionName": "Prelogin",
        "dataResponseObject": {
            "uiErrorDipslayMessage": "",
            "transactionStatus": "S",
            "transactionDescription": "",
            "transactionCode": "",
            "confirmationNumber": "16589320",
            "billingScheduledMaintenance": "N",
            "estimatedDowntime": "01:56:07"
        }
    }]
});




submitDetails.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating submitDetails table,please contact admin...');
    } else {
        submitDetails.remove({}, function(err) {
            console.log('submitDetails collection removed');
            submitDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating submitDetails table,please contact admin...');
                }
                console.log('submitDetails table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = submitDetails;
