// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SWPInvRegdModelSchema = new mongoose.Schema({
    swpRegdResp: {
        type: Array,
        "default": []
    }
});

var SWPInvRegdModelLookUp = mongoose.model('SWPInvRegdModelLookUp', SWPInvRegdModelSchema);

var SWPRegdModel = new SWPInvRegdModelLookUp({
    swpRegdResp : {
  "siSummarys":[  
      {  
         "folioId":"17024206",
         "modeofHolding":"Joint",
         "holders":{  
            "firstHoldersName":"AASHISH SADANAND NARKAR NARYAN SHANTA",
            "secondHoldersName":"Raghu krishan",
            "thirdHoldersName":"Shyam chander"
         },
         "rows":[  
            {  
              "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "txnNo":"PT13020197"
            },
            {  "status":"active",
               "accountNo":"0029903853832",
               "amount":"10,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Prima Plus - Dividend",
               "txnNo":"PT13807545"
            },
            {  "status":"active",
               "accountNo":"0029903853832",
               "amount":"10,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Prima Plus - Dividend",
               "txnNo":"PT17073457"
            },
            {  "status":"active",
               "accountNo":"0069903636631",
               "amount":"3,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Bluechip Fund - Dividend",
               "txnNo":"PT17110933"
            },
            {  "status":"active",
               "accountNo":"0069903636631",
               "amount":"1,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Bluechip Fund - Dividend",
               "txnNo":"PT17486770"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"1,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "txnNo":"PT25154493"
            },
            {  "status":"active",
               "accountNo":"0029903853832",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Prima Plus - Dividend",
               "txnNo":"PT31202882"
            },
            {  "status":"active",
               "accountNo":"0029903853832",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Prima Plus - Dividend",
               "txnNo":"PT31202884"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"7,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "txnNo":"PT39133140"
            },
            {  "status":"active",
               "accountNo":"0029903853832",
               "amount":"10,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Prima Plus - Dividend",
               "txnNo":"PT39133141"
            },
            {  "status":"active",
               "accountNo":"2189903853832",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin India Smaller Companies Fund - Dividend",
               "txnNo":"PT39133142"
            },
            {  "status":"active",
               "accountNo":"3869903853832",
               "amount":"3,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
               "sourceFund":"Franklin Build India Fund - Dividend",
               "txnNo":"PT39133143"
            }
         ]
    }
  ]
}
});

SWPInvRegdModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SWPInvRegdModelLookUp table, please contact admin...');
    } else {
        SWPInvRegdModelLookUp.remove({}, function(err) {
            console.log('SWPInvRegdModelLookUp collection removed');
            SWPRegdModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SWPInvRegdModelLookUp table, please contact admin...');
                }
                console.log('SWPInvRegdModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SWPInvRegdModelLookUp;
