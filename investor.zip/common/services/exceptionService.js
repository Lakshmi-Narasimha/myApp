
/**
 * @ngdoc service
 * @name Common ExceptionHandler
 * @requires $provide
 * @description
 *
 * - Throws the exceptions that occur in our app
 *
 */
'use strict';

function exceptionService($provide) {
    $provide.decorator('$exceptionHandler',['$delegate','fticLogger','fticLoggerMessage',
        function($delegate,fticLogger,fticLoggerMessage) {
            return function(exception, cause) {
                // delegate on the original `$exceptionHandler` i.e. $log.error()
                $delegate(exception, cause);
                // Provide logic to handle error, display error or log error to server
                fticLoggerMessage.displayLoggerMessage({level:'error', 'message': exception.message});
            };
        }
    ]);
}

exceptionService.$inject = ['$provide'];
module.exports = exceptionService;

