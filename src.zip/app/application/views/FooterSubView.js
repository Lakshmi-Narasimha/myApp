define([
    'jquery',
    'lodash',
    'app/common/views/AbstractView',
    'text!app/application/templates/footer.html'
], function ($, _, AbstractView, FooterTemplate) {

    return AbstractView.extend({
        el: '#sem-footer',
        template: _.template(FooterTemplate),
        events: {},
        render: function () {
            this.$el.html(this.template());
            $('#modal-help').on('shown.bs.modal', function () {
                $('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'top': '0', 'width': '100vw', 'padding-right': '0' });
            });
            $('#modal-help').on('hidden.bs.modal', function () {
                $('body').removeAttr('style');
            });
        },
    });

});
