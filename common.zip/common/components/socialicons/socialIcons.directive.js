/**
 * @ngdoc directive
 * @name Social Icons Directive
 * @description
 *
 * - It displays the social icons 
 *
**/

'use strict';

var fticSocialIcons = function() {
	return {
            template: require('./socialIcons.html'),
            restrict: 'E',
            replace: true,
            scope: {
                icons : "=icons",
            }
        };
};

fticSocialIcons.$inject = [];
module.exports = fticSocialIcons;