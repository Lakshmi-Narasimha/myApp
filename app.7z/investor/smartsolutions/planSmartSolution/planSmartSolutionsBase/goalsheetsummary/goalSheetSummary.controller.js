/**
 * @ngdoc property
 * @name Goal Sheet Summary Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Goal Sheet Summary controller for guest module.
 *
 **/
'use strict';
function goalSheetSummaryController($scope, $state, buildPlanInitialLoader, buildPlanModelService, investorEventConstants, recommendedPlanInitialLoader, recommendedPlanModelService, savedSmartSolutionsModel, transactModel, planSmartSolution,toaster,$uibModal,$filter, downloadService) {

    $scope.init = function () {
        
        // queryDownloadObj = {
        //     "investorData": {
        //         "trxnType": "DOWNLOAD"
        //         }
        //     };
               
        $scope.config.stepsConfig.activeStep = 3;
        var planSmartSolutionDetails = planSmartSolution.getSmartSolutionDetails(),
            title = recommendedPlanModelService.getSelectedSmartSoln() ? recommendedPlanModelService.getSelectedSmartSoln().title : null;
        $scope.goalSummary = [{
            "GoalName": title,
            "GoalAmount": planSmartSolutionDetails.investmentAmount,
            "AnnualWithdrawals": recommendedPlanModelService.getCustomizePlanData() ? recommendedPlanModelService.getCustomizePlanData().withdrawl : "",
            "AnnualStep": recommendedPlanModelService.getCustomizePlanData() ? recommendedPlanModelService.getCustomizePlanData().stepUp +"%" : "0%",
            "GoalTenor":planSmartSolutionDetails.investmentTenure+" Years"
        }];

        planSmartSolution.setGoalSummaryData($scope.goalSummary);

        $scope.investmentSummary = {
            "fundDetails": buildPlanModelService.getGoalPlanData(),
            "total": buildPlanModelService.getGoalTotalPlanData()
        };
        $scope.goalChartData = planSmartSolution.getInvestmentSimulation();
        $scope.goalSheetSaveBtn = false;
    };

    $scope.init();

    $scope.proceedToBuy = function () {
        if (buildPlanModelService.getSelectInvType() == "New Investor") {
            //smartSol.planSmartSolution.newFolioNnewInvestor
            $state.go('smartSol.planSmartSolution.newFolioNnewInvestor');
        }
        else {
            $scope.fundDtls.fundDtlsState = "smartSol.planSmartSolution.fundDetailsSS.investment";
            planSmartSolution.setFundDetailsState($scope.fundDtls.fundDtlsState);
            $state.go('smartSol.planSmartSolution.invProceedToBuy.invPBInvestmentPref');
        }

    };

    $scope.goalSummaryBackBtn = function () {
        buildPlanModelService.fromGoalSheet = (buildPlanModelService.tabname === 'buildplan');
        $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan');
    };

    $scope.savedSmartSolBtn = function () {
        if(buildPlanModelService.getSelectInvType() === "Existing Investor"){
            if (buildPlanModelService.getGoalSummaryFromState() === "smartSol.planSmartSolution.ssBase.recommendations.recommendedplan") {
                $scope.setFlag = "PR";
            }
            else {
                $scope.setFlag = "PB"
            }
            savedSmartSoln();
        }
        else if(buildPlanModelService.getSelectInvType() === "New Investor"){
            if (buildPlanModelService.getGoalSummaryFromState() === "smartSol.planSmartSolution.ssBase.recommendations.recommendedplan") {
                $scope.setFlag = "NR";
            }
            else {
                $scope.setFlag = "NB"
            }
            var modalInstance = $uibModal.open({
                    template : require('../../components/savenewinv/saveNewInvestor.html'),
                    scope : $scope
                });
            $scope.$on('saveNewInvSmartSol',function(){
                savedSmartSoln();
            });
        }       
    };
    
    function saveGoalSheet(){       
        if (recommendedPlanModelService.getRecommendedFromState() === "smartSol.planSmartSolution.ssBase.planInputDetails") {
            $scope.mode = "A";
        }
        else {
            $scope.mode = "U"
        }
        var investorData = transactModel.getInvestorDetails();
        var inputDtlsData = recommendedPlanModelService.getPlanInputDtls();
        var investmentSummaryData = buildPlanModelService.getGoalPlanData();
        var savedDate = $filter('date')(new Date(), 'd/MM/yyyy');
        
        var holdersData = [];
        angular.forEach(investorData.holders, function (holder) {
            var holderList = {};
            holderList.name = holder.name;
            holderList.type = holder.type;
            holdersData.push(holderList);
        });

        var fundsData = [];
        angular.forEach(investmentSummaryData, function (fund, ind) {
            var fundList = {};
            fundList.fund = fund.fundName;
            fundList.allocation = fund.allocation;
            fundList.monthly = fund.installmentDetails.monthly || "";
            fundList.annual = fund.installmentDetails.annually || "";
            fundList.oneTime = fund.installmentDetails.oneTime || "";
            fundList.dividendOption = fund.dividendFlag || "";
            fundList.frequency = "";
            fundList.StepUpSIP = fund.stepUpSip || "";
            fundList.funcCode = fund.fundOption || "";
            fundList.fundType = fund.fundType || "";
            fundsData.push(fundList);
        });
        var lastRow = {};
        lastRow.fund =  "Total";
        lastRow.allocation = "100%";
        lastRow.monthly = buildPlanModelService.getGoalTotalPlanData().monthly || "";
        lastRow.annual = buildPlanModelService.getGoalTotalPlanData().annually || "";
        lastRow.oneTime = buildPlanModelService.getGoalTotalPlanData().oneTime || "";
        fundsData.push(lastRow);

        var chartData = [];
        $scope.InvestmentSimulation = (planSmartSolution.getInvestmentSimulation() && planSmartSolution.getInvestmentSimulation().data) ? planSmartSolution.getInvestmentSimulation().data : {};
        angular.forEach($scope.InvestmentSimulation, function (simulation) {
            var chartList = {};
            chartList.time = simulation.years;
            chartList.amount = simulation.amount;
            chartData.push(chartList);
        });

        $scope.body = {
            "investorData": {
                "emailId" : transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().emailId : "",
                "trxnType": $scope.setFlag,
                "trxnNo": "",
                "userType": "",
                "reqstDate": ""+savedDate,
                "folioId": transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().folioId : "",
                "holdingType": transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().holdingType : "",
                "mode": $scope.mode,
                "invType": "" + planSmartSolution.getTransactType(),
                "investorType": ""+buildPlanModelService.getSelectInvType(),
                "distId": "",
                "holderDetails": holdersData
            },
            "goalSheetData": {
                "goalSummary": [{
                    "goalName": recommendedPlanModelService.getSelectedSmartSoln() ? recommendedPlanModelService.getSelectedSmartSoln().title : "",
                    "goalDescription": buildPlanModelService.getGoalDesc() ? buildPlanModelService.getGoalDesc() : "",
                    "goalAmountAot": inputDtlsData.investmentAmount ? ""+inputDtlsData.investmentAmount : "",
                    "goalAmountEog": inputDtlsData.investmentAmount ? ""+inputDtlsData.investmentAmount : "",
                    "annualWithDrawals": $scope.goalSummary[2] ? $scope.goalSummary[2].value : "",
                    "annualStepUp": $scope.goalSummary[3] ? $scope.goalSummary[3].value : "",
                    "currentAge": "" + inputDtlsData.age + " Years",
                    "goalTenor": $scope.goalSummary[4] ? $scope.goalSummary[4].value + " Years" : "",
                    "goalCompPer": "",
                    "goalAchievedTillDt": "",
                    "goalAchivedPer": "",
                    "goalTenorRemained": ""
                }],
                "topUpSummary": {
                    "goalName": "",
                    "goalDeficit": "",
                    "goalTenorRemained": ""
                },
                "investmentSummary": fundsData,
                "investmentSimulation": chartData
            }
        };
       
    };

    function savedSmartSoln(){
        saveGoalSheet();
        console.log("saved Smart solution payload",$scope.body);
        savedSmartSolutionsModel.postSavedSmartSolDtls($scope.body)
            .then(function(data){    
                     toaster.success('Family Solution Saved Successfully');
                     $scope.goalSheetSaveBtn = true;
                  },function(){
                    toaster.error('Unable to Save Family Solution');
                });
    };
    $scope.$on('goalSheetDownload',function(){
        $scope.mode = "A";
        $scope.setFlag = "download";
        saveGoalSheet();
        downloadService.setQueryparams($scope.body);
    });
    
    $scope.emailSmartsolBtn = function () {
        $scope.mode = "A";
        $scope.setFlag = "goalsheet";
        saveGoalSheet();
        savedSmartSolutionsModel.postEmailSmartSolDtls($scope.body)
            .then(function(data){
                   toaster.success('Email Investor successfull');
                  },function(){
                    toaster.error('Unable to Email Investor');
                });
    };
 
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
goalSheetSummaryController.$inject = ['$scope', '$state', 'buildPlanInitialLoader', 'buildPlanModelService', 'investorEventConstants', 'recommendedPlanInitialLoader', 'recommendedPlanModelService', 'savedSmartSolutionsModel', 'transactModel', 'planSmartSolution','toaster','$uibModal','$filter','downloadService'];
module.exports = goalSheetSummaryController;