var fticHeaderSearch = function() {
    return {
        template: require('./headerSearch.html'),
        restrict: 'EA',
        replace: true
    };
};

fticHeaderSearch.$inject = [];
module.exports = fticHeaderSearch;