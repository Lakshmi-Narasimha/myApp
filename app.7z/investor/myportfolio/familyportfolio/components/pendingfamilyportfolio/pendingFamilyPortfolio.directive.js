/**
 * @ngdoc property
 * @name fticAddRemoveFamilyPortfolio Directive
 * @requires fticLoggerMessage 
 * @requires loggerConstants 
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Family PortFolio Pending request  for Add or Remove Port folio into Family PortFolio
 *
 **/
'use strict';
var fticAddRemoveFamilyPortfolio = function(familyPortfolioInitialLoader,familyPortfolioModel,$loader,toaster) {
    return {
        template: require('./pendingFamilyPortfolio.html'),
        restrict: 'E',
        replace: true,
        scope: true,
        link: function($scope) {
		    $scope.onSubmit = function(index,pan){
		        var reqObject = {};
		        reqObject = {
		            'pan'  :  pan,
		            'userId' :  $scope.userName[index].value,
		            'status' :  'AP'
		        };
		        $loader.start();
		        familyPortfolioModel.acceptOrRejectOrRemoveFamilyPFReq(reqObject)
				.then(function(){
					$scope.userName[index].errorMessage = '';
					familyPortfolioInitialLoader._isServicesData = false;
					familyPortfolioInitialLoader.loadAllServices($scope);
				},function(error){
					//$scope.userName[index].errorMessage = 'The entered Username is incorrect, Please try again.';
					if(error && error.data && error.data.length > 0) {
						$scope.userName[index].errorMessage = error.data[0].errorDescription;
						toaster.error(error.data[0].errorDescription);
                    }
				}).finally(function(){
					$loader.stop();
				});
		    };
		    $scope.onReject = function(index,pan){
		        var reqObject = {};
		        reqObject = {
		            'pan'  : pan,
		            'userId' : $scope.userName[index].value,
		            'status' : 'RJ'
		        };
		        $loader.start();
		        familyPortfolioModel.acceptOrRejectOrRemoveFamilyPFReq(reqObject)
				.then(function(){
					$scope.userName[index].errorMessage = '';
					familyPortfolioInitialLoader._isServicesData = false;
					familyPortfolioInitialLoader.loadAllServices($scope);
				},function(error){
					//$scope.userName[index].errorMessage = 'The entered Username is incorrect, Please try again.';
					if(error && error.data && error.data.length > 0) {
						$scope.userName[index].errorMessage = error.data[0].errorDescription;
						toaster.error(error.data[0].errorDescription);
					}
				}).finally(function(){
					$loader.stop();
				});
			};
        }
    };
};
fticAddRemoveFamilyPortfolio.$inject = ['familyPortfolioInitialLoader','familyPortfolioModel','$loader','toaster'];
module.exports = fticAddRemoveFamilyPortfolio;