import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/catch';

import { AlertMessage } from '../_models/alertmessage';

@Injectable()
export class AIAssistAlertService {


  private alertMessage : AlertMessage = new AlertMessage();
  private dialogMessage : AlertMessage = new AlertMessage();

  private alertMessageObserver : Observer<any>;
  private dialogMessageOberver : Observer<any>;

  alertMessageObservable : Observable<any>;
  dialogMessageObservable : Observable<any>;

  constructor() {
    this.alertMessageObservable = new Observable(observer => this.alertMessageObserver = observer).share();
    this.dialogMessageObservable = new Observable(observer => this.dialogMessageOberver = observer).share();
  }

  clearAlertMessages() {
    let pAlertMessage : AlertMessage = new AlertMessage();
    pAlertMessage.messageType = null;
    pAlertMessage.messageInfo = "";
    this.alertMessage = pAlertMessage;

    if( this.alertMessageObserver == null || this.alertMessageObserver == undefined || this.alertMessageObservable == null || this.alertMessageObservable == undefined)
      this.alertMessageObservable = new Observable (observer => this.alertMessageObserver = observer).share();

    this.alertMessageObserver.next(pAlertMessage);
  }

  setMessage( MessageType : string, MessageInfo : string ) {

    let pAlertMessage : AlertMessage = new AlertMessage();
    pAlertMessage.messageType = MessageType;
    pAlertMessage.messageInfo = MessageInfo;
    this.alertMessage = pAlertMessage;

    if( this.alertMessageObserver == null || this.alertMessageObserver == undefined || this.alertMessageObservable == null || this.alertMessageObservable == undefined)
      this.alertMessageObservable = new Observable (observer => this.alertMessageObserver = observer).share();

    this.alertMessageObserver.next(pAlertMessage);

  }

  confirmDialog( messageTitle : string, messageInfo : string, callbackFunction : string,  callBackParam : any)  { //: Observable<void>
    let pDialogMessage : AlertMessage = new AlertMessage();
    pDialogMessage.messageTitle = messageTitle;
    pDialogMessage.messageInfo = messageInfo;
    pDialogMessage.callBackFunction = callbackFunction;
    pDialogMessage.callBackParam = callBackParam;
    this.dialogMessage = pDialogMessage;

    if( this.dialogMessageOberver == null || this.dialogMessageOberver == undefined || this.dialogMessageObservable == null || this.dialogMessageObservable == undefined)
      this.dialogMessageObservable = new Observable (observer => this.dialogMessageOberver = observer).share();

    this.dialogMessageOberver.next(pDialogMessage);

  }

}
