/**
 *@ngdoc object
 *@name 
 *@description
 * 
 * 
 */

'use strict';

module.exports = angular.module('investor.services', [])
	.factory('invFolioDetailsModel', require('./invFolioDetailsModel.service'))
	.factory('invInstantMailback',require('./invInstantMailback.service'))
	.factory('invPanLevelSummaryModel',require('./invPanLevelSummaryModel.service'))
	.factory('invPanFolioKycModel',require('./invPanFolioKycModel.service'))
	.factory('invSmartSavingsModel',require('./invSmartSavingsModel.service'))
	.factory('invSmartSavingsInitialLoader',require('./invSmartSavingsInitialLoader.service'));

