/**
 * @ngdoc property
 * @name Recommended Plan Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Customized Plan Controller for advisor smart solutions module.
 *
 **/
'use strict';
function customizedPlanController($scope, $state, recommendedPlanInitialLoader, recommendedPlanModelService, investorEventConstants, buildPlanInitialLoader, buildPlanModelService, fundDetailsModel, transactModel, planSmartSolution, recommendedFundCardModelService, $uibModal, $timeout,$window,appConfig,configUrlModel) {

    var fund = [], dividend = [];
    $scope.init = function () {
        buildPlanModelService.isFromCustomize = true;
        $scope.recommendationText = "Show another Recommendation";
        $scope.customizedData = recommendedPlanModelService.getCustomizePlanData();
        $scope.investmentType = $scope.customizedData.investmentType;
        if($scope.investmentType == "Combo") {
            buildPlanModelService.setInvestmentType($scope.investmentType);
        }
        $scope.funds = fundDetailsModel.getFundDetails();
        $scope.allocationArr = buildPlanModelService.getAllocationDetails();
        $scope.tabName = $scope.$parent.tab.tabViewName;
        $scope.fundSelectionArr = [];
        $scope.goalDetails = [];
        $scope.totalGoalDetails = {};
        var fundProductCodes = [];
        if ($scope.tabName == "buildplan") {
            buildPlanModelService.tabname = $scope.tabName;
            angular.forEach($scope.funds, function (fundDetails, ind) {
                if (fundDetails.fundName) {
                    $scope.fundSelectionArr[ind] = fundDetails.fundName;
                }
                fundProductCodes.push(fundDetails.productCode);
                fund[ind] = fundDetails;
                dividend[ind] = fundDetails.dividendFlag;
            });

            /*for (var i = 0; i < $scope.funds.length; i++) {
                if ($scope.funds[i].fundName) {
                    $scope.fundSelectionArr[i] = $scope.funds[i].fundName;
                }
                fundProductCodes.push($scope.funds[i].productCode);
                fund[i] = $scope.funds[i];
                dividend[i] = $scope.funds[i].dividendFlag;
            }*/
        }
        else {
            buildPlanModelService.tabname = $scope.tabName;
            $scope.fundSelectionArr.push(planSmartSolution.getSmartSolutionDetails().fundDetails.fundOptDesc);
            fundProductCodes.push(planSmartSolution.getSmartSolutionDetails().fundDetails.productCode);
            dividend[0] = "G";
        }
        fundCardModal(fundProductCodes.join(","));
        $scope.isCustomize = ($scope.investmentType == "Combo");

        loadPlanDetails();
    };

    $scope.init();

    if ($scope.investmentType != "Combo") {
        $scope.$on("investmentType", function ($event, data) {
            buildPlanModelService.setInvestmentType(data);
        });
    }

    $scope.toggleRecommendataions = function () {
        var planInputObj = {};
        planInputObj = planSmartSolution.plainputObj;
        $scope.recommendationText == "Show another Recommendation" ? (planInputObj.fundRecom = "A", $scope.recommendationText = "Show Original Recommendation") : (planInputObj.fundRecom = "O", $scope.recommendationText = "Show another Recommendation");
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
            $scope.isToggle = true;
            planSmartSolution.setSmartSolutionDetails(data);
            loadPlanDetails();
        }, function (data) {
            console.log("Error")
        });
    };
    $scope.$on("investmentValue", function ($event, data) {
        $scope.radioSelectedData = buildPlanModelService.setInvestmentValue(data);
        $scope.getFundDetails();
    });

    $scope.getFundDetails = function () {
        $scope.investmentType = buildPlanModelService.getInvestmentType();
        $scope.investmentValue = buildPlanModelService.getInvestmentValue();

        $scope.instalMentDtls = {
            monthly: "",
            annually: "",
            oneTime: ""
        };

        if ($scope.investmentType == "Monthly" || $scope.investmentType == "Annually") {
            planSmartSolution.setTransactType("SIP");
        }
        else if ($scope.investmentType == "One time") {
            planSmartSolution.setTransactType("Lumpsum");
        }
        else {
            planSmartSolution.setTransactType("Combo");
        }

        $scope.totalAllocation = 0;
        $scope.totalMonthly = null;
        $scope.totalAnnually = null;
        $scope.totalOneTime = null;

        for (var i = 0; i < $scope.fundSelectionArr.length; i++) {

            if ($scope.tabName == "buildplan") {
                $scope.fundAllocation = $scope.allocationArr[i];
                $scope.totalAllocation += $scope.allocationArr[i];
            }
            else {
                $scope.fundAllocation = "100%";
                $scope.totalAllocation = "100%";
                $scope.allocationArr = [];
                $scope.allocationArr[i] = 100;
            }
            loadInvestmentOptions(i);
            if($scope.tabName == 'buildplan') {
                $scope.goalDetails.push({
                    "fundName": $scope.fundSelectionArr[i], "allocation": $scope.fundAllocation,
                    "installmentDetails": $scope.instalMentDtls,
                    "dividendFlag": dividend[i],
                    "fund" : fund[i],
                    "nfoFlag" : fund[i].nfoFlag || '',
                    "fundType": fund[i].fundType || '',
                    "fundOption" : fund[i].fundOption || 'NA',
                    "accNo" : fund[i].fundType == "N" ? "NEW" : 'NEW',
                    "perpetualFlag" : 'N' || '',//fund[i].perpetualFlag
                    "stepUpFrequency": fund[i].stepUpFrequency || '',
                    "stepUpType" : fund[i].stepUpType || '',
                    "stepUpValue" : fund[i].stepUpValue || '',
                    "stepUpSip" : $scope.customizedData.stepUp || 0
                });
            }
            else {
                var smartSolnDetails = planSmartSolution.getSmartSolutionDetails();
                $scope.goalDetails.push({
                "fundName": $scope.fundSelectionArr[i], "allocation": $scope.fundAllocation,
                "installmentDetails": $scope.instalMentDtls,
                "dividendFlag": dividend[i],
                "fund" : '',
                "nfoFlag" : smartSolnDetails.fundDetails.nfoFlag || 'N',
                "fundType": smartSolnDetails.fundDetails.fundType || '',
                "fundOption" : smartSolnDetails.rtCode || '',
                "accNo" : smartSolnDetails.fundDetails.fundType == "N" ? "NEW" : 'NEW',
                "perpetualFlag" : 'N' || '',//smartSolnDetails.perpetualFlag
                "stepUpFrequency": smartSolnDetails.fundDetails.stepUpFrequency || '',
                "stepUpType" : smartSolnDetails.fundDetails.stepUpType || '',
                "stepUpValue" : smartSolnDetails.fundDetails.stepUpValue || '',
                "stepUpSip" : $scope.customizedData.stepUp || 0
            });
            }
            

            //
        }
        $scope.totalGoalDetails["allocation"] = "100%";
        $scope.totalGoalDetails["monthly"] = $scope.totalMonthly;
        $scope.totalGoalDetails["annually"] = $scope.totalAnnually;
        $scope.totalGoalDetails["oneTime"] = $scope.totalOneTime;
    };

    $scope.goalsheetBtn = function () {
        buildPlanModelService.setGoalPlanData($scope.goalDetails);
        buildPlanModelService.setGoalTotalPlanData($scope.totalGoalDetails);
        $state.go('smartSol.planSmartSolution.ssBase.goalSheetSummary');
    };

    $scope.customizeBtn = function () {
        //$state.go('smartsolutions.planSmartSolution.recommendations.recommendedplan.customizePlan');
        if($state.current.name == "smartSol.planSmartSolution.ssBase.recommendations.buildplan.bmycustomizeplan") {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.buildplan.bcustomizeplan');
        }
        else {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rcustomizePlan');
        }
    };

    $scope.$on(investorEventConstants.smartSolutions.RECOMMENDED_PLAN, function ($event) {
        $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
        $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
    });

    $scope.toggleRecommendataions = function () {
        var planInputObj = {};
        planInputObj = planSmartSolution.plainputObj;
        planInputObj.investmentAmount = planSmartSolution.replaceComma(planInputObj.investmentAmount);
        $scope.recommendationText == "Show another Recommendation" ? (planInputObj.fundRecom = "A", $scope.recommendationText = "Show Original Recommendation") : (planInputObj.fundRecom = "O", $scope.recommendationText = "Show another Recommendation");
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
            $scope.isToggle = true;
            planSmartSolution.setSmartSolutionDetails(data);
            fundCardModal(planSmartSolution.getSmartSolutionDetails().fundDetails.productCode);
            loadPlanDetails();
            $timeout(function () {
                $scope.goalChartData.data = null;
                $scope.fundCardDetails = null;
            }, 0);

        }, function (data) {
            console.log("Error")
        });
    };

    function loadPlanDetails () {
        $scope.smartSolnDetials = angular.copy(planSmartSolution.getSmartSolutionDetails());
        $scope.recommendationDetails = {};
        $scope.fundName = "";
        $timeout(function () {
            $scope.recommendationDetails = {
                "installmentDetails": [{
                    text: 'Monthly',
                    value: $scope.smartSolnDetials.monthlySIP
                },
                    {
                        text: 'Annually',
                        value: $scope.smartSolnDetials.annualSIP
                    },
                    {
                        text: 'One time',
                        value: $scope.smartSolnDetials.lumpsum
                    }],
                "details": {
                    "investmentTenure": planSmartSolution.getSmartSolutionDetails().revisedYears,
                    "investmentAmount": planSmartSolution.getSmartSolutionDetails().investmentAmount
                }
            };

            $scope.fundName = planSmartSolution.getSmartSolutionDetails().fundDetails ? planSmartSolution.getSmartSolutionDetails().fundDetails.fundOptDesc : "";

        }, 0);


        //$scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
        $scope.goalChartData = planSmartSolution.getInvestmentSimulation();
    }

    function loadInvestmentOptions (ind) {

        if ($scope.investmentType == "Monthly") {
            $scope.instalMentDtls.monthly = Math.round((planSmartSolution.replaceComma($scope.customizedData.monthly) * $scope.allocationArr[ind])/100);
            $scope.totalMonthly += parseInt($scope.instalMentDtls.monthly);
        }
        if ($scope.investmentType == "Annually") {
            $scope.instalMentDtls.annually =  Math.round((planSmartSolution.replaceComma($scope.customizedData.annually) * $scope.allocationArr[ind])/100);
            $scope.totalAnnually += parseInt($scope.instalMentDtls.annually);
        }
        if ($scope.investmentType == "One time") {
            $scope.instalMentDtls.oneTime = Math.round((planSmartSolution.replaceComma($scope.customizedData.onetime) * $scope.allocationArr[ind])/100);
            $scope.totalOneTime += parseInt($scope.instalMentDtls.oneTime);
        }
        if ($scope.investmentType == "Combo") {
            $scope.instalMentDtls.monthly = Math.round((planSmartSolution.replaceComma($scope.customizedData.monthly) * $scope.allocationArr[ind])/100);
            $scope.totalMonthly += parseInt($scope.instalMentDtls.monthly);
            $scope.instalMentDtls.annually = Math.round((planSmartSolution.replaceComma($scope.customizedData.annually) * $scope.allocationArr[ind])/100);
            $scope.totalAnnually += parseInt($scope.instalMentDtls.annually);
            $scope.instalMentDtls.oneTime = Math.round((planSmartSolution.replaceComma($scope.customizedData.onetime) * $scope.allocationArr[ind])/100);
            $scope.totalOneTime += parseInt($scope.instalMentDtls.oneTime);
        }

    };

    function getSmartSolutionDetails (planInputObj, source) {
        //console.log(JSON.stringify(planInputObj));
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, '', true).then(function (data) {
            planSmartSolution.setSmartSolutionDetails(data);
            loadPlanDetails();
        }, function (data) {
            console.log("Error")
        })
    };

    function fundCardModal(fundCode) {
        recommendedFundCardModelService.fetchRecommendedFundCard(fundCode).then(function (data) {
            console.log(data);
            $scope.fundCardDetails = data.fundDetails;
        }, function () {

        });
    };

    var modalInstance;
    $scope.$on('openFundCardModelPlan', function (event, fundCodes) {
        recommendedFundCardModelService.setFundCardId(fundCodes);
        // modalInstance = $uibModal.open({
        //     template: require('../../../../../../common/components/smartSolFundCardModelDetails/smartSolFundCardModel.html'),
        //     scope: $scope
        // });
    $window.open(
          appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/funds-and-solutions/funds-explorer/fund-overview?FundID='+fundCodes,
          '_blank');
    });


    $scope.$on("editFundCustimizeBackState", function ($event, data) {
        buildPlanModelService.isFromModify = true;
        buildPlanModelService.isFromCustomize = true;
        $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan");
    });

}

customizedPlanController.$inject = ['$scope', '$state', 'recommendedPlanInitialLoader', 'recommendedPlanModelService', 'investorEventConstants', 'buildPlanInitialLoader', 'buildPlanModelService', 'fundDetailsModel', 'transactModel', 'planSmartSolution', 'recommendedFundCardModelService', '$uibModal', '$timeout','$window','appConfig','configUrlModel'];
module.exports = customizedPlanController;