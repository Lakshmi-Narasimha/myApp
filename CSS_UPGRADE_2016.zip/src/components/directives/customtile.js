var componentModule = angular.module('component.tile', []);
componentModule.directive('tileElement', ['$compile', '$window', '$state', 'imagesDefaultConstant', function($compile, $window, $state, imagesDefaultConstant) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            cancelclickable: '=',
            content: '=',
            type: '@',
            agentslist: '=',
            elementid: '=',
            elementindex: '@',
            elementidchange: "@",
            parentdata: '=',
            parenttype: '=',
            enrolltype: '=',
            page: '=',
            textimagetoggle: '=',
            usereligibility: '=',
            billingmaintenance: '='
        },
        templateUrl: $window.UIC.sitePrefix + 'components/partials/tile.html',
        link: function(scope, element, attr) {
            scope.siteprefix = (window.sitePrefix)? window.sitePrefix: "";
            if((scope.type === 'esignpolicy' && !scope.content.packageInfo) || (scope.type === 'esign' && scope.content.completed)){
                angular.element(element).parent().addClass('pkg-complete');
            }
            scope.policydetails = false;
            if (scope.page === "policydetails" || scope.page === "policydocs" || $state.current.name === "policySummary") {
                scope.cancelledtext = "This policy is cancelled";
                scope.policydetails = true;
            } else {
                scope.cancelledtext = "Cancelled";
            }
            scope.content.policyType = angular.lowercase(scope.content.policyType);
            scope.content.LOBType = angular.lowercase(scope.content.lineOfBusiness);
            
            scope.path = imagesDefaultConstant.imagepathPolicy[scope.content.lineOfBusiness] ;

            if (scope.elementidchange) {
                scope.tileElementId = scope.elementid + "-" + scope.elementindex;
            } else {
                scope.tileElementId = attr.elementid + "-" + scope.elementindex;
            }

            scope.tileClass = function() {

                var className = " content  policy-tile-content ";

                scope.isCancelledpolicy = false;
                if (scope.content.policyStatus && scope.content.policyStatus !== scope.policystatusactive) {
                    className += " cancel ";
                    scope.isCancelledpolicy = true;
                }

                if (angular.lowercase(scope.parenttype) === "policydetailtype" && scope.elementindex === "0") {

                    if (scope.content.policyClickable === false) {
                        className += " ";
                        $('.policy-tile-content').parents('.slick-slide').removeClass('policy-active');
                    } else {
                        
                        className += " active ";
                        $('.policy-tile-content.active').parents('.slick-active').addClass('policy-active');
                    }

                }

                if (angular.lowercase(scope.type) === "policytype") {
                    className += " policy-tile ";

                    if (!scope.isCancelledpolicy) {
                        className += "non-cancel ";
                    }

                }

                if (angular.lowercase(scope.type) === "vehicletype") {
                    className += " vehicle-tile ";
                } else {
                    scope.content.subjectOfInsurance = scope.content.subjectOfInsurance || [];
                    if (scope.content.lineOfBusiness === "AUTO" && scope.content.subjectOfInsurance.length > 1) {

                        className += "multi-tile ";
                    } else {

                        className += "single-tile ";
                    }

                }

                if (angular.lowercase(scope.type) === "agentinfo") {
                    className += " managed-policy-tiles ";
                }


                return className;
            };

            scope.expand = function(event) {
                event.preventDefault();
                event.stopImmediatePropagation();

                var expandElement,
                    allPolicySlides = angular.element(".policy-slide"),
                    positionElement, placeElementFlag = false;

                if (event.type) {
                    expandElement = angular.element(event.currentTarget);
                } else {
                    expandElement = angular.element(event);
                }

                if (angular.element(event.currentTarget).hasClass("active") && event.type && !event.isTrigger) {

                    angular.element(".expand-policy-tile").stop().slideToggle("slow", function() {
                        allPolicySlides.removeClass("active");
                        angular.element(".expand-policy-tile").remove();
                    });


                    return false;
                }


                allPolicySlides.removeClass("active");


                angular.element(".expand-policy-tile").remove();

                positionElement = _.find(allPolicySlides, function(element, index) {

                    if (angular.element(element).position().top > expandElement.position().top) {

                        placeElementFlag = true;

                        return element;

                    } else if (angular.element(element).position().top === expandElement.position().top && allPolicySlides.length - 1 === index) {

                        return element;
                    }


                });

                expandElement.addClass("active");

                if (placeElementFlag) {

                    $($compile('<div policy-expand></div>')(scope)).insertBefore(angular.element(positionElement));
                } else {

                    $($compile('<div policy-expand></div>')(scope)).insertAfter(angular.element(positionElement));
                }

            };

            if (angular.lowercase(scope.type) === "policytype" || angular.lowercase(scope.type) === "esign" || angular.lowercase(scope.type) === "esignpolicy") {
                if (scope.content.LOBType !== "life") {
                    if((scope.type === 'esignpolicy' && !scope.content.packageInfo) || (scope.type === 'esign' && scope.content.completed)){
                        return;
                    }
                    element.parent().bind('click', scope.expand);
                }

            }


            scope.expandDetail = function(elementSlickIndex, clickedContent) {
                var elementSlick = _.find(angular.element(".policy-detail-head-carousel .slick-slide"), function(element, index) {
                    if (elementSlickIndex === angular.element(element).attr("data-slick-index")) {
                        return element;

                    }
                });

                if (angular.element(elementSlick).find(".policy-tile-content").attr("elementindex") === scope.elementindex) {
                    scope.$apply(function() {
                        if (scope.cancelclickable !== undefined) {
                            if (!scope.cancelclickable && scope.isCancelledpolicy) {
                                return;
                            }
                        }

                        scope.$emit('policy-tile-clicked', scope.content, clickedContent);

                        if (scope.content.policyClickable === false) {
                            return;
                        }
                        if (!scope.content.additionalTile) {
                            angular.element(".policy-detail-head-carousel .slick-slide .policy-tile-content").removeClass("active");
                            angular.element(elementSlick).find(".policy-tile-content").addClass("active");
                            //707230 Fixed
                            if(angular.element(".policy-detail-head-carousel .slick-slide .policy-tile-content.active").length){
                                var indexVal = angular.element(".policy-detail-head-carousel .slick-slide .policy-tile-content.active").attr('elementindex');
                                angular.element(".additional-dots .slick-active").removeClass("slick-active");
                                angular.element(".additional-dots li").eq(indexVal).addClass("slick-active");
                            }
                        }
                    });
                }
            };

            scope.contentType = (scope.content.lineOfBusiness) ? angular.copy(scope.content.lineOfBusiness) : (scope.content.vehicleID) ? "AUTO" : ""; // this for swtich condition

            scope.tiletype = function(typeElement) {
                var tileFlag = false;
                if (angular.lowercase(scope.type) === "vehicletype" && angular.lowercase(scope.contentType) === "auto") {
                    tileFlag = true;
                    scope.tileflag = "AUTO";
                    scope.policyName = angular.lowercase(scope.tileflag);
                    scope.content.vehicleYear = angular.lowercase(scope.content.vehicleYear);
                    scope.content.vehicleModel = angular.lowercase(scope.content.vehicleModel);
                    scope.content.vehicleVIN = angular.lowercase(scope.content.vehicleVIN);
                }

                return tileFlag;
            };
        }

    };
}]);
