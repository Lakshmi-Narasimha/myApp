// userEmailIds.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var frequencySchema = new mongoose.Schema({
    frequencyObject: {
        type: Array,
        "default": {}
    }
});

var frequencyLookUp = mongoose.model('frequencyLookUp', frequencySchema);

var frequencyModel = new frequencyLookUp({

  "frequencyObject": {
      "frequencyOptions": ["Monthly", "Quaterly", "Annually"]
    }
});

frequencyLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating frequencyLookUp table, please contact admin...');
    } else {
        frequencyLookUp.remove({}, function(err) {
            console.log('frequencyLookUp collection removed');
            frequencyModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating frequencyLookUp table, please contact admin...');
                }
                console.log('frequencyLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = frequencyLookUp;
