'use strict';

var notification = function($state,fticRecommAndNotifiModel,constants,$filter,$window,eventConstants, $cookies) {
	return {
            template: require('./notification.html'),
            restrict: 'E',
            replace: true,
            scope: {                
                
            },
            controller: function($scope, $element, $attrs){   
                $scope.notificationToDisplay = [];
                    $scope.$on(eventConstants.RECOMM_AND_NOTIFI_DATA,function(event,data){
                        $scope.recommandNotifiData = fticRecommAndNotifiModel.getRecommAndNotifiReport();

                        $scope.notifications = $scope.recommandNotifiData.notifications;
                            /*angular.forEach($scope.notifications,function(obj){
                        if(obj.readStatus == "N"){
                            $scope.notificationToDisplay.push(obj);
                        }

                        });*/
                        if($scope.notifications) {
                            $scope.notificationsCount = $scope.notifications.length;
                        }
                        
                    });
                    var redirectAdvisorApp = $cookies.get("userRedirectURI");
                    $scope.allNotifications = function(){
                    // $state.go('notificationsreport');
                    $window.location.href=redirectAdvisorApp+"/#/notificationsreport";
                    $scope.closePop=false;
                    }
                    $scope.notificationClick = function(index){
                        // $state.go('notificationsreport');
                        $window.location.href=redirectAdvisorApp+"/#/notificationsreport";
                        $scope.closePop=false;
                        //$scope.$emit($filter('translate')(constants.NOTIFI_CLICKED_TEXT),$scope.notifications[x]);
                    }
              
            },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};


notification.$inject = ['$state','fticRecommAndNotifiModel','constants','$filter','$window','eventConstants', '$cookies'];
module.exports = notification;