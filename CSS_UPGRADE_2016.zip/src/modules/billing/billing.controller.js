(function() {
    'use strict';

    angular
        .module('CSS.billing')
        .controller('billingCtrl', ['$rootScope',billingCtrl]);

    function billingCtrl($rootScope) {
        var billingVM = this;
        $rootScope.bgcolor=true;
    }

})();
