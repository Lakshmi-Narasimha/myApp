coa = coa || {};
define(['jquery', 'underscore', 'backbone','backboneRelational'], function($, _, Backbone,backboneRelational) {
	coa.models.Address = Backbone.RelationalModel.extend({

	});
	coa.Address = new coa.models.Address();
});
