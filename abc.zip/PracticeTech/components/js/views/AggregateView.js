﻿define(['jquery', 'underscore', 'backbone'
], function ($, _, Backbone) {
	var AggregateView = Backbone.View.extend({
		nestedViews: null,
		initialize: function (options) {
			this.nestedViews = {};
		},
		removeFromDom: function () {
			if (this.beforeRemoveFromDom) {
				this.beforeRemoveFromDom();
			}
			this.clearNestedViews();
			this.undelegateEvents();
			this.$el.empty();
			this.stopListening();
		},
		addNestedView: function (name, view) {
			this.removeNestedView(name);
			this.nestedViews[name] = view;
		},
		removeNestedView: function (name) {
			if (this.nestedViews[name]) {
				this.nestedViews[name].removeFromDom();
				delete this.nestedViews[name];
			}
		},
		getNestedView: function (name) {
			return this.nestedViews[name];
		},
		clearNestedViews: function () {
			for (var viewName in this.nestedViews) {
				this.removeNestedView(viewName);
			}
		}
	});
	return AggregateView;
});
