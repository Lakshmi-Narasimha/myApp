// redeemDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var BuySISchema = new mongoose.Schema({
    BuySIResp: {
        type: Array,
        "default": []
    }
});

var BuySIModelLookUp = mongoose.model('BuySIModelLookUp', BuySISchema);

var BuySIModel = new BuySIModelLookUp({
    BuySIResp : {
        'buy' : {
            'selectedInvestor': [
                {
                    'firstHolder' : 'Shankara Narayanan',
                    'kyc' : 'Not Registered',
                    'pan' :'AMRPB446B'
                }
            ]
        }
    }
});

BuySIModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating BuySIModelLookUp table, please contact admin...');
    } else {
        BuySIModelLookUp.remove({}, function(err) {
            console.log('BuySIModelLookUp collection removed');
            BuySIModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating BuySIModelLookUp table, please contact admin...');
                }
                console.log('BuySIModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = BuySIModelLookUp;