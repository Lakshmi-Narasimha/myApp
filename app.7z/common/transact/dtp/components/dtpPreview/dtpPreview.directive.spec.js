'use strict';
describe('Directive: dtpDividendForm', function() {
	var compile,scope,$rootScope,directiveElement,isolatedScope,$window,dtpModel;

	var existingFundSelectedObject = {
        "accNo": "0060007818365",
        "amount": "800",
        "direct": null,
        "dividendFlag": "R",
        "endDate": "4 aug 2020",
        "frequency": "monthly",
        "fundCategory": "EQUITY",
        "fundOptDesc": "Franklin India BLUECHIP FUND",
        "fundOption": "006",
        "fundType": "E",
        "minAddPurAmt": "1000",
        "minNewPurAmt": "5000",
        "minSipAmt": "1",
        "multiples": "1",
        "nfoFlag": "N",
        "payoutFlag": "N",
        "reinvestmentFlag": "N",
        "startDate": "12 apr 2014",
        "stepUpType": "",
        "nextInstlDate": "5 sep 2016",
        "nextAnnualDate": "12 apr 2017",
        "stepUpValue": "NA",
        "leadDays": "15",
        "paymentDet":{
        	"payModeEmand": "false",
	        "eMandateType":"",
	        "eMandateVal": "",
	        "eMandateExpiryDate": "" 
		}		       
	};

	var dtpObjectWithReInvestmentDividendType = {
		"destinationFund" : existingFundSelectedObject,
        "switchType" : "Re-Investment",
        "type": ""
	};

	beforeEach(angular.mock.module('advisor'));	
	beforeEach(angular.mock.module('investor.transact'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-dtp-review></ftic-dtp-review>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function(_$rootScope_,_$compile_,$window,_dtpModel_) {            
            compile = _$compile_;
            scope = _$rootScope_.$new();    

            $window = $window;
            $window.ga = function() {};
        	
        	dtpModel = _dtpModel_;
        	dtpModel.setDataObj(dtpObjectWithReInvestmentDividendType);
        	dtpModel.setType("Re-Investment");
        	directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();    
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variable dtpDividendobj on load of directive',function(){
    	expect(isolatedScope.dtpDividendobj[0].text).toBe("Destination Fund");
    	expect(isolatedScope.dtpDividendobj[1].text).toBe("Dividend Option");
    	expect(isolatedScope.dtpDividendobj[0].value).toBe("Franklin India BLUECHIP FUND");
    	expect(isolatedScope.dtpDividendobj[1].value).toBe("Re-Investment");
    });    
});	