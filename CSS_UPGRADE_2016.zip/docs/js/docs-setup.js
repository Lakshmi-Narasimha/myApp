NG_DOCS={
  "sections": {
    "api": "API Documentation"
  },
  "pages": [
    {
      "section": "api",
      "id": "Billing MakePayment",
      "shortName": "Billing MakePayment",
      "type": "property",
      "moduleName": "Billing MakePayment",
      "shortDescription": "-This is Makepayment controller in Billing module.",
      "keywords": "$rootscope api billing controller makepayment module property sendemailservice submitpaymentdetailsservice"
    },
    {
      "section": "api",
      "id": "common",
      "shortName": "common",
      "type": "property",
      "moduleName": "common",
      "shortDescription": "-This is a sample comment for ngdoc",
      "keywords": "$scope api comment common ngdoc property sample"
    },
    {
      "section": "api",
      "id": "Common Service",
      "shortName": "Common Service",
      "type": "service",
      "moduleName": "Common Service",
      "shortDescription": "",
      "keywords": "api common details getpaymentdetailssevice json method payment service"
    },
    {
      "section": "api",
      "id": "Common Service",
      "shortName": "Common Service",
      "type": "service",
      "moduleName": "Common Service",
      "shortDescription": "",
      "keywords": "api common details email json method send sendemailservice service"
    },
    {
      "section": "api",
      "id": "Common Service",
      "shortName": "Common Service",
      "type": "service",
      "moduleName": "Common Service",
      "shortDescription": "",
      "keywords": "api common details json method payment service submit submitpaymentdetailsservice"
    },
    {
      "section": "api",
      "id": "component.AddEditPayment",
      "shortName": "component.AddEditPayment",
      "type": "object",
      "moduleName": "component",
      "shortDescription": "",
      "keywords": "addeditpayment api component detectcardcategoryfilter item level main module object payment time"
    },
    {
      "section": "api",
      "id": "component.sendemail",
      "shortName": "component.sendemail",
      "type": "object",
      "moduleName": "component",
      "shortDescription": "",
      "keywords": "api component email final item level module object payment send sendemail sendemailservice time"
    },
    {
      "section": "api",
      "id": "getPaymentDetailsSevice",
      "shortName": "getPaymentDetailsSevice",
      "type": "service",
      "moduleName": "getPaymentDetailsSevice",
      "shortDescription": "",
      "keywords": "api getpaymentdetailssevice json method paymentdetails service"
    },
    {
      "section": "api",
      "id": "sendEmailService",
      "shortName": "sendEmailService",
      "type": "service",
      "moduleName": "sendEmailService",
      "shortDescription": "",
      "keywords": "api emailservice json method sendemailservice service"
    },
    {
      "section": "api",
      "id": "submitPaymentDetailsService",
      "shortName": "submitPaymentDetailsService",
      "type": "service",
      "moduleName": "submitPaymentDetailsService",
      "shortDescription": "",
      "keywords": "api json method service submitpaymentdetails submitpaymentdetailsservice"
    }
  ],
  "apis": {
    "api": true
  },
  "html5Mode": false,
  "editExample": true,
  "startPage": "/api",
  "scripts": [
    "angular.min.js",
    "angular-route.min.js",
    "jquery.js",
    "fcss.js"
  ]
};