
'use strict';
function smartSolsTopupWithSFCtrl($scope, $state,recommendedPlanInitialLoader,recommendedPlanModelService,advisorEventConstants, overviewModel) {
  $scope.topUpWithSF = true;
  $scope.config = {};
  $scope.config.stepsConfig = {};
  $scope.config.stepsConfig.activeStep = 1;
  $scope.config.stepsConfig.noOfSteps = 2;
  $scope.config.stepIndImgs = [
     {
            key : "01",
            iconClass : 'icon-fti-recommend',
            label : "Recommendations"
        }, {
            key : '02',
            iconClass : 'icon-fti-goal',
            label : "Goal Sheet / Summary"
        }
        ];
  $scope.keyValueList = overviewModel.getHolderInformation();

  $scope.$on('topUpOptionsection',function(){
    $scope.topUpWithSF = false;
  });
  $scope.$on('invEditIcon',function(){
    $scope.topUpWithSF = false;
  });
  /*[{key:"First Holder",value:"Shankar Narayanan"},
                      {key:"Second Holder",value:"Shyama Shankar"},
                      {key:"Third Holder",value:"Anil Narayanan"},
                      {key:"Folio.No.",value:"4563152-FS"},
                      {key:"Mode Of Holding",value:"Joint"}
                      ];*/


  $scope.goBack=function(){
    $state.go('smartSol.investor.cp');
  }
}

smartSolsTopupWithSFCtrl.$inject = ['$scope', '$state','recommendedPlanInitialLoader','recommendedPlanModelService','advisorEventConstants', 'overviewModel'];
module.exports = smartSolsTopupWithSFCtrl;