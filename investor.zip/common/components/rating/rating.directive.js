/**
 * @ngdoc directive
 * @name rating
 * @description
 *
 * - rating component will display the no of stars and rating.
 * 
 *
 **/
 'use strict';

var rating = function() {

	return {
            template: require('./rating.html'),
            restrict: 'E',
            replace: true,
            scope: {  
                noOfStars: "@",
                rating: "@"
            },
            controller: function($scope, $element, $attrs){
                $scope.noOfStarsArray = [];
                for(var i=1;i<=$scope.noOfStars;i++){
                    $scope.noOfStarsArray.push(i);
                }
                console.log($scope.noOfStarsArray);
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

rating.$inject = [];
module.exports = rating;