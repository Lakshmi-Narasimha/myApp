/**
 * @ngdoc directive
 * @name badge
 * @description
 *
 * - It displays a badge icon with the count on top which need to be passed while declaring this directive.
 * 
**/

'use strict';

var iconCount = function(){
	return {
		template : require('./badge.html'),
		restrict : 'E',
		scope : {
			iconClass:'=',
			count:'='
		}
	}
}

iconCount.$inject = [];

module.exports = iconCount;


