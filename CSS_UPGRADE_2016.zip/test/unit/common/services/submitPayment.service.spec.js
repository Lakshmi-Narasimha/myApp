(function() {

    'use strict';

    describe('submit Payment Details service', function() {
        var resultData, timeout, $httpBackend, service;

        var successCallback = function(data) {
            resultData = data;
        };

        var errorObj = {
            'errorMessageCode': 500,
            'transactionStatus': 'Error',
            'errorDescription': 'Something went wrong...',
        };

        var submitObject = [{
            "functionName": "Prelogin",
            "dataResponseObject": {
                "uiErrorDipslayMessage": "",
                "transactionStatus": "S",
                "transactionDescription": "",
                "transactionCode": "",
                "confirmationNumber": "16589320",
                "billingScheduledMaintenance": "N",
                "estimatedDowntime": "01:56:07"
            }
        }]

        beforeEach(module('CSS.common'));

        beforeEach(inject(function(submitPaymentDetailsService, $timeout, $injector) {
            service = submitPaymentDetailsService;
            timeout = $timeout;
            $httpBackend = $injector.get('$httpBackend');
        }));

        it('service should be defined...', function() {
            expect(service).toBeDefined();
        });

        it('should submitPaymentDetails service to be called, then should respond with success object ...', function() {
            var obj = {
                functionName: null,
                dataResponseObject: {}
            };

            $httpBackend.expectPOST('http://localhost:9900/submitPaymentDetails/submitPaymentDetails', obj.functionName).respond(submitObject);
            service.submitPaymentDetails(obj.functionName).then(function(data) {
                expect(data.transactionStatus).not.toEqual("E");
            });
            timeout.flush();
            $httpBackend.flush();
        });

        it('should submitPaymentDetails service to be called, then should respond with with failure object ...', function() {
            var obj = {
                functionName: null,
                dataResponseObject: {}
            };

            var errorCallback = function(data) {
                expect(data.transactionStatus).toBe('Error');
            };

            $httpBackend.expectPOST('http://localhost:9900/submitPaymentDetails/submitPaymentDetails', obj.functionName).respond(404, errorObj);
            service.submitPaymentDetails(obj.functionName).then(successCallback, errorCallback);

            timeout.flush();
            $httpBackend.flush();
        });

    });

})();
