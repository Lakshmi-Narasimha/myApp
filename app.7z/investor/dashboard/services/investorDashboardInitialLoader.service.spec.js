'use strict';
describe('Services: investor dashboard initial loader service', function() {

    var mockInvestorDashboardInitialServices, investorDashboardDetailsModelData, getDashboardDetailsDeferred, httpBackend, Restangular, $window;

    beforeEach(angular.mock.module('investor'));
    beforeEach(inject(function(_investorDashboardInitialServices_, _investorDashboardDetailsModel_, $injector, _$httpBackend_, _Restangular_) {
        mockInvestorDashboardInitialServices = _investorDashboardInitialServices_;
        investorDashboardDetailsModelData = _investorDashboardDetailsModel_;
        var $q = $injector.get('$q');
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
    }));

    it('should loadAllServices to be defined', function() {
        expect(mockInvestorDashboardInitialServices.loadAllServices).toBeDefined();
    });

    describe('Services: investor dashboard initial loader service and check for success', function() {
        beforeEach(inject(function(_investorDashboardInitialServices_, _investorDashboardDetailsModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
            mockInvestorDashboardInitialServices = _investorDashboardInitialServices_;
            investorDashboardDetailsModelData = _investorDashboardDetailsModel_;
            var $q = $injector.get('$q');
            httpBackend = _$httpBackend_;
            Restangular = _Restangular_;

            // spyOn(investorDashboardDetailsModelData, 'getDashboardDetails').and.callFake(function() {
            //     getDashboardDetailsDeferred = $q.defer();
            //     getDashboardDetailsDeferred.resolve({
            //         investorDashboardObject: [{
            //             'profileDetails': {
            //                 'pan': 'DRCQR7575C'
            //             }
            //         }]
            //     });
            //     return getDashboardDetailsDeferred.promise;
            // });

            httpBackend.expectGET('http://localhost:3030/dashboard/investorDashboard?guId=').respond({
                'investorDashboardObject': {
                    'profileDetails': {
                        'pan': 'DRCQR7575C'
                    }
                }
            });
            httpBackend.expectGET('http://localhost:3030/dashboard/investorSmartSolGoals?guId=').respond({
                'smartSavingsAccount': {
                    'currentValue': '5120'
                }
            });
            httpBackend.expectGET('http://localhost:3030/dashboard/investorSmartSavings?guId=').respond({
                    'smartSolutionGoals': [{
                        'goalId': 'G1234',
                        'goalName': 'Wealth Creation',
                        'investment': '75,000.87',
                        'targetAmount': '2,16,000 ',
                        'achievedAmount': '1,25,876.90',
                        'pendingTimeFrame': '32',
                        'encourageText': 'Great start!',
                        'achieved': '15.07%'
                    }]
            });
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should loadAllServices to be defined and load Services dashboard, Smart SavAcc And OneTouch Details and smart Solutions to be success', function() {
            mockInvestorDashboardInitialServices.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            });
            httpBackend.flush();
            expect(investorDashboardDetailsModelData.getDashboardData().profileDetails.pan).toEqual('DRCQR7575C');
            expect(investorDashboardDetailsModelData.getSmartSolutions().smartSavingsAccount.currentValue).toEqual('5120');
            expect(investorDashboardDetailsModelData.getSmartSaveAccAndOneTouchData().smartSolutionGoals.length).toEqual(1);
        });
    });

    describe('Services: investor dashboard initial loader service and check for failure', function() {
        beforeEach(inject(function(_investorDashboardInitialServices_, _investorDashboardDetailsModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
            mockInvestorDashboardInitialServices = _investorDashboardInitialServices_;
            investorDashboardDetailsModelData = _investorDashboardDetailsModel_;
            var $q = $injector.get('$q');
            httpBackend = _$httpBackend_;
            Restangular = _Restangular_; 

            httpBackend.expectGET('http://localhost:3030/dashboard/investorDashboard?guId=').respond(404, {
                'data': [{
                    'errorCode': 'E123',
                    'errorMessage': 'Something went wrong...'
                }]
            });
            httpBackend.expectGET('http://localhost:3030/dashboard/investorSmartSolGoals?guId=').respond(404, {
                'data': [{
                    'errorCode': 'E123',
                    'errorMessage': 'Something went wrong...'
                }]
            });
            httpBackend.expectGET('http://localhost:3030/dashboard/investorSmartSavings?guId=').respond(404, {
                'data': [{
                    'errorCode': 'E123',
                    'errorMessage': 'Something went wrong...'
                }]
            });
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should loadAllServices to be defined and expect error Services dashboard, Smart SavAcc And OneTouch Details and smart Solutions to be success', function() {
            mockInvestorDashboardInitialServices.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            });
            //httpBackend.flush();
            expect(mockInvestorDashboardInitialServices._isServicesData).toEqual(false);
        });
    });

});
