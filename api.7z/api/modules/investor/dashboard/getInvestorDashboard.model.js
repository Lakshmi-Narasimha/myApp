// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var InvestorDashboardSchema = new mongoose.Schema({
    investorDashboardObject: {
        type: Object,
        'default': {}
    }
});

var InvestorDashboardLookUp = mongoose.model('InvestorDashboardLookUp', InvestorDashboardSchema);

var InvestorDashboardModel = new InvestorDashboardLookUp({
    'investorDashboardObject': {
        'profileDetails': {
            'distId': '',
            'subDistId': '',
            'subArn': '',
            'name': 'NILESH HIMMATLAL SHAH M BANSAL SANBUI',
            'pan': 'DRCQR7575C',
            'kycStatus': 'Yes',
            'userType': '',
            'userId': '',
            'secretQtn': '',
            'guId': '',
            'mobile': '2706100644',
            'emailId': 'Asa.Arigo@ApcoArgentinaInc.com',
            'otpFlag': '',
            'otpType': '',
            'refNo': '',
            'date': '31 May 2016',
            'time': '12:00:00 PM'
        },
        'smartSavingsAccount': {
            'image': '',
            'heading': 'Smart Savings Account',
            'promo-image': '',
            'title': 'Smart Savings Account',
            'content': '<p>Liquid funds earn you better returns than a savings account.</p>\n<p>User has not started a transaction.</p>',
            'element': 'no-transaction',
            'currentValue': '0'
        },
        'oneTouchInvest': {
            'image': '',
            'heading': 'One Touch Invest',
            'promo-image': '',
            'title': 'One Touch Invest',
            'content': '<p>Save money because you can. It is easy, convenient and you don&rsquo;t need a lot to start doing it. Invest your first <strong>₹1,000</strong> now with a simple click.</p>',
            'element': '',
            'status': 'No'
        },
        'banner': {
            'image': '/images/bulls-and-bears.png',
            'component': 'banner',
            'heading': 'Bulls & Bears',
            'link': '/bulls-and-bears.html',
            'title': 'Bulls & Bears',
            'linkname': 'Read More',
            'content': ''
        },
        'mySips': {
            'hasInvested': 'N',
            'description': '<h3>You have not yet invested in SIP.</h3><p>1 line explaining the benefits of investing in SIPs - To be suggested by FT team.</p>'
                // 'totalActiveSIPS': 3,
                // 'monthlyInvestments': '3,000.00',
                // 'quarterlyInvestments': '15,000.00',
                // 'annualInvestments': '36,000.00'
        },
        'myTransactions': {
            'currentCost': '101377.7',
            'currentValue': '1440979.1',
            'fundValues': [{
                'fund': '0',
                'fundCategory': 'ELSS',
                'percentage': '0%'
            }, {
                'fund': '1424136.76',
                'fundCategory': 'EQUITY',
                'percentage': '98.83%'
            }, {
                'fund': '16842.43',
                'fundCategory': 'FIXED INCOME',
                'percentage': '1.17%'
            }, {
                'fund': '0',
                'fundCategory': 'HYBRID',
                'percentage': '0%'
            }, {
                'fund': '0',
                'fundCategory': 'INTERNATIONAL',
                'percentage': '0%'
            }, {
                'fund': '0',
                'fundCategory': 'LIQUID',
                'percentage': '0%'
            }]
        },
        'smartSolutions': {
            'smartSolutionGoals': [{
                'SNO': '1',
                'goal': 'R',
                'goalId': 'G0001',
                'goalDetails': 'Wealth Creation',
                'targetAmount': '2,16,000 ',
                'achievedAmount': '1,25,876.90',
                'pendingTimeFrame': '32',
                'encourageText': 'Great start!',
                'achieved': '15.07%',
                'completedTime': '11.11%',
                'futureReturn': '17,00,000',
                'initcap': '2.04',
                'investmentAmount': '8,00,000',
                'mktvalue': '1,14,528.71',
                'series': 'Retirement-Retirement -',
                'timeFrame': '36'
            }, {
                'SNO': '1',
                'goal': 'R',
                'goalId': 'G0001',
                'goalDetails': 'Dream Home',
                'targetAmount': '2,16,000 ',
                'achievedAmount': '1,25,876.90',
                'pendingTimeFrame': '12',
                'encourageText': 'Great start!',
                'achieved': '55.07%',
                'completedTime': '80.11%',
                'futureReturn': '11,00,000',
                'initcap': '2.04',
                'investmentAmount': '8,00,000',
                'mktvalue': '4,14,528.71',
                'series': 'Retirement-Retirement -',
                'timeFrame': '36'
            }, {
                'SNO': '1',
                'goal': 'R',
                'goalId': 'G0001',
                'goalDetails': 'Wealth Creation',
                'targetAmount': '2,16,000 ',
                'achievedAmount': '1,25,876.90',
                'pendingTimeFrame': '32',
                'encourageText': 'Great start!',
                'achieved': '85.07%',
                'completedTime': '11.11%',
                'futureReturn': '17,00,000',
                'initcap': '2.04',
                'investmentAmount': '8,00,000',
                'mktvalue': '1,14,528.71',
                'series': 'Retirement-Retirement -',
                'timeFrame': '36'
            }],
            'carousel': [{
                'link': {
                    'external': 'no',
                    'name': 'Amount you wish to save towards the end of goal',
                    'href': '/dream-home.html',
                    'type': 'default'
                },
                'description': 'Lorem Ipsum is simply dummy text of printing and typesetting?',
                'title': 'Dream Home',
                'background-image-mobile': '/images/fti_dreamHome_thumb.jpg',
                'background-image-tablet': '/images/fti_dreamHome_thumb.jpg',
                'background-image-desktop': '/images/fti_dreamHome_thumb.jpg'
            }, {
                'link': {
                    'external': 'no',
                    'name': 'Wealth Creation Link Text',
                    'href': '/wealth-creation.html',
                    'type': 'default'
                },
                'description': 'Lorem Ipsum is simply dummy text of printing and typesetting?',
                'title': 'Wealth Creation',
                'background-image-mobile': '/images/fti_wealthCreation_thumb.jpg',
                'background-image-tablet': '/images/fti_wealthCreation_thumb.jpg',
                'background-image-desktop': '/images/fti_wealthCreation_thumb.jpg'
            }, {
                'link': {
                    'external': 'no',
                    'name': 'Retirement Link Text',
                    'href': '/retirement.html',
                    'type': 'default'
                },
                'description': 'Lorem Ipsum is simply dummy text of printing and typesetting?',
                'title': 'Retirement',
                'background-image-mobile': '/images/fti_retirement_thumb.jpg',
                'background-image-tablet': '/images/fti_retirement_thumb.jpg',
                'background-image-desktop': '/images/fti_retirement_thumb.jpg'
            }]
        },
        'unclaimedAmount': '5,000.00',
        'dividendHistory': '1000'
    }
});

InvestorDashboardLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorDashboardLookUp table, please contact admin...' + err);
    } else {
        InvestorDashboardLookUp.remove({}, function(err) {
            console.log('InvestorDashboardLookUp collection removed' + err);
            InvestorDashboardModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InvestorDashboardLookUp table, please contact admin...');
                }
                console.log('InvestorDashboardLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorDashboardLookUp;
