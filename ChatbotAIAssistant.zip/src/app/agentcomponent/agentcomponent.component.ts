import { Component, OnInit, ViewChild } from '@angular/core';
import { Agent } from '../_models/index';
import { ModalDirective } from 'ng2-bootstrap';

import { AIAssistCacheService } from '../_services/aiassistcache.service';

@Component({
  selector: 'agentcomponent',
  templateUrl: './agentcomponent.component.html',
  styleUrls: ['./agentcomponent.component.css']
})
export class AgentcomponentComponent implements OnInit {

  newAgentmodel: any = {};

   @ViewChild('newAgentModal') public newAgentModel:ModalDirective;
   @ViewChild('removeAgentModal') public removeAgentModel:ModalDirective;
    agentsList : Array<Agent> = [];
    selectedAgent: Agent = null;
    constructor(private aiAssistCacheService : AIAssistCacheService) { this.subscribefordata();}
    private subscribefordata() {
      this.aiAssistCacheService.agentListObservable.subscribe((data) => {
        // console.log("inside agentcomponent subscribe before -> data -> ");
        // console.log(data);
        // console.log("agentsList -->");
        // console.log(this.agentsList);
        //this.agentsList.length = 0;
        //this.agentsList.push.apply(this.agentsList, data);
        this.agentsList = data;
        // console.log("inside agentcomponent subscribe after -> data -> ");
        // console.log(data);
        // console.log("agentsList -->");
        // console.log(this.agentsList);
      });
      this.aiAssistCacheService.activeAgentObservable.subscribe( (data) => {
        //console.log("Before --> this.selectedAgent -> " + JSON.stringify(this.selectedAgent) +"\ndata -> " + JSON.stringify(data));
        this.selectedAgent = data;
        //console.log("After --> this.selectedAgent -> " + JSON.stringify(this.selectedAgent) +"\ndata -> " + JSON.stringify(data));
      });
      //console.log("the data are : " + this.agentsList);
      /**
      this.aiAssistCacheService.getAllAgents().subscribe((data) => {
        console.log("inside agentcomponent subscribe before -> data -> ");
        console.log(data);
        console.log("agentsList -->");
        console.log(this.agentsList);
        this.agentsList.length = 0;
        this.agentsList.push.apply(this.agentsList, data);
        //this.agentsList = data;
        console.log("inside agentcomponent subscribe after -> data -> ");
        console.log(data);
        console.log("agentsList -->");
        console.log(this.agentsList);
      });
      //console.log("the data are : " + this.agentsList);
      **/
    }

    public hideNewAgentModal():void {
    this.newAgentModel.hide();
  }

  public hideRemoveAgentModal() : void {
    this.removeAgentModel.hide();
  }

  public createNewAgent(){
    //console.log("Ok button clicked");
    this.aiAssistCacheService.createAgent(this.newAgentmodel);
          /**  .subscribe(
                data => {
                    // set success message and pass true paramater to persist the message after redirecting to the login page
                    console.log(data);
                },
                error => {
                  console.log(error);
                });**/
    this.hideNewAgentModal();
  }

  public removeCurrentAgent() {
    this.aiAssistCacheService.removeActiveAgent();
    this.hideRemoveAgentModal();
  }
  private value:any = {};
  private _disabledV:string = '0';
  private disabled:boolean = false;

 private get disabledV():string {
   return this._disabledV;
 }

 private set disabledV(value:string) {
   this._disabledV = value;
   this.disabled = this._disabledV === '1';
 }

 public changeAgent(value:any):void {
   this.aiAssistCacheService.updateActiveAgent(value);
   //console.log('Selected value is: ', value);
 }

 public removed(value:any):void {
   //console.log('Removed value is: ', value);
 }

 public typed(value:any):void {
   //console.log('New search input: ', value);
 }

 public refreshValue(value:any):void {
   this.value = value;
 }

  ngOnInit() {
  }

}
