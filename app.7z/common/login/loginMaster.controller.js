

 function loginMasterController($scope,$state){

 	

}
loginMasterController.$inject = ['$scope','$state'];
module.exports = loginMasterController;