module.exports = function($q, $http) {
    
    var config = null;
    this.makeHttpCall = function(config) {
        var deferred = $q.defer();
        $http(config)
            .success(function(data, status, headers, config) {
                deferred.resolve(data);
            })
            .error(function(data) {
                deferred.reject(data);
            });
        return deferred.promise;
    };

    this.liveChat = function(queryData) {
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/livechat',
            data: queryData,
        };
        return this.makeHttpCall(config);
    };

    this.endChat = function(queryData) {
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/endchat',
            data: queryData,
        };
        return this.makeHttpCall(config);
    };

    this.getSupport = function(queryData) {
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/getSupport',
            data: queryData,
        };
        return this.makeHttpCall(config);
    };

    this.getTypeSearchSupport = function(queryData) {
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/getTypeSearchSupport',
            data: queryData,
        };
        return this.makeHttpCall(config);
    };

    this.search = function(queryData) {
        config = {
            method: 'post',
            url: 'http://localhost:9000/ask-verizon-api/search',
            data: queryData,
        };
        return this.makeHttpCall(config);
    };
};
