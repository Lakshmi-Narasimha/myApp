'use strict';

var tabs = function($state, $timeout, $stateParams, fticStateChange) {
	return {
            template: require('./tabs.html'),
            restrict: 'E',
            replace: true,
            scope: {
              tabs: "=tabdata",
              showTab :'=?',
              tabActive:'='
            },
            link: function(scope){
                if(scope.showTab !== null || scope.showTab !== undefined)
                {      
                    scope.activeJustified = scope.showTab;                 
                    if(scope.showTab >= 0 && scope.showTab < 4) {
                        fticStateChange.stateChange($state, scope.tabs[scope.showTab].uiref);
                        //$state.go(scope.tabs[scope.showTab].uiref);
                    }
                    scope.$on("showTabView",function(event,tabNo){
                        // scope.showTab = tabNo;          
            
                        if(tabNo > -1 && tabNo < 4) //Move to Constants               
                        {
                            if(scope.showTab == tabNo) {
                                fticStateChange.stateChange($state, scope.tabs[tabNo].uiref, {'xParam': $stateParams.xParam == 1 ? 0 : 1});
                                //$state.go(scope.tabs[tabNo].uiref, {'xParam': $stateParams.xParam == 1 ? 0 : 1});
                                scope.$emit("updateKeyValueListPan");
                            }
                            else {
                                fticStateChange.stateChange($state, scope.tabs[tabNo].uiref);
                                //$state.go(scope.tabs[tabNo].uiref);
                            }
                                
                            scope.activeJustified = tabNo;
                        }
                        else
                        {
                            fticStateChange.stateChange($state, scope.tabs[0].uiref);
                            //$state.go(scope.tabs[0].uiref);
                        }                    
                    })

                    scope.stopDefaultEvent = function($event,tabNo){
                        scope.$emit("getTabNo",tabNo)
                        if(scope.showTab === -1)
                        {
                            $event.stopPropagation();
                            $event.preventDefault();
                        }                                                
                    }                         

                }                    
                else
                {
                    fticStateChange.stateChange($state, scope.tabs[0].uiref);
                    //$state.go(scope.tabs[0].uiref);
                }                                                                        

            }
        };
};

tabs.$inject = ["$state",'$timeout', '$stateParams', 'fticStateChange'];
module.exports = tabs;