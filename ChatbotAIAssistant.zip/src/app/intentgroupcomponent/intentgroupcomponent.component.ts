import { Component, OnInit,ViewChild } from '@angular/core';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Agent } from '../_models/index';
import { Intent } from '../_models/index';

import { ModalDirective } from 'ng2-bootstrap';

@Component({
  selector: 'intentgroupcomponent',
  templateUrl: './intentgroupcomponent.component.html',
  styleUrls: ['./intentgroupcomponent.component.css'],
   inputs: ['title']
})

export class IntentgroupcomponentComponent implements OnInit {

closed: Boolean = false;
selectedIntent: Intent = null;
activeAgentIntents: Array < String > = null;

newIntentModel: any = {};

@ViewChild('addIntentModal') public newIntentModalDialog: ModalDirective;

constructor(private aiAssistCacheService : AIAssistCacheService) { this.subscriptions(); }

ngOnInit() {
}

toggle() {
  this.closed = !this.closed;
}

public updateActiveIntent(pIntent:Intent) {
  this.aiAssistCacheService.getIntentByIdFromServer(pIntent);
  console.log(JSON.stringify(pIntent));
}

public hideNewIntentModal():void {
  this.newIntentModalDialog.hide();
}

public createNewIntent(){
  //console.log("Ok button clicked");
  console.log("inside createNewIntent");
  console.log(this.newIntentModel);
  this.aiAssistCacheService.createIntent(this.newIntentModel);
  /**  .subscribe(
        data => {
            // set success message and pass true paramater to persist the message after redirecting to the login page
            console.log(data);
        },
        error => {
          console.log(error);
        });**/
  this.hideNewIntentModal();
}

private subscriptions() {
  this.aiAssistCacheService.activeIntentsObservable.subscribe((data) => {
    // console.log("inside agentcomponent subscribe before -> data -> ");
    // console.log(data);
    // console.log("agentsList -->");
    // console.log(this.agentsList);
    //this.agentsList.length = 0;
    //this.agentsList.push.apply(this.agentsList, data);
    this.activeAgentIntents = data;
    //console.log("agent group component");
    //console.log(this.activeAgentIntents);
    // console.log("inside agentcomponent subscribe after -> data -> ");
    // console.log(data);
    // console.log("agentsList -->");
    // console.log(this.agentsList);
  });
  this.aiAssistCacheService.activeIntentObservable.subscribe((data) => {
    //console.log("Inside intentgroupcomponent");
    //console.log(JSON.stringify(data));
    this.selectedIntent = data;
  });

  //console.log("the data are : " + this.agentsList);
  /**
  this.aiAssistCacheService.getAllAgents().subscribe((data) => {
    console.log("inside agentcomponent subscribe before -> data -> ");
    console.log(data);
    console.log("agentsList -->");
    console.log(this.agentsList);
    this.agentsList.length = 0;
    this.agentsList.push.apply(this.agentsList, data);
    //this.agentsList = data;
    console.log("inside agentcomponent subscribe after -> data -> ");
    console.log(data);
    console.log("agentsList -->");
    console.log(this.agentsList);
  });
  //console.log("the data are : " + this.agentsList);
  **/
}

}
