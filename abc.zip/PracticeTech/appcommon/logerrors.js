define([ 
         'appcommon/analytics',
         'appcommon/globalcontext',
         'config',
         'spinner',
         'appcommon/commonutility',
         'underscore'
], function (Analytics, GlobalContext, Config, Spinner, CommonUtils, __) {
			
			var ErrorUtils = (function() {
				"use strict"
				
				var numberOfErrorsLogged = 0;
				
				function getNumberOfErrorsLogged() {
					return numberOfErrorsLogged;
				};
				
				function handleErrors() {

					var _that = this;

					this.loggingConfig =  {
							loggingToConsole : Config.enableConsoleLogging,
							loggingLevel : Config.loggingLevel
					};
					
					this.configLogging = function(urlParms) {
						
			        	if(urlParms['enableConsoleLogging']){
			        		_that.loggingConfig.loggingToConsole = urlParms['enableConsoleLogging'] == 'true';
			        	}
			        	if(urlParms['logLevel']){
			        		_that.loggingConfig.loggingLevel = urlParms['logLevel'];
			        	}
					};
					
					this.generalErrMsgs = {
						defaultMsg : "We experienced some issues while retrieving this information.",
						serviceFilure: "We experienced some issues while retrieving this information.",
						systemUnavailableErrorMessage: "System unavailable",
						cmMsg: "We experienced some issues while retrieving this information from Contact Manager."
					};
					this.getBrowserInfo = function() {
						var unknown = 'Unknown';

						// screen
						var screenSize = '';
						if (screen.width) {
							var width = (screen.width) ? screen.width : '';
							var height = (screen.height) ? screen.height : '';
							screenSize += '' + width + " x " + height;
						}

						// browser
						var nVer = navigator.appVersion;
						var nAgt = navigator.userAgent;
						var browser = navigator.appName;
						var version = '' + parseFloat(navigator.appVersion);
						var majorVersion = parseInt(navigator.appVersion, 10);
						var nameOffset, verOffset, ix;

						// Opera
						if ((verOffset = nAgt.indexOf('Opera')) != -1) {
							browser = 'Opera';
							version = nAgt.substring(verOffset + 6);
							if ((verOffset = nAgt.indexOf('Version')) != -1) {
								version = nAgt.substring(verOffset + 8);
							}
						}
						// MSIE
						else if ((verOffset = nAgt.indexOf('MSIE')) != -1) {
							browser = 'Microsoft Internet Explorer';
							version = nAgt.substring(verOffset + 5);
						}

						// IE 11 no longer identifies itself as MS IE, so trap
						// it
						else if ((browser == 'Netscape')
								&& (nAgt.indexOf('Trident/') != -1)) {

							browser = 'Microsoft Internet Explorer';
							version = nAgt.substring(verOffset + 5);
							if ((verOffset = nAgt.indexOf('rv:')) != -1) {
								version = nAgt.substring(verOffset + 3);
							}

						}

						// Chrome
						else if ((verOffset = nAgt.indexOf('Chrome')) != -1) {
							browser = 'Chrome';
							version = nAgt.substring(verOffset + 7);
						}
						// Safari
						else if ((verOffset = nAgt.indexOf('Safari')) != -1) {
							browser = 'Safari';
							version = nAgt.substring(verOffset + 7);
							if ((verOffset = nAgt.indexOf('Version')) != -1) {
								version = nAgt.substring(verOffset + 8);
							}

							// Chrome on iPad identifies itself as Safari.
							// Actual results do not match what Google claims
							// at:
							// https://developers.google.com/chrome/mobile/docs/user-agent?hl=ja
							// No mention of chrome in the user agent string.
							// However it does mention CriOS, which presumably
							// can be keyed on to detect it.
							if (nAgt.indexOf('CriOS') != -1) {
								// Chrome on iPad spoofing Safari...correct it.
								browser = 'Chrome';
								// Don't believe there is a way to grab the
								// accurate version number, so leaving that for
								// now.
							}
						}
						// Firefox
						else if ((verOffset = nAgt.indexOf('Firefox')) != -1) {
							browser = 'Firefox';
							version = nAgt.substring(verOffset + 8);
						}
						// Other browsers
						else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt
								.lastIndexOf('/'))) {
							browser = nAgt.substring(nameOffset, verOffset);
							version = nAgt.substring(verOffset + 1);
							if (browser.toLowerCase() == browser.toUpperCase()) {
								browser = navigator.appName;
							}
						}
						// trim the version string
						if ((ix = version.indexOf(';')) != -1)
							version = version.substring(0, ix);
						if ((ix = version.indexOf(' ')) != -1)
							version = version.substring(0, ix);
						if ((ix = version.indexOf(')')) != -1)
							version = version.substring(0, ix);

						majorVersion = parseInt('' + version, 10);
						if (isNaN(majorVersion)) {
							version = '' + parseFloat(navigator.appVersion);
							majorVersion = parseInt(navigator.appVersion, 10);
						}

						// mobile version
						var mobile = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/
								.test(nVer);

						// cookie
						var cookieEnabled = (navigator.cookieEnabled) ? true
								: false;

						if (typeof navigator.cookieEnabled == 'undefined'
								&& !cookieEnabled) {
							document.cookie = 'testcookie';
							cookieEnabled = (document.cookie
									.indexOf('testcookie') != -1) ? true
									: false;
						}

						// system
						var os = unknown;
						var clientStrings = [
								{
									s : 'Windows 3.11',
									r : /Win16/
								},
								{
									s : 'Windows 95',
									r : /(Windows 95|Win95|Windows_95)/
								},
								{
									s : 'Windows ME',
									r : /(Win 9x 4.90|Windows ME)/
								},
								{
									s : 'Windows 98',
									r : /(Windows 98|Win98)/
								},
								{
									s : 'Windows CE',
									r : /Windows CE/
								},
								{
									s : 'Windows 2000',
									r : /(Windows NT 5.0|Windows 2000)/
								},
								{
									s : 'Windows XP',
									r : /(Windows NT 5.1|Windows XP)/
								},
								{
									s : 'Windows Server 2003',
									r : /Windows NT 5.2/
								},
								{
									s : 'Windows Vista',
									r : /Windows NT 6.0/
								},
								{
									s : 'Windows 7',
									r : /(Windows 7|Windows NT 6.1)/
								},
								{
									s : 'Windows 8.1',
									r : /(Windows 8.1|Windows NT 6.3)/
								},
								{
									s : 'Windows 8',
									r : /(Windows 8|Windows NT 6.2)/
								},
								{
									s : 'Windows NT 4.0',
									r : /(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/
								},
								{
									s : 'Windows ME',
									r : /Windows ME/
								},
								{
									s : 'Android',
									r : /Android/
								},
								{
									s : 'Open BSD',
									r : /OpenBSD/
								},
								{
									s : 'Sun OS',
									r : /SunOS/
								},
								{
									s : 'Linux',
									r : /(Linux|X11)/
								},
								{
									s : 'iOS',
									r : /(iPhone|iPad|iPod)/
								},
								{
									s : 'Mac OS X',
									r : /Mac OS X/
								},
								{
									s : 'Mac OS',
									r : /(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/
								},
								{
									s : 'QNX',
									r : /QNX/
								},
								{
									s : 'UNIX',
									r : /UNIX/
								},
								{
									s : 'BeOS',
									r : /BeOS/
								},
								{
									s : 'OS/2',
									r : /OS\/2/
								},
								{
									s : 'Search Bot',
									r : /(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/
								} ];
						for ( var id in clientStrings) {
							var cs = clientStrings[id];
							if (cs.r.test(nAgt)) {
								os = cs.s;
								break;
							}
						}

						var osVersion = unknown;

						if (/Windows/.test(os)) {
							osVersion = /Windows (.*)/.exec(os)[1];
							os = 'Windows';
						}

						switch (os) {
						case 'Mac OS X':
							osVersion = /Mac OS X (10[\.\_\d]+)/.exec(nAgt)[1];
							break;

						case 'Android':
							osVersion = /Android ([\.\_\d]+)/.exec(nAgt)[1];
							break;

						case 'iOS':
							osVersion = /OS (\d+)_(\d+)_?(\d+)?/.exec(nVer);
							osVersion = osVersion[1] + '.' + osVersion[2] + '.'
									+ (osVersion[3] | 0);
							break;

						}

						return {
							screen : screenSize,
							browser : browser,
							browserVersion : version,
							mobile : mobile,
							os : os,
							osVersion : osVersion,
							cookies : cookieEnabled
						};
					};
					// Lock the window
					this.lockWindow = function() {
						$("#lock-window").modal();
					};
					// Lock the window
					this.info = function(options) {
						$('#afi-nav-modal').modal('hide');
						Spinner.hide();
						
						$("#info-box .message").text(options.msg);
						if ($.trim(options.stack)) {
							var _dateString = "<div class='pt-data-value'>Date: "+new Date().toUTCString()+"</div>";
							$("#info-box .technical-details").addClass("hidden").html(_dateString +
									options.stack);
							$(document).off("click", ".see-tech-details").on(
									"click",
									".see-tech-details",
									function() {
										$(".technical-details").toggleClass(
												"hidden");
									});
						} else {
							$(".see-tech-details").addClass("hidden");
						}

						$("#info-box").modal();
					};
					this.defaultOptions = {
						resource : null,
						id: null,
					    PeopleSoftId: null,
						log : {
							type: null,
							info: null,
							location : null,
							stack : {
								request : null,
								response: null,
								httpCode: null,
								clientStackTrace: null,
								isClientSide: null
							}
						},
						globalContext: null,
					};
					this.prepareAndLogError = function(errObj,hidePopup, errorResource) {
						var theErrorResource;
						if (errorResource) {
							theErrorResource = errorResource;
						} else {
							theErrorResource = Analytics.analytics.sessionAnalytics.currentPage;
						}
						var myValues = {
								resource : theErrorResource,
								type : 'ERROR',
								info : 'Service Error',
								location : Analytics.analytics.sessionAnalytics.currentPage,
								request : '',
								response : '',
								httpCode : '',
								clientStackTrace : '',
								isClientSide: false,
								sourceSystem: '',
                                params: ''
						}

						try {
							if (errObj && errObj.httpResponse) {
								//for breeze calls
							    var _data = (typeof errObj.httpResponse.data === "object") ? JSON.parse(JSON.stringify(errObj.httpResponse.data))
										: errObj.httpResponse.data;
								myValues.request = (errObj.httpResponse.config.url) ? errObj.httpResponse.config.url
										: '';
								myValues.params = (errObj.httpResponse.config.params) ? errObj.httpResponse.config.params : '';
								_data = (typeof _data == "string") ? JSON.parse(_data) : _data;
								myValues.sourceSystem = _data ? (_data.source ? _data.source : "") : "";
								myValues.response =  _data.error.message.value;
								myValues.httpCode = errObj.httpResponse.status;
								myValues.clientStackTrace = JSON.stringify(_data);
							} else  if (errObj && errObj.responseJSON ){
								//for normal jquery ajax calls
								var _data = errObj.responseJSON;
								myValues.request = (errObj.config) ? errObj.config.url : '';
								myValues.params = (errObj.config) ? ((errObj.config.params) ? errObj.config.params : '') : '';
								myValues.response =_data?(_data.error ? (_data.error.message ? _data.error.message.value:""):""):"";
								myValues.httpCode = errObj.status;
								myValues.clientStackTrace = JSON.stringify(_data);
							} else if (errObj && errObj.responseText) {
							    var _data = errObj.responseText;
							    myValues.request = (errObj.config) ? errObj.config.url : '';
							    myValues.params = (errObj.config) ? ((errObj.config.params) ? errObj.config.params : '') : '';
							    myValues.response = _data?(_data.error ? (_data.error.message ? _data.error.message.value: ""): ""): "";
							    myValues.httpCode = errObj.status;
							    myValues.clientStackTrace = _data;
							} else if (errObj && errObj.statusText) {
								var _data = errObj.statusText;
								myValues.request = (errObj.config) ? errObj.config.url : '';
								myValues.params = (errObj.config) ? ((errObj.config.params) ? errObj.config.params : '') : '';
								myValues.response =_data;
								myValues.httpCode = errObj.status;
								myValues.clientStackTrace = _data;
							} 
							else { }
							
							if (errObj && errObj.status == "400") {
							    var _copyOfMyValues = JSON.parse(JSON.stringify(myValues)), _payloadInfo;
							    _payloadInfo = { "info": "Log for 400 Error Payload", "payload": errObj.data ? errObj.data : "could not capture the data" };
							    _copyOfMyValues.response = _payloadInfo;
							    _copyOfMyValues.clientStackTrace = _payloadInfo;
							    _that.logMessage(myValues.resource, myValues.type, myValues.info, myValues.location, myValues.request, _copyOfMyValues.response, myValues.httpCode, _copyOfMyValues.clientStackTrace, myValues.isClientSide, myValues.sourceSystem, true, myValues.params);
							}
						} catch (err) {
							this.logErrors(err);
						}

						_that.logMessage(myValues.resource, myValues.type, myValues.info, myValues.location, myValues.request, myValues.response, myValues.httpCode, myValues.clientStackTrace, myValues.isClientSide, myValues.sourceSystem, hidePopup, myValues.params);
					};
					this.logErrors = function (options, hidePopup) {
					    var message = this.generalErrMsgs.defaultMsg;
					    if ((!__.isUndefined(options.log)) && (!__.isUndefined(options.log.stack)) && options.log.stack.httpCode == "500") {
					        message = this.generalErrMsgs.systemUnavailableErrorMessage;
					    }
					    else if ((!__.isUndefined(options.sourceSystem)) && options.sourceSystem == "AmMidTier") {
					        message = this.generalErrMsgs.cmMsg;
					    }						
                        if(!options.log){
                        	options.log = {type:"ERROR"};
                        }
						if (this.loggingIsEnabled(options)) {
							options = this.extend(this.defaultOptions, options);
							if(!hidePopup){
								var _stack = "";
								if(typeof options.log !=="undefined"){
									_stack = options.log.info + ", " + JSON.stringify(options.log.stack);
								}else{
									_stack = options.stack?options.stack:options.message;
								}
								this.info({
									msg : message,
									stack : _stack
								});
							}
							this.rightSizeMessage(options);
							if (_that.loggingConfig.loggingToConsole == true) {
								console.log(JSON.stringify(options));
							};
							numberOfErrorsLogged ++;
							// Send error to the server
							new Image().src = "images/error_log_image.png?error_message="
									+ encodeURIComponent(JSON.stringify(options)
											.replace(/'/g, "\\'").replace(/"/g, "'"));
						};

					};
					
					this.loggingIsEnabled = function(error) {
						// only log levels are ERROR, PERF, and WARN.
						if (_that.loggingConfig.loggingLevel == 'WARN') {
							return true;
						} else {
							if (_that.loggingConfig.loggingLevel == 'PERF' && error.log.type != 'WARN') {
								return true;								
							} else {
								if (_that.loggingConfig.loggingLevel == 'ERROR' && error.log.type == 'ERROR') {
									return true;
								} else {
									return false;
								}
							}
						}
					}
					
					// Method to ensure that the total length of the input error message is not
					// greater than the max length permissible for a Get Message send.
					this.rightSizeMessage = function(message) {
						var maxGetMessageSize = 2040;   // max is 2048 but make it 2040 to eliminate any boundary conditions
						var stringifiedMessage = JSON.stringify(message);
						if (stringifiedMessage.length > maxGetMessageSize) {
							var charsToRemove = stringifiedMessage.length - maxGetMessageSize;
							if (message.log.stack.clientStackTrace.length > charsToRemove) {
								message.log.stack.clientStackTrace = message.log.stack.clientStackTrace.substring(0,  message.log.stack.clientStackTrace.length - charsToRemove);
							} else { message.log.stack = null; }
						}
						
					};
					// Method to register window onerror event
					this.registerWindowErrorEvent = function() {
						if (typeof window.onerror != "function") {
							window.onerror = this.handleWindowError;
						}
					};
					// Window onerror handler
					this.handleWindowError = function(errorMsg, url, line,
							column, stack) {
						_that.logMessage(Analytics.analytics.sessionAnalytics.currentPage, 'ERROR', errorMsg, Analytics.analytics.sessionAnalytics.currentPage, '', '', '', stack.stack, true, '', '');
					};
					// Create a new object, that prototypically inherits from the
					// Error constructor.
					this.myError = function(errorObj,hidePopup) {
						if (typeof errorObj === "undefined")
							errorObj = {};
						if(errorObj.stack){
							_that.logMessage(Analytics.analytics.sessionAnalytics.currentPage, 'ERROR', errorObj.message, Analytics.analytics.sessionAnalytics.currentPage, '', '', '', errorObj.stack, true, '', hidePopup, '');
						} else if(errorObj.status !== undefined){
						_that.prepareAndLogError(errorObj,hidePopup);
						} else if (errorObj.jqXHR) {
						    _that.prepareAndLogError(errorObj.jqXHR, hidePopup);
						} else {
						_that.logMessage(Analytics.analytics.sessionAnalytics.currentPage, 'ERROR', errorObj.message, Analytics.analytics.sessionAnalytics.currentPage, '', '', '', errorObj.message, true, '', hidePopup, '');
						}
					};
					
					this.myError.prototype = new Error();
					this.myError.prototype.constructor = this.myError;

					// Extend an object
					this.extend = function(parentObj, chileObj) {
						if (typeof parentObj != "object"
								&& typeof parentObj != "object") {
							return {};
						}
						var _tmpObj = {};
						for ( var key in parentObj)
							_tmpObj[key] = (chileObj[key] == null) ? parentObj[key]
									: chileObj[key];
						return _tmpObj;
					};
					
					// Create a new warning type message and log it.
					this.logWarning = function(myResource, myLogInfo, myLocation, myRequest, myResponse, myHttpCode, myClientStackTrace, myIsClientSide) {
						this.logMessage(myResource, 'WARN', myLogInfo, myLocation, myRequest, myResponse, myHttpCode, myClientStackTrace, myIsClientSide, '');
					}
					
					// Create a new messaging object and log it.
					this.logMessage = function(myResource, myType, myLogInfo, myLocation, myRequest, myResponse, myHttpCode, myClientStackTrace, myIsClientSide, mySourceSystem, hidePopup, myParams) {

						var tempStack = {
						    request: myRequest,
						    params: myParams,
							response : myResponse,
							httpCode : myHttpCode,
							clientStackTrace : myClientStackTrace,
							isClientSide : myIsClientSide
						};
						var tempLog = {
							type : myType,
							info : myLogInfo,
							location : myLocation,
							stack : tempStack
						};
						var tmpErrObj = {
						    id: GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID,
						    PeopleSoftId: CommonUtils.readCookie('PeopleSoftID') || '',
							resource : myResource,
							log: tempLog,
							globalContext: GlobalContext.getInstance().getGlobalContext().Context,
							sourceSystem: mySourceSystem
						};
						_that.logErrors(tmpErrObj,hidePopup);
					};
				}

				var _ = new handleErrors();
				_.registerWindowErrorEvent();
				return _;
			})();
			
			 return { ErrorUtils: ErrorUtils };

		}); 
