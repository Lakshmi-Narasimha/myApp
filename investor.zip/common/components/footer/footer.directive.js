var fticFooter = function() {
    return {
        template: require('./fticFooter.html'),
        restrict: 'EA',
        replace: true
    };
};

fticFooter.$inject = [];
module.exports = fticFooter;
