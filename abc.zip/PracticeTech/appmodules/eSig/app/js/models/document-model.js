define(['backbone'], function(Backbone) {
	var documentModel = Backbone.Model.extend({
		defaults : {
			"docId" : "",
			"docName" : "",
			"signDueDate" : "",
			"signOnDevice" : "",
			"sendForEsig" : ""

		// "assignedUserList":[]
		}
	/*
	 * , relations: [{ type: Backbone.HasMany, key: 'assignedUserList',
	 * relatedModel: eSig.models.customerModel, reverseRelation: { key:
	 * 'document', includeInJSON: 'docId' } }]
	 */
	});
	return documentModel;
});