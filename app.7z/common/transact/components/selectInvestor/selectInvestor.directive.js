/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accordion = function($state, eventConstants, selectInvestorModel,selectInvestorInitialLoader,$timeout,transactEventConstants,transactEvents,transactModel,$stateParams,$filter,TransactConstant, toaster) {
  return {
            template: require('./selectInvestor.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              accordionData: "=",
              lable: "=",
              count: "="
            },
            controller:['$scope', function($scope){ 
                
                var editIconChanged = false,
                    previousSearchValue = "",
                    previousSearchText = "",
                    index = "",
                    searchData = {},
                    pageRange = {},
                    pageOffset = 1,
                    limit = 5,
                    previousPage = 0,
                    oldPageRange, 
                    newPageRange, 
                    oldInvValue, 
                    newInvValue
                    ;
                pageRange.limit = 5;
                pageRange.offset = 1;
                $scope.paginationObject = {
                    paginationTotal : 50,
                    currentPage : 1
                }
                $scope.pageChanged = function() {
                    $scope.showSearchResult = false;
                    if($scope.paginationObject.currentPage === 1){
                        pageRange.offset = 1;
                    }else{
                        pageRange.offset = (pageRange.limit * ($scope.paginationObject.currentPage-1)) + 1;
                    }
                    //selectInvestorInitialLoader.loadAllServices($scope,searchData,pageRange);
                    $scope.init(searchData);
                    listenForData(searchData);
                }; 

                $scope.gridOptions = {};   
                $scope.selectedInvestorDtls = null; 
                $scope.config = {};
                $scope.config.showNotification = false;
                $scope.searchOptions = [
                    {
                    lable: "PAN"
                  },
                  {
                    lable: "Folio No."
                  },
                  {
                    lable: "Account No."
                  },
                  {
                    lable: "Unit Holder Name"
                  },
                  {
                    lable: "Mobile"
                  },
                  {
                    lable: "Email"
                  },
                  {
                    lable: "Aadhaar"
                  },
                  {
                    lable: "CAN"
                  },
                  {
                    lable: "IIN"
                  }
                ];
                $scope.$on(eventConstants.HIDE_SEARCH_RESULT, function (event, args) {                 
                    $scope.showSearchResult = false;
                    $scope.selectInvestorGrid = [];
                });
                $scope.init = function (searchData) {
                  $scope.selectedInvestorDtls = null;            
                  $scope.selectInvestorGrid = []; 
                  $scope.showSearchResult = false;               
                  selectInvestorInitialLoader.loadAllServices($scope,searchData,pageRange);
                  var statusTemplate = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}" name="selectedInvestor" ng-click="grid.appScope.$emit(\'selectInvestor\', row.entity)" />';

                  $scope.gridOptions.columnDefs = [
                    { field: 'checkBox',displayName:'', value:index, width:"50", cellTemplate:statusTemplate , enableSorting:false, pinnedLeft:true},
                    { field: 'custName', displayName: 'Unit Holder Name', width:"180", enableSorting:false, pinnedLeft:true, footerCellTemplate: '<div class="ui-grid-cell-contents">Total</div>'},                        
                    { field: 'pan', displayName: 'PAN', width:"140", enableSorting:false},
                    { field: 'folioId', displayName: 'Folio No.', width:"154", enableSorting:false},
                    { field: 'holdingType', displayName: 'Mode of Holding', width:"180",  enableSorting:false},
                    { field: 'mobile', displayName: 'Mobile', width:"154", enableSorting:false},
                    { field: 'emailId', displayName: 'Email', width:"254",  enableSorting:false},
                    { field: 'city', displayName: 'City', width:"254",  enableSorting:false}                  
                  ];
                };

                function setDetailsFundsGo(){
                  selectInvestorModel.setSelectedInvestorDtls($scope.selectedInvestorDtls);
                  transactModel.setInvestorDetails($scope.selectedInvestorDtls);
                  transactModel.setSearchOption(searchData.searchOption);
                  transactModel.setSearchText(searchData.searchText);
                  transactModel.setPageRange(pageRange.offset);
                  $scope.$emit(transactEventConstants.transact.Investor_Details);
                }

                function setExistingData(){
                  index = transactModel.getInvestorDetails().index;
                  searchData = {
                    searchOption : transactModel.getSearchOption(),
                    searchText : transactModel.getSearchText()
                  };
                  $timeout(function(){
                    $scope.selectedInvestorDtls = transactModel.getInvestorDetails();
                  },0);
                }

                function checkPreviousData(oldPageRange, newPageRange, oldInvValue, newInvValue){
                  if(oldInvValue){
                        if ((oldInvValue.index != newInvValue.index) || (oldPageRange !=newPageRange)){
                        $scope.config.showNotification = true;
                        var destroyHandler =  $scope.$on('yes', function () {
                            transactModel.isSameInv = false;
                            index = "";
                            $scope.config.showNotification = false;
                            $scope.selectedInvestorDtls = newInvValue;
                            setDetailsFundsGo();                         
                            destroyHandler();
                        });
                        $scope.$on('no', function () {
                          $scope.config.showNotification = false;
                          setExistingData();  
                          $scope.init(searchData);
                          listenForData(searchData);
                        });
                      }
                      else{
                        transactModel.isSameInv = true;
                        setDetailsFundsGo();
                      }
                  }
                  else{
                     transactModel.isSameInv = false;
                    setDetailsFundsGo();
                  }                    
                  
                }
                if($stateParams.key === TransactConstant.transact.Investor_Key)
                {
                  setExistingData();  
                  $scope.init(searchData);
                  editIconChanged = true;
                  listenForData(searchData);
                }   

                function listenForData(args){
                  var destroyGrid = $scope.$on(transactEventConstants.transact.Select_Investor, function (event) {
                    
                      $scope.selectInvestorGrid = selectInvestorModel.getInvestors();
                      $scope.paginationObject.totalItems = Math.ceil(selectInvestorModel.getInvestors()[0].recordCount/pageRange.limit) || 1;
                      $scope.paginationObject.count = selectInvestorModel.getInvestors()[0].recordCount;

                      for(var i=0;i<$scope.selectInvestorGrid.length;i++) {
                          $scope.selectInvestorGrid[i].index = ""+(i+1);
                      }              
                      $scope.$emit(transactEventConstants.transact.Open_Grid);
                    
                    $scope.showSearchResult = true;                                
                    previousSearchValue = args.searchOption;
                    previousSearchText = args.searchText;
                  });
                }

                $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) { 
                  
                  if(editIconChanged == true){
                    /*function destroyHandlerFn(){
                      destroyHandler();
                     }*/
                    if(previousSearchValue !== args.searchOption || previousSearchText !== args.searchText)
                    { 
                      $scope.config.showNotification = true;
                     var destroyHandler =  $scope.$on('yes', function () {
                        index = "";
                        searchData = {
                          searchOption : args.searchOption,
                          searchText : args.searchText   
                        };
                        $scope.init(searchData);
                        listenForData(searchData);
                        $scope.config.showNotification = false;
                        transactModel.setInvestorDetails(null);
                        destroyHandler();
                      });

                      $scope.$on('no', function () {
                        $scope.config.showNotification = false;
                      });
                    }
                  } 
                  else
                  {
                    searchData = {
                      searchOption : args.searchOption,
                      searchText : args.searchText   
                    };
                    $scope.init(searchData);
                    listenForData(searchData);
                  }                   
                });

                $scope.$on(transactEventConstants.transact.Edit_Button_Clicked, function (event, args) { 
                  setExistingData();  
                  editIconChanged = true;
                  $scope.init(searchData);
                  listenForData(searchData);
                });
                $scope.$on(transactEventConstants.transact.TRANS_SELECT_INVESTOR, function (event, args) {                 
                  $scope.selectedInvestorDtls = args;
                   console.log(args)
                    if((args.emailId ===""|| args.emailId ==="null" || args.emailId ===" ") && (args.mobile ===""||args.mobile ==="null" || args.mobile ===" ")){
                    console.log("No data here");
                    toaster.error("The user doesn’t have a registered mobile and e-mail. Please select a different folio to proceed with the transaction");
                    $scope.selectedInvestorDtls = null;
                  }
                }); 

                $scope.$on(transactEventConstants.transact.Trans_Select_Option_Changed, function (event, args) {  
                  $scope.showSearchResult = false;
                  $scope.selectInvestorGrid = null;
                });

                $scope.SIContnuBtn = function($event){
                  if (editIconChanged) {
                    checkPreviousData(transactModel.getPageRange(), pageRange.offset, transactModel.getInvestorDetails(), $scope.selectedInvestorDtls);
                  }
                  else{                    
                    setDetailsFundsGo();
                  }
                    
                  
                }
            }]
        };
};

accordion.$inject = ['$state', 'eventConstants', 'selectInvestorModel','selectInvestorInitialLoader','$timeout','transactEventConstants','transactEvents','transactModel','$stateParams','$filter','TransactConstant','toaster'];
module.exports = accordion;