function securityQuestionController($scope, $state, advisorRegistrationModelService, fticStateChange) {
    $scope.formData = {};
    $scope.errorMessage = '';
    $scope.wrongAnswer = false;
    $scope.submitQuestion = function() {
        $scope.$broadcast('submitSecurityQuestion');
        var postObj = {
            guId: advisorRegistrationModelService.getUserData().guId,
            answer: advisorRegistrationModelService.getSecurityAnsData()
        };


        if ($scope.secuirtySubmitForm.$valid) {
            var postSuccess = function() {
                $scope.wrongAnswer = false;
                if (advisorRegistrationModelService.getUserForgotTypeDetails() === 'password') {
                    fticStateChange.stateChange($state, 'loginmaster.newpassword');
                    //$state.go('loginmaster.newpassword');
                } else {
                    advisorRegistrationModelService.postAcknowledgeCall(advisorRegistrationModelService.getUserData().guId);
                    fticStateChange.stateChange($state, 'loginmaster.thankyou');
                    //$state.go('loginmaster.thankyou');
                }
            };
            var handleFailure = function() {
                $scope.wrongAnswer = true;
                //toaster.error(errorResp.data[0].errorDescription);
                $scope.errorMessage = 'Sorry! Your Secret Answer is incorrect, Please try again';
                //toaster.error("Sorry! Your Secret Answer is incorrect, Please try again");

            };
            advisorRegistrationModelService.postAnsForSecurityQn(postObj).then(postSuccess, handleFailure);
        } else {
            $scope.wrongAnswer = true;
            $scope.errorMessage = 'Please enter your secret answer to proceed.';
        }
    };
}
securityQuestionController.$inject = ['$scope', '$state', 'advisorRegistrationModelService', 'fticStateChange'];
module.exports = securityQuestionController;
