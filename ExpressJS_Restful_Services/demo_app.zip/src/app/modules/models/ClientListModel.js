define(['jquery',
    'lodash',
    'backbone'
], function ($, _, Backbone) {

    var ClientListModel = Backbone.Model.extend({
        defaults: {
            clientList: [],
        },
        initialize: function () {
            self = this;
        },
        setClientList: function (res) {
            var response = res.d || {};
            var list = response.results ? response.results : [];
            self.set('clientList', list);
            return self;
        },
        filterByClId: function (id) {
           return _.filter(self.get('clientList'), function(obj,key){
               return obj.id == id
           })[0];
        }
    });
    return ClientListModel;
});