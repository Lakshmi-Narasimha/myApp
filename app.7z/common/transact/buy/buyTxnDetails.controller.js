/**
 * @ngdoc property
 * @name buyTxnDtlsController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function buyTxnDtlsController($scope, fticLoggerMessage, loggerConstants, $state, transactModel) {
    console.info("Buy Txn Details Controller!!");

    $scope.redirect = function () {
    	// transactModel.setStateValue({key:null});
    	transactModel.resetSetters(); 
        transactModel.isNewInvestor = false;
    	$state.go("transact.base.buy",{key:null});
    }
}

buyTxnDtlsController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state','transactModel'];
module.exports = buyTxnDtlsController;