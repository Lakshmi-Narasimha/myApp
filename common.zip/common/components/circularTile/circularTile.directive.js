'use strict';

var circularTile = function() {
    return {
            template: require('./circularTile.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                tiledata: '=tiledata',              
                type: '=type',
                dType: '='               
            }
        };
};

circularTile.$inject = [];
module.exports = circularTile;