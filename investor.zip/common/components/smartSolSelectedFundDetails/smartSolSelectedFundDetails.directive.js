/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolSelectedFundDetails = function($state) {
	return {
          template: require('./smartSolSelectedFundDetails.html'),
           restrict: 'E',
           replace: true,
            controller: function($scope, $element, $attrs){
              $scope.annualizedGrowthVal = $scope.fundDetails[0].returnSlabs;  
              $scope.$on('slectedOptionValue', function(event, obj){
                  $scope.anuualizedGrowth = obj.value;
              });  
              $scope.showFundCardModal = function(fundId) {
                $scope.$emit('openFundCardModelPlan', fundId);
              }
            },
            link: function(scope, iElement, iAttrs, controller){
              $('[data-toggle="popover"]').popover();  
            }
        };
};

smartSolSelectedFundDetails.$inject = [];
module.exports = smartSolSelectedFundDetails;