/* ************************************************************************* */
/* *** Copyright 2015 Ameriprise Financial, Inc.  All rights reserved. ***** */
/* ************************************************************************* */

define([
    'app/common/analyticsScode',
    'CryptoJS',
    'app/application/app',
    'config'
], function (sCode, CryptoJS, app, config) {
    "use strict";

    var gomezMonitoringPeopleSoftID = '9978852';
    var s_account = config.omnitureSAccount;
    var userAnalyticsIdentifier = null;
    var CURRENT_S_CODE = null;

    function getUserIdentifier() {
        if (!userAnalyticsIdentifier) {
            var userSSOGuid = app.userInformation.guid;
            if (userSSOGuid) {
                userAnalyticsIdentifier = CryptoJS.SHA1(userSSOGuid).toString();
            }
        }
        return userAnalyticsIdentifier ? userAnalyticsIdentifier : '';
    }

    function shouldCollectAnalyticsForUser() {
        return app.userInformation.peopleSoftId != gomezMonitoringPeopleSoftID;
    }

    var analytics = {

        sessionAnalytics: {
            currentPage: '',
            previousPage: ''
        },

        SUITE_NAME: 'SharedSuite',

        // Navigation names

        processSaaSubRouteChangeEvent: function (route) {

            if (route == 'defaultAction') {
                this.recordNavigation("defaultAction");
            } else if (route == 'handleStepsView') {
                this.recordNavigation("saaSteps");
            } else if (route == 'handleSelectParticipants') {
                this.recordNavigation("selectParticipants");
            } else {

            }
        },

        recordNavigation: function (destinationPage, reportingSuite /* optional */) {

            this.sessionAnalytics.previousPage = this.sessionAnalytics.currentPage;
            this.sessionAnalytics.currentPage = destinationPage;

            var event = {
                TYPE: 'navigation',
                CURRENT_PAGE: this.sessionAnalytics.currentPage,
                PREVIOUS_PAGE: this.sessionAnalytics.previousPage,
                ACTION: 'entering'
                // entering current page and leaving the previous page
            };

            this.sendEvent(event, reportingSuite);
        },

        recordAction: function (action, reportingSuite /* optional */) {
            var event = {
                TYPE: 'action',
                CURRENT_PAGE: this.sessionAnalytics.currentPage,
                ACTION: action
            };

            this.sendEvent(event, reportingSuite);
        },

        recordSearch: function (searchString, searchType, reportingSuite /* optional */) {
            var event = {
                TYPE: 'search',
                CURRENT_PAGE: this.sessionAnalytics.currentPage,
                ACTION: 'search',
                SEARCH_STRING: searchString,
                SEARCH_TYPE: searchType
            };

            this.sendEvent(event, reportingSuite);
        },

        sendEvent: function (event, reportingSuite /* optional */) {
            event.SESSION_ID = getUserIdentifier();
            event.TIMESTAMP = new Date().toJSON();
            event.APPLICATION = 'web';  // other values can be 'ios', or 'android'

            this.sendToOmniture(event, reportingSuite);
        },

        logEventToConsole: function (suite, s_omniture, event) {

            if (config.enableAnalyticsConsoleLogging) {

                var omnitureVariables = {
                    pageName: s_omniture.pageName,
                    prop1: s_omniture.prop1,
                    eVar1: s_omniture.eVar1,
                    prop14: s_omniture.prop14,
                    eVar14: s_omniture.eVar14,
                    prop21: s_omniture.prop21,
                    eVar21: s_omniture.eVar21,
                    prop23: s_omniture.prop23,
                    eVar23: s_omniture.eVar23,
                    currentPage: event.CURRENT_PAGE,
                    action: event.ACTION,
                    searchString: event.SEARCH_STRING,
                    searchType: event.SEARCH_TYPE
                };

            /*    console.log('Analytics Event Recorded to Suite: ' + suite + ', Type: ' + event.TYPE + ', Send-to-Omniture: ' +
                    config.sendAnalyticsToOmniture + ', Include-user-in-analytics: ' + shouldCollectAnalyticsForUser());

                console.log('Analytics OmnitureVariables: ' + JSON.stringify(omnitureVariables));*/
            }
        },

        sendToOmniture: function (event, reportingSuite) {

            if (!reportingSuite) {
                reportingSuite = this.SUITE_NAME;
            }

            var CURRENT_S_CODE = sCode.configureOmnitureForAccountSuite(s_account);

            // evars are relatively consistent through several steps/actions and possibly the whole session.
            // props change much more frequently throughout the session

            CURRENT_S_CODE.eVar1 = event.SESSION_ID;
            CURRENT_S_CODE.prop1 = event.SESSION_ID;

            // t for tracking, tl for link tracking
            if (config.sendAnalyticsToOmniture && shouldCollectAnalyticsForUser()) {
                if (event.TYPE == 'navigation') {
                    CURRENT_S_CODE.pageName = event.CURRENT_PAGE;  // only for nav events else metrics get double counted.
                    CURRENT_S_CODE.prop14 = event.CURRENT_PAGE;
                    CURRENT_S_CODE.eVar14 = event.CURRENT_PAGE;
                    CURRENT_S_CODE.t();  // t() sends all props and evars.
                } else if (event.TYPE == 'action') {
                    CURRENT_S_CODE.prop14 = event.ACTION;
                    CURRENT_S_CODE.eVar14 = event.ACTION;
                    CURRENT_S_CODE.linkTrackVars = 'eVar1,prop14,eVar14,prop1';
                    CURRENT_S_CODE.tl(true, 'o', event.CURRENT_PAGE + ':' + event.ACTION) // tl() sends only the props in the linkTrackVars above
                } else { // must be a search
                    CURRENT_S_CODE.prop14 = event.ACTION;
                    CURRENT_S_CODE.eVar14 = event.ACTION;
                    CURRENT_S_CODE.prop21 = event.SEARCH_STRING;
                    CURRENT_S_CODE.eVar21 = event.SEARCH_STRING;
                    CURRENT_S_CODE.prop23 = event.SEARCH_TYPE;
                    CURRENT_S_CODE.eVar23 = event.SEARCH_TYPE;
                    CURRENT_S_CODE.linkTrackVars = 'eVar1, prop1, eVar14, prop14, eVar21, prop21, eVar23, prop23';
                    CURRENT_S_CODE.tl(true, 'o', event.CURRENT_PAGE + ':' + event.SEARCH_TYPE); // tl() sends only the props in the linkTrackVars above
                }
            }
            this.logEventToConsole(reportingSuite, CURRENT_S_CODE, event);
        }

    };

    return analytics;

});
