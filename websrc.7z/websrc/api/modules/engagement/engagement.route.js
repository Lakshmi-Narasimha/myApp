var express = require('express');
var https = require('https');
var querystring = require('querystring');

var router = express.Router();
var engagementModel = require('./engagement.model');
var getMessageModel = require('../getMessage/getMessage.model');
var dataPassModel = require('../dataPass/dataPass.model');

var dataPass = function(req, res, dataPassCallback) {

    var post_data = {
        "engagementID": req.session.engagementID,
        "agentID": req.session.agentID,
        "Role": req.session.accRole,
        "Mobile Number": req.session.MDN,
        "Greeting Name": req.session.nickName
    };

    req.uri = dataPassModel.createRequestUri;
    console.log("requestURI:", req.uri);

    var postBody = querystring.stringify(post_data);
    console.log(postBody);

    var proxyRequest = https.request({
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        },
        function(proxyResponse) {
            console.log("statusCode: ", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                dataPassCallback(res);
                //res.status(200).end();
            } else {
                res.send({
                    statusCode: proxyResponse.statusCode,
                    message: 'Something went wrong while retrieving data.'
                });
            }
            proxyResponse.on('error', function(err) {
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
            });
        });

    proxyRequest.write(postBody);
    proxyRequest.end();
};

var getMsg = function(req, res, callBack) {
    req.uri = getMessageModel.createRequestUri;
    for (var i = 0; i < 3; i++) {
        (function(i) {
            var proxyRequest = https.request({
                    host: req.uri.host,
                    method: 'GET',
                    path: req.uri.path + req.engagementID,
                    headers: {
                        'Cookie': req.sessionCookie
                    }
                },
                function(proxyResponse) {
                    proxyResponse.setEncoding('utf8');
                    proxyResponse.on('data', function(chunk) {
                        if (i === 2) {
                            callBack(chunk);

                        }
                    });
                    proxyResponse.on('error', function(err) {
                        err.message = 'ERROR!!! Something went wrong while retrieving data.';
                        res.send(err);
                    });
                });

            proxyRequest.write(res.body + '');
            proxyRequest.end();
        })(i);
    }
};

// api route
router.route('/mfchat/rest/engagement')
    .post(function(req, res) {

        req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID];

        req.session.agentGroupID = req.body.RequestParams.agentGroupID;
        req.session.nickName = req.body.RequestParams.nickName;
        req.session.accRole = req.body.RequestParams.accRole;
        req.session.MDN = req.body.RequestParams.MDN;

        var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + '&InitialMessage=' + initialMessage,
                headers: {
                    'Cookie': req.sessionCookie,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            },

            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    chunk = JSON.parse(chunk);
                    console.log('EngmntResponse:', chunk.engagementID);

                    if (chunk.engagementID) {
                        engagementModel.response.Page.status = (chunk.status === "queued" ? "accepted" : chunk.status);
                        engagementModel.response.Page.engagementID = req.engagementID = req.session.engagementID = chunk.engagementID;
                        engagementModel.response.Page.customerID = req.session.customerID = chunk.customerID;
                        // Added explictly not available in model
                        //res.send(engagementModel);
                        getMsg(req, res, function(chunk) {
                            chunk = JSON.parse(chunk);
                            //console.log("FinalResponse: " chunk);
                            //console.log('GetMessageResponse:',engagementModel.response.ModuleMap.Support.msgList[0].messageType);
                            if (chunk.message && chunk.messages[0].agentID) {
                                engagementModel.response.Page.agentName = req.session.agentName = chunk.messages[0][agent.alias]; // Added explictly not available in model
                                engagementModel.response.Page.agentID = req.session.agentID = chunk.messages[0].agentID;
                                //engagementModel.response.page.command = chunk.command; //Added explictly not available in model
                                //engagementModel.response.page.from = chunk.from; //Added explictly not available in model
                                //engagementModel.response.page.message = chunk.message; //Added explictly not available in model
                                //engagementModel.response.page.messageText = chunk.messageText; //Added explictly not available in model
                                engagementModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                engagementModel.response.ModuleMap.Support.msgList[0].agentGroupID = chunk.messages[0].agentGroupID;
                                engagementModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                engagementModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                engagementModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0][agent.alias] + "joined the conversation";
                                engagementModel.response.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0][agent.alias];
                                engagementModel.response.ModuleMap.Support.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0][agent.alias];
                            }
                            //res.send(engagementModel.response);

                        });
                        if (req.session.agentGroupID !== 'WirelessSales') {
                            dataPass(req, res, function(res) {
                                res.send(engagementModel.response);
                            });
                        } else {
                            res.send(engagementModel.response);
                        }


                    } else {
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }

                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
