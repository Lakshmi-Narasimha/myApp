// FolioDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var folioDetailsModelSchema = new mongoose.Schema({
    folioDetailsResp: {
        type: Object,
        "default": {}
    }
});

var FolioDetailsModelLookUp = mongoose.model('FolioDetailsModelLookUp', folioDetailsModelSchema);

var NewFolioDtlsModel = new FolioDetailsModelLookUp({
  "folioDetailsResp": 
                      {
                        "result" : {
                          "folioDetails": [
                            {
                              "folioId": "3128201",
                              "holderDetails": [
                                {
                                  "name": "Shankar S",
                                  "type": "Firstholder",
                                  "kycStatus": "KYC - Registered",
                                  "pan": "ELKI1234EF"
                                },
                                {
                                  "name": "Shankar Narayan",
                                  "type": "Secondholder",
                                  "kycStatus": "KYC - Registered",
                                  "pan": "ELKI1234EF"
                                }
                              ]
                            },
                            {
                              "folioId": "3128203",
                              "holderDetails": [
                                {
                                  "name": "Shankar Sh",
                                  "type": "Firstholder",
                                  "kycStatus": "KYC - Registered",
                                  "pan": "ELKI1234EF"
                                },
                                {
                                  "name": "Shankar Narayan l",
                                  "type": "Secondholder",
                                  "kycStatus": "KYC - Not Registered",
                                  "pan": "ELKI1234EF"
                                }
                              ]
                            },
                            {
                              "folioId": "3128202",
                              "holderDetails": [
                                {
                                  "name": "Shankar S",
                                  "type": "Firstholder",
                                  "kycStatus": "KYC - Not Registered",
                                  "pan": "ELKI1234EF"
                                }
                              ]
                            }
                          ]
                        }
                      }           
             
    });

FolioDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FolioDetailsModelLookUp table, please contact admin...');
    } else {
        FolioDetailsModelLookUp.remove({}, function(err) {
            console.log('FolioDetailsModelLookUp collection removed');
            NewFolioDtlsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating FolioDetailsModelLookUp table, please contact admin...');
                }
                console.log('FolioDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FolioDetailsModelLookUp;