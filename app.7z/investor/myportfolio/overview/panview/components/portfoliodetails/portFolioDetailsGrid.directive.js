/**
 * @ngdoc directive
 * @name portFolioDetailsGrid
 * @requires investorEventConstants
 * @requires panViewModel
 * @requires 
 * @requires 
 * @requires 
 * @description
 *
 **/
/*global _ */
'use strict';
var portFolioDetailsGrid = function(panViewModel, investorDashboardDetailsModel) {
    return {
        template: require('./portFolioDetailsGrid.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        link: function(scope) {

            scope.gridData = [];
            /*_.map(unitHolderModel.getUnitHolderKeyValueList(), function(obj) {
                if (obj.key === 'PAN') {
                    scope.panNumber = obj.value;
                }
            });*/
            var profileData = investorDashboardDetailsModel.getDashboardData();
            scope.panNumber = profileData.profileDetails ? profileData.profileDetails.pan : '';
            var rows = panViewModel.getPanViewDtls().portfolioDetails.rows;

            _.each(rows, function(panViewData) {
                var gridRow = {};
                gridRow.folioNumber = panViewData.folioId;
                gridRow.ModeofHolding = panViewData.holidingType;
                gridRow.CurrentCost = panViewData.currentCost;
                gridRow.CurrentValue = panViewData.currentValue;
                gridRow.AccessLevel = panViewData.accessLevel;
                gridRow.Returns = panViewData.returns;
                scope.gridData.push(gridRow);


            });
            // var statusTemplate = '<div uib-popover-template="" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'
            var statusTemplate = '<div uib-popover-template="\'folioViewTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                '<script type="text/ng-template" id="folioViewTemplate.html">' +
                '<div><button type="button" ng-click="grid.appScope.$emit(\'showFolioView\', COL_FIELD)" class="btn panel-orange-btn m0">Account Statement</button></div></script>';

            var myLastRow = {};
            myLastRow.folioNumber = panViewModel.getPanViewDtls().portfolioDetails.grandTotal.folioId;
            // myLastRow.ModeofHolding = panViewModel.getPanViewDtls().portfolioDetails.grandTotal.ModeofHolding;
            myLastRow.CurrentCost = panViewModel.getPanViewDtls().portfolioDetails.grandTotal.currentCost;
            myLastRow.CurrentValue = panViewModel.getPanViewDtls().portfolioDetails.grandTotal.currentValue;
            scope.gridData.push(myLastRow);

            // var statusTemplate = '<div uib-popover-template="" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'
            /*var statusTemplate ='<div uib-popover-template="\'folioViewTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'+
            '<script type="text/ng-template" id="folioViewTemplate.html">' +
            '<div><button type="button" ng-click="grid.appScope.$emit(\'showFolioView\', COL_FIELD)" class="btn panel-orange-btn m0">Account Statement</button></div></script>';*/
            var accessLevelTemplate = '<div class="fti-returns">Access Level<span uib-popover-template="\'accessLevelTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue"></span></div>' +
                '<script type="text/ng-template" id="accessLevelTemplate.html">' +
                '<div class="overview-tool-tip">You can execute online transactions only if you have transact access in a given folio. \'View\' access is provided for joint mode of investments or non-individual investments or for certain non-active folios. For queries, please email us at service@franklintempleton.com</div></script>';
            var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnsTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue"></span></div>' +
                '<script type="text/ng-template" id="returnsTemplate.html">' +
                '<div class="overview-tool-tip">Returns basis XIRR i.e., rate of return basis your investments at various time periods in this fund.</div></script>';

            scope.columnDefs = [{ field: 'folioNumber', displayName: '', width: '48', cellTemplate: statusTemplate, pinnedLeft: true, headerCellClass: 'fti-grid-sortDisabledHeader' },
                { field: 'folioNumber', displayName: 'Folio No', width: '139', pinnedLeft: true },
                { field: 'ModeofHolding', displayName: 'Mode of Holding', width: '175', enableSorting: true,},
                { field: 'CurrentCost', displayName: 'Current Cost', cellClass:'text-right', width: '125', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'CurrentValue', displayName: 'Current Value', cellClass:'text-right', width: '125', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'AccessLevel', displayName: '', width: '120', headerCellTemplate: accessLevelTemplate },
                { field: 'Returns', displayName: '', width: '103', headerCellTemplate: returnsTemplate }
            ];

        }

    };

};

portFolioDetailsGrid.$inject = ['panViewModel', 'investorDashboardDetailsModel'];
module.exports = portFolioDetailsGrid;
