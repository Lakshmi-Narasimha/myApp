// changeSecretQA.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ChangeSecretQASchema = new mongoose.Schema({
    changeSecretQADropdownList: {
        type: Object,
        "default": {}
    }
});

var ChangeSecretQALookUp = mongoose.model('ChangeSecretQALookUp', ChangeSecretQASchema);

var ChangeSecretQAModel = new ChangeSecretQALookUp({

  "changeSecretQADropdownList":{
    "securityQuestions": [
  {
    "code": "Q1",
    "descriptions": "Name of your closest relative"
  },
  {
    "code": "Q10",
    "descriptions": "What are the last 6 digits of your driving license"
  },
  {
    "code": "Q11",
    "descriptions": "Which is your favourite holiday destination?"
  },
  {
    "code": "Q12",
    "descriptions": "What is the name of your family doctor?"
  },
  {
    "code": "Q2",
    "descriptions": "Who is your favourite school teacher?"
  },
  {
    "code": "Q3",
    "descriptions": "What is the first name of your father?"
  },
  {
    "code": "Q4",
    "descriptions": "Where did you first meet your spouse?"
  },
  {
    "code": "Q5",
    "descriptions": "What is your most valuable possession?"
  },
  {
    "code": "Q6",
    "descriptions": "What is your favourite sport?"
  },
  {
    "code": "Q7",
    "descriptions": "What was the make of your first car?"
  },
  {
    "code": "Q8",
    "descriptions": "What is the first share that you purchased?"
  },
  {
    "code": "Q9",
    "descriptions": "What is the name of your favourite restaurant?"
  }
]}

});

ChangeSecretQALookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ChangeSecretQALookUp table, please contact admin...');
    } else {
        ChangeSecretQALookUp.remove({}, function(err) {
            console.log('ChangeSecretQALookUp collection removed');
            ChangeSecretQAModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating ChangeSecretQALookUp table, please contact admin...');
                }
                console.log('ChangeSecretQALookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ChangeSecretQALookUp;
