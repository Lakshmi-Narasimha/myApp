'use strict';

describe('Directive : Capital gains folio filter', function() {

    var rootScope, compile, scope, directiveEle, event, $window, isolatedScope, cgAccDetModel, fticgAccDetLoadInitialService;

    var cgFolioData = {
        "panFolioAccounts": [{
                    "folioId": "18507834",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "0019906346498"
                    ]
                }, {
                    "folioId": "18507836",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "0019906346500"
                    ]
                }, {
                    "folioId": "12984431",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "1529900982051"
                    ]
                }, {
                    "folioId": "18587899",
                    "latestFolio": "Y",
                    "folioAccounts": [
                        "4069906573525"
                    ]
                }],
        'folioNumber': '65376478585'
    };
        var cgfolioFilter = {
            'folioPanAccNo': '4069906573525',
            '_isInitialLoad': true,
            'dayFlag': 'CY',
        }
        var data = {
            'accountNumber': '4069906573525',
            'key': 'CY'
        };
        var folioNumber = cgFolioData.folioNumber;
    cgAccDetModel = {
        getAccFolioNumber: function() {
            return cgFolioData.folioNumber
        },
        getFolioNumbersList: function () {
            return cgFolioData.panFolioAccounts
        },
        setAccFolioNumber: function(folioNumber) {
            folioNumber = folioNumber;
        }
    }
    fticgAccDetLoadInitialService = {
        getcgaccountdetails: function(scope, cgfolioFilter) {
            return cgFolioData.panFolioAccounts
        },
        getCgFolioDetails: function(scope,cgfolioFilter) {
            return cgFolioData.panFolioAccounts
        }
    }

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('cgAccDetModel', cgAccDetModel);
            $provide.value('fticgAccDetLoadInitialService', fticgAccDetLoadInitialService);
        });
    });
    var getCompiledElement = function() {
        var element = angular.element('<ftic-capital-gain-folio-filter></ftic-capital-gain-folio-filter>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _$window_, _cgAccDetModel_, _fticgAccDetLoadInitialService_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            cgAccDetModel = _cgAccDetModel_;
            fticgAccDetLoadInitialService = _fticgAccDetLoadInitialService_;
            $window = _$window_;
            $window.ga = function() {};
            event = document.createEvent("MouseEvent");
            event.initMouseEvent("click", true, true);

            directiveEle = getCompiledElement();
            isolatedScope = directiveEle.isolateScope();
        });
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have selectedFundAccName from isolated scope', function() {
        spyOn(scope, '$broadcast').and.callThrough();
        scope.$broadcast('cgFolioNumberList');
        expect(scope.$broadcast).toHaveBeenCalledWith('cgFolioNumberList');
        expect(isolatedScope.sectionOptsFolio).toBeDefined();
        spyOn(isolatedScope, 'emitcgApply').and.callThrough();
        isolatedScope.emitcgApply();
        expect(isolatedScope.emitcgApply).toHaveBeenCalled();
        expect(isolatedScope.cgFolioData).toBeFalsy();
    });

    it('should trigger cgfolioapply', function() {
        spyOn(scope, '$emit').and.callThrough();
        scope.$emit('cgfolioapply', cgfolioFilter);
        expect(scope.$emit).toHaveBeenCalledWith('cgfolioapply', cgfolioFilter);
    });

    it('should trigger selectedValue and set data values', function() {
        spyOn(scope, '$broadcast').and.callThrough();
        scope.$broadcast('selectedValue', event, data);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedValue', event, data);
        expect(data.key).not.toBe(null);
    });
});
