define(['jquery'],function($){
    var generalError = "Please check the indicated fields";
    var errorMsg = {
        "generic": "Incomplete required field.",
    };
    var valStr = '';
    function validateInputs(frmId, validateRequired) {
        $(':text.hasPlaceholder').val('');
        var status = $("#" + frmId).commonValidate(frmId, validateRequired);
        if ($("#" + frmId).length < 1) {
            return false;
        }
        return status;
    }

    $.fn.commonValidate = function(formId, valdateRequired) {
        var validate = new $.commonValidator(formId);
        return validate.validateForm(valdateRequired);
    }

    $.commonValidator = function(formId) {
        var validator = this;
        this.errorList = {};
        this.currentForm;
        this.validateForm = function(valdateRequired) {
            validator.errorList = {};
            validator.currentForm = $('#' + formId);
            $('p.has-error', validator.currentForm).addClass("hidden");
            if (valdateRequired) {
                $(".required-group", validator.currentForm).each(function() {
                    if ($(this).is(':visible')) {
                        validator.validateRequiredGroup(this);
                    }
                });
            }
            if (!validator.isFormValid()) {
                return false;
            }
            return true;
        };

        this.validateRequiredGroup = function(element) {
            var $elem = $(element);
            var _commonDataName = $elem.attr('name');

            if ($('input[name=' + _commonDataName + ']:checked').length == 0) {
                this.errorList[$elem.attr('data-master-container')] = [];
                this.errorList[$elem.attr('data-master-container')].errMsg = errorMsg.generic;
            }
        };

        this.isFormValid = function() {
            var count = 0;
            for (i in this.errorList) {
                count++;
            }
            if (count == 0) {
                return true;
            } else {
                this.showErrors();
                return false;
            }
        };

        this.showErrors = function() {
            var context = this.currentForm;
            for (elementID in this.errorList) {
                $("div[data-for=" + elementID + "]").addClass("has-error").find("p.has-error").text(this.errorList[elementID].errMsg).removeClass("hidden");
            }
            showError();
        };
    };

    function showError(error) {
        hideMessage();
        if (!error) {
            error = generalError;
        }
        $('.errorMsg').html(error);
    }

    function hideError() {
        if ($("#error").css('display') == 'block') {
            $('#error').fadeOut('slow');
        }
    }
    function showMessage(message) {
        hideError();
        $('.warningMsg').html(message);
        $('#message').fadeIn('slow');
        setTimeout(function() {
            hideMessage();
        }, 4000);
    }

    function hideMessage() {
        if ($("#message").css('display') == 'block') {
            $('.warningMsg').html('');
            $('#message').fadeOut('slow');
        }
    }

    return {
        validateInputs:validateInputs,
        errorMsg: errorMsg,
        commonValidator : $.commonValidator,
    };
});