var config = require('/app/conf/properties/mfchatnode/config');

var getMessageModelConfig = {
    response: {
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
            "type": "Success"
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "timeToWait": null,
            "showChatHistory": false,
            "agentBusy": false
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "msgList":[],
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
                    "type": "Success"
                }
            }
        }
    },

    endResponse: {
        "ModuleMap": {
            "Support": {
                "msgList": [{
                    "messageList": [{
                        "nextmsgId": 20001,
                        "loginReq": false,
                        "messageText": "Thank you for chatting with Verizon Wireless"
                    }],
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "type": "header",
                    "msgId": 20000,
                    "messageType": "stateChange",
                    "state": "closed"
                }, {
                    "sequenceNumberInt": 20000,
                    "msgId": 20001,
                    "animationDuration": 800,
                    "type": "bot",
                    "messageList": [{
                        "nextmsgId": -1,
                        "loginReq": false,
                        "messageText": "Let me know if you need anything else. I'm always here for you."
                    }]
                }],
                "startMsgId": 20000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "2edfe2c1-970f-4cfe-974d-d458d5f2525a",
                    "type": "Success"
                }
            }
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "timeToWait": null,           
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "2edfe2c1-970f-4cfe-974d-d458d5f2525a",
            "type": "Success"
        }
    },
    timeoutResponse:{
        "sessionOver": true,
        "Page": {
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "showChatHistory": false,
            "agentBusy": false
        },
        "ResponseInfo": {
            "locale": "en",
            "requestId": "f4bc475c-aeed-48c5-9b18-012ec35495c7",
            "buildNumber": "280",
            "code": "00000",
            "type": "Success"
        },
        "ModuleMap": {
            "Support": {
            "startMsgId": 30000,
            "searchStartIndex": 10000,
            "ResponseInfo": {
                "locale": "en",
                "requestId": "f4bc475c-aeed-48c5-9b18-012ec35495c7",
                "buildNumber": "280",
                "code": "00000",
                "type": "Success"
            },
            "msgList": [
                {
                "type": "header",
                "msgId": 30000,
                "messageType": "stateChange",
                "sequenceNumberInt": 20000,
                "state": "401",
                "animationDuration": 800,
                "messageList": [
                    {
                    "messageText": "Your chat with us timed out",
                    "nextmsgId": 30001,
                    "loginReq": false
                    }
                ]
                },
                {
                "type": "bot",
                "msgId": 30001,
                "sequenceNumberInt": 20000,
                "animationDuration": 800,
                "messageList": [
                    {
                    "content": "Oops. Your chat with us was interrupted",
                    "nextmsgId": 30002,
                    "loginReq": false
                    }
                ]
                },
                {
                "type": "content",
                "msgId": 30002,
                "sequenceNumberInt": 20000,
                "animationDuration": 800,
                "messageList": [
                    {
                    "content": "Do you want to start a new chat?",
                    "nextmsgId": -1,
                    "childType": "contentTitle",
                    "animationDuration": 800,
                    "loginReq": false
                    },
                    {
                    "content": "Yes, please",
                    "nextmsgId": 30004,
                    "childType": "contentOption",
                    "loginReq": false
                    },
                    {
                    "content": "No, thanks",
                    "nextmsgId": 30005,
                    "childType": "contentOption",
                    "loginReq": false
                    }
                ]
                },
                {
                "type": "userMessage",
                "msgId": 30004,
                "sequenceNumberInt": 20000,
                "animationDuration": 800,
                "messageList": [
                    {
                    "messageText": "Chat with an expert",
                    "nextmsgId": 30006,
                    "loginReq": false
                    }
                ]
                },
                {
                "type": "userMessage",
                "msgId": 30005,
                "sequenceNumberInt": 20000,
                "animationDuration": 800,
                "messageList": [
                    {
                    "content": "No, Thanks",
                    "nextmsgId": -1,
                    "loginReq": false
                    }
                ]
                },
                {
                "type": "condition",
                "msgId": 30006,
                "sequenceNumberInt": 20000,
                "animationDuration": 800,
                "messageList": [
                    {
                    "messageText": "Got it. Hold on as I find the right person to help you.",
                    "nextmsgId": -1,
                    "condition": "STARTCHAT",
                    "loginReq": false
                    }
                ]
                }
            ]
            }
        }
    },
    emptyResponse: {
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
            "type": "Success"
        },
        "Page": {
            "status": "accepted",
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "getMessage",
            "timeToWait": null,
            "showChatHistory": false,
            "agentBusy": false
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 10003,
                "searchStartIndex": 10003,
                "msgList": [],                
                "ResponseInfo": {
                    "locale": "en",
                    "buildNumber": "207",
                    "code": "00000",
                    "requestId": "d2c221d2-502a-402a-b2fd-2881fca6d9a5",
                    "type": "Success"
                }
            }
        }
    }
};

module.exports = getMessageModelConfig;
