/**
 * @ngdoc property
 * @name FundDetailsController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display fund details for sip and lumpsum
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function FundDetailsController($scope, $state, fticLoggerMessage, loggerConstants, transactModel, buildPlanModelService, transactEventConstants, planSmartSolution, $filter, eventConstants, TransactConstant, configUrlModel, appConfig, fundDetailsModel, fundDetails, toaster, $window, investorConstants, $loader) {

    var futureDay, futureYear, futureMonth, futuredate, futureInstallmentDate;

    //Date variables setting - Needed to enable step up option and to validate no.of installments
    $scope.startDate = new Date();
    var startDateMonth = $scope.startDate.getMonth();
    var startDateYear = $scope.startDate.getFullYear();
    var startDateDay = $scope.startDate.getDate();

    $scope.info = {
        heading: investorConstants.smartSolutions.INV_FUND_SELCTION
    };

    /*It includes day also*/
    $scope.oneYearDayFromToday = new Date(startDateYear + 1, startDateMonth, startDateDay);
    $scope.oneYearDayFromToday = new Date($scope.oneYearDayFromToday.toDateString());

    $scope.thirtyDaysFromToday = new Date(startDateYear, startDateMonth, startDateDay + 30);
    $scope.thirtyDaysFromToday = new Date($scope.thirtyDaysFromToday.toDateString());


    $scope.isPaperLess = false;
    $scope.isTransactNow = false;
    if (transactModel.getFlowType() === 'paperless') {
        $scope.isPaperLess = true;
    } else if (transactModel.getFlowType() === 'transactnow') {
        $scope.isTransactNow = true;
    }

    // data setting for the Popup
    $scope.popUpHeader = $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_LIMIT);
    $scope.popUpText = $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_Desc);
    $scope.btnNo = $filter('translate')(TransactConstant.buy.CANCEL_BUTTON);
    $scope.btnYes = $filter('translate')(TransactConstant.buy.DOWNLOAD_KYC_FORM);
    $scope.noEventName = 'FundLimitCancel';

    // KYC Additional Details Notification popup        
    $scope.kycDtlsText = $filter('translate')(TransactConstant.common.KYC_ADDITIONAL_DETAILS);
    // $scope.kycDtlsBtnNo= $filter('translate')(TransactConstant.common.CANCEL);
    $scope.kycDtlsBtnYes = $filter('translate')(TransactConstant.common.CONTINUE);
    $scope.kycDtlsNoEventName = 'kycDetailsCancel';

    //If user selects 'Download E-KYC' in download kyc notification popup
    var configURL = configUrlModel.getEnvUrl('MARKETING_URL'),
        transactNowUrl = appConfig[configURL] + '/#tab_tab2',
        pdfUrl = appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL;

    $scope.$on('downloadKyc', function (event, resp) {
        $scope.showNotification = false;
        $window.open(pdfUrl, '_blank');
        if ($scope.isPaperLess || $scope.isTransactNow) {
            location.href = transactNowUrl;
        } else {
            $state.go('smartSol.planSmartSolution.selectSS');
        }
    });

    //If user selects 'Cancel' in download kyc notification popup
    $scope.$on('FundLimitCancel', function () {
        $scope.showNotification = false;
        if ($scope.isPaperLess || $scope.isTransactNow) {
            location.href = transactNowUrl;
        } else {
            $state.go('smartSol.planSmartSolution.selectSS');
        }
    });


    /* If user selects 'Continue' in KYC Additional details popup */
    $scope.$on('showKycDtlsForm', function (event, data) {
        $scope.showKycDtlsNotif = false;
        if (transactModel.isTransactNowModule) {
            $state.go('transactnow.baseNow.kycForm');
        } else if (transactModel.isPaperless) {
            $state.go('paperLess.kycAdditionalDtls');
        } else {
            $state.go('transact.base.kycForm');
        }
    });

    /*Service Integration For InvestmentAmount - Starts*/
    var requestObject = {},
        returnedObj = {};
    requestObject.bodyObj = {};
    requestObject.bodyObj.fundOptions = [];
    var regex = new RegExp(',', 'g');

    var setSIPFundOptions = function (fundDetailsArray) {

        angular.forEach(fundDetailsArray, function (value, key) {
            var fundObj = {};
            fundObj.amount = angular.isNumber(value.sipAmount) ? value.sipAmount.toString() : value.sipAmount.replace(regex, '');
            fundObj.txnType = 'SIP';
            fundObj.startDate = value.startDate;
            fundObj.endDate = value.endDate;
            fundObj.frequency = value.frequency === 'Monthly' ? 'M' : (value.frequency === 'Annually' ? 'A' : (value.frequency === 'Quaterly' ? 'Q' : value.frequency || ''));
            requestObject.bodyObj.fundOptions.push(fundObj);
        });
    };

    var setLumpsumFundOptions = function (fundDetailsArray) {
        angular.forEach(fundDetailsArray, function (value, key) {
            var fundObj = {};
            fundObj.amount = angular.isNumber(value.amount) ? value.amount.toString() : value.amount.replace(regex, '');
            fundObj.txnType = 'P';
            fundObj.startDate = '';
            fundObj.endDate = '';
            fundObj.frequency = '';
            requestObject.bodyObj.fundOptions.push(fundObj);
        });
    };

    var transactionLimitSuccess = function (data) {
        $scope.showNotification = false;
        $scope.showKycDtlsNotif = false;
        if (!$scope.transactionLimit) {
            transactModel.setKycTransactionLimit(data.allowableTxnAmount);
            $scope.transactionLimit = transactModel.getKycTransactionLimit();
        }

        if (!$scope.onFundLoad) {
            if (data.statusFlag === TransactConstant.transact.INVESTMENT_REJECTED_CODE) {
                $scope.showNotification = true;
            } else if (data.statusFlag === TransactConstant.transact.INVESTMENT_WARNING_CODE) {
                $scope.showKycDtlsNotif = true;
            } else {
                paymentDetailsRedirection();
            }
        }
    };

    var transactionLimitFailure = function (data) {
        toaster.error(data.data[0].errorDescription);
    };

    var setRequestObject = function () {
        requestObject = {};
        requestObject.bodyObj = {};
        requestObject.bodyObj.fundOptions = [];
        returnedObj = fundDetailsModel.setCommonInvProperties();
        requestObject.bodyObj.folioId = returnedObj.folioId;
        requestObject.bodyObj.panNo = returnedObj.panNo;
        requestObject.bodyObj.webRefNo = returnedObj.webRefNo;

        if (planSmartSolution.getLumpsumFunds() || planSmartSolution.getSIPFunds()) {
            if ($scope.showLumpsum) {
                setLumpsumFundOptions(planSmartSolution.getLumpsumFunds());
            } else if ($scope.showSip) {
                setSIPFundOptions(planSmartSolution.getSIPFunds());
            } else if ($scope.showBoth) {
                setLumpsumFundOptions(planSmartSolution.getLumpsumFunds());
                setSIPFundOptions(planSmartSolution.getSIPFunds());
            }
        } else {
            requestObject.bodyObj.fundOptions = [];
        }

        //Calling service with requestObject
        if (requestObject.bodyObj.panNo && requestObject.bodyObj.folioId) {
            $loader.start();
            fundDetails.fetchRvalidateInvFYLimit(requestObject)
            .then(transactionLimitSuccess, transactionLimitFailure)
            .finally(function() {

                $loader.stop();
            });
        }
    };

    /*Service Integration For InvestmentAmount - Ends*/

    transactModel.setKYCMode(true);
    // planSmartSolution.setTransactType('Combo'); //temp added
    // buildPlanModelService.setInvestmentType('Monthly');
    // planSmartSolution.setSmartSolutionDetails({
    //     'age': '25',
    //     'investmentTenure': '4',
    //     'investmentAmount': '3000',
    //     'equityPerc': '0',
    //     'fundCode': 'FICBOF',
    //     'fundName': 'Franklin India Corporate Bond Opportunities Fund',
    //     'allocPer': '100',
    //     'fundCategory': 'INCOME',
    //     'rtCode': '406',
    //     'productType': '16084',
    //     'annualizedReturn': '9.71',
    //     'schemePortfolio': '4347',
    //     'monthlySIP': '39.15',
    //     'annualSIP': '591.72',
    //     'lumpsum': '2070.79',
    //     'revisedYears': '1.92'
    // });
    // buildPlanModelService.setGoalPlanData([{
    //     'fundName': 'ABC MUTUAL FUND',
    //     'allocation': '100' + '%',
    //     'installmentDetails': {
    //         'anually': '2500',
    //         'monthly': '500000',
    //         'oneTime': '500000'
    //     },
    //     'dividendFlag': 'G', //$scope.smartSolnDetials.dividendFlag,
    //     'fundOption': '406',
    //     'nfoFlag': 'NA',
    //     'fundType': 'N',
    //     'accNo': 'NEW',
    //     'perpetualFlag': 'N' || '', //$scope.smartSolnDetials.perpetualFlag
    //     'stepUpFrequency': 'NA',
    //     'stepUpType': 'NA',
    //     'stepUpValue': 'NA',
    //     'stepUpSip': 0
    // }]);

    //For Transaction limit validation, if user is KYC-reg through Aadhar 
    $scope.isKycRegAadhar = transactModel.getKYCMode();
    $scope.$on('checkKycMode', function () {
        $scope.isKycRegAadhar = transactModel.getKYCMode();
        // Fetch transaction limit from service
        if ($scope.isKycRegAadhar) {
            setRequestObject();
        }
    });

    //On SIPForm load
    var checkKycModeOnLoad = function () {
        $scope.onFundLoad = true;
        setRequestObject();
    };
    if ($scope.isKycRegAadhar) {
        checkKycModeOnLoad();
    }

    // $state.go(planSmartSolution.getFundDetailsState());

    // var currentState = planSmartSolution.getFundDetailsState();
    // $scope.showInTransactNow = true;
    // $scope.isFromPaperLess = transactModel.isPaperLess;    
    // if (currentState == 'transactnow.baseNow.smartSolTransact.investment') {    
    //     $scope.showInTransactNow = false;
    //     $scope.showContinue = true;        
    // } else if($scope.isPaperLess){
    //     $scope.showInTransactNow = false;
    //     $scope.showContinue = false;
    //     $scope.showBack = false;
    // }else {
    //     $scope.showContinue = false;
    //     $scope.showBack = false;
    // }

    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;
    $scope.sipInvestment = {};
    $scope.sipInvestment.isFutureDateWithinRange = true;
    $scope.sipInvestment.isInvalidFutureDate = true;
    if (planSmartSolution.getTransactType() === 'Lumpsum') {
        $scope.showLumpsum = true;
    } else if (planSmartSolution.getTransactType() === 'SIP') {
        $scope.showSip = true;
    } else if (planSmartSolution.getTransactType() === 'Combo') {
        $scope.showBoth = true;
    }

    // if(currentState == 'smartSol.planSmartSolution.fundDetailsSS.investment')
    // {
    //     $scope.showContinue = true;
    //     $scope.showBack = true;
    // }

    $scope.fdCntnuBtn = function () {
        if ($scope.showSip || $scope.showBoth) {
            var datefilter = $filter('date');
            /*Future installment Validation*/
            futureInstallmentDate = $scope.sipInvestment.futureInstallmentDay + ' day - ' + datefilter($scope.sipInvestment.futureInstallmentMonth, 'MMM yyyy');
            futureMonth = $scope.sipInvestment.futureInstallmentMonth.getMonth();
            futureYear = $scope.sipInvestment.futureInstallmentMonth.getFullYear();
            futuredate = new Date(futureYear, futureMonth, $scope.sipInvestment.futureInstallmentDay);
            if (futuredate < $scope.thirtyDaysFromToday || futuredate > $scope.oneYearDayFromToday) {
                $scope.sipInvestment.isFutureDateWithinRange = false;
                return;
            } else {
                $scope.sipInvestment.isFutureDateWithinRange = true;
                addFutureInstallment();
            }
        }
        if ($scope.isKycRegAadhar || transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
            $scope.showNotification = false;
            $scope.showKycDtlsNotif = false;
            $scope.onFundLoad = false;
            setRequestObject();
        } else {
            paymentDetailsRedirection();
        }
    };

    var paymentDetailsRedirection = function () {
        // addFutureInstallment();
        // if(currentState === 'transactnow.baseNow.smartSolTransact.investment') {
        //     $scope.$emit(transactEventConstants.transact.Show_Fund);
        //     $scope.$emit('paymntDtls');
        // } else if(currentState === 'smartSol.planSmartSolution.fundDetailsSS.investment'){
        // $scope.paymentDtls.paymentDtlsState = 'smartSol.planSmartSolution.paymentdetailsSS.investment';
        $state.go('smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS');
        // } else if(currentState === 'paperLess.transact.fundDtls.smartSol.investment'){
        //     $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
        // }
    };

    $scope.fdBackBtn = function () {
        $state.go('smartSol.planSmartSolution.ssBase.goalSheetSummary');
    };

    var addFutureInstallment = function () {
        var sipFunds = [],
            datefilter = $filter('date'),
            //futureInst = ,
            middleDate = datefilter(new Date($scope.sipInvestment.futureInstallmentMonth), 'MM') + '/' + $scope.sipInvestment.defaultDaySelected.title + '/' + datefilter(new Date($scope.sipInvestment.futureInstallmentMonth), 'yyyy'),
            futureDate = datefilter(new Date(middleDate), 'dd/MM/yyyy');
        angular.forEach(planSmartSolution.getSIPFunds(), function (obj, ind) {
            var fundsParams = {};
            fundsParams = obj;
            fundsParams.firstInstallment = datefilter(new Date(), 'dd/MM/yyyy');
            fundsParams.futureDate = futureDate;
            fundsParams.futureInstallment = futureDate;
            fundsParams.startDateSS = futureDate;
            sipFunds.push(fundsParams);
        });
        planSmartSolution.setSIPFunds(sipFunds)
    };

    // $scope.$on(eventConstants.PAPERLESS_CONTINUE_CLICKED, function(){            
    //     /*if($scope.showSip || $scope.showBoth) {
    //         addFutureInstallment();
    //     }
    //     $scope.$emit(eventConstants.PAPERLESS_VALIDATED);*/
    //     $scope.fdCntnuBtn();
    // });

}

FundDetailsController.$inject = ['$scope', '$state', 'fticLoggerMessage', 'loggerConstants', 'transactModel', 'buildPlanModelService', 'transactEventConstants', 'planSmartSolution', '$filter', 'eventConstants', 'TransactConstant', 'configUrlModel', 'appConfig', 'fundDetailsModel', 'fundDetails', 'toaster', '$window', 'investorConstants', '$loader'];

module.exports = FundDetailsController;