import { Parameter } from '../_models/index';
import { Agent } from '../_models/index';
import { UserExpression } from '../_models/userexpression';

export class Intent {

    name: string;
    description: string;
    agentId: string;
    actionName: string;
    expressionList: Array<UserExpression> = [];
    paramMap: any = {};
    intentId : string;
    paramTypeList : Array<string> = [];

    // getAllExpressionList() {
    //     return this.expressionList;
    // }
    //
    // getAllParameters() {
    //     return this.paramMap;
    // }
    //
    // addUserExpressionList(pUserExpression : UserExpression) {
    //     this.expressionList.push(pUserExpression);
    // }
    //
    // removeUserExpressionById(pExpressionId : string) {
    //     var userExpressionToRemove = this.expressionList.filter((userExpression:UserExpression) => userExpression.userExpressionId === pExpressionId );
    //     var index = this.expressionList.indexOf(userExpressionToRemove[0]);
    //     this.removeTrainingStringByIndex(index);
    // }
    //
    // removeTrainingStringByIndex(pElementIndex : number) {
    //     if(pElementIndex != null && pElementIndex >=0 && pElementIndex < this.expressionList.length)
    //         this.expressionList.splice(pElementIndex, 1);
    // }
    //
    // addParameters(pParameter : Parameter) {
    //     this.lstParameters.push(pParameter);
    // }
    //
    // removeParameter(pElement : Parameter) {
    //     var index = this.lstParameters.indexOf(pElement);
    //     this.removeTrainingStringByIndex(index);
    // }
    //
    // removeParametersByIndex(pElementIndex : number) {
    //     if(pElementIndex != null && pElementIndex >=0 && pElementIndex < this.lstParameters.length)
    //         this.lstParameters.splice(pElementIndex, 1);
    // }


}
