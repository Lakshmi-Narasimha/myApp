'use strict';
describe('Controller: ReviewRedeemCtrl', function() {
    var $controller,$scope,ReviewRedeemCtrl,eventConstants,authenticationService,redeemModel;

    var advisor = false;

    beforeEach(angular.mock.module('advisor'));             

    beforeEach(inject(function($rootScope,_$controller_,_eventConstants_,_authenticationService_,_redeemModel_){  
        $controller = _$controller_;
        $scope = $rootScope.$new(); 
        
        eventConstants = _eventConstants_;
        authenticationService = _authenticationService_;
        redeemModel = _redeemModel_;
        if(advisor){
            authenticationService.setUser({                                        
                "userId" : "test123"        
            }); 
        }

        $scope.config = {};
        loadController();           
    }));    

    function loadController(){
        ReviewRedeemCtrl = $controller('ReviewRedeemCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
        expect(ReviewRedeemCtrl).toBeDefined();
    });

    it('should define the variables toTxnDetailsState,toState if investor logged in',function(){
        expect($scope.config.toTxnDetailsState).toBe('invTransact.txnDetails');
        expect($scope.config.toState).toBe('invTransact.base.redeem');  
        expect(redeemModel.getIsRedeemEdit()).toBe(false);
        advisor = true;     
    });

    it('should define the variables toTxnDetailsState,toState if advisor logged in',function(){
        expect($scope.config.toTxnDetailsState).toBe('transact.txnDetails.redeem');
        expect($scope.config.toState).toBe('transact.base.redeem');        
    });

    it('should listen the event eventConstants.ACTION_ICON_CLICKED when triggered',function(){
        spyOn($scope,"$emit");
        $scope.$broadcast(eventConstants.ACTION_ICON_CLICKED);
        expect($scope.$emit).toHaveBeenCalledWith("NAVIGATE_TO_TRANSACT", {key: 'Redeem'});        
    });
});


