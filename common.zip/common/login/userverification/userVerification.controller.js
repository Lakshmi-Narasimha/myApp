function userVerificationController($scope, $state, constants, advisorRegistrationModelService, fticStateChange) {
    $scope.otpObj = {};
    $scope.counter = 1;

    var userType = advisorRegistrationModelService.getUserForgotTypeDetails();
    if (userType === 'username') {
        $scope.headingObj = {
            text: constants.login.FORGOTTEN_USERNAME,
            displayBack: true
        };

    } else {
        $scope.headingObj = {
            text: constants.login.FORGOTTEN_PASSWORD,
            displayBack: true
        };
    }


    $scope.backBtn = function($event) {
        $event.preventDefault();

        userType === 'username' ? fticStateChange.stateChange($state, 'loginmaster.forgotusername.distributor') : fticStateChange.stateChange($state, 'loginmaster.forgotpassword.distributor');
    };
    $scope.$on('securityQuestionSelected', function() {
        fticStateChange.stateChange($state, 'loginmaster.userverification.securityquestion');
        //$state.go('loginmaster.userverification.securityquestion');
    });

    $scope.$on('otpSelected', function() {
        if ($scope.counter === 1) {
            var otpObj = {};
            var userData = advisorRegistrationModelService.getUserData();
            otpObj.mobileNo = userData.mobile; //"9440415681";
            otpObj.emailId = userData.emailId;
            otpObj.type = userData.userType;
            otpObj.guId = userData.guId;
            var postSuccess = function() {

            };

            var handleFailure = function() {


            };
            advisorRegistrationModelService.postRequestForOtpDetails(otpObj).then(postSuccess, handleFailure);


            $scope.counter = $scope.counter + 1;

        }
        fticStateChange.stateChange($state, 'loginmaster.userverification.otpverification');
        //$state.go('loginmaster.userverification.otpverification');

    });

}
userVerificationController.$inject = ['$scope', '$state', 'constants', 'advisorRegistrationModelService', 'fticStateChange'];
module.exports = userVerificationController;
