/**
 * @ngdoc property
 * @name fticConfirmModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function ConfirmPasswordModalController($scope, $uibModalStack, $filter, changeDividendModel, authenticationService, investorConstants, investorEvents, toaster, $timeout, $loader, loggerConstants, fticLoggerMessage) {
    var requiredInfoForDividendApi = changeDividendModel.getRequiredInfoForDividendOptionsApi();
    $scope.showConfirmPassword = true;
    $scope.dividendConfirmPasswordObj = {
        key: 'dividendConfirmPassword',
        text: 'Confirm Password',
        value: '',
        name: 'dividendConfirmPassword',
        type: 'password',
        min: '',
        message: '',
        isRequired: true
    };
    

    //$scope.isReloadDrop = true;   
    $scope.closeModal = function() {
        $uibModalStack.dismissAll();
        $scope.updateDividendOption();
    };
    $scope.verifyConfirmPassword = function() {

        if ($scope.dividendConfirmPasswordObj.value !== '' && $scope.dividendConfirmPasswordObj.value.length !== 0) {
            //var regexPattern = new RegExp(/^(?=.*[a-z])(?=.*\d)[a-zA-Z\d]{7,12}$/);
            var regexPattern = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,12}$/);

                var creds = { 'guId': authenticationService.getUser().guId, 'password': $scope.dividendConfirmPasswordObj.value };

                var stopLoader = function () {
                    $loader.stop();
                    $uibModalStack.dismissAll();
                };

                var checkConfirmPasswordPostPromiseSuccess = function () {
                    //$scope.showConfirmPassword = false;
                    $scope.dividendConfirmPasswordObj.value = null;
                    var getWebrefNoFailure = function (err) {
                        toaster.error(err.data[0].errorDescription);
                        $scope.updateDividendOption();
                    };

                    var getWebrefNoSuccess = function (data) {
                        

                        var postChangeDividendOptionsSuccess = function () {
                            var successMsg = 'Dividend option for Folio Number' + requiredInfoForDividendApi.folioNo + ' has been successfully changed';
                            toaster.success(successMsg);
                        };

                        var postChangeDividendOptionsFailure = function (err) {
                            toaster.error(err.data[0].errorDescription);
                            $scope.updateDividendOption();
                        };

                        $loader.start();
                        changeDividendModel.postChangeDividendOptions(data, 'N')
                        .then(postChangeDividendOptionsSuccess, postChangeDividendOptionsFailure).finally(stopLoader);
                    };

                    $loader.start();
                    changeDividendModel.postChangeDividendOptions(requiredInfoForDividendApi, 'Y')
                        .then(getWebrefNoSuccess, getWebrefNoFailure).finally(stopLoader);
 

                };

                var checkConfirmPasswordPostPromiseFailure = function (error) {
                    toaster.error(error.data[0].errorDescription);
                    $scope.updateDividendOption();
                };

                $loader.start();
                changeDividendModel.checkConfirmPasswordPost(creds).then(checkConfirmPasswordPostPromiseSuccess, checkConfirmPasswordPostPromiseFailure).finally(stopLoader);
        }
    };
    var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_ACCOUNT_SETTINGS_MODULE + ' | ' + loggerConstants.INV_CHANGE_PWD_MODAL_CONTROLLER;
    fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
}
ConfirmPasswordModalController.$inject = ['$scope', '$uibModalStack', '$filter', 'changeDividendModel', 'authenticationService', 'investorConstants', 'investorEvents', 'toaster', '$timeout', '$loader', 'loggerConstants', 'fticLoggerMessage'];

module.exports = ConfirmPasswordModalController;
