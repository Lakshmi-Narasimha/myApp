define([
    'jquery',
    'underscore',
    'backbone',
    'appcommon/analytics',
    'spinner',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'text!appmodules/contactprofile/app/templates/contactfiduciary.html',
    'errorLog', "config", 'appcommon/globalcontext',
    'appcommon/commonutility',
], function ($, _, Backbone, Analytics, Spinner, cpCommon, Dataservice, fiduciaryTemplate, ErrorLog, Config, GlobalContext, CommonUtility) {
    var $scroller, self = null, brkgProdClsCds = CommonUtility.getBrkgProdClsCds();
	var fiduciaryView = Backbone.View.extend({
    	template : _.template(fiduciaryTemplate),
    	initialize: function () {
    	    self = this;
    	    $(document).off('click', '#fiduciary-page-ebene-link').on('click', '#fiduciary-page-ebene-link', this.invokeAuthPerosnWorkflowLinkClick);
    	}, events: {
    	},
        render: function (clId, smuId) {
            var that = this;
            var _serviceCallsStack = []; 
            
            function clientServicePrefSuccess(response){
                try {
                   var servicesInProgress = 0;
                   var _results = response['results'][0];

                   var _collection = [];
            		if( _results.attributes.ClientFiduciaries === null){
                		Spinner.show();
                		Dataservice.getClientFiduciaries(clId).then(function(result){
                		    var _response = result[0]['results'];
                		    var tempArr = [];
                		    $.each(_response, function (index, record) {
                		        var relDate = new Date(_response[index].relEndDt);
                                var fidRelTypResp = _response[index].fidRelTypCd;
                		        var today = new Date();
                		        if((relDate > today) && fidRelTypResp !="016" && fidRelTypResp !="017") {
                		            _collection.push(record);
                		        }
                		    });

                		    if (_collection && _collection.length > 0 ){
                				var _tmtCollectionGlobal = [];
                				var _tmtCollectionAccount = [];
                				$.each(_collection,function(index,record){
                					if(record['specAcctCd'] == 'Y'){
                						_tmtCollectionAccount.push(record);
                					}else{
                						_tmtCollectionGlobal.push(record);
                					}
                				});
                				
                				_tmtCollectionGlobal.sort(function (r1, r2) {
              					  if (cpCommon.formatClientId(r1.granteeId) > cpCommon.formatClientId(r2.granteeId)) { 
              					    return 1;
              					  }
              					  if (cpCommon.formatClientId(r1.granteeId) < cpCommon.formatClientId(r2.granteeId)) {
              					    return -1;
              					  }
              					  return 0;
              					});
                				
                				_tmtCollectionAccount.sort(function (r1, r2) {
              					  if (cpCommon.formatClientId(r1.granteeId) > cpCommon.formatClientId(r2.granteeId)) { 
              					    return 1;
              					  }
              					  if (cpCommon.formatClientId(r1.granteeId) < cpCommon.formatClientId(r2.granteeId)) {
              					    return -1;
              					  }
              					  return 0;
              					});
                				
                				_collection = _tmtCollectionGlobal.concat(_tmtCollectionAccount);
                				
                				$.each(_collection,function(key,row){
                        			row.fidRelType = getFidRelationshipType(row.fidRelTypCd);
                        			row.clientIdFmtd = cpCommon.formatClientId(row.granteeId);
                        			
                        			if(row.fiduciaryAccountInclusions){
                        				var _fidAccounts = row.fiduciaryAccountInclusions.results;
                        				if(_fidAccounts && _fidAccounts.length>0){
                        					servicesInProgress += _fidAccounts.length;
                        					$.each(_fidAccounts,function(key1,account){
                        						Spinner.show();
                        						Dataservice.getAccountInfo(account.acctId,[401])
                        						.then(function(response){
                        							servicesInProgress--;
                        							var _accountInfo = response[0] || response;
                        							if(_accountInfo.status && _accountInfo.status == 401){
                        								_fidAccounts[key1].authorized = false;
                        								var _acctId = _fidAccounts[key1].acctId;
                        								var _acctLast12 = _acctId.substring(_acctId.length -12);
                        								var _formattedId = _acctLast12.substring(0,4)+" "+_acctLast12.substring(4,8) + " "+_acctLast12.substring(8,12) + " "+_acctId.substring(0,3);
                        								_fidAccounts[key1].acctId = _formattedId;
                        							}
                        							else{
                        								var _accntOwnrshps = [];
                            							_accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle1Txt']);
                            							_accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle2Txt']);
                            							_accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle3Txt']);
                            							_accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle4Txt']);
                            							_accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle5Txt']);
                                                        _fidAccounts[key1].ownerships = _accntOwnrshps.clean().join(" ");
                            							_fidAccounts[key1].carrierNum = _accntOwnrshps.clean().join(" ");
                            							_fidAccounts[key1].carrierNm = _accntOwnrshps.clean().join(" ");
                            							if (_accountInfo.adminCd == "134") {
                            							    var _carrierNum = "", _carrierNm = _accountInfo.carrierNm;
                            							    $.each(_accountInfo.accountIdentifier, function (indx, data) {
                            							        if (data.altAcctCtx == "ADMSRV.ACCT") {
                            							            _carrierNum = "CARRIER #" + data.altAcctId;
                            							        }

                            							    });
                            							    if (_carrierNum == "" || _carrierNum == "undefined" || _carrierNum == null) {
                            							        _carrierNum = "CARRIER #NA";
                            							    }
                            							    if (_accountInfo.carrierNm == "" || _accountInfo.carrierNm == "undefined" || _accountInfo.carrierNm == null) {
                            							        _carrierNm = "CARRIER NOT AVAILABLE"
                            							    }
                            							    _fidAccounts[key1].carrierNm = _carrierNm;
                            							    _fidAccounts[key1].carrierNum = _carrierNum;
                            							}
                            							
                            							var productCd = _accountInfo.productCd;
                            							var mediumNm = "";
                            							if(productCd == "00221" || productCd == "00222" || productCd == "00223" || productCd == "00225" || productCd == "00235" || productCd == "00238" || productCd == "00239"){
                            								mediumNm = _accountInfo.accountProduct['mediumNm'].substr(0,18)+" ("+_accountInfo.accountProduct['shortNm']+")";
                            							}else{
                            								mediumNm = _accountInfo.accountProduct['mediumNm'];
                            							}
                            							
                            							_fidAccounts[key1].accountDesc = mediumNm;
                            							_fidAccounts[key1].strategyNm = _accountInfo.accountProduct['strategyNm'];
                            							_fidAccounts[key1].brkgProdClsNm = _accountInfo.accountProduct['brkgProdClsNm'];
                            							_fidAccounts[key1].brkgProdClsCd = _accountInfo.accountProduct['brkgProdClsCd'];
                            							_fidAccounts[key1].adminCd = _accountInfo.adminCd;
                            							_fidAccounts[key1].acctId = _accountInfo.fmtId;
                            							_fidAccounts[key1].authorized = true;
                        							}
                        							if(servicesInProgress == 0){
                        								_results.set({ 'ClientFiduciaries': _collection }, { silent: true });
                        	                    		
                        								var _deceased = _results.attributes.clientPersonal.attributes.decsdInd;
                        								renderFiduciaryDetails(_collection, _deceased);
                        							}
                        							Spinner.hide();
                        						})
                        						.fail(function(err){
                        							Spinner.hide();
                        						});
                        						
                        					});
                        					
                        				}
                        				if(servicesInProgress == 0 && key == (_collection.length-1)){
            								_results.set({ 'ClientFiduciaries': _collection }, { silent: true });
            	                    		
            								var _deceased = _results.attributes.clientPersonal.attributes.decsdInd;
            								renderFiduciaryDetails(_collection, _deceased);
            							}
                        			}
                        			
                        		});
                			}else{
                				var _deceased = _results.attributes.clientPersonal.attributes.decsdInd;
                				renderFiduciaryDetails(_collection, _deceased);
                			}
                			Spinner.hide();
                		}).fail(function(err){
                			Spinner.hide();
                		});
                		
                	} else {
                	    Spinner.hide();
                		var _deceased = _results.attributes.clientPersonal.attributes.decsdInd;
                		renderFiduciaryDetails(_results.attributes.ClientFiduciaries,_deceased);
                	}
            	}catch(err){
            		ErrorLog.ErrorUtils.myError(err);
            	}
            }
            function getFidRelationshipType(fidRelTypCd){
            	try{
            		_relationShipDeatails = {
                			"001": 'Attorney in fact',
                			"002": 'Authorized signer',
                			"003": 'Authorized inquirer',
                			"004": 'Trustee',
                			"005": 'Administrator',
                			"006": 'Executor',
                			"007": 'Personal representative',
                			"008": 'Conservator',
                			"009": 'Guardian',
                			"010": 'Tutor',
                			"011": 'Authorized trader',
                			"012": 'General partner',
                			"013": 'Next friend',
                			"014": 'Bankruptcy trustee',
                			"015": 'Dual fiduciary',
                			"016": 'Beneficial owner'
                	};
                	if(fidRelTypCd && parseInt(fidRelTypCd)!= ""){
                		return _relationShipDeatails[fidRelTypCd];
                	}else{
                		return null;
                	}
            	}catch(err){
            		ErrorLog.ErrorUtils.myError(err);
            	}
            	
            }
            function renderFiduciaryDetails(collection, _deceased) {
            	try{
            		        	       	
            	    if (collection && collection.length > 0 ) {
            	        $('#cp-content-container').html(that.template({ "brkgProdClsCds": brkgProdClsCds, collection: collection, deceased: _deceased }));
                	}else{
            	        $('#cp-content-container').html(that.template({ "brkgProdClsCds": brkgProdClsCds, collection: { nodata: true }, deceased: _deceased }));
                	}
            	}catch(err){
            		ErrorLog.ErrorUtils.myError(err);
            	}
            	CommonUtility.logFisrtViewLoadTime("CP:Authorized Persons", ErrorLog);
            }
            $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
            $(".hdr-tab-buttons-wrap .bt-fid").addClass("hdr-tab-active");
                       
            _serviceCallsStack.push(Dataservice.getContactprofileInfoCache(clId));
             
            Q.all(_serviceCallsStack)
            	.then(function(response){
            		if(response && response.length>0){
            			if(response[0]){
        					clientServicePrefSuccess(response[0]);
        				}
        				
            		}
            		
            	})
            	.fail(function (error) {
            		ErrorLog.ErrorUtils.myError(error);
	            })
            	.done();     
            
            
        },
        invokeAuthPerosnWorkflowLinkClick: function () {
                        var _url = Config.getConfigProperty("eformsUrl");
            Spinner.show();
            self.callPutContextService(false).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId + "#fiduciary-update/";
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
            });
            Analytics.analytics.recordAction('contactProfileAuthorisedPersonEdit:clicked');
        },
        callPutContextService: function (async) {
            var _data = {
                putAdvsSessCntxAcctIds: null,
                putAdvsSessCntxClIds: null,
                putAdvsSessCntxDstrIds: null,
                putAdvsSessCntxGrpIds: null

            };
            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _clientId = _gContext.ContactId;
            var _clientCtx = {
                clId: _clientId,
                clCtx: "COLA.CL",
                clRole: "PrimaryClient"
            };
            _data.putAdvsSessCntxClIds = [_clientCtx];
            var _dstrCtx = {
                dstrId: _gContext.AdvisorFMID,
                dstrCtx: "DMU.DIST"
            };
            _data.putAdvsSessCntxDstrIds = [_dstrCtx];
            return Dataservice.putAdvisorSessionContext(_data, (async != undefined) ? async : true);
        }
    });
    return fiduciaryView;
});