/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolInvestmentOptions = function ($state, $timeout, buildPlanModelService,recommendedPlanModelService) {
    return {
        template: require('./smartSolInvestmentOptions.html'),
        restrict: 'E',
        replace: true,
        scope: {
            investData: '=',
            isCustomize: "=?"
        },
        controller:['$scope', function ($scope) {
            $scope.navPillsOptions = [
                {
                    btnName: "Recommended Plan"

                },
                {
                    btnName: "Build my Plan"

                }
            ];

            $scope.installment = $scope.investData.installmentDetails;
            $scope.tenorDetails = $scope.investData.details;
            $scope.btnColor = 'btn-group-sm green-btn-group pull-left';
            $scope.radios = {};

            $scope.radios.selectedVal = "Monthly";
            $scope.defaultRadioVal = $scope.installment[0].value;
            $scope.activeClass = 0;
            if (buildPlanModelService.getInvestmentType() == "Annually") {
                $scope.radios.selectedVal = buildPlanModelService.getInvestmentType();
                $scope.defaultRadioVal = $scope.installment[1].value;
                $scope.activeClass = 1;
            }
            ;

            if (buildPlanModelService.getInvestmentType() == "Monthly") {
                $scope.radios.selectedVal = buildPlanModelService.getInvestmentType();
                $scope.defaultRadioVal = $scope.installment[0].value;
                $scope.activeClass = 0;
            }
            ;

            if (buildPlanModelService.getInvestmentType() == "One time" || buildPlanModelService.getInvestmentType() == "One-time") {
                $scope.radios.selectedVal = "One time";
                $scope.defaultRadioVal = $scope.installment[2].value;
                $scope.activeClass = 2;
            }

            if(buildPlanModelService.getGoalSummaryFromState() === 'smartsolutions.planSmartSolution.goalSheetSummary' && recommendedPlanModelService.isExpectedReturn !== false)
            {
                $scope.radios.selectedVal = 'Monthly';
                $scope.defaultRadioVal = $scope.installment[0].value;
                $scope.activeClass = 0;
            }

            $scope.listenChange = function (index, radioValue) {
                $scope.activeClass = index;

                $scope.$emit("investmentType", $scope.radios.selectedVal);
                $scope.$emit("investmentValue", radioValue);
            };

            $scope.$emit("investmentType", $scope.radios.selectedVal);
            $scope.$emit("investmentValue", $scope.defaultRadioVal);
        }]
    };
};

smartSolInvestmentOptions.$inject = ['$state', '$timeout', 'buildPlanModelService','recommendedPlanModelService'];
module.exports = smartSolInvestmentOptions;