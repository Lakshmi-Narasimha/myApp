'use strict';

describe('reviewController', function() {

    var ctrl, 
        scope,
        TransactConstant,
        directiveElem;

    beforeEach(angular.mock.module('advisor'));

    beforeEach(function() {

        angular.mock.inject(function($controller, $rootScope,_TransactConstant_) {
            scope = $rootScope.$new();
            TransactConstant = _TransactConstant_;
            ctrl = $controller('reviewController', {
                $scope: scope
            });
        });

    });

    it('reviewController should be defined', function() {
        expect(ctrl).toBeDefined();
        expect(scope).toBeDefined();
    });

    it('ftic-rac-details directive should  be defined', function () {
        var racDetailsComponent = directiveElem.find('<ftic-rac-details></ftic-rac-details>');
        expect(racDetailsComponent).toBeDefined();
    });

});