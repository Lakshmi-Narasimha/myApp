/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function planSmartSolutionBaseController($scope, $state,buildPlanModelService,$uibModal,recommendedPlanModelService,recommendedPlanInitialLoader,transactModel, toaster) {
    $scope.config = {};
    $scope.config.stepsConfig = {};
    $scope.config.stepsConfig.activeStep = 1;
    $scope.config.stepsConfig.noOfSteps = 3;

    $scope.smartSolnHeader = recommendedPlanModelService.getSelectedSmartSoln();
    $scope.isNewInvestor = buildPlanModelService.isNewInvestor;
  
    $scope.config.stepIndImgs = [
        {
            key : "01",
            iconClass : 'icon-fti-plan',
            label : "Plan / Input Details"
        }, {
            key : "02",
            iconClass : 'icon-fti-recommend',
            label : "Recommendations"
        }, {
            key : '03',
            iconClass : 'icon-fti-goal',
            label : "Goal Sheet / Summary"
        }
    ];

    $scope.header.title = "Plan a Family Solutions";
    $scope.holderInfo = true;
    $scope.holderInfoArray = null;
    $scope.investorDetails =  buildPlanModelService.getInvestorSearch();
    if(transactModel.getInvestorDetails()) {
        $scope.holderInfoArray = [
            {key:"First Holder Name",value:transactModel.getInvestorDetails().custName},
            {key:"Second Holder Name",value:transactModel.getInvestorDetails().holders[1] ? transactModel.getInvestorDetails().holders[1].name : "NA"},
            {key:"Third Holder Name",value:transactModel.getInvestorDetails().holders[2] ? transactModel.getInvestorDetails().holders[2].name : "NA"},
            {key:"Folio Number",value:transactModel.getInvestorDetails().folioId},
            {key:"Mode of Holding",value:transactModel.getInvestorDetails().holdingType}
        ];   
    }
         

    $scope.panLevelInv = function(){
        $scope.$emit('showPANLevelInvModal');
    };

    $scope.showInvestorSelection = function () {
        $state.go('smartSol.planSmartSolution.selectFolio');
    };
    
}
planSmartSolutionBaseController.$inject = ['$scope', '$state','buildPlanModelService','$uibModal','recommendedPlanModelService','recommendedPlanInitialLoader','transactModel', 'toaster'];
module.exports = planSmartSolutionBaseController;