/**
 * @ngdoc factory
 * @name selectFundGrid factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var racInvestorDetailsFactory = function($filter) {

    var racInvestorDetailsFactory = {

        getFormattedInvestorDetails: function(userType, invDetails, stateUrl, dashboardDetails) {
            var _investorDetails = [];
            if (userType && (userType.toString() === '10')) {

                _investorDetails = [{
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    text: 'First Holder',
                    value: invDetails.custName
                }, {
                    text: 'PAN/PEKRN',
                    value: (dashboardDetails && dashboardDetails.pan ? dashboardDetails.pan : 'NA')
                }, {
                    text: 'Email',
                    value: (dashboardDetails && dashboardDetails.emailId ? dashboardDetails.emailId : 'NA')
                }, {
                    text: 'Mobile' + (stateUrl === '/redeem' ? ' Number' : ''), //Mobile Number - Redeem
                    value: (dashboardDetails && dashboardDetails.mobile ? dashboardDetails.mobile : 'NA')
                }, {
                    text: 'Second Holder',
                    value: (invDetails.holders.length > 1) ? $filter('fticNACheck')(invDetails.holders[1].name) : 'NA' //invDetails.holders[1].name
                }, {
                    text: 'Third Holder',
                    value: (invDetails.holders.length > 2) ? $filter('fticNACheck')(invDetails.holders[2].name) : 'NA' //invDetails.holders[2].name
                }];
            } else {
                _investorDetails = [{
                    text: 'First Holder Name',
                    value: invDetails.custName
                }, {
                    text: 'PAN',
                    value: invDetails.pan
                }, {
                    text: 'E-Mail',
                    value: invDetails.emailId
                }, {
                    text: 'Mobile',
                    value: invDetails.mobile
                }, {
                    text: 'Second Holder Name',
                    value: (invDetails.holders.length > 1 ) ? invDetails.holders[1].name : 'NA' //invDetails.holders[1].name
                }, {
                    text: 'Third Holder name',
                    value: (invDetails.holders.length > 2 ) ? invDetails.holders[2].name : 'NA' //invDetails.holders[2].name
                }];
            }
            return _investorDetails;
        },
        getExactHeaderText: function(userType) {
            if (userType && (userType.toString() === '10')) {
                return 'INV_TRANSACT_FOLIO_DETAILS';
            } else {
                return 'INVEST_DETAILS';
            }
        }
    };
    return racInvestorDetailsFactory;

};

racInvestorDetailsFactory.$inject = ['$filter'];
module.exports = racInvestorDetailsFactory;
