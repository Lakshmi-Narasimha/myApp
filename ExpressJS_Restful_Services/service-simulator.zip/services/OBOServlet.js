var fs = require('fs');
var path = require('path');
var _ = require('lodash');

var OBOServletService = function () {
    var initialDataFolder = '/initial-data/OBOServlet';

    // public functions

    this.getOBOServletInfo = function (requestData, success, error) {
        var dirPath = __dirname + initialDataFolder;
        var filePath = path.join(dirPath, requestData.fileName);
        // read the contents of the file specified in server.js and serve the response
        fs.readFile(filePath, 'utf8', function (err, data) {
            if (err) {
                // send error if file reading fails
                error(err);
            } else {
                success(JSON.parse(data));
            }
        });
    };

};

module.exports = new OBOServletService();



