/**
 * @ngdoc property
 * @name fticSwpDetailsForm Directive
 * @requires MyInvestorConstant
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the SWP Details Form.
 *
 **/
'use strict';


var fticSwpDetailsForm = function ($state, $timeout, transactEventConstants, toaster, swpInitialLoader, swpModel, reviewSwpDetailsModel, transactModel, TransactConstant, $filter, RegisteredBankInitLoader, RegisteredBankModel, ifscModel, frequencyOptionsModel, transactEvents, $stateParams, fundDetailsModel, authenticationService, $loader) {
    return {
        template: require('./swpdetailsform.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function ($scope, $element, $attrs) {
            var _userType = authenticationService.getUser().userType;
            $scope.isInvestor = authenticationService.isInvestorLoggedIn();
            $scope.ifscTextField = "ifscTextField";
            $scope.continueBtn = true;
            $scope.fundEditClick = false;
            $scope.disableCapital = false;
            $scope.disableAmount = false;
            $scope.$input = $element[0].querySelector('.fixed-amount-label input');
            $scope.fieldNames = {
                label1: $filter('translate')(TransactConstant.swp.SWP_START_DATE),
                label2: $filter('translate')(TransactConstant.swp.SWP_END_DATE)
            };
            $scope.selections = {};
            $scope.config = {};
            $scope.config.showNotification = false;
            var selectionsSwp = $scope.selections;
            $scope.inputObject = {
                key: "fixedAmount",
                text: TransactConstant.stp.FIXED_AMOUNT,
                value: "",
                name: "SwpfixedAmt",
                type: "number",
                min: 1000,
                pattern: /^[0-9]*$/,
                isRequired: false
            };

            $scope.inputChanged = function (val) {
                console.log("Value " + val);
                if (val === "fixed") {
                    $scope.inputObject.disable = false;
                    $scope.inputObject.isRequired = true;
                    angular.element($scope.$input).triggerHandler('focus');
                    frequencyOptionsModel.setAmountFormType('FIXEDAMOUNT', 'SWPFORM');
                    transactEvents.transact.publishAmountSelected($scope);
                    /**
                     * Added for Investor - Start
                     */
                    $scope.$broadcast('AMT_SELECTED', {
                        type: 'fixed'
                    });
                    /**
                     * Added for Investor - End
                     */
                }
                if (val === "capital") {
                    $scope.inputObject.isRequired = false;
                    $scope.inputObject.value = "";
                    angular.element($scope.$input).triggerHandler('blur');
                    $scope.inputObject.disable = true;
                    frequencyOptionsModel.setAmountFormType('CAPITAL', 'SWPFORM');
                    transactEvents.transact.publishAmountSelected($scope);
                    /**
                     * Added for Investor - Start
                     */
                    $scope.$broadcast('AMT_SELECTED', {
                        type: 'capital'
                    });
                    /**
                     * Added for Investor - End
                     */
                }
                if (val === 'direct-credit') {
                    $scope.ifsc_search = true;
                    /**
                     * Code Added for Investor - Works for Advisor - Start
                     */
                    if($stateParams.key === 'SWP' || transactModel.SWP_MAIN_FLAG) {
                        $scope.city = $scope.selections.city = ifscModel.getIfscGridResDet().bnkAdd;
                        $scope.brnch = $scope.selections.brnch = ifscModel.getIfscGridResDet().bankDetails;
                        $scope._ifscCode = $scope.selections._ifscCode = ifscModel.getIfscGridResDet().ifscCode;
                    }
                    /**
                     * Code Added for Investor - Works for Advisor - End
                     */
                    //ifscModel.setIfscGridResDet({});
                }
                if (val === 'cheque') {
                    $scope.ifsc_search = false;
                    /**
                     * Below Code is modified by commentig if condition for Investor - Start
                     */
                    //if ($stateParams.key == 'SWP') {
                        $scope.city = $scope.selections.city = null;
                        $scope.brnch = $scope.selections.brnch = null;
                        $scope._ifscCode = $scope.selections._ifscCode = null;
                    //}
                    /**
                     * Below Code is modified by commentig if condition for Investor - End
                     */
                }
                console.log($scope.ifsc_search)
            };
            
            $scope.$on(transactEventConstants.transact.SWP_FORM_RESET, function (event) {

                /**
                 * Condition Added for the below code to persist data on edit - Investor - Transact - SWP
                 */
                if(!transactModel.SWP_MAIN_FLAG) {
                    $scope.$broadcast(transactEventConstants.transact.FREQUENCY_FORM_RESET);
                    resetSWPForm();
                }
            });


            $scope.inputObject.disable = true;
            $scope.$on('Call_Registered_banks', function (event, data) {
                RegisteredBankInitLoader.loadAllServices($scope);
            });
            // Integrated the payment bank for the IFSC search.
            /**
             * For BankDetails - Code changed based on fundselected
             * Showing bankdetails based on fund's accountNumber
             */
            $scope.$on(transactEventConstants.transact.REGISTERED_BANK, function () {
                var _selectedFundBankAccNum = transactModel.getFundDetails().bankAccountNo;
                /**
                 * Commenting the below code as a part of CR - Start
                 */
                /*
                for (var i = 0; i < RegisteredBankModel.getRegisteredBank().paymentBank.length; i++) {
                    if (RegisteredBankModel.getRegisteredBank().paymentBank[i].defaultFlag === 'Y' && RegisteredBankModel.getRegisteredBank().paymentBank[i].pbPersonalAccountNumber === _selectedFundBankAccNum) {
                        $scope.selections.bankDetails = RegisteredBankModel.getRegisteredBank().paymentBank[i].pbBankName + " - " + RegisteredBankModel.getRegisteredBank().paymentBank[i].pbPersonalAccountNumber;
                        RegisteredBankModel.setDefaultBankDetails(RegisteredBankModel.getRegisteredBank().paymentBank[i]);
                    }
                }
                */
                /**
                 * Commenting the below code as a part of CR - End
                 */
                $scope.selections.bankDetails = _selectedFundBankAccNum;
                $scope.minSwpAmt = transactModel.getFundDetails().minSwpAmount;
                $scope.inputObject.min = $filter('removeComma')($scope.minSwpAmt);
            });
            $scope.freqOptions = [{
                title: "Monthly"
            }, {
                    title: "Yearly"
                }];
            //$scope.selections.selectedMode = 'cheque'; -- Commented as part of CR
            $scope.selections.selectedMode = '' ;
            $scope.minSwpAmt = '';
            // $scope.city = 'Mumbai';
            // $scope.brnch = 'Idgah Hill';            
            $scope.ifsc_search = false;

            $scope.$on('ifscSrchRes', function (event, data) {
                $scope.brnch = data.bankDetails;
                $scope.city = data.bnkAdd;
                /**
                 * Code Added for Investor - Works for Advisor - Start
                 */
                $scope._ifscCode = data.ifscCode;
                $scope.selections.city = $scope.city;
                $scope.selections.brnch = $scope.brnch;
                $scope.selections._ifscCode = $scope._ifscCode;
                /**
                 * Code Added for Investor - Works for Advisor - End
                 */
            });

            function SetDetailsGoReview() {
                
                $loader.start();
                swpModel.validateSWP().then(function (data) {
                    if (_userType && (_userType.toString() === '10')) {
                        $state.go('invTransact.review.swp');
                    } else {
                        $state.go('transact.review.swp');
                    }

                    transactModel.setWebRefNo(data.webRefNo);
                }, function (error) {
                    toaster.error(error.data[0].errorDescription);
                }).finally(function() {
                    $loader.stop();
                });
            }

            $scope.initialFlag = true;
            if ($scope.initialFlag) {
                $timeout(function () {
                    frequencyOptionsModel.setAmountFormType('FIXEDAMOUNT', 'SWPFORM');
                    transactEvents.transact.publishAmountSelected($scope);
                    $scope.initialFlag = false;
                });
            };

            $scope.checkRadio = function (type) {
                $scope.selectedType = type;
            }

            var SwpHandler = $scope.$on(transactEventConstants.transact.SWP_DETAILS, function (event, data) {
                var swpDataObj = swpModel.getSwpDetails().bankDetails;
            });

            var setIfscData = function(city, branch, code) {

                ifscModel.getIfscGridResDet().bnkAdd = city;
                ifscModel.getIfscGridResDet().bankDetails = branch;
                ifscModel.getIfscGridResDet().ifscCode = code;
            };

            $scope.handleIfscData = function(selections) {
                if($scope.selections.selectedMode === 'cheque') {

                    ifscModel.setIfscGridResDet({});

                }else {
                    selections.city = $scope.city;
                    selections.brnch = $scope.brnch;
                    selections._ifscCode = $scope._ifscCode;
                    //Setting New Data in IFSCModel based on confirmed selection
                    //setIfscData($scope.city, $scope.brnch, $scope._ifscCode); -- Commented as part of CR
                    // swpDetailModel.swpDetails.city = $scope.city;
                    // swpDetailModel.swpDetails.brnch = $scope.brnch;
                }
            };

            $scope.formSubmission = function(selections) {
                if ($scope.swpForm.$valid) {

                    var swpDetailModel = {};
                    swpDetailModel.investorDetails = transactModel.getInvestorDetails();
                    swpDetailModel.fundDetails = transactModel.getFundDetails();
                    swpDetailModel.swpDetails = selections;
                    if ($stateParams.key === 'INVESTORSWP') {
                        swpDetailModel.swpobj = reviewSwpDetailsModel.getReviewSwpObj();
                    }
                    reviewSwpDetailsModel.setReviewSwpObj(selections);

                    if ($scope.continueBtn === true) {
                        if ($stateParams.key === 'SWP') {
                            /**
                             * Investor Changes - As we are setting edit SWP - Start
                             */
                            var _transactDetails = angular.copy(transactModel.getTransactDetails());
                            delete _transactDetails.swpDetails.isEditSWP;
                            var result = _.isEqual(_transactDetails.swpDetails, swpDetailModel.swpDetails);
                            /**
                             * Investor Changes - As we are setting edit SWP - End
                             */
                            if (!result) {
                                $scope.config.showNotification = true;
                                var destroyHandler = $scope.$on('yes', function () {
                                    $scope.handleIfscData(selections); // Added Code for Investor
                                    transactModel.setTransactDetails(swpDetailModel);
                                    SetDetailsGoReview();
                                    $scope.config.showNotification = false;
                                    destroyHandler();
                                });

                                $scope.$on('no', function () {
                                    $scope.config.showNotification = false;
                                    /**
                                     * Code Added for Investor - Start
                                     */
                                    ifscModel.getIfscGridResDet().bnkAdd = _transactDetails.swpDetails.city;
                                    ifscModel.getIfscGridResDet().bankDetails = _transactDetails.swpDetails.brnch;
                                    ifscModel.getIfscGridResDet().ifscCode = _transactDetails.swpDetails._ifscCode;
                                    reviewSwpDetailsModel.setReviewSwpObj(_transactDetails.swpDetails); //Asssinging to get back frequency details
                                    
                                    /**
                                     * Code Added for Investor - End
                                     */
                                    editSWP();
                                });
                            } else
                                SetDetailsGoReview();
                        } else {
                            transactModel.setTransactDetails(swpDetailModel);
                            SetDetailsGoReview();
                        }
                    } else {
                        transactModel.setTransactDetails(swpDetailModel);
                        $loader.start();
                        swpModel.validateSWP().then(function (data) {
                            //transactModel.setWebRefNo(data.webRefNo);
                            $scope.$emit('postTransactTypeDetails');
                        }, function (error) {
                            toaster.error(error.data[0].errorDescription);
                        }).finally(function() {
                            $loader.stop();
                        });
                    }
                }
            };

            $scope.getSelections = function () {
                var selections = $scope.selections;
                var availableUnitsVal = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits;
                console.log("availableUnitsVal", availableUnitsVal);
                var amtStatus = false;
                if(!$stateParams.key) {
                    $scope.handleIfscData(selections);
                }
                if ($scope.selections.selectedType == "fixed") {
                    selections.swpAmtValue = $scope.inputObject.value;
                    if (availableUnitsVal < selections.swpAmtValue) {
                        amtStatus = true;
                    }
                    // -- Validation will be performed at server side
                    // if (amtStatus) {
                    //     toaster.error(TransactConstant.swp.SWP_FIXED_AMT_ERR);
                    // }

                } else if ($scope.selections.selectedType == "capital") {
                    selections.swpAmtValue = "Capital Appreciation";
                    amtStatus = false;
                }
                //if(!amtStatus) { // -- Validation will be performed at server side
                    $scope.formSubmission(selections);
                //}
                

            };

            $scope.getFormattedPayMode = function(mode) {

                if(mode === 'Directly To Bank') {
                    return 'Direct-Credit';
                } else {
                    return 'Cheque';
                }
            };

            function resetSWPForm() {
                $scope.isEditing = false;

                $scope.selections.selectedType = "";
                $scope.inputObject.value = "";
                // $scope.selections.bankDetails = "Dena Bank -001234567890";
                //$scope.selections.selectedMode = 'cheque'; -- Commented as part of CR
                $scope.selections.selectedMode = transactModel.getFundDetails().paymentMode;

                $scope.inputChanged($scope.selections.selectedMode); // Added Code for Investor
                $scope.selections.noofInstallments = 0;
                // $scope.city = 'Mumbai';
                // $scope.brnch = 'Idgah Hill'; 
                $scope.continueBtn = true;
                $scope.inputObject.value = null;
            }

            // for guest module and advisor edit SWP details...
            var editReviewSWPDetails = reviewSwpDetailsModel.getReviewSwpObj();
            editSWP();
            //console.log(editReviewSWPDetails)
            $scope.$on("validateSWPForm", function () {
                //alert('post from directive controller')
                $scope.swpForm.$submitted = true;
                $scope.getSelections();

            });

            $scope.$on("Edit_Form", function () {
                $scope.fundEditClick = true;
                editSWP();
            });

            /**
             * Code added to load persisted data on edit from Select fund to SWP - Investor - Start
             */
            $scope.$on('EDIT_SWP_FORM', function() {
                editSWP();
            });

            /**
             * Code added to load persisted data on edit from Select fund to SWP - Investor - End
             */

            function editSWP() {
                /**
                 * Changes did in this function to work as expected in investor with common functionality:
                 * below condition changed and editReviewSWPDetails.isEditSWP is set on action click
                 * isEditing = true part is commented
                 * transactModel.resetForm is removed and it is replaced with SWP_MAIN_FLAG
                 */
                if ((editReviewSWPDetails && editReviewSWPDetails.isEditSWP != null) || (transactModel.SWP_MAIN_FLAG || $stateParams.key == 'SWP')) {
                    if (editReviewSWPDetails) {
                        // if(editReviewSWPDetails.isEditSWP){
                        //     $scope.isEditing = true;
                        // }
                        $scope.selections.selectedType = editReviewSWPDetails.amountType;
                        $scope.inputObject.value = Number(editReviewSWPDetails.swpAmtValue);
                        if ($scope.inputObject.value) {
                            $scope.selections.selectedType = 'fixed';
                            if ($stateParams.key === 'INVESTORSWP') {
                                $scope.disableCapital = true;
                            }
                        } else {
                            if ($stateParams.key === 'INVESTORSWP') {
                                $scope.disableAmount = true;
                                $scope.inputObject.disable = true;
                            }
                            $scope.selections.selectedType = 'capital';
                        }
                        //$scope.selections.frequency = editReviewSWPDetails.frequency;`
                        $scope.inputChanged($scope.selections.selectedType);
                        //alert(editReviewSWPDetails.selectedMode)

                        /**
                         * commenting below code as part of CR - SWP 
                         */
                        // if (editReviewSWPDetails.selectedMode == "Direct Credit" || editReviewSWPDetails.selectedMode == "direct-credit") {
                        //     $scope.selections.selectedMode = "direct-credit";
                        //     /**
                        //      * The below Code is commented as it is no need for Investor.
                        //      * However, editReviewSWPDetails.isEditSWP is not used in adivsor or any other module except Investor
                        //      * Start
                        //      */
                        //     // if (editReviewSWPDetails.isEditSWP) {
                        //     //     var obj = ifscModel.getIfscGridResDet() || {};
                        //     //     obj.ifscCode = editReviewSWPDetails.ifscCode || '';
                        //     //     ifscModel.setIfscGridResDet(obj);
                        //     // }
                        //     /**
                        //      * 
                        //      * End
                        //      */
                        // } else {
                        //     $scope.selections.selectedMode = "cheque";
                        // }
                        $scope.selections.selectedMode = editReviewSWPDetails.selectedMode;
                        $scope.selections.bankDetails = editReviewSWPDetails.bankDetails;
                        /**
                         * The below Code is modified for Investor - Start
                         */
                        $scope.city = $scope.selections.city =  editReviewSWPDetails.city;
                        $scope.brnch = $scope.selections.brnch = editReviewSWPDetails.brnch;
                        $scope._ifscCode = $scope.selections._ifscCode = editReviewSWPDetails._ifscCode;
                        //setIfscData($scope.city, $scope.brnch, $scope._ifscCode); - Commented as part of CR

                        if (($stateParams.key == 'SWP' && editReviewSWPDetails.selectedMode == "direct-credit") || ($scope.fundEditClick == true && editReviewSWPDetails.selectedMode == "direct-credit")) {
                            if ($scope.fundEditClick == true) {
                                reviewSwpDetailsModel.setFundEditIfscStatus(true);
                                $scope.fundEditClick = false;
                            }
                            //$scope.city = $scope.selections.city = ifscModel.getIfscGridResDet().bnkAdd;
                            //$scope.brnch = $scope.selections.brnch = ifscModel.getIfscGridResDet().bankDetails;
                        }
                        /**
                         * The below Code is modified for Investor - End
                         */
                        $scope.inputChanged($scope.selections.selectedMode);
                        $scope.continueBtn = false;
                        if ($stateParams.key == 'SWP' || transactModel.SWP_MAIN_FLAG) {
                            /**
                             * Investor-Changes - Start
                             */
                            $scope.$emit("Select_Fund_Continue");
                            $scope.$broadcast("CALL_FOR_FREQ_POPULATE");
                            /**
                             * Investor-Changes - End
                             */
                            $scope.continueBtn = true;
                        }
                    } else {
                        resetSWPForm();
                    }
                }
            }
        },
        link: function (scope, iElement, iAttrs, controller) {

        }
    };
};

fticSwpDetailsForm.$inject = ['$state', '$timeout', 'transactEventConstants', 'toaster', 'swpInitialLoader', 'swpModel', 'reviewSwpDetailsModel', 'transactModel', 'TransactConstant', '$filter', 'RegisteredBankInitLoader', 'RegisteredBankModel', 'ifscModel', 'frequencyOptionsModel', 'transactEvents', '$stateParams', 'fundDetailsModel', 'authenticationService', '$loader'];
module.exports = fticSwpDetailsForm;
