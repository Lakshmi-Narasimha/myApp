/**
 * @ngdoc directive
 * @name fticKeyValueTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticKeyValueTile will display the kye value tiles for "My profile - Grant Access" .
 * 
 *
 **/

'use strict';

var keyValuePanel = function() {
    return {
            template: require('./keyValuePanel.html'),
            restrict: 'E',
            replace: true,         
            scope: {
                keyValueObject: "=",
                headerText: "@?",
                actionClass: "@?"
            },
            controller: function($scope, $element, $attrs){    
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

keyValuePanel.$inject = [];
module.exports = keyValuePanel;