'use strict';

describe('Directive: Carousel Directive', function() {

    var compile, scope, directiveElem, isoScope, validHtml;
    var getCompiledElement = function() {
        var element = angular.element('<ftic-loader></ftic-loader>');
        var compiledDirective = compile(element)(scope);
        scope.$digest();
        return compiledDirective;
    };

    //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            directiveElem = getCompiledElement();
        });

    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should be created with scope:true', function() {
        expect(directiveElem.scope()).toBeDefined();
    });

    it('should applied template', function() {
        expect(directiveElem.html()).not.toEqual('');
    });

});
