﻿define([
  'datamanager',
  'services/dataservice'
], function (DataService) {
    var testModal = Backbone.Model.extend({        
           
    });

    ////********Abstract out how data is fetched.  This instead of knowing breeze.******************
    ////Client should know nothing of data access other than BB model

    //var Accountviewmodel = function (groupId, fmId) {
    //    var accountviewmodel = dataservice.getAccountView(groupId, fmId);

    //    //Now do what you want for this model received from service
    //    accountviewmodel.newattribute = "new attribute";
    //    //
    //    //
    //}
    //var getAccountOwnershipDetails = function (accountId) { dataservice.getAccountOwnershipDetails(accountId); }

    ////*********************************************************
    return testModal;
});