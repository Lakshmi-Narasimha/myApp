/**
 * @ngdoc property
 * @name ReviewNConfirmController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display fund details for sip and lumpsum
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function ReviewNConfirmController($scope,$state,fticLoggerMessage, loggerConstants, $filter, bankDtlsModel,transactModel, planSmartSolution, paymentDetailsUtility, authenticationService, $location, TransactConstant, $cookies, eventConstants, appConfig, transactEventConstants) {
        
    $scope.reviewAndConfirmHeading = {
        heading : 'Review & Confirm'
    };    

    var isAdvisor = false,
        isPaperless = false,
        isCreatedLogin = false,
        needToGoPaymentGateway = false,
        queryParams = $location.search();    

    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;

    $scope.submit = {};
    $scope.submit.sipFormSubmitted = false;
    $scope.submit.lumpsumFormSubmitted = false;

    $scope.showDtls = {};
    $scope.showDtls.showInvDtls = false;
    $scope.showDtls.showAdvForm = false;
    $scope.showDtls.showInvestorPrefer = false;
    $scope.showDtls.showPanelHeader = false;
    $scope.showDtls.showLumpsumTransactionDtls = false;
    $scope.showDtls.showSipTransactionDtls = false;
    $scope.showDtls.requestDateAndTime = $filter('date')(new Date(), 'dd MMMM yyyy, hh:mm a');
        

    if(queryParams.hasOwnProperty('successFlag'))
    {        
        $scope.params = {
            webRefNo: queryParams.webRefNo,
            guId: queryParams.guId
        };
        $scope.reviewDtls = {};
        if($cookies.get('flowType')==="paperless")
        {
            $scope.reviewDtls.reviewDtlsState = "paperLess.transact.reviewAndConfirm.smartsol.investment";
            transactModel.setFlowType("paperless");
            isCreatedLogin = true;
        }
        else if($cookies.get('flowType')==="transactnow")
        {
            $scope.reviewDtls.reviewDtlsState = "transactnow.reviewNow.smartSol.investment";
            transactModel.setFlowType("transactnow");
        }
        if(queryParams.successFlag === "true")
        {                        
            paymentDetailsUtility.setPaymentRedirectDtls($scope);            
            if($cookies.get('isCombo')==="true")
            {                                
                planSmartSolution.setTransactType("Combo");                
                if($cookies.get('clickedOn')==="lumpsum")
                {                
                    transactModel.setSipReqParams(JSON.parse($cookies.get('pendingPostStr')));
                    $scope.params.webRefNo = transactModel.getSipReqParams().webRefNo;
                    console.log("transactModel.getSipReqParams()",transactModel.getSipReqParams());
                }
                else if($cookies.get('clickedOn')==="sip")
                {                
                    transactModel.setBuyReqParams(JSON.parse($cookies.get('pendingPostStr')));
                    $scope.params.webRefNo = transactModel.getBuyReqParams().webRefNo;
                    console.log("transactModel.getBuyReqParams()",transactModel.getBuyReqParams());
                }
                paymentDetailsUtility.setPaymentRedirectDtls($scope);
                $cookies.remove("pendingPostStr",{'domain': appConfig.DOMAIN_CONFIG});
            }
            if($cookies.get('clickedOn')==="lumpsum")
            {                
                if(planSmartSolution.getTransactType()!=="Combo")
                {
                    planSmartSolution.setTransactType("Lumpsum");    
                }                                
                $scope.showDtls.showLumpsumTransactionDtls = true;
            }
            else if($cookies.get('clickedOn')==="sip")
            {                
                if(planSmartSolution.getTransactType()!=="Combo")
                {
                    planSmartSolution.setTransactType("SIP");    
                }                                
                $scope.showDtls.showSipTransactionDtls = true;
            }                                    

        }
        else if(queryParams.successFlag === "false")
        {            
            if(queryParams.retryFlag === "false")
            {            
                $scope.showDtls.showLumsumErrMsg = queryParams.errorDescription;
                $scope.showDtls.showSipErrMsg = queryParams.errorDescription;
            }
            else if(queryParams.retryFlag === "true")
            {                
                authenticationService.setUser({"guId" : queryParams.guId});
                transactModel.isRetryPayment = true;
                transactModel.setRetryCount(queryParams.retryCount);
                paymentDetailsUtility.setPaymentRedirectDtls($scope);
            }
        }

    }
    else
    {        
        $state.go($scope.reviewDtls.reviewDtlsState);         
    }
    
    if(transactModel.getFlowType() === "advisor")
    { 
        isAdvisor = true;
    }
    else if(transactModel.getFlowType() === "paperless")
    {
        isPaperless = true;
    }   

    // isAdvisor = false;  //TEST

    if(planSmartSolution.getTransactType()==="Lumpsum")
    {
        $scope.showLumpsum = true;
    }
    else if(planSmartSolution.getTransactType()==="SIP")
    {
        $scope.showSip = true;
    }
    else if(planSmartSolution.getTransactType()==="Combo")
    {
        $scope.showBoth = true;
        if(!isAdvisor)
        {
            $cookies.put('isCombo', 'true',{'domain': appConfig.DOMAIN_CONFIG});
        }
        
    }
            
    if($scope.reviewDtls.reviewDtlsState ===  "transactnow.reviewNow.smartSol.investment")
    {
		$scope.showDtls.showInvestorPrefer = true;
    }  

    if($scope.reviewDtls.reviewDtlsState ===  "smartSol.planSmartSolution.reviewnconfirm.investment")
    {
		$scope.showDtls.showInvDtls = true;
    	$scope.showDtls.showAdvForm = true; 
    	$scope.showDtls.showPanelHeader = true;   	
    }
    $scope.$emit(transactEventConstants.transact.HIDE_PAPERLESS_BTNS);
    if($scope.reviewDtls.reviewDtlsState === "paperLess.transact.reviewAndConfirm.smartsol.investment")
    {
        $scope.showDtls.showInvDtls = true;
        $scope.showDtls.showInvestorPreferPaperless = true;        
    }
    $scope.setPaymentIntegration = function(params)
    {
        if(!isAdvisor && isGoingToPaymentGateway(params))
        {
            needToGoPaymentGateway = true;
            setPaymentIntegration();
        }
    }    

    $scope.postReviewDetails = function(transaction)
    {
        if(transaction==="lumpsum")
        {            
            postLumpsum();
            if($scope.showBoth && isGoingToPaymentGateway(transactModel.getBuyReqParams()))
            {
                $cookies.put('clickedOn', 'lumpsum',{'domain': appConfig.DOMAIN_CONFIG});
                postSip(true);
            }
        }   

        if(transaction==="sip")
        {            
            postSip();   
            if($scope.showBoth && isGoingToPaymentGateway(transactModel.getSipReqParams()))
            {
                $cookies.put('clickedOn', 'sip',{'domain': appConfig.DOMAIN_CONFIG});
                postLumpsum(true);
            }
        }

    }
    
    function postLumpsum(storeThisPostStr)
    {
        if(!$scope.submit.lumpsumFormSubmitted)
        {
            var postParams = transactModel.getBuyReqParams();
            postParams.webRefNo = transactModel.getLumpsumWebRefNo();        
            if(storeThisPostStr)
            {
                $cookies.put("pendingPostStr",postParams,{'domain': appConfig.DOMAIN_CONFIG})
            }                
            bankDtlsModel.postBuyDtls(postParams)
            .then(postLumpsumSuccess, handleFailure);    
        }
        else
        {
            postLumpsumSuccess();            
        }
        
    }

    function postSip(storeThisPostStr)
    {
        if(!$scope.submit.sipFormSubmitted)
        {
            var postParams = transactModel.getSipReqParams();            
            postParams.webRefNo = transactModel.getSipWebRefNo();        
            if(storeThisPostStr)
            {
                $cookies.put("pendingPostStr",postParams,{'domain': appConfig.DOMAIN_CONFIG})
            }        
            bankDtlsModel.postSysBuy(postParams)
            .then(postSipSuccess, handleFailure);
        }
        else
        {
            postSipSuccess();
        }        
    }        

    function postLumpsumSuccess(data)
    {        
        $scope.submit.lumpsumFormSubmitted = true;          
        if(isAdvisor)
        {
            $scope.showDtls.showLumpsumTransactionDtls = true;            
        }
        else if(isPaperless)
        {
            transactModel.setSubFlowType('Lumpsum');
            if(!isCreatedLogin)
            {
                $scope.isOpenQuickLoginPop = true;    
            }
            else
            {
                checkPaymentRedirection(transactModel.getBuyReqParams());
            }            
        }
        else
        {
            checkPaymentRedirection(transactModel.getBuyReqParams());
        }
    }

    function postSipSuccess(data)
    {    
        $scope.submit.sipFormSubmitted = true;                            
        if(isAdvisor)
        {
            $scope.showDtls.showSipTransactionDtls = true;            
        }
        else if(isPaperless)
        {
            transactModel.setSubFlowType('Sip');
            if(!isCreatedLogin)
            {
                $scope.isOpenQuickLoginPop = true;    
            }
            else
            {
                checkPaymentRedirection(transactModel.getSipReqParams());
            }            
        }
        else
        {  
            checkPaymentRedirection(transactModel.getSipReqParams());
        } 
    }

    function checkPaymentRedirection(params)
    {    
        if(needToGoPaymentGateway)
        {                                
            if(!$scope.showBoth || ($scope.showBoth&&$scope.submit.lumpsumFormSubmitted&&$scope.submit.sipFormSubmitted))
            {
                submitPaymentProxyForm();    
            }
        }
        else
        {
            if(params.txnSource === TransactConstant.buy.PURCHASE)
            {
                $scope.showDtls.showLumpsumTransactionDtls = true;
            }
            else if(params.txnSource === TransactConstant.sip.SIP)
            {
                $scope.showDtls.showSipTransactionDtls = true;    
            }
        }
    }

    function handleFailure()
    {
        console.log("Post Failed")
    }

    function isGoingToPaymentGateway(params)
    {    
        var paymentMode = params.paymentMode;
        if(paymentMode === TransactConstant.common.NET_BANKING_CODE || paymentMode === TransactConstant.common.DEBIT_CARD_CODE || paymentMode === TransactConstant.common.EMANDATE_CODE)
        {
            return true;
        }
        return false;
    }    

    function setPaymentIntegration()
    {
        $scope.submitURL = transactModel.getPaymentURL();                        
        transactModel.setProxyRedirectURL($location.absUrl().split('//')[1]);   
        if(transactModel.getFlowType() === "paperless")
        {
            transactModel.setFlowIdForProxy("paperLess");     
        }
        else if(transactModel.getFlowType() === "transactnow")
        {
            transactModel.setFlowIdForProxy("transactNow");
        }  
        $scope.proxyReqObj = transactModel.getPaymentProxyReqObj();        
    }                        

    function submitPaymentProxyForm()
    {           
        $cookies.put('flowType',transactModel.getFlowType(),{'domain': appConfig.DOMAIN_CONFIG});
        document.getElementById("prxoyForm1").submit();                            
    }
    
    $scope.$on(eventConstants.CLOSE_LOGIN_POPUP, function(){
        $scope.isOpenQuickLoginPop = false;
    });

    $scope.$on(eventConstants.PAPERLESS_QUICK_LOGIN_SUCCESS, function(){        
        if(transactModel.getSubFlowType() === 'Sip')
        {
            checkPaymentRedirection(transactModel.getSipReqParams());
        }
        else if(transactModel.getSubFlowType() === 'Lumpsum')
        {
            checkPaymentRedirection(transactModel.getBuyReqParams());
        }
    });            
}

ReviewNConfirmController.$inject = ['$scope','$state','fticLoggerMessage', 'loggerConstants','$filter','bankDtlsModel','transactModel', 'planSmartSolution', 'paymentDetailsUtility', 'authenticationService', '$location', 'TransactConstant', '$cookies', 'eventConstants', 'appConfig', 'transactEventConstants'];
module.exports = ReviewNConfirmController;