﻿define([
  'jquery',
  'underscore',
  'config',
   'appmodules/nav/app/models/contactdetails',
   'appcommon/globalcontext',
   'appcommon/commonutility',
   'appcommon/constants',
   'spinner',
   'services/dataservice',
   'text!appmodules/nav/app/templates/footer.html',
   'CryptoJS'
], function ($, _, Config, NavContcactList, GlobalContext, CommonUtils, Constants, Spinner, DataService, PTFooter, CryptoJS) {
	var globalContext = GlobalContext.getInstance();
	var selContactDetails = null;
	var footerRendered = false;
	var timeOut = null;
	var counter = 0;
    var isSelectedContactExist = function (fmId, contactId) {
        if (NavContcactList.advsiorContacts.getSelectedContactDetails(fmId, contactId)) {
            return true;
        }
        else {
            return false;
        }
    };
    var getSelecetdContactdetails = function (fmId, contactId) {
    	
    	if(!selContactDetails){
    		selContactDetails = NavContcactList.advsiorContacts.getSelectedContactDetails(fmId, contactId);
    	}else if(selContactDetails.id && selContactDetails.id != contactId){
    		selContactDetails = NavContcactList.advsiorContacts.getSelectedContactDetails(fmId, contactId);
    	}
    	return selContactDetails;
    };
    var getPinnedContactNmIdInfo = function (fmId, contactId) {
        var _gContext = globalContext.getGlobalContext().Context,
                   _contactType = _gContext.ContactType,
                   _pinnedContactId = _gContext.ContactId,
                   _shortClId,
                   _pinnedContactInfo = getSelecetdContactdetails(_gContext.AdvisorFMID, _pinnedContactId),
                   _pinnedContactNm = _pinnedContactInfo.orgNm ? _pinnedContactInfo.orgNm : (_pinnedContactInfo.firstNm + " " + _pinnedContactInfo.lastNm);
        return _pinnedContactNm;
    }
    var addNewContact = function (fmId, contactObject) {
        return NavContcactList.advsiorContacts.AddContact(fmId, contactObject);
    };
    var editContact = function (fmId, contactObject) {
        return NavContcactList.advsiorContacts.AddContact(fmId, contactObject);
    };
    var changeContactAndLauchCP = function (contactId, contactType, deepLinkUrl, retryWithOBO,deeplinkParams) {
    	contactId = contactId || undefined;
    	contactType = contactType || undefined;
    	var fmID = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
    	function lauchCP(contactId, contactType) {
    		if(GlobalContext.getInstance().getGlobalContext().Context.ContactId == contactId){
    			Backbone.history.navigate("contactprofile/",true);
    		} else {
    		    var _grpId = undefined;
    		    if (deepLinkUrl) {
    		        _grpId = GlobalContext.getInstance().getGlobalContext().Context.GroupId;
    		    }
    		    console.log("Setting client id into the context.... changeContactAndLauchCP - navAPI - Launching CP");
    		    console.log("Client Information>>>>", contactId);
    		    globalContext.setContext(undefined, undefined, contactId, contactType, undefined, _grpId, false); //set Client context to the global context
    			//For toggling Search text box
    			$('body').click();
    		}
    	}
    	function getClientDetails (fmID,clientId){
    		Spinner.show();
			filter = "id eq '"+clientId+"' and ctx eq 'COLA.CL'";
        	DataService.getClients(fmID,Config.contactListLimit,filter,[404])
        	.then(function(result){
        		var actualResult = (result[0] && result[0]['results']) ? result[0]['results'] : null;
        		if(result.status == 404 || !actualResult || actualResult.length<1){
        		    if (retryWithOBO) {
        		        $.event.trigger({
        		            type: "oboretryready",
        		            message: {},
        		            time: new Date()
        		        });
        		        return;
        		    } else {
        		        getClientDetailsByGroupCall(fmID, clientId);
        		        return;        		        
        		    }
        		}
        		
        		if(!NavContcactList.advsiorContacts.getSelectedContactDetails(fmID, contactId,contactType)){
        			NavContcactList.advsiorContacts.AddContactDetails(fmID, actualResult, Constants.contactType.Client,true);
    			}
				lauchCP(clientId,Constants.contactType.Client);
        	})
        	.fail(function(error){
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(error);
        	});
    	}
    	function getClientDetailsByGroupCall (fmID,clientId){
    		Spinner.show();
        	DataService.getClientgroup(clientId, [401])
        	.then(function(result){
        		
        		if(result.status && result.status == 401){
        			Spinner.hide();
        			BootstrapDialog.alert("The selected advisor is not authorized to view the details of this client. You may need to select a different advisor before continuing.");
        			return;
				}else{
	        		var contact = [{
	        			ctx: "COLA.CL",
						firstNm: null,
						fmtNm: null,
						id: clientId,
						lastNm: null,
						orgNm: null
	        		}];
	        		if(result[0].get("orgClient") && result[0].get("orgClient").get("orgNm")){
	        			contact[0].fmtNm = result[0].get("orgClient").get("orgNm");
	        			contact[0].lastNm = result[0].get("orgClient").get("orgNm");
	        			contact[0].orgNm = result[0].get("orgClient").get("orgNm");
	        		}else{
	        			contact[0].fmtNm = result[0].get("personClient").get("clFirstNm")+" "+result[0].get("personClient").get("clLastNm");
	        			contact[0].firstNm = result[0].get("personClient").get("clFirstNm");
	        			contact[0].lastNm = result[0].get("personClient").get("clLastNm");
	        		}
	        		
	        		NavContcactList.advsiorContacts.AddContactDetails(fmID, contact, Constants.contactType.Client);
					lauchCP(clientId,Constants.contactType.Client);
				}
        	})
        	.fail(function(error){
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(error);
        	});
    	}
    		
    	if(contactId && contactId.indexOf("Contact.") == -1){
    		contactType = Constants.contactType.Client;
			
			if(!NavContcactList.advsiorContacts.getSelectedContactDetails(fmID, contactId,contactType)){
				var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
				 var _userRoles = _gContext.Roles;
				 if (_userRoles && (_userRoles.indexOf("csr") > -1 || _userRoles.indexOf("aac") > -1)) {
					  getClientDetailsByGroupCall(fmID,contactId);
				  }else{
					  getClientDetails(fmID,contactId);
				  }
			}else{
				lauchCP(contactId,contactType);
			}
    	}else{
    		Spinner.show();
    		DataService.getContactDetailsbyContactId(CommonUtils.readCookie('FMID'),contactId)
        	.then(function(response){
        		if(response[0] && response[0].attributes && response[0].attributes.clientId){
        			contactId = response[0].attributes.clientId;
        			contactType = Constants.contactType.Client;
        			if(!NavContcactList.advsiorContacts.getSelectedContactDetails(fmID, contactId, contactType)){
        				getClientDetails(fmID,contactId);
        			}else{
        				lauchCP(contactId,contactType);
        			}
        		}
        		else{
        			if(!NavContcactList.advsiorContacts.getSelectedContactDetails(CommonUtils.readCookie('FMID'), contactId, contactType)){
        				var contact = [{id:contactId,contactType:contactType,firstNm:response[0].attributes.firstName,lastNm:response[0].attributes.lastName,orgNm:((!response[0].attributes.firstName) ? response[0].attributes.lastName : null)}];
        				NavContcactList.advsiorContacts.AddContactDetailsFromContactList(CommonUtils.readCookie('FMID'), contact, Constants.contactType.NonClient,true);
        				lauchCP(contactId,contactType);
        			}else{
        				lauchCP(contactId,contactType);
        			}
        		}
        		
        		
        	})
        	.fail(function(error){
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(error);
        	});
    	}
    	
    	
    	
    		
    };
    var renderPTFooter = function(resetCounter){
    	if(resetCounter){counter = 0;}
    	$("#practicetech-footer").hide();
    	if(counter<10){
    		timeOut = setTimeout(function(){
    			if($.trim($("#practicetech-subapp").text()) != "" && !$("#spinner-overlay").is(":visible")){
    			    if (!footerRendered) {
    			        var _template = _.template(PTFooter);
    			        var _compiledTemplate = _template({ 'feedbacklink': Config.getConfigProperty('feedbacklink') });
    					$("#practicetech-footer").html(_compiledTemplate);
                    	footerRendered = true;
                    	$(window).resize(function() {
                    		adjustPTAppContainer();
                    	});
                    	$(document).off('click', '#feedback-link').on('click', '#feedback-link', handleFeedbackLinkClick);
    				}
    				$("#practicetech-footer").show();
    				clearTimeout(timeOut);
    				adjustPTAppContainer();
            	}else{
            		$("#practicetech-footer").hide();
            		renderPTFooter();
            	}
        		counter++;
    		},1000);
    	}else{
    		clearTimeout(timeOut);
    		$("#practicetech-footer").show();
    		adjustPTAppContainer();
    	}
    	
    };
    var adjustPTAppContainer = function(){
    	var singleAppDivHt = $("#practicetech-subapp").height();
		var expectedMinHeight = window.innerHeight - ($("#afinav-navbar").height()+$("#practicetech-footer").height());
			$('#practicetech-subapp').css('min-height', expectedMinHeight);
			if (window.innerHeight > 300 && window.innerHeight < 600 && singleAppDivHt < 150 && window.orientation == 0) {
			    $(".footer-conatiner").css("margin-bottom", "60px");
			} else {
			    $(".footer-conatiner").css("margin-bottom", "10px");
			}
			$('#practicetech-subapp').css({'min-height': expectedMinHeight,'padding-bottom':$("#practicetech-footer").height()+'px'});
    };
    var changeOBOAndLauchCP = function (data) {
        console.log("Setting OBO id into the context.... changeOBOAndLauchCP - navAPI ");
        console.log("Changing OBO id and setting the context", data.oboId);
        globalContext.setContext(data.oboId, true, undefined, undefined, undefined, GlobalContext.getInstance().getGlobalContext().Context.GroupId, true); //set OBO Advsior context to the global context
    	
    };
    function handleFeedbackLinkClick(evt) {
        var _smUnivrslId = CommonUtils.readCookie('SM_UNIVERSALID') || CommonUtils.readCookie('smuid'), _$target = $('#feedback-link');
        var _url = _$target.data('href'), _sha1EncrypetdId = CryptoJS.SHA1(_smUnivrslId).toString();
        window.open(_url + _sha1EncrypetdId, 'Feedback link');
    }
    var navapi = {
        isSelectedContactExist: isSelectedContactExist,
        getSelecetdContactdetails: getSelecetdContactdetails,
        addNewContact: addNewContact,
        editContact: editContact,
        changeContactAndLauchCP:changeContactAndLauchCP,
        renderPTFooter:renderPTFooter,
        changeOBOAndLauchCP: changeOBOAndLauchCP,
        getPinnedContactNmIdInfo: getPinnedContactNmIdInfo
    };
    return navapi;
});
