// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FundCompositionModelSchema = new mongoose.Schema({
    fundsCompostionResp: {
        type: Array,
        "default": []
    }
});

var FundCompositionModelLookUp = mongoose.model('FundCompositionModelLookUp', FundCompositionModelSchema);

var FundCompositionModel = new FundCompositionModelLookUp({
  fundsCompostionResp: [
      {
  "fundCompositionSummary": {
    "assetCategory": "ELSS",
    "fundsComposition": [{
      "fundsType": "Franklin India Taxshield - Direct - Growth",
      "noOfAccounts": "18099",
      "AUM": "9108.71",
      "AUMAllocation": "1.99",
      "grossSales_MTD": ""
    }, {
      "fundsType": "Franklin India Taxshield - Growth",
      "noOfAccounts": "4054",
      "AUM": "3367.43",
      "AUMAllocation": "5.37",
      "grossSales_MTD": ""
    }, {
      "fundsType": "Franklin India Taxshield - Direct - Dividend",
      "noOfAccounts": "5369",
      "AUM": "3343.75",
      "AUMAllocation": "5.41",
      "grossSales_MTD": ""
    }, {
      "fundsType": "Franklin India Taxshield - Dividend",
      "noOfAccounts": "4556",
      "AUM": "2261.89",
      "AUMAllocation": "7.99",
      "grossSales_MTD": ""
    }]
  }
}
  ]
});

FundCompositionModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FundCompositionModelLookUp table, please contact admin...');
    } else {
        FundCompositionModelLookUp.remove({}, function(err) {
            console.log('FundCompositionModelLookUp collection removed');
            FundCompositionModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating FundCompositionModelLookUp table, please contact admin...');
                }
                console.log('FundCompositionModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FundCompositionModelLookUp;
