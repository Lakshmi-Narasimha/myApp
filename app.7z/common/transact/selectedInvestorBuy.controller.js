/**
 * @ngdoc property
 * @name selectedInvestorBuyCtrl
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function selectedInvestorBuyCtrl(transactModel, TransactConstant, $state) {
    console.log('selectedInvestorBuyCtrl');
    if($state.current.url=="/buy")
    	transactModel.setTransactType(TransactConstant.buy.BUY);
    else if($state.current.url=="/sip")
    	transactModel.setTransactType(TransactConstant.sip.SIP);
}
selectedInvestorBuyCtrl.$inject = ['transactModel', 'TransactConstant', '$state'];
module.exports = selectedInvestorBuyCtrl;