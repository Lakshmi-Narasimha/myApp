/**
 * @ngdoc service
 * @name FTI FamilyPortfolio Initial Load Service
 * @requires cgAccDetModel
 * @requires investorEvents
 * @requires toaster
 * @requires $timeout
 * loggerConstants
 * $loader
 * @description
 *
 * - Handles the services and model for FamilyPortFolio content details
 *
 */
'use strict';

var fticFTUserAccessDetailsLoadInitialService = function(familyPortfolioUserAccessModel, investorEvents,  toaster, $loader) {
	var fticFTUserAccessDetailsLoadInitialService = {
		_isServicesData: false,
		loadAllServices : function (scope) {
            function fPUserAccessDetailsListSuccess(data){
				familyPortfolioUserAccessModel.setFamilyPFUserAccessList(data);
				investorEvents.accountSettings.getUserAccessDetailsList(scope);
			}
			function promiseFailure (data) {
				fticFTUserAccessDetailsLoadInitialService._isServicesData = false;
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			}
			function stopLoader() {
                $loader.stop();
            }
            $loader.start();
			familyPortfolioUserAccessModel.fetchFamilyPFUserAccessList()
			.then(fPUserAccessDetailsListSuccess, promiseFailure).finally(stopLoader);
		}
	};
	return fticFTUserAccessDetailsLoadInitialService;
};
fticFTUserAccessDetailsLoadInitialService.$inject = ['familyPortfolioUserAccessModel', 'investorEvents', 'toaster', '$loader'];
module.exports = fticFTUserAccessDetailsLoadInitialService;