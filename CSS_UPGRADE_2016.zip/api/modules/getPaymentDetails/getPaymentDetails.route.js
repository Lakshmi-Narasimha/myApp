// PaymentDetailsInfo.route.js
var express = require('express');
var router = express.Router();
var PaymentDetailsInfo = require('./getPaymentDetails.model');

// api route
var  error = {
    errorMessageCode: 500,
    errorDescription: "Something went wrong...",
    uiErrorDisplayMessage: "We weren't able to process your request. Please try again. If you still need help, contact Farmers Consumer Solutions at 1-877-327-6392",
    transactionStatus: "E",
};

var billingDataError = {
    "uiErrorDisplayMessage": "We weren't able to process your request. Please try again. If you still need help, contact Farmers Consumer Solutions at 1-877-327-6392",
    "transactionStatus": "E",
    "transactionDescription": "Invalid Zipcode",
    "transactionCode": "E4620",
    "region": null,
    "postalCode": null,
    "policies": [{
        "policyContractNumber": null,
        "lineOfBusiness": null
    }],
    "paymentPlanCode": null,
    "paymentDueDate": null,
    "outStandingAmountCurrency": null,
    "outStandingAmount": null,
    "minPaymentDueAmountCurrency": null,
    "minPaymentDueAmount": null,
    "isMultiPolicyAccount": null,
    "fullName": null,
    "city": null,
    "billingAccountNumber": null,
    "agentOfRecord": null,
    "addressLine1": null,
    "accountStatus": null
};


router.route('/getPaymentDetails')
    .post(function(req, res) {
        
        // Mandatary elements are present
        if(!req.body.zipCode && 
           !req.body.policyContractNumber &&
           !req.body.billingAccountNumber
        ) {
             res.send(error);
        }
        else {
            // use mongoose to get all nerds in the database
            var billingAccountNumber = req.body.billingAccountNumber;

            PaymentDetailsInfo.find({}, function(err, data) {
                // if there is an error retrieving, send the error. 
                // nothing after res.send(err) will execute
                if (err) {
                    res.send(err);
                } else if (!data) {  
                    res.send(billingDataError);
                } else {
                    res.json(data[0]);
                }
            });
        }

    });


module.exports = router;
