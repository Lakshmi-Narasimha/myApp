define([
    'jquery',
    'lodash',
    'backbone',
    'bootstraptypeahead',
    'q',
    'app/common/util',
    'app/common/constants',
    'app/common/views/AbstractView',
    'app/application/app',
    'app/services/awmService',
    'text!app/modules/templates/ClientSearchView.html'
], function ($, _, Backbone, BootstrapTypeahead, Q, util, constants, AbstractView, app, awmService, Template) {

    return AbstractView.extend({
        el: '#sem-app-primary-view',
        render: function () {
            this.showSpinner();
            var clientList = [];

            awmService.promiseToGetSignOnInformation().then((data) => {
                var list = data.results;
                
            _.forEach(list, function(obj) {
                var client = {
                    id: obj.id,
                    name: obj.fmtNm + ' ' + obj.id.substr(15)
                }
                clientList.push(client);
            });
            this.populateUI(clientList);
            this.hideSpinner();
        }).fail(this.handleServiceError);
            //this.populateUI();
        },
        populateUI: function (clientList) {
            this.$el.html(Template);
            var $input = $(".typeahead");
            $input.typeahead({
                source:clientList
            });
        }
    });

});
