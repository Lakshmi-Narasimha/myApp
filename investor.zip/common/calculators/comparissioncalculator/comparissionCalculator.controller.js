/**
 * @ngdoc property
 * @name Comparission Calculator Controller
 * @requires $scope
 * @requires $state
 * @requires constants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function comparissionCalculatorController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel, calculatorsConstants, comparisonCalculatorInitialService, comparisonCalculatorModel,calculatorsEventConstants) {
    $scope.init = function () {
        if($state.current && $state.current.data && $state.current.data.isAdvisor) {
          $scope.isAdvisor = $state.current.data.isAdvisor;
        };
        $scope.$emit("setBreadCrumb",{
        	cat : "funds",
        	subcat : "tools",
        	breadCrumb :{
        		label:'SIP Vs Lumpsum Calculator',
        		state : ''
        	}   
        });
        comparisonCalculatorInitialService.loadAllServices($scope);   
    };

    $scope.init();   

    $scope.statusTypes = [
        {
            label: calculatorsConstants.SIP_CAL,
            value: $state.current.parent +".sip",
            selected: false
        },
        {
            label: calculatorsConstants.LUMP_CAL,
            value: $state.current.parent +".lumpsum",
            selected: false
        } 
    ];
    
    $scope.radios = {};
    // if($scope.radios == {}){
        $scope.radios.selectedVal = $state.current.parent +".sip";
        $state.go($scope.radios.selectedVal);
    // };

     /*$scope.$on('$stateChangeSuccess',
    function(event, toState, toParams, fromState, fromParams){
        if(fromState.name == "comparissioncalculators.lumpsum" && toState.name == "comparissioncalculators.lumpsum"){            
            $scope.radios.selectedVal = "comparissioncalculators.lumpsum";
            $state.go($scope.radios.selectedVal);
        }
        if(toState.name == "comparissioncalculators" || toState.name == "comparissioncalculators.sip"){
            $scope.radios.selectedVal = "comparissioncalculators.sip";
            $state.go($scope.radios.selectedVal);
        }
        if(toState.name == "comparissioncalculators.lumpsum"){
            $scope.radios.selectedVal = "comparissioncalculators.lumpsum";
            $state.go($scope.radios.selectedVal);
        }
    });*/

    
    $scope.listenChange = function () {  
        $state.go($scope.radios.selectedVal);
    };

       $scope.$on(calculatorsEventConstants.COMPARISON_FUND_SUBMIT,function(event, calculatorReq) {
      console.log(calculatorReq);
      comparisonCalculatorModel.callComparisonCalculatorData({"comparisionCalculatorReq": calculatorReq},$scope.isAdvisor).then(function (data) {
        console.log("comparisonFundDetails");
        comparisonCalculatorModel.setComparisonCalculations(data.comparisionCalculatorResp);
        $scope.$broadcast(calculatorsEventConstants.COMPARISON_FUND_CHART);

      }, function (data) {
        console.log("ERROR")
      });
    });
    
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.

comparissionCalculatorController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsConstants', 'comparisonCalculatorInitialService', 'comparisonCalculatorModel','calculatorsEventConstants'];
module.exports = comparissionCalculatorController;