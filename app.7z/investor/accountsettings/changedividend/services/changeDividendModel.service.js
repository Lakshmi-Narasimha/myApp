/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var changeDividendModel= function(Restangular, $q, authenticationService,investorDashboardDetailsModel, configUrlModel, $http, appConfig, loggerConstants, fticLoggerMessage) {
    var _dividendDetailsData = null, _allCategoryOptions = null, _requiredInfoForDividendOption = null;
    var changeDividendModel = {
         getDividendDetailsFromApi: function(fundCategory) {
            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_ACCOUNT_SETTINGS_MODULE + ' | ' + loggerConstants.INV_CHANGE_DIVIDEND_GET_DIVIDEND_DETAILS;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

            var deferred = $q.defer();
            var params = {};                   
            params.guId = authenticationService.getUser().guId;
            params.folioPanFlag = 'P';
            params.fundCategory = fundCategory;
            params.distId='';
            var userDetails = investorDashboardDetailsModel.getDashboardData();
            if(userDetails) {
                params.folioPanNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
            }

            Restangular.one('clients/dividendSchemes').get(params).then(function(response) {
                deferred.resolve(response);             
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setDividendDetailsData : function (dividendDetailsList) {
            _dividendDetailsData = dividendDetailsList;
        },
        getDividendDetailsData : function () {
            if (!angular.isDefined(_dividendDetailsData)) {
                return null;
            }
            return _dividendDetailsData;
        },
        setAssetCategoryFilterOptions : function(options){
            
            var allCategoryOptions = [], idsSeen = {}, idSeenValue = {};
            for (var i = 0, len = options.length; i < len; ++i) {
                var category = options[i].fundCategory;
                if (idsSeen[category] !== idSeenValue) {
                    var obj = {};
                    obj.title = options[i].fundCategory;
                    allCategoryOptions.push(obj);
                    idsSeen[category] = idSeenValue;
                }
            }
            _allCategoryOptions = allCategoryOptions;
        },
        getAssetCategoryFilterOptions : function () {
            if (!angular.isDefined(_allCategoryOptions)) {
                return null;
            }
            return _allCategoryOptions;
        },
         getAssetCategoryListFromApi: function(fundCategory) {
            var deferred = $q.defer();
            var params = {};                   
            //params.guId = authenticationService.getUser().guId;
            params.groupId='fundcategory';
            Restangular.one('services/paramCodes').get(params).then(function(response) {
                deferred.resolve(response);             
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setAssetCategoryList : function(codeValueList){
            var allCategoryOptions = [];
            for (var i = 0, len = codeValueList.length; i < len; ++i) {
                var obj = {};
                obj.title = codeValueList[i].value;
                obj.code = codeValueList[i].code;
                allCategoryOptions.push(obj);
            }
            _allCategoryOptions = allCategoryOptions;
        },
        getAssetCategoryList : function () {
            if (!angular.isDefined(_allCategoryOptions)) {
                return null;
            }
            return _allCategoryOptions;
        },
        setRequiredInfoForDividendOptionsApi : function (data) {
            _requiredInfoForDividendOption = data;
        },
        getRequiredInfoForDividendOptionsApi : function () {
            if (!angular.isDefined(_requiredInfoForDividendOption)) {
                return null;
            }
            return _requiredInfoForDividendOption;
        },
        checkConfirmPasswordPost : function(creds){
            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_ACCOUNT_SETTINGS_MODULE + ' | ' + loggerConstants.INV_CHANGE_DIVIDEND_CHECK_CONFIRM_PASSWORD;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL] + 'confirmPassword', creds).then( function (data) {
                deferred.resolve(data);
            }, function (data) {
                deferred.reject(data);
            });
            return deferred.promise;
        },
        postChangeDividendOptions : function (info,validationParam) {
            var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_ACCOUNT_SETTINGS_MODULE + ' | ' + loggerConstants.INV_CHANGE_DIVIDEND_API;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer(),
             params = {},
             guidParams = {};
            params.guId = authenticationService.getUser().guId;
            if(validationParam =="N"){
                params.folioId = info.folioId;
                params.webRefNo = info.webRefNo;
            }else if(validationParam =="Y"){
                params.folioId = info.folioNo;
                params.webRefNo = '';
            }
            
            params.accountNo =info.accountNo;
            
            params.txnType = 'CHGDOP';
            params.userType = '10';
            params.makerId = '';
            params.dividendOption = 'P';
            params.validation = validationParam;
            guidParams = {
                    "guId" : authenticationService.getUser().guId,
                }
                Restangular.one('clients/changeDividend').customPOST(params, "",   guidParams, {"Content-Type":"application/json"}).then(function (responseData) {
                deferred.resolve(responseData);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        }

    };
    return changeDividendModel;
};

changeDividendModel.$inject = ['Restangular', '$q', 'authenticationService','investorDashboardDetailsModel', 'configUrlModel', '$http', 'appConfig', 'loggerConstants', 'fticLoggerMessage'];
module.exports = changeDividendModel;
