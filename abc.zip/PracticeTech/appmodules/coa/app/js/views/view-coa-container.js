define([ 'jquery', 'underscore', 'backbone', 'appmodules/ncst/app/js/utils','appcommon/globalcontext',
		'text!appmodules/coa/app/templates/coaContainer.html','appcommon/analytics' ], function($,
		_, Backbone,Utils,GlobalContext, coaContainerTemplate,Analytics) {
	var self = null;
	coa.views.Container = Backbone.View.extend({
		el : $("#practicetech-subapp"),
		id : 'practicetech-subapp',
		initialize : function() {
			self = this;
			$(document).off('click', '#user-home-view .cancel-text').on('click', '#user-home-view .cancel-text',self.handlerForCancel);
			$(document).off('click','#coa-cancel-modal .coa-btn-no,.bootstrap-dialog-close-button')
			   .on('click','#coa-cancel-modal .coa-btn-no,.bootstrap-dialog-close-button',function() {
						$('#coa-cancel-modal').modal('hide');
				  });
		},
		render : function() {
			var _compiledTemplate = _.template(coaContainerTemplate)(this.model.toJSON());
			this.$el.html(_compiledTemplate);
			self.initModals();
		},
		afterRender : function() {
			 Utils.lockForm();
             var _context = GlobalContext.getInstance().getGlobalContext().Context;
             if(_context.IsStandalone){
             	Backbone.history.navigate("coa/home"+_context.QueryString, true);
             }
             else{
             	location.hash = "coa/home";
             }
		},
		initModals: function () {
			$(document).off('click', '#coa-cancel-modal .coa-btn-yes').on('click','#coa-cancel-modal .coa-btn-yes',function() {
				if (confirm) {
					var _context = GlobalContext.getInstance().getGlobalContext().Context;
					Analytics.analytics.recordAction('coaCancel:confirmed', Analytics.analytics.SHARED_SUITE);
					if (_context.IsStandalone == true) {
						if (Utils.iOSversion() > 7 || window.chrome) {
							$('#coa-cancel-modal').modal('hide');
							var _cancelMsg = '<div class="container"><div class="row cancld-txn-msg">This transaction has been cancelled. You may now close the window.</div>';
							var _cntnr = $('#user-home-view');
							_cntnr.find('.coa-steps-wrapper,#coa-app').remove();
							_cntnr.append(_cancelMsg);
						} else {
							window.open('', '_self');
							window.close();
						}
					} else {
						$('#coa-cancel-modal').modal('hide');
						setTimeout(function() {
							var _contextualRoute = self.model.get('contextualRoute')
							location.hash = _contextualRoute;
						}, 700);

					}

				}

			});

		},
		handlerForCancel:function () {
			$('#coa-cancel-modal').modal('show');
		}
	});
	
	return coa.views.Container;
});