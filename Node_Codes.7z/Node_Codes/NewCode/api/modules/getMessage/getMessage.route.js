var express = require('express');
var https = require('https');
var config = require('/app/conf/properties/mfchatnode/config');
var logger = require('../../../config/logger');
var router = express.Router();
var getMessageModel = require('./getMessage.model');
var engagementModel = require('../engagement/engagement.model');
var apiUtils = require('../../common/apiUtils');
var myCache = require('../../../api-server');

// api route
/* Trigerring the Get Message API on request from Client */
router.route('/mfchatnode/rest/message/:engagementID')
    .post(function(req, res) {
        logger.general.info(logger.formatInfoMsg(req.session.id, "get message called by app with engagementID "+ req.session.engagementID)); 
        logger.general.info(logger.formatInBoundReqMsg(req));       
        apiUtils.getMsg(req,res,function(chunk){            
            logger.general.info(logger.formatInBoundResMsg(req, chunk));
            try{
               chunk = JSON.parse(chunk);    
            }catch(e){                
               logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json"));
               res.send(getMessageModel.emptyResponse);
            }
               
            chunk.messages = chunk.messages || [{}];
            if(chunk.messages[0] && chunk.messages[0].state){
                if(chunk.messages[0].state === 'assigned'){                              
                    req.session.agentID = engagementModel.response.Page.agentID = chunk.messages[0]['agentID'];
                    req.session.agentName = getMessageModel.response.Page.agentName = chunk.messages[0]['agent.alias'];                
                    engagementModel.response.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                    engagementModel.response.Page.customerID = req.session.customerID ; /// storing customerID into the session
                    engagementModel.ResponseInfo.topMessage = "You're chatting with "+ chunk.messages[0]['agent.alias'];
                    engagementModel.ResponseInfo.type = "Success";
                    engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                    engagementModel.msgList[0].messageList[0].messageText =  chunk.messages[0]['agent.alias'] + " joined the conversation";
                    engagementModel.response.ModuleMap.Support.startMsgId = 10000;
                    engagementModel.response.ModuleMap.Support.msgList = engagementModel.msgList;
                    engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                    req.session.getMsgRes = engagementModel.response;
                    //apiUtils.sendCmd(req, res, function(response) {});
                    apiUtils.dataPass(req, res,function(response) {});
                    logger.general.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                    logger.conversation.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                    logger.general.info(logger.formatInBoundResMsg(req, engagementModel.response));
                    res.send(engagementModel.response);
                }else if (chunk.messages[0].state === 'closed'){
                    myCache.set(req.session.engagementID+".mqtt", false);                                                 
                    if (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
                        apiUtils.surveyEligibility(req, res, function(response) {
                            if(response.eligible === true){
                                var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                getMessageModel.surveyResponse.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                                getMessageModel.surveyResponse.Page.customerID = req.session.customerID ; /// storing customerID into the session
                                getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                req.session.getMsgRes = getMessageModel.surveyResponse;
                                //apiUtils.sendCmd(req, res, function(response) {});
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                logger.general.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));   
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.surveyResponse));
                                res.send(getMessageModel.surveyResponse);
                            }else{
                                req.session.getMsgRes = getMessageModel.endResponse; 
                                //apiUtils.sendCmd(req, res, function(response) {});
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                                logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                res.send(getMessageModel.endResponse);
                            }
                            apiUtils.cleanMFCCache(req.session.engagementID);
                        }); 
                    }else{                   
                        req.session.getMsgRes = getMessageModel.endResponse;
                        //apiUtils.sendCmd(req, res, function(response) {}); 
                        logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));   
                        logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID " +req.session.engagementID));
                        logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID "+req.session.engagementID));
                        apiUtils.cleanMFCCache(req.session.engagementID); 
                        res.send(getMessageModel.endResponse);            
                    }         
                                    
                    
                }else if(chunk.messages[0].state === 'agentIsTyping'){                
                    getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                    getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                    getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                    getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = 50000;
                    getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = 50000;
                    getMessageModel.response.ModuleMap.Support.msgList[0].msgId = 50000;
                    getMessageModel.response.ModuleMap.Support.startMsgId = 50000;
                    getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type; 
                    req.session.getMsgRes = getMessageModel.response;
                    //apiUtils.sendCmd(req, res, function(response) {});
                    res.send(getMessageModel.response);
                    
                }            
            }else if(chunk.messages[0] && chunk.messages[0].messageType === 'chatLine' && parseInt(chunk.messages[0].sequenceNumber,10) >=3 ){                
                var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1); 
                if (chunk.messages[0].messageText.toLowerCase() === 'login needed') {
                    getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                    getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                    getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;     
                    req.session.getMsgRes = getMessageModel.loginNeededResponse;
                }else{
                    getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                    getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                    getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                    getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                    getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                    getMessageModel.response.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                    getMessageModel.response.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                    delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                    delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                    req.session.getMsgRes = getMessageModel.response;
                }    
            if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                    parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && 
                    parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
                    myCache.set(req.session.engagementID+".isAssisted", true);
                        apiUtils.assisted(req,res,function(response) {});
                        apiUtils.saveMDN(req,res,function(response) {});
                }
                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.session.engagementID + ' Get Message: ' + chunk.messages[0].messageText);
                //apiUtils.sendCmd(req, res, function(response) {});
                res.send(req.session.getMsgRes);
            }else{
                res.send(getMessageModel.emptyResponse);
            }  
                   
        });
    });
module.exports = router;
