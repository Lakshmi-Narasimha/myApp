'use strict';

var express = require('express');
var router = express.Router();
var FamilyPortfolioListModel = require('./getFamilyPortfolioList.model');

// api route
router.route('/profile/familyPortfolio')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        FamilyPortfolioListModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            console.log(data[0].familyPortFolioList);
            if (err) {
                res.send(err);
            } else if (data[0].familyPortFolioList.length === 0) {
                res.send(err);
            } else {
                res.json(data[0].familyPortFolioList);
            }
        });
    });
module.exports = router;
