'use strict';

var smrtsolGoalSummaryVerticalTileList = function() {
	return {
        template: require('./smrtsolGoalSummary.html'),
        restrict: 'E',
        replace: true,
        scope:{
             goalSummary :'=',
             title : "="
        },
        controller: function($scope, $element, $attrs){
             //   console.log($scope.goalSummary);
        }
    }
};

smrtsolGoalSummaryVerticalTileList.$inject = [];
module.exports = smrtsolGoalSummaryVerticalTileList;