'use strict';

describe('Directive : Account Statement Holder', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, accViewModel;
    var accountViewData = {
                'unitHolderDetails': {
                'invName': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'address': {
                    'address1': 'BUDHA VILLAGE PO ASANSOL',
                    'address2': 'OPP SITE SAMTHAR PETROL PUMP',
                    'address3': 'MAYUR VIHAR PHASE III',
                    'address4': 'HYDERABAD AP 500028',
                    'city': 'DOMEIVALI',
                    'pinCode': '400062',
                    'line1': null,
                    'line2': null,
                    'line3': null
                },
                'holders': [{
                    'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                    'pan': 'CNJQL2964N',
                    'kycStatus': 'KYC - Registered',
                    'kycSource': null,
                    'modeOfKyc': null,
                    'aadharNo': null,
                    'balAmount': null,
                    'type': 'Firstholder'
                }],
                'status': 'Individual',
                'modeofOperation': 'Single',
                'bankDetails': '57523667318/STATE BANK OF INDIA/FORT MUMBAI',
                'allBankDetails': [{
                    'bankCode': '635864358346/ Yes Bank',
                    'bankAdd': 'Nunbakkam Chennai'

                }, {
                    'bankCode': '635864358346/ HDFC Bank',
                    'bankAdd': 'Nunbakkam Chennai'

                }, {
                    'bankCode': '635864358346/ ICICI Bank',
                    'bankAdd': 'Nunbakkam Chennai'

                }],
                'modeofpayment': 'Directly To Bank'
            }
        };
    
    var getCompiledElement = function() {
        var element = angular.element('<ftic-accnt-stmt-holder></ftic-accnt-stmt-holder>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };
    
    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.inject(function(_$rootScope_, _$compile_, _accountViewModel_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            accViewModel = _accountViewModel_;

            accViewModel.setAccountViewObj({
                'unitHolderDetails': accountViewData.unitHolderDetails
            })
        });
        
        directiveEle = getCompiledElement();
        isolatedScope = directiveEle.isolateScope();
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create a separate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have defined accountStmtHolderData from isolated Scope', function() {
        var accountStmtHolderData = isolatedScope.accountStmtHolderData;
        expect(accountStmtHolderData).toBeDefined();
        expect(accountStmtHolderData.bankDetails).toBe('57523667318/STATE BANK OF INDIA/FORT MUMBAI');
        expect(accountStmtHolderData.invName).toBe('YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED');
        expect(accountStmtHolderData.modeofOperation).toBe('Single');
        expect(accountStmtHolderData.modeofpayment).toBe('Directly To Bank');
        expect(accountStmtHolderData.status).toBe('Individual');
    });

    it('should have defined verticalTileRows from isolated Scope', function() {
        var verticalTileRows = isolatedScope.verticalTileRows;
        expect(verticalTileRows).toBeDefined();
        expect(verticalTileRows[0][0].key).toBe('First Holder');
        expect(verticalTileRows[0][0].value).toBe('CNJQL2964N');
    });

    it('should have defined keyValuesArr from isolated Scope', function() {
        var keyValuesArr = isolatedScope.keyValuesArr;
        expect(keyValuesArr).toBeDefined();
        expect(keyValuesArr[0].popOver).toBe(false);
        expect(keyValuesArr[0].text).toBe('Status');
        expect(keyValuesArr[0].value).toBe('Individual');
    });

    it('should have defined bankPopover from isolated Scope', function() {
        var bankPopover = isolatedScope.bankPopover;
        expect(bankPopover).toBeDefined();
        expect(bankPopover[0].text).toBe('635864358346/ Yes Bank');
        expect(bankPopover[0].value).toBe('Nunbakkam Chennai');
    });
});
