/**
 * @ngdoc directive
 * @name accountDetailsGrid
 * @requires investorEventConstants
 * @requires accountViewModel
 * @description
 *
 * - It displays the account details grid view of account view in account statements of Valuations.
 * 
 *
 **/
'use strict';

var accountDetailsGrid = function(investorEventConstants, accountViewModel) {
    return {
        template: require('./accountDetailsGrid.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {

            var accountDetails = accountViewModel.getAccountViewObj().accountDetails;
            $scope.accountNumber = accountDetails.accountNumber;
            // $scope.accountNumber = $state.params.accountNumber;                      
            $scope.accountName = accountDetails.accountName;

            $scope.gridData = [];
            /* var topRow = {};
             topRow.date = null;
             topRow.transaction = "OPENING BALANCE"
             topRow.amount = null;
             topRow.nav = null;
             topRow.units = null;
             topRow.balanceUnits = accountDetails.gridData.openingBalance.balanceUnits;
             $scope.gridData.push(topRow)*/

            angular.forEach(accountDetails.gridData.rows, function(obj) {
                var row = {};
                row.date = obj.txnDate || '-';
                row.transaction = (obj.transaction? obj.transaction.trim():"") || '-';
                row.amount = obj.amount || '-';
                row.nav = obj.nav || '-';
                row.units = obj.units || '-';
                row.balanceUnits = obj.balanceUnits || '-';
                $scope.gridData.push(row);
            });
            $scope.columnDefs = [
                { field: 'date', displayName: 'Date', width: '140' },
                { field: 'transaction', displayName: 'Transaction', width: '225' },
                { field: 'amount', displayName: 'Amount', width: '115', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'nav', displayName: 'NAV', width: '90', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon' },
                { field: 'units', width: '80', displayName: 'Units' },
                { field: 'balanceUnits', width: '180', displayName: 'Total Units' }
            ];
        }
    };
};

accountDetailsGrid.$inject = ['investorEventConstants', 'accountViewModel'];
module.exports = accountDetailsGrid;
