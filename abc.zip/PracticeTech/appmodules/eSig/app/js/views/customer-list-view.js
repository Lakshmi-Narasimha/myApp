define(
        ['backbone',
            'config',
            'spinner',
            'appmodules/eSig/app/js/views/customer-list-item-view',
            'appmodules/eSig/app/js/collections/customer-collection',
            'appmodules/eSig/app/js/views/sign-submitted-view',
            'appmodules/eSig/app/js/collections/signature-collection',
            'appmodules/eSig/app/js/utils',
            'appmodules/eSig/app/js/audit',
            'text!appmodules/eSig/app/templates/customerList.html'],
        function(Backbone, Config, Spinner, CustomerItemView, CustomerCollection,
                SignSubmitView, SignCollection, Utils, AuditLog, TempView) {
            var custListContants = {
                "advisorContextCd": "DMU",
                "advisorLabel": "Advisor",
                "clientContextCd": "COLA",
                "clientLabel": "Signer"
            };
            var customerListView = Backbone.View
                    .extend({
                        tagName: 'div',
                        el: $("#practicetech-subapp"),
                        id: 'practicetech-subapp',
                        template: _.template(TempView),
                        initialize: function() {
                            var _that = this;
                            this.docId = null;
                           
                            if (Utils.isMobile()) {
                                if (Utils.isWindowsPlatform()) {
                                    /*
                                     * Resize handler for devices which does not
                                     * trigger orientation change event
                                     */
                                    this.endResize();
                                    setTimeout(
                                            function() {
                                                _that.startResize(function(
                                                        event) {
                                                    if (Utils.getPrevWidth() !== window.innerWidth) {
                                                        Utils.setBodySectionHt(false);
                                                        Utils.setOverlay();
                                                        _that.setContentHeight();

                                                    }

                                                });
                                            }, 100);
                                } else {
                                    this.endOrientation();
                                    this.startOrientation(function(event) {
                                        Utils.setBodySectionHt(false);
                                        Utils.setOverlay();
                                        _that.setContentHeight();

                                    });
                                }
                            } else {
                                Utils.setBodySectionHt(false);
                            }
                        },
                        events: {
                            'click #back-todoc-list-contnr': 'handlebacktoDocList'
                        },
                        render: function(docId) {
                        	window.scrollTo(0,0);
                            var _self = this, _currTime = new Date().getTime();
                            _self.docId = docId;
                            Spinner.show();
                            /*set the page name for audit log service */
                            AuditLog.setAuditLogParams({
                                "pageName": "clientPicker",
                                "docid": docId
                            });
                            CustomerCollection.reset();
                            CustomerCollection
                                    .fetch({
                                        url: Config.eSigConfig.serviceUrl + 'getDocument?'
                                                + 'docid=' + docId
                                                + '&includeImage=false&time=' + _currTime,
                                        // url:"https://eforms.qa.advisorcompass.com/eforms/auth/poc/response.json?docid=4",
                                        success: function(response) {
                                            Spinner.hide();
                                            _self.$el.html(_self.template);
                                            if(response.length > 0){
                                            	_self.createCustomerItemView(response);
                                            }else{
                                            	Utils.showErrorMsg('#doc-retrieve-fail-error');
                                            	$('.title-div').hide();
                                            }
                                        },
                                        error: function(response,xhr) {
                                        	_self.$el.html(_self.template);
                                            Spinner.hide();
                                            $('.title-div').hide();
                                            Utils.logError(xhr, true);
                                            if(xhr.status != 400){
                                            	 Utils.showErrorMsg('#signers-list-page-sysytem-error');
                                            }else{
                                            	 Utils.showErrorMsg('#esig-unauthorized-error');
                                            }
                                           
                                        }
                                    });
                            return this;
                        },
                        createCustomerItemView: function(CustCollection) {
                            var _self = this;
                            var custListHolder = _self.$('.cust-list-holder'), _label = "";
                            _.each(CustCollection.models, function(customer, index) {
                               
                            	var numberInWords = inWords(index + 1);
                            	numberInWords = (numberInWords!= undefined && numberInWords != 'overflow')? numberInWords :"";
                                var users = new CustomerItemView({
                                    model: customer
                                });
                                custListHolder.append(users.render(_self.docId).el);
                                if (customer.attributes.signerContextCd == custListContants.advisorContextCd) {
                                	_label = custListContants.advisorLabel;
                                } else if (customer.attributes.signerContextCd == custListContants.clientContextCd) {
                                	_label = numberInWords+custListContants.clientLabel;
                                } else {
                                	_label = "";
                                };
                                users.addListLabel(_label);


                            }, _self);
                            // Utils.setBodySectionHt(true);
                            _self.setContentHeight();
                            
                            /* Function to change the index into words. Eg: 1 will be given as First, 2 as Second and so on.  */
                            function inWords(num) {
                                var a = ['', 'First ', 'Second ', 'Third ', 'Fourth ', 'Fifth ', 'Sixth ', 'Seventh ', 'Eighth ', 'Nineth ', 'Tenth ', 'Eleventh ', 'Twelveth ', 'Thirteenth ', 'Fourteenth ', 'Fifteenth ', 'Sixteenth ', 'Seventeenth ', 'Eighteenth ', 'Nineteenth '];
                                var b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
                                if ((num = num.toString()).length > 2)
                                    return 'overflow';
                                var n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                                if (!n)
                                    return;
                                var str = '';
                                str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
                                str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) : '';
                                return str;
                            }
                            
                        },
                        cleanup: function() {
                            this.undelegateEvents();
                            this.$el.empty();
                        },
                        /* backto doclist */
                        handlebacktoDocList: function() {
                            AuditLog.setAuditLogParams({
                                "eventId":105
                            });
                            AuditLog.sendAudit();
                            location.hash = '#navigator/draftspage';
                        },
                        hasAllSigned: function(userCollection) {
                            var i, _hasAllSigned = true;
                            for (i = 0; i < userCollection.length; i++) {
                                if (!userCollection[i].attributes.hasSigned
                                        && userCollection[i].attributes.signerContextCd == "COLA") {
                                    _hasAllSigned = false;
                                    break;
                                }
                            }
                            return _hasAllSigned;
                        },
                        setContentHeight: function() {
                            var _$body = $("#body-section");
                            var screenHt = Math.floor($(window).innerHeight());
                            var headerHt = Math.floor($('#navigator-section')
                                    .height());
                            var footerHt = Math.floor($('.footer').height());
                            var subHeaderHt = Math
                                    .floor(_$body
                                            .find('#sign-doc-title-contnr')
                                            .outerHeight(true));
                            var title = Math.floor(_$body.find('.title-div')
                                    .outerHeight(true));
                            var bodyHt = screenHt - (headerHt + footerHt + subHeaderHt + title) - 1;

                            // console.log("screenHt:",screenHt,"headerHt:",headerHt,"bodyHt:",bodyHt,"_instrnHeight:",_instrnHeight);
                            _$body.find('.left-panel').height(bodyHt);
                            $('#body-section').css("height", "auto");
                        },
                        endOrientation: function(handler) {
                            $(window).off("orientationchange", handler);
                        },
                        startOrientation: function(handler) {
                            $(window).on("orientationchange", handler);
                        },
                        startResize: function(handler) {
                            $(window).resize(handler);
                        },
                        endResize: function(handler) {
                            $(window).off("resize", handler);
                        }
                    });
            return customerListView;
        });