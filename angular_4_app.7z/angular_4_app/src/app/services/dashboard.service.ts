import { Injectable, Inject } from '@angular/core';
import { Http, Response } from "@angular/http";
import { HttpclientService } from './httpclient.service';
import { APP_CONFIG, AppConfig } from '../app-config.module';
import { Observable } from "rxjs/Observable";
import "rxjs/Rx";

@Injectable()
export class DashboardService {

  constructor(private http: HttpclientService, @Inject(APP_CONFIG) private config: AppConfig) {
  }

  getApplications(): Observable<any> {
    return this.http
      .get(this.config.apiEndpoint + 'project')
      .map((response: Response) => {
        return response.json();
      })
      .catch(this.handleError);
  }

  getLatestProjectDeploymentDeatils(projectKey: any): Observable<any> {
    return this.http
      .get(this.config.apiEndpoint + 'result/' + projectKey)
      .map((response: Response) => {
        return response.json();
      })
      .catch(this.handleError);
  }
  getLatestBuildDeatils(key: any): Observable<any> {
    return this.http
      .get(this.config.apiEndpoint + 'result/'+key)
      .map((response: Response) => {
        return response.json();
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
