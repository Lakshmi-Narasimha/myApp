// getFamilyPortfolioList.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var FamilyPortFolioListModelSchema = new mongoose.Schema({
    familyPortFolioList: {
        type: Object,
        'default': {}
    }
});

var FamilyPortFolioListModelLookUp = mongoose.model('FamilyPortFolioListModelLookUp', FamilyPortFolioListModelSchema);

var FamilyPortFolioListModel = new FamilyPortFolioListModelLookUp({
    familyPortFolioList: {
        'primaryPan': 'ABAPL1235D',
        'approved': [{
            'custName': 'Shankar Narayan',
            'pan': 'ABAPL1235C',
            'currentCost': '2,50,000.00',
            'currentValue': '6,50,000.00'
        }, {
           
            'custName': 'Gayatri Narayan',
            'pan': 'ABAPL1235D',
            'currentCost': '2,50,000.00',
            'currentValue': '6,50,000.00'
        }],
        'pending': [{
            'refId': '345',
            'custName': 'Priya Venkatesh'
        },
        {
            'refId': '342',
            'custName': 'GiriBabu'
        }]
    }
});

FamilyPortFolioListModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FamilyPortFolioListModelLookUp table, please contact admin...');
    } else {
        FamilyPortFolioListModelLookUp.remove({}, function() {
            console.log('FamilyPortFolioListModelLookUp collection removed');
            FamilyPortFolioListModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating FamilyPortFolioListModelLookUp table, please contact admin...');
                }
                console.log('FamilyPortFolioListModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FamilyPortFolioListModelLookUp;
