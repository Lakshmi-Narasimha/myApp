/**
 * @ngdoc property
 * @name fticExistingInvPayDetails Directive
 * @description
 *
 * - This directive is responsible for displaying the Payment Details.
 *
 **/
'use strict';
var fticExistingInvPayDetails = function(bankDtlsModel, transactModel, $state, fundDetails, $filter, TransactConstant, $stateParams, sipDetailsModel, transactEventConstants, authenticationService, buildPlanModelService, paymentDetailsUtility, toaster, $loader, configUrlModel, appConfig, $window) {
    return {
        template: require('./existingInvPayDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
             reviewState : "=?",
             istermsavail: '=?'
        },
        controller:['$scope', function ($scope) {
            var accordion = "",
                validateParams = {},
                params = {},
                custBankParams = {},
                txnType = "",
                bankOptions = null,
                isNewAct = false,
                isValidForm = false,
                payMethod = "",
                isEmpty = false,
                editIconChanged = false,
                transaction = "";

            init();

            if(transactModel.isRetryPayment) {
                if($stateParams.from !=='INVESTORLEG'){
                    bankDtlsModel.resetForm();
                }
                init();
                initPayMethod();
                checkFlow();
                if(!transactModel.isNewInvestor || !transactModel.getIsNewFolio()) {
                    getPaymentBanks(txnType);
                }
                paymentDetailsUtility.getNEFTPayeeDetails(txnType);
            }

            $scope.$on(transactEventConstants.transact.Go_To_Payment_Dtls,function(event) {
                // In case of smart solutions, edit of payment details, checking for state params as form is getting reset.                
                if($stateParams.from !=='INVESTORLEG' && !transactModel.showPaymentDtlsOnNo){
                  bankDtlsModel.resetForm(); 
                }
                init();
                initPayMethod();                     
                checkFlow();
                if(transactModel.showPaymentDtlsOnNo) {
                    showPayOnNo()
                }
                if(!transactModel.isNewInvestor || !transactModel.getIsNewFolio()) {
                    getPaymentBanks(txnType);
                }                        
                paymentDetailsUtility.getNEFTPayeeDetails(txnType);
            });

            function showPayOnNo() {
                checkFlow();
                bankOptions = bankDtlsModel.getBankDetails();
                setBankFilters(bankOptions);
                paymentDetailsUtility.showSelectedBank($scope);
                savePrevSelections();
                editIconChanged = true;
            }

            $scope.payMethodChanged = function(value) {
                initPayMethod();
                disablePayOptsInit();
                bankDtlsModel.setIsNewAccount($scope.isNewAccount);
                bankDtlsModel.setPaymentMethod(value);
                bankDtlsModel.setSelectedBank(null);  //Clear any previous bank selections
                enableBankFilter(value);

                if(TransactConstant.transact.MULTIPLE_PAY_MODE !== value) {
                    bankDtlsModel.setIsMultiBankError(false);
                }
                if(TransactConstant.transact.AUTO_DEBIT !== value) {
                    bankDtlsModel.setIsAutoBankError(false);
                }
                if(TransactConstant.transact.SETUP_NEW_MANDATE !== value) {
                    bankDtlsModel.setIsNewAccBankError(false);
                }
                if(TransactConstant.transact.EXISTING_PAY_MANDATE !== value) {
                    bankDtlsModel.setIsExhausted(false);
                }
                if(TransactConstant.transact.AUTO_DEBIT !== value && TransactConstant.transact.SETUP_NEW_MANDATE !== value) {
                    bankDtlsModel.setIsFundAmountError(false);
                    bankDtlsModel.setIsFixedAmountError(false);
                    bankDtlsModel.setIsSipFreqError(false);
                }
                bankDtlsModel.setIsMultiPayMode($scope.showMultiPayMode);
            };

            $scope.$on(transactEventConstants.transact.EMANDATE_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if(bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.emandate;
                    if(bankDtls) {
                        var selectedIdx = paymentDetailsUtility.setPayment(bankDtls, data);
                        $scope.showMandateDetails = true;
                        bankDtlsModel.setEmandateDetails(bankDtls[selectedIdx]);
                    }
                } else if(data.key === 'select') {
                    $scope.showMandateDetails = false;
                }
            });

            $scope.$on(transactEventConstants.transact.NETBANK_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if(bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.netBanking;
                    paymentDetailsUtility.setPayment(bankDtls, data);
                }
            });

            $scope.$on(transactEventConstants.transact.DEBITBANK_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if(bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.debit;
                    paymentDetailsUtility.setPayment(bankDtls, data);
                }
            });

            $scope.$on(transactEventConstants.transact.NEWMANDATE_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                $scope.showNewAccount = false;
                $scope.isNewAccount = false;
                $scope.isNewMandate = true;

                if(bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    if(data.key === 'newAccount') {
                        $scope.showNewAccount = true;
                        $scope.isNewAccount = true;
                        bankDtlsModel.setPaymentMode(TransactConstant.common.EMANDATE_CODE); //Set payment mode for Setup a new e-mandate - new account option
                    } else if(data.key !== 'select') {
                        var bankDtls = bankOptions.newEmandates;
                        paymentDetailsUtility.setPayment(bankDtls, data);
                    }
                    bankDtlsModel.setIsNewAccount($scope.isNewAccount);
                    $scope.$broadcast('bankChanged', data);
                }
            });

            $scope.$on(transactEventConstants.transact.NEFTBANK_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if(bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.neftRtgs;
                    paymentDetailsUtility.setPayment(bankDtls, data);
                    $scope.showPayeeDetails = true;
                } else if(data.key === 'select') {
                    $scope.showPayeeDetails = false;
                }
            });


            function goNextTab(){
                var payDetailsModel = {},
                    payDetails = paymentDetailsUtility.getPayDetails($scope);
                    bankDtlsModel.setPaymentDetails(payDetails);
                    payDetailsModel.investorDetails = transactModel.getInvestorDetails();
                    payDetailsModel.fundDetails = transactModel.getFundDetails();
                    payDetailsModel.paymentDetails = bankDtlsModel.getPaymentDetails();
                    transactModel.setTransactDetails(payDetailsModel);

                if(isNewAct) {
                    custBankParams = paymentDetailsUtility.setCustBankParams(); // custormerBank service integration
                    bankDtlsModel.postCustBankDtls(custBankParams).then(custBankSuccess, custBankFailure);
                }
                validateParams = paymentDetailsUtility.setValidateParams(); // For /validateSIP and validateBuy services
                if(transactModel.getIsSip() || transactModel.getIsModifySIP()){
                    $loader.start();
                    if($state.current.url === '/renewsip'){
                        validateParams.distId = '0000000000';
                    }
                    bankDtlsModel.postValidateSip(validateParams)
                    .then(validateSuccess, handleFailure)
                    .finally(function() {
                        
                        $loader.stop();
                    });
                } else if(transactModel.getIsBuy()){
                    bankDtlsModel.postValidateBuyDtls(validateParams).then(validateSuccess, handleFailure);
                }
            }

            $scope.getSelections = function() {
                $scope.$broadcast('continueClicked');
                isValidForm = paymentDetailsUtility.checkFormValidity($scope); //Check for form errors based on mandatory requirements
                isNewAct = bankDtlsModel.getIsNewAccount();

                if($scope.paymentForm.$valid && isValidForm) {
                    if (editIconChanged) {
                        var result = _.isEqual(bankDtlsModel.getPaymentDetails(), paymentDetailsUtility.getPayDetails($scope));
                        if (!result) {
                            $scope.configDataLost.showNotification = true;
                            var destroyHandler =  $scope.$on('yes', function () {
                                $scope.configDataLost.showNotification = false;
                                goNextTab();
                                destroyHandler();
                              });

                              $scope.$on('no', function () {
                                $scope.configDataLost.showNotification = false;
                              });
                        }
                        else{
                            goNextTab();
                        }

                    }else{
                        goNextTab();
                    }
                }
            };

            if($stateParams.key === TransactConstant.transact.Payment_Key) { // On Review & Confirm edit, show previous selections
                checkFlow();
                bankOptions = bankDtlsModel.getBankDetails();
                setBankFilters(bankOptions);
                paymentDetailsUtility.showSelectedBank($scope);
                savePrevSelections();
                editIconChanged = true;
            }

            function init() {
                $scope.showContinue = true;
                $scope.method = {};
                $scope.method.eMandateSel = null;
                $scope.method.netBankSel = null;
                $scope.method.debitBankSel = null;
                $scope.method.newMandateSel = null;
                $scope.method.neftSel = null;
                $scope.mode = {};
                $scope.mode.selectedVal = null;
                $scope.methodRequired = true;
                $scope.showMandateDetails = false;
                $scope.showNewMandate = false;
                $scope.showPayeeDetails = false;
                $scope.showNewAccount = false;
                $scope.isNewAccount = false;
                $scope.isNewMandate = false;
                $scope.showMultiPayMode = false;
                $scope.showAutoDebit = false;
                $scope.showBankError = false;
                $scope.showNoBankError = false;
                $scope.continueButton = true;
                $scope.disableContinue = true;
                $scope.configDataLost = {};
                $scope.configDataLost.showNotification = false;
                $scope.eMandateOptions = [{title: TransactConstant.transact.SELECT_BANK, key : 'select'}];
                $scope.netBankOptions = [{title: TransactConstant.transact.SELECT_BANK, key : 'select'}];
                $scope.debitBankOptions = [{title: TransactConstant.transact.SELECT_BANK, key : 'select'}];
                $scope.newMandateOptions = [{title: TransactConstant.transact.SELECT_BANK, key : 'select'}];
                $scope.neftBankOptions = [{title: TransactConstant.transact.SELECT_BANK, key : 'select'}];
                disablePayOptsInit();
                $scope.continueButton = ($stateParams.from === 'INVESTORLEG') ? false : true; // Hide the continue button for Guest Buy Transaction
                $scope.showContinue = ($stateParams.from === 'INVESTORLEG') || transactModel.isRetryPayment ? false : true; // Hide the continue button for Guest Buy Transaction & Payment Failure Redirection
            }

            function initPayMethod() {
                $scope.showMandateDetails = false;
                $scope.showNewMandate = false;
                $scope.showPayeeDetails = false;
                $scope.showNewAccount = false;
                $scope.isNewMandate = false;
                $scope.isNewAccount = false;
                $scope.showMultiPayMode = false;
                $scope.showAutoDebit = false;
                $scope.showNoBankError = false;
                $scope.method.eMandateSel = $scope.eMandateOptions[0];
                $scope.method.netBankSel = $scope.netBankOptions[0];
                $scope.method.debitBankSel = $scope.debitBankOptions[0];
                $scope.method.newMandateSel = $scope.newMandateOptions[0];
                $scope.method.neftSel = $scope.neftBankOptions[0];
            }

            function disablePayOptsInit() {
                $scope.existingMandate = {disable : true, name : 'eMandate'};
                $scope.netBanking = {disable : true, name : 'netBank'};
                $scope.debitCard = {disable : true, name : 'debit'};
                $scope.newMandate = {disable : true, name : 'nMandate'};
                $scope.neft = {disable : true, name : 'neftRtgs'};
            }

            function checkFlow() {
                txnType = paymentDetailsUtility.getTxnType();
                $scope.isSIP = transactModel.getIsSip();
                $scope.isBuy = transactModel.getIsBuy();
                $scope.isModifySIP = transactModel.getIsModifySIP();
            }

            function getPaymentBanks(txnType) {
                var params= {
                    "folioId" : transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().folioId : "" || transactModel.getSelectedFolioDts() ? transactModel.getSelectedFolioDts().folioId : "",
                    "trxnType" : txnType,
                    "guId" : authenticationService.getUser().guId
                };

                $loader.start();
                bankDtlsModel.fetchBankDetails(params)
                .then(bankDtlsSuccess, bankDtlsFailure)
                .finally(function() {

                    $loader.stop();
                }); //Populate Banks
                function bankDtlsSuccess(data) {
                    bankDtlsModel.setBankDetails(data);
                    bankOptions = bankDtlsModel.getBankDetails();
                    setBankFilters(bankOptions);
                    if($stateParams.from==='INVESTORLEG'){
                         paymentDetailsUtility.showSelectedBank($scope);
                         savePrevSelections();
                    }
                }
                function bankDtlsFailure(data) {
                    console.log('bankDtlsFailure');
                }
            }

            function enableBankFilter(value) {
                isEmpty = false;
                switch(value) {
                    case TransactConstant.transact.EXISTING_PAY_MANDATE :
                        if(bankOptions) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.emandate);
                            if(!isEmpty) {
                                $scope.existingMandate.disable = false;
                                $scope.disableContinue = false; // Enable continue button
                            }
                        }
                        break;
                    case TransactConstant.transact.NET_BANKING :
                        if(bankOptions) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.netBanking);
                            if(!isEmpty) {
                                $scope.netBanking.disable = false;
                                $scope.disableContinue = false; // Enable continue button
                            }
                        }
                        break;
                    case TransactConstant.transact.DEBIT_CARD :
                        if(bankOptions) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.debit);
                            if(!isEmpty) {
                                $scope.debitCard.disable = false;
                                $scope.disableContinue = false; // Enable continue button
                            }
                        }
                        break;
                    case TransactConstant.transact.SETUP_NEW_MANDATE :
                        if(bankOptions) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.newEmandates);
                            if(!isEmpty) {
                                $scope.newMandate.disable = false;
                                $scope.disableContinue = false; // Enable continue button
                                $scope.showNewMandate = true;
                            }
                        }
                        break;
                    case TransactConstant.transact.NEFT_RTGS :
                        if(bankOptions) {
                            isEmpty = paymentDetailsUtility.isEmptyBankList(bankOptions.neftRtgs);
                            if(!isEmpty) {
                                $scope.neft.disable = false;
                                $scope.disableContinue = false; // Enable continue button
                            }
                        }
                        break;
                    case TransactConstant.transact.AUTO_DEBIT :
                        var autoDebitBanks = [],
                            banks = null;
                        if(bankOptions) {
                            banks = bankOptions.emandate;
                            for(var i=0; i<banks.length;i++) {
                                if(banks[i].paymentType === 'M') {
                                    autoDebitBanks.push(banks[i]);
                                }
                            }
                        }
                        isEmpty = paymentDetailsUtility.isEmptyBankList(autoDebitBanks);
                        if(!isEmpty) {
                            $scope.showAutoDebit = true;
                            $scope.showBankError = false;
                            $scope.disableContinue = false;
                        }
                        break;
                    case TransactConstant.transact.BILL_PAY :
                        $scope.showBankError = false;
                        $scope.disableContinue = false;
                        if(transactModel.getIsModifySIP()) {
                            bankDtlsModel.setPaymentMode(TransactConstant.common.BILL_PAY_CODE);
                        }
                        break;
                    case TransactConstant.transact.MULTIPLE_PAY_MODE :
                        isEmpty = false;
                        $scope.disableContinue = false; // Enable continue button
                        $scope.showMultiPayMode = true;
                        $scope.methodRequired = false;
                };
                if(isEmpty) {
                    $scope.showNoBankError = true;
                }
                bankDtlsModel.setIsNoBankError($scope.showNoBankError);
            }

            function setBankFilters(bankOptions) {
                if(bankOptions) {
                    paymentDetailsUtility.populateBanks('emandate', bankOptions.emandate, $scope.eMandateOptions); //E-Mandate Bank Options
                    paymentDetailsUtility.populateBanks('netBanking', bankOptions.netBanking, $scope.netBankOptions); //Net Banking Options
                    paymentDetailsUtility.populateBanks('debit', bankOptions.debit, $scope.debitBankOptions); //Debit Card Options
                    paymentDetailsUtility.populateBanks('newEmandates', bankOptions.newEmandates, $scope.newMandateOptions); //New E-Mandate Options
                    paymentDetailsUtility.populateBanks('neftRtgs', bankOptions.neftRtgs, $scope.neftBankOptions); //NEFT / RTGS Options
                }
            }

            function savePrevSelections() {
                $scope.disableContinue = false;
                var isMultiMode = bankDtlsModel.getIsMultiPayMode();
                if(!isMultiMode) {
                    var payMethod = bankDtlsModel.getPaymentMethod(); //Set Payment Method
                    $scope.mode.selectedVal = payMethod;
                }
                isNewAct = bankDtlsModel.getIsNewAccount(); //Setup a new-mandate - new account
                if(isNewAct) {
                    $scope.showNewAccount = true;
                }
            }

            function validateSuccess(data) {

                var isBothValidated = false,
                    transactionType = "";
                if(transactModel.getIsBuy()){
                    transactModel.setLumpsumWebRefNo(data.webRefNo);
                    transactModel.isLumpsumValidated = true;
                    transactionType = "BUY";
                }else if(transactModel.getIsSip()){
                    transactModel.setSipWebRefNo(data.webRefNo);
                    transactModel.isSipValidated = true;
                    transactionType = "SIP";
                }

                if(transactModel.isLumpsumValidated&&transactModel.isSipValidated){
                    isBothValidated = true;
                }

                //if($stateParams.from !== 'INVESTORLEG' && !transactModel.isRetryPaymentInvestorLeg){
                if($stateParams.from !== 'INVESTORLEG'){    
                    transactModel.setWebRefNo(data.webRefNo); // Set webRefNo received in the success response of /validateBuy, /validateSIP services                
                } 

                $scope.$emit("validated",{"isBothValidated":isBothValidated,"transactType":transactionType});
                if(!$scope.continueButton || transactModel.isRetryPayment) {
                    $scope.$emit('postTransactTypeDetails');
                }
                if(transactModel.getIsModifySIP()) {
                    $scope.$emit('setModifySipDetails');
                }
                if($scope.reviewState) {
                    if($state.current.name === "invTransact.base.buy")
                    {
                        $scope.$emit('reviewBuy');
                    }
                    else{
                     $state.go($scope.reviewState);
                    }
                    return;
                }
                 if($scope.reviewState) {
                    if($state.current.name === "invTransact.base.renewsip")
                    {
                        $scope.$emit('reviewRenewSip');
                    }
                    else{
                     $state.go($scope.reviewState);
                    }
                    return;
                }
                if($scope.reviewState) {
                    if($state.current.name === "invTransact.base.sip")
                    {
                        $scope.$emit('reviewStartSip');
                    }
                    else{
                     $state.go($scope.reviewState);
                    }
                    return;
                }
                if(transactModel.isRetryPayment){
                    $scope.$emit('PaymentRedirectionValidateSuccess',{"transaction":transaction});
                }


            }
            function handleFailure(errorResp) {
                console.log('validate sip/buy error');
                //$scope.$emit('reviewRenewSip');
                toaster.error(errorResp.data[0].errorDescription);
            }

            function custBankSuccess(data) {
                console.log('customer bank service success');
            }

            function custBankFailure(data) {
                console.log('customer bank service failure');
            }

            $scope.$on('bankSelected', function(event, data) {
                $scope.$broadcast('bankChanged', data);
            });

            $scope.$on('validateBuyForm', function(event, data){
                $scope.paymentForm.$submitted = true;
                $scope.getSelections();
            });

            $scope.$on('validateSipForm', function(event, data){ //added for SIP
                $scope.paymentForm.$submitted = true;
                $scope.getSelections();
            });

            $scope.$on('validateModifySipForm', function(event, data){ //added POST  for guest transact modify sip
                $scope.paymentForm.$submitted = true;
                $scope.getSelections();
            });

            $scope.$on("submitTransactionClicked",function(event,data){
                transaction = data.transaction;
                $scope.paymentForm.$submitted = true;
                $scope.getSelections();
            })

            if(bankDtlsModel.getModifysipEditable()){
                $scope.continueButton = false;
            }

           $scope.$on("hideContinue",function(event,data){
                $scope.showContinue = false;
           });

           $scope.$on("payment_form_submit", function(event, data) {
                $scope.getSelections();
           });

           var configURL = configUrlModel.getEnvUrl('MARKETING_URL');
          var clickHereUrl=appConfig[configURL] + '/investor/resources?firstFilter-1&secondFilter-3'; 
          $scope.clickHereTab = function(){
            $window.open(clickHereUrl,"_blank");
          }
        }]
    };
};
fticExistingInvPayDetails.$inject = ['bankDtlsModel', 'transactModel', '$state', 'fundDetails', '$filter', 'TransactConstant', '$stateParams', 'sipDetailsModel', 'transactEventConstants', 'authenticationService', 'buildPlanModelService', 'paymentDetailsUtility', 'toaster', '$loader', 'configUrlModel', 'appConfig', '$window'];
module.exports = fticExistingInvPayDetails;
