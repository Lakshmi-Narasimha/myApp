"use strict";
var moment = require('moment');
var DateFormatter = (function () {
    function DateFormatter() {
    }
    DateFormatter.prototype.format = function (date, format) {
        return moment(date.getTime()).format(format);
    };
    return DateFormatter;
}());
exports.DateFormatter = DateFormatter;
