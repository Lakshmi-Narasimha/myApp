/**
 * @ngdoc property
 * @name videoLoader Directive
 * @description
 *
 * Displays Video
 *
 **/
'use strict';

var transDetails = function() {
	return {
        template: require('./transDetails.html'),
        restrict: 'E',
        replace: false,
        scope: true,
        controller: function($scope, transDetailsModel){
            
            $scope.keyValuePairs = transDetailsModel.getTransactionDetails($scope.type);
        },
        link: function(){

        }
    };
};

transDetails.$inject = ['transDetailsModel'];
module.exports = transDetails;