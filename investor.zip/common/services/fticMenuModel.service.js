/**
 * @ngdoc property
 * @name ftMenuModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - ftMenuModel is a service model which fetches the menu items from service.
 *
 **/
'use strict';

var ftMenuModel = function (Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _headerData = null,
        _footerData = null;
    var ftMenuModel = {
        
        fetchMenuData : function () {
            var deferred = $q.defer();
            Restangular.one('others/globalMenu').get().then(function (menudata) {
                deferred.resolve(menudata);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        
        getHeaderData: function() {
            return _headerData;
        },
        
        setHeaderData: function(headerdata) {  
            _headerData = headerdata.framework.header;
        },

        getFooterData: function() {
            return _footerData;
        },
        setFooterData: function(footerdata) {           
            _footerData = footerdata.framework.footer;
        }

    };
    return ftMenuModel;
};

ftMenuModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];

module.exports = ftMenuModel;