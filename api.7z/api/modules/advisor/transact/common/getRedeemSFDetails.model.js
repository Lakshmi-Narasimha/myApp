// getRedeemSFDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RedeemSFSchema = new mongoose.Schema({
	RedeemSFObject: {
		type: Array,
		"default": []
	}
});

var SelectFundLookUp = mongoose.model('SelectFundLookUp', RedeemSFSchema);

var RedeemSFDetailsModel = new SelectFundLookUp({
	"RedeemSFObject" : [{
		result: [

			{
                "fund":"Franklin India Equity  Fund",
                "accno":"1234567890",
                "investgoal":"Retirement",
                "totalUnits":"254.36",
                "currentValue":"890.12",
                "amount": "1500",
                "dividend": "Re-Investment",
                "dividendFlag" : "R",
                "fundCategory" : "EQUITY",
                "fundType" : "E",
                "minSipAmt" : 500,
                "nfoFlag" : "N",
                "payoutFlag" : false,
                "reinvestmentFlag" : true,
                "sipStartDate" : "1 mar 2014",
                "sipEndDate" :"4 sep 2020",
                "sipAmount" :1000,
                "frequency" : "monthly",
                "stepUp" : 2500
            },
            {
                "fund":"Franklin India Balanced Fund",
                "accno":"8761098271",
                "investgoal":"Study Abroad",
                "totalUnits":"334.01",
                "currentValue":"245.09",
                "amount": "1500",
                "dividend": "Re-Investment",
                "dividendFlag" : "P",
                "fundCategory" : "EQUITY",
                "fundType" : "E",
                "minSipAmt" : 500,
                "nfoFlag" : "N",
                "payoutFlag" : true,
                "reinvestmentFlag" : false,
                "sipStartDate" : "1 mar 2014",
                "sipEndDate" :"4 sep 2020",
                "sipAmount" :1000,
                "frequency" : "monthly",
                "stepUp" : 2500
            },
            {
                "fund":"Franklin India Smaller Companies Fund",
                "accno":"8762071568",
                "investgoal":"---",
                "totalUnits":"123.56",
                "currentValue":"289.10",
                "amount": "2000",
                "dividend": "Payout",
                "dividendFlag" : "G",
                "fundCategory" : "EQUITY",
                "fundType" : "E",
                "minSipAmt" : 500,
                "nfoFlag" : "N",
                "payoutFlag" : false,
                "reinvestmentFlag" : false,
                "sipStartDate" : "1 mar 2014",
                "sipEndDate" :"4 sep 2020",
                "sipAmount" :1000,
                "frequency" : "monthly",
                "stepUp" : 2500
            },
            {
                "fund":"Franklin India Dynamic PE Ratio Fund of Funds",
                "accno":"6253891092",
                "investgoal":"FS",
                "totalUnits":"12.87",
                "currentValue":"345.98",
                "amount": "2000",
                "dividend": "Payout",
                "dividendFlag" : "P",
                "fundCategory" : "EQUITY",
                "fundType" : "E",
                "minSipAmt" : 500,
                "nfoFlag" : "N",
                "payoutFlag" : true,
                "reinvestmentFlag" : false,
                "sipStartDate" : "1 mar 2014",
                "sipEndDate" :"4 sep 2020",
                "sipAmount" :1000,
                "frequency" : "monthly",
                "stepUp" : 2500
            }


		]
	}
	]
});

SelectFundLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
    	console.log('Having toruble in creating SelectFundLookUp table, please contact admin...');
    } else {
    	SelectFundLookUp.remove({}, function(err) {
    		console.log('SelectFundLookUp collection removed');
    		RedeemSFDetailsModel.save(function(err) {
    			if (err) {
    				console.log('Having toruble in creating SelectFundLookUp table, please contact admin...');
    			}
    			console.log('SelectFundLookUp table created in mongoose...');
    		});
    	});
    	console.log(data.length);
    }
});

module.exports = SelectFundLookUp;
