/**
 * @ngdoc directive
 * @name fticNomineeFilter
 * 
 * @description
 *
 * - 
 *
 **/

'use strict';

var fticNomineeFilter = function(investorEventConstants, investorEvents, investorConstants, nomineeDetailsModel) {
    return {
            template: require('./nomineeFilter.html'),
            restrict: 'E',
            replace: true,
            controller: function($scope){
                $scope.inputObject = {
                    label:'Folio No.',
                    required:false,
                    disable:false
                };

                $scope.inputObjectAcc = {
                    label:'Account No.',
                    required:false,
                    disable:false
                };
                $scope.$on('nomineeFolio', function(event, data){
                    $scope.nomineeListDir = false;
                    $scope.nomineeDtlsObj = [];
                    $scope.nomineeAccount = [];
                    _.each(nomineeDetailsModel.getFolioNumbersList(), function(element){
                        _.each(element.rows, function(element1,index1){
                            if(data.title === element.folioId){
                                if(element1.accountNo){
                                    var nomineeAccountObj = {                
                                        'title' : element1.accountNo
                                    };
                                    if(index1 === 0){
                                        $scope.selectedAccountObj = nomineeAccountObj;
                                        $scope.nomineeDtlsLength = element.rows[0].nomineeDetails;
                                        if(!$scope.nomineeDtlsLength){
                                            $scope.addNominee = false;
                                            $scope.showNominee = false;
                                        } else {
                                            $scope.nomineeDtlsObj.push(element.rows[0]);
                                            $scope.nomineeDtlsLength = true;
                                            $scope.showNominee = true;
                                        }
                                    }
                                    $scope.nomineeAccount.push(nomineeAccountObj);
                                }
                            }
                        }); 
                        if(!$scope.nomineeAccount.length){
                            $scope.accountLength = false;
                            $scope.addNominee = false;
                            $scope.showNominee = false;
                        }else{
                            $scope.accountLength = true;
                        }
                    });
                });
            }
        };
};
fticNomineeFilter.$inject = ['investorEventConstants', 'investorEvents', 'investorConstants', 'nomineeDetailsModel', 'nomineeDetailsInitialLoader'];
module.exports = fticNomineeFilter;