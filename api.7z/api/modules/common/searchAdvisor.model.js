// getSearchAdvisor.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var SearchAdvisorSchema = new mongoose.Schema({
    advisorData: {
        type: Array,
        'default': []
    }
});

var SearchAdvisorLookUp = mongoose.model('InvSearchAdvisorLookup', SearchAdvisorSchema);

var SearchAdvisorModel = new SearchAdvisorLookUp({
    'advisorData': [{
        'distId': '',
        'distName': ['SRIRAM SURYANARAYANAN ~ ARN-3439 ~ SOUTH', 'ABHI AND CO~1201110000~NORTH']
    }, {
        'distId': '',
        'distName': ['A G FINANCIAL PRODUCTS & SERVICES~ARN-2111~MUMBAI', 'A G FINANCIAL PRODUCTS & SERVICES~AWC5001111~MUMBAI', 'AADITI ANANT JOSHI~0001001110~MUMBAI', 'ABHI & CO~1201115000~NORTH', 'ABHI AND CO~1201110000~NORTH']
    }]
});

SearchAdvisorLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SearchAdvisorLookUp table, please contact admin...');
    } else {
        SearchAdvisorLookUp.remove({}, function() {
            console.log('SearchAdvisorLookUp collection removed');
            SearchAdvisorModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating SearchAdvisorLookUp table, please contact admin...');
                }
                console.log('SearchAdvisorLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SearchAdvisorLookUp;
