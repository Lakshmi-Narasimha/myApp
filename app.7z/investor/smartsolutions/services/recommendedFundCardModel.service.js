'use strict';

var recommendedFundPlan= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _recommendedFundModelResp = null,
        _recommendedFundId = null;

    var recommendedFundCardModel = {
        fetchRecommendedFundCard : function (fundCodes) {
            var deferred = $q.defer();
            var params= {};
            params.fundCodes = fundCodes;
            Restangular.one('others/fundExplorer').get(params).then(function (fundCardModalRep) {
                deferred.resolve(fundCardModalRep);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        getFundCardModelDtls : function () {
                 return _recommendedFundModelResp;
        },
        setFundCardModelDtls : function (fundCardModalRep) {
            _recommendedFundModelResp = fundCardModalRep;
        },
        setFundCardId: function(fundId) {
            _recommendedFundId = fundId;
        },
        getFundCardId: function() {
            return _recommendedFundId;
        }
 
    };
    return recommendedFundCardModel;

};

recommendedFundPlan.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = recommendedFundPlan;
