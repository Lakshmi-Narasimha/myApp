define(
		[ 'appmodules/eSig/app/js/models/customer-model' ],
		function(CustomerModel) {
			var CustomerCollection = Backbone.Collection
					.extend({
						model : CustomerModel,
						fetched : false,
						//url : 'appmodules/eSig/app/js/data/content_10.js',
						parse : function(response) {
							if (response.statCd != 1) {
								var advisorArr = [], clientArr = []
								for (i = 0; i < response.ESignatureDocument.documentSigner.length; i++) {
									if (response.ESignatureDocument.documentSigner[i].signerContextCd == 'COLA') {
										clientArr
												.push(response.ESignatureDocument.documentSigner[i]);
									} else if (response.ESignatureDocument.documentSigner[i].signerContextCd == 'DMU') {
										advisorArr
												.push(response.ESignatureDocument.documentSigner[i]);
									}
								}
								response.ESignatureDocument.documentSigner = clientArr.concat(advisorArr);
								return response.ESignatureDocument.documentSigner || [];
							} else {
								alert("Some error occured.");
								// return;
							}
						}

					});
			return new CustomerCollection();
		});
