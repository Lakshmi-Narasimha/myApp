﻿define([], function () {
    var honorific =
    [
        { name: "DR", code: "DR", serviceValue: "DR" },
        { name: "HON", code: "HON", serviceValue: "HON" },
        { name: "MISS", code: "MISS", serviceValue: "MISS" },
        { name: "MR", code: "MR", serviceValue: "MR" },
        { name: "MRS", code: "MRS", serviceValue: "MRS" },
        { name: "MS", code: "MS", serviceValue: "MS" },
        { name: "PROF", code: "PROF", serviceValue: "PROF" },
        { name: "REV", code: "REV", serviceValue: "REV" },
        { name: "SIR", code: "SIR", serviceValue: "SIR" }
    ];
    
    var primarySourceOfIncome = [
	    { name: "Business income", code: "H", serviceValue: ["H"] },  
	    { name: "Disability income", code: "C", serviceValue: ["C"] },
        { name: "Employment", code: "A",serviceValue:["A"] },
        { name: "Inheritance/Trust income", code: "D", serviceValue: ["D"] },
        { name: "Investment income", code: "E", serviceValue: ["E"] },
        { name: "Lottery/Gambling", code: "F", serviceValue: ["F"] },
        { name: "Rents/Royalities", code: "G", serviceValue: ["G"] },
        { name: "Social security/Pension", code: "B", serviceValue: ["B"] },
        { name: "Other", code: "I", serviceValue: ["I"] }
      ];
    
    var federalTaxBrackets = [
         { name: "0%", code: "00.00",serviceValue:"0.00" },
         { name: "10%", code: "10.00", serviceValue: "10.00" },
         { name: "15%", code: "15.00", serviceValue: "15.00" },
         { name: "25%", code: "25.00", serviceValue: "25.00" },
         { name: "28% and over", code: "28.00", serviceValue: "28.00" }
      ];
    
   var maritalstatus = [
        { name: "Divorced", code: "D", serviceValue: "D" },
        { name: "Married", code: "M", serviceValue: "M" },
        { name: "Single", code: "S", serviceValue: "S" },
        { name: "Widowed", code: "W", serviceValue: "W" },
      ];
   
   var investmentExperince = [
        { name: "0-5 years", code: "A", serviceValue: ["A"] },
        { name: "6-10 years", code: "B", serviceValue: ["B"] },
        { name: "11 + years", code: "C", serviceValue: ["C"] }
      ];
   
   var productExperince = [
	    { name: "Annuities, Variable life", code: "C", serviceValue: ["C"] },
	    { name: "Bonds", code: "E", serviceValue: ["E"] },
	    { name: "Certificates", code: "A", serviceValue: ["A"] },
	    { name: "Commodities", code: "G", serviceValue: ["G"] },
	    { name: "Limited Partnership", code: "H", serviceValue: ["H"] },
	    { name: "Mutual Funds", code: "B", serviceValue: ["B"] },
	    { name: "Options", code: "F", serviceValue: ["F"] },
	    { name: "Stocks", code: "D", serviceValue: ["D"] },
	    { name: "None", code: "I", serviceValue: ["I"] }
      ];
    var phoneType = [
        {"name": "Home", "code": "1", "serviceValue": ["Home", "HOME"] },
        {"name": "Home (Contact Manager)", "code": "1", "serviceValue": ["Home", "HOME"] },
        {"name":"Home - TTY/TDD (Contact Manager)","code":"16004","serviceValue":["Home - TTY/TDD"]},
        {"name":"Business","code":"2","serviceValue":["Business","BUSINESS"]},
        {"name":"Business (Contact Manager)","code":"2","serviceValue":["Business","BUSINESS"]},
        {"name":"Business Fax (Contact Manager)","code":"4","serviceValue":["Business Fax"]},
        {"name":"Business - TTY/TDD (Contact Manager)","code":"16005","serviceValue":["Business - TTY/TDD"]},        
        {"name":"Mobile","code":"10","serviceValue":["Mobile","MOBILE"]},
        {"name":"Mobile (Contact Manager)","code":"10","serviceValue":["Mobile","MOBILE"]},
        {"name":"Mobile - Business (Contact Manager)","code":"16001","serviceValue":["Mobile - Business"]},
        {"name":"Fax - Home (Contact Manager)","code":"13","serviceValue":["Fax - Home"]},        
        {"name":"Other 1","code":"16006","serviceValue":["Other 1","OTHER 1"]},
        {"name":"Other 1 (Contact Manager)","code":"16006","serviceValue":["Other 1","OTHER 1"]},
        {"name":"Other 2","code": "16007","serviceValue":["Other 2", "OTHER 2"] },
        {"name":"Other 2 (Contact Manager)","code": "16007","serviceValue":["Other 2", "OTHER 2"] }
      ];
   var colaPhoneType = [
        { "name": "Home", "code": "1", "serviceValue": ["Home", "HOME"] },
        {"name":"Business","code":"2","serviceValue":["Business","BUSINESS"]},
        {"name":"Mobile","code":"10","serviceValue":["Mobile","MOBILE"]},
        {"name":"Other 1","code":"16006","serviceValue":["Other 1","OTHER 1"]},
        { "name": "Other 2", "code": "16007", "serviceValue": ["Other 2", "OTHER 2"] }
      ];  
   var emailTypes = [
        { name: "Primary", code: "Primary", serviceValue: ["Primary", "PRIMARY"] },
        { name: "Secondary", code: "Secondary", serviceValue: ["Secondary", "SECONDARY"] },
        { name: "Other (Contact Manager)", code: "1", serviceValue: ["Other", "Email"] },
        { name: "Url", code: "1", serviceValue: ["Other", "Url"] },
        { name: "IM", code: "1", serviceValue: ["Other", "IM"] }
 	  ];
   var familyRelationships = [
       { name: "Attorney", code: "Attorney", serviceValue: "Attorney" },
       { name: "Child", code: "Child", serviceValue: "Child" },
       { name: "Executor", code: "Executor", serviceValue: "Executor" },
       { name: "Parent", code: "Parent", serviceValue: "Parent" },
       { name: "Sibling", code: "Sibling", serviceValue: "Sibling" },
       { name: "Spouse", code: "Spouse", serviceValue: "Spouse" },
       { name: "Trustee of Trust", code: "TrusteeofTrust", serviceValue: "Trustee of Trust" },
       { name: "Other", code: "Other", serviceValue: "Other" }
   ];
   var entityTypes = [
       {name: "Corporation - C-Corp", code:"1C", serviceValue: "1C"},
       {name: "Corporation - S-Corp", code:"1S", serviceValue: "1S"},
       {name: "Estate", code:"09", serviceValue: "09"},
       {name: "Government entity", code:"04", serviceValue: "04"},
       {name: "Irrevocable trust", code:"08", serviceValue: "08"},
       {name: "LLP", code:"10", serviceValue: "10"},
       {name: "LLC - C-Corp", code:"6C", serviceValue: "6C"},
       {name: "LLC - S-Corp", code:"6S", serviceValue: "6S"},
       {name: "Non-Profit", code:"05", serviceValue: "05"},
       {name: "Partnership", code:"02", serviceValue: "02"},
       {name: "Revocable trust", code:"07", serviceValue: "07"}
   ];
   var entityTypesViewOnly = [
      { name: "Corporation - C-Corp", code: "1C", serviceValue: "1C" },
      { name: "Corporation - S-Corp", code: "1S", serviceValue: "1S" },
      { name: "Estate", code: "09", serviceValue: "09" },
      { name: "Government entity", code: "04", serviceValue: "04" },
      { name: "Irrevocable trust", code: "08", serviceValue: "08" },
      { name: "LLP", code: "10", serviceValue: "10" },
      { name: "LLC - C-Corp", code: "6C", serviceValue: "6C" },
      { name: "LLC - S-Corp", code: "6S", serviceValue: "6S" },
      { name: "Non-Profit", code: "05", serviceValue: "05" },
      { name: "Partnership", code: "02", serviceValue: "02" },
      { name: "Revocable trust", code: "07", serviceValue: "07" },
      { name: "Sole Proprietorship", code: "03", serviceValue: "03" }
   ];

    return { honorific: honorific,
	    	primarySourceOfIncome:primarySourceOfIncome,
	    	federalTaxBrackets:federalTaxBrackets,
	    	maritalstatus:maritalstatus,
	    	investmentExperince:investmentExperince,
	    	productExperince:productExperince,
	    	phoneType:phoneType,
            colaPhoneType:colaPhoneType,
	    	emailTypes:emailTypes,
	    	familyRelationships: familyRelationships,
	    	entityTypes: entityTypes,
	    	entityTypesViewOnly: entityTypesViewOnly
    	};
});