/**
 * @ngdoc property
 * @name panLevelInvModal Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function panLevelInvModalController($scope, $uibModalStack, investorConstants, recommendedPlanModelService, authenticationService, investorGoalModelService) { 
    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    };
    //NavpillOptions Configuration
    $scope.navPillsOptions = [
      {
        btnName : investorConstants.smartSolutions.NON_SOLUTION_LABEL,
        uibValue : 'non_solution'
      }, 
      {
        btnName : investorConstants.smartSolutions.SOLUTION_LABEL,
        uibValue : 'solution'
      }];
      $scope.modelVal = 'solution';    
      $scope.btnColor = 'btn-group-md blue-btn-group pull-right'; 
      
      $scope.pillSelect = function (param) {
        $scope.modelVal = param;
        if(param === "non_solution") {
          $scope.setNonSolutionPanLevel();
        }
      };
      console.log(recommendedPlanModelService.getpanLevelSummaryFS());

      $scope.popovercontent = [];
      
      

      //Grid Configuration
      // var returnsTemplate = '<ftic-tool-tip tooltip-txt="Info About Returns" class="p0 col-md-1 col-xs-1 mv-"></ftic-tool-tip>'
      var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnTemp.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue pl-"></span></div>'+
                '<script type="text/ng-template" id="returnTemp.html">' +
                '<div><button type="button" class="btn panel-orange-btn m0">Returns calculation will be displayed</button></div></script>';
      $scope.panLevelInvColumnDefs = [
        { field: 'accountNo', displayName: 'Account', width:"150", enableSorting:false, pinnedLeft:true},
        { field: 'scheme', displayName: 'Fund', width:"200", enableSorting:false},
        { field: 'goal', displayName: 'Goal', width:"150", enableSorting:false},
        { field: 'totalUnits',displayName: 'Unit Balance', width:"150",headerCellClass:'text-right',cellClass:'text-right', enableSorting:false},
        { field: 'currentCost', displayName: 'Current Cost',  headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"150", enableSorting:false},
        { field: 'currentValue', displayName: 'Current Value',  headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"150", enableSorting:false},
        { field: 'returns',displayName: 'Returns', width:'100',headerCellTemplate:returnsTemplate,headerCellClass:'fti-grid-headercell text-right media-vtop pt- pr-', cellClass:'text-right'}
    ];

    $scope.panLevelInvColumnDefsNFS = [
        { field: 'accountNo', displayName: 'Account', width:"150", enableSorting:false, pinnedLeft:true},
        { field: 'scheme', displayName: 'Fund', width:"200", enableSorting:false},
        { field: 'totalUnits',displayName: 'Unit Balance', width:"150",headerCellClass:'text-right',cellClass:'text-right', enableSorting:false},
        { field: 'currentCost', displayName: 'Current Cost',  headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"150", enableSorting:false},
        { field: 'currentValue', displayName: 'Current Value',  headerCellClass: 'fti-grid-rupeeIcon text-right', cellClass: 'text-right', width:"150", enableSorting:false},
        { field: 'returns', displayName: 'Returns', width:'100',headerCellTemplate:returnsTemplate,headerCellClass:'fti-grid-headercell text-right media-vtop pt- pr-', cellClass:'text-right'}
    ];
    
    $scope.setPanLevelGrids = function (data) {
      $scope.panLevelInvDataFSObj = {
        panLevelInvDataFS : []
      };
      $scope.panLevelFS = [];
      //Checking for data whether it is null or not.
      for (var i = data ? data.length - 1 : -1; i >= 0; i--) {
        $scope.panLevelInvDataFSObj.panLevelInvDataFS[i] = angular.copy(data[i].rows);  
        $scope.panLevelInvDataFSObj.panLevelInvDataFS[i].push(
        {
          "accountNo" : "Grand Total",
          "scheme" : "", 
          "goal" : "",
          "totalUnits" : data[i].grandTotal.totalUnits,
          "currentCost" : data[i].grandTotal.currentCost,
          "currentValue" : data[i].grandTotal.currentValue,
          "returns" : "",

        });
        $scope.popovercontent = [];
        for(var h=0, len=data[i].holders.length; h<len; h++) {
          $scope.popovercontent.push({"text" : data[i].holders[h].name, "value" : data[i].holders[h].pan})
        };

        $scope.panLevelFS.push({"panLevelSolution" : $scope.panLevelInvDataFSObj.panLevelInvDataFS[i], 
          "folioNo": data[i].folioId,
          "MOH" : data[i].modeofHolding,
          "popoverContent" :  $scope.popovercontent
        })
      };
      return $scope.panLevelFS;
    };

    $scope.panLevelFunds = recommendedPlanModelService.getpanLevelSummaryFS();
    console.log($scope.panLevelFunds);
    $scope.panLevelFunds = $scope.setPanLevelGrids($scope.panLevelFunds);

    /*$scope.$watch($scope.panLevelFunds, function(newValue, oldValue){
      if(oldValue !== newValue) {
        console.log(newValue);
        $scope.setPanLevelGrids(newValue);
      }
    });*/
    // $scope.panLevelInvDataFS = angular.copy(data.rows);
    console.log($scope.panLevelFunds);
    /*$scope.folioNo = data.folioId;
    $scope.modeOfHolding = data.modeofHolding;*/

    $scope.setNonSolutionPanLevel = function () {
      console.log('setNonSolutionPanLevel');
      $scope.panLevelFundsNonSolution = $scope.setPanLevelGrids(recommendedPlanModelService.getpanLevelSummaryNFS());
      console.log($scope.panLevelFundsNonSolution);
    };

}


panLevelInvModalController.$inject = ['$scope', '$uibModalStack', 'investorConstants', 'recommendedPlanModelService', 'authenticationService', 'investorGoalModelService'];

module.exports = panLevelInvModalController;