/**
 * @ngdoc directive
 * @name kycAdditionalDetailsForm
 * 
 * @description
 *
 * - kycAdditionalDetailsForm directive to be used if user's investment amount is more than 50,000.
 **/
 'use strict';

var kycAdditionalDetailsForm = function(formDetailsModel, $state, $timeout, transactModel, paperlessModel,transactEventConstants, appConfig, configUrlModel) {
	return {
		template: require('./kycAdditionalDetailsForm.html'),
		restrict: 'E',
		scope: {
			formObj:"=",
			formName : "="
		},
		controller:['$scope', function($scope) {
			var occupation = formDetailsModel.getOccupationDetails(),
				holder = $scope.formObj.type;

                //As on date
                var tempCurrentDate = new Date();
                var dd = tempCurrentDate.getDate() + 1;
                var mm = tempCurrentDate.getMonth();
                var yyyy = tempCurrentDate.getFullYear()-1;
                var minDateforAsOn = new Date(yyyy, mm, dd);
                $scope.dateOptions = {
                    datepickerMode: 'day',
                    minMode: 'day',
                    yearRows: 3,
                    yearColumns: 4,
                    fulldatepickerMode:'year',
                    formatMonth: 'MMM',
                    formatYear: 'yyyy',
                    formatDayTitle: 'MMM yyyy',
                    monthColumns: 4,
                    showWeeks: false,
                    maxDate : new Date(),
                    minDate : minDateforAsOn
                }

			$scope.formName.fatcaArray = [];
			$scope.incomeDetailsData = [{title:"Gross Annual Income", value:"Gross Annual Income"}];
			$scope.occupationDetailsData = [{title:"Occupation", value:"Occupation"}];
			$scope.asonDateName = holder+"asOnDate";
			$scope.asOnDate = $scope.formObj.netWorthDate || new Date();
			
			$scope.netWorthDetails = {
				key : "worth",
				text:"Net Worth"+" <span class='icon-fti_rupee'></span>",
				name : holder+"netWorth",
				type : "number",
				isRequired : $scope.selectedIncomeOption,
				value : $scope.formObj.netWorth || '',				
				pattern : /^(?!\.?$)\d{0,20}(\.\d{1,2})?$/
			};

			$scope.occupationDetails = {
				title:"Occupation",
				// label : "Occupation",
				message : "",
				value: '', 
				name : holder+"occupationDetails",
				selected : $scope.formObj.occDetails || '',
				isRequired : true
			};

			$scope.incomeDetails = {
				title:"Gross Annual Income",
				// label: "Gross Annual Income",
				message : "",
				value: '',
				name : holder+"incomeDetails",
				selected : $scope.formObj.incDetails || '',
				isRequired : true
			};

			$scope.checkPolitical1 = {
				label:"Politically exposed person",
				value: $scope.formObj.political || ''
			};

			$scope.checkPolitical2 = {
				label:"Related to Politically exposed person",
				value: $scope.formObj.relatedPolitical || ''
			};

			// Function to find the given "value" in a given object array
            $scope.findItemInFilter = function(objArr, value){
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                        return (x.title == value || x.value == value);
                }))[0];
                return obj;
            };
			$scope.$on(transactEventConstants.transact.KYC_ADTNL_DETAILS, function() {				
				$scope.fatcaObj = {};
				$scope.formName.fatcaArray.push({	
					'name': $scope.formObj.name,
					'pan': $scope.formObj.pan,
					'aadhar': $scope.formObj.aadhar,
					'mobile': $scope.formObj.mobile,
					'email': $scope.formObj.email,
					'dob' : $scope.formObj.dob,					
					'netWorth' : $scope.netWorthDetails.value==undefined?null:$scope.netWorthDetails.value,
					'netWorthDate' : $scope.asOnDate,
					'political' : $scope.checkPolitical1.value==undefined?null:$scope.checkPolitical1.value,
					'relatedPolitical' : $scope.checkPolitical2.value==undefined?null:$scope.checkPolitical2.value,
					'occDetails' : $scope.regFormCnfigObj.occuValue.value==undefined?null:$scope.regFormCnfigObj.occuValue.value,
					'incDetails' : $scope.regFormCnfigObj.incValue.value==undefined?null:$scope.regFormCnfigObj.incValue.value,						 
					'modeOfKyc' : $scope.formObj.modeOfKyc || $scope.formObj.kycMode || "",
					'type' : $scope.formObj.type
				});				
				transactModel.setKycAddnlDetails($scope.formName.fatcaArray);	
			});

			formDetailsModel.fetchFormOcupDetails().then(occuDtlsSuccess, occuDtlsFailure);
			function occuDtlsSuccess(data) {
				formDetailsModel.setOccupationDetails(data.codeValueList);
				var occuDtls = formDetailsModel.getOccupationDetails();
				for(var i=0; i<occuDtls.length; i++) {
					$scope.occupationDetailsData.push({title: occuDtls[i].code, value : occuDtls[i].value});
				}				
				if (paperlessModel.kycAddnlDtls.hasData) {
					$scope.regFormCnfigObj.occuValue = $scope.findItemInFilter($scope.occupationDetailsData, $scope.formObj.occDetails);
					setFormFieldValidity($scope.occupationDetails.name, true);
				}
			}

			function occuDtlsFailure(data) {
				console.log('handleFailure');
			}

			formDetailsModel.fetchFormIncDetails().then(IncDtlsSuccess, IncDtlsFailure);
			function IncDtlsSuccess(data) {
				formDetailsModel.setGrossIncome(data.codeValueList);
				var incomeDtls = formDetailsModel.getGrossIncome();
				for(var i=0; i<incomeDtls.length; i++) {
						$scope.incomeDetailsData.push({title: incomeDtls[i].code, value : incomeDtls[i].value});
				}				
				if (paperlessModel.kycAddnlDtls.hasData){
					$scope.regFormCnfigObj.incValue = $scope.findItemInFilter($scope.incomeDetailsData, $scope.formObj.incDetails);
					$scope.incomeDDShow = false;
					if($scope.regFormCnfigObj.incValue.value === "Gross Annual Income"){
						$scope.incomeDDShow = true;
					}
					$scope.netWorthDetails.value = $scope.formObj.netWorth || '';
					$scope.asOnDate = $scope.formObj.netWorthDate || '';
					networthAsonValidation();					
				}
			}

			function IncDtlsFailure(data) {
				console.log('handleFailure');
			}

			$scope.$on('occupationValue', function(event, data) { 
				var occupationObj = {};
				occupationObj.selectedOccupation =data.title;
				formDetailsModel.setOccuMethod(occupationObj);
				if(occupationObj.selectedOccupation === "Occupation"){
					setFormFieldValidity($scope.occupationDetails.name, false);
				}
				else {
					setFormFieldValidity($scope.occupationDetails.name, true);
				}
			});

	        $scope.netWorthChanged = function(netWorthAmt) {
	        	networthAsonValidation();			
		    };

		    $scope.asOnDateChange = function() {
		    	networthAsonValidation();			
			};

			$scope.$on('incomeValue', function(event, data) {
				var incomeObj = {};
				incomeObj.selectedIncome =data.title;
				formDetailsModel.setIncmMethod(incomeObj);
				if(incomeObj.selectedIncome === "Gross Annual Income" && (!$scope.netWorthDetails.value || !$scope.asOnDate)) {
					$scope.incomeDDShow = true;
					setFormFieldValidity($scope.incomeDetails.name, false);
				}
				else {
					$scope.incomeDDShow = false;
					setFormFieldValidity($scope.incomeDetails.name, true);												
				}
			});

			function networthAsonValidation() {
	        	if($scope.incomeDDShow && $scope.netWorthDetails.value && !$scope.asOnDate) {
					setFormFieldValidity($scope.incomeDetails.name, true);
					setFormFieldValidity($scope.netWorthDetails.name, true);
					setFormFieldValidity($scope.asonDateName, false);
				}else if($scope.incomeDDShow && !$scope.netWorthDetails.value && $scope.asOnDate) {
					setFormFieldValidity($scope.incomeDetails.name, true);
					setFormFieldValidity($scope.asonDateName, true);
					setFormFieldValidity($scope.netWorthDetails.name, false);
				}else if($scope.incomeDDShow && !$scope.netWorthDetails.value && !$scope.asOnDate) {
					setFormFieldValidity($scope.incomeDetails.name, false);
					setFormFieldValidity($scope.netWorthDetails.name, true);
					setFormFieldValidity($scope.asonDateName, true);
				}else {
					setFormFieldValidity($scope.incomeDetails.name, true);
					setFormFieldValidity($scope.asonDateName, true);
					setFormFieldValidity($scope.netWorthDetails.name, true);
				}
			}

			function setFormFieldValidity(name, requiredFlag){
				$timeout(function(){
					$scope.formName[name].$setValidity("required", requiredFlag);
				},0);
			}
		}]
	}
};
kycAdditionalDetailsForm.$inject = ['formDetailsModel', '$state', '$timeout', 'transactModel', 'paperlessModel','transactEventConstants', 'appConfig', 'configUrlModel'];
module.exports = kycAdditionalDetailsForm;