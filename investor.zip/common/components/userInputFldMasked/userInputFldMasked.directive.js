/**
 * @ngdoc directive
 * @name fticUserInputFldMasked
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFldMasked will display floatable input control with Masked.
 * 
 *
 **/
'use strict';

var userInputFldMasked = function($timeout, eventConstants) {
	return {
            template: require('./userInputFldMasked.html'),
            restrict: 'E',
            replace: true,
            scope: {
                inputObject: "="
            },
            controller: function($scope, $element, $attrs){
                $scope.$input = $element[0].querySelector('input');
                $scope.isChanged = false;
                $scope.toggleLabel = function($event){
                    angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || $scope.$input.value.length > 0));
                    $scope.updateParent();
                };
                $timeout(function(){
                    angular.element($scope.$input).triggerHandler('blur');
                    $scope.isChanged = true;
                }, 0);

                $scope.updateParent = function(){
                    if(!$scope.isChanged) {
                        return;
                    } else {
                        $scope.$emit("INPUT_CHANGED", $scope.inputObject);
                    }
                }
            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

userInputFldMasked.$inject = ['$timeout', 'eventConstants'];
module.exports = userInputFldMasked;