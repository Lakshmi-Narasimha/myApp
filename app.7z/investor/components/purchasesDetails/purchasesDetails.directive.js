/**
 * @ngdoc property
 * @name fticTransactionSummary Directive
 * @requires transactionModel
 * @requires transactionsGridConfig
 * @requires mytransactionsConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Transaction Summary data in a ui-grid.
 *
 **/
'use strict';

var purchasesDetails = function ($timeout, $state, $filter, bankDtlsModel, $loader, transactEventConstants, transactModel, invSmartSavingsModel, transactNowModel, newFundDetailsInitialLoader, newFundDetailsModel, $uibModal, recommendedFundCardModelService, $uibModalStack, eventConstants, invEformPaymentBanksUtility, TransactConstant, smartSolnFundDetailsModel, toaster) {

    return {
        template: require('./purchasesDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
            instructionType: '@?'
        },
        link: function ($scope) {
            $scope.selections = {};
            $scope.selections.instructionType = $scope.instructionType;
            $scope.fixedObject = {
                key: 'Fixed Amount',
                text: 'Fixed Amount  &#8377;',
                value: '',
                type: 'number'
            };
            $scope.errors = {};
            $scope.saveInstruction = function () {
                $scope.selections.amount = $scope.fixedObject.value;
                $scope.errors = {};
                var investPref = transactNowModel.getInvestPrefer();
                var newAdvisorDetails = transactModel.getAdvDetails();
                if (!$scope.folioSelObj) {
                    $scope.errors.folio = 'Please choose a Folio in Select Folio to proceed further.';
                    return false;
                }
                $scope.$broadcast('savePurchaseDetails');
                if (investPref) {
                    if (investPref.advisorMode === 'new' && !investPref.code) {
                        $scope.errors.investPref = true;
                    } else if (newAdvisorDetails.euin === 'NO EUIN' && !newAdvisorDetails.checkNoEuin) {
                        $scope.errors.investPref = true;
                    }
                }
                if (!$scope.selections.destinationFund) {
                    $scope.errors.destinationFund = 'Please select a Fund to proceed further.';
                }
                if (!$scope.fixedObject.value) {
                    $scope.errors.amount = 'Please enter Purchase Amount to proceed further.';
                } else if ($scope.fixedObject.value && $scope.selections.destinationFund && ($filter('fticInvStringToNumber')($scope.fixedObject.value) < $filter('fticInvStringToNumber')($scope.selections.destinationFund.allowableAmount))) {
                    $scope.errors.amount = 'The Amount entered should be equal to or greater than the Minimum Investment Amount for the Fund.';
                } else if ($scope.fixedObject.value.toString().indexOf('.') > -1) {
                    $scope.errors.amount = 'Purchase Amount should not contain decimals.';
                }
                var paymentMethod = bankDtlsModel.getPaymentMethod();
                var emandateDetails = bankDtlsModel.getEmandateDetails();
                var netBankingDtls = bankDtlsModel.getSelectedBank();
                var newEmandateAmount = bankDtlsModel.getTotalAmount();
                //var paymentMode = bankDtlsModel.getPaymentMode();
                //var isNewAccount = bankDtlsModel.getIsNewAccount();
                //var bankName = bankDtlsModel.getBankName();
                //var acctType = bankDtlsModel.getAccountType();
                //var acctNo = bankDtlsModel.getAccountNo();
                //var ifscCode = bankDtlsModel.getIfscCode();
                if (!paymentMethod) {
                    $scope.errors.paymentMethod = 'Please choose a Payment Method to proceed further.';
                } else if (paymentMethod === TransactConstant.transact.EXISTING_PAY_MANDATE) {
                    if (!emandateDetails || !Object.keys(emandateDetails).length) {
                        $scope.errors.paymentMethod = 'Please select bank name and account number in existing Payment Mandate to proceed.';
                    } else if ($filter('fticInvStringToNumber')(emandateDetails.amount) < $filter('fticInvStringToNumber')($scope.fixedObject.value)) {
                        $scope.errors.paymentMethod = 'The Amount in the Existing Payment Mandate is not enough to make the payment. Please choose another Mandate or a Payment option to proceed.';
                    }
                } else if (paymentMethod === TransactConstant.transact.SETUP_NEW_MANDATE) {
                    /*if (!paymentMode) {
                        $scope.errors.paymentMethod = 'Please select a Bank name or New Account in ‘Setup a new E-Mandate’ to proceed further.';
                    }
                    if (isNewAccount) {
                        if (!bankName) {
                            $scope.errors.paymentMethod = 'Please select a Bank name in ‘Setup a new E-Mandate’ to proceed further';
                        }
                        if (!acctType) {
                            $scope.errors.paymentMethod = 'Please select an Account type in ‘Setup a new E-Mandate’ to proceed further.';
                        }
                        if (!acctNo) {
                            $scope.errors.paymentMethod = 'Please enter an Account number in ‘Setup a new E-Mandate’ to proceed further.';
                        }
                        if (!ifscCode) {
                            $scope.errors.paymentMethod = 'Please enter an IFSC code in ‘Setup a new E-Mandate’ to proceed further.';
                        }
                    }
                    if (!amount) {
                        $scope.errors.paymentMethod = 'Please enter Purchase Amount to proceed further.';
                    } else*/
                    if (newEmandateAmount) {
                        if (newEmandateAmount < $filter('fticInvStringToNumber')($scope.fixedObject.value)) {
                            $scope.errors.paymentMethod = 'Amount entered in ‘Setup a new E-Mandate’ is less than the Purchase Amount, Please modify to proceed further.';
                        } else if (newEmandateAmount.toString().indexOf('.') > -1) {
                            $scope.errors.paymentMethod = 'Amount in ‘Setup a New E-Mandate’ should not contain decimals.';
                        }
                    }
                } else if (paymentMethod === TransactConstant.transact.NET_BANKING) {
                    if (!netBankingDtls) {
                        $scope.errors.paymentMethod = 'Please select bank name and account number in Net Banking to proceed.';
                    }
                }
                if (bankDtlsModel.getPaymentMethodError()) {
                    $scope.errors.paymentMethodError = bankDtlsModel.getPaymentMethodError();
                }
                if (angular.equals($scope.errors, {})) {
                    $scope.navigateToNextStep();
                    makePurchaseCall();
                }
            };

            $scope.onCancelClick = function () {
                if (invSmartSavingsModel.getPurchaseDtls() || invSmartSavingsModel.getSmartSavingsData()) {
                    $scope.$emit('cancelEditPurchase', true);
                } else {
                    reset();
                    $scope.$emit('cancelEditPurchase', false);
                }
            };

            function makePurchaseCall() {
                var validateParams = {};
                validateParams.folioId = invSmartSavingsModel.getPurchaseDtls().selectFolio.folioId;
                validateParams.subDist = invSmartSavingsModel.getPurchaseDtls().advisorDetails.subBrokerCode || '';
                validateParams.subBrokerARN = invSmartSavingsModel.getPurchaseDtls().advisorDetails.subBrokerArn || '';
                validateParams.euinFlag = invSmartSavingsModel.getPurchaseDtls().advisorDetails.euin ? 'Y' : 'N';
                validateParams.euin = invSmartSavingsModel.getPurchaseDtls().advisorDetails.euin || '';
                validateParams.selectedARN = invSmartSavingsModel.getPurchaseDtls().investmentPref.selectedArn || '';
                validateParams.investorMode = invSmartSavingsModel.getPurchaseDtls().investmentPref.investorMode;
                validateParams.advisorMode = invSmartSavingsModel.getPurchaseDtls().investmentPref.advisorMode;
                validateParams.amount = invSmartSavingsModel.getPurchaseDtls().amount;
                validateParams.selectedBank = invSmartSavingsModel.getPurchaseDtls().paymentDtls.selectedBank;
                validateParams.paymentMethod = invSmartSavingsModel.getPurchaseDtls().paymentDtls.paymentMethod;
                validateParams.totalAmount = invSmartSavingsModel.getPurchaseDtls().paymentDtls.totalAmount;
                invSmartSavingsModel.postValidatePurchaseDtls(validateParams).then(validateSuccess, handleFailure);
            }

            $scope.navigateToNextStep = function () {
                var purchaseDetails = {
                    'selectFolio': transactModel.getSelectedFolioDts(),
                    'paymentDtls': invEformPaymentBanksUtility.getPayDetails($scope),
                    'investmentPref': transactNowModel.getInvestPrefer(),
                    'advisorDetails': transactModel.getAdvDetails(),
                    'amount': $scope.fixedObject.value,
                    'fundName': $scope.selections.destinationFund
                };
                invSmartSavingsModel.setPurchaseDtls(purchaseDetails);
            };

            function validateSuccess(data) {
                $scope.$emit('saveInstruction');
            }

            function handleFailure(errorResp) {
                toaster.error(errorResp.data[0].errorDescription);
            }

            $scope.$on(transactEventConstants.transact.INV_FOLIO_SELECTED_CON, function (data) {
                $scope.folioSelObj = transactModel.getSelectedFolioDts();
                $scope.$broadcast('getInvestorPreferenceData');
                if ($scope.instructionType === 'oneTouchInvest') {
                    var selectedInv = {
                        folioId: $scope.folioSelObj.folioId
                    };
                    newFundDetailsInitialLoader.loadAllServices($scope, selectedInv);
                }
            });

            $scope.$on('fundSelected', function () {
                if ($scope.instructionType !== 'oneTouchInvest') {
                    $scope.selections.destinationFund = invSmartSavingsModel.getFundData().getFundDetails;
                }
            });

            var modalInstance;
            $scope.chooseFundsModal = function () {
                modalInstance = $uibModal.open({
                    template: require('../../../common/transact/components/newFundsModal/newFundsModal.html'),
                    scope: $scope
                });
            };

            $scope.showFundCardModal = function (fundId) {
                var modalInstance;
                recommendedFundCardModelService.setFundCardId(fundId);
                modalInstance = $uibModal.open({
                    template: require('../../../common/components/smartSolFundCardModelDetails/smartSolFundCardModel.html'),
                    scope: $scope
                });
            };

            $scope.$on('selectedOption', function (event, data) {
                newFundDetailsModel.setSelectedExistingFund(data);
                $timeout(function () {
                    $scope.selections.destinationFund = data;
                    $scope.$emit(transactEventConstants.transact.FUND_UPDATED);
                }, 0);
            });

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function ($event, ele) {
                $scope.chooseFundsModal();
            });

            $scope.$on('singleSelectionDone', function (event, obj) {
                $scope.selections.destinationFund = obj.selectedOne;
                $scope.$emit(transactEventConstants.transact.FUND_UPDATED);
                $scope.selectedFund = obj.selectedOne;
                $uibModalStack.dismissAll();
            });

            $scope.$on(transactEventConstants.transact.EDIT_FUND, function (event, editFundObj) {
                $scope.selections.destinationFund = angular.copy(editFundObj.fundObj);
                $scope.$emit(transactEventConstants.transact.FUND_UPDATED);
            });

            $scope.$on('removePurchase', function () {
                var removeParams = {};
                invSmartSavingsModel.postRemovePurchaseDtls(removeParams).then(removePurchaseSuccess);
            });

            function removePurchaseSuccess(data) {
                reset();
            }

            function reset() {
                var nullObj = {};
                transactModel.setSelectedFolioDts(nullObj);
                transactNowModel.setInvestPrefer(nullObj);
                transactModel.setAdvDetails(nullObj);
                transactNowModel.hasInvPreferData = false;
                transactNowModel.isInvPreferHasInitialData = true;
                $scope.selections = {};
                $scope.selections.instructionType = $scope.instructionType;
                $scope.fixedObject.value = '';
                bankDtlsModel.setBankName('');
                bankDtlsModel.setIfscCode('');
                bankDtlsModel.setAccountType('');
                $scope.fixedObject.value = '';
                $scope.folioSelObj = '';
                $scope.$broadcast('setpayment');
            }

            $scope.$on('purchaseGetDetails', function (data) {
                if ($scope.fixedObject.value === '') {
                    $scope.fixedObject.value = data.targetScope.invPurchaseData.instructionAmount;
                    //$scope.selections.destinationFund.fundName = data.targetScope.invPurchaseData.fundName;
                    //$scope.selections.destinationFund.productCode = data.targetScope.invPurchaseData.productCode;
                }
            });
        }
    };
};


purchasesDetails.$inject = ['$timeout', '$state', '$filter', 'bankDtlsModel', '$loader', 'transactEventConstants', 'transactModel', 'invSmartSavingsModel', 'transactNowModel', 'newFundDetailsInitialLoader', 'newFundDetailsModel', '$uibModal', 'recommendedFundCardModelService', '$uibModalStack', 'eventConstants', 'invEformPaymentBanksUtility', 'TransactConstant', 'smartSolnFundDetailsModel', 'toaster'];
module.exports = purchasesDetails;
