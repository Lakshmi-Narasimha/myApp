'use strict';
describe('Directive: switchForm', function() {
	var compile,scope,directiveElement,isolatedScope,$window,switchDtlsToReviewModel,$filter,TransactConstant,fundDetailsModel,$stateParams,$timeout,transactEventConstants,transactModel,$state,httpBackend;

	var switchBaseDtlsObjWithAmountEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Amount",        
        amount : 8000
	};

	var switchBaseDtlsObjWithUnitsEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Units",              
        units : 3000
	};	

	var fundDetailsResponse = {
            'fundDetails': [{
                'clearUnits': '8371.015',
                'lastestNav': '62.2344',
                'loadFreeUnits': '0',
                'navDate': '2017-01-16 00:00:00.0',
                'totalAvailableUnits': '8371.015',
                'unitDetails': {
                    'lienUnits': '0',
                    'unitsUnderProcess': '8371.015',
                    'unitsUnderProvisionalStatus': '0'
                },
                'valueOfLoadFreeUnits': '0',
                'valueOfTotalAvailableUnits': '520965.095916'
            }]
        };

    var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

    var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	beforeEach(angular.mock.module('advisor'));	
   
	var getCompiledElement = function(){
		var element = angular.element('<ftic-switch-form></ftic-switch-form>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope, _$compile_,$window,_switchDtlsToReviewModel_,_$filter_,_TransactConstant_,_fundDetailsModel_,_$stateParams_,_$timeout_,_transactEventConstants_,_transactModel_,_$state_,$httpBackend) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};

            $timeout = _$timeout_;
            $state = _$state_;
            $stateParams = _$stateParams_;
            $filter = _$filter_;
            TransactConstant = _TransactConstant_;
            transactEventConstants = _transactEventConstants_;
            transactModel = _transactModel_;
            switchDtlsToReviewModel = _switchDtlsToReviewModel_;
            fundDetailsModel = _fundDetailsModel_;
            fundDetailsModel.setFundDetails(fundDetailsResponse);
            transactModel.setInvestorDetails(investorDetails);
            transactModel.setFundDetails(selectedFundObject);
            httpBackend = $httpBackend;

            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();            
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variables switchCtnBtnDisable,greaterAmtUnitsMsgStaus,typeshow,inputObjs,showNotification on load',function(){                 
        expect(isolatedScope.switchCtnBtnDisable).toBe(true);
        expect(isolatedScope.greaterAmtUnitsMsgStaus).toBe(false);
        expect(isolatedScope.typeshow).toBe(false);

        expect(isolatedScope.inputObjs[0].key).toEqual('amount');
    	expect(isolatedScope.inputObjs[0].text).toEqual('Amount');
    	expect(isolatedScope.inputObjs[0].value).toEqual("");
    	expect(isolatedScope.inputObjs[0].disable).toEqual(true);
    	expect(isolatedScope.inputObjs[0].name).toEqual("switchAmt");
    	expect(isolatedScope.inputObjs[0].type).toEqual("number");
    	expect(isolatedScope.inputObjs[0].isRequired).toEqual(false);

    	expect(isolatedScope.config.showNotification).toBe(false);
    });

	describe('should call the function typeChanged when the switch radio button value changed',function(){
		it('to Full',function(){
			isolatedScope.radios.selectedVal = "Full";
			isolatedScope.typeChanged('Full');
			expect(switchDtlsToReviewModel.getType()).toBe('Full');
			expect(isolatedScope.inputObjs[0].disable).toBe(true);
			expect(isolatedScope.inputObjs[1].disable).toBe(true);
			expect(isolatedScope.inputObjs[0].isRequired).toBe(false);
			expect(isolatedScope.inputObjs[1].isRequired).toBe(false);
			expect(isolatedScope.switchCtnBtnDisable).toBe(false);	
			expect(isolatedScope.inputObjs[1].value).toBe(8371.015);		
		});

		it('to Amount',function(){
			isolatedScope.radios.selectedVal = "Amount";
			isolatedScope.typeChanged('Amount');
			expect(switchDtlsToReviewModel.getType()).toBe('Amount');
			expect(isolatedScope.inputObjs[0].disable).toBe(false);
			expect(isolatedScope.inputObjs[1].disable).toBe(true);
			expect(isolatedScope.inputObjs[0].isRequired).toBe(true);
			expect(isolatedScope.inputObjs[1].isRequired).toBe(false);

			expect(isolatedScope.inputObjs[0].value).toBe("");
			expect(isolatedScope.inputObjs[1].value).toBe("");

			expect(isolatedScope.switchCtnBtnDisable).toBe(false);				
		});

		it('to Units',function(){
			isolatedScope.radios.selectedVal = "Units";
			isolatedScope.typeChanged('Units');
			expect(switchDtlsToReviewModel.getType()).toBe('Units');
			expect(isolatedScope.inputObjs[0].disable).toBe(true);
			expect(isolatedScope.inputObjs[1].disable).toBe(false);
			expect(isolatedScope.inputObjs[0].isRequired).toBe(false);
			expect(isolatedScope.inputObjs[1].isRequired).toBe(true);

			expect(isolatedScope.inputObjs[0].value).toBe("");
			expect(isolatedScope.inputObjs[1].value).toBe("");

			expect(isolatedScope.switchCtnBtnDisable).toBe(false);				
		});
	});

	it('should listen when the event INPUT_CHANGED triggered and if switch type is full',function(){
		switchDtlsToReviewModel.setType('Full');
		isolatedScope.$broadcast('INPUT_CHANGED',{value:8342});
		expect(isolatedScope.inputObjs[0].value).toBe('');
	});

	it('should listen when the event INPUT_CHANGED triggered and if switch type is partial(Amount)',function(){
		switchDtlsToReviewModel.setType('Amount');
		isolatedScope.$broadcast('INPUT_CHANGED',{value:8342,key:'amount'});
		expect(isolatedScope.inputUnit).toBeDefined();
	});

	it('should listen when the event INPUT_CHANGED triggered and if switch type is partial(Unit)',function(){
		switchDtlsToReviewModel.setType('Units');
		isolatedScope.$broadcast('INPUT_CHANGED',{value:8342,key:'units'});
		expect(isolatedScope.inputAmount).toBeDefined();
	});
	
	it('should call previousData when again redirected to this view(if user selects switch type as amount)',function(){						
		$stateParams.key = "switch";
		transactModel.setTransactDetails({"switchDetails":switchBaseDtlsObjWithAmountEntered});		
        directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();            

		$timeout.flush();

		expect(isolatedScope.fundObj).toEqual({
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"
	    });
	    expect(isolatedScope.switchCtnBtnDisable).toBe(false);
	    expect(isolatedScope.switchValues).toBe(switchBaseDtlsObjWithAmountEntered);
	    
	    expect(isolatedScope.inputObjs[0].value).toBe(8000);
	    expect(isolatedScope.radios.selectedVal).toBe("Amount");

	    expect(isolatedScope.inputObjs[0].disable).toBe(false);
	    expect(isolatedScope.inputObjs[0].isRequired).toBe(true);
	});

	it('should call previousData when again redirected to this view(if user selects switch type as units)',function(){						
		$stateParams.key = "switch";
		transactModel.setTransactDetails({"switchDetails":switchBaseDtlsObjWithUnitsEntered});				
        directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();            

		$timeout.flush();

		expect(isolatedScope.fundObj).toEqual({
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"
	    });
	    expect(isolatedScope.switchCtnBtnDisable).toBe(false);
	    expect(isolatedScope.switchValues).toBe(switchBaseDtlsObjWithUnitsEntered);
	    
	    expect(isolatedScope.inputObjs[1].value).toBe(3000);
	    expect(isolatedScope.radios.selectedVal).toBe("Units");

	    expect(isolatedScope.inputObjs[1].disable).toBe(false);
	    expect(isolatedScope.inputObjs[1].isRequired).toBe(true);
	});

	it('should call previousData when again redirected to this view(if user selects switch type as full)',function(){						
		$stateParams.key = "switch";
		transactModel.setTransactDetails({"switchDetails":
			{
				destinationFund: {
			        "accNo": "0010008062712",
			        "fundOptDesc": "Franklin India PRIMA FUND"},
		        switchType : "Full",
		        type : "Full",        
		        amount : 8000,
		        units : 3000
			}
		});				
        directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();            

	    expect(isolatedScope.switchValues.switchType).toBe("Full");
	    
	    expect(isolatedScope.inputObjs[0].value).toBe(8000);
	    expect(isolatedScope.inputObjs[1].value).toBe(3000);
	    expect(isolatedScope.radios.selectedVal).toBe("Full");
	});

	it('should listen the event transactEventConstants.transact.SWITCH_FORM_RESET when triggered',function(){
		spyOn(isolatedScope,"typeChanged");
		isolatedScope.$broadcast(transactEventConstants.transact.SWITCH_FORM_RESET);
        expect(isolatedScope.radios.selectedVal).toBe('');
        expect(isolatedScope.inputObjs[0].value).toBe('');
        expect(isolatedScope.inputObjs[1].value).toBe('');
        expect(isolatedScope.typeChanged).toHaveBeenCalled();
	});

	describe('should call function postStpDetails when clicked on continue button',function(){
		beforeEach(function(){
			spyOn(isolatedScope,"$emit");
			isolatedScope.postStpDetails();
		});

		it('and show error message if switch type is not selected not',function(){
			expect(isolatedScope.typeshow).toBe(true);
		});

		it('and update the variables isSameFund,showNotification',function(){
			expect(isolatedScope.isSameFund).toBe(false);
			expect(isolatedScope.config.showNotification).toBe(false);
		});		

		it('and emit an event SwitchFormSubmit',function(){
			expect(isolatedScope.$emit).toHaveBeenCalledWith("SwitchFormSubmit");
		});

		it('and update the amount input box when Switch type full is selected',function(){
			isolatedScope.radios.selectedVal = "Full";
			isolatedScope.postStpDetails();
			expect(isolatedScope.inputObjs[1].value).toBe(8371.015);			
		});

		it('and show the notification if entered values in Amount text box greater then the amount in fund details',function(){
			isolatedScope.radios.selectedVal = "Amount";			
			isolatedScope.typeChanged('Amount');
			isolatedScope.inputObjs[0].value = 530965.00;
			isolatedScope.postStpDetails();			
			expect(isolatedScope.greaterAmtUnitsMsgStaus).toBe(true);
		});

		it('and show the notification if entered values in Units text box greater then the amount in fund details',function(){
			isolatedScope.radios.selectedVal = "Units";			
			isolatedScope.typeChanged('Units');
			isolatedScope.inputObjs[1].value = 8378.90;
			isolatedScope.postStpDetails();			
			expect(isolatedScope.greaterAmtUnitsMsgStaus).toBe(true);
		});		
	});
});    