// TransactionStatusDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InvestorSearchResultModelSchema = new mongoose.Schema({
    investorSearchResult: {
        type: Array,
        "default": []
    }
});

var InvestorSearchResultModelLookUp = mongoose.model('InvestorSearchResultModelLookUp', InvestorSearchResultModelSchema);

var InvestorSearchResultModel = new InvestorSearchResultModelLookUp({
    "investorSearchResult" : [{
        "basisInvestorSearchResult": [{
            "unitHolderName": "Shankar Narayanan",
            "pan": "ABCD1234KF",
            "folioNo": 17932569,
            "modeOfHolding": "Joint",
            "mobile": 9039758625,
            "email": "shankarnarayanan@gmail.com",
            "city": "Chennai",
            "holders": {
                "firstHoldersName": "Swapnil",
                "secondHoldersName": "Ramesh",
                "minorGuardian": "Suresh"
            },
            "active":true
        }, {
            "unitHolderName": "Shankar BK",
            "pan": "MKLK1234IJ",
            "folioNo": 3896503,
            "modeOfHolding": "Joint",
            "mobile": 9049758635,
            "email": "shankar.bk@gmail.com",
            "city": "Chennai",
            "holders": {
                "firstHoldersName": "Vamsi",
                "secondHoldersName": "Ramesh",
                "minorGuardian": "Suresh"
            },
            "active":false
        }, {
            "unitHolderName": "Shankar Bansal",
            "pan": "OIUH1234GH",
            "folioNo": 2648571,
            "modeOfHolding": "single",
            "mobile": 9059758645,
            "email": "shankar.bansal@gmail.com",
            "city": "Chennai",
            "holders": {
                "firstHoldersName": "Suresh",
                "secondHoldersName": "Vamsi",
                "minorGuardian": "Ramesh"
            },
            "active":true
        }]
    }]    
});

InvestorSearchResultModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorSearchResultModelLookUp table, please contact admin...');
    } else {
        InvestorSearchResultModelLookUp.remove({}, function(err) {
            console.log('InvestorSearchResultModelLookUp collection removed');
            InvestorSearchResultModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvestorSearchResultModelLookUp table, please contact admin...');
                }
                console.log('InvestorSearchResultModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorSearchResultModelLookUp;