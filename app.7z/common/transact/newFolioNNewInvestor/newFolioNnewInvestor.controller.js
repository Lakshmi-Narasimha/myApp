/**
 * @ngdoc property
 * @name newFolioNnewInvestorController 
 * @requires $scope
 *
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function newFolioNnewInvestorController($scope, transactModel, TransactConstant, folioValidationInitialLoader, folioValidationModelService, $state, transactEventConstants, selectInvestorModel, configUrlModel, appConfig, $window, ekycVerificationModel, authenticationService, kycRegisterStatusModel) {
    var configURL = configUrlModel.getEnvUrl('MARKETING_URL');
    var pdfUrl = appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL;
    $scope.openFlow = true;
    $scope.showNotification = false;
    $scope.modeOfHoldingOptions = [{
        label: "Single",
        value: "single",
        selected: false,
        nameLbl: "mode",
        check: true,
        selectedVal: ""
    }, {
        label: "Either or Survivor",
        value: "eitherRSurvivor",
        selected: false,
        nameLbl: "mode",
        check: true,
        selectedVal: ""
    }];
    $scope.isTransactNowNewFolio = false;
    $scope.radios = {};
    $scope.holderDetails = [];
    $scope.rawHolderDetails = [];
    $scope.shwSecondChkKyc = true;
    $scope.shwThirdChkKyc = true;
    $scope.group = [];
    $scope.holderDetail = ['Firstholder', 'Secondholder', 'Thirdholder']
    $scope.kycFlow = false;
    $scope.closeFlow = false;
    $scope.newInvestorDetails = null;
    $scope.resultObj;
    $scope.firstHolderKyc = "";
    var instantKycVals;
    $scope.trnstNwKycFlow = false;
    $scope.folioMatcherParams = [];
    $scope.noRecFound = false;
    $scope.checkTerms = {
        label: "I give consent to FT to access details from AADHAAR database on behalf of all the unit holders.",
        value: "",
        required: true,
        name: 'checkTerms'
    }
    $scope.formLabel = $scope.moduleUrl === '/newFolioNnewInvestor' ? "PAN / PEKRN or Aadhaar" : "PAN / PEKRN";
    transactModel.kycNotRegPan = "";

    $scope.NewInv = transactModel.isNewInvestor;
    $scope.NewFolio = transactModel.getIsNewFolio();
    $scope.isInvestorLoggedIn = authenticationService.isInvestorLoggedIn();

    $scope.moduleUrl = $state.current.url;
    if ($scope.moduleUrl === '/trnsctNowNewFolio') {
        $scope.NewFolio = false;
        $scope.isTransactNowNewFolio = true;
    }
    if(!((transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") && $state.current.parent == 'invTransact')){
            transactModel.setStateValue({
                key: TransactConstant.transact.Fund_Key
            });
        }

    if (transactModel.isNewInvestor && $scope.moduleUrl == '/newFolioNnewInvestor') {
        $scope.newInvestorDetails = transactModel.getNewInvestorData();
        if ($scope.newInvestorDetails !== null) {
            $scope.rawHolderDetails.push($scope.newInvestorDetails);
            transactModel.setrawHolderDts($scope.rawHolderDetails);
            $scope.header.title = "Investor registration";
            if ($scope.newInvestorDetails.fromKRA && ($scope.newInvestorDetails.data.kycStatus === "KYC-Registered" || $scope.newInvestorDetails.data.kycStatus === "A" || $scope.newInvestorDetails.data.kycStatus === "KYC Registered-New KYC" || $scope.newInvestorDetails.data.kycStatus === "KYC - Registered")) {
                $scope.holderPan = $scope.newInvestorDetails.data.pan.replace(/\s+/g, ' ').trim();
                if ($scope.holderPan === "" || $scope.holderPan === " " || $scope.holderPan === "null" || !$scope.holderPan) {
                    $scope.holderPan = transactModel.getSelectInvestorValue();
                }
                $scope.firstHolderDetails = transactModel.setInvTileData($scope.newInvestorDetails.data.custName, $scope.holderPan, $scope.newInvestorDetails.data.holders[0].aadharNo, "Registered", "First Holder Name");
                //$scope.firstHolderKyc=true;
                $scope.firstHolderKyc = "KYC - Registered"
                $scope.group.push({
                    'name': $scope.newInvestorDetails.data.custName,
                    'type': 'Firstholder',
                    'pan': $scope.newInvestorDetails.data.pan
                });
            } else {
                var pan = "",
                    aadhaar = "";
                if ($scope.newInvestorDetails.data.searchOption === "PAN") {
                    pan = $scope.newInvestorDetails.data.panORaadhar;
                } else if ($scope.newInvestorDetails.data.searchOption === "Aadhaar") {
                    aadhaar = $scope.newInvestorDetails.data.panORaadhar;
                }
                $scope.firstHolderDetails = transactModel.setInvTileData("NA", pan, aadhaar, "Not Registered", "First Holder Name");
                $scope.group.push({
                    'name': null,
                    'type': 'Firstholder',
                    'pan': $scope.newInvestorDetails.data.panORaadhar
                });
                //$scope.firstHolderKyc=false;
                $scope.kycFlow = true;
                if ($scope.newInvestorDetails.data.searchOption === "Aadhaar") {
                    transactModel.setAadhaarNo($scope.newInvestorDetails.data.panORaadhar);
                }
            }

        }
    } else if (!transactModel.isNewInvestor && $scope.moduleUrl == '/newFolioNnewInvestor') {
        $scope.investorDetails = transactModel.getInvestorDetails();
        $scope.header.title = "New Folio";
        if ($scope.investorDetails != null) {
            if (!$scope.isInvestorLoggedIn) {
                for (var i = 0; i < $scope.investorDetails.holders.length; i++) {
                    if ($scope.investorDetails.holders[i].type == "Firstholder") {
                        $scope.rawHolderDetails.push($scope.investorDetails.holders[i]);
                        transactModel.setrawHolderDts($scope.rawHolderDetails);
                        $scope.firstHolderPan = $scope.investorDetails.holders[i].pan;
                        $scope.firstHolderAadhaar = $scope.investorDetails.holders[i].aadharNo;
                        $scope.firstHolderName = $scope.investorDetails.holders[i].name;
                        $scope.firstHolderKyc = $scope.investorDetails.holders[i].kycStatus;
                        //$scope.firstHolderKyc=false;
                    }
                }
                $scope.firstHolderDetails = transactModel.setInvTileData($scope.firstHolderName, $scope.firstHolderPan, $scope.firstHolderAadhaar, $scope.firstHolderKyc, "First Holder Name");
            } else {
                /*var holderDetails = [];
                holderDetails.push({
                    'name': $scope.investorDetails.name,
                    'pan': $scope.investorDetails.pan
                });
                angular.extend(holderDetails, $scope.investorDetails);*/

                $scope.investorDetails.type = "Firstholder";
                $scope.firstHolderPan = $scope.investorDetails.pan;
                $scope.firstHolderName = $scope.investorDetails.name;
                //$scope.firstHolderKyc = (angular.lowercase($scope.investorDetails.kycStatus) === 'yes' ? 'KYC - Registered' : 'KYC - Not Registered');
                $scope.firstHolderKyc = kycRegisterStatusModel.checkKycStatus($scope.investorDetails.kycStatus) ? 'KYC - Registered' : 'KYC - Not Registered';
                $scope.rawHolderDetails.push($scope.investorDetails);
                transactModel.setrawHolderDts($scope.rawHolderDetails);
                $scope.firstHolderDetails = transactModel.setInvTileData($scope.firstHolderName, $scope.firstHolderPan, $scope.firstHolderKyc, "First Holder Name");
            }

            $scope.group.push({
                'name': $scope.firstHolderName,
                'type': 'Firstholder',
                'pan': $scope.firstHolderPan
            });

            if ($scope.firstHolderKyc != "KYC - Registered") {
                $scope.kycFlow = true;
            }
        }
    } else if ($scope.moduleUrl !== '/newFolioNnewInvestor') {
        $scope.trNwFirstHolder = null;
        $scope.trNwFirstHolder = transactModel.getUnitHolder();
        $scope.trNwFirstHolderDetails = transactModel.setInvTileData($scope.trNwFirstHolder.unitHolder, $scope.trNwFirstHolder.pan, $scope.trNwFirstHolder.aadharNo, $scope.trNwFirstHolder.kycStatus, "First Holder Name");
        $scope.group.push({
            'name': $scope.trNwFirstHolder.unitHolder,
            'type': 'Firstholder',
            'pan': $scope.trNwFirstHolder.pan
        });
        $scope.rawHolderDetails.push($scope.trNwFirstHolder);
        transactModel.setrawHolderDts($scope.rawHolderDetails);

        //$scope.trNwFirstHolder.kycStatus = "KYC - NOT Registered"
        if ($scope.trNwFirstHolder.kycStatus === 'KYC - Not Registered' || $scope.trNwFirstHolder.kycStatus === 'Not Available') {
            $scope.kycFlow = true;
        }

    }


    $scope.listenChange = function(data) {
        if (data !== $scope.selectedMode && ($scope.rawHolderDetails && $scope.rawHolderDetails.length - 1 !== 0)) {
            angular.forEach($scope.rawHolderDetails, function(value, key) {
                if (key > 0) {
                    $scope.removeItem(key - 1);
                }
            });
        }
        transactModel.transactModeOfHolding = data;
        $scope.selectedMode = $scope.radios.selectedVal;
        $scope.modeOfHoldingOptions[0].selectedVal = data;
        $scope.modeOfHoldingOptions[1].selectedVal = data;
        if (data == "eitherRSurvivor") {
            $scope.showSecondHolder = true;
            $scope.shwSecondChkKyc = true;
            $scope.shwThirdChkKyc = true;
            $scope.disableAddJoinee = true;
        } else if (data == "single" && $scope.moduleUrl == '/newFolioNnewInvestor') {
            if (($scope.firstHolderKyc == "KYC - Registered" || $scope.firstHolderKyc == "A" || $scope.firstHolderKyc == "KYC-Registered" || $scope.firstHolderKyc == "KYC Registered-New KYC") && transactModel.isCreateFolio) {
                $scope.kycFlow = false;
            } else {
                $scope.kycFlow = true;
            }
        } else if (data == "single" && $scope.moduleUrl !== '/newFolioNnewInvestor') {
            if ($scope.trNwFirstHolder.kycStatus == "KYC - Registered" || $scope.trNwFirstHolder.kycStatus == "A" || $scope.trNwFirstHolder.kycStatus == "KYC-Registered" || $scope.trNwFirstHolder.kycStatus == "KYC Registered-New KYC") {
                $scope.kycFlow = false;
            } else if ($scope.trNwFirstHolder.kycStatus == "KYC - Not Registered") {
                $scope.kycFlow = true;
            }
        }
    };

    $scope.addJoinee = function() {
        $scope.FolioNInvestorForm.$submitted = false;
        if ($scope.rawHolderDetails.length == 1 && $scope.shwSecondChkKyc) {
            $scope.showSecondHolder = true;
            $scope.disableAddJoinee = true;
            transactModel.kycNotRegPan = "";
        } else {
            $scope.showThirdHolder = true;
            transactModel.kycNotRegPan = $scope.holderDetails[0][0].value;
        }
    }


    $scope.removeItem = function(index) {
        $scope.rawHolderDetails.splice(index + 1, 1);
        transactModel.setrawHolderDts($scope.rawHolderDetails);
        $scope.holderDetails.splice(index, 1);
        $scope.disableAddJoinee = false;
        if (index === 0 && $scope.rawHolderDetails.length == 1) {
            $scope.showSecondHolder = false;
            $scope.shwSecondChkKyc = true;
            transactModel.kycNotRegPan = "";
            if (($scope.firstHolderKyc === 'KYC - Registered' || $scope.firstHolderKyc == "A" || $scope.firstHolderKyc == "KYC-Registered" || $scope.firstHolderKyc == "KYC Registered-New KYC") && $scope.moduleUrl === '/newFolioNnewInvestor')
                $scope.kycFlow = false;
            else
                $scope.kycFlow = true;
            if (($scope.firstHolderKyc === 'KYC - Registered' || $scope.firstHolderKyc == "A" || $scope.firstHolderKyc == "KYC-Registered" || $scope.firstHolderKyc == "KYC Registered-New KYC") && $scope.moduleUrl !== '/newFolioNnewInvestor')
                $scope.kycFlow = false;
            else
                $scope.kycFlow = true;
        }
        if (index === 0 && $scope.rawHolderDetails.length == 2) {
            $scope.showThirdHolder = false;
            $scope.shwThirdChkKyc = true;
            transactModel.kycNotRegPan = "";
            $scope.instntKycSecHolder = $scope.instntKycThrdHolder ? true : false;
            if ((($scope.firstHolderKyc === 'KYC - Registered' || $scope.firstHolderKyc == "A" || $scope.firstHolderKyc == "KYC-Registered" || $scope.firstHolderKyc == "KYC Registered-New KYC") && $scope.rawHolderDetails[1].kycSource === 'KRA Verified') && $scope.moduleUrl === '/newFolioNnewInvestor')
                $scope.kycFlow = false;
            else
                $scope.kycFlow = true;
                if($scope.trNwFirstHolder){
                    if ((($scope.trNwFirstHolder.kycStatus === 'KYC - Registered' || $scope.trNwFirstHolder.kycStatus == "A" || $scope.trNwFirstHolder.kycStatus == "KYC-Registered" || $scope.trNwFirstHolder.kycStatus == "KYC Registered-New KYC") && $scope.rawHolderDetails[1].kycSource === 'KRA Verified') && $scope.moduleUrl !== '/newFolioNnewInvestor')
                        $scope.kycFlow = false;
                    else
                        $scope.kycFlow = true;
                }
        } else if (index === 1) {
            transactModel.kycNotRegPan = $scope.holderDetails[0][0].value;
            $scope.showThirdHolder = false;
            $scope.shwThirdChkKyc = true;
            $scope.holderDetails[0][1].key = "Second Holder Name";
            if (((($scope.firstHolderKyc === 'KYC - Registered' || $scope.firstHolderKyc == "A" || $scope.firstHolderKyc == "KYC-Registered" || $scope.firstHolderKyc == "KYC Registered-New KYC")) && $scope.rawHolderDetails[1].kycSource === 'KRA Verified') && $scope.moduleUrl === '/newFolioNnewInvestor')
                $scope.kycFlow = false
            else
                $scope.kycFlow = true;
            if ((($scope.trNwFirstHolder.kycStatus === 'KYC - Registered' || $scope.trNwFirstHolder.kycStatus == "A" || $scope.trNwFirstHolder.kycStatus == "KYC-Registered" || $scope.trNwFirstHolder.kycStatus == "KYC Registered-New KYC") && $scope.rawHolderDetails[1].kycSource === 'KRA Verified') && $scope.moduleUrl !== '/newFolioNnewInvestor')
                $scope.kycFlow = false
            else
                $scope.kycFlow = true;
        }

    }

    $scope.disableCont = function() {
        if (!$scope.FolioNInvestorForm.$valid)
            return true;
        if ($scope.selectedMode == "single") {
           return ($scope.firstHolderDetails.length > 0 ? ($scope.firstHolderDetails[1].value === 'NA' ? true : false) : true);
        } else if ($scope.selectedMode == "eitherRSurvivor") {
            if ($scope.showSecondHolder && $scope.showThirdHolder)
                return $scope.shwSecondChkKyc || $scope.shwThirdChkKyc;
            else if ($scope.showSecondHolder && !$scope.showThirdHolder)
                return $scope.shwSecondChkKyc;
            else if (!$scope.showSecondHolder && !$scope.showThirdHolder)
                return false;
        }
    }


    $scope.$on("holderDtls", function(event, data) {
        if (data.kycSource === 'Not available' && $scope.moduleUrl == '/trnsctNowNewFolio') {
            var holderType = $scope.holderDetails.length == 0 ? "Secondholder" : "Thirdholder";
            $scope.rawHolderDetails.push(data);
            $scope.holderDetails.push([{}]);
            $scope.$emit('kycregstion', holderType);
            $scope.kycFlow = true;
            return;
        }
        //this logic should be changed once we get update from business
        $scope.rawHolderDetails.push(data);
        transactModel.setrawHolderDts($scope.rawHolderDetails);
        $scope.holderDetails.length == 0 ? $scope.shwSecondChkKyc = false : $scope.shwThirdChkKyc = false;
        var kycStatus = data.kycSource !== "KRA Verified" ? "KYC - Not Registered" : "KYC - Registered",
            holderKey = $scope.holderDetails.length == 0 ? "Second Holder Name" : "Third Holder Name";
        var invTileData;
        if (!$scope.isInvestorLoggedIn) {
            invTileData = transactModel.setInvTileData(data.fullName, data.kycId, data.aadhaarNo, kycStatus, holderKey); // Aadhaar property is not returned in /validateKyc service response. Correct property name needs to be changed
        } else {
            invTileData = transactModel.setInvTileData(data.fullName, data.kycId, kycStatus, holderKey);
        }
        $scope.holderDetails.push(invTileData);
        $scope.group.push({
            'name': data.fullName,
            'type': $scope.holderDetails.length == 1 ? "Secondholder" : "Thirdholder",
            'pan': $scope.firstHolderPan == undefined ? data.appPanNo : $scope.firstHolderPan
        });

        $scope.disableAddJoinee = false;
        if (data.kycSource !== "KRA Verified" && $scope.moduleUrl === '/newFolioNnewInvestor')
            $scope.kycFlow = true;
        if (data.kycSource !== "KRA Verified" && $scope.moduleUrl === '/trnsctNowNewFolio')
            $scope.kycFlow = true;
        event.stopPropagation();
    });

    $scope.physicalKycValidation = function() {
        $scope.phyResult = false;
        angular.forEach($scope.resultObj, function(value, key) {
            if ($scope.resultObj[key].aadhar == "" || null || undefined) {
                $scope.phyResult = true;
            }
        });
        return $scope.phyResult;
    }

    $scope.findItemInFilter = function(objArr, value) {
        var obj = null;
        obj = (_.filter(objArr, function(x) {
            return x.type == value;
        }))[0];
        return obj;
    };

    $scope.panOrNot = function(value) {
        var patt2 = /^([a-zA-Z]{5})(\d{4})([a-zA-Z]{1})$/;
        var result = patt2.test(value);
        return result;
    }

    $scope.submitKyc = function() {
        $scope.shwErr = false;
        if ($scope.FolioNInvestorForm.$valid) {
            if ($scope.selectedMode == "eitherRSurvivor" && $scope.holderDetails.length == 0 && !$scope.noRecFound) {
                $scope.shwErr = true;
                return;
            }
            $scope.$broadcast(transactEventConstants.transact.INSTANT_KYC);
            $scope.resultObj = $scope.FolioNInvestorForm.kycVal;
            if ($scope.physicalKycValidation()) {
                $window.open(pdfUrl, "_blank");
                $scope.closeFlow = true;
                $scope.openFlow = false;
            } else {
                transactModel.setrawHolderDts($scope.rawHolderDetails);
                instantKycVals = $scope.group;
                angular.forEach($scope.group, function(obj, key) {
                    instantKycVals[key].Title = (obj.type == 'Secondholder' ? "Second Holder Details" : "Third holder Details" && obj.type == 'Firstholder' ? "First Holder Details" : "Third holder Details")
                    instantKycVals[key].name = obj.name || '';
                    instantKycVals[key].pan = obj.pan || '';


                    if (!obj.name) {
                        var foundObjNonKyc = $scope.findItemInFilter($scope.resultObj, obj.type);
                        instantKycVals[key] = foundObjNonKyc;
                        instantKycVals[key].kycStatus = 'KYC - Not Registered';
                    } else {
                        instantKycVals[key].kycStatus = 'KYC - Registered';
                    }

                    if (!$scope.panOrNot(obj.pan)) {
                        instantKycVals[key].pan = '';
                    }
                })
                transactModel.setInstantKyc(instantKycVals);
                if ($scope.moduleUrl == "/newFolioNnewInvestor") {
                    $state.go("invTransact.ekycVerification");
                } else {
                    $state.go("transactnow.ekycVerification"); 
                }
            }
        }
    }


    $scope.onCancel = function() {
        if($scope.isInvestorLoggedIn) {
            if ($scope.moduleUrl === '/newFolioNnewInvestor') {
                if (($state.current.name == "BUYFUND" || transactModel.getTransactType() == "BUY")) {
                    $state.go('invTransact.base.buy');
                } else if ((transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP")) {
                    transactModel.setStateValue({ key: null });
                    $state.go('invTransact.base.sip');
                }
            }
        } else {
            if ($scope.moduleUrl == '/trnsctNowNewFolio') {
                if (transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") {
                    $state.go('transactnow.baseNow.buy');
                    return;
                } else if (transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") {
                    $state.go('transactnow.baseNow.sip');
                    return;
                } else if (transactModel.getTransactType() == TransactConstant.renewSip.RENEWSIP) {
                    $state.go('transactnow.baseNow.renewSip');
                    return;
                }
            } else if ($scope.moduleUrl !== '/newFolioNnewInvestor') {
                if ((transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") && transactModel.isNewInvestor) {
                    $state.go('transact.base.buy');
                    return;
                } else if ((transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") && transactModel.isNewInvestor) {
                    $state.go('transact.base.sip');
                    return;
                }
            }
        }
    }

    function setInstantKycDetails() {
        var instantKycDetails = angular.copy(transactModel.getFolioMatcherParams());
        for (var i = 0; i < $scope.rawHolderDetails.length; i++) {

            if ($scope.rawHolderDetails[i].kycStatus === "KYC - Registered" || $scope.rawHolderDetails[i].kycStatus === "A" || $scope.rawHolderDetails[i].kycStatus === "KYC-Registered" || $scope.rawHolderDetails[i].kycStatus === "KYC Registered-New KYC") {
                instantKycDetails[i].kycStatus = "KYC - Registered";
                instantKycDetails[i].name = $scope.rawHolderDetails[i].name || $scope.rawHolderDetails[i].unitHolder || $scope.rawHolderDetails[i].fullName;
                instantKycDetails[i].pan = $scope.rawHolderDetails[i].pan || $scope.rawHolderDetails[i].kycId;
                instantKycDetails[i].kycMode = $scope.rawHolderDetails[i].kycMode || $scope.rawHolderDetails[i].modeOfKyc || "";
                instantKycDetails[i].kycSource = $scope.rawHolderDetails[i].kycSource || "";
                instantKycDetails[i].kycStatus = $scope.rawHolderDetails[i].kycStatus || "";
                instantKycDetails[i].appIPVFlag = $scope.rawHolderDetails[i].appIPVFlag || $scope.rawHolderDetails[i].ipvFlag || "";
                if (instantKycDetails[i].aadhar && (instantKycDetails[i].aadhar !== 'null' || instantKycDetails[i].aadhar !== " ")) {
                    instantKycDetails[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo || transactModel.getrawHolderDts()[i].aadhar;
                }
            } else if ($scope.rawHolderDetails[i].kycStatus == "Yes") {
                instantKycDetails[i].kycStatus = "KYC - Registered";
                instantKycDetails[i].name = $scope.rawHolderDetails[i].name || $scope.rawHolderDetails[i].unitHolder || $scope.rawHolderDetails[i].fullName;
                instantKycDetails[i].pan = $scope.rawHolderDetails[i].pan || $scope.rawHolderDetails[i].kycId;
                instantKycDetails[i].kycMode = $scope.rawHolderDetails[i].holders[i].kycMode || $scope.rawHolderDetails[i].holders[i].modeOfKyc || "";
                instantKycDetails[i].kycSource = $scope.rawHolderDetails[i].holders[i].kycSource || "";
                //instantKycDetails[i].kycStatus = $scope.rawHolderDetails[i].holders[i].kycStatus || "";
                instantKycDetails[i].appIPVFlag = $scope.rawHolderDetails[i].holders[i].appIPVFlag || $scope.rawHolderDetails[i].holders[i].ipvFlag || "";
                if (instantKycDetails[i].aadhar && (instantKycDetails[i].aadhar !== 'null' || instantKycDetails[i].aadhar !== " ")) {
                    instantKycDetails[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo || transactModel.getrawHolderDts()[i].aadhar;
                }
            } else {
                if ($scope.rawHolderDetails[i].kycStatus === "05" || $scope.rawHolderDetails[i].kycStatus === "KYC - Not Registered") {
                    instantKycDetails[i].kycStatus = "KYC - Not Registered";
                    instantKycDetails[i].kycSource = $scope.rawHolderDetails[i].kycSource;
                }
            }

        }

        for (var i = 0; i < instantKycDetails.length; i++) {
            if (instantKycDetails[i].kycStatus !== "KYC - Registered" || instantKycDetails[i].kycStatus !== "A" || instantKycDetails[i].kycStatus !== "KYC-Registered" || instantKycDetails[i].kycStatus !== "KYC Registered-New KYC" || instantKycDetails[i].kycStatus !== "Yes") {
                if ($scope.resultObj) {
                    for (var j = 0; j < $scope.resultObj.length; j++) {
                        if (instantKycDetails[i].type === $scope.resultObj[j].type) {
                            instantKycDetails[i].aadhar = $scope.resultObj[j].aadhar;
                            instantKycDetails[i].Title = $scope.resultObj[j].Title;
                            instantKycDetails[i].email = $scope.resultObj[j].email;
                            instantKycDetails[i].mobile = $scope.resultObj[j].mobile;
                        }
                    }
                }
            }
            if (instantKycDetails[i].type == "Firstholder") {
                instantKycDetails[i].Title = "First Holder Details";
            } else if (instantKycDetails[i].type == "Secondholder") {
                instantKycDetails[i].Title = "Second Holder Details";
            } else {
                instantKycDetails[i].Title = "Third Holder Details";
            }
        }
        transactModel.setInstantKyc(instantKycDetails);
    }
    $scope.continue = function() {
        debugger
        $scope.shwErr = false;
        if ($scope.FolioNInvestorForm.$valid) {
            transactModel.setrawHolderDts($scope.rawHolderDetails);
            if ($scope.selectedMode == "eitherRSurvivor" && $scope.holderDetails.length == 0 && !$scope.noRecFound) {
                $scope.shwErr = true;
                return;
            }
            $scope.$broadcast(transactEventConstants.transact.INSTANT_KYC);
            $scope.resultObj = $scope.FolioNInvestorForm.kycVal;
            $scope.resultObj = $scope.FolioNInvestorForm.kycVal;
            if ($scope.physicalKycValidation()) {
                $window.open(pdfUrl, "_blank");
                $scope.closeFlow = true;
                $scope.openFlow = false;
            } else {
                $scope.folioMtchPrms();
                /* if ($scope.moduleUrl === '/trnsctNowNewFolio') {
                     for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                         $scope.headerOnPopUp = "";
                         $scope.noBtnTxt = "Cancel";
                         $scope.yesBtnTxt = "Continue with KYC";
                         $scope.txtOnPopUp = "Please complete KYC registration of all the holders to proceed with the transaction.";
                         $scope.popUpMainHeader = "";
                         //transactModel.getrawHolderDts()[0].kycStatus = ""
                         if (i == 0 && transactModel.getrawHolderDts()[0].kycStatus !== "KYC - Registered") {
                             $scope.showNotification = true;
                             $scope.trnstNwKycFlow = true;
                             return;
                         } else if (i !== 0 && transactModel.getrawHolderDts()[i].kycSource !== "KRA Verified") {
                             $scope.showNotification = true;
                             $scope.trnstNwKycFlow = true;
                             $scope.noRecFound = true;
                             return;
                         }
                     }
                 }*/

                if ($scope.moduleUrl == '/trnsctNowNewFolio' || $scope.moduleUrl == '/newFolioNnewInvestor') {
                    folioValidationInitialLoader.loadAllServices($scope, $scope.folioMatcherParams);

                    // var instantKycDetails = angular.copy($scope.folioMatcherParams);
                    $scope.$on(transactEventConstants.transact.Folio_Validation, function() {
                        // for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                        //     if($scope.rawHolderDetails[i].kycStatus === "KYC - Registered" || $scope.rawHolderDetails[i].kycStatus === "A" || $scope.rawHolderDetails[i].kycStatus === "KYC-Registered"){
                        //         instantKycDetails[i].Title = (i == 0) ? "First Holder Details" : (i == 1 ? "Second Holder Details" : "Third Holder Details");
                        //         instantKycDetails[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo;
                        //         instantKycDetails[i].kycStatus = transactModel.getrawHolderDts()[i].kycStatus;
                        //     }else{
                        //         if($scope.rawHolderDetails[i].kycStatus === "05" || $scope.rawHolderDetails[i].kycStatus === "KYC - Not Registered"){
                        //             instantKycDetails[i].kycStatus = "KYC - Not Registered";
                        //         }
                        //     }
                        // }
                        // transactModel.setInstantKyc(instantKycDetails);


                        //Setting instant KYC-Details
                        setInstantKycDetails();

                        if (folioValidationModelService.getFolioValidationDtls().patternExists == 'true') {
                            $scope.headerOnPopUp = "The similar holding pattern is available for investor";
                            $scope.noBtnTxt = "Continue to Existing Folio";
                            $scope.yesBtnTxt = "Create new Folio";
                            $scope.txtOnPopUp = "Do you want to continue creating newfolio";
                            $scope.popUpMainHeader = "";
                            $scope.showNotification = true;
                            return;
                        } else if (folioValidationModelService.getFolioValidationDtls().patternExists == 'false') {
                            transactModel.setIsNewFolio(true);
                            if ($scope.moduleUrl == '/newFolioNnewInvestor' && $state.current.parent == 'smartSol.planSmartSolution') {
                                var instantKycDetails = angular.copy($scope.folioMatcherParams);
                                for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                                    instantKycDetails[i].Title = (i == 0) ? "First Holder Details" : (i == 1 ? "Second Holder Details" : "Third Holder Details");
                                    instantKycDetails[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo;
                                }
                                transactModel.setInstantKyc(instantKycDetails);
                                transactNowEKYVerify();
                                $state.go('smartSol.planSmartSolution.newFolioNnewInvestor.ekyc');
                            } else if ($scope.moduleUrl == '/newFolioNnewInvestor') {
                                var instantKycDetails = angular.copy($scope.folioMatcherParams);
                                for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                                    instantKycDetails[i].Title = (i == 0) ? "First Holder Details" : (i == 1 ? "Second Holder Details" : "Third Holder Details");
                                    instantKycDetails[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo;
                                }
                                transactModel.setInstantKyc(instantKycDetails);
                                if($scope.moduleUrl == '/trnsctNowNewFolio') {
                                    transactNowEKYVerify();
                                }
                                $state.go('invTransact.ekycVerification');
                                return;
                            } else if ($scope.moduleUrl == '/trnsctNowNewFolio') {
                                //$state.go('transactnow.ekyc');
                                transactNowEKYVerify();
                                return;
                            }
                        }
                    });
                } else if (!transactModel.isNewInvestor || ($scope.moduleUrl !== '/newFolioNnewInvestor' && $scope.moduleUrl !== '/trnsctNowNewFolio')) {
                    var instantKycDetails = angular.copy($scope.folioMatcherParams);
                    for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                        instantKycDetails[i].Title = (i == 0) ? "First Holder Details" : (i == 1 ? "Second Holder Details" : "Third Holder Details");
                        instantKycDetails[i].aadhar = transactModel.getrawHolderDts()[i].aadharNo;
                    }
                    transactModel.setInstantKyc(instantKycDetails);
                    $state.go('transact.ekyc');
                    return;
                } else if ((transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") && transactModel.isNewInvestor) {
                    transactModel.setStateValue({ key: "Fund" });
                    $state.go('transact.base.buy', { key: TransactConstant.transact.Fund_Key });
                    return;
                } else if ((transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") && transactModel.isNewInvestor) {
                    transactModel.setStateValue({ key: "Fund" });
                    $state.go('transact.base.sip', { key: TransactConstant.transact.Fund_Key });
                    return;
                }
            }
        }
    }

    var transactNowEKYVerify = function() {
        var folioNo = folioValidationModelService.getFolioValidationDtls().folioNo;
        if (folioNo === "does not exits") {
            folioNo = "NEW";
        }
        $scope.folioDetailsObj = {
            "folioId": folioNo, //folioValidationModelService.getFolioValidationDtls().folioNo,
            "firstHolder": transactModel.getFolioMatcherParams()[0].name,
            "secondHolder": transactModel.getFolioMatcherParams().length > 1 ? transactModel.getFolioMatcherParams()[1].name : "NA",
            "thirdHolder": transactModel.getFolioMatcherParams().length > 2 ? transactModel.getFolioMatcherParams()[2].name : "NA"
        }
        transactModel.setFolioDetailsObj($scope.folioDetailsObj);


        /* TransactNow checking kyc status for all holder */
        var isNotRegisterFlow = false;
        angular.forEach(transactModel.getrawHolderDts(), function(value, key) {
            /*if (value.kycStatus !== "KYC - Registered" ||  value.kycStatus === "05") {
                isNotRegisterFlow = true;
            }*/
            if (value.kycStatus == "KYC - Registered" || value.kycStatus == "A" || value.kycStatus == "KYC-Registered" || value.kycStatus == "KYC Registered-New KYC") {
                //isNotRegisterFlow = false;
            } else {
                isNotRegisterFlow = true;
            }
        });

        /* new folio with existing */
        if (isNotRegisterFlow) {
            var instantKycDetails = angular.copy($scope.folioMatcherParams);
            $scope.folioDetailsObj.holderDetails = instantKycDetails;
            transactModel.setSelectedFolioDts($scope.folioDetailsObj);
            // var instantKycDetails = angular.copy($scope.resultObj);

            //Setting instant KYC-Details
            setInstantKycDetails();

            instantKycDetails = transactModel.getInstantKyc();
            var requestAadharObj = [];

            if (instantKycDetails.length > 0 && !(instantKycDetails[0].kycStatus == "KYC - Registered" || instantKycDetails[0].kycStatus == "A" || instantKycDetails[0].kycStatus == "KYC-Registered" || instantKycDetails[0].kycStatus == "KYC Registered-New KYC") && instantKycDetails[0].aadhar !== undefined) {
                requestAadharObj.push({ "adrPANPkrn": instantKycDetails[0].aadhar.toString() });
            }
            if (instantKycDetails.length > 1 && !(instantKycDetails[1].kycStatus == "KYC - Registered" || instantKycDetails[1].kycStatus == "A" || instantKycDetails[1].kycStatus == "KYC-Registered" || instantKycDetails[1].kycStatus == "KYC Registered-New KYC") && instantKycDetails[0].aadhar !== undefined) {
                requestAadharObj.push({ "adrPANPkrn": instantKycDetails[1].aadhar.toString() });
            }
            if (instantKycDetails.length > 2 && !(instantKycDetails[2].kycStatus == "KYC - Registered" || instantKycDetails[2].kycStatus == "A" || instantKycDetails[2].kycStatus == "KYC-Registered" || instantKycDetails[2].kycStatus == "KYC Registered-New KYC") && instantKycDetails[0].aadhar !== undefined) {
                requestAadharObj.push({ "adrPANPkrn": instantKycDetails[2].aadhar.toString() });
            }

            var requestObject = {
                paramObj: { "guId": authenticationService.getUser().guId },
                bodyObj: {
                    "validateOTPeKYC": requestAadharObj
                }
            }
            ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpDtlsSuccess, otpDtlsFailure);
            //$state.go("transactnow.ekycVerification");
            return;
        } else {
            $state.go('transactnow.ekyc');
        }

    }

    $scope.$on('yes', function() {
        $scope.showNotification = false;
        if ($scope.trnstNwKycFlow == true) {
            $scope.kycFlow = true;
            /************ new folio not registered start **************/
            var instantKycDetails = angular.copy($scope.resultObj)


            var folioDetailsObj = {
                "folioId": transactModel.getSelectedFolioDts().folioId,
                "firstHolder": transactModel.getFolioMatcherParams()[0].name,
                "secondHolder": transactModel.getFolioMatcherParams().length > 1 ? transactModel.getFolioMatcherParams()[1].name : "NA",
                "thirdHolder": transactModel.getFolioMatcherParams().length > 2 ? transactModel.getFolioMatcherParams()[2].name : "NA"
            }
            for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                instantKycDetails[i].kycStatus = $scope.rawHolderDetails[i].kycStatus;
            }

            transactModel.setSelectedFolioDts(folioDetailsObj);
            transactModel.setInstantKyc(instantKycDetails);
            $state.go("transactnow.ekycVerification");

            /********* new folio not registered flow end*********************/
        } else {
            transactModel.setIsNewFolio(true);

            if ($scope.moduleUrl == '/trnsctNowNewFolio') {
                $scope.folioDetailsObj = {
                    "folioId": 'NEW',
                    "firstHolder": transactModel.getFolioMatcherParams()[0].name,
                    "secondHolder": transactModel.getFolioMatcherParams().length > 1 ? transactModel.getFolioMatcherParams()[1].name : "NA",
                    "thirdHolder": transactModel.getFolioMatcherParams().length > 2 ? transactModel.getFolioMatcherParams()[2].name : "NA"
                }
                transactModel.setFolioDetailsObj($scope.folioDetailsObj);
                //$state.go('transactnow.ekyc');
                if (transactModel.getrawHolderDts()[0].kycStatus == "KYC - Registered" || transactModel.getrawHolderDts()[0].kycStatus == "KYC-Registered" || transactModel.getrawHolderDts()[0].kycStatus == "A" || transactModel.getrawHolderDts()[0].kycStatus == "KYC Registered-New KYC") {
                    $state.go('transactnow.ekyc');
                } else {
                    /************ new folio not registered start **************/
                    transactModel.setSelectedFolioDts($scope.folioDetailsObj);
                    var instantKycDetails = angular.copy($scope.resultObj)



                    for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                        instantKycDetails[i].kycStatus = $scope.rawHolderDetails[i].kycStatus;
                    }


                    transactModel.setInstantKyc(instantKycDetails);

                    var requestAadharObj = [];

                    if (instantKycDetails.length > 0) {
                        requestAadharObj.push({ "adrPANPkrn": instantKycDetails[0].aadhar.toString() });
                    }
                    if (instantKycDetails.length > 1) {
                        requestAadharObj.push({ "adrPANPkrn": instantKycDetails[1].aadhar.toString() });
                    }
                    if (instantKycDetails.length > 2) {
                        requestAadharObj.push({ "adrPANPkrn": instantKycDetails[2].aadhar.toString() });
                    }

                    var requestObject = {
                        paramObj: { "guId": authenticationService.getUser().guId },
                        bodyObj: {
                            "validateOTPeKYC": requestAadharObj
                        }
                    }
                    ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpDtlsSuccess, otpDtlsFailure);
                    // $state.go("transactnow.ekycVerification");
                }

                /********* new folio not registered flow end*********************/
                return;
            } else if ($scope.moduleUrl == '/newFolioNnewInvestor' && $state.current.parent == 'smartSol.planSmartSolution') {
                if (folioValidationModelService.getFolioValidationDtls()) {
                    var newFolid = folioValidationModelService.getFolioValidationDtls().folioNo;
                    transactModel.getInvestorDetails().folioId = newFolid;
                    //if(!$scope.isInvestorLoggedIn) { new folio buy
                    selectInvestorModel.getSelectedInvestorDtls().folioId = newFolid;
                }
                $state.go("smartSol.planSmartSolution.newFolioNnewInvestor.ekyc");
                return;


            } else if ($scope.moduleUrl !== '/trnsctNowNewFolio') {
                if (folioValidationModelService.getFolioValidationDtls()) {
                    var newFolid = folioValidationModelService.getFolioValidationDtls().folioNo;
                    transactModel.getInvestorDetails().folioId = newFolid;
                    //if(!$scope.isInvestorLoggedIn) { new folio buy
                    selectInvestorModel.getSelectedInvestorDtls().folioId = newFolid;
                }
                $state.go("transact.ekyc");
                return;
            }
        }
    });

    $scope.handleContinue = function() {
        $state.go("transactnow.ekycVerification");
    }

    function otpDtlsSuccess(data) {
        //otpGenerationModel.setOtpDetails(data);     
        $scope.handleContinue();
    };

    function otpDtlsFailure(error) {
        console.log(error);
        $scope.handleContinue();
    }

    $scope.$on('no', function() {
        $scope.showNotification = false;
        transactModel.openFundTab = true;
        if ($scope.trnstNwKycFlow !== true) {
            transactModel.setIsNewFolio(false);
            if ($scope.moduleUrl == '/trnsctNowNewFolio') {
                $scope.folioDetailsObj = {
                    "folioId": folioValidationModelService.getFolioValidationDtls().folioNo,
                    "firstHolder": transactModel.getFolioMatcherParams()[0].name,
                    "secondHolder": transactModel.getFolioMatcherParams().length > 1 ? transactModel.getFolioMatcherParams()[1].name : "NA",
                    "thirdHolder": transactModel.getFolioMatcherParams().length > 2 ? transactModel.getFolioMatcherParams()[2].name : "NA"
                }
                transactModel.setFolioDetailsObj($scope.folioDetailsObj);
                angular.forEach(transactModel.getFolioDet(), function(value, key) {
                    if (value.folioId === folioValidationModelService.getFolioValidationDtls().folioNo) {
                        value.index = key;
                        transactModel.setSelectedFolioDts(value);
                    }
                });

                /* TransactNow checking kyc status for all holder */
                /*var isNotRegisterFlow = false;
                angular.forEach(transactModel.getrawHolderDts(), function(value, key) {
                    if (value.kycStatus !== "KYC - Registered" ||  value.kycStatus === "05") {
                        isNotRegisterFlow = true;
                    }else{
                        isNotRegisterFlow = false;
                    }
                });*/
                var isNotRegisterFlow = false;
                angular.forEach(transactModel.getrawHolderDts(), function(value, key) {

                    if (value.kycStatus == "KYC - Registered" || value.kycStatus == "A" || value.kycStatus == "KYC-Registered" || value.kycStatus == "KYC Registered-New KYC") {
                        //isNotRegisterFlow = false;
                    } else {
                        isNotRegisterFlow = true;
                    }
                });

                /* new folio with existing */
                if (isNotRegisterFlow) {
                    var instantKycDetails = angular.copy($scope.resultObj)
                    $scope.folioDetailsObj.holderDetails = instantKycDetails;
                    transactModel.setSelectedFolioDts($scope.folioDetailsObj);
                    var instantKycDetails = angular.copy($scope.resultObj);
                    for (var i = 0; i < transactModel.getrawHolderDts().length; i++) {
                        instantKycDetails[i].kycStatus = $scope.rawHolderDetails[i].kycStatus;
                    }
                    transactModel.setInstantKyc(instantKycDetails);
                    var requestAadharObj = [];

                    if (instantKycDetails.length > 0) {
                        requestAadharObj.push({ "adrPANPkrn": instantKycDetails[0].aadhar.toString() });
                    }
                    if (instantKycDetails.length > 1) {
                        requestAadharObj.push({ "adrPANPkrn": instantKycDetails[1].aadhar.toString() });
                    }
                    if (instantKycDetails.length > 2) {
                        requestAadharObj.push({ "adrPANPkrn": instantKycDetails[2].aadhar.toString() });
                    }

                    var requestObject = {
                        paramObj: { "guId": authenticationService.getUser().guId },
                        bodyObj: {
                            "validateOTPeKYC": requestAadharObj
                        }
                    }
                    ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpDtlsSuccess, otpDtlsFailure);
                    //$state.go("transactnow.ekycVerification");
                    return;
                }
                /*else{
                                    $state.go("transactnow.ekyc");
                                    return;
                                }*/


                /* new folio with existing end */


                $scope.$emit('setFolioDetailsTl');
                if (transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") {
                    $state.go('transactnow.baseNow.buy');
                    return;
                } else if (transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") {
                    $state.go('transactnow.baseNow.sip');
                    return;
                } else if (transactModel.getTransactType() == TransactConstant.renewSip.RENEWSIP) {
                    $state.go('transactnow.baseNow.renewSip');
                    return;
                } else if (transactModel.isTransactNowSmartSol) {
                    $state.go('transactnow.baseNow.smartSolTransact');
                    return;
                }
            } else if ($scope.moduleUrl == '/newFolioNnewInvestor') {
                if (!$scope.isInvestorLoggedIn) {
                    if (transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") {
                        transactModel.setStateValue({ key: "Fund" });
                        $state.go('transact.base.buy');
                    } else if (transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") {
                        transactModel.setStateValue({ key: "Fund" });
                        $state.go('transact.base.sip');
                        return;
                    }
                } else {
                    if (transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") {
                        // transactModel.setStateValue({key: 'Investment Preference New Folio'});
                        transactModel.setStateValue({ key:null });
                        $state.go('invTransact.base.buy');
                    } else if ($state.current.parent == 'smartSol.planSmartSolution') {
                        $state.go('smartSol.planSmartSolution.selectFolio');
                        return
                    } else if (transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") {
                        transactModel.setStateValue({ key: TransactConstant.transact.Investment_Perf_Key });
                        $state.go('invTransact.base.sip');
                        return;
                    }
                }


            }
        }
    });

    $scope.$on('kycregstion', function(event, groupName) {
        $scope.group.push({
            'name': '',
            'type': groupName,
            'pan': ''
        });
        $scope.noRecFound = true;
        if (groupName == "Secondholder") {
            $scope.showSecondHolder = true;
            $scope.shwSecondChkKyc = false;
            $scope.disableAddJoinee = false;
            $scope.instntKycSecHolder = true;
        } else if (groupName == "Thirdholder") {
            $scope.shwThirdChkKyc = false;
            $scope.showThirdHolder = true;
            $scope.instntKycThrdHolder = true;
        }
    });


    $scope.folioMtchPrms = function() {
        $scope.folioMatcherParams = [];
        var rawHolderDetails = transactModel.getrawHolderDts();
        for (var i = 0; i < rawHolderDetails.length; i++) {
            if (i == 0 && $scope.moduleUrl !== '/trnsctNowNewFolio') {
                $scope.folioMatcherParams.push({
                    "name": rawHolderDetails[i].name,
                    "pan": rawHolderDetails[i].pan,
                    "type": rawHolderDetails[i].type,
                    "aadhar": rawHolderDetails[i].aadharNo
                });
            } else if (i == 0 && $scope.moduleUrl == '/trnsctNowNewFolio') {
                $scope.folioMatcherParams.push({
                    "name": rawHolderDetails[i].unitHolder,
                    "pan": rawHolderDetails[i].pan,
                    "type": "Firstholder"
                })
            } else if (i !== 0 && $scope.moduleUrl == '/newFolioNnewInvestor') {
                $scope.folioMatcherParams.push({
                    "name": rawHolderDetails[i].fullName,
                    "pan": rawHolderDetails[i].kycId || rawHolderDetails[i].userEnteredPan,
                    "type": i == 1 ? "Secondholder" : "Thirdholder",
                    "kycMode": rawHolderDetails[i].kycMode,
                    "kycStatus": rawHolderDetails[i].kycStatus,
                    "appIPVFlag": rawHolderDetails[i].appIPVFlag,
                    "aadhar": rawHolderDetails[i].aadhar
                })
            } else if (i !== 0) {
                $scope.folioMatcherParams.push({
                    "name": rawHolderDetails[i].fullName,
                    "pan": rawHolderDetails[i].kycId || rawHolderDetails[i].userEnteredPan,
                    "type": i == 1 ? "Secondholder" : "Thirdholder",
                    "kycMode": rawHolderDetails[i].kycMode,
                    "kycStatus": rawHolderDetails[i].kycStatus,
                    "appIPVFlag": rawHolderDetails[i].appIPVFlag,

                })
            }
        }
        transactModel.setFolioMatcherParams($scope.folioMatcherParams);
    }

}


newFolioNnewInvestorController.$inject = ['$scope', 'transactModel', 'TransactConstant', 'folioValidationInitialLoader', 'folioValidationModelService', '$state', 'transactEventConstants', 'selectInvestorModel', 'configUrlModel', 'appConfig', '$window', 'ekycVerificationModel', 'authenticationService', 'kycRegisterStatusModel'];
module.exports = newFolioNnewInvestorController;
