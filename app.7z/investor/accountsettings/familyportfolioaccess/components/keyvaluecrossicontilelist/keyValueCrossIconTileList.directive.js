/**
 * @ngdoc directive
 * @name fticKeyValueTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - keyValueCrossIconTile will display the kye value tiles for "My profile - Grant Access" .
 * 
 *
 **/

'use strict';

var keyValueCrossIconTileList = function($uibModal,investorEventConstants) {
    return {
            template: require('./keyValueCrossIconTileList.html'),
            restrict: 'E',
            replace: true,
            scope: {
                keyValueObject: '=',
                onDelete: '&'
            },
            link: function($scope){
                
                $scope.onDelete = function(userName){
                    $scope.userName = userName;
                    var modalInstance;
                    modalInstance = $uibModal.open({
                        template : require('../removegrantaccessconfirmpopup/remGranAccessConfPopup.html'),
                        controller: 'RemMemConfPopup',
                        scope: $scope
                    });
                };
                $scope.deleted = function(){
                    $scope.$emit(investorEventConstants.accountSettings.USER_ACCESS_DELETE);
                }
			}
		};
};

keyValueCrossIconTileList.$inject = ['$uibModal','investorEventConstants'];
module.exports = keyValueCrossIconTileList;