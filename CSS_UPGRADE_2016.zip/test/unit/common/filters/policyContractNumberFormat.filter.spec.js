'use strict';

/* jasmine specs for filter go here */

describe('policyContractNumberFormatFilter', function() {

	var policyContractNumberFormatFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    policyContractNumberFormatFilter = $injector.get('$filter')('policyContractNumberFormat');
	}));

	//--- Test for definition

	it('should expect policyContractNumberFormatFilter to be defined...', function(){
		expect(policyContractNumberFormatFilter).toBeDefined();
	});

	//--- Test  policyContractNumberFormat Filter

	it('should format the given number with proper policyContractNumberFormat...', function(){
		expect(policyContractNumberFormatFilter('123456789')).toEqual('12345-67-89');
	});
	
});