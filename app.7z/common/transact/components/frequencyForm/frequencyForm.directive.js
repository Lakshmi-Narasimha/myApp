/**
* @ngdoc property
* @name frequencyForm Directive
* @requires TransactConstant
* @requires $filter
* @description
*
* - It handles the custom form validation for the transact frequency, start date, end date and no.of installments fields along with the basic angular form validation.
*
**/
'use strict';

var frequencyForm = function (TransactConstant, $filter, reviewSwpDetailsModel, frequencyOptionsModel, transactEventConstants, frequencyOptionsInitalLoader, $timeout, $stateParams, transactModel,fticDateUtils) {
    return {
        template: require('./frequencyForm.html'),
        restrict: 'E',
        scope: {
            stpDetails : "=",
            frequencyForm : "=",
            formFields : "="
        },
        controller:['$scope', function ($scope) { 
            /*$scope.stpDetails = $scope.stpDetails || {};*/
            var days, oneDay_ms; 

            oneDay_ms = 1000*60*60*24;            
            $scope.displayDateLable = false;
            $scope.defaultDay = new Date((new Date()).getTime()+(7*oneDay_ms));
            $scope.defaultOption = {};
            $scope.isEdit = false;
            $scope.pattern = /^[0-9]*$/;
           
            //Calender styling
            $scope.dateOptions = {
                yearRows: 3,
                yearColumns: 4,
                fulldatepickerMode:'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                monthColumns: 4,
                datepickerMode: 'day',
                showWeeks: false,
                minDate: new Date(),
                dateDisabled : disabled
            };
            
            
            $scope.stpDetails.startDate = $scope.defaultDay;
            $scope.stpDetails.endDate =$scope.defaultDay;
             function disabled(dateAndMode) {
                var date = dateAndMode.date;
                var mode =  $scope.selectedmode;
                if(mode == 'Daily'){
                    return (date.getDay() === 0 || date.getDay() === 6);
                }
                if(mode == 'Weekly'){
                    if((date.getDate() === 7) || (date.getDate() === 14) || (date.getDate() === 21) || (date.getDate() === 28)){
                        return false;                            
                    }else{
                        return true;
                    }
                } 
                
                if(mode == 'Monthly'){
                    return (date.getDay() === 0 || date.getDay() === 6);
                }
                if(mode == 'Quarterly'){
                    return (date.getDay() === 0 || date.getDay() === 6);
                }
            };
               $scope.$on(transactEventConstants.transact.FREQUENCY_FORM_RESET, function (event) {
                
                 resetFrequencyForm();             
            })           
            $scope.$on(transactEventConstants.transact.AMOUNT_SELECTED, function (event) {
                 frequencyOptionsInitalLoader.loadAllServices($scope);              
            })

            $scope.$on(transactEventConstants.transact.FREQUENCY_OPTIONS,function (event) {
                $scope.frequencyOptions = null;
                $timeout(function () {
                    $scope.frequencyOptions = frequencyOptionsModel.getFrequencyOptions(); 
                    if($scope.isEdit){
                        $scope.defaultFrequency = findItemInFilter($scope.frequencyOptions, editReviewSWPDetails.frequency); 
                        $scope.isEdit = false;
                    }else{
                       $scope.defaultFrequency = findItemInFilter($scope.frequencyOptions, $scope.frequencyOptions[0].title); 
                       // $scope.defaultOption =  findItemInFilter(frequencyOptionsModel.getFrequencyOptions(), $scope.frequencyOptions[0].title);
                    }
                });    
            })
                    
            var flag = false;

            $scope.$on('transactFrequency', function(event, selectedValue){                                
                $scope.stpDetails.frequency = selectedValue.title;         
                days = selectedValue.days;   
                $scope.selectedmode = selectedValue.title; 
                if(flag)
                {
                    $scope.autoSync("endDate");                                
                }
                flag = true;
            });

            $scope.sectionFilterOptions = {
                required : true,
                name : "frequency"
            };
            
            var dateDifferenceInDays = function(stDate, endDate) {

                var stDate_ms, enddate_ms, difference_ms;
                                
                stDate_ms = stDate.getTime();                
                enddate_ms = endDate.getTime();
                
                difference_ms = enddate_ms - stDate_ms;
                
                return Math.round(difference_ms/oneDay_ms); 
            }        
                                                    
            $scope.autoSync = function(lbl){  
             
                if(lbl === "startDate")
                {           
                    $scope.stpDetails.endDate = $scope.stpDetails.startDate;
                    $scope.stpDetails.noofInstallments = 0;
                }
                else if(lbl === "endDate")
                {                                       
                    if($scope.stpDetails.endDate)
                    {
                        var no_of_days = dateDifferenceInDays($scope.stpDetails.startDate,$scope.stpDetails.endDate);
                        if(no_of_days >= 0)
                        {                        
                            $scope.stpDetails.noofInstallments = Math.floor(no_of_days/days);
                            $scope.autoSync("installments");    
                        }else{
                            $scope.stpDetails.startDate = $scope.stpDetails.endDate;
                        }
                    }
                    
                }
                else if(lbl === "installments")                    
                {                                                              
                    if($scope.stpDetails.noofInstallments != undefined)
                    {                            
                        $scope.stpDetails.endDate = new Date($scope.stpDetails.startDate.getTime() + ($scope.stpDetails.noofInstallments*days*oneDay_ms));
                    }
                    else
                    {
                        $scope.stpDetails.endDate = $scope.stpDetails.startDate;
                    }                     
                } 

            }

             // for guest module edit SWP details...
            function resetFrequencyForm(){
                //$scope.isEditing = false;
                $scope.stpDetails.startDate = $scope.defaultDay;
                $scope.stpDetails.endDate =$scope.defaultDay;
                $scope.stpDetails.noofInstallments = 0;  
                if(frequencyOptionsModel.getFrequencyOptions()){
                    $scope.defaultFrequency = findItemInFilter(frequencyOptionsModel.getFrequencyOptions(), frequencyOptionsModel.getFrequencyOptions()[0].title); 
                    $scope.frequencyOptions = null;
                    $timeout(function () {                       
                        $scope.frequencyOptions = frequencyOptionsModel.getFrequencyOptions(); 
                    });  
                }
            }
            function findItemInFilter(objArr, value){
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                        return x.title == value;
                }))[0];
                return obj;
            }
            var editReviewSWPDetails =  {};
            if ($stateParams.key == 'stp') {
                editReviewSWPDetails = transactModel.getTransactDetails().stpDetails;
            } else if ($stateParams.key == 'SWP') {
               editReviewSWPDetails =  reviewSwpDetailsModel.getReviewSwpObj();
            }
            else if($stateParams.key === 'INVESTORSWP'){
                $scope.displayDateLable = true;
                editReviewSWPDetails =  reviewSwpDetailsModel.getReviewSwpObj();
            }

            $scope.$on("Edit_Form",function(){
                editReviewSWPDetails =  reviewSwpDetailsModel.getReviewSwpObj();
                frequencyFormEdit();
            });

            $scope.$on("CALL_FOR_FREQ_POPULATE", function() {
                editReviewSWPDetails =  reviewSwpDetailsModel.getReviewSwpObj();
                frequencyFormEdit();
            });
            $scope.$on("CALL_FOR_FREQ_POPULATE_STP", function() {
                editReviewSWPDetails =  transactModel.getTransactDetails().stpDetails;
                if(Object.keys(editReviewSWPDetails).length > 0) {
                    frequencyFormEdit();
                } else {
                    resetFrequencyForm();
                }
            });
            

            function frequencyFormEdit(){

                if((editReviewSWPDetails && editReviewSWPDetails.isEditSWP) || (transactModel.SWP_MAIN_FLAG || transactModel.STP_MAIN_FLAG || $stateParams.key == 'SWP' || $stateParams.key == 'stp' || $stateParams.key == 'INVESTORSWP')){

                    //console.log(editReviewSWPDetails)
                    $scope.stpDetails.startDate = editReviewSWPDetails.startDate ? new Date (editReviewSWPDetails.startDate) : $scope.defaultDay;
                    $scope.stpDetails.endDate = editReviewSWPDetails.endDate ? new Date (editReviewSWPDetails.endDate): $scope.defaultDay;
                    $scope.stpDetails.noofInstallments = Number(editReviewSWPDetails.noofInstallments);
                    var SWPFrequencyDays = 1;
                    if(editReviewSWPDetails.frequency && (editReviewSWPDetails.frequency.toUpperCase() == "DAILY")){
                        SWPFrequencyDays = 1;
                    }else if(editReviewSWPDetails.frequency && (editReviewSWPDetails.frequency.toUpperCase() == "WEEKLY")){
                        SWPFrequencyDays = 7;
                    }else if(editReviewSWPDetails.frequency && (editReviewSWPDetails.frequency.toUpperCase() == "MONTHLY")){
                        SWPFrequencyDays = 30;
                    }else if(editReviewSWPDetails.frequency && (editReviewSWPDetails.frequency.toUpperCase() == "QUARTERLY")){
                        SWPFrequencyDays = 90;
                    }
                    $scope.isEdit = true;
                    $scope.frequencyOptions = [{
                      title : editReviewSWPDetails.frequency ? editReviewSWPDetails.frequency.toUpperCase() : '',
                      days : SWPFrequencyDays
                    }];
                }else{
                    resetFrequencyForm(); 
                }
            }
            frequencyFormEdit();
        }]
    };
};


frequencyForm.$inject = ['TransactConstant', '$filter','reviewSwpDetailsModel', 'frequencyOptionsModel', 'transactEventConstants', 'frequencyOptionsInitalLoader', '$timeout', '$stateParams','transactModel','fticDateUtils'];
module.exports = frequencyForm;
