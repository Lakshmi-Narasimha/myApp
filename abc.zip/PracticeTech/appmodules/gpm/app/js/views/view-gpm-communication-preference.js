define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'text!appmodules/gpm/app/templates/gpmcommunicationpreference.html','appmodules/contactprofile/app/models/preferenceviewmodel'
], function ($, _, Backbone, Utils, CommunicationPreferencesTemplate,PreferenceViewModel) {
    var alertpreferencesView = Backbone.View.extend({
        el: "#gpm-form-update-field-container",
        id: 'gpm-form-update-field-container',
        events: {
            'change input[type="radio"]': 'toggleRadioClassActive',
            'click .pt-toggle-btn': 'toggleYesNo',
            'change #retirement-stage':'toggleGrp'
        },
        template: _.template(CommunicationPreferencesTemplate),
        initialize: function (data) {
            this.data = data;

        },
        render: function (updateMode) {
        	if(!this.model.get('currentItemSet')){
        		this.data = this.getViewData();
    			this.model.setCurrentValue(updateMode,{data:this.data});
    		}
        	console.log(this.model,"this.model")
            var self = this;
            try {
                var _compiledTemplate = this.template({ data: this.model, email: PreferenceViewModel.getData().emails });
                $("#" + this.id).html(_compiledTemplate);
                var _sections = this.model.get('itemSections');
            	var _advsrPrefSectn = _sections.find(function(row){return row.sectionId == "200"}),_amerPrefSectn = _sections.find(function(row){return row.sectionId == "206"}),_commctnIntrstPrefSectn = _sections.find(function(row){return row.sectionId == "4"});
            	_advsrPrefSectn.customValues.changed = false ; _advsrPrefSectn.customValues.changed = false ;_advsrPrefSectn.customValues.changed = false;
            	if(_commctnIntrstPrefSectn.items[0].get('changedItemValueId') == ""){
            		$('#retirement-stage').val("");
            	}
            	
            }
            catch (error) {
                console.log(error);
            }
        },
        toggleRadioClassActive: function (event) {
            var _radio = $(event.target);
            var _radioHolder = _radio.parents('div.radio-grp');
            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
            _radio.parents('div.radio-group-conatiner').addClass('active');
        },
        toggleYesNo: function (obj) {
            var _$clickedButton = $(obj.currentTarget);
            var btnGroup = _$clickedButton.parents('div.btn-group')
            if (_$clickedButton.hasClass('active')) {
                return false;
            } else {
                btnGroup.find('.pt-toggle-btn').removeClass('active');
                _$clickedButton.addClass('active');
            }
        },
        toggleGrp: function (obj) {
        	var _sections = this.model.get('itemSections');
        	var _communicationIntrstpref = _sections.find(function(row){return row.sectionId =="4"});
        	var _items = _communicationIntrstpref.items;
        	var _$retireStage = $('#retirement-stage');
        	$('.retirement-plan-options').val("");
        	var _selectedVal = _$retireStage.val(),_prefId = _selectedVal,_$retirePlansQns = $('.communication-interest-rt-plns');
        	$.each(_items,function(indx,itemModel){
    			if(itemModel.get('itemType') != "402"){
    				itemModel.set("changedItemValue","");
    				itemModel.set("changedItemValueId","");
    				if(itemModel.get("customValues").refId == _prefId){
    					itemModel.get("customValues").viewDisplay = true;
    				}else{
    					itemModel.get("customValues").viewDisplay = false;
    				}
    			}
    		});
        	_$retirePlansQns.addClass("hidden");
        	if(_selectedVal != ""){
        		$('.communication-interest-rt-plns.ref-id-'+_prefId).removeClass("hidden");
        	}
        },
        getViewData:function(){
        	var _prefViewModelData = PreferenceViewModel.getData();
        	var _validEmails = [];
        	$.each(_prefViewModelData.emails,function(index,email){
        		//if(email.undeliverable == false){
        			_validEmails.push(email);
        		//}
        	});
        	var _advsrCommPrefModel = {
        			prfrTypCd:"",
        			prfrId:null,
        			prfrdEmail:{},
        			emails:_validEmails,
        			label:"",
        			isComplex: true,
        			customValues:{},
        			prfrdEmail:{
        				type:""
        			},
        			values:[]
        	}, _amerCommPrefModel = {
        			prfrTypCd:"",
        			prfrId:null,
        			prfrdEmail:{},
        			emails:_validEmails,
        			label:"",
        			isComplex: true,
        			customValues:{},
        			prfrdEmail:{
        				type:""
        			},
        			values:[]
        	},_commnIntrPrefModel = {
        			prfrTypCd:"",
        			prfrId:null,
        			prfrdEmail:{},
        			emails:_validEmails,
        			label:"",
        			isComplex: true,
        			customValues:{},
        			prfrdEmail:{
        				type:""
        			},
        			values:[]
        	}
        	var _dataSections = {
        			"advisorEmail":_advsrCommPrefModel,
        			"ameripriseEmail":_amerCommPrefModel,
        			"communicationInterests":_commnIntrPrefModel,
        	};
        	var _advsrCommnctnPrefData = _prefViewModelData.communication,_advsrCommnctnPrefSectn = [],_amerCommnctnPrefSectn = [],_commnIntrPrefSectn = [];
        	console.log(_advsrCommnctnPrefData,"_advsrCommnctnPrefData");
        	 var _clPrfs = _advsrCommnctnPrefData.clPrfrs.results;
     	    var _advsrCommnctnPrefIndx="",_amerCommnctnPrefIndx="",_commnIntrPrefIndx="",noPhoneText="";
     	    _.each(_clPrfs,function(data,index){
     	    	switch (data.prfrNm) {
				case "Advisor Email Selection":
					_advsrCommPrefModel.prfrTypCd = data.prfrTypCd;
     	        	_advsrCommPrefModel.prfrId = data.prfrId;
     	        	_advsrCommnctnPrefIndx = index;
     	        	_advsrCommnctnPrefSectn = data.relPrfrs.results;
					break;
				case "Ameriprise Email Preference":
					_amerCommPrefModel.prfrTypCd = data.prfrTypCd;
					_amerCommPrefModel.prfrId = data.prfrId;
					_amerCommnctnPrefIndx = index;
					_amerCommnctnPrefSectn = data.relPrfrs.results;
					break;
				case "Communication Interests":
					_commnIntrPrefModel.prfrTypCd = data.prfrTypCd;
					_commnIntrPrefModel.prfrId = data.prfrId;
					_commnIntrPrefIndx = index;
					_commnIntrPrefSectn = data.relPrfrs.results;
					break;
				default:
					break;
				}
     	       
     	    });
     	   //email delivery mechanisms for advisor section
     	    var  _emailDestId = "";
     	   var _advsrCommnctnPrefDelMechnsm = _clPrfs[_advsrCommnctnPrefIndx].dlvMchnsms.results,_amerCommnctnPrefDelMechnsm = _clPrfs[_amerCommnctnPrefIndx].dlvMchnsms.results,_commnIntrPrefDelMechnsm = _clPrfs[_commnIntrPrefIndx].dlvMchnsms.results;
     	  _.each(_advsrCommnctnPrefDelMechnsm, function(list,keys){
  	        if(list.dlvTypCd == "email"){
  	            if(keys!== undefined){
  	            var _emailPref= _advsrCommnctnPrefDelMechnsm[keys].dlvChos.results;
  	            //_gpmPrefModel.emails = _emailPref;
  	                _.each(_emailPref, function(d,i){
  	                    if(d.dlvChoSlctInd == true){
  	                    _emailDestId = d.dlvDestId;
  	                    _emailDestId = _emailDestId.charAt(0).toUpperCase() + _emailDestId.slice(1).toLowerCase();
  	                    _advsrCommPrefModel.prfrdEmail.type  = _emailDestId;
  	                     }
  	                });
  	            }
  	        }
  	     	});
     	 _.each(_amerCommnctnPrefDelMechnsm, function(list,keys){
   	        if(list.dlvTypCd == "email"){
   	            if(keys!== undefined){
   	            var _emailPref= _amerCommnctnPrefDelMechnsm[keys].dlvChos.results;
   	            //_gpmPrefModel.emails = _emailPref;
   	                _.each(_emailPref, function(d,i){
   	                    if(d.dlvChoSlctInd == true){
   	                     _emailDestId = d.dlvDestId;
   	                    _emailDestId = _emailDestId.charAt(0).toUpperCase() + _emailDestId.slice(1).toLowerCase();
   	                    _amerCommPrefModel.prfrdEmail.type  = _emailDestId;
   	                     }
   	                });
   	            }
   	        }
   	     	});
     	_.each(_commnIntrPrefDelMechnsm, function(list,keys){
   	        if(list.dlvTypCd == "email"){
   	            if(keys!== undefined){
   	            var _emailPref= _commnIntrPrefDelMechnsm[keys].dlvChos.results;
   	            //_gpmPrefModel.emails = _emailPref;
   	                _.each(_emailPref, function(d,i){
   	                    if(d.dlvChoSlctInd == true){
   	                    	_emailDestId = d.dlvDestId;
   	   	                    _emailDestId = _emailDestId.charAt(0).toUpperCase() + _emailDestId.slice(1).toLowerCase();
   	   	                    _commnIntrPrefModel.prfrdEmail.type  = _emailDestId;
   	                     }
   	                });
   	            }
   	        }
   	     	});


     	//get advisor commnctn prefs
     	_.each(_advsrCommnctnPrefSectn,function(d,i){
            if( d.prfrTypCd == "C"){
	            var _infoResult = d.relPrfrs.results;
	           _.each(_infoResult,function(infoList,infoKeys){
		            if(infoList.prfrTypCd == "P"){
	            		 var _editType = d.prfrNm.toLowerCase() == "advisor informational"?"informational":"commercial";
		            	 var _item = {label:infoList.prfrNm, value:"", prfrId:infoList.prfrId,customValues:{editType:_editType}};
		            	 var _tempDlvResult = infoList.dlvMchnsms.results,_infoOption = "";
		                 var _infoIndRslt = _tempDlvResult[0].dlvChos.results;
		                    _.each(_infoIndRslt,function(dat,j){
			                    if(_advsrCommPrefModel.prfrdEmail.type.toLowerCase() === dat.dlvDestId.toLowerCase()){
			                    	_item.value = dat.dlvChoSlctInd == true?"Yes":"No";
			                    	_item.valueId = dat.dlvChoSlctInd;
			                    }
		                    });  
		                 _advsrCommPrefModel.values.push(_item);
		            }
	          });
            }
            
     	});
     	//get ameriprise commnctn prefs
     	_.each(_amerCommnctnPrefSectn,function(d,i){
            if( d.prfrTypCd == "C"){
	            var _infoResult = d.relPrfrs.results;
	           _.each(_infoResult,function(infoList,infoKeys){
		            if(infoList.prfrTypCd == "P"){
	            		 var _editType = d.prfrNm.toLowerCase() == "ameriprise informational"?"informational":"commercial";
		            	 var _item = {label:infoList.prfrNm, value:"",prfrId:infoList.prfrId, customValues:{editType:_editType}};
		            	 var _tempDlvResult = infoList.dlvMchnsms.results,_infoOption = "";
		                 var _infoIndRslt = _tempDlvResult[0].dlvChos.results;
		                    _.each(_infoIndRslt,function(dat,j){
			                    if(_amerCommPrefModel.prfrdEmail.type.toLowerCase() === dat.dlvDestId.toLowerCase()){
			                    	_item.value = dat.dlvChoSlctInd == true ?"Yes":"No";
			                    	_item.valueId = dat.dlvChoSlctInd;
			                    }
		                    });  
		                    _amerCommPrefModel.values.push(_item);
		            }
	          });
            }
            
     	});
     	//get communication interests pref
     	console.log(_commnIntrPrefSectn,"_commnIntrPrefSectn")
         var _retirementStage = {"label":"Retirement stage","value":"","valueId":""},_prfChoices = {},_retireMentOptions = [];
         _.each(_commnIntrPrefSectn,function(d,i){
        	 if(d.prfrNm == "Retirement Track" && d.prfrTypCd == "C"){
        		 var _retireResult = d.relPrfrs.results;
        		 _.each(_retireResult,function(dat,j){
        			 if(dat.prfrNm == "Retirement Track" && dat.prfrTypCd == "P"){
             			var _retirePrfChoiceGrps = dat.prfrChoGrps.results;
             			 _.each(_retirePrfChoiceGrps,function(prfChoiceGrp,indx){
             				var _retirePrfChoices = prfChoiceGrp.prfrChos.results[0];
             				if(_retirePrfChoices.prfrChoValSlctInd == true){
             					_retirementStage.value = _retirePrfChoices.prfrChoTitle;
             					_retirementStage.valueId = _retirePrfChoices.prfrChoVal;
             					_commnIntrPrefModel.values.push(_retirementStage);
             				}
             				_prfChoices[_retirePrfChoices.prfrChoVal] = {
             						"value":_retirePrfChoices.prfrChoTitle,
             						"valueId":_retirePrfChoices.prfrChoVal,
             						"subPrfrs":[]
             				};
             				_retireMentOptions.push({"value":_retirePrfChoices.prfrChoTitle,"valueId":_retirePrfChoices.prfrChoVal})
             				var _subPrefs = _retirePrfChoices.subPrfrs.results[0].relPrfrs.results;
         					_.each(_subPrefs,function(subPref,index){
         						var _subPref = {"label":subPref.prfrNm,"labelId":subPref.prfrId,"subPrefOptions":[],"value":"","valueId":""};
         						var _subPrefOpts = subPref.prfrChoGrps.results;
             					_.each(_subPrefOpts,function(subPrfChoiceOpt,index){
             						var _subPerefChoiceOpt = subPrfChoiceOpt.prfrChos.results[0];
             						if(_subPerefChoiceOpt.prfrChoValSlctInd == true){
             							_subPref.value = _subPerefChoiceOpt.prfrChoTitle;
             							_subPref.valueId = _subPerefChoiceOpt.prfrChoVal;
             						}
             						_subPref.subPrefOptions.push({"value":_subPerefChoiceOpt.prfrChoTitle ,"valueId":_subPerefChoiceOpt.prfrChoVal});
             					});
                 				_prfChoices[_retirePrfChoices.prfrChoVal].subPrfrs.push(_subPref);
         					});
         					
             				
             			 
             			 });
             		 }
    			 });
        		
        	 }
         });
         if(_commnIntrPrefModel.values.length == 0){
        	 _commnIntrPrefModel.values.push(_retirementStage);
         }
         _commnIntrPrefModel.customValues.prfChoices = _prfChoices;
         _commnIntrPrefModel.customValues.retirementOptions = _retireMentOptions;
     	   console.log(_advsrCommPrefModel,_amerCommPrefModel,_commnIntrPrefModel,"_emailDestId");
     	   return _dataSections;
        },
        validateAndNavigateFromStep1:function(){
        	var _sections = this.model.get('itemSections');
			var _advsrPrefSectn = _sections.find(function(row){return row.sectionId == "200"}),_amerPrefSectn = _sections.find(function(row){return row.sectionId == "206"}),_commctnIntrstPrefSectn = _sections.find(function(row){return row.sectionId == "4"});
        	var _self = this;
        	_advsrPrefSectn.customValues.changed = false ; _amerPrefSectn.customValues.changed = false ; _commctnIntrstPrefSectn.customValues.changed = false;
        	function valuesModified(){
        		return (_advsrPrefSectn.customValues.changed == true || _amerPrefSectn.customValues.changed == true || _commctnIntrstPrefSectn.customValues.changed == true);
        	}
        	this.model.setChangedValue();
        	if(valuesModified()){
        		 if (this.model.validate('gpm-update-form', true)) {
        				$('.gpm-step.step1').addClass("finished").removeClass("active");
                    	$('.gpm-step.step2').addClass("active");
                    	Backbone.history.navigate('gpm/verification/'+this.model.get('updateMode'), true);
        		 }
            
        	}else{
        		Utils.showNoChangesMessageToUser();
        	}
        	
        }
    });
    return alertpreferencesView;
});