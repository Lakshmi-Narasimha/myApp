coa = coa || {};
define(
		['jquery',
		  'underscore',
		  'backbone', 'text!appmodules/coa/app/templates/addressConfirmation.html', 'appmodules/coa/app/js/utils', 'appcommon/analytics'],
		function($,
				_, Backbone, Template, Utils, Analytics) {
			coa.views.Confirmation = Backbone.View.extend({
				el : '#coa-app',
				template : _.template(Template),
				events : {
					'click #coa-confirm-print' : 'showPrintInterface',
					'click #pdf-viewer-close-button' : 'closePdfViewer'
				},
				initialize : function() {
					this.$main = this.$('#user-info');
				},
				render : function() {
					this.$main.html(this.template(this.model.toJSON()));
					if(!this.model.get('isStandalone')){
					    $('#coa-back-to-cp-contnr').removeClass("hidden");
		        	}
				},clearView : function() {
					this.undelegateEvents();
					this.model.unbind('change', this.render, this); 					
				},
				customInit : function() {},
				showPrintInterface: function () {				   
				    window.print();
				    Analytics.analytics.recordAction('CoaPrintConfirmation:clicked');

                },
				closePdfViewer : function() {
					$('#pdf-object-container').hide();
					$('body').css({
						'overflow' : 'auto',
						'height' : 'auto'
					});
				}

			});

			function initDownloadify() {
				return;
				Utils.lockForm();
				var _canvasImage;
				html2canvas(
						document.getElementById('pdf-content-container'),
						{
							onrendered : function(canvas) {
								Utils.unlockForm();
								_canvasImage = canvas.toDataURL('image/jpeg');
								var doc = new jsPDF();
								doc.addImage(_canvasImage, 'JPEG', 15, 40, 180,
										180);
								var _pdfdata = btoa(doc.output());
								Downloadify
										.create(
												'create-pdf-container',
												{
													filename : 'confirmation_page_'
															+ new Date()
																	.getTime()
															+ '.pdf',
													dataType : 'base64',
													data : function() {
														return _pdfdata;
													},
													onComplete : function() {
														alert('Your File Has Been Saved!');
													},
													onCancel : function() {
														alert('You have cancelled the saving of this file.');
													},
													onError : function() {
														alert('You must put something in the File Contents or there will be nothing to save!');
													},
													swf : 'js/lib/downloadify/downloadify.swf',
													downloadImage : 'img/download.png',
													width : 120,
													height : 30,
													transparent : true,
													append : false
												});

							}
						});

			}
		});
