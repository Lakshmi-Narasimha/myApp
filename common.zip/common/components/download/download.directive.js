'use strict';

var download = function(downloadService, toaster, $state, FileSaver, savedSmartSolutionsModel, $loader, dateDetailsModel, authenticationService) {
    return {
        template: require('./download.html'),
        restrict: 'E',
        replace: true,
        scope: {
            moduleName:'@?'
        },
        link: function(scope) {
            var restUrl, queryParam;
            scope.setMonthAndYear = function(){
                scope.details = dateDetailsModel.getDateDtls();
            };
            scope.download = function(params) {
                if(scope.moduleName === 'Investor'){
                    restUrl = 'services/downloadAccountStatement';
                    queryParam = downloadService.getQueryparams();
                } else {
                    if($state.current.name === "myinvestors.statements.accountstmt.panview"|| $state.current.name === "myinvestors.statements.accountstmt.folioView" || $state.current.name === "myinvestors.statements.accountstmt.actview"){
                    restUrl = 'services/downloadAccountStatement';
                    queryParam = downloadService.getQueryparams();
                    console.log("qparam", queryParam);
                } else if($state.current.name === "smartSol.planSmartSolution.ssBase.goalSheetSummary" || authenticationService.isFromGoalSheet){
                    restUrl = 'smartsolution/goalSheetEmail';
                    queryParam = downloadService.getQueryparams();
                    console.log("qparam", queryParam);
                    scope.$emit('goalSheetDownload');
                    } else{
                        restUrl = 'services/download';
                        queryParam = params;
                    }
                }
                
                $loader.start();
                downloadService.downloadReportService(queryParam, restUrl).then(function(data) {
                    data = angular.isArray(data) ? data[0] : data;
                    data.download = data.download ? data.download : {};
                    var blobData = scope.b64toBlob(data.download.strDocBase64, 'application/pdf');
                    FileSaver.saveAs(blobData, $state.current.name + '.pdf');
                }, function(error) {
                    console.info(error);
                    toaster.error('Currently No File Associated');
                }).finally(function(){
                    $loader.stop();
                });
            };

            scope.b64toBlob = function (b64Data, contentType) {
                var  contentType = contentType || '';
                var sliceSize = sliceSize || 512;

                var byteCharacters = atob(b64Data);
                var byteArrays = [];

                for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                    var slice = byteCharacters.slice(offset, offset + sliceSize);

                    var byteNumbers = new Array(slice.length);
                    for (var i = 0; i < slice.length; i++) {
                        byteNumbers[i] = slice.charCodeAt(i);
                    }

                    var byteArray = new Uint8Array(byteNumbers);

                    byteArrays.push(byteArray);
                }
            
                var out;
                try {
                    out = new Blob(byteArrays, {type: contentType});
                    console.debug("case 1");
                }
                catch (e) {
                    window.BlobBuilder = window.BlobBuilder ||
                            window.WebKitBlobBuilder ||
                            window.MozBlobBuilder ||
                            window.MSBlobBuilder;

                    if (e.name == 'TypeError' && window.BlobBuilder) {
                        var bb = new BlobBuilder();
                        bb.append(byteArrays);
                        out = bb.getBlob(contentType);
                        console.debug("case 2");
                    }
                    else if (e.name == "InvalidStateError") {
                        // InvalidStateError (tested on FF13 WinXP)
                        out = new Blob(byteArrays, {type: contentType});
                        console.debug("case 3");
                    }
                    else {
                        // We're screwed, blob constructor unsupported entirely   
                        console.debug("Errore");
                    }
                }
                return out;
            
            };
        }
    };
};

download.$inject = ['downloadService', 'toaster', '$state', 'FileSaver', 'savedSmartSolutionsModel', '$loader', 'dateDetailsModel', 'authenticationService'];
module.exports = download;
 
