/**
 * @ngdoc directive
 * @name investmentPreferencesReview
 * @description
 *
 * - investmentPreferencesReview component will provide preview of the user investor prefernce .
 * 
 *
 **/
'use strict';

var investmentPreferencesReview = function(transactModel, $state, $filter, TransactConstant, eventConstants, paperlessModel, authenticationService, transactNowModel) {
    return {
            template: require('./investmentPreferencesReview.html'),
            restrict: 'E',
            replace: true,
            scope: {
                editRedirectState : '='
            },
            controller: function($scope){
                $scope.invPrefDetails = transactModel.getAdvDetails();
                $scope.investorPreferenceOptions = transactNowModel.getInvestPrefer();
                var translateFilter = $filter('translate');
                if(paperlessModel.investorPreferenceOption === 'financial'){
                    if(($state.current.name === 'invTransact.review.sip' || $state.current.name === 'invTransact.review.switch') && authenticationService.isInvestorLoggedIn()) {
                        $scope.invPrefKeyValuePairs = [
                            {
                                text : translateFilter(TransactConstant.common.ADVISER_NAME),
                                value: $scope.invPrefDetails.code
                            },
                            {
                                text : translateFilter(TransactConstant.common.SUB_BROKAR_CODE),
                                value: $scope.invPrefDetails.subBrokerCode || 'NA'
                            },
                            {
                                text: translateFilter(TransactConstant.common.SUB_BROKAR_ARN),
                                value: $scope.invPrefDetails.subBrokerArn || 'NA'
                            },
                            {
                                text: translateFilter(TransactConstant.common.EUIN),
                                value: $scope.invPrefDetails.euin || 'NO EUIN'
                            }
                        ];
                    }else {
                        $scope.invPrefKeyValuePairs = [
                            {
                                text : translateFilter(TransactConstant.common.ADVISER_NAME),
                                value: $scope.investorPreferenceOptions.code
                            },
                            {
                                text : translateFilter(TransactConstant.common.SUB_BROKAR_CODE),
                                value: $scope.investorPreferenceOptions.code || 'NA'
                            },
                            {
                                text: translateFilter(TransactConstant.common.SUB_BROKAR_ARN),
                                value: $scope.investorPreferenceOptions.advisorArnCode || 'NA'
                            },
                            {
                                text: translateFilter(TransactConstant.common.EUIN),
                                value: $scope.investorPreferenceOptions.euin || 'NA'
                            }
                        ];
                    }
                }else if(paperlessModel.investorPreferenceOption === 'direct'){
                    $scope.invPrefKeyValuePairs = [
                        {
                            text : translateFilter(TransactConstant.common.DIRECT_ARN_MSG)
                        }
                    ];
                }
                $scope.$on(eventConstants.ACTION_ICON_CLICKED, function(){
                    $scope.$emit('NAVIGATE_TO_TRANSACT', {key: 'Investment Preference'});
                });
            }
        };
};

investmentPreferencesReview.$inject = ['transactModel','$state', '$filter', 'TransactConstant', 'eventConstants', 'paperlessModel', 'authenticationService', 'transactNowModel'];
module.exports = investmentPreferencesReview;