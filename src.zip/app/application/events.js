define([
    'jquery',
    'underscore',
    'backbone'
], function($, _, Backbone){
    const event = _.extend({}, Backbone.Events);
    return event;
});