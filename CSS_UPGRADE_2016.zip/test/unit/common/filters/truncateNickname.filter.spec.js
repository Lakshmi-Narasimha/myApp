'use strict';

/* jasmine specs for filter go here */

describe('truncateNicknameFilter', function() {

	var truncateNicknameFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    truncateNicknameFilter = $injector.get('$filter')('truncateNickname');
	}));

	//--- Test for definition

	it('should expect truncateNicknameFilter to be defined...', function(){
		expect(truncateNicknameFilter).toBeDefined();
	});

	//--- Test  truncateNickname Filter

	it('should expect proper truncateNickname...', function(){
		expect(truncateNicknameFilter('Savings')).toEqual('Savings');
	});
	
	it('should expect proper truncateNickname...', function(){
		expect(truncateNicknameFilter('Checking')).toEqual('Checking');
	});

});