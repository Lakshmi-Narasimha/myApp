var express = require('express');
var https = require('https');
var config = require('/app/conf/properties/mfchatnode/config');
var logger = require('../../../config/logger');
var router = express.Router();
var getMessageModel = require('./getMessage.model');
var getMessageLPModel = require('./getMessageLP.model');
var engagementModel = require('../engagement/engagement.model');
var apiUtils = require('../../common/apiUtils');
var apiLPUtils = require('../../common/apiLPUtils');
var myCache = require('../../../api-server');

// api route
/* Trigerring the Get Message API on request from Client */
router.route('/mfchatnode/rest/message/:engagementID')
    .post(function(req, res) {
        logger.general.info(logger.formatInfoMsg(req.session.id, "get message called by app with engagementID "+ req.params.engagementID)); 
        logger.general.info(logger.formatInBoundReqMsg(req));
        if(!req.session.isTMP){       
            apiUtils.getMsg(req,res,function(chunk){            
                logger.general.info(logger.formatInBoundResMsg(req, chunk));
                try{
                    chunk = JSON.parse(chunk);   
                }catch(e){                
                    logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json"));
                    res.send(getMessageModel.emptyResponse);
                }
                
                chunk.messages = chunk.messages || [{}];
                if(chunk.messages && chunk.messages[0] && chunk.messages[0].state){
                    if(chunk.messages[0].state === 'assigned'){                              
                        req.session.agentID = engagementModel.response.Page.agentID = chunk.messages[0]['agentID'];
                        req.session.agentName = getMessageModel.response.Page.agentName = chunk.messages[0]['agent.alias'];                
                        engagementModel.response.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                        engagementModel.response.Page.customerID = req.session.customerID ; /// storing customerID into the session
                        engagementModel.ResponseInfo.topMessage = "You're chatting with "+ chunk.messages[0]['agent.alias'];
                        engagementModel.ResponseInfo.type = "Success";
                        engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                        engagementModel.msgList[0].messageList[0].messageText =  chunk.messages[0]['agent.alias'] + " joined the conversation";
                        delete req.session.engagementCompleteReq.VATranscript;
                        req.session.updatedEngagementReq = req.session.engagementCompleteReq;
                        req.session.updatedEngagementReq.event = "Chat Started";
                        req.session.updatedEngagementReq.retryTimes = 0;
                        logger.tag.info(logger.tagsInfo(req.session.updatedEngagementReq));  
                        //engagementModel.msgList[0].messageList[0].condition = "showTranscript";
                        engagementModel.response.ModuleMap.Support.startMsgId = 9999;
                        engagementModel.response.ModuleMap.Support.msgList = engagementModel.msgList;
                        engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                        req.session.getMsgRes = engagementModel.response;
                        apiUtils.sendDataToAcss(req, res, function(response) {});
                        //apiUtils.sendCmd(req, res, function(response) {});
                        apiUtils.dataPass(req, res,function(response) {});
                        logger.general.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                        logger.conversation.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                        logger.general.info(logger.formatInBoundResMsg(req, engagementModel.response));
                        res.send(engagementModel.response);
                    }else if (chunk.messages && chunk.messages[0].state === 'closed'){
                        myCache.set(req.session.engagementID+".mqtt", false);                                                 
                        if (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
                            apiUtils.surveyEligibility(req, res, function(response) {
                                if(response.eligible === true){
                                    var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                    var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                    getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                    getMessageModel.surveyResponse.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                                    getMessageModel.surveyResponse.Page.customerID = req.session.customerID ; /// storing customerID into the session
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                    getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                    req.session.getMsgRes = getMessageModel.surveyResponse;
                                    //apiUtils.sendCmd(req, res, function(response) {});
                                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));   
                                    logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.surveyResponse));
                                    res.send(getMessageModel.surveyResponse);
                                    req.session.destroy();
                                }else{
                                    req.session.getMsgRes = getMessageModel.endResponse; 
                                    //apiUtils.sendCmd(req, res, function(response) {});
                                    logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                    res.send(getMessageModel.endResponse);
                                    req.session.destroy();
                                }
                                apiUtils.cleanMFCCache(req.session.engagementID);
                            }); 
                        }else{                   
                            req.session.getMsgRes = getMessageModel.endResponse;
                            //apiUtils.sendCmd(req, res, function(response) {}); 
                            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));   
                            logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID " +req.session.engagementID));
                            logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID "+req.session.engagementID));
                            apiUtils.cleanMFCCache(req.session.engagementID); 
                            res.send(getMessageModel.endResponse);
                            req.session.destroy();            
                        }          
                    }else if(chunk.messages && chunk.messages[0].state === 'agentIsTyping'){                
                        getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                        getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                        getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                        getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = 50000;
                        getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = 50000;
                        getMessageModel.response.ModuleMap.Support.msgList[0].msgId = 50000;
                        getMessageModel.response.ModuleMap.Support.startMsgId = 50000;
                        getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type; 
                        req.session.getMsgRes = getMessageModel.response;
                        //apiUtils.sendCmd(req, res, function(response) {});
                        res.send(getMessageModel.response);
                        
                    }            
                }else if(chunk.messages && chunk.messages[0] && chunk.messages[0].messageType === 'chatLine' && parseInt(chunk.messages[0].sequenceNumber,10) >=3 ){                
                    var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                    myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1); 
                    if (chunk.messages[0].messageText.toLowerCase() === 'login needed') {
                        getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                        getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                        getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;     
                        req.session.getMsgRes = getMessageModel.loginNeededResponse;
                    }
                    else if(chunk.messages[0].messageText.toLowerCase().indexOf('<a href=')!==-1 && (chunk.messages[0].messageText.toLowerCase().indexOf('http')!==-1 || chunk.messages[0].messageText.toLowerCase().indexOf('https')!==-1)){ 
                                var messageWithLink= chunk.messages[0].messageText;
                                var browserUrlFormed = messageWithLink.match(/(?:"[^"]*"|^[^"]*$)/)[0].replace(/"/g, "");
                                req.session.openUrl = browserUrlFormed;
                                messageWithLink = messageWithLink.replace(/<a.*>/ig,'<a> Click Here</a>');
                                
                                getMessageModel.alinkResponse.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].messageList[0].messageText = messageWithLink;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].messageList[0].ButtonMap.FeedLink.browserUrl= req.session.openUrl;
                                getMessageModel.alinkResponse.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                //delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                                //delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                req.session.getMsgRes = getMessageModel.alinkResponse;
                             }
                            else if(chunk.messages[0].messageText.toLowerCase().indexOf('<a')!==-1 && !(chunk.messages[0].messageText.toLowerCase().indexOf('http')!==-1 || chunk.messages[0].messageText.toLowerCase().indexOf('https')!==-1)){
                                var pageWithLink= chunk.messages[0].messageText;
                                var pageFormed = pageWithLink.match(/(?:"[^"]*"|^[^"]*$)/)[0].replace(/"/g, "");
                                req.session.openPage = pageFormed;
                                pageWithLink = pageWithLink.replace(/<a.*>/ig,'<a> Click Here</a>');
                                
                                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].messageText = pageWithLink;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].ButtonMap.FeedLink.pageType= req.session.openPage;
                                getMessageModel.blinkResponse.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                // delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                                // delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                req.session.getMsgRes = getMessageModel.blinkResponse;
                            }else{
                                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                getMessageModel.response.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                req.session.getMsgRes = getMessageModel.response;
                    }    
                if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                        parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && 
                        parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 3) {
                        myCache.set(req.session.engagementID+".isAssisted", true);
                            apiUtils.assisted(req,res,function(response) {});
                            apiUtils.saveMDN(req,res,function(response) {});
                    }
                    logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.session.engagementID + ' Get Message: ' + chunk.messages[0].messageText);
                    //apiUtils.sendCmd(req, res, function(response) {});
                    res.send(req.session.getMsgRes);
                }else{
                    res.send(getMessageModel.emptyResponse);
                }  
                    
            });
        }else{
             apiLPUtils.getLPMsg(req,res,function(chunk){            
                logger.general.info(logger.formatInBoundResMsg(req, chunk));
                getMessageLPModel.response.ModuleMap.Support.msgList = [];
                try{
                    chunk = JSON.parse(chunk);    
                }catch(e){                
                    logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json"));
                    res.send(getMessageModel.emptyResponse);
                }                               
                if(chunk && chunk.info && chunk.info.state === 'chatting'){
                    req.session.state = chunk.info.state;                    
                    req.session.agentName = chunk.info.agentName;
                    req.session.agentId = chunk.info.agentId;
                    req.session.customerId = chunk.info.visitorId;                    
                    myCache.set(req.session.engagementID+".chatNextMessageUrl", req.session.location + '/events?v=1'+ config.LP_APP_KEY_PARAM);
                    engagementModel.response.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                    engagementModel.response.Page.customerID = chunk.info.visitorId ; /// storing customerID into the session
                    engagementModel.ResponseInfo.topMessage = "You're chatting with "+ chunk.info.agentName;
                    engagementModel.ResponseInfo.type = "Success";
                    engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                    engagementModel.msgList[0].messageList[0].messageText =  chunk.info.agentName + " joined the conversation";
                    //engagementModel.msgList[0].messageList[0].condition = "showTranscript";
                    engagementModel.response.ModuleMap.Support.startMsgId = 9999;
                    engagementModel.response.ModuleMap.Support.msgList = engagementModel.msgList;
                    engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                    res.send(engagementModel.response);                                                                  
                    logger.general.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText + " with EngagementID:" + req.session.engagementID));
                    logger.conversation.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText + " with EngagementID:" + req.session.engagementID));                    
                }else{
                    if(chunk && chunk.events){
                        if(chunk.events.link){
                            let linkArray = chunk.events.link;
                             for(i=0;i<linkArray.length;i++){
                                 if(linkArray[i]['@rel'] === 'next'){
                                    myCache.set(req.session.engagementID+".chatNextMessageUrl", linkArray[i]['@href']+'&v=1'+ config.LP_APP_KEY_PARAM);                                                                      
                                    break;
                                 }
                             }
                        }
                        
                        if(chunk.events.event){
                            var eventArray = chunk.events.event; 
                            getMessageLPModel.response.ModuleMap.Support.msgList = [];
                            if((Object.prototype.toString(eventArray) === '[object Object]' && eventArray['@type'] ==='state' && eventArray.state ==='ended') 
                                || myCache.get(req.session.engagementID+".closed") === true){
                                req.session.state = "";
                                req.session.getMsgRes = getMessageLPModel.endResponse; 
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "LPChat ended with EngagementID: "+ req.session.engagementID));
                                apiLPUtils.cleanMFCCache(req.session.engagementID);
                                res.send(req.session.getMsgRes);                               
                            }else if(Object.prototype.toString(eventArray) === '[object Object]' && eventArray['@type'] ==='line' && eventArray.source ==='agent'){                               
                                var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                                getMessageLPModel.response.ModuleMap.Support.startMsgId = msgCount+10000;
                                myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1);
                                myCache.set(req.session.engagementID+".chatTimer", new Date().getTime());                                   
                                let msgText = apiLPUtils.getPlainText(eventArray.text);  
                                let msgObj = {};
                                let msgContent = {};
                                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.session.engagementID + ' LPGet Message: ' + msgText);
                                msgObj.type = 'chat',
                                msgObj.msgId = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10)+9999;//req.session.getMsgCount;
                                msgObj.messageType = 'chatLine',
                                msgObj.sequenceNumberInt = 20000,
                                msgObj.animationDuration = 800,
                                msgObj.messageList = [],
                                msgContent.content = msgText;
                                msgContent.nextmsgId = -1;
                                msgObj.messageList.push(msgContent);                                    
                                getMessageLPModel.response.ModuleMap.Support.msgList.push(msgObj);
                                req.session.getMsgRes = getMessageLPModel.response;
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.response)); 
                                res.send(req.session.getMsgRes);
                            }else{
                                getMessageLPModel.response.ModuleMap.Support.startMsgId = (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0)+10000;
                                let arraySize = 0;
                                for(i=0;i<eventArray.length;i++){
                                    if(eventArray[i]['@type']==='line' && eventArray[i].source === 'agent'){ 
                                        arraySize++; 
                                        var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                                        myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1);
                                        myCache.set(req.session.engagementID+".chatTimer", new Date().getTime());                                   
                                        let msgText = apiLPUtils.getPlainText(eventArray[i].text);  
                                        let msgObj = {};
                                        let msgContent = {};
                                        logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.session.engagementID + ' LPGet Message: ' + msgText);
                                        msgObj.type = 'chat',
                                        msgObj.msgId = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10)+9999;//req.session.getMsgCount;
                                        msgObj.messageType = 'chatLine',
                                        msgObj.sequenceNumberInt = 20000,
                                        msgObj.animationDuration = 800,
                                        msgObj.messageList = [],
                                        msgContent.content = msgText;
                                        msgContent.nextmsgId = msgObj.msgId + 1;
                                        msgObj.messageList.push(msgContent);                                    
                                        getMessageLPModel.response.ModuleMap.Support.msgList.push(msgObj);                                        
                                        req.session.getMsgRes = getMessageLPModel.response;
                                        logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.response));                                    
                                    }else if(eventArray[i]['@type'] ==='state' && eventArray[i].state ==='ended'){
                                        req.session.getMsgRes = getMessageLPModel.endResponse; 
                                        logger.conversation.info(logger.formatInfoMsg(req.session.id, "LPChat ended with EngagementID: "+ req.session.engagementID));                                       
                                        break;
                                    }
                                }
                                 if(arraySize>=1){
                                    getMessageLPModel.response.ModuleMap.Support.msgList[arraySize-1].messageList[0].nextmsgId = -1;
                                } 
                                res.send(req.session.getMsgRes);
                            }                                                        
                                                        
                        }else{                            
                            logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.emptyResponse));
                            res.send(getMessageLPModel.emptyResponse);                           
                        }
                    }
                }               

             });
        }
    });
module.exports = router;
