/**
 * @ngdoc factory
 * @name selectFundGrid factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var swpTxnDetailsFactory = function () {

    var swpTxnDetailsFactory = {
        getTxnDetails: function (userType, transConf, swpDetails, invDetails, fundDetails, datefilter) {
            var _txnDetails = [];
            if (userType && (userType.toString() === '10')) {
                _txnDetails = [{
                    key: 'folioId',
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    key: 'fmDescription',
                    text: 'Fund',
                    value: fundDetails.fmDescription
                }, {
                    key: 'tschvalAccno',
                    text: 'Account Number',
                    value: fundDetails.tschvalAccno
                }, {
                    key: 'transactionRefNo',
                    text: 'Transaction Reference No.',
                    value: transConf.transactionRefNo
                }, {
                    key: 'requestDateTime',
                    text: 'Request Date and Time ',
                    value: transConf.transDateTime
                }, {
                    key: 'selectedType',
                    text: 'Withdrawl Type',
                    value: (swpDetails.selectedType === 'capital') ? 'Capital Appreciation' : 'Fixed Amount'
                }, {
                    key: 'amt',
                    text: 'Amount',
                    value: swpDetails.swpAmtValue
                }, {
                    key: 'freq',
                    text: 'Frequency',
                    value: swpDetails.frequency
                }, {
                    key: 'swpStrtDate',
                    text: 'SWP Start Date',
                    value: datefilter(swpDetails.startDate, 'dd MMMM yyyy, hh:mm a')
                }, {
                    key: 'swpEndDate',
                    text: 'SWP End Date',
                    value: datefilter(swpDetails.endDate, 'dd MMMM yyyy, hh:mm a')
                }];
            } else {
                _txnDetails = [{
                    key: 'transactionRefNo',
                    text: 'Transaction Reference No.',
                    value: transConf.transactionRefNo
                }, {
                    key: 'requestDateTime',
                    text: 'Request Date and Time ',
                    value: transConf.transDateTime
                }, {
                    key: 'amt',
                    text: 'Amount',
                    value: swpDetails.swpAmtValue
                }, {
                    key: 'freq',
                    text: 'Frequency',
                    value: swpDetails.frequency
                }, {
                    key: 'swpStrtDate',
                    text: 'SWP Start Date',
                    value: datefilter(swpDetails.startDate, 'dd MMMM yyyy, hh:mm a')
                }, {
                    key: 'swpEndDate',
                    text: 'SWP End Date',
                    value: datefilter(swpDetails.endDate, 'dd MMMM yyyy, hh:mm a')
                }, {
                    key: 'noOfInstallments',
                    text: 'No of Installments',
                    value: swpDetails.noofInstallments
                }];
            }
            return _txnDetails;
        }
    };
    return swpTxnDetailsFactory;

};

swpTxnDetailsFactory.$inject = [];
module.exports = swpTxnDetailsFactory;
