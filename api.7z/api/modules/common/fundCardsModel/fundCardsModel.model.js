// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FundCardsModelSchema = new mongoose.Schema({
    FundCardsModelObject: {
        type: Array,
        "default": []
    }
});

var FundCardsModelLookup = mongoose.model('FundCardsModelLookup', FundCardsModelSchema);

var FundCardsModel = new FundCardsModelLookup({

  "fundCardsModelObject": [
    {
      "fundCardModelResp": [{
        "fundCardData": [{
          "fundName": "Franklin India Blue Chip Fund",
          "fundId": 4752,
          "cprRating": 4,
          "fundDescription": "To provide long-term capital appreciation by investing predominantly in large cap.",
          "suitableFor": "Retirement, Wealth Creation",
          "performanceAnnualized": [{
            "value": "SinceInception",
            "percentage": "6.5"
          }, {
            "value": "One Year",
            "percentage": "7.5"
          }, {
            "value": "Two Year",
            "percentage": "8.5"
          }, {
            "value": "Three Year",
            "percentage": "5.5"
          }]
        }]
      }]
  }]
});

FundCardsModelLookup.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FundCardsModelLookup Model, please contact admin...');
    } else {
        FundCardsModelLookup.remove({}, function(err) {
            console.log('FundCardsModelLookup collection removed');
            FundCardsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FundCardsModelLookup Model, please contact admin...');
                }
                console.log('FundCardsModelLookup Model created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FundCardsModelLookup;
