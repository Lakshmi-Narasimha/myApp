define([
  'jquery',
  'underscore',
  'backbone',
  'config',
  'spinner',
  'services/dataservice',
  'appcommon/constants',
  'appcommon/globalcontext',
  'appcommon/commonutility',
  'appmodules/nav/app/models/contactdetails',
  'text!appmodules/nav/app/templates/contactlistshell.html',
   'text!appmodules/nav/app/templates/contactlist.html',
   'text!appmodules/nav/app/templates/contactlistdetails.html',
   'text!appmodules/nav/app/templates/contactlistoverthousand.html',
   'text!appmodules/nav/app/templates/contactdetailsoverthous.html',
   'appcommon/analytics',
   'errorLog',
], function ($, _, Backbone, Config, Spinner, Dataservice, Constants, GlobalContext, Utility, ContactDetailsModel, ContactlistShellTemplate, ContactlistTemplate, ContactlistDetailsTemplate, ContactOverThouTemplate, ContactDetailsOverThous, Analytics, ErrorLog) {
        var self = null,contactlist = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click .sorting": "sortContactList",
            "click .cl-actions": "showDetails",
            "click .vertical-div a" : "showContactSubSection",
            "click .add-contact": "showAddContactPage",
            "click .edit-contact": "showEditContactPage",
            "click #cl-modal .modal-footer": "hideclmodal",
            "click #contactlist-nav": "clNavBtnClick",
            "click #ClientBtn": "clientBtnClick",
            "click #ProspectBtn": "prospectBtnClick"
        },

        initialize: function () {
            var _that = this;
                self = this;
        	 this.contactList = [];
        	 this.globalContext = GlobalContext.getInstance();
        	 this.counter = 0;
        	 this.timer = null;
        	 this.eleId = 0;
        	 this.clLnks = undefined;
            $(window).on("scroll", this.adjustContactBar);
        	 $(window).on("orientationchange", function () {
        	     if ($("#cl-modal").is(":visible")) {
        	         setTimeout(function () {
        	             var clmaxheight = _that.adjustclmodal();
        	             $("#cl-modal .modal-body").css({ "max-height": clmaxheight + "px" });
        	         }, 300);
        	     }
        	 });
        	 $(window).resize(function () {
        	     if (!(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i))) {
        	         if ($("#cl-modal").is(":visible")) {
        	             var clmaxheight = _that.adjustclmodal();
        	             $("#cl-modal .modal-body").css({ "max-height": clmaxheight + "px" });
        	          }
                   }
        	 });
        	 $(document).off("click", ".cl-alpha-header").on("click", ".cl-alpha-header", function (e) { _that.togglealphaList(e) });
            //event listner for contactlist ready
        	 $(document).off("contactlistready", _that.contactListReadyHandler).on("contactlistready", _that.contactListReadyHandler);
        },

        clNavBtnClick : function (e){
            $('#cl-btns-section').slideToggle('slow');
        },

        clientBtnClick: function (e) {
            //this.linkActive(this.clLnks, e.target.id);
            $('#cl-btns-section').slideToggle('slow');
            Backbone.history.navigate('navigator/contactlist', true);
        },
        prospectBtnClick: function (e) {
            e.preventDefault();
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                Utility.toggleNonCMmsg("function");
                return;
            }
            else {
                $('#cl-btns-section').slideToggle('slow');
                Backbone.history.navigate('navigator/prospectlist', true);
            }
        },

        //linkActive: function (clLnks, thisLnk) {
        //    if (clLnks.parent().hasClass('hdr-tab-active')) {
        //        clLnks.parent().removeClass('hdr-tab-active');
        //        $("#" + thisLnk).parent().addClass('hdr-tab-active');
        //    }
        //},
        togglealphaList: function (e) { 
            $(".contact-list-wrapper div").remove(); 
            var target = e.target || e.currentTarget;
            $(".cl-alpha-header").each(function (e) {
                var $that = this; 
                if ($that !== target) {
                    if ($($that).hasClass("cl-opened")) {
                        $($that).parent().parent().next().slideUp(250);
                        $($that).removeClass("cl-opened").addClass("cl-closed");
                    }
                }
            });
        	var data = $(target).data("target");
        	var collapsable = $("#" + data);
        	if ($(target).hasClass("cl-closed")) {
            // Integration code
        	Spinner.show();
        	var _that = this;
        	var filter = undefined;
        	var fmid = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
        	var keyWord = data.slice(7);

        	filter = "startswith(lastNm,'" + keyWord + "') eq true";
        	Dataservice.getClientsForContactList(fmid, Config.contactListLimit, filter, [404]).then(gotoAsyncCallSuccess).fail(gotoAsyncCallError);

        	function gotoAsyncCallSuccess(result) {
        	    var actualRecordList = result.d.results;
        	    //Filling results to the common Navigator contact repository
        	    ContactDetailsModel.advsiorContacts.AddContactDetailsFromContactList(fmid,actualRecordList,Constants.contactType.Client,true);
        	    
        	    var compiledDetailsTemplate = _.template(ContactDetailsOverThous);
        	    actualRecordList.sort(Utility.sortMultiColumn({
    			    name: 'lastNm',
    			    reverse: false
    			  }, 'firstNm', 'id'));
                _that.contactList = actualRecordList;
                
        	    collapsable.html(compiledDetailsTemplate({ row: actualRecordList }));
        	    Spinner.hide();
        	};
        	function gotoAsyncCallError(Error) {
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(Error);
        	};
        	    collapsable.slideDown(250);
        	    $(target).removeClass("cl-closed");
        	    $(target).addClass("cl-opened");
        	    setTimeout(function () {
        	        window.scrollTo(0, $(target).offset().top);
        	    }, 300);        	   
    	
        	} else {
        	    collapsable.slideUp(250);
        	    $(target).addClass("cl-closed");
        	    $(target).removeClass("cl-opened");
            }
        },
        showAddContactPage : function(){
            var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            if (_isNonCMuser) {
                Utility.toggleNonCMmsg("function");
                return;
            }
            else {
                Analytics.analytics.processNavSubRouteChangeEvent('addContact');
                Backbone.history.navigate("navigator/addcontact", true);
            }
        },
        showEditContactPage: function () {
            Analytics.analytics.processNavSubRouteChangeEvent('editContact');
            Backbone.history.navigate("navigator/editcontact", true);
        },
        hideclmodal : function(e){
            $("#cl-modal").modal('hide');
            var _top = $("body").css("top");
            var _bodytop = Math.abs(_top.substr(0, _top.length-2));
            $('body').removeAttr('style');
            $(window).scrollTop(_bodytop);
            $($(".fc-agenda-divider.fc-widget-header").next()[0]).css({"overflow-y": "auto", "-webkit-overflow-scrolling": "touch" });
            //$('html,body').animate({ scrollTop : $("#" +this.eleId).offset().top}, 0);
            //$(window).scrollTop(clmodaloffset);
        },

        adjustContactBar: function(e){
            //var barHeight = $('.top-nav-header').height();
            //var navBarHeight = $('#afinav-navbar').height();
            //var offsetHeight = barHeight + navBarHeight;
            var offsetHeight = $('.top-nav-header').height() + $('#afinav-navbar').height();
            var scrollTopHeight = $(this).scrollTop();
            var totalOffset = scrollTopHeight - offsetHeight;
            if (scrollTopHeight >= offsetHeight) {
                $('.vertical-div').css("margin-top", -(offsetHeight-10));
            }
            else{
                $('.vertical-div').css("margin-top", "10px");
            }
        },

        //Dynamic POPUP Height Calculations

        adjustclmodal :function(e){
            var _ofsetheight = 0;
            var _clmodalheight = window.innerHeight;
            if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
                if ($(window).width() > $(window).height()) {
                    _offsetHeight = 84;
                }
                else if ($(window).height() > $(window).width()) {
                    _offsetHeight = 114;
                }
            }
            else {
                _offsetHeight = 84;
            }
            var reqmodalheight = _clmodalheight - _offsetHeight;
            return reqmodalheight;
        },

        showDetails: function (e) {
        	try{
        		var _that = this;
        		var _target = e.target || e.currentTarget;
        		_that.eleId = $(_target).parent().parent().attr("id");
            	var _selectedClient = $(_target).parent().parent().data("clientid");
            	var _selectedIndex = $(_target).parent().parent().data("index");
            	var _selectedAction = $(_target).data("action");
            	var _selectedClientname = $.trim($(_target).parent().parent().find("div:first").text());
            	var _serviceCallsStack = [];
            	function renderContactDetails(details){
            		var compiledTemplate = _.template(ContactlistDetailsTemplate);
        			$("#cl-modal-body").html(compiledTemplate({name:_selectedClientname,details:details})).promise().done(function(){
        				$(".cl-pop-details").hide();
        				$("." + _selectedAction).show();
        				setTimeout(function () {
        				    $("#cl-modal").modal('show');
        				    var clmaxheight= _that.adjustclmodal();
        				    $("#cl-modal .modal-body").css({ "max-height": clmaxheight + "px" });
        				}, 400);
        				var clmodaloffset = $(window).scrollTop();
        				    $('body').css({ 'overflow': 'hidden', 'position': 'fixed', 'width': '100vw', 'padding-right': '0px', 'top': -(clmodaloffset)
        				    });
            			$($(".fc-agenda-divider.fc-widget-header").next()[0]).css("overflow-y", "hidden");
//            			$('#cl-modal').on('hide.bs.modal', function (e) {
//            				var dialogName;
//            				if (_selectedAction == 'cl-email-details') {
//            					dialogName = 'email';
//            				} else if (_selectedAction == 'cl-tel-details') {
//            					dialogName = 'telephone';
//            				} else if (_selectedAction == 'cl-loc-details') {
//            					dialogName = 'location';
//            				};
//            				Analytics.analytics.recordAction('NavShowContactList:' + dialogName + 'DialogClosed');
//            			});
            			if (_selectedAction == 'cl-email-details') {
            				Analytics.analytics.recordAction('NavShowContactListEmail:clicked');
            			} else if (_selectedAction == 'cl-tel-details') {
            				Analytics.analytics.recordAction('NavShowContactListTelephone:clicked');
            			} else if (_selectedAction == 'cl-loc-details') {
            				Analytics.analytics.recordAction('NavShowContactListLocation:clicked');
            			}
        			});
        		}
            	
            	function gototClientProfileSuccess(result){
            		if(result[0] && result[0]['value'][0]){
            			var colaProfileInfo = result[0]['value'][0];
            		}
            		if(result[1] && result[1]['value'][0]){
            			var ebixProfileInfo = result[1]['value'][0];
            		}
            		if(colaProfileInfo){
            			//Sorting - By adding prefCode 
            			var tmpClientTlphones = (colaProfileInfo['attributes']['telephones'].length && colaProfileInfo['attributes']['telephones'].length >0) ? colaProfileInfo['attributes']['telephones'] : [];
                    	_.each(tmpClientTlphones, function (val, key) {
                    		//if(!val.isCustom){
                    			val.phnLblTxt = val.phnLblTxt.toUpperCase(val.phnLblTxt);
                        	    if (val.phnLblTxt == 'HOME') { val['prefCode'] = "1"; }
                        	    if (val.phnLblTxt == 'WORK') { val['prefCode'] = "2"; val['phnLblTxt'] = "BUSINESS";}
                        	    if (val.phnLblTxt == 'MOBILE') { val['prefCode'] = "3"; }
                        	    if (val.phnLblTxt == 'OTHER1') { val['prefCode'] = "4"; }
                        	    if (val.phnLblTxt == 'OTHER2') { val['prefCode'] = "5"; }
                    		//}
                    	});

                    	tmpClientTlphones = _.sortBy(tmpClientTlphones, 'prefCode');
                        //Sorting code ends here 
            			
            			_that.contactList[_selectedIndex].clientTelephones = tmpClientTlphones;
            			_that.contactList[_selectedIndex].clientEmails = colaProfileInfo['attributes']['clientEmails'];
    					_that.contactList[_selectedIndex].clientPostalAddresses = colaProfileInfo['attributes']['clientPostalAddresses'];
            		}
            		if(ebixProfileInfo){
            			_that.contactList[_selectedIndex].ebixTelephones = ebixProfileInfo['attributes']['Phones'];
            			//Sort on the basis of Preferred indicator
            			if(_that.contactList[_selectedIndex].ebixTelephones && _that.contactList[_selectedIndex].ebixTelephones.length>0){
            				_that.contactList[_selectedIndex].ebixTelephones.sort(function(key,row){
            					if(row.get("Preferred") == "1"){
            						return 1;
            					}
            				});
            			}
    					_that.contactList[_selectedIndex].ebixEmails = ebixProfileInfo['attributes']['WebAddresses'];
    					//Sort on the basis of Preferred indicator
    					if(_that.contactList[_selectedIndex].ebixEmails && _that.contactList[_selectedIndex].ebixEmails.length>0){
    						_that.contactList[_selectedIndex].ebixEmails.sort(function(key,row){
            					if(row.get("Preferred") == "1"){
            						return 1;
            					}
            				});
    					}
                        //Code Commented for PT - 4832 - Hiding Contact Manager postal address in CP View page
    					/*_that.contactList[_selectedIndex].ebixPostalAddresses = ebixProfileInfo['attributes']['Addresses'];
    					//Sort on the basis of Preferred indicator
    					if(_that.contactList[_selectedIndex].ebixPostalAddresses && _that.contactList[_selectedIndex].ebixPostalAddresses.length>0){
    						_that.contactList[_selectedIndex].ebixPostalAddresses.sort(function(key,row){
            					if(row.get("Preferred") == "1"){
            						return 1;
            					}
            				});
    					}*/
            		}
    				renderContactDetails(_that.contactList[_selectedIndex]);
    				Spinner.hide();
            	}
            	
            	if(_selectedClient && _selectedIndex> -1){
            	    var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
            			//Get contactId from Ebix
            	    Spinner.show();
            	    if (_isNonCMuser == true) {
            	        _serviceCallsStack.push(Dataservice.getContactprofileInfo(_selectedClient, Constants.clientMaxAgeVal));
            	        Q.allSettled(_serviceCallsStack)
							.then(function (response) {
							    if (response && response.length > 0) {
							        _serviceCallsStack = [];
							        gototClientProfileSuccess(response);
							    }
							})
							.fail(function (error) {
							    Spinner.hide();
							    ErrorLog.ErrorUtils.myError(error);
							})
            	    }
            	    if (_isNonCMuser == false) {
            	        Dataservice.getContactDetailsbyClientId(Utility.readCookie('FMID'), _selectedClient)
						.then(function (response) {
						    _serviceCallsStack.push(Dataservice.getContactprofileInfo(_selectedClient, Constants.clientMaxAgeVal));
						    if (response[0] && response[0].attributes && response[0].attributes.contactId) {
						        _serviceCallsStack.push(Dataservice.getNonClientEbixDetails(Utility.readCookie('FMID'), response[0].get('contactId')));
						    }
						    //Queuing the service requests
						    Q.allSettled(_serviceCallsStack)
								.then(function (response) {
								    if (response && response.length > 0) {
								        _serviceCallsStack = [];
								        gototClientProfileSuccess(response);
								    }
								})
								.fail(function (error) {
								    Spinner.hide();
								    ErrorLog.ErrorUtils.myError(error);
								})
						})
						.fail(function (error) {
						    Spinner.hide();
						    ErrorLog.ErrorUtils.myError(error);
						})
            	    }
            	}
            	
        	}catch(error){
        		ErrorLog.ErrorUtils.myError(error);
        	}
        	
        	
        },
        sortContactList: function (e) {
        	try{
        		var $this = $(e.currentTarget);
                var $thisSpan = $this.find("span.sorticons");
                var sortOrder = "";
                var sortField = $this.attr('data-sort');
                if (!$this.hasClass("reset-sorting")) {
                    if ($thisSpan.hasClass("desc-icon")) {
                        $thisSpan.removeClass("desc-icon").addClass("asc-icon").addClass("act");
                        sortOrder = "asc";

                    }
                    else if ($thisSpan.hasClass("asc-icon")) {
                        $thisSpan.removeClass("asc-icon").addClass("desc-icon").addClass("act");
                        sortOrder = "desc";
                    }
                    else {
                        $thisSpan.addClass("asc-icon").addClass("act");
                        sortOrder = "asc";
                    }
                }
                $(".sorting").each(function () {

                    var $innerThisSpan = $(this).find('span.sorticons');
                    if (!$thisSpan.is($innerThisSpan) && $innerThisSpan.hasClass("act")) {
                        if ($innerThisSpan.hasClass("asc-icon")) {
                            $innerThisSpan.removeClass("asc-icon").removeClass("act");
                        }
                        if ($innerThisSpan.hasClass("desc-icon")) {
                            $innerThisSpan.removeClass("desc-icon").removeClass("act");
                        }

                    }

                });
        	}catch(error){
        		ErrorLog.ErrorUtils.myError(error);
        	}
            
        },
        showContactSubSection : function(e){
        	try{
        		var _target = e.target || e.currentTarget;
            	var _subSecId = $(_target).data("sub-section");
            	window.scrollTo(0,$('#'+_subSecId).offset().top);
        	}catch(e){
        	    ErrorLog.ErrorUtils.info({ msg: "No contact found for the selected section." });
        	}
        	
        },
        applyaSortToContacts : function(contacts){
        	if(contacts && contacts.length>0){
        		contacts.sort(function (r1, r2) {
  				  if(r1.lastNmFmtd === ""){
  					return -1;
  				  }
  				  if (r1.lastNmFmtd && r2.lastNmFmtd && r1.lastNmFmtd.toUpperCase() > r2.lastNmFmtd.toUpperCase()) { 
  				    return 1;
  				  }
  				  if (r1.lastNmFmtd && r2.lastNmFmtd && r1.lastNmFmtd.toUpperCase() < r2.lastNmFmtd.toUpperCase()) {
  				    return -1;
  				  }
  				  // r1 must be equal to r2
  				  return 0;
  				});
        	}
        },
        processContactList : function(advisorId){
        	try{
        		var _that = this;
        	    var generalTemplate = _.template(ContactlistShellTemplate);
        	    _that.$el.html(generalTemplate());
        	    _that.clLnks = $("#cl-menu-list > div > a");
        		var compiledTemplate = _.template(ContactlistTemplate);
        		var compiledOverTemplate = _.template(ContactOverThouTemplate); //over Thousand CL
        		var isContactSearchDynamic = ContactDetailsModel.advsiorContacts.getContactSearchType(advisorId);
        		var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;
        		if(isContactSearchDynamic === undefined){
        			//_that.timer = setTimeout(function(){
        			//	_that.counter++;
        			//	_that.processContactList(advisorId);
        			//},500);
        			//don't do anything event will fire once client list is success
        		}else{
        			clearTimeout(_that.timer);
        			if(advisorId){
        			    if (userRoles && (userRoles.indexOf("csr") > -1) && advisorId == Utility.readCookie('FMID')) {
    						$(".cl-list-container").html(compiledTemplate({ contactList: [], noClientsFound: true }));
                			Spinner.hide();
        				}
        				else if (isContactSearchDynamic === true) {    			    
        				    //_that.$el.html(compiledTemplate({ contactList: [], noClientsFound: false })); 
        			        $(".cl-list-container").html(compiledOverTemplate({ contactList: [] }));
                			Spinner.hide();
                		}else{
                    		var _actualContactList = ContactDetailsModel.advsiorContacts.GetContactDetails(advisorId,Constants.contactType.Client);
                    		//_that.applyaSortToContacts(_actualContactList);
                    		_that.contactList = _actualContactList;
                    		if(_that.contactList && _that.contactList.length>0){
                    			_that.contactList.sort(Utility.sortMultiColumn({
                    			    name: 'lastNm',
                    			    reverse: false
                    			  }, 'firstNm', 'id'));
                    			
                    		}
                    		$(".cl-list-container").html(compiledTemplate({ contactList: _actualContactList, noClientsFound: (!_actualContactList ? true : false) }));
                			Spinner.hide();
                		}
        			}else{
        				$(".cl-list-container").html(compiledTemplate({ contactList: [], noClientsFound: true }));
            			Spinner.hide();
        			}
        			
        		}
        	}catch(error){
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(error);
        	}
        },
        render: function () {
        	try{
        		var advisorId = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
        		var _that = this; self = this;
        		Spinner.show();
        		_that.processContactList(advisorId);
        		var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
        		if (_isNonCMuser) {
        		    Utility.toggleNonCMmsg("login");
        		}
        	}catch(error){
        		Spinner.hide();
        		ErrorLog.ErrorUtils.myError(error);
        }
        },
        contactListReadyHandler: function (event) {
            console.log(event, "custom event");
            if (location.hash != "#crm/") {
                var _advisorId = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
                Spinner.show();
                self.processContactList(_advisorId);
            }

        }
    });
    return contactlist;
});
