import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Observer} from 'rxjs/Observer';

import { Agent } from '../_models/index';
import { Intent } from '../_models/index';
import { UserExpression } from '../_models/userexpression';
import { AIAssistCache } from '../_models/index';

import { AIAssistRestService } from './aiassistrest.service';

@Injectable()
export class AIAssistCacheService {

  private agentsList : Array<Agent> = [];
  private activeAgent : Agent;
  private activeAgentIntents : Array<Intent> = [];
  private activeIntent : Intent;
  private activeUserExpressions : Array<UserExpression> = [];
  private intentEditMode : boolean = true;
  private newUserExpressions : Array<UserExpression> = [];
  private removedUserExpressions : Array<UserExpression> = [];
  private activeParamMap : any = {};
  private activeParamList : Array<string> = [];

  private agentsListObserver : Observer<any>;
  private activeAgentObserver : Observer<any>;
  private activeIntentsObserver : Observer<any>;
  private activeIntentObserver : Observer<any>;
  private activeUserExpressionsObserver : Observer<any>;
  private intentEditModeObserver : Observer<any>;
  private activeParamListObserver : Observer<any>;
  private activeParamMapObserver : Observer<any>;


  agentListObservable : Observable<any>;
  activeAgentObservable : Observable<any>;
  activeIntentsObservable : Observable<any>;
  activeIntentObservable : Observable<any>;
  activeUserExpressionsObservable : Observable<any>;
  intentEditModeObservable : Observable<any>;
  activeParamListObservable : Observable<any>;
  activeParamMapObservable : Observable<any>;

    constructor(private restService : AIAssistRestService) {
      //console.log("new cache service created");
      this.agentListObservable = new Observable(observer => this.agentsListObserver = observer).share();
      this.activeAgentObservable = new Observable(observer => this.activeAgentObserver = observer).share();
      this.activeIntentsObservable = new Observable(observer => this.activeIntentsObserver = observer).share();
      this.activeIntentObservable = new Observable(observer => this.activeIntentObserver = observer).share();
      this.activeUserExpressionsObservable = new Observable(observer => this.activeUserExpressionsObserver = observer).share();
      this.intentEditModeObservable = new Observable (observer => this.intentEditModeObserver = observer).share();
      this.activeParamListObservable = new Observable (observer => this.activeParamListObserver = observer).share();
      this.activeParamMapObservable = new Observable (observer => this.activeParamMapObserver = observer).share();
    }

    serverLoadAgents () {
      //this.restService.getAllAgentsFromServer();
        this.restService.getAllAgents().subscribe((data) => {
          //console.log("inside cache subscribe before -> data -> ");
          //console.log(data);
          // console.log("agentsList -->");
          // console.log(this.agentsList);
          this.updateAgents(data.agentList);
          // this.agentsList.length = 0;
          // this.agentsList.push.apply(this.agentsList, data);
          // console.log("inside cache subscribe after -> data -> ");
          // console.log(data);
          // console.log("agentsList -->");
          // console.log(this.agentsList);
        },
      (err)=>{
        console.log(err);
      });
        //console.log(this.agentsList);
        //this.cachedData.setAgentsList(this.restService.getAllAgents());
    }

    // serverGetAgent(pAgent : Agent) {
    //   this.restService.getAgentById(pAgent).subscribe(
    //     (data) => {},
    //     (err) => {}
    //   );
    // }

    getIntentsByAgentFromServer(pAgent:Agent) {
      this.restService.getAgentById(pAgent).subscribe((data) => {
        this.updateActiveAgentIntentList(data.agent);
      },
    (err)=>{
      console.log(err);
    });
    }

    getIntentByIdFromServer(pIntent:Intent) {
      this.restService.getIntentById(pIntent).subscribe((data) => {
        // console.log("Inside getIntentByIdFromServer");
        // console.log(JSON.stringify(data.intent));
        this.updateActiveIntent(data.intent);
      },
    (err)=>{
      console.log(err);
    });
    }

    updateAgents(pagentsList:Array<Agent>) {
      this.agentsList = pagentsList;
      this.agentsListObserver.next(pagentsList);
      if(this.activeAgent == null && this.activeAgent == undefined ) {
        this.updateActiveAgent(pagentsList[0]);
      }
    }

    updateActiveAgent(pAgent:Agent) {
      //console.log("Before --> this.activeAgent : " + JSON.stringify(this.activeAgent));
      this.activeAgent = pAgent;
      if ( this.activeAgentObserver == null || this.activeAgentObserver == undefined || this.activeAgentObservable == null || this.activeAgentObservable == undefined )
        this.activeAgentObservable = new Observable(observer => this.activeAgentObserver = observer).share();
      this.activeAgentObserver.next(pAgent);
      //console.log("Before --> this.activeAgent : " + JSON.stringify(this.activeAgent));
      this.getIntentsByAgentFromServer(pAgent);
    }

    updateActiveAgentIntentList(pAgent:Agent) {
      this.activeAgentIntents = pAgent.intentList;
      if(this.activeIntentsObserver == null ||  this.activeIntentsObserver == undefined || this.activeIntentsObservable == null || this.activeIntentsObservable == undefined )
        this.activeIntentsObservable = new Observable(observer => this.activeIntentsObserver = observer).share();

        // console.log("AIAssistCacheService");
        // console.log(JSON.stringify(pAgent));
        // console.log(pAgent);
        // console.log(pAgent.intentList);

      this.activeIntentsObserver.next(pAgent.intentList);
      if(this.activeAgentIntents != null && this.activeAgentIntents != undefined && this.activeAgentIntents.length > 0) {
        this.getIntentByIdFromServer(this.activeAgentIntents[0]);
      } else {
        this.updateActiveIntent(null);
        this.updateActiveUserExpression(new Array<UserExpression>());
      }
    }

    updateActiveIntent(pIntent:Intent) {
      this.activeIntent = pIntent;
      if(this.activeIntentObserver == null || this.activeIntentObserver == undefined || this.activeIntentObservable == null || this.activeIntentObservable == undefined )
        this.activeIntentObservable = new Observable(observer => this.activeIntentObserver = observer).share();
        //console.log("Inside aiAssistCacheService");
        //console.log(JSON.stringify(pIntent));
      this.activeIntentObserver.next(pIntent);
      // console.log("Inside updateActiveIntent");
      // console.log(JSON.stringify(pIntent));
      // console.log(JSON.stringify(pIntent.expressionList));
      if(pIntent != null)
      this.updateActiveUserExpression(pIntent.expressionList);
      this.updateParamList(pIntent.paramTypeList)
      this.updateActiveParamMap(pIntent.paramMap);
    }

    updateActiveUserExpression(pUserExpressions:Array<UserExpression>) {
      // console.log("Inside updateActiveUserExpression");
      // console.log(JSON.stringify(pUserExpressions));
      if (pUserExpressions == undefined || pUserExpressions == null) {
        pUserExpressions = new Array<UserExpression>();
      }
        this.activeUserExpressions = pUserExpressions;
      if( this.activeUserExpressionsObserver == null || this.activeUserExpressionsObserver == undefined || this.activeUserExpressionsObservable == null ||  this.activeUserExpressionsObservable == undefined)
        this.activeUserExpressionsObservable = new Observable(observer => this.activeUserExpressionsObserver = observer).share();
        this.activeUserExpressionsObserver.next(pUserExpressions);
    }

    updateParamList(pParamList:Array<string>) {
      if(pParamList == undefined || pParamList == null) {
        pParamList = [];
      }
      this.activeParamList = pParamList;
      if(this.activeParamMapObservable == null || this.activeParamMapObservable == undefined || this.activeParamMapObserver == null || this.activeParamMapObserver == undefined)
      this.activeParamMapObservable = new Observable (observer => this.activeParamMapObserver = observer).share();
      this.activeParamListObserver.next(pParamList);
    }

    updateActiveParamMap(pParamMap:any) {
      // console.log("inside updateActiveParamMap");
      // console.log(pParamMap);
      if ( pParamMap == undefined || pParamMap == null ) {
        pParamMap = {};
      }
      this.activeParamMap = pParamMap;
      if( this.activeParamMapObserver == null || this.activeParamMapObserver == undefined || this.activeParamMapObservable == null || this.activeParamMapObservable == undefined )
        this.activeParamMapObservable = new Observable (observer => this.activeParamMapObserver = observer).share();
        this.activeParamMapObserver.next(pParamMap);

    }

    setIntentEdit(pEditMode:boolean) {
      this.intentEditMode = pEditMode;
      if( this.intentEditModeObserver == null || this.intentEditModeObserver == undefined || this.intentEditModeObservable == null || this.intentEditModeObservable == undefined)
      this.intentEditModeObservable = new Observable (observer => this.intentEditModeObserver = observer).share();
      this.intentEditModeObserver.next(pEditMode);
      this.newUserExpressions = new Array<UserExpression>();
      this.removedUserExpressions = new Array<UserExpression>();
    }

    getAllAgents() {
        return this.agentListObservable;
    }

    getActiveAgent() {
      return this.activeAgentObservable;
    }

    getActiveIntentList() {
      return this.getActiveIntentList;
    }

    getActiveIntent() {
      return this.activeIntentObservable;
    }

    createAgent(pAgent:Agent) {
      this.restService.createAgent(pAgent).subscribe(
            data => {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                //console.log(JSON.stringify(data));
                if(data.statusCode == 0) {
                  this.serverLoadAgents();
                }
            },
            error => {
              console.log(error);
            });
    }

    removeActiveAgent() {
      this.restService.removeAgent(this.activeAgent).subscribe(
            data => {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                //console.log(JSON.stringify(data));
                if(data.statusCode == 0) {
                  this.serverLoadAgents();
                }
            },
            error => {
              console.log(error);
            });
    }

    createIntent(pIntent:Intent) {
      pIntent.agentId = this.activeAgent.agentId;
      this.restService.createIntent(pIntent).subscribe(
            data => {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                console.log(JSON.stringify(data));
                if(data.statusCode == 0) {
                  this.getIntentsByAgentFromServer(this.activeAgent);
                  //this.serverLoadAgents();
                  //console.log("Intent Created");
                }
            },
            error => {
              console.log("Intent creation failed : " + error);
            });
    }

    removeActiveIntent() {
      this.restService.removeIntent(this.activeIntent).subscribe(
            data => {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                //console.log(JSON.stringify(data));
                if(data.statusCode == 0) {
                  this.updateActiveAgent(this.activeAgent);
                }
            },
            error => {
              console.log(error);
            });
    }

    addUserExpression(pUserExpressionString:string) {
      // console.log("inside addUserExpression in aiAssistCacheService");
      // console.log(pUserExpressionString);
      let userExpression : UserExpression = new UserExpression();
      let existingUserExpression = this.activeUserExpressions.filter((userExpression:UserExpression) => userExpression.expression === pUserExpressionString.trim() );

      if(existingUserExpression != null && existingUserExpression.length > 0)
        return false;
      userExpression.expression = pUserExpressionString.trim();
      userExpression.intentId = this.activeIntent.intentId;
      this.activeUserExpressions.unshift(userExpression);
      this.activeUserExpressionsObserver.next(this.activeUserExpressions);
      this.newUserExpressions.push(userExpression);
      console.log("inside addUserExpression in aiAssistCacheService");
      console.log(JSON.stringify(this.newUserExpressions));
      return true;
    }

    removeUserExpression(pUserExpression : UserExpression) {
      var index = this.activeUserExpressions.indexOf(pUserExpression);
      if(index > -1) {
        this.activeUserExpressions.splice(index,1);
        if(pUserExpression.userExpressionId == null) {
          var indexNewExpression = this.newUserExpressions.indexOf(pUserExpression);
          if(indexNewExpression > -1) {
            this.newUserExpressions.splice(indexNewExpression,1);
          }
        } else {
          this.removedUserExpressions.push(pUserExpression);
        }
      }
      this.activeUserExpressionsObserver.next(this.activeUserExpressions)
    }

    removeUserExpressionById(pExpressionId : string) {
        var userExpressionToRemove = this.activeUserExpressions.filter((userExpression:UserExpression) => userExpression.userExpressionId === pExpressionId );
        var index = this.activeUserExpressions.indexOf(userExpressionToRemove[0]);
        this.removeUserExpressionByIndex(index);
    }

    removeUserExpressionByIndex(pElementIndex : number) {
        if(pElementIndex != null && pElementIndex >=0 && pElementIndex < this.activeUserExpressions.length)
            this.activeUserExpressions.splice(pElementIndex, 1);
    }

    saveEditChanges(pActiveIntentName:string) {

      if(this.newUserExpressions.length > 0) {
        this.restService.createUserExpressions(this.newUserExpressions).subscribe(
              data => {
                  // set success message and pass true paramater to persist the message after redirecting to the login page
                  //console.log(JSON.stringify(data));
                  if(data.statusCode == 0) {
                    this.getIntentByIdFromServer(this.activeIntent);
                  }
              },
              error => {
                console.log(error);
              });
      }

      if(this.removedUserExpressions.length > 0) {
        this.restService.deleteUserExpressions(this.removedUserExpressions).subscribe(
              data => {
                  // set success message and pass true paramater to persist the message after redirecting to the login page
                  //console.log(JSON.stringify(data));
                  if(data.statusCode == 0) {
                    this.getIntentByIdFromServer(this.activeIntent);
                  }
              },
              error => {
                console.log(error);
              });
      }

      if (pActiveIntentName != null) {
        this.activeIntent.name = pActiveIntentName;
        //this.restService.
      }
      this.setIntentEdit(false);
    }

    private handleError (error: Response | any) {
         // In a real world app, we might use a remote logging infrastructure
         let errMsg: string;
         if (error instanceof Response) {
             const body = error.json() || '';
             const err = body.error || JSON.stringify(body);
             errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
         } else {
             errMsg = error.message ? error.message : error.toString();
         }
         console.error(errMsg);
         return Observable.throw(errMsg);
     }

}
