/**
 * @ngdoc property
 * @name ekycTerminationController
 * @requires $scope
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter

function ekycTerminationController($scope) {

}
ekycTerminationController.$inject = ['$scope'];
module.exports = ekycTerminationController;