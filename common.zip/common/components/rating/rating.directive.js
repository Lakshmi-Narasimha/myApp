/**
 * @ngdoc directive
 * @name rating
 * @description
 *
 * - rating component will display the no of stars and rating.
 * 
 *
 **/
 'use strict';

var rating = function() {

	return {
            template: require('./rating.html'),
            restrict: 'E',
            replace: true,
            scope: {  
                noOfStars: '@',
                rating: '@'
            },
            controller:['$scope', function($scope){
                $scope.noOfStarsArray = [];
                for(var i=1;i<=$scope.noOfStars;i++){
                    $scope.noOfStarsArray.push(i);
                }
                
            }]
        };
};

rating.$inject = [];
module.exports = rating;