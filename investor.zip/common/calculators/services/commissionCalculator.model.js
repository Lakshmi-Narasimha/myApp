/**
 * @ngdoc service
 * @name advisor alerts model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Setting the default $cacheFactory options for http call
 *
 */
'use strict';

var commissionCalculatorModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, $cookies,toaster) {
     var _commissionCalculation = null;
    //     _fundDetails = null;
    var commissionCalculatorModel = {
        commissionCalculatorData : function (params,isAdvisor) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.ADVISOR_ALERTS_MODEL + ' | callCommissionCalculatorData' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            console.log(params)

            Restangular.one('/smartsolution/commissionCalculator').customPOST(params, "", {"guId" : $cookies.get("guId")}, {}).then(function (commissionCalculations) {
                deferred.resolve(commissionCalculations);
            }, function (resp) {
                deferred.reject(resp);
                toaster.error(resp.data[0].errorDescription);
                console.log('error');
            });
            return deferred.promise;
        },
        setCommissionCalculations:function(commissioncalculations){
            _commissionCalculation = commissioncalculations;
        },
        getCommissionCalculations:function(){
            if(!angular.isDefined(_commissionCalculation))
            {
                return null;
            }

            return _commissionCalculation;
        }
    };
    return commissionCalculatorModel;
};

commissionCalculatorModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', '$cookies','toaster'];

module.exports = commissionCalculatorModel;