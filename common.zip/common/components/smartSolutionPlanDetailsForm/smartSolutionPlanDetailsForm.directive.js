'use strict';

<<<<<<< HEAD
var smartSolutionPlanDetailsForm = function ($state, recommendedPlanModelService, planSmartSolution, $stateParams) {
=======
var smartSolutionPlanDetailsForm = function ($state, recommendedPlanModelService, planSmartSolution, transactModel) {
>>>>>>> ftic-inv-sprint6
    return {
        template: require('./smartSolutionPlanDetailsForm.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            formParent: "=",
            isBackEnabled: "=?",
            smartSolInv : '@',
            planInputDtls: "=?"
        },
        controller:['$scope', function ($scope) {
            $scope.inflationAdjust ;
            $scope.goalinflationRateError = false;
            $scope.secOptions = [];
            $scope.isPaperless = transactModel.isPaperless;
            $scope.isTransactNow = transactModel.isTransactNowSmartSol;
            //$scope.secOptions = [{title: "Select"}];
            // $scope.defaultInflationRates = "";
            var Obj = {
                "groupId": "InflationRates"
            };
            $scope.inflation = {};
            if($scope.smartSolInv === 'smartSolInvestor'){
                $scope.checkAge = 20;
                $scope.checkGoalAmount = {text:"1,00,000",value:100000};                
              }else{
                $scope.checkAge = 10;
                $scope.checkGoalAmount = {text:"10,000",value:10000};
              }
            planSmartSolution.getInflationRates(Obj)
                .then(function (data) {
                    angular.forEach(data.codeValueList, function (obj,key) {
                        var inflationRate = {title: obj.value};
                        $scope.secOptions.push(inflationRate);
                        
                        /**
                         *  Added code below to pre-populate on click of back from step 2 - #5688 - Investor - Start
                         * */
                        if($stateParams.data) {
                            if(obj.value === $stateParams.data.inflationRate.title) {
                                $scope.inflation.defaultRate = $scope.secOptions[key];
                            }
                        } else if(obj.value === '6') {
                            $scope.inflation.defaultRate = $scope.secOptions[key];
                        }
                        /**
                         *  Added code below to pre-populate on click of back from step 2 - #5688 - Investor - End
                         * */
                    });
                }, function () {

                });

            $scope.isBackEnabled = $scope.isBackEnabled || false;
            if($scope.smartSolInv === 'smartSolInvestor') {
                $scope.ageObject = {
                    key: "age",
                    type: "text",
                    name: "age",
                    min: 0,
                    max:2,
                    maxlength:2,
                    isRequired: true,
                    pattern: /^[0-9]*$/,
                    value: ""
                };
            } else {
                $scope.ageObject = {
                    key: "age",
                    type: "number",
                    name: "age",
                    min: 20,
                    isRequired: true,
                    pattern: /^[0-9]*$/,
                    value: ""
                };
            }
            $scope.investTenureObject = {
                key: "investTenure",
                type: "number",
                name: "investTenure",
                isRequired: true,
                min: 1,
                max: 40,
                pattern: /^[0-9]{1,2}$/,
                value: ""
              };
              $scope.goalAmtTodayObject = {
                key: "goalAmtToday", 
                text: "", 
                type: "number", 
                name: "goalAmtToday", 
                isRequired: true,
<<<<<<< HEAD
                min: $scope.checkGoalAmount.value,
                maxlength: 9,
                //pattern:  /^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{8}$/,
                pattern : /^[0-9]*$/,
=======
                min: 100000,
                max: 999999999,
                pattern:  /^[1-9][0-9]*$/, 
>>>>>>> ftic-inv-sprint6
                value: ""
              };
              /**
               * Added the below code for defect #5310 - Investor - Start
               */
              if(planSmartSolution.getSSInvestAmount()) {
                  $scope.goalAmtTodayObject.value = planSmartSolution.getSSInvestAmount();
                  planSmartSolution.setSSInvestAmount(null);
              }
              /**
               * Added the below code for defect #5310 - Investor - End
               */

              if($stateParams.data) {
                  console.log($stateParams.data);
                  var _prevPlannedData = $stateParams.data;
                  $scope.ageObject.value = _prevPlannedData.age;
                  $scope.investTenureObject.value = _prevPlannedData.investmentTenure;
                  $scope.goalAmtTodayObject.value = _prevPlannedData.goalAmtToday;
              }

              $scope.$on('selectedOption', function (event, data) {
                  $scope.selecetdInflationRate = data.title;

                  if (data.title !== "Select") {
                      $scope.goalinflationRateError = false;
                      if($scope.goalAmtTodayObject.value !=="" && $scope.investTenureObject.value !=="") {
                          loadAdjustedAmount();
                      }
                  }
                  else {
                      $scope.goalinflationRateError = true;
                  }
              });

              $scope.goBack = function () {
                  $scope.$emit('goToBackScreen');
              };

              $scope.investorFormSubmit = function () {
                if ($scope.planInputDtlsForm.$valid && $scope.ageObject.value >= $scope.checkAge) {
                    var investmentAmount = null;
                    if ($scope.goalAmtTodayObject.value !== "") {
                        investmentAmount = $scope.goalAmtTodayObject.value;
                    }
                    else {
                        investmentAmount = $scope.goalAmtEndOfGoalObject.value;
                    }
                    $scope.planInputDetails = {
                        "age": $scope.ageObject.value,
                        "investmentTenure": $scope.investTenureObject.value,
                        "investmentAmount": $scope.inflaValue ? $scope.inflaValue : investmentAmount,
                        "equityPerc": 0,
<<<<<<< HEAD
                        'goalAmtToday': $scope.goalAmtTodayObject.value,
                        'inflationRate': $scope.inflation.defaultRate
=======
                        "investmentAmountActual": $scope.goalAmtTodayObject.value
>>>>>>> ftic-inv-sprint6
                    };
                    recommendedPlanModelService.setPlanInputDtls($scope.planInputDetails);

                    $scope.goalAmountField = false;
                    if ($scope.goalAmtTodayObject.value === "" && $scope.goalAmtEndOfGoalObject.value === "") {
                        $scope.goalAmountField = true;
                    }

                    if ($scope.planInputDtlsForm.$valid && !$scope.goalAmountField) {
                        $scope.$emit('planInputDetailsBtn');
                    }
                    recommendedPlanModelService.setRecommendedFromState($state.current.name);
                }
              };

            $scope.planInputChanged = function () {
                if($scope.smartSolInv === 'smartSolInvestor') {
                    $scope.ageObject.value = $scope.ageObject.value ? parseInt($scope.ageObject.value): '';
                }                
                if($scope.planInputDtlsForm.$valid && $scope.ageObject.value>=20 && ($scope.investTenureObject.value < 41 && $scope.investTenureObject.value > 0)){
                    loadAdjustedAmount();
                }
            };

            function loadAdjustedAmount() {
                $scope.queryObj = {
                    "currentGoalAmt": $scope.goalAmtTodayObject.value,
                    "inflationRate": $scope.selecetdInflationRate,
                    "noOfYears": $scope.investTenureObject.value
                };
                planSmartSolution.getAdjGoalAmt($scope.queryObj)
                    .then(function (data) {
                        $scope.inflaValue = planSmartSolution.replaceComma(data.status);
                        $scope.inflationAdjust = true;
                    }, function () {

                    });
              }
            $scope.back = function(){
                if($scope.isPaperless) {
                    $state.go('paperLess.smartSolution');
                }else if($scope.isTransactNow){
                    $state.go('transactnow.smartSolutions.chooseSmartSol');
                }
            }
            if ($scope.planInputDtls) {
                $scope.ageObject.value = $scope.planInputDtls.age || null;
                $scope.investTenureObject.value = $scope.planInputDtls.investmentTenure || null;
                $scope.goalAmtTodayObject.value = $scope.planInputDtls.investmentAmount || null;
            }
        }]
    };
};
<<<<<<< HEAD
smartSolutionPlanDetailsForm.$inject = ['$state', 'recommendedPlanModelService', 'planSmartSolution', '$stateParams'];
=======
smartSolutionPlanDetailsForm.$inject = ['$state', 'recommendedPlanModelService', 'planSmartSolution', 'transactModel'];
>>>>>>> ftic-inv-sprint6
module.exports = smartSolutionPlanDetailsForm;