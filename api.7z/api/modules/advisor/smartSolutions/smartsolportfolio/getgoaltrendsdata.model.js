// getoverviewdetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GoalTrendsSchema = new mongoose.Schema({
    GoalTrendsObject: {
        type: Array,
        "default": []
    }
});

var GoalTrendsLookUp = mongoose.model('GoalTrendsLookUp', GoalTrendsSchema);

var GoalTrendsModel = new GoalTrendsLookUp({
	"GoalTrendsObject" : {
			  "chartData": {
			    "AUMSAG": [
			      {
			        "goals": "ChildS Education",
			        "aum": "5.47L",
			        "years": "31"
			      },
			      {
			        "goals": "Cash Management",
			        "aum": "5.24L",
			        "years": "28"
			      },
			      {
			        "goals": "Retirement Plan",
			        "aum": "4.1L",
			        "years": "24"
			      },
			      {
			        "goals": "Dream Home",
			        "aum": "3.6L",
			        "years": "20"
			      },
			      {
			        "goals": "Holiday",
			        "aum": "0.6L",
			        "years": "5"
			      },
			      {
			        "goals": "Wealth Creation",
			        "aum": "0.6L",
			        "years": "5"
			      },
			      {
			        "goals": "Tax Planning",
			        "aum": "0.2L",
			        "years": "2"
			      }
			    ],
			    "TotalAUM": "? 19,81,000.00"
			  },
			  "attritionAnalysisObject": [
			    {
			      "purchase": {
			        "year": "2012",
			        "NoOfUnits": "11276552.5690"
			      },
			      "redemption": {
			        "year1": {
			          "key": "2012",
			          "value": "0"
			        },
			        "year2": {
			          "key": "2013",
			          "value": "45.84"
			        },
			        "year3": {
			          "key": "2014",
			          "value": "14.96"
			        },
			        "year4": {
			          "key": "2015",
			          "value": "34.2"
			        },
			        "year5": {
			          "key": "2016",
			          "value": "4.99"
			        },
			        "total": "421"
			      }
			    },
			    {
			      "purchase": {
			        "year": "2013",
			        "NoOfUnits": "13755496.5350"
			      },
			      "redemption": {
			        "year1": {
			          "key": "2012",
			          "value": ""
			        },
			        "year2": {
			          "key": "2013",
			          "value": "0"
			        },
			        "year3": {
			          "key": "2014",
			          "value": "54.34"
			        },
			        "year4": {
			          "key": "2015",
			          "value": "30.87"
			        },
			        "year5": {
			          "key": "2016",
			          "value": "14.79"
			        },
			        "total": "311"
			      }
			    },
			    {
			      "purchase": {
			        "year": "2014",
			        "NoOfUnits": "30995194.2730"
			      },
			      "redemption": {
			        "year1": {
			          "key": "2012",
			          "value": ""
			        },
			        "year2": {
			          "key": "2013",
			          "value": ""
			        },
			        "year3": {
			          "key": "2014",
			          "value": "0"
			        },
			        "year4": {
			          "key": "2015",
			          "value": "64.98"
			        },
			        "year5": {
			          "key": "2016",
			          "value": "35.02"
			        },
			        "total": "317"
			      }
			    },
			    {
			      "purchase": {
			        "year": "2015",
			        "NoOfUnits": "11045489.9660"
			      },
			      "redemption": {
			        "year1": {
			          "key": "2012",
			          "value": ""
			        },
			        "year2": {
			          "key": "2013",
			          "value": ""
			        },
			        "year3": {
			          "key": "2014",
			          "value": ""
			        },
			        "year4": {
			          "key": "2015",
			          "value": "0"
			        },
			        "year5": {
			          "key": "2016",
			          "value": "100"
			        },
			        "total": "105"
			      }
			    },
		    	{
			      "purchase": {
			        "year": "2016",
			        "NoOfUnits": "866942.7880"
			      },
			      "redemption": {
			        "year1": {
			          "key": "2012",
			          "value": ""
			        },
			        "year2": {
			          "key": "2013",
			          "value": ""
			        },
			        "year3": {
			          "key": "2014",
			          "value": ""
			        },
			        "year4": {
			          "key": "2015",
			          "value": ""
			        },
			        "year5": {
			          "key": "2016",
			          "value": "0"
			        },
			        "total": "0"
			      }
			    }
			  ]
			}
		});

GoalTrendsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GoalTrendsLookUp table, please contact admin...');
    } else {
        GoalTrendsLookUp.remove({}, function(err) {
            console.log('GoalTrendsLookUp collection removed');
            GoalTrendsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating GoalTrendsLookUp table, please contact admin...');
                }
                console.log('GoalTrendsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GoalTrendsLookUp;
