(function() {
    'use strict';

    var farmersApp = angular.module('CSS.justPay', ['ngMessages', 'ui.router', 'CSS.billing', 'CSS.components', 'CSS.common'])

    .config(function($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/billing/authentication');
    });

})();
