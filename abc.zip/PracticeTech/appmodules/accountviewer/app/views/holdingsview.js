﻿define(
		[
				"jquery",
				"underscore",
				"backbone",
				'spinner',
				'services/dataservice',
				'appmodules/accountviewer/app/models/accountviewmodel',
				"text!appmodules/accountviewer/app/templates/holdingsbrokerage.html",
				"text!appmodules/accountviewer/app/templates/holdingsannuityinsurance.html",
				'appcommon/analytics',
				'errorLog'],
		function($, _, Backbone, Spinner, Dataservice, Accountviewmodel, holdingsBrokerageTmlp, holdingsAnnuityTmpt, Analytics, ErrorLog) {
			var holdingsview = Backbone.View.extend({
				el : $(".acc-holdings-container"),
				events : {},
				initialize : function(options) {
					this.type = options.type;
				},
				triggerCollapsables: function (targetBtn, targetContainer) {
				    $(targetBtn).toggleClass('collapse-icon');
				    if ($(targetBtn).hasClass('show-acc-details')) {
				        var $this = $("#" + $(targetBtn).data('target'));
				        if ($this.hasClass('hidden-xs')) {
				            $this.removeClass('hidden-xs').slideDown("slow");
				        } else {
				            $this.slideUp("slow", function () { $(this).addClass('hidden-xs'); });
				        }
				    }
				    targetContainer.slideToggle("slow");
		        },
				render: function (accountId, targetBtn, container, adminCd, productCd, isAlternativeAccnt, isAuthorised) {
					try{
						var _that = this;
						isAuthorised = (isAuthorised == undefined) ? true : isAuthorised;
						if(!Accountviewmodel.isHodlingsApplicable(adminCd,productCd)){
							 _that.triggerCollapsables(targetBtn, container);
								return true;
						}
						else if(container.data("loaded") == true){
						    _that.triggerCollapsables(targetBtn, container);
							return true;
						}
						else if(this.type == "brokerage"){
							var tmpTemplate = _.template(holdingsBrokerageTmlp);
							if(!isAuthorised){
								container.html(tmpTemplate({ data: [],authorized:isAuthorised }));
								_that.triggerCollapsables(targetBtn, container);
							}
							else{
								Spinner.show();
								var _serviceCallsStack = [];
								_serviceCallsStack.push(Dataservice.promiseToGetBrokerageHoldings(accountId, [401]));
								_serviceCallsStack.push(Dataservice.promiseToGetBrokerageAccountDetails(accountId, [401]));
								 Q.allSettled(_serviceCallsStack)
								.then(function(results){
								    var authorized = true, _data = [], brokerageHoldings = results[0].value ? results[0].value : results[0].reason/*reason is xhr object*/, brokerageAccntDetails = results[1].value ? results[1].value : results[1].reason;
									if (brokerageHoldings && brokerageHoldings.d) {
									    _data = (brokerageHoldings.d && brokerageHoldings.d.holdingSummaries && brokerageHoldings.d.holdingSummaries.results && brokerageHoldings.d.holdingSummaries.results.length > 0) ? brokerageHoldings.d.holdingSummaries.results : [];
									    authorized = true;
									} else {
									    if (brokerageHoldings.jqXHR && brokerageHoldings.jqXHR.status && brokerageHoldings.jqXHR.status == 401) {
									        authorized = false;
									    } else {
									        _that.logError(brokerageHoldings);
									    }
									}
									if (brokerageAccntDetails && brokerageAccntDetails.d) {
									    var brokerageAccntData = brokerageAccntDetails.d;
									    authorized = true;
									} else {
									    if (brokerageAccntDetails.jqXHR && brokerageAccntDetails.jqXHR.status && brokerageAccntDetails.jqXHR.status == 401) {
									        authorized = false;
									    } else {
									        _that.logError(brokerageAccntDetails);
									    }
									}
									 
									_data = _.filter(_data,function(row){ return (row.hldCatgCd !="002" )});
									container.html(tmpTemplate({ data: _data, authorized: authorized, brokerageAccntDetails: brokerageAccntData, productCd: productCd }));
									container.data("loaded",true);
									_that.triggerCollapsables(targetBtn, container);
									Spinner.hide();
									Analytics.analytics.recordAction('AccountView:BrokerageAccount:HoldingsDisplayedFromAccountList');
								})
								.fail(function(error){
									Spinner.hide();
									ErrorLog.ErrorUtils.myError(error);
								});
							}
							
						}else{
							var tmpTemplate = _.template(holdingsAnnuityTmpt);
							if(!isAuthorised){
								container.html(tmpTemplate({ data: [],authorized:isAuthorised }));
								_that.triggerCollapsables(targetBtn, container);
							}else{
								Spinner.show();
							    Dataservice.promiseToGetAnnuityInsurenceHoldings(accountId, isAlternativeAccnt, [401])
								.then(function(annuityHoldingsResp){
								    var authorized = null, _data = [], _results = annuityHoldingsResp ? annuityHoldingsResp : {};

								    if (annuityHoldingsResp && annuityHoldingsResp.d) {
								        var _data = (annuityHoldingsResp.d.results && annuityHoldingsResp.d.results.length > 0) ? annuityHoldingsResp.d.results : [];
								        authorized = true;
								    }else{
								        if (annuityHoldingsResp.jqXHR && annuityHoldingsResp.jqXHR.status && annuityHoldingsResp.jqXHR.status == 401) {
								            authorized = false;
								        } else {
								            _that.logError(annuityHoldingsResp);
								        }
									}
									
									container.html(tmpTemplate({ data: _data, adminCd: adminCd, authorized:authorized }));
									container.data("loaded",true);
									_that.triggerCollapsables(targetBtn, container);
									Spinner.hide();
								})
								.fail(function(error){
									Spinner.hide();
									ErrorLog.ErrorUtils.myError(error);
								});
							}
							
						}
					}
					catch(err){
						Spinner.hide();
		        		ErrorLog.ErrorUtils.myError(err);
		        	}
					
					
				},
				logError: function (err) {
				    Spinner.hide();
				    ErrorLog.ErrorUtils.myError(err);
				}
			});
			return holdingsview;
		});