'use strict';
describe('Controller: swpController', function() {
	var $controller,$scope,swpController,transactModel;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_transactModel_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();
		
		transactModel = _transactModel_;

		$scope.config = {"txnFormDetails":{}};	
		$scope.header = {"title": ""};
		loadController();			
	}));	

	function loadController(){
        swpController = $controller('SwpController', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(swpController).toBeDefined();
    });

    it('should define the variables config,header',function(){
    	expect($scope.config.txnFormDetails.title).toBe('SWP Details');
    	expect($scope.header.title).toBe('Start a SWP');
    	expect(transactModel.isSWP).toBe(true);
    })
});