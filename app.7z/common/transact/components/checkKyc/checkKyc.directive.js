/**
 * @ngdoc property
 * @name fticCheckKyc Directive
 * @description
 *
 * - This directive is responsible for displaying Joint Holder Window.
 *
 **/

'use strict';

var fticCheckKyc = function(checkKycModelService,checkKycInitialLoader,$timeout, authenticationService, transactEventConstants, transactModel,$state, paperlessModel) {
    return {
            template: require('./checkKyc.html'),
            restrict: 'E',
            replace: true,  
			scope:{
				parentForm:'=',
                groupName:'=',
                formLabel : '@?'
			},
               
            
            controller:['$scope', function($scope){
                $scope.isGuest = transactModel.isPaperless || transactModel.isTransactNowModule;
				$scope.inpObj={
                  text: $scope.formLabel || "PAN / PEKRN or Aadhaar",
                  value: "",
                  message: "",
                  isRequired: true,
                  min:"",
                  name:"panRAadharInput",
                }
                var panParam;
                function checkKycService(userValue){
                    checkKycInitialLoader.loadAllServices($scope,panParam);
                    var listnerHandler = $scope.$on(transactEventConstants.transact.Check_Kyc,function(data){
                        $scope.kycStatus =  checkKycModelService.getCheckKycDtls();

                        $scope.kycStatus.userEnteredPan = (panParam.panNo).toUpperCase();
                        $scope.kycStatus.appPanNo = $scope.kycStatus.userEnteredPan;
                        /*EKYC-CR*/
                        transactModel.checkRegistrationMode($scope.kycStatus.kycMode);

                        if((panParam.panNo) ===transactModel.kycNotRegPan || (transactModel.getrawHolderDts() && (panParam.panNo) === transactModel.getrawHolderDts()[0].pan) && !transactModel.isPaperless){
                            $scope.adHlder = true;
                            listnerHandler();
                            return;
                        }
                        else {
                            $scope.successCall(userValue);
                            listnerHandler();
                        }
                    });
                }
				$scope.checkKyc=function(userValue){
                    paperlessModel.insKyc.hasData = false;
					$scope.validateFlag = true;
                    $scope.adHlder = false;
                    var isPanRAadhar = $scope.validatePattern(userValue);
                    
                    if ($scope.parentForm.panRAadharInput.$valid) {
                        //if(isPanRAadhar == "pan"){
                            panParam = {
                                "panNo" : userValue.toUpperCase(),
                                "guId" : authenticationService.getUser().guId
                            }
                            if (transactModel.isPaperless) {
                                if (paperlessModel.invDetails.getFirstHolderDetails() && paperlessModel.invDetails.getFirstHolderDetails().appPanNo == panParam.panNo) {
                                    $scope.adHlder = true;
                                }else if(paperlessModel.invDetails.getHolderDetails()){
                                    angular.forEach(paperlessModel.invDetails.getHolderDetails(), function(obj, key){
                                        if (obj.appPanNo == panParam.panNo) {
                                            $scope.adHlder = true;
                                        }else{
                                            checkKycService(userValue);
                                        }
                                    });
                                }else{
                                    checkKycService(userValue);
                                }
                            }else{
                                checkKycService(userValue);
                            }
                            
                        //}commenting this because phani said he will provide aadhar validation through validateKyc service.
                        /*else if(isPanRAadhar == "aadhar"){
                            var aadharParam = {
                                "folioPanAccNo" : userValue,
                                "folioPanFlag" :"A",
                                "guId" : authenticationService.getUser().guId
                            }   
                            checkKycModelService.validateFolio(aadharParam).then(validateFolioSuccess, validateFolioFailure);
                            function validateFolioSuccess(data) {
                                $scope.successCall(data);
                            }
                            function validateFolioFailure(data) {
                                console.log('handleFailure');
                            }
                        }*/
                        //}
                    }  
				}, 
				
				
				$scope.serviceKyc = function(userValue){
                    $scope.ftDbObj =  checkKycModelService.getCheckKycDtls(userValue);
                    return $scope.ftDbObj
                },
				
				
				$scope.validatePattern = function(data){
                    var patt1 = /^([a-zA-Z]{5})(\d{4})([a-zA-Z]{1})$/ ;
                    var patt2 = /^\d{12}$/; 
                    if($scope.isGuest && patt1.test(data)){
                        $scope.parentForm.panRAadharInput.$valid = true;
                        $scope.parentForm.panRAadharInput.$invalid = false;
                        return "pan";
                    }else if ((patt1.test(data) || patt2.test(data)) && !$scope.isGuest) {
                        $scope.parentForm.panRAadharInput.$valid = true;
                        $scope.parentForm.panRAadharInput.$invalid = false;
                        if($scope.isPan && patt1.test(data)){
                            $scope.isPan = !$scope.isPan
                        }
                        else if($scope.isAadhar && patt2.test(data)){
                            $scope.isAadhar = !$scope.isAadhar
                        }
                        return patt1.test(data) ? "pan" :"aadhar";
                    }
                    else{
                        $scope.parentForm.panRAadharInput.$valid = false;
                        $scope.parentForm.panRAadharInput.$invalid = true;
                        $scope.parentForm.$valid = false;
                        $scope.parentForm.$invalid = true;
                    }
                }
                $scope.successCall = function(userValue){
                    if($scope.isGuest || $state.current.url === '/trnsctNowNewFolio'){
                        transactModel.kycNotRegPan = userValue;
                        $scope.$emit("holderDtls", $scope.kycStatus);
                        return;
                    }
                    if (($scope.kycStatus.kycSource || !!$scope.kycStatus.kycSource.trim()) && $scope.kycStatus.kycSource !== 'Not available' && $scope.kycStatus.kycSource !== 'Not Checked with respective KRA') {
                        $scope.isPan = false;
                        $scope.isAadhar = false;
                        $scope.addJoint = false;
                        $scope.validateFlag = false;
                        transactModel.kycNotRegPan = userValue;
                        $scope.$emit("holderDtls", $scope.kycStatus);
                    }   
                    else if (!$scope.kycStatus.kycSource.trim() || $scope.kycStatus.kycSource === 'Not available' || $scope.kycStatus.kycSource === 'Not Checked with respective KRA') {
                        debugger  
                        if (!$scope.isPan && !$scope.isAadhar) {
                            $scope.showPopup = true; 
                            $scope.popval = userValue.length==10?"Pan":"Aadhar";
                            $scope.popupText = $scope.popval=="Pan"?"No Record found using PAN please try searching Aadhaar":"No Record found using Aadhaar please try searching PAN";
                            $scope.yesText = "ok";
                            $scope.noTxt = "";
                            $timeout(function(){$scope.showPopup = true;},0) 
                            $scope.$on("yes",function(event){
                               debugger  
                              //$scope.showPopup = false; 
                              //event.stopPropagation();
                            });
                        }
                        (userValue.length == 10)?$scope.isPan = true:$scope.isAadhar = true;
                        if ($scope.isPan && $scope.isAadhar) {
                            $scope.isPan = false;
                            $scope.isAadhar = false;
                            $scope.addJoint = false;
                            $scope.validateFlag = false;
                            transactModel.kycNotRegPan = userValue;
                            $scope.$emit('kycregstion',$scope.groupName);
                            
                        }
                    }
                    userValue="";
                }
			}]
        };
};

fticCheckKyc.$inject = ['checkKycModelService','checkKycInitialLoader','$timeout', 'authenticationService', 'transactEventConstants', 'transactModel', '$state', 'paperlessModel'];
module.exports = fticCheckKyc;
