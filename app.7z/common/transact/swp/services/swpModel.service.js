

'use strict';

var swpModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, transactModel, authenticationService, fundDetailsModel, ifscModel, TransactConstant, swpReviewDetailsFactory) {
    var _swpDetails = null;
    var _selectedObj = null;

    var swpModel = {        
        
        fetchSwpDetails : function () {
            
            var deferred = $q.defer();
            Restangular.all('/swp').getList().then(function (swp) {
                deferred.resolve(swp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        // setReviewSwpDetails : function(selectedObj){
        //     _selectedObj = selectedObj;            
        // },

        // getReviewSwpDetails : function() {
        //     return _selectedObj;
        // },
        
        getSwpDetails: function() {
            return _swpDetails;
        },
        
        setSwpDetails: function(swpDetails) {
            _swpDetails = swpDetails;
        },

        validateSWP : function(){
             
            var deferred = $q.defer();
            var params = {};
            var body = {};
            var SWPselectedType = "";
            body.amount = "";
            body.folioId = transactModel.getTransactDetails().investorDetails.folioId;
            //body.amount = transactModel.getTransactDetails().swpDetails.selectedType.toString();
            SWPselectedType = transactModel.getTransactDetails().swpDetails.selectedType.toString();
            //console.log(SWPselectedType);
            if(SWPselectedType === 'capital'){

                /*var intAmount = Math.round((fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits) * 100) / 100;
                var stringAmount =  intAmount.toString();               
                body.amount = stringAmount;*/            
                //body.amount = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[1].substring(0, 2);
                body.amount = "";
                body.allUnitsFlag = 'Y';
                body.amountUnitFlag = "C";
            }else{
                body.amount = transactModel.getTransactDetails().swpDetails.swpAmtValue.toString();
                body.allUnitsFlag = 'P';
                body.amountUnitFlag = "A";
            }
            if(transactModel.getTransactDetails().swpDetails.selectedMode === "cheque"){
                body.ifscCode = '';
            }else if(transactModel.getTransactDetails().swpDetails.selectedMode === "direct-credit"){
                body.ifscCode = ifscModel.getIfscGridResDet().ifscCode;
            }
            body.units = "";
            body.txnSource = 'SWP';
            body.txnType = 'SWP';
            body.batchCode = TransactConstant.common.BATCH_CODE;
            body.fundOption = transactModel.getTransactDetails().fundDetails.tschvalAccno.substring(0,3);
            body.accountNo = transactModel.getTransactDetails().fundDetails.tschvalAccno;
            var startDate;
            var _swpTransactDetails = transactModel.getTransactDetails().swpDetails;
            if(authenticationService.isInvestorLoggedIn()) {

                startDate = swpReviewDetailsFactory.getExactSelectedDate( _swpTransactDetails.freqStartDaySelected, _swpTransactDetails.startMonth, true);
            } else {
                startDate = new Date(_swpTransactDetails.startDate);
            }
            var _isSLbd = startDate.toString().split('/')[0].toLowerCase() === 'lbd' ? true: false;
            if(!_isSLbd) {
                var dd = startDate.getDate();
                var mm = startDate.getMonth()+1; //January is 0!
                var yyyy = startDate.getFullYear();
                if(dd<10){
                    dd='0'+dd;
                } 
                if(mm<10){
                    mm='0'+mm;
                } 
                startDate = dd+'/'+mm+'/'+yyyy;
            }
            body.startDate = startDate;
            var endDate;
            if(authenticationService.isInvestorLoggedIn()) {

                endDate = swpReviewDetailsFactory.getExactSelectedDate(_swpTransactDetails.freqEndDaySelected, _swpTransactDetails.endMonth, true);
            } else {
                endDate = new Date(transactModel.getTransactDetails().swpDetails.endDate);
            }
            var _isELbd = endDate.toString().split('/')[0].toLowerCase() === 'lbd' ? true: false;
            if(!_isELbd) {
                var dd = endDate.getDate();
                var mm = endDate.getMonth()+1; //January is 0!
                var yyyy = endDate.getFullYear();
                if(dd<10){
                    dd='0'+dd;
                } 
                if(mm<10){
                    mm='0'+mm;
                } 
                endDate = dd+'/'+mm+'/'+yyyy;
            }
            body.endDate =  endDate;
            
            if(transactModel.getTransactDetails().swpDetails.frequency === 'Weekly' || transactModel.getTransactDetails().swpDetails.frequency === 'WEEKLY'){
                body.frequency = 'W';
            }else if(transactModel.getTransactDetails().swpDetails.frequency === 'Monthly' || transactModel.getTransactDetails().swpDetails.frequency === 'MONTHLY'){
                //body.frequency = 'M';
                body.frequency = 'M';
            }else if(transactModel.getTransactDetails().swpDetails.frequency === 'Daily' || transactModel.getTransactDetails().swpDetails.frequency === 'DAILY'){
                body.frequency = 'D';
            }else if(transactModel.getTransactDetails().swpDetails.frequency === 'Quarterly' || transactModel.getTransactDetails().swpDetails.frequency === 'QUARTERLY'){
                body.frequency = 'Q';
            }else if(transactModel.getTransactDetails().swpDetails.frequency === 'Annually' || transactModel.getTransactDetails().swpDetails.frequency === 'ANNUALLY'){
                body.frequency = 'A';
            }
            
            body.investmentGoalFlag = '';
            body.urnNo = '';
            body.lbdFlag = _isELbd ? 'Y' : 'N';
            body.source = authenticationService.getUser().userType;
            body.umrnNo = '';
            body.subBrokerARN = '';
            body.branchCode = '';
            body.installments = transactModel.getTransactDetails().swpDetails.noofInstallments;
            params.guId = authenticationService.getUser().guId;
            Restangular.one('transact/validateSwp').customPOST(body, "", params, {}).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        }

    };
    return swpModel;
};

swpModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'transactModel', 'authenticationService', 'fundDetailsModel', 'ifscModel', 'TransactConstant', 'swpReviewDetailsFactory'];

module.exports = swpModel;