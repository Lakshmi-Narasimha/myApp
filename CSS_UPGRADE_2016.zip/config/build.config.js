(function() {

  'use strict';

  //basic configuration object used by grunt tasks
  module.exports = {
    port: 3000,
    tmp: 'temp',
    dist: 'dist',
    app: 'src',
    tpl: 'src/modules/**/*.html',
    mainScss: 'src/app.scss',
    scss: 'src/**/*.scss',
    scripts: [
      'src/modules/**/*.js',
      '!src/vendor/**/*.js',
      'src/**/*-spec.js', //unit
      'src/test/e2e/**/*.js' //e2e
    ],
    index: 'src/index.html',
    assets: 'src/assets/**',
    images: 'src/assets/style/images',
    font: 'src/assets/style/fonts'
  };

})();
