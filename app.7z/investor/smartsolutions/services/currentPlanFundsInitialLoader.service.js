'use strict';

var currentPlanFundsInitalLoaderService = function (currentPlanFundsService, investorEvents) {

    var currentPlanFundsInitalLoader = {
        _isServicesData: false,
        loadAllServices : function (scope, params) {

            currentPlanFundsService.fetchCurrentPlanFunds(params)
                .then(goalInvestorSuccess, handleFailure);

            function goalInvestorSuccess(data) {
                console.log(data);
                currentPlanFundsService.setCurrentPlanFunds(data.fsGoalDetails);
                currentPlanFundsService.setGoalChartDetails(data.goalChart);
                investorEvents.smartSolutions.publishCurrentGoalchart(scope);
                investorEvents.smartSolutions.publishCurrentPlanFunds(scope,currentPlanFundsService.getCurrentPlanFunds());

            }

            function handleFailure(data){
                console.error('handleFailure');
                currentPlanFundsInitalLoader._isServicesData = false;
            }
        }

    };
    return currentPlanFundsInitalLoader;
};

currentPlanFundsInitalLoaderService.$inject = ['currentPlanFundsService', 'investorEvents'];

module.exports = currentPlanFundsInitalLoaderService;