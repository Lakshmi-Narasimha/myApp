/**
 * @ngdoc property
 * @name sipDetailsReviewController
 * @requires $scope
 * @requires stpDetailsModel
 * @requires $filter
 * @requires eventConstants
 * @description
 *
 * - It gets the data from stpDetailsModel and binds the data. 
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function sipDetailsReviewController($scope, $state, eventConstants, bankDtlsModel, $filter, TransactConstant, authenticationService) {
	var translateFilter = $filter('translate');
	
    if(!authenticationService.isInvestorLoggedIn()) {
        $scope.config.toTxnDetailsState = "transact.txnDetails.sip";
        $scope.config.toState = "transact.base.sip";
        $scope.config.fromState = $state.current.name;
    }else {
        $scope.config.toTxnDetailsState = "invTransact.txnDetails.sip";
        $scope.config.toState = "invTransact.base.sip";
        $scope.config.fromState = $state.current.name;
    }
    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){  
        $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'PaymentDetails'});                                                
    }); 
    if(!authenticationService.isInvestorLoggedIn()) {
      	$scope.paymentDetails = [
            {
                text: "Bank Details",
                value: bankDtlsModel.getSelectedBank()
            },
            {
                text: "Mode of Payment",
                value: bankDtlsModel.getPaymentMethod()
            },
            {
                text: "Total Investment Amount",
                value: bankDtlsModel.getTotalAmount()
            }
        ];
    }else {
        $scope.paymentDetails = [
            {
                text: "Mode of Payment",
                value: bankDtlsModel.getPaymentMethod()
            },
            {
                text: "Bank Details",
                value: bankDtlsModel.getSelectedBank()
            },
            {
                text: "Total Investment Amount",
                value: "<span class='icon-fti_rupee'></span>"+bankDtlsModel.getTotalAmount()
            }
        ];
    }
		
}

sipDetailsReviewController.$inject = ['$scope', '$state', 'eventConstants', 'bankDtlsModel', '$filter', 'TransactConstant', 'authenticationService'];
module.exports = sipDetailsReviewController;