/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var cgAccDetModel= function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, unitHolderModel) {
    var _cgaccdet = null,
        _cgfolio = null,
        _cgUnitDetails = null,
        _cgAcUnitDetails = null,
        _folioNumbersList = null,
        _folioNumber = null,
        _cgFolioDet = null,
        _cgCgFolioUnitDetails = null;
	var cgAccDetModel = {
        fetchcgaccountdetails : function (params) {
            params.flag = 'A';
            params.guId = authenticationService.getUser().guId;
            var deferred = $q.defer();
            Restangular.one('clients/capitalGain').get(params).then(function (advisorDetails) {
                deferred.resolve(advisorDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        fetchCgFolioDetails : function (params) {
            params.flag = 'F';
            params.guId = authenticationService.getUser().guId;
            var deferred = $q.defer();
            Restangular.one('clients/capitalGain').get(params).then(function (advisorDetails) {
                deferred.resolve(advisorDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
         
        setcgaccountdetails : function (advisorDetails) {
            
            _cgaccdet = advisorDetails;
        },
        getcgaccountdetails : function () {
            if (!angular.isDefined(_cgaccdet)) {
                return null;
            }
            return _cgaccdet;
        },
        setCgFoliodetails : function (advisorDetails) {
            
            _cgFolioDet = advisorDetails;
        },
        getCgFoliodetails : function () {
            if (!angular.isDefined(_cgFolioDet)) {
                return null;
            }
            return _cgFolioDet;
        },
        setcapitalgainsfoliodetails : function (advisorDetails) {
            _cgfolio = advisorDetails;
        },
        getcapitalgainsfoliodetails : function () {
            if (!angular.isDefined(_cgfolio)) {
                return null;
            }
            return _cgfolio;
        },
        
        setCapitalGainsUnitHolder : function (folioDetails) {
            _cgUnitDetails = folioDetails.unitHolderDetails;
        },
        getCapitalGainsUnitHolder : function () {
            if (!angular.isDefined(_cgUnitDetails)) {
                return null;
            }
            return _cgUnitDetails;
        },
        
        setcgaccountdetunitholder : function (accDetails) {
            console.log('holder details');
            console.log(accDetails.unitHolderDetails);
            _cgAcUnitDetails = accDetails.unitHolderDetails;
        },
        getcgaccountdetunitholder : function () {
            if (!angular.isDefined(_cgAcUnitDetails)) {
                return null;
            }
            return _cgAcUnitDetails;
        },
        setCgFolioDetUnitholder : function (accDetails) {
            _cgCgFolioUnitDetails = accDetails.unitHolderDetails;
        },
        getCgFolioDetUnitholder : function () {
            if (!angular.isDefined(_cgCgFolioUnitDetails)) {
                return null;
            }
            return _cgCgFolioUnitDetails;
        },
        setAccFolioNumber:function (folioNumber) {
            _folioNumber = folioNumber;
        },
        getAccFolioNumber : function () {
            if (!angular.isDefined(_folioNumber)) {
                return null;
            }
            return _folioNumber;
        },
        getFolioAccountDetails: function() {
            var deferred = $q.defer();
            var params = {};                   
            params.guId = authenticationService.getUser().guId;
            params.flag = 'P';
            Restangular.one('clients/folioAccounts').get(params).then(function(response) {  

                deferred.resolve(response);             
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setFolioNumbersList : function (folioNumbersList) {
            _folioNumbersList = folioNumbersList;
        },
        getFolioNumbersList : function () {
            if (!angular.isDefined(_folioNumbersList)) {
                return null;
            }
            return _folioNumbersList;
        }
    };
    return cgAccDetModel;
};

cgAccDetModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', 'unitHolderModel'];
module.exports = cgAccDetModel;
