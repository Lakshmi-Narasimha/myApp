'use strict';
// Controller naming conventions should start with an uppercase letter
function KycConfirmController($scope, TransactConstant,$state,$uibModalStack) {
	
	$scope.popUpText1='Please complete KYC registration of all the holders to proceed with thetransaction';
                    $scope.cancelBtnTxt='cancel';
                    $scope.continueBtnTxt='continue with KYC';
	
                    $scope.yes = function() {
                        //$scope.yesEventName = $scope.yesEventName ? $scope.yesEventName :'yes';
                       // $scope.$emit($scope.yesEventName || 'yes');
                       $uibModalStack.dismissAll();
                    };

                    $scope.no = function() {
                        //$scope.noEventName = $scope.noEventName ? $scope.noEventName : 'no';
                        //$scope.$emit($scope.noEventName || 'no');
                      $uibModalStack.dismissAll();
                    };

}

KycConfirmController.$inject = ['$scope', 'TransactConstant','$state','$uibModalStack'];
module.exports = KycConfirmController;