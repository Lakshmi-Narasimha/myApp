import { Component, OnInit } from '@angular/core';
import { AIAssistCacheService } from '../_services/aiassistcache.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private cacheService : AIAssistCacheService) { }

  ngOnInit() {
    this.loadAllAgents();
  }

  private loadAllAgents() {
      this.cacheService.serverLoadAgents();
  }

}
