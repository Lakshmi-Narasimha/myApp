'use strict';
function smartSolsmodifyCtrl($scope, $state, recommendedPlanInitialLoader, recommendedPlanModelService, advisorEventConstants, $uibModal, overviewModel, smartSolnFundDetailsInitialLoader, buildPlanInitialLoader, buildPlanModelService, $uibModalStack, currentPlanFundsService, investorGoalModelService, planSmartSolution) {

    $scope.fundObject = [
        {
            key: "firstFund",
            text: "",
            name: "firstFund",
            type: "number",
            isRequired: true,
            pattern: /^[0-9]/,
            maxlength: 6,
            value: ""
        },
        {
            key: "secondFund",
            text: "",
            name: "secondFund",
            type: "number",
            isRequired: true,
            pattern: /^[0-9]/,
            maxlength: 6,
            value: ""
        },
        {
            key: "thirdFund",
            text: "",
            name: "thirdFund",
            type: "number",
            isRequired: true,
            pattern: /^[0-9]/,
            maxlength: 6,
            value: ""
        },
        {
            key: "fourthFund",
            text: "",
            name: "fourthFund",
            type: "number",
            isRequired: true,
            pattern: /^[0-9]/,
            maxlength: 6,
            value: ""
        },
        {
            key: "fifthFund",
            text: "",
            name: "fifthFund",
            type: "number",
            isRequired: true,
            pattern: /^[0-9]/,
            maxlength: 6,
            value: ""
        }
    ];


    $scope.selectfund = [];

    // TODO - Need to Check previous state for edit funds
    var planInputObj = {};
    $scope.init = function () {
        $scope.keyValueList = overviewModel.getHolderInformation();
        $scope.fundDetails = angular.copy(currentPlanFundsService.getCurrentPlanFunds()) ;
        var goalSummary = angular.copy(investorGoalModelService.getSelectedGoalData());
        planInputObj = {
            "age": "",
            "investmentTenure": 4,//goalSummary.pendingTimeFrame,
            "investmentAmount": goalSummary.targetAmount - ((goalSummary.achieved.split("%")[0] * goalSummary.targetAmount) /100),
            "equityPerc": 0
        };
        planInputObj.myFunds = [];
        angular.forEach(angular.copy(currentPlanFundsService.getCurrentPlanFunds()), function (fund, ind) {
            var fundList = {};
            fundList.fundCode = "002";//fund.fundOption;
            fundList.allocPer = 50;
            planInputObj.myFunds.push(fundList);
        });
        getSmartSolutionDetails(planInputObj);
    };

    $scope.init();


    //recommendedPlanInitialLoader.loadAllServices($scope);
    $scope.initializeDetails = function () {
        if (planSmartSolution.getSmartSolutionDetails()) {
            $scope.smartSolnDetials = planSmartSolution.getSmartSolutionDetails();
            //$scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
            //$scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
            //$scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
            for (var fund = 0, len = $scope.fundDetails.length; fund < len; fund++) {
                $scope.selectfund.push({"fundName": $scope.fundDetails[fund].funddesc, "value": fund + "fund"});
                $scope.fundObject[fund].value = (parseInt($scope.smartSolnDetials.monthlySIP.replace(',', ""))*planInputObj.myFunds[fund].allocPer)/100;
            }
            ;
            $scope.selectfund.push(
                {"fundName": "Select Fund", "value": $scope.fundDetails.length + 1 + "fund"},
                {"fundName": "Select Fund", "value": $scope.fundDetails.length + 2 + "fund"},
                {"fundName": "Select Fund", "value": $scope.fundDetails.length + 3 + "fund"}
            );
        }

    };

    /*if (buildPlanModelService.isFromModifyApply) {
        $scope.fundDetails = buildPlanModelService.getFundDetails();
        $scope.fundsValues = buildPlanModelService.getAllocationDetails();
        for (var fund = 0, len = $scope.fundDetails.length; fund < len; fund++) {
            $scope.selectfund.push({"fundName": $scope.fundDetails[fund].fundName, "value": fund + "fund"});
            $scope.fundObject[fund].value = (parseInt($scope.smartSolnDetials.monthlySIP.replace(',', ""))*planInputObj.myfunds[i].allocper)/100;
        }
        ;
        if ($scope.selectfund.length < 5) {
            for (var i = 1, j = 5 - $scope.selectfund.length; i <= j; i++) {
                $scope.selectfund.push({"fundName": "Select Fund", "value": $scope.selectfund.length + i + "fund"});
            }
        }
        console.log($scope.selectfund);
    }
    else {
        $scope.initializeDetails();
    };*/

    $scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function ($event) {
        if (!buildPlanModelService.isFromModifyApply) {
            $scope.initializeDetails();
        }
        ;

        $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
    });


    //buildPlanInitialLoader.loadAllServices($scope);
    var modalInstance;
    $scope.indexOfFund = null;
    $scope.selectFund = function ($index) {
        $scope.indexOfFund = $index;
        modalInstance = $uibModal.open({
            template: require('../../../../../common/components/newFundsModal/newFundsModal.html'),
            scope: $scope
        });
    };

    $scope.closeModal = function () {
        $uibModalStack.dismissAll();
    };

    //$scope.fundDetails = [];
    $scope.$on('singleSelectionDone', function (event, obj) {
        $scope.selectfund[$scope.indexOfFund].fundName = obj.selectedOne.fundName;
        $scope.fundDetails[$scope.indexOfFund] = obj.selectedOne;
        $scope.closeModal();
        // buildPlanModelService.setFundDetails($scope.fundDetails);
    });


    $scope.goBack = function () {
        $state.go('smartSol.investor.currentPlan');
    };

    $scope.goalsheetBtn = function () {
        $state.go('smartSol.investor.topupwithsf.topupwithsamefundsgoalsheet');
    };

    $scope.apply = function () {
        var allocation = [], fund = [];
        $scope.showSumError = false;
        for (var i = 0; i < $scope.fundObject.length; i++) {
            if ($scope.fundObject[i].value !== "") {
                allocation.push($scope.fundObject[i].value);
            }
            if ($scope.selectfund[i].fundName !== "Select Fund") {
                fund.push($scope.selectfund[i])
            }
        }
        ;
        console.log(fund, allocation.length);
        if (fund.length == allocation.length) {
            $state.go('smartSol.investor.modifymain.modifyapply');
        }
        else {
            console.log("ERROR FOR FUND SELECTION");
        }
        buildPlanModelService.setAllocationDetails(allocation);
        buildPlanModelService.setFundDetails(fund);
        // if($scope.buildMyPlan.$valid && !$scope.showSumError){

        // $scope.$broadcast('goBuildMyPlanCntrl');
        // };
        // $state.go('smartSol.investor.modifymain.modifyapply');
    };

    function getSmartSolutionDetails (planInputObj) {

        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "BP", true).then(function (data) {
            planSmartSolution.setSmartSolutionDetails(data);
            $scope.initializeDetails();
        }, function (data) {
            console.log("Error")
        })
    };
}

smartSolsmodifyCtrl.$inject = ['$scope', '$state', 'recommendedPlanInitialLoader', 'recommendedPlanModelService', 'advisorEventConstants', '$uibModal', 'overviewModel', 'smartSolnFundDetailsInitialLoader', 'buildPlanInitialLoader', 'buildPlanModelService', '$uibModalStack', 'currentPlanFundsService', 'investorGoalModelService', 'planSmartSolution'];
module.exports = smartSolsmodifyCtrl;