var express = require('express');
var https = require('https');
var querystring = require('querystring');

var router = express.Router();
var dataPassModel = require('./dataPass.model');
var engagementModel = require('../engagement/engagement.model');

// api route
router.route('/mfchat/rest/dataPassForSales')
    .post(function(req, res) {
        req.uri = dataPassModel.createRequestUri;
        console.log("requestURI:", req.uri);
        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": req.session.agentID,
            "Role": req.body.RequestParams.accRole,
            "Mobile Number": req.body.RequestParams.MDN,
            "Greeting Name": req.body.RequestParams.nickName
        };
        var postBody = querystring.stringify(post_data);
        console.log(postBody);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'POST',
                path: req.uri.path,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Cookie': req.sessionCookie,
                    'Content-Length': Buffer.byteLength(postBody)
                },
                rejectUnauthorized: true
            },

            function(proxyResponse){
                console.log("statusCode: ", proxyResponse.statusCode);
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                    res.status(200).end();
                } else {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {

                });
            });

        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
