﻿define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appcommon/analytics',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'errorLog',
    'text!appmodules/contactprofile/app/templates/contactbeneficiary.html', 'appcommon/globalcontext', "config", 'appmodules/contactprofile/app/models/cpviewmodel',
    'appcommon/applauncher/device',
    'appcommon/commonutility',
], function ($, _, Backbone, Spinner, Analytics, cpCommon, Dataservice, ErrorLog, beneficiaryTemplate, GlobalContext, Config, CPViewModel, Device, CommonUtility) {
    var self = null, brkgProdClsCds = CommonUtility.getBrkgProdClsCds();
      var beneficiaryView = Backbone.View.extend({
        template: _.template(beneficiaryTemplate),
        el: $("#cp-content-container"),
        id: 'cp-content-container',
        events: {
        },
        initialize: function () {
            self = this;
            $(document).off("keydown").on("keydown", function (e) {
            	self.analyticsEbenePrint(e);
            });
            $(document).off('click', '#benfcry-page-ebene-link').on('click', '#benfcry-page-ebene-link', this.invokeEbeneWorkflowLinkClick);
            $(document).off('click', ".spelling-correction-link").on('click', ".spelling-correction-link", function (event) {
                var tempId = $(this).data("account-id")               
                self.invokeSpellingCorrectionClick(tempId);
            });
            window.onafterprint = function () {
            	if (window.location.hash === '#contactprofile/beneficiary') {
            		Analytics.analytics.recordAction('Print:BeneficiaryTab');
            	}
            };            
        },
       analyticsEbenePrint: function (e) {
       	if (window.location.hash === '#contactprofile/beneficiary' && (window.chrome)) {
        		if (e.ctrlKey && e.keyCode == 80) {
        			Analytics.analytics.recordAction('Print:Beneficiary');
        		}
        	}
        },
        toggleBeneficiary: function (e) {
            var target = e.target || e.currentTarget;
            var data = $(target).data("target");
            var collapsable = $("#" + data);
            if (collapsable.css('display') === 'none') {
                collapsable.slideDown(250);
                $(target).removeClass("closed");
            } else {
                collapsable.slideUp(250);
                $(target).addClass("closed");
            }
        },
        Beneficiarylist: {
            list: null,
            parseData: function (data) {
                that = this;
                data.serviceOne = data[0];
                data.secondService = data[1];
                addedItems = [];
                processRiderService();

                function _isUnique(compareId) {
                    for (var i = 0; i < data[0].value[0].accounts.length; i++) {
                        if (data[0].value[0].accounts[i].acctId === compareId) {
                            return false;
                        }
                    }
                    for (var i = 0; i < that.addedItems.length; i++) {
                        if (typeof that.addedItems[0] === "undefined") { return true; }
                        if (that.addedItems[i].acctId === compareId) {
                            return false;
                        }
                    }
                    return true;
                }

                function processRiderService() {
                    for (var i = 0; i < data[1].value.d.clientAcctRoles.results.length; i++) {
                        if (_dataIsRelevant(data[1].value.d.clientAcctRoles.results[i]) === true && _isUnique(data[1].value.d.clientAcctRoles.results[i].acctId) === true) {
                            tmpmv = data[1].value.d.clientAcctRoles.results[i];
                            addObj = {
                                acctCTX: tmpmv.acctCore.ctx,
                                acctId: tmpmv.acctCore.id,
                                fmtAcctId: tmpmv.acctCore.fmtId,
                                lstUpdtDt: "",
                                planTypDesc: "Non-Qualified",
                                primaryBeneLines: null,
                                qualPlanCtx: null,
                                qualPlanId: null,
                                secondaryBeneLines: null,
                                statuses: null,
                            }
                            that.addedItems = that.addedItems || [];
                            that.addedItems.push(addObj)

                        }
                    }
                }

                function _dataIsRelevant(data) {
                    if (typeof data === 'undefined') { return false }
                    if (typeof data.acctCore.statusCd === 'undefined') { return false }
                    if (typeof data.acctCore.ownshpCd === 'undefined') { return false }
                    if (typeof data.acctCore.adminCd === 'undefined') { return false }
                    allowedAdminCds = ['001', '002', '133'];
                    allowedOwnershipCode = ['N015', 'N018', 'N022', 'N028', 'N006'];
                    if (data.acctCore.statusCd.toUpperCase() === "ACTIVE"
                        && (data.clRoleCd == "001" || data.clRoleCd == "004")
                        && allowedOwnershipCode.indexOf(data.acctCore.ownshpCd) != -1
                        && (allowedAdminCds.indexOf(data.acctCore.adminCd) != -1)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            },

            getRiders: function (clId, response) {
                var _self = this;
                var qcallStack = [];
                _self.addedItems = [];
                var _results = response['results'][0];

                if (_results == undefined || _results.attributes == undefined || _results.attributes.ClientBeneficiaries === null) {
                    qcallStack.push(Dataservice.getClientBeneficiaries(clId));
                }
                qcallStack.push(Dataservice.getBeneficiariesAccountListforClient(clId));
                return Q.allSettled(qcallStack).then(function (responseArray) {
                    //_self.parseData(responseArray);
                    return responseArray;
                });
            },
        },
        render: function (clId) {
            var that = this;
            var _serviceCallsStack = [];
            var respStatCd = respStatCd ||  null;

            function infoCheck ( collection ) { 
                collection = collection || [];
                respStatCdErrors = ['0110', '0111', '0113'];
                showError = false;
                for (var i = 0; i < collection.length; i++) {
                    if (collection.constructor === Array
                            && typeof collection[i].statuses !== 'undefined'
                            && collection[i].statuses !== null
                            && typeof collection[i].statuses.results[0] !== 'undefined'
                            && typeof collection[i].statuses.results[0].statCd !== 'undefined'
                            && respStatCdErrors.indexOf(collection[i].statuses.results[0].statCd) !== -1)
                    {
                        showError = true;
                    } 
                }
                return showError;
            }

            function contactprofileInfoCacheSuccess(response, data) {
                try {
                    var servicesInProgress = 0;
                    var _results = response['results'][0];
                    if (_results == undefined || _results.attributes == undefined || _results.attributes.ClientBeneficiaries === null) {
                        Spinner.show();

                        var _collection = data[0].value[0]['accounts'] || [];
                        (_collection.constructor !== Array) ? _collection = [] : "";

                        (typeof that.Beneficiarylist.addedItems === 'undefined') ? that.Beneficiarylist.addedItems = [] : "";
                        for (var i = 0; i < that.Beneficiarylist.addedItems.length; i++) {
                            _collection.push(that.Beneficiarylist.addedItems[i]);
                        }

                        respStatCd = infoCheck(_collection);

                        if (_collection && _collection.length > 0) {
                            _collection.sort(function (r1, r2) {
                                r1.planTypDesc = (r1.planTypDesc === null) ? "" : r1.planTypDesc;
                                r2.planTypDesc = (r2.planTypDesc === null) ? "" : r2.planTypDesc;
                                r1.qualPlanId = (r1.qualPlanId === null) ? "" : r1.qualPlanId;
                                r2.qualPlanId = (r2.qualPlanId === null) ? "" : r2.qualPlanId;

                                if (r1.planTypDesc > r2.planTypDesc) {
                                    return 1;
                                }
                                if (r1.planTypDesc < r2.planTypDesc) {
                                    return -1;
                                }
                                if (r1.rplanTypDesc == r2.rplanTypDesc) {
                                    if (r1.qualPlanId > r2.qualPlanId) {
                                        return 1;
                                    }
                                    if (r1.qualPlanId < r2.qualPlanId) {
                                        return -1;
                                    }
                                }
                                return 0;
                            });
                            //Beneficiary Account details
                            var _benAccounts = _collection;
                            self._benAccounts = _collection;
                            if (_benAccounts && _benAccounts.length > 0) {
                                servicesInProgress += _benAccounts.length;
                                $.each(_benAccounts, function (key1, account) {
                                    Spinner.show();
                                    Dataservice.getAccountInfo(account.acctId, [401])
                                    .then(function (response) {
                                        servicesInProgress--;
                                        var _accountInfo = response[0] || response;
                                        if (_accountInfo.status && _accountInfo.status == 401) {
                                            _benAccounts[key1].authorized = false;
                                            var _acctId = _benAccounts[key1].acctId;
                                            var _acctLast12 = _acctId.substring(_acctId.length - 12);
                                            var _formattedId = _acctLast12.substring(0, 4) + " " + _acctLast12.substring(4, 8) + " " + _acctLast12.substring(8, 12) + " " + _acctId.substring(0, 3);
                                            _benAccounts[key1].fmtAcctId = _formattedId;
                                        }
                                        else {
                                            var _accntOwnrshps = [];
                                            _accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle1Txt']);
                                            _accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle2Txt']);
                                            _accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle3Txt']);
                                            _accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle4Txt']);
                                            _accntOwnrshps.push(_accountInfo.accountRegistration['legalTitle5Txt']);

                                            _benAccounts[key1].ownerships = _accntOwnrshps.clean().join(" ");
                                            _benAccounts[key1].carrierNum = "";
                                            _benAccounts[key1].carrierNm = "";
                                            if (_accountInfo.adminCd == "134") {
                                                var _carrierNum = "", _carrierNm = _accountInfo.carrierNm;
                                                $.each(_accountInfo.accountIdentifier, function (indx, data) {
                                                    if (data.altAcctCtx == "ADMSRV.ACCT") {
                                                        _carrierNum = "CARRIER #" + data.altAcctId;
                                                    }

                                                });
                                                if (_carrierNum == "" || _carrierNum == "undefined" || _carrierNum == null) {
                                                    _carrierNum = "CARRIER #NA";
                                                }
                                                if (_accountInfo.carrierNm == "" || _accountInfo.carrierNm == "undefined" || _accountInfo.carrierNm == null) {
                                                    _carrierNm = "CARRIER NOT AVAILABLE"
                                                }
                                                _benAccounts[key1].carrierNm = _carrierNm;
                                                _benAccounts[key1].carrierNum = _carrierNum;
                                            }
                                            var productCd = _accountInfo.productCd;
                                            var mediumNm = ""
                                            if (productCd == "00221" || productCd == "00222" || productCd == "00223" || productCd == "00225" || productCd == "00235" || productCd == "00238" || productCd == "00239") {
                                                mediumNm = _accountInfo.accountProduct['mediumNm'].substr(0, 18) + " (" + _accountInfo.accountProduct['shortNm'] + ")";
                                            } else {
                                                mediumNm = _accountInfo.accountProduct['mediumNm'];
                                            }

                                            _benAccounts[key1].mediumNm = mediumNm;
                                            _benAccounts[key1].strategyNm = _accountInfo.accountProduct['strategyNm'];
                                            _benAccounts[key1].brkgProdClsNm = _accountInfo.accountProduct['brkgProdClsNm'];
                                            _benAccounts[key1].brkgProdClsCd = _accountInfo.accountProduct['brkgProdClsCd'];
                                            _benAccounts[key1].adminCd = _accountInfo.adminCd;
                                            _benAccounts[key1].authorized = true;
                                        }
                                        if (servicesInProgress == 0) {
                                            if (_results != undefined) {
                                                _results.set({
                                                    'ClientBeneficiaries': _collection
                                                }, {
                                                    silent: true
                                                });
                                                var _deceased = _results.attributes.clientPersonal.attributes.decsdInd;
                                            }
                                            renderBeneficiaryDetails(_collection);
                                        }
                                    })
                                    .fail(function (err) {
                                        Spinner.hide();
                                    });

                                });

                            }
                            if (servicesInProgress == 0 && key == (_collection.length - 1)) {
                                _results.set({ 'ClientFiduciaries': _collection }, { silent: true });

                                var _deceased = _results.attributes.clientPersonal.attributes.decsdInd;
                                renderBeneficiaryDetails(_collection);
                            }
                        } else {
                            //Set empty collection to avoid Service call when there are no client beneficiaries
                            _results.set({
                                'ClientBeneficiaries': _collection
                            }, {
                                silent: true
                            });
                            renderBeneficiaryDetails(_collection);
                        }
                    } else {
                        renderBeneficiaryDetails(_results.attributes.ClientBeneficiaries);
                    }
                }
                catch (err) {
                    ErrorLog.ErrorUtils.myError(err);
                }
            }

            _serviceCallsStack.push(Dataservice.getContactprofileInfoCache(clId));
            Spinner.show();
            Q.all(_serviceCallsStack)
            	.then(function (response) {

            	    if (response && response.length > 0) {
            	        if (response[0]) {
            	            that.Beneficiarylist.getRiders(clId, response[0]).then(function (data) {
            	                var _results = response[0]['results'][0];
            	                var finalData = [];

            	                if (_results.attributes.ClientBeneficiaries === null) {
            	                    finalData[0] = data[0];
            	                    finalData[1] = data[1];
            	                }
            	                else {

            	                    var cacheData = new Object();
            	                    cacheData.value = [];
            	                    cacheData.value[0] = new Object();
            	                    cacheData.value[0].accounts = _results.attributes.ClientBeneficiaries

            	                    finalData[0] = cacheData;
            	                    finalData[1] = data[0]
            	                }
            	                that.Beneficiarylist.parseData(finalData);
            	                contactprofileInfoCacheSuccess(response[0], finalData);
            	            });            	            
            	        }
            	    }
            	})
            	.fail(function (error) {
            	    Spinner.hide();
            	    ErrorLog.ErrorUtils.myError(error);
            	})
            	.done();

            function renderBeneficiaryDetails(collection) {
                try {

                    if (collection && collection.length > 0) {
                        var tmpCollection = {};
                        tmpCollection['nonqualified'] = [];
                        tmpCollection['simpleretiremnt'] = [];
                        tmpCollection['other'] = [];
                        var showErrorMsg = infoCheck(collection);
                        var respStatCd = showErrorMsg; // seems redundant, but is needed as a chaching workaround
                        //(respStatCd === true) ? true : false;
                        $.each(collection, function (key, row) {
                            (moment(row.lstUpdtDt).isValid() && moment(row.lstUpdtDt).isValid()) ? (row.lstUpdtDt = moment(row.lstUpdtDt).format("MM/DD/YYYY")) : "";
                            (!moment(row.lstUpdtDt).isValid() ? row.lstUpdtDt = null : "");

                            if (row.acctId.substr(0, 3) != "141" && row.acctId.substr(0, 3) != "142") {
                                if (row.statuses && row.statuses.results && row.statuses.results.length > 0) {
                                    showErrorMsg = true;
                                }
                                if (row.planTypDesc && row.planTypDesc == "AMP SIMPLE RETIREMENT ACCOUNT") {
                                    tmpCollection['simpleretiremnt'].push(row);
                                }
                                else if (row.statuses && row.statuses.results && row.statuses.results[0] && row.statuses.results[0].statCd == "0111") {
                                    tmpCollection['other'].push(row);
                                }
                                else if (row.qualPlanId && row.planTypDesc) {
                                    if (tmpCollection[row.qualPlanId]) {
                                        tmpCollection[row.qualPlanId].push(row);
                                    } else {
                                        tmpCollection[row.qualPlanId] = [];
                                        tmpCollection[row.qualPlanId].push(row);
                                    }
                                } else {
                                    tmpCollection['nonqualified'].push(row);
                                }
                            }
                         
                        }

                        );

                        tmpCollection['nonqualified'].sort(function (r1, r2) {
                            r1.adminCd = (r1.adminCd === null) ? "" : r1.adminCd;
                            r2.adminCd = (r2.adminCd === null) ? "" : r2.adminCd;
                            r1.fmtAcctId = (r1.fmtAcctId === null) ? "" : r1.fmtAcctId;
                            r2.fmtAcctId = (r2.fmtAcctId === null) ? "" : r2.fmtAcctId;

                            if (r1.adminCd > r2.adminCd) {
                                return 1;
                            }
                            if (r1.adminCd < r2.adminCd) {
                                return -1;
                            }
                            if (r1.adminCd == r2.adminCd) {
                                if (r1.fmtAcctId > r2.fmtAcctId) {
                                    return 1;
                                }
                                if (r1.fmtAcctId < r2.fmtAcctId) {
                                    return -1;
                                }
                            }
                        })
                        console.log(tmpCollection, "collectioncollectioncollection");
                        globalEbene = tmpCollection;
                        CPData = CPViewModel.getInstance().getData();
                        clLastNm = CPData.cola.personClient.get("clLastNm")

                        $('#cp-content-container').html(that.template({ "brkgProdClsCds": brkgProdClsCds, collection: tmpCollection, respStatCd: respStatCd, showErrorMsg: showErrorMsg, clLastNm: clLastNm }));
                        Spinner.hide();
                    } else {
                        CPData = CPViewModel.getInstance().getData();
                        clLastNm = CPData.cola.personClient.get("clLastNm")

                        $('#cp-content-container').html(that.template({ "brkgProdClsCds": brkgProdClsCds, collection: [], showErrorMsg: showErrorMsg, respStatCd: respStatCd, clLastNm: clLastNm }));
                        Spinner.hide();
                    }
                    CPData.cola.personClient.get("clLastNm")

                } catch (err) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.myError(err);
                }

            }
           
            $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
            $(".hdr-tab-buttons-wrap .bt-ben").addClass("hdr-tab-active");



        },
        
        invokeSpellingCorrectionClick: function (tempId) {
        	Analytics.analytics.recordAction('spellingCorrectionLink:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) ) {
            var _url = Config.getConfigProperty("beneSpellingURL");
            var AcctId = tempId;
            Spinner.show();
            self.callPutContextServicespell(false, AcctId).then(function (response) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId;
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                    }
                }).fail(function (error) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(error);
                });
            }
            else { BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable"); }
        },
       
        invokeEbeneWorkflowLinkClick: function () {
            var _url = Config.getConfigProperty("ebeneUrl");
            Spinner.show();
                        self.callPutContextService(false).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId + "#eBene/";
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
            });

            Analytics.analytics.recordAction('contactProfileBeneficiaryEdit:clicked');

        },

      
        callPutContextServicespell: function (async,acc) {
            var _data = {
                putAdvsSessCntxAcctIds: null,
                putAdvsSessCntxClIds: null,
                putAdvsSessCntxDstrIds: null,
                putAdvsSessCntxGrpIds: null

            };

            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _clientId = _gContext.ContactId;
            var _clientCtx = {
                clId: _clientId,
                clCtx: "COLA.CL",
                clRole: "PrimaryClient"
            };
            _data.putAdvsSessCntxClIds = [_clientCtx];
            var _dstrCtx = {
                dstrId: _gContext.AdvisorFMID,
                dstrCtx: "DMU.DIST"
            };
            _data.putAdvsSessCntxDstrIds = [_dstrCtx];
            var _accCtx = {
                acctId: acc,
                acctCtx: "COLA.ACCT"
            };
            _data.putAdvsSessCntxAcctIds = [_accCtx];
            return Dataservice.putAdvisorSessionContext(_data, (async != undefined) ? async : true);
        },

        callPutContextService: function (async) {
            var _data = {
                putAdvsSessCntxAcctIds: null,
                putAdvsSessCntxClIds: null,
                putAdvsSessCntxDstrIds: null,
                putAdvsSessCntxGrpIds: null

            };

            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _clientId = _gContext.ContactId;
            var _clientCtx = {
                clId: _clientId,
                clCtx: "COLA.CL",
                clRole: "PrimaryClient"
            };
            _data.putAdvsSessCntxClIds = [_clientCtx];
            var _dstrCtx = {
                dstrId: _gContext.AdvisorFMID,
                dstrCtx: "DMU.DIST"
            };
            _data.putAdvsSessCntxDstrIds = [_dstrCtx];
               return Dataservice.putAdvisorSessionContext(_data, (async != undefined) ? async : true);
        }
    });

    return beneficiaryView;
});
