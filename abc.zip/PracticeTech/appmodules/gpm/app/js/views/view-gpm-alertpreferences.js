﻿define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'text!appmodules/gpm/app/templates/gpmalertpreferences.html','appmodules/contactprofile/app/models/preferenceviewmodel'
], function ($, _, Backbone, Utils, AlertPreferencesTemplate,PreferenceViewModel) {
    var alertpreferencesView = Backbone.View.extend({
        el: "#gpm-form-update-field-container",
        id: 'gpm-form-update-field-container',
        events: {
            'change input[type="radio"]': 'toggleRadioClassActive',
        },
        template: _.template(AlertPreferencesTemplate),
        initialize: function (data) {
            this.data = data;

        },
        render: function (updateMode) {
        	if(!this.model.get('currentItemSet')){
        		this.data = this.getViewData();
    			this.model.setCurrentValue(updateMode,{data:this.data});
    		}
            var self = this;
            try {
                var _compiledTemplate = this.template({ data: this.model, email: PreferenceViewModel.getData().emails });
                $("#" + this.id).html(_compiledTemplate);
            }
            catch (error) {
                console.log(error);
            }
        },
        toggleRadioClassActive: function (event) {
            var _radio = $(event.target);
            var _radioHolder = _radio.parents('div.radio-grp-alert');
            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
            _radio.parents('div.radio-group-conatiner').addClass('active');
        },
        getViewData:function(){
        	var _prefViewModelData = PreferenceViewModel.getData();
        	var _gpmPrefModel = {
        			prfrTypCd:"",
        			prfrId:null,
        			prfrdEmail:{},
        			prfrdPhone:{},
        			emails:_prefViewModelData.emails,
        			phones:[],
        			category:[]
        	}
        	var _prefData = _prefViewModelData.alertsAndCommunication;
        	if(!_prefData){return null;}
    	   // var _prefData = alertField.d;
    	    var _clPrfs = _prefData.clPrfrs.results;
    	    var _alertPrefIndx="",noPhoneText="";
    	    _.each(_clPrfs,function(data,index){
    	        if(data.prfrNm == "Alerts"){
    	        	_gpmPrefModel.prfrTypCd = data.prfrTypCd;
    	        	_gpmPrefModel.prfrId = data.prfrId;
    	            _alertPrefIndx = index;
    	        }
    	    });

    	    var _alertPrefDelMechnsm = _clPrfs[_alertPrefIndx].dlvMchnsms.results;
    	    var _emailDestId="",_smsDestId="";
    	    _.each(_alertPrefDelMechnsm, function(list,keys){
    	        if(list.dlvTypCd == "email"){
    	            if(keys!== undefined){
    	            var _emailPref= _alertPrefDelMechnsm[keys].dlvChos.results;
    	            //_gpmPrefModel.emails = _emailPref;
    	                _.each(_emailPref, function(d,i){
    	                    if(d.dlvChoSlctInd == true){
    	                    _emailDestId = d.dlvDestId;
    	                    _gpmPrefModel.prfrdEmail.type = d.dlvDestId;
    	                    _emailDestId = _emailDestId.charAt(0).toUpperCase() + _emailDestId.slice(1).toLowerCase();
    	                     }
    	                });
    	            }
    	        }
    	        if(list.dlvTypCd == "SMS"){
    	            if(keys!== undefined){
    	            var _smsPref= _alertPrefDelMechnsm[keys].dlvChos.results;      
    	            _.each(_smsPref, function(d,i){
    	                if(d.dlvChoSlctInd == true){
    	                _smsDestId =d.dlvDestId;
    	                _gpmPrefModel.dlvDestId = _smsDestId;
    	                 }
    	              });
    	           }
    	        }
    	       if(list.dlvTypCd == "email" && list.dlvTypCd != "SMS"){
    	            noPhoneText = "No";
    	        }
    	     });

    	var lbltxt="",ctrycd="",fullsmsNum="",smsextn="",_emailAddr="";
    	var prefValue = _prefData.dlvAddrs.results;
    	_.each(prefValue, function(list,keys){
    	   if(list.dlvDestId == _emailDestId){
    	    _emailAddr=list.email.emlAddr;
    	    _gpmPrefModel.prfrdEmail.id=_emailAddr;
    	}
    	 if(list.dlvDestId == _smsDestId){
    	    if(!(list.telephone.nonNANPPhnNbr)){

    	        lbltxt = list.telephone.phnLblTxt;
    	        if(lbltxt.toUpperCase() == "OTHER1"){
    	            lbltxt = "Other 1";
    	        }
    	        if(lbltxt.toUpperCase() == "OTHER2"){
    	            lbltxt = "Other 2";
    	        }
    	        if(lbltxt.toUpperCase() == "WORK"){
    	            lbltxt = "Business";
    	        }
    	        lbltxt = lbltxt.charAt(0).toUpperCase() + lbltxt.slice(1).toLowerCase();

    	        var combinePhNo = (list.telephone.NANPAreaCd || "") + (list.telephone.NANPExchCd || "") + (list.telephone.NANPSbscNbr || "");
    	        combinePhNo = combinePhNo.replace(/\D/g, '');
    	        var m = combinePhNo.match(/^(\d{3})(\d{3})(\d{4})$/);
    	        fullsmsNum = ((!m) ? "" : "(" + m[1] + ") " + m[2] + "-" + m[3]);
    	        smsextn = list.telephone.phnExtnNbr; 
    	        _gpmPrefModel.prfrdPhone.type = lbltxt;
    	        _gpmPrefModel.prfrdPhone.num = fullsmsNum;
    	        _gpmPrefModel.prfrdPhone.ext = smsextn;
    	    }else{
    	       fullsmsNum = list.telephone.phnCtryCd + " " + list.telephone.nonNANPPhnNbr;
    	       smsextn = list.telephone.phnExtnNbr;
    	       _gpmPrefModel.prfrdPhone.num = fullsmsNum;
   	        _gpmPrefModel.prfrdPhone.ext = smsextn;
    	        }
    	    }
    	});
    	var _alertSection = _clPrfs[_alertPrefIndx].relPrfrs.results,_reqrdAlertSection = [];
    	_.each(_alertSection, function (list, keys) {
    			_reqrdAlertSection.push(list);
            });
    	_.each(_reqrdAlertSection, function(list,keys){
    		var _catgrItem = {};
    		_catgrItem.label = list.prfrNm;
    		_catgrItem.prfrId = list.prfrId;
    		_catgrItem.isComplex =true;
    		_catgrItem.values = [];
    		_catgrItem.customValues = {
    				prfrTypCd:list.prfrTypCd,
    				prfrId:list.prfrId,
    				prfrChoPtrnCd:list.prfrChoPtrnCd,
    				prfrNm:list.prfrNm
    		}
    		var sectionResult = list.relPrfrs.results;
            _.each(sectionResult, function(listResult, keys1){
            var sectionMchn = listResult.dlvMchnsms.results;
            var _sectionItem = {
        			type:"",
        			label:listResult.prfrNm,
        			values:[],
        			customValues : {
            				prfrTypCd:listResult.prfrTypCd,
            				prfrId:listResult.prfrId,
            				prfrChoPtrnCd:listResult.prfrChoPtrnCd,
            				prfrNm:listResult.prfrNm
            		}
        	};
            var textValue="",emailValue="";
            _.each(sectionMchn, function(listMchn, keys2){
            	var _item = {
            			type:"",
            			isRequired:false,
            			value:"",
            			valueId:false
            			
            	};
                if(listMchn.dlvTypCd == "email"){
                	_item.type="email";
                	
                if(listMchn.dlvReqInd == true){ emailValue = "Required"; _item.isRequired = true;}
                else if (listMchn.dlvChos && listMchn.dlvChos.results[0] && listMchn.dlvChos.results[0].dlvChoSlctInd == true) { emailValue = "Yes"; _item.value = "Yes"; _item.valueId = true; }
                else { emailValue = "No";_item.value = "No";_item.valueId =  false;}
                }
                else if(listMchn.dlvTypCd == "SMS"){
                	_item.type="SMS";
                if(listMchn.dlvReqInd == true){ textValue = "Required";_item.isRequired = true;}
                else if (listMchn.dlvChos && listMchn.dlvChos.results[0] && listMchn.dlvChos.results[0].dlvChoSlctInd == true) { textValue = "Yes"; _item.value = "Yes"; _item.valueId = true; }
                else {textValue = "No";_item.valueId =  false;}
                }
                _sectionItem.values.push(_item);
                var _smsMchnsm = sectionMchn.find(function (mchnsmTyp) { return mchnsmTyp.dlvTypCd == "SMS" });
                if (!_smsMchnsm && listMchn.dlvTypCd == "email" && listMchn.dlvTypCd != "SMS") {
             	   _sectionItem.values.push({type:"SMS",isRequired:false,value:"No",valueId:false });
                 }
            });
            _catgrItem.values.push(_sectionItem);
            });
            _gpmPrefModel.category.push(_catgrItem);
    	});
    	return _gpmPrefModel;
        },
        validateAndNavigateFromStep1:function(){
        	var _self = this;
        	function valuesModified(){
        		var _isModified = true;
        		var _items = _self.model.get('items');
        		var _prfrdEmail = _items.find(function(row){return row.get("itemType") == "preferedEmail"}),
				_prfrdPhone = _items.find(function(row){return row.get("itemType") == "preferedPhone"}),
				_myProfile = _items.find(function (row) { return row.get("itemType") == "myProfile" }),
				_accountMgmt = _items.find(function (row) { return row.get("itemType") == "accountManagement" }),
				_workWithAdvsr = _items.find(function (row) { return row.get("itemType") == "workingWithAdvisor" });
				if (_prfrdEmail.get('valueChanged') == false && _prfrdPhone.get('valueChanged') == false && _myProfile.get('smsAlertChanged') == false && _myProfile.get('emailAlertChanged') == false && _accountMgmt.get('smsAlertChanged') == false && _accountMgmt.get('emailAlertChanged') == false  && _workWithAdvsr.get('smsAlertChanged') == false && _workWithAdvsr.get('emailAlertChanged') == false) {
        			_isModified = false;
        		}
        		return _isModified;
        	}
            if (this.model.validate('gpm-update-form', true)) {
            	this.model.setChangedValue();
            	if(valuesModified()){
            		$('.gpm-step.step1').addClass("finished").removeClass("active");
                	$('.gpm-step.step2').addClass("active");
                	Backbone.history.navigate('gpm/verification/'+this.model.get('updateMode'), true);
            	}else{
            		Utils.showNoChangesMessageToUser();
            	}
        		
        	}
        	
        }
    });
    return alertpreferencesView;
});