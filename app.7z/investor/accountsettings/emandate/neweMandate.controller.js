/**
 * @ngdoc property
 * @name neweMandateController Controller
 * @requires $state
 * @requires $scope
 * @description
 *
 * - change password controller deals with calling the services to load to change the current password to required password.
 *
 **/


'use strict';

function newEmandateController($state, $scope,$timeout, eMandateIntialLoadService, investorEventConstants) {
	
	$scope.neweMandate = {
        showNewMandate : false
    }
    var params = {};

    $scope.$on(investorEventConstants.accountSettings.LOAD_NEW_EMANDATE_DATA_EVENT, function(){
        $scope.neweMandate.showNewMandate = true;
    });

    eMandateIntialLoadService.newEmandate($scope, {});
    //eMandateIntialLoadService.getFolios($scope, {})
    
}
// $inject is necessary for minification. 
newEmandateController.$inject = ['$state','$scope','$timeout', 'eMandateIntialLoadService', 'investorEventConstants'];
module.exports = newEmandateController;