/**
 * @ngdoc property
 * @name Switch Form Directive
 * @requires $state
 * @requires $timeout
 * @requires 
 * @description
 *
 * - Switch form directive will represent the form details of switch module in transact controller.
 *
 **/
'use strict';

var switchForm = function($state, $timeout, switchDtlsToReviewModel, $filter, TransactConstant, transactModel, toaster, $stateParams, transactEventConstants, fundDetailsModel, newFundDetailsModel, authenticationService) {

    return {
            template: require('./switchForm.html'),
            restrict: 'E',
            replace: true,            
            scope: {},
            controller:['$scope', '$element', function($scope, $element){                
                var switchType;  
                var stpDetailsObj = null;
                $scope.switchCtnBtnDisable = true; 
                $scope.greaterAmtUnitsMsgStaus = false; 
                $scope.typeshow = false;  
                $scope.stpDetails={}; 
                $scope.dividendOptns = [$filter('translate')(TransactConstant.transact.RE_INVESTMENT), $filter('translate')(TransactConstant.transact.PAYOUT)];
                                    
                $scope.inputObjs = [
                    {
                        key : "amount",
                        text : $filter('translate')(TransactConstant.transact.AMT_CAP),
                        value : "",
                        disable : true,
                        name : "switchAmt",
                        type : "number",
                        // min : 1000,
                        isRequired : false,
                        pattern : /^[0-9]*$/      
                    },
                    {
                        key : "units",
                        text : $filter('translate')(TransactConstant.transact.UNITS_CAP),
                        value : "",
                        disable : true,
                        name : "switchUnit",
                        type : "number",
                        pattern: /^(?!\.?$)\d{0,9}(\.\d{1,3})?$/,  
                        // min : 1000,
                        isRequired : false
                    }    
                ];     
                $scope.config = {};
                $scope.config.showNotification = false;           
                
                $scope.radios = {};
                //removed default selection of switch type full
                // $scope.radios.selectedVal = $filter('translate')(TransactConstant.transact.FULL);
                // switchType = $filter('translate')(TransactConstant.transact.FULL);
                function SetDetailsGoReview(){
                    switchDtlsToReviewModel.validateSwitch().then(function(data){
                        authenticationService.isInvestorLoggedIn() ? $state.go('invTransact.review.switch') : $state.go('transact.review.switch');
                        if($scope.greaterAmtUnitsMsgStaus){
                            toaster.success("No.of Amount/Units you have entered is more than the balance available. Hence entire amount/unit balance will be considered for redemption");
                        }
                        transactModel.setvalidateSWITCHDetails(data);
                        transactModel.setWebRefNo(data.webRefNo);
                        stpDetailsModel.setStpDetails(stpDetailsObj);
                    }, function(data){
                        toaster.error(data.data[0].errorDescription);
                    });
                }
                function clearInputValues() {
                    $scope.inputObjs[0].value = "";
                    $scope.inputObjs[1].value = "";
                }
                $scope.typeChanged = function(val){ 
                    switchDtlsToReviewModel.setType(val);
                    $scope.inputObjs[0].disable = true;
                    $scope.inputObjs[1].disable = true;    
                    $scope.inputObjs[0].isRequired = false;               
                    $scope.inputObjs[1].isRequired = false;
                    if($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.FULL))
                    {
                        $scope.switchCtnBtnDisable = false;  
                        switchType = $filter('translate')(TransactConstant.transact.FULL); 
                        var valueOfTotalAvailableUnits = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.replace(',','');  
                        var totalAvailableUnits = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits.replace(',','');         
                        // $scope.inputObjs[0].value = valueOfTotalAvailableUnits;
                        $scope.inputObjs[1].value = parseFloat(totalAvailableUnits);
                        $scope.inputUnit = $element[0].querySelector('.unit-label input');
                        // $scope.inputAmount = $element[replace0].querySelector('.fixed-amount-label input');
                        angular.element($scope.inputUnit).triggerHandler('focus');
                        // angular.element($scope.inputAmount).triggerHandler('focus');
                    }
                    else
                    {
                        switchType = $filter('translate')(TransactConstant.transact.PARTIAL);
                        if($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.AMT_CAP))
                        {
                            clearInputValues();
                            // $scope.inputObjs[1].value = ""; 
                            $scope.switchCtnBtnDisable = false;   
                            $scope.inputObjs[0].disable = false;                            
                            $scope.inputObjs[0].isRequired = true;
                            angular.element($scope.inputAmount).triggerHandler('blur');
                            // $scope.inputObjs[1].value = transactModel.convertAmountToUnit($scope.inputObjs[0].value, 10);
                        }   
                        else if($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.UNITS_CAP))                            
                        {
                            clearInputValues();
                            // $scope.inputObjs[0].value = "";
                            $scope.switchCtnBtnDisable = false;
                            $scope.inputObjs[1].disable = false;
                            $scope.inputObjs[1].isRequired = true;
                            angular.element($scope.inputUnit).triggerHandler('blur');
                            // $scope.inputObjs[0].value = transactModel.convertUnitToAmount($scope.inputObjs[1].value, 10);                            
                        }
                    }                    
                } 
                // this is done for auto-populating the Amounts and Units simultaniously.
                $scope.$on('INPUT_CHANGED', function(event, data) {
                    if(data.value){
                        var nav = fundDetailsModel.getFundDetails().fundDetails[0].lastestNav;
                        if(data.value && switchDtlsToReviewModel.getType() === "Full") {
                            $scope.inputObjs[0].value = "";
                        } 
                        if(data.value && data.key=="amount") {
                            
                            if(switchDtlsToReviewModel.getType() === "Amount") {
                                if(data.value) {
                                    $scope.inputUnit = $element[0].querySelector('.unit-label input');
                                    // angular.element($scope.inputUnit).triggerHandler('focus');
                                    // $scope.inputObjs[1].value = transactModel.convertAmountToUnit(data.value, nav);
                                }
                            }
                        } 
                        if(data.value && data.key=="units") {

                            if(switchDtlsToReviewModel.getType() === 'Units') {
                                if(data.value) {
                                    $scope.inputAmount = $element[0].querySelector('.fixed-amount-label input');
                                    // angular.element($scope.inputAmount).triggerHandler('focus'); 
                                    // $scope.inputObjs[0].value = transactModel.convertUnitToAmount(data.value, nav);
                                }
                            }
                        }
                    }
                });
                /*$scope.$on("Edit_Form", function(){
                    $scope.typeChanged();
                });*/
                // $scope.continueBtn = false;
                if($stateParams.key == "switch"){
                    
                    // $scope.continueBtn = true;
                    setPreviousData();
                }

                function setPreviousData(){
                    $scope.$emit("Select_Fund_Continue");  
                    $scope.switchCtnBtnDisable = false;
                    $scope.switchValues = transactModel.getTransactDetails().switchDetails;
                    $scope.fundObj = {};
                    $scope.fundObj = $scope.switchValues.destinationFund;
                    switchType = $scope.switchValues.switchType;
                    $timeout(function(){
                        $scope.$broadcast(transactEventConstants.transact.EDIT_FUND, {fundObj: $scope.fundObj});                       
                    },0)                    
                    if($scope.switchValues.switchType ==  $filter('translate')(TransactConstant.transact.PARTIAL)){
                        $scope.inputObjs[0].value = $scope.switchValues.amount;
                        $scope.inputObjs[1].value = $scope.switchValues.units;
                        $scope.radios.selectedVal = $scope.switchValues.type;
                        if($scope.radios.selectedVal === "Amount"){
                            $scope.inputObjs[0].disable = false;                            
                            $scope.inputObjs[0].isRequired = true;
                            angular.element($scope.inputAmount).triggerHandler('blur');
                        } else{
                            $scope.inputObjs[1].disable = false;
                            $scope.inputObjs[1].isRequired = true;
                            angular.element($scope.inputUnit).triggerHandler('blur');                            
                        }  
                    }
                    else{
                        $scope.inputObjs[0].value = $scope.switchValues.amount;
                        $scope.inputObjs[1].value = $scope.switchValues.units;
                        $scope.radios.selectedVal = $scope.switchValues.type;

                    }                     
                }
                

                // $scope.swpDetails = {};

                function changeSwitchForm(){
                    $scope.radios.selectedVal = "";
                    $scope.inputObjs[0].value = "";
                    $scope.inputObjs[1].value = "";
                    $scope.typeChanged();
                }
                $scope.$on(transactEventConstants.transact.SWITCH_FORM_RESET, function(event){
                   changeSwitchForm();
                });

                $scope.$on('dividendOptionsStp',function(event,obj){            
                    $scope.reinvestmentDisable=false;
                    $scope.payoutDisable=false;
                    $scope.showDividendOpt=true;
                    $timeout(function() {
                         if (obj.fundType === 'E') {
                                if (obj.payoutFlag == 'Y' && obj.reinvestmentFlag == 'Y') {
                                    if (obj.dividendFlag == 'P') {
                                        $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                                        $scope.reinvestmentDisable=true;
                                        $scope.payoutDisable=true;
                                    } else if (obj.dividendFlag == 'R') {
                                        $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                        $scope.reinvestmentDisable=true;
                                        $scope.payoutDisable=true;
                                    }
                                } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'N') {
                                    //$scope.sipDetails.dividend = 'NA';
                                    $scope.showDividendOpt=false;
                                } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'Y') {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                    $scope.reinvestmentDisable=true;
                                        $scope.payoutDisable=true;
                                } else {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                                  $scope.reinvestmentDisable=true;
                                        $scope.payoutDisable=true;
                                }
                            } else if (obj.fundType === 'N') {
                                if (obj.payoutFlag == 'Y' && obj.reinvestmentFlag == 'Y') {
                                    if (obj.dividendFlag == 'P') {
                                        $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                                    } else if (obj.dividendFlag == 'R') {
                                        $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                    }
                                } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'N') {
                                    //$scope.sipDetails.dividend = 'NA';
                                    $scope.showDividendOpt=false;
                                } else if (obj.payoutFlag == 'N' && obj.reinvestmentFlag == 'Y') {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[0];
                                } else {
                                    $scope.stpDetails.dividendSel = $scope.dividendOptns[1];
                                }
                            }
                        },0)
                   $scope.minStpAmt = obj.minSWPAmt;               
                });

                $scope.types = switchDtlsToReviewModel.getType();
                $scope.postStpDetails = function(){
                     $scope.isSameFund = false;
                     
                     var stpModel = {};
                     $scope.stpDetails.stpAmount = {}; 


                    if($scope.radios.selectedVal){
                        $scope.typeshow = false;  
                    }else{
                        $scope.typeshow = true;
                    }
                    $scope.config.showNotification = false;
                    $scope.$emit("SwitchFormSubmit");                         
                    var switchModel = {};
                    var switchBaseDtlsObj = {
                        destinationFund:angular.copy($scope.destinationFund),
                        switchType : switchType,
                        type : ""
                    };
                    if(switchType == $filter('translate')(TransactConstant.transact.PARTIAL))
                    {
                        $scope.greaterAmtUnitsMsgStaus = false;
                        if($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.AMT_CAP)){
                            switchBaseDtlsObj.amount = $scope.inputObjs[0].value;
                            switchBaseDtlsObj.type = $scope.radios.selectedVal; 
                        }
                        else if($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.UNITS_CAP)){
                            switchBaseDtlsObj.units = $scope.inputObjs[1].value;
                            switchBaseDtlsObj.type = $scope.radios.selectedVal;
                        }

                        if(parseInt(switchBaseDtlsObj.amount) > parseInt(fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits) || parseInt(switchBaseDtlsObj.units) > parseInt(fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits)){                            
                            switchType = $filter('translate')(TransactConstant.transact.FULL);                            
                            var totalAvailableUnits = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits.replace(',','');                              
                            switchBaseDtlsObj.units = parseFloat(totalAvailableUnits);
                            switchBaseDtlsObj.amount = "";
                            switchBaseDtlsObj.type = $filter('translate')(TransactConstant.transact.FULL); 
                            switchBaseDtlsObj.switchType = $filter('translate')(TransactConstant.transact.FULL);                       
                            $scope.greaterAmtUnitsMsgStaus = true;
                        }
                            
                    }
                    else if($scope.radios.selectedVal == $filter('translate')(TransactConstant.transact.FULL)){
                        switchType = $filter('translate')(TransactConstant.transact.FULL); 
                        var valueOfTotalAvailableUnits = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.replace(',','');
                        // $scope.inputObjs[0].value = valueOfTotalAvailableUnits;
                        // switchBaseDtlsObj.amount = $scope.inputObjs[0].value;
                        var totalAvailableUnits = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits.replace(',','');  
                        $scope.inputObjs[1].value = parseFloat(totalAvailableUnits);
                        switchBaseDtlsObj.units = $scope.inputObjs[1].value;
                        switchBaseDtlsObj.type = $scope.radios.selectedVal;
                    }

                    if(newFundDetailsModel.getSelectedExistingFund()){
                        if(transactModel.getFundDetails().tschvalScheme === newFundDetailsModel.getSelectedExistingFund().fundOption){
                            $scope.isSameFund = true;
                        };
                    }


                    if($scope.switchForm.$valid && $scope.destinationFund && !$scope.isSameFund)
                    {
                        $scope.stpDetails.destinationFund = $scope.destinationFund;
                        $scope.stpDetails.stpAmount.type =  $scope.radios.selectedVal;

                        if($scope.radios.selectedVal == "fixedAmount"){
                            $scope.stpDetails.stpAmount.amount = $scope.inputObject.value;

                            var availableUnitsVal = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits;                        

                            var amount = $scope.stpDetails.stpAmount.amount;                        

                            if(availableUnitsVal < amount){                            
                                $scope.stpDetails.stpAmount.amount = amount;
                                availAmtStatus = true;
                                
                            }
                            if(availAmtStatus){
                                toaster.error(TransactConstant.stp.STP_FIXED_AMT_ERR);          
                            }
                        } else if($scope.radios.selectedVal == "capitalAppreciation"){
                            $scope.stpDetails.stpAmount.amount = "Capital Appreciation";
                            availAmtStatus = false;
                        }

                    stpDetailsObj = $scope.stpDetails;

                        switchDtlsToReviewModel.setDataObj(switchBaseDtlsObj);
                        switchModel.investorDetails = transactModel.getInvestorDetails();
                        switchModel.fundDetails = transactModel.getFundDetails();
                        switchModel.switchDetails = switchBaseDtlsObj;
                        switchModel.stpDetails = stpDetailsObj;

                        if ($stateParams.key == 'switch') {
                            $scope.config.showNotification = false;
                            var result = _.isEqual(transactModel.getTransactDetails().switchDetails, switchModel.switchDetails);
                            if (!result) {
                                $scope.config.showNotification = true;
                                var destroyHandler =  $scope.$on('yes', function () {
                                    transactModel.setTransactDetails(switchModel);
                                    SetDetailsGoReview();
                                    $scope.config.showNotification = false;
                                    destroyHandler();
                                  });

                                  $scope.$on('no', function () {
                                    $scope.config.showNotification = false;
                                    setPreviousData();
                                  });
                            }
                            else
                                SetDetailsGoReview();
                        }else{
                            transactModel.setTransactDetails(switchModel);
                            SetDetailsGoReview();
                        }
                    }                                  
                }                                
            }]
        };

};

switchForm.$inject = ['$state', '$timeout', 'switchDtlsToReviewModel', '$filter', 'TransactConstant', 'transactModel', 'toaster', '$stateParams', 'transactEventConstants', 'fundDetailsModel','newFundDetailsModel', 'authenticationService'];

module.exports = switchForm;