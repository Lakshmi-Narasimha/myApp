function loginMasterController() {



}
loginMasterController.$inject = [];
module.exports = loginMasterController;
