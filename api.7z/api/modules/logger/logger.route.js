var express = require('express'),
    router = express.Router(),
    CryptoJS = require('crypto-js'),
    fs = require('fs');
// api route

var error = {status: 300, message: 'Authentication Failed'}; /* Error messge object */


var writeToFile = function(message){
    var path = "./logger/log.txt";
    if (!fs.existsSync(path)){
        fs.mkdirSync("./logger");
        fs.writeFile(path, message, function(err) {
            if(err) {
                console.log(err);
                return false;
            }
            return true;
        });
    } else {
        fs.open(path, 'a', 666, function( e, id ) {
          fs.write( id, "\r\n"+ message, null, 'utf8', function(){
            fs.close(id, function(){
              console.log('file closed');
            });
          });
        });
    }
    
};


router.route('/fticLogger')
    .post(function(req, res) {
        var date = new Date().toLocaleDateString('en-US'), message;
        
        message = date + " | " + req.body[0].level + " | " + req.body[0].message;
        
        var status = writeToFile(message);
        if(status) {
            res.send({status:100});
        } else {
            res.send({status:500});
        }
        
    });


module.exports = router;
