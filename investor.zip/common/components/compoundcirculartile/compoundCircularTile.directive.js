'use strict';

var compoundCircularTile = function() {
    return {
            template: require('./compoundCircularTile.html'),
            restrict: 'E',
            replace: true,           
            scope: {              
                compoundCircularTile: '=compoundCircularTile'
            },
            controller: function(){                
            },
            link: function(){
            }
        };
};

compoundCircularTile.$inject = [];
module.exports = compoundCircularTile;