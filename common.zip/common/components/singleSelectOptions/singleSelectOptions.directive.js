/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var singleSelectOptions = function ($state) {
    return {
        template: require('./singleSelectOptions.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            options: "="
        },
        controller:['$scope', function ($scope) {
            $scope.selectedOne = {};
            $scope.selectedOne.lable = "";  
           
            $scope.toggleSelection = function (index, option) {
                for (var i = 0; i < $scope.options.length; i++) {
                    // Condition check when filter happened
                    if($scope.options[i].fundOption === option.fundOption) {
                        $scope.options[i].selected = true;
                    } else {
                        $scope.options[i].selected = false;
                    }
                }

                //$scope.options[index].selected = true;
                $scope.selectedOne = $scope.options[index];

            };


            $scope.doneSelection = function () {
                for (var i = 0; i < $scope.options.length; i++) {
                    if ($scope.options[i].selected) {
                        $scope.selectedOne = $scope.options[i];
                    }
                }
                if ($scope.selectedOne.selected == true) {

                    $scope.$emit('singleSelectionDone', {selectedOne: $scope.selectedOne});
                } else {

                    $scope.selectedOneErrorMsg = "* Please select New Fund"
                }

            };

            $scope.$on("fundFilter", function (event, data) {
                $scope.filterText = data.filterText;
            });

        }]
    };
};

singleSelectOptions.$inject = [];
module.exports = singleSelectOptions;