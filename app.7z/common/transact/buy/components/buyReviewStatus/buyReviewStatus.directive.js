/**
 * @ngdoc property
 * @name fticBuyReviewStatus Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the Redemption Review Status.
 *
 **/
'use strict';

var fticBuyReviewStatus = function (transactModel, TransactConstant) {
    return {
        template: require('./buyReviewStatus.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {

            var paymentDetails = transactModel.getTransactDetails().paymentDetails;
            var transConf = transactModel.getTransactConfirm();
            var arnCode = transactModel.getAdvDetails();
            console.log("paymentDetails", paymentDetails);
            console.log("arnCode", arnCode);
            console.log("transConf", transConf);
            $scope.keyValuePairs = [
                {
                    key: "totalInvestmentAmount",
                    text: TransactConstant.transact.TOTAL_INVSTMNT_AMT,
                    value: paymentDetails.totalAmount
                },
                {
                    key: "paymentMethod",
                    text: TransactConstant.transact.MODE_OF_PAYMENT,
                    value: paymentDetails.paymentMethod
                },
                {
                    key: "bankDetails",
                    text: TransactConstant.transact.BANK_DETAILS,
                    value: paymentDetails.selectedBank
                }
            ];
            $scope.advisorKeyValuePairs = [
                {
                    key: "advisorARN",
                    text: TransactConstant.transact.ADVISOR_ARN_CODE,
                    value : arnCode.arnCode
                },
                {
                    key: "transactionRefNo",
                    text: TransactConstant.transact.TRANS_REF_NO,
                    value : transConf.transactionRefNo
                },
                {
                    key: "dateAndTime",
                    text: TransactConstant.transact.ADV_REQ_DATE,
                    value : transConf.transDateTime
                }
            ];
            /*{
                key: "transactionRefNo",
                text: TransactConstant.transact.TRANS_REF_NO,
                value: transConf.transactionRefNo
            },

            {
                key: "advisorARN",
                text: TransactConstant.transact.ADVISOR_ARN_CODE,
                value: arnCode.code
            }*/
        }]
    };
};

fticBuyReviewStatus.$inject = ['transactModel', 'TransactConstant'];
module.exports = fticBuyReviewStatus;