'use strict';

describe('Directive: Left Nav', function() {

	var compile, scope, directiveEle, isoScope, httpBackend, authRequestHandler, leftNavJson;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

 		angular.mock.inject(function($rootScope, $compile, $httpBackend) {
            scope = $rootScope.$new();
  			compile = $compile;
			httpBackend = $httpBackend;
  			scope.leftNavJson = {
				"leftNav": {
					"Dashboard": {
						"url": "dashboard"
					},
					"Book of Business": [{
						"text": "Sales Overview",
						"url": "salesoverview"
					}, {
						"text": "Portfolio snapshot",
						"url": "#"
					}, {
						"text": "Top Clients",
						"url": "#"
					}],
					"My Clients": [{
						"text": "Client Portfolio",
						"url": "#"
					}, {
						"text": "Account Statement",
						"url": "#"
					}, {
						"text": "Capital Gains statements",
						"url": "#"
					}, {
						"text": "Client Subscriptions",
						"url": "#"
					}, {
						"text": "Transaction Details",
						"url": "#"
					}],
					"Smart Solutions": [{
						"text": "Business Overview",
						"url": "#"
					}, {
						"text": "Commissions",
						"url": "#"
					}, {
						"text": "Monthly Snapshot",
						"url": "#"
					}, {
						"text": "Top 50 Clients",
						"url": "#"
					}],
					"Collaterals": [{
						"text": "Product Literatures",
						"url": "#"
					}, {
						"text": "E-Forms and Transaction Slips",
						"url": "#"
					}, {
						"text": "E-order",
						"url": "#"
					}],
					"Reports": [{
						"text": "My Subscriptions",
						"url": "#"
					}, {
						"text": "Custom Reports",
						"url": "#"
					}, {
						"text": "Transaction Status Report",
						"url": "#"
					}, {
						"text": "Recommended Report",
						"url": "#"
					}, {
						"text": "Commission Details",
						"url": "#"
					}],
					"My Learning": [{
						"text": "Learning Modules",
						"url": "#"
					}, {
						"text": "Learning Tests",
						"url": "#"
					}, {
						"text": "Certificates",
						"url": "#"
					}, {
						"text": "Training Modules",
						"url": "#"
					}],
					"Leads": [{
						"text": "Learning Modules",
						"url": "#"
					}, {
						"text": "Learning Tests",
						"url": "#"
					}, {
						"text": "Certificates",
						"url": "#"
					}, {
						"text": "Training Modules",
						"url": "#"
					}],
					"My Profile": [{
						"text": "Learning Modules",
						"url": "#"
					}, {
						"text": "Learning Tests",
						"url": "#"
					}, {
						"text": "Certificates",
						"url": "#"
					}, {
						"text": "Training Modules",
						"url": "#"
					}]
				}
			};
  			httpBackend.whenGET('jsonServices/leftnav.json').respond(200,scope.leftNavJson);
        	//assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-left-nav></ftic-left-nav>');
        directiveEle = compile(element)(scope);
        // isoScope = directiveEle.isolateScope();
        scope.$digest();
    });
    
    // it('should create seperate isolated scope', function() {
    //     expect(directiveEle.isolateScope()).toBeDefined();
    // });
    
    it('should define left nav data', function() {
        expect(directiveEle.html()).toBeDefined();
    });
	
	it('Verify the mocked data', function(){
		httpBackend.expectGET('jsonServices/leftnav.json'); // Asserts request url
		// httpBackend.flush();
		// console.log(httpBackend);
	});
});