
define(['jquery', 'underscore', 'backbone','backboneRelational', 'appmodules/ncst/app/js/lib/validate-4.2'], function($, _, Backbone,backboneRelational, Validator) {
	var self = this;
	var incomeModel = Backbone.RelationalModel.extend({
		defaults : {
			'type' : 'Permanent',
			'fromBack' : false,
			'investmentExp':'',
			'fiduciaryFlag':false,
			'prodexp':{},
			incomeFedTax:'',
			incomeIndiAnnualNum:'',
			incomeIndiNetNum:'',
			incomeIndiLiquidNetNum:'',
			incomeSourcePrimary:'',
			productExperience:'',
			productExperienceVal: '',
			assetsTypeHeld: '',
			assetsTypeHeldVal: ''
			
		},
		initialize:function(){
			self = this;
		},
		validate: function (valdateRequired) {
			var _proceed = true;
			if (!Validator.validateInputs('client-income',valdateRequired)) {
				_proceed = false;
			}
			if (_proceed) {
				if(Validator.checkforMandatoryFields('client-income')){
					this.set('clientIncomeValid', true);
				}else{
					this.set('clientIncomeValid', false);
				}
				//this.setModel();
			}
			return _proceed;
		},
		setModel: function (investmentExpsData, sourceIncomeCollection, clientHaveAssetsData, doesClientHaveAssetsVal) {
			/****code to round off decimal values in individual income section*****/
			self.set('incomeIndiAnnualNum', removeComma($("#income-indi-annual").val()));
			self.set('incomeIndiNetNum',removeComma($("#income-indi-net").val()));
			self.set('incomeIndiLiquidNetNum', removeComma($('#income-indi-liquid').val()));
			self.set('incomeSourcePrimary', sourceIncomeCollection);
			self.set('incomeFedTax', $('#income-fed-tax').val());
            self.set('incomeFedTaxCode', $('#income-fed-tax option:selected').data('value'));
			self.set('investmentExpToggle', $('.has-invest-exp.active').val());
			self.set('productExperienceVal', investmentExpsData);
			self.set('doesClientHaveAssets', doesClientHaveAssetsVal);
			self.set('assetsTypeHeldVal', clientHaveAssetsData);
			self.set('fromBack', true);
		}
	});
	function commaSeparator(val){
	    while (/(\d+)(\d{3})/.test(val.toString())){
	      val = val.toString().replace(/(\d+)(\d{3})/, '$1'+','+'$2');
	    }
	    return val;
	  }
	function removeComma(val){
		return val.toString().replace(/,/g, '');
	}
	function toFixed(x) {
		var firstNum=(x.toString().split(".")[0]); ///before
		var secondNum=(x.toString().split(".")[1]); ///after
		var secondNum=Math.round("."+secondNum);
		if(	secondNum == 1){
			var str=firstNum;
			i = (str.length-1);
			while(i>0){
			   var intVal = parseInt(str.charAt(i));
			   if(intVal == 9){
				   firstNum = str.replaceAt(i,'0');
			      return firstNum;
			   }else{
				   firstNum = str.replaceAt(i,(intVal+1).toString()); 
			      return firstNum;
			      break;
			   }
			   i--;
			}
		}
		else{
			firstNum=firstNum;
		}
		console.log(firstNum);
		return firstNum;
		} 
	return new incomeModel();
});