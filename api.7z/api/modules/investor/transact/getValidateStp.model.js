// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetValidateStpModelSchema = new mongoose.Schema({
    GetValidateStpResp: {
        type: Array,
        "default": []
    }
});

var GetValidateStpModelLookUp = mongoose.model('GetValidateStpModelLookUp', GetValidateStpModelSchema);

var GetValidateStpModel = new GetValidateStpModelLookUp({
    GetValidateStpResp : {
      "accountNo":"0389906480558",
      "folioId":"18556824",
      "transactionValidated":"true",
      "webRefNo":"STP000693"
    }
});

GetValidateStpModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetValidateStpModelLookUp table, please contact admin...');
    } else {
        GetValidateStpModelLookUp.remove({}, function(err) {
            console.log('GetValidateStpModelLookUp collection removed');
            GetValidateStpModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetValidateStpModelLookUp table, please contact admin...');
                }
                console.log('GetValidateStpModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GetValidateStpModelLookUp;