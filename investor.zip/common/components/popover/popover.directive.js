/**
 * @ngdoc property
 * @name fticPopover Directive
 * @description
 *
 *
 *
 **/
'use strict';

var popover = function($templateCache, $compile) {
    return {
            template: require('./popover.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                placement: "@",
                popovercontent: "=",
                iconClass: '@'

            },
            controller: function($scope){   
                $scope.isArray = angular.isArray; 
                           
                var getTemplate = function() {
                    var templateUrl = $templateCache.get("popover-template.html");
                    return templateUrl;
                };
                
               //console.log($scope.popovercontent);
            },
            link: function(scope, iElement, iAttrs){
            }
        };
};
popover.$inject = ['$templateCache', '$compile'];
module.exports = popover;