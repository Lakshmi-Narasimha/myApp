/**
 * @ngdoc directive
 * @name fticBreadCrumb
 * @requires
 * @requires
 * @requires
 * @description
 *
 * - It displays the bootstrap breadcrumb component.
 *
 **/
'use strict';

var breadCrumb = function($window, appConfig, configUrlModel) {
    return {
        template: require('./breadcrumb.html'),
        restrict: 'E',
        replace: true,
        scope: {
            breadCrumbList: '='
        },
        link: function(scope) {
            scope.MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/';
            scope.redirectPath = function(breadcrumbObject) {
                if (breadcrumbObject.state) {
                    $window.location.href = breadcrumbObject.state;
                }
            };
        }
    };
};

breadCrumb.$inject = ['$window', 'appConfig', 'configUrlModel'];
module.exports = breadCrumb;