'use strict';
describe('Service: switchDtlsToReviewModel ', function() {
	var httpBackend,$window,switchDtlsToReviewModel,fetchTxnDetailsSwitchPromise,transactModel,validateSwitchPromise,fundDetailsModel;

    var GetTxnSwitchResp = {
		"customerInfoVo": {
			"custName": "MR KAUSHIGAN(MINOR) J DAKHAWE MENDONZA",
			"address1": "H NO 64 VIDYAGIRI COLONY",
			"address2": "7TH FLOOR GRANDE PALLIDIUM",
			"address3": "NO 64 BARRACKS ARCADE ",
			"address4": "NEAR RAJPURIA HALL VILE PARLE (E)",
			"city": "HADUR",
			"pinCode": "400058",
			"firstHolderName": "MR KAUSHIGAN(MINOR) J DAKHAWE MENDONZA",
			"secondHolderName": "",
			"thirdHolderName": "",
			"guardian": "",
			"firstHolderPanNo": "CWYQI7401R",
			"secondHolderPanNo": "",
			"thirdHolderPanNo": "",
			"guardianPanNo": "",
			"firstHolderKycStatus": "KYC - Registered",
			"secondHolderKycStatus": "KYC - Registered",
			"thirdHolderKycStatus": "KYC - Registered",
			"guardianKycStatus": "",
			"socialStatus": "Individual",
			"holdingType": "Single",
			"bankdetails": "321400303684/ICICI BANK/ANDHERI WEST MUMBAI",
			"paymentType": "",
			"paymentMode": "Directly To Bank"
		},
		"retrieveSipVo": null,
		"fundOptions": [
		{
			"accNo": "2009901255927",
			"amount": "3000",
			"direct": "",
			"dividendFlag": "R",
			"endDate": "",
			"frequency": "",
			"fundCategory": "",
			"fundOptDesc": "",
			"fundOption": "200",
			"fundType": "",
			"minAddPurAmt": "",
			"minNewPurAmt": "",
			"minSipAmt": "",
			"multiples": "",
			"nfoFlag": null,
			"payoutFlag": "",
			"perpetualFlag": "",
			"reinvestmentFlag": "",
			"startDate": "",
			"stepUpFrequency": "",
			"stepUpType": "",
			"stepUpValue": "",
			"txnType": ""
		}],
		"invPaymentBank": null,
		"paymentMode": "",
		"folioId": "14378413",
		"accountType": null,
		"paymentBankAccNo": null,
		"invAmount": "",
		"subBrokerCode": "0000000000",
		"subBrokerARN": null,
		"euin": null,
		"txn_no": "SWI000245",
		"seq_no": "1",
		"account_number": "",
		"fund_option": "",
		"batch_code": "web",
		"trxn_requested_date": "2016-03-15 00:00:00.0",
		"trxn_requested_time": "10:00",
		"txn_source": "S",
		"sub_distributor_id": null,
		"ref_txn_no": "SW08704206",
		"application_sr_no": "SWI000245",
		"remarks": null,
		"maker_id": "Mobile",
		"maker_date": "2016-08-19 00:00:00.0",
		"auth_id": "Mobile",
		"auth_date": "2016-08-19 00:00:00.0",
		"acc_ref_no": null,
		"transferflag": "1",
		"trtype": "S",
		"web_refno": "SWI000245",
		"transaction_flag": "C",
		"mode_of_txn": null,
		"euin_flag": null,
		"trxn_units": "3000",
		"all_units_flag": "N",
		"start_date": "",
		"end_date": "",
		"frequency": null,
		"perpetual_flag": null,
		"mf_code": null,
		"destination_account_number": "NEW",
		"destination_fund_option": "001",
		"sip_txn_status": null,
		"urn_no": null,
		"nfo_flag": "",
		"priority_batch_flag": null,
		"trxn_effective_date": "2016-03-15 00:00:00.0",
		"amount_unit_flag": "P",
		"dc_last_xdigits": null,
		"dc_name_on_card": null,
		"check_no": null,
		"dividend_option": "",
		"account_source": "RWD",
		"branch_code": null,
		"no_of_installments": null,
		"lbd_flag": null,
		"umrn_no": null,
		"source": null,
		"renewal_flag": null,
		"paymentOption": null,
		"aadhaar": "",
		"pepFlag": "",
		"stepUpType": null,
		"stepUpValue": null,
		"emandateDebitType": null,
		"emandateFrequency": null,
		"emandateAmount": null,
		"untillCancel": null,
		"emandateFromdate": null,
		"emandateTodate": null,
		"stepUpFrequency": null
	};

	var switchBaseDtlsObjWithAmountEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Amount",        
        amount : 8000
	};

	var switchBaseDtlsObjWithUnitsEntered  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Partial",
        type : "Units",              
        units : 3000
	};

	var switchBaseDtlsObj  ={
		destinationFund: {
	        "accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"},
        switchType : "Full",
      	amount : 8000,              
        units : 3000
	};

	var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

    var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];
    
    var switchModel = {
    	'investorDetails' : investorDetails,
    	'fundDetails' : selectedFundObject,
    	'switchDetails' : switchBaseDtlsObj 
    };

    var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': '520965.095916'
        }]
    };

	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,_transactModel_,_switchDtlsToReviewModel_,_fundDetailsModel_){	
		switchDtlsToReviewModel = _switchDtlsToReviewModel_;		
        httpBackend = $httpBackend;		        
        transactModel = _transactModel_;
        fundDetailsModel = _fundDetailsModel_;
        
        transactModel.setTransactDetails(switchModel); 
        fundDetailsModel.setFundDetails(fundDetailsResponse);

		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the function fetchTxnDetailsSwitch',function(){
		expect(switchDtlsToReviewModel.fetchTxnDetailsSwitch).toBeDefined();
	});

	it('should define the function validateSwitch',function(){
		expect(switchDtlsToReviewModel.validateSwitch).toBeDefined();
	});
	
	describe("fetchTxnDetailsSwitch promise",function(){
		beforeEach(inject(function() {						
			fetchTxnDetailsSwitchPromise = switchDtlsToReviewModel.fetchTxnDetailsSwitch();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/getTxnDetailsSwitch').respond(200,GetTxnSwitchResp);
			fetchTxnDetailsSwitchPromise.then(function(response){										
				expect(response.customerInfoVo.custName).toBe("MR KAUSHIGAN(MINOR) J DAKHAWE MENDONZA");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/getTxnDetailsSwitch').respond(400,failureResponse);
			fetchTxnDetailsSwitchPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	describe("validateSwitch promise",function(){
		beforeEach(inject(function() {						
			validateSwitchPromise = switchDtlsToReviewModel.validateSwitch();				
		}));

		it("should resolve when success if user selects full as switch type",function(done){					
			
			httpBackend.expectPOST('http://localhost:3030/transact/validateSwitch?guId=878').respond(200,{
				'accountNo': '6019904934582',
				'folioId': '17919883',
				'transactionValidated': 'true',
				'webRefNo': 'SWI001166'
		    });

			validateSwitchPromise.then(function(response){										
				expect(response.accountNo).toBe('6019904934582');			
				done();
			});			

			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectPOST('http://localhost:3030/transact/validateSwitch?guId=878').respond(400,failureResponse);
			validateSwitchPromise.then(null,function(response){						
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	it('validateSwitch promise resolve successfully if user selects Amount',function(){		
		switchModel = {
	    	'investorDetails' : investorDetails,
	    	'fundDetails' : selectedFundObject,
	    	'switchDetails' : switchBaseDtlsObjWithAmountEntered 
    	};
		transactModel.setTransactDetails(switchModel); 
		validateSwitchPromise = switchDtlsToReviewModel.validateSwitch();

		httpBackend.expectPOST('http://localhost:3030/transact/validateSwitch?guId=878').respond(200,{
				'accountNo': '6019904934582',
				'folioId': '17919883',
				'transactionValidated': 'true',
				'webRefNo': 'SWI001166'
		    });

		validateSwitchPromise.then(function(response){										
			expect(response.accountNo).toBe('6019904934582');			
			done();
		});			
	});

	it('validateSwitch promise resolve successfully if user selects Units',function(){		
		switchModel = {
	    	'investorDetails' : investorDetails,
	    	'fundDetails' : selectedFundObject,
	    	'switchDetails' : switchBaseDtlsObjWithUnitsEntered 
    	};
		transactModel.setTransactDetails(switchModel); 
		validateSwitchPromise = switchDtlsToReviewModel.validateSwitch();

		httpBackend.expectPOST('http://localhost:3030/transact/validateSwitch?guId=878').respond(200,{
				'accountNo': '6019904934582',
				'folioId': '17919883',
				'transactionValidated': 'true',
				'webRefNo': 'SWI001166'
		    });

		validateSwitchPromise.then(function(response){										
			expect(response.accountNo).toBe('6019904934582');			
			done();
		});			
	});
	    
});	
