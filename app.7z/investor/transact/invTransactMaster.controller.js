/**
 * @ngdoc property
 * @name Investor TransactMaster Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function InvTransactMasterCtrl($scope, transactModel, $state, $timeout) {
    
    console.info("Investor TransactionMaster Controller!!");
    $scope.init = function () {
        $scope.header = {};
        $scope.header.title = '';
        $scope.config = {};
        $scope.config.showNotification = false;
        $scope.config.statename = '';
        $scope.config.toState = '';
        $scope.config.toTxnDetailsState = '';
        $scope.videoUrl = 'https://www.youtube.com/embed/ZJZfIw3P8No?wmode=opaque&autohide=1&autoplay=1';
        
            $scope.$on("NAVIGATE_TO_TRANSACT", function ($event, value) {
                $scope.config.param = null;
                $scope.config.param = value;
                if ($scope.config.fromState === $state.current.name) {
                    transactModel.setStateValue($scope.config.param);
                    $state.go($scope.config.toState, $scope.config.param);
                    $timeout(function () {
                        if ($scope.config.param.key == "PaymentDetails") {
                            $scope.$emit("Go_To_Payment_Dtls");
                        }
                    });

                }
            });
        
    };
    $scope.init();
}

InvTransactMasterCtrl.$inject = ['$scope',  'transactModel', '$state', '$timeout'];
module.exports = InvTransactMasterCtrl;