/**
 * @ngdoc property
 * @name review sip Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the review sip controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewSipController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout, bankDtlsModel, profileDetailsModel, planSmartSolution, $filter, transactModel,fundDetails)
{
	
	$scope.accordionClicked = function(){

		var reqParams = transactModel.getSipReqParams(),
			paymentMethod = "",
			totalAmount = 0;

		angular.forEach(reqParams.fundOptions,function(obj,ind){
			totalAmount = totalAmount + parseInt(obj.amount)
		})

		// -------Review Details
		if(!$scope.showDtls.showSipTransactionDtls)
		{
			fundDetails.removeFundDetails();
			angular.forEach(transactModel.getSipFundDtls(),function(obj,ind){
				fundDetails.setFundDetails(obj)
			})

			$scope.showFundDtls = true;
			
			transactModel.setTransactType(TransactConstant.sip.SIP);
			$scope.setPaymentIntegration(transactModel.getSipReqParams());			

			switch(reqParams.paymentMode) {
	            case TransactConstant.common.EMANDATE_CODE:
	                  paymentMethod = TransactConstant.transact.SETUP_NEW_MANDATE;
	                  break;
	            case TransactConstant.common.NET_BANKING_CODE:
	                  paymentMethod = TransactConstant.transact.NET_BANKING;
	                  break;
	            case TransactConstant.common.NEFT_CODE:
	                  paymentMethod = TransactConstant.transact.NEFT_RTGS;
	                  break; 
	            case TransactConstant.common.DEBIT_CARD_CODE:
	                  paymentMethod = TransactConstant.transact.DEBIT_CARD;
	                  break;
	            case TransactConstant.common.AUTO_DEBIT_CODE:
	                  paymentMethod = TransactConstant.transact.AUTO_DEBIT;
	                  break;
	            case TransactConstant.common.BILL_PAY_CODE:
	                  paymentMethod = TransactConstant.transact.BILL_PAY;
	                  break;
	        }
			
			$scope.paymentDetails = [
				{
		            text: "Transaction Reference No.",
		            value: ""
		        },
		        {
		            text: "Total Investment Amount",
		            value: totalAmount || "NA"
		        },		        
		        {
		            text: "Mode of Payment",
		            value: paymentMethod || "NA"
		        },
		        {
		            text: "Bank Details",
		            value: reqParams.bankName || "NA"
		        },	
		        {
		            text: "Advisor ARN",
		            value: profileDetailsModel.getProfileDtls().profileDetails.ARN
		        }	       		       
			];
		}
		

		// -------Transaction details
		if($scope.showDtls.showSipTransactionDtls)
		{
			$scope.SIPkeyValueList = [
				{key:"Folio. No.",value:transactModel.getInvestorDetails().folioId},  
				{key:"First Holder",value:transactModel.getInvestorDetails().custName}		     
			];

			$scope.infoObj=[];
			var SIPFunds =  fundDetails.getFundDetails();
			angular.forEach(SIPFunds,function(obj){
				$scope.infoObj.push([
					{
						text: "Fund",
						value: obj.fundName
					},
					{
						text: "Amount",
						value: obj.sipAmount
					},
					{
						text: "Dividend Option",
						value: obj.dividend || ""
					},
					{
						text: "SIP First Installment",
						value: obj.startDate
					},
					{
						text: "SIP Future Installment",
						value: obj.futureInstallment || ""
					},
					{
						text: "SIP End Date",
						value: obj.endDate
					},
					{
						text: "Frequency",
						value: obj.frequency
					}
				]);
			});

			$scope.showDtls.keyValueList = [
	            {key:'Transaction Reference Number',value:transactModel.getSipWebRefNo()},
	            {key:'Request Date and Time',value:$scope.showDtls.requestDateAndTime},
	            {key:'Total Invested Amount',value:totalAmount}
	        ];
		}		
		
	};
	 	    
    $scope.postTransactDataSip = function(advisorDetailsForm) {		
		$scope.postReviewDetails("sip")	
	};  
			
}


reviewSipController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','$timeout','bankDtlsModel', 'profileDetailsModel', 'planSmartSolution','$filter', 'transactModel', 'fundDetails'];
module.exports = reviewSipController;