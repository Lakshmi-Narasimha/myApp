var config = require('/app/conf/properties/mfchatnode/config');

var conversionModelConfig = {
    request: {
        "tcCustomerID": "",
        "siteID": config.TC_SITE_ID,
        "clientOrderNumber": "",
        "orderType": null,
        "viewID": "36219496",
        "products": []
    }
};

module.exports = conversionModelConfig;
