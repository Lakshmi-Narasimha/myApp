'use strict';
describe('Controller: investor transact controller', function() {
	var $controller,$scope,InvTransactController,$state,$window,transactModel,$timeout,transactEventConstants,newFundDetailsInitialLoader,selectInvestorModel,selectFundInitialLoader,transactNowModel,fticCancelStpFundDetailsModel,TransactConstant;

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.transact'));

	beforeEach(inject(function($rootScope,_$controller_,_$state_,_$timeout_,_transactModel_,$window,_transactEventConstants_,_newFundDetailsInitialLoader_,_selectInvestorModel_,_selectFundInitialLoader_,_transactNowModel_,_fticCancelStpFundDetailsModel_,_TransactConstant_){				
		$controller = _$controller_;
		$scope = $rootScope.$new();
		$state = _$state_;		
        $timeout = _$timeout_;
		transactModel = _transactModel_;
        transactEventConstants = _transactEventConstants_;
        newFundDetailsInitialLoader = _newFundDetailsInitialLoader_;        
        selectFundInitialLoader = _selectFundInitialLoader_;
        selectInvestorModel = _selectInvestorModel_;
        transactNowModel = _transactNowModel_;
        fticCancelStpFundDetailsModel = _fticCancelStpFundDetailsModel_;
        TransactConstant = _TransactConstant_;
		$window = $window;
		$window.ga = function(){};

        $state.current.name = "invTransact.base.switch";
        $state.current.url = "invTransact/base/switch";
        transactModel.setStateValue({key: 'switch'}); 
		InvTransactController = $controller('invTransactCtrl', { $scope: $scope });
        spyOn(newFundDetailsInitialLoader,"loadAllServices");     
        spyOn(selectFundInitialLoader,"loadAllServices");        
	}));	

	it('should be defined', function() {
        expect(InvTransactController).toBeDefined();        
    });

    it('should set the initial values on load of the controller',function(){                           
       $timeout.flush();       
       expect($scope.isTransactChanged).toBe(true);  

       expect($scope.isShowFundGrid).toBe(false);         
       expect($scope.isShowInvestorDetails).toBe(false);         
       expect($scope.isShowReedemGrid).toBe(true);         
       expect($scope.isShowReviewDetails).toBe(true);         
       
       expect($scope.isDisableFundGrid).toBe(true);         
       expect($scope.isDisableReedemGrid).toBe(false);         
       expect($scope.isDisableReviewDetails).toBe(true);         
       
       expect($scope.isOpenInvGrid.open).toBe(false);         
       expect($scope.isOpenFundGrid.open).toBe(false);         
       expect($scope.isOpenRedeemGrid.open).toBe(true);         
       expect($scope.isOpenReviewDetails.open).toBe(false);        

       expect(transactModel.isModifySip).toBe(false);         
       expect(transactModel.isSameInv).toBe(false);         

       expect($scope.isInvestmentPreferAvailable).toBe(true);                
       expect($scope.isShowInvestPrefer).toBe(false);
       expect($scope.isDisableInvestPreferGrid).toBe(true);
       expect($scope.isOpenInvestPreferGrid.open).toBe(false);

       expect($scope.stateStatus.key).toBe('switch');       
    });
    
    it('should listen the event KYC_NOT_REG_FLOW when triggered', function() {
        $scope.$broadcast(transactEventConstants.transact.KYC_NOT_REG_FLOW);
        expect($scope.isShowInvestorDetails).toBe(true);     
    });

    it('should listen the event Pay_Detail_Show when triggered', function() {
        $scope.$broadcast(transactEventConstants.transact.Pay_Detail_Show);
        expect($scope.isPaymentDetailsIni).toBe(true);     
        expect($scope.isDisablePayDetails).toBe(true);
    });

    it('should listen the event Payment_Detail when triggered', function() {
        $scope.$broadcast(transactEventConstants.transact.Payment_Detail);
        expect($scope.isOpenPayDetails.open).toBe(true);     
        expect($scope.isDisablePayDetails).toBe(false);
        expect($scope.isOpenRedeemGrid.open).toBe(false);
    }); 

    it('should listen the event Set_Key_Value_Transact when triggered', function() {
        $scope.$broadcast(transactEventConstants.transact.Set_Key_Value_Transact,[{}]);
        expect($scope.keyValueList).toBeDefined();     
        expect($scope.isShowReedemGrid).toBe(false);        
    });  

    it('should listen the event FlexiSip when triggered', function() {
        $scope.$broadcast('FlexiSip');
        expect($scope.keyValueList.length).toBe(0);  
        expect($scope.isShowReedemGrid).toBe(true); 
        expect($scope.isOpenPayDetails.open).toBe(false); 
        expect($scope.isDisablePayDetails).toBe(true); 
        expect($scope.isOpenRedeemGrid.open).toBe(true); 
    });    

    it('should listen the event Investor_Details when triggered', function() {
        $scope.$broadcast(transactEventConstants.transact.Investor_Details);    
        expect(selectFundInitialLoader.loadAllServices).toHaveBeenCalledWith($scope,selectInvestorModel.getSelectedInvestorDtls());
        expect(newFundDetailsInitialLoader.loadAllServices).toHaveBeenCalledWith($scope,selectInvestorModel.getSelectedInvestorDtls());                
        expect($scope.stateStatus).toBe(null);
    });        

    it('should listen the event Open_Grid when triggered', function() {        
        $scope.$broadcast(transactEventConstants.transact.Open_Grid);          
        expect($scope.isInitialShow).toBe(false);
        expect($scope.isDisableFundGrid).toBe(true);
        expect($scope.isDisableReedemGrid).toBe(true);        
        expect($scope.moduleUrl).toBe('invTransact/base/switch');
    });         

    it('should listen the event Show_Fund when triggered', function() {        
        $scope.$broadcast(transactEventConstants.transact.Show_Fund);          
        spyOn($scope,"$broadcast");
        expect($scope.showView).toBe(true);
        $timeout.flush();
        expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.Show_Fund_Tile);        
        expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.Intl_Modify_Ctrl);        
        expect($scope.isShowFundGrid).toBe(false);
        expect($scope.isOpenFundGrid.open).toBe(false);
        expect($scope.isOpenInvGrid.open).toBe(false);
        expect($scope.isOpenRedeemGrid.open).toBe(true);
        expect($scope.isDisableReedemGrid).toBe(false);
    });   

    it('should listen the event RESET_REDEEM_FORM when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.RESET_REDEEM_FORM,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.REDEEM_FORM_RESET,{});
        },0);    
    });

    it('should listen the event RESET_STP_FORM when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.RESET_STP_FORM,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.STP_FORM_RESET,{});
        },0);    
    });

    it('should listen the event RESET_SWITCH_FORM when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.RESET_SWITCH_FORM,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.SWITCH_FORM_RESET,{});
        },0);    
    });

    it('should listen the event RESET_SWP_FORM when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.RESET_SWP_FORM,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.SWP_FORM_RESET,{});
        },0);    
    });

    it('should listen the event Select_Fund_Continue when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.Select_Fund_Continue,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith("Call_Balance_Units");
            expect($scope.$broadcast).toHaveBeenCalledWith("Call_Registered_banks");
            expect($scope.$broadcast).toHaveBeenCalledWith("populateRedeemDetails");
        },0);    
    });

    it('should listen the event Select_Fund_Continue1 when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.Select_Fund_Continue1,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith("Call_Balance_Units");
            expect($scope.$broadcast).toHaveBeenCalledWith("Call_Registered_banks");            
        },0);    
    });

    it('should listen the event FUND_SELECTION_UNCHANGED when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.FUND_SELECTION_UNCHANGED,{});                
        spyOn($scope,"$broadcast");   
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith("EDIT_SWP_FORM");
            expect($scope.$broadcast).toHaveBeenCalledWith("EDIT_STP_FORM");            
        },0);    
    });

    it('should listen the event setInvestorPreference when triggered', function() {  
        $scope.$broadcast("setInvestorPreference",{});     
        expect($scope.isShowInvestPrefer).toBe(false);  
        expect(selectFundInitialLoader.loadAllServices).toHaveBeenCalledWith($scope,selectInvestorModel.getSelectedInvestorDtls());
        expect(newFundDetailsInitialLoader.loadAllServices).toHaveBeenCalledWith($scope,selectInvestorModel.getSelectedInvestorDtls());                
        expect($scope.stateStatus).toBe(null);  
    });

    it('should listen the event investorPrefer when triggered', function() {  
        $scope.$broadcast("investorPrefer");     
        expect($scope.keyValueInvestPreferList.length).toBe(0);  
        expect($scope.isDisableInvestPreferGrid).toBe(false);  
        expect($scope.isOpenInvestPreferGrid.open).toBe(true);  
        expect($scope.isDisableFundGrid).toBe(true);  
        expect($scope.isShowInvestPrefer).toBe(true);  
        expect($scope.isShowFundGrid).toBe(true);  
        expect($scope.isDisableReedemGrid).toBe(true);  
        expect(transactNowModel.invPreferEditClicked).toBe(true);
        expect(transactNowModel.hasInvPreferData).toBe(true);
    });

    it('should listen the event nomineeDetailsCont when triggered', function() {          
        $scope.ifNewInvestor = true;
        $scope.moduleUrl = "/buy";                         
        $scope.$broadcast("nomineeDetailsCont");                     
        spyOn($scope,"$broadcast");  

        expect($scope.isShowNomineeGrid).toBe(false);        
        expect($scope.isOpenPayDetails.open).toBe(true);  
        expect($scope.isOpenRedeemGrid.open).toBe(true);  
        expect($scope.isDisableReedemGrid).toBe(false);  
        expect($scope.isNomineeEdit).toBe(false);  
        expect(transactModel.getNomineeDtlsFlag()).toBe(true);        

        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith("NOMINEE_TILE",$scope.isNomineeEdit);            
        },10);
    });

    it('should listen the event Fund_Edit_Clicked when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.Fund_Edit_Clicked);     
        spyOn($scope,"$broadcast");
        
        expect($scope.keyValueList.length).toBe(0);  
        expect($scope.isShowReedemGrid).toBe(true);  
        expect($scope.isDisablePayDetails).toBe(true);  
        expect($scope.isShowFundGrid).toBe(true);  
        expect($scope.isOpenInvGrid.open).toBe(false);  
        expect($scope.isOpenFundGrid.open).toBe(true);  
        expect($scope.isOpenRedeemGrid.open).toBe(false);  
            expect($scope.isDisableReedemGrid).toBe(true);  
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.Edit_Fund_Button_Clicked);
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.NEW_FUND_DETAILS);
            expect($scope.$broadcast).toHaveBeenCalledWith(transactEventConstants.transact.INV_FUND_DETAILS);
        },10);
        expect($scope.stateStatus.key).toBe('');        
    });

    it('should listen the event Nominee_Edit_Clicked when triggered', function() {  
        $scope.$broadcast(transactEventConstants.transact.Nominee_Edit_Clicked);     
        spyOn($scope,"$broadcast");
        expect($scope.isNomineeEdit).toBe(true);  
        expect($scope.isShowFundGrid).toBe(false);  
        expect($scope.isShowNomineeGrid).toBe(true);  
        expect($scope.isOpenNomineeGrid.open).toBe(true);  
        expect($scope.isOpenFundGrid.open).toBe(false);  
        expect($scope.isOpenInvGrid.open).toBe(false);  
        expect($scope.isOpenRedeemGrid.open).toBe(false);  
        expect($scope.isDisableNomineeGrid).toBe(false);  
        expect(transactModel.getNomineeDtlsFlag()).toBe(true);
        $timeout(function(){
            expect($scope.$broadcast).toHaveBeenCalledWith("NOMINEE_TILE",$scope.isNomineeEdit);
        },10);
    });

    it('should listen the event editNoNominee when triggered', function() {  
        $scope.$broadcast("editNoNominee");     
        expect($scope.isNomineeEdit).toBe(true);    
        expect($scope.isShowFundGrid).toBe(false);  
        expect($scope.isShowNomineeGrid).toBe(true);  
        expect($scope.isOpenNomineeGrid.open).toBe(true);  
        expect($scope.isOpenFundGrid.open).toBe(false);  
        expect($scope.isOpenInvGrid.open).toBe(false);  
        expect($scope.isOpenRedeemGrid.open).toBe(false);  
        expect($scope.isDisableNomineeGrid).toBe(false);  
    });

    it('should listen the event Inv_Edit_Clicked when triggered', function() {  
        
        $scope.isInvestmentPreferAvailable = true;        
        $state.current.url = "/cancelStp";        
        $scope.$broadcast(transactEventConstants.transact.Inv_Edit_Clicked);          

        expect($scope.keyValueList.length).toBe(0);       
        //expect($scope.isShowReedemGrid).toBe(true);            
        expect($scope.isShowInvestorDetails).toBe(true);  

        expect($scope.isShowInvestPrefer).toBe(true);  
        expect($scope.isOpenInvestPreferGrid.open).toBe(false);
        expect($scope.isDisableInvestPreferGrid).toBe(true);                

        expect($scope.isOpenInvGrid.open).toBe(true);  
        expect($scope.isOpenFundGrid.open).toBe(false);          
        expect($scope.isOpenRedeemGrid.open).toBe(false);  
        expect($scope.isShowFundGrid).toBe(true);         
        expect($scope.isDisableFundGrid).toBe(true);

        expect(transactNowModel.isFolioEditClicked).toBe(true);  
        expect($scope.isShowReedemGrid).toBe(false);
        expect($scope.isDisableReedemGrid).toBe(true);        
    });

    it('should listen the event Inv_Edit_Clicked when triggered', function() {          
        transactModel.setFundDetails({"trxnNo":"54323221","sourceAccNo":"0809776332323","nextTiggerDate":"Mar 31st"});
        fticCancelStpFundDetailsModel.setSelectFundDtls({"folioid":"321289"});
        $scope.$broadcast(transactEventConstants.transact.INV_TRANSACT_CSTP_REVIEW);           
        expect($scope.isOpenReviewDetails.open).toBe(true);
        expect($scope.isDisableReviewDetails).toBe(false);
        expect($scope.isShowReedemGrid).toBe(false);
        expect($scope.isDisableReedemGrid).toBe(true);
    });

    it('should listen the event $stateChangeSuccess when triggered', function() {                  
        $scope.$broadcast("$stateChangeSuccess",{"parent":"base"},{},{"parent":"base"},{});           
        expect(transactModel.isNewInvestor).toBe(false);
        expect($scope.stateStatus).toBe(null);
        expect($scope.keyValueList.length).toBe(0); 
        expect(selectInvestorModel.getEditInvIconChanged()).toBe(false);
        expect($scope.isInvestmentPreferAvailable).toBe(true);
        expect($scope.isShowInvestPrefer).toBe(true);
        expect($scope.isDisableInvestPreferGrid).toBe(true);
        expect($scope.isShowReedemGrid).toBe(true); 
    });

    it('should listen the event INV_FOLIO_SELECTED_CON when triggered', function() {                  
        $scope.$broadcast(transactEventConstants.transact.INV_FOLIO_SELECTED_CON);         
        expect($scope.isShowInvestorDetails).toBe(false);
        expect($scope.isShowInvestPreferGrid).toBe(true);        
        expect($scope.isDisableInvestPreferGrid).toBe(false);        
        expect($scope.isOpenInvGrid.open).toBe(false);      
        expect($scope.isOpenInvestPreferGrid.open).toBe(true); 
    });    

    it('should listen the event $stateChangeStart when triggered', function() {  
        transactModel.isStateChangedTransact=true;                
        $scope.$broadcast("$stateChangeStart");
        $timeout.flush();
        expect($scope.isTransactChanged).toBe(true);        
        expect(transactModel.isStateChangedTransact).toBe(false);
        expect(transactModel.isTransactionStarted).toBe(false);
        expect(transactModel.navigationfromPopup).toBe(false);              
    });
});