var express = require('express'),
    router = express.Router(),
    AdvInstantReportsModel = require('./instantreports/advInstantReports.model'),
    GuestInstantReportsModel = require('./instantreports/guestInstantReports.model'),
    ChangeSecretQAModel = require('./changesecretqa/changeSecretQA.model'),
    SIPCalculatorModel = require('./calculators/sipCalculator.model'),
    CommissionCalculatorModel = require('./calculators/commissionCalculator.model'),
    TaxAdvantageCalculatorModel = require('./calculators/taxAdvantageCalculator.model'),
    ComparissionCalculatorModel = require('./calculators/comparisionCalculator.model'),
    FundDetailsModel = require('./calculators/fundDetails.model'),
    FundCardsModel = require('./fundCardsModel/fundCardsModel.model'),
    FTMenuModel = require('./ftMenu/ftMenu.model'),
    FTRecommedAndNotifyModel = require('./recommendAndNotify/recommendAndNotify.modal'),
    GrantAccessModel = require('./ftMenu/grantaccess.model'),
    SearchAdvisorModel = require('./searchAdvisor.model');
    

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */


router.route('/services/instantReports')
    .get(function (req, res) {
        // console.log(req.query.userType);
        AdvInstantReportsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].instantReportsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].instantReportsObject[0]);
            }

        });
});

router.route('/getSecretQuestions')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ChangeSecretQAModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].changeSecretQADropdownList.length === 0) {
            console.log(123);
            res.send(error);
        } else {
            res.json(data[0].changeSecretQADropdownList);
        }

    });
});   

router.route('/changeSecretQA')
.post(function(req, res) {
    var obj = {
        "transactionStatus": "S"
    }
    
    if(req.body.answer && req.body.confirmanswer){
        res.json(obj);
    } else {
        res.send(error);
    }

});

router.route('/smartsolution/sipLumpCalculator')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SIPCalculatorModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].sipCalculatorObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].sipCalculatorObject[0]);
        }

    });
});   

router.route('/smartsolution/commissionCalculator')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        CommissionCalculatorModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].commissionCalculatorObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].commissionCalculatorObject);
        }

    });
});   

router.route('/smartsolution/taxAdvtCalculator')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        TaxAdvantageCalculatorModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].taxAdvantageCalculatorObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].taxAdvantageCalculatorObject[0]);
        }

    });
});   

router.route('/smartsolution/comparisonCalculator')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ComparissionCalculatorModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].comparissionCalculatorObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].comparissionCalculatorObject[0]);
        }

    });
});   
router.route('/getFundDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        FundDetailsModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].fundDetailsObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].fundDetailsObject);
        }

    });
});
router.route('/getFundCardsModel')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        FundCardsModel.find(function (err, data) {
            console.log(data);
        if(err){
            res.send(err);
        } else if (data[0].fundCardsModelObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].fundCardsModelObject);
        }

    });
}); 

router.route('/others/globalMenu')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        FTMenuModel.find(function (err, data) {
        if(err){
            res.send(err);
        } else if (!data[0].ftMenuObject) {
            res.send(error);
        } else {
            res.json(data[0].ftMenuObject);
        }

    });
});   


router.route('/services/recomNotifications')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        FTRecommedAndNotifyModel.find(function (err, data) {
            console.log(JSON.stringify(data));
        if(err){
            res.send(err);
        } else if (!data[0]) {
            res.send(error);
        } else {
            res.json(data[0]);
        }

    });
});

router.route('/profile/subUserModuleAccess')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GrantAccessModel.find(function (err, data) {
        if(err){
            res.send(err);
        } else if (!data[0].grantAccessObject) {
            res.send(error);
        } else {
            res.json(data[0].grantAccessObject);
        }

    });
}); 

router.route('/services/searchAdvisor')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SearchAdvisorModel.find(function (err, data) {
        if(err){
            res.send(err);
        } else{
            req.query.distFlag === 'NC' ? res.json(data[0].advisorData[1]) : res.json(data[0].advisorData[0]);
        }

    });
});

module.exports = router;
