var express = require('express'),
    router = express.Router(),
    RecommendedPlanModel = require('./planSmartSolution/getRecomendedPlanResp.model'),
    BuildPlanModel =  require('./planSmartSolution/getBuildMyPlanResp.model'),
    SavedSmartSolutionsModel  = require('./savedSmartSolutions/getSavedSmartSolutions.model'),
    GoalInvestorModel = require('./goalinvestor/goalinvestor.model'),
    currentPlanFundsModel = require('./currentplanfunds/currentplanfunds.model'),
    panLevelSummaryModel = require('./panlevelsummary/panlevelsummary.model'),
    FundCardPlanModal = require('./planSmartSolution/getFundModalResp.model'),
    OverviewModel = require('./smartsolportfolio/getoverviewdetails.model'),
    GoalTrendsModel = require('./smartsolportfolio/getgoaltrendsdata.model'),
    InvTrendsModel = require('./smartsolportfolio/getinvtrendsdata.model'),
    CurrentFundsPopup = require('./goalinvestor/currentfundspopup.model'),
    PlanSmartSolution = require('./planSmartSolution/getplansmartsolution.model');
// api route
var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */

router.route('/getRecommendedPlan')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        RecommendedPlanModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].recommendedPlanResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].recommendedPlanResp);
            }

        });
    });


router.route('/getBuildMyPlan')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
            BuildPlanModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].buildPlanResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].buildPlanResp);
                //res.send(500, error);
            }

        });
});   

router.route('/smartsolution/retrieveSmartSolutions')
    .get(function(req, res){
       // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SavedSmartSolutionsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].savedSmartSolObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].savedSmartSolObject[0]);
            }

        }); 
});

router.route('/smartsolution/fsGoalSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
            GoalInvestorModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].GoalDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].GoalDetails[0]);
                //res.send(500, error);
            }

        });
}); 

router.route('/smartsolution/fsGoalDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
            currentPlanFundsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].currentPlanDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].currentPlanDetails[0]);
                //res.send(500, error);
            }

        });
}); 

router.route('/smartsolution/panLevelSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
            panLevelSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].panLevelSummary.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].panLevelSummary[0]);
                //res.send(500, error);
            }

        });
});

router.route('/others/fundExplorer')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
            FundCardPlanModal.find(function (err, data) {
                debugger;
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].fundModalPlanResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].fundModalPlanResp);
                //res.send(500, error);
            }

        });
});

router.route('/smartsolution/overview')
    .get(function (req, res) {
        OverviewModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].OverviewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].OverviewObject[0].OverviewData);
            }

        });

});

router.route('/smartsolution/goalTrends')
    .get(function (req, res) {
        GoalTrendsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].GoalTrendsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].GoalTrendsObject[0]);
            }

        });

});

router.route('/smartsolution/investorTrends')
    .get(function (req, res) {
        InvTrendsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].InvTrendsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].InvTrendsObject);
            }

        });

});

router.route('/smartsolution/currentFunds')
    .get(function (req, res) {
        CurrentFundsPopup.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].funds.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].funds);
            }

        });

});

router.route('/smartsolution/planSmartSolution')
    .post(function (req, res) {
        PlanSmartSolution.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].planSmartSolutionResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].planSmartSolutionResp[0]);
            }

        });

});

module.exports = router;
