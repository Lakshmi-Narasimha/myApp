/**
 * @ngdoc property
 * @name resetPasswordController
 * @requires $scope
 * @description
 *
 * - Reset password
 *
 **/


'use strict';
function ResetPasswordController($scope, appConfig, configUrlModel, $window, authenticationService, toaster, $cookies, $state) {
    
    $scope.headingObj = {
        text: 'Reset Password',
        displayBack: true
    };

    $scope.currentPasswordObj = {
        key: 'currentpassword',
        text: 'Current Password',
        value: '',
        name: 'currentpassword',
        isRequired: true,
        type: 'text'
    };

    $scope.newPasswordObj = {
        key: 'newpassword',
        text: 'New Password',
        value: '',
        name: 'newpassword',
        isRequired: true,
        type: 'text'
    };

    $scope.confirmPasswordObj = {
        text: 'Confirm New Password',
        key: 'confirmnewpassword',
        name: 'confirmnewpassword',
        isRequired: true,
        value: '',
        type: 'text'
    };

    var marketingURL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
    $scope.resetPassword = function(formRef){
        if(formRef.$valid && (formRef.newpassword.$viewValue === formRef.confirmnewpassword.$viewValue)){
            var params = {
                'guId':$cookies.get('guId'),
                'oldPassword':formRef.currentpassword.$viewValue,
                'newPassword':formRef.newpassword.$viewValue,
                'confirmPassword':formRef.confirmnewpassword.$viewValue
            };
            authenticationService.resetPwd(params)
                .then(function(data){
                    $cookies.put('accessToken', data.data.accessToken, { 'domain': appConfig.DOMAIN_CONFIG });
                    $cookies.put('guId', data.data.guId, { 'domain': appConfig.DOMAIN_CONFIG });
                    $cookies.put('userType', data.data.userType, { 'domain': appConfig.DOMAIN_CONFIG });
                    $cookies.put('userRedirectURI', data.data.userRedirectURI, { 'domain': appConfig.DOMAIN_CONFIG });
                    $cookies.put('usersysId', data.data.usersysId, { 'domain': appConfig.DOMAIN_CONFIG });
                    authenticationService.backButton = true;

                    authenticationService.checkUserFeedback().then(function(userStatus) {
                        $cookies.put('userFeedbackStatus', userStatus.status, { 'domain': appConfig.DOMAIN_CONFIG });
                            if (authenticationService.getAppName() === 'guest') {
                                toaster.success('Thankyou, your Password has been reset Successfully.');
                                $window.location.href = data.data.userRedirectURI;
                            } else {
                                authenticationService.innerClick = true;
                                $state.go('dashboard', {}, { reload: true });
                            }
                        }, function() {
                            if (authenticationService.getAppName() === 'guest') {
                                toaster.success('Thankyou, your Password has been reset Successfully.');
                                $window.location.href = data.data.userRedirectURI;
                            } else {
                                authenticationService.innerClick = true;
                                $state.go('dashboard', {}, { reload: true });
                            }                        
                        });                    
                },
                function(data){
                    if (data.status === 400) {
                        toaster.error(data.data[0].errorDescription);
                    }
                });
        }
    }

    $scope.cancelPassword = function(){
        authenticationService.backButton = true;
        $window.location.href = marketingURL;
    }
    var breadCrumb = {
        label: 'Reset Password',
        state: ''
    };

    $scope.$emit("setBreadCrumb",{'breadCrumb':breadCrumb})
}

ResetPasswordController.$inject = ['$scope', 'appConfig', 'configUrlModel', '$window', 'authenticationService', 'toaster', '$cookies', '$state'];
module.exports = ResetPasswordController;