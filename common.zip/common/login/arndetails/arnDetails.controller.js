/**
 * @ngdoc property
 * @name Forgot Password controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
function arnDetailsController($scope, $state, $filter, TransactConstant, $uibModal, constants, advisorRegistrationModelService, $cookies, appConfig, fticStateChange) {
    $scope.formData = {};
    $scope.otpObj = {};
    $scope.backBtn = function($event) {
        $event.preventDefault();
        fticStateChange.stateChange($state, 'loginmaster.register');
        //$state.go('loginmaster.register');
    };
    $scope.headingObj = {
        text: 'Register'
    };

    $scope.arnSubmit = function() {
        $scope.displayARNError = '';
        $scope.displayDateError = '';
        $scope.displayFailureError = '';
        $scope.errorstatus = false;
        //if($scope.arnForm.$valid){
        //post call to validate arn details
        $scope.$broadcast(constants.login.ARN_SUBMTTED_TEXT);
        $scope.formData = advisorRegistrationModelService.getArnData();
        $scope.formData.regType = advisorRegistrationModelService.getUserType();
        if (!$scope.formData.panARN) {
            $scope.displayARNError = 'ARN/RIA Code field cannot be empty';
            $scope.errorstatus = true;
        }
         if (!$scope.formData.dobOrRegDate) {
            $scope.displayDateError = 'Please enter ARN/RIA Registration date';
            $scope.errorstatus = true;
        } if(!($scope.errorstatus)) {
            /*var saveSuccess = function (response) {
                    $state.go('loginmaster.otpdetails');
              };

              var saveFailure = function (errResponse) {
                 toaster.error(errResponse.data[0].errorDescription);
              };*/
            var loadPostSuccess = function(successResponse) {
                var otpdetails = {};
                otpdetails.mobileNo = successResponse.data.mobile;
                otpdetails.emailId = successResponse.data.emailId;
                otpdetails.guId = successResponse.data.guId;

                advisorRegistrationModelService.setUserData(otpdetails);
                advisorRegistrationModelService.setUserDetails(successResponse.data.panARN);
                $cookies.remove('accessToken', { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.remove('guId', { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('accessToken', successResponse.data.accessToken, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('userType', successResponse.data.userType, { 'domain': appConfig.DOMAIN_CONFIG });
                /*advisorRegistrationModelService.postRequestForOtpDetails(otpdetails).then(saveSuccess,saveFailure);*/
                fticStateChange.stateChange($state, 'loginmaster.otpdetails');
                //$state.go('loginmaster.otpdetails');

            };

            var loadPostFailure = function(errResponse) {
                $scope.displayFailureError = errResponse.data[0].errorDescription;
            };

            var arnPostSuccess = function(successResponse) {
                var paramObj = {
                    guId: successResponse.data.guId,
                    userId: null,
                    password: null
                };
                advisorRegistrationModelService.loadAdviserDetails(paramObj).then(loadPostSuccess, loadPostFailure);
            };

            var arnPostFailure = function(errResponse) {
                $scope.displayFailureError = errResponse.data[0].errorDescription;
            };

            advisorRegistrationModelService.postArnDetails($scope.formData).then(arnPostSuccess, arnPostFailure);
        }


        //}
    };

}

arnDetailsController.$inject = ['$scope', '$state', '$filter', 'TransactConstant', '$uibModal', 'constants', 'advisorRegistrationModelService', '$cookies', 'appConfig', 'fticStateChange'];
module.exports = arnDetailsController;
