﻿define(['jquery'], function ($) {
    $.fn.invokeInfoPopup = function (options) {
        // These are the defaults.
        var defaultsettings = {
            "lgscreenposition": "right",
            "smscreenposition": "bottom"
        },
        options = $.extend(defaultsettings, options),
		placement = options.lgscreenposition,
		self = this;

        //Based on devices, the popup will be positioned as requested
        if (window.innerWidth < 768) { placement = options.smscreenposition; }
        $('.popover.info-popup').remove();
        $(this).find('.icon-info.info-popup').popover('destroy');
        $(this).find('.icon-info').popover({
            container: 'body',
            html: true,
            placement: placement,
            viewport: 'body',
            title: 'Change type <i class="icon-popover-close"></i>',
            template: '<div class="popover info-popup ncst-popover" role="tooltip"><div class="arrow info-popup">'
                    + '</div><h2 class="popover-title info-popup"></h2><div class="popover-content info-popup"></div></div>'
        });

        $(this).find('.icon-info').on('shown.bs.popover', function () {
            var popoverId = $(this).attr('aria-describedby');
            if ($('#' + popoverId + ' .icon-popover-close').length == 0) {
                $('#' + popoverId + ' .popover-title').append('<i class="icon-popover-close"></i>');
            }
            $('#' + popoverId + ' .icon-popover-close').off("click").on("click", function (e) {
                $('[aria-describedby=' + popoverId + ']').popover('hide')
            });
            $(document).off('click', 'body').on('click', 'body', function (e) {
                if ($(e.target).attr('class') != 'icon-popover-close' && $(e.target).data('toggle') !== 'popover' && $(e.target).parents('.popover.in').length === 0) {
                    $('[data-toggle="popover"]').popover('hide');
                }
            });
        });

        //Adjust the position of already opened info popup on orientation change
        $(window).off('orientationchange', orientaionChangehandler).on('orientationchange', orientaionChangehandler);
        function orientaionChangehandler(event) {
            var _timeout = 0;
            (function (_event) {
                if (navigator.userAgent.indexOf('Android') > -1) {
                    _timeout = 200;
                }
                setTimeout(function () {
                    var _activePopup = $(self).find('.icon-info[aria-describedby]');
                    if (_activePopup.length > 0) {
                        $(self).invokeInfoPopup(options);
                        setTimeout(function () { _activePopup.click(); }, 10);
                    }
                }, _timeout);
            })(event);
        }
    };
});
