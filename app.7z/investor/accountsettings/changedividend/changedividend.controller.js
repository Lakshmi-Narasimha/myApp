/**
 * @ngdoc Controller
 * @name PanViewController
 * @requires $scope
 * @requires panViewModel
 * @requires investorEventConstants
 * @requires panViewInitialLoader
 * @description
 *
 **/


'use strict';

function ChangeDividendController($scope, $timeout, $uibModal, $state,changeDividendInitialLoadService,investorEventConstants,changeDividendModel,changeDividendGridConfigModel, investorEvents, loggerConstants, fticLoggerMessage) {

  var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_ACCOUNT_SETTINGS_MODULE;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
   $scope.showChangeDividendGrid = false;
   $scope.assetCategoryOptions = [];
   
  $scope.inputObject = {
        label:'Asset Category',
        required:false,
        disable:false
    };

   $scope.assetCategoryOptionsEventName = investorEventConstants.accountSettings.CHANGE_ASSET_CATEGORY_OPTIONS;

   $scope.$on(investorEventConstants.accountSettings.DIVIDEND_DETAILS, function(){
        $scope.showChangeDividendGrid = false;
        $scope.dividendDetailsList = changeDividendModel.getDividendDetailsData();
        $scope.gridOptions = {};
        $scope.gridOptions.columnDefs = changeDividendGridConfigModel.gridConfig.dividendDetails();
        $timeout(function(){
          $scope.showChangeDividendGrid = true;
        });
    });

   $scope.$on(investorEventConstants.accountSettings.cHANGEDIVIDEND_ASSET_CATEGORIES, function(){
        $scope.assetCategoryList = changeDividendModel.getAssetCategoryList();
        $scope.assetCategoryOptions = [
            {
                title: 'All'
            }
        ];
        $scope.assetCategoryOptions =  $scope.assetCategoryOptions.concat(changeDividendModel.getAssetCategoryList());
    });
   
   $scope.$on($scope.assetCategoryOptionsEventName, function(event, data){
        if (data.title != "All"){
          changeDividendInitialLoadService.getDividendDetails($scope,data.title);
        }else{
            if(changeDividendInitialLoadService._isInitialLoadDone){
              changeDividendInitialLoadService.getDividendDetails($scope,'A');
            }
        }
        changeDividendInitialLoadService._isInitialLoadDone = true;
    });
   
   $scope.$on('dividendChangeOptionEvent',function(event, data){
         changeDividendModel.setRequiredInfoForDividendOptionsApi(data);
        if(!data.load){
            var modalInstance = $uibModal.open({
              template : require('./components/confirmmodal/confirmPasswordModal.html'),
              scope : $scope
            });
        }
    });
   changeDividendInitialLoadService.getDividendDetails($scope,'A');
   changeDividendInitialLoadService.getAssetCategoryData($scope);
    
    $scope.updateDividendOption = function(){
      investorEvents.accountSettings.broadcastDividendDetails($scope);
        
    };
}

ChangeDividendController.$inject = ['$scope', '$timeout', '$uibModal', '$state','changeDividendInitialLoadService','investorEventConstants','changeDividendModel', 'changeDividendGridConfigModel', 'investorEvents', 'loggerConstants', 'fticLoggerMessage'];
module.exports = ChangeDividendController;