// advisorSearch.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RenewSipDetailsSchema = new mongoose.Schema({
	renewSipDetailsObject: {
		type: Array,
		"default": []
	}
});

var RenewSipDetailsLookUp = mongoose.model('RenewSipDetailsLookUp', RenewSipDetailsSchema);

	
var RenewSipDetailsModel = new RenewSipDetailsLookUp({

	renewSipDetailsObject: {
		"RenewSipDetails": [
    		{
	    		"investInto":"Franklin India Cash Management Account - Direct – Growth",
	    		"sipAmt":"1500",
	    		"sipstartdate":"1 Jan 2016",
	    		"sipenddate":"1 Jan 2020",
	    		"frequency":"Monthly",
	    		"stepup":"Active"
    		},
    		{
				"investInto":"Franklin India Tax shield Fund",
	    		"sipAmt":"2000",
	    		"sipstartdate":"1 Jan 2016",
	    		"sipenddate":"1 Jan 2020",
	    		"frequency":"Monthly",
	    		"stepup":"Active"
    		}
    	]
	}
});

RenewSipDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
    	console.log('Having toruble in creating RenewSipDetailsLookUp table, please contact admin...');
    } else {
    	RenewSipDetailsLookUp.remove({}, function(err) {
    		console.log('RenewSipDetailsLookUp collection removed');
    		RenewSipDetailsModel.save(function(err) {
    			if (err) {
    				console.log('Having toruble in creating RenewSipDetailsLookUp table, please contact admin...');
    			}
    			console.log('RenewSipDetailsLookUp table created in mongoose...');
    		});
    	});
    	console.log(data.length);
    }
});

module.exports = RenewSipDetailsLookUp;
