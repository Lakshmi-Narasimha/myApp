import { Component, OnInit,ViewChild } from '@angular/core';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Agent } from '../_models/index';
import { Intent } from '../_models/index';
import { ModalDirective } from 'ng2-bootstrap';

@Component({
  selector: 'intentgroupcomponent',
  templateUrl: './intentgroupcomponent.component.html',
  styleUrls: ['./intentgroupcomponent.component.css'],
   inputs: ['title']
})

export class IntentgroupcomponentComponent implements OnInit {

closed: Boolean = false;
selectedIntent: Intent = null;
activeAgentIntents: Array < String > = [];

newIntentModel: any = {};

@ViewChild('addIntentModal') public newIntentModalDialog: ModalDirective;

constructor(private aiAssistCacheService : AIAssistCacheService) { this.subscriptions(); }

ngOnInit() {
}

toggle() {
  this.closed = !this.closed;
}

public updateActiveIntent(pIntent:Intent) {
  this.aiAssistCacheService.getIntentByIdFromServer(pIntent);
}

public hideNewIntentModal():void {
  this.newIntentModalDialog.hide();
}

public createNewIntent(){
  this.aiAssistCacheService.createIntent(this.newIntentModel);
  this.hideNewIntentModal();
}

private subscriptions() {
  this.aiAssistCacheService.activeIntentsObservable.subscribe((data) => {
    this.activeAgentIntents = data || [];
  });
  this.aiAssistCacheService.activeIntentObservable.subscribe((data) => {
    this.selectedIntent = data;
  });

}

}
