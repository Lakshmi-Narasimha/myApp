/**
 * @ngdoc directive
 * @name investmentPreferencesReview
 * @description
 *
 * - investmentPreferencesReview component will provide preview of the user investor prefernce .
 * 
 *
 **/
 'use strict';

var investmentPreferencesBuyReview = function(eventConstants,transactNowModel, $filter, TransactConstant,$state, $cookies) {
	return {
            template: require('./investmentPreferenceBuyReview.html'),
            restrict: 'E',
            replace: true,
            scope: {
                sipType:"=?"
            },
            controller:['$scope', function($scope){
                console.log("invest prefer");
                var invPrefDetails = transactNowModel.getInvestPrefer();
                var _userType = $cookies.get('userType');
                var _isInvestor = (_userType && _userType.toString() === '10') ? true: false;
                var translateFilter = $filter('translate'),
                invPerfCode;
                if($state.current.url==='/renewsip'){
                        invPerfCode = translateFilter(TransactConstant.common.INV_PERF_CODE);
                        console.log("in if block of renewsip");
                    }
                    else{
                        if(_isInvestor) {
                            invPerfCode = translateFilter(TransactConstant.common.INV_FIN_ADVISOR);
                        } else {
                            invPerfCode = translateFilter(TransactConstant.common.FINANCIAL_ADVISOR);                            
                        }
                    }
                if(invPrefDetails.investorMode === "financial"){
                    $scope.invPrefKeyValuePairs = [
                        {
                            text : invPerfCode,
                            value: invPrefDetails.code || 'NA'
                        },
                        {
                            text : translateFilter(TransactConstant.common.SUB_BROKAR_CODE),
                            value: invPrefDetails.subBrokerCode || 'NA'
                        },
                        {
                            text: translateFilter(TransactConstant.common.SUB_BROKAR_ARN),
                            value: invPrefDetails.subBrokerArn || 'NA'
                        },
                        {
                            text: translateFilter(TransactConstant.common.EUIN),
                            value: invPrefDetails.euin || 'NA'
                        }
                    ];
                }else{
                    $scope.invPrefKeyValuePairs = [
                        {
                            text : translateFilter(TransactConstant.common.DIRECT_ARN_MSG)
                        }
                    ];
                }

                $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){ 
                    if($scope.sipType == "renewSip"){
                        transactNowModel.isRenewSipInvEditClicked = true;
                        $scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: 'investorPreferenceRenew'});
                    }else{
                        $scope.$emit("NAVIGATE_TO_TRANSACTNOW", {key: 'investorPreference'});
                    }           
                    $event.stopPropagation(); 
                }); 
            }]
        };
};

investmentPreferencesBuyReview.$inject = ['eventConstants','transactNowModel', '$filter', 'TransactConstant','$state', '$cookies'];
module.exports = investmentPreferencesBuyReview;