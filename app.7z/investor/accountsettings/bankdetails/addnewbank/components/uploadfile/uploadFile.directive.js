'use strict';

var uploadFile = function($parse, addNewBankModel,basisBankAccModel) {
    return {
        template: require('./uploadFile.html'),
        restrict: 'E',
        replace:true,               
        controller: function($scope, $element, $attrs){            
            
        },
        link: function(scope, element, attrs) {            
            angular.element(element)
            scope.fileDetails = [];
            scope.fileData = [];
            scope.fileLength  = null;
            scope.removeFileLength = null;             
            element.on('change', function(onChangeEvent) {
                var files = event.target.files;                       
                _.each(files, function(file) {
                    var reader = new FileReader();
                    reader.onload = scope.imageIsLoaded; 
                    reader.readAsDataURL(file);
                    console.log("file",file);
                    scope.fileDetails.push(file);                                                          
                    scope.fileLength += file.size;                     
                }) 
                console.log("uploadedlength",scope.fileLength);
                basisBankAccModel.setImageLength(scope.fileLength);
            });
            
            scope.imageIsLoaded = function(e){ 
                scope.$apply(function() {
                    scope.fileData.push(e.target.result);
                    basisBankAccModel.setImageData(scope.fileData);                  
                });
            } 
            scope.removeFile = function(event, data) {
                var attachedFile = angular.element(this)[0].file;
                var index = scope.fileDetails.indexOf(attachedFile);
                scope.fileLength = 0;
                scope.fileDetails.splice(index, 1); 
                scope.fileData.splice(index, 1);
                angular.forEach(scope.fileDetails,function(files){
                    console.log("size",files.size);
                    scope.fileLength += files.size;
                })
                basisBankAccModel.setImageLength(scope.fileLength);
                basisBankAccModel.setImageData(scope.fileData);
                scope.fileLength = 0;
                
                /*angular.forEach(scope.updatedFiles,function(files){
                    angular.forEach(files,function(file){
                        console.log("size",file.size);
                        scope.removeFileLength += file.size
                    })
                    console.log("remove",scope.removeFileLength);
                    basisBankAccModel.setImageLength(scope.fileLength);
                    scope.removeFileLength = 0;
                })
                 console.log("removeSize",scope.removeFileLength);
                 scope.updatedFiles = []; */             

            }  
        }
    }
};

uploadFile.$inject = ['$parse','addNewBankModel','basisBankAccModel'];
module.exports = uploadFile;