import { ParamField } from './paramfield';

export class Parameter {

  paramType : string;
  paramTypeId : Number;
  response : string;
  fieldText : string;
  displayImage : false;
  paramList : Array<ParamField>;
  intentId : string;

  isModified: boolean;
  isAvailableParam : boolean = true;
  //isLinkAvailable: boolean = false;
  isPopupRequired: boolean = false;
  //linkText: string;
  clearFieldText: string;
}
