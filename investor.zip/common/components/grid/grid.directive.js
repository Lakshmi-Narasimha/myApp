'use strict';

var fticGrid = function() {
    return {
            template: require('./grid.html'),
            restrict: 'E',
            replace: true,
            scope: {
                gridData: "=",
                gridColumnDef: "=",
                gridOptionsHTemplate : "=",
                paginationEnable: "=?",
                recordsPerPage: "=?",
                gridOptions: "=?"
            },
            controller: function($scope, $element, $attrs){
                 $scope.range = function(n) {
                     return new Array(n);
                };
            },
            link: function(scope, iElement, iAttrs, controller){
                console.log(scope.gridColumnDef)
                if(scope.gridOptionsHTemplate !== undefined || scope.gridOptionsHTemplate) {
                    scope.gridOptions = scope.gridOptionsHTemplate;
                }
                else{
                    scope.gridOptions = scope.gridOptions || {};
                    scope.gridOptions = angular.merge({
                        enableSorting: false,
                        enableColumnMenus: false,
                        enableHorizontalScrollbar: 5,
                        enableVerticalScrollbar: 0
                        
                        // showColumnFooter: true
                    }, scope.gridOptions);    
                }
                if(scope.paginationEnable){
                    scope.gridOptions.onRegisterApi = function (gridApi) {
                        scope.gridApi2 = gridApi;
                    }
                    // scope.gridOptions.paginationPageSizes = [25, 50, 75];
                    scope.gridOptions.paginationPageSize = scope.recordsPerPage;
                }
                scope.gridOptions.enablePaginationControls = false;
                scope.gridOptions.data = scope.gridData;
                scope.gridOptions.columnDefs = scope.gridColumnDef;
            }
        };
};

fticGrid.$inject = [];
module.exports = fticGrid;
