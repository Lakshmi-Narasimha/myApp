'use strict';
describe('Directive: switchForm', function() {
	var compile,scope,$rootScope,directiveElement,isolatedScope,$window,$filter,TransactConstant,fundDetailsModel,$stateParams,$timeout,transactEventConstants,transactModel,$state,httpBackend,frequencyOptionsModel,transactEvents,newFundDetailsModel,toaster,httpBackend,stpDetailsModel,authenticationService;

	var validateSTPResponse =  {
		"accountNo":"0060007818365",
		"folioId":"3456572",
		"transactionValidated":"true",
		"webRefNo":"STP000693"
    };

    var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': 520965.095916
        }]
    };

    var existingFundSelectedObject = {
        "accNo": "0060007818365",
        "amount": "800",
        "direct": null,
        "dividendFlag": "R",
        "endDate": "4 aug 2020",
        "frequency": "monthly",
        "fundCategory": "EQUITY",
        "fundOptDesc": "Franklin India BLUECHIP FUND",
        "fundOption": "006",
        "fundType": "E",
        "minAddPurAmt": "1000",
        "minNewPurAmt": "5000",
        "minSipAmt": "1",
        "multiples": "1",
        "nfoFlag": "N",
        "payoutFlag": "N",
        "reinvestmentFlag": "N",
        "startDate": "12 apr 2014",
        "stepUpType": "",
        "nextInstlDate": "5 sep 2016",
        "nextAnnualDate": "12 apr 2017",
        "stepUpValue": "NA",
        "leadDays": "15",
        "paymentDet":{
        	"payModeEmand": "false",
	        "eMandateType":"",
	        "eMandateVal": "",
	        "eMandateExpiryDate": "" 
		}		       
	};

    var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var stpObjectWithAmountSelected = {
		"stpAmount" : {
			"amount" : 51000,
			"type" : "fixedAmount"
		},
		"destinationFund" : {
			"accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"
		},
		"noofInstallments" : 6
	};

	var stpObjectWithCapitalAppreciationSelected = {
		"stpAmount" : {
			"amount" : "Capital Appreciation",
			"type" : "capitalAppreciation"
		},
		"destinationFund" : {
			"accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"
		},
		"noofInstallments" : 6
	};

	var stpModel = {
		"investorDetails" : investorDetails,
		"fundDetails" : selectedFundObject,
		"stpDetails" : stpObjectWithCapitalAppreciationSelected
	};

	beforeEach(angular.mock.module('advisor'));	
	beforeEach(angular.mock.module('investor.transact'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-stp-form></ftic-stp-form>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function(_$rootScope_,_$compile_,$window,_switchDtlsToReviewModel_,_$filter_,_TransactConstant_,_fundDetailsModel_,_$stateParams_,_$timeout_,_transactEventConstants_,_transactModel_,_$state_,$httpBackend,_frequencyOptionsModel_,_transactEvents_,_newFundDetailsModel_,_toaster_,_stpDetailsModel_,_authenticationService_) {            
            compile = _$compile_;
            scope = _$rootScope_.$new();    

            $window = $window;
            $window.ga = function() {};

            $rootScope = _$rootScope_;
            $timeout = _$timeout_;
            $state = _$state_;
            $stateParams = _$stateParams_;
            $filter = _$filter_;
            httpBackend = $httpBackend;
            transactEvents = _transactEvents_;
            TransactConstant = _TransactConstant_;
            transactEventConstants = _transactEventConstants_;
            transactModel = _transactModel_;
            stpDetailsModel = _stpDetailsModel_;
			
			authenticationService = _authenticationService_;
			toaster = _toaster_;
			frequencyOptionsModel = _frequencyOptionsModel_; 
			newFundDetailsModel = _newFundDetailsModel_;
            fundDetailsModel = _fundDetailsModel_;
            fundDetailsModel.setFundDetails(fundDetailsResponse);
            transactModel.setInvestorDetails(investorDetails);
            transactModel.setFundDetails(selectedFundObject);
            httpBackend = $httpBackend;

            spyOn( transactEvents.transact,"publishAmountSelected");
            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();   
            isolatedScope.initialFlag = true;         
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variables on load',function(){
    	$timeout.flush();
    	expect(isolatedScope.radios.selectedVal).toBe("");
    	expect(isolatedScope.capitalAprrSelected).toBe(false);  
    	expect(isolatedScope.$input).toBeDefined();  
    	expect(isolatedScope.stpDetails).toBeDefined();  
    	expect(isolatedScope.destinationFund).toBeDefined();  
    	expect(isolatedScope.config.showNotification).toBe(false);  
    	expect(isolatedScope.fieldNames.label1).toBe($filter('translate')(TransactConstant.stp.STP_START_DATE));  
    	expect(isolatedScope.fieldNames.label2).toBe($filter('translate')(TransactConstant.stp.STP_END_DATE));  
		expect(isolatedScope.inputObject.key).toBe('fixedAmount');  
		expect(isolatedScope.stpAmtTypes[0].value).toBe('fixedAmount');
		expect(isolatedScope.stpAmtTypes[1].value).toBe('capitalAppreciation');		
		expect(isolatedScope.inputObject.disable).toBe(true);  		  				
		expect(isolatedScope.initialFlag).toBe(false);  	
		expect(frequencyOptionsModel.getAmountFormType().amountType).toBe('FIXEDAMOUNT');
        expect(frequencyOptionsModel.getAmountFormType().formType).toBe('STPFORM');
		expect(transactEvents.transact.publishAmountSelected).toHaveBeenCalledWith(isolatedScope);        	  				
    });

    it('should listen the event transactEventConstants.transact.STP_FORM_RESET when triggered',function(){
    	transactModel.STP_MAIN_FLAG = null;
    	isolatedScope.$broadcast(transactEventConstants.transact.STP_FORM_RESET);
    	expect(isolatedScope.isEditing).toBe(false);  
    	expect(isolatedScope.inputObject.value).toBe(null);  
    	expect(isolatedScope.radios.selectedVal).toBe(' ');  

    	transactModel.STP_MAIN_FLAG = true;
    	isolatedScope.$broadcast(transactEventConstants.transact.STP_FORM_RESET);    	
    });

    it('should call the function listenFixedAmountChange on click of radio button fixed amount',function(){    	
    	isolatedScope.listenFixedAmountChange();    	
        expect(isolatedScope.stpCtnBtnDisable).toBe(false);  
        expect(isolatedScope.inputObject.disable).toBe(false);        
        expect(frequencyOptionsModel.getAmountFormType().amountType).toBe('FIXEDAMOUNT');
        expect(frequencyOptionsModel.getAmountFormType().formType).toBe('STPFORM');
        expect(transactEvents.transact.publishAmountSelected).toHaveBeenCalledWith(isolatedScope);        
    });

    it('should call the function listenCapitalApprChange on click of radio button fixed amount',function(){    	
    	isolatedScope.listenCapitalApprChange();    	
        expect(isolatedScope.stpCtnBtnDisable).toBe(false);  
        expect(isolatedScope.inputObject.value).toBe("");        
        expect(frequencyOptionsModel.getAmountFormType().amountType).toBe('CAPITAL');
        expect(frequencyOptionsModel.getAmountFormType().formType).toBe('STPFORM');
        expect(transactEvents.transact.publishAmountSelected).toHaveBeenCalledWith(isolatedScope);        
    });

    it('should show error message when the user selects same fund after clicking on continue button',function(){
    	newFundDetailsModel.setSelectedExistingFund(existingFundSelectedObject);
    	isolatedScope.postStpDetails();
    	expect(isolatedScope.isSameFund).toBe(true);
    });

    it('should show error message when the user selects Amount radio button and entering the amount greater then the available amount after clicking on continue button',function(){
    	spyOn(toaster,"error");
    	newFundDetailsModel.setSelectedExistingFund(null);
    	isolatedScope.radios.selectedVal = "fixedAmount";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	isolatedScope.postStpDetails();
    	expect(isolatedScope.stpDetails.stpAmount.type).toBe("fixedAmount");
    	expect(isolatedScope.stpDetails.stpAmount.amount).toBe(540000);
    	expect(toaster.error).toHaveBeenCalledWith(TransactConstant.stp.STP_FIXED_AMT_ERR);
    });

    it('should call the api successfully after clicking continue button',function(){    	
    	isolatedScope.radios.selectedVal = "capitalAppreciation";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	transactModel.setTransactDetails(stpModel);    	
    	isolatedScope.postStpDetails();    	
    	httpBackend.expectPOST("http://localhost:3030/transact/validateStp?guId=878").respond(200,validateSTPResponse);
    	$rootScope.$digest();
    	expect(isolatedScope.stpDetails.stpAmount.type).toBe("capitalAppreciation");
    	expect(isolatedScope.stpDetails.stpAmount.amount).toBe("Capital Appreciation");
    	expect(transactModel.getStpFixedAmtStatus()).toBe(false);
    	expect(transactModel.getTransactDetails().investorDetails).toBeDefined();
    	expect(transactModel.getTransactDetails().fundDetails).toBeDefined();
    	expect(transactModel.getTransactDetails().stpDetails).toBeDefined();    

    	httpBackend.flush();    	
    	expect(transactModel.getWebRefNo()).toBe(validateSTPResponse.webRefNo);   
    	expect(stpDetailsModel.getStpDetails().stpAmount.amount).toBe("Capital Appreciation");    	
    });
	
	it('should navigate to investor review page after clicking continue button',function(){    	
		spyOn($state,"go");
		isolatedScope.radios.selectedVal = "capitalAppreciation";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;    	
    	isolatedScope.postStpDetails();    	
    	httpBackend.expectPOST("http://localhost:3030/transact/validateStp?guId=878").respond(200,validateSTPResponse);
    	$rootScope.$digest();

    	httpBackend.flush();    	
    	
    	expect($state.go).toHaveBeenCalledWith("invTransact.review.stp");
	});

	it('should navigate to advisor review page after clicking continue button',function(){    	
		spyOn($state,"go");
		isolatedScope.radios.selectedVal = "capitalAppreciation";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	authenticationService.setUser({                                        
            "userId": "test123"                
        });
    	isolatedScope.postStpDetails();    	
    	httpBackend.expectPOST("http://localhost:3030/transact/validateStp").respond(200,validateSTPResponse);
    	$rootScope.$digest();

    	httpBackend.flush();    	
    	
    	expect($state.go).toHaveBeenCalledWith("transact.review.stp");
	});

	it('should show the error when the api fails after clicking continue button',function(){    	
    	isolatedScope.radios.selectedVal = "capitalAppreciation";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	transactModel.setTransactDetails(stpModel);    	
    	spyOn(toaster,"error");
    	isolatedScope.postStpDetails();    	
    	httpBackend.expectPOST("http://localhost:3030/transact/validateStp?guId=878").respond(400,failureResponse);
    	$rootScope.$digest();
    	
    	httpBackend.flush();    	
    	expect(toaster.error).toHaveBeenCalledWith(failureResponse[0].errorDescription);       	
    });

	it('should listen the event yes after clicking on yes in the pop up',function(){		
		$stateParams.key = "stp";
		isolatedScope.radios.selectedVal = "capitalAppreciation";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"stpDetails" : stpObjectWithAmountSelected
		});	
    	isolatedScope.postStpDetails(); 

		isolatedScope.$broadcast("yes");
		expect(isolatedScope.config.showNotification).toBe(false);
		expect(transactModel.getStpFixedAmtStatus()).toBe(false);
    	expect(transactModel.getTransactDetails().investorDetails).toBeDefined();
    	expect(transactModel.getTransactDetails().fundDetails).toBeDefined();
    	expect(transactModel.getTransactDetails().stpDetails.stpAmount.type).toEqual("capitalAppreciation");
	});

	it('should listen the event no after clicking on yes in the pop up(show the previous data the user selected)',function(){		
		$stateParams.key = "stp";
		spyOn(isolatedScope,"$emit");		
		isolatedScope.radios.selectedVal = "fixedAmount";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"stpDetails" : stpObjectWithCapitalAppreciationSelected
		});	
    	isolatedScope.postStpDetails(); 

		isolatedScope.$broadcast("no");
		$timeout.flush();
		expect(isolatedScope.config.showNotification).toBe(false);
		expect(isolatedScope.$emit).toHaveBeenCalledWith("stpFormSubmit");
		expect(isolatedScope.$emit).toHaveBeenCalledWith("Select_Fund_Continue");		
		
		expect(isolatedScope.fundObj).toEqual(stpObjectWithCapitalAppreciationSelected.destinationFund);
		expect(isolatedScope.radios.selectedVal).toEqual("capitalAppreciation");
		expect(isolatedScope.inputObject.value).toBe('');
		expect(isolatedScope.stpCtnBtnDisable).toBe(false);				 		
	});
	
	it('should listen the event no after clicking on yes in the pop up(show the previous data if the user selected capital Appreciation)',function(){		
		$stateParams.key = "stp";
		spyOn(isolatedScope,"$emit");		
		isolatedScope.radios.selectedVal = "capitalAppreciation";    	
    	isolatedScope.inputObject.value = 540000;
    	isolatedScope.stpForm.$valid = true;
    	transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"stpDetails" : stpObjectWithAmountSelected
		});	
    	isolatedScope.postStpDetails(); 

		isolatedScope.$broadcast("no");
		$timeout.flush();
		expect(isolatedScope.config.showNotification).toBe(false);
		expect(isolatedScope.$emit).toHaveBeenCalledWith("stpFormSubmit");
		expect(isolatedScope.$emit).toHaveBeenCalledWith("Select_Fund_Continue");		
		
		expect(isolatedScope.fundObj).toEqual(stpObjectWithAmountSelected.destinationFund);
		expect(isolatedScope.radios.selectedVal).toEqual("fixedAmount");
		expect(isolatedScope.inputObject.value).toBe(51000);		 		
	});
});	

  