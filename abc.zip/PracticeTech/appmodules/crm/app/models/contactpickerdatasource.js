define([
    'jquery',
    'underscore',
    'backbone',
    'config',
    'appcommon/constants',
    'appcommon/commonutility',
    'appcommon/globalcontext',
    'appmodules/nav/app/models/contactdetails',
    'services/dataservice',
], function ($, _, Backbone, Config, Constants, Util, Context, AppContactDetails, DataService) {

    /*
        Provides data to a ContactPickerView

        Users of the contact picker instantiate a data source and provide it to the view
        as a constructor parameter.  If the client list is already fully downloaded it can
        be set in the data source.

        Terms:
            dynamic - the data source will query the server given a search criteria
            fixed - the data source has a fixed list

            NOTE: The Client list can be fixed or dynamic.  The Prospect list is always dynamic.

     */

    ContactPickerDataSource = function (clientFmid, prospectFmid) {

        // private instvars

        var self = this;
        var fixedClientList = null;
        var clientSearchFmid = clientFmid;
        var prospectSearchFmid = prospectFmid ? prospectFmid : clientFmid;
        var recentSearchResults = [];
        var maxRecentResultsToKeep = 3;

        // public methods

        this.isClientListFixed = function() {
            return fixedClientList != null;
        }

        this.setFixedClientListFromAppClientList = function(appClientList) {
            var contacts = transformAppFixedClientListToPickerContacts(appClientList);
            if (contacts.length > 0) {
                fixedClientList = contacts;
            }
        }

        this.pinnedContact = function() {
            var pinnedContactId = Context.getInstance().getGlobalContext().Context.ContactId;
            if (pinnedContactId) {
                var pinnedContactType = Context.getInstance().getGlobalContext().Context.ContactType;
                var pinnedContact = AppContactDetails.advsiorContacts.getSelectedContactDetails(Context.getInstance().getGlobalContext().Context.AdvisorFMID, pinnedContactId, pinnedContactType);
                if (pinnedContact) {
                    var contact = {};
                    contact.contactType = pinnedContact.contactType;
                    contact.id = pinnedContact.id;
                    contact.firstName = pinnedContact.firstNm;
                    contact.lastName = pinnedContact.lastNm;
                    contact.orgName = pinnedContact.orgNm;
                    if (contact.lastName) {
                        contact.displayName = contact.lastName;
                        if (contact.firstName) {
                            contact.displayName += (', ' + contact.firstName);
                        }
                    } else if (contact.orgName) {
                        contact.displayName = contact.orgName;
                    } else {
                        contact.displayName = "?"
                    }
                    return contact;
                }
            }
            return null;
        }

        // return [contact]
        this.searchFixedClientList = function(searchText) {
            return _.filter(fixedClientList, function(contact) {
                return isSearchHit(contact, searchText);
            });
        }

        // searches server for contacts.  if ok the success will be invoked with [contact], if fails the failure will be invoked with Error
        this.searchServerContacts = function(contactType, searchText, success, failure) {
            var safeSearchText = toUrlSafeString(searchText);
            var results = searchRecentResults(contactType, searchText);
            if (results) {
                success(results);
            } else {
                if (contactType == 'client') {
                    if (fixedClientList != null) {
                        success(this.searchFixedClientList(safeSearchText));
                    } else {
                        searchServerClients(safeSearchText, success, failure);
                    }
                } else {
                    searchServerNonClients(safeSearchText, success, failure);
                }
            }
        }
        this.searchClientById = function (clientId, success, failure) {
            DataService.getClientgroup(clientId, [401]).then(function (result) {
                if (result && result[0]) {
                    success(result);
                } else {
                    failure(result);
                }
            }).fail(function (xhr) {
                failure(error);
            });
        };
        // private methods

        function searchServerClients(searchText, success, failure) {
            filter = "startswith(firstNm,'" + searchText + "') eq true  or startswith(lastNm,'" + searchText + "') eq true";
            DataService.getClients(clientSearchFmid, Config.contactListLimit, filter, [404]).then(function (result) {
                var resultContacts = (result[0] && result[0]['results']) ? result[0]['results'] : null;
                if (Util.isEmpty(resultContacts)) {
                    putToRecentResults('client', searchText, []);
                    success([]);
                } else {
                    var contacts = transformServiceClientSearchResponseToPickerContacts(resultContacts);
                    if (contacts) {
                        putToRecentResults('client', searchText, contacts);
                        success(contacts)
                    } else {
                        failure(new Error('Service returned invalid data for client search'));
                    }
                }
            }).fail(function(error) {
                failure(error);
            });
        }

        function searchServerNonClients(searchText, success, failure) {
            DataService.getNonClients(prospectSearchFmid, false, searchText).then(function (result) {
                var resultContacts = result[0].get("clientRefs");
                if (Util.isEmpty(resultContacts)) {
                    putToRecentResults('nonClient', searchText, []);
                    success([]);
                } else {
                    var contacts = transformServiceNonClientSearchResponseToPickerContacts(resultContacts);
                    if (contacts) {
                        putToRecentResults('nonClient', searchText, contacts);
                        success(contacts)
                    } else {
                        failure(new Error('Service returned invalid data for client search'));
                    }
                }
            }).fail(function(error) {
                failure(error);
            });
        }

        function isSearchHit(contact, searchText) {
            var contactSearchText = contact.displayName;
            if (contact.contactType == Constants.contactType.Client && contact.id != null && contact.id.length > 8) {
                contactSearchText += contact.id.slice(-8);
            }
            return contactSearchText.search(new RegExp(searchText, "i")) != -1;
        }

        function transformAppFixedClientListToPickerContacts(appClientList) {
            contacts = [];

            _.each(appClientList, function(contactListContact){
                var contact = {};
                contact.contactType = Constants.contactType.Client;
                contact.id = contactListContact.id;
                contact.firstName = contactListContact.firstNm;
                contact.lastName = contactListContact.lastNm;
                contact.orgName = contactListContact.orgNm;
                if (contact.lastName) {
                    contact.displayName = contact.lastName;
                    if (contact.firstName) {
                        contact.displayName += (', ' + contact.firstName);
                    }
                } else if (contact.orgName) {
                    contact.displayName = contact.orgName;
                } else {
                    contact.displayName = "?"
                }
                contacts.push(contact);
            });

            return contacts;
        }

        function transformServiceClientSearchResponseToPickerContacts(serviceContactList) {
            var contacts = [];

            _.each(serviceContactList, function(serviceContact) {
                var contact = {};
                contact.contactType = Constants.contactType.Client;
                contact.id = serviceContact.get('id');
                contact.clientId = contact.id;
                contact.firstName = serviceContact.get('firstNm');
                contact.lastName = serviceContact.get('lastNm');
                contact.orgName = serviceContact.get('orgNm');
                if (contact.lastName) {
                    contact.displayName = contact.lastName;
                    if (contact.firstName) {
                        contact.displayName += (', ' + contact.firstName);
                    }
                } else if (contact.orgName) {
                    contact.displayName = contact.orgName;
                } else {
                    contact.displayName = "?"
                }
                contacts.push(contact);
            });

            return contacts;
        }

        function transformServiceNonClientSearchResponseToPickerContacts(serviceContactList) {
            var contacts = [];

            _.each(serviceContactList, function(serviceContact) {
                if (serviceContact.get('contactType') != 'Client') {
                    var contact = {};
                    contact.contactType = Constants.contactType.NonClient;
                    contact.id = serviceContact.get('id');
                    contact.firstName = serviceContact.get('firstNm');
                    contact.lastName = serviceContact.get('lastNm');
                    contact.orgName = serviceContact.get('orgNm');
                    if (contact.lastName) {
                        contact.displayName = contact.lastName;
                        if (contact.firstName) {
                            contact.displayName += (', ' + contact.firstName);
                        }
                    } else if (contact.orgName) {
                        contact.displayName = contact.orgName;
                    } else {
                        contact.displayName = "?"
                    }
                    contacts.push(contact);
                }
                return contacts;
            });

            return contacts;
        }

        function toUrlSafeString(searchText) {
            return searchText.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
        }

        // return null if no recents available that can be used for this search type/text
        function searchRecentResults(contactType, searchText) {
            var recentInclusiveResults = getInclusiveRecentResults(contactType, searchText);
            if (recentInclusiveResults) {
                return _.filter(recentInclusiveResults.contacts, function(contact) {
                    return isSearchHit(contact, searchText);
                });
            } else {
                return null
            }
        }

        function putToRecentResults(contactType, searchText, contacts) {
            // only keep it if we don't already have a search that covers the same contacts
            var inclusiveSearch = getInclusiveRecentResults(contactType, searchText);
            if (!inclusiveSearch) {
                if (recentSearchResults.length > maxRecentResultsToKeep) {
                    recentSearchResults.shift();  // drop the oldest result
                }
                recentSearchResults.push({
                    contactType: contactType,
                    searchText : searchText,
                    contacts: contacts
                });
            }
        }

        function getInclusiveRecentResults(contactType, searchText) {
            return _.find(recentSearchResults, function(otherRecentResult) {
                return contactType == otherRecentResult.contactType &&
                    searchText.toLowerCase().indexOf(otherRecentResult.searchText.toLowerCase()) === 0;  // starts with
            });
        }
    }

    return ContactPickerDataSource;

});