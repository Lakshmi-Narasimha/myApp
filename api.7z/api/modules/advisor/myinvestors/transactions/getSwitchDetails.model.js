// getSwitchDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SwitchDetailsModelSchema = new mongoose.Schema({
    switchDetailsResp: {
        type: Array,
        "default": []
    }
});

var SwitchDetailsModelLookUp = mongoose.model('SwitchDetailsModelLookUp', SwitchDetailsModelSchema);

var SwitchDetailsModel = new SwitchDetailsModelLookUp({
    switchDetailsResp : {
      "switch": {
        "fundWiseData": [
            {
              "switchOutDate": "18 Feb 2016",
              "SwitchInDate": "10 Feb 2010",
              "destinationFund": "Frnklin India equity fund-growth",
              "destinationAccountNo": "101011901",
              "switchAmount": "1000.90",
              "switchOutNAV": "98.11",
              "switchInNAV": "101.11",
              "units": "120",
              "status": "Processed",
              "type": "Partial"
            },
            {
              "switchOutDate": "18 Jan 2016",
              "SwitchInDate": "17 Jan 2011",
              "destinationFund": "Frnklin India equity fund-growth",
              "destinationAccountNo": "101011904",
              "switchAmount": "2300.90",
              "switchOutNAV": "97.11",
              "switchInNAV": "112.11",
              "units": "111",
              "status": "Processed",
              "type": "Full"
            },
            {
              "switchOutDate": "18 Dec 2015",
              "SwitchInDate": "28 Dec 2012",
              "destinationFund": "Frnklin India Prima Plus",
              "destinationAccountNo": "101011904",
              "switchAmount": "1140.90",
              "switchOutNAV": "97.34",
              "switchInNAV": "123.11",
              "units": "120",
              "status": "Processed",
              "type": "Partial"
            }
        ],
        "fundInfo": {
          "fundName": "Franklin India Flexi Cap Fund",
          "folioNo": "1995059",
          "accountNo": "0009012",
          "modeOfHolding": "joint",
          "goal": "Wealth Creation",
          "goalDetails": "Buying a House"
        }
    }
}
	});

SwitchDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SwitchDetailsModelLookUp table, please contact admin...');
    } else {
        SwitchDetailsModelLookUp.remove({}, function(err) {
            console.log('SwitchDetailsModelLookUp collection removed');
            SwitchDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SwitchDetailsModelLookUp table, please contact admin...');
                }
                console.log('SwitchDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SwitchDetailsModelLookUp;
