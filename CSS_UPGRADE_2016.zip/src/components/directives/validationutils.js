var componentModule = angular.module('component.validationutils', []);

componentModule.directive('validateAccountNumber', function() {
    return {
        require: 'ngModel',
        link: function(scope, elm, attrs, ctrl) {
            ctrl.$parsers.unshift(function(viewValue) {
                if (viewValue) {
                    var validateAlphaNumeric = (/^['\A-Za-z0-9\s]+$/).test(viewValue);
                    ctrl.$setValidity('alphaNumeric', validateAlphaNumeric);
                    if(viewValue.split(" ").length > 1 || viewValue.split("-").length > 1) {
                        ctrl.$setValidity('validNumber', false);
                        ctrl.$setValidity('alphaNumeric', true);
                    }
                    else {
                        ctrl.$setValidity('validNumber', true);
                    }
                    return viewValue;
                }
            });
        }
    };
});

componentModule.directive('errorMessages', ['$window', 'billingConstants', function($window, billingConstants) {
    return {
        restrict: 'E',
        templateUrl: $window.UIC.sitePrefix + 'components/partials/errormessages.html',
        scope: {
            isSubmitted: '=',
            formName: '@',
            atr: '@',
            val: '=',
            isCancel: '@'
        },
        link: function(scope, elm, attrs) {
            scope.errorMsgVM = {};
            scope.errorMsgVM.messages = billingConstants.errorMsgs[scope.atr];
        }
    };
}]);

componentModule.directive('bannerMessages', ['$window', function($window) {
    return {
        restrict: 'E',
        templateUrl: $window.UIC.sitePrefix + 'components/partials/bannermessages.html',
        scope: {
            classname:'@',
            faclass:'@',
            headermsg:'@',
            pmsg:'@',
            ismaintenance: '='
        },
        link: function(scope, elm, attrs) {
        }
    };
}]);

componentModule.directive('checkNumbersOnly', function() {
    return {
        require: '?ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
            if (!ngModelCtrl) {
                return;
            }

            ngModelCtrl.$parsers.push(function(val) {
                if (angular.isUndefined(val)) {
                    var val = '';
                }

                var clean = val.replace(/[^0-9\.]/g, '');
                var decimalCheck = clean.split('.');
                if (!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0, 2);
                    clean = decimalCheck[0] + '.' + decimalCheck[1];
                }

                if (val !== clean) {
                    ngModelCtrl.$setViewValue(clean);
                    ngModelCtrl.$render();
                }
                return clean;
            });

            element.bind('keypress', function(event) {
                if (event.keyCode === 32) {
                    event.preventDefault();
                }
            });
        }
    };
});

componentModule.directive('cancelPayment', ['$window', function($window) {
    return {
        restrict: 'E',
        templateUrl: $window.UIC.sitePrefix + 'components/partials/cancelpayment.html',
        controller: modalPopupController,
        controllerAs: 'popupVM',
        bindToController: true,
        scope: {}        
    };
}]);

function modalPopupController() {
    var popupVM = this;
    popupVM.cancelHanlder = function(selection) {
        if(selection === 'continue') {
            window.location.href= window.UIC.paymentsLink;
        } else {
            angular.element('#popupModal').modal('hide');
        }
    };
}
