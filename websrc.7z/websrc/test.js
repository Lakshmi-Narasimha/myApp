var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var apiUtils = require('./api/common/apiUtils');
var app = express();

app.use(cookieParser('123456ABCDEFG'));
app.use(session({
    secret: '123456ABCDEFG',
    secure: true,
    maxAge: 1000*60*60*24,
    cookie:{
      maxAge: 1000*60*60
    },
    saveUninitialized: false,
    resave: false,
}));app.all("/admin/getAdmin", function(req, res, next) {
    console.log("get admin");
      console.log('IN CHATLINE:', req.session.chatGetMsgCounter)
    apiUtils.test(req,res);
    req.session.test = (req.session.test || 1);
    req.session.test++;
    req.session.chatGetMsgCounter = 'TTTTTTTTTTT'
    res.json(null);

})
app.all("/admin/endService", function(req, res, next) {
    console.log(req.session.test);
   console.log('IN CHATLINE:', req.session.chatGetMsgCounter)
    res.json(null);
    //apiUtils.test(req,res);
    console.log('IN CHATLINE:', req.session.chatSendMsgCounter, req.session.chatGetMsgCounter)
})

app.get("/test", function(req, res) {
    console.log("other hit");
    res.json(null);
})

var server = app.listen(8080, function() {
    console.log('Listening on port %d', server.address().port);
});
