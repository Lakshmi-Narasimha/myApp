define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'text!appmodules/contactprofile/app/templates/contactira.html',
    'text!appmodules/contactprofile/app/templates/iracontributions.html',
    'text!appmodules/contactprofile/app/templates/iradistributions.html',
    'text!appmodules/contactprofile/app/templates/iradistributiondetails.html',
    'text!appmodules/contactprofile/app/templates/iracontributiondetails.html',
    'text!appmodules/contactprofile/app/templates/iradistributionrmd.html',
    'appcommon/analytics',
    'errorLog',
    'appcommon/commonutility'
], function ($, _, Backbone, Spinner, cpCommon, Dataservice, iraTemplate, iraContributionsTemplate, iraDistributionsTemplate, iraDistributionDetailsTemplate, iraContributionDetailsTemplate, iradistributionrmdTmplt,Analytics, ErrorLog, CommonUtils) {
    var $scroller, brkgProdClsCds = CommonUtils.getBrkgProdClsCds();
    var iraView = Backbone.View.extend({
        template: _.template(iraTemplate),
        el: $("#afiacct-pg-container"), 
        id: 'afiacct-pg-container',
        events: {},
        initialize: function (args) {
            var that = this;
            this.iraType = args.iraType ?  args.iraType : "contributions";
            this.clientId = null;
            this.clientDistributions  = [];
            this.clientContributions = [];
            this.totAcctDstbAmt = [];
            this.totDetDstbAmt = [];
            this.totAcctCntbAmt = [];
            this.totDetCntbAmt = [];
            this.selectedYear = ((this.selectedYear !== null && this.selectedYear !== undefined) ? this.selectedYear : null);
            this.clearIRAGlobalParams();
        },
        attachEvents : function(){
            var that = this;
            $(document).off("click",".cp-ira-buttons").on("click",".cp-ira-buttons",function(e){
                that.showIRAType(e);
            });
            $(document).off("change","#tax-year-select").on("change","#tax-year-select",function(e){
                that.changeInTaxYear(e);
            });
            $(document).off("click", ".cp-ira-to-details").on("click", ".cp-ira-to-details", function (e) {
                that.gotodetails(e);
                CommonUtils.plDrawerToggle(e);
            });
            $(document).off("click",".ira-back-to-list").on("click",".ira-back-to-list",function(e){
                that.backToList(e);
            });
        },
        loadYears : function(){
            var _currentYear = new Date().getFullYear();
            var _element = document.getElementById('tax-year-select');
            _element.add(new Option(_currentYear,_currentYear,false,true));
            for(var i=1;i<6;i++){
                _element.add(new Option(_currentYear-i,_currentYear-i,false,false));
            }
        },
        initializeIRAView : function(params){
            var that = this;
            that.clearCollections();
            that.iraType = params.iraType ?  params.iraType : "contributions";
            $('#cp-content-container').html(this.template()).promise().done(function(){
             that.loadYears();
             that.selectedYear = (that.selectedYear ? that.selectedYear: new Date().getFullYear());
             that.getIRAGlobalParams();
             that.attachEvents();
            });
        },
        resetTaxYear : function(){
            $("#tax-year-select").val(new Date().getFullYear());
            this.selectedYear = new Date().getFullYear();
        },
        showIRAType : function(e){
            var _target = e.target || e.currentTarget;
            var _actualElement = ($(_target).parent().data("ira") ? $(_target).parent() : $(_target))
            this.iraType = _actualElement.data("ira");
            $(".cp-ira-buttons").removeClass("active");
            _actualElement.addClass("active");
            this.resetTaxYear();
            this.clearCollections();
            this.updateIRAGlobalParams();
            if(this.clientId){
                this.render(this.clientId,true);
            }
            if (this.iraType == 'distributions') {
                Analytics.analytics.recordAction('iraDistributions:clicked');
            } else {
                Analytics.analytics.recordAction('iraContributions:clicked');
            }
        },
        updateIRAGlobalParams : function(){
            $("#practicetech-subapp").data("ira-year",$("#tax-year-select").val());
            $("#practicetech-subapp").data("ira-type",$(".cp-ira-buttons.active").data("ira"));
        },
        getIRAGlobalParams : function(){
            if($("#practicetech-subapp").data("ira-year")){
                this.selectedYear = $("#practicetech-subapp").data("ira-year");
                $("#tax-year-select").val(this.selectedYear);
            }
            if($("#practicetech-subapp").data("ira-type")){
                this.iraType = $("#practicetech-subapp").data("ira-type"); 
                $(".cp-ira-buttons").removeClass("active");
                $(".cp-ira-buttons[data-ira='"+this.iraType+"']").addClass('active');
            }
        },
        clearIRAGlobalParams : function(){
            $("#practicetech-subapp").data("ira-year",null);
            $("#practicetech-subapp").data("ira-type",null);
            $("#practicetech-subapp").data("from-ira-details",false);
        },
        gotodetails: function (e) {
            var _target = $(e.currentTarget);
            var $this = $(_target);
            var selectedIndex = $this.data("index");
            var type = ($this.hasClass("goto-distdetails") ? "distribution" : "contribution");
            var openCloseDivId = 'cp-ira-details-'+selectedIndex;
            this.renderDetails(selectedIndex, type, this);

        },
        renderDetails : function(index,type,iraView){
            var that = this;
            var topopulateDivId = 'cp-ira-details-' + index;
            if (type == "distribution") {
                tmpTemplate = _.template(iraDistributionDetailsTemplate);
                $("#" + topopulateDivId).html(tmpTemplate({ "brkgProdClsCds": brkgProdClsCds, data: iraView.clientDistributions[index], disAcctVals: that.totAcctDstbAmt, disAcctDetsVals: that.totDetDstbAmt }));
            }else if (type == "contribution") {
                tmpTemplate = _.template(iraContributionDetailsTemplate);
                $("#" + topopulateDivId).html(tmpTemplate({ "brkgProdClsCds": brkgProdClsCds, data: iraView.clientContributions[index], disAcctVals: that.totAcctCntbAmt, disAcctDetsVals: that.totDetCntbAmt }));
            }   
        },
        toggleShellAndSidebar : function(action){
            if (action == "show") {
                $(".cp-common-header").show();
                $(".cp-shell-client-name").show();
                $(".household-grp-container").show();
                $(".cp-shell-menu").show();
                $(".cp-button-shell").show();
                $(".cp-shell-sidebar").show();
                $(".cp-edit-details-container").show();
                $(".ira-details-header").hide();
                if ($(window).width() < 992) {
                       $(".cp-esign-small").show();
                    }
                $(".cp-main-contain").css("max-width", "1024px");
                $("#cp-content-container").addClass("col-md-9 cp-mob-box-padding");
                $("#contact-details-page").css("margin-top", "0px");
                
            } else if (action == "hide") {
                $(".cp-common-header").hide();
                $(".cp-shell-client-name").hide();
                $(".household-grp-container").hide();
                $(".cp-edit-details-container").hide();
                if($(".cp-esign-small").is(":visible")){
                    $(".cp-esign-small").hide();
                }
                $(".cp-shell-menu").hide();
                $(".cp-button-shell").hide();
                $(".cp-shell-sidebar").hide();
                $(".ira-details-header").show();
                $(".cp-main-contain").css("max-width", "100%");
                $("#cp-content-container").removeClass("col-md-9 cp-mob-box-padding");
                $("#contact-details-page").css("margin-top", "-15px");
                $("#launchHOCBtn").addClass("hidden");
                
            }
        },
        backToList : function(){
            $("#practicetech-subapp").data("from-ira-details",true);
            Backbone.history.navigate("contactprofile/"+this.iraType,true);
        },

        changeInTaxYear : function(){
            this.clearCollections();
            this.selectedYear = $("#tax-year-select").val();
            this.updateIRAGlobalParams();
            this.getIRAGlobalParams();
            if(this.clientId){
                this.render(this.clientId,true);
            }
            Analytics.analytics.recordAction('iraTaxYear:clicked');
        },
        isKeyValInArray : function(arr,key,value){
            var _found = {present:false,index:null};
            $.each(arr, function(index, row){
                if(row && row[key] == value){
                    _found.present = true;
                    _found.index = index;
                }
            });
            return _found;
        },
        clearCollections : function(){
            this.clientDistributions  = [];
            this.clientContributions  = [];
        },
        getContributionType : function(typeCd,cntbAmt){
            var _contributionTypes = {
                    "CU" : "CURRENT YEAR CONTRIBUTION",
                    "CV" : "ROTH IRA CONVERSION",
                    "ET" : "EXTERNAL TRANSFER",
                    "IT" : "INTERNAL TRANSFER",
                    "PR" : "PRIOR YEAR CONTRIBUTION",
                    "RE" : "RECHARACTERIZATION",
                    "RO" : "ROLLOVER CONTRIBUTION",
                    "SC" : "SEP CONTRIBUTION",
                    "SD" : "SIDE FUND CONTRIBUTION",
                    "SP" : "SEP CONTRIBUTION"};
            try{
                if(cntbAmt && cntbAmt <= 0 && !typeCd){
                    return "NONE FOR TAX YEAR";
                }else{
                    return _contributionTypes[typeCd];
                }
                
            }catch(err){
                return null;
            }
            
        },
        getDistributionType : function(typeCd, distbAmt){
            var _distributionTypes = {
                    "0" : "N/A",
                    "1" : "PREMATURE DISTRIBUTION",
                    "2" : "PREMATURE EXCEPTION",
                    "3" : "DISABILITY",
                    "4" : "DEATH",
                    "5" : "PROHIBITED TRANSACTIONS",
                    "6" : "1035 EXCHANGE",
                    "7" : "RETIREMENT",
                    "8" : "EXCESS CONTRIBUTION CURRENT YR",
                    "9" : "PS58 COSTS",
                    "10" : "DIRECT ROLLOVER TO IRA",
                    "11" : "DIRECT ROLLOVER TO QUAL PLAN",
                    "12" : "EXCESS ANNUAL ADDITIONS",
                    "13" : "DEATH DIRECT ROLLOVER TO IRA",
                    "14" : "EXCESS CONT TAX CURRENT YEAR",
                    "15" : "EXCESS CONT TAX CURR EXCEPT",
                    "16" : "EXCESS CONT TAX PRIOR YEAR",
                    "17" : "LOAN DEFAULT",
                    "18" : "SIMPLE EARLY DISTRIBUTION",
                    "19" : "LOAN DEFAULT PENALTY",
                    "21" : "ROTH DISTRIBUTION",
                    "22" : "PREMATURE ROTH DISTRIBUTION",
                    "23" : "EARLY EXCP ROTH DISTRIBUTION",
                    "24" : "DISABILITY ROTH DISTRIBUTION",
                    "25" : "DEATH ROTH DISTRIBUTION",
                    "26" : "PROHIBITED ROTH DISTRIBUTION",
                    "27" : "EXCESS ROTH CONTRIBUTION",
                    "28" : "PRE EXC RTH CONTRIBUTION",
                    "32" : "ROTH CONVERSION",
                    "33" : "PREMATURE ROTH CONVERSION",
                    "34" : "EARLY EXCP ROTH CONVERSION",
                    "35" : "DISABILITY ROTH CONVERSION",
                    "36" : "DEATH ROTH CONVERSION",
                    "37" : "PROHIBITED ROTH CONVERSION",
                    "38" : "EXCESS ROTH CONVERSION",
                    "39" : "EXCESS ROTH CONVERSION PRIOR",
                    "43" : "COVERDELL ESA DISTRIBUTION",
                    "44" : "DISABILITY CESA DISTRIBUTION",
                    "45" : "DEATH CESA DISTRIBUTION",
                    "46" : "PROHIBITED COVERDELL ESA DIST.",
                    "47" : "EXCESS CESA DISTRIBUTION",
                    "48" : "PRE EXCESS CESA DISTRIBUTION",
                    "50" : "IRA RECHARACTERIZATION",
                    "51" : "PREMATURE ROTH CONVERSION",
                    "52" : "RETIREMENT ROTH CONVERSION",
                    "53" : "IRA RECHARACTERIZATION",
                    "54" : "EXCESS ROTH CONTRIB 5YR",
                    "55" : "EXCESS ROTH CONVER 5YR",
                    "56" : "ROTH 5YR AGE 59.5",
                    "57" : "ROTH 5YR DISABLED",
                    "58" : "ROTH 5YR DECEASED",
                    "59" : "CESA DISTRIBUTION TO FAMILY",
                    "60" : "CESA TO FAMILY OTHER CUST",
                    "61" : "CESA TO OTHER CUSTODIAN",
                    "87" : "EXCESS CONT YEAR BEFORE",
                    "88" : "EXCESS CONT PRIOR YEAR",
                    "99" : "NON-TAX REPORTABLE"
                };
            try{
                if(distbAmt && distbAmt <= 0 && !typeCd){
                    return "NONE FOR TAX YEAR";
                }else{
                    return _distributionTypes[parseInt(typeCd)];
                }
            }catch(err){
                return null;
            }
            
        },
        renderIRAList : function(type){
            var that = this;
            if(type == "contributions"){
                tmpTemplate = _.template(iraContributionsTemplate);
                $(".ira-page").html(tmpTemplate({ "brkgProdClsCds": brkgProdClsCds, data: this.clientContributions })).promise().done(function () {
                    window.scrollTo(0,0);
                });
                CommonUtils.logFisrtViewLoadTime("CP:Contributions", ErrorLog);
            }else{
                tmpTemplate = _.template(iraDistributionsTemplate);
                $(".ira-page").html(tmpTemplate({ "brkgProdClsCds": brkgProdClsCds, data: this.clientDistributions })).promise().done(function () {
                    window.scrollTo(0,0);
                    that.renderIRADistributionsRMD();
                });
                CommonUtils.logFisrtViewLoadTime("CP:Distributions", ErrorLog);
            }
        },
        renderIRADistributionsRMD : function(selectedYear){
            var selectedYear = (this.selectedYear ? this.selectedYear : $("#tax-year-select").val());
            var _currentYear = new Date().getFullYear(), rmdList = [], yearDifference = _currentYear-selectedYear, isInvalidYear = false;
            var rmdParsedTmpl = _.template(iradistributionrmdTmplt);
            if(selectedYear< "2015" || yearDifference>4){
                ((selectedYear< "2015") ? isInvalidYear = true: isInvalidYear = false);
                $("#ira-distribution-rmd-container").html(rmdParsedTmpl({rmdList:rmdList,isInvalidYear:isInvalidYear})).promise().done(function(){
                    $("#ira-distribution-rmd-container").removeClass("ira-adjust-flickering")
                });
            }else{
                Spinner.show();
                Dataservice.getIRADistributionRMD(this.clientId,selectedYear)
                .then(function(response){
                    
                    if(response && response[0] && response[0].clRMDAllocations){
                        if(response[0].clRMDAllocations && response[0].clRMDAllocations.length>0){
                            rmdList = response[0].clRMDAllocations;
                        }
                    }
                    for (var i = 0; i < rmdList.length; i++) {
                        var currentItem = rmdList[i];
                        var currentNull = currentItem && currentItem.planRefTxt == null && currentItem.RMDAmt == "0";
                        for (var j = i + 1; j < rmdList.length; j++) {
                            var nextItem = rmdList[j];
                            var nextNull = nextItem && nextItem.planRefTxt == null && nextItem.RMDAmt == "0";
                            if (currentNull && nextNull && currentItem.planTypCd == nextItem.planTypCd) {
                                rmdList.splice(j, 1);
                                j--;
                            }
                        }
                    }
                    $("#ira-distribution-rmd-container").html(rmdParsedTmpl({rmdList:rmdList,isInvalidYear:isInvalidYear})).promise().done(function(){
                        $("#ira-distribution-rmd-container").removeClass("ira-adjust-flickering")
                    });
                    Spinner.hide();
                })
                .fail(function(err){
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(error);
                });
            }
        },
        render: function (clientId, notResetTaxYear) {
            try{
                this.clientId = clientId;
                var that = this;
                if(!notResetTaxYear){
                    if(!$("#practicetech-subapp").data("from-ira-details")){
                        that.resetTaxYear();
                    }else{
                        $("#practicetech-subapp").data("from-ira-details",false);
                    }
                }
                var tmpTemplate = '', proceed = true; notAuthFlag = false;
                var _selectedYear = (that.selectedYear ? that.selectedYear : $("#tax-year-select").val());
                var _accountDetailsFetchCounter = 0;
                that.toggleShellAndSidebar("show");
                function fetchAccountOwnership(accountId, IRAArray,type){
                    Spinner.show();
                    Dataservice.getAccountInfo(accountId,[401])
                    .then(function(response){
                        var productCd = null;
                        if(response[0]){
                            IRAArray.accntOwnership = response[0];
                            productCd = response[0].productCd;
                        }
                        else{
                            IRAArray.accntOwnership = response;
                            IRAArray.accntOwnership.fmtId = accountId;
                            productCd = response.productCd;
                        }
                        var _carrierNum = "";
                        $.each(IRAArray.accntOwnership.accountIdentifier, function (indx, data) {
                            if (data.altAcctCtx == "ADMSRV.ACCT") {
                                _carrierNum = "CARRIER #" + data.altAcctId;
                            }

                        });
                        if (_carrierNum == "" || _carrierNum == "undefined" || _carrierNum == null) {
                            _carrierNum = "CARRIER #NA";
                        }
                        IRAArray.accntOwnership.carrierNum = _carrierNum;
                        if (IRAArray.accntOwnership.carrierNm == "" || IRAArray.accntOwnership.carrierNm == "undefined" || IRAArray.accntOwnership.carrierNm == null) {
                            IRAArray.accntOwnership.carrierNm = "CARRIER NOT AVAILABLE"
                        }
                        if(IRAArray.accntOwnership && IRAArray.accntOwnership.accountProduct){
                            if(productCd == "00221" || productCd == "00222" || productCd == "00223" || productCd == "00225" || productCd == "00235" || productCd == "00238" || productCd == "00239"){
                                IRAArray.accntOwnership.accountProduct.mediumNm = IRAArray.accntOwnership.accountProduct.mediumNm.substr(0,18)+" ("+IRAArray.accntOwnership.accountProduct.shortNm+")";
                        }
                        }
                        
                        _accountDetailsFetchCounter--;
                        if(_accountDetailsFetchCounter == 0){
                            Spinner.hide();
                            that.renderIRAList(type);
                        }
                    })
                    .fail(function(err){
                        Spinner.hide();
                        ErrorLog.ErrorUtils.prepareAndLogError(error);
                    });
                }
                
                if(this.iraType && this.iraType == "distributions"){
                        that.countAcctDstbAmt  = 0;
                        that.totAcctDstbAmt = [];
                        that.countDetDstbAmt = 0;
                        that.totDetDstbAmt = [];
                        Spinner.show();
                        Dataservice.getIRATaxDistribution(this.clientId,_selectedYear)
                        .then(function(response){
                            if(response[0].clientTxDstbAllocations && response[0].clientTxDstbAllocations.length>0){
                                $.each(response[0].clientTxDstbAllocations, function(key, row){
                                    var _found = that.isKeyValInArray(that.clientDistributions,"planTypCd",row.planTypCd);
                                    if(!_found.present){
                                        var _tmpRow = {};
                                        _tmpRow.planTypCd = row.planTypCd;
                                        _tmpRow.planDesc = row.planDesc;
                                        _tmpRow.distributionDetails = [];
                                        _tmpRow.acctTxDstbSummaries = [];
                                        _tmpRow.distributionDetails.push({dstbTypeCd:row.dstbTyp,dstbType:that.getDistributionType(row.dstbTyp,row.dstbAmt),dstbAmt:row.dstbAmt,fedWthAmt:row.fedWthAmt,stWthAmt:row.stWthAmt});
                                        that.clientDistributions.push(_tmpRow);
                                    } else {
                                        that.clientDistributions[_found.index].distributionDetails.push({ dstbTypeCd: row.dstbTyp, dstbType: that.getDistributionType(row.dstbTyp, row.dstbAmt), dstbAmt: row.dstbAmt, fedWthAmt: row.fedWthAmt, stWthAmt: row.stWthAmt });
                                    }
                                });

                                //Adding Amount for all Accounts
                                var planTypCode = 0;
                                $.each(that.clientDistributions, function (row, key) {
                                    planTypCode = that.clientDistributions[row].planTypCd;
                                    $.each(key.distributionDetails, function (i, j) {
                                        //planTypCode = that.clientDistributions[i].planTypCd;
                                        that.countAcctDstbAmt  = that.countAcctDstbAmt  + parseFloat(key.distributionDetails[i].dstbAmt);
                                    });
                                    that.totAcctDstbAmt.push([planTypCode, that.countAcctDstbAmt.toFixed(2)]);
                                    that.countAcctDstbAmt = 0; planTypCode = 0;
                                });
                                //console.log("totAcctDstbAmt: " + that.totAcctDstbAmt);
                            }else{}
                            if (response[0].acctTxDstbSummaries && response[0].acctTxDstbSummaries.length > 0) {
                                var i = 0;
                                var planTypCdVal = 0;
                                $.each(response[0].acctTxDstbSummaries, function (key, rowAccTxSummry) {
                                    if(rowAccTxSummry.acctTxDstbAllocations.results && rowAccTxSummry.acctTxDstbAllocations.results.length>0){
                                        var _found = {}, acctTxDstbSummaries = [], _txnCount = 0;
                                        $.each(rowAccTxSummry.acctTxDstbAllocations.results, function (key1, rowAccTxAlloc) {
                                            _found = that.isKeyValInArray(that.clientDistributions, "planTypCd", rowAccTxAlloc.planTypCd);
                                            planTypCdVal = rowAccTxAlloc.planTypCd;
                                            //console.log("that.clientDistributions: " + that.clientDistributions + " planTypCd " + " rowAccTxAlloc.planTypCd " + rowAccTxAlloc.planTypCd);
                                            if(!that.clientDistributions[_found.index].acctTxDstbSummaries[i]){
                                                that.clientDistributions[_found.index].acctTxDstbSummaries[i] = {};
                                                that.clientDistributions[_found.index].acctTxDstbSummaries[i].acctId = rowAccTxSummry.acctId;
                                                that.clientDistributions[_found.index].acctTxDstbSummaries[i].acctTxDstbSummaries = [];
                                                fetchAccountOwnership(rowAccTxSummry.acctId, that.clientDistributions[_found.index].acctTxDstbSummaries[i], that.iraType);
                                            }
                                            
                                            if (_found.present) {
                                                _txnCount++;
                                                var _tmpRow = {};
                                                _tmpRow.planTypCd = rowAccTxAlloc.planTypCd;
                                                _tmpRow.planDesc = rowAccTxAlloc.planDesc;
                                                _tmpRow.dstbTypeCd = rowAccTxAlloc.dstbTyp;
                                                _tmpRow.dstbType = that.getDistributionType(rowAccTxAlloc.dstbTyp,rowAccTxAlloc.dstbAmt);
                                                _tmpRow.dstbAmt = rowAccTxAlloc.dstbAmt;
                                                _tmpRow.fedWthAmt = rowAccTxAlloc.fedWthAmt;
                                                _tmpRow.stWthAmt = rowAccTxAlloc.stWthAmt;
                                                that.clientDistributions[_found.index].acctTxDstbSummaries[i].acctTxDstbSummaries.push(_tmpRow);
                                                that.countDetDstbAmt = that.countDetDstbAmt + parseFloat(_tmpRow.dstbAmt);
                                            }
                                        });
                                        
                                        if (_txnCount > 0) {
                                            _accountDetailsFetchCounter++;
                                            proceed = false;
                                        }
                                        i++;
                                    }
                                    that.totDetDstbAmt.push([planTypCdVal, that.countDetDstbAmt.toFixed(2)]);
                                    that.countDetDstbAmt = 0; planTypCdVal = 0;
                                });
                                //console.log('totDetDstbAmt:' + that.totDetDstbAmt);
                            }
                            
                            if(response[0].acctTxDstbDetails && response[0].acctTxDstbDetails.length>0){
                                $.each(response[0].acctTxDstbDetails, function(key, rowAccTxDstrb){
                                    if(rowAccTxDstrb.acctTxDstbTransactions.results && rowAccTxDstrb.acctTxDstbTransactions.results.length>0){
                                        var _found = {}, acctTxDstbTransactions = [],_dstrbtnCount=0;
                                        $.each(rowAccTxDstrb.acctTxDstbTransactions.results, function(key1, rowAccTxTrans){
                                            _found = that.isKeyValInArray(that.clientDistributions, "planTypCd", rowAccTxTrans.planTypCd);
                                            var SLI = that.isKeyValInArray(that.clientDistributions[_found.index].acctTxDstbSummaries, "acctId", rowAccTxDstrb.acctId);
                                            if (!that.clientDistributions[_found.index].acctTxDstbSummaries[SLI.index].acctTxDstbTransactions) {
                                                that.clientDistributions[_found.index].acctTxDstbSummaries[SLI.index].acctTxDstbTransactions = [];
                                            }
                                            if(_found.present){
                                                var _tmpRow = {};
                                                _tmpRow.transEfctDt = rowAccTxTrans.transEfctDt;
                                                _tmpRow.planTypCd = rowAccTxTrans.planTypCd;
                                                _tmpRow.planDesc = rowAccTxTrans.planDesc;
                                                _tmpRow.dstbTypeCd = rowAccTxTrans.dstbTyp;
                                                _tmpRow.dstbType = that.getDistributionType(rowAccTxTrans.dstbTyp,rowAccTxTrans.dstbAmt);
                                                _tmpRow.IRSCd =rowAccTxTrans.IRSCd;
                                                _tmpRow.stWthAmt = ((rowAccTxTrans.stWthAmt!= null) ? rowAccTxTrans.stWthAmt : "0");
                                                _tmpRow.fedWthAmt = ((rowAccTxTrans.fedWthAmt!= null) ? rowAccTxTrans.fedWthAmt : "0");
                                                _tmpRow.dstbAmt = rowAccTxTrans.dstbAmt;
                                                that.clientDistributions[_found.index].acctTxDstbSummaries[SLI.index].acctTxDstbTransactions.push(_tmpRow);
                                            }
                                        });

                                        if(acctTxDstbTransactions && acctTxDstbTransactions.length>0){
                                            var SLI = that.isKeyValInArray(that.clientDistributions[_found.index].acctTxDstbSummaries, "acctId", rowAccTxDstrb.acctId);
                                            that.clientDistributions[_found.index].acctTxDstbSummaries[SLI.index].acctTxDstbTransactions = acctTxDstbTransactions;
                                        }
                                    }
                                });
                            }
                            if(proceed === true){
                                Spinner.hide();
                                that.renderIRAList(that.iraType);
                            }
                        })
                        .fail(function(error){
                            Spinner.hide();
                            ErrorLog.ErrorUtils.myError(error);
                        });
                } else { //Contributions
                        that.countAcctCntbAmt = 0;
                        that.totAcctCntbAmt = [];
                        that.countDetCntbAmt = 0;
                        that.totDetCntbAmt = [];

                        Spinner.show();
                        Dataservice.getIRATaxContribution(this.clientId,_selectedYear)
                        .then(function(response){
                            if (response[0].clientTxCntbAllocations && response[0].clientTxCntbAllocations.length > 0) {
                                $.each(response[0].clientTxCntbAllocations, function(key, row){
                                    var _found = that.isKeyValInArray(that.clientContributions,"planTypCd",row.planTypCd);
                                    if(!_found.present){
                                        var _tmpRow = {};
                                        _tmpRow.planTypCd = row.planTypCd;
                                        _tmpRow.planDesc = row.planDesc;
                                        _tmpRow.contributionDetails = [];
                                        _tmpRow.acctTxCntbSummaries = [];
                                        _tmpRow.contributionDetails.push({cntbTypeCd:row.cntbTyp,cntbType:that.getContributionType(row.cntbTyp,row.cntbAmt),cntbAmt:row.cntbAmt});
                                        that.clientContributions.push(_tmpRow);
                                        //totCntbAmt = totCntbAmt + parseFloat(row.cntbAmt);
                                    }else{
                                        that.clientContributions[_found.index].contributionDetails.push({ cntbTypeCd: row.cntbTyp, cntbType: that.getContributionType(row.cntbTyp, row.cntbAmt), cntbAmt: row.cntbAmt });
                                        //totCntbAmt = totCntbAmt + parseFloat(row.cntbAmt);
                                    }
                                });

                                //Adding Amount for all Accounts
                                var planTypCode = 0;
                                $.each(that.clientContributions, function (row, key) {
                                    planTypCode = that.clientContributions[row].planTypCd;
                                    $.each(key.contributionDetails, function (i, j) {
                                        that.countAcctCntbAmt = that.countAcctCntbAmt + parseFloat(key.contributionDetails[i].cntbAmt);
                                    });
                                    that.totAcctCntbAmt.push([planTypCode, that.countAcctCntbAmt.toFixed(2)]);
                                    that.countAcctCntbAmt = 0; planTypCode = 0;
                                });
                                //console.log("totAcctCntbAmt: " + that.totAcctCntbAmt);
                            }else{}
                            if(response[0].acctTxCntbSummaries && response[0].acctTxCntbSummaries.length>0){
                                var i = 0;
                                var planTypCdVal = 0;
                                $.each(response[0].acctTxCntbSummaries, function(key, rowAccTxSummry){
                                    if(rowAccTxSummry.acctTxCntbAllocations.results && rowAccTxSummry.acctTxCntbAllocations.results.length>0){
                                        var _found = {};
                                        var acctTxCntbSummaries = [];
                                        $.each(rowAccTxSummry.acctTxCntbAllocations.results, function(key1, rowAccTxAlloc){
                                            _found = that.isKeyValInArray(that.clientContributions, "planTypCd", rowAccTxAlloc.planTypCd);
                                            planTypCdVal = rowAccTxAlloc.planTypCd;
                                            if(_found.present){
                                                var _tmpRow = {};
                                                _tmpRow.planTypCd = rowAccTxAlloc.planTypCd;
                                                _tmpRow.planDesc = rowAccTxAlloc.planDesc;
                                                _tmpRow.cntbTyp = rowAccTxAlloc.cntbTyp;
                                                _tmpRow.cntbType = that.getContributionType(rowAccTxAlloc.cntbTyp,rowAccTxAlloc.cntbAmt);
                                                _tmpRow.cntbAmt = rowAccTxAlloc.cntbAmt;
                                                acctTxCntbSummaries.push(_tmpRow);
                                                that.countDetCntbAmt = that.countDetCntbAmt + parseFloat(_tmpRow.cntbAmt);
                                            }
                                        });
                                        if(acctTxCntbSummaries && acctTxCntbSummaries.length>0){
                                            that.clientContributions[_found.index].acctTxCntbSummaries[i] = {};
                                            that.clientContributions[_found.index].acctTxCntbSummaries[i].acctTxCntbSummaries = acctTxCntbSummaries;
                                            that.clientContributions[_found.index].acctTxCntbSummaries[i].acctId = rowAccTxSummry.acctId;
                                            _accountDetailsFetchCounter++;
                                            proceed = false;
                                            fetchAccountOwnership(rowAccTxSummry.acctId,that.clientContributions[_found.index].acctTxCntbSummaries[i],that.iraType);
                                        }
                                        i++;    
                                    }
                                    that.totDetCntbAmt.push([planTypCdVal, that.countDetCntbAmt.toFixed(2)]);
                                    that.countDetCntbAmt = 0; planTypCdVal = 0;
                                });
                                //console.log("totDetCntbAmt: " + that.totDetCntbAmt);
                            }
                            if(response[0].acctTxCntbDetails && response[0].acctTxCntbDetails.length>0){
                                $.each(response[0].acctTxCntbDetails, function(key, rowAccTxCntrb){
                                    if(rowAccTxCntrb.acctTxCntbTransactions.results && rowAccTxCntrb.acctTxCntbTransactions.results.length>0){
                                        var _found = {};
                                        var acctTxCntbTransactions = [];
                                        $.each(rowAccTxCntrb.acctTxCntbTransactions.results, function(key1, rowAccTxTrans){
                                            _found = that.isKeyValInArray(that.clientContributions,"planTypCd",rowAccTxTrans.planTypCd);
                                            if(_found.present){
                                                var _tmpRow = {};
                                                _tmpRow.transEfctDt = rowAccTxTrans.transEfctDt;
                                                _tmpRow.planTypCd = rowAccTxTrans.planTypCd;
                                                _tmpRow.planDesc = rowAccTxTrans.planDesc;
                                                _tmpRow.cntbTyp = rowAccTxTrans.cntbTyp;
                                                _tmpRow.cntbType = that.getContributionType(rowAccTxTrans.cntbTyp,rowAccTxTrans.cntbAmt);
                                                _tmpRow.cntbAmt = rowAccTxTrans.cntbAmt;
                                                acctTxCntbTransactions.push(_tmpRow);
                                            }
                                            //totAcctCntbAmt = totAcctCntbAmt + parseFloat(rowAccTxTrans.cntbAmt);
                                        });
                                        if(acctTxCntbTransactions && acctTxCntbTransactions.length>0){
                                            var SLI = that.isKeyValInArray(that.clientContributions[_found.index].acctTxCntbSummaries,"acctId",rowAccTxCntrb.acctId);
                                            that.clientContributions[_found.index].acctTxCntbSummaries[SLI.index].acctTxCntbTransactions = acctTxCntbTransactions;
                                        }
                                    }
                                });
                            }
                            
                            if(proceed === true){
                                Spinner.hide();
                                that.renderIRAList(that.iraType);
                            }

                            //if (totAcctCntbAmt != totCntbAmt) { notAuthFlag = true; } else { notAuthFlag = false; }

                        })
                        .fail(function(error){
                            Spinner.hide();
                            ErrorLog.ErrorUtils.prepareAndLogError(error);
                        });
                }
                $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                $(".hdr-tab-buttons-wrap .bt-"+that.iraType).addClass("hdr-tab-active");
            }catch(error){
                ErrorLog.ErrorUtils.myError(error);
            }
            
        }
    });
    return iraView;
});