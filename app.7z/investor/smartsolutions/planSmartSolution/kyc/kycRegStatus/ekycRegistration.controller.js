/**
 * @ngdoc property
 * @name ekycRegistrationCtrl Controller
 * @requires $scope
 * @description
 *
 * - 
 *
 **/


 'use strict';
// Controller naming conventions should start with an uppercase letter
function ekycRegistrationCtrl($scope) {    
	console.log("ekycRegistration controller");	
}

ekycRegistrationCtrl.$inject = ['$scope'];
module.exports = ekycRegistrationCtrl;