/**
 * @ngdoc directive
 * @name selectFundGrid
 * @requires 
 * @requires 
 * @requires 
 * @requires 
 * @requires 
 * @description
 *
 **/
'use strict';
var selectFundGrid = function(selectFundInitialLoader, transactEventConstants, selectFundModel,transactModel,$timeout,fundGridConfig,$stateParams,$state,TransactConstant,newFundDetailsModel,SipModifyDetailModel, fundDetails,transactNowModel,$filter, selectFundGridFactory, authenticationService,$uibModal,fticCancelStpFundDetailsModel, transactConstants, toaster,truncateTextService) {
  return{
        template: require('./selectFundGrid.html'),
        restrict: 'E',
        replace: true,
        scope: {
        },
        controller :['$scope', function($scope){  
            var index = "";
            var _stateUrl = "";
            var editIconChanged = false;
            var transactType = transactModel.getTransactType();
            var indexValue = "";
            var _userType = authenticationService.getUser().userType;
            var $translate = $filter('translate');
            $scope.selectedFund = null;
            $scope.isReload = false;
            $scope.config = {};
            $scope.config.showNotification = false;
            $scope.presentState = $state.current.name;
            var datefilter = $filter('date');
            $scope._gridConfig = {};
            
            /**
             * Code Added for pagination of grid - Defect #3994 - Start
             */
            var configureGrid = function() {
              $scope._gridConfig.enablePagination = true;
              $scope._gridConfig.recordsPerPage = 5;
            };

            configureGrid();
            /**
             * Code Added for pagination of grid - Defect #3994 - End
             */

            $scope.$on('DIFFERENT_INVESTOR_CONTINUE',function(){
              $scope.isReload = false;
              index = "";
              transactModel.resetForm = false;
            });

            var eventHandler = $scope.$on(transactEventConstants.transact.INV_FUND_DETAILS, function(event,data){
              $scope.selectFundData = null;
              $scope.selectedFund = null;
              $scope.isReload = false;
              $scope.isGridDataRefresh = true;
              checkPreviousState();
              if(!$stateParams.key)
              {
                index = "";
              }
              if($stateParams.key === "Fund"){
                transactModel.resetForm = true;
              }
              if($stateParams.key)
              {
                $stateParams.key = null;
              }else{
                editIconChanged = false;
              }
              $scope.selectFundData = [];
              index = ""; 
              $timeout(function() {
              //  debugger;
                setGridConfig();

                if ($scope.presentState === "transact.base.modifysip" || $scope.presentState === "transactnow.baseNow.renewSip" ||  $scope.presentState === "invTransact.base.renewsip" || $scope.presentState === "invTransact.base.modifysip"){

                  //$scope.selectFundData = newFundDetailsModel.getExistingFundDetails();
                  $scope.selectFundData = SipModifyDetailModel.getModifySipInpDetails();
                  truncateTextService.updateLabel($scope.selectFundData, 'fund', 54);
                  for(var i=0;i<$scope.selectFundData.length;i++) {
                    var startDateSplit = $scope.selectFundData[i].sipStartDate.split("/");
                    var endDateSplit = $scope.selectFundData[i].sipEndDate.split("/");
                    $scope.selectFundData[i].startDateField = datefilter(new Date(startDateSplit[2],startDateSplit[1]-1,startDateSplit[0]),'dd MMM yyyy');
                    $scope.selectFundData[i].endDateField = datefilter(new Date(endDateSplit[2],endDateSplit[1]-1,endDateSplit[0]),'dd MMM yyyy');
                  }
                  /**
                  * Condition adding for renewsip to handle edit from review and confirm page - start
                  */

                  if(transactModel.getFundDetails()) {
                      setExistingData();
                      editIconChanged = true;
                    }
                    setGridConfig();

                  /**
                  * Condition adding for renewsip to handle edit from review and confirm page - End
                  */

                } 
                else {
                  if ((transactModel.resetForm || transactModel.INV_FOLIO_EDIT_FLAG)) { //Condition added for Investor to persist data from folio to selectfund
                    $scope.selectFundData = ($scope.presentState === "invTransact.base.cancelStp" ? fticCancelStpFundDetailsModel.getSelectFundGridDtls() : selectFundModel.getSelectFundGridDtls());
                    truncateTextService.updateLabel($scope.selectFundData, 'fund', 47);
                    if (transactModel.getFundDetails()) {
                      setExistingData();
                      editIconChanged = true;
                    }
                    setGridConfig();
                  } else {
                    $scope.selectFundData = ($scope.presentState === "invTransact.base.cancelStp" ? fticCancelStpFundDetailsModel.getSelectFundGridDtls() : selectFundModel.getSelectFundGridDtls());
                    /**
                     * Added 'transactModel.showFundsOnNo' condition to get selected data on no change in Inv preference - Start - Defect #3542
                     */
                     truncateTextService.updateLabel($scope.selectFundData, 'fund', 47);
                    if (transactModel.isSameInv || transactModel.showFundsOnNo) {
                      if (transactModel.getFundDetails()) {
                        setExistingData();
                        editIconChanged = true;
                      }
                      setGridConfig();
                    }
                    
                    /**
                     * Added 'transactModel.showFundsOnNo' condition to get selected data on no change in Inv preference - End - Defect #3542
                     */
                  }
                }

                
               
                 
                for(var i=0;i<$scope.selectFundData.length;i++) {
                    $scope.selectFundData[i].index = ""+(i+1);
                }
                $scope.isReload = true;
              }, 0);
            });

            function setExistingData(){
              index = transactModel.getFundDetails().index;
              $scope.isGridDataRefresh = false;
              $timeout(function(){ 
                $scope.selectedFund = transactModel.getFundDetails();
              },0);
            }

            function checkPreviousState(){
              if($stateParams.key === TransactConstant.transact.Fund_Key)
              {
                setExistingData();
                editIconChanged = true;
              }
            }
            
            function setGridConfig() {
               if ($scope.presentState === "transact.base.modifysip" || $scope.presentState === "invTransact.base.modifysip"){
                  var statusTemplateModify = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}"  name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'
                  /*var statusTemplateRenew = '<input type="radio" name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'*/
                 
                   $scope.columnDefs =  [{ field: 'fund', displayName: '',value: index, width:"48",cellTemplate: statusTemplateModify, pinnedLeft:true},
                     { field: 'fundOptionDesc', displayName: 'Fund', width:"200", enableSorting:false, pinnedLeft:true},
                      { field: 'accountNumber', displayName: 'Account No.', width:"150", enableSorting:false},
                      { field: 'startDateField', displayName: 'SIP Start Date', width:"163", enableSorting:false},
                      { field: 'endDateField', displayName: 'SIP End Date', width:"127", enableSorting:false},
                      { field: 'amount', displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon text-right',cellClass: 'text-right',width:"127", enableSorting:false},
                      { field: 'frequency', displayName: 'Frequency', width:"127", enableSorting:false},
                      { field: 'stepUpAmount', displayName: 'Step Up', headerCellClass: 'fti-grid-rupeeIcon text-right',cellClass: 'text-right',width:"127", enableSorting:false}
                  ]; 
                } else if($scope.presentState === "transactnow.baseNow.renewSip"){
                  var statusTemplateRenew = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}"  name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'

                  $scope.columnDefs =  [{ field: 'fund', displayName: '',value: index, width:"48",cellTemplate: statusTemplateRenew, pinnedLeft:true},
                     { field: 'fundOptionDesc', displayName: 'Fund', width:"200", enableSorting:false, pinnedLeft:true},
                      { field: 'accountNumber', displayName: 'Account No.', width:"150", enableSorting:false},
                      { field: 'startDateField', displayName: 'SIP Start Date', width:"163", enableSorting:false},
                      { field: 'endDateField', displayName: 'SIP End Date', width:"127", enableSorting:false},
                      { field: 'amount', displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon text-right',cellClass: 'text-right',width:"127", enableSorting:false},
                      { field: 'frequency', displayName: 'Frequency', width:"127", enableSorting:false},
                      { field: 'sipStatusDesc', displayName: 'Status',width:"127", enableSorting:false}
                  ];
                }
                 else if( $scope.presentState === "invTransact.base.renewsip"){
                  var statusTemplateRenew = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}"  name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'

                  $scope.columnDefs =  [{ field: 'fund', displayName: '',value: index, width:"48",cellTemplate: statusTemplateRenew, pinnedLeft:true},
                     { field: 'fundOptionDesc', displayName: 'Fund', width:"200", enableSorting:false, pinnedLeft:true},
                      { field: 'accountNumber', displayName: 'Account No.', width:"150", enableSorting:false},
                      { field: 'startDateField', displayName: 'SIP Start Date', width:"163", enableSorting:false},
                      { field: 'endDateField', displayName: 'SIP End Date', width:"127", enableSorting:false},
                      { field: 'amount', displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon text-right',cellClass: 'text-right',width:"127", enableSorting:false},
                      { field: 'frequency', displayName: 'Frequency', width:"127", enableSorting:false},
                      { field: 'sipStatusDesc', displayName: 'SIP Status',width:"127", enableSorting:false}
                  ];
                }
                else if($scope.presentState === "invTransact.base.cancelStp"){
                  var statusTemplateRenew = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}"  name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'

                  $scope.columnDefs =  [{ field: 'fund', displayName: '',value: index, width:"48",cellTemplate: statusTemplateRenew, pinnedLeft:true},
                     { field: 'sourceFundDesc', displayName: 'Source Fund', width:"200", enableSorting:false},
                      { field: 'sourceAccNo', displayName: 'Account No.', width:"150", enableSorting:false},
                      { field: 'destFundDesc', displayName: 'Destination Fund', width:"200", enableSorting:false},
                      { field: 'destAccNo', displayName: 'Account No.', width:"150", enableSorting:false},
                      { field: 'startDate', displayName: 'STP Start Date', width:"163", enableSorting:false},
                      { field: 'endDate', displayName: 'STP End Date', width:"127", enableSorting:false},
                      { field: 'frequency', displayName: 'Frequency', width:"127", enableSorting:false},
                      { field: 'amount', displayName: 'STP Amount', headerCellClass: 'fti-grid-rupeeIcon text-right',cellClass: 'text-right',width:"127", enableSorting:false}                   
                    
                  ];
                }
                else{
                  var statusTemplateTransact = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}" name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>';
                  var cellTemplateForNa = '<div class="ui-grid-cell-contents">{{grid.getCellValue(row, col) | fticNACheck}}</div>';
                  var fundTitle = "Fund";
                 if($state.current.url === "/switch" || $state.current.url === "/dtp"){
                    _stateUrl =$state.current.url;
                    fundTitle = "Source Fund";
                  }else if($state.current.url === "/stp" ){
                    var statusTemplateTransact = '<input type="radio" ng-model = "col.colDef.value" ng-value = "{{row.entity.index}}" name="selectedfundList" ng-disabled="row.entity.status !== \'A\' ? true : false" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>';
                    _stateUrl =$state.current.url;
                    fundTitle = "Source Fund";
                  }else{
                    fundTitle = "Fund";
                  }

                  $scope.columnDefs =  selectFundGridFactory.getColumnDefs(_userType, statusTemplateTransact, fundTitle, index,_stateUrl,cellTemplateForNa);
                } 
            }  

            $scope.$on(transactEventConstants.transact.Selected_Investor, function() {
              if(transactModel.isDataResetFund && authenticationService.isInvestorLoggedIn()) {
                transactModel.setFundDetails('');
              }
            });
            
            /**
             * Added to reset fund on change of Investment pref: Defect #3542 - Start
             */
            $scope.$on('RESET_FUND_ON_CALL', function() {
              transactModel.setFundDetails('');
            });
            /**
             * Added to reset fund on change of Investment pref: Defect #3542 - End
             */

            $scope.$on(transactEventConstants.transact.TRANS_SELECT_FUND, function (event, args) {                 
              indexValue = args.index;                
              $scope.selectedFund = args;
             /*   if(editIconChanged) {
                    if(indexValue!==transactModel.getFundDetails().index) {
                        // editIconChanged = false;
                        $scope.config.showNotification = true;                              
                    }else{
                      transactModel.resetForm = false;
                    }
                } */
                        
            });  
            var fundFormStatus;
            $scope.result = null;
           var loadNextSection = function () {

              if ($state.current.name == 'transactnow.baseNow.renewSip') {
                fundDetails.removeFundDetails();
                fundDetails.setFundDetails($scope.selectedFund);
                transactModel.setTransactType(TransactConstant.guest.SELECTSIP);
                $scope.$emit(transactEventConstants.transact.Show_Fund);
              }else if($state.current.name == 'invTransact.base.renewsip'){
                fundDetails.removeFundDetails();
                fundDetails.setFundDetails($scope.selectedFund);
                transactModel.setTransactType(TransactConstant.renewSip.RENEWSIP);
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                
              } 
              else if ($state.current.name == 'transact.base.redeem' || $state.current.name == 'invTransact.base.redeem') {
                  if (!authenticationService.isInvestorLoggedIn()) {
                      if (transactModel.resetForm) {
                          $scope.$emit(transactEventConstants.transact.RESET_REDEEM_FORM);
                      }
                  } else {
                      fundFormStatus = !transactModel.resetForm;
                      fundFormStatus = ($scope.result && !$scope.isGridDataRefresh ? false : ($scope.result ? false : fundFormStatus));
                      $scope.$emit(transactEventConstants.transact.RESET_REDEEM_FORM, fundFormStatus);
                  }
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                $scope.$emit("Select_Fund_Continue");
              } else if ($state.current.name == 'transact.base.swp' || $state.current.name == 'invTransact.base.swp') {
                $scope.$emit(transactEventConstants.transact.RESET_SWP_FORM);
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                $scope.$emit("Select_Fund_Continue");
              } else if ($state.current.name == 'transact.base.stp' || $state.current.name == 'invTransact.base.stp') {
                $scope.$emit(transactEventConstants.transact.RESET_STP_FORM);
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                $scope.$emit("Select_Fund_Continue");
              }
              else if ($state.current.name == 'transact.base.switch') {
                $scope.$emit(transactEventConstants.transact.RESET_SWITCH_FORM);
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                $scope.$emit("Select_Fund_Continue");
              }
              else if ($state.current.name == 'invTransact.base.cancelStp' && authenticationService.isInvestorLoggedIn()) {
                fundDetails.removeFundDetails();
                fundDetails.setFundDetails($scope.selectedFund);
                if ($scope.selectedFund.alertFlag === "Y") {
                  var modalInstanceCancelSTP;
                  modalInstanceCancelSTP = $uibModal.open({
                    template: require('./cancelStpPopup/cancelStpPopup.html'),
                    scope: $scope
                  });
                }
                else {
                  $scope.$emit(transactEventConstants.transact.INV_TRANSACT_CSTP_REVIEW);
                }
              } else if ($state.current.name == 'invTransact.base.dtp' && authenticationService.isInvestorLoggedIn) {
                transactModel.setTransactType("dtp");
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                $scope.$emit("Select_Fund_Continue");
              }else if($state.current.name === 'invTransact.base.modifysip' && authenticationService.isInvestorLoggedIn) {
                  transactModel.setTransactType(TransactConstant.modifySip.MODIFYSIP);
                  $scope.$emit(transactEventConstants.transact.Show_Fund);
                  $scope.$emit("Select_Fund_Continue");                 
               }
              else {
                $scope.$emit(transactEventConstants.transact.Show_Fund);
                $scope.$emit("Select_Fund_Continue");

              }
            };

            $scope.$on('yes', function () {
              $scope.config.showNotification = false;
              transactModel.resetForm = false;
              transactModel.setFundDetails($scope.selectedFund); // Added - Investor
              loadNextSection();//Added -Investor 
              transactModel.STP_MAIN_FLAG = false;          
            });

            $scope.$on('no', function () {
                $scope.config.showNotification = false;
                transactModel.resetForm = false;
                index = transactModel.getFundDetails().index;                  
                $scope.selectedFund = transactModel.getFundDetails();
                
                setGridConfig()
                $timeout(function(){
                  $scope.isReload = false;                
                },0)
                $timeout(function(){
                  $scope.isReload = true;
                },0)              
                            
            });

            $scope.$on(transactEventConstants.transact.Edit_Fund_Button_Clicked, function (event, args) { 
              if ($scope.presentState !== "transact.base.modifysip" || $scope.presentState !== "invTransact.base.modifysip"){
                  setExistingData();
              }
              editIconChanged = true;   
            });
      

            $scope.SFContnuBtn = function($event){

              if($state.current.url === '/swp') {
                if($filter('removeComma')($scope.selectedFund.marketValue) < transactConstants.swp.MIN_SWP_SELECT_FUND) {
                  
                  toaster.error($translate(transactConstants.swp.MIN_SWP_SELECT_FUND_ERR_MSG));
                  return;
                }
              }
              selectFundInitialLoader.setSelectFundDtls(selectFundGridFactory.getFormattedFundDetails(_userType, $scope.selectedFund));
              transactNowModel.hasSelectSipData = true;
              var previousData = angular.copy(transactModel.getFundDetails());
              console.log($scope.selectedFund);
              //transactModel.setFundDetails($scope.selectedFund); // Removed - Investor - Not working proper with this line
              var result = _.isEqual(previousData, angular.copy($scope.selectedFund));
              $scope.result = result;
              // var fundFormStatus = !transactModel.resetForm;
              // console.log($state);
              if(!result && previousData){
                 transactModel.resetForm = true;
                 transactModel.STP_MAIN_FLAG = false; //Added for a fix to work with investor
                 $scope.config.showNotification = true;
                 transactModel.resetForm = true;
              }else {
                /** Added code For Investor - Start - To work with SWP */
                 transactModel.setFundDetails($scope.selectedFund);
                 if(previousData && angular.copy($scope.selectedFund)) {
                    transactModel.SWP_MAIN_FLAG = true;
                    transactModel.STP_MAIN_FLAG = true; //Added for a fix to work with investor
                    $scope.$emit('FUND_SELECTION_UNCHANGED');
                    loadNextSection(); //Added - Investor
                 } else {
                   loadNextSection(); //Added - Investor 
                 }
                 /** Added code For Investor - END - To work with SWP */
              }
              $scope.$emit("sipdetailsview");
            }
            var destroyHandler = function(){
              eventHandler();  
            }
        }]
    }
};

selectFundGrid.$inject = ['selectFundInitialLoader','transactEventConstants','selectFundModel','transactModel','$timeout','fundGridConfig','$stateParams','$state','TransactConstant','newFundDetailsModel','SipModifyDetailModel', 'fundDetails','transactNowModel','$filter', 'selectFundGridFactory', 'authenticationService','$uibModal','fticCancelStpFundDetailsModel', 'transactConstants', 'toaster','truncateTextService'];
module.exports = selectFundGrid;