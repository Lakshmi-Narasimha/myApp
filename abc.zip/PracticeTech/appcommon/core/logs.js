﻿define([

], function (  ) {
    /* Log Management*/
    var log = function () { };
    log.prototype.logList = [];
    log.prototype.addEntry = function (entry) {

        /* we can be opinoinated for freeformed here.  Freemored Errors are nice on the FE
            can also conditionally handle errors in a way specific to core, while leaving opinions out of PTs ErrorLogging Object
        */
        // entry = entry || "";
        // entry.time = entry.time

        this.logList.push(entry)
    }
    log.prototype.flush = function () {
        this.logList = [];
    }
    return log;
})