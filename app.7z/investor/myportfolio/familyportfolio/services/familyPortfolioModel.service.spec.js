'use strict';
describe('Services: family portfolio model service', function() {
	var familyPortfolioModel,httpBackend,$window,Restangular,$q,deferred,scope,fetchFamilyPFListPromise,acceptOrRejectOrRemoveFamilyPFReqPromise ;
	
	var familyPFList = {
	  "pending": [
	    {
	      "custName": "Priya Venkatesh",
	      "refId": "345"
	    },
	    {
	      "custName": "GiriBabu",
	      "refId": "342"
	    }
	  ],
	  "approved": [
	    {
	      "currentValue": "6,50,000.00",
	      "currentCost": "2,50,000.00",
	      "pan": "ABAPL1235C",
	      "custName": "Shankar Narayan"
	    },
	    {
	      "currentValue": "6,50,000.00",
	      "currentCost": "2,50,000.00",
	      "pan": "ABAPL1235D",
	      "custName": "Gayatri Narayan"
	    }
	  ],
	  "primaryPan": "ABAPL1235D"
	};

	var failureResponse =  [{
                    'errorCode': 'E123',
                    'errorDescription': 'Something went wrong...'
                }];

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.myportfolio'));

	beforeEach(inject(function(_familyPortfolioModel_,$httpBackend,_$q_,_$window_,_Restangular_,$rootScope){		
		familyPortfolioModel = _familyPortfolioModel_;
		scope =$rootScope.$new();
		httpBackend = $httpBackend;		
		Restangular =_Restangular_;		
		$q = _$q_;		

		$window = _$window_;
        $window.ga = function() {};
	}));	

	it("fetchFamilyPFList should be defined",function(){
		expect(familyPortfolioModel.fetchFamilyPFList).toBeDefined();
	});

	it("acceptOrRejectOrRemoveFamilyPFReq should be defined",function(){
		expect(familyPortfolioModel.acceptOrRejectOrRemoveFamilyPFReq).toBeDefined();
	});

	describe("fetchFamilyPFList promise",function(){
		beforeEach(inject(function() {
			spyOn(Restangular, 'one').and.callThrough();
			fetchFamilyPFListPromise = familyPortfolioModel.fetchFamilyPFList();	
		}));

		it("should resolve promise when success",function(done){		
			httpBackend.expectGET('http://localhost:3030/profile/familyPortfolio?guId=878').respond(familyPFList);
			fetchFamilyPFListPromise.then(function(response){						
				expect(response.primaryPan).toContain("ABAPL1235D");
				done();
			});
			
			expect(Restangular.one).toHaveBeenCalledWith('/profile/familyPortfolio');
			httpBackend.flush();
		});

		it("fetchFamilyPFList should reject promise when failure",function(){
			httpBackend.expectGET('http://localhost:3030/profile/familyPortfolio?guId=878').respond(400,failureResponse);
			fetchFamilyPFListPromise.then(function(response){						
				expect(response.errorCode).toContain("E123");			
			});
			
			expect(Restangular.one).toHaveBeenCalledWith('/profile/familyPortfolio');
			httpBackend.flush();
		});
	});
	
	it('should retrive financialTransactionData data using getter', function() {        	
       familyPortfolioModel.setFamilyPFList(familyPFList);             
       expect(familyPortfolioModel.getFamilyPFList().primaryPan).toEqual("ABAPL1235D");
    });

    describe("acceptOrRejectOrRemoveFamilyPFReq promise",function(){
		beforeEach(inject(function() {
			spyOn(Restangular, 'one').and.callThrough();
			acceptOrRejectOrRemoveFamilyPFReqPromise = familyPortfolioModel.acceptOrRejectOrRemoveFamilyPFReq({"guId":"878"});	
		}));

		it("should resolve promise when success",function(done){		
			httpBackend.expectGET('http://localhost:3030/profile/accessFamilyPortfolio?guId=878').respond(200,"success");
			acceptOrRejectOrRemoveFamilyPFReqPromise.then(function(response){						
				expect(response).toContain("success");
				done();
			});
			
			expect(Restangular.one).toHaveBeenCalledWith('/profile/accessFamilyPortfolio');
			httpBackend.flush();
		});

		it("fetchFamilyPFList should reject promise when failure",function(){
			httpBackend.expectGET('http://localhost:3030/profile/accessFamilyPortfolio?guId=878').respond(400,failureResponse);
			acceptOrRejectOrRemoveFamilyPFReqPromise.then(function(response){						
				expect(response.errorCode).toContain("E123");			
			});
			
			expect(Restangular.one).toHaveBeenCalledWith('/profile/accessFamilyPortfolio');
			httpBackend.flush();
		});
	});
});