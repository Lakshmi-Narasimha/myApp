import { ModuleWithProviders } from '@angular/core';
export declare class ButtonsModule {
    static forRoot(): ModuleWithProviders;
}
