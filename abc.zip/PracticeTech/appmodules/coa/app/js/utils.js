define(
		[ 'spinner','errorLog' ],
		function(Spinner,ErrorLog) {
			var _ = {

				setCustomHeader : function(xhr, maxAge) {
					if (maxAge != undefined) {
						xhr.setRequestHeader('cache-control', 'max-age='
								+ maxAge);
					} else {
						xhr.setRequestHeader('cache-control', 'max-age=0');
					}

				},
				lockForm : function() {
					Spinner.show();

				},
				unlockForm : function() {
					Spinner.hide();
				},
				put : function(url, data, successHandler, errorHandler, maxAge,
						headers) {
					var res = _send('PUT', url, "application/json", data,
							successHandler, errorHandler, maxAge, headers);
					return res;
				},
				post : function(url, data, successHandler, errorHandler,
						maxAge, headers, processData, xhr1) {
					var res = _send('POST', url, ((xhr1 != ""
							&& xhr1 != undefined && xhr1 != null) ? false
							: "application/json"), data, successHandler,
							errorHandler, maxAge, headers, processData, xhr1);
					return res;
				},
				get : function(url, data, successHandler, errorHandler, maxAge,
						headers) {
					var res = _send('GET', url, "application/json", data,
							successHandler, errorHandler, maxAge, headers);
					return res;
				},
				_delete : function(url, data, successHandler, errorHandler,
						maxAge, headers) {
					var res = _send('DELETE', url, "application/json", data,
							successHandler, errorHandler, maxAge, headers);
					return res;
				},
				capitalize : function(string) {
					return string.charAt(0).toUpperCase()
							+ string.substring(1).toLowerCase();
				},
				lowerCase : function(string) {
					return string.toLowerCase();
				},
				readCookie : function(name) {
					var nameEQ = name + "=";
					var ca = document.cookie.split(';');
					for ( var i = 0; i < ca.length; i++) {
						var c = ca[i];
						while (c.charAt(0) == ' ')
							c = c.substring(1, c.length);
						if (c.indexOf(nameEQ) == 0) {
							var _substring = decodeURIComponent(c.substring(
									nameEQ.length, c.length));
							return _substring;

						}
					}
					return null;
				},
				isMobile : function() {
					var _regxMob = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
					return _regxMob.test(navigator.userAgent);
				},
				showSystemUnavailabelError : function(error,hidePopup,customMessage) {
					window.scrollTo(0,0);
					this.unlockForm();
					$(".coa-system-error").addClass("hidden");
					var _$errorCtnr = $('.coa-alert-row:first');
					var _$errorHeader = _$errorCtnr.find('.pt-alert-msg-header'), _$errorDesc = _$errorCtnr.find('.pt-aleert-error-text');
					if (error && error.status != null && error.status != undefined && error.status == "401") {
					    _$errorHeader.text("Unauthorized access");
					    _$errorDesc.text("You are not authorized to use this application. Contact the Technology Service Desk at 1.877.444.3375 to request access.");
					} else {
					    _$errorHeader.text("System unavailable");
					    _$errorDesc.text("The system is currently unavailable. Please try again later.");
					}
					_$errorCtnr.removeClass('hidden');
					if(error){
					    _.logError(error,hidePopup,customMessage);
					}
					
					
				},
				showSystemWarningError: function () {
				    _.hideSystemUnavailabelError();
				    $('.coa-warning-msg-container').removeClass("hidden");
				},
				hideSystemUnavailabelError : function() {
					$('.coa-alert-row').addClass('hidden');

				},
				logError : function(error,hidePopup,customMessage) {
					if(customMessage){
					ErrorLog.ErrorUtils.myError(error,true);
					}else{
						ErrorLog.ErrorUtils.prepareAndLogError(error,true);
					}
				
				},
				showAlert : function(msg) {
					$('#coa-alert-dialog-msg').html(msg);
					$('#coa-alert-modal').modal('show');
				},
				getJson : function(url, data, successHandler, errorHandler) {
					$.ajax({
						type : 'GET',
						dataType : "json",
						url : url,
						success : function(resp) {
							successHandler(resp);
						},
						error : function(resp) {
							successHandler(JSON.parse(resp));
						}
					});
				},
				iOSversion : function() {
					if (/iP(hone|od|ad)/.test(navigator.userAgent)) {
						var v = (navigator.appVersion)
								.match(/OS (\d+)_(\d+)_?(\d+)?/);
						return parseInt(v[1], 10);
					}
				},
				getConfigProperty : function(prop) {
					return config[prop] ? config[prop] : "";
				},
				setConfigProperty : function(prop, val) {
					config[prop] = val;
				}

			};
			var config = {
				API_COMMON_DATA_BODY : {
					$format : 'json'
				}
			};
			function _send(type, url, contentType, data, successHandler,
					errorHandler, maxAge, headers, processData, xhr1,
					retryCount) {
				headers = headers || {};
				headers = $.extend(headers, {
					'cache-control' : 'no-cache'

				});

				var response = $
						.ajax({
							cache : false,
							type : type,
							url : url,
							processData : ((processData != null && processData != undefined) ? processData
									: true),
							headers : headers,
							contentType : contentType,
							
							data : data,
							dataType : "json",
							success : function(res, ab, c) {
							    successHandler(res, ab, c);
							},
							xhr : ((xhr1 != null && xhr1 != undefined) ? xhr1
									: function() {
										return jQuery.ajaxSettings.xhr();
									}),
							error : function(jqXHR, textStatus, errorThrown) {
								if (errorHandler) {
									errorHandler(jqXHR, textStatus,
											errorThrown);
								} else {
									_genericErrorHandler(jqXHR, textStatus,
											errorThrown);
								}
							

							}

						});
				return response;

			}
			function _genericErrorHandler(xhr, text, status) {
				if (text == "timeout") {
					_.showAlert('System Unavailable.<br/>The system is currently unavailable.  Please try again later.');
				} else {
					_.showAlert('System Unavailable.<br/>The system is currently unavailable.  Please try again later.');
					
				}
			}
			return _;

		});
