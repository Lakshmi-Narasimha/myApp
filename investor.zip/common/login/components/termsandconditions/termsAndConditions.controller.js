/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function termsAndConditionsController($scope, $uibModalStack,loginModelService,constants) { 


   
    
    console.log($scope.chkTnCs+"checkvalueinmodel");
    $scope.accpted=false;
    $scope.accept=function(){
    	
    	//loginModelService.setChoosenOptionData($scope.accpted);
    	$scope.$emit('accptedTermsAndConditions');
    	console.log($scope.chkTnCs+"checkvalueinmodelafterclick");
    	$scope.closeModal();
    }
    $scope.doNotAccept=function(){
$scope.$emit('rejectedTermsAndConditions');
    	$scope.closeModal();
    }
     $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
    
}


termsAndConditionsController.$inject = ['$scope', '$uibModalStack','loginModelService','constants'];

module.exports = termsAndConditionsController;