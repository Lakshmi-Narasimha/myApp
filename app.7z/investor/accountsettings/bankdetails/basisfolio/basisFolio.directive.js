/**
 * @ngdoc directive
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires investorConstants
 * @description
 *
 * - It displays error
 * 
 **/
'use strict';

var basisFolio = function(investorConstants, basisFolioModel, investorEventConstants, basisFolioInitialLoader) {
    return {
        template: require('./basisFolio.html'),
        replace: true,
        scope: true,
        controller: function($scope, $filter) {
            var INV_BF_INFO = $filter('translate')(investorEventConstants.accountSettings['INV_BF_INFO']);
            $scope.gridData = [];

            var params = {};
            params.guId = '878';
            basisFolioInitialLoader.loadAllServices($scope, params);
            $scope.$on(INV_BF_INFO,  function(event, data){
            	var data = basisFolioModel.getbasisfoliodetails().basisFolioDetails;
            	_.each(data, function(basisFolioDetails) {
	                var gridRow = {};
	                gridRow.folioNo = basisFolioDetails.folioNo;
	                gridRow.fundName = basisFolioDetails.fundName;
	                gridRow.folioAccountNo = basisFolioDetails.folioAccountNo;
	                gridRow.bankDetails = basisFolioDetails.bankDetails;
	                gridRow.payType = basisFolioDetails.payType;
	                gridRow.ifscCode = basisFolioDetails.ifscCode;
	                $scope.gridData.push(gridRow);
            	});
            });

            $scope.columnDefs = [{ field: 'folioNo', displayName: 'Folio No.', width: '104', pinnedLeft: true },
                { field: 'fundName', displayName: 'Fund Name', width: '260' },
                { field: 'folioAccountNo', displayName: 'Account No.', width: '135' },
                { field: 'bankDetails', displayName: 'Bank', width: '195' },
                { field: 'payType', displayName: 'Purpose Type', width: '125' },
                { field: 'ifscCode', displayName: 'IFSC', width: '125' }
            ];

        }
    };

};

basisFolio.$inject = ['investorConstants', 'basisFolioModel','investorEventConstants','basisFolioInitialLoader'];
module.exports = basisFolio;
