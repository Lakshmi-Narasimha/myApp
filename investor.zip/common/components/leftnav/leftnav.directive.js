/**
 * @ngdoc directive
 * @name fticLeftNav 
 * @requires $http
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - It displays the side nav bar with the data from jsonservices.
 * 
 *
 **/
'use strict';

var fticLeftNav = function($http,$state, fticLoggerMessage, loggerConstants, eventConstants, constants, grantAccessRightsModel, $cookies, authenticationService) {
	return {
            template: require('./leftnav.html'),
            restrict: 'E',
            replace: true,
            scope: {
                userType: "@"
            },
            controller: function($scope, $element, $attrs){ 
                  $scope.advisorDashboard = $cookies.get("userRedirectURI");

                var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.ADVISOR_COMPONENTS_MODULE + ' | ' + loggerConstants.LEFT_NAV_DIRECTIVE + ' | controller' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});

                // Get the content of the left nav for view from the Json.

        /* This is a temporary logic to get the left nav data from constants as per userType. It should be replaced by services*/
                var leftNavPath = "";

                if($scope.userType === "advisor"){
                    leftNavPath = "/leftnav.json";
                } else if ($scope.userType === "investor"){
                    leftNavPath = "/leftnavinvestor.json";
                }

//                 $http.get(constants.JSON_SERVICES + leftNavPath).then(function (leftNavData){

//                     // Success Function
//                     // Assigning the resolved left nav data to the scope object.
//                     console.log(1234);
//                     console.log(leftNavData);

//                     $scope.leftNavData = leftNavData.data;

// =======
                $scope.leftnav = {};
                $http.get(constants.JSON_SERVICES + leftNavPath).then(function (leftNavData){
                    var leftNavData = angular.copy(leftNavData.data.leftNav);
                    if($cookies.get('userType') !== undefined && parseInt($cookies.get('userType')) !== constants.ADVISOR_MAIN_USER && parseInt($cookies.get('userType')) !== constants.INVESTOR_MAIN_USER) {
                        var params = {
                            "guId": authenticationService.getUser() ? authenticationService.getUser().guId : null,
                            "subUserId": authenticationService.getUser() ? authenticationService.getUser().userId : null//"MFBACKOFFICE"
                        };
                        grantAccessRightsModel.getGrantAccessRights(params).then(function (data) {
                            var accessPerm = angular.copy(data.subUserDetails.accessRights);
                            grantAccessRightsModel.setAccessRights(data.subUserDetails);
                            createGrantAccess(leftNavData, accessPerm);
                            angular.forEach(angular.copy(data.subUserDetails.accessRights), function(value, key){
                                if(value.accessRight == "Yes") {
                                    grantAccessRightsModel._accessCodes[value.moduleCode] = value.description;
                                };
                            });
                            $scope.$emit("GRANT_ACCESS_VALIDATION");
                        }, function (data) {
                            $scope.leftnav = leftNavData;
                        });
                    }
                    else {
                        $scope.leftnav = leftNavData;
                        $scope.$emit("GRANT_ACCESS_VALIDATION");
                    }
                    
                    // Success Function
                    // Assigning the resolved left nav data to the scope object.
                },function(error){

                    // Error Function
                    console.log("Left nav data invalid");

                });

                function createGrantAccess (leftNavData, accessPerm) {
                    // var accessPerm = angular.copy($scope.accessPermissions);
                    $scope.leftnav['Dashboard'] = leftNavData['Dashboard'];
                    for(var i in leftNavData) {
                        var arr = [];
                        if (leftNavData[i].moduleCode === undefined) {
                            for (var k in leftNavData[i].submenu) {
                                for(var m= 0; m<accessPerm.length; m++) {
                                    if(leftNavData[i].submenu[k].moduleCode == accessPerm[m].moduleCode && accessPerm[m].accessRight == "Yes") {
                                        arr.push(leftNavData[i].submenu[k]);
                                        accessPerm.splice(m, 1);
                                        break;
                                    }
                                }                                         
                            }
                            if(arr.length >= 1) {
                                $scope.leftnav[i] = {"submenu":arr};
                            }
                        }
                        else {
                            for(var j=0; j<accessPerm.length; j++) {
                                if(leftNavData[i].moduleCode == accessPerm[j].moduleCode && accessPerm[j].accessRight == "Yes") {
                                    $scope.leftnav[i] = leftNavData[i];
                                    accessPerm.splice(j, 1);
                                    break;
                                }
                            };
                        };
                    };
                    console.log($scope.leftnav);
                }               
            },
            link: function(scope, iElement, iAttrs, controller){
                scope.oneAtATime = true;
                scope.openIndex = [true];
                scope.oneAtATime = true;
                scope.status = {
                    isFirstOpen: false,
                    isFirstDisabled: true
                };

                scope.advisorLocation = function(location){
                    if(location != undefined){
                        scope.$emit(eventConstants.Dashboard.ADV_DB_SIDE_NAV_TOGGLE);
                        $state.go(location);
                    }
                    $(".submenu a").removeClass("menuSelected");
                }

                scope.subMenuOpen = function($event){
                    var ele = angular.element($event.target);
                    $(".submenu a").removeClass("menuSelected"); 
                    $(ele).addClass("menuSelected");
                    scope.$emit(eventConstants.Dashboard.ADV_DB_SIDE_NAV_TOGGLE);
                } 
            }
        };
};


fticLeftNav.$inject = ['$http','$state', 'fticLoggerMessage', 'loggerConstants', 'eventConstants', 'constants', 'grantAccessRightsModel', '$cookies', 'authenticationService'];

module.exports = fticLeftNav;