define([
    'jquery',
    'lodash',
    'backbone',
    'bootstraptypeahead',
    'q',
    'config',
    'app/common/spinner',
    'app/common/util',
    'app/common/constants',
    'app/common/validate',
    'app/common/views/AbstractView',
    'app/application/router',
    'app/application/app',
    'app/services/awmService',
    'app/common/models/GroupCollection',
    'app/services/currentContext',
    'text!app/modules/templates/ClientGroupView.html'
], function ($, _, Backbone, BootstrapTypeahead, Q, config, Spinner, util, constants, Validator, AbstractView, router, app, awmService, GroupCollection, currentContext, ClientGroupViewTemplate) {

    return AbstractView.extend({
        el: '#sem-app-primary-view',
        template: _.template(ClientGroupViewTemplate),
        initialize: function(){
            let self = this;
            self.householdGroupData = [];
            self.primaryClient = {};
            self.clientData = {};       
            self.createMgpObj = {};
            $(document).off('click', '.group-list input[name=optradio]').on('click', '.group-list input[name=optradio]', function (e) {
                $(self).blur();
            });
        },
        events: {
            "click #cl-btn-cancel, #search-another-client": "cancel",
            "click #cs-household-component li a.group": "householdChanged",
            "click #submit-client-group":"validateForm",
            'click .radio-group-conatiner input:radio': 'onCreateMgpSelect'
        },
        render: function () {
            this.clientHouseholdGroupCollection = new GroupCollection();
			var clientId = currentContext.context.get('clientIds')[0];
            this.selectedClientId = clientId;
            this.isNonHouseholdGroup = false;
            this.isCreateMgp = false;
            this.callClientService(clientId);
        },
        cancel: function () {
            app.selClientId = null;  
            router.routeTo('clientSearchView');
        },
        onCreateMgpSelect: function(event){
            let self = this;
            const selGroupMemNames = this.$(event.currentTarget).val();
            const grpInfo = _.find(this.selectedHouseholdGroup, {groupMemNames:selGroupMemNames});
            this.createMgpObj = {
                isCreateMgp : (grpInfo.plnSysName === 'Create MoneyGuidePro Group'? true: false),
                grpInfo: grpInfo
            }
            
        },
        householdChanged: function (event) {
            const selHouseholdId = this.$(event.currentTarget).attr('id');
            this.selHouseholdGroupName = selHouseholdId;
            this.isNonHouseholdGroup = false;
            $("#cs-sel-householdgrp-btn").addClass('hidden');
            $("#cs-selected-householdgrp-btn").removeClass('hidden');
            $("#cs-householdgrp-btn").removeClass('hidden');
            $("#cs-household-list").removeClass('hidden');
            const selHouseholdGroup = this.clientHouseholdGroupCollection.filterByFmtId(selHouseholdId);
            this.clientData.selGroup = selHouseholdGroup.toJSON();
            this.callPlanningGroupDetails(selHouseholdGroup);
            window.scrollTo(0,0);
        },
        callClientService: function(clientId){
            const self = this;
            Spinner.show({
                parentElement: "sem-app-primary-view",
            });
            awmService.promiseToGetClientDetails(clientId).then((data) => {
                let activeGroups = data.activeGroups.results|| [];
                Spinner.hide();
                self.selGroupId = currentContext.context.get('groupIds')[0];
                if(clientId && self.selGroupId && self.selGroupId.grpId.substr(0,3) !== '001'){
                    if(activeGroups.length > 0){
                        self.isNonHouseholdGroup = true;
                    }else{
                        this.$el.html(ClientGroupViewTemplate);
                        $("#householdGroupErrorNote").removeClass('hidden');
                        $("#clientSearchResultContainer").addClass('hidden');
                    }
                } else if(activeGroups.length === 0){
                    this.$el.html(ClientGroupViewTemplate);
                    $("#householdGroupErrorNote").removeClass('hidden');
                    $("#clientSearchResultContainer").addClass('hidden');
                }
                activeGroups.sort(function(a, b) { return Number(b.id) - Number(a.id); });
                self.clientActiveGroups = activeGroups.reverse();
                let groupId = activeGroups[0]? activeGroups[0].id : '';
                groupId = groupId.slice(5,groupId.length);
                self.clientData = data || {};
                self.clientData.fmtName = self.clientData.personClient ? (self.clientData.personClient.clFirstNm+' '+self.clientData.personClient.clLastNm) : '';
                self.clientData.fmtName = _.startCase(_.toLower(self.clientData.fmtName));
                self.populateClientGroup();
            }).fail(error=>this.handlerServiceError(error));
        },
        isHouseholdGroup: function(group){
            return group ? group.id.slice(0,3) === '001' : false;
        },
        populateClientGroup: function(){
            const self = this;
            let modifgroup= []; 
            let pensionGrp = [];
            let asyncGrpMembCallList = [];
            this.clientActiveGroups.forEach((srtGroup, i) => {
                if(self.isHouseholdGroup(srtGroup)){
                    asyncGrpMembCallList.push(awmService.promiseToGetListActiveClientsByGroup(srtGroup.id));
                }
            });
            Q.all(asyncGrpMembCallList).then(gotoclientGroupActiveMembers, this.handleServiceError);
            function gotoclientGroupActiveMembers(groupMemCollection) {
                self.householdGroupData = self.clientHouseholdGroupCollection.populateFromGroupListResponse(groupMemCollection);
                self.primaryClient = self.clientData;
                if(self.selGroupId && self.selGroupId.grpId){
                    let selModel = self.householdGroupData.where({id:self.selGroupId.grpId})[0];
                    selModel = selModel || self.householdGroupData.models[0];
                    self.clientData.groupId = selModel.get('fmtId');
                    self.clientData.selGroup = selModel.toJSON();
                    self.callPlanningGroupDetails(selModel);  
                } else{
                    self.clientData.groupId = self.householdGroupData.models[0].get('fmtId');
                    self.clientData.selGroup = self.householdGroupData.models[0].toJSON();
                    self.callPlanningGroupDetails(self.householdGroupData.models[0]);
                }
            }

        },
        callPlanningGroupDetails: function (groupmem) {
            let self = this;
            const group = groupmem ? groupmem.toJSON() : {};
            let financialGroupCall = [
                awmService.promiseToGetFinancialPlanningGroupDetails(group, self.clientData, true),
                awmService.promiseToGetFinancialPlanningGroupDetails(group, self.clientData, false)
            ];
            var mgpGroupDetails = function(planningGroupDetails){
                planningGroupDetails[0] = planningGroupDetails[0] ? planningGroupDetails[0].models : [];
                planningGroupDetails[1] = planningGroupDetails[1] ? planningGroupDetails[1].models : [];
                planningGroupDetails = _.merge(planningGroupDetails[0], planningGroupDetails[1]);
                self.selectedHouseholdGroup = self.clientHouseholdGroupCollection.planningGroupDetails(group, self.primaryClient, planningGroupDetails);
                self.planningGroupInfo = planningGroupDetails;
                self.populateUI();
            }
            Q.all(financialGroupCall).then(mgpGroupDetails, this.handleServiceError);
            
        },
        handlerServiceError: function(){
            Spinner.hide();
            this.populateUI();
        },
        validateForm: function(){
            var self = this;
            let $userErrorNote = $('#userErrorNote');
            if (Validator.validateInputs('client-group-form', true)) {
                $userErrorNote.addClass('hidden');
                $('.has-error').removeClass('has-error');
                app.selClientId = null;
                if(this.createMgpObj.isCreateMgp){
                    let reqPayload = {
                        "actnCd": "CREATE",
                        "prmClId": this.createMgpObj.grpInfo.priClient.id,
                        "prmClCtx":this.createMgpObj.grpInfo.priClient.ctx,
                        "grpId": self.clientData.selGroup.id,
                        "grpCtx": self.clientData.selGroup.ctx,
                        "finPlnGrpStatCd": "ACTIVE",
                        "plnSysCd": "MGP"
                    };
                    if(this.createMgpObj.grpInfo.coClient.id != this.createMgpObj.grpInfo.priClient.id){
                        reqPayload.coClId =  this.createMgpObj.grpInfo.coClient.id,
                        reqPayload.coClCtx = this.createMgpObj.grpInfo.coClient.ctx
                    }
                    awmService.promiseToPostFinancialPlanningGroupDetails(reqPayload).then((result) =>{
                        console.log(result);
                        this.promiseToCallAppLauncher(result.finPlnGrpId);
                    }, () =>{
                        this.handlerServiceError();
                    })
                } else{
                    //let coClientId = $("#clientSearchResultContainer input[type='radio']:checked").attr('data-master-coClientId');
                    //let primaryClientId = $("#clientSearchResultContainer input[type='radio']:checked").attr('data-master-primaryId');

                    //this.promiseToCallAppLauncher(result.finPlnGrpId); use old one
                }
            }else{
                $userErrorNote.removeClass('hidden');
            }
        },
        promiseToCallAppLauncher: function(finPlnGrpIdValue){
            let requestPayload = {
                "planGrpCtx": "FPH.PLNGRP",
                "planGrpId": finPlnGrpIdValue,
                "srcAppId": "A0293935",
                "oboDistributorId": "",
                "oboDistributorCtx": ""
            };
            awmService.promiseToMgpPostFinancialPlanningGroupDetails(requestPayload).then((response) =>{
                console.log(response);
                if(response && response.d.launchUrl){
                    let appURL = response.d.launchUrl+response.d.tokenVal;
                    console.log(appURL);
                    window.open(config.launchMgpUrl, '_blank');
                }
            }, () =>{
                this.handlerServiceError();
            })

        },
        populateUI: function () {
            const responseData = {
                clientInfo: this.clientData,
                groupData: this.householdGroupData.toJSON(),
                formattedGroupInfo: this.selectedHouseholdGroup,
                launchMgpUrl : config.launchMgpUrl
            };
            this.$el.html(this.template(responseData));
            if(this.isNonHouseholdGroup ){
                $("#nonHouseholdErrorNote").removeClass('hidden');
                $("#cs-sel-householdgrp-btn").removeClass('hidden');
                $("#cs-selected-householdgrp-btn").addClass('hidden');
                $("#cs-householdgrp-btn").addClass('hidden');
                $("#cs-household-list").addClass('hidden');
            };
            this.$('#cs-householdgrp-btn').text(this.selHouseholdGroupName);
        }
    });

});
