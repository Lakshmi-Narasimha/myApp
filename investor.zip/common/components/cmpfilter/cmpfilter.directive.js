/**
  * @ngdoc property
  * @name fticcmpfilter Directive
  * @description
  *
  * - Composite filter enables the input field according to type selection. UI Bootstrap datepicker integrated.
  *
  **/
 'use strict';


 var cmpFilter = function($window, toaster) {
     return {
         restrict: 'EA',
         replace: true,
         template: require('./cmpfilter.directive.html'),
         scope: {
             filterOptions: "=",
             hideSelect: '=?',
             selectedObj : '=?',
             disableFuture : '=?'
         },
         link: function(scope) {

             /* DatePicker Code */
             scope.today = function() {
                scope.dt = new Date();
                scope.fdt = (scope.selectedObj && scope.selectedObj.fullDate) || new Date();
                scope.dtr1 = new Date();
                scope.dtr1.setDate(scope.dtr1.getDate()-1);
                scope.dtr2 = new Date();
                scope.dtrmonth1 = new Date();
                scope.dtrmonth2 = new Date();
             };
             scope.today();
             scope.clear = function() {
                 scope.dt = null;
             };
             scope.inlineOptions = {
                 customClass: getDayClass,
                 minDate: new Date(),
                 showWeeks: false
             };

             var _maxDate = new Date(2040, 11, 30);
             if(scope.disableFuture){
				_maxDate = new Date();
             }

             scope.dateOptions = {
                 yearRows: 4,
                 yearColumns: 3,
                 datepickerMode: 'month',
                 fulldatepickerMode:'year',
                 minMode: 'month',
                 dateDisabled: disabled,
                 formatMonth: 'MMM',
                 formatYear: 'yyyy',
                 maxDate: _maxDate,
                 minDate: new Date(),
                 startingDay: 1,
                 showWeeks: false
                 //yearRange: 20

             };
             scope.dateOptionsDisableWeek = {
                yearRows: 4,
                yearColumns: 3,
                dateDisabled: false,
                fulldatepickerMode:'year',
                datepickerMode: 'day',
                formatYear: 'yyyy',
                formatMonth: 'MMM',
                maxDate: _maxDate,
                startingDay: 1,
                showWeeks: false

             };

             // Disable weekend selection
             function disabled(data) {
                 var date = data.date,
                     mode = data.mode;
                 return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
             }

             scope.toggleMin = function() {
                 scope.inlineOptions.minDate = scope.inlineOptions.minDate ? null : new Date();
                 scope.dateOptions.minDate = scope.inlineOptions.minDate;
             };

             scope.toggleMin();

             scope.open1 = function() {
                 scope.popup1.opened = true;
             };

             scope.open2 = function() {
                 scope.popup2.opened = true;
             };

             scope.setDate = function(year, month, day) {
                 scope.dt = new Date(year, month, day);
                 
             };

             scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
             scope.format = scope.formats[0];
             scope.altInputFormats = ['M!/d!/yyyy'];

             scope.popup1 = {
                 opened: false
             };

             scope.popup2 = {
                 opened: false
             };

             var tomorrow = new Date();
             tomorrow.setDate(tomorrow.getDate() + 1);

             var afterTomorrow = new Date();
             afterTomorrow.setDate(tomorrow.getDate() + 1);

             scope.events = [{
                 date: tomorrow,
                 status: 'full'
             }, {
                 date: afterTomorrow,
                 status: 'partially'
             }];


             function getDayClass(data) {
                 var date = data.date,
                     mode = data.mode;
                 if (mode === 'day') {
                     var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                     for (var i = 0; i < scope.events.length; i++) {
                         var currentDay = new Date(scope.events[i].date).setHours(0, 0, 0, 0);

                         if (dayToCheck === currentDay) {
                             return scope.events[i].status;
                         }
                     }
                 }

                 return '';
             }

             /* DatePicker Ends */

             /*First Dropdown Scope Change events*/
          
             scope.changed = function() {
                 if (scope.selected) {
                    scope.$emit('selectedValue', scope.selected);

                     var updatetype = scope.selected.type;
                     //console.log(updatetype);
                     if (updatetype == 'text' || updatetype == 'number' || updatetype == 'date') {
                         scope.$emit('selectedType', scope.selected);
                     }
                     if (updatetype == 'date'|| updatetype == 'fulldate') {
                        var dt = (scope.selectedObj && scope.selectedObj.fullDate) || scope.dt;
                         scope.$emit('getcurrentdate', dt);
                         console.log(scope.dt);
                     }
                     if(updatetype == 'daterange'){
                        scope.dtr1 = new Date();
                        scope.dtr1.setDate(scope.dtr1.getDate()-1);
                        //Commented as this defect not fixed properly
                        /*if(scope.selectedObj != null && scope.selectedObj.sysFilter.fromDate != null){
							scope.dtr1 = scope.selectedObj.sysFilter.fromDate;
						}
                        scope.dtr2 = new Date();
                        if(scope.selectedObj != null && scope.selectedObj.sysFilter.toDate != null){
							scope.dtr2 = scope.selectedObj.sysFilter.toDate;
						}*/
                        scope.$emit('getdaterange', scope.dtr1, scope.dtr2);
                     }
                    if(updatetype == 'daterangemonth'){
                        scope.$emit('getdaterangemonth', scope.dtrmonth1, scope.dtrmonth2);
                     }
                 }
             }

             /*Second Select Change events*/
             scope.inputChange = function(inputVal, inputType) {
                scope.rangeError = false;
                scope.popup2.opened = false;
                 var inputValue = inputVal;
                 console.log(inputType + ': ' +inputVal);
                 
                 if(inputType == 'dtr1'){
                    scope.dtr1 = inputValue;
                 }

                  if(inputType == 'dtr2'){
                    scope.dtr2 = inputValue;
                 }

                 // if(scope.dtr1 >= scope.dtr2) {
                 //    scope.rangeError = true;
                 //    //toaster.error("From Date should be lesser than the To Date");
                 // }
                 scope.$emit('fticcmpFilterEvent', inputValue, inputType);
                 console.log(inputValue);

             };

            if(scope.hideSelect){
                 scope.hideSelectOption = false;
                 scope.selected = scope.filterOptions[0];
                if(scope.selectedObj && scope.selectedObj.sysFilter){
                 	scope.selected = scope.filterOptions[scope.selectedObj.sysFilter.filterOptionIndex];
                 	scope.changed();
                 } else{
                    scope.changed();
                 }

            }else{
                 scope.hideSelectOption = true;
            };

         }
     }
 }

 cmpFilter.$inject = ["$window", "toaster"];
 module.exports = cmpFilter;