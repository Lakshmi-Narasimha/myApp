import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { BuildinfoComponent } from '../buildinfo/buildinfo.component';

const routes: Routes = [
    {
        path: 'env/:id',
        children: [
            { path: 'dashboard', component: DashboardComponent },
            { path: 'dashboard/build/:buildType/:key', component: BuildinfoComponent }
        ]
    },
    { path: '**', redirectTo: 'env/1/dashboard', pathMatch: 'full' },
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ],
    declarations: []
})
export class AppRoutingModule { }