﻿define(['jquery',
    'underscore',
    'backbone',
    'components/js/views/AggregateView',
    'text!components/template/RadioButton.html'
], function ($, _, Backbone, AggregateView, RadioButtonHtml) {
    var RadioButtonView = AggregateView.extend({
        // OPTIONAL PUBLIC PROPERTIES
        selectedItem: null,
        itemSelectionComplete: null,
        objectRender: null,
        objectIdentifier: null,
        errorMessage: "Incomplete required field",
        noEscape: false,
        triggerPreSelection: true,
        // PRIVATE PROPERTIES
        items: null,
        template: _.template(RadioButtonHtml),
        initialize: function (options) {
            AggregateView.prototype.initialize.apply(this, arguments);
            _.extend(this, _.pick(options, 'items'));
        },
        events: {
            'change [ampf-radio-button]': 'handleChange',
            'click .radio-button-group input': 'toggleRadioButtonActiveState'
        },
        componentId: function () {
            return this.$el.prop('id');
        },
        render: function () {
            this.populateUI();
        },
        populateUI: function () {
            var self = this;
            var selectedIndex = null;
            var itemDescriptions = [];
            _.forEach(this.items, function (item, i) {
                itemDescriptions.push(self.itemDescription(item));
                if (self.objectIdentifier && self.objectIdentifier == 'model') {
                    if (self.selectedItem && self.selectedItem.id == item.id) {
                        selectedIndex = i;
                    }
                }
                else if (self.selectedItem && _.isEqual(self.selectedItem, item)) {
                    selectedIndex = i;
                }
            });
            this.$el.html(this.template({
                componentId: self.componentId(),
                itemDescriptions: itemDescriptions,
                selectedIndex: selectedIndex
            }));

            if (selectedIndex || selectedIndex == 0) {
                self.highlightPreSelected(selectedIndex);
            }
        },
        itemDescription: function (item) {
            var desc;
            if (this.objectRender) {
                desc = this.objectRender(item);
            } else if (item.description) {
                desc = typeof item.description === 'function' ? item.description() : item.description;
            } else {
                desc = '' + item;
            }
            return this.noEscape ? desc : _.escape(desc);
        },
        handleChange: function (e) {
            var self = this;
            var index = parseInt(self.$el.find("input[type='radio']:checked").attr('ampf-radio-button-id'));
            this.selectedItem = this.items[index];
            if (this.itemSelectionComplete) {
                this.itemSelectionComplete(this.selectedItem, e);
            }
        },
        highlightPreSelected: function (itemIndex) {
            var $selectedTarget = $('input[ampf-radio-button-id=' + itemIndex + "-" + this.componentId() + ']');
            var $selectedButtonGroup = $selectedTarget.closest(".radio-button-group");
            $selectedButtonGroup.find("radio-group-conatiner.active").removeClass("active");
            $selectedTarget.closest("label").parent().addClass("active");
            if (this.triggerPreSelection) {
                this.$('div[ampf-radio-button]').trigger('change');
            }
        },
        toggleRadioButtonActiveState: function (evt) {
            var $target = $(evt.target);
            var $buttonGroup = $target.closest(".radio-button-group");
            $buttonGroup.find("div.active").removeClass("active");
            $target.closest("div").addClass("active");
        },
        showError: function (shouldShow) {
            if (!shouldShow) {
                this.$('[ampf-error-label]').addClass('hidden');
            } else {
                this.$('[ampf-error-label]').text(this.errorMessage).removeClass('hidden');
            }
        },
        getItems: function () {
            return this.items;
        }
    });
    return RadioButtonView;
});