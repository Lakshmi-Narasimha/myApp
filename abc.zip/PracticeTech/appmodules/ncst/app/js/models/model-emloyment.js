
define(['jquery', 'underscore', 'backbone','backboneRelational','appmodules/ncst/app/js/lib/validate-4.2','appmodules/ncst/app/js/models/model-client-details'],
		function($, _, Backbone,backboneRelational, Validator,ClientDetailsModel) {
	var self = null;
    var employmentModel = Backbone.RelationalModel.extend({
        defaults: {
            fromBack: false,
            isEmployed: '',
            isClientODSP: '',
            employmentStatus: '',
            employmentAddrCollection: ''
        },
        initialize:function(){
        	self = this;
        },
        validate: function () {
            var _proceed = true;
            if (!Validator.validateInputs('client-employement')) {
                _proceed = false;
            }
            if (_proceed) {
                if (Validator.checkforMandatoryFields('client-employement')) {
                    ClientDetailsModel.set('clientEmploymentValid', true);
                } else {
                    ClientDetailsModel.set('clientEmploymentValid', false);
                }
            }
            return _proceed;
        },
        setModel: function (employmentData, FINRAData, finraCheckbox, shareHolderData, shareHolderCheckbox) {
        	var _clientEmploymentForm = $('#client-employement'), occupation;
        	var empStatus = _clientEmploymentForm.find('input[name="empStatus"]:checked').val(), _industryType = "", _industryText = "";
            self.set('fromBack', true);
            self.set('employmentStatus', empStatus);
            self.set('employmentStatusCode', _clientEmploymentForm.find(
                    'input[name="empStatus"]:checked').data('value'));
            if (empStatus == "Self employed") {
            	_industryType = $('#pt-emp-select-industry').val();
            	_industryText = $('#pt-emp-select-industry option:selected').text();
            }
            if (employmentData != "") {
            	occupation = employmentData[0].primaryOccupation ? employmentData[0].primaryOccupation : "";
	        }
            self.set('industryClassifyEmp', (_industryText != "") ? _industryText : "");
            self.set('industryClassifyEmpCd', (_industryType != "") ? _industryType : "");
            self.set('industryClassifyEmpOther', (_industryText == "Other") ? $('#pt-emp-industry-other-input').val() : "");
            
            self.set('employmentAddrCollection', employmentData);
            self.set('occupation', occupation);

            self.set('isEmployed', $('.is-employed.active').val());
            self.set('FINRAAddrCollection', FINRAData);
			self.set('finraCheckbox', finraCheckbox);

            self.set('isClientODSP', $('.is-officer.active').val());
            self.set('shareHolderAddrCollection', shareHolderData);
            self.set('shareHolderCheckbox', shareHolderCheckbox);
        },
        setCompletionStatus: function (status) {
            ClientDetailsModel.set('clientEmploymentValid', status);
        }
    });
    return new employmentModel();
});