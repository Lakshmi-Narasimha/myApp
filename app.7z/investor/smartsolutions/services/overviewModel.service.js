'use strict';

var overviewModelService= function(Restangular, $q, fticLoggerMessage, loggerConstants,authenticationService,appConfig) {
    var _ovDtls = null;
    var _fundCompositionDetails = null;
    var _holderinfo = null;

    var overviewModel = {
        fetchOverviewDtls : function () {
            var params = {
                "guId" : authenticationService.getUser().guId
            };

            var deferred = $q.defer();
            Restangular.one('smartsolution/overview').get(params).then(function (ovDetails) {
                deferred.resolve(ovDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getOverviewDtls : function () {
                 return _ovDtls;
        } ,
        setOverviewDtls : function (overviewData) {
            _ovDtls = overviewData;
        },
        setHolderInformation : function (holderinfo) {
            _holderinfo = holderinfo;
        },
        getHolderInformation : function (holderinfo) {
            return _holderinfo;
        },
        getFundCompositionDetails: function(queryObj){
            var deferred = $q.defer();
            var end = 'smartsolution/overview';
            Restangular.one(end).get(queryObj).then(function (fundCompositionDetails) {
                deferred.resolve(fundCompositionDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setFundCompositionDetails: function(fundDetails){
            _fundCompositionDetails = fundDetails;
        }

    };
    return overviewModel;

};

overviewModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants','authenticationService','appConfig'];
module.exports = overviewModelService;
