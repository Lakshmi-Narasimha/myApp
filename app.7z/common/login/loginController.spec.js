/*jshint expr: true*/

'use strict';

describe('loginCtrl', function() {

    var ctrl, scope,loginCtrlScope;

    beforeEach(angular.mock.module('common'));

    beforeEach(function() {

        angular.mock.inject(function($controller, $rootScope) {
            loginCtrlScope = $rootScope.$new();
            ctrl = $controller('loginCtrl', {
                $scope: loginCtrlScope
            });
        });

    });

    it('should exist', function() {
        expect(ctrl).toBeDefined();
        expect(loginCtrlScope).toBeDefined();
    });
    it('login function is called', function(){
        expect(loginCtrlScope.test).toBe(false);
        loginCtrlScope.login();
        expect(loginCtrlScope.test).toBe(true);
    });

});