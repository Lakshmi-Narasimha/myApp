/**
 * @ngdoc property
 * @name Stp Controller
 * @requires $scope
 * @requires TransactConstant
 * @description
 *
 * - 
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function cancelStpController($scope, TransactConstant) {

    $scope.header.title = "Cancel an STP";    
   // $scope.config.txnFormDetails.title = "Review & Confirm";
    $scope.isShowReedemGrid = false;

}

cancelStpController.$inject = ['$scope', 'TransactConstant'];
module.exports = cancelStpController;