define(['jquery', 'underscore', 'backbone', 'spinner','appcommon/globalcontext', 'appcommon/analytics','appmodules/gpm/app/js/lib/validate.js', 'appmodules/ncst/app/js/utils', 'appmodules/ncst/app/data/country-list','appmodules/contactprofile/app/models/cpviewmodel','appmodules/gpm/app/js/views/view-drivers-licence',
		'text!appmodules/gpm/app/templates/gpmadvsrclntinfotemplate.html', 'text!appmodules/gpm/app/templates/gpmcommonsectionstemplate.html'], function ($, _, Backbone, Spinner, GlobalContext, Analytics, Validator, Utils, StateList, CPViewModel, DriversLicenceView, GPMAdvsrClientTemplate, CommonSectionTemplate) {
		    var _containerView = Backbone.View.extend({
		        el: $("#practicetech-subapp"),
		        id: 'practicetech-subapp',
		        events: {
		            'click #gpm-step1-next-button,#m-gpm-step1-next-button': 'vaidateAndNavigateFromStep1',
		            'click .is-employed': 'toggleEmployed',
		            'click .is-officer': 'toggleOfficer',
		        },
		        initialize: function () {
		        	this.data = {};
		        },
		        render: function (updateMode) {
		        	var _self = this;
		        	$('.gpm-step').removeClass("active");
		        	$('.gpm-step.step1').removeClass("finished");
		        	$('.gpm-step.step1').addClass("active");
		        	var _template = "";
		        	_self.getClientInfo();
		        	switch (updateMode) {
					    case 'gender':
						    _template="gpmgendersection.html";
						    break;
		        	    case 'greeting':
		        	        _template = "gpmclientgreeting.html";
		        	        break;
		        	    case 'remarks':
		        	        _template = "gpmclientremarks.html";
		        	        break;
		        	    case 'dependents':
		        	        _template = "gpmdependents.html";
		        	        break;
		        	    case 'honorific':
		        	        _template = "gpmhonorificupdates.html";
		        	        break;
		        	    case 'maritalstatus':
		        	        _template = "gpmmaritalstatus.html";
		        	        break;
		        	    case 'passport':
		        	        _template = "gpmpassport.html";
		        	        break;
		        	    case 'subtype':
		        	        _template = "gpmsubtype.html";
		        	        break;
		        	    case 'employment':
		        	        _template = "gpmemployment.html";
		        	        break;
		        	    case 'suitability':
		        	        _template = "gpmsuitability.html";
		        	        break;
		        	    case 'entity':
		        	        _template = "gpmentity.html";
		        	        break;
		        	    case 'driverslicense':
		        	        _template = "gpmdriverslicense.html";
		        	        new DriversLicenceView();
		        	        break;
		        	    case 'alert':
		        	        _template = "gpmalertpreferences.html";
		        	        break;
		        	    case 'communicationprefs':
		        	        _template = "gpmcommunicationprefs.html";
		        	        break;
		        	    case 'documentDelivery':
		        	        _template = "gpmdocdelivery.html";
		        	        break;
		        	    case 'reportclientsdeath':
		        	        _template = "gpmreportclientsdeath.html";
		        	        break;
		        	    case 'reportclientsdivorce':
		        	        _template = "gpmreportclientsdivorce.html";
		        	        break;
					    default:
						    break;
					}
		        	require(['text!appmodules/gpm/app/templates/'+_template],function(GenderSectionTmplt){
		        		_self.model.setCurrentValue(updateMode,{data:_self.data});
		        		//load the common section 
		        		_self.loadPageTitle(updateMode);
		        		_self.loadAdvsrClientNametemplate();
		        		_self.loadNavigationButtonTemplate(updateMode);
		        		
			        	//load the form fields to the container
			        	//mode  related template loading
			        	var _sectionTemplate = GenderSectionTmplt;
			        	 var _compiledTemplate = _.template(_sectionTemplate);
			        	_self.$el.find('#gpm-form-update-field-container').html(_compiledTemplate({data:_self.data}));
			        	$('#confirm-msg-section-holder').html('').addClass("hidden");
		        	    //Loading State List
			        	_self.loadStateList(_self.data.fieldsInfo.drvLicStCd);
			        	_self.loadEmploymentStateList();
			            Spinner.hide();
		        	})
		        	
                    
		        },
		        getClientInfo : function(){
		        	var CPData = CPViewModel.getInstance().getData();
		        	var cliemtName = ""
		        		if(CPData.cola.personClient.get("clLastNm")){
		        			cliemtName = CPData.cola.personClient.get("clLastNm")+ ", "+CPData.cola.personClient.get("clFirstNm");
		        		}else{
		        			cliemtName = CPData.cola.orgClient.get("orgNm");
		        		}
		        	this.data.clientInfo = {fmtId:CPData.cola.fmtId,name : cliemtName};
                    
		        },
		        getDriversLicenceData : function(){ 
		        	try{
		        		var CPData = CPViewModel.getInstance().getData();
			        	var state = (_.find(StateList.USStateslist,function(obj){return obj.code == CPData.cola.clientPersonal.get('drvLicStCd')}) || {name:"",code:""});
			        	this.data.fieldsInfo = {drvLicNbr: (CPData.cola.clientPersonal.get('drvLicNbr') || ""), drvLicStCd: (CPData.cola.clientPersonal.get('drvLicStCd') || ""), drvLicSt:(state.name || "")};
		        	}
		        	catch(error){
		        		
		        	}
		        	
		        },
		        loadAdvsrClientNametemplate:function(){
		        	var _self = this;
		        	//common sewction loading
		        	var _advsrClientInfoTmplt = GPMAdvsrClientTemplate;
		        	//load advsr/client info
		        	var _advtmplt = _.template(_advsrClientInfoTmplt);
		        	var _advsrInfoCompiledTmplt = _advtmplt({step:1,data:this.model.toJSON()});
		        	_self.$el.find('#gpm-advsr-client-info-container').html(_advsrInfoCompiledTmplt);
		        	
		        },
		        loadNavigationButtonTemplate: function (updateEgment) {
		        	var _self = this;
		        	var _commonTemplate = _.template(CommonSectionTemplate);
		        	var _sectionName = { sectionName: updateEgment };
		        	var _navSectionSubTemplate = _self.getTemplateSection(CommonSectionTemplate(_sectionName), '#nav-section-step1');
		        		//load the naviagtion container to the container
		        		_self.$el.find('#gpm-step-navigation-button-container').html(_navSectionSubTemplate);
		        },
		        loadPageTitle: function (updateEgment) {
		        	var _self = this;
		        	var _commonTemplate = _.template(CommonSectionTemplate);
		        	var _sectionName = { sectionName: updateEgment };
		        	var _pageHeadingTemplate = _self.getTemplateSection(CommonSectionTemplate(_sectionName), '#pt-gpm-update-step1-page-title');
		        	//load the page header template to container
		        	_self.$el.find('#gpm-step-title-container').html(_pageHeadingTemplate);
		        },
		        getTemplateSection:function(template,dataSection){
		        	var  _$wrapper = $('<div></div>');
		        	_$wrapper.html($(template).find(dataSection));
		        	var _templt = _$wrapper.html();
		        	return _templt;
		        },
		        vaidateAndNavigateFromStep1:function(){
		        	if(this.model.validate('gpm-update-form',true)){
		        		this.model.setChangedValue();
			        	$('.gpm-step.step1').addClass("finished").removeClass("active");
			        	$('.gpm-step.step2').addClass("active");
			        	Backbone.history.navigate('gpm/verification/'+this.model.get('updateMode'), true);
		        	}
		        },
		        loadStateList: function(selStateCd) {
		            var _stateList = StateList.USStateslist;
		            var _selectbox = "#us-states-list-details-page";
		            Utils.loadSelectbox(_selectbox, _stateList, false, selStateCd);
		        },
		        /* Functions for Employment Starts Here*/
		        toggleEmployed: function (obj) {
		            var _$clickedButton = $(obj.currentTarget);
		            if (_$clickedButton.hasClass('active')) {
		                return false;
		            } else {
		                var _btnTxt = _$clickedButton.text();
		                $('.is-employed').removeClass('active');
		                if (_btnTxt == 'Yes') {
		                    $('.is-employed-alert').removeClass(
                                    'clientofficer-status-hide');
		                    $('#ce-not-employed').hide().removeClass(
                                    'active');
		                    $('#not-employed').attr('checked', false);
		                } else {
		                    $('#ce-not-employed').show();
		                    $('.is-employed-alert').addClass(
                                    'clientofficer-status-hide');
		                }
		                _$clickedButton.addClass('active');
		            }

		        },
		        toggleOfficer: function (obj) {
		            var _$clickedButton = $(obj.currentTarget);
		            if (_$clickedButton.hasClass('active')) {
		                return false;
		            } else {
		                $('.is-officer').removeClass('active');
		                _$clickedButton.addClass('active');
		        }
		        },
		        loadEmploymentStateList: function () {
		            var _stateList = StateList.USStateslist;
		            var _selectbox = "#income-state-list-select";
		            Utils.loadSelectbox(_selectbox, _stateList);
		        },
		        /* Functions for Employment Ends Here*/
		        
		    });
		    return _containerView;
		});