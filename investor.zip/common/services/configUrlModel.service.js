/**
 * @ngdoc property
 * @name configUrl
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - configUrl service returns the URL based on the environment.
 *
 **/
'use strict';

var configUrlModel = function(appConfig) {   
    var _environment = appConfig.ENVIRONMENT;

	var configUrlModel = {
        getEnvUrl: function(requestURL) {
            return requestURL + '_' + _environment;
        }
    };
    return configUrlModel;
};

configUrlModel.$inject = ['appConfig'];
module.exports = configUrlModel;