/**
 * @ngdoc service
 * @name registrationFormModel
 * @description
 *
 * - It works like model with setters and getters.
 *
 */


'use strict';

var formDetailsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _personalDetails = null,
        _occuDetails = null,
        _grossIncome = null,
        _taxResidentCntry = null,
        _occuMethod = null,
        _incmMethod = null,
        _taxMethod = null,
        _nomineeDetails=null;

   /* var formDetailsModel = {
        fetchFormOcupDetails : function () {
            
            var deferred = $q.defer();
            Restangular.all('/ekycDetails').getList().then(function (formDetails) {
                    deferred.resolve(formDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        fetchFormIncDetails : function () {
            
            var deferred = $q.defer();
            Restangular.all('/ekycDetails').getList().then(function (formDetails) {
                deferred.resolve(formDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        fetchFormResidentDetails : function () {
                    
                    var deferred = $q.defer();
                    Restangular.all('/ekycDetails').getList().then(function (formDetails) {
                        
                        deferred.resolve(formDetails);
                    }, function (resp) {
                        deferred.reject(resp);
                        console.log('error');
                    });
                    return deferred.promise;
                },*/

    var formDetailsModel = {
    fetchFormOcupDetails : function () {
        
        var deferred = $q.defer();
        //Restangular.all('/ekycDetails').getList().then(function (formDetails) {
            var params = {
                "groupId" : "OCCUPATION",
               "guId": authenticationService.getUser() !== null ? authenticationService.getUser().guId : null
            }
            Restangular.one('services/paramCodes').get(params).then(function (formDetails) {
                deferred.resolve(formDetails);
        }, function (resp) {
            deferred.reject(resp);
            console.log('error');
        });
        return deferred.promise;
    },
    fetchFormIncDetails : function () {
        
        var deferred = $q.defer();
        //Restangular.all('/ekycDetails').getList().then(function (formDetails) {
            var params = {
                "groupId" : "WebFinStatus",
               "guId": authenticationService.getUser() !== null ? authenticationService.getUser().guId : null
            }
            Restangular.one('services/paramCodes').get(params).then(function (formDetails) {
            deferred.resolve(formDetails);
        }, function (resp) {
            deferred.reject(resp);
            console.log('error');
        });
        return deferred.promise;
    },
    fetchFormResidentDetails : function () {
                
                var deferred = $q.defer();
                //Restangular.all('/ekycDetails').getList().then(function (formDetails) {
                    var params = {
                        "groupId" : "WebInvCateogry",
                       "guId": authenticationService.getUser() !== null ? authenticationService.getUser().guId : null
                    }
                    Restangular.one('services/paramCodes').get(params).then(function (formDetails) {
                    deferred.resolve(formDetails);
                }, function (resp) {
                    deferred.reject(resp);
                    console.log('error');
                });
                return deferred.promise;
            },

        
        getPersonalDetails: function() {
            return _personalDetails;
        },
        
        setPersonalDetails: function(personalDetails) {
            _personalDetails = personalDetails;
        },
        getOccupationDetails: function() {
            return _occuDetails;
        },
        
        setOccupationDetails: function(formDetails) {
            _occuDetails = formDetails;
        },
        getGrossIncome: function() {
            return _grossIncome;
        },
        
        setGrossIncome: function(grossIncome) {
            _grossIncome = grossIncome;
        },
        getTaxResidentCntry: function() {
            return _taxResidentCntry;
        },
        
        setTaxResidentCntry: function(taxResidentCntry) {
            _taxResidentCntry = taxResidentCntry;
        },
        getOccuMethod: function() {
            return _occuMethod;
        },
        
        setOccuMethod: function(occuMethod) {
            _occuMethod = occuMethod;
        },
        getIncmMethod: function() {
            return _incmMethod;
        },
        
        setIncmMethod: function(incmMethod) {
            _incmMethod = incmMethod;
        },
        getTaxMethod: function() {
            return _taxMethod;
        },
        
        setTaxMethod: function(taxMethod) {
            _taxMethod = taxMethod;
        },
        getNomineeDetails: function() {
            return _nomineeDetails;
        },
        
        setNomineeDetails: function(nomineeDetails) {
            _nomineeDetails = nomineeDetails;
        }
    };
    return formDetailsModel;
};

formDetailsModel.$inject = ['Restangular','$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];

module.exports = formDetailsModel;
