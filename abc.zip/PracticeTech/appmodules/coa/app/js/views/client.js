coa = coa || {};
define(['jquery',
        'underscore',
        'backbone',
'text!appmodules/coa/app/templates/clientList.html'
], function($,
		_, Backbone,Template){
	coa.views.clientView = Backbone.View
		.extend({
			tagName : 'tr',
			className : 'client-view active',
			events : {
				'click .client-list-table input[type="checkbox"]'  : 'toggleCheckClassActive'
			},
			initialize : function() {},
			toggleCheckClassActive : function(event) {
				var _$checkbox = $(event.target);
				if (_$checkbox.prop('checked') == true) {
					this.model.set('checked', true);
				} else {
					this.model.set('checked', false);
				}
				//this.model.set('user', coa.user.get('submitterId'));
				coa.Clients.get(this.model.get('id')).save();
			},
			template : _.template(Template),

			render : function() {
				var _checked = this.model.get('checked');
				this.model.set('index',coa.Clients.length)
				this.model.set('checked', true);
				this.model.save();
				coa.user.get('clients').add(this.model);
				return $(this.el).html(this.template(this.model.toJSON()));
			}
		});
});