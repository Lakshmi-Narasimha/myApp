var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var router = express.Router();
var sendMessageModel = require('./sendMessage.model');
var apiUtils = require('../../common/apiUtils');

// api route
router.route('/mfchatnode/rest/message')
    .post(function(req, res) {
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        req.uri = sendMessageModel.createRequestUri;
        req.body.RequestParams = req.body.RequestParams || {};
        req.session.mqtt = req.body.RequestParams.mqtt;
        delete req.body.RequestParams.mqtt;
        var post_data = req.body.RequestParams;
        var postBody = querystring.stringify(post_data);
        logger.conversation.info('Engagement ID: ' + req.body.RequestParams.engagementID + ' Msg text: ' + req.body.RequestParams.messageText + ' MQTT:' + req.session.mqtt);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: false
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            console.log("proxyResponse.statusCode:", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
            if (proxyResponse.statusCode === 200) {
                req.session.chatGetMsgCounter = (req.session.chatGetMsgCounter || 1);
                req.session.chatSendMsgCounter++;
                req.session.save();

                logger.outBoundData.info(logger.formatResMsg(req, { statusCode: proxyResponse.statusCode }));
                console.log('IN Req:', req.session.chatSendMsgCounter, req.session.chatGetMsgCounter);
                if (req.session.mqtt && !req.session.isRecurEnabled) {
                    apiUtils.getMsgMultiRecursiveCall(req, res, function(chunk) {

                    });
                    res.status(200).end();
                } else {
                    res.end();
                }
            } else {
                var errObj = {
                    statusCode: proxyResponse.statusCode,
                    message: 'Something went wrong while retrieving data.'
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
                logger.error.error(logger.formatResMsg(req, err));
            });
        });
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
