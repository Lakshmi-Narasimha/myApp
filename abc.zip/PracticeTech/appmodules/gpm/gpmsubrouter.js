// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
  'backbonesubroute',
  'appcommon/memmorymgr',
  'appmodules/contactprofile/cpcommon',
  'appcommon/constants',
  'appcommon/globalcontext',
  'spinner',
  'appmodules/gpm/app/js/views/view-gpm-main.js','appmodules/gpm/app/js/views/view-gpm-verification.js',
  'appmodules/gpm/app/js/views/view-gpm-confirmation','appmodules/gpm/app/js/models/model-gpm-update.js',
  'text!appmodules/gpm/app/templates/gpmadvsrclntinfotemplate.html', 'text!appmodules/gpm/app/templates/gpmcommonsectionstemplate.html',
  'appcommon/analytics'
  
], function ($, _, Backbone, backbonesubroute, MemmoryMgr, CommonUtil,Constants, GlobalContext,Spinner,MainView,GPMVerificationView,GPMConfirmationView,GPMUpdateModel,GPMAdvsrClientTemplate,CommonSectionTemplate, Analytics) {
    var self = null, gpmRouter = Backbone.SubRoute.extend({
        routes: {
           'update(/):updatesegment(/)':'showUpdateView',
           'verification(/*:updatesegment)':'showVerificationView',
           'confirm(/*:updatesegment)':'showConfirmationView',
            '*path(/:updatesegment)': 'defaultAction'
        },
        initialize: function () { self = this; },
        defaultAction: function (updateEgment) {
        	GPMUpdateModel.clear();
        	GPMUpdateModel.setClientInfo();
        	console.log(updateEgment,"updateEgment");
        	if(this.mainView){
        		MemmoryMgr.clearView(this.mainView);
        	}
        	this.mainView = new MainView({ model: GPMUpdateModel });
        	this.mainView.render({},updateEgment.replace(/\/$/, ""));
        	Analytics.analytics.processGPMSubRouteChangeEvent('showUpdateView', updateEgment);
        },
        showUpdateView: function (updatesegment) {
            var test1 = "";
            if (!$("#gpm-template-container").is(":visible")) {
                self.defaultAction(updatesegment);
            }
        	var _self = this,  _step1Title = "Update client information",_step1NavBtnCtnr = "#nav-section-step1";
        	if(this.updateView){
        		MemmoryMgr.clearView(this.updateView);
        	}
        	switch (updatesegment) {
        	    case 'gender':
        	        _step1Title = "Update gender information";
        	        _view = "view-gpm-gender";
        	        _step1NavBtnCtnr = "#nav-section-step1-two-step";
        	        break;
        	    case 'greeting':
        	        _step1Title = "Update greeting";
        	        _view = "view-gpm-greetings";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'remarks':
        	        _step1Title = "Update remarks";
        	        _view = "view-gpm-remarks";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'dependents':
        	        _step1Title = "Update total dependents";
        	        _view = "view-gpm-dependents";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'honorific':
        	        _step1Title = "Update honorific";
        	        _view = "view-gpm-honorific";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'maritalstatus':
        	        _step1Title = "Update marital status";
        	        _view = "view-gpm-maritalstatus";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'passport':
        	        _step1Title = "Update passport";
        	        _view = "view-gpm-passport";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'subtype':
        	        _step1Title = "Update sub-type";
        	        _view = "view-gpm-subtype";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'employment':
        	        _step1Title = "Update employment information";
        	        _view = "view-employment";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        Analytics.analytics.recordAction('gpm:updateEmployment:clicked');
        	        break;
        	    case 'suitability':
        	        _step1Title = "Update income & investments information";
        	        _view = "view-gpm-suitability";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        Analytics.analytics.recordAction('gpm:updateSuitability:clicked');
        	        break;
        	    case 'entity':
        	        _step1Title = "Update entity information ";
        	        _view = "view-gpm-entity";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        Analytics.analytics.recordAction('gpm:updateEntity:clicked');
        	        break;
        	    case 'driverslicense':
        	        _step1Title = "Update driver's license";
        	        _view = "view-drivers-licence";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'alert':
        	        _step1Title = "Update alert information";
        	        _view = "view-gpm-alertpreferences";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        Analytics.analytics.recordAction('gpm:updateAlerts:clicked');
        	        break;
        	    case 'communicationPreference':
        	        _step1Title = "Update communication preferences information";
        	        _view = "view-gpm-communication-preference";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        Analytics.analytics.recordAction('gpm:updateAlerts:clicked');
        	        break;
        	    case 'phonenumbers':
        	        _step1Title = "Update phone number";
        	        _view = "view-gpm-phonenumbers";
        	        _step1NavBtnCtnr = "#nav-section-step1-two-step";
        	        break;
        	    case 'email':
        	        _step1Title = "Update email address";
        	        _view = "view-gpm-emails";
        	        _step1NavBtnCtnr = "#nav-section-step1-two-step";
        	        //Analytics.analytics.recordAction('gpm:updateEmail:clicked');
        	        break;
        	    case 'documentDelivery':
        	        _step1Title = "Update document delivery preferences";
        	        _view = "view-gpm-docdelivery";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'reportclientsdeath':
        	        _step1Title = "Provide details";
        	        _view = "view-gpm-clientsdeath";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    case 'reportclientsdivorce':
        	        _step1Title = "Provide details";
        	        _view = "view-gpm-clientsdivorce";
        	        _step1NavBtnCtnr = "#nav-section-step1";
        	        break;
        	    default:
        	        break;
        	}
        	//_step1Title  ="Update client information";
        	 Spinner.show();
 		    require(['appmodules/gpm/app/js/views/'+_view],function(GPMUpdateView){
 		    	if(_self.updateView){
 	        		MemmoryMgr.clearView(_self.updateView);
 	        	}
 		    	_self.updateView = new GPMUpdateView({ model: GPMUpdateModel });
 		    	_self.mainView.currentUpdateView = _self.updateView; 
 		    	_self.updateView.render(updatesegment);
 		    	_self.loadPageTitle("Step 1 - " + _step1Title, updatesegment);
 		    	_self.loadAdvsrClientNametemplate(updatesegment);
 		    	_self.loadNavigationButtonTemplate(_step1NavBtnCtnr, _step1Title, updatesegment);
        		$('.gpm-alert-row').addClass("hidden");
 	        	 Spinner.hide();
 		    })
        },
        getTemplateSection:function(template,dataSection){
        	var  _$wrapper = $('<div></div>');
        	_$wrapper.html($(template).find(dataSection));
        	var _templt = _$wrapper.html();
        	return _templt;
        },
        loadAdvsrClientNametemplate: function (updatesegment) {
        	//common sewction loading
        	var _advsrClientInfoTmplt = GPMAdvsrClientTemplate;
        	//load advsr/client info
        	var clientName = GPMUpdateModel.get('clientName');
        	if (clientName.indexOf(',') === -1) {
        	    var nameParts = clientName.split(' ');
        	    if (nameParts.length === 2) {
        	        clientName = nameParts[0] + ", " + nameParts[1];
        	    }
        	}
        	var _data = { submitterId: GPMUpdateModel.get('submitterId'), advisorId: GPMUpdateModel.get('advisorId'), clientName: clientName, clientFmtId: GPMUpdateModel.get('clientFmtId') };
        	var _advtmplt = _.template(_advsrClientInfoTmplt);
        	var _advsrInfoCompiledTmplt = _advtmplt({ step: 1, data: _data, sectionName: updatesegment });
        	$('#gpm-advsr-client-info-container').html(_advsrInfoCompiledTmplt);
        	
        },
        loadNavigationButtonTemplate: function (step1NavBtnCtnr, title, updateEgment) {
        	var _self = this;
        	var _commonTemplate = _.template(CommonSectionTemplate);
        	var _sectionName = { sectionName: updateEgment };
        	var _navSectionSubTemplate = _self.getTemplateSection(_commonTemplate(_sectionName), step1NavBtnCtnr, title);
        		//load the naviagtion container to the container
        		$('#gpm-step-navigation-button-container').html(_navSectionSubTemplate);
        },
        loadPageTitle: function (title, updateEgment) {
        	var _self = this;
        	var _commonTemplate = _.template(CommonSectionTemplate);
        	var _sectionName = { sectionName: updateEgment };
        	var _pageHeadingTemplate = _self.getTemplateSection(_commonTemplate(_sectionName), '#pt-gpm-update-step1-page-title');
        	//load the page header template to container
        	$('#gpm-step-title-container').html(_pageHeadingTemplate);
	        $('#pt-gpm-step1-title-label').html(title);	
        },
        showVerificationView : function(updatesegment){
        	if(GPMUpdateModel.get('updateCompleted'))
        	{
        		Backbone.history.navigate('gpm/conifrm/'+GPMUpdateModel.get('updateMode'), { trigger: false });
        		return false;
        	}
        	
        	if(this.verificationView){
        		MemmoryMgr.clearView(this.verificationView);
        	}
        	 this.verificationView = new GPMVerificationView({ model: GPMUpdateModel });
        	 this.verificationView.render({},updatesegment);
        	 Analytics.analytics.recordNavigation('gpm:verificationView:' + updatesegment, Analytics.analytics.SHARED_SUITE);
        },
        showConfirmationView : function(updatesegment){
        	if(this.confirmationView){
        		MemmoryMgr.clearView(this.confirmationView);
        	}
        	 this.confirmationView = new GPMConfirmationView({ model: GPMUpdateModel });
        	 this.confirmationView.render({},updatesegment);
        	 Analytics.analytics.recordNavigation('gpm:confirmationView:' + updatesegment, Analytics.analytics.SHARED_SUITE);
        },
    });
    return { gpmRouter: gpmRouter };
});
