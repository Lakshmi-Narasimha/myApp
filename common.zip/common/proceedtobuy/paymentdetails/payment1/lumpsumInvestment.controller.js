/**
 * @ngdoc property
 * @name payment 1 Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details Lumpsum controller for Advisor module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function payment1Ctrl($scope, buildPlanModelService, keyValueGridConfig, TransactConstant, transactModel, $timeout, planSmartSolution, fundDetails, $stateParams, authenticationService, $cookies, truncateTextService) {


    $scope.isNewInvestor = transactModel.isNewInvestor;

    if(transactModel.getIsNewFolio())
    {
        $scope.isNewInvestor = true;
    }

    if($cookies.get('userType') === '10') {
        $scope.terms = {
            show: true
        };
    }

    $scope.lumpsumFundDetails = planSmartSolution.getLumpsumFunds();
    $scope.lumpsumFundDetails = truncateTextService.updateLabel(angular.copy($scope.lumpsumFundDetails), 'fundName', 27);
    var celltemp = '<div class="ui-grid-cell-contents" title="{{col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)].fundName_orignal}}">{{COL_FIELD}}</div>';


    $scope.lumpsumColumnDefs = [
        { field: 'fundName', displayName: 'Invest Into',data: $scope.lumpsumFundDetails, cellTemplate: celltemp, width: '210',enableSorting:false, pinnedLeft: true},
        { field: 'amount', displayName: 'Buy Amount', width:'263', enableSorting:false, cellClass: 'fti-grid-cell-rupee text-right', headerCellClass: 'text-right'},
        { field: 'dividend', displayName: 'Dividend Option', width:'520', enableSorting:false}
    ];
    var flag = false;
    $scope.accordionClicked = function() {        
        transactModel.setTransactType(TransactConstant.buy.BUY);
        $scope.showComp = true;

        if(!flag && ($stateParams.key !== TransactConstant.transact.Payment_Key)) {
            $timeout(function () {
                $scope.$broadcast("Go_To_Payment_Dtls");
            }, 0);
            flag = true;
        }        

        fundDetails.removeFundDetails();
        
        angular.forEach(planSmartSolution.getLumpsumFunds(),function(obj,ind){           
            if(!angular.isNumber(obj.amount)) {
                obj.amount = obj.amount.indexOf(',') >-1 ? obj.amount.replace(/,/g, "") : obj.amount;
            }
            fundDetails.setFundDetails(obj);
        });

        transactModel.setLumpsumFundDtls(fundDetails.getFundDetails());
    };
    
    $scope.accordionClicked();
    $scope.isOpenInvGrid = {
        'open': true      
    }; 

    $scope.$on("openLumpsumAccordion",function(){
        $scope.accordionClicked();
        $scope.isOpenInvGrid = {
            'open': true      
        };
    });

    $scope.$on("openSipAccordion",function(){
        $scope.isOpenInvGrid = {
            'open': false                
        };
    });
}

payment1Ctrl.$inject = ['$scope', 'buildPlanModelService', 'keyValueGridConfig', 'TransactConstant', 'transactModel', '$timeout', 'planSmartSolution', 'fundDetails', '$stateParams', 'authenticationService', '$cookies', 'truncateTextService'];
module.exports = payment1Ctrl;