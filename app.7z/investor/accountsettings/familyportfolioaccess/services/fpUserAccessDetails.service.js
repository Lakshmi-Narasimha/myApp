/**
 * @ngdoc service
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var familyPortfolioUserAccessDetailsModel= function(Restangular, $q,   authenticationService) {
    var _fPfolioUserAccessDetails = null,
    familyPortfolioUserAccessDetailsModel = {
        fetchFamilyPFUserAccessList : function () {
            var params = {},
            deferred = $q.defer();
            params.guId = authenticationService.getUser().guId;
            Restangular.one('/profile/portfolioMembers').get(params).then(function (fPfolioUserAccessList) {
                deferred.resolve(fPfolioUserAccessList);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        removeOrAddGrantAccess : function(params){
           var deferred = $q.defer();
            params.guId = authenticationService.getUser().guId;
            console.log('remove');
            console.log(params);
            Restangular.one('/profile/portfolioAccess').get(params).then(function (fPfolioUserAccessList) {
                deferred.resolve(fPfolioUserAccessList);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise; 
        },
        setFamilyPFUserAccessList : function (fPfolioUserAccessList) {
            _fPfolioUserAccessDetails = fPfolioUserAccessList;
        },
        getFamilyUserAccessPFList : function () {
            if (!angular.isDefined(_fPfolioUserAccessDetails)) {
                return null;
            }
            return _fPfolioUserAccessDetails;
        }
    };
    return familyPortfolioUserAccessDetailsModel;
};
familyPortfolioUserAccessDetailsModel.$inject = ['Restangular', '$q', 'authenticationService'];
module.exports = familyPortfolioUserAccessDetailsModel;
