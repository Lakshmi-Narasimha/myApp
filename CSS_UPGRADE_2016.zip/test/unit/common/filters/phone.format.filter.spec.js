'use strict';

/* jasmine specs for filter go here */

describe('phoneFormatFilter', function() {

	var phoneFormatFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    phoneFormatFilter = $injector.get('$filter')('phoneFormat');
	}));

	//--- Test for definition

	it('should expect phoneFormatFilter to be defined...', function(){
		expect(phoneFormatFilter).toBeDefined();
	});

	//--- Test for phoneFormatFilter

	it('should properly format the 10 digit phone number...', function(){
		expect(phoneFormatFilter(8765374890)).toEqual('876-537-4890');
	});

});