// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var PanFolioKycSchema = new mongoose.Schema({
    'folioDetails': {
        'type': Object,
        'default': {}
    }
});

var PanFolioKycLookUp = mongoose.model('PanFolioKycLookUp', PanFolioKycSchema);

var PanFolioKycModel = new PanFolioKycLookUp({
    'folioDetails': {
        'pan': 'CHDQR9223F',
        'panFolioKyc': [{
            'folioId': '13352194',
            'accessRight': ' ',
            'holdingType': 'ANYONE OR SURVIVOR',
            'fsFlag': 'N',
            'folioDisplay': '13352194',
            'lastTxnBroker': ' ',
            'holders': [{
                'aadharNo': '123456789012',
                'balAmount': '',
                'kycSource': 'null',
                'kycStatus': 'KYC - Not Registered',
                'modeOfKyc': '',
                'name': 'PUVVADA SWARNA LATHA ANANTHA VIJAY K VYAS',
                'pan': 'CVDQR2159F',
                'type': 'Firstholder'
            }, {
                'aadharNo': '123456789012',
                'balAmount': '',
                'kycSource': '',
                'kycStatus': '',
                'modeOfKyc': '',
                'name': 'ABDDD',
                'pan': 'CVDQR2159F',
                'type': 'Secondholder'
            }]
        }, {
            'folioId': '17023676',
            'accessRight': ' ',
            'holdingType': 'Single',
            'fsFlag': 'Y',
            'folioDisplay': '17023676-FS',
            'fundName':'Franklin Saving Fund',
            'lastTxnBroker': 'INTEGRATED ENTERPRISES (INDIA) LTD - ARN-0962',
            'holders': [{
                'aadharNo': 'null',
                'balAmount': '',
                'kycSource': 'CVLKRA',
                'kycStatus': 'KYC - Registered',
                'modeOfKyc': '',
                'name': 'RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI',
                'pan': 'CHDQR9223F',
                'type': 'Firstholder'
            },{
                'aadharNo': '',
                'balAmount': '',
                'kycSource': '',
                'kycStatus': '',
                'modeOfKyc': '',
                'name': '',
                'pan': '',
                'type': 'Secondholder'
            }]
        }]
    }
});

PanFolioKycLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PanFolioKycLookUp table, please contact admin...' + err);
    } else {
        PanFolioKycLookUp.remove({}, function (err) {
            console.log('PanFolioKycLookUp collection removed' + err);
            PanFolioKycModel.save(function (err) {
                if (err) {
                    console.log('Having toruble in creating ValidateKycLookUp table, please contact admin...');
                }
                console.log('ValidateKycLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PanFolioKycLookUp;
