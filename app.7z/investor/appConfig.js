/**
*@ngdoc overview
*@name FTIC Config
*@requires AngularyticsProvider, KeepaliveProvider, IdleProvider
*@description
*<p>
* Defines default route, Configure the idle time for the application
* 
*</p>
* @project FTIC 
* @Date
* @version 1.0
* @author DEE | Digital Engagement Practice @Cognizant.com
*/


// This config file does not define any routes.
// For module-level route definitions, use the *Routes.js files found in the module folders.

'use strict';

function appConfig($urlRouterProvider, $locationProvider, $httpProvider, AngularyticsProvider, $StateProvider, KeepaliveProvider, IdleProvider) {

    // Add hashbang prefix for SEO and HTML5 mode to remove #! from the URL.
    // Html5 mode requires server-side configuration. See http://bit.ly/1qLuJ0v
    // $locationProvider.html5Mode(true).hashPrefix('!');
    // For any unmatched url, redirect to /
    $StateProvider
        .state('home', {
            name: 'home',
            url: '/',
            data: {
                pageTitle: 'Dashboard'
            },
            views: {
                'content@': {
                    template: require('./home.html'),
                    controller: 'InvestorController'
                },
                'dashboard@home': {
                    template: require('./dashboard/dashboard.html'),
                    controller: 'DashboardController'
                }
                //'aside': {
                //    templateUrl: 'platform/views/aside.html'
                //},
                //'content': {
                //    templateUrl: 'platform/views/content.html'
                //}
            }
        });

    $urlRouterProvider.otherwise('/dashboard');
    /*$httpProvider.defaults.headers.common = {};
    $httpProvider.defaults.headers.post = {};
    $httpProvider.defaults.headers.put = {};
    $httpProvider.defaults.headers.patch = {};*/
    $httpProvider.interceptors.push('errorInterceptor');
    // $httpProvider.defaults.useXDomain = true;
    // $httpProvider.defaults.withCredentials = true;

    AngularyticsProvider.setEventHandlers(['Console', 'GoogleUniversal']);
    IdleProvider.idle(300);
    IdleProvider.timeout(10);
    KeepaliveProvider.interval(1);
}

appConfig.$inject = ['$urlRouterProvider', '$locationProvider', '$httpProvider', 'AngularyticsProvider', '$stateProvider', 'KeepaliveProvider', 'IdleProvider'];
module.exports = appConfig;