'use strict';
describe('Controller: ReviewSwpCtrl', function() {
	var $controller,$scope,ReviewSwpCtrl,reviewSwpDetailsModel,eventConstants,authenticationService;

	var advisor = false;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_reviewSwpDetailsModel_,_eventConstants_,_authenticationService_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();	

		reviewSwpDetailsModel = _reviewSwpDetailsModel_;
		eventConstants = _eventConstants_;
		authenticationService = _authenticationService_;

		reviewSwpDetailsModel.setReviewSwpObj({});
		if(advisor){
        	authenticationService.setUser({                                        
    			"userId" : "test123"        
    		});	
        }

        $scope.config = {};
		loadController();			
	}));	

	function loadController(){
        ReviewSwpCtrl = $controller('ReviewSwpCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(ReviewSwpCtrl).toBeDefined();
    });

    it('should define the variables toTxnDetailsState,toState if investor logged in',function(){
    	expect($scope.config.toTxnDetailsState).toBe('invTransact.txnDetails');
    	expect($scope.config.toState).toBe('invTransact.base.swp');  
    	advisor = true;  	
    });

    it('should define the variables toTxnDetailsState,toState if advisor logged in',function(){
    	expect($scope.config.toTxnDetailsState).toBe('transact.txnDetails.swp');
    	expect($scope.config.toState).toBe('transact.base.swp');    	
    });

    it('should listen the event eventConstants.ACTION_ICON_CLICKED when triggered',function(){
      	spyOn($scope,"$emit");
    	$scope.$broadcast(eventConstants.ACTION_ICON_CLICKED);
    	expect($scope.$emit).toHaveBeenCalledWith("NAVIGATE_TO_TRANSACT", {key: 'SWP'});
    	expect(reviewSwpDetailsModel.getReviewSwpObj().isEditSWP).toBe(true);    	
    });
});