// getRecommendedPlan.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FundModalSchema = new mongoose.Schema({
    fundModalPlanResp: {
        type: Array,
        "default": []
    }
});

var fundModalPlanLookUp = mongoose.model('fundModalPlanLookUp', FundModalSchema);

var fundModalPlanModel = new fundModalPlanLookUp({
  fundModalPlanResp: [
      {
        "fundModalPlanResp": {
          "fundDetails": [
            {
              "fundName": "Franklin India Prima Fund",
              "fundId": 4756,
              "fundDescription": "Invests in companies at an early stage of business and have potential for growth",
              "suitableFor": "Retirement Corpus,Child’s Marriage,Long Term Wealth Creation",
              "rating": 4,
              "aum": "?38,457,234,673.80",
              "aumAsOfDate": "31/01/2016",
              "fundInceptionDate": "1993-12-01",
              "riskLevel": "moderately-high",
              "taxImplication": "Nil long term capital gains (LTCG) tax if held for more than 12 months\nDividends are tax free and carry NIL Dividend Distribution Tax",
              "fundScheme": "An Open-end growth scheme",
              "equityExposure": [
                {
                  "name": "Equity",
                  "value": 95.98
                },
                {
                  "name": "Fixed Income",
                  "value": "0.00"
                },
                {
                  "name": "Cash & Cash Equivalents",
                  "value": 4.02
                }
              ],
              "entryLoad": "Nil",
              "exitLoad": "In respect of each purchase of units - 1% if the units are redeemed/switched-out within one year of allotment",
              "minimumInvestment": 5000,
              "additionalInvestment": 1000,
              "totalExpense": "",
              "portfolioTurnover": "",
              "returnSlabs": [
                {
                  "title": "Since Inception",
                  "value": 20.55
                },
                {
                  "title": "2 Year",
                  "value": 28.61
                },
                {
                  "title": "3 Year",
                  "value": 28.59
                },
                {
                  "title": "5 Year",
                  "value": 19.43
                },
                {
                  "title": "10 Year",
                  "value": 12.69
                }
              ]
            },
            {
              "fundName": "Franklin India Flexi Cap Fund",
              "fundId": 4752,
              "fundDescription": "Invests in large, mid & small sized companies based on their growth potential",
              "suitableFor": "Retirement Corpus,Child’s Marriage,Long Term Wealth Creation",
              "rating": 5,
              "aum": "?27,953,410,432.26",
              "aumAsOfDate": "31/01/2016",
              "fundInceptionDate": "2005-03-02",
              "riskLevel": "high",
              "taxImplication": "Nil long term capital gains (LTCG) tax if held for more than 12 months\nDividends are tax free and carry NIL Dividend Distribution Tax",
              "fundScheme": "An Open-end Diversified Equity Fund",
              "equityExposure": [
                {
                  "name": "Equity",
                  "value": "92.30"
                },
                {
                  "name": "Fixed Income",
                  "value": "0.00"
                },
                {
                  "name": "Cash & Cash Equivalents",
                  "value": "7.70"
                }
              ],
              "entryLoad": "Nil",
              "exitLoad": "In respect of each purchase of units - 1% if the units are redeemed/switched-out within one year of allotment",
              "minimumInvestment": 5000,
              "additionalInvestment": 1000,
              "totalExpense": "",
              "portfolioTurnover": "",
              "returnSlabs": [
                {
                  "title": "Since Inception",
                  "value": 17.47
                },
                {
                  "title": "2 Year",
                  "value": 20.51
                },
                {
                  "title": "3 Year",
                  "value": 21.26
                },
                {
                  "title": "5 Year",
                  "value": 12.52
                },
                {
                  "title": "10 Year",
                  "value": 12.53
                }
              ]
            }
          ]
        }
      }
  ]
});

fundModalPlanLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating fundModalPlanLookUp table, please contact admin...');
    } else {
        fundModalPlanLookUp.remove({}, function(err) {
            console.log('fundModalPlanLookUp collection removed');
            fundModalPlanModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating fundModalPlanLookUp table, please contact admin...');
                }
                console.log('fundModalPlanLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = fundModalPlanLookUp;
