/**
 * @ngdoc service
 * @name instant reports service
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Instant reports service fetch the instant reports data from api and it has setter and getter methods to set/get the data whereevr needed.
 *
 */

'use strict';

var instantReportsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, validateUserModel) {
    var _InstantRepsDtls = null;
    var instantReportsModel = {
        
        fetchInstantReportsDetails : function (userType) {
            var params = {};
            params.guId = authenticationService.getUser().guId;
            params.distId = userType.distId || '';
            params.emailId = userType.emailId || '';
            params.userType = userType.userType || '';

            var message =  loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.REPORTS_DETAILS + ' | ' + loggerConstants.INSTANT_REPORTS_DETAILS_MODEL + ' | fetchInstantReportsDetails' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            
            var deferred = $q.defer();
            Restangular.one('services/instantReports').get(params).then(function (instantreportsdetails) {
                deferred.resolve(instantreportsdetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postInstantReportDetails : function (body) {

            var message =  loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.REPORTS_DETAILS + ' | ' + loggerConstants.INSTANT_REPORTS_DETAILS_MODEL + ' | postInstantReportDetails' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            
            var deferred = $q.defer();
            var params = {};
            params.guId = authenticationService.getUser().guId;
            params.distId = validateUserModel.getUserDetails() ? validateUserModel.getUserDetails().arnCode : '';
            params.emailId = validateUserModel.getUserDetails() ? validateUserModel.getUserDetails().emailId : '';
            params.userType = validateUserModel.getUserType() || '';
            Restangular.one('services/reportMailback').customPOST(body, "", params, {}).then(function (instantreportsdetails) {
                deferred.resolve(instantreportsdetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        getInstantRepsDtls: function() {
            return _InstantRepsDtls;
        },
        
        setInstantRepsDtls: function(instantreportsdetails) {            
            _InstantRepsDtls = instantreportsdetails.instantReportsDetails;
        }

    };
    return instantReportsModel;
};

instantReportsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', 'validateUserModel'];

module.exports = instantReportsModel;