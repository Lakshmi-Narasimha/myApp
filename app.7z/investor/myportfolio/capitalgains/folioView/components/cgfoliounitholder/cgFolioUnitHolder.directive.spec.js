'use strict';

describe('Directive : Capital gains unit holder', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, cgAccDetModel;

    var cgFolioData = {
        'unitHolderDetails': {
            'invname': 'Deepit Manish Banode Dholkia Motiram Umalkar',
            'address': {
                'address1': 'B-34 Acrot Street No 161 Yerapalli street',
                'address2': 'Vadapallani',
                'address3': 'Yerapalli street',
                'address4': 'Acrot Street No',
                'city': 'Chennai',
                'pinCode': '763001',
                'line1': null,
                'line2': null,
                'line3': null
            },
            "sstatus": "NRI"
        }
    };
    cgAccDetModel = {
        getCapitalGainsUnitHolder: function() {
            return cgFolioData.unitHolderDetails
        }
    }

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('cgAccDetModel', cgAccDetModel);
        });
    });
    var getCompiledElement = function() {
        var element = angular.element('<ftic-capital-gains-folio-unit-details></ftic-capital-gains-folio-unit-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _cgAccDetModel_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            cgAccDetModel = _cgAccDetModel_;

            directiveEle = getCompiledElement();
            isolatedScope = directiveEle.isolateScope();
        });
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have defined capGainunitHolder from isolated scope', function() {
        expect(isolatedScope.unitHolderDetails).toBeDefined();
        expect(isolatedScope.unitHolderDetails.invname).toBe('Deepit Manish Banode Dholkia Motiram Umalkar');
        expect(isolatedScope.unitHolderDetails.sstatus).toBe('NRI');
        expect(isolatedScope.unitHolderDetails.address).toBeDefined();
    });
});
