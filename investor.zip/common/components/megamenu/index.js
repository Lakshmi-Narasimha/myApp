'use strict';

module.exports = angular.module('commmon.components.megamenu', [
		require('./dropdown').name,
		require('./navbar').name
	]);