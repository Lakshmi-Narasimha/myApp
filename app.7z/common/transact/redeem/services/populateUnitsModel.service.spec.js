'use strict';
describe('Service: unitsModel ', function() {
	var unitsModel,httpBackend,$window,fetchUnitsValuePromise;

	var UnitsResp = {
    	'units' : {
    		'value': '225'
    	}
    };

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,populateUnitsModel){	
		unitsModel = populateUnitsModel;		
        httpBackend = $httpBackend;		        
       
		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the functions fetchUnitsValue,setUnits,getUnits',function(){
		expect(unitsModel.fetchUnitsValue).toBeDefined();
		expect(unitsModel.setUnits).toBeDefined();
		expect(unitsModel.getUnits).toBeDefined();
	});

	describe("fetchAmountValue promise",function(){
		beforeEach(inject(function() {						
			fetchUnitsValuePromise = unitsModel.fetchUnitsValue();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/getUnitsValue').respond(200,[UnitsResp]);
			fetchUnitsValuePromise.then(function(response){														
				expect(response[0].units.value).toBe("225");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/getUnitsValue').respond(400,failureResponse);
			fetchUnitsValuePromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});
});	
