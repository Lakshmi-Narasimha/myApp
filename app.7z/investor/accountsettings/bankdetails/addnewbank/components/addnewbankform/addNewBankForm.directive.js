

/**
 * @ngdoc directive
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires investorConstants
 * @description
 *
 * - It displays error
 * 
 **/
'use strict';

var addNewBankForm = function(investorConstants, basisFolioModel, investorEvents, investorEventConstants, basisFolioInitialLoader, addNewBankModel, ftiAddNewBankInitialService, fticLoggerMessage, loggerConstants) {
    return {
        template: require('./addNewBankForm.html'),
        replace: true,
        scope: true,
        controller: function($scope, $filter, $state, $timeout) {
            
            var accFolioObj = {}; 
            $scope.sectionInvBanksList = [];
            $scope.currentIfscNumber = "";
            $scope.sectionInvOptsfolio = [];
            $scope.sectionInvOptsAccount = [];
            $scope.maskedBankAccNo = {
                text: 'Enter Bank Account No.',
                value: "",          
                isRequired: true,
                class: ''
            };
            $scope.bankAccNo = [{
                text: 'Confirm Bank Account No.',
                type:'number',
                value: '',
                isRequired: true,
                errorMessage:'',
                class: ''
            }];
            $scope.payInTypeObj = 
                {
                    label : 'Payin Banks',
                    value : false
                };
            $scope.payOutTypeObj = 
                {
                    label : 'Payout Banks',
                    value : false
                };
            $scope.payTypeCheck = true;
            $scope.loadIFSCDetails = function() {
                $scope.$broadcast(investorEventConstants.Eforms.INV_EFORM_BANK_SELECTED_IFSC, {title: $scope.selectedInvBankName.title});
            };
            $scope.$on(investorEventConstants.Eforms.INV_EFORM_IFSC_SEARCH_RES, function(event, data) {
                console.log(data);
                var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_EFORMS_MODULE + ' | ' + loggerConstants.INV_EF_INCLUDE_TEMPLATE_DIRECTIVE + ' | on ' + investorEventConstants.Eforms.INV_EFORM_IFSC_SEARCH_RES + ' event' /* Function Name */;
                fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
                $scope.currentIfscNumber = data.ifscCode;   
            });
            $scope.BanksListObject = {label: "Select Bank", required: 'required'};
            $scope.FolioNoObject = {text: "Folio No.", isRequired: 'required'};
            $scope.FolioAccObject = {text: "Account No.", isRequired: 'required', disabled: false};
            ftiAddNewBankInitialService.loadAllServices($scope);
            ftiAddNewBankInitialService.loadBanksList($scope);
            $scope.$on(investorEventConstants.accountSettings.INV_BANK_DETAILS, function() {
                var data = addNewBankModel.getBasisBankDetails().banksNames;
                _.each(data, function(element, index, list){
                    var banksList = null; 
                    banksList = {
                        title : element
                    };
                    $scope.sectionInvBanksList.push(banksList);
                });
                $scope.selectedInvBankName = $scope.sectionInvBanksList[0];
                $scope.loadIFSCDetails();
            });
            $scope.$on(investorEventConstants.accountSettings.INV_ADD_NEW_BANK, function() {
                var folioData = _.map(addNewBankModel.getFolioNumbersList(), 'folioId');
                $scope.sectionInvOptsfolio = angular.copy(folioData);
                $scope.selectedFolioList = angular.copy(folioData);
                $scope.$emit('multiSelectDropdownOptions');
                $scope.$broadcast('setSelectDropdownOptions', 'Folio No', $scope.sectionInvOptsfolio);
                $scope.selectedInvFolioOpt = "All";
            });
            $scope.$on('multiSelectDropdownOptions', function(event, data){
                if(data) {
                    if(data.header === "Folio No") {
                        $scope.sectionInvOptsAccount = [];
                        if(data.selection.length > 0) {
                            var selectedCount = data.selection.length;
                            $scope.selectedInvFolioOpt = selectedCount + " Folios Selected";
                        }else {
                            $scope.selectedInvFolioOpt = "Select Folio";
                        }
                    }
                    if(data.header === "Folio Account No") {
                        if(data.selection.length > 0) {
                            var selectedCount = data.selection.length;
                            $scope.selectedInvAccOpt = selectedCount + " Accounts Selected";
                            for (var i in data.selection) {   
                                $scope.addNewBankForm.folioAccounts.push(data.selection[i]);
                            }
                        }else {
                            $scope.selectedInvAccOpt = "Select Account No";
                        }
                    }  
                }    
                if  ((data && data.header === "Folio No") || $scope.selectedInvFolioOpt === "All") {
                    _.each(addNewBankModel.getFolioNumbersList(), function(element, index, list){  
                        if($scope.selectedInvFolioOpt === "All") {
                            _.each(element.folioAccounts, function(value, index) {
                                $scope.sectionInvOptsAccount.push(value);
                            })
                        }else{
                            _.each(data.selection, function(value, index) { 
                                if(value === element.folioId){
                                    _.each(element.folioAccounts, function(value, index) {
                                        $scope.sectionInvOptsAccount.push(value);
                                    })
                                }
                            })
                        }
                    });
                } 
                $scope.$watch('$scope.addNewBankForm.folioAccounts', function() {
                    if(data) {
                        if(data.selection.length) {
                            $scope.$broadcast('setSelectDropdownOptions', 'Folio Account No', $scope.sectionInvOptsAccount);
                            $scope.selectedInvAccOpt = "All";
                            $scope.FolioAccObject.disabled = false;
                        }else {
                            $scope.selectedInvAccOpt = "Select Account No";
                            if(data.header === "Folio No") {
                                $scope.FolioAccObject.disabled = true;
                            }
                        }
                    }
                });
            });

            $scope.isFolioSelected = function() {
                if($scope.selectedInvAccOpt === "Select Account No" || $scope.selectedInvFolioOpt === "Select Folio") {
                    return true;
                }else {
                    return false;
                }
            }

            $scope.isPayTypeChecked = function() {
                if($scope.payInTypeObj.value || $scope.payOutTypeObj.value) {
                    return false;
                }else {
                    return true;
                }
            }

            $scope.addNewBank = function() {
                var bankAccountNum = $scope.maskedBankAccNo.value;
                var cnfrmBankAccountNum = $scope.bankAccNo[0].value;
                var regExPattern = new RegExp(/^\d+$/);
                if(regExPattern.test(bankAccountNum)) {    
                    $scope.maskedBankAccNo.class = "";
                    $scope.maskedBankAccNo.errorMessage = "";                
                    if (bankAccountNum != cnfrmBankAccountNum) {
                        $scope.bankAccNo[0].class = "errBrd";
                        $scope.bankAccNo[0].errorMessage = "ERROR_LABEL";
                    } else {
                        $scope.bankAccNo[0].class = "";
                        $scope.bankAccNo[0].errorMessage = "";
                    } 
                }else {
                    $scope.maskedBankAccNo.class = "errBrd";
                    $scope.maskedBankAccNo.errorMessage = "ERROR_LABEL";
                }
                var newBankDetails = {
                    "bankName": $scope.selectedInvBankName.title,
                    "accountNo": $scope.maskedBankAccNo.value,
                    "ifscCode": $scope.currentIfscNumber,
                    "folioNo": $scope.selectedInvFolioOpt.title,
                    "folioAccountNo": $scope.selectedInvAccOpt.title,
                    "payInType": $scope.payInTypeObj.value,
                    "payOutType": $scope.payOutTypeObj.value
                }
            }
        }
    }
}

addNewBankForm.$inject = ['investorConstants','basisFolioModel','investorEvents','investorEventConstants','basisFolioInitialLoader','addNewBankModel','ftiAddNewBankInitialService','fticLoggerMessage','loggerConstants'];
module.exports = addNewBankForm;
