var fs = require('fs');
var path = require('path');
var _ = require('lodash');

var clientListService = function () {
    var initialDataFolder = '/initial-data/clientList';

    // public functions

    this.getClientList = function (requestData, success, error) {
        var dirPath = __dirname + initialDataFolder;
        var filePath = path.join(dirPath, 'clientref');
        // read the contents of the file specified in server.js and serve the response
        fs.readFile(filePath, 'utf8', function (err, data) {
            if (err) {
                // send error if file reading fails
                error(err);
            } else {
                success(JSON.parse(data));
            }
        });
    };

};

module.exports = new clientListService();