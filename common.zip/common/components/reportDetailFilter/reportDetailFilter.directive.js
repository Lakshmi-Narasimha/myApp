/**
 * @ngdoc property
 * @name fticcmpfilter Directive
 * @description
 *
 * - Composite filter enables the input field according to type selection. UI Bootstrap datepicker integrated.
 *
 **/
'use strict';
var reportDetailFilter = function ($window, toaster) {
    return {
        restrict: 'EA',
        replace: true,
        template: require('./reportDetailFilter.directive.html'),
        scope: {
            filterOptions: "=",
            hideSelect: '=?',
            selectedObj: '=?'
        },
        controller: ['$scope', function ($scope) {
            $scope.changedOptions = function () {
                if ($scope.selected) {
                    $scope.$emit('selectedFilterValue', $scope.selected);
                    $scope.$emit('showFilterValue', $scope.selected);
                }
            }
        }]
    }
}
reportDetailFilter.$inject = ["$window", "toaster"];
module.exports = reportDetailFilter;