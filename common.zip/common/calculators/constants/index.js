/**
 *@ngdoc object
 *@name guest.module:Constants
 *@description
 * <p>
 * Calling the services those are for showing the pages
 * </p>
 * @project FTIC
 */



'use strict';
// Home View
module.exports = angular.module('calculators.constants', [])
	.config(require('./messages'))
	.constant('calculatorsConstants', require('./calculators.constants'))
    .constant('calculatorsEventConstants', require('./calculatorsEvent.constants'));