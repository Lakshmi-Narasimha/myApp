// getRecommendedPlan.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RecommendedPlanSchema = new mongoose.Schema({
    recommendedPlanResp: {
        type: Array,
        "default": []
    }
});

var recommendedPlanLookUp = mongoose.model('recommendedPlanLookUp', RecommendedPlanSchema);

var recommendedPlanModel = new recommendedPlanLookUp({
  recommendedPlanResp: [
      {
          "recomendedPlanResp": {
            "installmentDetails":[
                    {
                      text: 'Monthly',
                      value: '1400'
                    }, 
                    {
                      text: 'Annually',
                      value: '14000'
                    }, 
                    {
                      text: 'One time',
                       value: '200000'
                    }
             ],
            "goalForeCast": {
              "goalAmount": "2,00,000",
              "data": [
                {
                  "years": "4ys",
                  "amount": 400000
                },
                {
                  "years": "8ys",
                  "amount": 800000
                },
                {
                  "years": "12ys",
                  "amount": 1200000
                },
                {
                  "years": "16ys",
                  "amount": 900000
                },
                {
                  "years": "20ys",
                  "amount": 2000000
                }
              ]
            },
            "fundDetails": [
              {
                "fundName": "Franklin India Blue Chip Fund",
                "fundId": 4752,
                "fundDescription": "To provide long-term capital appreciation by investing predominantly in large cap.",
                "suitableFor": "Retirement, Wealth Creation",
                "rating": "CPR1",
                "annualizedGrowthRate": "6.5%",
                "returnSlabs":[
                      { title:"Since Inception", value:"6.5"},
                      { title:"1 Year", value:"7.5"},
                      { title:"3 Years", value:"8.5"}
                  ],
                "addnFundDetails":"",
                "priority": "1"
              },
              {
                "fundName": "Franklin India Prima Plus",
                "fundId": 4756,
                "fundDescription": "To provide long-term capital appreciation by investing predominantly in large cap.",
                "suitableFor": "Retirement, Wealth Creation",
                "rating": "CPR1",
                "annualizedGrowthRate": "6.5%",
                "returnSlabs":[
                      { title:"Since Inception", value:"6.5"},
                      { title:"1 Year", value:"7.5"},
                      { title:"3 Years", value:"8.5"}
                  ],
                "addnFundDetails":"",
                "priority": "2"
              }
            ]
          }
      }
  ]
});

recommendedPlanLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating recommendedPlanLookUp table, please contact admin...');
    } else {
        recommendedPlanLookUp.remove({}, function(err) {
            console.log('recommendedPlanLookUp collection removed');
            recommendedPlanModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating recommendedPlanLookUp table, please contact admin...');
                }
                console.log('recommendedPlanLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = recommendedPlanLookUp;
