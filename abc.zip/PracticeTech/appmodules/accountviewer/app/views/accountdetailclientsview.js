define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailclientsview.html',
  'appcommon/commonutility'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml, Utils) {

    var SectionView = AccountDetailSectionView.extend({
        events: { 
          'click [pt-account-detail-client-link]': 'handleClientClicked',
        },
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetClientAccountRoles(this.accountSummary.accountId)
                .then(function(clientRoles) {
                  _.each(clientRoles, function(clientRole) {
                    clientRole.client.roleText = self.textForRoleCode(clientRole.clRoleCd)
                  })
                  var clients = self.createClientList(_.pluck(clientRoles, 'client'), self);
                  self.renderSection(SectionTemplateHtml, {clients: clients});
                })
                .fail(this.handleServiceError);
        },
        textForRoleCode: function(code) {
          var roleTextTable = {
              '000': 'UNKNOWN',
              '001': 'OWNER',
              '002': 'INSURED-BASE PLAN',
              '003': 'ANNUITANT',
              '004': 'TAXPAYER',
              '005': 'RIDER INSURED',
              '006': 'PARTICIPANT',
              '007': 'SECOND OWNER'
          };
          var text = roleTextTable[code];
          return text ? text : roleTextTable['000'];
        },
        createClientList: function (clientsData, view) {
            var clients = [];
            _.each(clientsData, function(clientData) {
              var client = _.find(clients, function(cl) {
                return cl.id == clientData.id;
              });
              if (client) {
                client.roles.push(clientData.roleText);
              } else {
                client = {id: clientData.id, fmtId: clientData.fmtId, name: view.clientName(clientData), roles: [clientData.roleText]};
                clients.push(client);
              }
            });
            return clients;
        },
        clientName: function (clientData) {
            if (clientData.orgClient) {
              return clientData.orgClient.orgNm;
            } else {
              var name = clientData.personClient.clFirstNm + " " + clientData.personClient.clLastNm;
              if (!Utils.isEmpty(clientData.personClient.clSfxTxt)) {
                name = name + ' ' + clientData.personClient.clSfxTxt;
              }
              return name;
            }
        },
        handleClientClicked: function (e) {
            var clientId = $(e.target).attr('pt-account-detail-client-link');
            if (this.clientPickHandler) {
              this.clientPickHandler(clientId);
            }
        },
    });

    return SectionView;
});