//getSelectFundDtls
'use strict';

var sfModel = function (Restangular, $q, fticLoggerMessage, loggerConstants) {
	 var _sfDtls = null;
	 var _selectedFundDtls = null;
	 var sfModel = {
		fetchSelectFundDetails : function (selectedInv) {
			selectedInv.folioId = selectedInv.folioId;
			selectedInv.type = "S";
			selectedInv.userType = "D";
			selectedInv.distId = "ARN-23800";
		    	           
		    var deferred = $q.defer();
		     Restangular.one('getSelectFundDtls').get(selectedInv).then(function (sfdetails) {		     
		        deferred.resolve(sfdetails);

		    }, function (resp) {
		        deferred.reject(resp);
		        console.log('error');
		    });
		    return deferred.promise;
		},

		getSelectFundGridDtls: function() {
			return _sfDtls;
		},
		setSelectFundGridDtls: function(sfdetails) {			
			_sfDtls = sfdetails;
		},

		getSelectFundDtls: function() {            
			return _selectedFundDtls;
		},
		setSelectFundDtls: function(selectedFundDtls) {            
			_selectedFundDtls = selectedFundDtls;
		}

	  };
	  return sfModel;

};

sfModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = sfModel;