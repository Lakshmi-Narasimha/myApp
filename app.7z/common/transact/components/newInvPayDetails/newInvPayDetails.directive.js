/**
 * @ngdoc property
 * @name fticPaymentForm Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Redemption Form.
 *
 **/
'use strict';

var fticExistingInvPayDetails = function (bankDtlsModel, transactModel, $state, fundDetails, eventConstants, TransactConstant, $stateParams, transactEventConstants, sipDetailsModel, paperlessModel, buildPlanModelService, investorRegistrationModel, $filter, paymentDetailsUtility, authenticationService,profileDetailsModel, appConfig, configUrlModel, $window, constants, transactNowModel, toaster) {
    return {
        template: require('./newInvPayDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
          reviewState : '=?',
          type: '=?'
        },
        controller:['$scope', function ($scope) {

            var accordion, 
                transactionType, 
                webRefNo, 
                paymentMode, 
                frequency, 
                fundArr, 
                fundObj, 
                debitType, 
                datefilter = $filter('date'), 
                modeOfPay, 
                nextPayMode, 
                autoDebitPeriod,
                custBankParams = {},
                advisorProfile = profileDetailsModel.getProfileDtls(),
                accType = null,
                flowType = null,
                transaction = "";

                
            $scope.disableContinue = true;
            $scope.isPaperLess = transactModel.isPaperless;
            if(paperlessModel.invType.getInvType()=== "SmartSoln")
            {
                $scope.isPaperLessSmartSol = true;                  
            }
            
            $scope.investorLeg = (($stateParams.from===TransactConstant.investorleg.INVESTORLEG) || transactModel.isRetryPaymentInvestorLeg || transactModel.isRetryPayment) ? true:false;            
            $scope.isValid = false;
            $scope.disableNetBank = true;
            $scope.disableNewMandate = true;
            $scope.disableMultiMode = true;
            $scope.disableDebit = true;
            $scope.disableNeft = true;
            $scope.continueButton =false;
            $scope.hideContinue = false;
            $scope.methodRequired = true;

            $scope.mode = {};
            $scope.mode.selectedVal = null;

            $scope.showMultiPayMode = false;
            var validateBuyParams={};

            $scope.confirmObject = {
                  label : TransactConstant.transact.CONFIRMATION_LABLE,
                  value : false,
                  required : true,
                  name: 'confirmCheck'
            };

            $scope.$on("ChangePaymentOnChange", function () {
                $scope.mode.selectedVal = "";
                $scope.showNewMandate = false;
                $scope.showMultiPayMode = false;
            })

            var transactType = transactModel.getTransactType();
            console.log(transactModel.getIsSmartSol())
            //Check flow
            if(transactModel.getIsSmartSol()) {
              $scope.isSmartSol=true;
               //$scope.isBuy = false;
            }else if(transactType === TransactConstant.sip.SIP || transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.renewSip.RENEWSIP) {
                $scope.isSIP = true;
            } else if(transactType === TransactConstant.buy.BUY || transactType === TransactConstant.buy.BUYFUND) {
                $scope.isBuy = true;
            } else if(transactType === TransactConstant.modifySip.MODIFYSIP) {
                $scope.isModifySIP = true;
            }

            var payMethod = bankDtlsModel.getPaymentMethod();
            
            /*if(accordion === "lumpsum"){
                payMethod = bankDtlsModel.getLumpsumPaymentMethod()
            }else if(accordion === "sip"){
                payMethod = bankDtlsModel.getSipPaymentMethod()
            }*/

            if(payMethod !== TransactConstant.transact.SETUP_NEW_MANDATE && payMethod !== TransactConstant.transact.AUTO_DEBIT) {
                if($scope.isSIP) {
                  bankDtlsModel.setTotalAmount(sipDetailsModel.getSipTotalAmount());

                  /*if(accordion === "lumpsum"){
                      bankDtlsModel.setLumpsumTotalAmount(sipDetailsModel.getSipTotalAmount());
                  }else if(accordion === "sip"){
                      bankDtlsModel.setSipTotalAmount(sipDetailsModel.getSipTotalAmount());
                  }*/
                } else if($scope.isBuy) {
                    bankDtlsModel.setTotalAmount(fundDetails.getBuyTotalAmount());
                    /*if(accordion === "lumpsum") {
                        bankDtlsModel.setLumpsumTotalAmount(fundDetails.getBuyTotalAmount());
                    } else if(accordion === "sip") {
                        bankDtlsModel.setSipTotalAmount(fundDetails.getBuyTotalAmount());
                    }*/
                                        
                }
            }
          
            
            $scope.$on('bankSelected', function(event, data) {
                // Reset form on change of bank selection
                $scope.mode.selectedVal = null;
                $scope.showPayeeDetails = false;
                var payMethod = bankDtlsModel.getPaymentMethod();
                var nextPayMethod = bankDtlsModel.getFutureInstPayMethod();

                /*if(accordion === "lumpsum"){
                    payMethod = bankDtlsModel.getLumpsumPaymentMethod();
                }else if(accordion === "sip"){
                    payMethod = bankDtlsModel.getSipPaymentMethod();
                }*/

                switch(payMethod) {
                  case TransactConstant.transact.SETUP_NEW_MANDATE:
                        $scope.showNewMandate = false;
                        bankDtlsModel.setPaymentMode("")
                        break;
                  case TransactConstant.transact.MULTIPLE_PAY_MODE:
                        $scope.showMultiPayMode = false;
                };

                switch(nextPayMethod) {
                  case TransactConstant.transact.AUTO_DEBIT:
                        $scope.showMultiPayMode = false;
                        break;
                  case TransactConstant.transact.BILL_PAY:
                        $scope.showMultiPayMode = false;
                };

                if(data.key !== 'select') {
                      $scope.disableNetBank = true;
                      $scope.disableNewMandate = true;
                      $scope.disableMultiMode = true;

                      enablePaymentMethod(data.title);
                }
            });

            $scope.payMethodChanged = function(value) {
                
                bankDtlsModel.setPaymentMethod(value);
                /*if(accordion === "lumpsum"){
                    bankDtlsModel.setLumpsumPaymentMethod(value);
                } else if(accordion === "sip"){
                    bankDtlsModel.setSipPaymentMethod(value);
                }*/
                $scope.showNewMandate = false;
                $scope.showMultiPayMode = false;
                $scope.showPayeeDetails = false;
                $scope.disableContinue = false;
                bankDtlsModel.setIsMultiPayMode(false);
                bankDtlsModel.setIsAutoBankError(false);
                bankDtlsModel.setIsMultiBankError(false);
                
                switch(value) {
                  case TransactConstant.transact.SETUP_NEW_MANDATE:
                        $scope.showNewMandate = true;
                        break;
                  case TransactConstant.transact.MULTIPLE_PAY_MODE:
                        $scope.showMultiPayMode = true;
                        bankDtlsModel.setIsMultiPayMode(true);
                        /*if(accordion === "lumpsum"){
                            bankDtlsModel.setIsMultiPayModeLumpsum(true);
                        }else if(accordion === "sip"){
                            bankDtlsModel.setIsMultiPayModeSip(true);
                        }*/
                        break;
                  case TransactConstant.transact.NEFT_RTGS:
                        $scope.showPayeeDetails = true;
                        break;
                }

                if(TransactConstant.transact.MULTIPLE_PAY_MODE !== value) {
                    bankDtlsModel.setIsMultiBankError(false);
                    bankDtlsModel.setNextPaymentMode("");
                }
                if(TransactConstant.transact.AUTO_DEBIT !== value) {
                    bankDtlsModel.setIsAutoBankError(false);
                }
                if(TransactConstant.transact.SETUP_NEW_MANDATE !== value) {
                    bankDtlsModel.setIsNewAccBankError(false);
                }                
                if(TransactConstant.transact.AUTO_DEBIT !== value && TransactConstant.transact.SETUP_NEW_MANDATE !== value) {
                    bankDtlsModel.setIsFundAmountError(false);
                    bankDtlsModel.setIsFixedAmountError(false);
                    bankDtlsModel.setIsSipFreqError(false);
                }
            };

            $scope.$on(eventConstants.CHECKBOX_CHECKED, function(event, data){
                $scope.confirmPayment = data.value;
            });

            function validateSuccess(data) {

              var isBothValidated = false;
              if($scope.isPaperLess){
                // paperlessModel.paymentDtls.hasData = true;
              }
              
              if(transactModel.isRetryPayment){                    
                  $scope.$emit('PaymentRedirectionValidateSuccess',{"transaction":transaction});
              }
              
              if($scope.isPaperLess && (!$scope.isPaperLessSmartSol)){
                  paperlessModel.paymentDtls.hasData = true;
                  if(!transactModel.isRetryPayment){
                    $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
                  }                  
              }else{
                  webRefNo = data.webRefNo;
                  // var transactionType = transactModel.getTransactType();
                  
                  if(transactType === TransactConstant.sip.FUNDSIP || transactType == TransactConstant.sip.SIP || transactType === TransactConstant.renewSip.RENEWSIP){
                    transactModel.isSipValidated = true;
                    transactionType = "SIP";
                  }else if(transactType === TransactConstant.buy.BUYFUND || transactType == TransactConstant.buy.BUY){
                    transactModel.isLumpsumValidated = true;
                    transactionType = "BUY";
                  }
                  
                  if(data.webRefNo)
                  {
                    transactModel.setWebRefNo(data.webRefNo);
                    if(transactType === TransactConstant.sip.FUNDSIP || transactType == TransactConstant.sip.SIP || transactType === TransactConstant.renewSip.RENEWSIP){
                        transactModel.setSipWebRefNo(data.webRefNo);                            
                    }else if(transactType === TransactConstant.buy.BUYFUND || transactType == TransactConstant.buy.BUY){
                         transactModel.setLumpsumWebRefNo(data.webRefNo);                             
                    }
                  }        

                  if(transactModel.isLumpsumValidated&&transactModel.isSipValidated){
                      isBothValidated = true;
                  }
                            
                  paymentMode = data.paymentType;
                  
                  $scope.$emit("validated",{"isBothValidated":isBothValidated,"transactType":transactionType});
                  
                  if($stateParams.from === TransactConstant.investorleg.INVESTORLEG || transactModel.isRetryPaymentInvestorLeg){
                      $scope.$emit('postTransactTypeDetails');
                  }
              }



            }
            function handleFailure(errorResp) {
                console.log('validate sip/buy error');
                toaster.error(errorResp.data[0].errorDescription);
            }

            $scope.getSelections = function() {
                $scope.isValid = false;
                $scope.$broadcast('continueClicked');

                var isAmountError = bankDtlsModel.getIsFundAmountError() || bankDtlsModel.getIsFixedAmountError(),
                    isBankError = bankDtlsModel.getIsMultiBankError() || bankDtlsModel.getIsAutoBankError(), //For banks within multiple pay mode & autoDebit
                    isSipFreqError = bankDtlsModel.getIsSipFreqError(),
                    isAccTypeError = bankDtlsModel.getIsAccTypeError();
                if($scope.newInvPaymentForm.$valid && !isAmountError && !$scope.showBankError && !isBankError && !isSipFreqError && !isAccTypeError) {
                    if(!$scope.isExhausted) {
                        var payDetailsModel = {};

                        if($scope.isSIP) {
                          bankDtlsModel.setTotalAmount(sipDetailsModel.getSipTotalAmount());
                        } else if($scope.isBuy) {                          
                          bankDtlsModel.setTotalAmount(fundDetails.getBuyTotalAmount());
                        }
                        var payDetails = {
                              'paymentMethod' : bankDtlsModel.getPaymentMethod(),
                              'futureInstPayMethod' : bankDtlsModel.getFutureInstPayMethod(),
                              'selectedBank' : bankDtlsModel.getSelectedBank(),
                              'accountType' : bankDtlsModel.getAccountType(),
                              'accountNo' : bankDtlsModel.getAccountNo(),
                              'ifscCode' : bankDtlsModel.getIfscCode(),
                              'branchName' : bankDtlsModel.getBranchName(),
                              'branchAddress' : bankDtlsModel.getBranchAddress(),
                              'amountType' : bankDtlsModel.getAmountType(),
                              'totalAmount' : bankDtlsModel.getTotalAmount(),
                              'frequency' : bankDtlsModel.getFrequency(),
                              'startDate' : bankDtlsModel.getStartDate(),
                              'endDate' : bankDtlsModel.getEndDate()
                        }; 

                        /*if(accordion === "lumpsum"){
                            payDetails = {
                                  'paymentMethod' : bankDtlsModel.getLumpsumPaymentMethod(),
                                  'futureInstPayMethod' : bankDtlsModel.getFutureInstPayMethod(),
                                  'selectedBank' : bankDtlsModel.getSelectedBank(),
                                  'futureInstBank' : bankDtlsModel.getFutureInstBank(),
                                  'accountType' : bankDtlsModel.getAccountType(),
                                  'accountNo' : bankDtlsModel.getAccountNo(),
                                  'ifscCode' : bankDtlsModel.getIfscCode(),
                                  'branchName' : bankDtlsModel.getBranchName(),
                                  'branchAddress' : bankDtlsModel.getBranchAddress(),
                                  'amountType' : bankDtlsModel.getAmountType(),
                                  'totalAmount' : bankDtlsModel.getLumpsumTotalAmount(),
                                  'frequency' : bankDtlsModel.getFrequency(),
                                  'startDate' : bankDtlsModel.getLumpsumStartDate(),
                                  'endDate' : bankDtlsModel.getLumpsumEndDate()
                            };
                        }else if(accordion === "sip"){                            
                            payDetails = {
                                  'paymentMethod' : bankDtlsModel.getSipPaymentMethod(),
                                  'futureInstPayMethod' : bankDtlsModel.getFutureInstPayMethod(),
                                  'selectedBank' : bankDtlsModel.getSelectedBank(),
                                  'futureInstBank' : bankDtlsModel.getFutureInstBank(),
                                  'accountType' : bankDtlsModel.getAccountType(),
                                  'accountNo' : bankDtlsModel.getAccountNo(),
                                  'ifscCode' : bankDtlsModel.getIfscCode(),
                                  'branchName' : bankDtlsModel.getBranchName(),
                                  'branchAddress' : bankDtlsModel.getBranchAddress(),
                                  'amountType' : bankDtlsModel.getAmountType(),
                                  'totalAmount' : bankDtlsModel.getSipTotalAmount(),
                                  'frequency' : bankDtlsModel.getFrequency(),
                                  'startDate' : bankDtlsModel.getSipStartDate(),
                                  'endDate' : bankDtlsModel.getSipEndDate()
                            };
                        }*/

                        bankDtlsModel.setPaymentDetails(payDetails);

                        /*if(accordion === "lumpsum"){
                            bankDtlsModel.setLumpsumPaymentDetails(payDetails);    
                        }else if(accordion === "sip"){
                            bankDtlsModel.setSipInvestmentPaymentDetails(payDetails);    
                        }*/

                        payDetailsModel.investorDetails = transactModel.getInvestorDetails();
                        payDetailsModel.fundDetails = transactModel.getFundDetails();
                        payDetailsModel.paymentDetails = bankDtlsModel.getPaymentDetails();

                        transactModel.setTransactDetails(payDetailsModel);

                        modeOfPay = bankDtlsModel.getPaymentMethod();
                        switch(modeOfPay) {
                            case TransactConstant.transact.SETUP_NEW_MANDATE:
                                  bankDtlsModel.setPaymentMode(TransactConstant.common.EMANDATE_CODE);
                                  break;
                            case TransactConstant.transact.NET_BANKING:
                                  bankDtlsModel.setPaymentMode(TransactConstant.common.NET_BANKING_CODE);
                                  break;
                            case TransactConstant.transact.NEFT_RTGS:
                                  bankDtlsModel.setPaymentMode(TransactConstant.common.NEFT_CODE);
                                  break; 
                            case TransactConstant.transact.DEBIT_CARD:
                                  bankDtlsModel.setPaymentMode(TransactConstant.common.DEBIT_CARD_CODE);
                                  break;
                            case TransactConstant.transact.AUTO_DEBIT :
                                  bankDtlsModel.setNextPaymentMode(TransactConstant.common.AUTO_DEBIT_CODE);
                                  break;
                            case TransactConstant.transact.BILL_PAY :
                                  bankDtlsModel.setNextPaymentMode(TransactConstant.common.BILL_PAY_CODE);
                                  break;
                        }

                        nextPayMode = bankDtlsModel.getFutureInstPayMethod();
                        switch(nextPayMode) {
                            case TransactConstant.transact.AUTO_DEBIT:
                                  bankDtlsModel.setNextPaymentMode(TransactConstant.common.AUTO_DEBIT_CODE);
                                  break;
                            case TransactConstant.transact.BILL_PAY:
                                  bankDtlsModel.setNextPaymentMode(TransactConstant.common.BILL_PAY_CODE);
                                  break;
                        }

                        custBankParams = paymentDetailsUtility.setCustBankParams(); // custormerBank service integration
                        bankDtlsModel.postCustBankDtls(custBankParams).then(custBankSuccess, custBankFailure);

                        /*** Validate Service Integration Start***/
                        validateBuyParams.folioId = investorRegistrationModel.getNewInvestorFolioId() || "";
                        validateBuyParams.bankAccountNumber = bankDtlsModel.getAccountNo() ? bankDtlsModel.getAccountNo().toString() : "";
                        validateBuyParams.bankName = bankDtlsModel.getBankName() || "";
                        validateBuyParams.ifscCode = bankDtlsModel.getIfscCode() || "";
                        
                        accType = bankDtlsModel.getAccountType();
                        if(accType === TransactConstant.transact.SAVINGS) {
                            validateBuyParams.bankAccountType = 'SA';
                        } else if(accType === TransactConstant.transact.CURRENT) {
                            validateBuyParams.bankAccountType = 'CA';
                        }

                        validateBuyParams.batchCode = TransactConstant.common.BATCH_CODE;
                        validateBuyParams.mfCode = "WSOLNACC";
                        if($scope.isPaperLess){
                          validateBuyParams.batchCode = "WSOLNACC";
                        }
                        validateBuyParams.txnFlag = "C";

                        flowType = transactModel.getFlowType();
                        if(flowType === "advisor") {
                            validateBuyParams.source = TransactConstant.common.USER_TYPE_ADVISOR;                
                        } else { // For Transact Now, Paperless, Investor leg
                            validateBuyParams.source = "10";
                        }

                        validateBuyParams.panNo = authenticationService.getUser().pan || transactModel.getInvestorDetails().pan;

                        validateBuyParams.paymentMode = bankDtlsModel.getPaymentMode();
                        validateBuyParams.nextPaymentMode = bankDtlsModel.getNextPaymentMode() || "";
                        if(validateBuyParams.paymentMode === TransactConstant.common.EMANDATE_CODE || validateBuyParams.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE || validateBuyParams.nextPaymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                            validateBuyParams.emAmount =  bankDtlsModel.getTotalAmount() ? bankDtlsModel.getTotalAmount().toString() : "";
                            frequency = bankDtlsModel.getFrequency();
                            switch(frequency) {
                              case TransactConstant.transact.MONTHLY:
                                    validateBuyParams.emFrequency = "M";
                                    break;
                              case TransactConstant.transact.QUARTERLY:
                                    validateBuyParams.emFrequency = "Q";
                                    break;
                              case TransactConstant.transact.AS_AND_WHEN:
                                    validateBuyParams.emFrequency = "A";
                                    break;
                            }
                            debitType = bankDtlsModel.getAmountType();
                            switch(debitType) {
                              case TransactConstant.transact.MAXIMUM:
                                    validateBuyParams.debitType = "U";
                                    break;
                              case TransactConstant.transact.FIXED:
                                    validateBuyParams.debitType = "F";
                                    break;
                            }
                            validateBuyParams.emFromDate = datefilter(bankDtlsModel.getStartDate(), 'dd/MM/yyyy');
                            validateBuyParams.emToDate =  datefilter(new Date(bankDtlsModel.getEndDate()), 'dd/MM/yyyy');
                            if(validateBuyParams.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE || validateBuyParams.nextPaymentMode === TransactConstant.common.AUTO_DEBIT_CODE || validateBuyParams.paymentMode === TransactConstant.common.EMANDATE_CODE){
                                autoDebitPeriod = bankDtlsModel.getPeriod();
                                validateBuyParams.emFromDate =  "";
                                validateBuyParams.emToDate =  "";
                                validateBuyParams.untillCancel = "Y";
                                if(autoDebitPeriod === TransactConstant.transact.DATE_RANGE){
                                    validateBuyParams.emFromDate =  datefilter(bankDtlsModel.getStartDate(), 'dd/MM/yyyy');
                                    validateBuyParams.emToDate =  datefilter(new Date(bankDtlsModel.getEndDate()), 'dd/MM/yyyy');
                                    validateBuyParams.untillCancel = "N";
                                }
                            }
                        }
                         
                        $scope.advisorDetails = transactModel.getAdvDetails();
                        var investorPref = transactNowModel.getInvestPrefer();

                        validateBuyParams.distId = "";
                        if(paperlessModel.investorPreferenceOption === "direct"){
                          validateBuyParams.distId = "0000000000";
                        }else if(paperlessModel.investorPreferenceOption === "financial" && $scope.isPaperLess){
                          // validateBuyParams.distId = $scope.advisorDetails.code.split("~")[1];
                          validateBuyParams.distId = $scope.advisorDetails.code; //Proxy team will split this and set arn code as distId
                        }else if(advisorProfile) {
                            validateBuyParams.distId = advisorProfile.profileDetails.ARN;
                        }else if(investorPref) {
                            if(investorPref.investorMode === "direct"){
                              validateBuyParams.distId = "0000000000";
                            } else if(investorPref.investorMode === "financial"){              
                              validateBuyParams.distId = investorPref.code; //Proxy team will split this and set arn code as distId
                            }
                        } /*else if(advisorProfile) {
                            validateBuyParams.distId = advisorProfile.profileDetails.ARN;
                        } */else { //For Renew SIP
                            validateBuyParams.distId = authenticationService.getUser().distId;
                        }

                        if(investorPref) {
                            if(investorPref.investorMode === "direct"){
                              validateBuyParams.distId = "0000000000";
                            } else if(investorPref.investorMode === "financial"){              
                              validateBuyParams.distId = investorPref.code; //Proxy team will split this and set arn code as distId
                            }
                        } else if(advisorProfile) {
                            validateBuyParams.distId = advisorProfile.profileDetails.ARN;
                        } else { //For Renew SIP
                            validateBuyParams.distId = authenticationService.getUser().distId;
                        }

                        validateBuyParams.subBrokerARN = "";
                        validateBuyParams.euin = "";
                        validateBuyParams.euinFlag = "N";
                        if($scope.advisorDetails){
                            validateBuyParams.subBrokerARN = $scope.advisorDetails.subBrokerArn;
                            if($scope.advisorDetails.euin && $scope.advisorDetails.euin !== TransactConstant.transact.NO_EUIN){
                              validateBuyParams.euinFlag = "Y";
                              validateBuyParams.euin = $scope.advisorDetails.euin;
                            }
                        }

                        validateBuyParams.customerName = "";
                        validateBuyParams.urnNo = "";
                        validateBuyParams.umrnNo = bankDtlsModel.getAchRefNo() || "";
                        validateBuyParams.renewal = "N";
                        if(!transactModel.isRetryPaymentInvestorLeg){
                          validateBuyParams.webRefNo = transactModel.getWebRefNo() || '';
                        }                        
                        transactionType = transactModel.getTransactType();
                        if(transactionType === TransactConstant.sip.FUNDSIP || transactionType == TransactConstant.sip.SIP || transactType === TransactConstant.renewSip.RENEWSIP){
                            validateBuyParams.txnSource = "SIP";
                        }else if(transactionType === TransactConstant.buy.BUYFUND || transactionType == TransactConstant.buy.BUY){
                             validateBuyParams.txnSource = "P";
                        }
                        if(transactModel.getInvestorDetails()) {
                           validateBuyParams.customerName = transactModel.getInvestorDetails().custName; 
                        }else if(transactModel.getrawHolderDts()){
                           validateBuyParams.customerName = transactModel.getrawHolderDts()[0].unitHolder; 
                        }

                        if(validateBuyParams.txnSource === "P"){
                            validateBuyParams.fundOptions = [];
                            fundArr = fundDetails.getFundDetails();
                            for(var i in fundArr){
                                fundObj = {};
                                fundObj.fundOption = fundArr[i].fundOption;
                                fundObj.accNo = fundArr[i].accNo;
                                fundObj.amount = fundArr[i].amount.toString();
                                fundObj.dividendFlag = fundArr[i].dividendFlag;
                                fundObj.nfoFlag = fundArr[i].nfoFlag;
                                fundObj.txnType = fundArr[i].accNo !== "NEW" ? "ADD" : "NEW";
                                fundObj.perpetualFlag = "N";
                                fundObj.fundType = fundArr[i].fundType;
                                validateBuyParams.fundOptions.push(fundObj);
                            }
                            transactModel.setBuyReqParams(validateBuyParams);
                            bankDtlsModel.postValidateBuyDtls(validateBuyParams)
                            .then(validateSuccess, handleFailure);
                        } else if(validateBuyParams.txnSource === "SIP") {
                            validateBuyParams.fundOptions = [];
                            fundArr = fundDetails.getFundDetails();
                            for(var i in fundArr){
                              fundObj = {};
                              fundObj.fundOption = fundArr[i].fundOption;
                              fundObj.perpetualFlag = fundArr[i].perpetualFlag; 
                              fundObj.txnType = fundArr[i].accNo !== "NEW" ? "ADD" : "NEW";
                              fundObj.amount = fundArr[i].sipAmount ? fundArr[i].sipAmount.toString(): fundArr[i].amount;
                              fundObj.accNo = fundArr[i].accNo;
                              fundObj.dividendFlag = fundArr[i].dividendFlag;
                              fundObj.frequency = fundArr[i].frequency ==='Monthly' ? "M" :(fundArr[i].frequency === "Annually" ? "A" : (fundArr[i].frequency === "Quaterly" ? "Q" : fundArr[i].frequency || "" ));
                              fundObj.startDate = fundArr[i].startDateSS || fundArr[i].startDate;
                              fundObj.endDate = fundArr[i].endDate === "Until Cancelled" ? "" : fundArr[i].endDate;
                              fundObj.stepUpFrequency = (fundArr[i].stepUpSip === "" || fundArr[i].stepUpSip === "NA") ? "" : "A";
                              fundObj.stepUpType = fundArr[i].stepUpType || "";
                              fundObj.stepUpValue = fundArr[i].stepUpValue ? fundArr[i].stepUpValue.toString() : '';
                              validateBuyParams.fundOptions.push(fundObj);
                            }
                            validateBuyParams.urnNo = "";
                            validateBuyParams.umrnNo = bankDtlsModel.getAchRefNo() || "";
                            validateBuyParams.renewal = "N"; 

                            transactModel.setSipReqParams(validateBuyParams);
                            bankDtlsModel.postValidateSip(validateBuyParams)
                            .then(validateSuccess, handleFailure);
                        }
                        
                        transactModel.setReqParams(validateBuyParams);
                        /*** Validate Service Integration End***/
                        transactType = transactModel.getTransactType();
                        if(transactType === TransactConstant.modifySip.MODIFYSIP) {
                            $scope.$emit('setModifySipDetails');
                        } else {
                            if($scope.reviewState){
                              $state.go($scope.reviewState);
                            }
                        }
                    }
                }
            };
            
            //Paperless : Payment details continue clicked
            $scope.$on(eventConstants.PAPERLESS_CONTINUE_CLICKED, function (event){
              $scope.newInvPaymentForm.$setSubmitted();
              $scope.getSelections();
            });

            //Proceed to buy : payment details continue clicked
            $scope.$on('validateBuyForm', function(event){
                $scope.newInvPaymentForm.$setSubmitted();
                $scope.getSelections();
                if($scope.isValid){
                  paperlessModel.paymentDtls.hasData = true;
                  $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
                }
            });

             //Proceed to buy : payment details continue clicked

            $scope.$on('validateFormNewInvestor', function(event){
                $scope.newInvPaymentForm.$setSubmitted();
                $scope.getSelections();
            });

            $scope.$on("payment_form_submit", function(event, data) {
                $scope.newInvPaymentForm.$setSubmitted();
                $scope.getSelections();
            });
                        
            $scope.$on("submitTransactionClicked",function(event,data){
                transaction = data.transaction;
                $scope.newInvPaymentForm.$setSubmitted();
                $scope.getSelections();
            })


            /* Save previous selections - START*/
            function saveSelections() {
                $scope.disableContinue = false;
                //Set Payment Method
                var payMethod = bankDtlsModel.getPaymentMethod();
                var isMultiMode = bankDtlsModel.getIsMultiPayMode();

                /*if(accordion === "lumpsum"){
                    payMethod = bankDtlsModel.getLumpsumPaymentMethod();
                    isMultiMode = bankDtlsModel.getIsMultiPayModeLumpsum();
                }else if(accordion === "sip"){
                    payMethod = bankDtlsModel.getSipPaymentMethod();
                    isMultiMode = bankDtlsModel.getIsMultiPayModeSip();
                }*/
                
                if(isMultiMode) {
                  $scope.mode.selectedVal = TransactConstant.transact.MULTIPLE_PAY_MODE;
                  $scope.showMultiPayMode = true;
                } else {
                  $scope.mode.selectedVal = payMethod;
                }

                if(payMethod === TransactConstant.transact.SETUP_NEW_MANDATE) {
                  $scope.showNewMandate = true;
                } else if(payMethod === TransactConstant.transact.NEFT_RTGS) {
                  $scope.showPayeeDetails = true;
                }                

                var bankName = bankDtlsModel.getBankName();
                if(bankName){
                  enablePaymentMethod(bankName);
                }
                
            }

            //For paperless Module
            if(paperlessModel.paymentDtls.hasData){
                saveSelections();
            }

            //For Transact Module
            if($stateParams.key === TransactConstant.transact.Payment_Key) {
               saveSelections();
            }
            /* Save previous selections - CLOSE*/

            $scope.$on("hideContinue",function(event,data){                 
                $scope.hideContinue = true;                
           })

           function enablePaymentMethod(bankName) {
            if(bankDtlsModel.getPreRegBanks() !== null) {
                var bankDtls = bankDtlsModel.getPreRegBanks();
                var i = 0;
                while(bankDtls[i].bankName !== bankName) {
                  i++;
                }
                if(bankDtls[i].netBanking === 'Y') {
                   $scope.disableNetBank = false;
                   $scope.disableMultiMode = false;
                }
                if(bankDtls[i].eMandate === 'Y') {
                  $scope.disableNewMandate = false;
                }
                if(bankDtls[i].directCredit === 'Y') { //Debit Card Payment Method
                  $scope.disableDebit = false;
                  $scope.disableMultiMode = false;
                }
                if(bankDtls[i].neft === 'Y') {
                  $scope.disableNeft = false;
                  $scope.disableMultiMode = false;
                }
            }
          }

          function custBankSuccess(data) {
              console.log('customer bank service success');
          }

          function custBankFailure(data) {
              console.log('customer bank service failure');
          }
          var configURL = configUrlModel.getEnvUrl('MARKETING_URL');
          var clickHereUrl=appConfig[configURL] + '/investor/resources?firstFilter-1&secondFilter-3'; 
          $scope.clickHereTab = function(){
            $window.open(clickHereUrl,"_blank");
          }
        }]
    };
};

fticExistingInvPayDetails.$inject = ['bankDtlsModel', 'transactModel', '$state', 'fundDetails', 'eventConstants', 'TransactConstant', '$stateParams', 'transactEventConstants', 'sipDetailsModel', 'paperlessModel', 'buildPlanModelService', 'investorRegistrationModel', '$filter', 'paymentDetailsUtility', 'authenticationService','profileDetailsModel','appConfig','configUrlModel','$window','constants', 'transactNowModel', 'toaster'];
module.exports = fticExistingInvPayDetails;