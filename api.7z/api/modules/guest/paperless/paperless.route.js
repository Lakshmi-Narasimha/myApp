var express = require('express'),
    router = express.Router(),
    AdvisorSearchModel = require('./advisorsearch/advisorSearch.model');
    OtpVerificationModel = require('./otpVerification/otpVerification.model');

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */

router.route('/getAdvisorDtls')
.get(function (req, res) {
    AdvisorSearchModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].advisorSearchObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].advisorSearchObject);
        }
    });

});

router.route('/ekycOTPVerification')
.get(function (req, res) {
    OtpVerificationModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].OtpVerificationObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].OtpVerificationObject);
        }
    });

});
   
module.exports = router;
