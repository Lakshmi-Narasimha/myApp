'use strict';

var express = require('express'),
    router = express.Router(),
    GetRedemptionDetailsModel = require('./getInvRedemptionDetails.model'),
    SubmitRedemptionDetailsModel = require('./submitRedemptionTransact.model'),
    GetValidateStpModel = require('./getValidateStp.model'),
    ValidateSwitchModel = require('./validateSwitch.model'),
    GetValidateCstpModel = require('./getValidateCstp.model'),
    ValidateDtpModel = require('./validateDtp.model'),
    ValidateInvFyLimitModel = require('./getValidateInvFYLimit.model'),
    GetPaymentBankListModel = require('./getPaymentBankList.model'),
    ValidateBuyModel = require('./getValidateBuy.model'),
    GetPaymentBanksByFolio = require('./getPaymentBanksByFolio.model'),
    ModifySipModel = require('./transactSipDetails.model');

var errorObj = [{
    errorCode: 'A0003',
    errorMessage: 'Something went wrong'
}];

// get redemption route
router.route('/transact/validateSell')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GetRedemptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 

            if (err) {
                res.send(err);
            } else if (data[0].redemptionDetailsResponse.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].redemptionDetailsResponse);
            }

        });
    });

// get redemption route
router.route('/transact/validateSwitch')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ValidateSwitchModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 

            if (err) {
                res.send(err);
            } else {
                res.json(data[0].ValidateSwitchResponse);
            }

        });
    });

router.route('/transact/validateStp')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GetValidateStpModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 

            if (err) {
                res.send(err);
            } else if (data[0].GetValidateStpResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].GetValidateStpResp);
            }

        });
    });
// redemption submit route
router.route('/transact/orders')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SubmitRedemptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            // console.log(data)
            if (err) {
                res.send(err);
            } else if (data[0].submitRedemptionDetailsResponse.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].submitRedemptionDetailsResponse);
            }

        });
    });
//Cancel Stp route
router.route('/transact/cancelStp')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GetValidateCstpModel.find(function (err, data) {
            if (err) {
                res.send(err);
            } else if (data[0].GetValidateCstpResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].GetValidateCstpResp);
            }

        });
    });

//Validate DTP
router.route('/transact/registerDtp')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ValidateDtpModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].ValidateDtpResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].ValidateDtpResp);
            }
        });
    });


//transactDownload service
router.route('/transact/downloadTransSlip')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        res.send({
            status: 'S'
        });
    });

router.route('/transact/validateInvFYLimit')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        ValidateInvFyLimitModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else {
                res.json(data[0].ValidateInvFyLimitResponse);
            }
        });
    });

router.route('/transact/folioMatcher')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        res.send({
            'newFolioMatcherResp':{'folioNo':'17238713','patternExists':'true'}
        });
    });
router.route('/transact/investorRegistration')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        res.send({
            'webRefNo':'RS00014528',
            'status':'success',
            'folioId':'25138106'
        });
    });

/*router.route('/transact/validateInvFYLimit')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present

        res.send({
            'statusFlag':'A',
            'displayMessage':' ',
            'allowableTxnAmount':'45000'
        });
    });*/

router.route('/transact/updInvestorDetails')
    .post(function (req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        res.json({
            'webRefNo': 'RS00014645',
            'status': '',
            'folioId': ''
        });
    });
    
//Payment Bank Details
router.route('/transact/paymentBankList')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GetPaymentBankListModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].PaymentBankListResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].PaymentBankListResp);
            }

       }); 
    });
    //Validate Buy route
router.route('/transact/validateBuy')
    .post(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        ValidateBuyModel.find(function(err, data) {
            if (err) {
                res.send(err);
            } else if (data[0].GetValidateBuyResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].GetValidateBuyResp);
            }

        });
    });

//Payment Bank Details
router.route('/transact/paymentBanksByFolio')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        GetPaymentBanksByFolioModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].PaymentBanksByFolioResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].PaymentBanksByFolioResp[0]);
            }

       }); 
    });

 
    router.route('/transact/sipDetails')

    .get(function(req,res) {        
         ModifySipModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].ModifySipResp.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].ModifySipResp);
            }
        });

    })  




module.exports = router;