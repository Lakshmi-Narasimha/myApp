// Eforms.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TransSlipExistingFundsModelSchema = new mongoose.Schema({
    TransSlipExistingFundsObj: {
        type: Array,
        "default": []
    }
});

var TransSlipExistingFundsModelLookUp = mongoose.model('TransSlipExistingFundsModelLookUp', TransSlipExistingFundsModelSchema);

var TransSlipExistingFundsModel = new TransSlipExistingFundsModelLookUp({
    "TransSlipExistingFundsObj" : 
        {
            "funds":[
                {
                    category:'fund1',
                    title:'101018981028 -  Franklin India Balance Fund'
                },
                {
                    category:'fund2',
                    title:'201552981028 -  Franklin India Equity Fund'
                }
            ]
        }    
});

TransSlipExistingFundsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating TransSlipExistingFundsModelLookUp table, please contact admin...');
    } else {
        TransSlipExistingFundsModelLookUp.remove({}, function(err) {
            console.log('TransSlipExistingFundsModelLookUp collection removed');
            TransSlipExistingFundsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransSlipExistingFundsModelLookUp table, please contact admin...');
                }
                console.log('TransSlipExistingFundsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransSlipExistingFundsModelLookUp;