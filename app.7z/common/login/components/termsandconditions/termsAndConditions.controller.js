/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function termsAndConditionsController($scope, $uibModalStack,loginModelService,constants,tcAndSTPopupModel) { 


    $scope.accpted=false;
    $scope.accept=function(){
    	
    	//loginModelService.setChoosenOptionData($scope.accpted);
    	$scope.$emit('accptedTermsAndConditions');
    	$scope.closeModal();
    }
    $scope.doNotAccept=function(){
$scope.$emit('rejectedTermsAndConditions');
    	$scope.closeModal();
    }
     $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
   $scope.contentForTCObject = tcAndSTPopupModel.getPopUpContent();
    
   if(angular.isObject($scope.contentForTCObject)){
   //if($scope.contentForTCObject && $scope.contentForTCObject !== 'null' && $scope.contentForTCObject !== 'undefined'){
    $scope.contentForTC = $scope.contentForTCObject["accounts-content"]["tc-investor-online"].content;  
   }
   
}


termsAndConditionsController.$inject = ['$scope', '$uibModalStack','loginModelService','constants','tcAndSTPopupModel'];

module.exports = termsAndConditionsController;