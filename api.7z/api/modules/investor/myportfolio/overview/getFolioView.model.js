// getFolioView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var FolioViewSchema = new mongoose.Schema({
    viewData: {
        type: Array,
        'default': []
    }
});

var FolioViewLookUp = mongoose.model('InvFolioViewLookup', FolioViewSchema);

var FolioViewModel = new FolioViewLookUp({

    'viewData': [{
        'unitHolderDetails': {
            'invName': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
            'address': {
                'address1': 'BUDHA VILLAGE PO ASANSOL',
                'address2': 'OPP SITE SAMTHAR PETROL PUMP',
                'address3': 'MAYUR VIHAR PHASE III',
                'address4': 'HYDERABAD AP 500028',
                'city': 'DOMEIVALI',
                'pinCode': '400062',
                'line1': null,
                'line2': null,
                'line3': null
            },
            'holders': [{
                'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'ABJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }, {
                'name': 'YASMIN POLLY PATEL',
                'pan': 'CDJQL2964N',
                'kycStatus': 'KYC',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Secondholder'
            }],
            'status': 'Individual',
            'modeofOperation': 'Single',
            'bankDetails': null,
            'modeofpayment': null
        },
        'folioDetails': {
            'folioNumber': '17877097',
            'gridData': {
                'rows': [{
                    'currentValue': '92755.57',
                    'currentCost': '59998.89',
                    'accno': '1349904865101',
                    'returns': '20.46%',
                    'fund': 'Franklin India Taxshield - Growth',
                    'totalUnits': '219.347',
                    'divInvAmount': '0.00', //invest
                    'purchaseAmount': '59998.89' // reinvest
                }, {
                    'currentValue': '0.00',
                    'currentCost': '0.00',
                    'accno': '2389904865101',
                    'returns': '0%',
                    'fund': 'Franklin India Bluechip Fund - Growth',
                    'totalUnits': '0.000',
                    'divInvAmount': '0.00',
                    'purchaseAmount': '0.00'
                }, {
                    'currentValue': '29408.34',
                    'currentCost': '22499.85',
                    'accno': '4379904865101',
                    'returns': '16.81%',
                    'fund': 'Franklin India Prima Plus - Growth',
                    'totalUnits': '66.411',
                    'divInvAmount': '0.00',
                    'purchaseAmount': '22499.85'
                }],
                'footer': {
                    'totalUnits': '285.758',
                    'currentCost': '82498.74',
                    'currentValue': '122163.91'
                }
            }
        }
    }]

});

FolioViewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FolioViewLookUp table, please contact admin...');
    } else {
        FolioViewLookUp.remove({}, function(err) {
            console.log('FolioViewLookUp collection removed');
            FolioViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FolioViewLookUp table, please contact admin...');
                }
                console.log('FolioViewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FolioViewLookUp;
