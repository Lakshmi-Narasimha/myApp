// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PaymentBanksByFolioModelSchema = new mongoose.Schema({
    PaymentBanksByFolioResp: {
        type: Object,
        "default": {}
    }
});

var PaymentBanksByFolioModelLookUp = mongoose.model('PaymentBanksByFolioModelLookUp', PaymentBanksByFolioModelSchema);

var PaymentBanksByFolioModel = new PaymentBanksByFolioModelLookUp({
        PaymentBanksByFolioResp : {
            "billPay": [],
            "debit": [{
                "accTypeDesc": "Savings Account",
                "achRefNo": "",
                "amount": "",
                "amountType": "",
               "defaultFlag": "Y",
                "fromDate": "",
                "ifscCode": "UTIB0000173",
                "paymentType": "T",
                "payoutFlag": "N",
                "pbAccountType": "SA",
                "pbBankName": "AXIS BANK LTD",
                "pbMakerId": "",
                "pbPersonalAccountNumber": "442086347488894",
                "regDate": "",
                "status": "",
                "toDate": ""
            }],
            "emandate": [],
            "folioId": "17894993",
            "neftRtgs": [{
                "accTypeDesc": "Savings Account",
                "achRefNo": "",
                "amount": "",
                "amountType": "",
                "defaultFlag": "Y",
                "fromDate": "",
                "ifscCode": "UTIB0000173",
                "neftDetails": [{
                    "code": "Account Number",
                    "value": "5050CGHQF6543E"
                }, {
                    "code": "Account Type",
                    "value": "Current"
                }, {
                    "code": "Bank Name",
                    "value": "CITIBANK"
                }, {
                    "code": "Branch Name",
                    "value": "Fort, Mumbai"
                }, {
                    "code": "IFSC Code",
                    "value": " CITI0100000"
                }, {
                    "code": "Name",
                    "value": "Franklin Templeton Mutual Fund"
                }],
                "paymentType": "L",
                "payoutFlag": "N",
                "pbAccountType": "SA",
                "pbBankName": "AXIS BANK LTD",
                "pbMakerId": "",
                "pbPersonalAccountNumber": "442086347488894",
                "regDate": "",
                "status": "",
                "toDate": ""
            }],
            "netBanking": [{
                "accTypeDesc": "Savings Account",
                "achRefNo": "",
                "amount": "",
                "amountType": "",
                "defaultFlag": "Y",
                "fromDate": "",
                "ifscCode": "UTIB0000173",
                "paymentType": "W",
                "payoutFlag": "N",
                "pbAccountType": "SA",
                "pbBankName": "AXIS BANK",
                "pbMakerId": "",
                "pbPersonalAccountNumber": "442086347488894",
                "regDate": "",
                "status": "",
                "toDate": ""
            }],
            "newEmandates": [{
                "accTypeDesc": "Savings Account",
                "achRefNo": "",
                "amount": "",
                "amountType": "",
                "defaultFlag": "Y",
                "fromDate": "",
                "ifscCode": "UTIB0000173",
                "paymentType": "Z",
                "payoutFlag": "N",
                "pbAccountType": "SA",
                "pbBankName": "AXIS BANK LTD",
                "pbMakerId": "",
                "pbPersonalAccountNumber": "442086347488894",
                "regDate": "",
                "status": "",
                "toDate": ""
            }]
        }
});

PaymentBanksByFolioModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PaymentBanksByFolioModelLookUp table, please contact admin...');
    } else {
        PaymentBanksByFolioModelLookUp.remove({}, function(err) {
            console.log('PaymentBanksByFolioModelLookUp collection removed');
            PaymentBanksByFolioModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PaymentBanksByFolioModelLookUp table, please contact admin...');
                }
                console.log('PaymentBanksByFolioModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PaymentBanksByFolioModelLookUp;