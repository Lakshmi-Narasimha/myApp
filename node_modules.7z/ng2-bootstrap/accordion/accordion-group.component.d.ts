import { OnDestroy, OnInit } from '@angular/core';
import { AccordionComponent } from './accordion.component';
export declare class AccordionPanelComponent implements OnInit, OnDestroy {
    /** click able text in accordion's group header, check `accordion heading` below for using html in header */
    heading: string;
    /** provides an ability to use Bootstrap's contextual panel classes (`panel-primary`, `panel-success`, `panel-info`, etc...). List of all available classes [link](http://getbootstrap.com/components/#panels-alternatives) */
    panelClass: string;
    /** if <code>true</code> disables accordion group */
    isDisabled: boolean;
    /** is accordion group open or closed */
    isOpen: boolean;
    protected _isOpen: boolean;
    protected accordion: AccordionComponent;
    constructor(accordion: AccordionComponent);
    ngOnInit(): any;
    ngOnDestroy(): any;
    toggleOpen(event: Event): any;
}
