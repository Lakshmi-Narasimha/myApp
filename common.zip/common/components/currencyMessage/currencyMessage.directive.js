/**
 * @ngdoc directive
 * @name fticCurrMsg
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticCurrMsg will display the message based on the given label and icon class/classes.
 * 
 *
 **/
'use strict';

var currencyMessage = function() {
	return {
            template: require('./currencyMessage.html'),
            restrict: 'E',
            replace: true,
            scope: {
              label: '@',
              iconClass: '@'
            }
        };
};

currencyMessage.$inject = [];
module.exports = currencyMessage;