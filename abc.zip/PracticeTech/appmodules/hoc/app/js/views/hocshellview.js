﻿define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appcommon/memmorymgr',
    'services/dataservice',
    'appcommon/globalcontext',
    'appcommon/groupui/app/views/groupuiview',
    'appmodules/hoc/app/js/views/hocview',
    'appcommon/analytics',
    'errorLog',
    'appcommon/commonutility',
    'appcommon/constants',
    'appcommon/hocindicator',
    'text!appmodules/hoc/app/templates/hocshell.html',
    'appmodules/hoc/app/js/model/model-hoc',
    'appmodules/hoc/app/js/utils', 'appmodules/contactprofile/app/models/cpviewmodel'
], function ($, _, Backbone, Spinner, MemmoryMgr, DataService, GlobalContext, GroupUi, HOCView, Analytics, ErrorLog, CommonUtils, Constants, HOCIndicator, HOCShellTemplate, HOCModel, HOCUtils, CPViewModel) {
    var self, hocShellView = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
        },
        initialize: function () {
            self = this;
        },
        render: function (ctgCd) {
            var that = this, clId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            var _isOrgClient = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm") == null?false:true;
            var birthDate = CPViewModel.getInstance().getData().cola.clientPersonal.get('bthDt');
            this.clientId = clId;
            Spinner.show();
            var _$hocContainer = $('#hoc-content-container');
            if (_$hocContainer.length > 0) {
                //shell view already rendered, switching between tabs
                that.renderHocView(ctgCd);
            } else {
                Analytics.analytics.processHOCSubRouteChangeEvent('defaultAction');
                that.$el.html(_.template(HOCShellTemplate)).promise().done(function () {
                    //Initializing Group dropdown
                    var _clAge = undefined,_includeCtg2 = true;
                    new GroupUi({ el: $('#sharedgrpdiv') }).render();
                    DataService.getHOCListItems(clId, _includeCtg2).then(function (resp) {
                        var _listItems = CommonUtils.parseHOCListemsResponse(resp);
                        HOCIndicator.updateActionStatus(_listItems);
                        if (_isOrgClient === true) {
                            HOCModel.setModel(_listItems, _clAge);
                            that.renderHocView(ctgCd, resp);
                        } else {
                        	if (birthDate != "" && birthDate != null) {
                        	    DataService.getTaxPayerAge(clId).then(function (response) {
                        	        if (response[0] && response[0].clAge) {
                        	            _clAge = response[0].clAge;
                        	        }
                        	        HOCModel.setModel(_listItems, _clAge);
                        			that.renderHocView(ctgCd, resp);
                        		}).fail(function (error) {
                        		    HOCModel.setModel(_listItems, _clAge);
                        		    that.renderHocView(ctgCd, resp);
                        		});
                        	} else {
                        	    HOCModel.setModel(_listItems, _clAge);
                        	    that.renderHocView(ctgCd, resp);
                        	}
                        }

                    }).fail(function (err) {
                        HOCModel.clearModel();
                        Spinner.hide();
                        HOCUtils.showServiceError(err)
                        //ErrorLog.ErrorUtils.myError(err);
                    });
                });
            }

        },
        renderHocView: function (ctgCd, resp) {
            if (resp) {
                self.checkServiceError(resp);
            }
            var _serviceCounter = 0;
            var _categories = HOCModel.get('categories'),_accountInfoServiceCounter = 0;
            //check for 134 beneficiary accounts
            $.each(_categories, function (i, ctgry) {
                var _sections = ctgry.sections;
                $.each(_sections, function (j,section) {
                    var _gapItems = section.get('gapItems');
                    $.each(_gapItems, function (k, gapItem) {
                        var _secondaryValues = gapItem.get('values');
                        switch (gapItem.get("itemTypCd")) {
                            case "acctsuitmis":
                            case "missacctbeneinfo":
                            case "nobenecliovr":
                                $.each(_secondaryValues, function (l, secondaryItemArray) {
                                    var _secondaryItem = secondaryItemArray[0];
                                    if (_secondaryItem && _secondaryItem.adminCd == "134") {
                                        _serviceCounter++;
                                        _accountInfoServiceCounter++;
                                        DataService.getAccountInfo(_secondaryItem.acctId, [401]).then(function (response) {
                                            _serviceCounter--;
                                            try {
                                                var _accountIdentfiers = undefined;
                                                if (response && response[0].accountIdentifier && response[0].accountIdentifier.length > 0) {
                                                    _accountIdentfiers = response[0].accountIdentifier;
                                                    $.each(_accountIdentfiers, function (m,_acctIdntfr) {
                                                        if (_acctIdntfr.altAcctCtx == "ADMSRV.ACCT") {
                                                            _secondaryItem.propVal = "CARRIER #" + _acctIdntfr.altAcctId;
                                                        }
                                                    });
                                                }
                                              
                                            } catch (error) {
                                                console.log(error);
                                            } finally {
                                                if (_serviceCounter == 0) {
                                                    renderView();
                                                }
                                            }
                                            
                                        }).fail(function () {
                                            _serviceCounter--;
                                            if (_serviceCounter == 0) {
                                                renderView();
                                            }
                                        });
                                    }
                                });
                                break;
                            default:
                                break;
                        }
                    });
                });
            });
            if (_accountInfoServiceCounter == 0) {
                renderView();
            }
            function renderView() {
                if (ctgCd === undefined) {
                    Backbone.history.navigate("hoc/takeAction", true);
                } else {
                    var hocView = new HOCView();
                    MemmoryMgr.setcurrentview(hocView);
                    hocView.render(ctgCd);
                }
            }
            
            
        },
        checkServiceError: function (resp) {
            var _categories, _ctgry, _ctgrCd;
            if (resp && resp.length > 0) {
                _categories = HOCModel.get('categories');
                $.each(resp, function (i,data) {
                    _ctgry = null;
                    if (data.state == "rejected") {
                        switch (i) {
                            case 0:
                                _ctgrCd = 1;
                                break;
                            case 1:
                                _ctgrCd = 3;
                                break;
                            case 2:
                                _ctgrCd = 2;
                                break;
                            default:
                                break;
                        }
                        _ctgry = _categories.find(function (ctgry) {
                            return ctgry.ctgCd == _ctgrCd;
                        });
                        if (_ctgry) {
                            _ctgry.serviceError = true;
                        }
                    }
                })
            }
        }
    });
    return hocShellView;
});