'use strict';
function smartSolsModifyApplyCtrl($scope, $state, recommendedPlanInitialLoader, recommendedPlanModelService, advisorEventConstants, overviewModel, buildPlanModelService, eventConstants, planSmartSolution, sipCalculatorModel) {
    $scope.init = function () {
        $scope.smartSolnDetials = angular.copy(planSmartSolution.getSmartSolutionDetails());
        $scope.keyValueList = overviewModel.getHolderInformation();
        loadInvestmentSimulation ();
        $scope.allocationArr = buildPlanModelService.getAllocationDetails();
        $scope.fundsData = buildPlanModelService.getFundDetails();
        $scope.recommendationDetails =
        {
            installmentDetails: [
                {text: 'Monthly', value: _.sum($scope.allocationArr)}
            ],
            details: {
                "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                "investmentAmount": $scope.smartSolnDetials.investmentAmount
            }
        };
        console.log($scope.allocationArr, $scope.fundsData);
    };

    $scope.init();

    function add(a, b) {
        return a + b;
    }

    function loadInvestmentSimulation () {
        var calculatorReq = [{
            "investmentTenure": 4,//planInputDetails.investmentTenure,
            "annualizedReturn": null,
            "investmentAmount": 100000,//planInputDetails.investmentAmount,
            "fundName": "406",//$scope.smartSolnDetials.rtCode,
            "frequency" : "Monthly",
            "calculatorType": "SIP",
            "trxnType": "SIP"
        }];
        sipCalculatorModel.callSipCalculatorData({"calculatorReq": calculatorReq}, false).then(function (data) {
            var investMentSimulation = angular.copy(data.calculatorResp[0].returnData[0].periodicReturnData);
            $scope.goalChartData = {
                "data": [],
                "goalAmount": null
            };
            angular.forEach(investMentSimulation, function (value, key) {
                var chart = {};
                chart.years = value.duration;
                chart.amount = value.valueOfAmount;
                $scope.goalChartData.data.push(chart);
            });
            $scope.goalChartData.goalAmount = 100000;//planInputDetails.investmentAmount;
            planSmartSolution.setInvestmentSimulation($scope.goalChartData);
        }, function (data) {

        });
    };
    //recommendedPlanInitialLoader.loadAllServices($scope);

   /* console.log($scope.fundsData);
    $scope.total = null;
    for (var fd = 0, len = $scope.fundsData.length; fd < len; fd++) {
        $scope.fundsData[fd]["monthly"] = $scope.allocationArr[fd];
        $scope.total += parseInt($scope.allocationArr[fd]);
    }
    ;
    buildPlanModelService.totalFundsvalue = $scope.total;
    console.log($scope.fundsData);
    $scope.installmentDetails = [{
        text: 'Monthly',
        value: $scope.total
    }];
    $scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function ($event) {
        $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
        // $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
        $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
        $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
    });*/

    $scope.goBack = function () {
        $state.go('smartSol.investor.currentPlan');
    };

    $scope.goalsheetBtn = function () {
        $state.go('smartSol.investor.modifymain.modifygoalsheet');
        console.log("modify apply Goalsheet btn", $state.current.name);
        buildPlanModelService.setGoalSummaryFromState($state.current.name);
    };

    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function (event, data) {
        buildPlanModelService.isFromModifyApply = true;
        $state.go("smartSol.investor.modifymain.modify");
    });
}

smartSolsModifyApplyCtrl.$inject = ['$scope', '$state', 'recommendedPlanInitialLoader', 'recommendedPlanModelService', 'advisorEventConstants', 'overviewModel', 'buildPlanModelService', 'eventConstants', 'planSmartSolution', 'sipCalculatorModel'];
module.exports = smartSolsModifyApplyCtrl;