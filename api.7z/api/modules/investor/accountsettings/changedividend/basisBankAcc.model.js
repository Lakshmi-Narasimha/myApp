// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var InvBasisBankAccSchema = new mongoose.Schema({
    basisBankAccDetailsObject: {
        type: Object,
        "default": {}
    }
});

var InvBasisBankAccLookUp = mongoose.model('InvBasisBankAccLookUp', InvBasisBankAccSchema);

var InvBasisBankAccModel = new InvBasisBankAccLookUp({

  'basisBankAccDetailsObject': {
      "invBankDetails": [{
      "fundDetails": [{
      "fundDesc": "Franklin India Prima Plus - Dividend",
      "payInType": "E-Mandate",
      "folioAccount": "0029903636631"
      }],
      "bankName": "ICIC Bank",
      "bankAccountNo": "17259162",
      "payOutType": "Cheque",
      "ifscCode": "ICIC0000001"   
      }, {
      "fundDetails": [{
      "fundDesc": "Franklin India Bluechip Fund - Dividend",
      "payInType": "NACH",
      "folioAccount": "0069903636631"
      }],
      "bankName": "HDFC Bank",
      "bankAccountNo": "17259164",
      "payOutType": "Direct",
      "ifscCode": "HDFC0008567"   
      }, {
      "fundDetails": [{
      "fundDesc": "Franklin India Taxshield - Dividend",
      "payInType": "Pay In",
      "folioAccount": "0359903636631"
      }],
      "bankName": "Dena Bank",
      "bankAccountNo": "17259166",
      "payOutType": "Cheque",
      "ifscCode": "DENA0000010"   
      }, {
      "fundDetails": [{
      "fundDesc": "Franklin Asian Equity Fund - Growth",
      "payInType": "Bill Pay",
      "folioAccount": "3049903636631"
      }],
      "bankName": "CITI Bank",
      "bankAccountNo": "17259168",
      "payOutType": "Direct",
      "ifscCode": "CITI0000004"   
      }]
  }

});

InvBasisBankAccLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvBasisBankAccLookUp table, please contact admin...');
    } else {
        InvBasisBankAccLookUp.remove({}, function(err) {
            console.log('InvBasisBankAccLookUp collection removed');
            InvBasisBankAccModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvBasisBankAccLookUp table, please contact admin...');
                }
                console.log('InvBasisBankAccLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvBasisBankAccLookUp;
