'use strict';
describe('Services: account view initial loader service', function() {

    var mockAccountViewInitialLoader, accountViewModelData, httpBackend, Restangular, $window;
    
    var accountData = {
        "accountDetails":{  
          "gridData":{  
             "rows":[  
                {  
                   "netAmount":"0",
                   "totalUnits":"188.98",
                   "units":"34.9",
                   "nav":"123.56",
                   "amount":"6656",
                   "transaction":"Opening Balance",
                   "txnDate":"15 Nov 2015"
                },
                {  
                   "netAmount":"0",
                   "totalUnits":"189.98",
                   "units":"35.9",
                   "nav":"124.56",
                   "amount":"6657",
                   "transaction":"Opening Balance",
                   "txnDate":"16 Nov 2015"
                }
             ],
             "openingBalance":{  
                "totalUnits":"188.98"
             }
          },
          "accountNumber":"0349904865101",
          "accountName":"Franklin India Bluechip Dividend Fund"
       }
    }
    var accountFilter = {
            flag: 'P',
            guId: '878'
        };

    beforeEach(angular.mock.module('investor'));

    beforeEach(inject(function(_accountViewInitialLoader_, _accountViewModel_, $injector, _$httpBackend_, _Restangular_) {
        mockAccountViewInitialLoader = _accountViewInitialLoader_;
        accountViewModelData = _accountViewModel_;
        var $q = $injector.get('$q');
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        accountFilter = {};
    }));

    it('should loadAllServices to be defined', function() {
        expect(mockAccountViewInitialLoader.loadAllServices).toBeDefined();
    });

    describe('Services: account view initial loader service and check for success', function() {

        beforeEach(inject(function(_accountViewInitialLoader_, _accountViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
            mockAccountViewInitialLoader = _accountViewInitialLoader_;
            accountViewModelData = _accountViewModel_;
            var $q = $injector.get('$q');
            httpBackend = _$httpBackend_;
            Restangular = _Restangular_;

            httpBackend.whenGET('http://localhost:3030/clients/clientStatement?flag=A&guId=878').respond(accountData);
            $window = _$window_;
            $window.ga = function() {};
        }));

        it('should loadAllServices to be defined and load Service getAccountViewObj to be success', function() {
            mockAccountViewInitialLoader.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            }, {});
            httpBackend.flush();
            expect(accountViewModelData.getAccountViewObj().accountDetails.accountNumber).toEqual('0349904865101');
        });
    });

    describe('Services: account view initial loader service and check for failure', function() {
      
        beforeEach(inject(function(_accountViewInitialLoader_, _accountViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
            mockAccountViewInitialLoader = _accountViewInitialLoader_;
            accountViewModelData = _accountViewModel_;
            var $q = $injector.get('$q');
            httpBackend = _$httpBackend_;
            Restangular = _Restangular_; 

            httpBackend.expectGET('http://localhost:3030/clients/clientStatement?flag=A&guId=878').respond(accountData);
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should loadAllServices to be defined and expect error Services', function() {
            mockAccountViewInitialLoader.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            }, {});
            expect(mockAccountViewInitialLoader._isServicesData).toEqual(false);
        });
    });

});
