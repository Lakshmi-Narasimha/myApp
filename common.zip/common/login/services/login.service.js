'use strict';

var loginModelService = function(Restangular, $q) {
    var _choosenOption = null;

    var loginModel = {

        fetchLoginDtls: function() {

            var deferred = $q.defer();
            Restangular.all('getChoosenOptionData').getList().then(function(attrDetails) {
                deferred.resolve(attrDetails);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        setChoosenOptionData: function(data) {
            _choosenOption = data;
        },
        getChoosenOptionData: function() {
            return _choosenOption;
        }



    };
    return loginModel;

};

loginModelService.$inject = ['Restangular', '$q'];
module.exports = loginModelService;
