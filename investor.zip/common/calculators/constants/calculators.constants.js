'use strict';

var calculatorsConstants = (function() {
    return {
    	SIP_CAL : "SIP_CAL",
    	LUMP_CAL : "LUMP_CAL"
    };
}());

calculatorsConstants.$inject = [];
module.exports = calculatorsConstants;