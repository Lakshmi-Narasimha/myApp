/**
 * @ngdoc directive
 * @name fticKeyValueTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticKeyValueTile will display the kye value tiles for "My profile - Grant Access" .
 * 
 *
 **/

'use strict';

var keyValuePanel = function(paperlessModel, transactModel, $cookies) {
    return {
            template: require('./keyValuePanel.html'),
            restrict: 'E',
            replace: true,         
            scope: {
                keyValueObject: '=',
                headerText: '@?',
                actionClass: '@?'
            },
            controller:['$scope', function($scope){   
                if(	paperlessModel.invType.getInvType() === 'SmartSoln' || ( transactModel.getFlowType() === 'paperless' && $cookies.get('paperlessTxnType') === 'SmartSoln' ) ){
                    $scope.isPaperlessSS = true;
                } 
            }]
        };
};

keyValuePanel.$inject = ['paperlessModel', 'transactModel', '$cookies'];
module.exports = keyValuePanel;