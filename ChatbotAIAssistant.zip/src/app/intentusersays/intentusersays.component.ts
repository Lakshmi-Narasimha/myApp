import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
//import { LocalDataSource  } from 'ng2-smart-table';

import { UserExpression } from '../_models/userexpression';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Ng2PaginationModule } from 'ng2-pagination';

@Component({
  selector: 'intentusersays',
  templateUrl: './intentusersays.component.html',
  styleUrls: ['./intentusersays.component.css']
})

export class IntentusersaysComponent implements OnInit {

  userExpressions : Array<UserExpression> = [];
  rows : Array<UserExpression> = [];
  editMode : boolean = true;
  showhidePagination: boolean = false;

  public totalItems:number = this.userExpressions.length;
  public currentPage:number = 1;
  public itemsPerPage:number = 5;

  public maxSize:number = 5;
  public bigTotalItems:number = 175;
  public bigCurrentPage:number = 1;

  constructor(private aiAssistCacheService : AIAssistCacheService, private cd: ChangeDetectorRef) {
    this.subscribefordata();
    //this.source = new LocalDataSource(this.data); // create the source
  }

  ngOnInit() {
  }

  public setPage(pageNo:number):void {
    this.currentPage = pageNo;
  }

onPageChange(page:any):void {
   let start = (page.page - 1) * page.itemsPerPage;
   let end = page.itemsPerPage > -1 ? (start + page.itemsPerPage) : this.userExpressions.length;
   this.rows = this.userExpressions.slice(start, end);
   //console.log("inside onPageChange");
   //console.log(JSON.stringify(this.rows));
   this.cd.detectChanges();
}

public pageChanged(pevent:any) {
  console.log(pevent);
}

  private subscribefordata() {
    this.aiAssistCacheService.activeUserExpressionsObservable.subscribe((data) => {
      // console.log("inside agentcomponent subscribe before -> data -> ");
      // console.log(data);
      // console.log("agentsList -->");
      // console.log(this.agentsList);
      //this.agentsList.length = 0;
      //this.agentsList.push.apply(this.agentsList, data);
      this.userExpressions = data;
      //console.log("inside intentusersays");
      //console.log(JSON.stringify(this.userExpressions));
      this.totalItems = this.userExpressions.length;
      this.updatePaginationVisibility();
      this.onPageChange({page:1,itemsPerPage:this.maxSize});
      // console.log("inside agentcomponent subscribe after -> data -> ");
      // console.log(data);
      // console.log("agentsList -->");
      // console.log(this.agentsList);
    });
    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });
  }

  onAddInputKeyEnter(event:any) { // without type info
          // console.log(this.source.getElements());
          //console.log("event triggered");
          //console.log("event.target.value " + event.target.value);
        //   console.log(this.data);
        // this.source.add({response:event.target.value});
        this.aiAssistCacheService.addUserExpression(event.target.value);
    //this.data.push({usersays:event.target.value});// += event.target.value + ' | ';
          event.target.value = null;
  }

  removeExpression(pUserExpression : UserExpression ) {
    //console.log(pUserExpression);
    this.aiAssistCacheService.removeUserExpression(pUserExpression);
  }

  updatePaginationVisibility() {
    if (this.userExpressions != null && this.userExpressions.length > 0)
      this.showhidePagination = false;
    else
      this.showhidePagination = true;
  }

/* settings = {
columns: {
 response: {
   title: 'String'
 }
},
     hideSubHeader: true
};
     data =[
         {response:"aaa"},
         {response:"bbb"},
         {response:"ccc"},
         {response:"ddd"},
         {response:"eee"}
     ];

 source: LocalDataSource; // add a property to the component
*/


}
