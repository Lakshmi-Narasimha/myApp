var fs = require('fs');
var path = require('path');
var _ = require('lodash');

var createMGPLaunchTokenForDistributorService = function () {

    // public functions

    this.getLaunchInformation = function (req, success, error) {

        var returnData = {};
        returnData.tokenNm = 'JWTToken';
        returnData.tokenValue = 'abcdefghijklmnopqrstuvwxyz';
        returnData.launchHttpMethod = 'GET';
        returnData.launchURL = req.get('host');

        success(returnData);

    };
};

module.exports = new createMGPLaunchTokenForDistributorService();

