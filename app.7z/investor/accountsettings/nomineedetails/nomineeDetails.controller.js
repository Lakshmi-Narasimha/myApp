/**
 * @ngdoc property
 * @name NomineeDetailsController
 * @requires $state
 * @requires $scope
 * @description
 *
 * - NomineeDetailsController deals with calling the services to load to folio account details to display and edit nominee details.
 *
 **/
'use strict';
function NomineeDetailsController($state, $scope, nomineeDetailsInitialLoader, investorEvents, nomineeDetailsModel, investorEventConstants) {

	$scope.init = function () {
		$scope.nomineeListDir = false;
        $scope.showNomineeEditForm = false;
		$scope.nomineeFolio = [] ;
		$scope.nomineeDtlsObj = [];
        $scope.nomineeAccount = [];
		$scope.$on(investorEventConstants.accountSettings.NOMINEE_DETAILS, function(event){
            nomineeDetailsInitialLoader._isServicesData = true;
            $scope.folioIdLength = nomineeDetailsModel.getFolioNumbersList();
            _.each(nomineeDetailsModel.getFolioNumbersList(), function(element, index){
                var nomineeObj = null; 
                if(index === 0){
                    var selNomineeObj = {                
                        'title' : element.folioId
                    };
                    $scope.selectedFolioObj = selNomineeObj;
                    $scope.nomineeFolio.push(selNomineeObj);
                    _.each(element.rows, function(element1, index1){
                        if(element1.accountNo){
                            var nomineeAccountObj = {                
                                'title' : element1.accountNo
                            };
                            if(index1 === 0){
                                $scope.selectedAccountObj = nomineeAccountObj;
                            }
                            $scope.nomineeAccount.push(nomineeAccountObj);
                        }
                    });
                }    
                else{
                     nomineeObj = {                
                        'title' : element.folioId
                    };
                    $scope.nomineeFolio.push(nomineeObj);
                }
            });
        });
        $scope.$on('nomineeAccount', function(event, data){
            $scope.nomineeListDir = false;
            $scope.nomineeDtlsObj = [];
            _.each(nomineeDetailsModel.getFolioNumbersList(), function(element){
                _.each(element.rows, function(element1, index1){
                    if(data.title === element1.accountNo){
                        var nomineeAccountObj = {                
                            'title' : element1.accountNo
                        };                        
                        $scope.selectedAccountObj = nomineeAccountObj;
                        $scope.addNominee = false;
                        $scope.showNominee = false;
                        if(!element1.nomineeDetails){
                            $scope.nomineeDtlsLength = false;
                        } else {
                            $scope.nomineeDtlsObj.push(element1);
                            $scope.nomineeDtlsLength = true;
                            $scope.showNominee = true;
                        }
                    }
                });                
            });            
        });
        if(!nomineeDetailsInitialLoader._isServicesData){
            nomineeDetailsInitialLoader.loadAllServices($scope);
        }
        else{
            investorEvents.accountSettings.getNomineeDetails($scope);
        }
	};
	$scope.init();  
}
NomineeDetailsController.$inject = ['$state','$scope', 'nomineeDetailsInitialLoader', 'investorEvents','nomineeDetailsModel', 'investorEventConstants'];
module.exports = NomineeDetailsController;