/**
 * @ngdoc property
 * @name fticFlexiSip Directive
 * 
 * @description
 *
 * - This directive is responsible for acquiring the Flexi SIP details.
 *
 **/
'use strict';

var fticFlexiSip = function (SipModifyDetailModel, eventConstants,transactModel,transactEventConstants,$filter,fundDetails,TransactConstant) {
    return {
        template: require('./flexisip.html'),
        restrict: 'E',
        replace: true,
        scope: {
            sipType:"@"
        },
        controller:['$scope', function ($scope) {
            
            var datefilter = $filter('date');
            var susObj = transactModel.getFundDetails();
            var condCheck = false;
            $scope.strtDate= datefilter(susObj.nextTriggerDate, 'dd MMM yyyy');
            $scope.flexiSip = {};
            $scope.config = {};
            $scope.config.showNotification = false;
            $scope.showTile = function(){
                if($scope.flexForm.$valid) {
                    $scope.flexiSip.sipModifyType = $scope.sipType;
                    $scope.flexiSip.txnSource = "SIPFLX";
                    $scope.flexiSip.sipOptionName = "Flexible SIP";
                    $scope.flexiSip.newSipAmount = $scope.amntFlexiChange;
                    $scope.flexiSip.strtDate = $scope.strtDate;
                    SipModifyDetailModel.setModifySipDetails($scope.flexiSip);

                    if(susObj.paymentMode === TransactConstant.common.EMANDATE_CODE || susObj.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                        if($scope.amntFlexiChange > parseInt(susObj.achAmount)){
                            condCheck = true;
                        }else{
                            condCheck = false;
                        }
                    }
                    if(condCheck){   
                        $scope.config.showNotification = true;
                    }else{
                        $scope.$emit(transactEventConstants.transact.Set_Modify_Sip_Details);
                    } 
                };
            };
            $scope.$on('yes', function(event, data){
                $scope.config.showNotification = false;
                $scope.$emit(transactEventConstants.transact.Set_Key_Value_Object);  
                $scope.$emit(transactEventConstants.transact.Payment_Detail);

            }); 
            $scope.$on('no', function(event, data){
                 $scope.config.showNotification = false;
            });
            $scope.EnableConfirm = false;
            $scope.$on(eventConstants.CHECKBOX_CHECKED, function($event, checkboxObject){
                if (checkboxObject.value) {
                    $scope.EnableConfirm = true;
                } else {
                    $scope.EnableConfirm = false;
                }
                
            });
             
        }]
    };
};

fticFlexiSip.$inject = ['SipModifyDetailModel', 'eventConstants','transactModel','transactEventConstants','$filter','fundDetails','TransactConstant'];
module.exports = fticFlexiSip;