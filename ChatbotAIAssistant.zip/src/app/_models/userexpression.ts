export class UserExpression {

  userExpressionId : string;
  expression : string;
  intentId : string;

}
