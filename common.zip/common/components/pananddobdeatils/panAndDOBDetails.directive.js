/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var panAndDOBDetails = function($timeout,constants,advisorRegistrationModelService,$filter) {
	return {
            template: require('./panAndDOBDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
                formObj:'='
            },
            controller:['$scope', function($scope){
                $scope.dateOptions = {
                    yearRows: 4,
                    yearColumns: 3,
                    fulldatepickerMode:'year',
                    formatMonth: 'MMM',
                    formatYear: 'yyyy',
                    formatDayTitle: 'MMM yyyy',
                    datepickerMode: 'day',
                    startingDay: 0,
                    showWeeks: false
                };
                $scope.formData={};
                $scope.panObject = {
                     key : 'pan',
                     text : 'PAN',
                     value : '',
                     name : 'pan',
                     isRequired: true,
                     type: 'text'
                };
                $scope.$on('panAndDobsubmitted',function(event){
                    /*alert("submitted")*/
                $scope.formData.panARN=$scope.panObject.value;
                $scope.formData.dobOrRegDate =$filter('date')($scope.startDate, 'dd/MM/yyyy');
                advisorRegistrationModelService.setPanAndDOBData($scope.formData);
              });
                
            }]
        };
};

panAndDOBDetails.$inject = ['$timeout','constants','advisorRegistrationModelService','$filter'];
module.exports = panAndDOBDetails;