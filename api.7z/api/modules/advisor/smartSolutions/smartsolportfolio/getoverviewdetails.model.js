// getoverviewdetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var OverviewSchema = new mongoose.Schema({
    OverviewObject: {
        type: Array,
        "default": []
    }
});

var OverviewLookUp = mongoose.model('OverviewLookUp', OverviewSchema);

var OverviewModel = new OverviewLookUp({
	"OverviewObject" : {
		"OverviewData":[
				  {
				    "smartSolHighlights": {
				      "solutions": {
				        "active": "350",
				        "inActive": "50",
				        "total": "400"
				      },
				      "investors": {
				        "investors": "100",
				        "total": "10%"
				      },
				      "smartSolAUM": {
				        "aum": "7,50,00,000",
				        "total": "20%"
				      },
				      "grossSales": {
				        "grossSales": "50,00,000",
				        "total": "10%"
				      }
				    },
				    "portfolioComposition": [
				      {
				        "assetCategory": "BALANC",
				        "accounts": "130",
				        "aum": "171.46",
				        "aumAllocation": "0.02%",
				        "grossSalesMTD": "0.05"
				      },
				      {
				        "assetCategory": "ELSS",
				        "accounts": "1129",
				        "aum": "614.1",
				        "aumAllocation": "0.06%",
				        "grossSalesMTD": "0.9"
				      },
				      {
				        "assetCategory": "EQUITY",
				        "accounts": "7297",
				        "aum": "6616.78",
				        "aumAllocation": "0.61%",
				        "grossSalesMTD": "60.99"
				      },
				      {
				        "assetCategory": "FEEDER",
				        "accounts": "42",
				        "aum": "55.01",
				        "aumAllocation": "0.01%",
				        "grossSalesMTD": "0.34"
				      },
				      {
				        "assetCategory": "FOF",
				        "accounts": "82",
				        "aum": "303.61",
				        "aumAllocation": "0.03%",
				        "grossSalesMTD": "0.18"
				      },
				      {
				        "assetCategory": "INCOME",
				        "accounts": "795",
				        "aum": "3053.79",
				        "aumAllocation": "0.28%",
				        "grossSalesMTD": "26.44"
				      }
				    ]
				  }
				]
			}
		});

OverviewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating OverviewLookUp table, please contact admin...');
    } else {
        OverviewLookUp.remove({}, function(err) {
            console.log('OverviewLookUp collection removed');
            OverviewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating OverviewLookUp table, please contact admin...');
                }
                console.log('OverviewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = OverviewLookUp;
