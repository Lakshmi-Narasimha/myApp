'use strict';

var fticNotificationPopup = function($uibModal) {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            popUpText:"@?",
            popUpHeader:"@?",
            btnNo:"@?",
            btnYes:"@?",
            mainHeader:"@?",
            yesEventName : '@?',
            noEventName : '@?',
            buttonsRight: '@'
            // extraBtn : '@?',
            // extraEventName : '@?'
        },
        controller:['$scope', function($scope) {
            $scope.animationsEnabled = true;
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                template: require('./notificationPopup.html'),
                backdrop: 'static',
                keyboard: false,
                windowClass: 'ftic-notification-popup',
                scope: $scope,
                controller: ['$scope', '$uibModalInstance', function($scope, $uibModalInstance){
                    $scope.popUpHeader1 = angular.isUndefined($scope.popUpHeader) ? "You might lose some/all data entered/chosen till now" : $scope.popUpHeader;
                    $scope.popUpText1 = angular.isUndefined($scope.popUpText) ? "Do you wish to proceed?" : $scope.popUpText;
                    //$scope.popUpText2 = angular.isUndefined($scope.popUpText) ? "Do you wish to proceed?" : $scope.popUpText;
                    $scope.btnNo1 = angular.isUndefined($scope.btnNo) ? "No": $scope.btnNo;
                    $scope.btnYes1 = angular.isUndefined($scope.btnYes) ? "Yes" : $scope.btnYes;
                    $scope.mainHeader1 =  angular.isUndefined($scope.mainHeader) ? "Are you sure you want to change your selection?" : $scope.mainHeader ;
                    //$scope.extraBtn1 = angular.isUndefined($scope.extraBtn) ? "Yes" : $scope.extraBtn;

                    $scope.yes = function() {
                        //$scope.yesEventName = $scope.yesEventName ? $scope.yesEventName :'yes';
                        $scope.$emit($scope.yesEventName || 'yes');
                        $uibModalInstance.close();
                    };

                    $scope.no = function() {
                        //$scope.noEventName = $scope.noEventName ? $scope.noEventName : 'no';
                        $scope.$emit($scope.noEventName || 'no');
                        $uibModalInstance.close();
                    };

                    $scope.extraBtn1 = function () {
                        $scope.$emit($scope.extraEventName);
                        $uibModalInstance.close();
                    }
                }]
            });
        }]
    };
};
        
fticNotificationPopup.$inject = ['$uibModal'];
module.exports = fticNotificationPopup;