'use strict';
describe('Controller: swpTxnController', function() {
	var $controller,$scope,swpTxnController,transactModel,$state,authenticationService,$window;
	var advisor = false;
	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_transactModel_,_$state_,_authenticationService_,_$window_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();

		$window = _$window_;
		$state = _$state_;
		transactModel = _transactModel_;
		authenticationService = _authenticationService_;
		
		if(advisor){
        	authenticationService.setUser({                                        
    			"userId" : "test123"        
    		});	
        }

		loadController();			
	}));	

	function loadController(){
        swpTxnController = $controller('SwpTxnController', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(swpTxnController).toBeDefined();
    });

    it('should set the variable isInvestorType to true if investor logged in on load',function(){
    	expect($scope.isInvestorType).toBe(true);
    	advisor = true;
    });

    it('should set the variable isInvestorType to false if advisor logged in on load',function(){
    	expect($scope.isInvestorType).toBe(false);
    });

    it('should call the function redirect on click of Initiate Another SWP link',function(){
		spyOn($state,"go");
		$scope.redirect();
    	expect($state.go).toHaveBeenCalledWith('transact.base.swp');
    });

    it('should print the transaction details on click of print button',function(){
    	spyOn($window,"print");
		$scope.windowPrint();
    	expect($window.print).toHaveBeenCalled();
    });
});