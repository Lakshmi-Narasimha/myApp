define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appcommon/commonutility',
  'services/accountdetailservice',
  'text!appmodules/accountviewer/app/templates/accountdetailsectionspinner.html',
  'text!appmodules/accountviewer/app/templates/accountdetailsectionretry.html'
], function ($, _, Backbone, Spinner, Utils, dataService, SpinnerHtml, RetryHtml) {

var AccountDetailSectionView = Backbone.View.extend({
        clientId:  null,
        groupId:  null,
        accountSummary: null,
        errorHandler: null,
        clientPickHandler: null,
        initialize: function(options) {
          _.extend(this, _.pick(options, 'clientId', 'groupId', 'accountSummary', 'errorHandler', 'clientPickHandler'));
          _.bindAll(this, 'renderSection', 'handleServiceError');
        },
        spinnerTemplate: _.template(SpinnerHtml),
        handleServiceError: function(error) {
          if (this.errorHandler) {
            this.insertRetry();
            this.errorHandler(error);
          } else {
            console.log(error);
          }
        },
        render: function() { 
          this.insertSpinner();
          this.retrieveAndRender();
        },
        renderSection: function(uncompiledTemplate, data) {
          data.formatHelper = this;
          var compiledTemplate = _.template(uncompiledTemplate);
          this.$el.html(compiledTemplate(data));
        },
        insertSpinner: function() { 
          this.$el.html(this.spinnerTemplate({}));
        },
        insertRetry: function() { 
          var self = this;
          this.$el.html(RetryHtml);
          var $retryButton = this.$el.find("[pt-detail-section-retry-button]");
          $retryButton.on('click', function() {
            self.render();
          });
        },
        formatProperty: function(value, formatterFunction) {
          if (Utils.isEmpty(value)) {
            return '&ndash;';
          } else {
            return formatterFunction ? formatterFunction(value) : value;
          }
        },
        formatMoney: function(value) {
          return this.formatProperty(value, function(unformattedValue) {
            return unformattedValue.formatMoney();
          });
        },
        viewFormatDateMMddYYYY: function(value) {
          return this.formatProperty(value, function(unformattedValue) {
            return unformattedValue.formatDateMMddYYYY();
          });
        },
        isNonQualified: function() {
          return this.accountSummary.taxQualCd === "000";
        }
    });

    return AccountDetailSectionView;
});