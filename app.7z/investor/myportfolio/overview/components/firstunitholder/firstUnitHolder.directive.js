/**
 * @ngdoc directive
 * @name firstUnitHolder
 * @description
 *
 * - It displays the first unit holder view of the account statements in valutions/statements
 * 
 **/
'use strict';

var firstUnitHolder = function() {
	return {
            template: require('./firstUnitHolder.html'),
            restrict: 'E',
            replace: true,
            scope: {
                name : '=?',
                address : '=?' 
            },
            controller: function($scope, $element, $attrs){ 
            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

firstUnitHolder.$inject = [];
module.exports = firstUnitHolder;