// getDividendDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var DividendDetailsModelSchema = new mongoose.Schema({
    dividendDetailsResp: {
        type: Array,
        "default": []
    }
});

var DividendDetailsModelLookUp = mongoose.model('DividendDetailsModelLookUp', DividendDetailsModelSchema);

var DividendDetailsModel = new DividendDetailsModelLookUp({
    dividendDetailsResp : {
      "dividends": {
        "fundWiseData": [
            {
              "dividendRecordDate": "18 Feb 2016",
              "dividendPaymentDate": "19 Feb 2016",
              "dividendOption": "Reinvestment",
              "dividendAmount": "100",
              "bankName": null,
              "bankAccountNo": null,
              "modeOfPayment": null
            },
            {
              "dividendRecordDate": "18 Jan 2016",
              "dividendPaymentDate": "20 Jan 2016",
              "dividendOption": "Payout",
              "dividendAmount": "212.34",
              "bankName": "Icci Bank Ltd",
              "bankAccountNo": "1000110191",
              "modeOfPayment": "Cheque"
            },
            {
              "dividendRecordDate": "18 Dec 2015",
              "dividendPaymentDate": "19 Dec 2015",
              "dividendOption": "Payout",
              "dividendAmount": "114",
              "bankName": "Icci Bank Ltd",
              "bankAccountNo": "1000110191",
              "modeOfPayment": "Directly to bank"
            }
        ],
        "fundInfo": {
            "fundName": "Franklin India Flexi Cap Fund",
            "folioNo": "4356453",
            "accountNo": "00901524856",
            "modeOfHolding": "joint",
            "goal": "Wealth Creation",
            "goalDetails": "Buying a House"
        }
    }
}
});

DividendDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating DividendDetailsModelLookUp table, please contact admin...');
    } else {
        DividendDetailsModelLookUp.remove({}, function(err) {
            console.log('DividendDetailsModelLookUp collection removed');
            DividendDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating DividendDetailsModelLookUp table, please contact admin...');
                }
                console.log('DividendDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = DividendDetailsModelLookUp;
