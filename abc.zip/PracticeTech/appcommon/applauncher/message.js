﻿define(function () {
    var message = function (messageType, context, targetAppId,additionalParams, error) {
        if (undefined === typeof (messageType) || messageType == undefined)
            return;
        if (undefined === typeof (context) || context == undefined)
            return;
        this.Type = messageType;
        if (targetAppId != null || targetAppId != undefined)
            this.TargetAppId = targetAppId;
        this.Content = new content(context, additionalParams, error);        
    };    

    var getContextRequest = function () {
        this.Type = 'GetContextRequest';
    };

    var getContextResponse = function (context, additionalParams) {
        this.Type = "GetContextResponse";
        this.Content = new content(context, additionalParams);
    };

    var errorNotification = function (info,messageData) {
        this.Type = "ErrorNotification";
        var errorData = new error(info, messageData);
        this.Content = new content(null, null, errorData);
    };
   

    var launchApplication= function(targetAppId,targetResource){
        if (undefined === typeof (targetAppId) || targetAppId == undefined)
            return;
        if (undefined === typeof (targetResource) || targetResource == undefined)
            return;
        this.Type = 'LaunchApplication';
        this.TargetApp = new targetApp(targetAppId, targetResource);
    };

    var targetApp = function (targetAppId, targetResource) {
        this.Id = targetAppId;
        this.Resource = targetResource;
    };
    var content = function (context, additionalParams, error) {
        if (content != null || context != undefined)
            this.Context = context;
        if (additionalParams != null || additionalParams != undefined)
            this.AdditionalParams = additionalParams;
        if (error != null || error != undefined) {
            this.Error = error;
            this.Context = null;
            this.AdditionalParams = null;
        }
    };
    var error = function (info, messageData) {
        if (info != null || info != undefined)
            this.Info = info;
        if (messageData != null || messageData != undefined)
            this.MessageData = messageData;
    };
    return { Message: message, Content: content, ErrorNotification: errorNotification, LaunchApplication: launchApplication, GetContextResponse: getContextResponse }
})