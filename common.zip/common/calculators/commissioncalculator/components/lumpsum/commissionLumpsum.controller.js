
function commissionLumpsumController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel,calculatorsEventConstants) {
 $scope.calculatorReq = [];
 $scope.fundName = null;
 $scope.userInput= { 
  Tenure : {
    key: '', 
    text: 'Investment Tenure',
    value: '',
    // pattern:/^[0-9]*$/,
    message: '',
    isMasked: false,
    isRequired: false ,
    type: 'number'                    
  },
  GrossSale : {
    key: '', 
    text: 'Gross Sales <span class="icon-fti_rupee"></span>',
    value: '',
    // pattern:/^[0-9]*$/,
    message: '',
    isMasked: false,
    isRequired: true ,
    // maxlength: 9 ,
    type: 'number'                  
  }
};
$scope.$on('fundType', function(event, fundName) { 
  $scope.fundName = fundName;
});
$scope.onSubmit = function() {
 $scope.$emit(calculatorsEventConstants.COMMISSION_RESET_CHART);
 $scope.tenureErrorvalue = parseInt($scope.userInput.Tenure.value);
 if($scope.userInput.Tenure.value  === null)
   $scope.userInput.Tenure.value = '';
 if($scope.userInput.GrossSale.value < 500 || $scope.userInput.GrossSale.value > 999999999 || ($scope.userInput.Tenure.value !== '' && $scope.userInput.Tenure.value >40 )|| ($scope.userInput.Tenure.value !== '' && $scope.userInput.Tenure.value < 1)) {
  return;
 }else if (!$scope.checkWholeNumPattern($scope.userInput.Tenure.value) || !$scope.checkWholeNumPattern($scope.userInput.GrossSale.value) ){
          return;
 }else {
  $scope.calculatorReq = [{ 
    'trxnType' : 'SIP &Lumpsum',
        'fundCode' :  $scope.fundCode,//Fund Code needs to be dynamic
        'invstTenure' : $scope.userInput.Tenure.value,
        'grossSales' :$scope.userInput.GrossSale.value
      }];
      
      $scope.$emit(calculatorsEventConstants.COMMISSION_CALCULATE_SUBMIT,$scope.calculatorReq);
    }
  };

  $scope.resetForm = function () {
   $scope.$emit(calculatorsEventConstants.RESET_DATA, 'lumpsum');
   $scope.userInput.Tenure.value = '';
   $scope.userInput.GrossSale.value = '';
   $scope.calculatorReq = {};
   $scope.tenureErrorvalue = $scope.userInput.Tenure.value;
 };  
 $scope.checkWholeNumPattern = function(field){
      var patt = /^[0-9]*$/;
      // var result = patt.test($scope.userInput.Tenure.value);
      var result = patt.test(field);                
      return result;
    };
$scope.inputChanged = function(data){
  $scope.commissionCalculatorForm.$submitted = false;
  $scope.tenureErrorvalue = parseInt(data.value);
}; 
$scope.amountValue = function(){
    $scope.commissionCalculatorForm.$submitted = false;
}; 
}
commissionLumpsumController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsEventConstants'];
module.exports = commissionLumpsumController;