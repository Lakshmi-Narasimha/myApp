import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import { CarouselModule, TabsModule } from 'ngx-bootstrap';

import { AppRoutingModule } from './app-routing/app-routing.module';
import { AppConfigModule } from './app-config.module';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardService } from './services/dashboard.service';
import { HttpclientService } from './services/httpclient.service';
import { BuildinfoComponent } from './buildinfo/buildinfo.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    BuildinfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppConfigModule,
    HttpModule,
    HttpClientModule,
    CarouselModule.forRoot(),
    TabsModule.forRoot()
  ],
  providers: [DashboardService, HttpclientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
