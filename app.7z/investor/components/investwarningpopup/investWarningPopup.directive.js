'use strict';

var InvestWarningPopup = function() {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            popUpHeader: "@?",
            btnNo: "@?",
            btnYes: "@?",
            mainHeader: "@?",
            yesEventName: '@?',
            noEventName: '@?',
            extraBtn: '@?',
            extraEventName: '@?'
        },
        controller: function($scope, $uibModal) {
            $scope.animationsEnabled = true;
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                template: require('./investWarningPopup.html'),
                backdrop: 'static',
                keyboard: false,
                windowClass: 'ftic-warning-popup',
                scope: $scope,
                controller: function($scope, $uibModalInstance) {
                    $scope.popUpHeader1 = angular.isUndefined($scope.popUpHeader) ? "You might lose some/all data entered/chosen till now" : $scope.popUpHeader;
                    $scope.btnNo1 = angular.isUndefined($scope.btnNo) ? "No" : $scope.btnNo;
                    $scope.btnYes1 = angular.isUndefined($scope.btnYes) ? "Yes" : $scope.btnYes;
                    $scope.mainHeader1 = angular.isUndefined($scope.mainHeader) ? "Are you sure you want to change your selection?" : $scope.mainHeader;
                    $scope.yes = function(event) {
                        event.preventDefault();
                        $scope.$emit($scope.yesEventName || 'yes');
                        console.log('Yes Event Triggered');
                        $uibModalInstance.close();
                    };

                    $scope.no = function() {

                        $scope.$emit($scope.noEventName || 'no');
                        $uibModalInstance.close();
                    };

                    $scope.extraBtn1 = function() {
                        $scope.$emit($scope.extraEventName);
                        $uibModalInstance.close();
                    }
                }
            });
        },
        link: function($scope, $element, $attrs) {

        }
    };
};

InvestWarningPopup.$inject = [];
module.exports = InvestWarningPopup;
