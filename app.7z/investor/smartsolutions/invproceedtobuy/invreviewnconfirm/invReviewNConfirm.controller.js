/**
 * @ngdoc property
 * @name ReviewNConfirmController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display fund details for sip and lumpsum
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function InvReviewNConfirmController($scope, $state, fticLoggerMessage, loggerConstants, $filter, bankDtlsModel, transactModel, planSmartSolution, paymentDetailsUtility, authenticationService, $location, TransactConstant, $cookies, eventConstants, appConfig, transactEventConstants, $timeout, paperlessModel, $sce, $window, toaster, fundDetails, profileDetailsModel, configUrlModel) {
        
    $scope.reviewAndConfirmHeading = {
        heading : 'Review & Confirm'
    };
    $scope.documentURL = $sce.trustAsResourceUrl(appConfig[configUrlModel.getEnvUrl('PROXY_URL')] + "getConfirmTxnSlip");    
    $scope._isInvestor = authenticationService.isInvestorLoggedIn();
    var isAdvisor = false,
        isPaperless = false,
        isCreatedLogin = false,
        needToGoPaymentGateway = false,
        validateBuySuccess = true,
        validateSipSuccess = true,
        showLumpsumPaymentComp = false,
        showSipPaymentComp = false,
        isServiceCalled = false,
        queryParams = $location.search();    

    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;

    $scope.submit = {};
    $scope.submit.sipFormSubmitted = false;
    $scope.submit.lumpsumFormSubmitted = false;

    $scope.showDtls = {};
    $scope.showDtls._isInvestor = authenticationService.isInvestorLoggedIn();    
    $scope.showDtls.showInvDtls = false;
    $scope.showDtls.showAdvForm = false;
    $scope.showDtls.showInvestorPrefer = false;
    $scope.showDtls.showPanelHeader = false;
    $scope.showDtls.showLumpsumTransactionDtls = false;
    $scope.showDtls.showSipTransactionDtls = false;
    $scope.showDtls.showLumpsumPaymentComp = false;
    $scope.showDtls.showSipPaymentComp = false;
    $scope.showDtls.requestDateAndTime = $filter('date')(new Date(), 'dd MMMM yyyy, hh:mm a');
        
    function successOrRetrySetter()
    {
        if($cookies.get('isCombo')==="true")
        {
            $cookies.remove("isCombo",{'domain': appConfig.DOMAIN_CONFIG});                                            
            planSmartSolution.setTransactType("Combo");
            $scope.submit.lumpsumFormSubmitted = true;
            $scope.submit.sipFormSubmitted = true;

            // if(transactModel.getFlowType()==="paperless")
            // {
                if($scope.params.trxnType === "P")
                {
                    $scope.params.trxnType = "SIP"
                }
                else if($scope.params.trxnType === "SIP")
                {
                    $scope.params.trxnType = "P";
                }
            // }

            if(!$cookies.get('pendingTransPostStr'))
            {                    
                $scope.params.webRefNo = $cookies.get('otherTransactionWebRefNo');
                paymentDetailsUtility.setPaymentRedirectDtls($scope);
                isServiceCalled = true;
                $scope.showDtls.showLumpsumTransactionDtls = true;
                $scope.showDtls.showSipTransactionDtls = true;   
                if(transactModel.isRetryPayment)
                {             
                    if(queryParams.transactionType === TransactConstant.buy.BUY)
                    {
                        $scope.showDtls.showLumpsumTransactionDtls = false;
                        showLumpsumPaymentComp = true;
                        validateBuySuccess = false;
                    }
                    else if(queryParams.transactionType === TransactConstant.sip.SIP)
                    {
                        $scope.showDtls.showSipTransactionDtls = false;
                        showSipPaymentComp = true;
                        validateSipSuccess = false;
                    }
                }
            }
            else if($cookies.get('pendingTransPostStr'))
            {
                if(queryParams.transactionType === TransactConstant.buy.BUY)
                {
                    transactModel.setSipReqParams(JSON.parse($cookies.get('pendingTransPostStr')));
                    $scope.params.webRefNo = transactModel.getSipReqParams().webRefNo;  
                    paymentDetailsUtility.setPaymentRedirectDtls($scope);
                    isServiceCalled = true;
                    if(transactModel.isRetryPayment)
                    {
                        showLumpsumPaymentComp = true;
                        validateBuySuccess = false;
                    }
                    else
                    {
                        $scope.showDtls.showLumpsumTransactionDtls = true;                                    
                    }
                    if($cookies.get("validationPending")==="sip")
                    {
                        showSipPaymentComp = true;
                        validateSipSuccess = false;
                        transactModel.isRetryPayment = true;
                        $cookies.remove("validationPending",{'domain': appConfig.DOMAIN_CONFIG});
                    }
                }
                else if(queryParams.transactionType === TransactConstant.sip.SIP)
                {
                    transactModel.setBuyReqParams(JSON.parse($cookies.get('pendingTransPostStr')));
                    $scope.params.webRefNo = transactModel.getBuyReqParams().webRefNo;                    
                    paymentDetailsUtility.setPaymentRedirectDtls($scope); 
                    isServiceCalled = true;                       
                    if(transactModel.isRetryPayment)
                    {
                        showSipPaymentComp = true;
                        validateSipSuccess = false;
                    }
                    else
                    {
                        $scope.showDtls.showSipTransactionDtls = true;
                    }
                    if($cookies.get("validationPending")==="lumpsum")
                    {
                        showLumpsumPaymentComp = true;
                        validateBuySuccess = false;
                        transactModel.isRetryPayment = true;
                        $cookies.remove("validationPending",{'domain': appConfig.DOMAIN_CONFIG});
                    }
                }                                    
            }                
            $cookies.remove("otherTransactionWebRefNo",{'domain': appConfig.DOMAIN_CONFIG});            
            $cookies.remove("pendingTransPostStr",{'domain': appConfig.DOMAIN_CONFIG});
        }
        else if(!$cookies.get('isCombo'))
        {
            if(queryParams.transactionType === TransactConstant.buy.BUY)
            {
                planSmartSolution.setTransactType("Lumpsum");
                if(transactModel.isRetryPayment)
                {
                    showLumpsumPaymentComp = true;
                    validateBuySuccess = false;
                }
                else
                {
                    $scope.showDtls.showLumpsumTransactionDtls = true;
                    $scope.submit.lumpsumFormSubmitted = true;   
                }
            }                
            else if(queryParams.transactionType === TransactConstant.sip.SIP)
            {
                planSmartSolution.setTransactType("SIP");
                if(transactModel.isRetryPayment)
                {
                    showSipPaymentComp = true;
                    validateSipSuccess = false;
                }
                else
                {
                    $scope.showDtls.showSipTransactionDtls = true;
                    $scope.submit.sipFormSubmitted = true;
                }
            }            
        }                 
    }                

    if(queryParams.hasOwnProperty('successFlag'))
    {
        $scope.disableEditIcon = true;
        
        $scope.reviewDtls = {};

        $scope.params = {
            webRefNo: queryParams.webRefNo,
            guId: queryParams.guId
        };
        
        if(queryParams.transactionType === TransactConstant.buy.BUY)
        {
            $scope.params.trxnType = "P";
        }
        else if(queryParams.transactionType === TransactConstant.sip.SIP)
        {
            $scope.params.trxnType = "SIP";
        }
        
        authenticationService.setUser({"guId" : queryParams.guId});

        if($cookies.get('flowType')==="paperless")
        {
            $scope.reviewDtls.reviewDtlsState = "paperLess.transact.reviewAndConfirm.smartsol.investment";
            transactModel.setFlowType("paperless");
            isCreatedLogin = true;

            /*if(queryParams.transactionType === TransactConstant.buy.BUY)
            {
                $scope.params.trxnType = "P";
            }
            else if(queryParams.transactionType === TransactConstant.sip.SIP)
            {
                $scope.params.trxnType = "SIP";
            }*/            
        }
        else if($cookies.get('flowType')==="transactnow")
        {
            $scope.reviewDtls.reviewDtlsState = "transactnow.reviewNow.smartSol.investment";
            transactModel.setFlowType("transactnow");
        }

        $cookies.remove("flowType",{'domain': appConfig.DOMAIN_CONFIG});
        
        if(queryParams.successFlag === "true")
        {                        
            paymentDetailsUtility.setPaymentRedirectDtls($scope);
            isServiceCalled = true;
            successOrRetrySetter();
        }
        else if(queryParams.successFlag === "false")
        {
            if(queryParams.retryFlag === "true")
            {
                transactModel.isRetryPayment = true;                
                transactModel.setRetryCount(queryParams.retryCount);

                if(parseInt(transactModel.getRetryCount()) > 3) {
                    toaster.error("You have exceeded the maximum number of payment attempts. You will now be redirected to FT India homepage");
                    authenticationService.backButton = true;
                    $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                }else {
                    $scope.disableEditIcon = true;
                    toaster.error("Your transaction could not be completed. Please try again with the same/different payment mode");
                }


                paymentDetailsUtility.setPaymentRedirectDtls($scope);
                isServiceCalled = true;
                successOrRetrySetter();
            }
            else if(queryParams.retryFlag === "false")
            {
                successOrRetrySetter();                
                $scope.showDtls.showLumsumErrMsg = queryParams.errorDescription;
                $scope.showDtls.showSipErrMsg = queryParams.errorDescription;
            }
        }

    }
    else
    {        
        //$state.go($scope.reviewDtls.reviewDtlsState); --No Need of Investor   
    }
    
    if(transactModel.getFlowType() === "advisor")
    { 
        isAdvisor = true;
    }
    else if(transactModel.getFlowType() === "paperless")
    {
        isPaperless = true;
        paperlessModel.invType.setInvType("SmartSoln");
    }   

    // isAdvisor = false;  //TEST

    $cookies.remove("isCombo",{'domain': appConfig.DOMAIN_CONFIG});
    
    if(planSmartSolution.getTransactType()==="Lumpsum")
    {
        if(!isServiceCalled)
        {
            $scope.showLumpsum = true;
        }
    }
    else if(planSmartSolution.getTransactType()==="SIP")
    {
        if(!isServiceCalled)
        {
            $scope.showSip = true;
        }        
    }
    else if(planSmartSolution.getTransactType()==="Combo")
    {
        if(!isServiceCalled)
        {
            $scope.showBoth = true;
        }        
        if(!isAdvisor)
        {
            $cookies.put('isCombo', 'true',{'domain': appConfig.DOMAIN_CONFIG});
        }
        
    }
            
    // if($scope.reviewDtls.reviewDtlsState ===  "transactnow.reviewNow.smartSol.investment")
    // {
	// 	$scope.showDtls.showInvestorPrefer = true;
    // }  

    // if($scope.reviewDtls.reviewDtlsState ===  "smartSol.planSmartSolution.reviewnconfirm.investment")
    // {
	// 	$scope.showDtls.showInvDtls = true;
    // 	$scope.showDtls.showAdvForm = true; 
    // 	$scope.showDtls.showPanelHeader = true;   	
    // }
    $scope._currentState = $state.current.name;
    if($scope._currentState === 'smartSol.planSmartSolution.invProceedToBuy.reviewnconfirm') {
        $scope.showDtls.showInvDtls = true;
        $scope.showDtls.showInvestorPrefer = true;
    }
    $scope.$emit(transactEventConstants.transact.HIDE_PAPERLESS_BTNS);
    // if($scope.reviewDtls.reviewDtlsState === "paperLess.transact.reviewAndConfirm.smartsol.investment")
    // {
    //     $scope.showDtls.showInvDtls = true;
    //     $scope.showDtls.showInvestorPreferPaperless = true;        
    // }

    $scope.postReviewDetails = function(transaction)
    {
        if((!validateBuySuccess && transaction==="lumpsum") || (!validateSipSuccess && transaction==="sip"))
        {
            $scope.$broadcast("submitTransactionClicked",{"transaction":transaction});
            return;
        }        

        var postBuyParams,postSipParams;
        if($scope.showBoth)
        {
            postBuyParams = getLumpsumParams();
            postSipParams = getSipParams();
        }
        
        if(transaction==="lumpsum")
        {   
            postBuyParams = getLumpsumParams();                     
            if(isGoingToPaymentGateway(transactModel.getBuyReqParams()))
            {                
                setPaymentIntegration();
            }     
            $timeout(function(){
                postLumpsum(postBuyParams); 
                if($scope.showBoth && isGoingToPaymentGateway(transactModel.getBuyReqParams()))
                {                                                           
                    $cookies.put('otherTransactionWebRefNo',transactModel.getSipWebRefNo(),{'domain': appConfig.DOMAIN_CONFIG});  
                    if(!$scope.showDtls.showSipTransactionDtls)
                    {
                        $cookies.put("pendingTransPostStr",JSON.stringify(postSipParams),{'domain': appConfig.DOMAIN_CONFIG});
                        if(!validateSipSuccess)
                        {
                            $cookies.put("validationPending","sip",{'domain':appConfig.DOMAIN_CONFIG})
                        }

                    }                
                    postSip(postSipParams);
                }
            },0);
        }   

        if(transaction==="sip")
        {      
            postSipParams = getSipParams();                  
            if(isGoingToPaymentGateway(transactModel.getSipReqParams()))
            {                
                setPaymentIntegration();
            }
            $timeout(function(){
                postSip(postSipParams);
                if($scope.showBoth && isGoingToPaymentGateway(transactModel.getSipReqParams()))
                {                                              
                    $cookies.put('otherTransactionWebRefNo',transactModel.getLumpsumWebRefNo(),{'domain': appConfig.DOMAIN_CONFIG});
                    if(!$scope.showDtls.showLumpsumTransactionDtls)
                    {
                        $cookies.put("pendingTransPostStr",JSON.stringify(postBuyParams),{'domain': appConfig.DOMAIN_CONFIG});
                        if(!validateBuySuccess)
                        {
                            $cookies.put("validationPending","lumpsum",{'domain':appConfig.DOMAIN_CONFIG})
                        }
                    }
                    postLumpsum(postBuyParams);
                }
            },0)            
        }

    }

    function getLumpsumParams()
    {
        var postBuyParams;
        postBuyParams = angular.copy(transactModel.getBuyReqParams());
        postBuyParams.webRefNo = transactModel.getLumpsumWebRefNo();
        postBuyParams.txnNo = transactModel.getLumpsumWebRefNo();
        return postBuyParams
    }
    
    function getSipParams()
    {
        var postSipParams;
        postSipParams = angular.copy(transactModel.getSipReqParams());
        postSipParams.webRefNo = transactModel.getSipWebRefNo();
        postSipParams.txnNo = transactModel.getSipWebRefNo();
        return postSipParams;
    }

    function postLumpsum(postParams)
    {
        if(!$scope.submit.lumpsumFormSubmitted)
        {                          
            bankDtlsModel.postBuyDtls(postParams)
            .then(postLumpsumSuccess, handleFailure);    
        }
        else
        {
            postLumpsumSuccess();            
        }        
    }

    function postSip(postParams)
    {                        
        if(!$scope.submit.sipFormSubmitted)
        {                   
            bankDtlsModel.postSysBuy(postParams)
            .then(postSipSuccess, handleFailure);
        }
        else
        {
            postSipSuccess();
        }        
    }        

    function postLumpsumSuccess(data)
    {        
        $scope.submit.lumpsumFormSubmitted = true;
        transactModel.setSubFlowType('Lumpsum');
        if(isAdvisor)
        {
            $scope.showDtls.showLumpsumTransactionDtls = true;            
        }        
        else
        {
            checkPaymentRedirection("lumpsum");
        }
    }

    function postSipSuccess(data)
    {
        $scope.submit.sipFormSubmitted = true;
        transactModel.setSubFlowType('Sip');
        if(isAdvisor)
        {
            $scope.showDtls.showSipTransactionDtls = true;            
        }
        else
        {  
            checkPaymentRedirection("sip");
        } 
    }

    function checkPaymentRedirection(transaction)
    {
        if(needToGoPaymentGateway)
        {                                
            if(!$scope.showBoth || ($scope.showBoth&&$scope.submit.lumpsumFormSubmitted&&$scope.submit.sipFormSubmitted))
            {   
                if(isPaperless)
                {
                    if(!isCreatedLogin)
                    {
                        $scope.isOpenQuickLoginPop = true;
                        return;
                    }       
                }
                $cookies.put('flowType',transactModel.getFlowType(),{'domain': appConfig.DOMAIN_CONFIG});
                authenticationService.backButton = true;
                document.getElementById("prxoyForm1").submit();
            }
        }
        else
        {
            if(isPaperless)
            {
                if(!isCreatedLogin)
                {
                    $scope.isOpenQuickLoginPop = true;
                    return;
                }       
            }
            if(transaction === "lumpsum")  
            {
                $scope.showDtls.showLumpsumTransactionDtls = true;
            }
            else if(transaction === "sip")
            {
                $scope.showDtls.showSipTransactionDtls = true;    
            }
        }
    }

    function handleFailure()
    {
        console.log("Post Failed")
    }

    function isGoingToPaymentGateway(params)
    {        
        if(!isAdvisor)
        {
            if(params.paymentMode === TransactConstant.common.NET_BANKING_CODE || params.paymentMode === TransactConstant.common.DEBIT_CARD_CODE || params.paymentMode === TransactConstant.common.EMANDATE_CODE)
            {
                if(params.umrnNo === "") // Allowing only new mandates
                {
                    needToGoPaymentGateway = true;
                    return true;   
                }                
            }
        }        
        needToGoPaymentGateway = false;
        return false;
    }    

    function setPaymentIntegration()
    {
        $scope.submitURL = transactModel.getPaymentURL();        
        transactModel.setProxyRedirectURL($location.absUrl().split('?')[0]);
        if(transactModel.getFlowType() === "paperless")
        {
            transactModel.setFlowIdForProxy("paperLess");     
        }
        else if(transactModel.getFlowType() === "transactnow")
        {
            transactModel.setFlowIdForProxy("transactNow");
        }  
        $scope.proxyReqObj = transactModel.getPaymentProxyReqObj(true); 
        console.log("$scope.proxyReqObj",$scope.proxyReqObj);       
    }                        

    $scope.$on(eventConstants.CLOSE_LOGIN_POPUP, function(){
        $scope.isOpenQuickLoginPop = false;
    });

    $scope.$on(eventConstants.PAPERLESS_QUICK_LOGIN_SUCCESS, function(){
        $scope.isOpenQuickLoginPop = false;
        isCreatedLogin = true;
        if(transactModel.getSubFlowType() === 'Sip')
        {
            checkPaymentRedirection("sip");
        }
        else if(transactModel.getSubFlowType() === 'Lumpsum')
        {
            checkPaymentRedirection("lumpsum");
        }
    });  

    $scope.$on('PaymentRedirectionValidateSuccess',function(event,data){
        if(data.transaction === "lumpsum")
        {
            validateBuySuccess = true;
            $scope.submit.lumpsumFormSubmitted = false;
        }
        else if(data.transaction === "sip")
        {
            validateSipSuccess = true;
            $scope.submit.sipFormSubmitted = false;   
        }
        $scope.postReviewDetails(data.transaction)        
    });

    $scope.$on("txnDetailsCompleted",function(event,data){

        if(data.transactType === "BUY")
        {
            $scope.showLumpsum = true;
        }
        else if(data.transactType === "SIP")
        {   
            $scope.showSip = true;
        }

        if(planSmartSolution.getTransactType()==="Combo")
        {
            if($scope.showLumpsum && $scope.showSip)
            {
                $scope.showBoth = true;
            }
        }

        if(showLumpsumPaymentComp)
        {
            $scope.showDtls.showLumpsumPaymentComp = true;    
            $scope.$broadcast("hideContinue");
        }
        else if(showSipPaymentComp)
        {
            $scope.showDtls.showSipPaymentComp = true;
            $scope.$broadcast("hideContinue");
        }        
    });

    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function ($event, ele) {
        var paymentRoute = "";
        // if(isAdvisor)
        // {
        //     paymentRoute = "smartSol.planSmartSolution.paymentdetailsSS.investment";
        // }
        // else if(isPaperless)
        // {
        //     paymentRoute = "paperLess.transact.paymentDtls.smartPaymentDtls.investment";
        // }
        // else
        // {
        //     paymentRoute = "transactnow.baseNow.smartSolTransact.paymentDetails";
        // }
        paymentRoute = "smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS";
        $state.go(paymentRoute, {key: TransactConstant.transact.Payment_Key});        
    });

    
    $scope.b64toBlob = function (b64Data, contentType, sliceSize) {
        
        var  contentType = contentType || '';
        var sliceSize = sliceSize || 512;
        b64Data = b64Data.replace(/\s/g, '');
        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

        var blob = new Blob(byteArrays, {type: contentType});
        return blob;
    }

    $scope.submit.saveTransaction = function(details){

        var key = (transactModel.getTransactType()==="BUY")?"buyTxnDetailsReq":"sipTxnDetailsReq",
            webRefNo = (transactModel.getTransactType()==="BUY")?transactModel.getLumpsumWebRefNo():transactModel.getSipWebRefNo();

        var downloadReq = {
            "strTrxnType": transactModel.getTransactType(),
            "strJsonObj": {}
        }    

        var arnCode = (isAdvisor)?profileDetailsModel.getProfileDtls().profileDetails.ARN:transactModel.getAdvDetails().code;            
        
        downloadReq.strJsonObj[key] = {
            "txnType": transactModel.getTransactType(),
            "advisorDetails": {
                "name": "",
                "arnCode": arnCode,
                "company": ""
            },
            "investorDetails": {
                "firstHolderName": transactModel.getInvestorDetails().custName,
                "folioNo": transactModel.getInvestorDetails().folioId
            },
            "fundDetails": details.fundDetails,
            "paymentDetails": {
                "bankDetails": details.bankDetails,
                "modeOfPayment": details.paymentMethod,
                "txnRefNo": webRefNo,
                "reqDateTime": $scope.showDtls.requestDateAndTime
            }            
        };        
        
        var postDownloadSuccess = function(resp){

            var file = $scope.b64toBlob(resp.download.strDocBase64, 'application/pdf');
            var fileURL = URL.createObjectURL(file);
            $scope.base64str = $sce.trustAsResourceUrl(fileURL); 
            $window.open($scope.base64str,"_blank");
        }

        var postDownloadFailure = function(resp){
            toaster.error(resp.data[0].errorDescription);
        } 
        var params = {};
        params.guId = authenticationService.getUser().guId;
        params.formType = 'TXNSLIP';
        params.postStr = downloadReq;
        $timeout(function () {
            document.getElementsByName("reqObj")[0].value = JSON.stringify(params);
            document.getElementById("smartTransactionForm").submit();
                   
        },200);
        //transactModel.downloadTransactDetails(downloadReq).then(postDownloadSuccess, postDownloadFailure);
    }

}

InvReviewNConfirmController.$inject = ['$scope','$state','fticLoggerMessage', 'loggerConstants','$filter','bankDtlsModel','transactModel', 'planSmartSolution', 'paymentDetailsUtility', 'authenticationService', '$location', 'TransactConstant', '$cookies', 'eventConstants', 'appConfig', 'transactEventConstants', '$timeout', 'paperlessModel', '$sce', '$window', 'toaster', 'fundDetails', 'profileDetailsModel', 'configUrlModel'];
module.exports = InvReviewNConfirmController;