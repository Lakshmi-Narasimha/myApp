/**
 * @ngdoc property
 * @name saved Smart Solutions Directive
 * @requires $state
 * @description
 *
 * - SmartSolutions directive will load the solutions with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';
var SmartSolutionsGrid = function(savedSmartSolutionsModel, investorConstants,$timeout,$state, $filter,transactModel, recommendedPlanModelService, buildPlanModelService, toaster, planSmartSolution, savedSmartSolutionsInitLoader) {
    return {
        template: require('./savedSmartSolutionsGrid.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {},
        controller: function($scope, $element, $attrs) {
            $scope.savedSmartGrid = [];
            /*var eventHandler =
                $scope.$on(investorConstants.smartSolutions.SAVED_SMART, function(event, data) {
                    $scope.savedSmartGrid = savedSmartSolutionsModel.getSavedSmartSolDtls().retriveSmartSolutions;
                    $scope.savedSmartSolDltBtn = false;
                    angular.forEach($scope.savedSmartGrid, function(obj) {
                        var gridRow = obj;
                        gridRow.firstHolderName = obj.holderDetails.firstHoldersName;
                        $scope.savedSmartGrid.push(gridRow);
                    });
                    $scope.destroyEvent();
                });

            $scope.destroyEvent = function() {
                eventHandler();
            };*/
            $scope.savedSmartGrid = savedSmartSolutionsModel.getSavedSmartSolDtls().retriveSmartSolutions;
            angular.forEach($scope.savedSmartGrid, function(obj) {
                        //var gridRow = obj;
                        obj.savedDate = $filter('date')(new Date(obj.savedDate), 'dd/MM/yyyy'); 
                        //$scope.savedSmartGrid.push(gridRow);
            });
            var statusTemplate = '<div uib-popover-template="\'isVeiwCompTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
                '<script type="text/ng-template" id="isVeiwCompTemplate.html">' +
                '<div class="fti-popClass">' +
                '<button type="button" ng-click="grid.appScope.$emit(\'proceedBuy\', row.entity)" class="btn panel-orange-btn mt0">Proceed To Buy</button>' +
                '<button type="button" ng-click="grid.appScope.$emit(\'modify\', row.entity)" class="btn panel-orange-btn savedSmartSolBtns">Modify</button>' +
                '<button type="button" ng-click="grid.appScope.$emit(\'delete\', row.entity)" class="btn panel-orange-btn savedSmartSolBtns">Delete</button>' +
                '</div></script>';

            $scope.columnDefs = [
                { field: 'firstHolderName', displayName: '', width: '50', pinnedLeft: true, cellTemplate: statusTemplate },

                //{field: 'firstHolderName', displayName: 'Investor Name', width:'350', pinnedLeft:true },
                { field: 'goalName', displayName: 'Goal Name', width: '240',headerCellClass: 'text-left', cellClass: 'text-left' },
                { field: 'goalAmount', displayName: 'Goal Amount',width: '240', headerCellClass: 'fti-grid-rupeeIcon text-left', cellClass: 'text-left' },
                { field: 'savedDate', displayName: 'Saved Date', width: '305', headerCellClass: 'text-center', cellClass: 'text-center' }

            ];

            $scope.$on('proceedBuy', function(event, args) {
                //if (args.investorType === 'Existing Investor' && args.invType !== '') {
                    $scope.fundDtls = {};
                    $timeout(function() {
                        var investmentType = args.invType;
                        planSmartSolution.setTransactType(investmentType);
                        unitHolderDtls(args);
                    }, 0);
                    $timeout(function() {
                        var fundDtlsState = 'smartSol.planSmartSolution.invProceedToBuy.invPBFundDetails';
                        planSmartSolution.setFundDetailsState(fundDtlsState);
                        $state.go('smartSol.planSmartSolution.invProceedToBuy.invPBInvestmentPref');
                    }, 0);
                    console.log('transact type', transactModel.getTransactType());
                /*} else if (args.investorType === 'New Investor') {
                    $state.go('smartSol.planSmartSolution.newInvPlanSS');
                } else {
                    toaster.error('There is no investment type for selected smart Solution');
                }*/

            });

            $scope.$on('modify', function(event, args) {
                unitHolderDtls(args);
                var selectedSmartSol = { 'title': args.goalName };
                recommendedPlanModelService.setSelectedSmartSoln(selectedSmartSol);
                    //var invEmailId = { 'emailId': args.email };
                    //transactModel.setInvestorDetails(invEmailId);
                $scope.planInputDetails = {
                    'age': args.currentAge.slice(0, 2),
                    'investmentTenure': parseInt(args.goalTenure.slice(0, 1)),
                    'investmentAmount': args.goalAmount,
                    'equityPerc': 0
                };
                recommendedPlanModelService.setPlanInputDtls($scope.planInputDetails);
                var planInputObj = {};
                planInputObj = angular.copy(recommendedPlanModelService.getPlanInputDtls());
                planInputObj.fundRecom = 'O';

                if (args.txnType === 'PR' || args.txnType === 'NR') {
                    var trxnType = 'RP';
                } else if (args.txnType === 'PB' || args.txnType === 'NB') {
                    var trxnType = 'BP';
                }
                planSmartSolution.fetchPlanSmartSolutionDetails(recommendedPlanModelService.getPlanInputDtls()).then(function(data) {
                    planSmartSolution.setSmartSolutionDetails(data);
                    stateChange(args);
                }, function(data) {
                    console.log('Error')
                });

                $timeout(function() {
                    unitHolderDtls(args);
                }, 0);
                recommendedPlanModelService.setRecommendedFromState($state.current.name);
            });

            function stateChange(args) {
                if (args.txnType === 'PR') {
                    //$state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan');
                } else if (args.txnType === 'PB') {
                    //$state.go('smartSol.planSmartSolution.ssBase.recommendations.buildplan');
                } else if (args.txnType === 'IS') {
                    $state.go('smartSol.investor.topupwithsf.topupwithsamefunds');
                } else if (args.txnType === 'IR') {
                    $state.go('smartSol.investor.topupwithftrf.topupwithftrecommendedfunds');
                } else if (args.txnType === 'IM') {
                    $state.go('smartSol.investor.modifymain.modify');
                }
            }
            var unitHolderDtls = function(args) {
                var holderInfoArray = {};
                holderInfoArray.custName = args.firstHoldersName;
                holderInfoArray.holders = [
                    { 'name': args.firstHoldersName, 'type': 'First Holder' },
                    { 'name': args.secondHoldersName ? args.secondHoldersName : 'NA', 'type': 'Second Holder' },
                    { 'name': args.thirdHoldersName ? args.thirdHoldersName : 'NA', 'type': 'Third Holder' }
                ];
                holderInfoArray.folioId = args.folioId;
                holderInfoArray.holdingType = args.holdingType;
                holderInfoArray.emailId = args.emailId;
                transactModel.setInvestorDetails(holderInfoArray);
            };

            $scope.$on('delete', function(event, args) {
                var body = {
                    "investorData": {
                        "emailId": "sai@gmail.com",
                        "trxnType": args.txnType ? args.txnType : "NA",
                        "trxnNo": args.goalId,
                        "userType": "",
                        "reqstDate": "",
                        "folioId": args.folioId,
                        "holdingType": args.holdingType,
                        "mode": "D",
                        "invType": args.invType,
                        "distId": args.distId,
                        "holderDetails": [{
                            "name": args.firstHolderName,
                            "type": "Firstholder"
                        }]
                    },
                    "goalSheetData": {
                        "goalSummary": [{
                            "goalName": args.goalName,
                            "goalDescription": "Vishu Dream",
                            "goalAmountAot": "20,00,00",
                            "goalAmountEog": "20,00,00",
                            "annualWithDrawals": "4000",
                            "annualStepUp": "10%",
                            "currentAge": "30 Years",
                            "goalTenor": "30 Yeras",
                            "goalCompPer": "50%",
                            "goalAchievedTillDt": "11,00,000",
                            "goalAchivedPer": "53.6%",
                            "goalTenorRemained": "15"
                        }],
                        "topUpSummary": {
                            "goalName": "Child Education",
                            "goalDeficit": "9,00,000",
                            "goalTenorRemained": "15"
                        },
                        "investmentSummary": [{
                            "fund": args.fundOption,
                            "allocation": "50%",
                            "monthly": "800",
                            "annual": "8,000",
                            "oneTime": "40,000"
                        }],
                        "investmentSimulation": [{
                            "time": "Current",
                            "amount": "800"
                        }]
                    }
                };
                savedSmartSolutionsModel.postDeleteSmartSolDtls(body)
                    .then(function(data) {
                        $state.go($state.current, {}, { reload: true });
                        toaster.success('Successfully Deleted -- selected Smart Solution');
                    }, function() {
                        toaster.error('Unable to Delete selected Smart Solution');
                    });
            });
        }
    }
}

SmartSolutionsGrid.$inject = ['savedSmartSolutionsModel', 'investorConstants','$timeout','$state', '$filter','transactModel', 'toaster', 'recommendedPlanModelService', 'buildPlanModelService', 'planSmartSolution', 'savedSmartSolutionsInitLoader'];
module.exports = SmartSolutionsGrid;
