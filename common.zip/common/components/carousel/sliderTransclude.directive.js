/**
 * @ngdoc directive
 * @name fticCarouselTransclude
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires $transclude
 * @description
 *
 * - fticCarouselTransclude will include template wraped between directive.
 * 
 *
 **/

'use strict';

var CarouselTransclude = function() {
    return {
        restrict: 'A',
        link: function(scope, elem, attrs, ctrl, $transclude) {
            //create a new scope that inherits from the parent of the
            //search directive ($parent.$parent)
            var newScope = scope.$parent.$parent.$new();
            //put result from isolate to be available to transcluded content
            newScope.slide = scope.$eval(attrs.slide);
            $transclude(newScope, function(clone) {
                elem.append(clone);
            });
        }
    };
};

CarouselTransclude.$inject = [];
module.exports = CarouselTransclude;
