// productDetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ProductThemeDetailsSchema = new mongoose.Schema({
    themeTypes: {
        type: Array,
        "default": []
    }
});

var ProductThemeDetailsLookUp = mongoose.model('ProductThemeDetailsLookUp', ProductThemeDetailsSchema);
/*json order: investor book-*/
var productLiteratureThemesModel = new ProductThemeDetailsLookUp({
 
  "themeTypes":[
    {
      title: 'Equities', 
      key : 'Eq'
    },
    {
       title: 'Fixed Income', 
      key : 'fi'
    }
  ]
  
});

ProductThemeDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ProductThemeDetailsLookUp table, please contact admin...');
    } else {
        ProductThemeDetailsLookUp.remove({}, function(err) {
            console.log('ProductThemeDetailsLookUp collection removed');
           productLiteratureThemesModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ProductThemeDetailsLookUp table, please contact admin...');
                }
                console.log('ProductThemeDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ProductThemeDetailsLookUp;
