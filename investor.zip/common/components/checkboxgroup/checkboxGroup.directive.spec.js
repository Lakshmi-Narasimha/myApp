describe('Directive: CheckBox Group', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;            
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-checkbox-group></ftic-checkbox-group>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();
        

    });

   
    it('should compiled element to be defined', function(){

        expect(directiveEle).toBeDefined();
        expect(scope).toBeDefined();
    });

    it('should have isolated scope', function(){

        expect(directiveEle.isolateScope()).toBeDefined();
    });
    
    it('should define updateCheckboxes function', function(){
        
        isoScope.updateCheckboxes(value);
        expect(isoScope.checkbox.value).toBe("checked"); //ToDo
    });
    
});
