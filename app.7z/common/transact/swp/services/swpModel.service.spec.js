'use strict';
describe('Service: swpModel ', function() {
	var swpModel,httpBackend,$window,transactModel,ifscModel,fetchSwpDetailsPromise,validateSWPPromise;

   var validateSWPResponse = {"webRefNo":"SWD000893",
		"transactionValidated":"true",
		"folioId":"13884342",
		"accountNo":"0380000217154"};

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

    var ifscResponse = { "ifscCode":"HDFC0000835",
		"bankName":"HDFC BANK LTD",
		"branchName":"BANDRA EAST - KALANAGAR",
		"city":"022-61606161"
	};

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var swpObject = { 
		selectedMode: 'cheque', 
		startDate: "Mon Dec 11 2017 14:54:45 GMT+0530 (India Standard Time)", 
		endDate: "Mon Dec 27 2017 14:54:45 GMT+0530 (India Standard Time)", 
		noofInstallments: 6,
		frequency: 'Monthly', 
		selectedType: 'capital',
		swpAmtValue: 'Capital Appreciation',
		bankDetails: 'CITI BANK - 7335300411'  
	};

	var swpModelObject = {
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"swpDetails" : swpObject
			};
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,_transactModel_,_swpModel_,_ifscModel_){	
		swpModel = _swpModel_;		
        httpBackend = $httpBackend;		        
        transactModel = _transactModel_;
        ifscModel = _ifscModel_;

        ifscModel.setIfscGridResDet({
			"bankDetails" : ifscResponse.branchName,
			"bnkAdd" : ifscResponse.city,
			"ifscCode" : ifscResponse.ifscCode
		});
        transactModel.setTransactDetails(swpModelObject); 

		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the function fetchSwpDetails',function(){
		expect(swpModel.fetchSwpDetails).toBeDefined();
	});

	it('should define the function validateSTP',function(){
		expect(swpModel.validateSWP).toBeDefined();
	});
	
	describe("fetchSwpDetails promise",function(){
		beforeEach(inject(function() {						
			fetchSwpDetailsPromise = swpModel.fetchSwpDetails();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/swp').respond(200,[{"status":"success"}]);
			fetchSwpDetailsPromise.then(function(response){										
				expect(response[0].status).toBe("success");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/swp').respond(400,failureResponse);
			fetchSwpDetailsPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	describe("validateSWP promise",function(){
		beforeEach(inject(function() {						
			validateSWPPromise = swpModel.validateSWP();				
		}));

		it("should resolve when success if user selects capital Appreciation and check radio buttons",function(done){					
			httpBackend.expectPOST('http://localhost:3030/transact/validateSwp?guId=878').respond(200,validateSWPResponse);

			validateSWPPromise.then(function(response){										
				expect(response.accountNo).toBe('0380000217154');			
				done();
			});			

			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectPOST('http://localhost:3030/transact/validateSwp?guId=878').respond(400,failureResponse);
			validateSWPPromise.then(null,function(response){						
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	it("validateSWP promise should resolve when success if user selects amount and direct-credit radio buttons",function(done){					
		transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"swpDetails" : { 
				selectedMode: 'direct-credit', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6,
				frequency: 'Yearly', 
				selectedType: 'fixed',
				swpAmtValue: 3000,
				bankDetails: 'CITI BANK - 7335300411'  
			}
		}); 

		validateSWPPromise = swpModel.validateSWP();				
		httpBackend.expectPOST('http://localhost:3030/transact/validateSwp?guId=878').respond(200,validateSWPResponse);

		validateSWPPromise.then(function(response){										
			expect(response.accountNo).toBe('0380000217154');			
			done();
		});			

		httpBackend.flush();
	});
});	
