var express = require('express');
var https = require('https');

var router = express.Router();
var engagementModel = require('./engagement.model');
var getMessageModel = require('../getMessage/getMessage.model');

// var dataPass = function(req, res){
//   req.uri = dataPassModel.createRequestUri;
//   console.log("requestURI:", req.uri);
//   var postBody = querystring.stringify(post_data);
//   console.log(postBody);
//   var proxyRequest = https.request({
//           host: req.uri.host,
//           method: 'POST',
//           path: req.uri.path,
//           headers: {
//             'Content-Type': 'application/x-www-form-urlencoded',
//             'Cookie': req.sessionCookie,
//             'Content-Length': Buffer.byteLength(postBody)
//           },
//           rejectUnauthorized: true
//       },
//
//       function(proxyResponse){
//           console.log("statusCode: ", proxyResponse.statusCode);
//           proxyResponse.setEncoding('utf8');
//           if (proxyResponse.statusCode === 200) {
//               res.status(200).end();
//           } else {
//               res.send({
//                   statusCode: proxyResponse.statusCode,
//                   message: 'Something went wrong while retrieving data.'
//               });
//           }
//           proxyResponse.on('error', function(err) {
//
//           });
//       });
//
//   proxyRequest.write(postBody);
//   proxyRequest.end();
// };


var getMsg = function(req, res, callBack) {
    req.uri = getMessageModel.createRequestUri;
    for (var i = 0; i < 3 ; i++) {
        (function(i) {
            var proxyRequest = https.request({
                    host: req.uri.host,
                    method: 'GET',
                    path: req.uri.path + req.engagementID,
                    headers: {
                        'Cookie': req.sessionCookie
                    }
                },
                function(proxyResponse) {
                    // console.log("GetMsgstatusCode: ", proxyResponse.statusCode);
                    proxyResponse.setEncoding('utf8');
                    //console.log("chunk: " + res.statusCode);
                    proxyResponse.on('data', function(chunk) {
                      //console.log("Response: " + chunk);
                        if (i === 2) {
                            callBack(chunk);

                        }
                    });
                    /*if (i === 2) {
                        callBack('{}');
                    }*/
                    proxyResponse.on('error', function(err) {
                        err.message = 'ERROR!!! Something went wrong while retrieving data.';
                        res.send(err);
                    });
                });

            proxyRequest.write(res.body + '');
            proxyRequest.end();
        })(i);
    }
};

// api route
router.route('/mfchat/rest/engagement')
    .post(function(req, res) {
        req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID];
        var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + '&InitialMessage=' + initialMessage,
                headers: {
                    'Cookie': req.sessionCookie,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            },

            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    chunk = JSON.parse(chunk);
                    console.log('EngmntResponse:',chunk.engagementID);

                    if (chunk.engagementID) {
                        engagementModel.response.Page.status = (chunk.status === "queued" ? "accepted" : chunk.status);
                        engagementModel.response.Page.engagementID  = req.engagementID = chunk.engagementID;
                        engagementModel.response.Page.customerID = chunk.customerID;
                        // Added explictly not available in model
                        //res.send(engagementModel);
                        getMsg(req, res, function(chunk) {
                            chunk = JSON.parse(chunk);
                            //console.log("FinalResponse: " chunk);
                            //console.log('GetMessageResponse:',engagementModel.response.ModuleMap.Support.msgList[0].messageType);
                            if (chunk.message && chunk.messages[0].agentID) {
                                engagementModel.response.Page.agentName = chunk.messages[0][agent.alias]; // Added explictly not available in model
                                engagementModel.response.Page.agentID = chunk.messages[0].agentID;
                                //engagementModel.response.page.command = chunk.command; //Added explictly not available in model
                                //engagementModel.response.page.from = chunk.from; //Added explictly not available in model
                                //engagementModel.response.page.message = chunk.message; //Added explictly not available in model
                                //engagementModel.response.page.messageText = chunk.messageText; //Added explictly not available in model
                                engagementModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                engagementModel.response.ModuleMap.Support.msgList[0].agentGroupID = chunk.messages[0].agentGroupID;
                                engagementModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                engagementModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                engagementModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0][agent.alias] + "joined the conversation";
                                engagementModel.response.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0][agent.alias];
                                engagementModel.response.ModuleMap.Support.ResponseInfo.topMessage = "You're chatting with" + chunk.messages[0][agent.alias];
                                engagementModel.response.ModuleMap.Support.msgList[0]
                            }
                            res.send(engagementModel.response);
                            // var post_data = {
                            //   "engagementID": engagementModel.response.Page.engagementID,
                            //   "agentID": engagementModel.response.Page.agentID,
                            //   "Role": req.body.RequestParams.accRole,
                            //   "Mobile Number": req.body.RequestParams.MDN,
                            //   "Greeting Name": req.body.RequestParams.nickName
                            // };
                        });
                        // dataPass(req, res){
                        //   console.log("DataPass call is trigerred": res.statusCode);
                        // };

                    } else {
                        /*getMsg(req, res, function(chunk) {
                            console.log("engagement" + chunk);
                            chunk = JSON.parse(chunk);
                            if (chunk.agentID) {
                                getMessageModel.response.Page.agentName = chunk.agentName; // Added explictly not available in model
                                //getMessageModel.response.agentIsTyping-state = chunk.agentIsTyping-state
                                getMessageModel.response.page.agentID = chunk.agentID;
                                getMessageModel.response.page.command = chunk.command; //Added explictly not available in model
                                getMessageModel.response.page.from = chunk.from; //Added explictly not available in model
                                getMessageModel.response.page.message = chunk.message; //Added explictly not available in model
                                getMessageModel.response.page.messageText = chunk.messageText; //Added explictly not available in model
                            }
                            res.send(getMessageModel.response);
                        });*/
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }

                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
