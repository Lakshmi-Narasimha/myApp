var log4js = require('log4js');
var fs = require('fs');
var path = require('path');

var logDirectory = path.join(__dirname, '../log');
// ensure log directory exists
var logDir = fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

var now = new Date();
var month = now.getMonth() + 1;
month = (month < 10 ? "0" : "") + month;
var day  = now.getDate();
day = (day < 10 ? "0" : "") + day;


log4js.configure({
    "appenders": [{
      "category": "access",
      "type": "dateFile",
      "filename": path.join(logDirectory, 'log4js-access-logs_'+ month + "-" + day + "-" + now.getFullYear() +'.log'),
      "pattern": "-yyyy-MM-dd",
      "backups": 3
    },
    {
      "category": "system",
      "type": "dateFile",
      "filename": path.join(logDirectory, 'log4js-system-logs_'+ month + "-" + day + "-" + now.getFullYear() +'.log'),
      "pattern": "-yyyy-MM-dd",
      "backups": 3
    },
    {
      "category": "error",
      "type": "dateFile",
      "filename": path.join(logDirectory, 'log4js-error-logs_'+ month + "-" + day + "-" + now.getFullYear() +'.log'),
      "pattern": "-yyyy-MM-dd",
      "backups": 3
    },
    {
      "type": "console"
    }],
    "levels": {
      "access": "ALL",
      "system": "ALL",
      "error": "ERROR"
    }
});

module.exports = {
  access: log4js.getLogger('access'),
  system: log4js.getLogger('system'),
  error: log4js.getLogger('error'),
  express: log4js.connectLogger(log4js.getLogger('access'), {level: log4js.levels.INFO}),
  isDebug: function(category) {
    return (log4js.levels.DEBUG.level >= category.level.level);
  }
};
