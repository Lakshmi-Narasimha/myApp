/**
 * @ngdoc directive
 * @name investment preferences
 * @description
 *
 * - Investment preferences component will display the selection option for payments through financial advisor or direct.
 * 
 *
 **/
 'use strict';

var kycReg = function($state, transactEventConstants, transactModel, buildPlanModelService) {
    return {
            template: require('./kycReg.html'),
            restrict: 'E',
            replace: true,
            scope: {
            },
            controller: ['$scope', function($scope){
                $scope.isPhysicalKyc = false;            
                $scope.instantKycArr = [];
                $scope.holderDtls = {};

                $scope.panNumber = buildPlanModelService.kycNotRegPan;
                $scope.name = buildPlanModelService.kycNotRegName;
                $scope.hodlerType = buildPlanModelService.kycNotRegType;
                
                $scope.continue = function(){
                    $scope.isPhysicalKyc = false;
                    if ($scope.keyRegis.$valid) {
                        if($scope.modeSelected == 'aadharNo'){
                            $scope.$broadcast(transactEventConstants.transact.INSTANT_KYC);
                            

                            $scope.holderDtls.aadhar = $scope.keyRegis.kycVal[0].aadhar;
                            $scope.holderDtls.email = $scope.keyRegis.kycVal[0].email;
                            $scope.holderDtls.mobile = $scope.keyRegis.kycVal[0].mobile;

                            $scope.jointHolders = buildPlanModelService.getNewInvestorHolderDetails();

                            if ($scope.hodlerType == "Firstholder") {
                                var firstHolder = buildPlanModelService.getNewInvestorFirstHolderDtls();
                                firstHolder = _.extend(firstHolder, $scope.holderDtls); 
                                buildPlanModelService.setNewInvestorFirstHolderDtls(firstHolder);
                                console.log(buildPlanModelService.getNewInvestorFirstHolderDtls());
                            }
                            if ($scope.hodlerType == "Secondholder") {
                                var secondHolder = buildPlanModelService.getNewInvestorHolderDetails()[0];
                                secondHolder = _.extend(secondHolder, $scope.holderDtls); 
                                $scope.jointHolders[0] = secondHolder;
                                buildPlanModelService.setNewInvestorHolderDetails($scope.jointHolders);
                                console.log(buildPlanModelService.getNewInvestorHolderDetails());
                            }
                            if ($scope.hodlerType == "Thirdholder") {
                                var thirdHolder = buildPlanModelService.getNewInvestorHolderDetails()[1];
                                thirdHolder = _.extend(thirdHolder, $scope.holderDtls);
                                $scope.jointHolders[1] = thirdHolder;
                                buildPlanModelService.setNewInvestorHolderDetails($scope.jointHolders);
                                console.log(buildPlanModelService.getNewInvestorHolderDetails());
                            }

                            $state.go('smartSol.planSmartSolution.modeOfHoldingSS');
                        }else{
                            $scope.instantKycVals = {};
                            $scope.isPhysicalKyc = true;
                        }

                    }
                };

                $scope.$on(transactEventConstants.transact.MODE_OF_KYC_SELECTED, function(event, modeSelected){
                    $scope.modeSelected = modeSelected;
                });
            }]
        };
};

kycReg.$inject = ['$state', 'transactEventConstants', 'transactModel', 'buildPlanModelService'];
module.exports = kycReg;