/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function paymentDetailsController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService) {
 	console.log('paymentDetailsController');
 	$scope.holderInfoArray = [
        {key:"First Holder",value:buildPlanModelService.getInvestorSearch().custName},
        {key:"Second Holder",value:buildPlanModelService.getInvestorSearch().holders[1].name},
        {key:"Third Holder",value:buildPlanModelService.getInvestorSearch().holders[2].name},
        {key:"Folio. No.",value:buildPlanModelService.getInvestorSearch().folioId},
        {key:"Mode of Holding",value:buildPlanModelService.getInvestorSearch().holdingType}        
    ];
	
	$scope.lumpsumFundDetails = [];
	$scope.lumpsumColumnDefs = keyValueGridConfig.fundGridConfig[TransactConstant.guest.LUMPSUMINV];

	$scope.sipFundDetails = [];
	$scope.sipcolumnDefs = keyValueGridConfig.fundGridConfig[TransactConstant.guest.SIPINV];

	$scope.continue = function(){
		$state.go('smartSol.planSmartSolution.transactionDetailsSS');
	}

	$scope.PDBackBtn = function(){
		$state.go("smartSol.planSmartSolution.fundDetailsSS");
	}

}
paymentDetailsController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService'];
module.exports = paymentDetailsController;