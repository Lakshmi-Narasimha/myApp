// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SIPCalculatorSchema = new mongoose.Schema({
    sipCalculatorObject: {
        type: Array,
        "default": []
    }
});

var SIPCalculatorLookUp = mongoose.model('SIPCalculatorLookup', SIPCalculatorSchema);

var SIPCalculatorModel = new SIPCalculatorLookUp({

  "sipCalculatorObject": [
    {
  "calculatorResp": [{
    "trxnType": "LUMPSUM",
    "investedAmount": "100000",
    "investedAmountAtTenure": "NA",
    "returnData": [{
      "returnType": "Your Investment",
      "periodicReturnData": [{
        "duration": "1 Year",
        "valueOfAmount": "108064.61",
        "investedAmount": "100000.00"
      }, {
        "duration": "5 Years",
        "valueOfAmount": "160691.00",
        "investedAmount": "100000.00"
      }, {
        "duration": "10 Years",
        "valueOfAmount": "170691.00",
        "investedAmount": "100000.00"
      }, {
        "duration": "12 Years",
       "valueOfAmount": "180691.00",
        "investedAmount": "100000.00"
      }, {
        "duration": "15 Years",
        "valueOfAmount": "190691.00",
        "investedAmount": "100000.00"
      }, {
        "duration": "20 Years",
        "valueOfAmount": "200691.00",
        "investedAmount": "100000.00"
      }, {
        "duration": "30 Years",
        "valueOfAmount": "230691.00",
        "investedAmount": "100000.00"
      }]
    }, {
      "returnType": "Crisil Short Term Bond Fund Index Returns",
      "periodicReturnData": [{
        "duration": "1 Year",
        "valueOfAmount": "109277.25",
        "investedAmount": "100000.00"
      }, {
        "duration": "5 Years",
        "valueOfAmount": "155582.31",
        "investedAmount": "100000.00"
      }, {
        "duration": "10 Years",
        "valueOfAmount": "219751.15",
        "investedAmount": "100000.00"
      }, {
        "duration": "12 Years",
        "valueOfAmount": "242909.82",
        "investedAmount": "100000.00"
      }, {
        "duration": "15 Years",
        "valueOfAmount": "NA",
        "investedAmount": "NA"
      }, {
        "duration": "20 Years",
        "valueOfAmount": "NA",
        "investedAmount": "NA"
      }, {
        "duration": "30 Years",
        "valueOfAmount": "NA",
        "investedAmount": "NA"
      }]
    }]
  }]
}
    ]

});

SIPCalculatorLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SIPCalculatorLookUp table, please contact admin...');
    } else {
        SIPCalculatorLookUp.remove({}, function(err) {
            console.log('AdvisorContentLookUp collection removed');
            SIPCalculatorModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating SIPCalculatorLookUp table, please contact admin...');
                }
                console.log('SIPCalculatorLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SIPCalculatorLookUp;
