'use strict';
describe('Service: stpDetailsModel ', function() {
	var httpBackend,$window,stpDetailsModel,fetchTxnDetailsStpPromise,transactModel,validateSTPPromise,fundDetailsModel;

    var validateSTPResponse =  {
		"accountNo":"0060007818365",
		"folioId":"3456572",
		"transactionValidated":"true",
		"webRefNo":"STP000693"
    };

    var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': 520965.095916
        }]
    };

    var existingFundSelectedObject = {
        "accNo": "0060007818365",
        "amount": "800",
        "direct": null,
        "dividendFlag": "R",
        "endDate": "4 aug 2020",
        "frequency": "monthly",
        "fundCategory": "EQUITY",
        "fundOptDesc": "Franklin India BLUECHIP FUND",
        "fundOption": "006",
        "fundType": "E",
        "minAddPurAmt": "1000",
        "minNewPurAmt": "5000",
        "minSipAmt": "1",
        "multiples": "1",
        "nfoFlag": "N",
        "payoutFlag": "N",
        "reinvestmentFlag": "N",
        "startDate": "12 apr 2014",
        "stepUpType": "",
        "nextInstlDate": "5 sep 2016",
        "nextAnnualDate": "12 apr 2017",
        "stepUpValue": "NA",
        "leadDays": "15",
        "paymentDet":{
        	"payModeEmand": "false",
	        "eMandateType":"",
	        "eMandateVal": "",
	        "eMandateExpiryDate": "" 
		}		       
	};

    var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var stpObjectWithAmountSelected = {
		"stpAmount" : {
			"amount" : 51000,
			"type" : "fixedAmount"
		},
		"destinationFund" : {
			"accNo": "0010008062712",
	        "fundOptDesc": "Franklin India PRIMA FUND"
		},
		"startDate":"Wed Dec 28 2016 18:44:13 GMT+0530 (India Standard Time)",
		"endDate":"Fri Dec 30 2016 22:44:13 GMT+0530 (India Standard Time)",
		"frequency":"Weekly",
		"noofInstallments" : 6
	};

	var stpObjectWithCapitalAppreciationSelected = {
		"stpAmount" : {
			"amount" : "Capital Appreciation",
			"type" : "capitalAppreciation"
		},
		"startDate":"Wed Jan 9 2016 18:44:13 GMT+0530 (India Standard Time)",
		"endDate":"Fri Aug 3 2016 22:44:13 GMT+0530 (India Standard Time)",
		"frequency":"Monthly",
		"destinationFund" : {			
	        "fundOptDesc": "Franklin India PRIMA FUND"
		},
		"noofInstallments" : 6
	};

	var stpModel = {
		"investorDetails" : investorDetails,
		"fundDetails" : selectedFundObject,
		"stpDetails" : stpObjectWithCapitalAppreciationSelected
	};
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,_transactModel_,_stpDetailsModel_,_fundDetailsModel_){	
		stpDetailsModel = _stpDetailsModel_;		
        httpBackend = $httpBackend;		        
        transactModel = _transactModel_;
        fundDetailsModel = _fundDetailsModel_;
        
        transactModel.setTransactDetails(stpModel); 
        fundDetailsModel.setFundDetails(fundDetailsResponse);

		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the function fetchTxnDetailsStp',function(){
		expect(stpDetailsModel.fetchTxnDetailsStp).toBeDefined();
	});

	it('should define the function validateSTP',function(){
		expect(stpDetailsModel.validateSTP).toBeDefined();
	});
	
	describe("fetchTxnDetailsStp promise",function(){
		beforeEach(inject(function() {						
			fetchTxnDetailsStpPromise = stpDetailsModel.fetchTxnDetailsStp();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/transact/txnDetails').respond(200,{"status":"success"});
			fetchTxnDetailsStpPromise.then(function(response){										
				expect(response.status).toBe("success");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/transact/txnDetails').respond(400,failureResponse);
			fetchTxnDetailsStpPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	describe("validateSTP promise",function(){
		beforeEach(inject(function() {						
			validateSTPPromise = stpDetailsModel.validateSTP();				
		}));

		it("should resolve when success if user selects capital Appreciation",function(done){					
			httpBackend.expectPOST('http://localhost:3030/transact/validateStp?guId=878').respond(200,validateSTPResponse);

			validateSTPPromise.then(function(response){										
				expect(response.accountNo).toBe('0060007818365');			
				done();
			});			

			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectPOST('http://localhost:3030/transact/validateStp?guId=878').respond(400,failureResponse);
			validateSTPPromise.then(null,function(response){						
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	it('validateSwitch promise resolve successfully if user selects Amount',function(){		
		stpModel = {
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"stpDetails" : stpObjectWithAmountSelected
		};

		transactModel.setTransactDetails(stpModel); 
		validateSTPPromise = stpDetailsModel.validateSTP();	

		httpBackend.expectPOST('http://localhost:3030/transact/validateSwitch?guId=878').respond(200,validateSTPResponse);
		validateSTPPromise.then(function(response){										
			expect(response.accountNo).toBe('6019904934582');			
			done();
		});			
	});    
});	
