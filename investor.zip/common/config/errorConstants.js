'use strict';

var errorConstants = (function() {
    return {
        A0001: 'INVALID_CLIENT_ID',
        A0002: 'NO_USERNAME',
        A0003: 'NO_PASSWORD',
        A0004: 'INVALID_REFRESH_TOKEN',
        A0005: 'INVALID_ACCESS_TOKEN',
        A0006: 'ACCESS_TOKEN_EXPIRED',
        A0007: 'ACCESS_TOKEN_REVOKED',
        A0008: 'SCRIPT_EXECUTION_FAILED',
        A0009: 'SPIKE_ARREST_VIOLATION',
        A0010: 'UNKNOWN_RESOURCE',
        A0011: 'MISSING_MANDATORY_FIELDS',
        A0012: 'ACCESS_RESTRICTED',
        A0013: 'EXECUTION_FAILED',
        2005: 'The email id you have entered is not in the correct format.',
        2107: 'Mobile Number should be 10 digits in length.',
        2008: 'The following field(s) can contain only numbers. They cannot contain alphabets or other characters: Mobile Number.'

    };
}());

errorConstants.$inject = [];
module.exports = errorConstants;