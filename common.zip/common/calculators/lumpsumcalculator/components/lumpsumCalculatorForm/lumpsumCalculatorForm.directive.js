/**
 * @ngdoc property
 * @name fticLumpsumCalculatorForm Directive
 * @description
 *
 * fticLumpsumCalculatorForm directive 
 *
 **/
 'use strict';

 var fticLumpsumCalculatorForm = function($state,$timeout,eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, calculatorsEventConstants) {
   return {
    template: require('./lumpsumCalculatorForm.html'),
    restrict: 'E',
    replace: true,
    scope:{
        inputObject:'=',
        selectOptions:'=',
        userInput:'=',
        
    },
    controller:['$scope', function($scope){
        $scope.amountValue = function(){
            $scope.lumpsumCalculatorForm.$submitted = false;
        };
        $scope.init = function() {
            $scope.selectedType= 'fundType';
            $scope.calculatorReq=[];
            $scope.reload = true;
            $scope.fundType = [];
            $scope.fundType.fundCode = '';
            $scope.$on('selectedFund', function(event, data){   
            $scope.lumpsumCalculatorForm.$submitted = false;                 
               $scope.fundType.fundName = data.title;
               $scope.fundType.fundCode = data.category; 
                $scope.fundType.minLumpsumAmount = data.minLumpsumAmount;           
        });


            $scope.onSubmit = function() { 
                $scope.$emit(calculatorsEventConstants.LUMPSUM_RESET_DATA);
                 $scope.tenureErrorvalue = parseInt($scope.userInput.Tenure.value);
               if($scope.userInput.Amount.value < $scope.fundType.minLumpsumAmount || $scope.userInput.Amount.value > 999999999 || $scope.userInput.Tenure.value > 40 ||
                        $scope.userInput.Tenure.value < 1 || (($scope.userInput.Annual.value >99 || $scope.userInput.Annual.value < 1) && ($scope.userInput.Annual.isRequired))) {
                        return;
                }else if (!$scope.checkWholeNumPattern($scope.userInput.Tenure.value) || !$scope.checkWholeNumPattern($scope.userInput.Amount.value) ){
                        return;
                }else if($scope.userInput.Annual.isRequired && !$scope.checkWholeNumPattern($scope.userInput.Annual.value)) {
                    return;
                }else {
                $scope.calculatorReq = [{
                    'investmentTenure': $scope.userInput.Tenure.value,
                    'annualizedReturn' : $scope.userInput.Annual.value,
                    'investmentAmount' : $scope.userInput.Amount.value,
                    'fundName' : $scope.fundType.fundCode,
                    'calculatorType' : 'LUMPSUM',
                    'trxnType' : 'LUMPSUM',
                    'lumpsumInvestmentAmount' : $scope.userInput.Amount.value
                }];                
                $scope.$emit(calculatorsEventConstants.LUMPSUM_FUND_SUBMIT, $scope.calculatorReq);
            }
        };
    };
    $scope.listenChange = function() {
        $scope.TypeSelected = $scope.selectedType;
        if($scope.selectedType === 'fundType')
        {
            $scope.userInput.Annual.disable = true;
            $scope.userInput.Annual.isRequired = false;
            $scope.inputObject.Fund.disable = false;
            $scope.inputObject.Fund.required = true;
            $scope.userInput.Annual.value = '';
            $scope.reload = true;
        }
        else
        {
            $scope.userInput.Annual.disable = false;
            $scope.userInput.Annual.isRequired = true;
            $scope.inputObject.Fund.disable = true;
            $scope.inputObject.Fund.required = false;
            $scope.fundType.fundCode ='';
            $scope.reload = false;
            $timeout(function () {
                        $scope.reload = true;
                    },0);
        } 
    };
    $scope.init();
    $scope.resetForm = function () {
        $scope.selectedType = null;
        $scope.$emit(calculatorsEventConstants.LUMPSUM_RESET_DATA);
        $scope.reload = false;
        $timeout(function () {
            $scope.selectedType= 'fundType';
            $scope.reload = true;
            $scope.userInput.Tenure.value = '';
            $scope.userInput.Amount.value = '';
            $scope.fundType.fundCode = '';
            $scope.inputObject.Fund.disable = false;
            $scope.inputObject.Fund.required = true;
            $scope.userInput.Annual.disable = true;
            $scope.userInput.Annual.isRequired = false;
            $scope.userInput.Annual.value = '';
            $scope.calculatorReq = {};
            $scope.tenureErrorvalue = $scope.userInput.Tenure.value;
        }, 0);
    };

    
    $scope.checkWholeNumPattern = function(field){
                var patt = /^[0-9]*$/;
                // var result = patt.test($scope.userInput.Tenure.value);
                var result = patt.test(field);                
                return result;
    };
    $scope.inputChanged = function(data){
                    $scope.tenureErrorvalue = parseInt(data.value);
                    $scope.lumpsumCalculatorForm.$submitted = false;
            };                                       
}]
};
};

fticLumpsumCalculatorForm.$inject = ['$state','$timeout','eventConstants','fticLoggerMessage', 'loggerConstants', '$cookies','authenticationService','sipCalculatorInitialService', 'calculatorsEventConstants'];
module.exports = fticLumpsumCalculatorForm;