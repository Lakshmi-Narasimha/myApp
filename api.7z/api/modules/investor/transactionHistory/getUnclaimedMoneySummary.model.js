// getDividendSummary.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TransUnclaimedMoneySummaryModelSchema = new mongoose.Schema({
    unclaimedMoneySummaryResp: {
        type: Array,
        "default": []
    }
});

var TransUnclaimedMoneySummaryModelLookUp = mongoose.model('TransUnclaimedMoneySummaryModelLookUp', TransUnclaimedMoneySummaryModelSchema);

var TransUnclaimedMoneySummaryModel = new TransUnclaimedMoneySummaryModelLookUp({
    unclaimedMoneySummaryResp: {
        "invTrxnSummary": [{
            "folioId": "16962373",
            "modeofHolding": "joint",
            "holders": {
                "firstHoldersName": "VARSHA YATISH MODI ARPUTHAM JAWALAKAR",
                "secondHoldersName": "Kishan ram kiran",
                "thirdHoldersName": " "
            },
            "rows": [{
                "accountNo": "2259903574798",
                "amount": "12,552.14",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "",
                "fundDesc": "Templeton India EQUITY INCOME FUND",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "Redemption",
                "ucFundDesc": "UNCLAIMED BALANCES REDEMPTION",
                "ucUnits": "1255.214"
            }]
        }, {
            "folioId": "16493790",
            "modeofHolding": "joint",
            "holders": {
                "firstHoldersName": "HITESH SHANKARAO SATHAWANE RONALD NRE SAKIBANDA",
                "secondHoldersName": "Kishan ram kiran",
                "thirdHoldersName": " "
            },
            "rows": [{
                "accountNo": "1709903101666",
                "amount": "12,656.92",
                "benfStatus": "",
                "currentUnits": "",
                "currentValue": "",
                "destacno": "",
                "destfundesc": "",
                "familySolution": "",
                "fundDesc": "Templeton India GROWTH FUND",
                "leinUnits": "",
                "leinUnitsValue": "",
                "nominee": "",
                "nomineePercent": "",
                "paymentOption": "",
                "postalReturn": "",
                "remarks": "",
                "trxnType": "Redemption",
                "ucFundDesc": "UNCLAIMED BALANCES REDEMPTION",
                "ucUnits": "1265.692"
            }]
        }]
    }
});

TransUnclaimedMoneySummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating TransUnclaimedMoneySummaryModelLookUp table, please contact admin...');
    } else {
        TransUnclaimedMoneySummaryModelLookUp.remove({}, function(err) {
            console.log('TransUnclaimedMoneySummaryModelLookUp collection removed');
            TransUnclaimedMoneySummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransUnclaimedMoneySummaryModelLookUp table, please contact admin...');
                }
                console.log('TransUnclaimedMoneySummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransUnclaimedMoneySummaryModelLookUp;
