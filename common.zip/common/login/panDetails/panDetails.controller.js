/**
 * @ngdoc property
 * @name Pan Details controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Pan Details controller for guest module.
 *
 **/

'use strict';
function panDetailsController($scope, $state, constants, advisorRegistrationModelService, $cookies, appConfig, fticStateChange) {
    $scope.formData = {};
    $scope.otpObj = {};
    $scope.headingObj = { text: 'Register' };

    $scope.backBtn = function($event) {
        $event.preventDefault();
        fticStateChange.stateChange($state, 'loginmaster.register');
    };

    $scope.$on('panDetailsChange', function(){
        $scope.formData = advisorRegistrationModelService.getPanData();
    });

    $scope.panSubmit = function() {
        $scope.displayPANError = '';
        $scope.displayDateError = '';
        $scope.displayFailureError = '';
        $scope.errorstatus = false;
        $scope.$broadcast(constants.login.PAN_SUBMTTED_TEXT);
        $scope.formData = advisorRegistrationModelService.getPanData();
        $scope.formData.regType = advisorRegistrationModelService.getUserType();
        if (!$scope.formData.panARN) {
            $scope.displayPANError = 'PAN field is empty, please try again.';
            $scope.errorstatus = true;
        }
         if (!$scope.formData.dobOrRegDate) {
            $scope.displayDateError = 'Date of birth field is empty, please try again.';
            $scope.errorstatus = true;
        } if(!($scope.errorstatus)) {
            var loadPostSuccess = function(successResponse) {
                var otpdetails = {};
                otpdetails.mobileNo = successResponse.data.mobile;
                otpdetails.emailId = successResponse.data.emailId;
                otpdetails.guId = successResponse.data.guId;

                advisorRegistrationModelService.setUserData(otpdetails);
                advisorRegistrationModelService.setUserDetails(successResponse.data.panARN);
                $cookies.remove('accessToken', { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.remove('guId', { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('accessToken', successResponse.data.accessToken, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('userType', successResponse.data.userType, { 'domain': appConfig.DOMAIN_CONFIG });
                fticStateChange.stateChange($state, 'loginmaster.otpdetails');
            };

            var handleFailure = function(errResponse) {
                $scope.displayFailureError = errResponse.data[0].errorDescription;
                $scope.errorstatus = true;
            };

            var arnPostSuccess = function(successResponse) {
                var paramObj = {
                    guId: successResponse.data.guId,
                    userId: null,
                    password: null
                };
                advisorRegistrationModelService.loadAdviserDetails(paramObj).then(loadPostSuccess, handleFailure);
            };
            advisorRegistrationModelService.postArnDetails($scope.formData).then(arnPostSuccess, handleFailure);
        }
    };
}

panDetailsController.$inject = ['$scope', '$state', 'constants', 'advisorRegistrationModelService', '$cookies', 'appConfig', 'fticStateChange'];
module.exports = panDetailsController;
