﻿define([

], function (  ) {
    list = function () {
   
    }

    list.prototype.addItem = function () { 
    


    }

    list.prototype.flush = function () {

    }

    return list 
})