coa = coa || {};
define(
		[ 'jquery', 'underscore', 'backbone','appmodules/coa/app/js/utils' ],
		function($,_,Backbone,Utils) {
			coa.collections.accountList = Backbone.Collection
					.extend({
						model : coa.models.Account,
						parse : function(response) {
						    var _fromBackbutton = coa.user.get('fromBackButton'), _caseId = coa.user.get('caseId'), _caseDetails = coa.user.get("editCaseDetails");
						    var _caseAccounts = [];
						    if (_caseId && _caseDetails) {
						        _caseAccounts = _caseDetails.assocAccounts;
						    }
							var _results = response.d.results;
							var _validAccounts = [], _validAcctObj = {};
							if (_results && _results.length > 0) {
								$
										.each(
												_results,
												function(i, d) {
													(function(key, val) {

														var _accountInfo = _results[key];
														if (_accountInfo.relEndDt == null
																&& (_accountInfo.clRoleCd == "001" || _accountInfo.clRoleCd == "004")
																&& (_accountInfo.acctCore.statusCd == "PENDING"
																		|| _accountInfo.acctCore.statusCd == "ACTIVE" || _accountInfo.acctCore.statusCd == "INACTIVE")) {
															if (!_validAcctObj[_accountInfo.acctId]) {
																var _accDetails = {};
																_accDetails.checked = false;
																if (!_fromBackbutton && _caseId && _caseDetails) {
																    _caseAccounts.forEach(function (caseAcct) {
																        if (caseAcct.acctId == _accountInfo.acctId) {
																            _accDetails.checked = true;
																        }
																    });
																}
																_accDetails.accountId = _accountInfo.acctId;
																_accDetails.accountNumberFmtd = _accountInfo.acctCore.fmtId;
																_accDetails.ownership = 'Not available';
																_accDetails.type = 'Not available';
																_accDetails.currentAddress = 'Not available';
																_validAccounts
																		.push(_accDetails);
																_validAcctObj[_accountInfo.acctId] = true;
															}

														}

													})(i, d);

												});
								delete _validAcctObj;
								coa.validAccountsCount = _validAccounts.length;
							} else {
								Utils.unlockForm();
							}
							return _validAccounts;
						},
						nextOrder : function() {
							if (!this.length) {
								return 1;
							}
							return this.last().get('order') + 1;
						}
					});
			if (!coa.Accounts) {
				coa.Accounts = new coa.collections.accountList();
			}

		});