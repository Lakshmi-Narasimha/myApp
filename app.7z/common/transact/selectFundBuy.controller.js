/**
 * @ngdoc property
 * @name SelectFundBuyController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function SelectFundBuyController($scope, $state, transactModel, $stateParams, TransactConstant, fundDetails, transactEventConstants, $timeout) {
    console.log('SelectFundBuyController');
    $scope.kycState = 'transact.base.kycForm';
    $scope.moduleUrl = $state.current.url;
    if($scope.moduleUrl == "/buy"){
        if($stateParams.key === TransactConstant.transact.Payment_Key){
    		transactModel.setTransactType(TransactConstant.buy.BUY);
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
    	}else if($stateParams.key === TransactConstant.transact.Fund_Key){
            transactModel.setTransactType(TransactConstant.buy.BUYFUND);
            $timeout(function(){
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            },0);
        }else if($stateParams.key === TransactConstant.transact.NOMINEE_KEY){
            transactModel.setTransactType(TransactConstant.buy.BUY);
            $timeout(function(){
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            },0);
        }else{
            fundDetails.removeFundDetails();
            transactModel.setTransactType(TransactConstant.buy.BUYFUND);
        }
    	
    }else if($scope.moduleUrl == "/sip"){
        if($stateParams.key === TransactConstant.transact.Payment_Key){
    		transactModel.setTransactType(TransactConstant.sip.SIP);
            $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
    	}else if($stateParams.key === TransactConstant.transact.Fund_Key){
            transactModel.setTransactType(TransactConstant.sip.FUNDSIP);
            $timeout(function(){
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            },0);                    
        }else if($stateParams.key === TransactConstant.transact.NOMINEE_KEY){
            transactModel.setTransactType(TransactConstant.sip.SIP);
            $timeout(function(){
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            },0);                    
        }
        else{
            fundDetails.removeFundDetails();
            transactModel.setTransactType(TransactConstant.sip.FUNDSIP);
        }
    	
    }
    $scope.config.txnFundDetails.title = "Select Fund";
}
SelectFundBuyController.$inject = ['$scope', '$state', 'transactModel', '$stateParams', 'TransactConstant', 'fundDetails', 'transactEventConstants', '$timeout'];
module.exports = SelectFundBuyController;