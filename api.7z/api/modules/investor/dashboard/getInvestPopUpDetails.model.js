// getInvestPopUpDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var InvestPopUpDetailsSchema = new mongoose.Schema({
    getInvestDetails: {
        type: Object,
        "default": {}
    }
});

var InvestPopUpDetailsLookUp = mongoose.model('InvestPopUpDetailsLookUp', InvestPopUpDetailsSchema);

var InvestPopUpDetailsModel = new InvestPopUpDetailsLookUp({
    getInvestDetails: {
        "Invest": [{
            "InvestInfo": "Franklin India savings",
            "InstructionAmount": "150000",
            "MinimunAmount": "50000",
            "AccountNo": "123456789"
        }],
        "RedeemDetails": [{
            "InstructionSet": "N",
            "InvestInfo": "Franklin India savings",
            "RedeemAmount": "8000",
            "AvaliableAmount": "50000",
            "AccountNo": "123456789"
        }]
    }
});

InvestPopUpDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvestPopUpDetailsLookUp table, please contact admin...');
    } else {
        InvestPopUpDetailsLookUp.remove({}, function(err) {
            console.log('InvestPopUpDetailsLookUp collection removed');
            InvestPopUpDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvestPopUpDetailsLookUp table, please contact admin...');
                }
                console.log('InvestPopUpDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestPopUpDetailsLookUp;
