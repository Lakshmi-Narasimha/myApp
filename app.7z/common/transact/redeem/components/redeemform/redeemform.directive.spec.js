'use strict';
describe('Directive: fticRedemptionForm', function() {
	var compile,scope,directiveElement,isolatedScope,RegisteredBankInitLoader,RegisteredBankModel,frequencyOptionsModel,$window,$filter,TransactConstant,fundDetailsModel,$stateParams,$timeout,transactEventConstants,transactModel,$state,httpBackend,authenticationService,toaster,redeemModel,transactEvents,populateUnitsModel,redeemInitialLoader;
	var validateRedeemResponse = {
		"webRefNo":"RED002125",
		"transactionValidated":"true",
		"folioId":"3456572",
		"accountNo":"0069901064910"
	};

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

	var	redeemObject = {
		'type': 'Full',
		'amount': '',
		'units': '8371.015',
		'mode': 'cheque',
		'bank': 'CITI BANK - 7335300411'
	};

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': '520965.095916'
        }]
    };

   	var paymentBankByFolioResponse = {
		"paymentBank": [
			{
				"toDate": "",
				"status": "",
				"regDate": "",
				"pbPersonalAccountNumber": "7335300411",
				"pbMakerId": "",
				"pbBankName": "CITI BANK",
				"pbAccountType": "SA",
				"payoutFlag": "N",
				"paymentType": "L",
				"ifscCode": "CITI0100000",
				"fromDate": "",
				"defaultFlag": "Y",
				"amountType": "",
				"amount": "",
				"achRefNo": "",
				"accTypeDesc": "Savings Account"
			},
			{
				"toDate": "",
				"status": "",
				"regDate": "",
				"pbPersonalAccountNumber": "7335300411",
				"pbMakerId": "",
				"pbBankName": "CITI BANK",
				"pbAccountType": "SA",
				"payoutFlag": "N",
				"paymentType": "T",
				"ifscCode": "CITI0100000",
				"fromDate": "",
				"defaultFlag": "Y",
				"amountType": "",
				"amount": "",
				"achRefNo": "",
				"accTypeDesc": "Savings Account"
			},
			{
				"toDate": "",
				"status": "",
				"regDate": "",
				"pbPersonalAccountNumber": "7335300411",
				"pbMakerId": "",
				"pbBankName": "CITI BANK",
				"pbAccountType": "SA",
				"payoutFlag": "N",
				"paymentType": "W",
				"ifscCode": "CITI0100000",
				"fromDate": "",
				"defaultFlag": "Y",
				"amountType": "",
				"amount": "",
				"achRefNo": "",
				"accTypeDesc": "Savings Account"
			}
		]
	};

	var advisor = false;

	beforeEach(angular.mock.module('advisor'));	
    beforeEach(angular.mock.module('investor.transact'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-redemption-form class="p+"></ftic-redemption-form>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope,_$compile_,$window,_$filter_,_toaster_,_authenticationService_,_TransactConstant_,_fundDetailsModel_,_$stateParams_,_$timeout_,_transactEventConstants_,_transactModel_,_$state_,$httpBackend,_RegisteredBankInitLoader_,_RegisteredBankModel_,_frequencyOptionsModel_,_ifscModel_,_reviewSwpDetailsModel_,_redeemModel_,_transactEvents_,_populateUnitsModel_,_redeemInitialLoader_) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};

            $timeout = _$timeout_;
            $state = _$state_;
            $stateParams = _$stateParams_;
            $filter = _$filter_;
            authenticationService = _authenticationService_;
            TransactConstant = _TransactConstant_;
            transactEvents = _transactEvents_;
            transactEventConstants = _transactEventConstants_;
            transactModel = _transactModel_;            
            fundDetailsModel = _fundDetailsModel_;
            toaster = _toaster_;

            redeemModel = _redeemModel_;
            populateUnitsModel = _populateUnitsModel_;
            redeemInitialLoader = _redeemInitialLoader_;
            RegisteredBankInitLoader = _RegisteredBankInitLoader_;
            RegisteredBankModel = _RegisteredBankModel_;            

            redeemModel.setBankDetails(paymentBankByFolioResponse);
            RegisteredBankModel.setRegisteredBank(paymentBankByFolioResponse);
            fundDetailsModel.setFundDetails(fundDetailsResponse);            
            transactModel.setFundDetails(selectedFundObject);
            transactModel.setInvestorDetails(investorDetails);
            httpBackend = $httpBackend;

            if(advisor){
            	authenticationService.setUser({                                        
        			"userId" : "test123"        
        		});	
            }

            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();      

            isolatedScope.redeemForm.bankDetails = {};      
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variable on load',function(){
    	expect(isolatedScope.greaterAmtUnitsMsgStaus).toBe(false);
    	expect(isolatedScope.required).toBe(true);
    	expect(isolatedScope.continueBtn).toBe(true);
    	expect(isolatedScope.editRedeemBankDetails).toBe('');
    	expect(isolatedScope.config).toBeDefined();
    	expect(isolatedScope.$amountInput).toBeDefined();
    	expect(isolatedScope.$unitsInput).toBeDefined();
    	expect(isolatedScope.config.showNotification).toBe(false);
    	expect(isolatedScope.redeemCtnBtn).toBe(true);
    	expect(isolatedScope.populateRedeemDetails).toBe(false);    	    	
    	expect(isolatedScope.amountObject.disable).toBe(true);
        expect(isolatedScope.unitsObject.disable).toBe(true);
        expect(isolatedScope.isInvestorLogin).toBe(true);
        expect(isolatedScope.bankOptionValues.required).toBe(true);
        expect(isolatedScope.showTypeError).toBe(false);
        expect(isolatedScope.showInputError).toBe(false);
        expect(isolatedScope.showBankError).toBe(false);         
    });

	it('should listen the event transactEventConstants.transact.REDEEM_FORM_RESET when triggered',function(){
		isolatedScope.$broadcast(transactEventConstants.transact.REDEEM_FORM_RESET,false);
		expect(isolatedScope.amountObject.value).toBe('');
    	expect(isolatedScope.unitsObject.value).toBe('');
    	expect(isolatedScope.selectedVal).toBe('');        
        expect(isolatedScope.modeSelectedVal).toBe('Cheque');
        expect(isolatedScope.continueBtn).toBe(true);
        expect(isolatedScope.populateRedeemDetails).toBe(false);         
	}); 
			
	it('should listen the event transactEventConstants.transact.REDEEM_FORM_RESET when triggered if investor logged in',function(){
		isolatedScope.$broadcast(transactEventConstants.transact.REDEEM_FORM_RESET,true);
		expect(isolatedScope.amountObject.value).toBe('');
    	expect(isolatedScope.unitsObject.value).toBe('');
    	expect(isolatedScope.selectedVal).toBe('');        
        expect(isolatedScope.modeSelectedVal).toBe('Cheque');
        expect(redeemModel.getUnits()).toBe('');
        expect(redeemModel.getAmount()).toBe('');
        expect(redeemModel.getType()).toBe('');
        expect(redeemModel.getMode()).toBe('Cheque');
	});

	it('should listen the event INPUT_CHANGED when triggered and check for Amount input ',function(){
		redeemModel.setType('Amount');
		isolatedScope.amountObject.value = 8000;
		spyOn(transactEvents.transact,"publishAmountDetails");
		isolatedScope.$broadcast('INPUT_CHANGED',{value:8000});
		expect(redeemModel.getAmount()).toBe(8000);
		expect(transactEvents.transact.publishAmountDetails).toHaveBeenCalledWith(isolatedScope);
	}); 

	it('should listen the event INPUT_CHANGED when triggered and check for Units input',function(){
		redeemModel.setType('Units');
		isolatedScope.unitsObject.value = 51000;
		spyOn(transactEvents.transact,"publishAmountDetails");
		isolatedScope.$broadcast('INPUT_CHANGED',{value:51000});
		expect(redeemModel.getUnits()).toBe(51000);
		expect(transactEvents.transact.publishAmountDetails).toHaveBeenCalledWith(isolatedScope);
	}); 

	it('should call the function typeChanged when redemption type radio button changes to Amount',function(){
		isolatedScope.typeChanged('Full');
		expect(isolatedScope.redeemCtnBtn).toBe(false);
		expect(isolatedScope.showTypeError).toBe(false);		
		expect(redeemModel.getType()).toBe('Full');		
        expect(isolatedScope.unitsObject.disable).toBe(true);
        expect(isolatedScope.amountObject.value).toBe('');
    	expect(isolatedScope.unitsObject.value).toBe('8371.015');	                
    	expect(redeemModel.getUnits()).toBe('8371.015');
    	expect(populateUnitsModel.getUnits()).toBe('8371.015');
	}); 

	it('should call the function typeChanged when redemption type radio button changes to Amount',function(){
		isolatedScope.typeChanged('Amount');		
		expect(redeemModel.getType()).toBe('Amount');
		expect(redeemModel.getUnits()).toBe('');
		expect(redeemModel.getAmount()).toBe('');
		expect(isolatedScope.amountObject.value).toBe('');
    	expect(isolatedScope.unitsObject.value).toBe('');	                
    	expect(isolatedScope.amountObject.disable).toBe(false);        
	}); 

	it('should call the function typeChanged when redemption type radio button changes to Amount',function(){
		isolatedScope.typeChanged('Units');		
		expect(redeemModel.getType()).toBe('Units');		
        expect(isolatedScope.unitsObject.disable).toBe(false);
	}); 

	it('should call the function modeChanged when mode of payment radio button',function(){
		isolatedScope.modeChanged('cheque');		
		expect(redeemModel.getMode()).toBe('cheque');		       
	});

	it('should listen the event Call_Registered_banks when triggered',function(){
		spyOn(redeemInitialLoader,"loadAllServices");
		isolatedScope.$broadcast('Call_Registered_banks');
		expect(redeemInitialLoader.loadAllServices).toHaveBeenCalledWith(isolatedScope);
	});

	it('should listen the event selectedOption when triggered',function(){
		isolatedScope.$broadcast('selectedOption',{title: 'CITI BANK - 7335300411'});				
		expect(redeemModel.getBank()).toBe('CITI BANK - 7335300411');
	});	

	it('should listen the event transactEventConstants.transact.REDEMPTION_DETAILS when triggered',function(){
		redeemModel.setBank('CITI BANK - 7335300411');
		isolatedScope.$broadcast(transactEventConstants.transact.REDEMPTION_DETAILS);
		$timeout.flush();		
		expect(isolatedScope.bankOptions).toEqual([{title: 'CITI BANK - 7335300411'},{title: 'CITI BANK - 7335300411'},{title: 'CITI BANK - 7335300411'}]);		
		expect(isolatedScope.selected).toEqual({title: 'CITI BANK - 7335300411'});
	});

	describe('should call the function getSelections on click of redeem continue button',function(){

		it('and show error message if no type is selected',function(){
			isolatedScope.getSelections();
			expect(isolatedScope.showTypeError).toBe(true);			
		});	

		it('andshould show the error if api fails',function(){
			isolatedScope.continueBtn = false;
			redeemModel.setType('Amount');
            redeemModel.setAmount('550000');
            redeemModel.setUnits('');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
			spyOn(toaster,"error");
			isolatedScope.redeemForm.$valid = true;
			isolatedScope.getSelections();
			httpBackend.expectPOST("http://localhost:3030/transact/validateSell?guId=878").respond(400,failureResponse);
			isolatedScope.$digest();
			httpBackend.flush();
			expect(toaster.error).toHaveBeenCalledWith(failureResponse[0].errorDescription);			
		});

		it('and should show the message if entered amount is greater then available',function(){
			spyOn(toaster,"success");
			redeemModel.setType('Amount');
            redeemModel.setAmount('550000');
            redeemModel.setUnits('');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');    
			isolatedScope.redeemForm.$valid = true;
			isolatedScope.getSelections();

			expect(redeemModel.getType()).toBe('Full');
			expect(redeemModel.getUnits()).toBe('8371.015');
			expect(redeemModel.getAmount()).toBe('');
			expect(isolatedScope.amountObject.value).toBe('');
			expect(isolatedScope.greaterAmtUnitsMsgStaus).toBe(true);
			httpBackend.expectPOST("http://localhost:3030/transact/validateSell?guId=878").respond(200,validateRedeemResponse);
			httpBackend.flush();
			expect(toaster.success).toHaveBeenCalledWith('No.of Amount/Units you have entered is more than the balance available. Hence entire amount/unit balance will be considered for redemption');			
		});
	
		it('and should validate the redemption details if api returns success and navigate to investor review page',function(){
			redeemModel.setType('Full');
            redeemModel.setAmount('');
            redeemModel.setUnits('8371.015');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
            spyOn($state,"go");
			isolatedScope.redeemForm.$valid = true;
			isolatedScope.getSelections();

			httpBackend.expectPOST("http://localhost:3030/transact/validateSell?guId=878").respond(200,validateRedeemResponse);

			expect(transactModel.getTransactDetails().investorDetails).toBeDefined();
			expect(transactModel.getTransactDetails().fundDetails).toBeDefined();
			expect(transactModel.getTransactDetails().transactDetails).toBeDefined();			
            
			httpBackend.flush();
			expect($state.go).toHaveBeenCalledWith("invTransact.review.redeem");
			expect(transactModel.getWebRefNo()).toBe(validateRedeemResponse.webRefNo);		
			advisor = true;			 
		});

		it('and should validate the redemption details if api returns success and navigate to advisor review page',function(){
			redeemModel.setType('Full');
            redeemModel.setAmount('');
            redeemModel.setUnits('8371.015');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
            spyOn($state,"go");
			isolatedScope.redeemForm.$valid = true;
			isolatedScope.getSelections();

			httpBackend.expectPOST("http://localhost:3030/transact/validateSell").respond(200,validateRedeemResponse); 
			httpBackend.flush();
			expect($state.go).toHaveBeenCalledWith("transact.review.redeem");			
			expect(transactModel.getWebRefNo()).toBe(validateRedeemResponse.webRefNo);			
		});

		it('and should not show the confirmation popup if user clicks on edit and then after clicks on continue(if user does not edits the form)',function(){
			$stateParams.key = "Redeem";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"transactDetails" : redeemObject
			});				
			redeemModel.setType('Full');
            redeemModel.setAmount('');
            redeemModel.setUnits('8371.015');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
            isolatedScope.redeemForm.$valid = true;

			isolatedScope.getSelections();
			expect(isolatedScope.config.showNotification).toBe(false);
		});

		it('and should show the confirmation popup if user clicks on edit and then after clicks on continue(if user edits the form)',function(){
			$stateParams.key = "Redeem";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"transactDetails" : redeemObject
			});				
			redeemModel.setType('Units');
            redeemModel.setAmount('');
            redeemModel.setUnits('8370.015');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
            isolatedScope.redeemForm.$valid = true;

			isolatedScope.getSelections();
			expect(isolatedScope.config.showNotification).toBe(true);
		});

		it('should listen the event yes when user clicks on yes button in confirmation popup',function(){
			$stateParams.key = "Redeem";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"transactDetails" : redeemObject
			});

			redeemModel.setType('Units');
            redeemModel.setAmount('');
            redeemModel.setUnits('8370.015');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
            isolatedScope.redeemForm.$valid = true;
			isolatedScope.getSelections();	
			
			isolatedScope.$broadcast('yes');		
			expect(transactModel.getTransactDetails().transactDetails.type).toBe('Units');	
			expect(transactModel.getTransactDetails().transactDetails.units).toBe('8370.015');
		});

		it('should listen the event no when user clicks on no button in confirmation popup',function(){
			$stateParams.key = "Redeem";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"transactDetails" : redeemObject
			});
			redeemModel.setType('Units');
            redeemModel.setAmount('');
            redeemModel.setUnits('8370.015');
            redeemModel.setMode('cheque');
            redeemModel.setBank('CITI BANK - 7335300411');
            isolatedScope.redeemForm.$valid = true;
			isolatedScope.getSelections();

			isolatedScope.$broadcast('no');
			expect(isolatedScope.config.showNotification).toBe(false);
		});
	});

	it('should listen the event validateRedeemForm when triggered',function(){
		spyOn(isolatedScope,"getSelections");
		isolatedScope.$broadcast('validateRedeemForm');
		expect(isolatedScope.getSelections).toHaveBeenCalled();
		expect(isolatedScope.redeemForm.$submitted).toBe(true);
	});

	it('should listen the event populateRedeemDetails when triggered(if user selects units for redemption type)',function(){
		redeemModel.setType('Units');
        redeemModel.setAmount('');
        redeemModel.setUnits(8370.015);
        redeemModel.setMode('Cheque');
        redeemModel.setBank('CITI BANK - 7335300411');
        spyOn(isolatedScope,"$emit");
		isolatedScope.$broadcast('populateRedeemDetails',true);				

		expect(isolatedScope.redeemCtnBtn).toBe(false);
		expect(isolatedScope.continueBtn).toBe(true);
		expect(isolatedScope.$emit).toHaveBeenCalledWith('Select_Fund_Continue1');
		expect(isolatedScope.selectedVal).toBe('Units');
		expect(isolatedScope.unitsObject.disable).toBe(false);
		expect(isolatedScope.amountObject.disable).toBe(true);
		expect(isolatedScope.amountObject.value).toBe('');
		expect(isolatedScope.unitsObject.value).toBe(8370.015);
		expect(isolatedScope.modeSelectedVal).toBe('Cheque');		
		expect(isolatedScope.editRedeemBankDetails).toBe('CITI BANK - 7335300411');		
	});

	it('should listen the event populateRedeemDetails when triggered(if user selects Amount for redemption type)',function(){
		redeemModel.setType('Amount');
        redeemModel.setAmount(500000);
        redeemModel.setUnits('');
        redeemModel.setMode('Direct Credit');
        redeemModel.setBank('CITI BANK - 7335300411');
        spyOn(isolatedScope,"$emit");

		isolatedScope.$broadcast('populateRedeemDetails',true);		
		
		expect(isolatedScope.selectedVal).toBe('Amount');
		expect(isolatedScope.unitsObject.disable).toBe(true);
		expect(isolatedScope.amountObject.disable).toBe(false);
		expect(isolatedScope.unitsObject.value).toBe('');
		expect(isolatedScope.amountObject.value).toBe(500000);
		expect(isolatedScope.modeSelectedVal).toBe('Direct Credit');				
	});

	it('should listen the event populateRedeemDetails when triggered(if user selects full for redemption type)',function(){
		redeemModel.setType('Full');
        redeemModel.setAmount('');
        redeemModel.setUnits('');
        redeemModel.setMode('');
        redeemModel.setBank('CITI BANK - 7335300411');
        spyOn(isolatedScope,"$emit");

		isolatedScope.$broadcast('populateRedeemDetails',true);		
		
		expect(isolatedScope.selectedVal).toBe('Full');
		expect(isolatedScope.unitsObject.disable).toBe(true);
		expect(isolatedScope.amountObject.disable).toBe(true);		
		expect(isolatedScope.modeSelectedVal).toBe('Cheque');				
	});
});