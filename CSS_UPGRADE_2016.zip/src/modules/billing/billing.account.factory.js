/*jshint  latedef:nofunc */
/*global commonModule*/

(function() {
    'use strict';
    angular.module('CSS.billing').factory('billingUtils', ['billingConstants', '$filter', function(billingConstants, $filter) {
        var paymentDataArray = [];
        var paymentData;
        var billingData = null;
        var paymentBillsSelected = [];
        var billingUtils = {
            parseList: function(data, successCallback) {
                var self = this;
                var paymentObj = data;          
                getPaymentData(paymentObj);

                function getPaymentData(paymentData) {
                    var paymentDetails = self.setPaymentMethodDetails(paymentData);
                    successCallback(paymentDetails);
                }

            },
            setPaymentMethodDetails: function(paymentData) {

                var cardtype, nickName, cardDisplayType, len, digitsCardNum, isDefault, isCard, creditCardCategoryDisplay;
                    var bankNickName, accountHolderName, bankAccountType, cardNumber;
                    var cardCategoryDisplay, cardNickName, cardType, paymentCardsValidTo;
                    var isNickNameLong, nickNameDisplay;


                    if (paymentData.bankOrCard !== "card") {
                        if(paymentData.accountNumber !== null) {
                            len = (paymentData.accountNumber).length;
                            digitsCardNum = (paymentData.accountNumber).substring(len - 4, len);
                        }

                        cardtype = paymentData.bankAccountType;
                        cardDisplayType = this.checkPaymentMethods(cardtype);
                       
                        bankNickName = (paymentData.bankAccountHolderNickName !== null ? paymentData.bankAccountHolderNickName: "");
                        nickNameDisplay = (paymentData.bankAccountHolderNickName !== null ? (paymentData.bankAccountHolderNickName.length > 9 ? $filter('truncateNickname')(paymentData.bankAccountHolderNickName) : paymentData.bankAccountHolderNickName) : cardDisplayType);
                        nickName = (paymentData.bankAccountHolderNickName !== null ? paymentData.bankAccountHolderNickName : "");
                        isNickNameLong = (paymentData.bankAccountHolderNickName !== null ? paymentData.bankAccountHolderNickName.length >= 9 : false);

                        isCard = false;
                    } else {
                        if(paymentData.cardNumber !== null){
                            len = (paymentData.cardNumber).length;
                            digitsCardNum = (paymentData.cardNumber).substring(len - 4, len);
                        }

                        cardtype = paymentData.cardType;
                        cardDisplayType = this.checkPaymentMethods(cardtype);
                        cardNickName = (paymentData.cardHolderNickName !== null ? paymentData.cardHolderNickName: "");
                        creditCardCategoryDisplay = this.getCardCategory(paymentData.cardcategory);
                        cardCategoryDisplay = this.checkCardCategory(paymentData.cardcategory);
                        nickNameDisplay = (paymentData.cardHolderNickName !== null ? (paymentData.cardHolderNickName.length > 9 ? $filter('truncateNickname')(paymentData.cardHolderNickName) : paymentData.cardHolderNickName) : creditCardCategoryDisplay);
                        nickName = (paymentData.cardHolderNickName !== null ? paymentData.cardHolderNickName: "");
                        isNickNameLong = (paymentData.cardHolderNickName !== null ? paymentData.cardHolderNickName.length >= 9 : false);
                        isCard = true;
                    }

                    var paymentDetails = {
                        cardtype: cardtype,
                        cardDisplayType: cardDisplayType,
                        creditCardCategoryDisplay: creditCardCategoryDisplay,
                        digitsCardNum: digitsCardNum,
                        nickNameDisplay: nickNameDisplay,
                        bankNickName: (bankNickName === undefined ? null : bankNickName),
                        cardNickName: (cardNickName === undefined ? null : cardNickName),
                        isNickNameLong: isNickNameLong,
                        cardCategoryDisplay: (cardCategoryDisplay === undefined ? null : cardCategoryDisplay),
                        nickName: nickName,
                        isDefault: isDefault,
                        isCard: isCard
                    };


                    angular.merge(paymentData, paymentDetails);
                    
                return paymentData;
            },
            checkPaymentMethods: function(data, successCallback) {
                var codes = billingConstants.payment_methods_code;
                var inputData = data;

                angular.forEach(codes, function(obj, index) {
                    if (index === inputData) {
                        data = obj;
                    }
                });

                return data;
            },
            checkCardCategory: function(data, successCallback) {
                var codes = billingConstants.SUPPORTED_CREDIT_CARDS;
                var inputData = data;

                angular.forEach(codes, function(obj, index) {
                    if (obj === inputData) {
                        data = inputData.toLowerCase();
                    }
                });

                return data;
            },
            getCardCategory: function(data, successCallback) {
                var codes = window.UIC.PAYMENT_METHOD_CODES;
                var inputData = data;

                angular.forEach(codes, function(value, key) {
                    if (key === inputData) {
                        data = value;
                    }
                });

                return data;
            },
            setBillingData: function(data) {
                billingData = data;
            },
            getBillingData: function() {
                return billingData;
            }
        };
        return billingUtils;
    }]);


})();
