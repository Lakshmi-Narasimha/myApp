/**
 * @ngdoc property
 * @name ftickeyValueTileMoreInfo Directive
 * @description
 *
 *
 *
 **/
'use strict';

var keyValueMoreInfo = function($templateCache, $compile) {
    return {
            template: require('./keyValueTileMoreInfo.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                placement: '@',
                popoverInfoContent: '=',
                keyValueInfoObject: '='
            },
            controller:function(){
                var getTemplate = function() {
                    var templateUrl = $templateCache.get('popoverinfo-template.html');
                    return templateUrl;
                };
                
            }
        };
};
keyValueMoreInfo.$inject = ['$templateCache', '$compile'];
module.exports = keyValueMoreInfo;