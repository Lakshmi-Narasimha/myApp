define(['jquery', 'underscore', 'backbone','backboneRelational','appmodules/ncst/app/js/lib/validate-4.2','appmodules/ncst/app/js/models/model-client-info','appmodules/ncst/app/js/models/model-new-client','config','appmodules/ncst/app/js/utils' ], 
		function($, _, Backbone,backboneRelational, Validator,ClientInfoModel,newClinetModel,Config,Utils) {
	var _self = null, API_COMMON_DATA_BODY = Utils.getConfigProperty('API_COMMON_DATA_BODY'), BASE_URL = Config.odataServiceName;
	var modelClientDetls = Backbone.RelationalModel.extend({
		defaults : {
                        fromBack : false,
                        clientbirthDay : '',
                        clientAssociated : '',
                        clientDependants : '',
                        clienthomePhone1 : '',
                        clienthomePhone2 : '',
                        clienthomePhone3 : '',
                        clientworkPhone1 : '',
                        clientworkPhone2 : '',
                        clientworkPhone3 : '',
                        clientworkPhone4 : '',
                        clientprimaryEmail : '',
                        clientsecondaryEmail : '',
                        clientprospectSource : '',
                        clientacquisitionTech : '',
                        clientdriverLicense : '',
                        clientState: '',
                        clientPassport: '',
                        clientprimaryEmailRadio: 'clientPrimaryEmail',
                        clientListData: true,
                        dateCheck:true,
                        clientassocName:'',
                        clientassocId:'',
                        clientassocReltn:'',
                        clientNames: [],
                        telephones: []
                        

		},
		
		initialize:function(){
		    _self = this;
		  
		},
		validate : function() {
			var _proceed = true;
			if (!Validator.validateInputs('add-details')) {
				_proceed = false;
			}
			if (_proceed) {
                                if(Validator.checkforMandatoryFields('add-details')){
                                    _self.set('clientDetlsValid', true);
                                }else{
                                    _self.set('clientDetlsValid', false);
                                }
				this.setModel();
			}
			return _proceed;
		},
                clearClientAssociation: function(){
                    _self.set('clientAssociated', '');
                    _self.set('clientassocName', '');
                    _self.set('clientassocReltn', '');
                    _self.set('clientassocId', '');
                },
		setModel : function() {

			var _newClientReqModel = newClinetModel.get('newClientModel');
			var _clientDetlsForm = $('#add-details');
			var _mm = $('#cd-bday-1').val(),_dd = $('#cd-bday-2').val(),_yyyy=$('#cd-bday-3').val();
            var birthDay = [_yyyy,_mm,_dd];
            var bDay = [_mm,_dd,_yyyy];
            _self.set('clientmaritalStatus', $('#cd-marital-status').val());
            _self.set('clientbirthDay', birthDay.join(''));
            _self.set('clientDependants', $('#cd-no-dependants').val());
          
          //setting new model international phone number
            var _selphArr = ['home','business','mobile','other1','other2'];
           var  _selphArrReq = ['HOME','WORK','MOBILE','OTHER1','OTHER2'];
           _self.set('telephones',[]);
            var _telePhs = _self.get('telephones');
           
            for (var i=0; i<_selphArr.length; i++){
            	
            	var _areaCd = $("#cd-"+_selphArr[i]+"phone-1").val(),_exchCd = $('#cd-'+_selphArr[i]+'phone-2').val(),
            		_sbsNbr =$('#cd-'+_selphArr[i]+'phone-3').val(),  _intNatNum = $('#cd-'+_selphArr[i]+'phone-int-number').val();
            	_telePhs[i] = {};
            	_telePhs[i]['phnLblTxt'] = _selphArrReq[i];
            	_telePhs[i]['NANPAreaCd'] = (_areaCd != '' && _areaCd != undefined ) ? _areaCd : "";
            	_telePhs[i]['NANPExchCd'] = (_exchCd != '' && _exchCd != undefined ) ? _exchCd : "";
            	_telePhs[i]['NANPSbscNbr'] = (_sbsNbr != '' && _sbsNbr != undefined ) ? _sbsNbr : "";
            	_telePhs[i]['nonNANPPhnNbr'] = (_intNatNum != '' && _intNatNum != undefined ) ? _intNatNum : "";
            	_telePhs[i]['phnExtnNbr'] = '';
            	_telePhs[i]['phnSubLblTxt']= "";
                /* Checking to set extension and country code*/
            	if ($('#'+_selphArr[i]+'-phone-int').prop('checked')){
            		if (_selphArr[i] == 'business' || _selphArr[i] == 'other1' || _selphArr[i] == 'other2'){
            			_telePhs[i]['phnExtnNbr'] = $('#cd-'+_selphArr[i]+'phone-int-extn').val();
            		} 
            		var _contryCd = $('#cd-'+_selphArr[i]+'phone-int-country').val().trim(); 
            		if(_contryCd.indexOf('+') != 0 && _contryCd.length>0){
            			_contryCd ='+'+_contryCd;
            		}
            		//remove + symbol
            		_telePhs[i]['phnCtryCd'] = _contryCd; 
        		}else{
        			if (_selphArr[i] == 'business' || _selphArr[i] == 'other1' || _selphArr[i] == 'other2'){
            			_telePhs[i]['phnExtnNbr'] = $('#cd-'+_selphArr[i]+'phone-4').val();
            		}
        			if(_areaCd != '' && _areaCd != undefined ){
        				_telePhs[i]['phnCtryCd'] = "+1";
        			}else{
        				_telePhs[i]['phnCtryCd'] = "";
        			}
        			
            	}

                /*If prferred is checked prefered flag is set */
            	if ($('#' + _selphArr[i] + '-phone-pref').prop('checked')) {
            	    _telePhs[i]['phnPrfrCd'] = "01";
            	} else {
            		 _telePhs[i]['phnPrfrCd'] = "02";
            	}
           
            }
            _self.set('telephones',_telePhs);
            /* End */
           
            
            
            /*if($('#cd-primary-email:visible').length)
                _self.set('clientprimaryEmail', $('#cd-primary-email').val());
            else if($('#cd-primary-email-entity:visible').length)*/
            var _$driverLicState = $('#us-states-list-details-page');
            _self.set('clientprimaryEmail', $('#cd-primary-email-entity').val());
            _self.set('clientprimaryEmailRadio',$('input[name="cd-primary-email"]:checked').val());
            _self.set('clientsecondaryEmail', $('#cd-secondary-email').val());
            _self.set('clientprospectSource', $('#cd-prospect-source').val());
            _self.set('clientacquisitionTech', $('#cd-acquisition-technique').val());
            _self.set('clientsecondaryEmail', $('#cd-secondary-email').val());
            _self.set('clientdriverLicense', $('#cd-driver-license').val());
            _self.set('clientState', _$driverLicState.val());
            _self.set('clientStateNm', _$driverLicState.val()?_$driverLicState.find('option:selected').text():null);
            _self.set('clientPassport', $('#cd-passport-number').val());
            _self.set('clientbDay', bDay.join('/'));
            _self.set('fromBack', true);
            //save user entered to new client req model
            
	var _client = {}, _mailAdd = {};
	if (_newClientReqModel['customerTypeCd'] == "P") {
		_client = _newClientReqModel['personClient'];
		_client['bthDt'] = _yyyy+''+_mm+''+_dd;
	} else {
		_client = _newClientReqModel['orgClient'];
	}
	
		
		},
                toTitleCase: function(str){
                    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
		}
	});
	return new modelClientDetls();
});