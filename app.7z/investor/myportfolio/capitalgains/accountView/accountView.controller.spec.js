'use strict';
describe('Controller: account view controller', function() {
    var $controller, $scope, event, accountViewController, fticgAccDetLoadInitialService, investorEventConstants, timeout;
    var accountFilter = { folioPanAccNo: '0119900830298', dayFlag: 'DE' };
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _fticgAccDetLoadInitialService_, _investorEventConstants_, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);
        fticgAccDetLoadInitialService = _fticgAccDetLoadInitialService_;
        investorEventConstants = _investorEventConstants_;

        accountViewController = $controller('CGAccountViewCtrl', { $scope: $scope });
    }));

    it('should expect to be defined', function() {
        expect(accountViewController).toBeDefined();
    });

    it('should have showcgAccountData to be false', function() {
        expect($scope.showcgAccountData).toBeFalsy();
    });

    it('should trigger cgapplyac', function() {
        spyOn($scope, '$broadcast');
        $scope.$broadcast('cgapplyac');
        expect($scope.$broadcast).toHaveBeenCalledWith('cgapplyac');
    });

    it('should trigger cgaccountdetails and make showcgAccountData to be true', function() {
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('cgaccountdetails', event);
        expect($scope.$broadcast).toHaveBeenCalledWith('cgaccountdetails', event);
        expect($scope.showcgAccountData).toBeTruthy();
    });
});
