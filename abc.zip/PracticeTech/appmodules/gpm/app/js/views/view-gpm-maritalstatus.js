﻿define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils',
     'appmodules/contactprofile/app/models/cpviewmodel',
    'text!appmodules/gpm/app/templates/gpmmaritalstatus.html',
    'appcommon/data'
], function ($, _, Backbone, Utils, CPViewModel, MaritalStatusTemplate, GPMdata) {
    var maritalStatusMapping = GPMdata.maritalstatus;
    var maritalstatus = Backbone.View.extend({
        el: $("#gpm-form-update-field-container"),
        id: 'gpm-form-update-field-container',
        events: {
        },
        template: _.template(MaritalStatusTemplate),
        initialize: function (data) {
            this.data = data;
        },
        render: function (updateMode) {
            try {
                var self = this;
                if(!this.model.get('currentItemSet')){
                    var CPData = CPViewModel.getInstance().getData();
                    /*var _code = CPData.cola.clientPersonal.get('mrtlStat');
                    var _mappedCode = maritalStatusMapping.find(function (row) { return row.serviceValue == _code }).code;*/
                    var _mappedCode = (_.find(maritalStatusMapping, function (row) { return row.serviceValue === ((CPData.cola && CPData.cola.clientPersonal && CPData.cola.clientPersonal.get('mrtlStatCd')) ? CPData.cola.clientPersonal.get('mrtlStatCd') : " ") }) || { name: "", code: "", serviceValue: "" }).code
                    var maritalstatistmp = (_.find(GPMdata.maritalstatus, function (obj) { return obj.code == CPData.cola.clientPersonal.get('mrtlStatCd') }) || { name: "", code: "" });
                    var maritalString = (_.find(GPMdata.maritalstatus, function (obj) { return obj.code == (maritalstatistmp.code) }) || { name: "", code: "" });
                    this.data.fieldsInfo = {
                        maritalstatus: (maritalString.code || ""),
                        maritalStatusString: maritalString.name
                    }
                    this.model.setCurrentValue(updateMode, { data: this.data });
                }
                var _dataSet = this.model.get('items');
                var _maritalstatus = _dataSet.find(function (row) { return row.get("itemType") == "maritalstatus" }).get("changedItemValueId");
                $("#" + this.id).html(this.template({ data: _dataSet })).promise().done(function () {
                    self.loadMaritalStatusList(_maritalstatus);
                });
            }
            catch (error) {
                console.log(error);
            }
        },
        validateAndNavigateFromStep1: function () {
            if (this.model.validate('gpm-update-form', true)) {
                this.model.setChangedValue();
                if(this.model.getChangedItems().length>0){
                	$('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                }else{
                	Utils.showNoChangesMessageToUser();
                }
                
            }
        },
        loadMaritalStatusList: function (selected) {
            var _maritalstatus = GPMdata.maritalstatus;
            var _selectbox = "#cd-marital-status";
            var _options = {
                selectBox: _selectbox,
                optionsList: _maritalstatus,
                selectedVal: selected,
                oEmptyOption: false,
                isOptional: false,
            }
            Utils.loadSelectbox(_options);
        },
    });
    return maritalstatus;
});