'use strict';

var fticSelectFundDetail = function (selectFundModel, formDetailsModel, $timeout, eventConstants, transactEventConstants, transactModel, keyValueGridConfig, fundDetails, TransactConstant, sipDetailsModel, authenticationService, $state) {
    return {
        template: require('./keyValueGrid.html'),
        restrict: 'E',
        replace: true,
        scope: {
            sipType: '@?'
        },
        controller: ['$scope', function ($scope) {
            $scope.$on(transactEventConstants.transact.Show_Fund_Tile, function (event, data) {
                $scope.isTotalInvAmtExists = false;
                var transactType = transactModel.getTransactType();
                var totalInvestmentObj = {
                    fundName: 'Total Investment Amount'
                };

                $scope.isTransactSmart = transactModel.isTransactNowSmartSol;
                if (transactModel.isTransactNowSmartSol) {

                    if (transactType == TransactConstant.buy.BUY) {
                        $scope.columnDefs = keyValueGridConfig.fundGridConfig["transactNowSmartSolBuy"];
                    } else if (transactType == TransactConstant.sip.SIP) {
                        $scope.columnDefs = keyValueGridConfig.fundGridConfig["transactNowSmartSolSip"];
                    }
                } else {
                    if (authenticationService.isInvestorLoggedIn()) {
                        if(transactType === "FUNDSIP") {
                            transactType = "SIP";                                
                        }
                        if($scope.sipType === 'saveSip') {
                            $scope.columnDefs = keyValueGridConfig.fundGridConfig.INV.SAVE_SIP;
                        } else {
                            $scope.columnDefs = keyValueGridConfig.fundGridConfig.INV[transactType];
                        }
                        
                    } else {
                        $scope.columnDefs = keyValueGridConfig.fundGridConfig[transactType];
                    }

                }

                $scope.fundDetail = [];
                $scope.isReload = false;

                if (transactType == TransactConstant.transact.TRANSACT || transactType == TransactConstant.modifySip.MODIFYSIP) {

                    var fundDetailRow = selectFundModel.getSelectFundDtls();


                    $timeout(function () {
                        $scope.fundDetail.push(fundDetailRow);
                    }, 0)
                } else if (transactType == TransactConstant.buy.BUY || transactType == TransactConstant.buy.BUYFUND || transactType == TransactConstant.sip.FUNDSIP || transactType == TransactConstant.sip.SIP || transactType == TransactConstant.guest.RENEWSIP || transactType == TransactConstant.guest.SELECTSIP || transactType === TransactConstant.transact.DTP || transactType === TransactConstant.renewSip.RENEWSIP) {
                    $scope.isTotalInvAmtExists = false;
                    if ($state.current.name === 'invTransact.base.buy' && authenticationService.isInvestorLoggedIn()){
                        var funds = transactModel.getFundDetails();
                    } else{
                        var funds = fundDetails.getFundDetails();
                    }

                    var fundDetailRow = {};
                    for (var i = 0; i < funds.length; i++) {
                        fundDetailRow = funds[i];
                        $scope.fundDetail.push(fundDetailRow);
                    }
                    var isBuyNewFolioInv = ($state.current.name === "invTransact.base.buy" && authenticationService.isInvestorLoggedIn() && transactModel.getIsNewFolio());
                    if (!transactModel.isTransactNowSmartSol && !isBuyNewFolioInv) {
                        if (transactType == TransactConstant.buy.BUY) {
                            $scope.isTotalInvAmtExists = true;
                            totalInvestmentObj.amount = fundDetails.getBuyTotalAmount();
                            if ($scope.fundDetail.length > 0) {
                                $scope.fundDetail.push(totalInvestmentObj);
                            };
                        } else if (transactType == TransactConstant.sip.SIP) {
                            if (!authenticationService.isInvestorLoggedIn()) {
                                $scope.isTotalInvAmtExists = true;
                                totalInvestmentObj.sipAmount = sipDetailsModel.getSipTotalAmount();
                                if ($scope.fundDetail.length > 0) {
                                    $scope.fundDetail.push(totalInvestmentObj);
                                };
                            }
                        } else if (transactType === TransactConstant.transact.DTP) {
                            var fundDetailsDTP = selectFundModel.getSelectFundDtls();
                            var row = {};



                            row.fmDescription = fundDetailsDTP.fmDescription + '-' + fundDetailsDTP.tschvalAccno || 'NA';
                            row.dividendOption = fundDetailsDTP.dividendOption || 'NA';
                            row.investmentGoal = (fundDetailsDTP.investmentGoal ? fundDetailsDTP.investmentGoal.trim() : "") || 'NA';
                            row.marketValue = fundDetailsDTP.marketValue || 'NA';

                            $scope.fundDetail.push(row);
                        }
                    }
                }
                $timeout(function () {
                    $scope.isReload = true;
                }, 0);


            });

            $scope.$on("NOMINEE_TILE", function (event, isEditNominee) {
                $scope.isEditNominee = isEditNominee;
                // var transactType = transactModel.getTransactType();
                $scope.columnDefs = keyValueGridConfig.fundGridConfig[TransactConstant.buy.NOMINEE];
                // if(transactType == TransactConstant.buy.NOMINEE) {
                if (transactModel.getNomineeDtlsFlag()) {
                    var getnomineeDetail = null;
                    $scope.nomineeDetail = [];
                    getnomineeDetail = formDetailsModel.getNomineeDetails();
                    $timeout(function () {
                        if (getnomineeDetail !== null) {
                            var nomineeDetailRow = {};
                            for (var i = 0; i < getnomineeDetail.length; i++) {
                                nomineeDetailRow = getnomineeDetail[i];
                                $scope.nomineeDetail.push(nomineeDetailRow);
                            }
                        }
                    }, 0)

                }
                $timeout(function () {
                    $scope.isReload = true;
                }, 0);

            });


            $scope.editNoNominee = function () {
                $scope.isEditNominee = true;
                $scope.$emit('editNoNominee');
            }


            $scope.$on('editNominee', function (event, args) {
                $scope.$emit(transactEventConstants.transact.Nominee_Edit_Clicked);
            });
            $scope.$on('editFund', function (event, args) {
                $scope.$emit(transactEventConstants.transact.Fund_Edit_Clicked);
            });

            $scope.$on('editRenewSipFund', function (event, args) {
                $scope.$emit(transactEventConstants.transact.RenewSip_Fund_Edit_Clicked);
            });

            // var statusTemplate = '<ftic-action-icon action-class="icon-fti_inlineEdit"></ftic-action-icon>';

        }]
    };

};

fticSelectFundDetail.$inject = ['selectFundModel', 'formDetailsModel', '$timeout', 'eventConstants', 'transactEventConstants', 'transactModel', 'keyValueGridConfig', 'fundDetails', 'TransactConstant', 'sipDetailsModel', 'authenticationService', '$state'];
module.exports = fticSelectFundDetail;