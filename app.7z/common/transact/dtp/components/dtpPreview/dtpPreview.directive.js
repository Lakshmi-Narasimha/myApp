/**
 * @ngdoc property
 * @name fticSwpReview Directive
 * 
 * @description
 *
 * - This directive is responsible for displaying the SWP Review Status.
 *
 **/
'use strict';

var fticDTPReview = function(transactModel, dtpModel, eventConstants, $filter) {
    return  {
        template: require('./dtpPreview.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope, $element, $attrs) {
            console.log("dividendOption in review"+dtpModel.getType());
            $scope.dtpDividendobj = [{
                    text: "Destination Fund",
                    value: dtpModel.getDataObj().destinationFund.fundOptDesc
                }, {
                    text: "Dividend Option",
                    value: dtpModel.getType()
                }

            ];

        },
        link: function(scope, iElement, iAttrs, controller) {

        }
    };
};

fticDTPReview.$inject = ['transactModel', 'dtpModel', 'eventConstants', '$filter'];
module.exports = fticDTPReview;
