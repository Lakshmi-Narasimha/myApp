/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var securityVerificationTabs = function() {
	return {
            template: require('./securityVerificationTabs.html'),
            restrict: 'E',
            replace: true,
            scope: {
                
            },
            controller:['$scope', function($scope){
 
                  $scope.securityQuestion = function($event){
                        $event.preventDefault();
                        $scope.$emit('securityQuestionSelected');
                  };

                  $scope.otpSelected = function($event){
                        $event.preventDefault();
                        $scope.$emit('otpSelected');
                  }; 
            }]
        };
};

securityVerificationTabs.$inject = [];
module.exports = securityVerificationTabs;