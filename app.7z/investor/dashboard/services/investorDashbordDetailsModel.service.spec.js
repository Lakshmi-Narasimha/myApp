'use strict';
describe('Services: investor dashboard details model factory', function() {

    var investorDashboardDetailsModelData, httpBackend, Restangular, $window, params;

    beforeEach(angular.mock.module('investor'));
    beforeEach(inject(function(_investorDashboardDetailsModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
        investorDashboardDetailsModelData = _investorDashboardDetailsModel_;
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        $window = _$window_;
        $window.ga = function() {};

        params = {};
        params.guId = "123456";
    }));

    it('should investorDashboardDetailsModel to be defined', function() {
        expect(investorDashboardDetailsModelData).toBeDefined();
    });

    describe('Services: load investor dashboard services', function() {
        var investorDashboardObject;
        beforeEach(inject(function() {
            investorDashboardObject = {
                'investorDashboardObject': {
                    'profileDetails': {
                        'pan': 'DRCQR7575C'
                    }
                }
            };

            httpBackend.expectGET('http://localhost:3030/dashboard/investorDashboard?guId=123456').respond(investorDashboardObject);

        }));

        it('should load getDashboardDetails with success data and retreive the data using getter', function() {
            investorDashboardDetailsModelData.getDashboardDetails(params).then(function(result) {
                expect(result.investorDashboardObject.profileDetails).toBeDefined();
            });
            httpBackend.flush();
        });

        it('should retrive getDashboardDetails data using getter', function() {
            investorDashboardDetailsModelData.setDashboardData(investorDashboardObject.investorDashboardObject);
            expect(investorDashboardDetailsModelData.getDashboardData().profileDetails.pan).toEqual('DRCQR7575C');
        });

    });

    describe('Services: load investor Smart Solutions services', function() {
        var smartSavingsAccountObj;
        beforeEach(inject(function() {
            smartSavingsAccountObj = {
                'smartSavingsAccount': {
                    'currentValue': '5120'
                }
            };

            httpBackend.expectGET('http://localhost:3030/dashboard/investorSmartSolGoals?guId=123456').respond(smartSavingsAccountObj);

        }));

        it('should load getSmartSolDetails with success data and retreive the data using getter', function() {
            investorDashboardDetailsModelData.getSmartSolDetails(params).then(function(result) {
                expect(result.smartSavingsAccount).toBeDefined();
                investorDashboardDetailsModelData.setSmartSolutions(result);
            });
            httpBackend.flush();
        });

        it('should retrive getSmartSolDetails data using getter', function() {
            investorDashboardDetailsModelData.setSmartSolutions(smartSavingsAccountObj);
            expect(investorDashboardDetailsModelData.getSmartSolutions().smartSavingsAccount.currentValue).toEqual('5120');
        });

    });

    describe('Services: load investor smart SavAcc And OneTouch services', function() {
        var investorSmartSavAccAndOneTouchObject;
        beforeEach(inject(function() {
            investorSmartSavAccAndOneTouchObject = {
                'investorSmartSavAccAndOneTouchObject': {
                    'smartSolutionGoals': [{
                        'goalId': 'G1234',
                        'goalName': 'Wealth Creation',
                        'investment': '75,000.87',
                        'targetAmount': '2,16,000 ',
                        'achievedAmount': '1,25,876.90',
                        'pendingTimeFrame': '32',
                        'encourageText': 'Great start!',
                        'achieved': '15.07%'
                    }]
                }
            };

            httpBackend.expectGET('http://localhost:3030/dashboard/investorSmartSavings?guId=123456').respond(investorSmartSavAccAndOneTouchObject);

        }));

        it('should load getSmartSaveAccAndOneTouchDetails with success data', function() {
            investorDashboardDetailsModelData.getSmartSaveAccAndOneTouchDetails(params).then(function(result) {
                expect(result.investorSmartSavAccAndOneTouchObject).toBeDefined();
                investorDashboardDetailsModelData.setSmartSaveAccAndOneTouchData(result);
                expect(investorDashboardDetailsModelData.getSmartSaveAccAndOneTouchData().investorSmartSavAccAndOneTouchObject.smartSolutionGoals.length).toEqual(1);
            });
            httpBackend.flush();
        });

        it('should retrive getSmartSaveAccAndOneTouchDetails data using getter', function() {
            investorDashboardDetailsModelData.setSmartSaveAccAndOneTouchData(investorSmartSavAccAndOneTouchObject);
            expect(investorDashboardDetailsModelData.getSmartSaveAccAndOneTouchData().investorSmartSavAccAndOneTouchObject.smartSolutionGoals.length).toEqual(1);
        });

    });
});
