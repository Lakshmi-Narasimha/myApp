/**
 * @ngdoc property
 * @name Forgot Password controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function registerController($scope, $state, $filter, constants, $uibModal, advisorRegistrationModelService, fticStateChange) {
    $scope.headingObj = {
        text: 'Register'
    };
    $scope.chkTnCs = false;
    $scope.disable = true;
    $scope.accpted = false;
    $scope.bread = [];
    $scope.regType ='Investor';
    advisorRegistrationModelService.setUserType($scope.regType);
    $scope.$on('investorSelected', function() {

        $scope.regType = 'Investor';
        advisorRegistrationModelService.setUserType($scope.regType);

    });
    $scope.$on('advisorSelected', function() {

        $scope.regType = 'Adviser';
        advisorRegistrationModelService.setUserType($scope.regType);

    });
    $scope.$on('accptedTermsAndConditions', function() {

        $scope.accpted = true;
        $scope.chkTnCs = true;
        if ($scope.chkTnCs === true && $scope.accpted === true) {
            $scope.disable = false;
        }

    });
    $scope.$on('rejectedTermsAndConditions', function() {

        $scope.accpted = false;
        $scope.chkTnCs = false;
        if ($scope.chkTnCs === true && $scope.accpted === true) {
            $scope.disable = false;
        } else {
            $scope.disable = true;
        }

    }); 
   
    $scope.loginContinue = function() { 
        advisorRegistrationModelService.setUserType($scope.regType);
        if($scope.regType === 'Investor'){
            fticStateChange.stateChange($state, 'loginmaster.panDetails');
        } else {
            fticStateChange.stateChange($state, 'loginmaster.arndetails');
        }
        //$state.go('loginmaster.arndetails');
    };
    
    $scope.termsAndConditions = function() {
       $uibModal.open({
            template: require('../components/termsandconditions/termsAndConditions.html'),
            scope: $scope,
            size: 'lg'
        });
    };
    $scope.checkBox = function() {
        //$scope.chkTnCs = !($scope.chkTnCs);
        $scope.chkTnCs = !($scope.chkTnCs);
        $scope.termsAndConditions();
        /*if($scope.chkTnCs){
            $scope.termsAndConditions();
        }*/
        if ($scope.chkTnCs === true && $scope.accpted === true) {
            $scope.disable = false;
        } else {
            $scope.disable = true;
        }

    };

    $scope.$emit('setBreadCrumb', {
        cat: 'register',
        breadCrumb: {
            label: 'Register',
            state: ''
        }
    });

}

registerController.$inject = ['$scope', '$state', '$filter', 'constants', '$uibModal', 'advisorRegistrationModelService', 'fticStateChange'];
module.exports = registerController;
