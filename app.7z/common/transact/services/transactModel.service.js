/**
 * @ngdoc property
 * @name transactModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - transactModel is a service model which consists the list of services required for Personal Info page in My profile module.
 *
 **/
'use strict';


var transactModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, selectFundModel, selectInvestorModel, authenticationService, $sce, TransactConstant, fundDetails, bankDtlsModel, $filter, appConfig, configUrlModel, $location) {

    var _transactDetails = null;
    var _searchOption = null;
    var _searchText = null;
    var _stateValue = null;
    var _investorDetails = null;
    var _pageRange = null;
    var _fundDetails = null;
    var _advisorDetails = null;
    var _transactConfirm = null;
    var _transactType = null;
    var _buyAdvDetails = null;
    var _instantKyc = null;
    var _previousSearchValue = null;
    var _newInvestorData = null;
    var _euinDetails = null;  
    var _formattedEuinDetails = null;
    var _folioDetails=null;
    var _rawHolderDetails=null;    
    var _sipTransactionHeading = null;
    var _transactHeader = null;
    var _webRefNo = null;
    var _totalFundDetails = null;
    var _validateSwitchResponse = null;
    var _txndate = null;
    var _folioDeatilsObj = null;
    var _unitHolder = null;
    var _selectedFolio = null;
    var _isNewFolio = false;
    var _lumpsumAdvisorDtls= null;
    var _sipAdvisorDtls=null;
    var _folioMatcherParams = null;
    var _txnDateAndTime = null;
    var _validateWebRefResponse = null;
    var _keyValueFolio = null;
    var _fatcaDetails = null;
    var _kycAddtnlDetails = null;
    var _sipReqParams = null;
    var _buyReqParams = null;
    var _reqParams = null;
    var _redirectURL = null;
    var _flowId = null;
    var kycValue;
    var _folioDet = null;
    var _otp = "";
    var _advisorHeaderDetails = "";
    var _isSip = false,
        _isBuy = false,
        _isModifySip = false;
    var _isStpFixedAmt = false; 
    var _nomineeFlag = false;
    var _investorReviewState = null;
    var _downloadObj = null;
    var _txnDetails = {};
    var _retryCount =null;
    var _sipWebRefNo = null;
    var _lumpsumWebRefNo = null;
    var _formattedExistingFunds = null;
    var _flowType=null;
    var _subFlowType="";
    var _sipFundDtls=null;
    var _lumpsumFundDtls=null;
    var _oldAdvisorData = null;
    var _selectInvestorValue = null;
    var _kycTransactionLimit = null;
    var _kycRegMode = false;
    var _aadhaarNo = null;
    var _isTransactionStarted = false;
    var _isSmartSol = false;
    var _newFolio = false;
    var isInvestorLoggedin = authenticationService.isInvestorLoggedIn();
    var transactDetails = {

        resetSetters : function(){
             _transactDetails = null;
             _searchOption = null;
             _searchText = null;
             _stateValue = null;
             _investorDetails = null;
             _pageRange = null;
             _fundDetails = null;
             _advisorDetails = null;
             _transactConfirm = null;
             _transactType = null;
             _buyAdvDetails = null;
             _instantKyc = null;
             _previousSearchValue = null;
             _newInvestorData = null;
             _euinDetails = null;    
             _formattedEuinDetails = null;
             _folioDetails=null;
             _rawHolderDetails=null;
             _sipTransactionHeading = null;
             _transactHeader = null; 
             _webRefNo = null; 
             _totalFundDetails = null;
             _validateSwitchResponse = null;
             _txndate = null; 
             _folioDeatilsObj = null;
             _unitHolder = null;
             _selectedFolio = null;
             _isNewFolio = false;
             _lumpsumAdvisorDtls= null;
             _sipAdvisorDtls=null;
             _folioMatcherParams = null;
             _txnDateAndTime = null;
             _validateWebRefResponse = null;
             _keyValueFolio = null;
             _fatcaDetails = null;
             _kycAddtnlDetails = null;
             _sipReqParams = null;
             _buyReqParams = null;
             _reqParams = null;
             _redirectURL = null;
             _flowId = null;
             kycValue = "";
             _folioDet = null;
             _otp = "";
             _advisorHeaderDetails = "";
             _isSip = false;
             _isBuy = false;
             _isModifySip = false;
             _isStpFixedAmt = false; 
             _nomineeFlag = false;
             _investorReviewState = null;
             _downloadObj = null;
             _txnDetails = {};
             _retryCount =null;
             _sipWebRefNo = null;
             _lumpsumWebRefNo = null;
             _formattedExistingFunds = null;
             _flowType=null;
             _subFlowType="";
             _sipFundDtls=null;
             _lumpsumFundDtls=null;
             _oldAdvisorData = null;
             _selectInvestorValue = null;
             _kycTransactionLimit = null;
             _kycRegMode = false;
             _aadhaarNo = null;
             _isTransactionStarted = false;
             _isSmartSol = false;

            transactDetails.isNewInvestor = false;
            transactDetails.isPaperless = false;
            transactDetails.isModifySip = false;
            transactDetails.isNomineeSuccess = false;
            transactDetails.isFatcaSuccess = false;
            transactDetails.isDirect = false;
            transactDetails.openFundTab = false;
            transactDetails.isCreateFolio = false;
            transactDetails.isSameInv = false;
            transactDetails.resetForm = false;
            transactDetails.isRetryPayment = false;
            transactDetails.isRetryPaymentInvestorLeg = false;
            transactDetails.isTransactNowSmartSol = false;
            transactDetails.paymentRedirectState= "";
            transactDetails.isPaymentReady = false;
            transactDetails.fundDetailsEditClicked= false;
            transactDetails.sipDetailsEditClicked= false;
            transactDetails.showFundsOnNo= false;
            transactDetails.showPaymentDtlsOnNo= false;
            transactDetails.smartSolModeofHolding = "";
            transactDetails.transactModeOfHolding = "";
            transactDetails.isTransactNowModule = false;
            transactDetails.isLumpsumValidated=false;
            transactDetails.isSipValidated=false;
        },

        fetchGuestAdvisorDetails : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('services/searchAdvisor').get(params).then(function (advDetails) {
                deferred.resolve(advDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        fetchTransactDetails : function () {
            var deferred = $q.defer();
            Restangular.all('/gettransactdetails').get().then(function (transactDetails) {
                console.log(transactDetails);
                deferred.resolve(transactDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        fetchEUINDetails : function(params){
            // var params = {};
            // params.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            var deferred = $q.defer();
            Restangular.one('transact/advisorEuins').get(params).then(function (euinDetails) {
                deferred.resolve(euinDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        postTransactDetails : function (body,params) {
          var end = "";
          end = "transact/orders";
          params.guId = authenticationService.getUser().guId;
          var deferred = $q.defer();
          Restangular.one(end).customPOST(body, "", params, {}).then(function (transactDetails) {
              console.log(transactDetails);
              deferred.resolve(transactDetails);
          }, function (resp) {
              deferred.reject(resp);
              console.log('error');
          });
          return deferred.promise;
        },

        postRejectTransactDetails : function (params) {

          var deferred = $q.defer();
          Restangular.one("transact/rejectTransaction").get(params).then(function (rejectTransDetails) {
              console.log(rejectTransDetails);
              deferred.resolve(rejectTransDetails);
          }, function (resp) {
              deferred.reject(resp);
              console.log('error');
          });
          return deferred.promise;
        },

        downloadTransactDetails : function (body) {
          var end = "";
          end = "transact/downloadTransSlip";
          var params = {};
          params.guId = authenticationService.getUser().guId;
          var deferred = $q.defer();
          Restangular.one(end).customPOST(body, "", params, {}).then(function (downloadDetails) {
              console.log(downloadDetails);
              deferred.resolve(downloadDetails);
          }, function (resp) {
              deferred.reject(resp);
              console.log('error');
          });
          return deferred.promise;
        },

         // for Download KYC form

        downloadKycForm : function () {
            var deferred = $q.defer();
            Restangular.all('/downloadKycForm').get().then(function (data) {
                console.log(data);
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        fetchTxnDetails : function (params) {            
            var deferred = $q.defer();
            Restangular.one('transact/txnDetails').get(params).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        fetchKYCTransactionLimit : function() {
            var deferred = $q.defer();
            var params = {
                "groupId" : "EkycCutOffAmt",
                "guId": authenticationService.getUser() ? authenticationService.getUser().guId : null
            };
            Restangular.one('services/paramCodes').get(params).then(function (kycTransactionLimit) {
                deferred.resolve(kycTransactionLimit);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        setEUINDetails: function(euinDetails){
            var euinArray = euinDetails.join().split(",");
            _euinDetails = euinArray;
        },

        getEUINDetails : function(){
            if(!angular.isDefined(_euinDetails)){
                return null
            }
            return _euinDetails;
        },
        setFormattedEUINDetails: function(euinDetails){
            _formattedEuinDetails = euinDetails;
        },

        getFormattedEUINDetails : function(){
            if(!angular.isDefined(_formattedEuinDetails)){
                return null
            }
            return _formattedEuinDetails;
        },
        setFormattedExistingFunds: function(existinfFunds){
            _formattedExistingFunds = existinfFunds;
        },

        getFormattedExistingFunds : function(){
            return _formattedExistingFunds;
        },
        setisNewfolio:function (newFolio) {
            _newFolio = newFolio;
        },
        getisNewfolio:function () {
            return _newFolio;
        },
        setOtp: function(otp){
            _otp = otp;
        },

        getOtp : function(){
            return _otp;
        },
        setBuyReqParams: function(buyReqParams){
            _buyReqParams = angular.copy(buyReqParams);
        },

        getBuyReqParams : function(){
            return angular.copy(_buyReqParams);
        },
        setSipReqParams: function(sipReqParams){
            _sipReqParams = angular.copy(sipReqParams);
        },

        getSipReqParams : function(){
            return angular.copy(_sipReqParams);
        },
        setSelectInvestorValue: function(searchValue){
            _selectInvestorValue = searchValue;
        },

        getSelectInvestorValue : function(){
            return _selectInvestorValue;
        },

        setTransactDetails: function(transactDetails){
            _transactDetails = transactDetails;
        },

        getTransactDetails: function(){
            return _transactDetails;
        },

        setIsSmartSol: function(isSmartSol){
            _isSmartSol = isSmartSol;
        },

        getIsSmartSol: function(){
            return _isSmartSol;
        },

        getInvestorDetails:function(){
            if(!angular.isDefined(_investorDetails)){
                return null
            }
            return _investorDetails;
        }, 

        setInvestorDetails:function(investorDetails){
            _investorDetails = investorDetails;
        },

        getPageRange : function(){
          if(!angular.isDefined(_pageRange)){
              return null
          }
          return _pageRange;
        },
        
        setPageRange : function(pageRange){
          _pageRange = pageRange;
        },

        getFundDetails:function(){
            if(!angular.isDefined(_fundDetails)){
                return null
            }
            return _fundDetails;
        }, 

        setFundDetails:function(fundDetails){
            _fundDetails = fundDetails;
        },

        getAdvisorDetails:function(){
            if(!angular.isDefined(_advisorDetails)){
                return null
            }
            return _advisorDetails;
        }, 
        
        setAdvisorDetails:function(advisorDetails){
            _advisorDetails = advisorDetails;
        },

        getSearchOption:function(){
            if(!angular.isDefined(_searchOption)){
                return null
            }
            return _searchOption;
        },

        setSearchOption:function(searchOption){
            _searchOption = searchOption;
        },

        getSearchText:function(){
             if(!angular.isDefined(_searchText)){
                return null
            }
            return _searchText;
        },

        setSearchText:function(searchText){
             _searchText = searchText;
        },

        getStateValue:function(){
             if(!angular.isDefined(_stateValue)){
                return null
            }
            return _stateValue;
        },

        setStateValue:function(stateValue){
             _stateValue = stateValue;
        },

        getTransactConfirm:function() {
            return _transactConfirm;
        },

        setTransactConfirm:function(transactConfirm){
            _transactConfirm = transactConfirm;
        },

        getTransactType : function() {
            return _transactType;
        },

        setTransactType : function(transactType) {
            _transactType = transactType;
        },

        setAdvDetails: function(arnCode){
            _buyAdvDetails = arnCode;
        },
        
        getAdvDetails: function(){
            return _buyAdvDetails;
        },

        setOldAdvisorData: function(oldAdvisorData){
            _oldAdvisorData = oldAdvisorData;
        },
        
        getOldAdvisorData: function(){
            return _oldAdvisorData;
        },

        setInstantKyc : function(instantKycDetails){
            _instantKyc = instantKycDetails;
        },
        getInstantKyc : function(){
            return _instantKyc;
        },
        getPreviousSearchValue:function(){
             if(!angular.isDefined(_previousSearchValue)){
                return null
            }
            return _previousSearchValue;
        },
        setPreviousSearchValue:function(previousSearchValue){
             _previousSearchValue = previousSearchValue;
        },
        setFolioDetails:function(folioDetails){
            _folioDetails=folioDetails;
        },
        getFolioDetails:function(){
            return _folioDetails;
        },
        setrawHolderDts:function(rawHolderDetails){
            _rawHolderDetails=rawHolderDetails
        },
        getrawHolderDts:function(){
            return _rawHolderDetails;
        },

        setNewInvestorData : function(data){
            _newInvestorData = data;
        },

        getNewInvestorData : function(){
            if(!angular.isDefined(_newInvestorData)){
                return null
            }
            return _newInvestorData;
        },

        setSipTransactionHeading : function(data){
            _sipTransactionHeading = data;
        },
        getSipTransactionHeading:function(){
            if(!angular.isDefined(_sipTransactionHeading)){
                return null
            }
            return _sipTransactionHeading;
        },
        setTransactHeader: function(data){
          _transactHeader = data;
        },
        getTransactHeader: function(){
          return _transactHeader;
        },
        setWebRefNo: function (webRefNo) {
          _webRefNo = webRefNo;
        },
        getWebRefNo: function() {
          return _webRefNo;
        },
        getTotalFundDetails:function(){
            if(!angular.isDefined(_totalFundDetails)){
                return null
            }
            return _totalFundDetails;
        }, 
        setTotalFundDetails:function(totalFundDetails){
            _totalFundDetails = totalFundDetails;
        },

        setvalidateSWITCHDetails : function(data){
          _validateSwitchResponse = data;
        },

        getvalidateSWITCHDetails : function(){
          return _validateSwitchResponse;
        },
        setTxnDate: function (date) {
          _txndate = date;
        },
        getTxnDate: function() {
          return _txndate;
        },
        setFolioDetailsObj : function(folioDeatilsObj){
            _folioDeatilsObj =folioDeatilsObj;
        },
        getFolioDetailsObj : function () {
            if (!angular.isDefined(_folioDeatilsObj)) {
                return null;
            }
            return _folioDeatilsObj;
        } ,
        setUnitHolder : function(unitHolder){
            _unitHolder = unitHolder;
        },
        getUnitHolder : function () {
            if (!angular.isDefined(_unitHolder)) {
                return null;
            }
            return _unitHolder;
        } ,
        getSelectedFolioDts : function () {
            if (!angular.isDefined(_selectedFolio)) {
                return null;
            }
            return _selectedFolio;
        } ,
        setSelectedFolioDts : function (selectedFolio) {
            _selectedFolio = selectedFolio;
        },
        getIsNewFolio : function () {
            if (!angular.isDefined(_isNewFolio)) {
                return null;
            }
            return _isNewFolio;
        } ,
        setIsNewFolio : function (isNewFolio) {
            _isNewFolio = isNewFolio;
        },

        setLumpsumAdvisorDetails: function(advisorDetails){
            _lumpsumAdvisorDtls = advisorDetails;
        },

        getLumpsumAdvisorDetails: function(){
            return _lumpsumAdvisorDtls;
        },

        setSipAdvisorDetails:function(advisorDetails){
            _sipAdvisorDtls = advisorDetails;
        },        

        getSipAdvisorDetails:function(){
            return _sipAdvisorDtls;
        }, 
        setFolioMatcherParams:function(folioMatcherParams){
            _folioMatcherParams = folioMatcherParams;
        },        

        getFolioMatcherParams:function(){
            return _folioMatcherParams;
        }, 
        setTxnDateAndTime: function (value) {
          _txnDateAndTime = value;
        },
        getTxnDateAndTime: function() {
          return _txnDateAndTime;
        }, 

        setValidateWebRefResponse: function (object) {
          _validateWebRefResponse = object;
        },
        getValidateWebRefResponse: function() {
          return _validateWebRefResponse;
        },
        setKeyValueFolioData  : function (keyValueFolio) {
            _keyValueFolio = keyValueFolio;
        },
        getKeyValueFolioData  : function () {
            if (!angular.isDefined(_keyValueFolio)) {
                return null;
            }
            return _keyValueFolio;
        },
        setFatcaDetail : function(fatcaDetails){
        	 _fatcaDetails = fatcaDetails;
        },
        getFatcaDetail  : function () {
            if (!angular.isDefined(_fatcaDetails)) {
                return null;
            }
            return _fatcaDetails;
        },
        setKycAddnlDetails : function(kycDetails){
             _kycAddtnlDetails = kycDetails;
        },
        getKycAddnlDetails  : function () {
            if (!angular.isDefined(_kycAddtnlDetails)) {
                return null;
            }
            return _kycAddtnlDetails;
        },
        setReqParams:function(reqParams){
            _reqParams = reqParams
        },
        getReqParams:function(){
            return _reqParams;
        },

        getPaymentURL:function(){

            var transactType = this.getTransactType(),                        
            reqObjParams = this.getReqParams();            

            if(transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.sip.SIP){                
                if(this.getSipReqParams())
                {
                    reqObjParams = this.getSipReqParams();    
                }                
            }else if(transactType === TransactConstant.buy.BUYFUND || transactType === TransactConstant.buy.BUY){                                        
                if(this.getBuyReqParams())
                {
                    reqObjParams = this.getBuyReqParams();    
                }                
            }

            var paymentMode = reqObjParams.paymentMode;
            var configURL = appConfig[configUrlModel.getEnvUrl('PROXY_URL')];
            if(paymentMode === TransactConstant.common.NET_BANKING_CODE){ //Net banking
                return $sce.trustAsResourceUrl(configURL+"netBanking")
            }
            else if(paymentMode === TransactConstant.common.DEBIT_CARD_CODE){ //Debit card
                return $sce.trustAsResourceUrl(configURL+"debitCard")
            }
            else if(paymentMode === TransactConstant.common.EMANDATE_CODE){ //Mandate
                if(reqObjParams.bankName.indexOf("AXIS") > -1 ){
                    return $sce.trustAsResourceUrl(configURL+"axisBankEmandate")                
                }
                else if(reqObjParams.bankName.indexOf("HDFC") > -1 ){
                    return $sce.trustAsResourceUrl(configURL+"hdfcBankEmandate")
                }
                
            }
        },

        getPaymentProxyReqObj:function(isSmartSol){
                  // debugger;
            var paymentMode,
                transactType = this.getTransactType(),                        
                reqObjParams = {},
                fundCategories = "",
                fundOptions = "",
                postParams = "",
                bankDetails = "";                    

            reqObjParams = this.getReqParams();            

            if(transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.sip.SIP){
                transactType = TransactConstant.sip.SIP;
                if(this.getSipReqParams())
                {
                    reqObjParams = this.getSipReqParams();    
                }
                
            }else if(transactType === TransactConstant.buy.BUYFUND || transactType === TransactConstant.buy.BUY){                        
                transactType == TransactConstant.buy.BUY;                        
                if(this.getBuyReqParams())
                {
                    reqObjParams = this.getBuyReqParams();    
                }
                
            }

            paymentMode = reqObjParams.paymentMode;

            if(!reqObjParams.webRefNo)
            {
                reqObjParams.webRefNo = this.getWebRefNo();
            }    
            reqObjParams.txnNo = reqObjParams.webRefNo || this.getWebRefNo();
            // if(this.getFlowIdForProxy()!=="paperLess"&&this.getFlowIdForProxy()!=="investorLeg"&&this.getFlowIdForProxy()!=="transactNow"){
            if(isSmartSol){
                if(transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.sip.SIP){                   
                    reqObjParams.webRefNo = this.getSipWebRefNo();
                    reqObjParams.txnNo = this.getSipWebRefNo();
                }else if(transactType === TransactConstant.buy.BUYFUND || transactType === TransactConstant.buy.BUY){                                            
                    reqObjParams.webRefNo = this.getLumpsumWebRefNo();
                    reqObjParams.txnNo = this.getLumpsumWebRefNo();
                }                
            }
             
            postParams = angular.copy(reqObjParams);

            var fundDtls = fundDetails.getFundDetails();

            for(var i in fundDtls){                            
                fundCategories = fundCategories+fundDtls[i].fundCategory+"/";
                fundOptions = fundOptions+fundDtls[i].fundOption+"/";
            }

            var totalAmount = 0;

            angular.forEach(reqObjParams.fundOptions,function(obj,ind){
                totalAmount = totalAmount + parseInt(obj.amount)
            })

            bankDetails = reqObjParams.bankName+"/"+reqObjParams.bankAccountNumber;
            
            var toDate = "";

            // (reqObjParams.emToDate===TransactConstant.transact.UNTIL_CANCEL)?'30/12/2099':$filter('date')(new Date(reqObjParams.emToDate), 'dd/MM/yyyy')
            if(reqObjParams.untillCancel === "Y"){
                toDate = "30/12/2099";
            }else if(reqObjParams.untillCancel === "N"){
                toDate = $filter('date')(new Date(reqObjParams.emToDate), 'dd/MM/yyyy');     
            }

            var proxyReqObj = JSON.stringify({
                "webRefNo":reqObjParams.webRefNo,
                "guId":authenticationService.getUser().guId,
                "loginUser":"",
                "custFolioNo":reqObjParams.folioId || this.getInvestorDetails().folioId,
                "investorBankStatus":"",      
                "txnAmt":totalAmount.toString(),
                "fundCategory":fundCategories,
                "fundOption":fundOptions,
                "bankDetails":bankDetails,
                "transactionType":transactType,
                "fromDate":(reqObjParams.emFromDate)?$filter('date')(reqObjParams.emFromDate, 'dd/MM/yyyy'):"",
                "toDate":(toDate)?toDate:"",
                "referenceNo":"",
                "accountNo":reqObjParams.bankAccountNumber||"",
                "frequency":reqObjParams.emFrequency||"",
                "amountType":reqObjParams.debitType||"",
                "bankType":reqObjParams.bankName||"",
                "paymentType":paymentMode,
                "panNum":(this.getFlowIdForProxy()==="transactNow")?authenticationService.getUser().pan:this.getInvestorDetails().pan,      
                "email":(this.getFlowIdForProxy()==="transactNow")?authenticationService.getUser().emailId:this.getInvestorDetails().email,      
                "requestSource":"OAC",
                "flowId":this.getFlowIdForProxy(),                      
                // "redirectURL":$location.protocol()+"://"+this.getProxyRedirectURL(),
                "redirectURL":this.getProxyRedirectURL(),
                "retryCount":this.getRetryCount()?this.getRetryCount():"0",
                "postStr":postParams
            })

            return proxyReqObj;               
        },

        setProxyRedirectURL:function(redirectURL){
            _redirectURL = redirectURL;
        },
        getProxyRedirectURL:function(){
            return _redirectURL;
        },
        setFlowIdForProxy:function(flowId){
          _flowId = flowId;
        },
        getFlowIdForProxy:function(){
          return _flowId;
        },
        setFolioDet : function(folioDet){
          _folioDet = folioDet;
      	},
        getFolioDet  : function () {
    			if (!angular.isDefined(_folioDet)) {
    			    return null;
    			}
    			return _folioDet;
    		},
        convertUnitToAmount: function (unit, nav) {
            if (!unit || !nav) {
                return 0;
            }

            return (unit * nav);
        },

        convertAmountToUnit: function (amount, nav) {
            if (!amount || !nav) {
                return 0;
            }

            return (amount / nav);
        },
        getIsSip : function() {
          return angular.copy(_isSip);
        },
        setIsSip : function(isSip) {
          _isSip = angular.copy(isSip);
        },
        getIsBuy : function() {
          return angular.copy(_isBuy);
        },
        setIsBuy : function(isBuy) {
          _isBuy = angular.copy(isBuy);
        },
        getIsModifySIP : function() {
          return angular.copy(_isModifySip);
        },
        setIsModifySIP : function(isModifySip) {
          _isModifySip = angular.copy(isModifySip);
        },
        setStpFixedAmtStatus : function(isStpFixedAmt) {
          _isStpFixedAmt = isStpFixedAmt;
        },
        getStpFixedAmtStatus : function(){
          return _isStpFixedAmt;
        }, 
        setInvestorReviewState : function(path) {
          _investorReviewState = path;
        },
        getInvestorReviewState : function(){
          return _investorReviewState;
        },      
        setNomineeDtlsFlag : function(nomineeFlag){
            _nomineeFlag = nomineeFlag;
        },
        getNomineeDtlsFlag : function(){
            return _nomineeFlag;
        },
        setDownloadObj : function(downloadDetails){
            _downloadObj = downloadDetails;
        },
        getDownloadObj : function(){
            return _downloadObj;
        },
        getTxnDetails : function() {
            return angular.copy(_txnDetails);
        },
        setTxnDetails : function(txnDetails) {
            _txnDetails = angular.copy(_txnDetails);
        },
        setRetryCount:function(retryCount){
            _retryCount = retryCount;
        },
        getRetryCount:function(){
            return _retryCount;
        },
        setSipWebRefNo:function(sipWebRefNo){
            _sipWebRefNo = sipWebRefNo;
        },
        getSipWebRefNo:function(){
            return _sipWebRefNo;
        },
        setLumpsumWebRefNo:function(lumpsumWebRefNo){
            _lumpsumWebRefNo = lumpsumWebRefNo;
        },
        getLumpsumWebRefNo:function(){
            return _lumpsumWebRefNo;
        },
        setFlowType:function(flowType)
        {
            _flowType=flowType;
        },
        getFlowType:function(){
            return _flowType;
        },
        setSubFlowType:function(subflowType)
        {
            _subFlowType=subflowType;
        },
        getSubFlowType:function(){
            return _subFlowType;
        },
        setSipFundDtls:function(sipFundDtls){
            _sipFundDtls = sipFundDtls;
        },
        getSipFundDtls:function(){
            return _sipFundDtls;
        },
        setLumpsumFundDtls:function(lumpsumFundDtls){
            _lumpsumFundDtls = lumpsumFundDtls;
        },
        getLumpsumFundDtls:function(){
            return _lumpsumFundDtls;
        },
        postDtpTransactDetails : function (body,params) {
          var end = "";
          end = "transact/registerDtp";
          params.guId = authenticationService.getUser().guId;
          var deferred = $q.defer();
          Restangular.one(end).customPOST(body, "", params, {}).then(function (transactDetails) {
              console.log(transactDetails);
              deferred.resolve(transactDetails);
          }, function (resp) {
              deferred.reject(resp);
              console.log('error');
          });
          return deferred.promise;
        },
        setKycTransactionLimit : function(kycTransactionLimit) {
            _kycTransactionLimit = angular.copy(kycTransactionLimit);
        },
        getKycTransactionLimit : function() {
            return angular.copy(_kycTransactionLimit);
        },
        setKYCMode : function(kycRegMode) {
            _kycRegMode = kycRegMode;
        },
        getKYCMode : function() {
            return _kycRegMode;
        },
        checkRegistrationMode : function(mode) {
            if(mode ===  TransactConstant.transact.EKYC_OTP_KYC_MODE) {
                this.setKYCMode(true);                                                     
            }
        },
        setAadhaarNo : function(aadhaarNo) {
            _aadhaarNo = angular.copy(aadhaarNo);
        },
        getAadhaarNo : function() {
            return angular.copy(_aadhaarNo);
        },
        setInvTileData : function(name, pan, aadhaar, kycStatus, holderKey) {
          var invTileObj;
          if(!isInvestorLoggedin) {
              invTileObj = [{
                  key: holderKey,
                  value: name || "NA"
              }, {
                  key: "PAN/PEKRN",
                  value: pan || "NA"
              }, {
                  key: "AADHAAR",
                  value: aadhaar || "NA" 
              }, {
                  key: "KYC Status",
                  value: kycStatus || "NA"
              }];
          }
          else {
            invTileObj = [{
                key: holderKey,
                value: name || "NA"
            }, {
                key: "PAN/PEKRN",
                value: pan || "NA"
            }, {
                key: "KYC Status",
                value: aadhaar || "NA"
            }];
          }
            return invTileObj;
        },
        getTransactionStatus: function(){
            return _isTransactionStarted;
        },
        setTransactionStatus: function(statusBool){
            _isTransactionStarted = statusBool;
        },
        isNewInvestor : false,
        isPaperless : false,
        isModifySip : false,
        isNomineeSuccess : false,
        isFatcaSuccess : false,
        isDirect : false,
        openFundTab : false,
        isCreateFolio : false,
        isSameInv : false,
        resetForm : false,
        isRetryPayment : false,
        isRetryPaymentInvestorLeg : false,
        isTransactNowSmartSol : false,
        paymentRedirectState : "",
        isPaymentReady : false,
        fundDetailsEditClicked: false,
        sipDetailsEditClicked: false,
        showFundsOnNo: false,
        showPaymentDtlsOnNo: false,
        isDataResetFund: false,
        smartSolModeofHolding : "",
        transactModeOfHolding : "",
        isTransactNowModule : false,
        isLumpsumValidated:false,
        isSipValidated:false,
        isBuyFolioEditState: false
    };

    return transactDetails;

    
};

transactModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'selectFundModel', 'selectInvestorModel', 'authenticationService', '$sce', 'TransactConstant', 'fundDetails', 'bankDtlsModel', '$filter', 'appConfig', 'configUrlModel', '$location'];
module.exports = transactModel;