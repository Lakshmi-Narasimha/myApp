// GrantAccess.model.js
// grab the mongoose module
// define our GrantAccess.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GrantAccessSchema = new mongoose.Schema({
    grantAccessObject: {
        type: Object,
        "default": {}
    }
});

var GrantAccessLookUp = mongoose.model('GrantAccessLookup', GrantAccessSchema);

var GrantAccessModel = new GrantAccessLookUp({

  "grantAccessObject": {
  "subUserDetails": {
    "name": "SURESH",
    "userId": "SURESH321",
    "email": "SURESH.POLAGANI@COGNIZANT.COM",
    "accessRights": [{
      "accessRight": "Yes",
      "moduleCode": "500",
      "description": "Business Highlights"
    }, {
      "accessRight": "Yes",
      "moduleCode": "510",
      "description": "Notifications"
    }, {
      "accessRight": "Yes",
      "moduleCode": "520",
      "description": "SIP Book"
    }, {
      "accessRight": "Yes",
      "moduleCode": "530",
      "description": "Transaction Status"
    }, {
      "accessRight": "Yes",
      "moduleCode": "540",
      "description": "Funds in Focus"
    }, {
      "accessRight": "Yes",
      "moduleCode": "550",
      "description": "My Investors"
    }, {
      "accessRight": "Yes",
      "moduleCode": "560",
      "description": "Family Solutions"
    }, {
      "accessRight": "Yes",
      "moduleCode": "570",
      "description": "Collaterals"
    }, {
      "accessRight": "Yes",
      "moduleCode": "580",
      "description": "Instant Reports"
    }, {
      "accessRight": "Yes",
      "moduleCode": "590",
      "description": "Transact Sticky"
    }, {
      "accessRight": "Yes",
      "moduleCode": "600",
      "description": "Communication Capability"
    }, {
      "accessRight": "Yes",
      "moduleCode": "610",
      "description": "Leads"
    }, {
      "accessRight": "Yes",
      "moduleCode": "620",
      "description": "Recommendations"
    }, {
      "accessRight": "Yes",
      "moduleCode": "630",
      "description": "Book of Business"
    }, {
      "accessRight": "Yes",
      "moduleCode": "640",
      "description": "My Profile - Change Password"
    }]
  }
}


});

GrantAccessLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GrantAccessLookUp table, please contact admin...');
    } else {
        GrantAccessLookUp.remove({}, function(err) {
            console.log('GrantAccessLookUp collection removed');
            GrantAccessModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating GrantAccessLookUp table, please contact admin...');
                }
                console.log('GrantAccessLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GrantAccessLookUp;