/**
 * @
 *
 * - It will call restangular(network service) and resolve the data to wrapper.
 *   Also works like model with setters and getters.
 */

'use strict';

var eMandateModel = function($q, Restangular, loggerConstants, fticLoggerMessage,  toaster, authenticationService, investorConstants) {
	var _eMandatedetails = null,
        _folioDetailsArray,
        _folioDetails;
	var eMandateModel = {
		fetcheMandateList : function(params){
            //var urlPath = '/transact/emandateDetails';
            var deferred = $q.defer(); 
            Restangular.one(investorConstants.accountsettings.getEmandateDetails).get(params).then(function(eMandate) {
                deferred.resolve(eMandate);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;	
	    },
        setEMandateDetails: function(eMandatedetails){
            _eMandatedetails = eMandatedetails; 
        },
        getEMandateDetails: function(){
            return _eMandatedetails;
        },
        setFolioDetails: function(folios) {
            _folioDetailsArray = folios; 
            var folioNumber = [];
            angular.forEach(folios, function(eachFolio){
                folioNumber.push({'folioId': eachFolio.folioId})
            });
            _folioDetails = folioNumber;
        },
        getFolioDetails : function() {
            return _folioDetails;
        },
        removeEmandate : function(params, body) {
            var deferred = $q.defer(); 
            Restangular.one(investorConstants.accountsettings.removeEmandate).customPOST(body, '', params, {}).then(function(eMandate) {
                deferred.resolve(eMandate);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        createEmandate : function(params, body) {
            var deferred = $q.defer(); 
            Restangular.one(investorConstants.accountsettings.regEmandate).customPOST(body, '', params, {}).then(function(eMandate) {
                deferred.resolve(eMandate);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        fetchfolioList: function(params) {
            console.log(params);
            params.fsFlag="";
            params.txnAccess='Y';
            var deferred = $q.defer(); 
            Restangular.one('transact/panFolioKYC').get(params).then(function(eMandate) {
                deferred.resolve(eMandate);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        }
	}

	return eMandateModel;
};

eMandateModel.$inject = ['$q','Restangular', 'loggerConstants', 'fticLoggerMessage', 'toaster', 'authenticationService', 'investorConstants'];
module.exports = eMandateModel;