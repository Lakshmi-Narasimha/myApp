/**
* @ngdoc property
* @name Instant reports details controller
* @requires $filter
* @requires toaster
* @requires constants
* @requires $uibModal
* @requires eventConstants
* @requires $log
* @requires $state
* @requires selectedInstantReportsModel
* @requires instantReportsDetailsModel
* @description
*
* - Reports details will listen to the event service, update the selected count in accordions and send the selected reports to the category page.
*
**/
'use strict';

var reportsDetails = function($filter, toaster, constants, $uibModal, eventConstants, $log, $state, selectedInstantReportsModel, instantReportsDetailsModel) {
    return {
            template: require('./reportsDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
                selectedEmail:"=",
                userType:"@"
            },
            controller: function($scope, $element, $attrs){ 

                //Event to get data from the service
                var serviceEventHandler = $scope.$on(eventConstants.COMMOM_IRD, function (event) {
                    $scope.instantReports = instantReportsDetailsModel.getInstantRepsDtls();

                    destroyServiceHandler();
                });

                function destroyServiceHandler() {
                    serviceEventHandler();
                }


                //accordionData to display the title and selected count in the respective accordion
                $scope.accordionData =[{title: constants.instantreports.COMM_DETAILS, checkCount: 0}, {title: constants.instantreports.INVESTOR_DETAILS, checkCount: 0}, {title: constants.instantreports.SPECIAL_PRODUCTS, checkCount: 0}, {title: constants.instantreports.TRANSACTION_DETAILS, checkCount: 0}];




                //Event to update the selected count on checkbox click
                $scope.enableNext = true;
                $scope.selectedReports = [];

                $scope.$on(eventConstants.CHECKBOX_CHECKED, function(event, data){
                    $scope.updateSelectedCount(data.index, data.reportData);
                });
                $scope.updateSelectedCount= function(index, value){
                    $scope.accordionData[index].checkCount = (_.filter(value, function(x) {
                        if(x.value){
                            if ($scope.selectedReports.indexOf(x) == -1) {
                                $scope.selectedReports.push(x);
                            }
                        }else{
                            if ($scope.selectedReports.indexOf(x) != -1){
                                var index = $scope.selectedReports.indexOf(x);
                                $scope.selectedReports.splice(index, 1);                    
                            }
                        }
                        return x.value;
                    })).length;
                    $scope.selectedCount();

                    if ($scope.accordionData[index].checkCount) {
                        $scope.accordionData[index].label = constants.SELECTED;
                    }
                    else {
                        $scope.accordionData[index].label = "";   
                    }  

                }


                $scope.selectedCount = function(){
                    var i
                    var accordionCheckCounts = $scope.accordionData.map(function(item) {
                        return item.checkCount;
                    });
                    var count = accordionCheckCounts.reduce(function(prev, curr) {
                        return prev + curr;
                    });
                    if(count > 5 && !isToasterVisible){
                        toaster.error(constants.IR_WARNING);
                        $scope.enableNext = true;
                        return false;
                    }else if(count <= 0){
                        $scope.enableNext = true;
                    }else{
                        $scope.enableNext = false;
                        return true;
                    }
                }
                


                //Transition to category page.
                $scope.sendReports = function(){
                    selectedInstantReportsModel.setSelectedInstantReps($scope.selectedReports);
                    $state.go('instantreportscategory');
                }


                //Reseting selected reports.
                $scope.resetReports = function(){
                    var reportDetails = {};
                    for(var i=0; i < $scope.instantReports.length; i++){
                        reportDetails.index=i;
                        reportDetails.reportData = $scope.instantReports[i].reportData;
                        for(var j=0; j<reportDetails.reportData.length; j++){
                            reportDetails.reportData[j].value = false;
                        }
                        $scope.updateSelectedCount(reportDetails.index, reportDetails.reportData);
                    }
                }

            },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

reportsDetails.$inject = ['$filter', 'toaster', 'constants', '$uibModal', 'eventConstants', '$log', '$state', 'selectedInstantReportsModel', 'instantReportsDetailsModel'];
module.exports = reportsDetails;
