module.exports = function($scope, $window) {
	var liveChatWindow = null;
    $scope.openWindow = function() {
        if (liveChatWindow) {
            liveChatWindow.close();
        }
        liveChatWindow = $window.open('#/livechat', 'live-chat', 'toolbar=0,status=1,width=1100,height=500,left=10%,top=10%', "_blank");
    };
};
