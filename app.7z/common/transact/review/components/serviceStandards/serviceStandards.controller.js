/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function reviewServiceStandardsController($scope, $uibModalStack,loginModelService,constants,tcAndSTPopupModel) { 
 
    console.log($scope.chkTnCs+"checkvalueinmodel");
    $scope.accpted=false;
    $scope.accept=function(){
    	
    	//loginModelService.setChoosenOptionData($scope.accpted);
    	$scope.$emit('accptedTermsAndConditions');
    	console.log($scope.chkTnCs+"checkvalueinmodelafterclick");
    	$scope.closeModal();
    }
    $scope.doNotAccept=function(){
$scope.$emit('rejectedTermsAndConditions');
    	$scope.closeModal();
    }
     $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
    $scope.contentForST = tcAndSTPopupModel.getPopUpContentForST()["accounts-content"]["tc-online-service-standards"].content;
}


reviewServiceStandardsController.$inject = ['$scope', '$uibModalStack','loginModelService','constants','tcAndSTPopupModel'];

module.exports = reviewServiceStandardsController;