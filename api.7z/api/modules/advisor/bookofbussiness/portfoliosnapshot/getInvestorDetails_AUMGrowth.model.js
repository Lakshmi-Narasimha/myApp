// getinvestordetailsAumGrowth.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InvestorDetailsAumGrowthSchema = new mongoose.Schema({
    investorDetailsAumGrowthObject: {
        type: Array,
        "default": []
    }
});

var InvestorDetailsAumGrowthLookUp = mongoose.model('InvestorDetailsAumGrowthLookUp', InvestorDetailsAumGrowthSchema);
/*json order: investor book-*/
var InvestorDetailsAumGrowthModel = new InvestorDetailsAumGrowthLookUp({
    "investorDetailsAumGrowthObject": [
    {
  "AUMGrowth": [
    {
      "fyYear": "APR 2013 - MAR 2014",
      "openingAUM": "0.00",
      "netSales": "740.22",
      "marketAppreciation": "14823.06",
      "closingAUM": "15,566.63"
    },
    {
      "fyYear": "APR 2014 - MAR 2015",
      "openingAUM": "15,566.63",
      "netSales": "1093.66",
      "marketAppreciation": "1720.78",
      "closingAUM": "18,563.63"
    },
    {
      "fyYear": "APR 2015 - MAR 2016",
      "openingAUM": "18,563.63",
      "netSales": "-6017.30",
      "marketAppreciation": "706.63",
      "closingAUM": "13,552.63"
    }
  ]
}
    ]

});

InvestorDetailsAumGrowthLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorDetailsAumGrowthLookUp table, please contact admin...');
    } else {
        InvestorDetailsAumGrowthLookUp.remove({}, function(err) {
            console.log('InvestorDetailsAumGrowthLookUp collection removed');
           InvestorDetailsAumGrowthModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InvestorDetailsAumGrowthLookUp table, please contact admin...');
                }
                console.log('InvestorDetailsAumGrowthLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorDetailsAumGrowthLookUp;
