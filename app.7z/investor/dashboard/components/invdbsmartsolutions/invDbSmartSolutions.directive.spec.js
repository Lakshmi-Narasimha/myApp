'use strict';

describe('Directive: Smart Solutions Directive', function() {

    var compile, scope, directiveElem, isoScope, validHtml;
    var getCompiledElement = function() {
        var element = angular.element('<ftic-inv-db-smart-solutions></ftic-inv-db-smart-solutions>');
        var compiledDirective = compile(element)(scope);
        scope.$digest();
        return compiledDirective;
    };

    var investorDashboardDetailsModel = {
        getSmartSolutions: function() {
            return {
                'hasGoals': 'Y',
                'smartSolutionGoals': [{
                    'goalId': 'G1234',
                    'goalName': 'Wealth Creation',
                    'investment': '75,000.87',
                    'targetAmount': '2,16,000 ',
                    'achievedAmount': '1,25,876.90',
                    'pendingTimeFrame': '32',
                    'encourageText': 'Great start!',
                    'achieved': '15.07%'
                }]
            }
        }
    }

    //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('investorDashboardDetailsModel', investorDashboardDetailsModel);
        });
    });

    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            directiveElem = getCompiledElement();
        });

    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should be created with scope:true', function() {
        expect(directiveElem.scope()).toBeDefined();
    });

    it('should applied template', function() {
        expect(directiveElem.html()).not.toEqual('');
    });

    it('should be scope data rendered in template', function() {
        expect(angular.element(directiveElem.find('span')[0]).text()).toBe('SORRY!');
        expect(angular.element(directiveElem.find('span')[1]).text()).toBe('We are currently unable to retrieve your data.');
    });

    it('should populate success data', function() {
        scope.$broadcast('investorSmartSolutions');
        scope.$digest();
        expect(directiveElem.scope().smartSol.goals).toBeDefined();
        expect(directiveElem.scope().smartSol.goals[0].goalId).toBe('G1234');
        expect(directiveElem.find('i').length).toEqual(9);
        expect(angular.element(directiveElem.find('span')[0]).text()).toBe('GOAL');
        expect(angular.element(directiveElem.find('span')[4]).text()).toBe('GOAL AMOUNT');
        expect(directiveElem.find('button').length).toEqual(5);
    });

});
