var express = require('express');
var https = require('https');
var http = require('http');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var engagementModel = require('./engagement.model');
var getMessageModel = require('../getMessage/getMessage.model');
var dataPassModel = require('../dataPass/dataPass.model');
var myCache = require('../../../api-server');
var apiUtils = require('../../common/apiUtils');
var apiLPUtils = require('../../common/apiLPUtils');
var proxy = require('../../../config/proxy');
var request = require('request');
var CryptoJS = require("crypto-js");

/* Trigerring the Engagement API on request from Client */
// API Route
router.route('/mfchatnode/rest/engagement')
    .post(function(req, res) {
        logger.general.info(logger.formatInBoundReqMsg(req));

        req.body.RequestParams = req.body.RequestParams || {};       
        req.session.agentGroupID = req.body.RequestParams.agentGroupID;
        req.session.nickName = req.body.RequestParams.nickName;
        req.session.accRole = req.body.RequestParams.accRole;
        req.session.MDN = req.body.RequestParams.MDN;
        req.session.accountNum = req.body.RequestParams.accountNumber;
        req.session.osName = req.body.RequestParams.InitialParams.osName;
        req.session.deviceName = req.body.RequestParams.InitialParams.deviceName;
        req.session.engagementCompleteReq = req.body.RequestParams;
        if(req.session.channel){
            req.session.requestor = 'chatServer_AskVerizon';
        }else{
            req.session.requestor = 'chatServer_' + req.body.RequestParams.InitialParams.osName;
        }
        var ivString = new Uint8Array(new Buffer([34, 30, 50, 33, 31, 116, 111, -24, 81, -124, 43, -121, -84, 117, -54, 60]));      
        var ivBase64 = new Buffer(ivString, 'binary').toString('base64');        
        var key = config.AES_ENCRYPTION_KEY; 
        var decrypted = CryptoJS.AES.decrypt(req.body.RequestParams.encryptedMdn, CryptoJS.enc.Base64.parse(key), {
        'iv': CryptoJS.enc.Base64.parse(ivBase64),
         padding: CryptoJS.pad.Pkcs7,
         mode: CryptoJS.mode.CBC,
        });        
        logger.general.info(logger.formatInfoMsg(req.session.id, "MDN: "+ req.body.RequestParams.MDN + " Decrypted MDN: "  + decrypted.toString(CryptoJS.enc.Utf8)));      
        if(decrypted.toString(CryptoJS.enc.Utf8) !== req.body.RequestParams.MDN){
            logger.general.info(logger.formatInfoMsg(req.session.id, "invalid MDN"));            
        }
        var model =  req.body.RequestParams.InitialParams.model ? req.body.RequestParams.InitialParams.model.toUpperCase().replace(/ /g, ''): '';

        if(req.body.RequestParams.InitialParams && req.body.RequestParams.InitialParams.model.toUpperCase().indexOf("IPAD") > -1){
        req.session.model =  engagementModel.checkDevice("IPAD");
        }else{
            req.session.model =  engagementModel.checkDevice(model);
        }
        req.uri = engagementModel.createRequestUrl(req.body.RequestParams.agentGroupID, req.session.channel) + engagementModel.createLaunchType(req.body.RequestParams.agentGroupID, req.session.channel, req.session.model)
        req.session.businessRuleID = engagementModel.businessRuleID(req.body.RequestParams.agentGroupID, req.session.channel, req.session.model);
        

        if(req.session.isTMP){
           logger.formatConvsStrtMsg(req);
           apiLPUtils.engagementCall(req, res, function(chunk){
               req.session.location = chunk;
               req.session.engagementID = chunk.substring(chunk.lastIndexOf('/')+1, chunk.length);
               engagementModel.response.Page.status =  "accepted";
               engagementModel.response.Page.engagementID = req.session.engagementID;// storing engagementID into the session               
               engagementModel.ResponseInfo.topMessage = "It may take a few moments to connect";
               engagementModel.ResponseInfo.type = "ChatTop";
               engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
               engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
               logger.general.info(logger.formatInfoMsg(req.session.id, req.session.agentGroupID+ " LPChat started with engagementID "+ req.session.engagementID));                                  
               apiLPUtils.generateToken(req, res, function(tokenResponse) {
                   if(res.statusCode === 200){
                    engagementModel.response.Page.tryConnection = 5;
                    engagementModel.response.Page.waitTime = 2000;
                    engagementModel.response.Page.tryUDM = true;                          
                    tokenResponse = tokenResponse || {};
                    tokenResponse.data = tokenResponse.data || {primaryMS: '', secondaryMS: ''};
                    if (tokenResponse.data && tokenResponse.data.primaryMS) {
                        var primaryMS = {
                            port: tokenResponse.data.primaryMS.slice(-4),
                            url: tokenResponse.data.primaryMS.slice(0, -5)
                        };
                        engagementModel.response.Page.primaryMS = primaryMS;
                        logger.general.info(logger.formatInfoMsg(req.session.id, "UDM primaryMS " + JSON.stringify(engagementModel.response.Page.primaryMS))); 
                    } else {
                        engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                    }
                    if (tokenResponse.data && tokenResponse.data.secondaryMS) {
                        var secondaryMS = {
                            port: tokenResponse.data.secondaryMS.slice(-4),
                            url: tokenResponse.data.secondaryMS.slice(0, -5)
                        };
                        engagementModel.response.Page.secondaryMS = secondaryMS;
                        logger.general.info(logger.formatInfoMsg(req.session.id, "UDM secondaryMS " + JSON.stringify(engagementModel.response.Page.secondaryMS)));                               
                    } else {
                        engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                    }
                    engagementModel.response.Page.token = tokenResponse.data.token;
                    engagementModel.response.Page.deviceId = tokenResponse.data.deviceId;
                    engagementModel.response.Page.topic = tokenResponse.data.topic;
                    engagementModel.response.ModuleMap.Support.startMsgId = -1;                            
                    logger.general.info(logger.formatInBoundResMsg(req, engagementModel.response));
                    res.send(engagementModel.response);
                   }else{
                        engagementModel.response.Page.tryUDM = false;
                        res.send(engagementModel.response);
                   }
               }); 
               
           });
        }else{
            /* Trigerring the Engagement API internally to TC */
            var initialMessage ;
            if(req.body.RequestParams.InitialMessage ===  '' || null || undefined){
                initialMessage = encodeURI('Hello');
            }else{
                initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
            }
            //var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
            logger.formatConvsStrtMsg(req);
            var reqObj = {
                host: config.TC_SERVER_NAME,
                method: 'GET',
                path: req.uri + '&InitialMessage=' + initialMessage,
                agent: proxy.agent,
                ca:proxy.ca,
                headers: {
                    'Cookie': req.session.sessionCookie,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                rejectUnauthorized: true
            };

            logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
            var resbody = [];
            var proxyRequest = https.request(reqObj, function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {                
                    resbody.push(chunk);
                }).on('end', function(){
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, resbody, req.session.id));               
                    chunk = JSON.parse(resbody);
                    if (chunk.engagementID) {
                        engagementModel.response.Page.status = (chunk.status === "queued" ? "accepted" : chunk.status);
                        engagementModel.response.Page.engagementID = req.engagementID = req.session.engagementID = chunk.engagementID; /// storing engagementID into the session
                        engagementModel.response.Page.customerID = req.session.customerID = chunk.customerID; /// storing customerID into the session
                        engagementModel.ResponseInfo.topMessage = "It may take a few moments to connect";
                        engagementModel.ResponseInfo.type = "ChatTop";
                        engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                        engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                        //req.session.chatSendMsgCounter = (req.session.chatSendMsgCounter || 1);
                        myCache.set(req.session.engagementID+'.Datapass' , apiUtils.getUserInfo(req));
                        myCache.set(req.session.engagementID+'.VATranscript' , apiUtils.getVATranscript(req.body.RequestParams.VATranscript));
                        if(req.session && req.session.channel){
                            logger.general.info(logger.formatInfoMsg(req.session.id, "User Login Details ################## :::: User Device#" + req.session.model + " and channel#"+ req.session.channel));
                        }else{
                            logger.general.info(logger.formatInfoMsg(req.session.id, "User Login Details ################## :::: User Device#" + req.session.model + " and channel#Mobile_App"));  
                        } 
                        logger.general.info(logger.formatInfoMsg(req.session.id, req.session.agentGroupID + " chat started with engagementID "+ req.session.engagementID)); 
                        logger.conversation.info(logger.formatInfoMsg(req.session.id, " #EngagementStarted: " + " #EngagementId: "+ req.session.engagementID +" #AgentGroupId: " + req.session.agentGroupID));                              
                        apiUtils.generateToken(req, res, function(tokenResponse) { 
                            if(res.statusCode === 200){
                                engagementModel.response.Page.tryConnection = 5;
                                engagementModel.response.Page.waitTime = 2000;
                                engagementModel.response.Page.tryUDM = true;                            
                                tokenResponse = tokenResponse || {};
                                tokenResponse.data = tokenResponse.data || {primaryMS: '', secondaryMS: ''};
                                if (tokenResponse.data && tokenResponse.data.primaryMS) {
                                    var primaryMS = {
                                        port: tokenResponse.data.primaryMS.slice(-4),
                                        url: tokenResponse.data.primaryMS.slice(0, -5)
                                    };
                                    engagementModel.response.Page.primaryMS = primaryMS;
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "UDM primaryMS " + JSON.stringify(engagementModel.response.Page.primaryMS))); 
                                } else {
                                    engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                                }
                                if (tokenResponse.data && tokenResponse.data.secondaryMS) {
                                    var secondaryMS = {
                                        port: tokenResponse.data.secondaryMS.slice(-4),
                                        url: tokenResponse.data.secondaryMS.slice(0, -5)
                                    };
                                    engagementModel.response.Page.secondaryMS = secondaryMS;
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "UDM secondaryMS " + JSON.stringify(engagementModel.response.Page.secondaryMS)));                               
                                } else {
                                    engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                                }
                                engagementModel.response.Page.token = tokenResponse.data.token;
                                engagementModel.response.Page.deviceId = tokenResponse.data.deviceId;
                                engagementModel.response.Page.topic = tokenResponse.data.topic;
                                engagementModel.response.ModuleMap.Support.startMsgId = -1; 
                                engagementModel.response.ModuleMap.Support.msgList = [];                   
                                logger.general.info(logger.formatInBoundResMsg(req, engagementModel.response));
                                //console.log(engagementModel.response);
                                res.send(engagementModel.response);
                                
                                  }else{
                                    engagementModel.response.Page.tryUDM = false;
                                    res.send(engagementModel.response);
                                 }
                        });

                        
                                        
                        if (req.session.agentGroupID === 'WirelessSales') {
                            req.session.isSales = true; 
                            req.session.isEmp = false; 
                        }else if(req.session.agentGroupID.toUpperCase().indexOf("EMP") > -1) {
                            req.session.isSales = false;
                            req.session.isEmp = true;
                        }else {
                            req.session.isSales = false;
                            req.session.isEmp = false;
                        }
                    } else {
                    var errObj = {
                            message: proxyResponse.statusMessage,
                            statusCode: proxyResponse.statusCode
                        };
                        logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id)); 
                        logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                        res.send(errObj);                      
                    }
                });
                proxyResponse.on('error', function(err) {
                    logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                    res.send(err);
                });
            });

            proxyRequest.write(res.body + '');
            proxyRequest.end();
            }
        
    });

module.exports = router;


 // var encrypted = CryptoJS.AES.encrypt(req.body.RequestParams.MDN, CryptoJS.enc.Base64.parse(key), {
        // 'iv': CryptoJS.enc.Base64.parse(ivBase64),
        //  padding: CryptoJS.pad.Pkcs7,
        //  mode: CryptoJS.mode.CBC,
        // });
        // console.log("MDN: " + encrypted);
        
// model =  engagementModel.checkDevice(model);
        // req.uri = engagementModel.createRequestUrl(req.body.RequestParams.agentGroupID) + engagementModel.createLaunchType(req.body.RequestParams.agentGroupID, req.session.channel, model)
        // req.session.businessRuleID = engagementModel.businessRuleID(req.body.RequestParams.agentGroupID, req.session.channel, model);

// if(req.body.RequestParams.InitialParams && req.body.RequestParams.InitialParams.model.toUpperCase().indexOf("IPAD") > -1){
        //     req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID] + engagementModel.createLaunchType[];
        //     req.session.businessRuleID = engagementModel.businessRuleID[req.body.RequestParams.agentGroupID+'_IPad'];
        // }else{
        //     req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID] + engagementModel.createLaunchType[req.body.RequestParams.agentGroupID];
        //     req.session.businessRuleID = engagementModel.businessRuleID[req.body.RequestParams.agentGroupID];
        // }

