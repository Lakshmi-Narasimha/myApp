// getFolioView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FolioViewSchema = new mongoose.Schema({
    folioViewObject: {
        type: Array,
        "default": []
    }
});

var FolioViewLookUp = mongoose.model('FolioViewLookup', FolioViewSchema);

var FolioViewModel = new FolioViewLookUp({

    "folioViewObject": [{
        "unitHolderDetails" : {
          "invname" : "Shankar",
          "address" : {
            "line1":"B-34 Acrot Street No 161 Yerapalli street",
            "line2":"Vadapallani",
            "line3":"Chennai 763001"
          },
          "firstholder" : {
            "name" : "Shankar",
            "pan" : "XXXXXX9L",
            "kyc" : "KYC registered"
          },
          "secondholder" : {
            "name" : "Meenakshi",
            "pan" : "XXXXXX8P",
            "kyc" : "KYC registered"
          },
          "status" : "Individual",
          "modeofoperation" : "Anyone or survivor"
        },
        "aumSplitDetails" : {
          "chartData":{
            "equity" : "5.47L",
            "fixedincome" : "5.25L",
            "balanced" : "4.1L",
            "elss" : "3.6L",
            "fof" : "0.6L",
            "feeder" : "0.6L",
            "liquid" : "0.2L"          
          },
          "totalAUM" : "13,801.98" 
        },
        "folioDetails" : {
          "folioNumber" : "326383",
          "gridData" :{
            "rows" : [
              {
                "accno" : "1111",
                "fund" : "Franklin India Prima Plus",
                "totalunits" : "182",
                "currentcost" : "112.9",
                "invesAmt": "112",
                "diviReinvest": "112",
                "currentvalue" : "123.9",
                "returns" : "10%"
              },
              {
                "accno" : "2222",
                "fund" : "Franklin India Prima Plus",
                "totalunits" : "182",
                "currentcost" : "112.9",
                "invesAmt": "113",
                "diviReinvest": "113",
                "currentvalue" : "123.9",
                "returns" : "10%"
              },
              {
                "accno" : "3333",
                "fund" : "Franklin India Prima Plus",
                "totalunits" : "182",
                "currentcost" : "112.9",
                "invesAmt": "114",
                "diviReinvest": "114",
                "currentvalue" : "123.9",
                "returns" : "10%"
              }
            ],  
            "footer" : {
              "grandTotal" : "276",
              "currentCost" : "16,789",
              "currentValue" : "1073.78" 
            }  
          }                   
        }  
    }]

});

FolioViewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FolioViewLookUp table, please contact admin...');
    } else {
        FolioViewLookUp.remove({}, function(err) {
            console.log('FolioViewLookUp collection removed');
            FolioViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FolioViewLookUp table, please contact admin...');
                }
                console.log('FolioViewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FolioViewLookUp;
