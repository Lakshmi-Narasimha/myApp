/**
 * @ngdoc property
 * @name Login
 * @requires $scope
 * @requires $state
 * @requires $localStorage
 * @description
 *
 * - Call the authorization service after validating the credentials
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function loginCtrl($scope, authenticationService, $state, $localStorage, toaster, $cacheFactory, constants, Idle, popupSrvc, $cookies, events, appConfig, $window, configUrlModel) {
    $scope.logClick = false;
    $scope.test = false;
    $scope.showPopup = false;
    $scope.loginInputChanged = function() {
        $scope.email = $scope.userNameInputObject.value;
        $scope.password = $scope.pwdInputObject.value;
    };
    $scope.login = function() {
     if(window.location.host.indexOf("accounts.franklintempletonindia.com") === -1){
        $scope.logClick = true;
        $scope.test = true;
        var error = false;
        if (!$scope.email) {
            $scope.email_err = 'Username field is empty, Please try again.';
            error = true;
        }

        if (!$scope.password) {
            $scope.password_err = 'Password field is empty, Please try again.';
            error = true;
        }

        if (error) {
            $scope.logClick = false;
            return;
        }
        var user = $scope.email,
            password = $scope.password;
        authenticationService.removeUserCookies();
        var promise = authenticationService.authenticate(user, password);

        promise.then(function(data) {
            if (data.data.guId) {
                $scope.logClick = false;
                $('.close-dropdown').removeClass('open');
                $cookies.put('accessToken', data.data.accessToken, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('guId', data.data.guId, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('userType', data.data.userType, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('userRedirectURI', data.data.userRedirectURI, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('userId', user, { 'domain': appConfig.DOMAIN_CONFIG });
                $cookies.put('usersysId', data.data.usersysId, { 'domain': appConfig.DOMAIN_CONFIG });
                var userInformation = {};
                userInformation = data.data;
                userInformation.userId = $cookies.get('userId');
                authenticationService.setUser(userInformation);
                authenticationService.backButton = true;
                if(data.data.accessToken){
                    authenticationService.checkUserFeedback().then(function(userStatus) {
                    $cookies.put('userFeedbackStatus', userStatus.status, { 'domain': appConfig.DOMAIN_CONFIG });
                        if (authenticationService.getAppName() === 'guest') {
                            events.loginSuccess($scope);
                            toaster.success(constants.LOGIN_SUCCESS);
                            window.name = "loggedIn";
                            $cookies.put("windowName",window.name,{ 'domain': appConfig.DOMAIN_CONFIG });
                            location.href = data.data.userRedirectURI;
                        } else {
                            authenticationService.innerClick = true;
                            $state.go('dashboard', {}, { reload: true });
                        }
                    }, function() {

                        if (authenticationService.getAppName() === 'guest') {
                            events.loginSuccess($scope);
                            toaster.success(constants.LOGIN_SUCCESS);
                            window.name = "loggedIn";
                            $cookies.put("windowName",window.name,{ 'domain': appConfig.DOMAIN_CONFIG });
                            location.href = data.data.userRedirectURI;
                        } else {
                            authenticationService.innerClick = true;
                            $state.go('dashboard', {}, { reload: true });
                        }
                        //$cookies.put("userFeedbackStatus", 'false', {'domain': appConfig.DOMAIN_CONFIG});
                    });                    
                }else{
                    location.href = data.data.userRedirectURI;
                } 
                
            } else {
                $scope.logClick = false;
                events.loginSuccess($scope);
                $('.close-dropdown').removeClass('open');
                authenticationService.innerClick = true;
                $state.go('dashboard', {}, { reload: true });
                toaster.error(constants.LOGIN_FAILURE);
            }
        }, function(data) {
            $('.close-dropdown').removeClass('open');
            $scope.logClick = false;
            if (data.status === 400) {
                toaster.error(data.data[0].errorDescription);
                // $scope.idleStart();
            }
            // toaster.error(constants.AUTHENTICATION_FAILED);
        });
        }else{
           alert("Login is not for scope of internal launch, please visit to our current site.");
       }
    };

    $scope.registerNow = function() {
        var configURL = configUrlModel.getEnvUrl('GUEST_URL');
        window.location.href = appConfig[configURL] + '/#/loginmaster/register';
        $('.close-dropdown').removeClass('open');
    };

    $scope.forgotUser = function() {
        var configURL = configUrlModel.getEnvUrl('GUEST_URL');
        window.location.href = appConfig[configURL] + '/#/loginmaster/forgotusername/distributor';
        $('.close-dropdown').removeClass('open');
    };

    $scope.forgotPwd = function() {
        var configURL = configUrlModel.getEnvUrl('GUEST_URL');
        window.location.href = appConfig[configURL] + '/#/loginmaster/forgotpassword/distributor';
        $('.close-dropdown').removeClass('open');
    };

    $('.dropdown-menu.fti-loginForm').on('click', function(event) {
        event.stopPropagation();
    });

    $scope.checkUserFeedbackStatus = function() {
        $scope.yesText = 'Submit Feedback';
        $scope.yesEventName = 'feedbackSubmit';
        $scope.popupText = 'We would like to hear from you, kindly provide your feedback';
        // $scope.extraBtn = "Submit Feedback";
        // $scope.extraEventName = "feedbackSubmit";
        $scope.noText = 'Continue to Logout';
        $scope.noEventName = 'logoutUser';
        if ($cookies.get('userFeedbackStatus') === 'false') {
            $scope.showPopup = true;
        } else {
            $scope.logout();
        }

    };
    $scope.hide = false;
    $scope.loginClicked =function(){
        if($window.location.host.indexOf("accounts.franklintempletonindia.com") !== -1){
        $scope.hide = true; 
        $scope.applyopenclass = false;
        alert("Login is not for scope of internal launch, please visit to our current site.");
        }
    }
    $scope.$on('logoutUser', function() {
        $scope.logout();
    });

    $scope.$on('feedbackSubmit', function() {
        $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/feedback?logout';
    });
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
loginCtrl.$inject = ['$scope', 'authenticationService', '$state', '$localStorage', 'toaster', '$cacheFactory', 'constants', 'Idle', 'popupSrvc', '$cookies', 'events', 'appConfig', '$window', 'configUrlModel'];
module.exports = loginCtrl;
