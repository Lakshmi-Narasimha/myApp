import { Agent } from '../_models/index';
import { Intent } from '../_models/index';

import { Observable } from 'rxjs/Observable';

export class AIAssistCache {

    private agentsList : Array<Agent> = [];
    private activeAgent : Agent;
    private activeIntent : Intent;

    public get AgentsList() {
        return this.agentsList;
    }

    public set AgentsList(lstAgents : Array<Agent>) {
        this.agentsList = lstAgents;
    }

    public getActiveAgent() {
        return this.activeAgent;
    }

    public setActiveAgent(pAgent : Agent) {
        this.activeAgent = pAgent;
    }

    public getActiveIntent() {
        return this.activeIntent;
    }

    public setActiveIntent(pIntent: Intent) {
        this.activeIntent = pIntent;
    }

}
