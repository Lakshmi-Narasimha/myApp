"use strict";
var collapse_directive_1 = require('./collapse.directive');
exports.CollapseDirective = collapse_directive_1.CollapseDirective;
var collapse_module_1 = require('./collapse.module');
exports.CollapseModule = collapse_module_1.CollapseModule;
