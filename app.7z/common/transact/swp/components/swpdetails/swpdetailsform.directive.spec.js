'use strict';
describe('Directive: fticSwpDetailsForm', function() {
	var compile,scope,directiveElement,isolatedScope,ifscModel,reviewSwpDetailsModel,RegisteredBankInitLoader,RegisteredBankModel,frequencyOptionsModel,$window,$filter,TransactConstant,fundDetailsModel,$stateParams,$timeout,transactEventConstants,transactModel,$state,httpBackend,authenticationService,toaster;
	
	var validateSWPResponse = {"webRefNo":"SWD000893",
		"transactionValidated":"true",
		"folioId":"13884342",
		"accountNo":"0380000217154"};

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': '520965.095916'
        }]
    };

   	var paymentBankByFolioResponse = {
		"paymentBank": [
			{
				"toDate": "",
				"status": "",
				"regDate": "",
				"pbPersonalAccountNumber": "7335300411",
				"pbMakerId": "",
				"pbBankName": "CITI BANK",
				"pbAccountType": "SA",
				"payoutFlag": "N",
				"paymentType": "L",
				"ifscCode": "CITI0100000",
				"fromDate": "",
				"defaultFlag": "Y",
				"amountType": "",
				"amount": "",
				"achRefNo": "",
				"accTypeDesc": "Savings Account"
			},
			{
				"toDate": "",
				"status": "",
				"regDate": "",
				"pbPersonalAccountNumber": "7335300411",
				"pbMakerId": "",
				"pbBankName": "CITI BANK",
				"pbAccountType": "SA",
				"payoutFlag": "N",
				"paymentType": "T",
				"ifscCode": "CITI0100000",
				"fromDate": "",
				"defaultFlag": "Y",
				"amountType": "",
				"amount": "",
				"achRefNo": "",
				"accTypeDesc": "Savings Account"
			},
			{
				"toDate": "",
				"status": "",
				"regDate": "",
				"pbPersonalAccountNumber": "7335300411",
				"pbMakerId": "",
				"pbBankName": "CITI BANK",
				"pbAccountType": "SA",
				"payoutFlag": "N",
				"paymentType": "W",
				"ifscCode": "CITI0100000",
				"fromDate": "",
				"defaultFlag": "Y",
				"amountType": "",
				"amount": "",
				"achRefNo": "",
				"accTypeDesc": "Savings Account"
			}
		]
	};


	var ifscResponse = { "ifscCode":"HDFC0000835",
		"bankName":"HDFC BANK LTD",
		"branchName":"BANDRA EAST - KALANAGAR",
		"city":"022-61606161"
	};

	var advisor = false;

	beforeEach(angular.mock.module('advisor'));	
   
	var getCompiledElement = function(){
		var element = angular.element('<ftic-swp-details-form></ftic-swp-details-form>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope,_$compile_,$window,_$filter_,_toaster_,_authenticationService_,_TransactConstant_,_fundDetailsModel_,_$stateParams_,_$timeout_,_transactEventConstants_,_transactModel_,_$state_,$httpBackend,_RegisteredBankInitLoader_,_RegisteredBankModel_,_frequencyOptionsModel_,_ifscModel_,_reviewSwpDetailsModel_) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};

            $timeout = _$timeout_;
            $state = _$state_;
            $stateParams = _$stateParams_;
            $filter = _$filter_;
            authenticationService = _authenticationService_;
            TransactConstant = _TransactConstant_;
            transactEventConstants = _transactEventConstants_;
            transactModel = _transactModel_;            
            fundDetailsModel = _fundDetailsModel_;
            toaster = _toaster_;

            RegisteredBankInitLoader = _RegisteredBankInitLoader_;
            RegisteredBankModel = _RegisteredBankModel_;
            frequencyOptionsModel = _frequencyOptionsModel_;
            ifscModel = _ifscModel_;
            reviewSwpDetailsModel = _reviewSwpDetailsModel_;

            RegisteredBankModel.setRegisteredBank(paymentBankByFolioResponse);
            fundDetailsModel.setFundDetails(fundDetailsResponse);            
            transactModel.setFundDetails(selectedFundObject);
            transactModel.setInvestorDetails(investorDetails);
            httpBackend = $httpBackend;

            if(advisor){
            	authenticationService.setUser({                                        
        			"userId" : "test123"        
        		});	
            }

            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();            
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variables on load of directive',function(){
    	expect(isolatedScope.ifscTextField).toBe("ifscTextField");
    	expect(isolatedScope.continueBtn).toBe(true);
    	expect(isolatedScope.fundEditClick).toBe(false);
    	expect(isolatedScope.disableCapital).toBe(false);
    	expect(isolatedScope.disableAmount).toBe(false);
    	expect(isolatedScope.$input).toBeDefined();
    	expect(isolatedScope.fieldNames.label1).toBe($filter('translate')(TransactConstant.swp.SWP_START_DATE));
    	expect(isolatedScope.fieldNames.label2).toBe($filter('translate')(TransactConstant.swp.SWP_END_DATE));
    	expect(isolatedScope.selections).toBeDefined();
    	expect(isolatedScope.config.showNotification).toBe(false);
    	expect(isolatedScope.inputObject.text).toBe(TransactConstant.stp.FIXED_AMOUNT);
    	expect(isolatedScope.inputObject.value).toBe("");
    	expect(isolatedScope.inputObject.type).toBe("number");
    	expect(isolatedScope.selections.selectedMode).toBe('cheque');
    	expect(isolatedScope.minSwpAmt).toBe('1000');
    	expect(isolatedScope.ifsc_search).toBe(false);
    	expect(isolatedScope.freqOptions).toEqual([{
			title: "Monthly"
			},{
		    title: "Yearly"
		}]);
    });

    it('should listen the event transactEventConstants.transact.SWP_FORM_RESET when triggered',function(){
    	isolatedScope.$broadcast(transactEventConstants.transact.SWP_FORM_RESET);
    	expect(isolatedScope.isEditing).toBe(false);
    	expect(isolatedScope.inputObject.value).toBe(null);
    	expect(isolatedScope.selections.selectedType).toBe("");
    	expect(isolatedScope.selections.noofInstallments).toBe(0);
    	expect(isolatedScope.selections.selectedMode).toBe('cheque');              
    	expect(isolatedScope.continueBtn).toBe(true);
    });

    it('should listen the event Call_Registered_banks when triggered',function(){
    	spyOn(RegisteredBankInitLoader,"loadAllServices");
    	isolatedScope.$broadcast("Call_Registered_banks");
    	expect(RegisteredBankInitLoader.loadAllServices).toHaveBeenCalledWith(isolatedScope);
    });

    it('should listen the event transactEventConstants.transact.REGISTERED_BANK when triggered',function(){
    	isolatedScope.$broadcast(transactEventConstants.transact.REGISTERED_BANK);
    	expect(isolatedScope.selections.bankDetails).toBe("CITI BANK - 7335300411");
    	expect(RegisteredBankModel.getDefaultBankDetails()).toEqual(paymentBankByFolioResponse.paymentBank[2]);
    });
	
    it('should listen the event ifscSrchRes when triggered',function(){
    	isolatedScope.$broadcast("ifscSrchRes",{
    		"bankDetails" : ifscResponse.branchName,
    		"bnkAdd" : ifscResponse.city,
    		"ifscCode" : ifscResponse.ifscCode
    	});

    	expect(isolatedScope.brnch).toBe(ifscResponse.branchName);
    	expect(isolatedScope.city).toBe(ifscResponse.city);
    	expect(isolatedScope._ifscCode).toBe(ifscResponse.ifscCode);
    	expect(isolatedScope.selections.city).toBe(ifscResponse.city);
    	expect(isolatedScope.selections.brnch).toBe(ifscResponse.branchName);
    	expect(isolatedScope.selections._ifscCode).toBe(ifscResponse.ifscCode);
    });

    it('should call the function inputChanged when any of the radio buttons either SWP Amount or Mode of payment changes(if radio button selected is fixed)',function(){
    	isolatedScope.inputChanged("fixed");
    	expect(isolatedScope.inputObject.disable).toBe(false);
    	expect(isolatedScope.inputObject.isRequired).toBe(true);
    	expect(frequencyOptionsModel.getAmountFormType().amountType).toBe("FIXEDAMOUNT");
    });

    it('should call the function inputChanged when any of the radio buttons either SWP Amount or Mode of payment changes(if radio button selected is capital appreciation)',function(){
    	isolatedScope.inputChanged("capital");
    	expect(isolatedScope.inputObject.disable).toBe(true);
    	expect(isolatedScope.inputObject.value).toBe("");
    	expect(isolatedScope.inputObject.isRequired).toBe(false);
    	expect(frequencyOptionsModel.getAmountFormType().amountType).toBe("CAPITAL");
    });

	it('should call the function inputChanged when any of the radio buttons either SWP Amount or Mode of payment changes(if radio button selected is Direct Credit and should show the empty ifsc form)',function(){
    	isolatedScope.inputChanged("direct-credit");
 		expect(isolatedScope.ifsc_search).toBe(true); 
    });

	it('should call the function inputChanged when any of the radio buttons either SWP Amount or Mode of payment changes(if radio button selected is Direct Credit and should show the preselected ifsc branch details)',function(){
    	transactModel.SWP_MAIN_FLAG = true;
    	ifscModel.setIfscGridResDet({
    		"bankDetails" : ifscResponse.branchName,
    		"bnkAdd" : ifscResponse.city,
    		"ifscCode" : ifscResponse.ifscCode
    	});
    	isolatedScope.inputChanged("direct-credit");
 		expect(isolatedScope.ifsc_search).toBe(true); 
 		expect(isolatedScope.brnch).toBe(ifscResponse.branchName);
    	expect(isolatedScope.city).toBe(ifscResponse.city);
    	expect(isolatedScope._ifscCode).toBe(ifscResponse.ifscCode);
    	expect(isolatedScope.selections.city).toBe(ifscResponse.city);
    	expect(isolatedScope.selections.brnch).toBe(ifscResponse.branchName);
    	expect(isolatedScope.selections._ifscCode).toBe(ifscResponse.ifscCode);
    });

    it('should call the function inputChanged when any of the radio buttons either SWP Amount or Mode of payment changes(if radio button selected is cheque)',function(){
    	isolatedScope.inputChanged("cheque");
 		expect(isolatedScope.ifsc_search).toBe(false); 
 		expect(isolatedScope.brnch).toBe(null);
    	expect(isolatedScope.city).toBe(null);
    	expect(isolatedScope._ifscCode).toBe(null);
    	expect(isolatedScope.selections.city).toBe(null);
    	expect(isolatedScope.selections.brnch).toBe(null);
    	expect(isolatedScope.selections._ifscCode).toBe(null);
    });

    describe("should call the function getSelections on click of continue button",function(){
    	beforeEach(function(){
    		isolatedScope.inputObject.value = 2000;
    		isolatedScope.selections = {
	    		selectedMode: 'cheque', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'fixed' 
			};
    	});
    
		it('should call the function formSubmission if all the validations are success(if user selects radio buttons fixed,cheque)',function(){
			spyOn(isolatedScope,"formSubmission");
			isolatedScope.getSelections();
			expect(isolatedScope.formSubmission).toHaveBeenCalledWith({
	    		selectedMode: 'cheque', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'fixed',
				swpAmtValue: 2000  
			}); 		   	
		});

		it('should call the function formSubmission if all the validations are success(if user selects radio buttons capital appreciation,cheque)',function(){
			isolatedScope.selections.selectedType = "capital";			
			spyOn(isolatedScope,"formSubmission");
			isolatedScope.getSelections();
			expect(isolatedScope.formSubmission).toHaveBeenCalledWith({
	    		selectedMode: 'cheque', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'capital',
				swpAmtValue: 'Capital Appreciation'  
			});						
		});	

		it('should show the error if api fails',function(){
			spyOn(toaster,"error");
			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			httpBackend.expectPOST("http://localhost:3030/transact/validateSwp?guId=878").respond(400,failureResponse);
			isolatedScope.$digest();						 			
			httpBackend.flush();
			expect(toaster.error).toHaveBeenCalledWith(failureResponse[0].errorDescription);			
		});

		it('should validate the swp detials if api returns success and navigate to investor review page',function(){
			spyOn($state,"go");
			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			httpBackend.expectPOST("http://localhost:3030/transact/validateSwp?guId=878").respond(200,validateSWPResponse);
			isolatedScope.$digest();						 
			expect(reviewSwpDetailsModel.getReviewSwpObj()).toEqual(isolatedScope.selections);
			expect(transactModel.getTransactDetails().investorDetails).toEqual(investorDetails);
			expect(transactModel.getTransactDetails().fundDetails).toEqual(selectedFundObject);
			expect(transactModel.getTransactDetails().swpDetails).toEqual({
	    		selectedMode: 'cheque', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'fixed',
				swpAmtValue: 2000  

			});
			httpBackend.flush();
			expect($state.go).toHaveBeenCalledWith("invTransact.review.swp");
			expect(transactModel.getWebRefNo()).toBe(validateSWPResponse.webRefNo);
			advisor = true; 
		});
	
		it('should validate the swp detials if api returns success and navigate to advisor review page',function(){
			spyOn($state,"go");
			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			httpBackend.expectPOST("http://localhost:3030/transact/validateSwp").respond(200,validateSWPResponse);
			isolatedScope.$digest();						 			
			httpBackend.flush();
			expect($state.go).toHaveBeenCalledWith("transact.review.swp");
			expect(transactModel.getWebRefNo()).toBe(validateSWPResponse.webRefNo);
		});

		it('should not show the confirmation popup if user clicks on edit and then after clicks on continue(if user does not edits the form)',function(){
			$stateParams.key = "SWP";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"swpDetails" : isolatedScope.selections
			});	
			
			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			expect(isolatedScope.config.showNotification).toBe(false);
		});

		it('should show the confirmation popup if user clicks on edit and then after clicks on continue(if user edits the form)',function(){
			$stateParams.key = "SWP";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"swpDetails" : isolatedScope.selections
			});	

			isolatedScope.selections = {
	    		selectedMode: 'cheque', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'capital',
				swpAmtValue: 'Capital Appreciation'  
			};

			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			expect(isolatedScope.config.showNotification).toBe(true);
		});

		it('should listen the event yes when user clicks on yes button in confirmation popup',function(){
			$stateParams.key = "SWP";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"swpDetails" : isolatedScope.selections
			});	

			ifscModel.setIfscGridResDet({
	    		"bankDetails" : ifscResponse.branchName,
	    		"bnkAdd" : ifscResponse.city,
	    		"ifscCode" : ifscResponse.ifscCode
    		});

			isolatedScope.selections = {
	    		selectedMode: 'direct-credit', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'capital',
				swpAmtValue: 'Capital Appreciation',
				city : ifscResponse.city,
                brnch : ifscResponse.branchName,
                _ifscCode : ifscResponse.ifscCode
			};		
			
			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			isolatedScope.$broadcast('yes');
			expect(isolatedScope.config.showNotification).toBe(false);
			expect(transactModel.getTransactDetails().swpDetails.swpAmtValue).toBe('Capital Appreciation');
		});

		it('should listen the event no when user clicks on no button in confirmation popup',function(){
			$stateParams.key = "SWP";
			transactModel.setTransactDetails({
				"investorDetails" : investorDetails,
				"fundDetails" : selectedFundObject,
				"swpDetails" : isolatedScope.selections
			});	

			ifscModel.setIfscGridResDet({
	    		"bankDetails" : ifscResponse.branchName,
	    		"bnkAdd" : ifscResponse.city,
	    		"ifscCode" : ifscResponse.ifscCode
    		});
			
			isolatedScope.selections = {
	    		selectedMode: 'cheque', 
				startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
				noofInstallments: 6, 
				selectedType: 'capital',
				swpAmtValue: 'Capital Appreciation'  
			};

			isolatedScope.swpForm.$valid = true;
			isolatedScope.getSelections();
			isolatedScope.$broadcast('no');
			expect(isolatedScope.config.showNotification).toBe(false);
			expect(reviewSwpDetailsModel.getReviewSwpObj().selectedType).toBe('fixed');			
		});
    });
	
	it('should call editSWP if data is available in the reviewSwpDetailsModel',function(){		
		$stateParams.key = "INVESTORSWP";
		transactModel.SWP_MAIN_FLAG = true;
		ifscModel.setIfscGridResDet({
    		"bankDetails" : ifscResponse.branchName,
    		"bnkAdd" : ifscResponse.city,
    		"ifscCode" : ifscResponse.ifscCode
    	});
		reviewSwpDetailsModel.setReviewSwpObj({
    		selectedMode: 'cheque', 
			startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
			endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
			noofInstallments: 6, 
			selectedType: 'capital',
			bankDetails: 'CITI BANK - 7335300411',
			amountType: 'capital',
			swpAmtValue: 'Capital Appreciation'  
		});
		
		
		directiveElement = getCompiledElement();            
        isolatedScope = directiveElement.isolateScope();            

		expect(isolatedScope.selections.selectedType).toBe('capital');
		expect(isolatedScope.disableAmount).toBe(true);
		expect(isolatedScope.inputObject.disable).toBe(true);
		expect(isolatedScope.selections.selectedMode).toBe('cheque');
		expect(isolatedScope.selections.bankDetails).toBe("CITI BANK - 7335300411");
		expect(isolatedScope.brnch).toBe(null);
    	expect(isolatedScope.city).toBe(null);
    	expect(isolatedScope._ifscCode).toBe(null);
    	expect(isolatedScope.selections.city).toBe(null);
    	expect(isolatedScope.selections.brnch).toBe(null);
    	expect(isolatedScope.selections._ifscCode).toBe(null);
	});	
});



