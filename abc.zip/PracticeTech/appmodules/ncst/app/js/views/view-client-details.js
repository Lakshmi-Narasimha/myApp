

define(
		[ 'text!appmodules/ncst/app/templates/clientDetails.html',
				'appmodules/ncst/app/js/lib/validate-4.2', 'config',
				'appmodules/ncst/app/js/utils','appmodules/ncst/app/js/models/model-address-entry' ,'appmodules/ncst/app/js/models/model-client-details','appmodules/ncst/app/js/models/model-client','appmodules/ncst/app/data/country-list','jquery',  'appcommon/analytics','services/dataservice'],
		function(Template, Validator, Config, Utils,AddressModel,ClientDetailsModel,ClientModel,DropdownOptions,$, Analytics,DataService ) {
			var ClientInfoModel = ClientModel.get('clientInfo'), _self = null;
			var API_COMMON_DATA_BODY = Utils
					.getConfigProperty('API_COMMON_DATA_BODY'), BASE_URL = Config.odataServiceName;
			var noClientsAssociatedErrMsg = "There are no clients associated to this advisor number.";
			var clientDetailsView = Backbone.View
					.extend({
                        el: '#ncst-app',
                        template: _.template(Template),
                        initialize: function() {
                        	_self = this;
							this.$main = this.$('#client-info');
						},
						events : {
							'click #step4-next-button,#m-step4-next-button' : 'navigateToStep5',
							'click #back-to-step3,#m-back-to-step3' : 'navigateToStep3',
							'focusout .bday' : 'saveBday',
							'keypress #cd-bday-3' : 'saveBday',
							'keypress #cd-no-dependants,.number-validate': 'numValidator',
							'keypress .countrycode-validate': 'countryCodeValidator',
							'keypress #cd-bday-1,#cd-bday-2,#cd-bday-3' : 'bdayValidator',
							'keyup #cd-bday-1,#cd-bday-2,.movetonext': 'movetonxtField',
							//'keypress #cd-homephone-1,#cd-homephone-2,#cd-homephone-3' : 'homephValidator',
							//'keypress #cd-workphone-1,#cd-workphone-2,#cd-workphone-3,#cd-workphone-4' : 'workphValidator',
							'keyup #cd-driver-license' : 'showStates',
							'change input[name="cd-primary-email"]': 'validatePrimarymail',
							'click .cd-inter-checkbox': 'internationalNumberCheck',
							'click .cd-pref-checkbox': 'preferredNumberCheck',
							'focus #cd-assoc-name':'showSearchOption',
							//'blur #cd-assoc-name-search':'hideSearchOption',
							'click #cd-assoc-name-clear-search':'clearClientSearch',
							'click #cd-assoc-id-clear-search':'clearClientIdSearch',
							'click #cd-assoc-name-clear':'clearAssociatedClient',
							"click .sad-text.sad-step4":"handleSAD"
						},
					handleSAD:function(){
						Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
						this.model.setModel();
						Utils.lockForm();
						ClientModel.createDraft().done(function(response){
							Utils.unlockForm();
							ClientModel.showDraftSaveSuccesMessage(response);
						}).fail(function(error){
							Utils.unlockForm();
							Utils.showDraftSaveErrorMessage();
							console.log(error,"error");
						});
					},
						clearClientSearch:function(){
							$('.typeahead.dropdown-menu').hide();
							$('#cd-assoc-name-search').val('');
						},
						clearClientIdSearch:function(){
							$('#cd-assoc-id-search').val('');
						},
						clearAssociatedClient:function(){
							var _$slectedClnt = $('#cd-assoc-name');
							_$slectedClnt.data('value','');
							_$slectedClnt.val('');
						},
						showSearchOption:function(){
							$('#ncst-user-home-view .icon-info').popover('hide');
							$('body').addClass("ncst-custom-modal-bg");
							$('#ncst-no-record-found').hide();
							$('#ncst-client-serach-ctnr').css('height','110px');
							var _$typeheadInput = $('#cd-assoc-name-search');
							$('.client-id-search-fields-r').addClass("hidden");
							$('#afi-nav-modal').modal('show');
							_$typeheadInput.val("");
							_$typeheadInput.data("value","");
							$('.client-id-search-fields').removeClass("hidden");
							$('#client-id-search-button,#cd-assoc-id-search,#cd-assoc-id-clear-search').addClass("hidden");
							$('.search-option-link').removeClass("active");
							$('#client-name-search').addClass("active");
							_$typeheadInput.focus();
						},
						clearTypehead:function(){
							
						},
						clearView : function() {
							this.undelegateEvents();// Unbind all local event
							// bindings
							this.model.unbind('change', this.render, this); // Unbind
							// reference
							// to
							// the
							// model
						},
						navigateToStep3 : function() {
							if ($('.ncst-step.step3').hasClass('finished')) {
								$('.ncst-step.step3').find('.step-nav-links')
										.click();
							} else {
								$('.ncst-step.step2').find('.step-nav-links')
										.click();
							}
						},
                        navigateToStep5: function() {
                            this.hideServiceErrors();
                            var _normalvalidation = this.model.validate(),_specvaldtn = this.validateMinimumPhone();
                            if(_normalvalidation && _specvaldtn){
								// var Route = '';
								if (ClientInfoModel.get('clientType') == 'P')
									// Route = 'employment';
									$('.ncst-step.step5').find(
											'.step-nav-links').click();
								else
									$('.ncst-step.step6').find(
											'.step-nav-links').click();
							}
                            this.sendEventsToAnalytics();
						},
						sendEventsToAnalytics : function(correctClientAddressChecked) {
							Analytics.analytics.recordSharedSuiteAction('ncstClientDetailsHasAssociatedClient:' + ClientDetailsModel.get('assClOption'));
							Analytics.analytics.recordSharedSuiteAction('ncstClientDetailsClientPrimaryEmailOption:' + ClientDetailsModel.get('clientprimaryEmailRadio'));
						},
                        modelSaver: function() {
                            this.hideServiceErrors();
                            var _normalvaldtn = this.model.validate(),_specValdtn = this.validateMinimumPhone();
							return _normalvaldtn && _specValdtn;
						},
						validateMinimumPhone : function(throwError){
							var phoneSections = $(".ph-num-section");
							var atLeastOnePhone = false;
							var missingPreffredPhoneSection = false,_errorList={},_isInvalid = false;
							if(phoneSections && phoneSections.length>0){
								$.each(phoneSections,function(key,section){
									var inputBoxes = $(section).find("input[type=text]:visible");
									if(Utils.isMobile()){
									 inputBoxes = $(section).find("input[type=tel]:visible");
									}
									var prefferedBox = $(section).find("input[name=preferred-num]");
									if(inputBoxes && inputBoxes.length>0){
										var fullPhoneNum = "";
										var isIntnsnl = false,_isBusiness = false;
										$.each(inputBoxes,function(index,phoneBox){
											
											var _$phoneBox = $(phoneBox);
											if(_$phoneBox.prop("id").match(/-int-/g)){
												isIntnsnl = true;
											}
											if(_$phoneBox.prop("id").match(/business/g)){
												_isBusiness = true;
											}
											if(isIntnsnl && $(inputBoxes[0]).val().length>=1 && $(inputBoxes[1]).val().length>3){
												//exclude extns from validation
												if(index != 2){
													fullPhoneNum += _$phoneBox.val();
												}
											}else if(!isIntnsnl){
												//exclude extns from validation
												if(index != 3){
													fullPhoneNum += _$phoneBox.val();
												}
											}
										});
										var _$input0 = $(inputBoxes[0]),_$input1 = $(inputBoxes[1]),_$input2 = $(inputBoxes[2]);
										//capture error for international number
										if(isIntnsnl ){
											var _input0Val = _$input0.val();
											if(_input0Val.indexOf('+') != -1){
												if(_input0Val.length == 1 ){
													_errorList[inputBoxes[0].id] = {};
													_errorList[inputBoxes[0].id]['errMsg'] = "Invalid phone number.";
													_errorList[inputBoxes[0].id]['section'] = section;
													_isInvalid = true;
												}
												_input0Val = _input0Val.substr(1,_input0Val.length);
											}else if(_input0Val.length == 0 && _$input1.val().length >0 ){
												_errorList[inputBoxes[0].id] = {};
												_errorList[inputBoxes[0].id]['errMsg'] = "Invalid phone number.";
												_errorList[inputBoxes[0].id]['section'] = section;
												_isInvalid = true;
											}
											if((_input0Val.length >0  && _$input1.length>0)){
												if(_$input1.val().length<4){
													_errorList[inputBoxes[0].id] = {};
													_errorList[inputBoxes[0].id]['errMsg'] = "Invalid phone number.";
													_errorList[inputBoxes[0].id]['section'] = section;
													_isInvalid = true;
												}
											}else if((_input0Val.length == 0  && _$input1.length > 3) || (_input0Val.length > 0  && _$input1.length < 4) ){
												_errorList[inputBoxes[0].id] = {};
												_errorList[inputBoxes[0].id]['errMsg'] = "Invalid phone number.";
												_errorList[inputBoxes[0].id]['section'] = section;
												_isInvalid = true;
											}
											
										}else if(fullPhoneNum.length != 10 && fullPhoneNum.length > 0 ){
											_errorList[inputBoxes[0].id] = {};
											_errorList[inputBoxes[0].id]['errMsg'] = "Invalid phone number.";
											_errorList[inputBoxes[0].id]['section'] = section;
											_isInvalid = true;
										}
										//if  prefeered is chcked and user didnt enter any phone num, throw an error
										if( ( prefferedBox.is(":checked")  &&  !_isInvalid && fullPhoneNum.length == 0)){
											_errorList[inputBoxes[0].id] = {};
											_errorList[inputBoxes[0].id]['errMsg'] = "You must type in a phone number to mark as preferred.";
											_errorList[inputBoxes[0].id]['section'] = section;
											_isInvalid = true;
										}
										
										if(isIntnsnl){
											if(fullPhoneNum && fullPhoneNum.length>5){
												atLeastOnePhone = true;
											}
										}else{
											if(fullPhoneNum && fullPhoneNum.length>9){
												atLeastOnePhone = true;											
																						
											}
										}
											
									}
									
								});
							}
							//invalid phonenumber check only if throw error is true
							if(throwError){
								if($("#ncst-phone-section-container.invalid-phone-number").length>0) {
									$(".ncst-phone-section-container").addClass("cust1-error");
									document.getElementById('ncst-phone-section-container').scrollIntoView(true);
									$("#ncst-phone-section-err-msg").html('Invalid phone number entered.');
									$("#ncst-phone-section-err-msg").removeClass("hidden");
									return false;
								}
							}
							if(!atLeastOnePhone){
								 this.model.set('clientDetlsValid', false);
							}
							if(_isInvalid){
								$(".ncst-phone-section-container").removeClass("error cust1-error");
								$("#ncst-phone-section-err-msg").addClass("hidden");
								for (elementID in _errorList) {
									var _section = _errorList[elementID];
									var _$section = $(_section['section']);
									_$section.addClass("error");
									_$section.find(".error").html(_section.errMsg).removeClass("hidden");
								}
								//$(missingPreffredPhoneSection).addClass("error");
								$(".ncst-phone-section-container .ph-num-section.error")[0].scrollIntoView();
								//$(missingPreffredPhoneSection).find(".error").removeClass("hidden");
								return false;
							}
							if(!atLeastOnePhone && throwError) {
								$(".ncst-phone-section-container").addClass("cust1-error");
								document.getElementById('ncst-phone-section-container').scrollIntoView(true);
								$("#ncst-phone-section-err-msg").html('&nbsp;At least one phone number is required.');
								$("#ncst-phone-section-err-msg").removeClass("hidden");
								return false;
								}
							else{
								$(".ncst-phone-section-container").removeClass("error cust1-error");
								$("#ncst-phone-section-err-msg").addClass("hidden");
								return true;
							}
							
						},
						render : function() {
							var _mdlVars = this.model.toJSON();
                            //console.log(_mdlVars, '_mdlVars');
							var _clientBday = _mdlVars.clientbDay ? _mdlVars.clientbDay
									.split('/')
									: null;
                            //console.log(_clientBday, '_clientBday');
							if (_clientBday) {
								_mdlVars['bMm'] = _clientBday[0];
								_mdlVars['bDd'] = _clientBday[1];
								_mdlVars['bYy'] = _clientBday[2];
							}else{
                                                            _mdlVars['bMm']=_mdlVars['bDd']=_mdlVars['bYy'] = ''; 
							}
							if (ClientInfoModel.get('clientType') == 'P') {
								_mdlVars['typeName'] = 'Client name';
								_mdlVars['typeValue'] = ClientInfoModel
										.get('fullName');
							} else {
								_mdlVars['typeName'] = 'Entity name';
								_mdlVars['typeValue'] = ClientInfoModel
										.get('entityName');
							}
							var _data = _mdlVars;
								_data.client = ClientModel;
								_data.isMobile = Utils.isMobile(); 
							this.$main.html(this.template(_data));
							return this;
						},
						afterRender : function() {
							
							var _self = this;
							if (ClientInfoModel.get('clientType') == 'P'
									&& AddressModel.get('primaryAddress').addressType != "Foreign") {
								this.loadUSStatesList();
								this.showStates();
							}
							var _errorCodes = ClientModel.get('serverErrorCodes');
                            Utils.setServerErrValidations("4", _errorCodes);
                            ClientModel.set('serverErrorCodes', _.without(_errorCodes, '15509', '15510','15521','9','10','21'));
							// Deciding if Person or entity
							if (ClientInfoModel.get('clientType') == 'P') {
								$('.entity-field').addClass('hidden');
								$('.person-field').removeClass('hidden');
							} else {
								$('.entity-field').removeClass('hidden');
								$('.person-field').addClass('hidden');
							}
							$('#us-states-list-details-page').val(
									this.model.get('clientState'));
							$('.custom-select').customizeSelect();

							if (this.model.get('fromBack')) {
								$('#cd-marital-status').val(
										this.model.get('clientmaritalStatus'));
								$('#cd-prospect-source').val(
										this.model.get('clientprospectSource'));
								$('#cd-acquisition-technique')
										.val(
												this.model
														.get('clientacquisitionTech'));

								$('#cd-primary-email-entity').val(
										this.model.get('clientprimaryEmail'));
								$(
										':radio[value="'
												+ this.model
														.get('clientprimaryEmailRadio')
												+ '"]').attr('checked',
										'checked');
								// if(ClientInfoModel.get('clientType') =='P'||
								// ClientInfoModel.get('entityRole') ==
								// 'Revocable trust' ||
								// ClientInfoModel.get('entityRole') ==
								// 'Irrevocable trust'){
								if ($("input[name='cd-primary-email']:checked")
										.val() != "clientPrimaryEmail") {
									$('#cd-primary-email-entity').removeClass(
											'needed required');
									$('#cd-primary-email-entity').attr(
											'disabled', 'true');
									$('#cd-secondary-email').attr('disabled',
											'true');
								} else {
									$('#cd-primary-email-entity').addClass(
											'needed required');
									$('#cd-primary-email-entity').removeAttr(
											'disabled');
									$('#cd-secondary-email').removeAttr(
											'disabled');
								}
								$('#add-details select').trigger('change');
							}
							if (ClientModel.get('clientCreated') == 'failed') {
								Validator.validateInputs('add-details', true);
								this.validateMinimumPhone(true);
							}
							// placeholder fix for IE
							$.support.placeholder = false;
							var _test = document.createElement('input');
							if ('placeholder' in _test)
								$.support.placeholder = true;

							// Placeholder for IE

							if (!$.support.placeholder) {

								var active = document.activeElement;
								$('.bday')
										.focus(
												function() {
													if ($(this).attr(
															'placeholder') != ''
															&& $(this).val() == $(
																	this)
																	.attr(
																			'placeholder')) {
														$(this)
																.val('')
																.removeClass(
																		'hasPlaceholder');
													}
												})
										.blur(
												function() {
													_self.ddmmDtFormater();
													if ($(this).attr(
															'placeholder') != ''
															&& ($(this).val() == '' || $(
																	this).val() == $(
																	this)
																	.attr(
																			'placeholder'))) {
														$(this)
																.val(
																		$(this)
																				.attr(
																						'placeholder'))
																.addClass(
																		'hasPlaceholder');
													} else {
														$(this)
																.removeClass(
																		'hasPlaceholder');
													}
												});
								$('.bday').blur();
								$(active).focus();
							}
						    //_self.initInfoPopup();
							$("#ncst-user-home-view").invokeInfoPopup();
						},
                        /*
						initInfoPopup : function() {
							Utils.initInfoPopup();
						},
                        */
						loadUSStatesList : function() {
							var _stateList = DropdownOptions.USStateslist;
							var _selectbox1 = "#us-states-list-details-page";
							Utils.loadSelectbox(_selectbox1, _stateList);
						},
						loadStateList : function() {
							var _stateList = [];
							var _selectbox1 = "#us-states-list-details-page";
							Utils.loadSelectbox(_selectbox1, _stateList);
						},
						handlerForCancel : function() {
							BootstrapDialog
									.confirm(
											"Cancel",
											"All your work will be lost.  Are you sure you want to cancel?",
											function(confirm) {
												if (confirm) {
													window.open('', '_self');
													window.close();
												}
											});

						},
						bdayValidator : function(obj) {
							var _regxNumOnly = /^\d*$/;
							// var _regxNumOnly =
							// /^(0[1-9]|1\d|2[0-8]|29(?=-\d\d-(?!1[01345789]00|2[1235679]00)\d\d(?:[02468][048]|[13579][26]))|30(?!-02)|31(?=-0[13578]|-1[02]))-(0[1-9]|1[0-2])-([12]\d{3})(\s([01]\d|2[0-3]):([0-5]\d):([0-5]\d))?$/gm;
							var _str = String.fromCharCode(event.keyCode);
							if (!_regxNumOnly.test(_str)) {
								obj.stopPropagation();
								if (event.preventDefault)
									event.preventDefault();
								return false;
							}
							var _currTgt = $(obj.currentTarget);
                                                        var _tgt = obj.target;
                                                       try {
                                                    	   if (_tgt.selectionStart == _tgt.selectionEnd){
                                                               var _id = _currTgt.attr('id');
                                                               var _maxLen = _currTgt.attr('maxlength');
                                                               var _nxtSibl = _currTgt.next();
                                                               switch (_id) {
                                                                   case 'cd-bday-1':
                                                                   case 'cd-bday-2':
                                                                           if (_currTgt.val().length >= _maxLen) {
                                                                                   if ($(_nxtSibl).val().length >= $(_nxtSibl)
                                                                                                   .attr('maxlength')) {
                                                                                               $(_nxtSibl).select();
//                                                                                           $(_nxtSibl).next().focus();
//                                                                                           var tmpStr = $(_nxtSibl).next().val();
//                                                                                           $(_nxtSibl).next().val('');
//                                                                                           $(_nxtSibl).next().val(tmpStr);
                                                                                   } else {
                                                                                           $(_nxtSibl).focus();
                                                                                           var _txtVal = $(_nxtSibl).val();
                                                                                           _txtVal += _str;
                                                                                           $(_nxtSibl).val(_txtVal);
                                                                                   }
                                                                                   obj.stopPropagation();
                                                                                   if (event.preventDefault)
                                                                                           event.preventDefault();
                                                                                   return false;
                                                                           }
                                                                           break;

                                                                   case 'cd-bday-3':
                                                                           this.ddmmDtFormater();
                                                                           if (_currTgt.val().length >= _maxLen) {
                                                                                   obj.stopPropagation();
                                                                                   if (event.preventDefault)
                                                                                           event.preventDefault();
                                                                                   return false;
                                                                           }
                                                                           break;
                                                                   }
                                                           }
													} catch (e) {
														console.log('no support to selection start.')
													}
						},
						ddmmDtFormater : function() {
							var _mmVal = $('#cd-bday-1').val();
							var _ddVal = $('#cd-bday-2').val();
							parseInt(_mmVal) && _mmVal.length == 1 ? $(
									'#cd-bday-1').val(
									this.zeroPadder(_mmVal, 2)) : '';
							parseInt(_ddVal) && _ddVal.length == 1 ? $(
									'#cd-bday-2').val(
									this.zeroPadder(_ddVal, 2)) : '';

						},
						zeroPadder : function(num, width, z) {
							z = z || '0';
							var _num = num + '';
							return _num.length >= width ? n : new Array(width
									- _num.length + 1).join(z)
									+ _num;
						},
						saveBday : function() {
							var birthDay = [ $('#cd-bday-1').val(),
									$('#cd-bday-2').val(),
									$('#cd-bday-3').val() ];
							ClientDetailsModel.set('clientbDay', birthDay
									.join('/'));
							/* Future dates dissallowed */
							var dateString = ClientDetailsModel.get('clientbDay');
							var date = new Date(dateString);
							ClientDetailsModel.set('dateCheck',
									date < new Date() ? true : false);
						},
						movetonxtField: function (obj) {

						    var specialCaseIdArr = ["cd-businessphone-1", "cd-businessphone-2", "cd-businessphone-3", "cd-other1phone-1", "cd-other1phone-2", "cd-other1phone-3", "cd-other2phone-1", "cd-other2phone-2", "cd-other2phone-3"]
                                                    // if the user press tab do not change the focus
                                                    if (event.keyCode != 9 && event.keyCode != 16) {
                                                        var _tgt = obj.target;
                                                         try {
                                                        	 if (_tgt.selectionStart == _tgt.selectionEnd){
                                                                 var _currTgt = $(obj.currentTarget);
                                                                 var _maxLen = _currTgt.attr('maxlength');
                                                                 var _nxtSibl = _currTgt.next();
                                                                 var _id = _currTgt.attr('id');
                                                                 if (_currTgt.val().length == _maxLen) {
                                                                     if ($(_nxtSibl).is("input")) {
                                                                        var  _nextval = $(_nxtSibl).val();
                                                                        if (_nextval != "" && _nextval.length >= $(_nxtSibl)
                                                                                                    .attr('maxlength')) {
                                                                             $(_nxtSibl).select();
                                                                         } else {
                                                                             $(_nxtSibl).focus();
                                                                         }
                                                                     }else if (specialCaseIdArr.indexOf(_id)>-1){
                                                                     	$(_nxtSibl).next().focus();
                                                                     }
                                                                                 
                                                                             
                                                                 }
                                                             }  
														} catch (e) {
															console.log('no support to selectionStart.')
														}
                                                    }    
						},
						numValidator : function(obj) {
							var _currTgt = $(obj.currentTarget);
							var _maxLen = _currTgt.attr('maxlength');
							var _regxNumOnly = /^\d*$/;
							var _str = String.fromCharCode(event.keyCode);
							if (!_regxNumOnly.test(_str)
									|| _currTgt.val().length >= _maxLen) {
								obj.stopPropagation();
								if (event.preventDefault)
									event.preventDefault();
								return false;
							}
						},

                        //TODO Remove this code duplication - Function to handle country code  like +1,+91,etc
						countryCodeValidator: function (obj) {
						    var _currTgt = $(obj.currentTarget);
						    var _maxLen = _currTgt.attr('maxlength');
						    var _regxNumOnly = /^[+]{0,1}?\d*$/;;
						    var _str = _currTgt.val() + String.fromCharCode(event.keyCode) ;
						   if(_str.indexOf('+') == -1) {
							   _maxLen = _maxLen - 1;
						   }
						    if (!_regxNumOnly.test(_str)
									|| _currTgt.val().length >= _maxLen) {
						        obj.stopPropagation();
						        if (event.preventDefault)
						            event.preventDefault();
						        return false;
						    }
						},


						showStates : function() {
							if ($('#cd-driver-license').val().length
									&& AddressModel.get('primaryAddress').addressType != 'Foreign') {
								$('#cd-us-states-list').show();
							} else {
								$('#cd-us-states-list').hide();
							}
						},
						validatePrimarymail : function(e) {
							if ($(e.target).val() == 'clientPrimaryEmail') {
								$('#cd-primary-email-entity').addClass(
										'needed required');
								$('#cd-primary-email-entity').removeAttr(
										'disabled');
								$('#cd-secondary-email').removeAttr('disabled');
							} else {
								$('#cd-primary-email-entity').val('');
								$('#cd-primary-email-entity').removeClass(
										'needed required');
								$('#cd-primary-email-entity').attr('disabled',
										'true');
								$('#cd-secondary-email').val('');
								$('#cd-secondary-email').attr('disabled',
										'true');
                                                                $("#client-detls-error-msg-cntnr").addClass('hidden');               
							}
						},						
                        validateEmailService :function(){
                            
                                var _url = BASE_URL + 'validateEmailAddress?$format=json';                                
                                //var _url = 'data/validateEmailService.json';
                                var _mailArr = this.mailArr;
                                var _cntr = this.mailArrCntr;
                                var _self = this;
                                Utils.lockForm();
				Utils.post(_url, JSON.stringify({"emlAddr" : _mailArr[_cntr].mailAddr}),
						validateEmailSuccess,function(xhr){
								Utils.unlockForm();
                                                                ClientDetailsModel.set('clientDetlsValid', false);
                                                                Utils.showSystemUnavailableMsg("4", "detls", xhr.status);
                                                                Utils.logError(xhr);
								/*show error like system unavailable*/
				},0);
                                function validateEmailSuccess(resp) {
                                    
                                    Utils.unlockForm();
                                    var _type = _mailArr[_self.mailArrCntr].type;
                                    _self.mailArrCntr --;                                    
                                    var _response = resp.d;
                                    
                                    if (!_response.explanations.results.length) {                                         
                                        
					if (_self.mailArrCntr >= 0){ // calling validateEmailService if items present in array.
                                            
                                            _self.validateEmailService(_mailArr[_self.mailArrCntr].mailAddr);
                                            
                                        }else{
                                            if (!_self.errInMailAddrCntr){
                                            _self.stepNavigator();
                                            }
                                        }
                                            
                                     } else {
                                        _self.errInMailAddrCntr++;
                                        /*showing error in email field if response.result array is null*/                                            
                                        ClientDetailsModel.set('clientDetlsValid', false);
                                        if (_type == 'primary'){
                                            $('.pt-primary-email-error-bg').addClass('pt-error');
                                            $('#pt-pmail-service-err-msg').removeClass('hidden').html("Invalid email address");
                                        }
                                        if (_type == 'secondary'){
                                            $('.pt-secondary-email-error-bg').addClass('pt-error');
                                            $('#pt-smail-service-err-msg').removeClass('hidden').html("Invalid email address");                                        
                                        }
                                        if (_self.mailArrCntr >= 0){ // calling validateEmailService if items present in array.
                                            Utils.lockForm();
                                            _self.validateEmailService(_mailArr[_self.mailArrCntr].mailAddr);
                                        }
                                            
				    }
				}
                        },                        
                        hideServiceErrors : function() {
                                $('.row.form-group.pt-warning').removeClass('pt-warning');
				$('.row.form-group.pt-error').removeClass('pt-error');
                                $('.pt-primary-email-error-bg,.pt-secondary-email-error-bg').removeClass('pt-error');
                                $('#pt-pmail-service-err-msg,#pt-smail-service-err-msg,label.pt-warning,label.pt-error').addClass('hidden');
                        },
                        navigateFromStep4 : function(hashTag, clickedStep) {
                            
                                this.hideServiceErrors();
                                Utils.hideErrorMsg();
                                this.nextHash = hashTag;
                                this.clickedStep = clickedStep;
                                var _normalvaldtn = this.model.validate(),_specValdtn = this.validateMinimumPhone();
                                if ( _normalvaldtn && _specValdtn) {
                                    
                                    /* Service to check if the mail address is valid */
                                    this.mailArr = [];                                    
                                    var _primMail = $('#cd-primary-email-entity').val();
                                    var _secMail = $('#cd-secondary-email').val();
                                    
                                    if (_primMail){                                        
                                        this.mailArr.push({mailAddr:_primMail, type:'primary'});
                                        if (_secMail){
                                          this.mailArr.push({mailAddr:_secMail, type:'secondary'});  
                                        }
                                        this.mailArrCntr = this.mailArr.length-1;
                                        this.errInMailAddrCntr = 0;
                                        this.validateEmailService();
                                    }else{
                                    	Utils.getView('clientInfo').markActiveStep(this.clickedStep);
                                    	location.hash  = this.nextHash;
                                        window.scrollTo(0, 0);
                                    }
                                        
                                }

                        },
                        stepNavigator: function(){
                        	Utils.getView('clientInfo').markActiveStep(this.clickedStep);
                        	location.hash = this.nextHash;
                            window.scrollTo(0, 0);
                        },

					    //function to handle the international home phone number
                        internationalNumberCheck: function (event) {
                            var _currTgt = $(event.currentTarget),internationalInputId,currBlock;
                            internationalInputId = _currTgt.data('toggle');
                            currBlock = _currTgt.data('block');
                            $("#"+currBlock).find("input[type=text]").val("");
                            $("#"+currBlock).find("input[type=tel]").val("");
                            if (_currTgt.find('input').prop('checked')) {
                               /* this.$main.find('#' + currBlock + ' .textbox-wrapper').hide();
                                this.$main.find('#' + internationalInputId).show();*/
                                this.$main.find('#' + currBlock + ' .textbox-wrapper').addClass('hidden');
                                this.$main.find('#' + internationalInputId).removeClass('hidden');
                            } else {
                               /* this.$main.find('#' + currBlock + ' .textbox-wrapper').hide();
                                this.$main.find('#' + currBlock + ' .default').show();*/
                                this.$main.find('#' + currBlock + ' .textbox-wrapper').addClass('hidden');
                                this.$main.find('#' + currBlock + ' .default').removeClass('hidden');
                            }
                           
                        },
                        preferredNumberCheck: function (event) {
                            var _currTgt = $(event.currentTarget);
                        	 var _checkbox = $(event.currentTarget).find('input[type="checkbox"]'),_checked = _checkbox.prop('checked');
                             this.$main.find('.cd-pref-checkbox input[type="checkbox"]').prop('checked', false);
                            _currTgt.find('input[type="checkbox"]').prop('checked', true)
                             _checkbox.prop('checked', _checked);
                        }

                    });
			return clientDetailsView;
        });