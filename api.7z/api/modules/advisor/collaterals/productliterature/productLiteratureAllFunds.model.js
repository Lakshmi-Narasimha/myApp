// ProductLiteratureAllFunds.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ProductLiteratureAllFundsSchema = new mongoose.Schema({
    ProductLiteratureAllFunds: {
        type: Array,
        "default": []
    }
});

var ProductLiteratureAllFundsLookUp = mongoose.model('ProductLiteratureAllFundsLookUp', ProductLiteratureAllFundsSchema);
/*json order: investor book-*/
var productDetailsModel = new ProductLiteratureAllFundsLookUp({
  "ProductLiteratureAllFunds": [
  {
    "label": "Franklin India Bluechip Fund - Dividend",
    "id": 1,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Fund - Growth",
    "id": 2,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Fund - Direct - Dividend",
    "id": 3,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Fund - Direct - Growth",
    "id": 4,
    "selected":"false"
  },
  {
    "label": "Franklin India Prima Fund - Dividend",
    "id": 5,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Plus - Dividend",
    "id": 6,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Plus - Growth",
    "id": 7,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Prima Plus - Dividend",
    "id": 8,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Plus - Direct - Dividend",
    "id": 9,
    "selected":"false"
  },
  {
    "label": "Franklin India Bluechip Plus - Direct - Growth",
    "id": 10,
    "selected":"false"
  },
  {
    "label": "Investing in equalites",
    "id": 11,
    "selected":"false"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 12,
    "selected":"false"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 13,
    "selected":"false"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 14,
    "selected":"false"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 15,
    "selected":"false"
  }
]
});

ProductLiteratureAllFundsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ProductLiteratureAllFundsLookUp table, please contact admin...');
    } else {
        ProductLiteratureAllFundsLookUp.remove({}, function(err) {
            console.log('ProductLiteratureAllFundsLookUp collection removed');
           productDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ProductLiteratureAllFundsLookUp table, please contact admin...');
                }
                console.log('ProductLiteratureAllFundsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ProductLiteratureAllFundsLookUp;
