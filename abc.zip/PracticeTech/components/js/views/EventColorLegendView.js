﻿define([
    'jquery',
    'underscore',
    'backbone',
    'appcommon/commonutility',
    'text!components/template/EventColorLegendView.html',
    'errorLog',
    'text!components/template/EventColorLegendCollectionTemplate.html'
], function ($, _, Backbone, CommonUtils, EventColorLegendViewTemplate, ErrorLog, EventColorLegendCollectionTemplate) {

    /*
     NOTE: This view need constructor property:
     1.) the element on which this view will be attached*
     Optional callback properties
     1.) the data source (a ContactPickerDataSource object);
     *
     example:
     var colorLegendView = new EventColorLegendView({el: $('#my-contact-picker').get(0), cancelCallback,doneCallback});
     NOTE: the element must have a unique DOM id
     */

    /*EventType Model*/
    var EvntTypeModel = Backbone.Model.extend({
            defaults: {
                "type": null,
                "hexColor": null
            }
    });

    /*EventType Collection*/
    var EvntTypeCollection = Backbone.Collection.extend({
        model: EvntTypeModel
    });

    /*Legend list SubView*/
    var LegendsSubView = Backbone.View.extend({
            template: _.template(EventColorLegendCollectionTemplate),
            initialize: function (options) {
                _.extend(this, options);
                this.listenTo(this.collection, 'reset', function (evt) {
                    this.render();
                });
            },
            render: function () {
                this.$el.empty();
                this.$el.html(this.template({
                    eventTypes: this.collection.toJSON()
                }));
            }
    });

    /*Main Modal View */
    var EventColorLegendView = Backbone.View.extend({
        template: _.template(EventColorLegendViewTemplate),
        events: function(){
            var _evts = [];
            _evts["click [cancel-button-" + this.getContainerId() + "]"] = "cancelCallback";
            _evts["click [done-button-" + this.getContainerId() + "]"] = "doneButtonHandler";
            _evts["click [color-toggle-button-" + this.getContainerId() + "]"] = "toggleColorOnOff";
                //_evts["click [close-view]"] = "closeView";
            return _evts;
        },
        initialize: function (options) {
            _.extend(this, options);
            this.on('render', this.onRender);
            this.evtTypeCollection = new EvntTypeCollection();
            //create sub view
            this.eventlegendSubView = new LegendsSubView({ 
                "collection":this.evtTypeCollection
            });
        },
        beforeClose: function () {
            
        },
        render: function (options) {
            this.$el.empty();
            this.$el.html(this.template({
                showColor: options.showColor,
                containerId: this.getContainerId()
            }));
            this.eventlegendSubView.setElement(this.$el.find('.color-legends-ctnr'));
        },
        cancelButtonHandler: function () {
            this.cancelCallback();
        },
        doneButtonHandler: function () {
            var _$toggleButtonCtive = $('.active[color-toggle-button-' + this.getContainerId() + ']');
            this.closeModal();
            this.doneCallback({ "showColor": _$toggleButtonCtive.attr("color-toggle-val") });
        },
        cancelCallback: function () {
            this.closeModal();
        },
        doneCallback: function () {
            this.closeModal();
        },
        closeModal: function () {
            $("#event-color-legend-modal-" + this.getContainerId()).modal('hide');
            this.resetBodyStyle();
        },
        toggleColorOnOff: function (evt) {
            var _$target = $(evt.currentTarget),
                _$toggelButtons = $('[color-toggle-button-' + this.getContainerId() + ']');
            if (_$target.hasClass("active")) {
                return;
            } else {
                _$toggelButtons.toggleClass('active');
            }
        },
        updateLegend: function (eventTypeColors) {
            var evtTypModelArray = [];
            for (var i = 0; i < eventTypeColors.length; i++) {
                var _evtTypModel = new EvntTypeModel(eventTypeColors[i]);
                evtTypModelArray.push(_evtTypModel);
            }
            this.evtTypeCollection.reset(evtTypModelArray);
        },
        closeView: function () {
            this.close();
        },
        getContainerId: function () {
            return this.$el.prop('id');
        },
        resetBodyStyle: function () {
            var _top = $("body").css("top");
            var _bodytop = Math.abs(_top.substr(0, _top.length - 2));
            $('body').removeAttr('style');
            $(window).scrollTop(_bodytop);
            $($(".fc-agenda-divider.fc-widget-header").next()[0]).css({ "overflow-y": "auto", "-webkit-overflow-scrolling": "touch" });
        }
       
    });
    return EventColorLegendView;
});
