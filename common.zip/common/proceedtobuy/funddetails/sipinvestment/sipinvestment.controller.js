/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details SIP controller for Advisor module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function fundDtlsSipCtrl($scope, $state, buildPlanModelService, planSmartSolution, $filter, TransactConstant, transactModel, fundDetails, truncateTextService,paperlessModel,recommendedPlanModelService, $timeout, eventConstants) {

    $scope.fundDetails = buildPlanModelService.getGoalPlanData();
    $scope.sipFundDetails = [];
    var startDate = null, endDate = null;
    $scope.isReload = true;

    // if(planSmartSolution.getFutureDate()){
    //        var changdFutreDate = planSmartSolution.getFutureDate();
    //        // futureMonth = changdFutreDate.getMonth();
    //        //  futureYear = changdFutreDate.getFullYear();
    //         console.log("changdFutreDate", changdFutreDate);
    //         console.log("future day",changdFutreDate.getDate());
    //     }
    //Future Installment Day option settings for section filter
    $scope.today = new Date();
    $scope.tYear = $scope.today.getFullYear();
    $scope.day = $scope.today.getDate();
    $scope.mm = $scope.today.getMonth()+1;
    $scope.days = [];

   
    //commenting as per 3945 
    startDate = $filter('date')(new Date(), 'd MMM yyyy');
    var startDateGrid = "Current Business Day";
    var endDateFormat =null;
    if(paperlessModel.isCustPlan && !recommendedPlanModelService.isExpectedReturn)
    {
        endDateFormat = parseInt($filter('date')(new Date(), 'yyyy')) + parseInt(planSmartSolution.getSmartSolutionDetails() ? planSmartSolution.getSmartSolutionDetails().revisedYears : '');
        var year =planSmartSolution.getSmartSolutionDetails().revisedYears;
        /*var month = year - parseInt(year);
        var newMonth = Math.round((month * 365)/30);
        $scope.finalMonth = $filter('date')(new Date($scope.tYear , newMonth, $scope.day), 'MMM');*/

        var nowDate = new Date();
        var totalMonths = Math.round(year * 12);
        var endDateFinal = new Date(new Date(nowDate).setMonth(nowDate.getMonth()+totalMonths));

        var endDateTotal = $filter('date')(endDateFinal, 'dd MMMM yyyy, hh:mm a');

        endDateFormat = $filter('date')(endDateFinal, 'yyyy');
        $scope.finalMonth = endDateFinal.getMonth();//$filter('date')(endDateFinal, 'MMMM');




    }
    else
    {
        endDateFormat = parseInt($filter('date')(new Date(), 'yyyy')) + parseInt(planSmartSolution.getSmartSolutionDetails() ? planSmartSolution.getSmartSolutionDetails().investmentTenure : '5');       
        var endDateFinal = new Date();
        $scope.finalMonth = endDateFinal.getMonth();//$filter('date')(new Date(), 'MMMM');
    }

     endDate = $scope.finalMonth +' ' + endDateFormat;
     
      var nowDate = new Date();
          nowDate.setMonth($scope.finalMonth);
          nowDate.setFullYear(endDateFormat);
          endDate = $filter('date')(nowDate, 'd MMM yyyy');
   
    //endDate = $filter('date')(new Date(), 'd MMM') +' ' + endDateFormat;
    // endDate = $filter('date')(new Date(), 'MMM') +' ' + endDateFormat;
    angular.forEach($scope.fundDetails, function (obj) {
        obj.sipstartdate = startDate;
        obj.sipenddate = endDate;
        obj.startDateGrid = startDateGrid;         
        if(buildPlanModelService.getInvestmentType() === 'Monthly' || buildPlanModelService.getInvestmentType() === 'Combo') {
            var gridRow = {};
            gridRow = planSmartSolution.returnMonthlyorAnnually('Monthly', obj, gridRow);
            gridRow.sipenddate = $filter('date')(new Date(gridRow.sipenddate), 'MMM yyyy');
            $scope.sipFundDetails.push(gridRow);
        }
        if(buildPlanModelService.getInvestmentType() === 'Annually' || buildPlanModelService.getInvestmentType() === 'Combo') {
            var gridRow1 = {};
            gridRow1 = planSmartSolution.returnMonthlyorAnnually('Annually', obj, gridRow1);
            gridRow1.sipenddate = $filter('date')(new Date(gridRow1.sipenddate), 'MMM yyyy');
            $scope.sipFundDetails.push(gridRow1);
        }
    });
    planSmartSolution.setSIPFunds($scope.sipFundDetails);

    $scope.sipFundDetails = truncateTextService.updateLabel(angular.copy($scope.sipFundDetails), 'fundName', 27);
    var celltemp = '<div class="ui-grid-cell-contents" title="{{col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)].fundName_orignal}}">{{COL_FIELD}}</div>';

    
    $scope.sipColumnDefs = [
        {field: 'fundName', displayName: 'Invest Into',data: $scope.sipFundDetails, cellTemplate: celltemp, width: '200', pinnedLeft: true},
        {field: 'sipAmt',displayName: 'SIP Amount',width: '180',headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',cellClass: 'text-right'},
        {field: 'startDateGrid', displayName: 'SIP Start Date', width: '180'},
        {field: 'sipenddate', displayName: 'SIP End Date', width: '180'},
        {field: 'frequency', displayName: 'Frequency', width: '200'},
        {field: 'stepup', displayName: 'Step Up SIP', width: '300'}
    ];


    
    $scope.endDateOptions = {
        yearRows: 4,
        yearColumns: 3,
        datepickerMode: 'month',
        minMode: 'month',
        fulldatepickerMode:'year',
        formatMonth: 'MMM',
        formatYear: 'yyyy',
        formatDayTitle: 'MMM yyyy',
        startingDay: 0,
        showWeeks: false,
        minDate:new Date()
    };

    /*var currentmonth = new Date($scope.today.getFullYear(), $scope.today.getMonth() + 1, 0);
    var currentMonthArray = currentmonth.toString().split(" ");
    $scope.max = parseInt(currentMonthArray[2]);
    for(var i=$scope.day+1;i<=$scope.max;i++){
        $scope.days.push(i);
    }*/
    if(planSmartSolution.getFutureDate()){
           var changdFutreDate = planSmartSolution.getFutureDate();
           // futureMonth = changdFutreDate.getMonth();
           //  futureYear = changdFutreDate.getFullYear();
        $scope.sipInvestment.futureInstallmentMonth = changdFutreDate;
        }
        else{
    $scope.sipInvestment.futureInstallmentMonth = $scope.today;}
    var maxDayInMonth;
    function futureDays(date) {
        $scope.days = [];
        maxDayInMonth = new Date(date.getFullYear(), date.getMonth()+1, 0).getDate();
        for(var i=1;i<=maxDayInMonth;i++){
            $scope.days.push(i);
        }
        $scope.futureInstDayOptions = $scope.days.map(function(e) {
            return { title: e };
        });
        if(planSmartSolution.getFutureDate()){
           var changdFutreDate = planSmartSolution.getFutureDate();
            for (var i=0;i<$scope.futureInstDayOptions.length;i++) {
                  if($scope.futureInstDayOptions[i].title==changdFutreDate.getDate()){
                    $scope.sipInvestment.defaultDaySelected=$scope.futureInstDayOptions[i];
                    break;
                  }
                }
            //$scope.sipInvestment.defaultDaySelected = changdFutreDate.getDate();
        }else{
        if($scope.futureInstDayOptions){
            $scope.sipInvestment.defaultDaySelected = $scope.futureInstDayOptions[0];
        }}
    }
    $scope.futureInstallmentDateChange = function(date){
        futureDays(date);
    };
    futureDays(new Date());
    //$scope.days= [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
    /*$scope.futureInstDayOptions = $scope.days.map(function(e) {
        return { title: e };
    });
    if($scope.futureInstDayOptions){
        $scope.sipInvestment.defaultDaySelected = $scope.futureInstDayOptions[0];
    }*/
    $scope.futureInstDayInputObject = {
        label : 'DAY',
        name : 'futureInstDay',
        required : true
    };

    //Assigning futureInstallmentDay to sipDetails object, if day changes
    $scope.$on('FutureInstallmentDayChange', function(event, selectedValue){
        $scope.sipInvestment.futureInstallmentDay = selectedValue.title;
    });

    $scope.firstInstallment = 'Current Business Day';



    ///* DatePicker Ends */
    //$scope.$emit('monthupdated', $scope.dt);
    //
    ///*Second Select Change events*/
    //$scope.inputChange = function(inputVal) {
    //   $scope.popup2.opened = false;
    //   $scope.$emit('initialmonthselected', inputVal);
    //};
    $scope.accordionClicked = function(){
        transactModel.setTransactType(TransactConstant.sip.SIP);
        fundDetails.removeFundDetails();
        
        angular.forEach(planSmartSolution.getSIPFunds(),function(obj){
            if(!angular.isNumber(obj.sipAmount)) {
                obj.sipAmount = obj.sipAmount.indexOf(',') >-1 ? obj.sipAmount.replace(/,/g, '') : obj.sipAmount;
            }

            fundDetails.setFundDetails(obj);
        });
    };

    if(planSmartSolution.getTransactType()!=='Combo')
    {        
        $scope.isOpenInvGrid = {
            'open': true      
        };
        $scope.accordionClicked();
    }

    $scope.$on(eventConstants.SIP_VALIDATION_FAILED,function(event){
        $scope.isReload = false;
        $scope.isOpenInvGrid = {
            'open': true      
        };       
        $timeout(function(){
            $scope.isReload = true;
        });
    });
}

fundDtlsSipCtrl.$inject = ['$scope', '$state', 'buildPlanModelService', 'planSmartSolution', '$filter', 'TransactConstant', 'transactModel', 'fundDetails', 'truncateTextService','paperlessModel','recommendedPlanModelService', '$timeout', 'eventConstants'];

module.exports = fundDtlsSipCtrl;