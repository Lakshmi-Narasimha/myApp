/**
 * @ngdoc service
 * @name ifscModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var ekycVerificationModel = function (Restangular, $q,authenticationService, fticLoggerMessage, loggerConstants) {
   
    var _holderDetails = null;

    var ekycVerificationModel = {
      
        validateEkycOtp : function(reqObj){ 
            var body = {};            
            var deferred = $q.defer();
            Restangular.one('transact/eKYCOTPValidation').customPOST(reqObj.bodyObj, "", reqObj.paramObj, {}).then(function (success) {
                deferred.resolve(success);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        generateAndSendEkycOtp : function(reqObj){                    
            var body = {};   
            var deferred = $q.defer();            
            Restangular.one('transact/eKYCOTPGeneration').customPOST(reqObj.bodyObj, "", reqObj.paramObj, {}).then(function (success) {
                deferred.resolve(success);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setHolderDetails : function(holderDetails){
            _holderDetails = holderDetails;
        },

        getHolderDetails :function(){
            return _holderDetails;
        }

    };
    return ekycVerificationModel;
};

ekycVerificationModel.$inject = ['Restangular', '$q', 'authenticationService', 'fticLoggerMessage', 'loggerConstants'];

module.exports = ekycVerificationModel;