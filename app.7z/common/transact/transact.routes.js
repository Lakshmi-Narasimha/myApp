'use strict';

function transactRoutes($stateProvider) {
    // Transact
    var transactMasterState = {
        parent: 'home',
        name: 'transact', // state name
        url: 'transact', // url path that activates this state
        views: {
            'dashboard@home': {
                template: require('./transactmaster.html'),
                controller: 'TransactMasterCtrl'
            }
        }
    };

    // Transact
    var transactState = {
        parent: 'transact',
        name: 'transact.base', // state name,
        abstract : true,
        url: '/base', // url path that activates this state,

        views: {
            'masterView': {
                template: require('./transact.html'),
                controller: 'TransactCtrl'
            }
        }
    };

    // Review
    var reviewState = {
        parent: 'transact',
        name: 'transact.review', // state name
        abstract : true,
        url: '/review', // url path that activates this state
        views: {
            'masterView': {
                template: require('./review/review.html'),
                controller: 'ReviewCtrl'
            }
        }
    };

    // txnDetailsState
    var txnDetailsState = {
        parent: 'transact',
        name: 'transact.txnDetails', // state name
        abstract : true,
        url: '/txnDetails', // url path that activates this state
        views: {
            'masterView': {
                template: require('./transactiondetails/transactiondetails.html'),
                controller: 'TxnDetailsCtrl'
            }
        }
    };

    // Redeem
    var redeemState = {
        parent: 'transact.base',
        name: 'transact.base.redeem', // state name
        url: '/redeem', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./redeem/redeem.html'),
                controller: 'RedeemCtrl'
            },
            'selectInvestorView' : {
                template: require('./selectedInvestor.html'),
                controller: 'selectedInvestorCtrl'
            },
            'selectFundView': {
                template: require('./selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            }
        }
    };

    var redeemReviewState = {
        parent: 'transact.review',
        name: 'transact.review.redeem', // state name
        url: '/redeem', // url path that activates this state
        views: {
            'review': {
                template: require('./redeem/reviewRedeem.html'),
                controller: 'ReviewRedeemCtrl'
            }
        }
    };
    var swpReviewState = {
        parent: 'transact.review',
        name: 'transact.review.swp', // state name
        url: '/swp', // url path that activates this state
        views: {
            'review': {
                template: require('./swp/reviewswp.html'),
                controller: 'ReviewSwpCtrl'
            }
        }
    };
    //DTP Review state

    var DTPReviewState = {
        parent: 'transact.review',
        name: 'transact.review.dtp', // state name
        url: '/dtp', // url path that activates this state
        views: {
            'review': {
                template: require('./dtp/reviewDTP.html'),
                controller: 'ReviewDTPCtrl'
            }
        }
    };


    var swpReviewState = {
        parent: 'transact.review',
        name: 'transact.review.swp', // state name
        url: '/swp', // url path that activates this state
        views: {
            'review': {
                template: require('./swp/reviewswp.html'),
                controller: 'ReviewSwpCtrl'
            }
        }
    };
    var switchReviewState = {
        parent: 'transact.review',
        name: 'transact.review.switch', // state name
        url: '/switch', // url path that activates this state
        views: {
            'review': {
                template: require('./switch/reviewSwitch.html'),
                controller: 'ReviewSwitchCtrl'
            }
        }
    };



    var redeemTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.redeem', // state name
        url: '/redeem', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./redeem/redeemTxnDetails.html'),
                controller: 'RedeemTxnDetailsCtrl'
            }
        }
    };

    // Switch
    var switchState = {
        parent: 'transact.base',
        name: 'transact.base.switch', // state name
        url: '/switch', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./switch/switch.html'),
                controller: 'SwitchCtrl'
            },            
            'selectInvestorView' : {
                template: require('./selectedInvestor.html'),
                controller: 'selectedInvestorCtrl'
            },            
            'selectFundView': {
                template: require('./selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            }
        }
    };
    
      // SWPState
    var swpState = {
        parent: 'transact.base',
        name: 'transact.base.swp', // state name
        url: '/swp', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./swp/swp.html'),
                controller: 'SwpController'
            },
            'selectInvestorView' : {
                template: require('./selectedInvestor.html'),
                controller: 'selectedInvestorCtrl'
            },
            'selectFundView': {
                template: require('./selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            }
        }
    };

    var swpTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.swp', // state name
        url: '/swp', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./swp/swptxndetails.html'),
                controller: 'SwpTxnController'
            }
        }
    };


    // STP
    var stpState = {
        parent: 'transact.base',
        name: 'transact.base.stp', // state name
        url: '/stp', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./stp/stp.html'),
                controller: 'stpController'
            },
            'selectInvestorView' : {
                template: require('./selectedInvestor.html'),
                controller: 'selectedInvestorCtrl'
            },
            'selectFundView': {
                template: require('./selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            }
        }
    };

    // Stp Details Review
    var stpReviewState = {
        parent: 'transact.review',
        name: 'transact.review.stp', // state name
        url: '/stp', // url path that activates this state
        views: {
            'review': {
                template: require('./stp/stpdetailsreview/stpDetailsReview.html'),
                controller: 'stpDetailsReviewController'
            }
        }
    };

    

    // Stp Transaction Details State
    var stpTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.stp', // state name
        url: '/stp', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./stp/stptransactiondetails/stpTransactionDetails.html'),
                controller: 'stpTransactionDetailsController'
            }
        }
    };

    // switch Transaction Details State
    var switchTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.switch', // state name
        url: '/switch', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./switch/transactionDtlsSwitch.html'),
                controller: 'transactionDtlsSwitchCtrl'
            }
        }
    };

    // buy transaction Details state
    var buyState = {
        parent: 'transact.base',
        name: 'transact.base.buy', // state name
        url: '/buy', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./buy/buy.html'),
                controller: 'buyController'
            },
            'selectInvestorView' : {
                template: require('./selectedInvestorBuy.html'),
                controller: 'selectedInvestorBuyCtrl'
            },
            'selectFundView': {
                template: require('./selectFundBuy.html'),
                controller: 'SelectFundBuyCtrl'
            },
            'nomineeDetailsView' :{
                template: require('./addNominee.html'),
                controller: 'addNomineeCtrl'
            }
        }
    };
    var newFolioRNewInvestor = {
        parent: 'transact',
        name: 'transact.base.newFolioNnewInvestor', // state name
        url: '/newFolioNnewInvestor', // url path that activates this state
        views: {
            'masterView': {
                template: require('./newFolioNNewInvestor/newFolioNnewInvestor.html'),
                controller: 'newFolioNnewInvestorCtrl'
            }
        }
    };
    

    var buyReviewState = {
        parent: 'transact.review',
        name: 'transact.review.buy', // state name
        url: '/buy', // url path that activates this state
        views: {
            'review': {
                template: require('./buy/reviewBuy.html'),
                controller: 'ReviewBuyCtrl'
            }
        }
    };

    var buyTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.buy', // state name
        url: '/buy', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./buy/buyTxnDetails.html'),
                controller: 'BuyTxnDetailsCtrl'
            }
        }
    };

    var sipState = {
        parent: 'transact.base',
        name: 'transact.base.sip', // state name
        url: '/sip', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./sip/sip.html'),
                controller: 'sipController'
            },
            'selectInvestorView' : {
                template: require('./selectedInvestorBuy.html'),
                controller: 'selectedInvestorBuyCtrl'
            },
            'selectFundView': {
                template: require('./selectFundBuy.html'),
                controller: 'SelectFundBuyCtrl'
            },
            'nomineeDetailsView' :{
                template: require('./addNominee.html'),
                controller: 'addNomineeCtrl'
            }
        }
    };

    var sipReviewState = {
        parent: 'transact.review',
        name: 'transact.review.sip', // state name
        url: '/sip', // url path that activates this state
        views: {
            'review': {
                template: require('./sip/sipdetailsreview/sipDetailsReview.html'),
                controller: 'sipDetailsReviewController'
            }
        }
    };

    var sipTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.sip', // state name
        url: '/sip', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./sip/siptransactiondetails/sipTransactionDetails.html'),
                controller: 'sipTransactionDetailsController'
            }
        }
    };

    var modifySipState = {
        parent: 'transact.base',
        name: 'transact.base.modifysip', // state name
        url: '/modifysip', // url path that activates this state
        params : {
            key : null
        },
        views: {
            'transactView': {
                template: require('./modifysip/modifysip.html'),
                controller: 'modifySipController'
            },
            'payDetView': {
                template: require('./modifysip/payDet.html'),
                controller: 'PayDetController'
            },
            'selectInvestorView' : {
                template: require('./selectedInvestor.html'),
                controller: 'selectedInvestorCtrl'
            },
            'selectFundView': {
                template: require('./selectFundTransact.html'),
                controller: 'SelectFundTransactCtrl'
            }
        }
    };

    var modifySipTxnDetailsState = {
        parent: 'transact.txnDetails',
        name: 'transact.txnDetails.modifysip', // state name
        url: '/modifysip', // url path that activates this state
        views: {
            'txndetailsview': {
                template: require('./modifysip/modifysipTxnDetails.html'),
                controller: 'ModifySipTxnDetController'
            }
        }
    };

    var ekycForm = {
        parent: 'transact',
        name: 'transact.ekyc', // state name
        url: '/ekycForm', // url path that activates this state
        views: {
            'masterView': {
                template: require('./buy/ekycRegForm/ekycRegister.html'),
                controller: 'ekycRegstrController'
            }
        }
    };

    var ekycRegState = {
        parent: 'transact',
        name: 'transact.base.ekycReg', // state name
        url: '/ekycReg', // url path that activates this state
        views: {
            'masterView': {
                template: require('./ekycregistration/ekycRegistration.html'),
                controller: 'ekycRegistrationCtrl'
            }
        }
    };

    var kycAdditionalDtlsState = {
        parent: 'transact',
        name: 'transact.base.kycForm',
        url: '/kycForm',
        views: {
            'masterView': {
                template: require('./kycAdditionalDetails/kycAdditionalDetails.html'),
                controller: 'kycAdditionalDetailsCtrl'
            }
        }
    };

    var ekycTerminationState = {
        parent: 'transact',
        name: 'transact.base.terminateEkyc',
        url: '/terminateEkyc',
        views: {
            'masterView': {
                template: require('./ekycTermination/ekycTermination.html'),
                controller: 'ekycTerminationCtrl'
            }
        }
    };

    


    $stateProvider
    .state(transactMasterState)
    .state(transactState)
    .state(redeemState)
    .state(switchState)
    .state(reviewState)
    .state(redeemReviewState)
    .state(txnDetailsState)
    .state(swpState)
    .state(swpReviewState)    
    .state(redeemTxnDetailsState)
    .state(stpState)
    .state(stpReviewState)
    .state(stpTxnDetailsState)
    .state(switchReviewState)
    .state(swpTxnDetailsState)
    .state(switchTxnDetailsState)
    .state(buyState)
    .state(buyReviewState)
    .state(buyTxnDetailsState)
    .state(sipState)
    .state(sipReviewState)
    .state(sipTxnDetailsState)
    .state(modifySipState)
    .state(modifySipTxnDetailsState)
    .state(ekycRegState)
    .state(ekycForm)
    .state(newFolioRNewInvestor)
    .state(DTPReviewState)
    .state(kycAdditionalDtlsState) 
    .state(ekycTerminationState)
    
    ;

}

transactRoutes.$inject = ['$stateProvider'];
module.exports = transactRoutes;