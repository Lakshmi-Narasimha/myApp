define([
    'lodash',
    'app/common/analytics',
    'app/application/app',
    'config'
], function (_, analytics, app, Config) {

    var ErrorUtils = function () {
        "use strict";

        // private functions
        var numberOfErrorsLogged = 0;

        // private functions
        function getNumberOfErrorsLogged() {
            return numberOfErrorsLogged;
        }


        var self = this;

        this.loggingConfig = {
            loggingToConsole: Config.enableErrorLogging,
            loggingLevel: Config.loggingLevel
        };

        // General error message object
        this.generalErrMsgs = {
            defaultMsg: "We experienced some issues while retrieving this information.",
            serviceFilure: "We experienced some issues while retrieving this information.",
            systemUnavailableErrorMessage: "System unavailable"
        };

        // Available default options for error object
        this.defaultOptions = {
            resource: null,
            id: null,
            PeopleSoftId: null,
            log: {
                type: null,
                info: null,
                location: null,
                stack: {
                    request: null,
                    requestData: null,
                    response: null,
                    httpCode: null,
                    clientStackTrace: null,
                    isClientSide: null
                }
            }
        };
        // Parse the error object that thrown from web service
        // failures
        this.prepareAndLogError = function (errObj, errorResource, requestUrl, requestData) {
            var theErrorResource;
            theErrorResource = errorResource ? errorResource : analytics.sessionAnalytics.currentPage;

            var myValues = {
                resource: theErrorResource,
                type: 'ERROR',
                info: 'Service Error',
                location: analytics.sessionAnalytics.currentPage,
                request: '',
                requestData: '',
                response: '',
                httpCode: '',
                clientStackTrace: '',
                isClientSide: false
            };

            try {
                myValues.request = requestUrl ? requestUrl : '';
                myValues.requestData = requestData ? requestData : {};
                if (errObj && errObj.httpResponse) {
                    var _data = (typeof errObj.httpResponse.data === "object") ? JSON.parse(JSON.stringify(errObj.httpResponse.data))
                            : errObj.httpResponse.data;
                    _data = (typeof _data == "string") ? JSON.parse(_data) : _data;
                    myValues.response = _data.error.message.value;
                    myValues.httpCode = errObj.httpResponse.status;
                    myValues.clientStackTrace = JSON.stringify(_data);
                } else if (errObj && errObj.responseJSON) {
                    //for normal jquery ajax calls
                     _data = errObj.responseJSON;
                    myValues.response = _data ? (_data.error ? (_data.error.message ? _data.error.message.value : "") : "") : "";
                    myValues.httpCode = errObj.status;
                    myValues.clientStackTrace = JSON.stringify(_data);
                } else if (errObj && errObj.responseText) {
                     _data = errObj.responseText;
                    myValues.response = _data ? (_data.error ? (_data.error.message ? _data.error.message.value : "") : "") : "";
                    myValues.httpCode = errObj.status;
                    myValues.clientStackTrace = _data;
                } else if (errObj && errObj.statusText) {
                     _data = errObj.statusText;
                    myValues.response = _data;
                    myValues.httpCode = errObj.status;
                    myValues.clientStackTrace = _data;
                } else {
                    // for other calls - like ajax calls to the OBO Servlet
                    // nothing to do here.
                }
            } catch (err) {
                this.logErrors(err);
            }

            self.logMessage(myValues.resource, myValues.type, myValues.info, myValues.location, myValues.request, myValues.requestData, myValues.response, myValues.httpCode, myValues.clientStackTrace, myValues.isClientSide);
        };

        // Method to register window onerror event
        // AUDIT-IGNORE-WINDOW-REF-RULE
        this.registerWindowErrorEvent = function () {
            if (typeof window.onerror != "function") {
                window.onerror = this.handleWindowError;
            }
        };
        // Window onerror handler
        this.handleWindowError = function (errorMsg, source, lineno, colno, stack) {
            self.logMessage(analytics.sessionAnalytics.currentPage, 'ERROR', errorMsg, analytics.sessionAnalytics.currentPage, '', '', '', stack.stack, true);
        };

        // Create a new warning type message and log it.
        this.logWarning = function (myResource, myLogInfo, myLocation, myRequest, myResponse, myHttpCode, myClientStackTrace, myIsClientSide) {
            this.logMessage(myResource, 'WARN', myLogInfo, myLocation, myRequest, myResponse, myHttpCode, myClientStackTrace, myIsClientSide);
        };

        // Create a new messaging object and log it.
        this.logMessage = function (myResource, myType, myLogInfo, myLocation, myRequest, myRequestData, myResponse, myHttpCode, myClientStackTrace, myIsClientSide) {

            var tempStack = {
                request: myRequest,
                requestData: myRequestData,
                response: myResponse,
                httpCode: myHttpCode,
                clientStackTrace: myClientStackTrace,
                isClientSide: myIsClientSide
            };
            var tempLog = {
                type: myType,
                info: myLogInfo,
                location: myLocation,
                stack: tempStack
            };
            var tmpErrObj = {
                id: app.userInformation ? app.userInformation.fmid: '',
                PeopleSoftId: app.userInformation ? app.userInformation.peopleSoftId || '' : '',
                resource: myResource,
                log: tempLog
            };
            self.logErrors(tmpErrObj);
        };

        // Master method for logging the errors and show required
        // info to the user
        this.logErrors = function (options) {
            //to avoid the javascriipt error in loggingIsEnbaled method
            if (!options.log) {
                options.log = {type: "ERROR"};
            }
            options = _.extend(this.defaultOptions, options);
            messageToRightSize(options);
            if (self.loggingConfig.loggingToConsole === true) {
                console.log(JSON.stringify(options));
            }
            numberOfErrorsLogged++;
            // Send error to the server
            new Image().src = "images/remote-error-logging.ico?error_message="
                    + encodeURIComponent(JSON.stringify(options)
                            .replace(/'/g, "\\'").replace(/"/g, "'"));

        };

        this.registerWindowErrorEvent();
    };


    // private functions
    // Method to ensure that the total length of the input error message is not
    // greater than the max length permissible for a Get Message send.
    function messageToRightSize(message) {
        var maxGetMessageSize, stringifiedMessage;
        maxGetMessageSize = 2040;   // max is 2048 but make it 2040 to eliminate any boundary conditions
        stringifiedMessage = JSON.stringify(message);
        if (stringifiedMessage.length > maxGetMessageSize) {
            var charsToRemove = stringifiedMessage.length - maxGetMessageSize;
            // take it from the client stack trace if possible
            if (message.log.stack.clientStackTrace.length > charsToRemove) {
                message.log.stack.clientStackTrace = message.log.stack.clientStackTrace.substring(0, message.log.stack.clientStackTrace.length - charsToRemove);
            } else { // eliminate the entire stack portion of the message - the rest of the message is surely small enough
                message.log.stack = null;
            }
        }
    }

    // returning a singleton instance
    return new ErrorUtils();

}); // helper function close
