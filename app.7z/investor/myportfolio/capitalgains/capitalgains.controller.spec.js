'use strict';
describe('Controller: account view controller', function() {
    var $controller, $scope, event, $state, CapitalGainsController, fticgAccDetLoadInitialService, myportfolioConstants, investorEventConstants, invInstantMailback, timeout;
    
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _$state_, _fticgAccDetLoadInitialService_, _myportfolioConstants_, _invInstantMailback_, _investorEventConstants_, $timeout) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        $state = _$state_;
        event = document.createEvent("MouseEvent");
        event.initMouseEvent("click", true, true);
        fticgAccDetLoadInitialService = _fticgAccDetLoadInitialService_;
        investorEventConstants = _investorEventConstants_;
        myportfolioConstants = _myportfolioConstants_;
        invInstantMailback = _invInstantMailback_;
        $state.$current.data = {
            'viewFlag': myportfolioConstants.flagOptions.FOLIO_FLAG
        }
        CapitalGainsController = $controller('CapitalGainsController', { $scope: $scope });
    }));

    it('should expect dashboard controller to be defined', function() {
        expect(CapitalGainsController).toBeDefined();
    });

    it('should load initial services is called on load and services data is available', function() {
        expect(fticgAccDetLoadInitialService._isInitialLoad).toBeFalsy();
        expect($scope.appName).toBe('Investor');
        expect($scope.navPillsOptions[0].btnName).toBe('Folio View');
        expect($scope.navPillsOptions[0].uibValue).toBe('folioview');
        expect($scope.btnColor).toBe('btn-group-sm green-btn-group pull-left');
        expect($scope.modelVal).toBe('folioview');
        expect($scope.viewFlag).toBe('F');
    });

    it('should trigger initial services when services data is not available', function() {
        var modelVal = 'accountview';
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('changeNavCgPill', modelVal);
        expect($scope.$broadcast).toHaveBeenCalledWith('changeNavCgPill', modelVal);
        expect($scope.modelVal).toBe('accountview');
    });

    it('should trigger pillSelect for state transition', function() {
        var param = 'folioview';
        spyOn($scope, 'pillSelect');
        $scope.pillSelect(event, param);
        expect($scope.pillSelect).toHaveBeenCalledWith(event, param);
        expect($scope.viewFlag).toBe('F');
        spyOn($state, 'go');
        expect($state.go).toHaveBeenCalledWith('capitalgains.folioview');
    });

    it('should trigger investor mailback success', function() {
        var data = {
            'type': 'F'
        };
        var params = {
            'options': [myportfolioConstants.overview.optionCode],
            'formats': [data.type],
            'flag': $scope.viewFlag
        }
        spyOn($scope, '$broadcast').and.callThrough();
        $scope.$broadcast('invMailbackSuccess', data);
        expect($scope.$broadcast).toHaveBeenCalledWith('invMailbackSuccess', data);
        invInstantMailback.postInstantMailBackDetails(params).then(function(result) {
                expect(result).toBeDefined();
        });
    });
});
