'use strict';

var overviewInitialLoaderService = function (overviewModel, advisorEvents, advisorEventConstants) {

    var overviewInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope) {           

            overviewModel.fetchOverviewDtls()
                .then(overviewSuccess, handleFailure);

            function overviewSuccess(data) {
                overviewModel.setOverviewDtls(data[0]);
                advisorEvents.smartSolutions.publishOverview(scope,overviewModel.getOverviewDtls());

            }
        },
        getFundCompositionDetails: function(scope, queryObj){
            overviewModel.getFundCompositionDetails(queryObj)
            .then(fundCompositionDetailsSuccess, handleFailure);

            function fundCompositionDetailsSuccess(data){
                overviewModel.setFundCompositionDetails(data);
                advisorEvents.salesOverview.detailedFundComposition(scope);
            };

        },
    };
    function handleFailure(data){
        console.error('handleFailure');
        overviewInitialLoader._isServicesData = false;
    }
    return overviewInitialLoader;

};

overviewInitialLoaderService.$inject = ['overviewModel', 'advisorEvents', 'advisorEventConstants'];

module.exports = overviewInitialLoaderService;