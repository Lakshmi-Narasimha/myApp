'use strict';
describe('Controller: PanViewController panview controller', function() {
    var $controller, $scope, PanViewController, mockpanViewInitialLoader, panViewModel, timeout, state, httpBackend, $window, stateParams;
    beforeEach(angular.mock.module('investor'));
    beforeEach(angular.mock.module('investor.myportfolio'));
    beforeEach(angular.mock.inject(function(_$controller_, $rootScope, _$window_, panViewModel, _$httpBackend_, $timeout, panViewInitialLoader, $state, $stateParams) {
        $controller = _$controller_;
        $scope = $rootScope.$new();
        timeout = $timeout;
        httpBackend = _$httpBackend_;
        mockpanViewInitialLoader = panViewInitialLoader;
        panViewModel = panViewModel;

        $window = _$window_;
        state = $state;
        stateParams = $stateParams;
        $window.ga = function() {};
        //httpBackend.expectGET('http://localhost:3000/clients/clientStatement').respond({success: true});
        //httpBackend.flush();
        PanViewController = $controller('PanViewController', { $scope: $scope });       

    }));

    it('should expect PanViewController to be defined', function() {
        expect(PanViewController).toBeDefined();
    });

    it('panVM should be defined on $scope', function(){
        expect($scope.panVM).toBeDefined();
    });

    it('should call function "showFolioView" when we trigger showFolioView', function(){
        var testAgr = false;
        $scope.$on('changeNavPill', function(folioview){
            testAgr = true;
        });
        spyOn(state, 'go');
        $scope.$broadcast('showFolioView', 123);
        expect(testAgr).toEqual(true);
        expect(state.go).toHaveBeenCalled();
    });

    it('testing the event "apply" should call when we trigger it', function(){        
        spyOn(mockpanViewInitialLoader, 'loadAllServices');
        $scope.$broadcast('apply');
        expect($scope.panVM.showData).not.toBeTruthy();
        expect(mockpanViewInitialLoader.loadAllServices).toHaveBeenCalled();
    });    
    
    it('should call function "showAccountView" when we trigger showAccountView', function(){
        var testAgr = false;
        $scope.$on('changeNavPill', function(folioview){
            testAgr = true;
        });
        spyOn(state, 'go');
        $scope.$broadcast('showAccountView', 123);
        expect(testAgr).toEqual(true);
        expect(state.go).toHaveBeenCalled();
    });

    it('should call function "myPortfolioPanView" when we trigger myPortfolioPanView', function(){
        $scope.$broadcast('myPortfolioPanView');
        expect($scope.panVM.showData).toBeTruthy();
    });
});
