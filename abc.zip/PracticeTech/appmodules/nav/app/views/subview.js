define([
  'jquery',
  'underscore',
  'backbone',
   'text!appmodules/nav/app/templates/sub.html',  
], function ($, _, Backbone, SubTmpt, NavContext) {
    var submasterview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
        },
        initialize: function () {
            
        },
        render: function (e, fmId) {          
            var tmpTemplate = _.template(SubTmpt);
            this.$el.html(tmpTemplate);           
        },
    });
    return submasterview;
});
