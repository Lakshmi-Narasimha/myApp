define(function () {

    /*
         The MIT License (MIT)

         Canonicalizer.js

         Copyright (c) 2013 Summit Hill Software. All rights reserved.

         Permission is hereby granted, free of charge, to any person obtaining a copy
         of this software and associated documentation files (the "Software"), to deal
         in the Software without restriction, including without limitation the rights
         to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
         copies of the Software, and to permit persons to whom the Software is
         furnished to do so, subject to the following conditions:

         The above copyright notice and this permission notice shall be included in
         all copies or substantial portions of the Software.

         THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
         IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
         FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
         AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
         LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
         OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
         THE SOFTWARE.

     Creates a canonical string representation of the object which can be used for comparison or subsequent hash creation.
     The object will be deeply recursed to find all objects.
     Circular references are handled automatically (an object will not be re-visited once it has been handled).
     Thread-safe (designed to be a singleton)

     */

    var Canonicalizer = function () {
        /*
         Return a canonical string of the object.
         Undefined properties are skipped.
         options: {
         treatNullAsUndefined: boolean  By default NULL properties will be written.  To treat nulls like undefined specify treatNullAsUndefined
         treatEmptyStringsAsUndefined: boolean  By default empty string properties will be written.  To treat empty strings like undefined specify treatEmptyStringsAsUndefined
         <propertyName>: boolean   By default all other properties of an object are navigated.  To ignore a certain property add it to the options with value of true.
         */

        this.toCanonicalString = function (object, options) {
            var allProps = [];
            var visitedObjects = [];
            pushObject(object, allProps, options == null ? {} : options, 0, visitedObjects);
            return allProps.join("");
        };

        this.toCanonicalEscapedString = function (object, options) {
            return encodeURIComponent(this.toCanonicalString(object, options));
        };

        function pushObject(obj, allProps, options, level, visitedObjects) {
            if (typeof obj == 'object' && obj != null) {
                var visitedReference = getVisitedReference(obj, visitedObjects);
                if (visitedReference) {
                    allProps[allProps.length] = visitedReference;
                } else {
                    visitedObjects.push(obj);
                    var props = [];
                    for (var prop in obj) {
                        props.push(prop);
                    }
                    props = props.sort();
                    for (var i = 0; i < props.length; i++) {
                        var childObj = obj[props[i]];
                        if (shouldPush(childObj, options, props[i])) {
                            allProps[allProps.length] = '\n';
                            for (var j = 0; j < level; j++) {
                                allProps[allProps.length] = '.';
                            }
                            allProps[allProps.length] = props[i];
                            allProps[allProps.length] = ':';
                            pushObject(childObj, allProps, options, level + 1, visitedObjects);
                        }
                    }
                }
            } else {
                allProps[allProps.length] = obj == null ? 'null' : obj;
            }
        }

        function shouldPush(value, options, propName) {
            if (propName && options[propName]) {
                return false;
            } else if (typeof value == 'function' || value === undefined) {
                return false;
            } else if (options.treatNullAsUndefined && value === null) {
                return false;
            } else if (options.treatEmptyStringsAsUndefined && value == '') {
                return false;
            }
            return true;
        }

        function getVisitedReference(object, visitedObjects) {
            for (var i = 0; i < visitedObjects.length; i++) {
                if (visitedObjects[i] === object) {
                    return '@REF' + i;
                }
            }
            return null;
        }

    };

    return new Canonicalizer();

});