// getDividendDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var financilalTransactionModelSchema = new mongoose.Schema({
    financialTransactionDetailsResp: {
        type: Array,
        "default": []
    }
});

var financilalTransactionModelLookUp = mongoose.model('financilalTransactionModelLookUp', financilalTransactionModelSchema);

var financilalTransactionModel = new financilalTransactionModelLookUp({
    financialTransactionDetailsResp : {
      "folioId": "CNLQO9184Z",
      "distId": "",
      "retrieveTxns": [
        {
          "trxnType": "Purchase",
          "source": "MFU",
          "firstHolderName": "AARIF NASIRUDDIN TEJAS PAREKH RAMACHANDRA BAINDOOR",
          "folioId": "17939601",
          "accountNo": "",
          "fund": "Franklin India BLUECHIP FUND - Direct",
          "amount": "",
          "reportedDate": "04 NOV 2016",
          "processedDate": "04 NOV 2016",
          "status": "Completed"
        },
        {
          "trxnType": "Purchase",
          "source": "MFU",
          "firstHolderName": "AARIF NASIRUDDIN TEJAS PAREKH RAMACHANDRA BAINDOOR",
          "folioId": "17939601",
          "accountNo": "4199904968992",
          "fund": "",
          "amount": "15000",
          "reportedDate": "04 NOV 2016",
          "processedDate": "04 NOV 2016",
          "status": "Processed"
        },
        {
          "trxnType": "Purchase",
          "source": "",
          "firstHolderName": "AARIF NASIRUDDIN TEJAS PAREKH RAMACHANDRA BAINDOOR",
          "folioId": "17939601",
          "accountNo": "4199904968992",
          "fund": "Franklin India BLUECHIP FUND - Direct",
          "amount": "15000",
          "reportedDate": "04 NOV 2016",
          "processedDate": "04 NOV 2016",
          "status": "Rejected"
        },
        {
          "trxnType": "",
          "source": "MFU",
          "firstHolderName": "AARIF NASIRUDDIN TEJAS PAREKH RAMACHANDRA BAINDOOR",
          "folioId": "17939601",
          "accountNo": "4199904968992",
          "fund": "Franklin India BLUECHIP FUND - Direct",
          "amount": "15000",
          "reportedDate": "04 NOV 2016",
          "processedDate": "",
          "status": "Clarification"
        },
        {
          "trxnType": "Purchase",
          "source": "MFU",
          "firstHolderName": "AARIF NASIRUDDIN TEJAS PAREKH RAMACHANDRA BAINDOOR",
          "folioId": "17939601",
          "accountNo": "4199904968992",
          "fund": "Franklin India BLUECHIP FUND - Direct",
          "amount": "15000",
          "reportedDate": "",
          "processedDate": "04 NOV 2016",
          "status": "Processed"
        }
      ]
    }
});

financilalTransactionModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating financilalTransactionModelLookUp table, please contact admin...');
    } else {
        financilalTransactionModelLookUp.remove({}, function(err) {
            console.log('financilalTransactionModelLookUp collection removed');
            financilalTransactionModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating financilalTransactionModelLookUp table, please contact admin...');
                }
                console.log('financilalTransactionModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = financilalTransactionModelLookUp;
