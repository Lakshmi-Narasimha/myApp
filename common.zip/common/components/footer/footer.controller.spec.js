/* eslint-disable */
/**
 * @ngdoc property
 * @name footer Controller spec
 * @requires $scope
 * @requires constants
 * @description
 *
 * - Unit test suite for 'footer.controller.spec.js'.
 *
 **/
'use strict';

describe('footercontroller spec', function() {

    var $scope, 
        footerCtrl,
        advisorConstants,
        $httpBackend,
        timeout,
        $q,
        deferred,
        footerData;

        // Setting the Mock data for Footer
        footerData = {
		   "footer":[
		      {
		         "footerLinks":[
		            {
		               "text":"Careers",
		               "url":""
		            },
		            {
		               "text":"Media",
		               "url":""
		            },
		            {
		               "text":"Feedback",
		               "url":""
		            },
		            {
		               "text":"Reports",
		               "url":""
		            },
		            {
		               "text":"Risk Factors",
		               "url":""
		            },
		            {
		               "text":"Terms & Conditions",
		               "url":""
		            },
		            {
		               "text":"Disclaimer",
		               "url":""
		            },
		            {
		               "text":"Security & Privacy ",
		               "url":""
		            },
		            {
		               "text":"Help",
		               "url":""
		            }, 
		            {
		               "text":"Anti Corruption Policy",
		               "url":""
		            },
		            {
		               "text":"Voting Policy",
		               "url":""
		            },
		             {
		               "text":"Disclosure of Voting",
		               "url":""
		            }
		           
		         ],
		         "footerIconLinks":[
		            {
		               "icon":"icon-fti_facebook"
		            },
		            {
		               "icon":"icon-fti_twitter"
		            },
		            {
		               "icon":"icon-fti_youtube"
		            },
		            {
		               "icon":"icon-fti_linkedin"
		            }
		         ],
		         "footerLogo":[
		            {
		               "image":"images/fti_footer_logo.jpg",
		               "alt":"Franklin Templeton Logo"
		            }
		         ],
		         "copyRight":[
		            {
		               "text":"Franklin Templeton Investments",
		               "year":"1999-2016",
		               "link":""
		            }
		         ]
		      }
		   ]
		};
    beforeEach(angular.mock.module('advisor'));

    beforeEach(function() {

        angular.mock.inject(function($controller, $rootScope,_$httpBackend_, $timeout) {
            $scope = $rootScope.$new();
            $httpBackend = _$httpBackend_;
            timeout = $timeout;
            footerCtrl = $controller('footerCtrl', {
                $scope: $scope
            });
        });

    });

    it('footerCtrl controller should be defined', function() {
        expect(footerCtrl).toBeDefined();
        expect($scope).toBeDefined();
    });
    it('Compare the data which is retrieved from json with the mock data', function(){
		//Faking ga function from google analytics
		window.ga = function(){
			return true;
		}
    	var url = 'jsonservices/footer.json';
    	var res = $httpBackend.whenGET(url).respond(200,footerData);
    	$httpBackend.flush();

    	expect($scope.footerCopyright.text).toEqual(footerData.footer[0].copyRight[0].text);
    	//Comparing the footerLinks data with mock data
    	angular.forEach($scope.footerLinks, function(data,key){
    		expect(data.text).toEqual(footerData.footer[0].footerLinks[key].text);
    	});
    	//Comparing the footerIconLinks data with mock data
    	angular.forEach($scope.footerIconLinks, function(data,key){
    		expect(data.icon).toEqual(footerData.footer[0].footerIconLinks[key].icon);
    	});
    	//Comparing the footerIconLinks data with mock data
    	expect($scope.footerLogo.image).toEqual(footerData.footer[0].footerLogo[0].image);
    });
});