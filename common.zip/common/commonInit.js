/**
*@ngdoc overview
*@name commoninit
*@description
* <p>
* To define application state events and checks the authorization at stateChangeStart.
* </p>
* @requires Restangular
* @requires $state
* @requires $rootScope
* @author DEE | Digital Engagement Practice
*/



'use strict';

function commonInit($rootScope, $state, Restangular, Angularytics, appConfig, configUrlModel, authenticationService) {
    $rootScope.$state = $state;

    // To set common url for connecting the backend/apis
    var configURL = configUrlModel.getEnvUrl('AUTH_REST_ENDPOINT_BASEURL');
    Restangular.setBaseUrl(appConfig[configURL]);
    // Set bodyClasses, pageTitle, and pageDescription on state change (ui-router)
    
    $rootScope.$on('$stateChangeSuccess', function(event, toState) {
        authenticationService.innerClick = false;
        if (toState.data && angular.isDefined(toState.data.pageTitle)) {
            $rootScope.pageTitle = toState.data.pageTitle;
            $rootScope.pageDescription = toState.data.pageDescription;
            $rootScope.bodyClasses = toState.data.moduleClasses + ' ' + toState.data.pageClasses;
        }

    });


    // Make sure the page scrolls to the top on all state transitions
    $rootScope.$on('$viewContentLoaded', function() {
        authenticationService.innerClick = false;
        if (document.readyState === 'complete') {
            window.scrollTo(0, 0);
        }
    });

    // Proper Regex Pattern for email input form validation
    /*
    * Commented because not used anywhere
    * Suresh P 12/10/2016
    */
    // $rootScope.emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    Angularytics.init();
}

commonInit.$inject = ['$rootScope', '$state', 'Restangular', 'Angularytics', 'appConfig', 'configUrlModel', 'authenticationService'];
module.exports = commonInit;