define([
], function () {
    var config = {
        awmServicePath:  location.origin + '/ods.svc/',
		oboServicePath: location.origin + '/adv_capl/oboselector/',

        virtualizedServicePath: 'https://eformsaar.dev.advisorcompass.com/virtualization/',
        virtualizedServicePatterns: [],   // regexes for services that should be routed to virtualization
        sendAnalyticsToOmniture: false,
        enableAnalyticsConsoleLogging: false,
        omnitureSAccount: "amppracviewerdev",
        enableErrorLogging: false,
		consumerId: "id=A0056064-7K9N1TN58FEYCUDK;type=WEB",
        disableDrafts: false
    };

    return config;
    
});