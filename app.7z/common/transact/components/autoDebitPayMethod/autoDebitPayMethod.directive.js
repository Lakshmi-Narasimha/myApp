/**
 * @ngdoc property
 * @name fticPaymentDateOptions Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Period, Start date and End date options.
 *
 **/
'use strict';

var fticAutoDebitPayMethod = function (bankDtlsModel, $stateParams, transactModel, TransactConstant, authenticationService, paperlessModel, ifscModel, $timeout, paymentDetailsUtility) {
    return {
        template: require('./autoDebitPayMethod.html'),
        restrict: 'E',
        replace: true,
        scope: {
            parentForm: '='
        },
        controller:['$scope', function ($scope) {
            $scope.ifscRequired = true;
            $scope.ifscTextField = "ifscTextField";
            $scope.ifscCode = null;
            $scope.isNewInvestor = transactModel.isNewInvestor;
            $scope.isNewFolio = transactModel.getIsNewFolio();
            $scope.showAutoBankError = false;
            $scope.method = {};
            $scope.method.autoDebitSel = null;

            $scope.formDetails = {
                paymentForm: $scope.parentForm
            };

            $scope.autoDebitBankOptions = [
                {
                    title: TransactConstant.transact.SELECT_BANK, 
                    key : 'select'
                }
            ];

            $scope.ifsc = {
                ifscCode : ''
            };

            var transactType = transactModel.getTransactType(),
                txnType = null,
                autoDebitBanks = [];

            if(transactType === TransactConstant.sip.SIP || transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.renewSip.RENEWSIP) {
                $scope.isSIP = true;
                 txnType = TransactConstant.sip.SIP;
            } else if(transactType === TransactConstant.buy.BUY || transactType === TransactConstant.buy.BUYFUND) {
                $scope.isBuy = true;
                txnType = "P";
            } else if(transactType === TransactConstant.modifySip.MODIFYSIP) {
                $scope.isModifySIP = true;
                txnType = "MSIP";
            }

            if(!$scope.isNewInvestor && !$scope.isNewFolio){
                //Populate Auto Debit Banks
                if(bankDtlsModel.getBankDetails()) {
                    var bankDtls = bankDtlsModel.getBankDetails().emandate;
                    if(bankDtls) {                        
                        for(var i=0; i<bankDtls.length; i++) {
                            if(bankDtls[i].paymentType === 'M') {
                                $scope.autoDebitBankOptions.push({title: bankDtls[i].pbBankName + '-' + bankDtls[i].pbPersonalAccountNumber, key : bankDtls[i].pbPersonalAccountNumber, refNo : bankDtls[i].achRefNo, bankName : bankDtls[i].pbBankName});
                                autoDebitBanks.push(bankDtls[i]);
                            }
                        }
                    }
                }
            }

            $scope.$on('autoDebitChanged', function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                var payMethod = bankDtlsModel.getFutureInstPayMethod() || bankDtlsModel.getPaymentMethod();                    

                if(bankDtlsModel.getBankDetails() && data.key !== 'select') {
                    $scope.showAutoBankError = false;
                    if(bankDtlsModel.getIsMultiPayMode()) {
                        bankDtlsModel.setFutureInstBank(data.title);
                    } else {
                        paymentDetailsUtility.setPayment(autoDebitBanks, data);
                    }
                    $scope.$emit('bankChanged', data);
                    $scope.$broadcast('bankSelected', data);
                } else if(payMethod.toString() === TransactConstant.transact.AUTO_DEBIT && data.key === 'select') {
                   $scope.showAutoBankError = true;
                }
                bankDtlsModel.setIsAutoBankError($scope.showAutoBankError);
            });

            $scope.ifscDetails = {};
            $scope.$on('ifscSrchRes', function(){
                $scope.showBranchDetails = false;
                $scope.ifscDetails = ifscModel.getIfscGridResDet();
                $scope.branchName = $scope.ifscDetails.bankDetails;
                $scope.branchAddress = $scope.ifscDetails.bnkAdd;
                $scope.ifscCode = $scope.ifscDetails.ifscCode;

                bankDtlsModel.setIfscCode($scope.ifscCode);
                bankDtlsModel.setBranchName($scope.branchName);
                bankDtlsModel.setBranchAddress($scope.branchAddress);
                if($scope.ifscCode) {
                    $scope.showBranchDetails = true;
                }
            });

            //Save previous selected bank
            function saveAutoDebitOptions(){
                var selectedBank = bankDtlsModel.getFutureInstBank();
                for(var i=0; i<$scope.autoDebitBankOptions.length; i++) {
                    if($scope.autoDebitBankOptions[i].title === selectedBank) {
                        $scope.method.autoDebitSel = $scope.autoDebitBankOptions[i];
                    }
                }
                $scope.ifsc.ifscCode = bankDtlsModel.getIfscCode();
                $timeout(function(){
                    $scope.ifsc.ifscCode = bankDtlsModel.getIfscCode();
                    if($scope.ifsc.ifscCode) {
                        $scope.branchName = bankDtlsModel.getBranchName();
                        $scope.branchAddress = bankDtlsModel.getBranchAddress();
                        $scope.showBranchDetails = true;
                    }
                }, 0);
            }

            //For Transact Module
            if($stateParams.key === TransactConstant.transact.Payment_Key) {
                $scope.showAutoBankError = false;
                bankDtlsModel.setIsAutoBankError(false);
                saveAutoDebitOptions();
            }

            //For Paperless Module
            if(paperlessModel.paymentDtls.hasData) {
                saveAutoDebitOptions();
            }
        }]
    };
};

fticAutoDebitPayMethod.$inject = ['bankDtlsModel', '$stateParams', 'transactModel', 'TransactConstant', 'authenticationService', 'paperlessModel', 'ifscModel', '$timeout', 'paymentDetailsUtility'];
module.exports = fticAutoDebitPayMethod;