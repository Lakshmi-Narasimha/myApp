/**
 * @ngdoc factory
 * @name commonUtils
 * @description
 *
 * - This factory provides utilty methods
 *
 */

'use strict';

var commonUtils = function($window, $sce) {
    return {
        convertBase64ToBlob: function(b64Data, type, size) {
            var contentType = type || '';
            var sliceSize = size || 512;
            b64Data = b64Data.replace(/\s/g, '');
            var byteCharacters = atob(b64Data);
            var byteArrays = [];

            for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                var slice = byteCharacters.slice(offset, offset + sliceSize);

                var byteNumbers = new Array(slice.length);
                for (var i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }

                var byteArray = new Uint8Array(byteNumbers);

                byteArrays.push(byteArray);
            }

            var blob = new Blob(byteArrays, { type: contentType });
            return blob;
        },
        downloadPdf: function(base64Response) {
            var file = this.convertBase64ToBlob(base64Response, 'application/pdf');
            var fileURL = $window.URL.createObjectURL(file);
            var resourceUrl = $sce.trustAsResourceUrl(fileURL);
            window.open(resourceUrl, '_blank');
        }
    };
};

commonUtils.$inject = ['$window', '$sce'];
module.exports = commonUtils;
