export declare function OnChange(defaultValue?: any): any;
