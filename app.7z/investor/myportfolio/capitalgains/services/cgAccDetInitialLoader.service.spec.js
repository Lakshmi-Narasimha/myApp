'use strict';

describe('factory: fticgAccDetLoadInitialService', function() {
	var cgAccDetModelMock,cgAccDetModelData,cgAccDetModelAccDetails,httpBackend,Restangular ,mockFticgAccDetLoadInitialService = null, $window;
   	
   	beforeEach(angular.mock.module('investor'));
	beforeEach(inject(function(_fticgAccDetLoadInitialService_,_cgAccDetModel_,$injector, _$httpBackend_, _Restangular_){
     	
     	mockFticgAccDetLoadInitialService=_fticgAccDetLoadInitialService_;
     	cgAccDetModelMock=_cgAccDetModel_;
     	 var $q = $injector.get('$q');
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
        cgAccDetModelData= { 
            'foliodet':[
                {
                'fundName': 'Franklin India Pension Plan-GROWTH',
                'accountNo': '0100007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-24 00:00:00.0',
                    'indexedVal': '8797.27'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '16 dec 2014',
                    'amount': '9791.1'
                },
                'capital': {
                    'shorterm': '993.83',
                    'longterm': '4791.089025'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }, {
                'fundName': 'Franklin India Pension Plan-DIVIDEND',
                'accountNo': '0110007823616',
                'purchase': {
                    'fundWiseData': null,
                    'txType': 'Purchase',
                    'txDate': '2008-06-24 00:00:00.0',
                    'indexedVal': '8797.26'
                },
                'redemption': {
                    'txType': 'Switch Out',
                    'txDate': '15 dec 2014',
                    'amount': '5795.55'
                },
                'capital': {
                    'shorterm': '-3001.71',
                    'longterm': '795.547104'
                },
                'taxded': {
                    'total': '',
                    'stt': '0'
                }
            }] };

cgAccDetModelAccDetails={
   'panFolioAccounts': [{
            'folioId': '17877097',
            'latestFolio': 'N',
            'folioAccounts': [
                '0549900759695'
            ]
        }]
    };
  
     }));
     it('should loadAllServices to be defined', function() {
        expect(mockFticgAccDetLoadInitialService.loadAllServices).toBeDefined(); 
    });
      it('should getcgaccountdetails to be defined', function() {
        expect(mockFticgAccDetLoadInitialService.getcgaccountdetails).toBeDefined();
    });
       it('should getCgFolioDetails to be defined', function() {
        expect(mockFticgAccDetLoadInitialService.getCgFolioDetails).toBeDefined();
    });
	   describe('Services: should be successfully load initial capital gains service', function() {
	   		beforeEach(inject(function(_fticgAccDetLoadInitialService_, $injector, _$window_) {
	   			mockFticgAccDetLoadInitialService=_fticgAccDetLoadInitialService_;
            	var $q = $injector.get('$q');

                httpBackend.expectGET('http://localhost:3030/clients/capitalGain?flag=F&guId=878').respond(cgAccDetModelData);
                $window = _$window_;
                $window.ga = function() {};
	   		}));


	   		it('should respond with valid data for successfully CgFolioDetails', function() {
             
                mockFticgAccDetLoadInitialService.getCgFolioDetails({
                    '$emit': function() {
                        return true;
                    }
                },{});
                httpBackend.flush();
                expect(cgAccDetModelMock.getCgFoliodetails().length).toEqual(2);
            });

	   })

      describe('Services: should be successfully load initial capital gains service', function() {
        beforeEach(inject(function(_fticgAccDetLoadInitialService_, $injector, _$window_) {
            mockFticgAccDetLoadInitialService=_fticgAccDetLoadInitialService_;
                var $q = $injector.get('$q');

            httpBackend.expectGET('http://localhost:3030/clients/folioAccounts?guId=878').respond(cgAccDetModelAccDetails);
            $window = _$window_;
            $window.ga = function() {};
        }));


        it('should respond with valid data for successfully CgAccountDetails', function() {
             
            mockFticgAccDetLoadInitialService.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            },{});
            httpBackend.flush();
            console.info("successfully"+cgAccDetModelMock.getFolioNumbersList())
            expect(cgAccDetModelMock.getFolioNumbersList().length).toEqual(1);
        });

     });
    describe('Services: should be successfully load initial capital gains service', function() {
        beforeEach(inject(function(_fticgAccDetLoadInitialService_, $injector, _$window_) {
            mockFticgAccDetLoadInitialService=_fticgAccDetLoadInitialService_;
                var $q = $injector.get('$q');

            httpBackend.expectGET('http://localhost:3030/clients/capitalGain?flag=A&guId=878').respond(cgAccDetModelData);
            $window = _$window_;
            $window.ga = function() {};
        }));


        it('should respond with valid data for successfully CgAccountDetail values', function() {
             
            mockFticgAccDetLoadInitialService.getcgaccountdetails({
                '$emit': function() {
                    return true;
                }
            },{});
            httpBackend.flush();
            console.info("successfully"+cgAccDetModelMock.getcgaccountdetails())
            expect(cgAccDetModelMock.getcgaccountdetails().length).toEqual(2);
        });

     })

});