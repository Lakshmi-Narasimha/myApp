/**
 * @ngdoc property
 * @name accountStmtModel
 * @requires Restangular
 * @requires $q
 * @description
 *
 * - accountStmeModel is a service model which consists the list of services required for Account statements in 
 *   Statements tab of my investors page.
 *
 **/
'use strict';


var bankAccountModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _invBankDetails = null;
    var _invImageUpload = null;
    var _invImageLength = null;
    var invBankAccDetails ={};
    var bankAccDetails = {
        getBankAccDetails: function() {
            invBankAccDetails.guId = authenticationService.getUser().guId;
            var deferred = $q.defer(); 
            Restangular.one('/accountSettings/basisBankAccDetails').get(invBankAccDetails).then(function(BankAccDetails) {
                deferred.resolve(BankAccDetails);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        setBasisBankDetails: function(bankdetails){
            console.log(bankdetails)
            _invBankDetails = bankdetails; 
        },
        getBasisBankDetails: function(){
            return _invBankDetails;
        },
        setImageData:function(imageData){
            _invImageUpload = imageData;
        },
        getImageData:function(){
            return _invImageUpload;
        },
        setImageLength:function(fileLength){
            _invImageLength = fileLength;
        },
        getImageLength:function(){
            return _invImageLength;
        },
        editBasisBankDetails : function (queryObj) {           
            var deferred = $q.defer();
            var end = '/accountSettings/BankAccEditDetails';            
            var params = {
                'guId' : authenticationService.getUser().guId,
                'strBankName' : queryObj.bankName,
                'strBankAccount' : queryObj.bankAccNo,
                'strCfrBankAccount' : queryObj.cfrBankAcc,
                'strIfscCode' : queryObj.ifscCode,
                'strImagesUploaded' : queryObj.imageUploaded
            }            
            console.log("params",params);
            Restangular.one(end).customPOST({}, "", params, {}).then(function (editBankAccDetails) {
                deferred.resolve(editBankAccDetails);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        }      
    };

    return bankAccDetails;

};

bankAccountModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = bankAccountModel;
