import { Component, OnInit, ViewChild } from '@angular/core';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Agent } from '../_models/index';
import { Intent } from '../_models/index';
import { ModalDirective } from 'ng2-bootstrap';

@Component({
  selector: 'intentdatacomponent',
  templateUrl: './intentdatacomponent.component.html',
  styleUrls: ['./intentdatacomponent.component.css']
})
export class IntentdatacomponentComponent implements OnInit {

  constructor(private aiAssistCacheService : AIAssistCacheService) { }

@ViewChild('removeIntentModal') public removeIntentModel:ModalDirective;
  ngOnInit() {
    this.subscriptions();
  }

  activeIntent : Intent;
  editMode : boolean = true;
  activeIntentName : string;

  private subscriptions() {
    this.aiAssistCacheService.activeIntentObservable.subscribe((data) => {
      //console.log("inside intentdatacomponent subscribe before -> data -> ");
      //console.log(data);
      // console.log("agentsList -->");
      // console.log(this.agentsList);
      //this.agentsList.length = 0;
      //this.agentsList.push.apply(this.agentsList, data);
      this.activeIntent = data;
      if ( this.activeIntent != null && this.activeIntent != undefined )
        this.activeIntentName = this.activeIntent.name;
      //console.log("agent group component");
      //console.log(this.activeAgentIntents);
      // console.log("inside agentcomponent subscribe after -> data -> ");
      // console.log(data);
      // console.log("agentsList -->");
      // console.log(this.agentsList);
    });
    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });
  }

  enableEdit() {
      if(this.editMode == false)
        this.aiAssistCacheService.setIntentEdit(true);
      else {
        if(this.activeIntent.name != this.activeIntentName.trim())
          this.aiAssistCacheService.saveEditChanges(this.activeIntentName.trim());
        else
          this.aiAssistCacheService.saveEditChanges(null);
        this.aiAssistCacheService.setIntentEdit(true);
      }
  }

  removeCurrentIntent() {
    this.aiAssistCacheService.removeActiveIntent();
    this.hideremoveIntentModal();
  }

  hideremoveIntentModal() {
    this.removeIntentModel.hide();
  }

}
