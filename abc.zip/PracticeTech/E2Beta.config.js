define([
], function () {
    var ebixServiceName = 'https://practicetech-02.qa.advisorcompass.com/contact-manager/svc/api/';
    var odataServiceName = 'https://practicetech-02.qa.advisorcompass.com/ods.svc/';   
    var oboservlet = 'https://practicetech-02.qa.advisorcompass.com/adv_capl/oboselector/OBOServlet';
    var SADServiceUrl = 'https://practicetech-02.qa.advisorcompass.com/draft/service/Draft/';
    var contactProfileURL = 'https://practicetech-02.qa.advisorcompass.com/contact-profile/index.html#navlanding';    
    var accountListURL = 'https://practicetech-02.qa.advisorcompass.com/account-viewer/index.html#navlanding';    
    var calendarURL = 'https://practicetech-02.qa.advisorcompass.com/contact-manager/index.html#navlanding';
    var defaultNavURL = 'https://practicetech-02.qa.advisorcompass.com/navigator/index.html';
    var isDevEnv = false;
    var contactListURL = 'https://practicetech-02.qa.advisorcompass.com/contactlist/index.html#contactlist';
    var ncstURL = 'https://practicetech-02.qa.advisorcompass.com/ncst/index.html#navlanding';
    var boxURL = 'https://e2ampf.app.box.com/login?continue_sso=true';
    var mmsystemURL = 'https://emms.qa.ameriprise.com/emms/';
    var technicalSupportURL = 'https://www.advisorcompass.com/web/advisorcompass/displaycontent?contID=730276&contType=AC-DeepContent';
    var contactManagerURL = 'https://ampf-e2b.ez-data.com/java/cdsApp?trustedWindow=1&Module=DeepLink&Object=Contact&Operation=View&contextid=';
    var efileDeliveryURL ='https://docdelivery.qa.advisorcompass.com/efile?contextid=';
    var eformsManagerURL = 'https://eforms.qa.advisorcompass.com/eforms/auth/eformscontroller?request_type=EFormsHome&contextid=';
    var newBusinessSetupURL ='https://eforms.qa.advisorcompass.com/eforms/auth/eformscontroller?request_type=EFormsHome&highlight_node=NewBusiness&contextid=';
    var opportunityManagerURL ='https://om2.qa.advisorcompass.com/omsadv/workbench/oppbyclientcallback?contextid=';
    var shareClassAnalyzerURL ='https://sca.qa.advisorcompass.com/mfsp/pages/FundPointPage.jsp?source=ClientList&contextid=';
    var morningstarAdvisorWorkstationURL ='https://aux.qa.advisorcompass.com/adv_aux/services/aws_launch/launch?WindowID=IatWindow&target_app=aws&contextid=';
    var teamingURL = 'https://practiceviewer.qa.advisorcompass.com/practiceviewer/';

    var totalviewNoOBOURL = 'https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=cashedge&OBODropDownRequired=true&source=advisorcompass';
    var totalviewURL = 'https://www28.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=cashedge&OBODropDownRequired=true&source=advisormobile&contextid=';
    var portfolioURL = 'https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=PMT&contextid=';
    var portfolio2URL = 'https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=PMT2&contextid=';
    var naviplanURL = 'https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=naviplanpremiumadv&OBODropDownRequired=true&contextid=';
    var confidentRetirementNoOBOURL = 'https://confidentret.qa.advisorcompass.com/retirement-income';
    var confidentRetirementOBOURL = 'https://confidentret.qa.advisorcompass.com/retirement-income/confident.html?contextid=';
    var shareDocumentToDoURL = 'https://collab2-a.qa.advisorcompass.com/collab/_layouts/15/ampfccapplicationcode/validate.html?ContextID=';
    var contactServiceOBOURL = 'https://contactservice.qa.ameriprise.com/occ/index.html?entryPoint=AM&contextId=';
    var eformNavTreeLink = 'https://eforms.qa.advisorcompass.com/eforms/auth/eformscontroller?request_type=TreeNavigationResults&documentIdentifier=2770&documentType=2&source=AdvPrtl';
    var dolImpactDashboardURL = 'https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/DOL%20Impact%20Dashboard.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed';

    var addBank = 'https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=mmsadd&contextid=';
    var updateBank = 'https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=mmssearch&contextid=';

    var t1URL = "https://app.thomsononeqa.com/?idpid=https%3A%2F%2Fssoiextraqa.ext.ampf.com%2F";
    var t1DomainName = "https://app.thomsononeqa.com";
	var consumerId = 'id=A0061097-B0GQB0GMKKH25KD2;type=WEB';
	//For PES
    //var consumerId = 'id=A0000000-SZD4WMA6VNLY3NO4;type=WEB';
    var ACDeepContentURL = "https://www.advisorcompass.com/web/advisorcompass/displaycontent?contID=749750&contType=AC-DeepContent";
    //only messages from the below url's will be responded to
    var urlWhiteList = ['https://practicetech-02.qa.advisorcompass.com'],NBSTMaxWaitTime=60000,NBSTCtxSrvcTimeIntrvl = 5000;
    var baseUri = '/app';
    var eSigConfig = {
    		docId : "197865",
    		signImgType : "jpg",
    		serviceUrl:"https://practicetech-02.qa.advisorcompass.com/esig/service/"
    		
    };


    var sendAnalyticsToOmniture = true;
    var omnitureSAccount = 'amppractechdev';
    var omnitureSharedSAccount = 'ampsharedpractechdev';
    // logging levels are WARN, PERF, and ERROR.  Entries are created for the level you set and
    // all those that follow it.  A level of PERF for example will create PERF and ERROR entries.
    var loggingLevel = 'ERROR';
    // writes all entries(except analytics) that are logged to the console as well as sending to the server.
    var enableConsoleLogging = false;
    // write analytics entries to the console
    var enableAnalyticsConsoleLogging = false;
    //Limit and timeout for contact list (applicable for both clients and prospect).
    var contactListLimit = 1000;
    var contactListTimeout = 500;//Milli seconds

    //Gomez Monitoring
    var monClientListSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/ClientLists(id='000030601',ctx='DMU.DIST',type='CAPLIST')/clientRefs?$inlinecount=allpages&$format=json&$top=1000";
    var monDistrbOverviewSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/getDistributorOverview?grpId=0010005010674&grpCtx=COLA.GRP&dstrId=000030601&dstrCtx=DMU.DIST&$format=json";
    var monClientActGrpsSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/Client(id='00100000000000015647367',ctx='COLA.CL')?$expand=activeGroups&$format=json";
    var monClientEmploymentSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/Client(id='00100000000000015647367',ctx='COLA.CL')/clientPersonal?$expand=employmentInfo,clientProductExpes&$format=json";
    var monClientCapRegSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/Client(id='00100000000000015647367',ctx='COLA.CL')/capabilityRegistrations?$expand=&$format=json";
    var monGroupsSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/Groups(id='0010005010674',ctx='COLA.GRP')?$expand=activeClients&$format=json";
    var monClientProfileListSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/ClientProfileListItems?$filter=clId eq '00100000000000015647367' and clCtx eq 'COLA.CL'";
    var monClientTaxContrbSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/ClientTaxContributionSummaries(clId='00100000000000015647367',clCtx='COLA.CL',txYr='2016')?$expand=acctTxCntbSummaries,acctTxCntbDetails&$format=json";
    var monClientDistSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/ClientTaxDistributionSummary(clId='00100000000000015647367',clCtx='COLA.CL',txYr='2016')?$expand=acctTxDstbSummaries,acctTxDstbDetails&$format=json";
    var monClientFiduciariesSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/ClientFiduciaries?$filter='grantorId' eq '00100000000000015647367' and 'grantorCtx' eq 'COLA.CL'&$format=json";
    var monAccountSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/Account(id='004000000000000091006601896',ctx='COLA.ACCT')?$expand=accountProduct,accountRegistration,accountIdentifier&$format=json";
    var monDistributorsSvc = "https://practicetech-02.qa.advisorcompass.com/ods.svc/Distributors(dstrId='000030601',dstrCtx='DMU.DIST')";

    //Ncst outage time 
    var ncstOutageTime = {
            "sunday": {
                "timerange": ["00:01-09:29"]
            },
            "monday": {
                "timerange": ["22:01-24:00"]
            },
            "tuesday": {
                "timerange": ["00:00-05:59", "22:01-24:00"]
            },
            "wednesday": {
                "timerange": ["00:00-05:59", "22:01-24:00"]
            },
            "thursday": {
                "timerange": ["00:00-05:59", "22:01-24:00"]
            },
            "friday": {
                "timerange": ["00:00-05:59", "22:01-24:00"]
            },
            "saturday": {
                "timerange": ["00:00-07:59", "18:31-24:00"]
            }
        }
    var NBSTUrl ="https://eforms.qa.advisorcompass.com/eforms/auth/eformscontroller?request_type=EFormsHome&highlight_node=NewBusiness";
    var configProperties = {
    		clientCacheClearTimeout :3000,
    		"hocExtrnlActnLinks":{
    			"rmdremainReviewDstrbtns":"",
    			"acctsuitmisReviewInCV": "https://clientviewer.qa.ameriprise.com/ost/secure/logon/logon.asp?ContextId=",
    			"updateAccountSuitability": "https://ctm.qa.advisorcompass.com/account-suitability/?contextid=",
    			"uncrttinReviewReqrmnts":"https://www.askameriprise.com/app/answers/detail/a_id/12878",
    			"missacctbeneinfoOFM":"",
    			"nigoopnReviewInSM":"https://statusmanager.qa.advisorcompass.com/sm/home.jsp",
    			"totlvwregNotifyClinet": "",
    			"edelivprefChangePref": "",
    			"authPersonUpdateLink": "https://eforms.qa.advisorcompass.com/efm/src/index.html?contextId=",
    			"sharkEFormsUniqueIDLink": "https://ctm.qa.advisorcompass.com/ear/dashboard/shark/index.html?uniqueId=",
    			"ssrsMngChg": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Investment%20Manager%20Changing%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=151&rv:DocMapMode=Collapsed",
    			"ssrsRmvNonBillPos": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Non-billable%20Investments%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=151&rv:DocMapMode=Collapsed",
    			"ssrsSersClos": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Managed%20Accounts%20Closing%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=151&rv:DocMapMode=Collapsed",
    			"ssrsAdmnFeeChg": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Administration%20Fee%20Changes%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsBrkgCliFee": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Custodial%20and%20Account%20Fee%20Changes%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=151&rv:DocMapMode=Collapsed",
    			"ssrsCtiPosUnwrp": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Columbia%20Threadneedle%20Investments%20in%20Qualified%20SPS%20Advisor%20Accounts%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=151&rv:DocMapMode=Collapsed",
    			"cfr": "https://cfr-tmp.qa.advisorcompass.com/cfr",
    			"ssrsFebSpsAdvRpt": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/February%20SPS%20Advantage%20impacted%20Mutual%20Fund%20Periodic%20arrangements%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsMarSpsAdvRpt": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/March%20SPS%20Advantage%20impacted%20Mutual%20Fund%20Periodic%20arrangements%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsConvColumbiaAcct": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Account%20Consolidation%20Opportunities%20Advisor%20View.rdl&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsLgcyColMutFund2": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Legacy%20Columbia%20Mutual%20Fund%20(002)%20-%20Final%20Conversion%20(FYI)%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsMaySpsAdvRpt": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/May%20SPS%20Advantage%20impacted%20Mutual%20Fund%20Periodic%20arrangements%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsDiligenceAdvisoryAcc": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Managed%20Account%20Due%20Diligence%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsDiligenceBrokerageAcc": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Brokerage%20Due%20Diligence%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"ssrsClientAttritionRpt": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Client%20Attrition%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"clientAttritionUniqueID": "https://reportingweb.qa.ampf.com/rcc/spa/ca/index.html#details?paramValue=",
    			"unclaimedPropertyRpt": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Unclaimed%20Property%20Report%20Advisor%20View.rdl&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
    			"updateContactDetails": "https://ctm.qa.advisorcompass.com/ear/dashboard/ucd/index.html?uniqueId="
    		},
    		"ebeneUrl": "https://eforms.qa.advisorcompass.com/efm/src/index.html?contextId=",
    		"beneSpellingURL": "https://eforms.qa.advisorcompass.com/eforms/auth/eformscontroller?request_type=TreeNavigationResults&documentIdentifier=2229&documentType=2&source=OST&contextid=",
    		"feedbacklink": "https://ameriprise.qualtrics.com/SE/?SID=SV_b0YAOJQ4AwIdya9&velo=",
    		"citizenshipAskarticleLink": "https://www.askameriprise.com/app/answers/detail/a_id/10712/kw/client%20citizenship",
    		"secCitizenshipAskarticleLink": "https://www.askameriprise.com/app/answers/detail/a_id/10712/kw/client%20citizenship",
    		"taxTreatyAskarticleLink": "https://www.askameriprise.com/app/answers/detail/a_id/10712/kw/client%20citizenship",
    		"DOBWorkfloLink": "https://eforms.qa.advisorcompass.com/efm/src/index.html?contextId=",
    		"eformsUrl": "https://eforms.qa.advisorcompass.com/efm/src/index.html?contextId=",
    		"beneOFMLink": "https://ofmr.qa.advisorcompass.com/OnlineFileManager/AMPFSearch.faces?docmtClass=client&srcSys=AM&contextid=",
            "mmsLink" : "https://caplist.qa.advisorcompass.com/adv_capl/applauncher/applauncher.do?target=mmsadd&contextid=",
            "ppaReportLink": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/PPA%20Advisor%20view.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
            "dnsPreCheckVPNLink": "http://practicetech.qa.ampf.com/1x1.gif",
            "columbiaMutualFundReport": "https://fieldreporting.qa.ampf.com/field/reports/_layouts/rsviewer/RSViewerPage.aspx?rv:RelativeReportUrl=/field/reports/BRReports/MiscReports/Legacy%20Columbia%20Mutual%20Fund%20Conversion%20Advisor%20View.rdl&rv:HeaderArea=None&rv:ToolBarItemsDisplayMode=150&rv:DocMapMode=Collapsed",
            "ppaEformsLink": "https://ctm.qa.advisorcompass.com/ear/dashboard/ppa/index.html?contextId=",
            "ncstprivacyNotcieUrl": "https://ameriprise.worksmartsuite.com/GetThumbnail.aspx?assetid=49097"
    };
   
    function getConfigProperty(configProperty){
    	return configProperties[configProperty];
    }
    
    var config = {
        ebixServiceName:ebixServiceName,
        odataServiceName: odataServiceName,       
        oboservlet: oboservlet,
        contactProfileURL: contactProfileURL,
        accountListURL: accountListURL,
        calendarURL: calendarURL,
        ncstURL:ncstURL,
        urlWhiteList: urlWhiteList,
        isDevEnv: isDevEnv,
        eSigConfig:eSigConfig,
        omnitureSAccount: omnitureSAccount,
        omnitureSharedSAccount: omnitureSharedSAccount,
        sendAnalyticsToOmniture : sendAnalyticsToOmniture,
        loggingLevel : loggingLevel,
        enableConsoleLogging : enableConsoleLogging,
        enableAnalyticsConsoleLogging : enableAnalyticsConsoleLogging,
        contactListLimit:contactListLimit,
        contactListTimeout:contactListTimeout,
        ncstOutageTime: ncstOutageTime,
        consumerId: consumerId,
        boxURL: boxURL,
        mmsystemURL: mmsystemURL,
        technicalSupportURL: technicalSupportURL,
        contactManagerURL: contactManagerURL,
        efileDeliveryURL: efileDeliveryURL,
        eformsManagerURL: eformsManagerURL,
        newBusinessSetupURL: newBusinessSetupURL,
        opportunityManagerURL: opportunityManagerURL,
        shareClassAnalyzerURL: shareClassAnalyzerURL,
        morningstarAdvisorWorkstationURL: morningstarAdvisorWorkstationURL,
        portfolioURL: portfolioURL,
        portfolio2URL: portfolio2URL,
        teamingURL: teamingURL,
        totalviewNoOBOURL: totalviewNoOBOURL,
        totalviewURL: totalviewURL,
        naviplanURL: naviplanURL,
        confidentRetirementNoOBOURL: confidentRetirementNoOBOURL,
        confidentRetirementOBOURL: confidentRetirementOBOURL,
        shareDocumentToDoURL: shareDocumentToDoURL,
        contactServiceOBOURL: contactServiceOBOURL,
    	eformNavTreeLink: eformNavTreeLink,
        addBank: addBank,
        updateBank: updateBank,
        baseUri: baseUri,
        NBSTUrl:NBSTUrl,
        SADServiceUrl:SADServiceUrl,
        t1URL:t1URL,
        t1DomainName:t1DomainName,
        NBSTMaxWaitTime:NBSTMaxWaitTime,
        NBSTCtxSrvcTimeIntrvl:NBSTCtxSrvcTimeIntrvl,
        getConfigProperty: getConfigProperty,
        ACDeepContentURL: ACDeepContentURL,
        monClientListSvc: monClientListSvc,
        monDistrbOverviewSvc: monDistrbOverviewSvc,
        monClientActGrpsSvc: monClientActGrpsSvc,
        monClientEmploymentSvc: monClientEmploymentSvc,
        monClientCapRegSvc: monClientCapRegSvc,
        monGroupsSvc: monGroupsSvc,
        monClientProfileListSvc: monClientProfileListSvc,
        monClientTaxContrbSvc: monClientTaxContrbSvc,
        monClientDistSvc: monClientDistSvc,
        monClientFiduciariesSvc: monClientFiduciariesSvc,
        monAccountSvc: monAccountSvc,
        monDistributorsSvc: monDistributorsSvc,
        dolImpactDashboardURL: dolImpactDashboardURL
    };
    return config;
});
