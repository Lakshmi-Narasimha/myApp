(function() {
    'use strict';

    angular.module('CSS.components', ['component.validationutils', 'component.customcarousel', 'component.tile', 'component.loader']);

})();
