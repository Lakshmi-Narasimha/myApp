/* eslint-disable */
'use strict';

describe('Directive: Currency Message', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;                                             
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-curr-msg label="lac" icon-class="fa fa-inr"></ftic-curr-msg>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

    it('should be defined',function(){
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('span text should be updated with the label given',function(){
        isoScope.label= "lac";
        var spanText = directiveEle.find('span').text();
        expect(spanText).toEqual(' in '+isoScope.label);
    });

    it('classes in i should be equal to the iconClass',function(){
        isoScope.iconClass= "fa fa-inr";
        var iconClasses = directiveEle.find('i').attr('class');
        expect(iconClasses).toEqual(isoScope.iconClass);
    });

});
