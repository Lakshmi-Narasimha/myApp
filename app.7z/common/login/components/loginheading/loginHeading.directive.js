/**
 * @ngdoc directive
 * @name LoginHeading
 * @description
 *
 * - It displays a heading which need to be passed while declaring this directive
 * 
**/

'use strict';

var loginHeading = function (){
 
	return {
		template : require('./loginHeading.html'),
		restrict : 'E',
		scope : {
			headingText: "="
		}
	};
};

loginHeading.$inject = [];
module.exports = loginHeading;