/**
 * @ngdoc property
 * @name SWP Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function dtpController($scope, fticLoggerMessage, loggerConstants, swpInitialLoader, transactModel,fundDetailsModel) {
    console.info("SWP Controller!!"+$scope.header);
    $scope.header.title = "StART A DTP";
    $scope.config.txnFormDetails.title = "Dividends Transfer Details";
    swpInitialLoader.loadAllServices($scope);
    transactModel.isSWP = true;
    fundDetailsModel.setInvestorType(true);

}

dtpController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'swpInitialLoader', 'transactModel','fundDetailsModel'];
module.exports = dtpController;