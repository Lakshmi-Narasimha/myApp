'use strict';

var checkKycDetails= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _checkKycDtlsResp = null;

    var checkKycModel = {
        fetchCheckKyc : function (param) {
            var deferred = $q.defer();
            //Restangular.one('checkKyc').get().then(function (CheckKycDtlsResp) {
                Restangular.one('transact/validateKYC').get(param).then(function (CheckKycDtlsResp) {
                deferred.resolve(CheckKycDtlsResp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getCheckKycDtls : function (value) {
            if (!angular.isDefined(_checkKycDtlsResp)) {
                return null;
            }
            return _checkKycDtlsResp;
        } ,
        setCheckKycDtls : function (CheckKycDtlsResp) {
            //_checkKycDtlsResp = CheckKycDtlsResp;
            _checkKycDtlsResp = CheckKycDtlsResp.kycValidation;
        },

        validateFolio : function (params) {                    
            var deferred = $q.defer();
            Restangular.one('transact/validateFolio').get(params).then(function (validatefolio) {
                deferred.resolve(validatefolio);
            }, function (resp) {
                deferred.reject(resp); 
                console.log('error');
            });
            return deferred.promise;

        },

    };
    return checkKycModel;

};

checkKycDetails.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = checkKycDetails;
