﻿define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'services/dataservice',
    'appmodules/hoc/hoccommon',
    'appcommon/analytics',
    'errorLog',
    'appmodules/hoc/app/js/model/model-hoc',
    'appmodules/hoc/app/data/hoc-matrix',
    'appcommon/globalcontext',
    'appcommon/hocindicator',
    'text!appmodules/hoc/app/templates/hocgeneral.html', "config", "appcommon/commonutility", "appmodules/hoc/app/js/utils",  'appmodules/contactprofile/app/models/preferenceviewmodel', "appcommon/applauncher/device",
    'appmodules/contactprofile/app/models/cpviewmodel',
    'appcommon/nativeadaptor',
], function ($, _, Backbone, Spinner, DataService, hocCommon, Analytics, ErrorLog, HOCModel, HOCMatrix, GlobalContext, HOCIndicator, hocGeneralTemplate, Config, CommonUtils, HOCUtils, PreferenceViewModel, Device, CPViewModel, NativeAdaptor) {
    var self = null, catgryCd = null, emailSendValdRules = undefined, extWindows ={"nigoSMWindow":null,"acctsuitCVWindow":null,"ebeneWindow":null,"OFMWindow":null};
    var hocView = Backbone.View.extend({
        template: _.template(hocGeneralTemplate),
        el: $("#hoc-content-container"),
        id: 'hoc-content-container',
        CPData: CPViewModel.getInstance().getData(),
        CPDataName: function () {
            CPData = this.CPData;
            var clientName = "";
            if (CPData.cola.personClient.get("clLastNm")) {
                clientName = CPData.cola.personClient.get("clLastNm") + ", " + CPData.cola.personClient.get("clFirstNm");
            } else {
                clientName = CPData.cola.orgClient.get("orgNm");
            }

            return clientName;
        },
        events: {
        },
        initialize: function () {
            self = this;
            self.CPData.id = self.CPData.id || null;
            $(document).off('click', '.drawerable').on('click', '.drawerable', function (e) {
                hocCommon.drawerToggle(event.target);
            }); 
            $(document).off('click', '.dolimpactheader').on('click', '.dolimpactheader', this.dolimpactheaderLink);
            $(document).off('click', '.hoc-action-links:not(.external)').on('click', '.hoc-action-links:not(.external)', this.routeToActionWorkflows);
            $(document).off('change', '.open-postponeID').on('change', '.open-postponeID', this.openPostponeDrpDown);
            $(document).off('change', '.pp-postponeID').on('change', '.pp-postponeID', this.postponeDrpDown);
            $(document).off('click', '.hoc-action-links.external').on('click', '.hoc-action-links.external', this.routeToExternalLinks);
        },
        dolimpactheaderLink: function (e) {
        	var url = Config.dolImpactDashboardURL;
        	Device.operatingSystem();
        	Device.physicalDevice();
        	Device.browser();
        	var _deviceInfo = Device.info;
        	var _deviceType = _deviceInfo.hardware.make;
        	if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
        	    self.checkVPNAndOpenLink(url);
        	} else {
        		BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
        		e.preventDefault();
        		return;
        	}
        	Analytics.analytics.recordAction('DOLImpactDashboard:header-link:clicked');
        },
        render: function (ctgCd) {
            emailSendValdRules = undefined;
            catgryCd = ctgCd;
            Spinner.hide();
            this.renderTemplate(ctgCd);
            window.scrollTo(0, 0);
        },
        renderTemplate: function (ctgCd) {
            if (HOCModel.get('categories').length == 0) {
                if (ctgCd == 1) {
                    $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                    $(".hdr-tab-buttons-wrap .btn-ta").addClass("hdr-tab-active");
                } else if (ctgCd == 2) {
                    $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                    $(".hdr-tab-buttons-wrap .btn-service").addClass("hdr-tab-active");
                }
                return;
            }
            var _takeACtionCategory = HOCModel.get('categories').find(function (row) {return row.ctgCd == ctgCd;
            });
            try {
                var _takeActionCtgry = HOCModel.get('categories').find(function (row) {
                    return row.ctgCd == 1;
                }), _servsOpprCtgry = HOCModel.get('categories').find(function (row) {
                    return row.ctgCd == 2;
                });
                var _takeActionDataNotAvailable = _takeActionCtgry.sections[3].get("gapItems");
                var _rmdRemainderNotAvailable = _takeActionDataNotAvailable.find(function (row) {
                    return row.get("itemTypCd") == "rmdremain";
                });
                var _rmdUnknownNotAvailable = _takeActionDataNotAvailable.find(function (row) {
                    return row.get("itemTypCd") == "rmdunkwn";
                });
                if (_rmdRemainderNotAvailable && _rmdUnknownNotAvailable) {
                    updateItemDisplay({
                        "ctgCd": 1,
                        "sectionId": "dna",
                        "itemTypCd": "rmdremain",
                        "viewDisplay": false
                    });
                }
                var _takeActionNoIssueItems = _takeActionCtgry.sections[2].get("gapItems"), _servsOppNoIssueItems = _servsOpprCtgry.sections[2].get("gapItems");
                // logic to only display the RMD no issue message if both RMD items have no issue
                var _rmdRemainderNoIssue = _takeActionNoIssueItems.find(function (row) {
                    return row.get("itemTypCd") == "rmdremain";
                });
                var _rmdUnknownNoIssue = _takeActionNoIssueItems.find(function (row) {
                    return row.get("itemTypCd") == "rmdunkwn";
                });
                if (!_rmdRemainderNoIssue || !_rmdUnknownNoIssue) {
                    updateItemDisplay({
                        "ctgCd": 1,
                        "sectionId": "ni",
                        "itemTypCd": "rmdremain",
                        "viewDisplay": false
                    });
                }
                updateItemDisplay({
                    "ctgCd": 1,
                    "sectionId": "ni",
                    "itemTypCd": "rmdunkwn",
                    "viewDisplay": false
                });

                var _bnkrenw, _bnkreauth, _nobnkinst;
                _nobnkinst = _servsOppNoIssueItems.find(function (row) {
                    return row.get("itemTypCd") == "nobnkinst";
                });
                if (_nobnkinst) {
                    _bnkrenw = _takeActionNoIssueItems.find(function (row) {
                        return row.get("itemTypCd") == "bnkrenw";
                    });
                    _bnkreauth = _takeActionNoIssueItems.find(function (row) {
                        return row.get("itemTypCd") == "bnkreauth";
                    });
                    if (_bnkrenw && _bnkreauth) {
                        updateItemDisplay({
                            "ctgCd": 1,
                            "sectionId": "ni",
                            "itemTypCd": "bnkreauth",
                            "viewDisplay": false
                        });
                    } else {
                        updateItemDisplay({
                            "ctgCd": 1,
                            "sectionId": "ni",
                            "itemTypCd": "bnkrenw",
                            "viewDisplay": false
                        });
                        updateItemDisplay({
                            "ctgCd": 1,
                            "sectionId": "ni",
                            "itemTypCd": "bnkreauth",
                            "viewDisplay": false
                        });
                    }
                } else {
                    updateItemDisplay({
                        "ctgCd": 1,
                        "sectionId": "ni",
                        "itemTypCd": "bnkrenw",
                        "viewDisplay": false
                    });
                    updateItemDisplay({
                        "ctgCd": 1,
                        "sectionId": "ni",
                        "itemTypCd": "bnkreauth",
                        "viewDisplay": false
                    });
                }
                function updateItemDisplay(options) {
                    var _catgry = HOCModel.get('categories').find(function (row) {
                        return row.ctgCd == options.ctgCd;
                    });
                    var _section = _catgry.sections.find(function (section) {
                        return section.get("sectionId") == options.sectionId;
                    });
                    var _itemIndex = null;
                    _section.get("gapItems").forEach(function (item, i) {
                        if (item.get("itemTypCd") == options.itemTypCd) {
                            _itemIndex = i;
                        }
                    });
                    if (_itemIndex != null) {
                        _section.get("gapItems").splice(_itemIndex, 1);
                    }
                }
            }
            catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
            if(_takeACtionCategory != undefined && _takeACtionCategory != null) {
                var _compiledTemplate = this.template({
                    "serviceError": _takeACtionCategory.serviceError, "sections": _takeACtionCategory.sections, "ctgDesc": _takeACtionCategory.ctgDesc, "ctgCd": _takeACtionCategory.ctgCd
                });
                $('#hoc-content-container').html(_compiledTemplate);

                var openIssue = _takeACtionCategory.sections[0].get('gapItems').length;
                if (catgryCd && catgryCd != 3) {
                    var postponeIssue = _takeACtionCategory.sections[1].get('gapItems').length;
                    var validateIssue = _takeACtionCategory.sections[2].get('gapItems').length;
                    Analytics.analytics.recordAction(_takeACtionCategory.ctgTitle + ' Insights: Opened:' + openIssue + ': Postponed:' + postponeIssue + ': Validated:' + validateIssue);
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _takeACtionCategory.ctgTitle + ' Insights:- Opened-' + openIssue + ': Postponed-' + postponeIssue + ': Validated-' + validateIssue, 1);
                    for (i = 0; i < 3; i++) {
                        var issueCtg = _takeACtionCategory.sections[i].get('sectionDesc');
                        var gapItems = _takeACtionCategory.sections[i].get('gapItems');
                        var arrayCtg = [];
                        for (j = 0; j < gapItems.length; j++) {
                            arrayCtg.push(gapItems[j].attributes.itemTypDesc);
                        }
                        Analytics.analytics.recordAction(_takeACtionCategory.ctgTitle + 'Insights:' + issueCtg + ' : ' + arrayCtg);
                        if (issueCtg == "Open issues") {
                            CommonUtils.sumoLog("sumoLogic: Insights:" + _takeACtionCategory.ctgTitle + 'Insights:' + issueCtg + ' : ' + arrayCtg, 2.1);
                        } else if (issueCtg == "Postponed issues") {
                            CommonUtils.sumoLog("sumoLogic: Insights:" + _takeACtionCategory.ctgTitle + 'Insights:' + issueCtg + ' : ' + arrayCtg, 2.2);
                        } else if (issueCtg == "Validated client information") {
                            CommonUtils.sumoLog("sumoLogic: Insights:" + _takeACtionCategory.ctgTitle + 'Insights:' + issueCtg + ' : ' + arrayCtg, 2.3);
                        }
                    }

                }
                else if (catgryCd && catgryCd == 3) {
                    var actionedIssue = _takeACtionCategory.sections[1].get('gapItems').length;
                    Analytics.analytics.recordAction(_takeACtionCategory.ctgTitle + ' Insights: Opened:' + openIssue + ': Actioned:' + actionedIssue);
                    for (i = 0; i < 2; i++) {
                        var issueCtg = _takeACtionCategory.sections[i].get('sectionDesc');
                        var gapItems = _takeACtionCategory.sections[i].get('gapItems');
                        var arrayCtg = [];
                        for (j = 0; j < gapItems.length; j++) {
                            arrayCtg.push(gapItems[j].attributes.itemTypDesc);
                        }
                        Analytics.analytics.recordAction(_takeACtionCategory.ctgTitle + 'Insights:' + issueCtg + ' : ' + arrayCtg);
                    }
                }

            	



            } else {
                $('#hoc-content-container').html("");
            }
            if(catgryCd ==1) {
                $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                $(".hdr-tab-buttons-wrap .btn-ta").addClass("hdr-tab-active");
            } else if(catgryCd ==2) {
                $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                $(".hdr-tab-buttons-wrap .btn-service").addClass("hdr-tab-active");
            }
        },
        openPostponeDrpDown: function (e) {
            var selectedOpenItem = e.target.value;
            var todayDt = new Date();
            var month = todayDt.getMonth();
            var year = todayDt.getFullYear();
            var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            var opnPspItem, addtoPsp, parsedResponse, postponeDate = "";

            var _$target = $(e.currentTarget), _dataSubject = $.trim(_$target.data('sub')), _dataSection = $.trim(_$target.data('section'));
            var _currentTabURL = '';
            if (window.location.hash === '#hoc/takeAction') { _currentTabURL = "TakeAction" }
            if (window.location.hash === '#hoc/serviceopportunities') { _currentTabURL = "ServiceOpportunity" }

            Analytics.analytics.recordAction('Postpone for-' + selectedOpenItem + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);
            //CommonUtils.sumoLog("sumoLogic: Insights:" + 'Postpone for-' + selectedOpenItem + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);

       
            switch (selectedOpenItem) {
                case 'oneMonth':
                    postponeDate = todayDt.setMonth(month +1);
                    break;
                case 'threeMonth':
                    postponeDate = todayDt.setMonth(month +3);
                    break;
                case 'sixMonth':
                    postponeDate = todayDt.setMonth(month +6);
                    break;
                case 'oneYear':
                    postponeDate = todayDt.setFullYear(year +1);
                    break;
                default:
                    break;
            }
            var formatOpnDate = $.datepicker.formatDate("yy-mm-dd", new Date(postponeDate));
            _payLoadItems = {
                "itemStatCd": "psp",
                "exprDt": formatOpnDate
            }
            var formatPspDate = $.datepicker.formatDate("mm/dd/yy", new Date(postponeDate));

            var pspDrawer = "", itemTypeCd = "", typeIndex = "";
            var targetId = e.target.id;
            typeIndex = targetId.substr(16);

            pspDrawer = $('#hoc-section-0-drawer').find('#itemType-' +typeIndex);
            itemTypeCd = pspDrawer.attr('data-attr-typecd');

            Spinner.show();
            DataService.postponedIssue(itemTypeCd, clientId, _payLoadItems)
            .then(function (response, statusMessage, xhr) {
                if (response) {
                    parsedResponse = JSON.parse(response);
                }
                if (response && parsedResponse.reqStatCd == "200") {
                    Spinner.hide();
                    var _takeActionCategory = HOCModel.get('categories').find(function (row) { return row.ctgCd == catgryCd;
                    });
                    var _takeActionOpnAttr = "", _takeActionDefAttr = "", _newPspItem = "", updatedOpenItem, updatedPspCount;
                    if(_takeActionCategory != undefined && _takeActionCategory != null) {
                        var _takeActionSection = _takeActionCategory.sections;
                        _.each(_takeActionSection, function (list, keys) {
                            if (list.attributes.sectionId == "opn") {
                                _takeActionOpnAttr = list.attributes;
                            }
                            if (list.attributes.sectionId == "psp") {
                                _takeActionDefAttr = list.attributes;
                            }
                        });
                    }

                    if(_takeActionOpnAttr != undefined && _takeActionOpnAttr != null) {
                        _newPspItem = _takeActionOpnAttr.gapItems.splice(typeIndex, 1);
                        updatedOpenItem = _takeActionOpnAttr.gapItems;
                    }
                    if(_takeActionDefAttr != undefined && _takeActionDefAttr != null) {
                        updatedPspCount = _takeActionDefAttr.gapItems;
                    }

                    //Adding postponed item into Postpone issue
                    _takeActionDefAttr.gapItems.push(_newPspItem[0]);
                    var secondaryKey= "", secondaryNewItem = _newPspItem[0].get("values");
                    var _seconValObj =[{ "propNm": "pspdate", "propVal": formatPspDate
                    }];
                    secondaryNewItem.push(_seconValObj);

                    //Sorting the open and postpone items
                    HOCModel.sortItems(updatedOpenItem);
                    HOCModel.sortItems(updatedPspCount);

                    //Re rendering
                    self.render(_takeActionCategory.ctgCd);

                    //Calling HOC Indicator to update count
                    var data = {
                        openActions: updatedOpenItem.length,
                        deferedActions: updatedPspCount.length,
                        ctgrWiseOpnItmCount: self.getCtgrWiseOpnItmCount(HOCModel)
                    }
                    if (catgryCd == 1 || catgryCd == 2) {
                        HOCIndicator.updateActionStatus(data, true);
                    }
                }
                else {
                    Spinner.hide();
                    BootstrapDialog.alert("This feature is not available at this time.  Please try again later.", function () {
                    }, "Information");
                }
            })
            .fail(function (err) {
                Spinner.hide();
                HOCUtils.showServiceError(err);
            });
        },
        getCtgrWiseOpnItmCount : function(hocModel){
            var _ctgrWiseOpnItmCount = {}, _ctgrs = hocModel.get("categories"), _opnSection, _fyiSection, _opnSctnLngth, _fyiSectnLngth;
            for (var i = 0; i < _ctgrs.length; i++) {
                _opnSection = _ctgrs[i].sections.find(function (row) {
                    return row.get("sectionId") == "opn"
                });
                _fyiSection = _ctgrs[i].sections.find(function (row) {
                    return row.get("sectionId") == "fyi"
                });
                _opnSctnLngth = _opnSection ? _opnSection.get("gapItems").length : 0;
                _fyiSectnLngth = _fyiSection ? _fyiSection.get("gapItems").length : 0;
                _ctgrWiseOpnItmCount[(i + 1)] = _opnSctnLngth + _fyiSectnLngth;
            }
            return _ctgrWiseOpnItmCount

        },
        postponeDrpDown: function (e) {
            var selectedOpenItem = e.target.value;

            var todayDt = new Date();
            var month = todayDt.getMonth();
            var year = todayDt.getFullYear();
            var parsedResponse, postponeNewDate = "", dateIndex = "";
            var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;

            var _$target = $(e.currentTarget), _dataSubject = $.trim(_$target.data('sub')), _dataSection = $.trim(_$target.data('section'));
            var _currentTabURL = '';
            if (window.location.hash === '#hoc/takeAction') { _currentTabURL = "TakeAction" }
            if (window.location.hash === '#hoc/serviceopportunities') { _currentTabURL = "ServiceOpportunity" }

            Analytics.analytics.recordAction('Postpone for-' + selectedOpenItem + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);
            //CommonUtils.sumoLog("sumoLogic: Insights:"+'Postpone for-' + selectedOpenItem + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);

           

            switch (selectedOpenItem) {
                case 'oneMonth':
                    postponeNewDate = todayDt.setMonth(month +1);
                    break;
                case 'threeMonth':
                    postponeNewDate = todayDt.setMonth(month +3);
                    break;
                case 'sixMonth':
                    postponeNewDate = todayDt.setMonth(month +6);
                    break;
                case 'oneYear':
                    postponeNewDate = todayDt.setFullYear(year +1);
                    break;
                case 'moveToOpen':

                    _payLoadItems = {
                        "itemStatCd": "opn"
                    }

                    var pspDrawer = "", itemTypeCd = "", typeIndex = "";
                    var targetId = e.target.id;
                    typeIndex = targetId.substr(16);

                    pspDrawer = $('#hoc-section-1-drawer').find('#itemType-' +typeIndex);
                    itemTypeCd = pspDrawer.attr('data-attr-typecd');

                    Spinner.show();
                    DataService.postponedIssue(itemTypeCd, clientId, _payLoadItems)
                    .then(function (response, statusMessage, xhr) {
                        if (response) {
                            parsedResponse = JSON.parse(response);
                        }
                        if (response && parsedResponse.reqStatCd == "200") {
                            Spinner.hide();

                            var _takeActionCategory = HOCModel.get('categories').find(function (row) { return row.ctgCd == catgryCd;
                            });
                            var _takeActionOpnAttr = "", _takeActionDefAttr = "", _newDelItem = "", updatedOpenItem = [], updatedPspCount;
                            if (_takeActionCategory != undefined && _takeActionCategory != null) {
                                var _takeActionSection = _takeActionCategory.sections;
                                _.each(_takeActionSection, function (list, keys) {
                                    if (list.attributes.sectionId == "opn") {
                                        _takeActionOpnAttr = list.attributes;
                                    }
                                    if (list.attributes.sectionId == "psp") {
                                        _takeActionDefAttr = list.attributes;
                                    }
                                });
                            }

                            if (_takeActionOpnAttr != undefined && _takeActionOpnAttr != null) {
                                updatedOpenItem = _takeActionOpnAttr.gapItems;
                            }
                            if (_takeActionDefAttr != undefined && _takeActionDefAttr != null) {
                                _newDelItem = _takeActionDefAttr.gapItems.splice(typeIndex, 1);
                                updatedPspCount = _takeActionDefAttr.gapItems;
                            }

                            //Adding postponed item into Postpone issue
                            _takeActionOpnAttr.gapItems.push(_newDelItem[0]);

                            //Sorting the open and postpone items
                            HOCModel.sortItems(updatedOpenItem);
                            HOCModel.sortItems(updatedPspCount);

                            //Re rendering
                            self.render(_takeActionCategory.ctgCd);

                            //Calling HOC Indicator to update count
                            var data = {
                                openActions: updatedOpenItem.length,
                                deferedActions: updatedPspCount.length,
                                ctgrWiseOpnItmCount: self.getCtgrWiseOpnItmCount(HOCModel)
                            }
                            if (catgryCd == 1 || catgryCd == 2) {
                                HOCIndicator.updateActionStatus(data, true);
                            }

                        } else {
                            Spinner.hide();
                            BootstrapDialog.alert("This feature is not available at this time.  Please try again later.", function () {
                            }, "Information");
                        }
                    })
                    .fail(function (err) {
                        Spinner.hide();
                        HOCUtils.showServiceError(err);
                    });

                    break;
                default:
                    break;
            }
            if (postponeNewDate) {
                var formatPspDate = $.datepicker.formatDate("mm/dd/yy", new Date(postponeNewDate));
                $('.pspDate').html(formatPspDate);
            }


            if (postponeNewDate) {
                var dateCal = e.target.id;
                dateIndex = dateCal.substr(16);
                var formatPspDate = $.datepicker.formatDate("mm/dd/yy", new Date(postponeNewDate));
                $('.pspDate-' +dateIndex).html(formatPspDate);
            }

        },
        routeToActionWorkflows: function (e) {
            that = this;
            var _targetRoute = null, _$target = $(e.currentTarget);
            var _dataHref = _$target.data('href'),
                _isExternal = _$target.hasClass('external'),
                _itemTypCd = _$target.data('itemtypcd'),
                _internalPopup = _$target.hasClass('internalpopup');
            var _dataSubject = $.trim(_$target.data('sub')), _dataSection = $.trim(_$target.data('section'));
            var _currentTabURL = '';
            if (_dataSection == "Validated client information") {
                if (window.location.hash === '#hoc/takeAction') {
                    _currentTabURL = "TakeAction";
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'Clicked on-' + _$target.text() + ' - ' + _dataSubject , 5)
                }
                if (window.location.hash === '#hoc/serviceopportunities') {
                    _currentTabURL = "ServiceOpportunity";
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'Clicked on-' + _$target.text() + ' - ' + _dataSubject  , 6);
                }
            }
            else if (window.location.hash === '#hoc/takeAction') {
                _currentTabURL = "TakeAction";
                if (_dataSection == "Open issues") {             
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'Clicked on-' + _$target.text() + ' - ' + _dataSubject, 3.1)
                } else if (_dataSection == "Postponed issues" && window.location.hash === '#hoc/takeAction') {
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'Clicked on-' + _$target.text() + ' - ' + _dataSubject , 3.2)
                }
            }
            else if (window.location.hash === '#hoc/serviceopportunities') {
                _currentTabURL = "ServiceOpportunity";
                {
                    if (_dataSection == "Open issues") {
                        CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'Clicked on-' + _$target.text() + ' - ' + _dataSubject + ' - ', 4.1)
                    } else if (_dataSection == "Postponed issues") {
                        CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'Clicked on-' + _$target.text() + ' - ' + _dataSubject + ' - ', 4.2)
                    }
                }
            }
            else if (window.location.hash === '#hoc/dol') {
            	_currentTabURL = "DOL";
            }

            Analytics.analytics.recordAction('Clicked on-' + _$target.text() + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);

             switch (_dataHref) {
                case 'gpm/employment':
                case 'gpm/suitability':
                case 'gpm/email':
                case 'coa/':
                case 'contactprofile/':
                case 'contactprofile/preferences':
                case 'contactprofile/beneficiary':
                case 'contactprofile/contributions':
                case 'contactprofile/distributions':
                case 'contactprofile/fiduciary':
                case 'contactprofile/bank':
                    _targetRoute = _dataHref;
                    self.navigateToInternalRoutes(_targetRoute);
                    window.scrollTo(0, 0);
                    break;
                case 'crm/addtask':
                    _targetRoute = _dataHref;
                    var _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
                    if (_isNonCMuser) {
                        CommonUtils.toggleNonCMmsg("function");
                        return;
                    } else {
                        if (!NativeAdaptor.notifyNewActivityRequested("Insights: " + _dataSubject, true)) {
                            self.navigateToInternalRoutesCRM(_targetRoute, _dataSubject);
                        } else {
                            e.preventDefault();
                        }
                    }
                    break;
                case 'gpm/documentDelivery':
                    self.saveDocDeliveryModel(_dataHref, _itemTypCd);
                    break;
                default:
                    console.log("error: edit field operator error")
                    break;
            }

            return false;

        },
        bootstrapDialogConfirm: function (title, msgBody, itemStatCd, uniqueId, itemTypeCd) {
            var self = this;
            BootstrapDialog.confirm(
                title, // Title of Popup
                msgBody, // Message
                function (confirm) {
                    if (confirm) {
                        self.reRenderMarkDoneAndDisregard(itemStatCd, uniqueId, itemTypeCd);
                    }
                },
                '', // CSS class
                "No",
                "Yes");
        },
        reRenderMarkDoneAndDisregard: function (itemstatcd, uniqueId, itemTypeCd) {
        	var _payLoadItems = {
        		"itemStatCd": itemstatcd,
        		"exprDt": uniqueId
        	};
        	var parsedResponse;
        	var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
        	Spinner.show();
        	DataService.postponedIssue(itemTypeCd, clientId, _payLoadItems)
			.then(function (response, statusMessage, xhr) {
				if (response) {
					parsedResponse = JSON.parse(response);
				}
				if (response && parsedResponse.reqStatCd == "200") {
				    setTimeout(function () {
				        self.updateHOCList(clientId, catgryCd);
				    }, 1500);
				} else {
					Spinner.hide();
					BootstrapDialog.alert("This feature is not available at this time. Please try again later.", function () {
					}, "Information");
				}
			}).fail(function (err) {
				Spinner.hide();
				HOCUtils.showServiceError(err);
			});
        },
        updateHOCList: function (clientId, catgryCd) {
            DataService.getHOCListWithCtgFilter(clientId, catgryCd, 0).then(function (resp) {
                Spinner.hide();
                HOCModel.updateCategory(catgryCd, resp);
        		var _updatedCount = {
        		    openActions: null,
        		    deferedActions: null,
        		    ctgrWiseOpnItmCount: self.getCtgrWiseOpnItmCount(HOCModel)
        		}
        		HOCIndicator.updateActionStatus(_updatedCount, true);
        		var _takeActionCategory = HOCModel.get('categories').find(function (row) {
        			return row.ctgCd == catgryCd;
        		});
        		self.render(_takeActionCategory.ctgCd);
        	}).fail(function (err) {
        		HOCModel.clearModel();
        		Spinner.hide();
        		HOCUtils.showServiceError(err)
        	});
        },
        navigateToInternalRoutesCRM: function (targetRoute, dataSubject) {
            var encode = btoa(dataSubject);
            var _url = targetRoute + "/" +encode;
            Backbone.history.navigate(_url, true);
        },
        navigateToInternalRoutes: function (targetRoute) {
            Backbone.history.navigate(targetRoute, true);
        },
        saveDocDeliveryModel: function (targetRoute, _itemTypCd) {
            var _clId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            var _serviceCallsStack =[];
            _serviceCallsStack.push(DataService.getContactprofileInfoCache(_clId));
            //Queuing the service requests
            Q.all(_serviceCallsStack)
            	.then(function (response) {
            	    if(response && response.length>0) {
            	        if(response[0]) {
            	            self.clientServicePrefSuccess(response[0], targetRoute, _itemTypCd);
            	        }
            	    }
            	})
            	.fail(function (error) {
            	    ErrorLog.ErrorUtils.myError(error);
            	});
        },
        clientServicePrefSuccess: function (preferences, targetRoute, _itemTypCd) {
            var _results = preferences['results'][0], _dataClientServPref = _results.attributes.clientServPreferences,
        	tmpClintDocDelivery = {
        	    prfrcServEmailDeliveredTo: null,
        	    prefrcSerEmailShow: false,
        	    prfrcShareHolderDocs: null,
        	    prfrcAccountStatements: null,
        	    prfrcFinancialConfirms: null,
        	    prfrcAddsnlDocumentType: null
        	};
            if(_dataClientServPref && _dataClientServPref.length>0) {

                $.each(_dataClientServPref, function (key, row) {
                    //Update Share holder document status
                    if(row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Shareholder Communication") {
                        tmpClintDocDelivery.prfrcShareHolderDocs = "Online";
                        tmpClintDocDelivery.prefrcSerEmailShow = true;
                    } else if(row.typCd === "Paper Suppression" && row.subTypCd === "Shareholder Communication") {
                        tmpClintDocDelivery.prfrcShareHolderDocs = "U.S. mail";
                    }
                    //Update Account statements status
                    if(row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Consolidated Statement") {
                        tmpClintDocDelivery.prfrcAccountStatements = "Online";
                        tmpClintDocDelivery.prefrcSerEmailShow = true;
                    } else if(row.typCd === "Paper Suppression" && row.subTypCd === "Consolidated Statement") {
                        tmpClintDocDelivery.prfrcAccountStatements = "U.S. mail";
                    }
                    //Update Financial Confirmations status
                    if(row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Financial Confirmations") {
                        tmpClintDocDelivery.prfrcFinancialConfirms = "Online";
                        tmpClintDocDelivery.prefrcSerEmailShow = true;
                    } else if(row.typCd === "Paper Suppression" && row.subTypCd === "Financial Confirmations") {
                        tmpClintDocDelivery.prfrcFinancialConfirms = "U.S. mail";
                    }
                    //Update Additional document types status
                    if(row.valCd === "Yes" && row.typCd === "Paper Suppression" && row.subTypCd === "Other Documents") {
                        tmpClintDocDelivery.prfrcAddsnlDocumentType = "Online";
                        tmpClintDocDelivery.prefrcSerEmailShow = true;
                    } else if(row.typCd === "Paper Suppression" && row.subTypCd === "Other Documents") {
                        tmpClintDocDelivery.prfrcAddsnlDocumentType = "U.S. mail";
                    }
                });
                if(tmpClintDocDelivery.prefrcSerEmailShow) {
                    tmpClintDocDelivery.prfrcServEmailDeliveredTo = "Primary email";
                }

            }
            PreferenceViewModel.setData("documentDelivery", tmpClintDocDelivery);
            var _valdnMethd = self.validateDocDelivAndShowMsg;
            if(emailSendValdRules != undefined) {
                if(_valdnMethd(emailSendValdRules)) {
                    self.navigateToInternalRoutes(targetRoute);
                }
            } else {
                self.getEmailSendValidationRules(_valdnMethd, function () {
                    self.navigateToInternalRoutes(targetRoute);
                });
            }

        },
        routeToExternalLinks: function (e) {
            var _clId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            var _targetRoute = null, _$target = $(e.currentTarget), _hocExtrnlActnLinks = Config.getConfigProperty("hocExtrnlActnLinks");
            var _dataHref = _$target.data('href'), _clId=GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            _targetRoute = _dataHref;
            var _itemTypCd = _$target.data('itemtypcd'), _uniqueId = _$target.attr('data-uniqueid'), _htmlString;
            var _dataSubject = $.trim(_$target.data('sub')), _dataSection = $.trim(_$target.data('section'));
            var _currentTabURL = '';
            if (_dataSection == "Validated client information") {
                if (window.location.hash === '#hoc/takeAction') {
                    _currentTabURL = "TakeAction";
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ' , 5);
                }
                else if (window.location.hash === '#hoc/serviceopportunities') {
                    _currentTabURL = "ServiceOpportunity";
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ', 6);
                }}
            if (window.location.hash === '#hoc/takeAction') {
                _currentTabURL = "TakeAction";
                if (_dataSection == "Open issues") {
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ' , 3.1);
                                      
                }
                else if (_dataSection == "Postponed issues" && window.location.hash === '#hoc/takeAction') {
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ', 3.2);
                }
            }
            if (window.location.hash === '#hoc/serviceopportunities') {
                _currentTabURL = "ServiceOpportunity";
                if (_dataSection == "Open issues") {
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ', 4.1);
                } else if (_dataSection == "Postponed issues") {
                    CommonUtils.sumoLog("sumoLogic: Insights:" + _currentTabURL + _dataSection + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ', 4.2);
                }
            }
            if (window.location.hash === '#hoc/dol') {
            	_currentTabURL = "DOL";
            }
            if (_dataSection=="Open items") {
                _currentTabURL = "DOL";
            }
            Analytics.analytics.recordAction('External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);
            //CommonUtils.sumoLog("sumoLogic: Insights:" + 'External link-Clicked on - ' + _$target.text() + ' - ' + _dataSubject + ' - ' + _dataSection + ' - ' + _currentTabURL);

             

            switch (_dataHref) {
                case 'acctsuitmisReviewInCV':
                case 'clientViewer':
                    navigateToCV('acctsuitmisReviewInCV');
                    break;
                case 'updateAccountSuitability':
                    navigateToAccSuitability('updateAccountSuitability');
                    break;
                case 'nigoopnReviewInSM':
                    navigateToStatusManager(_targetRoute);
                    break;
                case 'uncrttinReviewReqrmnts':
                    navigateToExtRoute(_targetRoute);
                    break;
                case 'totlvwregNotifyClinet':
                    if(emailSendValdRules != undefined) {
                        if(self.validateTotalViewInviteInfo(emailSendValdRules)) {
                            sendTotalViewEmail();
                        }
                    } else {
                        self.getEmailSendValidationRules(self.validateTotalViewInviteInfo, sendTotalViewEmail);
                    }
                    break;
                case 'edelivprefChangePref':
                    if(emailSendValdRules != undefined) {
                        if(self.validateSetPreferencesEmailInviteInfo(emailSendValdRules)) {
                            sendDeliveryPrefEmail();
                        }
                    } else {
                        self.getEmailSendValidationRules(self.validateSetPreferencesEmailInviteInfo, sendDeliveryPrefEmail);
                    }
                    break;
                case 'secureSite':
                    if (emailSendValdRules != undefined) {
                        if (self.validateSecureSiteRegg(emailSendValdRules)) {
                            secureSiteRegg();
                        }
                    }
                    else {
                        self.getEmailSendValidationRules(self.validateSecureSiteRegg, secureSiteRegg);
                    }
                    break;
                case 'ebeneUrl':
                    self.invokeEbeneWorkflowLinkClick();
                    break;
                case 'beneOFMLink':
                    Device.operatingSystem();
                    Device.physicalDevice();
                    Device.browser();
                    var _deviceInfo = Device.info;
                    var _deviceType = _deviceInfo.hardware.make;
                    if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                        Spinner.show();
                        self.invokeBeneOFMLinkClick();
                        Spinner.hide();                        
                    }   else {
                        BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");                        
                    }                    
                    break;
                case 'authPersonUpdateLink':
                    self.invokeAuthPersopnUpdateWorkflow();
                    break;
                case 'mmsLink':
                    self.invokeMMSLinkClick();
                    break;
                case 'ppaReportLink':
                    self.invokePPAReportLinkClick();
                    break;
                case 'ppaEformsLink':
                    self.invokePPAEformsLinkClick();
                    break;
            	case 'columbiaMutualFundReport':
            		self.invokeColumbiaReport();
            		break;
                case 'eformsUniqueID':
                    self.invokeEFormsLinkClick(_$target.data('uniqueid'));
                    break;
                case 'clientAttritionUniqueID':
                    self.invokeClientAttritionLinkClick(_$target.data('uniqueid'));
                    break;
            	case 'updateContactDetails':
            		self.invokeContactDetailLink(_uniqueId.substr(0, 15));
            		break;
            	case 'unclaimedPropertyRpt':
            		self.invokeUnclaimedPropertyLink();
            		break;

                case 'ssrsMngChg':
                case 'ssrsRmvNonBillPos':
                case 'ssrsCtiPosUnwrp':
                case 'ssrsSersClos':
                case 'ssrsAdmnFeeChg':
                case 'ssrsBrkgCliFee':
                case 'ssrsMarSpsAdvRpt':
                case 'ssrsFebSpsAdvRpt':
                case 'ssrsConvColumbiaAcct':
                case 'ssrsLgcyColMutFund2':
                case 'ssrsMaySpsAdvRpt':
                    self.invokeDOLSSRSReporTLinks(_dataHref);
                    break;
                case 'cfr':
                    self.invokeCFRToolActionClick(_dataHref)
                    break;
                case 'NBSTUrl':
                self.openExternalLinkWithContext({ "url": Config.NBSTUrl +"&contextid="});
                    break;
                case 't1Anywhere':
                    CommonUtils.openT1GenericLink();
                    break;
            	case 't1AnywhereWithContext':
            		var _customUniqueId = _$target.attr('data-acctNbr');
            		openT1WithContextLink(_customUniqueId.substring(0, 8));
            		break;
            	case 'ssrsDiligenceAdvisoryAcc':
            		self.invokeDOLSSRSReporTLinks(_dataHref);
            		break;
            	case 'ssrsDiligenceBrokerageAcc':
            		self.invokeDOLSSRSReporTLinks(_dataHref);
            		break;
                case 'ssrsClientAttritionRpt':
                    self.invokeDOLSSRSReporTLinks(_dataHref);
                    break;
                //case 'disregard':
                //    _htmlString = "Are you sure you want to disregard this? <span class='pt-data-label-demi'>&quot;" + _dataSubject + "&quot;</span>";
                //    self.bootstrapDialogConfirm(_$target.text(), _htmlString, "Disregarded", _uniqueId, _itemTypCd);
                //    break;
                case 'acknowledge':
                    _htmlString = "Are you sure you want to acknowledge this? <span class='pt-data-label-demi'>&quot;" + _dataSubject + "&quot;</span>";
                    self.bootstrapDialogConfirm(_$target.text(), _htmlString, "Acknowledged", _uniqueId, _itemTypCd);
                    break;
                case 'markdone':
                    _htmlString = "Are you sure you want to mark this as done? <span class='pt-data-label-demi'>&quot;" + _dataSubject + "&quot;</span>";
                    self.bootstrapDialogConfirm(_$target.text(), _htmlString, "Done", _uniqueId, _itemTypCd);
                    break;
                default:
                    console.log("error: edit field operator error");
                    break;
            }
            function openT1WithContextLink(_acctNo) {
            	var ABPMobileWindow = CommonUtils.getABPMobileWindow();
            	var _url = Config.t1URL + "&contextId=external";
            	var _options = {
            		"strAccNum": _acctNo,
            		"strTabId": "Positions",
            		"strThomledId": 156,
            		"strRefreshThomletId": 6764,
            	}

            	CommonUtils.launchThomsonSmart(_options, openT1Link);
            	function openT1Link() {
            		if (ABPMobileWindow) { ABPMobileWindow.close(); }
            		setTimeout(function () { ABPMobileWindow = window.open(_url); CommonUtils.setABPMobileWindow(ABPMobileWindow); }, 200);
            	}
            }
            function navigateToStatusManager(targetRoute) {
                   _url = _hocExtrnlActnLinks[targetRoute];
                   window.open(_url);
            }
            function navigateToExtRoute(targetRoute) {
                _url = _hocExtrnlActnLinks[targetRoute];
                window.open(_url);
            }
            function navigateToCV(targetRoute) {
                Spinner.show();
                var _contextId = null, _url = _hocExtrnlActnLinks[targetRoute];
                //context service v2 compatibility mode
                var _v2Compatible = true;
                self.callPutContextService(false, _v2Compatible).then(function (response) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                    }
                }).fail(self.genericServiceErrorHandler);
            }

            function navigateToAccSuitability(targetRoute) {
                Spinner.show();
                var _contextId = null, _url = _hocExtrnlActnLinks[targetRoute];
                var _v2Compatible = true;
                _putContextPaylod = CommonUtils.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext, true);
                Spinner.show();
                DataService.putAdvisorSessionContext(_putContextPaylod, false).done(function (response, status, xhr) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId;
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.prepareAndLogError(xhr);
                    }
                }).fail(function (xhr) {
                    ErrorLog.ErrorUtils.myError(xhr);
                });

            }

            function secureSiteRegg() {

                var payload = {
                    "regTypCd": "NEW"
                };
                Spinner.show();
                DataService.SecureSiteService(_clId, payload).then(function (response, result) {
                    var tokenId = response.d.results[0].tokenId;
                    if (tokenId != null && tokenId != "") {
                        var tokenPayload = {
                            "actnCd": "Registration Reminder",
                            "cmunTypCd": "Notification",
                            "EMSApplCd": "ADVISORMOBILE",
                            "token": {
                                "tokenId": tokenId
                            }
                        }
                        DataService.getTotalViewDelvPrefService(_clId, tokenPayload).then(function (response, result, xhr) {
                            if (result == "success") {
                                BootstrapDialog.alert('<div>'
                                    + '<div class="left-box right-tick pull-left"></div>'
                                    + '<div class="row right-box pull-left">'
                                        + '<div>The client will be sent an email to register with the Secure Site on ameriprise.com within the next business day.</div><br/>'
                                        + '<div class="pt-action-icon-header">Client Next Steps</div>'
                                        + '<div>They will need to go online the Secure Site on ameriprise.com and complete registration.</div><br/>'
                                        + '<div class="pt-action-icon-header">Advisor Next Steps</div>'
                                        + '<div> Let the client know to expect the email and encourage them to sign up for eDelivery.</div>'
                                        + '<div class="clearfix"></div>'
                                    + '</div>'
                                    + '<div class="clearfix"></div>'
                                + '</div>', function () {
                                }, "Invitation email sent");
                            }
                            Spinner.hide();
                        }).fail(function (xhr) {
                            Spinner.hide();
                            ErrorLog.ErrorUtils.prepareAndLogError(xhr);
                        });
                    } else {
                        Spinner.hide();
                        ErrorLog.ErrorUtils.prepareAndLogError(err);
                    }
                }).fail(function (err) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(err);
                });
            }
            function sendTotalViewEmail() {
                var _payload = { "actnCd": "Acct Agg Registered Client Advisor Invite", "cmunTypCd": "Notification", "EMSApplCd": "OST"};
                Spinner.show();
                DataService.getTotalViewDelvPrefService(_clId, _payload).then(function (xhr, result) {
                    Spinner.hide();
                    if (result === "success") {
                        BootstrapDialog.alert('<div>'
                            + '<div class="left-box right-tick pull-left"></div>'
                            + '<div class="row right-box pull-left">'
                                + '<div>The client will be sent an email link to enroll in Total View within the next business day.</div><br/>'
                                + '<div class="pt-action-icon-header">Client Next Steps</div>'
                                + '<div>They will need to login to the Secure Site on ameriprise.com and click on the Total View tab to enroll.</div><br/>'
                                + '<div class="pt-action-icon-header">Advisor Next Steps</div>'
                                + '<div> Let the client know to expect the email and encourage them to learn more and enroll.</div>'
                                + '<div class="clearfix"></div>'
                            + '</div>'
                            + '<div class="clearfix"></div>'
                          + '</div>', null, "Invitation email sent");
                    }
                }).fail(function (err) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(err);
                });
            }
            function sendDeliveryPrefEmail() {
                var _payload = { "actnCd": "Pending Preference Change", "cmunTypCd": "Notification", "EMSApplCd": "OST"},
                    _clientNxtSteps = (emailSendValdRules && emailSendValdRules.ameriReg !== true) ? "They will need to login to the Secure Site on ameriprise.com and update and confirm their preferences.  A repeat email will be sent if changes are not confirmed within 10 days.  e-Delivery clients will need to register for the Secure Site on ameriprise.com to see their documents. Clients who do not register within six months of signing up for e-Delivery will be reverted to paper delivery." : "They will need to login to the Secure Site on ameriprise.com and update and confirm their preferences.  A repeat email will be sent if changes are not confirmed within 10 days.";
                Spinner.show();
                DataService.getTotalViewDelvPrefService(_clId, _payload).then(function (xhr, result) {
                    Spinner.hide();
                    if (result === "success") {
                        BootstrapDialog.alert('<div>'
                              + '<div class="left-box right-tick pull-left"></div>'
                              + '<div class="row right-box pull-left">'
                                  + '<div>The client will be sent an email to register with the Secure Site on ameriprise.com within the next business day.</div><br/>'
                                  + '<div class="pt-action-icon-header">Client Next Steps</div>'
                                  + '<div>' + _clientNxtSteps + '</div><br/>'
                                  + '<div class="pt-action-icon-header">Advisor Next Steps</div>'
                                  + '<div>Let the client know to expect the email and encourage them to sing up for eDelivery.</div>'
                                  + '<div class="clearfix"></div>'
                                                  + '</div>'
                              + '<div class="clearfix"></div>'
                          + '</div>', null, "Invitation email sent");
                    }
                }).fail(function (err) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(err);
                });

            }


        },
   
        getEmailSendValidationRules: function (validationMethod, successCallback) {
            var _clId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            	    emailSendValdRules = {
            			   "primaryemail": "",
            			   "undeliverable": false,
            			   "prefernceSiteRegistered": false,
            			   "totalViewEnrolled": false,
            			   "ameriReg": false
        };
            	   Spinner.show();
            	   DataService.getContactprofileInfoCache(_clId).then(function (response) {
            		   var _results = response['results'][0], _clientEmails=[];
            		   if(_results && _results.get) {
            			   _clientEmails = _results.get('clientEmails');
            			   if (Array.isArray(_clientEmails)) {
            			       $.each(_clientEmails, function (key, row) {
            			           if (row.get("emlUseCd") === "Primary") {
            			               emailSendValdRules.primaryemail = row.get("emlAddr");
            			               if (row.get("emlVldStatCd") !== "Valid" || row.get("emlFuncStatCd") !== "Functional") {
            			                   emailSendValdRules.undeliverable = true;
            			                   emailSendValdRules.unReg = true;
            			           }
            			       }
            			   });
            		   }
            			   if(_results.get('capabilityRegistrations') === null) {
                       		DataService.getClientOnlineAccessPreference(_clId).then(function (result) {
                       			if(result && result[0]) {
                       				renderOnlineAccessPreference(result[0]['results']);
                       		}
                       		}).fail(function (err) {
                       			emailSendValdRules = undefined;
                       			Spinner.hide();
                       			ErrorLog.ErrorUtils.prepareAndLogError(err);
            			   });
            			   } else {
                          		Spinner.hide();
                       		renderOnlineAccessPreference(_results.attributes.capabilityRegistrations);
            		   }
            		   } else {
            			   Spinner.hide();
                		   emailSendValdRules.ameriReg = null;
                		   if(validationMethod(emailSendValdRules)) {
                			   successCallback();
            		   }
            	   }
            	   }).fail(function (err) {
            		   Spinner.hide();
            		   emailSendValdRules.ameriReg = null;
            		   if(validationMethod(emailSendValdRules)) {
            			   successCallback();
            	   }
        });
            function renderOnlineAccessPreference(collection) {
            		   Spinner.hide();
   	               	try {
   	               	    $.each(collection, function (key, row) {
   	               			if(row.status === "Active" && row.rsrcCd === "MYFA") {
   	               				emailSendValdRules.prefernceSiteRegistered = true;
   	               				emailSendValdRules.ameriReg = true;
   	               	    }
   	               			if (row.status === "Active" && row.rsrcCd === "CE") {
   	               				emailSendValdRules.totalViewEnrolled = true;
   	               	    }
   	               	});
   	               	 if(validationMethod(emailSendValdRules)) {
             			   successCallback();
   	               	}
   	               	}catch (err) {
   	               		emailSendValdRules = undefined;
               			Spinner.hide();
               			ErrorLog.ErrorUtils.prepareAndLogError(err);
            }
        }
},
        validateDocDelivAndShowMsg: function (emlSndValdRules) {
            var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
            console.log(CPViewModel.getInstance().getData().cola, "CPViewModel.getInstance().getData().cola");
            if (CPData != null) { // entity error
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted due to the following reason: Organization clients are not eligible to register  on the Secure Site on ameriprise.com</div>", function () {
                }, "Information");
                return false;
            } else if (emlSndValdRules.primaryemail == "") { // no primary email address
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted due to the following reason: The client is missing a primary email address. To update the email address, go to the Preferences tab and click on Change email addresses.</div>", function () {
                }, "Information");
                return false;
            } else if (emailSendValdRules.ameriReg === false) { //not register
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is not registered on the Secure Site on ameriprise.com</div>", function () {
                }, "Information");
                return false;
            } else if (emailSendValdRules.ameriReg  == null) { //not register and service fails
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because we are unable to determine if the client is registered on the Secure Site on ameriprise.com Please try again at a later time.</div>", function () {
                }, "Information");
                return false;
            } else if (emailSendValdRules.undeliverable == true) { // undelivered mail
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client's email address on file is undeliverable. You must make necessary corrections before proceeding.</div>", function () {
                    }, "Information");
                    return false;
        }

return true;
},
        validateSetPreferencesEmailInviteInfo: function (emlSndValdRules) {
                   var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
                   if (emailSendValdRules.ameriReg === null) { //not register and service fails
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Service fails</div>", null, "Invitation email not sent");
                       return false;
                   } else if (CPData != null) { // entity error
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", null, "Invitation email not sent");
                       return false;
                   } else if (emlSndValdRules.primaryemail == "") { // no primary email address
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", null, "Invitation email not sent");
                       return false;
                   } else if (emailSendValdRules.ameriReg === false) { //not register
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is not registered on the Secure Site on ameriprise.com</div>", null, "Invitation email not sent");
                       return false;
                   } else if (emailSendValdRules.undeliverable === true) { // undelivered mail
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", null, " Invitation email not sent ");
                       return false;
        }

                   return true;
},
        validateTotalViewInviteInfo: function (emlSndValdRules) {
                   var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");
                   if (emailSendValdRules.ameriReg === null) { //not register and service fails
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Service fails</div>", null, "Invitation email not sent");
                       return false;
                   } else if (CPData != null) { // entity error
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible for Total View.</div>", null, "Invitation email not sent");
                       return false;
                   } else if (emlSndValdRules.primaryemail === "") { // no primary email address
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", null, "Invitation email not sent");
                       return false;
                   } else if (emailSendValdRules.ameriReg === false) { //not register
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client needs to register for the Secure Site on ameriprise.com to use Total View.<br/></div>", null, "Invitation email not sent");
                       return false;
                   } else if (emailSendValdRules.undeliverable === true) { // undelivered mail
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", null, " Invitation email not sent ");
                       return false;
                   } else if (emailSendValdRules.totalViewEnrolled === true) { // totalview already enrolled
                       BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request cannot be initiated because the client is already enrolled in Total View.</div>", null, " Invitation email not sent ");
                       return false;
        }
                   return true;
        },
        validateSecureSiteRegg: function (emlSndValdRules) {
			var CPData = CPViewModel.getInstance().getData().cola.orgClient.get("orgNm");

			var _colaData = CPViewModel.getInstance().getData().cola;
            var dob = CPViewModel.getInstance().getData().cola.clientPersonal.attributes.bthDt;
            var year=Number(dob.substr(0, 4));
            var month=Number(dob.substr(5, 2)) -1;
            var day=Number(dob.substr(9, 2));
            var today= new Date();
            var age= today.getFullYear() -year;
            if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) { age--; }
            if (CPData == null && _colaData.clientPersonal.attributes.decsdInd === "Y") {
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because deceased clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () { 
                }, "Invitation email not sent");
                return false;
            }

            if (CPData != null) { // entity error
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because Organization clients are not eligible to register for the Secure Site on ameriprise.com</div>", function () {
                }, "Invitation email not sent");
                return false;
            } else if (emlSndValdRules.primaryemail === "") { // no primary email address
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client is missing a primary email address.</div>", null, "Invitation email not sent");
                return false;
            } else if (emailSendValdRules.ameriReg === true) { //not register
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client needs to register for the Secure Site on ameriprise.com to use Total View.<br/></div>", null, "Invitation email not sent");
                return false;
            } else if (emailSendValdRules.undeliverable === true) { // undelivered mail
                BootstrapDialog.alert("<div class='box-with pt-error-icon'>Your request was not submitted because the client's email is undeliverable.</div>", null, " Invitation email not sent ");
                return false;
            }
            return true;
        },
        genericServiceErrorHandler: function (err) {
        	Spinner.hide();
   			HOCUtils.showServiceError(err);
},
        callPutContextService: function (async, v2Compatible) {
        	var _data = {
        	    putAdvsSessCntxAcctIds: null,
        	    putAdvsSessCntxClIds: null,
        	    putAdvsSessCntxDstrIds: null,
        	    putAdvsSessCntxGrpIds: null

        	};
        	if (v2Compatible) {
        	    _data.clCntxIdTypCd = "IDs";
        	}
        	var _gContext = GlobalContext.getInstance().getGlobalContext().Context
        	var _clientId = _gContext.ContactId;
            //_clientId = _clientId.substr(_clientId.length - 8);
            //client context
        	var _clientCtx = {
        	        clId: _clientId,
        	        clCtx: "COLA.CL",
        	        clRole: "PrimaryClient"
        };
        _data.putAdvsSessCntxClIds =[_clientCtx];
            // distributor context
			var _dstrCtx = {
			        dstrId: _gContext.AdvisorFMID,
			        dstrCtx: "DMU.DIST"
        };
        _data.putAdvsSessCntxDstrIds =[_dstrCtx];
        return DataService.putAdvisorSessionContext(_data, (async != undefined) ? async: true);
},
        invokeEbeneWorkflowLinkClick: function () {
            
            var _url = Config.getConfigProperty("ebeneUrl");
            Spinner.show();
            self.callPutContextService(false).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId + "#eBene/";
                    //window.open(_url, "HOC eforms window");
                    window.open(_url);
                    Analytics.analytics.recordAction('HOC:ebenelink:clicked');
                   

                   

                } else {
                    ErrorLog.ErrorUtils.myError(response);
            }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
        });
        },
        invokeMMSLinkClick: function (e) {                    
                var _url = Config.getConfigProperty("mmsLink");
                Spinner.show();
               this.contextPayLoad(_url, e);
        },
        invokePPAReportLinkClick: function (e) {
        	var url = Config.getConfigProperty("ppaReportLink");
        	Device.operatingSystem();
        	Device.physicalDevice();
        	Device.browser();
        	var _deviceInfo = Device.info;
        	var _deviceType = _deviceInfo.hardware.make;
        	if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
        	    self.checkVPNAndOpenLink(url);
        	} else {
        		BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
        	}
        },
        invokeEFormsLinkClick: function (uniqueId) {
            var _hocExtrnlActnLinks = Config.getConfigProperty("hocExtrnlActnLinks");
            var _url = _hocExtrnlActnLinks.sharkEFormsUniqueIDLink;
            _url = _url + uniqueId; //Append UniqueID
            window.open(_url);
        },
        invokeClientAttritionLinkClick: function (uniqueId) {
            var _hocExtrnlActnLinks = Config.getConfigProperty("hocExtrnlActnLinks");
            var _url = _hocExtrnlActnLinks.clientAttritionUniqueID;
            _url = _url + uniqueId; 
            window.open(_url);
        },
        invokeContactDetailLink: function (uniqueId) {
			var _hocExtrnlActnLinks = Config.getConfigProperty("hocExtrnlActnLinks");
			var _url = _hocExtrnlActnLinks.updateContactDetails;
        	_url = _url +uniqueId;
			Device.operatingSystem();
			Device.physicalDevice();
			Device.browser();
			var _deviceInfo = Device.info;
			var _deviceType = _deviceInfo.hardware.make;
			if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
				self.checkVPNAndOpenLink(_url);
			} else { 
				BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable");
			}
        },
        invokeUnclaimedPropertyLink: function (e) {
        	var _hocExtrnlActnLinks = Config.getConfigProperty("hocExtrnlActnLinks");
			var _url = _hocExtrnlActnLinks.unclaimedPropertyRpt;
			Device.operatingSystem();
			Device.physicalDevice();
			Device.browser();
			var _deviceInfo = Device.info;
			var _deviceType = _deviceInfo.hardware.make;
			if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
				self.checkVPNAndOpenLink(_url);
			} else {
				BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable");
            }
        },
        invokeColumbiaReport: function (e) {
        	var url = Config.getConfigProperty("columbiaMutualFundReport");
        	Device.operatingSystem();
        	Device.physicalDevice();
        	Device.browser();
        	var _deviceInfo = Device.info;
        	var _deviceType = _deviceInfo.hardware.make;
        	if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
        	    self.checkVPNAndOpenLink(url);
        	} else {
        		BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
        	}
        },
    	invokePPAEformsLinkClick: function (e) {
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
        		//if ((_deviceInfo.os.type.indexOf('windows') !== - 1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {    
                var _url = Config.getConfigProperty("ppaEformsLink");
                Spinner.show();
                var _v2Compatible = true;
                self.callPutContextService(false, _v2Compatible).then(function (response) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId;
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(function (error) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(error);
        	});
        		/*} else {
					BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
				}*/
        },
        	invokeDOLSSRSReporTLinks: function (actionUrl) {
            var _url = Config.getConfigProperty("hocExtrnlActnLinks")[actionUrl], _deviceInfo, _deviceType;
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            _deviceInfo = Device.info;
            _deviceType = _deviceInfo.hardware.make;
            if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
                self.checkVPNAndOpenLink(_url);
            } else {
                BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable");
        	}
        },
        	checkVPNAndOpenLink: function (url) {
            CommonUtils.checkVPN(function () {
                window.open(url);
        	});
        },
        	contextPayLoad: function (linkName, e) {
            Spinner.show();
            var self = this;
            var _url = linkName;
            var _contextId = null;
            var _v2Compatible = true;
            var async = false;
            var contextResult = CommonUtils.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
            DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url +_contextId;
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
            }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
        	});
        	},
        	invokeBeneOFMLinkClick: function () {
            Device.operatingSystem();
            Device.physicalDevice();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
                var _url = Config.getConfigProperty("beneOFMLink");
                Spinner.show();
            	//context service v2 compatibility mode
                var _v2Compatible = true;
                self.callPutContextService(false, _v2Compatible).then(function (response) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId;
                    	//window.open(_url, "HOC OFM window");
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                }
                }).fail(function (error) {
                    Spinner.hide();
                    ErrorLog.ErrorUtils.prepareAndLogError(error);
            });
            } else {
                BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable");
        	}

        },
        	invokeAuthPersopnUpdateWorkflow: function () {
            var _hocExtrnlActnLinks = Config.getConfigProperty("hocExtrnlActnLinks")
            var _url = _hocExtrnlActnLinks.authPersonUpdateLink;
            Spinner.show();
            self.callPutContextService(false).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId + "#fiduciary-update/";
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
            }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
        	});
        },
        	invokeCFRToolActionClick: function (actionUrl) {
            var _url = Config.getConfigProperty("hocExtrnlActnLinks")[actionUrl], _deviceInfo = self.getDeviceInfo().info, _deviceType = _deviceInfo.hardware.make;
            if (_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) {
                window.open(_url);
            } else {
                BootstrapDialog.alert("This functionality is only available on Windows devices (desktop or Surface)", null, "Function unavailable");
        	}
        },
        	openExternalLinkWithContext: function (options) {
            Spinner.show();
            var _v2Compatible = options.v2Compatible,
                _url = options.url;
            self.callPutContextService(false, _v2Compatible).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId;
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
            }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
        	});
        },
        	getDeviceInfo: function () {
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            return Device
        }
});
return hocView;
});
