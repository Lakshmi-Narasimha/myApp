'use strict';
describe('directive : investor error message', function() {
    var $rootScope, $scope, $compile, validHTML, compiledElement, $filter, errorMsg;

    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.inject(function(_$compile_, _$rootScope_, _$filter_) {
            $rootScope = _$rootScope_;
            $compile = _$compile_;
            $scope = $rootScope.$new();
            $filter = _$filter_;

            validHTML = angular.element('<inv-error-message></inv-error-message>');
            compiledElement = $compile(validHTML)($scope);
            $scope.$digest();
        });
    });

    it('should be defined', function() {
        expect(compiledElement).toBeDefined();
    });

    it('should be available to show error message', function() {
        errorMsg = $filter('translate')(compiledElement.scope().errorObj.message);
		expect(errorMsg).toEqual('We are currently unable to retrieve your data.');
        compiledElement.scope().$digest();
        expect($(compiledElement).find('span')[1].innerHTML).toEqual('We are currently unable to retrieve your data.');
	});

});
