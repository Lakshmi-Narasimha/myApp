'use strict';

var ftiModifySipInitialLoader = function (SipModifyDetailModel, transactEventConstants, transactEvents,toaster) {
    
    var ftiModifySipInitialLoader = {
    	loadAllServices : function (scope,selectedInv) {                    	

            SipModifyDetailModel.fetchSipDetails(selectedInv).then(ModSIPSuccess, handleFailure);

            function ModSIPSuccess (data) {
                SipModifyDetailModel.setModifySipInpDetails(data.retrieveSip);
                transactEvents.transact.publishInvFundGrid(scope);
            }
            function handleFailure (data) {
                console.log('handleFailure');
                toaster.error(data.data[0].errorDescription)
            }
        }
    };
    return ftiModifySipInitialLoader;
};

ftiModifySipInitialLoader.$inject = ['SipModifyDetailModel', 'transactEventConstants', 'transactEvents','toaster'];
module.exports = ftiModifySipInitialLoader;
