'use strict';

var folioValidationDetails= function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _folioValidationDtlsResp = null;

    var folioValidationModel = {
        fetchfolioValidation : function (param) {
            var deferred = $q.defer();
            var body = {};
            body.holders = param;
            var params = {
                "guId" : authenticationService.getUser().guId,
            }
            //Restangular.one('folioValidation').get().then(function (folioValidationDtlsResp) {
                Restangular.one('transact/folioMatcher').customPOST(body, "", params, {}).then(function (folioValidationDtlsResp) {
                console.log(folioValidationDtlsResp);
                deferred.resolve(folioValidationDtlsResp);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        getFolioValidationDtls : function (value) {
            if (!angular.isDefined(_folioValidationDtlsResp)) {
                return null;
            }
            return _folioValidationDtlsResp;
        } ,
        setFolioValidationDtls : function (folioValidationDtlsResp) {
            _folioValidationDtlsResp = folioValidationDtlsResp;
        }

    };
    return folioValidationModel;

};

folioValidationDetails.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = folioValidationDetails;
