var launchAppModelConfig = {
  response: {
  "ResponseInfo": {
    "locale": "EN",
    "type": "Success",
    "server": "saswcvfszwd21.sdc.vzwcorp.com:srv01_wmobilefirst01",
    "buildNumber": "9103",
    "requestId": "5bf72ef6-c9a8-49dd-8048-f6551c7ae05f",
    "mdn": "2397766050",
    "code": "00000",
    "message": "0",
    "userMessage": "0"
  },
  "SystemParams": {
    "feedDismissalEnabled": true,
    "googleMapsAPIKey": "AIzaSyD9-5Q4fTMYESxmbZhYpA98sy7XFK2d0BE",
    "vzwAnalyticsUrl": "https://rdd-dev-w.vzw.com/upload/appAnalytics",
    "enableVzwAnalytics": true,
    "reportClientCrash": true,
    "helpInterceptEnabled": false,
    "enableGoogleMapsIOS": true,
    "touchIdSupported": true
  },
  "Page": {
    "pageType": "firstTimeTnCPage",
    "ButtonMap": {
      "PrimaryButton": {
        "presentationStyle": "root",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "walkthroughPage",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Accept terms",
        "isSelected": false
      },
      "SecondaryButton": {
        "presentationStyle": "root",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "declineFirstTimeTnC",
        "appContext": "mobileFirstSS",
        "actionType": "topAlert",
        "title": "Decline",
        "isSelected": false
      }
    },
    "tncMsg": "<html><body><b>Customer Agreement</b><br/><br/>Your use of My Verizon and any My Verizon services is subject to the terms and conditions of your customer agreement, including the dispute resolution provisions.<br/><br/><b>Password/Personal Identification Number (PIN)</b><br/><br/>You are solely responsible for maintaining the confidentiality of your password and/or PIN code. If your password or PIN code is lost, stolen or used without your permission, call us immediately at 1-800-922-0204.If you disclose your password or PIN to a third party bill payment vendor, Verizon Wireless is not responsible for the accuracy and timeliness of your bill payments.<br/>You consent to delivery of PIN codes by text message to your wireless phone unless Verizon Wireless determines that your wireless phone is not capable of receiving text messages.<br/><br/><b>Paper-Free Billing</b><br/><br/>You may enroll in paperless billing through My Verizon, which means you will no longer receive a paper bill and you accept the presentation of your bill online through My Verizon or by email.<br/><br/><b>Trademarks</b> You may not use any Verizon Wireless trademarks or service marks without Verizon Wireless's prior written permission. For information about usage or licensing, see our <a href=\"https://www.verizonwireless.com/b2c/globalText?textName=WEBSITE_USE&jspName=footer/webuse.jsp\">Website Use Terms and Conditions.</a><br/><br/><b>4. Trademarks</b><br/><br/>You may not use any Verizon trademarks or service marks without Verizon's prior written permission.  For information about usage or licensing, see our <a href=\"https://www.verizonwireless.com/b2c/globalText?textName=WEBSITE_USE&jspName=footer/webuse.jsp\">Website Use Terms and Conditions</a>.<br/><br/><b>5. U.S Export Laws</b><br/><br/>Your use of the App and Verizon Wireless online services is subject to U.S. export control laws and regulations.  You represent that you are not a citizen of an embargoed country or prohibited end user under applicable U.S. export and anti-terrorism laws, regulations and lists.  You will not use, export or allow a third party to use or export Verizon Wireless online services in any manner that would violate applicable law, including but not limited to applicable export control laws and regulations.<br/><br/><b>6. Privacy</b><br/><br/>For information on privacy, see our <br/> <a href=\"http://www.verizon.com/about/privacy/privacy-policy-summary\">Privacy Policy</a>.<br/><br/><b>7. Website Use Terms and Conditions</b> <br/><br/>Your use of My Verizon is subject to our <a href=\"https://www.verizonwireless.com/b2c/globalText?textName=WEBSITE_USE&jspName=footer/webuse.jsp\">Website Use Terms and Conditions</a>.<br/><br/><b>8.    Open Source Software</b><br/><br/>This application may contain certain software covered by open source or third party licensing requirements.  All such software is subject to the copyrights of the authors and to the terms of the applicable licenses below or available for download at <a href=\"http://www.verizon.com/opensource\">www.verizon.com/opensource</a>.<br/><br/>",
    "message": "Review and accept our Terms and Conditions.",
    "title": "And, here's the fine print.",
    "pageStatNames": [
      "/mf/am/login/with/mobilesso",
      "/mf/login/with/usernm/pwd",
      "/mf/login/with/wifi",
      "/mf/etni/get/etni/data",
      "/mf/plan/id",
      "/mf/resume/shopping/feed",
      "/mf/search/support/feed",
      "/mf/unlimited/plan/feed",
      "/mf/unlimited/plan/feed/shown",
      "/mf/billing/feed",
      "/mf/usage/feed",
      "/mf/launchapp/intercept/wifi/accountpin/setup/page",
      "unknown",
      "/mf/pin/valid/no/accountpin/intercept",
      "/mf/cntrlr/launchapp"
    ]
  },
  "ModuleMap": {
    "DataMeterData": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "Timestamp": "03/03/17 01:51 PM",
      "TotalAvailableData": "0",
      "DataUnits": "GB",
      "daysLeft": "25",
      "overageGB": "0",
      "text": "TVP",
      "MaximumAllowance": "36",
      "realEstDt": "N",
      "custType": "PE",
      "UsageData": "0",
      "planRemaining": "36",
      "percentageRemaining": "100",
      "usageMdn": "2397766050",
      "overageAmount": "0",
      "experienceId": "0",
      "planState": "1"
    },
    "ClearSpotTopAlertEnded": {
      "ResponseInfo": {
        "locale": "EN",
        "messageStyle": "Top",
        "type": "ClearSpotTopAlertEnded",
        "code": "00000",
        "message": "Your PopData session ended.",
        "userMessage": "Check for another available session.",
        "ButtonMap": {
          "presentationStyle": "push",
          "tryToReplaceFirst": true,
          "disableAction": false,
          "selected": false,
          "pageType": "getMoreDataSelector",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Check",
          "isSelected": false,
          "extraParameters": {
            "feedName": "ClearSpotTopAlertEnded"
          }
        }
      }
    },
    "SearchSupportFeed": {
      "categoryName": "CATEGORY_SEARCH_SUPPORT_BAR",
      "source": "EASY_RULE",
      "ButtonMap": {
        "FeedLink": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "getSupport",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Tell us what you need.",
          "isSelected": false,
          "extraParameters": {
            "feedName": "SearchSupportFeed"
          }
        }
      },
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "feedType": "bar",
      "iconName": "icon_grey_search",
      "contentID": "SEARCH_SUPPORT",
      "dismissible": false,
      "moduleName": "SearchSupportFeed"
    },
    "ClearSpotTopAlertMain": {
      "ResponseInfo": {
        "locale": "EN",
        "messageStyle": "TopPersistent",
        "type": "ClearSpotTopAlertMain",
        "code": "00000",
        "message": "Your session is coming to an end.",
        "userMessage": "remaining on PopData.",
        "ButtonMap": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "collapseNotification",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Okay",
          "isSelected": false,
          "extraParameters": {
            "feedName": "ClearSpotTopAlertMain"
          }
        }
      }
    },
    "DeepLinkMapping": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "deviceDetailsList": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "deviceLanding",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "device details",
        "isSelected": false
      },
      "launchRCApp": {
        "presentationStyle": "root",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myFeed",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "App Launch",
        "isSelected": false
      },
      "displayAccountManagersInfo": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "displayAccountManagersInfo",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "for account manager deeplink",
        "isSelected": false
      },
      "retailfeedback": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "retailfeedback",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Retail Feedback",
        "isSelected": false
      },
      "safetyModeIntroDetails": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "safetyModeIntroDetails",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Safety Mode Landing",
        "isSelected": false
      },
      "paperlessBilling": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "paperFreeBill",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "View Paperfree Billing",
        "isSelected": false
      },
      "carryoverDataDetails": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "carryoverDataDetails",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Carryover Landing",
        "isSelected": false
      },
      "allUsageDetails": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myData",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "All usage details",
        "isSelected": false
      },
      "getMoreData": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "purchaseDataBoost",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Data Boost Purchase",
        "isSelected": false
      },
      "intlGlobPageInfo": {
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "internationalUsage",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "International Plan Overview",
        "isSelected": false
      },
      "accountFamilyBase": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "familyBase",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Account - Family Base",
        "isSelected": false
      },
      "productDetails": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "productDetails",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Product Description",
        "isSelected": false
      },
      "smartPhoneGridwall": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "shopLanding",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Smartphone Gridwall",
        "isSelected": false
      },
      "shopNavigationFromPromotionFeed": {
        "browserUrl": "gridwall",
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "shopNavigationFromPromotionFeed",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "iconic landing",
        "isSelected": false
      },
      "clearspotLandingPage": {
        "presentationStyle": "push",
        "tryToReplaceFirst": true,
        "disableAction": false,
        "selected": false,
        "pageType": "getMoreDataSelector",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Clear Spot",
        "isSelected": false
      },
      "tabletGridwall": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "shopLanding",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Tablet Gridwall",
        "isSelected": false
      },
      "accountLanding": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "accountLanding",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Account - Home",
        "isSelected": false
      },
      "safeguardsSelectCallMsgBlock": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "ViewCMB",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Account - Device: Call and Message Blocking",
        "isSelected": false
      },
      "privacy": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "noDeeplink",
        "appContext": "mobileFirstSS",
        "actionType": "back",
        "title": "Privacy",
        "isSelected": false
      },
      "familyBaseLanding": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "familyBase",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Family Base Landing",
        "isSelected": false
      },
      "mngProfile": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "mngProfile",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Manage account",
        "isSelected": false
      },
      "dataHubOverview": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myData",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "DataHub Overview",
        "isSelected": false
      },
      "myFeed": {
        "presentationStyle": "root",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myFeed",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Feed",
        "isSelected": false
      },
      "manageFeatures": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "addOns",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Manage features",
        "isSelected": false
      },
      "chgplan": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myPlan",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Change plan",
        "isSelected": false
      },
      "myPlan": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myPlan",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Change plan",
        "isSelected": false
      },
      "changeAddr": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "accountLanding",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Manage Account",
        "isSelected": false
      },
      "felixPlanLanding": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "felixPlanLandingPage",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Felix Landing",
        "isSelected": false
      },
      "bill": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "billOverview",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "bill details",
        "isSelected": false
      },
      "safeguards": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "familyBase",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "safeguards details",
        "isSelected": false
      },
      "shopVerizon": {
        "presentationStyle": "root",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "gridwall",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Shop Verizon",
        "isSelected": false
      },
      "paymentArrangement": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "noDeeplink",
        "appContext": "mobileFirstSS",
        "actionType": "back",
        "title": "Payment arrangement",
        "isSelected": false
      },
      "EditEmailAddress": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "mngProfile",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "edit email details",
        "isSelected": false
      },
      "billSettingsPage": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "billSettings",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Bill Settings",
        "isSelected": false
      },
      "manageAccount": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "accountLanding",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Manage account",
        "isSelected": false
      },
      "miniGuideClearspot": {
        "presentationStyle": "modal",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "miniGuideClearspot",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Popdata Miniguide",
        "isSelected": false
      },
      "getSupport": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "getSupport",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Support Drawer",
        "isSelected": false
      },
      "autoPayLanding": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "manageAutopay",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Autopay",
        "isSelected": false
      },
      "safeguardsSingle": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "familyBase",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Family Base Landing",
        "isSelected": false
      },
      "nearestStore": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "storeLocator",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Store Locator",
        "isSelected": false
      },
      "purchaseDataBoost": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "purchaseDataBoost",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Data Boost Purchase",
        "isSelected": false
      },
      "shopLanding": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "shopLanding",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Shop Landing",
        "isSelected": false
      },
      "deviceManagement": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "deviceLanding",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Device Management",
        "isSelected": false
      },
      "rcaccountsummary": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "shopLanding",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Shop Deals",
        "isSelected": false
      },
      "changeFeatures": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "addOns",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Add-ons Landing",
        "isSelected": false
      },
      "payment": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "payBill",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Bill Payment Method (non click pay)",
        "isSelected": false
      },
      "eligibleDeviceListLanding": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "eligibleDeviceListLanding",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "International Ready Check Landing",
        "isSelected": false
      },
      "payment_ptp": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "billOverview",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "View details",
        "isSelected": false
      },
      "shopDeals": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "shopLanding",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Shop Deals",
        "isSelected": false
      },
      "dataHubDetails": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myData",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "DataHub Details",
        "isSelected": false
      },
      "getAccessoryDetails": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "getAccessoryDetails",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Accessory Details",
        "isSelected": false
      },
      "usageDetailsSummary": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myData",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Get more data",
        "isSelected": false
      },
      "MyFeedRCLaunch": {
        "presentationStyle": "root",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myFeed",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "clearspot feed",
        "isSelected": false
      },
      "accessoryLandingWithoutTabs": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "accessoryLandingWithoutTabs",
        "appContext": "mobileFirstShop",
        "actionType": "openPage",
        "title": "Shop Accessory Landing",
        "isSelected": false
      },
      "usage": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myData",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "Get more data",
        "isSelected": false
      },
      "UsageOverview": {
        "presentationStyle": "push",
        "tryToReplaceFirst": false,
        "disableAction": false,
        "selected": false,
        "pageType": "myData",
        "appContext": "mobileFirstSS",
        "actionType": "openPage",
        "title": "DataHub Details",
        "isSelected": false
      }
    },
    "Breadcrumb": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "dataMsgValue": "100%",
      "billMsgValue": "$1114.98",
      "billMsgText": "Due",
      "dataMsgText": "data remaining",
      "billValColor": "#000000",
      "dataValColor": "#000000"
    },
    "Spotlight": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "userImageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/GlobalNav_AccountOwner_MF",
      "menu": [
        {
          "name": "Change Plan",
          "imageName": "icon_forceTouchPlan",
          "searchKey": "change plan",
          "searchName": "Data Change Plan",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "chgplan",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Change Plan",
            "isSelected": false
          }
        },
        {
          "name": "Manage Add-On",
          "imageName": "icon_forceTouchFeatures",
          "searchKey": "change feature",
          "searchName": "Feature Change",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "manageFeatures",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Manage Add-On",
            "isSelected": false
          }
        },
        {
          "name": "Pay Bill",
          "imageName": "icon_forceTouchPayBill",
          "searchKey": "pay bill",
          "searchName": "Pay your bill",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "bill",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Pay Bill",
            "isSelected": false
          }
        },
        {
          "name": "Feed",
          "imageName": "icon_feed",
          "searchKey": "Verizon, my Verizon, Feed",
          "searchName": "The My Verizon feed gives you information about your bill, data usage and upgrades.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "myFeed",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Feed",
            "isSelected": false
          }
        },
        {
          "name": "Account - Home",
          "imageName": "icon_accountLanding",
          "searchKey": "Manage Verizon, Verizon Account, account, my account, manage account, my account, account manager, unlimited data change data plan",
          "searchName": "Check in on your Verizon account to make changes and manage all lines.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "accountLanding",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Account - Home",
            "isSelected": false
          }
        },
        {
          "name": "Account - Device: Call and Message Blocking",
          "imageName": "icon_callMessage",
          "searchKey": "block, block number, unblock, unblock number",
          "searchName": "Block or unblock a number from sending calls and messages to your device.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "safeguardsSelectCallMsgBlock",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Account - Device: Call and Message Blocking",
            "isSelected": false
          }
        },
        {
          "name": "Bill Overview",
          "imageName": "icon_billOverview",
          "searchKey": "bill, pay bill, view bill, billing, my bill, see bill, bill details, bill breakdown, balance, I owe, amount owed, my balance, what do I owe, credit, pay, invoice, payment",
          "searchName": "Get a breakdown of your bill, see your payment history and make payments easily.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "bill",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Bill Overview",
            "isSelected": false
          }
        },
        {
          "name": "DataHub Overview",
          "imageName": "icon_dataHubOverview",
          "searchKey": "data, my data, data usage, manage data, data left, data remaining, data used, monthly data, data hub, data limits, overage, overage charge, over limit, unlimited, bonus data, freebee data",
          "searchName": "Keep tabs on your data with a detailed breakdown of data usage.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "dataHubOverview",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "DataHub Overview",
            "isSelected": false
          }
        },
        {
          "name": "DataHub Details",
          "imageName": "icon_dataHubDetails",
          "searchKey": "text limits, text, texts, minutes, minutes used, minutes left, minutes remaining, sms limits, sms remaining, sms left, text messages, messages",
          "searchName": "Get an up-to-date breakdown of your text and minutes usage.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "usage",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "DataHub Details",
            "isSelected": false
          }
        },
        {
          "name": "Device Management",
          "imageName": "icon_deviceManangement",
          "searchKey": "manage iphone, manage ipad, manage phone, manage tablet, upgrade, upgrade date, when can I upgrade, upgrade eligibility, upgrades, my upgrades, can I upgrade",
          "searchName": "Manage your devices and check in on your upgrade eligibility.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "deviceManagement",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Device Management",
            "isSelected": false
          }
        },
        {
          "name": "Shop Landing",
          "imageName": "icon_shopLanding",
          "searchKey": "add a line, new number, new line, shop, products, ringback, hotspot, Verizon Phone",
          "searchName": "Browse all of our products and add lines or numbers to your account.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "shopLanding",
            "appContext": "mobileFirstShop",
            "actionType": "openPage",
            "title": "Shop Landing",
            "isSelected": false
          }
        },
        {
          "name": "Shop Deals",
          "imageName": "icon_shopDeals",
          "searchKey": "deals, promos, gift certificates",
          "searchName": "Take a look through deals and promos or buy gift certificates.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "shopDeals",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Shop Deals",
            "isSelected": false
          }
        },
        {
          "name": "Get More Data",
          "imageName": "icon_getMoreData",
          "searchKey": "add data, get data",
          "searchName": "Need more data? It's easy to up your allowance.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "getMoreData",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Get More Data",
            "isSelected": false
          }
        },
        {
          "name": "Data Boost Purchase",
          "imageName": "icon_purchaseDataBoost",
          "searchKey": "more data, data boost",
          "searchName": "Add a Data Boost to up your allowance for this billing cycle.",
          "itemName": null,
         "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "purchaseDataBoost",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Data Boost Purchase",
            "isSelected": false
          }
        },
        {
          "name": "International Plan Overview",
          "imageName": "icon_intlPlanOverview",
          "searchKey": "international plan, manage international",
          "searchName": "Get more information on international plans before you travel.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "intlGlobPageInfo",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "International Plan Overview",
            "isSelected": false
          }
        },
        {
          "name": "Bill Payment Method (one click pay)",
          "imageName": "icon_billPayment",
          "searchKey": "debit, atm",
          "searchName": "View and make changes to your current payment methods.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "payment",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Bill Payment Method (one click pay)",
            "isSelected": false
          }
        },
        {
          "name": "Store Locator",
          "imageName": "icon_storeLocator",
          "searchKey": "pay cash",
          "searchName": "Find a Verizon store nearby to pay your bill in cash.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "nearestStore",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Store Locator",
            "isSelected": false
          }
        },
        {
          "name": "Account - Family Base",
          "imageName": "icon_accountFamilyBase",
          "searchKey": "family base",
          "searchName": "View your FamilyBase limits on data, voice and messaging.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "accountFamilyBase",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Account - Family Base",
            "isSelected": false
          }
        },
        {
          "name": "Family Base Landing",
          "imageName": "icon_familyBaseLanding",
          "searchKey": "familybase limits",
          "searchName": "Make adjustments to FamilyBase limits on data, voice and messaging.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "familyBaseLanding",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Family Base Landing",
            "isSelected": false
          }
        },
        {
          "name": "Safety Mode Landing",
          "imageName": "icon_safetyModeLanding",
          "searchKey": "safety mode",
          "searchName": "Learn more about Safety Mode, which makes it easier to avoid surprise overages.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "safetyModeIntroDetails",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Safety Mode Landing",
            "isSelected": false
          }
        },
        {
          "name": "Carryover Landing",
          "imageName": "icon_carryOverData",
          "searchKey": "carryover data",
          "searchName": "Learn more about Carryover Data, which carries unused data over to the next month.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "carryoverDataDetails",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Carryover Landing",
            "isSelected": false
          }
        },
        {
          "name": "Popdata Miniguide",
          "imageName": "icon_popDataMiniguide",
          "searchKey": "popdata",
          "searchName": "Learn more about PopData, our unlimited data streaming sessions.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "miniGuideClearspot",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Popdata Miniguide",
            "isSelected": false
          }
        },
        {
          "name": "International Ready Check Landing",
          "imageName": "icon_intlCheck",
          "searchKey": "international phone",
          "searchName": "Use International Ready Check to make sure your phone is ready for your trip.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "eligibleDeviceListLanding",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "International Ready Check Landing",
            "isSelected": false
          }
        },
        {
          "name": "Add-ons Landing",
          "imageName": "icon_addonsLanding",
          "searchKey": "add ons",
          "searchName": "Take a look through your add-on options to get the most out of your device.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "changeFeatures",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Add-ons Landing",
            "isSelected": false
          }
        },
        {
          "name": "Tablet Gridwall",
          "imageName": "icon_tabletGridwall",
          "searchKey": "buy tablet, upgrade tablet, upgrade ipad",
          "searchName": "Browse and compare tablets before buying or upgrading your device.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "tabletGridwall",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Tablet Gridwall",
            "isSelected": false
          }
        },
        {
          "name": "Smartphone Gridwall",
          "imageName": "icon_smartPhGridwall",
          "searchKey": "upgrade phone, buy phone, upgrade iphone, iphone",
          "searchName": "Browse and compare smartphones before buying or upgrading your device.",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "smartPhoneGridwall",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Smartphone Gridwall",
            "isSelected": false
          }
        }
      ],
      "displayRole": "Account Owner",
      "displayName": "DAN SWARTZ"
    },
    "NavigationMenu": {
      "ButtonMap": {
        "Feedback": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "selectFeedbackSource",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Feedback",
          "isSelected": false
        },
        "SignOut": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "confirmSignOut",
          "appContext": "mobileFirstSS",
          "actionType": "popup",
          "title": "Sign Out",
          "isSelected": false
        }
      },
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "userImageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/GlobalNav_AccountOwner_MF",
      "menu": [
        {
          "name": "Feed",
          "imageName": "icon_nav_myfeed_selected",
          "altImageName": "icon_nav_myfeed_deselected",
          "highlightedColor": "#91BEFA",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "myFeed",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Feed",
            "isSelected": false
          }
        },
        {
          "name": "Data Hub",
          "imageName": "icon_nav_data_selected",
          "altImageName": "icon_nav_data_deselected",
          "searchKey": "SearchKey",
          "searchName": "SearchName",
          "highlightedColor": "#9CD8F4",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "myData",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Data Hub",
            "isSelected": false
          }
        },
        {
          "name": "Bill",
          "imageName": "icon_nav_bill_selected",
          "altImageName": "icon_nav_bill_deselected",
          "searchKey": "SearchKey",
          "searchName": "SearchName",
          "highlightedColor": "#82CEAC",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "billOverview",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Bill",
            "isSelected": false
          }
        },
        {
          "name": "Shop",
          "imageName": "icon_nav_gridwall_selected",
          "altImageName": "icon_nav_gridwall_deselected",
          "searchKey": "SearchKey",
          "searchName": "SearchName",
          "highlightedColor": "#F9B295",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "shopHomePage",
            "appContext": "mobileFirstShop",
            "actionType": "openPage",
            "title": "Shop",
            "isSelected": false
          }
        },
        {
          "name": "Account",
          "imageName": "icon_nav_account_selected",
          "altImageName": "icon_nav_account_deselected",
          "searchKey": "SearchKey",
          "searchName": "SearchName",
          "highlightedColor": "#fa7d92",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "accountLanding",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Account",
            "isSelected": false
          }
        },
        {
          "name": "Devices",
          "imageName": "icon_nav_device_selected",
          "altImageName": "icon_nav_device_deselected",
          "searchKey": "SearchKey",
          "searchName": "SearchName",
          "highlightedColor": "#69b2d5",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "deviceLanding",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Devices",
            "isSelected": false
          }
        },
        {
          "name": "Visit Us",
          "imageName": "icon_nav_visit_us_selected",
          "altImageName": "icon_nav_visit_us_deselected",
          "searchKey": "SearchKey",
          "searchName": "SearchName",
          "highlightedColor": "#C596FA",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "visitUsRtl",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Visit Us",
            "isSelected": false
          }
        }
      ],
      "displayRole": "Account Owner",
      "displayName": "DAN SWARTZ"
    },
    "AppShortcut": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "userImageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/GlobalNav_AccountOwner_MF",
      "menu": [
        {
          "name": "Change Plan",
          "imageName": "icon_forceTouchPlan",
          "searchKey": "change plan",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "chgplan",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Change Plan",
            "isSelected": false
          }
        },
        {
          "name": "Pay Bill",
          "imageName": "icon_forceTouchPayBill",
          "searchKey": "pay bill",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "bill",
            "appContext": "mobileFirstSS",
            "actionType": "openPage",
            "title": "Pay Bill",
            "isSelected": false
          }
        },
        {
          "name": "Shop",
          "imageName": "icon_forceTouchFeatures",
          "itemName": null,
          "ActionMap": {
            "presentationStyle": "root",
            "tryToReplaceFirst": false,
            "disableAction": false,
            "selected": false,
            "pageType": "shopLanding",
            "appContext": "mobileFirstShop",
            "actionType": "openPage",
            "title": "Shop",
            "isSelected": false
          }
        }
      ],
      "displayRole": "Account Owner",
      "displayName": "DAN SWARTZ"
    },
    "UsageFeed": {
      "categoryName": "GOOD_ON_DATA",
      "source": "DROOLS",
      "adobeTag": {
        "vzwi.mvmapp.feedCategory": "Data",
        "vzwi.mvmapp.feedSubCategory": "Usage",
        "vzwi.mvmapp.feedServerSubCategory": "GOOD_ON_DATA"
      },
      "ButtonMap": {
        "FeedLink": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "myData",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "View details",
          "isSelected": false,
          "extraParameters": {
            "feedName": "UsageFeed"
          }
        }
      },
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "hdgMsg": "You're good on data.",
      "billCycleEndDate": "03/28/2017",
      "dataMeter": "1",
      "graphData": [
        {
          "category": "BONUS",
          "totalRemainingPercentageContribution": "5.56",
          "totalUsed": "0",
          "totalAllowed": "2",
          "color": "#83CBAA",
          "unit": "GB",
          "totalRemaining": "2",
          "remainingPercentage": "100",
          "usedPercentage": 0,
          "order": 1,
          "imageName": "icon_data_bonus",
          "message": "Currently remaining",
          "displayName": "Bonus Data",
          "currentlyInUse": true,
          "labelColor": "#83CBAA",
          "backgroundColor": "#F6F6F6"
        },
        {
          "category": "PLAN",
          "totalRemainingPercentageContribution": "44.44",
          "totalUsed": "0",
          "totalAllowed": "16",
          "color": "#ABE0F9",
          "unit": "GB",
          "totalRemaining": "16",
          "remainingPercentage": "100",
          "usedPercentage": 0,
          "order": 2,
          "message": "Will be used next",
          "displayName": "16 GB XL Verizon Plan",
          "labelColor": "#ABE0F9",
          "backgroundColor": "#ffffff"
        },
        {
          "category": "CARRYOVER",
          "totalRemainingPercentageContribution": "50",
          "totalUsed": "0",
          "totalAllowed": "18",
          "color": "#91befa",
          "unit": "GB",
          "totalRemaining": "18",
          "remainingPercentage": "100",
          "usedPercentage": 0,
          "order": 3,
          "imageName": "icon_data_carryover",
          "message": "Unused data from last cycle",
          "displayName": "Carryover Data",
          "status": "Expires end of month",
          "labelColor": "#91befa",
          "backgroundColor": "#ffffff"
        }
      ],
      "totalAllowed": "36",
      "totalDataRemaining": "36",
      "totalDataRemainingPercentage": "100",
      "unit": "GB",
      "feedType": "graphicHeadlineMedium",
      "totalUsed": "0",
      "blockAnimations": true,
      "headlineMsg": "100% data remaining.",
      "contentID": "DATA_USAGE",
      "dismissible": false,
      "moduleName": "UsageFeed",
      "headlineMsg2": "You have 36 of 36 GB remaining.",
      "overageQty": "0.0",
      "isOverage": false,
      "subHdgMsg": "36 GB remaining with 25 days left.",
      "overageCostIncured": "\ufffd"
    },
    "UnLimitedFeed": {
      "categoryName": "UNLIMITED_FEED_RULE",
      "source": "EASY_RULE",
      "adobeTag": {
        "vzwi.mvmapp.feedCategory": "Data",
        "vzwi.mvmapp.feedSubCategory": "UnlimitedData",
        "vzwi.mvmapp.feedServerSubCategory": null
      },
      "ButtonMap": {
        "FeedLink": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "felixPlanLandingPage",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "View plans",
          "isSelected": false,
          "extraParameters": {
            "statsName": "UNLIMITED_PLAN",
            "feedName": "UnLimitedFeed",
            "recommendedSharePlanId": "98127"
          }
        }
      },
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/MF_Felix_FeedCard_Template_2000x1681px",
      "feedType": "headlineBleedImage",
      "headlineMsg": "Stream all you want with unlimited data.",
      "statsName": "UNLIMITED_PLAN",
      "contentID": "UNLIMITED",
      "dismissible": false,
      "moduleName": "UnLimitedFeed",
      "linkTextColor": "#FFFFFF",
      "headlineBGColor": "#FFFFFF"
    },
    "BillingFeed": {
      "categoryName": "BILLING_FEED_NO_PAST_DUE_MORETHAN7DAYS_RULE",
      "source": "DROOLS",
      "adobeTag": {
        "vzwi.mvmapp.feedCategory": "Data",
        "vzwi.mvmapp.feedSubCategory": "Buy Data",
        "vzwi.mvmapp.feedServerSubCategory": "BILLING_FEED_NO_PAST_DUE_MORETHAN7DAYS_RULE"
      },
      "ButtonMap": {
        "FeedLink": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "payBill",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Pay bill",
          "isSelected": false,
          "extraParameters": {
            "feedName": "BillingFeed"
          }
        }
      },
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "amount": "1114.98",
      "feedType": "headlineNoImageMedium",
      "headlineMsg": "Your next bill is ready. $1114.98",
      "contentID": "BILLING_INFO",
      "dismissible": false,
      "moduleName": "BillingFeed",
      "subHdgMsg": "Due on Mar 23."
    },
    "Greeting": {
      "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
      },
      "accountGrtName": "Hey, Lebowski.",
      "greetingName": "Hey, Lebowski",
      "name": "Lebowski"
    }
  },
  "PageMap": {
    "reviewAlertPopUpPage": {
      "pageType": "reviewAlertPopUpPage",
      "errorList": "404,400,500",
      "timeToWaitForReview": "5",
      "reviewPageTypes": "billOverview,gridwall,accountLanding,myFeed",
      "appURL": "https://play.google.com/store/apps/details?id=com.vzw.hss.myverizon",
      "reviewMessage": "Would you like to review the app?",
      "remindReviewCount": "5",
      "noThanksBtn": "No Thanks",
      "remindMeLaterBtn": "Remind Me Later",
      "remindReviewLater": true,
      "reviewAppBtn": "Review App",
      "reviewTitle": "Review App"
    },
    "firstTimeTnCPage": {
      "pageType": "firstTimeTnCPage",
      "ButtonMap": {
        "PrimaryButton": {
          "presentationStyle": "root",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "walkthroughPage",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Accept terms",
          "isSelected": false
        },
        "SecondaryButton": {
          "presentationStyle": "root",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "declineFirstTimeTnC",
          "appContext": "mobileFirstSS",
          "actionType": "topAlert",
          "title": "Decline",
          "isSelected": false
        }
      },
      "tncMsg": "<html><body><b>Customer Agreement</b><br/><br/>Your use of My Verizon and any My Verizon services is subject to the terms and conditions of your customer agreement, including the dispute resolution provisions.<br/><br/><b>Password/Personal Identification Number (PIN)</b><br/><br/>You are solely responsible for maintaining the confidentiality of your password and/or PIN code. If your password or PIN code is lost, stolen or used without your permission, call us immediately at 1-800-922-0204.If you disclose your password or PIN to a third party bill payment vendor, Verizon Wireless is not responsible for the accuracy and timeliness of your bill payments.<br/>You consent to delivery of PIN codes by text message to your wireless phone unless Verizon Wireless determines that your wireless phone is not capable of receiving text messages.<br/><br/><b>Paper-Free Billing</b><br/><br/>You may enroll in paperless billing through My Verizon, which means you will no longer receive a paper bill and you accept the presentation of your bill online through My Verizon or by email.<br/><br/><b>Trademarks</b> You may not use any Verizon Wireless trademarks or service marks without Verizon Wireless's prior written permission. For information about usage or licensing, see our <a href=\"https://www.verizonwireless.com/b2c/globalText?textName=WEBSITE_USE&jspName=footer/webuse.jsp\">Website Use Terms and Conditions.</a><br/><br/><b>4. Trademarks</b><br/><br/>You may not use any Verizon trademarks or service marks without Verizon's prior written permission.  For information about usage or licensing, see our <a href=\"https://www.verizonwireless.com/b2c/globalText?textName=WEBSITE_USE&jspName=footer/webuse.jsp\">Website Use Terms and Conditions</a>.<br/><br/><b>5. U.S Export Laws</b><br/><br/>Your use of the App and Verizon Wireless online services is subject to U.S. export control laws and regulations.  You represent that you are not a citizen of an embargoed country or prohibited end user under applicable U.S. export and anti-terrorism laws, regulations and lists.  You will not use, export or allow a third party to use or export Verizon Wireless online services in any manner that would violate applicable law, including but not limited to applicable export control laws and regulations.<br/><br/><b>6. Privacy</b><br/><br/>For information on privacy, see our <br/> <a href=\"http://www.verizon.com/about/privacy/privacy-policy-summary\">Privacy Policy</a>.<br/><br/><b>7. Website Use Terms and Conditions</b> <br/><br/>Your use of My Verizon is subject to our <a href=\"https://www.verizonwireless.com/b2c/globalText?textName=WEBSITE_USE&jspName=footer/webuse.jsp\">Website Use Terms and Conditions</a>.<br/><br/><b>8.    Open Source Software</b><br/><br/>This application may contain certain software covered by open source or third party licensing requirements.  All such software is subject to the copyrights of the authors and to the terms of the applicable licenses below or available for download at <a href=\"http://www.verizon.com/opensource\">www.verizon.com/opensource</a>.<br/><br/>",
      "message": "Review and accept our Terms and Conditions.",
      "title": "And, here's the fine print.",
      "pageStatNames": [
        "/mf/am/login/with/mobilesso",
        "/mf/login/with/usernm/pwd",
        "/mf/login/with/wifi",
        "/mf/etni/get/etni/data",
        "/mf/plan/id",
        "/mf/resume/shopping/feed",
        "/mf/search/support/feed",
        "/mf/unlimited/plan/feed",
        "/mf/unlimited/plan/feed/shown",
        "/mf/billing/feed",
        "/mf/usage/feed",
        "/mf/launchapp/intercept/wifi/accountpin/setup/page",
        "unknown",
        "/mf/pin/valid/no/accountpin/intercept",
        "/mf/cntrlr/launchapp"
      ]
    },
    "myFeed": {
      "pageType": "myFeed",
      "parentPageType": "myFeed",
      "ButtonMap": {
        "Support": {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "getSupportModules",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Support",
          "isSelected": false
        },
        "Cart": {
          "presentationStyle": "push",
          "tryToReplaceFirst": true,
          "disableAction": false,
          "selected": false,
          "pageType": "genericCart",
          "appContext": "mobileFirstShop",
          "actionType": "openPage",
          "title": "Cart",
          "isSelected": false
        }
      },
      "feedDismissDuration": 10,
      "feedOrder": [
        "SearchSupportFeed",
        "UnLimitedFeed",
        "UsageFeed",
        "BillingFeed"
      ],
      "loggedInMdn": "2397766050",
      "role": "accountHolder",
      "presentationStyle": "root"
    },
    "getSupport": {
      "pageType": "getSupport",
      "nextmsgId": "106",
      "dbUnLocker": "1234jiwjfs8jleks;==9980mlm;s990skkwpp99ff9fjdkjfoedjhgedgvedjvlejdvnelgepgfeoofefekfoieoifoifoifoeofofioeifipfiwofipsifpsi222fwwf",
      "searchBarButtonTitle": "Menu",
      "chatBaseURL": "https://mobile-nqa.vzw.com",
      "searchMessage": "Tell us what you need",
      "analyticsPageName": "/mf/support",
      "screenHeading": "Support"
    },
    "leavingApp": {
      "pageType": "leavingApp",
      "Links": [
        {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "cancel",
          "appContext": "mobileFirstSS",
          "actionType": "cancel",
          "title": "CANCEL",
          "isSelected": false
        },
        {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "invalidateSession",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "CONFIRM",
          "isSelected": false
        }
      ],
      "message": "Going back will close the app. Are sure you don't want to stick around?",
      "title": "Are you sure?"
    },
    "declineFirstTimeTnC": {
      "pageType": "declineFirstTimeTnC",
      "ResponseInfo": {
        "locale": "EN",
        "messageStyle": "Top",
        "type": "GlobalError",
        "code": "30036",
        "message": "Please accept the Terms and Conditions to continue.",
        "userMessage": "Please accept the Terms and Conditions to continue."
      },
      "presentationStyle": "root"
    },
    "confirmSignOut": {
      "pageType": "confirmSignOut",
      "parentPageType": "myFeed",
      "Links": [
        {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "cancel",
          "appContext": "mobileFirstSS",
          "actionType": "cancel",
          "title": "Cancel",
          "isSelected": false
        },
        {
          "presentationStyle": "root",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "signOut",
          "appContext": "mobileFirstSS",
          "actionType": "restart",
          "title": "Sign out",
          "isSelected": false
        }
      ],
      "message": "Are you sure you want to sign out?",
      "title": "Sign out"
    },
    "walkthroughPage": {
      "pageType": "walkthroughPage",
      "ButtonMap": {
        "SecondaryButton": {
          "presentationStyle": "root",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "myFeed",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Let's Go",
          "isSelected": false
        }
      },
      "presentationStyle": "root",
      "pages": [
        {
          "imageURL": "",
          "message": "More control. Less work.\nSwipe to see what's new.",
          "presentationStyle": "root",
          "title": "Introducing the new\nMy Verizon app.",
          "videoTransition": "transition1",
          "videoBackward": "transition2_reversed",
          "imageName": "walkThroughSlide1",
          "videoForward": "loop1"
        },
        {
          "imageURL": "",
          "message": "Complete control to buy, save and\nmanage your data. And no more surprises.",
          "presentationStyle": "root",
          "title": "Your data. Your way.",
          "videoTransition": "transition2",
          "videoBackward": "transition3_reversed",
          "imageName": "walkThroughSlide2",
         "videoForward": "loop2"
        },
        {
          "imageURL": "",
          "message": "The faster way to get what you want.",
          "presentationStyle": "root",
          "title": "Shop and Upgrade\nin minutes.",
          "videoTransition": "transition3",
          "videoBackward": "transition4_reversed",
          "imageName": "walkThroughSlide3",
          "videoForward": "loop3"
        },
        {
          "imageURL": "",
          "message": "Smart support that's with you\nevery step of the way.",
          "presentationStyle": "root",
          "title": "On-demand support.",
          "videoTransition": "transition4",
          "videoBackward": "transition5_reversed",
          "imageName": "walkThroughSlide4",
          "videoForward": "loop4"
        },
        {
          "imageURL": "",
          "message": "Easy to understand. Easy to Pay.",
          "presentationStyle": "root",
          "title": "Your bill, simplified.",
          "videoTransition": "transition5",
          "videoBackward": "transition6_reversed",
          "imageName": "walkThroughSlide5",
          "videoForward": "loop5"
        },
        {
          "imageURL": "",
          "message": "One real-time Feed, just for you.",
          "presentationStyle": "root",
          "title": "And all you need\nto know at a glance.",
          "videoTransition": "transition6",
          "videoBackward": "transition7_reversed",
          "imageName": "walkThroughSlide6",
          "videoForward": "loop6"
        }
      ]
    },
    "purchaseDataBoostFeedConfirm": {
      "pageType": "purchaseDataBoostFeedConfirm",
      "parentPageType": "myData",
      "Links": [
        {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "cancel",
          "appContext": "mobileFirstSS",
          "actionType": "cancel",
          "title": "Cancel",
          "isSelected": false
        },
        {
          "presentationStyle": "push",
          "tryToReplaceFirst": false,
          "disableAction": false,
          "selected": false,
          "pageType": "purchaseDataFromFeed",
          "appContext": "mobileFirstSS",
          "actionType": "openPage",
          "title": "Confirm",
          "isSelected": false
        }
      ],
      "message": "This purchase will increase this month's bill by $15.",
      "title": "Confirm your purchase."
    }
  }
}
};

module.exports = launchAppModelConfig;
