

export class AlertMessage {

  messageType : string = "";
  messageInfo : string = "";
  messageTitle : string = "";
  alertResponse : string = "";

  callBackFunction : string;
  callBackParam : any;

}
