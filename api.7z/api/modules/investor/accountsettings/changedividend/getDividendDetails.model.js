// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var DividendDetailsSchema = new mongoose.Schema({
    dividendDetailsObject: {
        type: Object,
        "default": {}
    }
});

var InvDividendDetailsLookUp = mongoose.model('InvDividendDetailsLookUp', DividendDetailsSchema);

var InvDevidendDetailsModel = new InvDividendDetailsLookUp({

  dividendDetailsObject : {
      "pan": "CHUQQ9746Q",
      "dividendSchemes": [
        {
          "accountNo": "2009903633080",
          "dividendOption": "Payout",
          "fundCategory": "Equity",
          "fundName": "Franklin Asian Equity Fund - Dividend",
          "folioNo":"17716242",
          "currentValue": "23,653,133.00"
        },
        {
          "accountNo": "2009903633080",
          "dividendOption": "Reinvestment",
          "fundCategory": "Bluechip",
          "fundName": "Franklin India Bluechip Fund – Dividend",
          "folioNo":"177697441",  
          "currentValue": "71,323.00"
        },
        {
          "accountNo": "2009903633080",
          "dividendOption": "Payout",
          "fundCategory": "Equity",
          "fundName": "Franklin Asian Equity Fund - Dividend",
          "folioNo":"17716242",
          "currentValue": "23,653,133.00"
        },
        {
          "accountNo": "2009903633080",
          "dividendOption": "Reinvestment",
          "fundCategory": "Bluechip",
          "fundName": "Franklin India Bluechip Fund – Dividend",
          "folioNo":"177697441",  
          "currentValue": "71,323.00"
        }
      ]
    }

});

InvDividendDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating InvDividendDetailsLookUp table, please contact admin...');
    } else {
        InvDividendDetailsLookUp.remove({}, function(err) {
            console.log('InvDividendDetailsLookUp collection removed');
            InvDevidendDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating InvDividendDetailsLookUp table, please contact admin...');
                }
                console.log('InvDividendDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvDividendDetailsLookUp;
