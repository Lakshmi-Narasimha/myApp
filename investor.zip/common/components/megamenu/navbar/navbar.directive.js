var uicNavBar = function(uicNavBarService, headerConstants, globalMenuInitLoader, eventConstants, fticMenuModel, events, $timeout, configUrlModel, appConfig, $window, $cookies, $filter, constants) { 

    return {
        template: require('./navbar.html'),
        restrict: 'E',
        transclude: true,
        scope: {
            minimalHeader: '@minimal',
            homeUrl: '@',
            chatdocid:'=',
            getexternallink: '=',
            contactnumber: '='
        },
        link: function(scope, iElement, iAttrs, navCtrl, $transclude) {
            scope.latestObject = {};
            scope.myObject = [];
            scope.showSubMenuItem = true;
            // if($cookies.get("userType") =='20' || $cookies.get("userType") =='30' || $cookies.get("userType") =='40'){
            if($cookies.get("userType") == $filter('translate')(constants.ADVISOR_MAIN_USER) || $cookies.get("userType") == $filter('translate')(constants.ADVISOR_SUB_USER1) || $cookies.get("userType") == $filter('translate')(constants.ADVISOR_SUB_USER2)){                 
               scope.showSubMenuItem = false;
            }
            scope.advisorDashboard = $cookies.get("userRedirectURI");
            scope.$on(eventConstants.ON_MENU_DETAILS,function(event,data){
                var MARKETING_URL = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                var data = fticMenuModel.getHeaderData();
                scope.menu = data["utility-links"]["dropdown"];   
                scope.header = data["header-common"]["logo"];
                scope.mobilelogo = data["header-mobile-logo"];               
                scope.searchplaceholder = data["header-common"]["search"]["placeholder"];
                angular.forEach(scope.menu,function(obj){
                    scope.latestObject[obj.text]=[obj];
                });
                scope.menu = scope.latestObject;
                angular.forEach(data["nav-bar"]["nav-links"]["first-level-link"],function(obj){
                    scope.myObj={};
                    scope.myObj[obj.text]=obj["second-level-link"]["nav-link"]; 
                    scope.myObject.push(scope.myObj);
                });
                scope.countryObject = [];
                angular.forEach(data["utility-links"]["dropdown"],function(obj){
                    var objTemp ={};
                    if(angular.isArray(obj.type)){
                        if(obj.text == 'Feedback'){
                            objTemp = {
                                "url":MARKETING_URL+obj.url,
                                "text":obj.text,
                                "imgsrc":"",
                                "title":""
                            }
                            scope.countryObject.push(objTemp);
                        }else{
                        objTemp[obj.text] = [{
                                        "type":"links",
                                        "link":{
                                        "url":"",
                                        "target":"",
                                        "text":"",
                                        "type":obj.type
                                        },
                                        "third-level-link":{
                                        "link":obj.link
                                        }
                                    }];
                                    scope.myObject.push(objTemp);
                        }
                    }else{  
                        objTemp = {
                            "url":obj["choose-country-link"],
                            "text":"Change Country",
                            "imgsrc":"images/fti_country_india.png",
                            "title":"India, click to change location"
                        }         
                        scope.countryObject.push(objTemp);
                    }
                });
            });
        
            scope.menus = scope.myObject;
            scope.isCollapsed = {};
            scope.getMenuName = function(obj){
                var value = "";
                obj = angular.copy(obj);
                angular.forEach(obj, function(property, key){
                    value = key;
                });
                return value;

            }
            
            scope.removenavleftClass = function(){
                angular.element(document.querySelector('#indexBody')).removeClass('fti-nav-open-left');
                //angular.element(document.querySelectorAll("[uib-collapse]")).removeClass('in');
            };

            //scope.navigationToggle();
            scope.position = (iAttrs.sticky === 'true') ? 'navbar-fixed-top' : 'navbar-static-top';
            //navCtrl.init(iElement);
        }
    };
};

uicNavBar.$inject = ['uicNavBarService', 'headerConstants', 'globalMenuInitLoader', 'eventConstants', 'fticMenuModel', 'events', '$timeout', 'configUrlModel', 'appConfig', '$window', '$cookies', '$filter', 'constants'];
module.exports = uicNavBar;