/**
 * @ngdoc directive
 * @name fticInvDbSmartSavingsAccount
 * @requires dashboardConstants
 * @requires investorConstants
 * @requires investorEventConstants
 * @requires investorDashboardDetailsModel
 * @requires $filter
 * @description
 *
 * -It displays One Touch Investment Section
 *
 **/

'use strict';

var smartSavingsAccount = function(dashboardConstants, investorConstants, investorEventConstants, investorDashboardDetailsModel, $filter, loggerConstants, fticLoggerMessage,investorDashboardInvestServices,investorDashboardInitialServices,$timeout) {
    return {
        template: require('./invDbSmartSavingsAccount.html'),
        restrict: 'E',
        replace: true,
        scope: true,
        link: function(scope) {
            scope.isRedeemDisable = false;
            scope.isDataAvailable = false;
            scope.info = { heading: investorConstants.dashboard.SMART_SAVINGS_ACCOUNT };
            scope.buttonLinks = dashboardConstants.dashboard.SMART_SAVINGS_ACCOUNT.BUTTON_LINKS;
            scope.$on(investorEventConstants.Dashboard.INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH, function() {
                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_SMART_SAV_ACCOUNT_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH + ' event' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
                if (investorDashboardDetailsModel.getSmartSaveAccAndOneTouchData().smartSavingsAccount) {
                    scope.initData = investorDashboardDetailsModel.getSmartSaveAccAndOneTouchData().smartSavingsAccount;
                    scope.initData.isPurchaseSet = 'Y';
                    scope.initData.isRedeemSet = 'N'
                    if (scope.initData.isPurchaseSet === 'Y' && scope.initData.isRedeemSet === 'N') {
                        scope.isTransactionStarted = 'Y';
                        scope.isRedeemDisable = false;
                    } else if (scope.initData.isPurchaseSet === 'Y' && scope.initData.isRedeemSet === 'Y') {
                        scope.isTransactionStarted = 'Y';
                        if (scope.initData.currentValue) {
                            scope.isRedeemDisable = false;
                        } else {
                            scope.isRedeemDisable = true;
                        }
                    } else if (scope.initData.isPurchaseSet === 'N' && scope.initData.isRedeemSet === 'Y') {
                        scope.isTransactionStarted = 'N';
                    } else {
                        scope.isTransactionStarted = 'N';
                    }
                    scope.isDataAvailable = true;
                } else {
                    scope.isDataAvailable = false;
                }
            });

            scope.quickInvest = function() {
                 investorDashboardInvestServices.getInvestDetails(scope);
                 $timeout(function () {
                    var investValues =investorDashboardDetailsModel.getInvestData();
                    if(investValues){
                        var confirmObj = {
                            'showConfirm' : true,
                            'mainHeader' : 'Smart Savings Account',
                            'popUpBody' : {
                                'fundName': investValues.getInvestDetails.Invest[0].InvestInfo,
                                'accountNo': investValues.getInvestDetails.Invest[0].AccountNo,
                                'labelText': 'Purchase', 
                                'radioButtons': [
                                    {
                                        'labelText': investValues.getInvestDetails.Invest[0].InstructionAmount,
                                        'name': 'purchaseVal',
                                        'value': 'default'
                                    },
                                    {
                                        'labelText': 'input',
                                        'name': 'purchaseVal',
                                        'value': 'other',
                                        'minAmount': investValues.getInvestDetails.Invest[0].MinimunAmount
                                    }
                                ] 
                            },
                            'yesText' : 'Confirm',
                            'noText' : 'Cancel',
                            'yesEventName' : 'submitConfirm',
                            'noEventName' : 'hideConfirm'
                        };
                        scope.$emit('showConfirm', confirmObj);
                    }
                }, 0);
            };
           
            scope.quickRedeem = function(){
                investorDashboardInvestServices.getInvestDetails(scope);
                $timeout(function () {
                    var investValues =investorDashboardDetailsModel.getInvestData();
                    if(investValues){
                        var confirmObj = {
                            'showConfirm' : true,
                            'mainHeader' : 'Smart Savings Account',
                            'popUpBody' : {
                                'fundName': investValues.getInvestDetails.RedeemDetails[0].InvestInfo,
                                'accountNo': investValues.getInvestDetails.RedeemDetails[0].AccountNo,
                                'labelText': 'Redeem',
                                'isInstructionSet': scope.initData.isRedeemSet === 'N' ? true : false,
                                'radioButtons': [
                                    {
                                        'labelText': investValues.getInvestDetails.RedeemDetails[0].RedeemAmount,
                                        'name': 'purchaseVal',
                                        'value': 'default'
                                    },
                                    {
                                        'labelText': 'input',
                                        'name': 'purchaseVal',
                                        'value': 'other',
                                        'minAmount': investValues.getInvestDetails.RedeemDetails[0].AvaliableAmount
                                    },
                                    {
                                        'labelText': 'Full Redeemption',
                                        'name': 'purchaseVal',
                                        'value': 'other'
                                    }
                                ],
                                'helpText': scope.initData.isRedeemSet === 'N' ? null : '*Available amount exclude lien, provisional and under process units'
                            },
                            'yesText' : scope.initData.isRedeemSet === 'N' ? 'Set Instruction' : 'Confirm',
                            'noText' : 'Cancel',
                            'yesEventName' : scope.initData.isRedeemSet === 'N' ? 'setInstruction' : 'submitConfirm',
                            'noEventName' : 'hideConfirm'
                        };
                        scope.$emit('showConfirm', confirmObj);
                    }
                }, 0);
            };
           
        }
    };

};

smartSavingsAccount.$inject = ['dashboardConstants', 'investorConstants', 'investorEventConstants', 'investorDashboardDetailsModel', '$filter', 'loggerConstants', 'fticLoggerMessage','investorDashboardInvestServices','investorDashboardInitialServices','$timeout'];
module.exports = smartSavingsAccount;
