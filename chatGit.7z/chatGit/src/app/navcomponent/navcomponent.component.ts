import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'navcomponent',
  templateUrl: './navcomponent.component.html',
  styleUrls: ['./navcomponent.component.css']
})
export class NavcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
