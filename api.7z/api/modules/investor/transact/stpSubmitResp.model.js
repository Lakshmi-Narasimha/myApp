// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var submitStpModelSchema = new mongoose.Schema({
    submitStpResponse: {
        type: Object,
        'default': {}
    }
});

var submitStpDetailsModelLookup = mongoose.model('submitStpDetailsModelLookup', submitStpModelSchema);

var SubmitRedemptionDetailsModel = new submitStpDetailsModelLookup({
    submitStpResponse: {
        'status': 'pending',
        'Reference_Number': 'SWI001167',
        'misc_info': {
            'Submitted': '2016-11-10T00:02:57.665',
            'MWESBID': '1780b41ca71c11e68b6c0a415f66000030592c7720000000'
        }

    }
});

submitStpDetailsModelLookup.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating submitStpDetailsModelLookup table, please contact admin...');
    } else {
        submitStpDetailsModelLookup.remove({}, function(err) {
            console.log('submitStpDetailsModelLookup collection removed');
            SubmitRedemptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating submitStpDetailsModelLookup table, please contact admin...');
                }
                console.log('submitStpDetailsModelLookup table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = submitStpDetailsModelLookup;
