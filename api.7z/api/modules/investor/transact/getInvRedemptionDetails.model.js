// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var RedemptionDetailsInvModelSchema = new mongoose.Schema({
    redemptionDetailsResponse: {
        type: Object,
        'default': {}
    }
});

var RedemptionDetailsInvModelLookUp = mongoose.model('RedemptionDetailsInvModelLookUp', RedemptionDetailsInvModelSchema);

var RedemptionDetailsInvModel = new RedemptionDetailsInvModelLookUp({
    redemptionDetailsResponse: {
        'accountNo':'6019904934582',
        'folioId':'17919883',
        'transactionValidated':'true',
        'webRefNo':'RED002125'
    }
});

RedemptionDetailsInvModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating RedemptionDetailsInvModelLookUp table, please contact admin...');
    } else {
        RedemptionDetailsInvModelLookUp.remove({}, function(err) {
            console.log('RedemptionDetailsInvModelLookUp collection removed');
            RedemptionDetailsInvModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RedemptionDetailsInvModelLookUp table, please contact admin...');
                }
                console.log('RedemptionDetailsInvModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RedemptionDetailsInvModelLookUp;
