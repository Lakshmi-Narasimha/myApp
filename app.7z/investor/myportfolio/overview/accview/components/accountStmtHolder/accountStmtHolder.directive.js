/**
 * @ngdoc directive
 * @name accountStmtHolder
 * @requires investorEventConstants  
 * @description
 *
 * - It displays the account statement holder view of account view in account statements of valuations.
 * 
 *
 **/
'use strict';

var accountStmtHolder = function(investorEventConstants, myportfolioConstants, accountViewModel,$filter) {
    return {
        template: require('./accountStmtHolder.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {

            $scope.accountStmtHolderData = accountViewModel.getAccountViewObj().unitHolderDetails;

            $scope.verticalTileRows = [];
            for (var holder in $scope.accountStmtHolderData.holders) {
                var holderArr = null;
                if ($scope.accountStmtHolderData.holders[holder].type === 'Firstholder') {
                    holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.FIRST_HOLDER), value: $scope.accountStmtHolderData.holders[holder].pan }, { key: $scope.accountStmtHolderData.holders[holder].name, value: $scope.accountStmtHolderData.holders[holder].kycStatus }];
                    $scope.verticalTileRows.push(holderArr);
                }
                if ($scope.accountStmtHolderData.holders[holder].type === 'Secondholder') {
                    holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.SECOND_HOLDER), value: $scope.accountStmtHolderData.holders[holder].pan }, { key: $scope.accountStmtHolderData.holders[holder].name, value: $scope.accountStmtHolderData.holders[holder].kycStatus }];
                    $scope.verticalTileRows.push(holderArr);
                }
                if ($scope.accountStmtHolderData.holders[holder].type === 'Thirdholder') {
                    holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.THIRD_HOLDER), value: $scope.accountStmtHolderData.holders[holder].pan }, { key: $scope.accountStmtHolderData.holders[holder].name, value: $scope.accountStmtHolderData.holders[holder].kycStatus }];
                    $scope.verticalTileRows.push(holderArr);
                }
                if ($scope.accountStmtHolderData.holders[holder].type === 'Fourthholder') {
                    holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.FOURTH_HOLDER), value: $scope.accountStmtHolderData.holders[holder].pan }, { key: $scope.accountStmtHolderData.holders[holder].name, value: $scope.accountStmtHolderData.holders[holder].kycStatus }];
                    $scope.verticalTileRows.push(holderArr);
                }
                if ($scope.accountStmtHolderData.holders[holder].type === 'Fifthholder') {
                    holderArr = [{ key: $filter('translate')(myportfolioConstants.overview.FIFTH_HOLDER), value: $scope.accountStmtHolderData.holders[holder].pan }, { key: $scope.accountStmtHolderData.holders[holder].name, value: $scope.accountStmtHolderData.holders[holder].kycStatus }];
                    $scope.verticalTileRows.push(holderArr);
                }
            }

            $scope.keyValuesArr = [
                { text: $filter('translate')(myportfolioConstants.overview.STATUS), value: $scope.accountStmtHolderData.status},
                { text: $filter('translate')(myportfolioConstants.overview.BANK_DETAILS), value: $scope.accountStmtHolderData.bankDetails, popOver: $scope.accountStmtHolderData.allBankDetails.length>1 ? true:false },
                { text: $filter('translate')(myportfolioConstants.overview.MODE_OF_OPERATION), value: $scope.accountStmtHolderData.modeofOperation},
                { text: $filter('translate')(myportfolioConstants.overview.MODE_OF_PAYMENT), value: $scope.accountStmtHolderData.modeofpayment}
            ];

            $scope.bankArray = [];
            $scope.bankPopover = [];
            angular.forEach($scope.accountStmtHolderData.allBankDetails, function(data, index) {
                $scope.bankPopover.push({ text: $scope.accountStmtHolderData.allBankDetails[index].bankCode, value: $scope.accountStmtHolderData.allBankDetails[index].bankAdd });
            });
        }
    };
};

accountStmtHolder.$inject = ['investorEventConstants', 'myportfolioConstants','accountViewModel','$filter'];
module.exports = accountStmtHolder;
