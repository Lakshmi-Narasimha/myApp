// getSalesOverviewChart.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SalesOverviewChartSchema = new mongoose.Schema({
    salesOverviewChartObject: {
        type: Array,
        "default": []
    }
});

var SalesOverviewChartLookUp = mongoose.model('SalesOverviewChartLookup', SalesOverviewChartSchema);

var SalesOverviewChartModel = new SalesOverviewChartLookUp({
  "salesOverviewChartObject":[{
  "salesOverview": {
    "portfolioComposition": {
      "totalAUM": "737023",
      "fundwiseAUM": {
        "balanced": "6289.98",
        "feeder": "9971.26",
        "fof": "3125.62",
        "elss": "18081.78",
        "equity": "426390.5",
        "income": "273163.9",
        "liquid": ""
      }
    }
  },
  "fundCompositionSummary": {
    "fundsSummary": [{
      "assetCategory": "BALANCED",
      "noOfAccounts": "3147",
      "AUM": "6289.98",
      "AUMAllocation": "0",
      "grossSalesMTD": "148.43"
    }, {
      "assetCategory": "ELSS",
      "noOfAccounts": "32642",
      "AUM": "18081.78",
      "AUMAllocation": "0",
      "grossSalesMTD": "816.3"
    }, {
      "assetCategory": "EQUITY",
      "noOfAccounts": "154899",
      "AUM": "426390.5",
      "AUMAllocation": "0",
      "grossSalesMTD": "12554.85"
    }, {
      "assetCategory": "FEEDER",
      "noOfAccounts": "3267",
      "AUM": "9971.26",
      "AUMAllocation": "0",
      "grossSalesMTD": "77.45"
    }, {
      "assetCategory": "FOF",
      "noOfAccounts": "1819",
      "AUM": "3125.62",
      "AUMAllocation": "0",
      "grossSalesMTD": "13.01"
    }, {
      "assetCategory": "FIXED INCOME",
      "noOfAccounts": "22425",
      "AUM": "273163.9",
      "AUMAllocation": "0",
      "grossSalesMTD": "13856.83"
    }],
    "total": {
      "assetCategory": "TOTAL",
      "noOfAccounts": "218199",
      "AUM": "737023",
      "AUMAllocation": "0",
      "grossSalesMTD": "27466.87"
    }
  }
}]
});

SalesOverviewChartLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SalesOverviewChartLookUp table, please contact admin...');
    } else {
        SalesOverviewChartLookUp.remove({}, function(err) {
            console.log('SalesOverviewChartLookUp collection removed');
            SalesOverviewChartModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SalesOverviewChartLookUp table, please contact admin...');
                }
                console.log('SalesOverviewChartLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SalesOverviewChartLookUp;
