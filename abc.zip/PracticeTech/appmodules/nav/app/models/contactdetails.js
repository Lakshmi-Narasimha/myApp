define(['jquery', 'backbone','appcommon/constants','appcommon/globalcontext'
], function ($, Backbone,Constants, GlobalContext) {    
    var advsiorContacts = {};
    advsiorContacts.client = {};
    advsiorContacts.nonclient = {};
    advsiorContacts.searchType = {};
    advsiorContacts.currentadvsiorContacts = null;
    var globalcontext = GlobalContext.getInstance();
    
    advsiorContacts.AddContactDetails = function (fmid, contacts, contactType,flush) {
    	this.UpdateContactType(contactType);
    	if(flush){
    		this.currentadvsiorContacts[fmid] = [];
    	}
    	if (contacts[0].hasOwnProperty('attributes')) {
    	    var contactDetails = _.chain(_.pluck(contacts, 'attributes')).value();
    	} else {
    	    var contactDetails = contacts;
    	}
    	contactDetails = _.chain(contactDetails).
                                sortBy(function (contact) { 
                                	
                                	if (contact.orgNm != null) {
                                		return contact.orgNm; 
                                	}else{
                                		return contact.lastNm ;
                                	}
                                	
                                
                                }).
                                    map(function (contact) {
               var contactObject = {};
               if (contact.orgNm != null) {
                   contactObject.orgNm = contact.orgNm;
                   contactObject.firstNm = undefined;
                   contactObject.lastNm = contact.lastNm;
                   contactObject.lastNmFmtd = contact.orgNm;
               }
               else {
                   contactObject.orgNm = undefined;
                   contactObject.firstNm = contact.firstNm;
                   contactObject.lastNm = contact.lastNm;
                   contactObject.lastNmFmtd = contact.lastNm;
               }
               if(contactType.toLowerCase() != "client"){
            	   contactObject.contactType = contact.contactType;
               }else{
            	   contactObject.contactType = contactType;
               }
               contactObject.id = contact.id;
               return contactObject;
           }).value();
        contactDetails = _.filter(contactDetails,
        		function (contact){
             	   if(contactType.toLowerCase() != "client" ){
             		   if(contact.contactType.toLowerCase() != "client"){
             			   contact.contactType = contactType;
             			   return true;
             		   }else{
             			   return false;
             		   }
             		   
             	   }else{
             		   //contact.contactType = contactType;
             		   return true;
             	   }
                });
        if (this.currentadvsiorContacts[fmid] == undefined) {
        	this.currentadvsiorContacts[fmid] = contactDetails;
        }
        else {
        	this.currentadvsiorContacts[fmid] = this.currentadvsiorContacts[fmid].concat(contactDetails);
        }
        return true;
    };
    //Method to push contacts that fetching from Clinet/prospect list
    advsiorContacts.AddContactDetailsFromContactList = function (fmid, contacts, contactType,flush) {
    	this.UpdateContactType(contactType);
    	if(flush){
    		this.currentadvsiorContacts[fmid] = [];
    	}
        var contactDetails = _.chain(contacts).
                                sortBy(function (contact) { 
                                	
                                	if (contact.orgNm != null) {
                                		return contact.orgNm; 
                                	}else{
                                		return contact.lastNm ;
                                	}
                                	
                                
                                }).
                                    map(function (contact) {
               var contactObject = {};
               if (contact.orgNm != null) {
                   contactObject.orgNm = contact.orgNm;
                   contactObject.firstNm = undefined;
                   contactObject.lastNm = contact.lastNm;
                   contactObject.lastNmFmtd = contact.orgNm;
               }
               else {
                   contactObject.orgNm = undefined;
                   contactObject.firstNm = contact.firstNm;
                   contactObject.lastNm = contact.lastNm;
                   contactObject.lastNmFmtd = contact.lastNm;
               }
               if(contactType.toLowerCase() != "client"){
            	   contactObject.contactType = contact.contactType;
               }else{
            	   contactObject.contactType = contactType;
               }
               contactObject.id = contact.id;
               return contactObject;
           }).value();
        contactDetails = _.filter(contactDetails,
        		function (contact){
             	   if(contactType.toLowerCase() != "client" ){
             		   if(contact.contactType.toLowerCase() != "client"){
             			   contact.contactType = contactType;
             			   return true;
             		   }else{
             			   return false;
             		   }
             		   
             	   }else{
             		   //contact.contactType = contactType;
             		   return true;
             	   }
                });
        if (this.currentadvsiorContacts[fmid] == undefined) {
        	this.currentadvsiorContacts[fmid] = contactDetails;
        }
        else {
        	this.currentadvsiorContacts[fmid] = this.currentadvsiorContacts[fmid].concat(contactDetails);
        }
        return true;
    };
    advsiorContacts.GetTypeAheadSourceInFormat = function (fmid, contactType) {
    	this.UpdateContactType(contactType);
        var formattedNames = _.chain(this.currentadvsiorContacts[fmid]).
                     sortBy(function (contact) { return contact.id }).
                      map(function (contact) {
                       var contactname;
                       if (contact.orgNm != null) {
                           contactname = contact.orgNm;
                         }
                         else {

                           if (contact.lastNm == null || contact.lastNm.length == 0 || contact.firstNm == null || contact.firstNm.length == 0) {
                               contactname = (contact.lastNm != null) ? contact.lastNm : contact.firstNm;
                             }
                             else {
                               contactname = contact.lastNm + ", " + contact.firstNm;
                             }
                         }

                       if (contact.id.indexOf("Contact.") >= 0) {
                           contactname = contactname + " " + contact.id;
                         }
                         else {
                           contactname = contactname + " " + contact.id.substr(14);
                         }
                         return contactname;
                     }).value();
        return formattedNames;
    }
    advsiorContacts.isExist = function (fmid, contactType) {
    	this.UpdateContactType(contactType);
        if (this.currentadvsiorContacts[fmid] == undefined) {
            return false;
        }
        return true;
    };
    advsiorContacts.getSelectedContactId = function (fmid, selClientInfo, contactType) {
    	this.UpdateContactType(contactType);
        var contactIdPart = selClientInfo.slice(-9);
        var selContactId = _.filter(this.currentadvsiorContacts[fmid], function (contact) {
            return ~contact.id.indexOf(contactIdPart);
        });
        return selContactId[0] != undefined ? selContactId[0].id : 0;
    }
    advsiorContacts.getSelectedContactDetails = function (fmid, selContactId, contactType) {
    	this.UpdateContactType(contactType);
        var selContactDetails = _.filter(this.currentadvsiorContacts[fmid], function (contact) {
            return ~contact.id.indexOf(selContactId);
        });
        return selContactDetails[0] != undefined ? selContactDetails[0] : undefined;
    }
    advsiorContacts.GetContactDetails = function (fmid, type)
    {	
    	this.UpdateContactType(type);
    	return this.currentadvsiorContacts[fmid];
    }
    advsiorContacts.AddContact = function (fmid, contactObject) {
    	this.UpdateContactType(contactObject.contactType);
        if (advsiorContacts.isExist(fmid,contactObject.contactType)) {
            var fmIdContacts = this.currentadvsiorContacts[fmid];
            fmIdContacts.push(contactObject);
            return true;
        }
        else {
        	if(!this.currentadvsiorContacts[fmid]){
        		this.currentadvsiorContacts[fmid] = [];
        	}
        	this.currentadvsiorContacts[fmid].push(contactObject);
        }
    };
    advsiorContacts.EditContact = function (fmid, contactObject) {
    	this.UpdateContactType(contactObject.contactType);
        if (advsiorContacts.isExist(fmid, contactObject.contactType)) {
            var selContactDetails = _.filter(this.currentadvsiorContacts[fmid], function (contact) {
                return ~contact.id.indexOf(contactObject.id);
            });
            if (selContactDetails[0] != undefined) {
                selContactDetails[0].firstNm=   selContactDetails[0].firstNm;
                selContactDetails[0].lastNm= selContactDetails[0].lastNm;
                selContactDetails[0].contactType= selContactDetails[0].contactType;
                selContactDetails[0].id= selContactDetails[0].id;
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    };
    advsiorContacts.UpdateContactType = function(type){
    	if(type){
    		this.currentadvsiorContacts =  advsiorContacts[type];
    	}
    	else if(globalcontext.getGlobalContext().Context.ContactType == "nonclient"){
        	this.currentadvsiorContacts =  advsiorContacts.nonclient;
        }else{
        	this.currentadvsiorContacts = advsiorContacts.client;
        }
    };
    advsiorContacts.clearContacts = function(fmid,flushAll){
    		if(flushAll){
    			this.client[fmid] = undefined;
    		}
    		this.nonclient[fmid] = undefined;
    };
    advsiorContacts.clearSearchType = function(fmid){
		this.searchType[fmid] = undefined;
    };
    advsiorContacts.setContactSearchTypeAsDynamic = function(fmid,type){
    	this.searchType[fmid] = type;
    };
    advsiorContacts.getContactSearchType = function(fmid){
    	return this.searchType[fmid];
    };
    var contactDetails =
        {
            advsiorContacts: advsiorContacts
        }
    return contactDetails;
});
