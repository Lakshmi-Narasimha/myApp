/**
 * @ngdoc directive
 * @name investment preferences
 * @description
 *
 * - Investment preferences component will display the selection option for payments through financial advisor or direct.
 * 
 *
 **/
 'use strict';

var checkPan = function($state, transactEventConstants, $filter, transactModel, $cookies, authenticationService, checkKycInitialLoader, checkKycModelService, $timeout, buildPlanModelService) {
	return {
            template: require('./newInvCheckPan.html'),
            restrict: 'E',
            replace: true,
            scope: {},
            controller: ['$scope', function($scope){
                
                $scope.firstHolder = {};
                //PAN UserInputFld Options
                $scope.panRegex = '(([a-zA-Z]{5})(\\d{4})([a-zA-Z]{1}))';
                $scope.panInputObject = {
                    key : "PAN",
                    text : "Please enter your pan",
                    value : "",
                    name : "pan",
                    pattern : $scope.panRegex,
                    type : "text",
                    isRequired : true
                };
                $scope.submitClick = function(){
                    if($scope.panForm.$valid){
                        var param = {
                            "panNo" : ($scope.panInputObject.value).toUpperCase(),
                             "guId" : authenticationService.getUser().guId
                        }
                        checkKycInitialLoader.loadAllServices($scope,param);
                    }
                }
                $scope.$on(transactEventConstants.transact.Check_Kyc, function(event, data){
                    $scope.firstHodler = checkKycModelService.getCheckKycDtls();
                    $scope.firstHodler.type = "Firstholder";
                    $scope.firstHodler.appPanNo = $scope.panInputObject.value.toUpperCase();

                    if ($scope.firstHodler.kycSource === "Not available") {  
                        // $scope.firstHodler.fullName = "Shankar narayanan1";
                        buildPlanModelService.kycNotRegPan = $scope.panInputObject.value;
                        buildPlanModelService.kycNotRegName = $scope.firstHodler.fullName;
                        buildPlanModelService.kycNotRegType = $scope.firstHodler.type;   
                        console.log(buildPlanModelService.kycNotRegPan);
                        console.log(buildPlanModelService.kycNotRegName);
                        console.log(buildPlanModelService.kycNotRegType);

                        
                        buildPlanModelService.setNewInvestorFirstHolderDtls($scope.firstHodler);
                        $state.go("smartSol.planSmartSolution.kycRegSSNew");
                    }
                    else if($scope.firstHodler.kycSource === "KRA Verified"){
                        buildPlanModelService.setNewInvestorFirstHolderDtls($scope.firstHodler);
                        $state.go("smartSol.planSmartSolution.modeOfHoldingSS");
                    }
                });
            }]
        };
};

checkPan.$inject = ['$state', 'transactEventConstants', '$filter', 'transactModel', '$cookies','authenticationService','checkKycInitialLoader','checkKycModelService','$timeout','buildPlanModelService'];
module.exports = checkPan;