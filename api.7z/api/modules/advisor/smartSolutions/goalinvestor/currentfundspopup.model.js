// currentFundsPopup.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var currentFundsPopupSchema = new mongoose.Schema({
    funds: {
        type: Array,
        "default": []
    }
});

var currentFundsPopupLookUp = mongoose.model('currentFundsPopupLookUp', currentFundsPopupSchema);

var currentFundsPopupModel = new currentFundsPopupLookUp({
    "funds":{
  "currenFunds": [
    {
      "fundOption": "Franklin India PRIMA FUND",
      "percentage": "90",
      "frequency": "1",
      "amount": "1"
    },
    {
      "fundOption": "Franklin India BLUECHIP FUND",
      "percentage": "10",
      "frequency": "2",
      "amount": "1"
    }
  ]
}

});

currentFundsPopupLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating currentFundsPopupLookUp table, please contact admin...');
    } else {
        currentFundsPopupLookUp.remove({}, function(err) {
            console.log('currentFundsPopupLookUp collection removed');
            currentFundsPopupModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating currentFundsPopupLookUp table, please contact admin...');
                }
                console.log('currentFundsPopupLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = currentFundsPopupLookUp;
