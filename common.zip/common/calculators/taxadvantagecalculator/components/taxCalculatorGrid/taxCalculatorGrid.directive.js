/**
 * @ngdoc property
 * @name ftictaxCalculatorForm Directive
 * @description
 *
 * ftictaxCalculatorChart directive 
 *
 **/
'use strict';

var fticTaxCalculatorGrid = function($state,$timeout,eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, taxCalculatorInitialService, taxCalculatorModel, calculatorsEventConstants) {
	return {
        template: require('./taxCalculatorGrid.html'),
        restrict: 'E',
        replace: true,
        scope:{},
        controller:['$scope', function($scope){


          $scope.$on(calculatorsEventConstants.TAX_CALCULATE_GRID, function(event){
             $scope.taxGridValues = false;
                $scope.taxGrid = {};
            $scope.fundName = taxCalculatorModel.getTaxCalculations()[0].fundName;

            $scope.taxGridValues = taxCalculatorModel.getTaxCalculations()[0].returnData;
            
            $scope.taxGrid.columnDefs = [
            { field: 'year', displayName: 'Year', width:'120', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft: true},
            { field: 'amountInvested', displayName: 'Amount Invested', width:'165', headerCellClass: 'text-right fti-grid-headercell fti-grid-sortDisabledHeader',cellClass:'text-right', enableSorting:false},
            { field: 'valueOfAmount', displayName: 'Value of Investment', width:'185', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false},
            { field: 'capitalGain', displayName: 'Capital Gain', width:'180', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false},
            { field: 'taxImplication', displayName: 'Tax Implications', width:'175', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false},
            { field: 'fdTaxImplication', displayName: 'FD Tax Implication*', width:'200', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader text-right',cellClass:'text-right', enableSorting:false}
            ]; 


            });

            $scope.$on(calculatorsEventConstants.TAX_RESET_DATA, function(event) {
                $scope.taxGridValues = false;
            });

            $scope.desc = {
                description:"Hi, I came across this useful calculator on the Franklin Templeton website to help me plan my taxes better. Check it out!"
            }
                      
        }]
    };
};
fticTaxCalculatorGrid.$inject = ['$state','$timeout','eventConstants','fticLoggerMessage', 'loggerConstants', '$cookies','authenticationService','taxCalculatorInitialService','taxCalculatorModel', 'calculatorsEventConstants'];
module.exports = fticTaxCalculatorGrid;