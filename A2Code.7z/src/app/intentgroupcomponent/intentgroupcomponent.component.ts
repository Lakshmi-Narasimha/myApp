import { Component, Directive, OnInit,ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Agent } from '../_models/agent';
import { Intent } from '../_models/intent';
import { ModalDirective, ModalOptions } from 'ng2-bootstrap';

@Component({
  selector: 'intentgroupcomponent',
  templateUrl: './intentgroupcomponent.component.html',
  styleUrls: ['./intentgroupcomponent.component.css'],
  inputs: ['title']
})

export class IntentgroupcomponentComponent implements OnInit {

closed: Boolean = false;
selectedIntent: Intent = null;
activeAgentIntents: Array < Intent > = [];
toggleImageSide : string = "left";

newIntentModel: any = {};
formErrors : any = {};

@ViewChild('addIntentModal') public newIntentModalDialog: ModalDirective;

constructor(private aiAssistCacheService : AIAssistCacheService) { this.subscriptions(); }

ngOnInit() {
}

toggle() {
  this.closed = !this.closed;
  if ( this.toggleImageSide == "left" )
    this.toggleImageSide = "right";
  else
    this.toggleImageSide = "left";
}

public updateActiveIntent(pIntent:Intent) {
  this.aiAssistCacheService.navigateIntent(pIntent);
}

public hideNewIntentModal():void {
  this.newIntentModalDialog.hide();
}

public createNewIntent(){
  let hasFormErrors : boolean = false;
  if ( !this.newIntentModel.name || ( this.newIntentModel.name != null && this.newIntentModel.name.trim() == "" ) ) {
    hasFormErrors = true;
    this.formErrors.name = "Intent Name is mandatory field.";
  } else {
    var existingIntent = this.activeAgentIntents.filter((intent: Intent) =>  intent.name === this.newIntentModel.name); //{ console.log(intent); console.log( intent + " , " + this.newIntentModel.name );
    // console.log(existingIntent);
    if(existingIntent && existingIntent.length > 0) {
      hasFormErrors = true;
      this.formErrors.name = "Intent Name \"" + this.newIntentModel.name + "\" is already exist in the selected Agent";
    }
  }

  if(hasFormErrors)
    return;
  this.aiAssistCacheService.createIntent(this.newIntentModel);
  this.hideNewIntentModal();
}

private subscriptions() {
  this.aiAssistCacheService.activeIntentsObservable.subscribe((data) => {
    this.activeAgentIntents = data || [];
    this.newIntentModel = {};
    this.formErrors = {};
  });
  this.aiAssistCacheService.activeIntentObservable.subscribe((data) => {
    this.selectedIntent = data || [];
    this.newIntentModel = {};
    this.formErrors = {};
  });
}

}
