﻿define([
       'appcommon/applauncher/device',
       'apipublic/rolesapi'

], function (Device, Roles) {
    var instance;
    function init() {
        var context = {
            LoggedInUser: undefined,
            ContactId: undefined,
            ContactType: undefined,
            ContactSource: undefined,
            GroupId: undefined,
            AdvisorFMID: undefined,
            IsOBO: undefined,
            IsStandalone: false,
            QueryString: '',
            ContextId: undefined,
            Device: Device,
            Roles: Roles.role || 'common',
            IsNonCMuser: Roles.isNonCMUser

        };
        return {
            setContext: function (advisorFMID, isAdvisorOBO, contactId, contactType, contactSource, groupId, isStandalone, queryString, contextId) {
                var contextChanged = new Array();
                if (context.AdvisorFMID != advisorFMID) {
                    if (advisorFMID == undefined) {
                        contextChanged.push("AdvisorRemoved");
                    }
                    else {
                        contextChanged.push("AdvisorChanged");
                    }
                    context.AdvisorFMID = (advisorFMID != null && advisorFMID != undefined) ? advisorFMID : context.AdvisorFMID;
                    context.IsOBO = (isAdvisorOBO != null && isAdvisorOBO != undefined) ? isAdvisorOBO : context.IsOBO;
                }
                if (context.ContactId != contactId) {
                    if (contactId == undefined) {
                        contextChanged.push("ContactRemoved");
                        context.ContactId = ((contactId === undefined) ? contactId : context.ContactId);
                    }
                    else {
                        contextChanged.push("ContactChanged");
                        context.ContactId = ((contactId != null && contactId != undefined) ? contactId : context.ContactId);
                    }
                    context.ContactType = ((contactType != null && contactType != undefined) ? contactType : context.ContactType);
                    context.ContactSource = (contactSource != null && contactSource != undefined) ? contactSource : context.ContactSource;
                }
                if (context.GroupId != groupId) {
                    if (groupId == undefined) {
                        contextChanged.push("GroupRemoved");
                    }
                    else {
                        contextChanged.push("GroupChanged");
                    }
                    context.GroupId = groupId;
                }
                if (context.IsStandalone != isStandalone) {
                    if (isStandalone == undefined) {
                        contextChanged.push("ModeRemoved");
                    }
                    else {
                        contextChanged.push("ModeRemoved");
                    }
                    context.IsStandalone = (isStandalone != null && isStandalone != undefined) ? isStandalone : context.IsStandalone;
                }
                if (context.QueryString != queryString) {
                    context.QueryString = (queryString != null && queryString != undefined) ? queryString : context.QueryString;
                }
                console.debug(contextChanged, "contextChangedcontextChangedcontextChanged");
                if (context.IsStandalone == false) {
                    $.event.trigger({
                        type: "changeAction",
                        message: JSON.stringify(contextChanged),
                        time: new Date()
                    });
                }

                if (context.ContextId != contextId) {
                    context.ContextId = (contextId != null && contextId != undefined && contextId) ? contextId : context.ContextId;
                }
            },

            getGlobalContext: function () {
                return { Context: context };
            },
            clearContact: function () {
                context.ContactId = undefined;
                context.ContactType = undefined;
                context.ContactSource = undefined;
                context.GroupId = undefined;
            }
        };
    };
    return {
        getInstance: function () {
            if (!instance) {
                instance = init();
            }
            return instance;
        }
    }
});
