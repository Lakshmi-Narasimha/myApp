/**
 * @ngdoc directive
 * @name searchFilter
 * @description
 *
 **/
'use strict';

var panSearchFilter = function($filter, $timeout, myportfolioConstants, fticDateUtils) {
    return {
        template: require('./searchFilter.html'),
        restrict: 'E',
        replace: true,
        scope: {
            foliosArr: '='
        },
        controller: function($scope) {

            $scope.panSearchVM = {
                searchOptions: myportfolioConstants.panView.PAN_FILTER_OPT,
                dateOptions: myportfolioConstants.panView.DATE_FILTER_OPT,
                hideSelect: true,
                selDate: {
                    fullDate: fticDateUtils.getYesterday()
                },
                errorMsgs: myportfolioConstants.overview.DATEPICKER_VAL_MSGS,
                dateRangeErrorMsgs: myportfolioConstants.overview.DATEPICKER_RANGE_VAL_MSGS
            };

            $scope.validationObj = {};
            $scope.validationObj.isApply = false;
            $scope.validationObj.isDateLess = false;

            var PANasHolder = {}, dateHolder = {};

            $scope.$on('EVT_SELECTED_PAN_AS', function(event, data) {
                if (data.category !== null) {
                    PANasHolder.flag = data.category;
                }
            });

            $scope.$on('selectedValue', function(event, data) {
                dateHolder = {};
                if (data.key !== null) {
                    dateHolder.dayFlag = data.key;
                    $scope.validationObj.isApply = false;
                }
            });

            $scope.initFlag = true;
            $scope.$on('getcurrentdate', function(event, date) {
                dateHolder.fromDate = $filter('date')(date, 'dd/MM/yyyy');
                dateHolder.toDate = $filter('date')(date, 'dd/MM/yyyy');
                if ($scope.initFlag) {
                    $timeout(function() {
                        $scope.emitApply();
                        $scope.initFlag = false;
                        $scope.validationObj.isApply = false;
                    });
                }
            });

            $scope.$on('getdaterange', function(event, date1, date2) {
                dateHolder.fromDate = $filter('date')(date1, 'dd/MM/yyyy');
                dateHolder.toDate = $filter('date')(date2, 'dd/MM/yyyy');
            });

            $scope.$on('fticcmpFilterEvent', function(event, inputVal, inputType) {
                if (dateHolder.dayFlag === 'AD') {
                    dateHolder.fromDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    dateHolder.toDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                } else if (dateHolder.dayFlag === 'DR') {
                    $scope.validationObj.isDateLess = false;
                    if (inputType === 'dtr1') {
                        dateHolder.fromDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    } else if (inputType === 'dtr2') {
                        dateHolder.toDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    }
                    $scope.both = dateHolder.fromDate;
                    $scope.validationObj.isDateLess =  fticDateUtils.checkValidDateRange(dateHolder.toDate, dateHolder.fromDate);
                }
            });

            $scope.emitApply = function() {

                /*var errMsg = function() {
                    $scope.validDate = false;
                    if (dateHolder.fromDate === undefined) {
                        $scope.validDate = true;
                    } else {
                        $scope.validDate = false;
                    }
                    return $scope.validDate;
                };
                $scope.isDateValid = errMsg();
                var checkValidDate = errMsg();
                if (!$scope.isDateValid) {
                    var panFilter = angular.merge({}, dateHolder, PANasHolder);
                    panFilter.folioPanAccNo = '17877097';
                    $scope.$emit('apply', panFilter);
                }*/
                var panFilter;

                $scope.isDateValid = fticDateUtils.checkIsValidDate(dateHolder, $scope.validationObj.isDateLess);
                $scope.validationObj.isApply = true;
                if ($scope.isDateValid) {
		            $scope.validationObj.isApply = false;
                    panFilter = angular.merge({}, dateHolder, PANasHolder);
                    //panFilter.folioPanAccNo = '17877097';
                    $scope.$emit('apply', panFilter);
                }

            };
        }
    };
};

panSearchFilter.$inject = ['$filter', '$timeout', 'myportfolioConstants', 'fticDateUtils'];
module.exports = panSearchFilter;
