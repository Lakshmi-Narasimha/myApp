import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Parameter } from '../_models/parameter';


@Component({
  selector: 'intentparameter',
  templateUrl: './intentparameter.component.html',
  styleUrls: ['./intentparameter.component.css']
})
export class IntentparameterComponent implements OnInit {


  public radioModel: string = null;
  editMode : boolean = true;
  paramTypes : Array<string> = [];
  currentParamMap : any = {};
  selectedParamName : string = null;
  paramList : Array<Parameter> = [];
  allowAddition : boolean = false;

constructor(private aiAssistCacheService : AIAssistCacheService) {
  this.subscribefordata();
  //this.source = new LocalDataSource(this.data); // create the source
}

  ngOnInit() {
  }

  private subscribefordata() {
    this.aiAssistCacheService.activeParamListObservable.subscribe((data) => {
      console.log("inside intentparameter subscribe before -> data -> ");
      console.log(data);
      this.paramTypes = data;
       console.log("this.paramTypes");
       console.log(this.paramTypes);
    });
    this.aiAssistCacheService.activeParamMapObservable.subscribe((data) => {
      console.log("inside intentparameter subscribe before -> data -> ");
      console.log(data);
      this.currentParamMap = data;
       console.log("this.paramTypes");
       console.log(this.paramTypes);
    });
    this.aiAssistCacheService.intentEditModeObservable.subscribe((data) => {
      this.editMode = data;
    });
  }

  public showParameter(paramType:any) {
    console.log(paramType);
    console.log(this.currentParamMap[paramType]);
    this.selectedParamName = paramType;
    //this.currentParamMap[paramType].paramList
    this.paramList = this.currentParamMap[paramType].paramList;
    this.allowAddition = this.currentParamMap[paramType].allowAddition;
  }

  public getParsedValues(pParameter:Parameter) {

    if( pParameter != null && pParameter != undefined ) {
      if(pParameter.fieldType == "select") {
        pParameter.parsedFieldValues = [];
        var data = pParameter.fieldValues.replace("[","").replace("]","");
        console.log("data");
        console.log(data);
        var arrData = data.split(",");
        console.log("arrData");
        console.log(arrData);
        for(var i =0; i < arrData.length; i++) {
          var keyvalue = arrData[i].split(":");
          pParameter.parsedFieldValues.push({id:keyvalue[0], label:keyvalue[1]});
        }
      }
      if(pParameter.fieldType == "radio") {

      }
    }
    console.log("parsedFieldValues");
    console.log(pParameter.parsedFieldValues);
      return pParameter.parsedFieldValues;
  }

  //    public checkModel:any = {inapp: false, miniguide: false, dtree: false, chat:false, faq:false, url:false};
  //    public tabs:Array<any> = [
  //   {title: 'INAPP', content: 'Dynamic content 1', id:'inapp'},
  //   {title: 'MINIGUIDE', content: 'Dynamic content 2',id:'miniguide'},
  //   {title: 'DTREE', content: 'Dynamic content 3',id:'dtree'},
  //   {title: 'CHAT', content: 'Dynamic content 4',id:'chat'},
  //   {title: 'FAQ', content: 'Dynamic content 5',id:'faq'},
  //   {title: 'URL', content: 'Dynamic content 6', id:'url'}
  //
  // ];

   /* settings = {
  columns: {
    usersays: {
      title: 'String'
    }
  },
        hideSubHeader: true
};
        data =[
            {usersays:"Response #1"},
            {usersays:"Response #1"},
            {usersays:"Response #1"},
            {usersays:"Response #1"},
            {usersays:"Response #1"}
        ];

    source: LocalDataSource; // add a property to the component


      onAddInputKeyEnter(event:any) { // without type info
          console.log(this.source.getElements());
          console.log("event triggered");
          console.log("event.target.value " + event.target.value);
          console.log(this.data);
        this.source.add({usersays:event.target.value});
    //this.data.push({usersays:event.target.value});// += event.target.value + ' | ';
          console.log(this.data);
          console.log(this.source);
          console.log(this.source.getElements());
          event.target.value = null;
  }
*/
  // public alertMe():void {
  //   setTimeout(function ():void {
  //     alert('You\'ve selected the alert tab!');
  //   });
  // };

  // public setActiveTab(index:number):void {
  //   this.tabs[index].active = true;
  // };

  // public removeTabHandler(/*tab:any*/):void {
  //   console.log('Remove Tab handler');
  // };


}
