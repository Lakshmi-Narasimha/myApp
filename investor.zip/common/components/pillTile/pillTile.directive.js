'use strict';

var pillTile = function() {
    return {
            template: require('./pillTile.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                tileData: "=tileData",              
                type: "=type",
                dType: "="               
            },
            controller: function($scope, $element, $attrs){                
            },
            link: function(scope, iElement, iAttrs, controller){
             
            }
        };
};

pillTile.$inject = [];
module.exports = pillTile;