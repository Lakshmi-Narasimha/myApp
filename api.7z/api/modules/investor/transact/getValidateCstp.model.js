// getBanks.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var GetValidateCstpModelSchema = new mongoose.Schema({
    GetValidateCstpResp: {
        type: Array,
        "default": []
    }
});

var GetValidateCstpModelLookUp = mongoose.model('GetValidateCstpModelLookUp', GetValidateCstpModelSchema);

var GetValidateCstpModel = new GetValidateCstpModelLookUp({
    GetValidateCstpResp : {
      "accountNo":"1689900886175",
      "folioId":"14512366",
      "transactionValidated":"True",
      "webRefNo":"STP000735",
      "trDate":"",
      "urnNo":""
    }
});

GetValidateCstpModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating GetValidateCstpModelLookUp table, please contact admin...');
    } else {
        GetValidateCstpModelLookUp.remove({}, function(err) {
            console.log('GetValidateCstpModelLookUp collection removed');
            GetValidateCstpModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating GetValidateCstpModelLookUp table, please contact admin...');
                }
                console.log('GetValidateCstpModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = GetValidateCstpModelLookUp;