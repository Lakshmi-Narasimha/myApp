var apiUtils = {
    customerInfo: {
        phoneNo: '',
        loggedInTimeStamp: new Date(),
        engagementCounter: 0,
        chatSendMsgCounter: 0,
        chatGetMsgCounter: 0,
        chatEndTime: new Date(),
        pastChatEndTime: new Date(),
        agentId: ''
    },
    setCustomerInfo: function(key, val) {
        if (val) {
            this.customerInfo[key] = val;
        } else {
            this.customerInfo = key;
        }
    },
    getCustomerInfo: function(key) {
        return key ? this.customerInfo[key] : this.customerInfo;
    },
    checkSurveyStatus: function(date1, date2) {
        // the following is to handle cases where the times are on the opposite side of
        // midnight e.g. when you want to get the difference between 9:00 PM and 5:00 AM

        if (date2 < date1) {
            date2.setDate(date2.getDate() + 1);
        }

        return date2 - date1;
    }
};

module.exports = apiUtils;
