/**
 * @ngdoc Controller
 * @name PanViewController
 * @requires $scope
 * @requires panViewModel
 * @requires investorEventConstants
 * @requires panViewInitialLoader
 * @description
 *
 **/


'use strict';

function PanViewController($scope, panViewModel, investorEventConstants, panViewInitialLoader, $state, invInstantMailback, downloadService, investorDashboardDetailsModel) {

    $scope.panVM = {
        showData: false,
        holderAddress: {},
        holderName: '',
    };

    var profileData = investorDashboardDetailsModel.getDashboardData();
    var panNumber = profileData.profileDetails ? profileData.profileDetails.pan : '';

    $scope.$emit('changeNavPill', 'panview');

    $scope.$on('apply', function(event, panFilter) {
        invInstantMailback.setMailBackData({
            folioPanAcc: panNumber,
            fromDate: panFilter.fromDate || null,
            toDate: panFilter.toDate || null,
            periodType: panFilter.dayFlag
        });
        
        downloadService.setQueryparams({
            strInputData: panNumber,
            inputFlag: 'P',
            periodType: panFilter.dayFlag,
            dtFromDate: panFilter.fromDate,
            dtToDate: (panFilter.dayFlag === 'DR' ? panFilter.toDate : null)
        });
        $scope.panVM.showData = false;
        panViewInitialLoader.loadAllServices($scope, panFilter);
    });

    $scope.$emit('changeNavPill', 'panview');
    $scope.$on(investorEventConstants.MyPortfolio.OVERVIEW_PAN_VIEW, function() {
        $scope.panVM.showData = true;
        var holderdetails = panViewModel.getPanViewDtls().unitHolderDetails;
        $scope.panVM.holderName = holderdetails.invName;
        $scope.panVM.holderAddress = holderdetails.address;
        
    });


    $scope.$on('showFolioView', function($event, param) {
        $scope.$emit('changeNavPill', 'folioview');
        $state.go('overview.folioview', {
            'folioNumber': param
        });
    });

    $scope.$on('showAccountView', function($event, param) {
        $scope.$emit('changeNavPill', 'accountview');
        $state.go('overview.accview', {
            'accontNumber': param.accontNumber,
            'folioNumber': param.folioNumber
        });
    });

}

PanViewController.$inject = ['$scope', 'panViewModel', 'investorEventConstants', 'panViewInitialLoader', '$state', 'invInstantMailback', 'downloadService', 'investorDashboardDetailsModel'];
module.exports = PanViewController;
