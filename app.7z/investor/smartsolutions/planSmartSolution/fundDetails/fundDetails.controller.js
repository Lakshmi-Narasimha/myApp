/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function fundDetailsController($scope, $state) {
 	console.log('fundDetailsController');
 	
}
fundDetailsController.$inject = ['$scope', '$state'];
module.exports = fundDetailsController;