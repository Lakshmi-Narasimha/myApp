﻿define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appcommon/memmorymgr',
    'services/dataservice',
    'appcommon/globalcontext',
    'appcommon/groupui/app/views/groupuiview',
    'appcommon/analytics',
    'errorLog',
    'appcommon/commonutility',
    'appcommon/constants',
    'appmodules/accountviewer/app/models/accountviewmodel',
    'appmodules/accountviewer/app/data/accountviewdatamodule',
    'text!appmodules/accountviewer/app/templates/accountshell.html',
    'text!appmodules/accountviewer/app/templates/accounttotalvalue.html',
], function ($, _, Backbone, Spinner, MemmoryMgr, DataService, GlobalContext, GroupUi, Analytics, ErrorLog, CommonUtility, Constants, accountViewData,AccountViewDataModule, AccountShellTemplate, AccountTotalValue) {
    var self=null, accountShellView = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
        },
        initialize: function () {
            self = this;
            this.callbackMethod = function () { };
        },
        render: function (options) {
            Spinner.show();
            this.$el.html(_.template(AccountShellTemplate)).promise().done(function () {
                new GroupUi({ el: $('#av-group-selection'), NoCahe: true }).render();
                self.loadAccountInfo(options.callback);

            });
            Spinner.hide();
        },
        loadAccountInfo: function (callback) {
        	this.callbackMethod = callback;
        	var _gContext = GlobalContext.getInstance().getGlobalContext().Context,
        		_groupId = _gContext.GroupId;
        	if (_groupId == undefined || _groupId == null) {
        		$("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile").html('');
				self.callbackMethod();
        	} else {
        		AccountViewDataModule.getAccountViewData(renderTotalValue);
        		function renderTotalValue(accounDetailsResp) {
        			var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
        			var callbackresponseObject = { "accountingDateResp": null, "accountViewResp": null },
						_groupId = _gContext.GroupId,
						_fmId = CommonUtility.readCookie('FMID'),
						_clientId = _gContext.ContactId,
						_partialOutput = false,
						_acctDt,
						_accountViewDataCollection = [], _accountvalTemplate = _.template(AccountTotalValue);
        			var _response = accounDetailsResp.accountingDateResp;
        			if (_response && _response.d && _response.d.acctDt) {
        				_acctDt = _response.d.acctDt;
        			}
        			loadAccountList(accounDetailsResp.accountViewResp);
        			function loadAccountList(response) {
							if (response && response[0]) {
        						response = response[0]['attributes'];
        					} else {
        						response = response['results'][0]['attributes'];
							}
							if (response.dstrOverviewProcessingStatus.attributes.statCd && response.dstrOverviewProcessingStatus.attributes.statCd == "0001") {
        						_partialOutput = true;
							}
        					var _totalValue = accountViewData.fillAccountListData(response.overviewAccount, _accountViewDataCollection, _groupId);
        					$("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile").html(_accountvalTemplate({ "accountList": _accountViewDataCollection, "accountTotal": _totalValue, "partialOutput": _partialOutput, "acctDt": _acctDt }));
        				self.callbackMethod(accounDetailsResp);
        			}
        			
        		}
			}
        }
    });
    return accountShellView;
});