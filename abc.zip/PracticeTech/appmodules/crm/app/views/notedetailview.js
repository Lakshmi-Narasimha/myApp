define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'services/dataservice',
  'appcommon/commonutility',
  'text!appmodules/crm/app/templates/smartpadnotedetail.html',
  'appcommon/analytics',
  'errorLog',
  'moment',
  'appcommon/globalcontext',
  'appcommon/constants',
  'apipublic/navapi'
], function ($, _, Backbone, Spinner, Dataservice, CommonUtilis, SmartpadNoteDetailTemplate, Analytics, ErrorLog, Moment, GlobalContext, Constants, NavApi) {
    var addsmartpadview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
        	'click #goto-list': 'handleBacktoListClick'
        },
        initialize: function () {
            window.scroll(0, 0);
        },
        render: function (options) {
        	try{
        	    var _that = this;

        		var pageHistory = Backbone.history.list.slice(-1)[0];
        		if (pageHistory.indexOf("contactprofile/") !== -1) {
        			_that.backContext = "Profile"
        		} else { //defaults for sanity purposes
        			_that.backContext = "SmartPad List"
        		}

        		Spinner.show();
            	Dataservice.getSmartPadDetails(CommonUtilis.readCookie('FMID'), options.smartPadId)
            	.then(function(response){
            		if(response && response[0]){
            			var _smartpad = response[0].toJSON();
            			var _memoDate = _smartpad.MemoDate,
                            _pinnedContactDisplayInfo = _smartpad.ContactFirstName ? (_smartpad.ContactFirstName + " " + _smartpad.ContactLastName) : _smartpad.ContactLastName;
                     	var _localTime  = moment(_memoDate).format('YYYY-MM-DD HH:mm:ss');
                        _localTime = moment(moment.utc(_localTime).toDate()).format('MM/DD/YYYY hh:mm A');
                        _smartpad.MemoDate = _localTime;
            			var compiledTemplate = _.template(SmartpadNoteDetailTemplate);
            			_that.$el.html(compiledTemplate({ data: _smartpad, backContext: _that.backContext, pinnedContactDisplayInfo: _pinnedContactDisplayInfo }));
            			$('#editSmartPadLink').click(function () {
            				Analytics.analytics.recordAction('CrmNoteDetailEditSmartPad:clicked');
            			});
            		}
            		Spinner.hide();
            	})
            	.fail(function(Error){
            		Spinner.hide();
            		ErrorLog.ErrorUtils.myError(Error);
            	})
                
        	}
        	catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        	
        },
        handleBacktoListClick: function () {
        	var self = this;
        	self.goToReferer();
        },
        goToReferer: function () {
        	var _referer = Backbone.history.list.slice(-2)[0];
        	switch (_referer) {
        		case 'contactprofile/':
        		case 'contactprofile/beneficiary':
        		case 'contactprofile/bank':
        		case 'contactprofile/ira':
        		case 'contactprofile/fiduciary':
        		case 'contactprofile/preferences':
        		case 'contactprofile/contributions':
        		case 'contactprofile/distributions':
        			location.hash = _referer;
        			break;
        		default:
        			location.hash = 'crm/smartpad';
        	}
        }
    });
    return addsmartpadview;
});
