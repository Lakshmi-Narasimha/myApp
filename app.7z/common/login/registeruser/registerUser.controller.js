/**
 * @ngdoc property
 * @name 
 * @requires $scope
 * @requires $state
 * @description
 *
 * - 
 *
 **/

'use strict';
function registerUserController($state, $scope, changeSecretQAModel, $filter,advisorRegistrationModelService,registerOnlineModel,$cookies,$window,appConfig,toaster, constants) {
 
    $scope.headingObj = {
        text:'<Register',
        displayBackBtn :true
    };
    $scope.gotToRegister = function($event){
        $event.preventDefault();
        $state.go('loginmaster.register');
    };
    

   $scope.init = function(){
        var qnSuccess = function(successResp){
            var obj = {};
            obj.title = 'Choose Secret Question*';
            $scope.changeSecretQADropdownList = [];
            $scope.changeSecretQADropdownList.push(obj); 
            angular.forEach(successResp.securityQuestions, function(question){
                var obj = {};
                obj.title = question.descriptions;
                obj.key = question.code;
                $scope.changeSecretQADropdownList.push(obj);
            });

        };

        var qnFailure = function(){
        
        };

        var param = {};
        param.guId= advisorRegistrationModelService.getUserData().guId;//'7d0af265-be63-4336-b385-f57c8a83c21d';
        changeSecretQAModel.getSecretQDetails(param).then(qnSuccess, qnSuccess);

        
        $scope.selectionEvent = "SelectedSecurityQ";

        $scope.$on($scope.selectionEvent, function(event, data){
            $scope.securityQObj = data;
        });
       
    };
    $scope.init(); 

    $scope.regFormInputList = [
        {
            text: "User Name",
            value: advisorRegistrationModelService.getUserDetails(),
            messages: $filter('translate')(constants.LOGIN_USER_NAME_FORMAT),
            isRequired: true,
            isReadonly: false,
            isMasked: false,
            showIcon: true

        },
        {
            text: "Enter Password",
            value: "",
            messages: "Minimum 8-12 characters at least one numeric, one letter and one upper case",
            isRequired: true,
            isReadonly: false,
            isMasked: true,
            showIcon: true,
            name:"userPassword"
        },
        {
            text: "Confirm Password",
            value: "",
            messages: "",
            isRequired: true,
            isReadonly: false,
            isMasked: true,
            showIcon: false
        },
        {
            text: "Mobile Number",
            value: advisorRegistrationModelService.getUserData().mobileNo,
            messages: "",
            isRequired: true,
            isReadonly: false,
            isMasked: false,
            showIcon: false,
            disable:false
        },
        {
            text: "Email",
            value: advisorRegistrationModelService.getUserData().emailId,
            messages: "",
            isRequired: true,
            isReadonly: true,
            isMasked: false,
            showIcon: false,
            disable:false
        },
        {
            text: "Secret Answer",
            value: "",
            messages: "Minimum 6 characters",
            isRequired: true,
            isReadonly: false,
            isMasked: true,
            showIcon: true
        }/*,
        {
            text: "Confirm Secret Answer",
            value: "",
            messages: "Minimum 6 characters",
            isRequired: false,
            isReadonly: false,
            isMasked: true,
            showIcon: true
        }*/
    ];


  	$scope.onSubmit = function(){                       
        var obj = {};
        obj.guId = advisorRegistrationModelService.getUserData().guId;
        obj['userName'] = $scope.regFormInputList[0].value;
        obj['password'] = $scope.regFormInputList[1].value;
        obj['verifyPwd'] = $scope.regFormInputList[2].value;
        obj['mobile'] = $scope.regFormInputList[3].value;
        obj['emailId'] = $scope.regFormInputList[4].value;
        //obj['question'] = $scope.securityQObj.title || '';
        if($scope.securityQObj.title == "Choose Secret Question*"){
            obj['question'] = "";
        }
        else{
            obj['question'] = $scope.securityQObj.title;
        }
        obj['answer'] = $scope.regFormInputList[5].value||'';
        obj['verifyAnswer'] = $scope.regFormInputList[5].value || '';
        var registerSuccess = function(successResp){
        	$cookies.remove('accessToken', {'domain': appConfig.DOMAIN_CONFIG});
        	$cookies.remove('guId', {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.put('accessToken',successResp.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.put('guId',successResp.data.guId, {'domain': appConfig.DOMAIN_CONFIG});
            $window.location.href = successResp.data.userRedirectURI;
        };
        var registerFailure = function(errorResp){ 
             toaster.error(errorResp.data[0].errorDescription);
        }

        advisorRegistrationModelService.postRequestForSavingArnDetails(obj).then(registerSuccess, registerFailure);
    };
 
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
registerUserController.$inject = ['$state', '$scope','changeSecretQAModel', '$filter','advisorRegistrationModelService','registerOnlineModel','$cookies','$window','appConfig','toaster', 'constants'];
module.exports = registerUserController;