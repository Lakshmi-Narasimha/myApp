// getCgFolio.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SearchResultModelSchema = new mongoose.Schema({
    searchResultResp: {
        type: Array,
        "default": []
    }
});

var SearchResultModelLookUp = mongoose.model('SearchResultModelLookUp', SearchResultModelSchema);

var SearchResultModel = new SearchResultModelLookUp({
  searchResultResp: [
              {result:
                        [{
                          "custName": "Shankar Narayanan",                    
                          "pan": "ABCD1234KL",
                          "folioId": 3456572,
                          "holdingType": "Joint",
                          "mobile": 9039758625,
                          "emailId": "shankarnarayanan@gmail.com",
                          "city":"P O BOX 170 170"
                        },

                        {
                          "custName": "Shankar BK",                    
                          "pan": "MKLK1234IJ",
                          "folioId": 3896503,
                          "holdingType": "Joint",
                          "mobile": 9049758635,
                          "emailId": "shankar.bk@gmail.com",
                          "city":"P O BOX 170 170"
                        },

                        {
                          "custName": "Shankar Bansal",                    
                          "pan": "OIUH1234GH",
                          "folioId": 2648571,
                          "holdingType": "single",
                          "mobile": 9059758645,
                          "emailId": "shankar.bansal@gmail.com",
                          "city":"P O BOX 170 170"
                        },

                        {
                          "custName": "Shankar S",                    
                          "pan": "ELKI1234EF",
                          "folioId": 3494892,
                          "holdingType": "single",
                          "mobile": 9069758655,
                          "emailId": "shankar.s@gmail.com",
                          "city":"P O BOX 170 170"
                        },

                        {
                          "custName": "Shankar KL",                    
                          "pan": "GFRW1234CD",
                          "folioId": 8987647,
                          "holdingType": "Joint",
                          "mobile": 9079758665,
                          "emailId": "shankar.kl@gmail.com",
                          "city":"P O BOX 170 170"
                        },

                        {
                          "custName": "Shankar Das",                    
                          "pan": "PDVB1234AB",
                          "folioId": 4098263,
                          "holdingType": "single",
                          "mobile": 9089758675,
                          "emailId": "shankar.das@gmail.com",
                          "city":"P O BOX 170 170"
                        }]
                }]
});

SearchResultModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SearchResultModelLookUp table, please contact admin...');
    } else {
        SearchResultModelLookUp.remove({}, function(err) {
            console.log('SearchResultModelLookUp collection removed');
            SearchResultModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SearchResultModelLookUp table, please contact admin...');
                }
                console.log('SearchResultModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SearchResultModelLookUp;