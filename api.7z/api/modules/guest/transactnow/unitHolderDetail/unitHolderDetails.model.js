// advisorSearch.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var UnitHolderDetailsSchema = new mongoose.Schema({
	unitHolderDetailsObject: {
		type: Array,
		"default": []
	}
});

var UnitHolderDetailsLookUp = mongoose.model('UnitHolderDetailsLookUp', UnitHolderDetailsSchema);

var UnitHolderDetailsModel = new UnitHolderDetailsLookUp({

	unitHolderDetailsObject: {
		"unitHolderDetails": {
			  "pan": "BLLPS0190D",
			  "unitHolder": "Shankar Narayanan",
			  "kycStatus": "KYC Not Registered",
              "emailId" : 'transactNowFirstHolder@trnsctnow.com',
              "mobile": '1234567891'
			}
	}
});

UnitHolderDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
    	console.log('Having toruble in creating UnitHolderDetailsLookUp table, please contact admin...');
    } else {
    	UnitHolderDetailsLookUp.remove({}, function(err) {
    		console.log('UnitHolderDetailsLookUp collection removed');
    		UnitHolderDetailsModel.save(function(err) {
    			if (err) {
    				console.log('Having toruble in creating UnitHolderDetailsLookUp table, please contact admin...');
    			}
    			console.log('UnitHolderDetailsLookUp table created in mongoose...');
    		});
    	});
    	console.log(data.length);
    }
});

module.exports = UnitHolderDetailsLookUp;
