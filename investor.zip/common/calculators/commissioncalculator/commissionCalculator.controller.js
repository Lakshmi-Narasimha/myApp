/**
 * @ngdoc property
 * @name Commission Calculator Controller
 * @requires $scope
 * @requires $state
 * @requires constants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


 'use strict';
// Controller naming conventions should start with an uppercase letter
function commissionCalculatorController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, commissionCalculatorModel,sipCalculatorModel, calculatorsEventConstants, calculatorsConstants) {
  $scope.radios = {};
  $scope.init = function () {
    if($state.current && $state.current.data && $state.current.data.isAdvisor) {
      $scope.isAdvisor = $state.current.data.isAdvisor;
    };
    $scope.$emit("setBreadCrumb",{
     cat : "funds",
     subcat : "tools",
     breadCrumb :{
      label:'Commission Calculator',
      state : ''
    }   
  })
  };
  $scope.init();
  $scope.radioFlag = true;
  $scope.currentState = $state.current.name.indexOf("commissioncalculators") !=-1 ? "commissioncalculators" : "commissioncalculator"; 
  $scope.statusTypes = [
  {
    label: calculatorsConstants.SIP_CAL,
    value: $scope.currentState +".sip",
    selected: true
  },
  {
    label:"Lumpsum",
    value: $scope.currentState +".lumpsum",
    selected: false
  } 

  ];

  $scope.userInput= {};
  $scope.selectOptions = {
    "Fund" : [],
    "Frequency" : []
  };
  $scope.inputObject = {
    Fund :{
      required:true,
      name : "fundSelection",
      label: "Select Fund"
    }
  };
  sipCalculatorModel.callFundDetailsData($scope.isAdvisor)
  .then(function (data) {
    $scope.selectOptions.Fund.push({"title":"Select fund", "category" : ""}); 

    var fundlist = data.codeValueList;
    for(var fd=0, len=fundlist.length;fd<len;fd++) {
      $scope.selectOptions.Fund.push({
        "title" : fundlist[fd].value,
        "category" :  fundlist[fd].code
      })    
    }
  });

  $scope.radios.selectedVal = $scope.currentState +".sip";
  $state.go($scope.radios.selectedVal);
  $scope.listenChange = function () { 
    $scope.commissionCalculatorForm.$setPristine();
    $state.go($scope.radios.selectedVal);
  }; 
  $scope.$on('selectedFund', function(event, data){ 
    $scope.fundCode = data.category;
    $scope.$broadcast("fundType",data.category);
  });
  $scope.$on(calculatorsEventConstants.COMMISSION_CALCULATE_SUBMIT, function(event,calculatorReq){
    commissionCalculatorModel.commissionCalculatorData({"commissionCalculatorReq": calculatorReq},$scope.isAdvisor)
    .then(function (data) {
      commissionCalculatorModel.setCommissionCalculations(data.commissionCalculatorRes);
      $scope.$broadcast(calculatorsEventConstants.COMMISSION_CALCULATE_GRID);
    }, function (data) {
      commissionCalculatorModel.setCommissionCalculations(null);
      console.log("ERROR");
    })
  });

  $scope.$on(calculatorsEventConstants.RESET_DATA, function(event, radioValue) { 
   $scope.radioFlag = null;
   $scope.radioValue = $scope.currentState + "." +radioValue;
   $timeout(function () {
     $scope.radios.selectedVal = $scope.radioValue;
     $scope.radioFlag = true;
      $scope.fundCode = "";
     $scope.commissionCalculatorForm.$setPristine();
     $state.go($scope.radios.selectedVal);
   },0);
   $scope.$broadcast(calculatorsEventConstants.COMMISSION_RESET_DATA);
 }); 

  $scope.$on(calculatorsEventConstants.RESET_CHART, function(event) { 
     $scope.$broadcast(calculatorsEventConstants.COMMISSION_RESET_DATA);
   });
}
// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
commissionCalculatorController.$inject = ['$scope',  '$state' , 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'commissionCalculatorModel','sipCalculatorModel', 'calculatorsEventConstants', 'calculatorsConstants'];
module.exports = commissionCalculatorController;