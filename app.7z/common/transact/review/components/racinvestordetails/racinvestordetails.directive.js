/**
 * @ngdoc property
 * @name racInvestorDetails Directive
 * @description
 *
 * racInvestorDetails - Displays the Review & Confirm - Select Investor Details
 *
 **/
'use strict';

var racInvestorDetails = function(transactModel, eventConstants, racInvestorDetailsFactory, authenticationService, $state) {
    return {
        template: require('./racinvestordetails.html'),
        restrict: 'EA',
        replace: true,
        scope: {

        },
        controller:['$scope', function($scope){

            var _userType = authenticationService.getUser().userType;
            var invDetails = transactModel.getInvestorDetails();
            var dashboardDetails = authenticationService.getInvDashboardDetails();
            $scope.headerText = 'INVEST_DETAILS';
            $scope.fromBuy = transactModel.getIsBuy();
            var stateUrl = $state.current.url;

            if (invDetails) {
                /*$scope.investorObj = [
                        {
                            text: 'First Holder Name',
                            value: invDetails.custName
                        },
                        {
                            text: 'PAN',
                            value: invDetails.pan
                        },            
                        {
                            text: 'E-Mail',
                            value: invDetails.emailId
                        },            
                        {
                            text: 'Mobile',
                            value: invDetails.mobile
                        },            
                        {
                            text: 'Second Holder Name',
                            value: (invDetails.holders.length>1)?invDetails.holders[1].name : 'NA' //invDetails.holders[1].name
                        },            
                        {
                            text: 'Third Holder name',
                            value: (invDetails.holders.length>2)?invDetails.holders[2].name : 'NA' //invDetails.holders[2].name
                        }
                    ];*/
                if ($scope.fromBuy) {
                    console.log('invDetails.....', invDetails);
                    $scope.investorObj = [{
                        text: 'Folio Number',
                        value: invDetails.folioId
                    }, {
                        text: 'First Holder Name',
                        value: invDetails.custName
                    }, {
                        text: 'PAN/PEKRN',
                        value: invDetails.pan
                    }, {
                        text: 'E-Mail',
                        value: invDetails.emailId
                    }, {
                        text: 'Mobile',
                        value: invDetails.mobile
                    }, {
                        text: 'Second Holder Name',
                        value: (invDetails.holders.length > 1 && invDetails.holders[1].name.trim().length > 0) ? invDetails.holders[1].name : 'NA' //invDetails.holders[1].name
                    }, {
                        text: 'Third Holder Name',
                        value: (invDetails.holders.length > 2 && invDetails.holders[2].name.trim().length > 0) ? invDetails.holders[2].name : 'NA' //invDetails.holders[2].name
                    }];
                } else {
                    $scope.investorObj = racInvestorDetailsFactory.getFormattedInvestorDetails(_userType, invDetails, stateUrl, dashboardDetails);
                    $scope.headerText = racInvestorDetailsFactory.getExactHeaderText(_userType);
                }
            }

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){
                $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'Investor'});
            }); 
            
        }]
    }
};

racInvestorDetails.$inject = ['transactModel', 'eventConstants', 'racInvestorDetailsFactory', 'authenticationService', '$state'];
module.exports = racInvestorDetails;
