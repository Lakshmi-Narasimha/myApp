// confirmInvestDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ConfirmInvestDetailsModelSchema = new mongoose.Schema({
    confirmInvestDetailsResp: {
        type: Object,
        'default': {}
    }
});

var ConfirmInvestDetailsModelLookUp = mongoose.model('ConfirmInvestDetailsModelLookUp', ConfirmInvestDetailsModelSchema);

var ConfirmInvestDetailsModel = new ConfirmInvestDetailsModelLookUp({
    confirmInvestDetailsResp: {
        'accountNo': '0380000217154',
        'currentValue': '50000',
        'transactionValidated': 'true',
        'webRefNo': 'SWD000893'
    }
});

ConfirmInvestDetailsModelLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ConfirmInvestDetailsModelLookUp table, please contact admin...');
    } else {

        ConfirmInvestDetailsModelLookUp.remove({}, function () {
            console.log('ConfirmInvestDetailsModelLookUp collection removed');
            ConfirmInvestDetailsModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating ConfirmInvestDetailsModelLookUp table, please contact admin...');
                }
                console.log('ConfirmInvestDetailsModelLookUp table created in mongoose...');
            });
        });
    }
});

module.exports = ConfirmInvestDetailsModelLookUp;