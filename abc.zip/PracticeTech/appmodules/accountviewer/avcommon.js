﻿define([
  'jquery',
  'bootstrap'
], function ($, bootstrap) {
    $(document).ready(function () {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
                $('.scrollToTops').fadeIn();
            } else {
                $('.scrollToTops').fadeOut();
            }
        });

        $(document).off("click", ".scrollToTops").on("click", ".scrollToTops", function () {
            $('html, body').animate({ scrollTop: 0 }, 500);
            return false;
        });

        $(window).resize(function () {
            if ($(window).width() >= 768) {
                $(".btns:not(.special-av-expnd-btn)").each(function () {
                    if ($(this).hasClass("collapse-icon")) {
                        $(this).trigger("click");
                        $(this).removeClass("collapse-icon").removeClass("act").addClass("expand-icon");
                    }

                })
            }
        });        
    });
     function readCookie(name) {
    	 try{
    		 var nameEQ = name + "=";
    			var ca = document.cookie.split(';');
    			for ( var i = 0; i < ca.length; i++) {
    				var c = ca[i];
    				while (c.charAt(0) == ' ')
    					c = c.substring(1, c.length);
    				if (c.indexOf(nameEQ) == 0){
    					var _substring = decodeURIComponent(c.substring(nameEQ.length, c.length));
    					return _substring;
    					
    				}
    			}
    	 }catch(e){
    		 
    	 }
		
		return null;
	}
    
    var avCommon = {
    		readCookie:readCookie
    }

    return avCommon;
});
