define(['jquery', 'underscore', 'backbone', 'spinner','appcommon/globalcontext', 'appcommon/analytics','appmodules/gpm/app/js/lib/validate.js','appcommon/commonutility','appcommon/hocindicator',
		'text!appmodules/gpm/app/templates/gpmcontainer.html', 'text!appmodules/gpm/app/templates/gpmcommonsectionstemplate.html',
        'text!appmodules/gpm/app/templates/gpmadvsrclntinfotemplate.html',
        'text!appmodules/gpm/app/templates/gpmconfirmationsections.html',
        'text!appmodules/gpm/app/templates/gpmconfirmationmsgsection.html',
        'text!appmodules/gpm/app/templates/gpmconfirmatointwostep.html',
        'text!appmodules/gpm/app/templates/gpmalertprefverif.html',
        'text!appmodules/gpm/app/templates/gpmverificationcommunicationprefsections.html',
        'appmodules/gpm/app/js/utils', 'appcommon/commonutility',
        'services/dataservice', 'appmodules/contactprofile/app/models/cpviewmodel',
        'text!appmodules/gpm/app/templates/gpmdeathverify.html',
        'text!appmodules/gpm/app/templates/gpmactionstemplate.html',
        'appmodules/gpm/app/data/gpmdata', 'config', 'errorLog',
'text!appmodules/gpm/app/templates/gpmverificationemployment.html'], function ($, _, Backbone, Spinner, GlobalContext, Analytics, Validator, CommonUtil,
            HOCIndicator, GPMContainerTemplate, CommonSectionTemplate, GPMAdvsrClientTemplate, ConfirmationSectionTemplate, ConfirmMsgTmplt,
            ConfirmTemplateTwoStep, AlertVerificationTemplate, CommunicationPrefVerificationtemplate, Utils, CommonUtils, Dataservices,
            CPViewModel, DeathVerifyTemplate, GPMActionsTemplate, GPMActionMatrix, Config, ErrorLog,
            GPMVerifyEmploymentTemplate) {
		    var self=null,_containerView = Backbone.View.extend({
		        el: $("#practicetech-subapp"),
		        id: 'practicetech-subapp',
		        history: {
		            referer: {
		                route: null,
		                context: null,
		            }
		        },
		        events: {
		            'click #toProfile': 'goToReferer',
		            'click #back-to-cp-contnr': 'goToReferer'
		        },
		        initialize: function () {
		            self = this;
		            $(document).off('click', '.gpm-action-external-links').on('click', '.gpm-action-external-links', function (e) {
		                self.linkOutToExternalWorkflows(e);
		            });
		            $(document).off('click', '.gpm-action-internal-links').on('click', '.gpm-action-internal-links', function (e) {
		                self.launchInternalWorkflows(e);
		            });
		        },
		        render: function (data, updateEgment) {
		        	$('.gpm-alert-row').addClass("hidden");
		            window.scrollTo(0,0);
		            var _changedItems = this.model.get("items");
		        	if(this.model.get('updateMode') == "phonenumbers" || this.model.get('updateMode') == "email"){
						_changedItems = this.model.getChangedItems();
		        	}
		        	var history = this.model.get("referrer");
		      

					var _commonTemplate = _.template(CommonSectionTemplate);
					var _sectionName = { sectionName: updateEgment, history: history };

        			var _pageHeadingTemplate = this.getTemplateSection(_commonTemplate(_sectionName), '#pt-gpm-update-step3-page-title');
        			var _gpmbtnTmpl = _.template(_commonTemplate(_sectionName));
        			//var _gpmbtnTmpl = _commonTemplate(_sectionName);
		        	_gpmbtnTmpl = _gpmbtnTmpl(history);


		        	var _confirmationTemplate = this.getTemplateSection(_gpmbtnTmpl, '#nav-section-step3');
		            var _data = this.model.toJSON();
		            _data.items = _changedItems;
		            //load advsr/client info
		            var _advtmplt = _.template(GPMAdvsrClientTemplate);
		            var _advsrInfoCompiledTmplt = _advtmplt({ step: 3, data: this.model.toJSON(), sectionName: updateEgment });
		            this.$el.find('#gpm-advsr-client-info-container').html(_advsrInfoCompiledTmplt);
		            //load the confrm msg
		            var _compiledConfirmTmplt = _.template(ConfirmMsgTmplt)(_data);
		            $('#confirm-msg-section-holder').html(_compiledConfirmTmplt).removeClass("hidden");
		        	
		        	//load the page header template to container
		            var _stepTitle="Step 3 - Confirm", _confirmtemplate = ConfirmationSectionTemplate;
		            //change the step title based on step number
		            if(this.model.get('updateMode') == "alert"){
		                _confirmtemplate = AlertVerificationTemplate;
		            }else if(this.model.get('updateMode') == "communicationPreference"){
		            	_confirmtemplate= CommunicationPrefVerificationtemplate;
		            	var _data = { data: this.model };
                       // _data
		            } else if (this.model.get('updateMode') == "reportclientsdeath") {
		            	_confirmtemplate = DeathVerifyTemplate;
		            }
		            else if (this.model.get('updateMode') == "employment") {
		                _confirmtemplate = GPMVerifyEmploymentTemplate;
		                _data = { data: this.model.toJSON() };
		            }
		            else if($('.gpm-step').length == 2){
		                _stepTitle="Step 2 - Confirm";
		                _confirmtemplate = ConfirmTemplateTwoStep;
		            }
		            $('#gpm-step-title-container').html(_pageHeadingTemplate).find('.pt-page-title').text(_stepTitle);

		            //clear footer
		            $('#gpm-step-navigation-button-container').html();
		            $('#gpm-step-navigation-button-container').html(_confirmationTemplate);

		            //load the form fields to the container
		            var _tmplt = _.template(_confirmtemplate);
		            var _compiledTemplate = _tmplt(_data);
		            $('#gpm-form-update-field-container').html(_compiledTemplate);
		            $('#ensure-accuracy-section-holder').html('').addClass("hidden");
		            $('#back-to-cp-contnr').removeClass("hidden");
		            //check for actions a
		            var _updateMode = this.model.get('updateMode')
		            var _gpmActions = GPMActionMatrix.actions,_actionMatrix = this.getActionMatrix(_updateMode), _$gpmViewInfoContainer = null, _$gpmConfirmPageActionCtnr = null, _actions = [];
		            if (_actionMatrix.columnLayout != 1) {
		                _$gpmViewInfoContainer = $("#gpm-view-info-container");
		                _$gpmConfirmPageActionCtnr = $("#gpm-confirm-page-action-ctnr");
		                var _actions = [];
                        _actionMatrix.actions.forEach(function (action) {
                            var _assignedActionDetails = _gpmActions.find(function (assignedAction) {
                                return assignedAction.actionId == action.actionId
                            });
                            if (_assignedActionDetails) {
                                _actions.push(_assignedActionDetails);
                            }
                        });
                        switch (_updateMode) {
                            case "maritalstatus":
                            	var _activeActn = null, _activeAction3 = null, _activeAction4 = null, _newMaritalStatus = _changedItems[0].get('changedItemValueId'), _oldMaritalStatus = _changedItems[0].get('currentItemValueId');
                                if (_newMaritalStatus == "M") {
                                	_activeActn = _actions.find(function (actn) {
                                		return actn.actionId == "gpmAction2";
                                	});
                                	if (_oldMaritalStatus == "S" || _oldMaritalStatus == "") {
                                		_activeAction4 = _actions.find(function (actn) {
                                			return actn.actionId == "gpmAction4";
                                		});
                                	}
                                	_actions = [];
                                	if (_activeActn && _activeAction4) {
                                		_actions = [_activeAction4, _activeActn];
                                	} else if (_activeActn) {
                                		_actions = [_activeActn];
                                	}
                                } else if (_oldMaritalStatus == "M" && (_newMaritalStatus == "D" || _newMaritalStatus == "S")) {
                                    _activeActn = _actions.find(function (actn) {
                                        return actn.actionId == "gpmAction1";
                                    });
                                    _activeAction3 = _actions.find(function (actn) {
                                    	return actn.actionId == "gpmAction3";
                                    });
                                    _actions = [];
                                    if (_activeActn) {
                                    	_actions = [_activeActn, _activeAction3];
                                    }
                                } else {
                                    _actions = [];
                                }
                                break;
                            default:
                                break;
                        }
                        if (_actions.length > 0) {
                            _$gpmViewInfoContainer.removeClass("col-xs-12 col-sm-12 col-md-12 col-lg-12").addClass("col-xs-12 col-sm-8 col-md-8 col-lg-8");
                            var _actnTemplate = _.template(GPMActionsTemplate);
                            var _dataCompiledActionTemaplate = _actnTemplate({ "actions": _actions });
                            _$gpmConfirmPageActionCtnr.html(_dataCompiledActionTemaplate).removeClass("hidden");
                            $('#gpm-step-navigation-button-container').removeClass("col-sm-12 col-md-12 col-lg-12").addClass("col-sm-8 col-md-8 col-lg-8")
                        }
		               
		            }
		            this.clearCahcheAndUpdateCpModel();
		            /*HOC Refresh*/
		            this.refreshHOCIndicator(_updateMode);
		        },
		        //clear clientfo from breeze cache
		        clearCahcheAndUpdateCpModel:function (){
		            var _serviceCallsStack = [],_clientId = this.model.get('clientId'),
		            _isNonCMuser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
		        	Dataservices.clearCPCacheById(_clientId,"Client");
		        	_serviceCallsStack.push(Dataservices.getClientPersonalFromSourceSystem(_clientId));
		        	if (_isNonCMuser == false) {
		        	    _serviceCallsStack.push(Dataservices.getContactDetailsbyClientId(CommonUtils.readCookie('FMID'), _clientId));
                    }
		        			        	
		        	 Q.allSettled(_serviceCallsStack).then(function (response) {
		            		if (response && response.length > 0) {
		            	        getContactProfileInfo(response);
		            	    }else{
		            	    	showError(response);
		            	    }
		            	})
		            	.fail(function (error) {
		            		showError(error);
		            	});
	        		
	        		function getContactProfileInfo(clientPersonalResp){
	        			_serviceCallsStack = [];
	        			var _clientInfo = undefined, _clientPersonal = clientPersonalResp[0]['value'];
            	        _serviceCallsStack.push(Dataservices.getContactprofileInfoFromSourceSystem(_clientId));
            	        Q.allSettled(_serviceCallsStack).then(function(response){
	   	        			 if (response && response.length > 0) {
	   	                             _clientInfo = response[0]['value'];
	   	        			 }
	   	        			 if(_clientInfo !==undefined && _clientInfo[0] != undefined && _clientPersonal !== undefined && _clientPersonal[0]!=undefined){
	   	        				if ((_clientInfo[0].get('clientPersonal').attributes == undefined) || (_clientInfo[0].get('id') != _clientInfo[0].get('clientPersonal').get('clId'))) {
	   	   	        				_clientInfo[0].set({ 'clientPersonal': _clientPersonal[0] }, { silent: true });
	   	                        }
	   	        				CPViewModel.getInstance().setData({ 'cola': _clientInfo[0].toJSON() });
	   	        			 }
	   	        			Spinner.hide();
            	        }).fail(function(error){
            	        	showError(error);
   	        			});
	        		}
	        		function showError(error){
	        			Spinner.hide();
	        			Utils.logError(error,false,true);
	        		}
	        	},
		        getTemplateSection:function(template,dataSection){
		            var _templt = $(template).find(dataSection).html();
		            return _templt;
		        },
		        navigateToStep1:function(){
		            Backbone.history.navigate('gpm/update/gender', true);
		        },
		        toProfile: function () {
		            Backbone.history.navigate("contactprofile/", true);
		        },      
		        goToReferer: function () {
		            var target = this.model.get("referrer");
		            location.hash = target.referer;
		        },
		        refreshHOCIndicator : function(_updateMode){
		        	var refreshHOC = false;
		        	/*Refresh HOC Indicator count*/
		        	switch (_updateMode) {
					    case "email":
		    	        case 'suitability':
		    	        case 'employment':
		        	    case 'phonenumbers':
		        	    case 'documentDelivery':
		    	    	    refreshHOC = true;
		    	            break;
					    default:
						    break;
					}
		        	
		        	if (refreshHOC) {
                        //make the call after 1 s, bcs HOC uses max-age=1
		        	    setTimeout(function () {
		        	        HOCIndicator.updateActionStatus(null, null, 0,true/*flag to fetch all categories*/);
		        	    }, 1500);
		        	}
		        },
		        getActionMatrix: function (updateMode) {
		            var _actionMappings = GPMActionMatrix.actionMapping;
		            var _updateModeMapping = _actionMappings[updateMode];
		            if (!_updateModeMapping) {
		                _updateModeMapping = { "columnLayout": 1, "actions": [] };
		            }
		            return _updateModeMapping;
		        },
		        linkOutToExternalWorkflows: function (event) {
		            var _$el = $(event.currentTarget);
		            var _targetUrl = _$el.data("href"), _targetModule = _$el.data("edit-module"),_url="";
		            switch (_targetUrl) {
		                case "eformsUrl":
		                    switch (_targetModule) {
		                        case "household":
		                            self.linkoutToEforms({ "v2Compatible": false, "groupFlag": false, "donotPassAdvsrId": false, "type": "household" });
		                            break;
		                    }
		                    break;
		            }
		        },
		        launchInternalWorkflows: function (e) {
		            var _targetRoute, _$target = $(e.currentTarget);
		            var _dataHref = _$target.data('href');
		            switch (_dataHref) {
		                case 'gpm/reportclientsdivorce':
		                    _targetRoute = _dataHref;
		                    self.navigateToInternalRoutes(_targetRoute);
		                    window.scrollTo(0, 0);
		                    break;
		            	case 'coa/':
		            		_targetRoute = _dataHref;
		            		self.navigateToInternalRoutes(_targetRoute);
		            		window.scrollTo(0, 0);
		            		break;
		            	case 'ncst/':
		            		_targetRoute = _dataHref;
		            		self.navigateToInternalRoutes(_targetRoute);
		            		window.scrollTo(0, 0);
		            		break;
		                default:
		                    console.log("error: edit field operator error")
		                    break;
		            }
		        },
		        navigateToInternalRoutes: function (targetRoute) {
		            Backbone.history.navigate(targetRoute, true);
		        },
		        linkoutToEforms: function (params) {
		            var _url = Config.getConfigProperty("eformsUrl"),
                        _putContextPaylod = CommonUtil.preparePutAdvContextPayLoad(params.v2Compatible, GlobalContext, params.groupFlag);
		            Spinner.show();
		            Dataservices.putAdvisorSessionContext(_putContextPaylod, false).done(function (response, status, xhr) {
		                Spinner.hide();
		                if (response && response.d) {
		                    _contextId = response.d.cntxId;
		                    if (params.type == "household") {
		                        _url = _url + _contextId + '&formCategory=household#grouping/';
		                    } 
		                    window.open(_url);
		                } else {
		                    ErrorLog.ErrorUtils.prepareAndLogError(xhr);
		                }
		            }).fail(function (xhr) {
		                ErrorLog.ErrorUtils.myError(xhr);
		            });
		        },
		        creatContextPayloadAndLaunchApp: function (v2Compatible, groupFlag, grpId) {

		        }
		        
		    });
		    return _containerView;
		});