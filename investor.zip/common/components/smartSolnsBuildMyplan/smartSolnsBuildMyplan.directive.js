'use strict';

var smartSolnsBuildMyplan = function ($state, $uibModal, $uibModalStack, buildPlanModelService, buildPlanInitialLoader, fundDetailsModel) {
    return {
        template: require('./smartSolnsBuildMyplan.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {},
        controller: function ($scope, $element, $attrs, $state) {
            // buildPlanInitialLoader.loadAllServices($scope);

            var modalInstance;
            $scope.indexOfFund = null;

            $scope.selectfund = [
                {
                    label: "Choose Fund",
                    value: "firstFund"
                },
                {
                    label: "Choose Fund",
                    value: "secondFund"
                },
                {
                    label: "Choose Fund",
                    value: "thirdFund"
                }
            ];
            $scope.fundObject = [
                {
                    key: "firstFund",
                    text: "",
                    name: "firstFund",
                    type: "number",
                    // isRequired:true,
                    pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                },
                {
                    key: "secondFund",
                    text: "",
                    name: "secondFund",
                    type: "number",
                    // isRequired:true,
                    pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                },
                {
                    key: "thirdFund",
                    text: "",
                    name: "thirdFund",
                    type: "number",
                    // isRequired:true,
                    pattern: /^100$|^[1-9]{1}[0-9]{1}$|^[0-0]{1}[5-9]{1}$/,
                    maxlength: 3,
                    value: "",
                    disable: true
                }
            ];

            var enabledIndices = [0];

            $scope.selectFund = function ($index) {
                $scope.indexOfFund = $index;
                if (isSelectFundEnabled($index)) {
                    modalInstance = $uibModal.open({
                        template: require('../newFundsModal/newFundsModal.html'),
                        scope: $scope
                    });
                }

            };

            function isSelectFundEnabled(index) {
                for (var i = 0; i < enabledIndices.length; i++) {
                    if (enabledIndices[i] == index) {
                        return true;
                    }
                }
                return false;
            }

            $scope.closeModal = function () {
                $uibModalStack.dismissAll();
            };

            $scope.fundDetails = [];

            $scope.$on('singleSelectionDone', function (event, obj) {
                $scope.selectfund[$scope.indexOfFund].label = obj.selectedOne.fundName;
                $scope.selectfund[$scope.indexOfFund].isSelected = true;
                $scope.fundObject[$scope.indexOfFund].disable = false;
                $scope.fundDetails[$scope.indexOfFund] = obj.selectedOne;
                $scope.closeModal();
                //buildPlanModelService.setFundDetails($scope.fundDetails);
                fundDetailsModel.setFundDetails($scope.fundDetails);
            });


            $scope.$on("INPUT_BLUR", function (event, obj) {
                if (getSum() >= 5) {
                    if (getSum() < 100) {
                        //Enanle click on next select fund  
                        enabledIndices.push(enabledIndices.length)
                    }
                }

            });

            function disableEmpty() {
                for (var i = 0; i < $scope.fundObject.length; i++) {
                    if ($scope.fundObject[i].value === "" || $scope.fundObject[i].value === null) {
                        $scope.fundObject[i].disable = true;
                    }
                }
            }

            function getSum() {
                var count = 0;
                for (var i = 0; i < $scope.fundObject.length; i++) {
                    count = count + $scope.fundObject[i].value;
                }
                return count;
            }

            if (buildPlanModelService.isFromModify && fundDetailsModel.getFundDetails() != null) {
                $scope.fundDetails = fundDetailsModel.getFundDetails();
                for (var i = 0; i < $scope.fundDetails.length; i++) {
                    $scope.selectfund[i].label = $scope.fundDetails[i].fundName;
                    $scope.fundObject[i].value = buildPlanModelService.getAllocationDetails()[i];
                    $scope.selectfund[i].isSelected = true;
                    $scope.fundObject[i].disable = false;
                    $scope.$emit("INPUT_BLUR");

                }
            }

            $scope.buildPlan = function () {

                var allocation = [];

                $scope.showSumError = false;

                if (getSum() != 100) {
                    $scope.showSumError = true;
                }

                if ($scope.buildMyPlan.$valid && !$scope.showSumError) {
                    for (var i = 0; i < $scope.fundObject.length; i++) {
                        allocation.push($scope.fundObject[i].value);
                    }
                    buildPlanModelService.setAllocationDetails(allocation);
                    $scope.$emit('goBuildMyPlanCntrl');
                }
            }

        }
    };
};
smartSolnsBuildMyplan.$inject = ['$state', '$uibModal', '$uibModalStack', 'buildPlanModelService', 'buildPlanInitialLoader', 'fundDetailsModel'];
module.exports = smartSolnsBuildMyplan;