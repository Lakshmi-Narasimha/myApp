var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var dataPassModel = require('./dataPass.model');
var apiUtils = require('../../common/apiUtils');
var myCache = require('../../../api-server');
var proxy = require('../../../config/proxy');
var request = require('request');

// api route
router.route('/mfchatnode/rest/dataPass')
    .post(function(req, res) {
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.uri = dataPassModel.createRequestUri;        
        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": myCache.get(req.session.engagementID+'.agentID')
         
        };
        if(req.body.RequestParams && req.body.RequestParams.pageVisited){
            if(req.body.RequestParams.pageVisited.pageType){
                post_data['<b>Page Visited</b>'] = req.body.RequestParams.pageVisited.pageType +', <b>Cart Count:</b>'+ req.body.RequestParams.pageVisited.cartItemsCount;
            }            
        }
        var reqObj = {
            url:'https://'+req.uri.host + req.uri.path,
            agent: proxy.agent,            
            ca:proxy.ca,            
            headers: {                
                'Cookie': req.session.sessionCookie,
                'Content-Type': 'application/json'
                },
            form:post_data
        }
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        request.post(reqObj,function(err,response,body){
               if(err){ 
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
               }else{                   
                    logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));  
               }
               res.send(dataPassModel.response);
        });        
        
    });

module.exports = router;
