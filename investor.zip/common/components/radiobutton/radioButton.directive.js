/**
 * @ngdoc directive
 * @name radio button
 * @requires 
 * @requires 
 * @description
 *
 * - It display a radio button with given label
 *
 **/

'use strict';

function radioButton() {
    return{        
        template : require('./radioButton.html'),
        restrict : 'E',
        replace : true,
        require : 'ngModel',
        scope : {
            label : '=',
            value : '=',
            nameLbl : '@name',
            ngModel : '=',
            isRequired : '=',
            mgClick : '&',
            disable : '=?',
            isBindHtml : '=?'
        }
    }
}

radioButton.$inject = [];
module.exports = radioButton;