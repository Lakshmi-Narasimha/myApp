/**
 * @ngdoc factory
 * @name investorDetailsFactory factory
 * @requires 
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var investorDetailsFactory = function ($filter) {

    var investorDetailsFactory = {
        getFormattedInvestorDetails: function (userType, invDetails, secondHolderDetail, thirdHolderDetail) {

            if (userType && (userType.toString() === '10')) {
                return [{
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    text: 'First Holder',
                    value: invDetails.custName
                }, {
                    text: 'PAN/PEKRN',
                    value: invDetails.pan
                }, {
                    text: 'E-Mail',
                    value: invDetails.emailId
                }, {
                    text: 'Mobile',
                    value: invDetails.mobile
                }, {
                    text: 'Second Holder',
                    value: $filter('fticNACheck')(secondHolderDetail) //invDetails.holders[1].name
                }, {
                    text: 'Third Holder',
                    value: $filter('fticNACheck')(thirdHolderDetail) //invDetails.holders[2].name
                }];
            } else {
                return [{
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    text: 'First Holder Name',
                    value: invDetails.custName
                }, {
                    text: 'PAN',
                    value: invDetails.pan
                }, {
                    text: 'E-Mail',
                    value: invDetails.emailId
                }, {
                    text: 'Mobile',
                    value: invDetails.mobile
                }, {
                    text: 'Second Holder Name',
                    value: secondHolderDetail //invDetails.holders[1].name
                }, {
                    text: 'Third Holder name',
                    value: thirdHolderDetail //invDetails.holders[2].name
                }];
            }
        }
    };
    return investorDetailsFactory;

};

investorDetailsFactory.$inject = ['$filter'];
module.exports = investorDetailsFactory;