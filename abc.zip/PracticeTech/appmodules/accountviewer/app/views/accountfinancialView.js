﻿define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'config',
  'appcommon/constants',
'appcommon/analytics',
  'text!appmodules/accountviewer/app/templates/accountfinancialtemplate.html',
  'appmodules/accountviewer/app/views/accountstatementsview',
  'appmodules/accountviewer/app/views/accountportfolioView',
  'appcommon/commonutility',
  'services/dataservice',
  'appcommon/globalcontext',
  'appmodules/hoc/app/js/utils'
], function ($, _, Backbone, Spinner, Config, Constants, Analytics, AccountFinancialTemplate, AccountStatementView, accountportfolioView, CommonUtils, DataService, GlobalContext, HOCUtils) {
	var globalCv = null;
	var accountfinancialView = Backbone.View.extend({
		el: $("#practicetech-subapp"),
		id: 'practicetech-subapp',
		events: {
			"click #av-Insights": "avInsightsclick",
			"click #av-Banks": "avBanksclick"
		},
		initialize: function () {
			var self = this;
			this.recentActivityCollection = [];
			$(document).off('click', '#goToClientViewer').on('click', '#goToClientViewer', function (e) {
				self.goToCV(e);
			});
		},
		renderDataInTempalte: function (collection) {
			collection = (!collection) ? this.recentActivityCollection : collection;
			var accountfinancialTemplate = _.template(AccountFinancialTemplate);
			$(".acc-tmp-conatiner").html(accountfinancialTemplate({ data: collection }));
		},
		render: function (options) {
			var _that = this;
			_that.renderDataInTempalte();

			$(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
			$(".hdr-tab-buttons-wrap .av-financial").addClass("hdr-tab-active");
		},
		goToCV: function (obj) {
			Analytics.analytics.recordAction("Client Viewer from: Financial :clicked");
				Spinner.show();
				var self = this;
				var _contextId = null, _url = Config.getConfigProperty("hocExtrnlActnLinks").acctsuitmisReviewInCV;
				var _v2Compatible = true;
				var async = false;
				var contextResult = CommonUtils.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
				DataService.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
					Spinner.hide();
					if (response && response.d) {
						_contextId = response.d.cntxId;
						_url = _url + _contextId
						window.open(_url);
					} else {
						ErrorLog.ErrorUtils.myError(response);
					}
				}).fail(self.genericServiceErrorHandler);
			
			obj.stopPropagation();
			if (obj.preventDefault)
				obj.preventDefault();
			return false;
			
		},
		avInsightsclick: function (e) {
			e.preventDefault();
			Backbone.history.navigate("hoc/", true);
		},
		avBanksclick: function (e) {
			e.preventDefault();
			Backbone.history.navigate("contactprofile/bank", true);
		}
	});
	return accountfinancialView;
});