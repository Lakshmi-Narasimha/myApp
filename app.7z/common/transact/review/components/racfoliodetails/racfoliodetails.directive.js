/**
 * @ngdoc property
 * @name fticracFolioDetails Directive
 * @description
 *
 * fticracFolioDetails - Displays the Review & Confirm - Select Fund Details
 *
 **/
'use strict';

var racFolioDetails = function(transactModel, eventConstants) {    
	return {
        template: require('./racfoliodetails.html'),
        restrict: 'EA',
        replace: true,
        scope:{

        },
        controller: function($scope, $element, $attrs){
          var foliodetails = transactModel.getFolioDetails();          
         console.log(transactModel.getFolioDetails())
          $scope.folioObj = [
            {
              text: "Folio No.",
              value: invDetails.folioId
            },
            {
              text: "First Holder",
              value: foliodetails.tschvalAccno
            },            
            {
              text: "PAN/PEKRN",
              value: foliodetails.fmDescription
            },
            {
              text: "email",
              value: foliodetails.fmDescription
            },
            {
              text: "mobile",
              value: foliodetails.fmDescription
            },
             {
              text: "second holder",
              value: foliodetails.fmDescription
            },
             {
              text: "third holder",
              value: foliodetails.fmDescription
            }
            
          ]; 

          $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){            
            $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'Fund'});
          }); 
            
        },
        link: function(scope, element, attrs, ctrl){
        }
    }
};

racFolioDetails.$inject = ['transactModel', 'eventConstants'];
module.exports = racFolioDetails;