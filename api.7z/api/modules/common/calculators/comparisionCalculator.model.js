// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ComparissionCalculatorSchema = new mongoose.Schema({
    comparissionCalculatorObject: {
        type: Array,
        "default": []
    }
});

var ComparissionCalculatorLookUp = mongoose.model('ComparissionCalculatorLookup', ComparissionCalculatorSchema);

var ComparissionCalculatorModel = new ComparissionCalculatorLookUp({

  "comparissionCalculatorObject": [
    {
    "comparisionCalculatorResp": [{
        "transactionType": "SIP & Lumpsum",
        "investedAmountSIP": "8,00,000",
        "investedAmountAtTenureSIP": "30,00,000",
        "investedAmountLumpsum": "8,00,000",
        "investedAmountAtTenureLumpsum": "30,00,000",
        "returnData": [
            {
                "returnType": "SIP Investment",
                "periodicReturnData": [
                    {
                        "duration": "5 Years",
                        "valueOfAmount": 400000,
                        "investedAmount": 300000
                    },
                    {
                        "duration": "10 Years",
                        "valueOfAmount": 800000,
                        "investedAmount": 600000
                    },
                    {
                        "duration": "15 Years",
                        "valueOfAmount": 1200000,
                        "investedAmount": 900000
                    },
                    {
                        "duration": "20 Years",
                        "valueOfAmount": 1400000,
                        "investedAmount": 1200000
                    }
                ]
            },
            {
                "returnType": "Lumpsum Investment",
                "periodicReturnData": [
                    {
                        "duration": "5 Years",
                        "valueOfAmount": 600000,
                        "investedAmount": 500000
                    },
                    {
                        "duration": "10 Years",
                        "valueOfAmount": 800000,
                        "investedAmount": 500000
                    },
                    {
                        "duration": "15 Years",
                        "valueOfAmount": 1000000,
                        "investedAmount": 500000
                    },
                    {
                        "duration": "20 Years",
                        "valueOfAmount": 1200000,
                        "investedAmount": 500000
                    }
                ]
            },
            {
                "returnType": "S&P BSE Sensex Returns",
                "periodicReturnData": [
                    {
                        "duration": "5 Years",
                        "amount": 200000
                    },
                    {
                        "duration": "10 Years",
                        "amount": 400000
                    },
                    {
                        "duration": "15 Years",
                        "amount": 600000
                    },
                    {
                        "duration": "20 Years",
                        "amount": 800000
                    }
                ]
            },
            {
                "returnType": "Nifty 50 Returns",
                "periodicReturnData": [
                    {
                        "duration": "5 Years",
                        "amount": 200000
                    },
                    {
                        "duration": "10 Years",
                        "amount": 400000
                    },
                    {
                        "duration": "15 Years",
                        "amount": 600000
                    },
                    {
                        "duration": "20 Years",
                        "amount": 800000
                    }
                ]
            }
        ]
    }]
}
    ]

});

ComparissionCalculatorLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ComparissionCalculatorLookUp table, please contact admin...');
    } else {
        ComparissionCalculatorLookUp.remove({}, function(err) {
            console.log('AdvisorContentLookUp collection removed');
            ComparissionCalculatorModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ComparissionCalculatorLookUp table, please contact admin...');
                }
                console.log('ComparissionCalculatorLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ComparissionCalculatorLookUp;
