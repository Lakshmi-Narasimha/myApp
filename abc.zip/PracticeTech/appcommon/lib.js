﻿define([

], function () {
     
    function exists(arg) {
        if (typeof arg === 'undefined') { return err('undefined') } //check for undefined
        if (typeof arg === 'boolean') { return true }
        if (typeof arg === 'number') { return true }
        if (typeof arg === 'string') { return true }
        if (Array.isArray(arg)) { return true }
        if (arg === null) { return true }
        if (typeof arg === 'object') { return verifyObj(arg) }

        return false;

        function verifyObj(arg) {
            var obj = arg;
            properties = Object.keys(arg);

            if (!obj) {
                return false
            }

            for (var i = 1; i < properties.length; i++) {
                if (!obj || !properties[i] in obj) {
                    return false
                }
            }
            return true;
        }
    }


    function existsOL(arg) {
        type = typeof arg;
        var typeHandler = {
            'default': function () { return false },
            'undefined': function () { return false },
            'boolean': function () { return true },
            'number': function () { return true },
            'string': function () { return true },

            'object': function (arg) {
                var obj = arg;
                properties = Object.keys(arg);

                if (!obj) {
                    return false
                }

                for (var i = 1; i < properties.length; i++) {
                    if (!obj || !properties[i] in obj) {
                        return false
                    }
                }
                return true;
            }
        };
        return (typeHandler[type](arg) || typeHandler['default'](arg));
    }


    return exists;

});