import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { Intent } from '../_models/intent';

@Component({
  selector: 'publishcomponent',
  templateUrl: './publish.component.html',
  styleUrls: ['./publish.component.css']
})
export class PublishComponent implements OnInit {

  publishEnv: any = {};
  private availableIntents: Intent[] =[];

  constructor(private aiAssistCacheService: AIAssistCacheService) {
    this.subscribeForServices();
    this.loadPublishAgents('QA');
  }

  ngOnInit() {
  }

  subscribeForServices() {
    this.aiAssistCacheService.intentsPublishObservable.subscribe((data) => {
      // console.log("data");
      // console.log(data);
      if(data.intentList) {
        data.intentList.forEach((pIntent)=>{pIntent.isSelected = false;});
        this.availableIntents = data.intentList;
      } else {
        this.availableIntents = [];
      }
      // console.log("this.availableIntents");
      // console.log(this.availableIntents);
    });
  }

  public loadPublishAgents(pEnv: string) {
    this.availableIntents =[];
    this.publishEnv = pEnv;
    // console.log("loadingPublishAgents");
    // console.log(this.publishEnv);
    this.aiAssistCacheService.getIntentsforPublish(this.publishEnv);
  }

  public publishIntents() {
    let intentsToPublish : Array<Intent>=[];
    if(this.availableIntents) {
      if(this.publishEnv=='QA') {
        intentsToPublish = this.availableIntents.filter((pIntent:Intent)=> pIntent.isSelected==true);
      } else if(this.publishEnv=='PROD') {
        intentsToPublish = this.availableIntents;
      }
    }
    if(intentsToPublish && intentsToPublish.length > 0) {
      this.aiAssistCacheService.publishSelectedIntents(intentsToPublish, this.publishEnv);
    } else {
      alert("No intents selected to Publish. Please select some Intents to publish.");
    }
  }

  changeSelection(pIntent:Intent) {
    pIntent.isSelected = !pIntent.isSelected;
  }

}
