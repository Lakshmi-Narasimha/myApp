'use strict';

/* jasmine specs for filter go here */

describe('phoneFormatBracketFilter', function() {

	var phoneFormatBracketFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    phoneFormatBracketFilter = $injector.get('$filter')('phoneFormatBracket');
	}));

	//--- Test for definition

	it('should expect phoneFormatBracketFilter to be defined...', function(){
		expect(phoneFormatBracketFilter).toBeDefined();
	});

	//--- Test for phoneFormatBracketFilter

	it('should properly format the 10 digit phone number...', function(){
		expect(phoneFormatBracketFilter(8765374890)).toEqual('(876) 537-4890');
	});

});