define([
  'jquery',
  'underscore',
  'backbone',
  'services/dataservice',
  'appcommon/commonutility',
  'spinner',
  'moment',
  'appcommon/globalcontext',
 'text!appmodules/nav/app/templates/drafts.html',
 'text!appmodules/nav/app/templates/formdetails.html',
 'errorLog', 'config',  'appcommon/applauncher/device'
], function ($, _, Backbone, DataService, CommonUtils, Spinner, Moment, GlobalContext,DraftsTemplate, FormDetailsTemplate, ErrorLog,Config, Device) {
    var draft = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        initialize: function () {
            Device.physicalDevice();
            this.deviceinfo = Device.info;
        	this.selectedDocId = null;
        	this.draftList = null;
        	var _that = this;
        	$(document).off('click','.sign-on-device').on('click','.sign-on-device',function(e){
        	    _that.gotoeSigClientListPage(e, _that);
        	});
        },
        events: {
            "click .forms": "gotodetails",
            "click .todrafts": "gotorender",
            "click .esig-sorting, .reset-sorting": "sortDraftsList",
            'click #back-to-cp-contnr': 'handlebacktoCP'
            /*'click .sign-on-device' : 'gotoeSigClientListPage'*/
        },       
        openDialogBox : function(e) {
			var _self = this;
			var _selectedEl = e.currentTarget || e.target;
			_self.selectedDocId = $(_selectedEl).data("doc-id");
			//  console.log(this.model.get('docId'));
			BootstrapDialog
					.show({
						title : 'Advisor Signature',
						message : 'By clicking Accept, you agree to have your signature automatically applied to this document. ',
						cssClass : 'esig-adv-signature',
						buttons : [
								{
									label : 'Cancel '
											+ '<i class="icon-arrow-right"></i>',
									cssClass : 'generic-button cancel-button',
									action : function(dialog) {
										dialog.close();
									}
								},
								{
									label : 'Accept',
									cssClass : 'generic-button accept-button',
									id : 'accept-button-sign-pad',
									action : function(dialog) {
										// if
										// (!customerListView) {
										// var customerListView
										// = new
										// CustomerListView();
										// }
										// //
										// eSig.customerListView.model
										// // = _self.model;
										// _
										// customerListView.render();

										Backbone.history
												.navigate("eSig/req-signers-list/"+_self.selectedDocId,true);
										dialog.close();
									}
								} ]
					});
		},
		gotoeSigClientListPage : function(e, view){
			var _windowWidth = window.innerWidth;
			if (view.deviceinfo.hardware.type == "Phone" || view.deviceinfo.hardware.make == "unknown") {
				BootstrapDialog.show({
				    title: 'Sign on Device',
					message: "<span class='disp-inln-blk pt-para-medium'>Sign on Device is not available on this device type.</span>",
					//closeByBackdrop: true,
					cssClass : 'esig-mobile-unavailablity',
					buttons : [
							{
								label : 'OK',
								cssClass : 'btn pt-btn-yes generic-button btn-primary',
								action : function(dialog) {
									dialog.close();
								}
							}]
				});
			}else{
				var _self = this;
				var _selectedEl = e.currentTarget || e.target;
				_self.selectedDocId = $(_selectedEl).data("doc-id");
				Backbone.history.navigate("eSig/req-signers-list/"+_self.selectedDocId,true);
			}
			
		},

        gotodetails:function(e){
        	Spinner.show();
            var that = this;
            var target = e.target || e.currentTarget;
            var _index = $(target).data("index");
            var _draft = JSON.parse(JSON.stringify(that.draftList[_index]));
            var tmpTemplate = '';
            var _url = Config.eSigConfig.serviceUrl+ 'EsigDoc(docid='+_draft.docid+')/getDocument(includeSupportingDocs=true)';
            $.ajax({
				cache : false,
				type : "GET",
				url : _url,
				contentType : "application/json",
				//data : data,
				dataType : "json",
				success : function(res) {
					Spinner.hide();
					if(res.status.statCd == "0"){
						var _disclosures = res.ESignatureDocument.supportingDoc;
						_disclosures = _.sortBy(_disclosures,'supportingDocDescription');
						_disclosures = _.sortBy(_disclosures,'supportingDocType');
						
						//sort the disclosure based on name
						_draft.supportingDoc = _disclosures;
						 tmpTemplate = _.template(FormDetailsTemplate);
						 $("#practicetech-subapp").html(tmpTemplate({data:_draft}));
					}else{
						alert("Disclosure Service error.");
					}
					window.scrollTo(0,0);
				},
				error : function(jqXHR, textStatus, errorThrown) {
					 Spinner.hide();
					window.scrollTo(0,0);
					//alert("Disclosure Service error.");
					 tmpTemplate = _.template(FormDetailsTemplate);
					 $("#practicetech-subapp").html(tmpTemplate({data:{}}));
					 if(jqXHR.status != 401){
						 that.showErrorMsg('#form-details-page-system-error');
					 }else{
						 that.showErrorMsg('#esig-unauthorized-error');
					 }
					 $('.formdetails-container').hide();
					
				}
            });

        },
        
        showErrorMsg: function(el){
        	 $('.error-wrapper').addClass('hidden');
        	 $(el).removeClass('hidden');
        },
        
       gotorender: function (e) {
            var that = this;
            that.render();
        },

        sortDraftsList : function(e){
            var $this = $(e.currentTarget);
            var $thisSpan = $this.find("span.sorticons");
            var sortOrder = "";
            var sortField = $this.attr('data-sort');
            if(!$this.hasClass("reset-sorting")){
                if ($thisSpan.hasClass("desc-icon")) {
                    $thisSpan.removeClass("desc-icon").addClass("asc-icon").addClass("act");
                    sortOrder = "asc";
                        
                }
                else if ($thisSpan.hasClass("asc-icon")) {
                    $thisSpan.removeClass("asc-icon").addClass("desc-icon").addClass("act");
                    sortOrder = "desc";
                }
                else {
                    $thisSpan.addClass("asc-icon").addClass("act");
                    sortOrder = "asc";
                } 
            }       
            $(".esig-sorting").each(function () {
                  
                var $innerThisSpan = $(this).find('span.sorticons');               
                if (!$thisSpan.is($innerThisSpan) && $innerThisSpan.hasClass("act")) {
                    if ($innerThisSpan.hasClass("asc-icon")) {
                        $innerThisSpan.removeClass("asc-icon").removeClass("act");
                    }
                    if ($innerThisSpan.hasClass("desc-icon")) {
                        $innerThisSpan.removeClass("desc-icon").removeClass("act");
                    }

                }
            });
            
            var options = {
            		sortField:sortField,
            		sortOrder:sortOrder
            };
            
            this.render(options);
            $(".esig-sorting[data-sort='"+sortField+"']").find('span').addClass(sortOrder+"-icon").addClass("act");
        },
        applySortToDraftList : function(draftListCollection,sortField,sortOrder){
    		//sorting the collection
    		if(sortField && sortOrder){
    			if(sortField == "ownership"){
    				if(sortOrder == "asc"){
    					draftListCollection.sort(function (r1, r2) {
    						
    						  if(r1.ownershipTypeCd === ""){
    							return -1;
    						  }
        					  if (r1.ownershipTypeCd > r2.ownershipTypeCd) { 
        					    return 1;
        					  }
        					  if (r1.ownershipTypeCd < r2.ownershipTypeCd) {
        					    return -1;
        					  }
        					  // r1 must be equal to r2
        					  return 0;
        					});
    				}else if(sortOrder == "desc"){
    					draftListCollection.sort(function (r1, r2) {
    						  if(r2.ownershipTypeCd === ""){
    							return -1;
    						  }
    						  if (r1.ownershipTypeCd < r2.ownershipTypeCd) { 
        					    return 1;
        					  }
        					  if (r1.ownershipTypeCd > r2.ownershipTypeCd) {
        					    return -1;
        					  }
        					  // r1 must be equal to r2
        					  return 0;
        					});
    				}
    				
    			}
    		}else{
    			draftListCollection.sort(function (r1, r2) {
    				r1 = Moment(r1.modifiedTime).format("YYYY-MM-DD H:M:S A");
					r2 = Moment(r2.modifiedTime).format("YYYY-MM-DD H:M:S A");
					if (r1 < r2) { 
					    return 1;
					  }
					  if (r1 > r2) {
					    return -1;
					  }
					  // r1 must be equal to r2
					  return 0;
    				});
    		}
    	},
    	handlebacktoCP:function(){
    	    Spinner.show();
    	    setTimeout(function () { gotoCP(); }, 800);
    	    Spinner.hide();
    	    function gotoCP() {
    	        location.hash = '#contactprofile/';
    	    }
    	},
        render: function (options) {
        	try{
        		var _that = this;
        		var compiledTemplate = _.template(DraftsTemplate);
        		if(!options)
        			options = {sortField:null,sortOrder:null};
        		if(_that.draftList && _that.draftList.length>0){
        			
        			if(options && options.sortField == "ownership"){
        				var tmpObjCollectionNotNull  = [];
        				var tmpObjCollectionNull  = [];
        				$.each(_that.draftList,function(key,row){
        					if(!row.ownershipTypeCd || row.ownershipTypeCd === "" ||
        							row.ownershipTypeCd === null){
        						tmpObjCollectionNull.push(row);
        					}else{
        						tmpObjCollectionNotNull.push(row);
        					}
        				});
        				
        				_that.applySortToDraftList(tmpObjCollectionNotNull,options.sortField,options.sortOrder);
        				tmpObjCollectionNotNull = tmpObjCollectionNotNull.concat(tmpObjCollectionNull);
        				/*Shibin fix: Issue after sorting if user click on the document wrong details is shown.
        				 * Cause: draftList array order remains same even after sort. Fix: Updates draftList array on sort click.
        				 * */
        				_that.draftList=tmpObjCollectionNotNull;
        				_that.$el.html(compiledTemplate({data:tmpObjCollectionNotNull}));
        			}else{
        				_that.applySortToDraftList(_that.draftList,options.sortField,options.sortOrder);
            			_that.$el.html(compiledTemplate({data:_that.draftList}));
        			}
        			$(window).scrollTop(0,0);
        		}else{
        			Spinner.show();
                	var _options = {
                			fmId : parseInt(GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID),
                			clientId : GlobalContext.getInstance().getGlobalContext().Context.ContactId
                	};
                	DataService.geteSigDraftList(_options).then(function(response){
                		_that.draftList = response.esignatureDocument;
                		if(_that.draftList && _that.draftList.length>0){
                			//Remove null elements from array
                			$.each(_that.draftList,function(key,val){
                    			if(!val){
                    				_that.draftList.splice(key,1);
                    			}
                    		});
                			_that.applySortToDraftList(_that.draftList);
                		}
                		_that.$el.html(compiledTemplate({data:response.esignatureDocument}));
                		Spinner.hide();
                		$(window).scrollTop(0,0);
                	}).fail(function(err){
                		Spinner.hide();
                		_that.$el.html(compiledTemplate({data:{}}));
                		if(err.status != 401){
                			_that.showErrorMsg('#drafts-page-system-error');
   					 	}else{
   					 	_that.showErrorMsg('#esig-unauthorized-error');
   					 	}
                		$(".drafts-container").hide();
                	});
        		}
        		
            	
        	}catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        }
    });
    return draft;
});