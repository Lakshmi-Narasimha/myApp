/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function switchController($scope, fticLoggerMessage, loggerConstants, $filter, TransactConstant, authenticationService, $state) {
    console.info("switch Controller!!");
    $scope.config.txnFormDetails.title = $filter('translate')(TransactConstant.transact.SWITCH_DTLS);
    if ((authenticationService.isInvestorLoggedIn()) && $state.current.name === 'invTransact.base.switch'){
    	$scope.header.title = 'Switch Funds';	
    }else{
   		$scope.header.title = TransactConstant.switch.SWITCH_HEADING; 
    } 
}

switchController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$filter', 'TransactConstant', 'authenticationService', '$state'];
module.exports = switchController;