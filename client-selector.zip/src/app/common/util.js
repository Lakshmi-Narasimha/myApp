define(['jquery', 'lodash', 'config', 'backbone'],
    function ($, _, config, Backbone) {

        function setExpiration(cookieLife){
            var today = new Date();
            var expr = new Date(today.getTime() + cookieLife * 24 * 60 * 60 * 1000);
            return expr.toGMTString();
        }

        var Util = function () {
            this.userFmid = null;
            this.isCSR = false;
            this.csrSelectedFmid = null;
            this.canSubmit = null; // Boolean
            this.selectedTeamAdvisorFmid = null;

            this.getAdvisorFmidForGettingPractices = function () {
                return this.csrSelectedFmid ? this.csrSelectedFmid : this.userFmid;
            };
            this.isEmpty = function (anObject, falseEqualsEmpty = true) {
                if (anObject != null) {
                    switch (typeof anObject) {
                        case 'string':
                            return $.trim(anObject) == '';
                        case 'number':
                            return anObject == 0;
                        case 'boolean':
                            return falseEqualsEmpty ? !anObject : false;
                        default:
                            return _.isEmpty(anObject);
                    }
                }
                return true;
            };
            this.isNotEmpty = function(anObject, falseEqualsEmpty) {
                return !this.isEmpty(anObject, falseEqualsEmpty);
            };
            /*
             * Method to format numbers/strings
             * @param input- excepts a number in string or number format
             * @param maxLength- excepts total numbers of digits needed the formatted output
             * Returns formatted number in string format as output
             */
            this.formatWithZeros = function (input /* required */, maxLength /* required */) {
                var str = input ? input.toString() : "";
                return str.length < maxLength ? this.formatWithZeros("0" + str, maxLength) : str;
            };
            /*
             * Method to validate and format the date
             * @param date should be ['MM', DD','YYYY']
             * Returns boolean value as output
             */
            this.validateDate = function (date) {
                var month = date[0], day = date[1], year = date[2];
                var dateFormat = month + "/" + day + "/" + year;
                if (month == 0 || day == 0 || year == 0 || year < 1800) {
                    return false;
                } else if (month < 1 || month > 12) {
                    return false;
                } else if (day < 1 || day > 31) {
                    return false;
                } else if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
                    return false;
                } else if (month == 2) {
                    var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
                    if (day > 29 || (day == 29 && !isleap)) {
                        return false;
                    }
                }
                if (new Date(dateFormat) > new Date()) {
                    return false;
                }
                return true;
            };

            this.getCookie = function(name) {
                match = document.cookie.match(new RegExp(name + '=([^;]+)'));
                if (match) {
                    return match[1];
                }
            };

            this.setCookie = function(name, value, domain, expires, path, secure) {

                cookie = name + "=" + escape(value) + "; ";

                if (domain) {
                    cookie += "domain=" + domain + "; ";
                }
                if (expires) {
                    expires = setExpiration(expires);
                    cookie += "expires=" + expires + "; ";
                }
                if (path) {
                    cookie += "path=" + path + "; ";
                }
                if (secure) {
                    cookie += "secure; ";
                }

                document.cookie = cookie;
            };

            this.isInternetExplorer = function() {
                return !!document.documentMode;
            };

            // returns {urlWithoutQueryString: String,  params: {String: String}, hashTag: String}
            this.parseURL = function(url) {
                var parts = {};
                var urlAndHashTag = url.split('#');
                var schemeAndHostAndPath = urlAndHashTag[0];
                parts.hashTag = urlAndHashTag.length > 1 ? urlAndHashTag[1] : null;
                var urlAndQueryString = schemeAndHostAndPath.split('?');
                parts.urlWithoutQueryString = urlAndQueryString[0];
                parts.params = {};
                var queryString = urlAndQueryString.length > 1 ? urlAndQueryString[1] : null;
                if (queryString) {
                    parts.params = _.fromPairs(_.map(queryString.split('&'), function (kAndV) {
                        return kAndV.split('=');
                    }));
                }
                return parts;
            };

            this.toURL = function(urlParts) {
                var url = urlParts.urlWithoutQueryString;
                if (urlParts.params) {
                    _.forEach(urlParts.params, function(value, key) {
                        if (value) {
                            url += (_.includes(url, '?') ? '&' : '?') + key + '=' + value;
                        }
                    });
                }
                if (urlParts.hashTag) {
                    url += '#' + urlParts.hashTag;
                }
                return url;
            };

            this.toAdvisorMobileDeepLinkingUrl = function(contextId) {
                var url = config.advisorMobileDeeplinkUrl + "?route=contactprofile&contextid=" + contextId + "&mode=nav&srcSystem=SAA";
                return url;
            };

            this.isBackboneModel = function (obj) {
                return !!(obj && (obj instanceof Backbone.Model));
            };

            this.handleAddressCheck = function (e) {
                let regex = new RegExp("^[a-zA-Z0-9-&/% ]*$");
                let key = String.fromCharCode(!e.charCode ? e.which : e.charCode);
                if (!regex.test(key)) {
                    e.preventDefault();
                    return false;
                }
                return true;
            };
        };

        return new Util();

    });
