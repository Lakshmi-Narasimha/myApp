// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var NominationDetailsSummaryModelSchema = new mongoose.Schema({
    NominationDetailsSummaryResp: {
        type: Array,
        "default": []
    }
});

var NominationDetailsSummaryModelLookUp = mongoose.model('NominationDetailsSummaryModelLookUp', NominationDetailsSummaryModelSchema);

var NominationDetailsSummaryModel = new NominationDetailsSummaryModelLookUp({
    NominationDetailsSummaryResp : {
        "nominationDetails": {
            "fundWiseData":[
                {                
                    "folioNo":"124523",
                    "accountNo":"000901524856",
                    "fund":"Franklin India Equity Fund - Growth",
                    "nomination":"Rajini",
                    "familySolutions":"Yes",
                    "percentageAllocation":"50"
                },
                {                
                    "folioNo":"865653",
                    "accountNo":"0005656856",
                    "fund":"Franklin India Equity Fund - Growth",
                    "nomination":"Gajini",
                    "familySolutions":"Yes",
                    "percentageAllocation":"50"
                }
            ]
        }
    }
});

NominationDetailsSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating NominationDetailsSummaryModelLookUp table, please contact admin...');
    } else {
        NominationDetailsSummaryModelLookUp.remove({}, function(err) {
            console.log('NominationDetailsSummaryModelLookUp collection removed');
            NominationDetailsSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating NominationDetailsSummaryModelLookUp table, please contact admin...');
                }
                console.log('NominationDetailsSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = NominationDetailsSummaryModelLookUp;
