'use strict';

var folioValidationInitialLoader = function (folioValidationModelService, transactEvents, transactEventConstants) {

    var folioValidationInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope, param) {

            folioValidationModelService.fetchfolioValidation(param)
                .then(folioValidationSuccess, handleFailure);

            function folioValidationSuccess(data) {
                folioValidationModelService.setFolioValidationDtls(data.newFolioMatcherResp);
                transactEvents.transact.publishFolioValidation(scope,folioValidationModelService.getFolioValidationDtls());

            }

            function handleFailure(data){
                console.error('handleFailure');
                folioValidationInitialLoader._isServicesData = false;
            }
        }

    };
    return folioValidationInitialLoader;
};

folioValidationInitialLoader.$inject = ['folioValidationModelService', 'transactEvents', 'transactEventConstants'];

module.exports = folioValidationInitialLoader;