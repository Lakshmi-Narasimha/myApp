/**
 * @ngdoc property
 * @name Forgot Password controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter
function otpController($scope, $state, $filter, TransactConstant, $uibModal, constants, advisorRegistrationModelService, configUrlModel, toaster, fticStateChange) {
    $scope.formData = {};
    $scope.otpObj = {};
    $scope.displayBackBtn = true;
    $scope.backBtn = function($event) {
        $event.preventDefault();
        fticStateChange.stateChange($state, 'loginmaster.arndetails');
        //$state.go('loginmaster.arndetails');
    };
    $scope.headingObj = {
        text: '< Register'
    };
    $scope.otpMessageText = {
        text: $filter('translate')(constants.login.OTP_TEXT),
        image: '../' + configUrlModel.getImagesUrl() + '/OTP_Tick.svg'
    };
    $scope.otpObject = {
        key: 'otp',
        text: 'OTP',
        value: '',
        name: 'otp',
        isRequired: true,
        type: 'text'
    };
    $scope.otpSubmit = function() {
        $scope.formData.OTP = $scope.otpObject.value;
        $scope.formData.guId = advisorRegistrationModelService.getUserData().guId;
        $scope.$submitted = true;
        if ($scope.otpForm.$valid) {
            var postSuccess = function() {
                fticStateChange.stateChange($state, 'loginmaster.registeruser');
                //$state.go('loginmaster.registeruser');
            };
            var postFailure = function(errorResp) {
                $scope.errorMessage = errorResp.data[0].errorDescription;
            };
            advisorRegistrationModelService.postOtpDetails($scope.formData)
                .then(postSuccess, postFailure);
        }
    };
    $scope.resendOtp = function($event) {
        $event.preventDefault();
        var postSuccess = function() {
            toaster.success('Your OTP has been resent successfully');
        };
        var postFailure = function(errorResp) {
            toaster.error(errorResp.data[0].errorDescription);
        };
        var params = advisorRegistrationModelService.getUserData();
        advisorRegistrationModelService.postRequestForOtpDetails(params)
            .then(postSuccess, postFailure);
    };
}

otpController.$inject = ['$scope', '$state', '$filter', 'TransactConstant', '$uibModal', 'constants', 'advisorRegistrationModelService', 'configUrlModel', 'toaster', 'fticStateChange'];
module.exports = otpController;
