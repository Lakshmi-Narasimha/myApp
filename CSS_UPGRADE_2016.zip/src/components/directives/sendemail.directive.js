/**
     * @ngdoc object
     * @name component.sendemail
     * @description
     > send email item is the Final level item in One Time Payment module.
     * @requires sendEmailService
     */

angular.module('CSS.billing').directive('sendEmailCopy', [function() {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: window.UIC.sitePrefix + 'components/partials/sendemailcopy.html',
        controller: sendEmailController,
        controllerAs: 'sendEmailVM',
        bindToController: true,
        scope: {
            paymentData: '='
        }
    };
}]);

function sendEmailController($scope) {
    var sendEmailVM = this;
    sendEmailVM.submitted = false;
    sendEmailVM.isError = false;
    sendEmailVM.isSucess = false;
    sendEmailVM.errMsg = "";

    $scope.$on('submit-email', function(event, data) {
        if (angular.lowercase(data.transactionStatus) !== 's') {
            sendEmailVM.isError = true;
            sendEmailVM.errMsg = data.uiErrorDisplayMessage || "There was a problem emailing your payment receipt. Please try again. If you still need help, call us at 1-888-327-6335.";
        } else {
            sendEmailVM.isSucess = true;
            sendEmailVM.errMsg = "Your payment receipt has been sent by email.";
        }
    });

    sendEmailVM.submit = function(isValid) {
        if(isValid && (sendEmailVM.email.EmailAddress === sendEmailVM.email.confirmEmailAddress)) {
            $scope.$emit('send-email', sendEmailVM.email.EmailAddress);    
        }
        else {
            sendEmailVM.submitted = true;
        }        
    };

    sendEmailVM.closeModal = function(isCancelClicked) {
        sendEmailVM.submitted = false;
        sendEmailVM.isError = false;
        sendEmailVM.isSucess = false;
        sendEmailVM.email = {};
       
    };
}
