/**
 * @ngdoc directive
 * @name ftic search
 * @description
 *
 * - It shows the input field with glass icon
 *
**/

'use strict';

var existingUnitHolderDetails = function($timeout, eventConstants, ekycVerificationModel, authenticationService, $state,toaster) {
  return {
            template: require('./existingUnitHolderDetails.html'),
            restrict: 'E',
            replace: true,
            scope: {
              holderDetails:"=?"
            }, 
            controller: function($scope, $element, $attrs){

              $scope.displayMsg = "Please provide consent for Aadhaar Verification for the below Unit Holders";                
              $scope.continueMsg = "Please Enter OTP received from Aadhaar for the below Unit Holders";

              $scope.firstHolderStatus = false;
              $scope.secondHolderStatus = false;
              $scope.thirdHolderStatus = false;

              $scope.firstHolderKYCStatus = false;
              $scope.secondHolderKYCStatus = false;
              $scope.thirdHolderKYCStatus = false;

              $scope.firstHolderInputStatus = false;
              $scope.secondHolderInputStatus = false;
              $scope.thirdHolderInputStatus = false;

              $scope.isSubmitted = false;

              $scope.firstHolderAadhar = "";
              $scope.secondHolderAadhar = "";
              $scope.thirdHolderAadhar = ""; 

              $scope.inputFieldsForFirstHolder = [
                {
                  text: "Aadhaar",
                  value: $scope.holderDetails[0].aadhar,
                  message: "",
                  disable:true,
                  isRequired: true
                },
                {
                  text: "One-time Password (OTP)",
                  value: "",
                  message: "",
                  isRequired: true
                }
              ];                                                  

              $scope.inputFieldsForSecondHolder = [
                {
                  text: "Aadhaar",
                  value: $scope.holderDetails[1].aadhar,
                  message: "",
                  disable:true,
                  isRequired: true
                },
                {
                  text: "One-time Password (OTP)",
                  value: "",
                  message: "",
                  isRequired: true
                }
              ];

              $scope.inputFieldsForThirdHolder = [
                {
                  text: "Aadhaar",
                  value: $scope.holderDetails[2].aadhar,
                  message: "",
                  disable:true,
                  isRequired: true                
                },
                {
                  text: "One-time Password (OTP)",
                  value: "",
                  message: "",
                  isRequired: true
                }
              ];
        
              // condition for message..
              if($scope.holderDetails[0].kycregistered === false){
                $scope.firstHolderKYCStatus = true;
              }else if($scope.holderDetails[1].kycregistered === false){
                $scope.secondHolderKYCStatus = true;
              }else if($scope.holderDetails[2].kycregistered === false){
                $scope.thirdHolderKYCStatus = true;
              }

              // condition for showing no of holders..
              if($scope.holderDetails[0].name){
                $scope.firstHolderStatus = true;
                $scope.firstHolderAadhar = $scope.inputFieldsForFirstHolder[0].value;
              }

              if($scope.holderDetails[1].name){
                $scope.secondHolderStatus = true;
                $scope.secondHolderAadhar = $scope.inputFieldsForSecondHolder[0].value;
              }

              if($scope.holderDetails[2].name){
                $scope.thirdHolderStatus = true;
                $scope.thirdHolderAadhar = $scope.inputFieldsForThirdHolder[0].value;
              }

              // condition for showing and hiding input feilds of holders..
              if($scope.holderDetails[0].name !="" && !$scope.holderDetails[0].kycregistered){
                $scope.firstHolderInputStatus = true;
              }

              if($scope.holderDetails[1].name !="" && !$scope.holderDetails[1].kycregistered){
                $scope.secondHolderInputStatus = true;
              }

              if($scope.holderDetails[2].name !="" && !$scope.holderDetails[2].kycregistered){
                $scope.thirdHolderInputStatus = true;
              }

              $scope.firstHolderDetails = [
                {key:"First Holder Name",value:$scope.holderDetails[0].name},
                {key: "PAN/PEKRN", value:$scope.holderDetails[0].pan},
                {key: "KYC", value: $scope.holderDetails[0].kycregistered === true ? "Registered" : "Not Registered"}
              ]

              $scope.secondHolderDetails = [
                {key:"Second Holder",value:$scope.holderDetails[1].name},
                {key: "PAN/PEKRN", value:$scope.holderDetails[1].pan},
                {key: "KYC", value: $scope.holderDetails[1].kycregistered === true ? "Registered" : "Not Registered"}
              ]  

              $scope.thirdHolderDetails = [
                {key:"Third Holder",value:$scope.holderDetails[2].name},
                {key: "PAN/PEKRN", value:$scope.holderDetails[2].pan},
                {key: "KYC", value: $scope.holderDetails[2].kycregistered === true ? "Registered" : "Not Registered"}
              ]
                                            
              $scope.KYCsubmit = function(){                 
                
                $scope.aadhaarDetails = [];
                if($scope.firstHolderInputStatus){
                  $scope.aadhaarDetails.push({"adrPANPkrn": $scope.inputFieldsForFirstHolder[0].value})
                }
                if($scope.secondHolderInputStatus){                  
                  $scope.aadhaarDetails.push({"adrPANPkrn": $scope.inputFieldsForSecondHolder[0].value})
                }
                if($scope.thirdHolderInputStatus){                               
                  $scope.aadhaarDetails.push({"adrPANPkrn": $scope.inputFieldsForThirdHolder[0].value})
                } 
                $scope.generateAndSendEkycOtp();                            
              } 

              $scope.continueFunction = function(){
                    
                    $scope.otpDetails=[];
                    if($scope.inputFieldsForFirstHolder[1].value){
                         $scope.otpDetails.push({"adrPANPkrn":$scope.inputFieldsForFirstHolder[0].value, "otp": $scope.inputFieldsForFirstHolder[1].value});
                    }

                    if($scope.inputFieldsForSecondHolder[1].value){
                         $scope.otpDetails.push({"adrPANPkrn":$scope.inputFieldsForSecondHolder[0].value, "otp": $scope.inputFieldsForSecondHolder[1].value});
                    }

                    if($scope.inputFieldsForThirdHolder[1].value){
                         $scope.otpDetails.push({"adrPANPkrn":$scope.inputFieldsForThirdHolder[0].value, "otp": $scope.inputFieldsForThirdHolder[1].value});
                    }               
                    $scope.validateEkycOtp();
              }

              //validating otp function...
              $scope.validateEkycOtp = function(){
               
                var requestObject = {
                    paramObj:  {"guId" : authenticationService.getUser().guId},
                    bodyObj: {
                      "validateOTPeKYC":$scope.otpDetails
                    }
                  } 
                var validateSuccess = function(successResp){
       /*           var successResp = {
  "eKYCOTPValidation":[ {
    "name": "",
    "dob": "",
    "gender": "",
    "phone": "",
    "email": "",
    "careOf": "",
    "houseNo": "",
    "street": "",
    "landMark": "",
    "locality": "",
    "vtc": "",
    "subDist": "",
    "district": "",
    "pinCode": "",
    "postOffice": "",
    "statusCode": "K105",
    "statusDescription": "Invalid Kyc XML from CIDR. kycres missing in the response"
  },
{
    "name": "",
    "dob": "",
    "gender": "",
    "phone": "",
    "email": "",
    "careOf": "",
    "houseNo": "",
    "street": "",
    "landMark": "",
    "locality": "",
    "vtc": "",
    "subDist": "",
    "district": "",
    "pinCode": "",
    "postOffice": "",
    "statusCode": "K105",
    "statusDescription": "Invalid Kyc XML from CIDR. kycres missing in the response"
  }]

};*/
                    ekycVerificationModel.setHolderDetails(successResp);
                    $state.go("txnmaster.verifydetails.aadharDetails");
                };

                var validateFailure = function(errorResp){
                   toaster.error(errorResp.data[0].errorDescription);
                };
                ekycVerificationModel.validateEkycOtp(requestObject).then(validateSuccess,validateFailure);
              }

              $scope.generateAndSendEkycOtp = function($event){
                  
                  if($event){
                      $event.preventDefault();
                  }
                  var requestObject = {
                      paramObj: {"guId" : authenticationService.getUser().guId},
                      bodyObj: {
                        "ekycoptpan":$scope.aadhaarDetails
                      }
                    }  
      
                  var otpSuccess = function(successResp){
                          $scope.isSubmitted = true;
                          $scope.displayMsg = $scope.continueMsg;
                  };

                  var otpFailure = function(errorResp){
                          toaster.error(errorResp.data[0].errorDescription);
                  }; 
                  ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpSuccess, otpFailure);
              }

            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

existingUnitHolderDetails.$inject = ['$timeout', 'eventConstants', 'ekycVerificationModel', 'authenticationService','$state','toaster'];
module.exports = existingUnitHolderDetails;