'use strict';

describe('Directive : Capital gains unit holder', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, cgAccDetModel;

    var cgAccData = {
        'unitHolderDetails': {
            'invname': 'Deepit Manish Banode Dholkia Motiram Umalkar',
            'address': {
                'address1': 'B-34 Acrot Street No 161 Yerapalli street',
                'address2': 'Vadapallani',
                'address3': 'Yerapalli street',
                'address4': 'Acrot Street No',
                'city': 'Chennai',
                'pinCode': '763001',
                'line1': null,
                'line2': null,
                'line3': null
            },
            "sstatus": "NRI"
        }
    };
    cgAccDetModel = {
        getcgaccountdetunitholder: function() {
            return cgAccData.unitHolderDetails
        }
    }

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('cgAccDetModel', cgAccDetModel);
        });
    });
    var getCompiledElement = function() {
        var element = angular.element('<ftic-capital-gain-ac-unit-details></ftic-capital-gain-ac-unit-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {

        angular.mock.inject(function(_$rootScope_, _$compile_, _cgAccDetModel_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
            cgAccDetModel = _cgAccDetModel_;

            directiveEle = getCompiledElement();
            isolatedScope = directiveEle.isolateScope();
        });
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create seperate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have defined capGainunitHolder from isolated scope', function() {
        expect(isolatedScope.capGainunitHolder).toBeDefined();
        expect(isolatedScope.capGainunitHolder.invname).toBe('Deepit Manish Banode Dholkia Motiram Umalkar');
        expect(isolatedScope.capGainunitHolder.sstatus).toBe('NRI');
        expect(isolatedScope.capGainunitHolder.address).toBeDefined();
    });
});
