'use strict';

var recommendedFundsInitialLoader = function (recommendedFundsModelService, investorEvents) {

    var recommendedFundsInitialLoader = {
        _isServicesData: false,
        loadAllServices : function(scope){
            
          recommendedFundsModelService.fetchRecommendedFundDetails()
            .then(recommendedFundPlanSuccess, handleFailure);

            function recommendedFundPlanSuccess(data){
                recommendedFundsModelService.setRecommendedFundPlanDtls(data);
                investorEvents.smartSolutions.publishRecommendedFundPlan(scope,recommendedFundsModelService.getRecommendedFundPlanDtls());
           
            }
            function handleFailure(data){
                console.error('handleFailure');
                recommendedFundsInitialLoader._isServicesData = false;
            }  

         }
       
    };
       
    return recommendedFundsInitialLoader;
};

recommendedFundsInitialLoader.$inject = ['recommendedFundsModelService', 'investorEvents'];

module.exports = recommendedFundsInitialLoader;