define([ 'backbone', 'text!appmodules/eSig/app/templates/signDocumentPage.html' ],
		function(Backbone, TempView) {
			var signDocumentPageView = Backbone.View.extend({
				className : 'sign-page',
				template : _.template(TempView),
				initialize : function() {

				},
				render : function(eventName) {

					this.$el.append(this.template(this.model.attributes));
					// this.setImageContainerHeight();
					return this;
				},
				setImageContainerHeight : function() {
					var _self = this;
					this.$el.find('img').on('load', function() {
						var imgHt = $(this).height();
						_self.$el.find('.data-1').css({
							height : imgHt,
							position : 'relative'
						});

					});

				}
			});
			return signDocumentPageView;
		});
