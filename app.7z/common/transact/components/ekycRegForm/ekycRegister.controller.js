'use strict';
// Controller naming conventions should start with an uppercase letter

function ekycRegstrController($scope, $state, transactModel, transactEventConstants, authenticationService, investorRegistrationModel, $timeout, $filter, formDetailsModel, TransactConstant, toaster) {
    console.info("Ekyc Register Controller!!");
    $scope.isFirstAccordianOpened = {};
    $scope.isFirstAccordianOpened.open = true;
    $scope.isOpenNominee = {};
    $scope.isOpenNominee.open = true;
    $scope.showError = false;
    $scope.holderData = [];

    $scope.holderData = transactModel.getInstantKyc();
    var requestObject = {};
    angular.forEach($scope.holderData, function(obj, k) {

        if (obj.dob != null || obj.dob != undefined) {
            var dateVal = new Date(obj.dob);
            obj.dob = dateVal;
        }
        if (obj.name == null && obj.type == "Firstholder") {
            var dtls = {
                custName: "",
                pan: "",
                emailId: "",
                holders: [{
                    name: ""
                }, {
                    name: ""
                }, {
                    name: ""
                }]
            }
            transactModel.setInstantKyc(dtls);
        }

    })
    $scope.formDataObject = [];
    $scope.isNewFolio = transactModel.getIsNewFolio();

    $scope.checkEkyc = function() {
        $scope.$broadcast("nomineeValidation");
        if (!$scope.kycForm.$invalid) {
            $scope.$broadcast(transactEventConstants.transact.FATCA_DETAILS);
            /* post data start*/

            $timeout(function() {
                if ( /*paperlessModel.isNomineeSuccess &&*/ transactModel.isFatcaSuccess) {
                    /*Fatca form service integration - start*/
                    requestObject = {};
                    var investorDetailsObj = {
                        holderDetails: transactModel.getFatcaDetail(),
                        holdingType: '',
                        isNomineeExists: true,
                        isFolioExists: false
                    };
                    if(transactModel.transactModeOfHolding){
                        investorDetailsObj.holdingType = (transactModel.transactModeOfHolding === 'eitherRSurvivor') ? TransactConstant.common.EITHER_SURVIVOR_HOLDING_CODE:((transactModel.transactModeOfHolding === 'single') ? TransactConstant.common.SINGLE_HOLDING_CODE:'');
                    }else{
                        investorDetailsObj.holdingType = (transactModel.getSelectedFolioDts() && transactModel.getSelectedFolioDts().holderDetails.length > 1) ? TransactConstant.common.EITHER_SURVIVOR_HOLDING_CODE : TransactConstant.common.SINGLE_HOLDING_CODE;
                    }


                    if (!transactModel.getIsNewFolio()) {
                        investorDetailsObj.isFolioExists = true;
                        investorDetailsObj.folioId = transactModel.getSelectedFolioDts() ? transactModel.getSelectedFolioDts().folioId : "";
                    }
                    requestObject = investorRegistrationModel.postFatcaDetails(investorDetailsObj);
                    investorRegistrationModel.fetchinvestorRegDetails(requestObject).then(invRegSuccess, invRegFailure);
                    /*Fatca form service integration - close*/
                }
            }, 0);

            /* post data end */

        }

    }


    function invRegSuccess(data) {
        // investorRegistrationModel.setinvestorRegDetails(data);
        transactModel.setWebRefNo(data.webRefNo);
        investorRegistrationModel.setNewInvestorFolioId(data.folioId); //For 'New Folio' set FolioId returned in investorregistrtion service response.
        if(transactModel.getSelectedFolioDts()!== null || transactModel.getFolioMatcherParams()!== null) {

        	if(!transactModel.getIsNewFolio()){
        		var len = transactModel.getSelectedFolioDts().holderDetails.length;
        	}else {
        		var len = transactModel.getFolioMatcherParams().length;
        	}
        	$scope.keyValueFolioList =[
        	{
        		key:"First Holder",
        		value: transactModel.getIsNewFolio() ? transactModel.getFolioMatcherParams()[0].name : transactModel.getSelectedFolioDts().holderDetails[0].name
        	},
        	{
        		key:"Second Holder",
        		value: len >1 ? (transactModel.getIsNewFolio() ? transactModel.getFolioMatcherParams()[1].name:transactModel.getSelectedFolioDts().holderDetails[1].name) : "NA"
        	},
        	{
        		key:"Third Holder",
        		value: len > 2 ? (transactModel.getIsNewFolio() ? transactModel.getFolioMatcherParams()[2].name:transactModel.getSelectedFolioDts().holderDetails[2].name) : "NA"	
        	},
        	{
        		key:"Folio No",
        		value:transactModel.getIsNewFolio() ? "NEW": transactModel.getSelectedFolioDts().folioId
        	},
        	{
        		key:"Mode Of Holding",
        		value: len ==1 ? "SINGLE" : "JOINT"
        	}
        	]
        	$scope.folioDetailsObj = {
        		"folioId" : transactModel.getIsNewFolio() ? "NEW": transactModel.getSelectedFolioDts().folioId,
        		"firstHolder" : transactModel.getIsNewFolio() ? transactModel.getFolioMatcherParams()[0].name : transactModel.getSelectedFolioDts().holderDetails[0].name,
        		"secondHolder" : len >1 ? (transactModel.getIsNewFolio() ? transactModel.getFolioMatcherParams()[1].name:transactModel.getSelectedFolioDts().holderDetails[1].name) : "NA",
        		"thirdHolder" : len > 2 ? (transactModel.getIsNewFolio() ? transactModel.getFolioMatcherParams()[2].name:transactModel.getSelectedFolioDts().holderDetails[2].name) : "NA"  
        	}
        	transactModel.setFolioDetailsObj($scope.folioDetailsObj);
        	$scope.$emit("setFolioDetailsTl",$scope.keyValueFolioList)
        	if(transactModel.getTransactType() == "BUYFUND"  || transactModel.getTransactType() == "BUY"){
        		$state.go('transactnow.baseNow.buy');
        		return;
        	}
        	else if(transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP"){
        		$state.go('transactnow.baseNow.sip');
        		return;
        	}
        	else if(transactModel.getTransactType() == TransactConstant.renewSip.RENEWSIP){
        		$state.go('transactnow.baseNow.renewSip');
        		return;
        	}else if(transactModel.isTransactNowSmartSol) {
        		$state.go('transactnow.baseNow.smartSolTransact');
        		return;
        	}
		}
    }

    function invRegFailure(err) {
        console.log("Investor Registration Failure");
        var resetFatcaArray = [];
        $scope.kycForm.fatcaArray = resetFatcaArray;
        transactModel.setFatcaDetail(resetFatcaArray);
        toaster.error(err.data[0].errorDescription);
    }

    $scope.goBack = function() {
        if (transactModel.getTransactType() === "BUYFUND" || transactModel.getTransactType() === "BUY") {
            $state.go('transactnow.baseNow.buy');
            return;
        } else if (transactModel.getTransactType() === "FUNDSIP" || transactModel.getTransactType() === "SIP") {
            $state.go('transactnow.baseNow.sip');
            return;
        } else if (transactModel.getTransactType() === TransactConstant.renewSip.RENEWSIP) {
            $state.go('transactnow.baseNow.renewSip');
            return;
        } else if(transactModel.getTransactType() === TransactConstant.guest.SMART_SOLUTIONS) {
            $state.go('transactnow.baseNow.smartSolTransact');
        }
    }
}
ekycRegstrController.$inject = ['$scope', '$state', 'transactModel', 'transactEventConstants', 'authenticationService', 'investorRegistrationModel', '$timeout', '$filter', 'formDetailsModel', 'TransactConstant', 'toaster'];
module.exports = ekycRegstrController;