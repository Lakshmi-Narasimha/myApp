import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { AlertMessage } from './_models/alertmessage';
import { AIAssistCacheService } from './_services/aiassistcache.service';
import { AIAssistAlertService } from './_services/aialert.service';
import { ModalDirective, ModalOptions } from 'ng2-bootstrap';
import * as $ from 'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

   //@Input('rootPath')
    appRoot: string;
    title = 'app works!';
    body: string = 'my awesome content';
    progressWidth : number = 100;
    progressStatusWidth : number = 0;
    ajaxprogressinterval : any;
    succproginteval : any;
    alertMessageConfig : AlertMessage = new AlertMessage();
    dialogMessage : AlertMessage = new AlertMessage();
    appRootPath: string;
    activeUser: any;

    modalOptions : ModalOptions = {
    backdrop: "static",
    keyboard: false,
    focus: true,
    show: true,
    ignoreBackdropClick: false
  };

    @ViewChild('yesnodialog') public yesnoDialog: ModalDirective;

    constructor(private cacheService : AIAssistCacheService, private aiAlertService : AIAssistAlertService, private elementRef: ElementRef) {
      this.subscribeForRootPath();
      this.appRoot = elementRef.nativeElement.getAttribute('rootPath')
      this.cacheService.updateRootPath(this.appRoot);
      this.subscribeForAlertService();
    }

    ngOnInit() {
    }

    subscribeForRootPath() {
      this.cacheService.rootPathObservable.subscribe((data) => {
        this.appRootPath = data;
      });
      this.cacheService.currentUserObservable.subscribe((data) => {
        if(data) {
          this.activeUser = data;
        } else {
          this.activeUser = null;
        }
      });
    }

    subscribeForAlertService() {
      this.aiAlertService.alertMessageObservable.subscribe((data) => {
        this.alertMessageConfig = data;

        if ( this.alertMessageConfig.messageType == "success" ) {

          this.succproginteval =  setInterval(()=>{
             this.progressWidth = this.progressWidth - 1;
          },3000/100);

          setTimeout(() => {
            if(this.alertMessageConfig != null && this.alertMessageConfig != undefined)
              this.alertMessageConfig.messageType = "";
            else {
              this.alertMessageConfig = new AlertMessage();
            }
            this.clearIntervalByParam(this.succproginteval);
            this.progressWidth = 100;
          }, 3500);

        }

        if ( this.alertMessageConfig.messageType == "status" ) {
          this.ajaxprogressinterval = setInterval(()=>{
             this.progressStatusWidth = this.progressStatusWidth + 1;
             if(this.progressStatusWidth == 90) {
              this.clearIntervalByParam(this.ajaxprogressinterval);
              this.progressStatusWidth = 0;
            }
          },1000/100);
        }

      });

      this.aiAlertService.dialogMessageObservable.subscribe((data) => {
        this.dialogMessage = data;
        this.yesnoDialog.show();
      });

    }

    OnYesClick() {
      // console.log(this.dialogMessage.callBackFunction);
      this.cacheService[this.dialogMessage.callBackFunction](this.dialogMessage.callBackParam);
      this.hideYesNoDialog();
    }

    OnNoClick() {
      this.hideYesNoDialog();
    }

    clearIntervalByParam(pInterval:any) {
      clearInterval(pInterval);
    }

    hideYesNoDialog() {
      this.yesnoDialog.hide();
      $(document.body).removeClass("modal-open");
      $(".modal-backdrop").remove();
    }
}
