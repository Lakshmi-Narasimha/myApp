﻿define(['jquery', 'underscore', 'backbone', 'components/js/views/AggregateView',
], function ($, _, Backbone, AggregateView) {
	var AbstractView = AggregateView.extend({
		modalDialog: null,
		initialize: function (options) {
			this.nestedViews = {};
		},
		removeFromDom: function () {
			AggregateView.prototype.removeFromDom.apply(this, arguments);
		}
	});
	return AbstractView;
});
