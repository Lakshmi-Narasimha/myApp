// Filename: main.js

// Require.js allows us to configure shortcut alias
require.config({
    waitSeconds: 200,
    deps: ["scripts/q"],
    callback: function (Q) {
        window.Q = Q;
    },   
    paths: {
        jquery: 'scripts/jquery-2.1.0.min',
        underscore: 'scripts/underscore',
        Q: 'scripts/q',
        backbone: 'scripts/backbone.min',
        bootstrap: 'scripts/bootstrap.min',
        text: 'scripts/text',       
        errorLog: 'appcommon/logerrors',
        moment: 'scripts/moment.min',
        backboneTouch:'scripts/backbone.touch',
        spinner : 'appcommon/spinner',
        Base64: 'scripts/base64'
    },
    shim: {
        'backbone': { deps: ['underscore', 'jquery'], exports: 'Backbone' },
        'underscore': { exports: '_' },
        'bootstrap': { deps: ['jquery'], exports: 'bootstrap' }
    }
});

require(['bootstrap', 'accountdetailstestapp'], function (Bootstrap, App) {  // force bootstrap js to load here
    App.initialize();
    document.addEventListener("touchstart", function(){}, true);
});