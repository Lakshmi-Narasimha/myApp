'use strict';

var SelectFundInitLoader = function (selectFundModel, transactEvents, transactEventConstants, fticLoggerMessage, loggerConstants, toaster, $loader) {

    var SelectFundInitLoader = {
        _isServicesData: false,
        loadAllServices: function (scope, selectedInv) {

            function selectFundDetailsSuccess(data) {
                selectFundModel.setSelectFundGridDtls(data);
                transactEvents.transact.publishInvFundGrid(scope);

            }

            function handleFailure(data) {
                console.error('handleFailure');
                SelectFundInitLoader._isServicesData = false;
                if (data.data[0].errorCode === "400") {
                    toaster.error(data.data[0].errorDescription);
                }
            }
            $loader.start();
            selectFundModel.fetchSelectFundDetails(selectedInv)
                .then(selectFundDetailsSuccess, handleFailure)
                .finally(function () {
                    $loader.stop();
                });



        },
        setSelectFundDtls: function (obj) {
            selectFundModel.setSelectFundDtls(obj);
        }
    };
    return SelectFundInitLoader;
};

SelectFundInitLoader.$inject = ['selectFundModel', 'transactEvents', 'transactEventConstants', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader'];
module.exports = SelectFundInitLoader;