/**
 * @ngdoc property
 * @name ConfirmModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function ConfirmModalController($scope, $uibModalStack, investorConstants, $filter, personalInformationModel, authenticationService, investorEventConstants, investorEvents, toaster, $state, $timeout) {

    var translateFilter = $filter('translate');
    $scope.checkConfirmPassword = true;
    // $scope.showMobileForm = false;
    $scope.confirmPassword = {
        key : 'confirmPassword',
        text : translateFilter(investorConstants.myprofile.CNF_PWD),
        value : '',
        name : 'confirmPassword',
        type : 'password',
        min : '',
        message : '',
        isRequired : true
    };
    
    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    };
    $scope.loadAddNewBankForm = function(){
        if($scope.checkConfirmPassword){
            var creds = {'guId':authenticationService.getUser().guId,'password':$scope.confirmPassword.value};
            personalInformationModel.checkConfirmPasswordPost(creds).then(function(){
                $state.go('addnewbank');
                $scope.closeModal();
            }, function(error){
                toaster.error(error.data[0].errorDescription);
            });
        }
    }
}


ConfirmModalController.$inject = ['$scope', '$uibModalStack', 'investorConstants', '$filter', 'personalInformationModel', 'authenticationService', 'investorEventConstants', 'investorEvents', 'toaster', '$state', '$timeout'];

module.exports = ConfirmModalController;