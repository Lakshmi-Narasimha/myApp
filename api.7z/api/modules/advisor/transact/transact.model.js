// getCgFolio.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var transactModelSchema = new mongoose.Schema({
    transactResp: {
        type: Array,
        "default": []
    }
});

var transactModelLookUp = mongoose.model('transactModelLookUp', transactModelSchema);

var transactModel = new transactModelLookUp({
  transactResp: [{
        investorObj : [
                          {
                              text: "First Holder Name",
                              value: "Shankar Narayan"
                          },
                          {
                              text: "PAN",
                              value: "ABCDE1234F"
                          },            
                          {
                              text: "E-Mail",
                              value: "Shankar.narayann@abc.com"
                          },            
                          {
                              text: "Mobile Number",
                              value: "9821827910"
                          },            
                          {
                              text: "Second Holder Name",
                              value: "Shyama Shankar"
                          },            
                          {
                              text: "Third Holder name",
                              value: "Anil Narayan"
                          }
                      ], 

        fundObj : [
                    {
                      text: "Folio No.",
                      value: "12345647"
                    },
                    {
                      text: "Account No.",
                      value: "1234567890"
                    },            
                    {
                      text: "Fund",
                      value: "Franklin India Equity Fund"
                    }
        ]
  }]

});

transactModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating transactModelLookUp table, please contact admin...');
    } else {
        transactModelLookUp.remove({}, function(err) {
            console.log('transactModelLookUp collection removed');
            transactModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating transactModelLookUp table, please contact admin...');
                }
                console.log('transactModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = transactModelLookUp;
