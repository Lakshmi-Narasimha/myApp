/**
 * @ngdoc directive
 * @name fticInvNomineeList
 * 
 * @description
 *
 * - 
 *
 **/

'use strict';

var fticNomineeLists = function(investorEventConstants, investorEvents, investorConstants, eventConstants, nomineeDetailsModel, nomineeDetailsInitialLoader, $uibModal, $timeout,$loader,toaster, $state) {
    return {
        template: require('./nomineeLists.html'),
        restrict: 'E',
        replace: true,
        link: function($scope, $element, $attrs){
            $scope.ifChecked = false;
            $scope.showError = false;
            $scope.actionClass = 'icon-fti_inlineEdit';
            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function(){
                var modalInstance = $uibModal.open({
                  template : require('../confirmmodal/confirmModal.html'),
                  scope : $scope
                });
            });
            
            $scope.invAddNominee = function() {
                var modalInstance = $uibModal.open({
                  template : require('../confirmmodal/confirmModal.html'),
                  scope : $scope
                });                  
            };

            $scope.$on('confirmValidatePwd', function(){
                $timeout(function() {
                    $scope.addNominee = true;
                    $scope.inputObject.disable = true;
                    $scope.inputObjectAcc.disable = true;
                    $scope.nomineeDtlsLength = true;
                    var nomineeName1 ,
                     nomineeName2 , 
                     nomineeName3 , 
                     percentage1  ,
                     percentage2 ,  
                     percentage3;
                    if($scope.nomineeDtlsObj[0].nomineeDetails[0] && $scope.nomineeDtlsObj[0].nomineeDetails[0].nomineeName){
                        nomineeName1 = $scope.nomineeDtlsObj[0].nomineeDetails[0].nomineeName;
                    }else{
                        nomineeName1  = null;
                    }
                    if($scope.nomineeDtlsObj[0].nomineeDetails[1] && $scope.nomineeDtlsObj[0].nomineeDetails[1].nomineeName){
                        nomineeName2 = $scope.nomineeDtlsObj[0].nomineeDetails[1].nomineeName;
                    }else{
                        nomineeName2  = null;
                    }
                    if($scope.nomineeDtlsObj[0].nomineeDetails[2] && $scope.nomineeDtlsObj[0].nomineeDetails[2].nomineeName){
                        nomineeName3 = $scope.nomineeDtlsObj[0].nomineeDetails[2].nomineeName;
                    }else{
                        nomineeName3  = null;
                    }
                    if($scope.nomineeDtlsObj[0].nomineeDetails[0] && $scope.nomineeDtlsObj[0].nomineeDetails[0].percentage){
                        percentage1 = $scope.nomineeDtlsObj[0].nomineeDetails[0].percentage;
                    }else{
                        percentage1  = null;
                    }
                    if($scope.nomineeDtlsObj[0].nomineeDetails[1] && $scope.nomineeDtlsObj[0].nomineeDetails[1].percentage){
                        percentage2 = $scope.nomineeDtlsObj[0].nomineeDetails[1].percentage;
                    }else{
                        percentage2  = null;
                    }
                    if($scope.nomineeDtlsObj[0].nomineeDetails[2] && $scope.nomineeDtlsObj[0].nomineeDetails[2].percentage){
                        percentage3 = $scope.nomineeDtlsObj[0].nomineeDetails[2].percentage;
                    }else{
                        percentage3  = null;
                    }
                    $scope.nomineeInputObj = [
                            {
                                'nomineename' : {
                                    key : 'N1',
                                    text : '',
                                    value : nomineeName1,
                                    name : 'nominee1',
                                    type : 'text',
                                    min : '',
                                    message : '',
                                    isRequired : true,
                                    errMsg : ''
                                },
                                'percentage' : {
                                    key : 'N1',
                                    text : '',
                                    value : parseFloat(percentage1),
                                    name : 'percentage1',
                                    type : 'number',
                                    min : '',
                                    message : '',
                                    isRequired : true,
                                    errorMsg : '',
                                    errMsg : ''
                                }
                            },
                            {
                                'nomineename' : {
                                    key : 'N2',
                                    text : '',
                                    value : nomineeName2,
                                    name : 'nominee2',
                                    type : 'text',
                                    min : '',
                                    message : '',
                                    isRequired : true,
                                    errMsg : ''
                                },
                                'percentage' : {
                                    key : 'N2',
                                    text : '',
                                    value : parseFloat(percentage2),
                                    name : 'percentage2',
                                    type : 'number',
                                    min : '',
                                    message : '',
                                    isRequired : true,
                                    errorMsg : '',
                                    errMsg : ''
                                }
                            },
                            {
                                'nomineename' : {
                                    key : 'N3',
                                    text : '',
                                    value : nomineeName3,
                                    name : 'nominee3',
                                    type : 'text',
                                    min : '',
                                    message : '',
                                    isRequired : true,
                                    errMsg : ''
                                },
                                'percentage' : {
                                    key : 'N3',
                                    text : '',
                                    value : parseFloat(percentage3),
                                    name : 'percentage3',
                                    type : 'number',
                                    min : '',
                                    message : '',
                                    isRequired : true,
                                    errorMsg : '',
                                    errMsg : ''
                                }
                            }
                        ];
                    if($scope.nomineeDtlsObj){
                        $scope.showNominee = false;
                    }
                }, 0);
            });

            $scope.cancelNominee = function(){
                $scope.addNominee = false;
                $scope.showNominee = false;
                $scope.inputObject.disable = false;
                $scope.inputObjectAcc.disable = false;
                if($scope.nomineeDtlsObj.length){
                    $scope.nomineeDtlsLength = true;
                    $scope.showNominee = true;
                } 
                else{
                    $scope.nomineeDtlsLength = false;
                }  
            };

            $scope.saveNominee=function(){
                $scope.showErr = false;
                $scope.nomineeInputObj[0].nomineename.errMsg = false;
                $scope.nomineeInputObj[0].percentage.errMsg = false;
                $scope.nomineeInputObj[1].nomineename.errMsg = false;
                $scope.nomineeInputObj[1].percentage.errMsg = false;
                $scope.nomineeInputObj[2].nomineename.errMsg = false;
                $scope.nomineeInputObj[2].percentage.errMsg = false;

                $scope.nomineeInputObj[0].percentage.errorMsg = false;
                $scope.nomineeInputObj[1].percentage.errorMsg = false;
                $scope.nomineeInputObj[2].percentage.errorMsg = false;


                if(!$scope.nomineeInputObj[0].nomineename.value && !parseFloat($scope.nomineeInputObj[0].percentage.value) && !$scope.nomineeInputObj[1].nomineename.value && !parseFloat($scope.nomineeInputObj[1].percentage.value) && !$scope.nomineeInputObj[1].nomineename.value && !parseFloat($scope.nomineeInputObj[1].percentage.value)){
                    $scope.showErr = true;
                    return false;
                }

                if($scope.nomineeInputObj[0].nomineename.value && !parseFloat($scope.nomineeInputObj[0].percentage.value)){
                    $scope.nomineeInputObj[0].percentage.errMsg = true;
                    return false;
                } else if(!$scope.nomineeInputObj[0].nomineename.value && parseFloat($scope.nomineeInputObj[0].percentage.value)){
                    $scope.nomineeInputObj[0].nomineename.errMsg = true;
                    return false;
                } 

                if($scope.nomineeInputObj[1].nomineename.value && !parseFloat($scope.nomineeInputObj[1].percentage.value)){
                    $scope.nomineeInputObj[1].percentage.errMsg = true;
                    return false;
                } else if(!$scope.nomineeInputObj[1].nomineename.value && parseFloat($scope.nomineeInputObj[1].percentage.value)){
                    $scope.nomineeInputObj[1].nomineename.errMsg = true;
                    return false;
                }
                
                if($scope.nomineeInputObj[2].nomineename.value && !parseFloat($scope.nomineeInputObj[2].percentage.value)){
                    $scope.nomineeInputObj[2].percentage.errMsg = true;
                    return false;
                } else if(!$scope.nomineeInputObj[2].nomineename.value && parseFloat($scope.nomineeInputObj[2].percentage.value)){
                    $scope.nomineeInputObj[2].nomineename.errMsg = true;
                    return false;
                }
               
                if($scope.nomineeInputObj[0].percentage.value && $scope.nomineeInputObj[1].percentage.value && $scope.nomineeInputObj[2].percentage.value){
                    if(parseFloat($scope.nomineeInputObj[0].percentage.value) + parseFloat($scope.nomineeInputObj[1].percentage.value) + parseFloat($scope.nomineeInputObj[2].percentage.value) > 100){
                        $scope.nomineeInputObj[2].percentage.errorMsg = true;
                        return false;
                    }
                }
                else if($scope.nomineeInputObj[0].percentage.value && $scope.nomineeInputObj[1].percentage.value){
                    if(parseFloat($scope.nomineeInputObj[0].percentage.value) + parseFloat($scope.nomineeInputObj[1].percentage.value)  > 100){
                        $scope.nomineeInputObj[1].percentage.errorMsg = true;
                        return false;
                    }
                }else if($scope.nomineeInputObj[0].percentage.value && $scope.nomineeInputObj[2].percentage.value){
                    if(parseFloat($scope.nomineeInputObj[0].percentage.value) + parseFloat($scope.nomineeInputObj[2].percentage.value)  > 100){
                        $scope.nomineeInputObj[2].percentage.errorMsg = true;
                        return false;
                    }
                }
                else if($scope.nomineeInputObj[1].percentage.value && $scope.nomineeInputObj[2].percentage.value){
                    if(parseFloat($scope.nomineeInputObj[1].percentage.value) + parseFloat($scope.nomineeInputObj[2].percentage.value)  > 100){
                        $scope.nomineeInputObj[2].percentage.errorMsg = true;
                        return false;
                    }
                }else if($scope.nomineeInputObj[0].percentage.value){
                    if(parseFloat($scope.nomineeInputObj[0].percentage.value) > 100){
                        $scope.nomineeInputObj[0].percentage.errorMsg = true;
                        return false;
                    }
                }
                if(parseFloat($scope.nomineeInputObj[0].percentage.value) + parseFloat($scope.nomineeInputObj[1].percentage.value) + parseFloat($scope.nomineeInputObj[2].percentage.value) < 100){
                    $scope.nomineeInputObj[0].percentage.errorMsg = 'Percentage allocation should be equal to 100%';
                    //$scope.errMsg = 'You should have allocation percentage equal to 100%';
                    return false;
                }

                $scope.changeNominee=[];
                $scope.changeNominee = {
                    'folioId': $scope.selectedFolioObj.title,
                    'accountNo': $scope.selectedAccountObj.title,
                    'webRefNo': '',
                    'txnType': 'CHGNOM',
                    'userType': '10',
                    'makerId':'',
                    'firstNominee': $scope.nomineeInputObj[0].nomineename.value,
                    'fpercent': $scope.nomineeInputObj[0].percentage.value,
                    'secondNominee': $scope.nomineeInputObj[1].nomineename.value,
                    'spercent': $scope.nomineeInputObj[1].percentage.value,
                    'thirdNominee': $scope.nomineeInputObj[2].nomineename.value,
                    'tpercent': $scope.nomineeInputObj[2].percentage.value,
                    'validation':'Y'//Y-validate (or) N-Register
                };
                nomineeDetailsModel.addEditNomineeDetails($scope.changeNominee).then(function () {
                    toaster.success('Update nominee details successfully.');
                    nomineeDetailsInitialLoader._isServicesData = false;
                    $state.reload('nomineedetails');
                },function(error){
                    if(error && error.data && error.data.length > 0) {
                        toaster.error(error.data[0].errorDescription);
                    }
                }).finally(function(){
                    $loader.stop();
                });
            };
        }   
    };
};

fticNomineeLists.$inject = ['investorEventConstants', 'investorEvents', 'investorConstants', 'eventConstants', 'nomineeDetailsModel', 'nomineeDetailsInitialLoader', '$uibModal', '$timeout','$loader','toaster', '$state'];
module.exports = fticNomineeLists;