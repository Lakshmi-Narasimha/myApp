define([
], function () {
    var config = {
         // LOCAL
         awmServicePath: 'http://localhost:9040/simservice/',
         oboServicePath: 'http://localhost:9040/simservice/',
        // oboServicePath: 'http://dev12hq508.ampf.com/amp/adv_capl/oboselector/',
        // awmServicePath:'http://dev12hq508.ampf.com/amp/ods.svc/',
        launchMgpUrl: 'pt-exit-mgp-scenario-1.html',
    };

    return config;
});
