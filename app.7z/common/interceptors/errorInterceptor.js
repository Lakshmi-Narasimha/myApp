/**
 *@ngdoc service
 *@name common.interceptors.errorinterceptor
 *@description
 * <p>
 * Error Interceptor Module to handle system error or exception occurs during  pre-processing of
 * request or postprocessing of responses. Intercept requests before they are handed to
 * the server and responses before they are handed
 * over to the application code that initiated these requests
 * </p>
 * @project FTIC-Advisor
 *
 */
'use strict';
var errorInterceptor = function (fticLogger, toaster, $q, $localStorage, fticLoggerMessage, errorConstants, $filter, $cookies, appConfig, $timeout, configUrlModel, $window, $rootElement) {
    //var log = fticLogger.getLogger('errorInterceptor');
    return {

        /*
         Optional Method :request interceptors get called with a http config object.
         The function is free to modify the config object or create a new one.The
         function needs to return the config object directly,or a promise containing
         the config or a new config object.
         */
        request: function (config) {

            var proxyURL = configUrlModel.getEnvUrl('PROXY_URL');
            var authURL = configUrlModel.getEnvUrl('AUTH_REST_ENDPOINT_BASEURL');
            if (config.url.indexOf(appConfig[proxyURL]) != -1) {
                config.useXDomain = true;
                config.withCredentials = true;
            }

            else if ((config.url.indexOf(appConfig[authURL]) != -1) && ($cookies.get("customerToken") != "customer")) {
                // The below if condition is to check whether the request is having guId to append the
                // authorization header to the request.
                //alert(config.params +'--'+config.params.guId)
                if (config.params && config.params.guId) {

                    config.headers['Authorization'] = 'Bearer ' + $cookies.get("accessToken");
                }
            }

            return config || $q.when(config);
            // return config;
        },


        /*
         Optional Method :requestError interceptors gets called when a previous interceptor
         threw an error or resolved with a rejection.
         */
        requestError: function (errorRequest) {
            // do something on error
            //log.error('<<<<<<<< Inside errorInterceptor requestError function() errorRequest is >>>>>>>>>>');
            console.log('Inside errorInterceptor requestError() method');
            return $q.reject(errorRequest);
        },

        /*
         Optional Method :response interceptors get called with http response object.
         The function is free to modify the response object or create a new one.The
         function needs to return the response object directly, or as a promise containing
         the response or a new response object.
         */
        response: function (response) {
            /*log.debug('<<<<<<<< Inside errorInterceptor response function() response is >>>>>>>>>>');
             console.log('Inside errorInterceptor response() method');*/
            return response;
        },

        /* optional Method : responseError interceptor gets called when a previous interceptor
         threw an error or resolved with a rejection. */
        responseError: function (errorResponse) {
            if (errorResponse.status === 401) {
                // Removing Cookies
                // authenticationService.removeUserCookies();
                $cookies.remove('accessToken', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('guId', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('userType', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('userRedirectURI', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('userId', {'domain': appConfig.DOMAIN_CONFIG});
                $cookies.remove('reloadFired', {'domain': appConfig.DOMAIN_CONFIG});
                //  Checking app is advisor or guest if advisor redirecting -- Suresh P
                if ($rootElement.attr('ng-app') == "advisor") {
                    if (!fticLoggerMessage.sessinFlag) {
                        toaster.error("Your session has expired due to inactivity. Please re-login");
                        fticLoggerMessage.sessinFlag = true;
                    }
                    // For Development Need to comment this line -- Suresh P
                    if(window.location.host.indexOf("localhost")<0)
                    {
                        $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                    }                    
                }
            }
            ;

            /*if (errorResponse.data && errorResponse.data.length !== 0) {
                angular.forEach(errorResponse.data, function (errorObj) {
                    var message = errorObj.errorCode + " | " + $filter('translate')(errorConstants[errorObj.errorCode]);
                    fticLoggerMessage.displayLoggerMessage({'level': 'error', 'message': message});
                });
            }*/


            // do something on error or recover from error by retrying REST calls
            // log.error('<<<<<<<< Inside errorInterceptor responseError function() errorResponse is >>>>>>>>>>');
            // console.log('Inside errorInterceptor responseError() method');
            // if(errorResponse.status === 0)
            // {
            /* If any unknow error or system error or backend server is down or newtork is down
             route  user to a friendly screen withmore details . Here i am  redirecting user
             to  "Currently application experiencing technical difficulties" page
             Note: we can't use $state.go() due to circular dependencies hence used $location.path */
            // $location.path('/error/technicalIssue');
            //     toaster.error('Sorry for the inconvenience caused. Please contact our help desk 1800-XXX-XXXX!');
            // }
            // else if(errorResponse.status === 404)
            // {
            //     toaster.error('Sorry for the inconvenience caused. Please contact our help desk 1800-XXX-XXXX!');
            // }

            return $q.reject(errorResponse);
        }
    };
};

errorInterceptor.$inject = ['fticLogger', 'toaster', '$q', '$localStorage', 'fticLoggerMessage', 'errorConstants', '$filter', '$cookies', 'appConfig', '$timeout', 'configUrlModel', '$window', '$rootElement'];
module.exports = errorInterceptor;
