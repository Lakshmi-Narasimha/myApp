﻿define(['jquery', 'backbone', 'breeze'
], function ($, Backbone, Breeze) {
    var smartpad = Backbone.Model.extend({
        defaults: {
            SmartPadId: undefined,
            entityType: undefined,
            MemoDate: undefined,
            Note: undefined,
            HouseholdId: undefined,
            HouseholdName: undefined,
            Private: undefined,
            CreatedBy: undefined,
            ContactId: undefined          
        }
    });  

    var smartpads = Backbone.Collection.extend({
        model: smartpad,
    });
    return SmartPadCollection = {
        smartpads: smartpads,
        smartpad: smartpad, //Model      
    };
});
