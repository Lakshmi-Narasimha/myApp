'use strict';

function loginRoutes($stateProvider) {

    var login = {
        name: 'login', // state name
        url: '/login', // url path that activates this state
        views: {
            'content@': {
                template: require('./login.html'), // generate the Directive "homeView" - when calling the directive in HTML, the name must not be camelCased
                controller : 'loginCtrl'
            }

        },
        data: {
            moduleClasses: 'page', // assign a module class to the <body> tag
            pageClasses: 'login', // assign a page-specific class to the <body> tag;
            pageTitle: 'Login', // set the title in the <head> section of the index.html file
            pageDescription: 'Meta Description goes here' // meta description in <head>
        }
    };

     var loginmaster = {
        name: 'loginmaster', // state name
        url: '/loginmaster', // url path that activates this state
        template: require('./loginMaster.html'),
        controller: 'loginMasterCtrl'
    };

    var forgotpassword = {
        parent :'loginmaster',
        name:'loginmaster.forgotpassword',
        url:'/forgotpassword',
        views:{
            'loginView' : {
                template : require('./forgotpassword/forgotPassword.html'),
                controller : 'forgotPasswordCtrl'
            }
        }
    };

    var forgotusername = {
        parent :'loginmaster',
        name:'loginmaster.forgotusername',
        url:'/forgotusername',
        views:{
            'loginView' : {
                template : require('./forgotusername/forgotUsername.html'),
                controller : 'forgotUsernameCtrl'
            }
        }
    };

    var userverification = {
        parent :'loginmaster',
        name:'loginmaster.userverification',
        url:'/userverification',
        views:{
            'loginView' : {
                template : require('./userverification/userVerification.html'),
                controller : 'userVerificationCtrl'
            }
        }
    };

     var distributor = {
        parent :'loginmaster.forgotpassword',
        name:'loginmaster.forgotpassword.distributor',
        url:'/distributor',
        views:{
            'userTypeView' : {
                template : require('./forgotpassword/distributor/distributor.html'),
                controller : 'distributorCtrl'
            }
        }
    };

     var investor = {
        parent :'loginmaster.forgotpassword',
        name:'loginmaster.forgotpassword.investor',
        url:'/investor',
        views:{
            'userTypeView' : {
                template : require('./forgotpassword/investor/investor.html'),
                controller : 'investorCtrl'
            }
        }
    };

    var usernamedistributor = {
        parent :'loginmaster.forgotusername',
        name:'loginmaster.forgotusername.distributor',
        url:'/distributor',
        views:{
            'userTypeView' : {
                template : require('./forgotusername/distributor/distributor.html'),
                controller : 'usernameDistributorCtrl'
            }
        }
    };

     var usernameinvestor = {
        parent :'loginmaster.forgotusername',
        name:'loginmaster.forgotusername.investor',
        url:'/investor',
        views:{
            'userTypeView' : {
                template : require('./forgotusername/investor/investor.html'),
                controller : 'usernameInvestorCtrl'
            }
        }
    };

     var register = {
        parent :'loginmaster',
        name:'loginmaster.register',
        url:'/register',
        views:{
            'loginView' : {
                template : require('./register/register.html'),
                controller : 'registerCtrl'
            }
        }
    };

     var registerUser = {
        parent :'loginmaster',
        name:'loginmaster.registeruser',
        url:'/registeruser',
        views:{
            'loginView' : {
                template : require('./registeruser/registerUser.html'),
                controller : 'registerUserCtrl'
            }
        }
    };

     var arndetails = {
        parent :'loginmaster',
        name:'loginmaster.arndetails',
        url:'/arndetails',
        views:{
            'loginView' : {
                template : require('./arndetails/arnDetails.html'),
                controller : 'arnCtrl'
            }
        }
    };
     var otpdetails = {
        parent :'loginmaster',
        name:'loginmaster.otpdetails',
        url:'/otpdetails',
        views:{
            'loginView' : {
                template : require('./otpdetails/otpDetails.html'),
                controller : 'otpCtrl'
            }
        }
    };

    var securityquestion = {
        parent :'loginmaster.userverification',
        name:'loginmaster.userverification.securityquestion',
        url:'/securityquestion',
        views:{
            'verificationView' : {
                template : require('./userverification/securityquestion/securityQuestion.html'),
                controller : 'securityQuestionCtrl'
            }
        }
    };

     var otpverification = {
        parent :'loginmaster.userverification',
        name:'loginmaster.userverification.otpverification',
        url:'/otpverification',
        views:{
            'verificationView' : {
                template : require('./userverification/otpVerification/otpVerification.html'),
                controller : 'otpVerificationCtrl'
            }
        }
    };

    var thankyou = {
        parent : 'loginmaster',
        name:'loginmaster.thankyou',
        url:'/thankyou',
        views : {
            'loginView' : {
                template : require('./thankyou/thankyou.html'),
                controller :'thankYouCtrl'
            }
        }
    };

 

     var newpassword = {
        parent :'loginmaster',
        name:'loginmaster.newpassword',
        url:'/newpassword',
        views:{
            'loginView' : {
                template : require('./createnewpassword/createNewPassword.html'),
                controller : 'createNewPasswordCtrl'
            }
        }
    };


    $stateProvider.state(login)
                  .state(loginmaster)
                  .state(forgotpassword)
                  .state(distributor)
                  .state(investor)
                  .state(register)
                  .state(arndetails)
                  .state(otpdetails)
                  .state(userverification) 
                  .state(securityquestion)
                  .state(otpverification)
                  .state(thankyou)
                  .state(forgotusername)
                  .state(usernameinvestor)
                  .state(usernamedistributor)
                  .state(newpassword)
                  .state(registerUser)
                 ;
 

}

loginRoutes.$inject = ['$stateProvider'];
module.exports = loginRoutes;