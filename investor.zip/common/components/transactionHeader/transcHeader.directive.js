/**
 * @ngdoc directive
 * @name transcHeader
 * @description
 *
 * - It displays a tittle which need to be passed while declaring this directive and count.
 * 
**/

'use strict';

var transcHeader = function (){
	return {
		template : require('./transcHeader.html'),
		restrict : 'E',
		scope : {
			 inputObjects:"="		
		},
        controller: function($scope, $element, $attrs){    
        },
        link: function(scope, iElement, iAttrs, controller){
        }
	};
};

transcHeader.$inject = [];
module.exports = transcHeader;