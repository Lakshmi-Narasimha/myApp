'use strict';
function smartSolsOriginalRecommendationsCtrl($scope, $state,recommendedPlanInitialLoader,recommendedPlanModelService,advisorEventConstants) {
  $scope.keyValueList=[{key:"First Holder",value:"Shankar Narayanan"},
                      {key:"Second Holder",value:"Shyama Shankar"},
                      {key:"Third Holder",value:"Anil Narayanan"},
                      {key:"Folio.No.",value:"4563152-FS"},
                      {key:"Mode Of Holding",value:"Joint"}
                      ];


                      recommendedPlanInitialLoader.loadAllServices($scope);


   $scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function($event) {
       $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
       $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
       $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
       $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
       //console.log($scope.goalChartData);
            
    });
  $scope.goBack=function(){
    $state.go('smartSol.investor.cp');
  }
  $scope.goalsheetBtn=function(){
    $state.go('smartSol.investor.topupwithftrf.topupwithftrecommendedfundsgoalsheet');
  }
  $scope.showAnotherRecommendation=function(){
    $state.go('smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.ar');
  }
}

smartSolsOriginalRecommendationsCtrl.$inject = ['$scope', '$state','recommendedPlanInitialLoader','recommendedPlanModelService','advisorEventConstants'];
module.exports = smartSolsOriginalRecommendationsCtrl;