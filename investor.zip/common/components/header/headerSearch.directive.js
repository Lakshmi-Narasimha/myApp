var fticHeaderSearch = function() {
    return {
        template: require('./headerSearch.html'),
        restrict: 'EA',
        replace: true,
        link: function(scope) {
        }
    };
};

fticHeaderSearch.$inject = [];
module.exports = fticHeaderSearch;