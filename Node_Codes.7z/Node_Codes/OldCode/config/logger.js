var log4js = require('log4js');
var winston = require('winston');
var expressWinston = require('express-winston');
var fs = require('fs');
var path = require('path');

var logDirectory = '/log/nginx-mfchat';
//var logDirectory = path.join(__dirname, '../../log');
// ensure log directory exists
//var logDir = fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

var now = new Date();
var month = now.getMonth() + 1;
month = (month < 10 ? "0" : "") + month;
var day = now.getDate();
day = (day < 10 ? "0" : "") + day;
function replacer(key,value){
        if (key==='ca') return "skip";
        else if(key==='agent') return "skip";        
        else return value;
}

log4js.configure({
    "appenders": [
        /*
        {
            "category": "access",
            "type": "file",          
            "filename": '/log/nginx-mfchat/mfcnode_access.log',            
            "backups": 10
        },{
            "category": "outbounddata",
            "type": "dateFile",
            "filename": '/log/nginx-mfchat/mfcnode_outbound.log', 
            "pattern": "-yyyy-MM-dd", 
            "alwaysIncludePattern": false,                   
            "backups": 10
        }, */
        {
            "category": "general",
            "type": "dateFile",
            "filename": '/log/nginx-mfchat/mfcnode.log',
            "pattern": "-yyyy-MM-dd", 
            "alwaysIncludePattern": true,                 
            "backups": 10
        }, {
            "category": "conversation",
            "type": "dateFile",
            "filename": '/log/nginx-mfchat/mfcnode_conversation.log', 
            "pattern": "-yyyy-MM-dd",  
            "alwaysIncludePattern": true,        
            "backups": 10
        },{
            "category": "error",
            "type": "dateFile",
            "filename": '/log/nginx-mfchat/mfcnode_error.log', 
            "pattern": "-yyyy-MM-dd",
            "alwaysIncludePattern": true,          
            "backups": 10
        }       
    ],
    "levels": {
        //"access": "ALL",
        //"inbounddata": "ALL",
        //"outbounddata": "ALL",
        "general": "ALL", 
        "conversation": "ALL",
        "error": "ERROR"
    }
});

var winstonLogConfig = {
    transports: [
        /*
        new winston.transports.File({
            level: 'info',
            name: 'info-file',
            //filename: path.join(logDirectory, 'mfcnode_win_all_' + month + "-" + day + "-" + now.getFullYear() + '.log'),
            filename: path.join(logDirectory, 'mfcnode_win_all-'+ now.getFullYear() + '-' + month + '-'+ day +'.log'),
            handleExceptions: true,
            json: true,
            maxsize: 52428800, //50MB
            maxFiles: 5,
            colorize: false
        }),*/
        new winston.transports.File({
            level: 'error',
            name: 'error-file',
            //filename: path.join(logDirectory, 'mfcnode_win_error.log'),
            filename: path.join(logDirectory, 'mfcnode_win_error-'+ now.getFullYear() + '-' + month + '-'+ day +'.log'),
            handleExceptions: true,
            json: true,
            maxsize: 52428800, //50MB
            maxFiles: 5,
            colorize: false
        })
    ],
    msg: "HTTP {{req.method}} {{req.url}}",
    exitOnError: false
};

module.exports = {
    access: log4js.getLogger('access'),
    //inBoundData: log4js.getLogger('inbounddata'),
    //outBoundData: log4js.getLogger('outbounddata'),
    general: log4js.getLogger('general'),
    error: log4js.getLogger('error'),
    conversation: log4js.getLogger('conversation'),
    //express: log4js.connectLogger(log4js.getLogger('access'), { level: log4js.levels.INFO }),
    winstonExpress: expressWinston.logger(winstonLogConfig),   
    formatInBoundReqMsg: function(req) {
        req.session = req.session || {};
        return 'SessionID: ' + req.session.id + ' HTTP ' + req.method + " " + req.url + ' Request Params: ' + JSON.stringify(req.params) + ' Request Body: ' + JSON.stringify(req.body);
    },
    formatInBoundResMsg: function(req, res) {
        req.session = req.session || {};
        res = res || {};
        return 'SessionID: ' + req.session.id + ' Response Body: ' + JSON.stringify(res) + ' HTTP ' + req.method + " " + req.url ;
    },
    formatOutBoundReqMsg: function(reqObj, data, sessionId) {
        data = data || '{}';            
        return 'SessionID: ' + sessionId + ' Request: ' + JSON.stringify(reqObj, replacer) + ' Request Body: ' + JSON.stringify(data,replacer);
    },
    formatOutBoundResMsg: function(reqObj, res, sessionId) {
        res = res || {};
        return 'SessionID: ' + sessionId  + ' Response Body: ' + JSON.stringify(res) + ' HTTP ' + reqObj.method + " " + reqObj.host + ' ' + reqObj.path;
    },
    formatInfoMsg: function(sessionId, msg) {        
        return 'SessionID: ' + sessionId + " " + msg;
    },
    formatConvsStrtMsg: function(req, sessionId) {
        req.session = req.session || {};
        req.body.RequestParams = req.body.RequestParams || {};
        this.conversation.info('/******************* Initiated Conversation With Session Id(' + req.session.id + ') *******************/');
        this.conversation.info('Nick Name: ' + req.session.nickName);
        this.conversation.info('Agent Group ID: ' + req.session.agentGroupID);
        this.conversation.info('Acc Role: ' + req.session.accRole);
        this.conversation.info('MDN: ' + req.session.MDN);
        this.conversation.info('Initial Message: ' + req.body.RequestParams.InitialMessage);
        this.conversation.info('Initial Paramters: ' + JSON.stringify(req.body.RequestParams.InitialParams));
        this.conversation.info('============================================================================================');
    }  

};
