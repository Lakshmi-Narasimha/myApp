﻿define(['jquery', 'backbone'], function ($, Backbone) {
    var Task = Backbone.Model.extend({
        defaults: {
            activityId: undefined,
            subject: undefined,
            startDate: undefined,
            endDate: undefined,
            dueDate: undefined,
            selectedParticipants: undefined,
            contactId: undefined,
            location: undefined,
            isPrivate: undefined,  // boolean
            priority: undefined,  // value, e.g., 'Medium'
            status: undefined,  // value, e.g., 'Active'
            typeId: undefined, // code
            subTypeId: undefined,  // code
            description: undefined,
            actKeyword: undefined,  // value
        },
        populateFromBreezeEntity: function (breezeEntity) {
            this.set('activityId', breezeEntity.get('activityId'));
            this.set('subject', breezeEntity.get('subject'));
            this.set('startDate', breezeEntity.get('startDate'));
            this.set('endDate', breezeEntity.get('endDate'));
            this.set('dueDate',breezeEntity.get('dueDate'));
            this.set('selectedParticipants', breezeEntity.get('selectedParticpants'));
            this.set('contactId', breezeEntity.get('contactId'));
            this.set('location', breezeEntity.get('location'));
            this.set('isPrivate', breezeEntity.get('privateTask') == 'Yes' ? true : false);
            this.set('typeId', breezeEntity.get('typeId'));
            this.set('subTypeId', breezeEntity.get('subTypeId'));
            this.set('description', breezeEntity.get('description'));
            this.set('actKeyword', breezeEntity.get('actKeyword'));
            this.set('priority', breezeEntity.get('priority'));
        },
        attributesForSave: function(isAdd) {
            var attributes = _.clone(this.attributes);

            attributes.startDate = moment(attributes.startDate).format("MM-DD-YYYY");
            attributes.endDate = moment(attributes.endDate).format("MM-DD-YYYY");
            if (attributes.dueDate) {
                if (isAdd) {
                    attributes.dueDate = moment(attributes.dueDate).format("MM-DD-YYYY");
                }
            } else {
                attributes.dueDate = '';
            }
            attributes.privateTask = attributes.isPrivate ? "1" : "0";
            attributes.type = attributes.typeId;
            attributes.subType = attributes.subTypeId;
            attributes.selectedParticpants = attributes.selectedParticipants;  // endpoint misspelled property name
            // cleanup unused vars to avoid confusion
            delete attributes.isPrivate;
            delete attributes.typeId;
            delete attributes.subTypeId;
            delete attributes.selectedParticipants;

            return attributes;
        },
        attributesForUpdate: function() {
            var attributes = _.clone(this.attributes);

            attributes.startDate =  attributes.startDate;
            attributes.endDate = attributes.endDate;
            if (attributes.dueDate) {
                attributes.dueDate = attributes.dueDate;
            }
            attributes.privateTask = attributes.isPrivate ? "1" : "0";
            attributes.type = attributes.typeId;
            attributes.subType = attributes.subTypeId;
            attributes.selectedParticpants = attributes.selectedParticipants;  // endpoint misspelled property name
            // cleanup unused vars to avoid confusion
            delete attributes.isPrivate;
            delete attributes.typeId;
            delete attributes.subTypeId;
            delete attributes.selectedParticipants;

            return attributes;
        }
    });
    return Task;
});

