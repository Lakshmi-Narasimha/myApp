import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, RequestMethod } from '@angular/http';

@Injectable()
export class HttpclientService {
  auth: any;
  constructor(private http: Http) { }

  createAuthorizationHeader(headers: Headers) {
    this.auth = this.auth || btoa('admin:Metlife@123')
    headers.append('Authorization', 'Basic ' + this.auth);
    headers.append("Accept", "application/json");
    headers.append('content-type','application/json');
    // headers.append("Access-Control-Allow-Origin", "*")
    // headers.append("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, PATCH, DELETE")
    // headers.append("Access-Control-Allow-Headers", "Token")
    // headers.append('Access-Control-Allow-Credentials', "true")
    // headers.append('Access-Control-Allow-Headers', "X-Accept-Charset,X-Accept,Content-Type,Credentials")
    
  }

  get(url) {
    let headers = new Headers();
    this.createAuthorizationHeader(headers);
    let requestoptions = new RequestOptions({
        method: RequestMethod.Get,
        url: url,
        headers: headers
    });
    return this.http.get(url, {
      headers: headers
    });
  }

  post(url, data) {
    let headers = new Headers();
    this.createAuthorizationHeader(headers);
    return this.http.post(url, data, {
      headers: headers
    });
  }

}
