'use strict';
describe('Directive: fticRedemptionReviewStatus', function() {
    var compile,scope,directiveElement,isolatedScope,transactModel,$window;
    
    var redeemObject = {
        'type': 'Full',
        'amount': '',
        'units': '8371.015',
        'mode': 'cheque',
        'bank': 'CITI BANK - 7335300411'
    };

    beforeEach(angular.mock.module('advisor'));     

    var getCompiledElement = function(){
        var element = angular.element('<ftic-redemption-review-status></ftic-redemption-review-status>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(function() {
        angular.mock.inject(function($rootScope,_$compile_,$window,_transactModel_) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};          
            
            transactModel = _transactModel_;
            transactModel.setTransactDetails({                
                "transactDetails" : redeemObject
            });

            transactModel.setTransactConfirm({
                'accountNo': '0010008062712',                     
                'transactionRefNo': 'SWI001166',
                'transDateTime':'Oct 16,2016'
            });
            
            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();      
        });
    });

    it('should be defined', function() {                
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
        expect(isolatedScope).toBeDefined();
    });

    it('should define the variable keyValuePairs on load if user selects full/Units type',function(){
        expect(isolatedScope.keyValuePairs[0].text).toBe('Transaction Reference No.');
        expect(isolatedScope.keyValuePairs[1].text).toBe('Request Date and Time ');
        expect(isolatedScope.keyValuePairs[2].text).toBe('Redemption Units');       

        expect(isolatedScope.keyValuePairs[0].value).toBe('SWI001166');
        expect(isolatedScope.keyValuePairs[1].value).toBe('Oct 16,2016');
        expect(isolatedScope.keyValuePairs[2].value).toBe('8371.015');   
        redeemObject = {
            'type': 'Amount',
            'amount': '513300',
            'units': '',
            'mode': 'cheque',
            'bank': 'CITI BANK - 7335300411'
        };  
    });

    it('should define the variable keyValuePairs on load if user selects amount type',function(){
        expect(isolatedScope.keyValuePairs[0].text).toBe('Transaction Reference No.');
        expect(isolatedScope.keyValuePairs[1].text).toBe('Request Date and Time ');
        expect(isolatedScope.keyValuePairs[2].text).toBe('Redemption Amount');      

        expect(isolatedScope.keyValuePairs[0].value).toBe('SWI001166');
        expect(isolatedScope.keyValuePairs[1].value).toBe('Oct 16,2016');
        expect(isolatedScope.keyValuePairs[2].value).toBe('513300');      
    });
});  