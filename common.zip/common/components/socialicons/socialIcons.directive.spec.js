/**
 * @ngdoc directive
 * @name Social Icons Directive
 * @description
 *
 * - It defines the social icons test cases  
 *
**/

'use strict';

describe('Directive: Social Icons', function() {

	var compile, scope, directiveEle;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

 		angular.mock.inject(function($rootScope, $compile, $httpBackend) {
            scope = $rootScope.$new();
  			compile = $compile;
            scope.footerIcons = [
                 {
                    "icon":"icon-fti_facebook"
                 },
                 {
                     "icon":"icon-fti_twitter"
                 },
                 {
                     "icon":"icon-fti_youtube"
                 },
                 {
                     "icon":"icon-fti_linkedin"
                 }
            ];
        	//assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-social-icons ng-repeat="icons in footerIcons" icons="icons"></ftic-social-icons>');
        directiveEle = compile(element)(scope);
        scope.$digest();

    });

    it('should be defined',function(){
		expect(directiveEle).toBeDefined();
	})


});