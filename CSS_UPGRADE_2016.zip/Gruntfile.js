/*jshint latedef: nofunc*/

/*----------------------------------( GRUNT FILE )----------------------------------*/

/**
 * The responsibility of this file is to take care of running tasks like linting,
 * minifying, concatinating, documenting, testing, serving various environment, creating distribution code etc.
 */


(function() {


    'use strict';

    var pkg = require('./package.json');
    var ngrok = require('ngrok');


    module.exports = function(grunt) {

        // load all grunt tasks
        require('load-grunt-tasks')(grunt);

        // Configurable paths for the application
        var config = require('./config/build.config.js');

        // Project configuration.
        grunt.initConfig({

            config: config,

            pkg: grunt.file.readJSON('package.json'),


            /*----------------------------------( WATCH )----------------------------------*/

            /**
             * Run predefined tasks whenever watched file patterns are added, changed
             * or deleted.*
             */

            watch: {
                js: {
                    files: ['src/**/*.js'],
                    tasks: ['jshint:all'],
                    options: {
                        livereload: '<%= connect.options.livereload %>'
                    }
                },
                jsTest: {
                    files: ['test/unit/{,*/}*.js'],
                    tasks: ['jshint:test', 'karma']
                },
                compass: {
                    files: ['<%= config.app %>/**/*.{scss,sass}'],
                    tasks: ['compass:server']
                },
                gruntfile: {
                    files: ['Gruntfile.js'],
                    tasks: ['jshint:all']
                },
                livereload: {
                    options: {
                        livereload: '<%= connect.options.livereload %>'
                    },
                    files: [
                        '<%= config.app %>/**/*.html',
                        'temp/styles/{,*/}*.css',
                        '<%= config.app %>/assets/style/images/**/*.{png,jpg,jpeg,gif,webp,svg}'
                    ]
                }
            },


            /*----------------------------------( CONNECT )----------------------------------*/

            /**
             * Run server with various ports for defined environment and tasks which a requires server
             */
            connect: {
                options: {
                    port: 3000,
                    // Change this to '0.0.0.0' to access the server from outside.
                    hostname: 'localhost',
                    livereload: 35729
                },
                livereload: {
                    options: {
                        open: true,
                        middleware: function(connect) {
                            return [
                                connect.static('temp'),
                                connect().use(
                                    '/vendor',
                                    connect.static('./vendor')
                                ),
                                connect.static(config.app)
                            ];
                        }
                    }
                },
                coverageE2E: {
                    options: {
                        //keepalive: true,
                        middleware: function(connect) {
                            return [
                                connect.static('temp'),
                                connect().use(
                                    '/vendor',
                                    connect.static('./vendor')
                                ),
                                connect.static('app/src')
                            ];
                        }
                    }
                },
                test: {
                    options: {
                        port: 9001,
                        middleware: function(connect) {
                            return [
                                connect.static('temp'),
                                connect.static('test'),
                                connect().use(
                                    '/vendor',
                                    connect.static('./vendor')
                                ),
                                connect.static(config.app)
                            ];
                        }
                    }
                },
                doc: {
                    options: {
                        port: 9002,
                        open: true,
                        keepalive: true,
                        middleware: function(connect, options) {
                            return [
                                connect.static(options.base[0]),
                                connect.static('docs'),
                                connect.directory(options.base[0])
                            ];
                        }
                    }
                },
                dist: {
                    options: {
                        open: true,
                        base: config.dist,
                        keepalive: true
                    }
                }
            },

            /*----------------------------------( JSHINT )----------------------------------*/

            /**
             * Validate files with JSHint.
             * Make sure code styles are up to par and there are no obvious mistakes
             * @see http://www.jshint.com/docs/
             */

            jshint: {
                options: {
                    jshintrc: '.jshintrc',
                    reporter: require('jshint-stylish')
                },
                all: {
                    src: [
                        'Gruntfile.js',
                        createFolderGlobs('*.js'),
                        '!test/**'
                    ]
                },
                test: {
                    options: {
                        jshintrc: 'test/.jshintrc'
                    },
                    src: ['test/unit/{,*/}*.js']
                }
            },


            /*----------------------------------( COMPASS )----------------------------------*/

            /**
             *
             * Compiles Sass to CSS and generates necessary files if requested
             * @see http://sass-lang.com/docs/yardoc/file.SASS_REFERENCE.html#output_style
             */

            compass: {
                options: {
                    sassDir: '<%= config.app %>',
                    cssDir: '<%= config.tmp %>/styles',
                    generatedImagesDir: '<%= config.tmp %>/styles/images',
                    imagesDir: '<%= config.images %>',
                    javascriptsDir: '<%= config.app %>',
                    fontsDir: '<%= config.font %>',
                    importPath: './vendor',
                    httpImagesPath: '/images',
                    httpGeneratedImagesPath: '/images',
                    httpFontsPath: '/style/fonts',
                    relativeAssets: false,
                    assetCacheBuster: false,
                    /*noLineComments: true,*/
                    raw: 'Sass::Script::Number.precision = 10\n'
                },
                dist: {
                    options: {
                        generatedImagesDir: '<%= config.dist %>/images'
                    }
                },
                server: {
                    options: {
                        sourcemap: true
                    }
                }
            },

            /*----------------------------------( CLEAN )----------------------------------*/

            /**
             *
             * Clean files and folders. Used for temporary files or those folders which will be generated
             *
             */

            clean: {
                before: {
                    src: ['dist', 'temp']
                },
                after: {
                    src: ['temp']
                },
                server: ['temp', 'docs'],
                coverageE2E: {
                    src: ['app/src'],
                }
            },

            /*----------------------------------( AUTO PREFIXER )----------------------------------*/

            /**
             *
             * TO DO
             *
             */
            autoprefixer: {
                options: {
                    browsers: ['last 1 version']
                },
                dist: {
                    files: [{
                        expand: true,
                        cwd: 'temp/styles/',
                        src: '{,*/}*.css',
                        dest: 'temp/styles/'
                    }]
                }
            },

            /*----------------------------------( NG TEMPLATE )----------------------------------*/

            /**
             *
             * TO DO
             *
             */

            ngtemplates: {
                main: {
                    options: {
                        module: pkg.name,
                        htmlmin: '<%= htmlmin.main.options %>',
                        url: function(url) {
                            return url.replace('src/', '');
                        }
                    },
                    src: ['src/**/*.html', '!src/index.html', '!_SpecRunner.html', '!src/index.prelogin.html', '!src/index.achpayment.html', '!src/index.paymentwithoutlogin.html'],
                    dest: 'temp/templates.js'
                }
            },

            /*----------------------------------( COPY )----------------------------------*/
            /**
             *
             * Copy generated code and folders and images
             *
             */

            copy: {
                coverageE2E: {
                    files: [{
                            src: ['vendor/bootstrap-sass-official/assets/fonts/**', 'vendor/font-awesome/fonts/**', 'vendor/slick-carousel/slick/fonts/**'],
                            dest: 'app',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'src/assets/style/',
                            src: '**',
                            dest: 'app/src/assets/style/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'src/assets/style/base/',
                            src: '**',
                            dest: 'app/src/assets/style/base/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'src/assets/style/fonts/',
                            src: '**',
                            dest: 'app/src/assets/style/fonts/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'src/assets/style/images/',
                            src: '**/{*.png,*.jpg,*.svg,*.gif}',
                            dest: 'app/src/assets/style/images/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'vendor/slick-carousel',
                            src: '**/{*.png,*.jpg,*.gif}',
                            dest: 'app/src/assets/style/images/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            expand: true,
                            dot: true,
                            cwd: 'src',
                            dest: 'app/src',
                            src: [
                                '*.*',
                                'common/*',
                                'common/**/*',
                                'components/*',
                                'components/**/*',
                                'modules/*',
                                'modules/**/*',
                            ]
                        }

                    ]
                },
                dist: {
                    files: [
                        /* Commenting tealeaf : May need to uncomment in future
                        {
                            cwd: 'src/common/tealeaf',
                            src: 'tealeaf.js',
                            dest: '<%= config.dist %>/scripts/',
                            filter: 'isFile',
                            expand: true
                        },
                        */
                        {
                            src: ['vendor/bootstrap-sass-official/assets/fonts/**', 'vendor/font-awesome/fonts/**', 'vendor/slick-carousel/slick/fonts/**'],
                            dest: 'dist/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'src/assets/style/fonts/',
                            src: '**',
                            dest: 'dist/assets/style/fonts/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'src/assets/style/images/',
                            src: '**/{*.png,*.jpg,*.svg,*.gif}',
                            dest: 'dist/assets/style/images/',
                            filter: 'isFile',
                            expand: true
                        }, {
                            cwd: 'vendor/slick-carousel',
                            src: '**/{*.png,*.jpg,*.gif}',
                            dest: 'dist/assets/style/images/',
                            filter: 'isFile',
                            expand: true
                        }
                        //{src: ['vendor/angular-ui-utils/ui-utils-ieshiv.min.js'], dest: 'dist/'},
                        //{src: ['vendor/select2/*.png','vendor/select2/*.gif'], dest:'dist/css/',flatten:true,expand:true},
                        //{src: ['vendor/angular-mocks/angular-mocks.js'], dest: 'dist/'}
                    ]
                },

            },


            /*----------------------------------( DOM MUNGER )----------------------------------*/
            /**
             *
             * To modify HTML on the fly to change script and link source and href and keep a new stack for production
             *
             */

            dom_munger: {
                postlogin: {

                    options: {
                        read: [{
                            selector: 'script[attr="vendor"]',
                            attribute: 'src',
                            writeto: 'vendorjs',
                            isPath: false
                        }, {
                            selector: 'script[attr="app"]',
                            attribute: 'src',
                            writeto: 'cssjs',
                            isPath: true
                        }, {
                            selector: 'link[rel="stylesheet"][data-concat!="false"]',
                            attribute: 'href',
                            writeto: 'csscss',
                            isPath: true
                        }],
                        remove: ['script[data-remove!="false"]', 'link[data-remove!="false"]'],
                        append: [{
                            selector: 'body',
                            html: '<script src="scripts/vendor.min.js"></script><script src="scripts/fcss.min.js"></script>' //Commenting tealeaf : May need to uncomment in future<script src="scripts/tealeaf.js"></script>'
                        }],
                        prepend: [{
                            selector: 'head',
                            html: '<link rel="stylesheet" href="styles/vendor.min.css"/><link rel="stylesheet" href="styles/fcss.min.css"/><link rel="stylesheet" media="print" href="styles/fcss.print.min.css"/><!--[if lt IE 9]><script src="scripts/vendor.ie.min.js"></script><![endif]-->'
                        }]

                    },
                    src: '<%= config.app %>/index.html',
                    dest: '<%= config.dist %>/index.html'
                },
                prelogin: {
                    options: {
                        read: [{
                            selector: 'script[attr="app"]',
                            attribute: 'src',
                            writeto: 'preloginCssjs',
                            isPath: true
                        }],
                        remove: ['script[data-remove!="false"]', 'link[data-remove!="false"]'],
                        append: [{
                            selector: 'body',
                            html: '<script src="scripts/vendor.min.js"></script><script src="scripts/fcss.prelogin.min.js"></script>' /*Commenting tealeaf : May need to uncomment in future <script src="scripts/tealeaf.js"></script>*/
                        }],
                        prepend: [{
                            selector: 'head',
                            html: '<link rel="stylesheet" href="styles/vendor.min.css"/><link rel="stylesheet" href="styles/fcss.min.css"/><!--[if lt IE 9]><script src="scripts/vendor.ie.min.js"></script><![endif]-->'
                        }]
                    },
                    src: '<%= config.app %>/index.prelogin.html',
                    dest: '<%= config.dist %>/index.prelogin.html'
                },
                achpayment: {
                    options: {
                        read: [{
                            selector: 'script[attr="app"]',
                            attribute: 'src',
                            writeto: 'achpaymentCssjs',
                            isPath: true
                        }],
                        remove: ['script[data-remove!="false"]', 'link[data-remove!="false"]'],
                        append: [{
                            selector: 'body',
                            html: '<script src="scripts/vendor.min.js"></script><script src="scripts/fcss.achpayment.min.js"></script><script src="scripts/tealeaf.js"></script>'
                        }],
                        prepend: [{
                            selector: 'head',
                            html: '<link rel="stylesheet" href="styles/vendor.min.css"/><link rel="stylesheet" href="styles/fcss.min.css"/><!--[if lt IE 9]><script src="scripts/vendor.ie.min.js"></script><![endif]-->'
                        }]
                    },
                    src: '<%= config.app %>/index.achpayment.html',
                    dest: '<%= config.dist %>/index.achpayment.html'
                },
                paymentwithoutlogin: {
                    options: {
                        read: [{
                            selector: 'script[attr="app"]',
                            attribute: 'src',
                            writeto: 'paymentwithoutloginCssjs',
                            isPath: true
                        }],
                        remove: ['script[data-remove!="false"]', 'link[data-remove!="false"]'],
                        append: [{
                            selector: 'body',
                            html: '<script src="scripts/vendor.min.js"></script><script src="scripts/fcss.paymentwithoutlogin.min.js"></script><script src="scripts/tealeaf.js"></script>'
                        }],
                        prepend: [{
                            selector: 'head',
                            html: '<link rel="stylesheet" href="styles/vendor.min.css"/><link rel="stylesheet" href="styles/fcss.min.css"/><!--[if lt IE 9]><script src="scripts/vendor.ie.min.js"></script><![endif]-->'
                        }]
                    },
                    src: '<%= config.app %>/index.paymentwithoutlogin.html',
                    dest: '<%= config.dist %>/index.paymentwithoutlogin.html'
                }
            },

            /*----------------------------------( CSS MIN )----------------------------------*/
            /**
             *
             * Minify css
             *
             */

            cssmin: {
                css: {
                    files: [{
                            expand: true,
                            cwd: '<%= config.tmp %>/styles',
                            src: ['*.css', '!*.min.css', '!*.ie.css', '!*.print.css'],
                            dest: '<%= config.dist %>/styles',
                            ext: '.min.css'
                        }]
                        /*,
                                            options: {
                                                shorthandCompacting: false,
                                                roundingPrecision: -1
                                            }*/
                },
                ieCss: {
                    files: [{
                        expand: true,
                        cwd: '<%= config.tmp %>/styles',
                        src: ['*.ie.css'],
                        dest: '<%= config.dist %>/styles'
                    }],
                    options: {
                        shorthandCompacting: false,
                        roundingPrecision: -1
                    }
                },
                printCss: {
                    files: [{
                        expand: true,
                        cwd: '<%= config.tmp %>/styles',
                        src: ['*.print.css'],
                        dest: '<%= config.dist %>/styles',
                        ext: '.print.min.css'
                    }],
                    options: {
                        shorthandCompacting: false,
                        roundingPrecision: -1
                    }
                }

            },


            /*----------------------------------( CONCAT )----------------------------------*/
            /**
             *
             * concatinating various files : here concatination dom mungler output cache files
             * order of the src files impacts output
             *
             */

            concat: {
                postlogin: {
                    //order of the src files impacts output
                    src: ['<%= dom_munger.data.cssjs %>',
                        '<%= config.app %>/common/sfservices/*.js',
                        '<%= ngtemplates.main.dest %>', '<%= config.app %>/common/gtm/google.tagmanager.js'
                    ],
                    dest: 'temp/fcss.js'
                }
            },

            /*----------------------------------( NG Annotate )----------------------------------*/
            /**
             *
             * annotation is required to support dependency injection after minification and generate $inject code for dependency injection
             *
             */
            ngAnnotate: {
                postlogin: {
                    src: 'temp/fcss.js',
                    dest: 'temp/fcss.js'
                }
            },

            /*----------------------------------( NG Docs )----------------------------------*/
            /**
             *
             * NG Docs is used to create documentation of the code from its comments
             *
             */
            ngdocs: {
                options: {
                    dest: 'docs',
                    html5Mode: false,
                    startPage: '/api',
                    title: "CSS Just Pay",
                    image: "src/assets/style/images/backgrounds/logo-farmers1.png",
                    scripts: ['angular.js', "//ajax.googleapis.com/ajax/libs/angularjs/1.4.9/angular-route.min.js", '../vendor/jquery/jquery.js', '../temp/fcss.js'],
                    titleLink: "#/api",
                    bestMatch: true
                },
                all: [createFolderGlobs('*.js'), 'src/**/*.js']
            },

            /*----------------------------------( `ify )----------------------------------*/
            /**
             *
             * obfuscation of code for production
             *
             */
            uglify: {
                options: {
                    compress: {
                        drop_console: true
                    }
                },
                postlogin: {
                    src: 'temp/fcss.js',
                    dest: 'dist/scripts/fcss.min.js'
                },
                vendor: {
                    src: '<%= dom_munger.data.vendorjs %>',
                    dest: 'dist/scripts/vendor.min.js'
                },
                ievendor: {
                    src: ['vendor/html5shiv/dist/html5shiv.min.js', 'vendor/respond/dest/respond.min.js', 'vendor/json3/lib/json3.min.js', 'vendor/es5-shim/es5-shim.js'],
                    dest: 'dist/scripts/vendor.ie.min.js'
                }
            },

            /*----------------------------------( HTML MIN)----------------------------------*/
            /**
             *
             * Minifing HTML
             *
             */
            htmlmin: {
                main: {
                    options: {
                        collapseBooleanAttributes: true,
                        collapseWhitespace: true,

                        /*removeAttributeQuotes: true,
                         */
                        removeComments: true
                            /*,
removeEmptyAttributes: true,
    removeScriptTypeAttributes: true,
    removeStyleLinkTypeAttributes: true
*/
                    },
                    files: [{
                        'dist/index.html': 'dist/index.html'
                    }]
                }
            },


            /*----------------------------------( HTML MIN)----------------------------------*/
            /**
             *
             * Run some tasks in parallel to speed up the build process
             *
             */

            concurrent: {
                server: [
                    'compass:server'
                ],
                test: [
                    'compass'
                ],
                dist: [
                    'compass:dist'
                ]
            },
            //Imagemin has issues on Windows.
            //To enable imagemin:
            // - "npm install grunt-contrib-imagemin"
            // - Comment in this section
            // - Add the "imagemin" task after the "htmlmin" task in the build task alias
            //imagemin: {
            //  main:{
            //    files: [{
            //      expand: true, cwd:'dist/',
            //      src:['**/{*.png,*.jpg}'],
            //      dest: 'dist/'
            //    }]
            //  }
            //},

            /*----------------------------------( KARMA )----------------------------------*/
            /**
             *
             * Karma configurations.
             *
             */

            karma: {
                unit: {
                    configFile: 'config/karma.config.js',
                    singleRun: false
                }
            },

            /*----------------------------------( protractor )----------------------------------*/
            /**
             *
             * protractor configurations.
             *
             */
            protractor: {
                e2e: {
                    options: {
                        configFile: "test/protractor.conf.js", // Target-specific config file
                        args: {
                            // Arguments passed to the command
                        }
                    }
                }
            },
            instrument: {
                files: [
                    /*
                          'vendor/jquery/jquery.js',
                          'vendor/bootstrap-sass-official/assets/javascripts/bootstrap.js',
                          'vendor/angular/angular.js',
                          'vendor/angular-ui-router/release/angular-ui-router.js',
                          'vendor/angular-animate/angular-animate.js',
                          'vendor/angular-resource/angular-resource.js',
                          'vendor/angular-cookies/angular-cookies.js',
                          'vendor/angular-bootstrap/ui-bootstrap-tpls.js',
                          'vendor/angular-ui-utils/ui-utils.js',
                          'vendor/angular-sanitize/angular-sanitize.js',
                          'vendor/underscore/underscore.js',
                          'vendor/slick-carousel/slick/slick.js',
                          'vendor/angular-mocks/angular-mocks.js',
                          'vendor/bootstrap-sass-datepicker/js/bootstrap-sass-datepicker.js',
                      */
                    'src/common/common.module.js',
                    'src/common/constants/header.constant.js',
                    'src/common/constants/errorService.constant.js',
                    'src/common/constants/image.constant.js',
                    'src/common/constants/carousel.constant.js',
                    'src/fcss.module.js',
                    "src/fcss.module.prelogin.js",
                    'src/fcss.module.achpayment.js',
                    'src/fcss-states.js',
                    'src/fcss.site.js',

                    'src/common/factory/parsedata.js',
                    'src/common/factory/paymentMethodsDataFactory.js',
                    'src/common/factory/policyBillingFactory.js',
                    'src/common/factory/paymentMethodsDataFactory.js',
                    "src/common/factory/preloginfactory.js",
                    'src/common/services/service.js',
                    'src/common/services/retrieveaccountbilling.service.js',
                    'src/common/services/recentbillingactivity.js',
                    'src/common/services/billingpayment.service.js',
                    'src/common/services/billingsubmitpayment.service.js',
                    'src/common/constants/image.constant.js',
                    'src/common/filters/filter.js',
                    'src/common/constants/**/**/*.js',
                    'src/common/factory/**/**/*.js',
                    'src/common/filters/**/**/*.js',
                    'src/common/services/**/**/*.js',

                    'src/components/component.module.js',
                    'src/components/header/header.module.js',
                    'src/components/megamenu/navbar/navbar.directive.js',
                    'src/components/megamenu/dropdown/dropdown.directive.js',
                    'src/components/megamenu/menu/menu.directive.js',
                    'src/components/megamenu/submenu/submenu.directive.js',
                    'src/components/directives/component.js',
                    'src/components/directives/customagentdetails.js',
                    'src/components/directives/custommodalpopup.js',
                    'src/components/directives/customcarosuel.js',
                    'src/components/directives/customtile.js',
                    'src/components/directives/exportCSV.js',
                    'src/components/directives/custombutton.js',
                    'src/components/directives/customimage.js',
                    'src/components/directives/customnotification.js',
                    'src/components/directives/modalpopup.grid.directive.js',
                    'src/components/directives/cssInputTextBox.js',
                    'src/components/directives/textTruncate.js',
                    'src/components/directives/customdatepicker.js',
                    'src/components/directives/paperlessmodalpopup.directive.js',
                    'src/components/directives/**/**/*.js',

                    'src/modules/policy/policy.module.js',
                    'src/modules/policy/summary/policy.summary.controller.js',
                    'src/modules/policy/summary/policy.summary.factory.js',
                    'src/modules/policy/summary/policy.summary.directive.js',
                    'src/modules/policy/summary/policy.summary.service.js',

                    'src/modules/billing/billing.module.js',
                    'src/modules/billing/summary/billing.constant.js',
                    'src/modules/billing/summary/billing.summary.controller.js',

                    'src/modules/billing/summary/billing.summary.factory.js',
                    'src/modules/billing/summary/billing.account.directive.js',
                    'src/modules/billing/summary/billing.service.js',
                    'src/modules/billing/**/**/*.js',
                    'src/modules/policydetails/policydetails.module.js',
                    'src/modules/policydetails/policydetails.service.js',
                    'src/modules/policydetails/policydetails.directive.js',
                    'src/modules/policydetails/policydetails.filters.js',
                    'src/modules/policydetails/policydetails.controller.js',
                    'src/modules/policydetails/policydetails.constant.js',
                    'src/modules/policydetails/policydetailsnavigation/policydetails.navigation.js',

                    'src/modules/autopayments/auto.payments.module.js',
                    'src/modules/autopayments/auto.payments.constant.js',
                    'src/modules/autopayments/auto.payments.remove.directive.js',
                    'src/modules/autopayments/auto.payments.setup.directive.js',
                    'src/modules/autopayments/auto.payments.choose.directive.js',
                    'src/modules/autopayments/auto.payments.accounts.directive.js',
                    'src/modules/autopayments/auto.payments.controller.js',
                    'src/modules/autopayments/auto.payments.service.js',

                    'src/modules/paymenthistory/paymenthistory.module.js',
                    'src/modules/paymenthistory/paymenthistory.directive.js',
                    'src/modules/paymenthistory/paymenthistory.filters.js',

                    'src/modules/managepayments/manage.payments.module.js',
                    'src/modules/managepayments/manage.payments.controller.js',
                    'src/modules/managepayments/manage.payments.service.js',
                    'src/modules/managepayments/addedit.payments.directive.js',

                    'src/modules/paperless/paperless.module.js',
                    'src/modules/paperless/paperless.controller.js',
                    'src/modules/paperless/paperless.cacheFactory.js',
                    'src/modules/paperless/paperless.module.js',
                    'src/modules/paperless/paperless.thankyou.controller.js',

                    'src/modules/editprofile/editprofile.module.js',
                    'src/modules/editprofile/editprofile.service.js',
                    'src/modules/editprofile/editprofile.constant.js',
                    'src/modules/editprofile/editprofile.controller.js',
                    'src/modules/editprofile/editprofile.directive.js',

                    'src/modules/registration/registration.module.js',
                    'src/modules/registration/registration.service.js',
                    'src/modules/registration/registration.controller.js',
                    'src/modules/registration/register.controller.js',
                    'src/modules/registration/resetpassword.controller.js',

                    "src/modules/authentication/authentication.module.js",
                    "src/modules/authentication/authentication.controller.js",
                    "src/modules/authentication/authentication.tryagain.controller.js",
                    "src/modules/authentication/authentication.securityquestions.controller.js",
                    "src/modules/authentication/authentication.partialregistration.controller.js",
                    "src/modules/authentication/authentication.passwordreset.controller.js",
                    "src/modules/authentication/authentication.constant.js",
                    "src/modules/authentication/authentication.factory.js",
                    "src/modules/authentication/authentication.service.js",

                    'src/modules/partialenrollment/partialenrollment.module.js',
                    'src/modules/partialenrollment/partialenrollment.service.js',
                    'src/modules/partialenrollment/partialenrollment.controller.js',

                    'src/modules/contactus/contactus.module.js',
                    'src/modules/contactus/contactus.controller.js',

                    'src/modules/agentinfo/agentinfo.controller.js',
                    'src/modules/agentinfo/agentinfo.directive.js',
                    'src/modules/agentinfo/agentinfo.module.js',

                    'src/modules/policydetails/changerequest/addadriver.controller.js',
                    'src/modules/policydetails/changerequest/addressChange.controller.js',
                    'src/modules/policydetails/changerequest/coveragechange.controller.js',
                    'src/modules/policydetails/changerequest/floaterchange.controller.js',
                    'src/modules/policydetails/changerequest/general.controller.js',
                    'src/modules/policydetails/changerequest/mailingAddress.controller.js',
                    'src/modules/policydetails/changerequest/policydetails.cr.constant.js',
                    'src/modules/policydetails/changerequest/policydetails.cr.controller.js',
                    'src/modules/policydetails/changerequest/vehicleChange.controller.js',

                    'src/modules/policydocuments/policydocuments.controller.js',
                    'src/modules/policydocuments/policydocuments.module.js',
                    'src/modules/policydocuments/policydocuments.service.js',

                    'src/modules/claims/claims.controller.js',
                    'src/modules/claims/claims.module.js',
                    'src/modules/claims/claims.service.js',

                    'src/modules/billingstatements/billingstatements.controller.js',
                    'src/modules/billingstatements/billingstatements.module.js',
                    'src/modules/billingstatements/billingstatements.service.js'
                ],
                options: {
                    lazy: false,
                    basePath: 'app/'
                }
            },

            makeReport: {
                src: 'app/src/*.json',
                options: {
                    type: 'html',
                    dir: 'app/src/reports',
                    print: 'detail'
                        //        type: 'lcov',
                        //        dir: 'reports',
                        //        print: 'detail'
                }
            },


            protractor_coverage: {
                options: {
                    configFile: 'test/protractor.conf.js', // Default config file
                    keepAlive: true, // If false, the grunt process stops when the test fails.
                    noColor: false, // If true, protractor will not use colors in its output.
                    coverageDir: 'app/src/',
                    args: {}
                },
                phantom: {
                    options: {
                        args: {
                            baseUrl: 'http://localhost:3000/',
                            // Arguments passed to the command
                            'browser': 'phantomjs'
                        }
                    }
                },
                firefox: {
                    options: {
                        args: {
                            baseUrl: 'http://localhost:3000/',
                            // Arguments passed to the command
                            'browser': 'firefox'
                        }
                    }
                },
                chrome: {
                    options: {
                        args: {
                            baseUrl: 'http://localhost:3000/',
                            // Arguments passed to the command
                            'browser': 'chrome'
                        }
                    }
                },
            },
            /*----------------------------------( hooks )----------------------------------*/
            /**
             *
             * hook is used to check linting before commit in git
             *
             */
            githooks: {
                all: {
                    options: {
                        template: 'hooks/pre-commit.js'
                    },
                    'pre-commit': 'jshint test'
                }
            },

            pagespeed: {
                options: {
                    nokey: true,
                    locale: "en_GB",
                    threshold: 40
                },
                local: {
                    options: {
                        strategy: "desktop"
                    }
                },
                mobile: {
                    options: {
                        strategy: "mobile"
                    }
                }
            },
            cmq: {
                options: {
                    log: true
                },
                /*your_target: {
                    files: {
                        'temp': ['temp/fcss.css']
                    }
                },*/
                dynamic: {
                    expand: true,
                    cwd: 'temp/styles/',
                    src: ['fcss.css'],
                    dest: 'temp/styles/'
                }
            }
        });

        /*----------------------------------( TASKs )----------------------------------*/
        /**
         *
         * To be updated
         *
         */
        grunt.loadNpmTasks('grunt-pagespeed');
        // Register customer task for ngrok
        grunt.registerTask('psi-ngrok', 'Run pagespeed with ngrok', function() {
            var done = this.async();
            var port = 3000;

            ngrok.connect(port, function(err, url) {
                if (err !== null) {
                    grunt.fail.fatal(err);
                    return done();
                }
                grunt.config.set('pagespeed.options.url', url);
                grunt.task.run('pagespeed');
                done();
            });
        });

        grunt.registerTask('run', 'Compile then start a connect web server', function(target) {
            if (target === 'dist') {
                return grunt.task.run(['build', 'connect:dist']);
            }

            grunt.task.run(['dev']);
        });
        grunt.registerTask('build', [
            'clean:before',
            'concurrent:dist',
            'dom_munger',
            'ngtemplates',
            'cssmin',
            'copy:dist',
            'concat',
            'ngAnnotate',
            'uglify',
            'htmlmin'
            /*,
                  'clean:after'*/
        ]);
        grunt.registerTask('docs', [
            'clean:before',
            'dom_munger',
            'ngtemplates',
            'concat',
            'ngdocs',
            'connect:doc'
        ]);
        grunt.registerTask('dev', [
            'clean:server',
            'jshint:all',
            'dom_munger',
            'concurrent:server',
            'connect:livereload',
            'cmq',
            'ngdocs',
            'watch'
        ]);

        grunt.registerTask('test', [
            'clean:server',
            'concurrent:test',
            // 'connect:test',
            'karma'
        ]);
        grunt.registerTask('perf', [
            'psi-ngrok'
        ]);

        grunt.registerTask('e2e', ['dom_munger:read', 'protractor']);
        grunt.registerTask('default', [
            'jshint',
            'test',
            'build'
        ]);

        grunt.registerTask('e2ecoverage', [
            'clean:coverageE2E',
            'copy:coverageE2E',
            'instrument',
            'connect:coverageE2E',
            'protractor_coverage:chrome',
            'makeReport'
        ]);

        grunt.registerTask('e2efirefox', [
            'clean:coverageE2E',
            'copy:coverageE2E',
            'instrument',
            'connect:coverageE2E',
            'protractor_coverage:firefox',
            'makeReport'
        ]);

        grunt.registerTask('e2ephantomjs', [
            'clean:coverageE2E',
            'copy:coverageE2E',
            'instrument',
            'connect:coverageE2E',
            'protractor_coverage:phantom',
            'makeReport'
        ]);
    };

    //Using exclusion patterns slows down Grunt significantly
    //instead of creating a set of patterns like '**/*.js' and '!**/node_modules/**'
    //this method is used to create a set of inclusive patterns for all subdirectories
    //skipping node_modules, vendor, dist, and any .dirs
    //This enables users to create any directory structure they desire.
    var createFolderGlobs = function(fileTypePatterns) {
        fileTypePatterns = Array.isArray(fileTypePatterns) ? fileTypePatterns : [fileTypePatterns];
        var ignore = ['node_modules', 'vendor', 'dist', 'temp', 'hooks', 'docs', 'coverage', 'app'];
        var fs = require('fs');
        return fs.readdirSync(process.cwd())
            .map(function(file) {
                if (ignore.indexOf(file) !== -1 ||
                    file.indexOf('.') === 0 ||
                    !fs.lstatSync(file).isDirectory()) {
                    return null;
                } else {
                    return fileTypePatterns.map(function(pattern) {
                        return file + '/**/' + pattern;
                    });
                }
            }).filter(function(patterns) {
                return patterns;
            }).concat(fileTypePatterns);
    };
})();
