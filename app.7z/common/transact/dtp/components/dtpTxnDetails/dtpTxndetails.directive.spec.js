'use strict';
describe('Directive: dtpDividendForm', function() {
	var compile,scope,$rootScope,directiveElement,isolatedScope,$window,transactModel,$filter;

	var existingFundSelectedObject = {
        "accNo": "0060007818365",
        "amount": "800",
        "direct": null,
        "dividendFlag": "R",
        "endDate": "4 aug 2020",
        "frequency": "monthly",
        "fundCategory": "EQUITY",
        "fundOptDesc": "Franklin India BLUECHIP FUND",
        "fundOption": "006",
        "fundType": "E",
        "minAddPurAmt": "1000",
        "minNewPurAmt": "5000",
        "minSipAmt": "1",
        "multiples": "1",
        "nfoFlag": "N",
        "payoutFlag": "N",
        "reinvestmentFlag": "N",
        "startDate": "12 apr 2014",
        "stepUpType": "",
        "nextInstlDate": "5 sep 2016",
        "nextAnnualDate": "12 apr 2017",
        "stepUpValue": "NA",
        "leadDays": "15",
        "paymentDet":{
        	"payModeEmand": "false",
	        "eMandateType":"",
	        "eMandateVal": "",
	        "eMandateExpiryDate": "" 
		}		       
	};

	var dtpObjectWithReInvestmentDividendType = {
		"destinationFund" : existingFundSelectedObject,
        "switchType" : "Re-Investment",
        "type": ""
	};

    var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': 520965.095916
        }]
    };

     var selectedFundObject = {
        "tschvalScheme": "006",
        "fmDescription": "Franklin India Bluechip Fund - Dividend",
        "fundCategory": "EQUITY",
        "fundType": "EQUITY",
        "tschvalAccno": "0069901064910",
        "balUnits": "2463.841",
        "marketValue": "349183.18",
        "tschvalFsFlag": "N",
        "investmentGoal": "",
        "dividendOption" : "Re-Investment"
    };

    var investorDetails =  {
        "custName": "Shankar Narayanan",                    
        "pan": "ABCD1234KL",
        "aadhar" : 123456789123,
        "folioId": 3456572,
        "holdingType": "Joint",
        "mobile": 9039758625,
        "emailId": "shankarnarayanan@gmail.com",
        "city":"P O BOX 170 170",
        "kycStatus":true,
        "holders": [
            {
            "name": "Shankar Narayanan",
            "type": "Firstholder",
            "kycregistered" : true,
            "pan": "ABCD1234KL",
            "aadhar" : 123456789123
            }, {
            "name": "JHON SMITH GOERGE",
            "type": "Secondholder",
            "kycregistered" : true,
            "pan": "ABCD1234KA",
            "aadhar" : 123456789120
            }, {
            "name": "KRISTIANA GOERGE",
            "type": "Thirdholder",
            "kycregistered" : true,
            "pan": "ABCD1234KB",
            "aadhar" : 123456789121
            }
        ]
    };

    var dtpModelObject = {
        "investorDetails" : investorDetails,
        "fundDetails" : selectedFundObject,
        "switchDetails" : dtpObjectWithReInvestmentDividendType
    };

	beforeEach(angular.mock.module('advisor'));	
	beforeEach(angular.mock.module('investor.transact'));

	var getCompiledElement = function(){
		var element = angular.element('<ftic-dtp-txn-details></ftic-dtp-txn-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function(_$rootScope_,_$compile_,$window,_transactModel_,_$filter_) {            
            compile = _$compile_;
            scope = _$rootScope_.$new();    

            $window = $window;
            $window.ga = function() {};

            $filter = _$filter_;
        	transactModel = _transactModel_;
        	transactModel.setTransactDetails(dtpModelObject); 
            transactModel.setTransactConfirm({
                'accountNo': '0010008062712',                     
                'transactionRefNo': 'SWI001166',
                'transDateTime':'Fri Dec 30 2016 22:44:13 GMT+0530 (India Standard Time)'
            });

        	directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();    
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variable keyValuePair on load of directive',function(){
    	expect(isolatedScope.keyValuePair[0].text).toBe("Folio No.");    	
    	expect(isolatedScope.keyValuePair[1].text).toBe("Source Fund");       
    	expect(isolatedScope.keyValuePair[2].text).toBe("Account Number");
        expect(isolatedScope.keyValuePair[3].text).toBe("Transaction Reference No");
        expect(isolatedScope.keyValuePair[4].text).toBe("Request Date and Time");       
        expect(isolatedScope.keyValuePair[5].text).toBe("Destination Fund");
        expect(isolatedScope.keyValuePair[6].text).toBe("Dividend Option");

        expect(isolatedScope.keyValuePair[0].value).toBe(3456572);       
        expect(isolatedScope.keyValuePair[1].value).toBe("Franklin India Bluechip Fund - Dividend");
        expect(isolatedScope.keyValuePair[2].value).toBe("0069901064910");
        expect(isolatedScope.keyValuePair[3].value).toBe("SWI001166");       
        expect(isolatedScope.keyValuePair[4].value).toBe($filter('date')(transactModel.getTransactConfirm().transDateTime),"dd MMMM yyyy, hh:mm a");
        expect(isolatedScope.keyValuePair[5].value).toBe(undefined);
        expect(isolatedScope.keyValuePair[6].value).toBe("Re-Investment");
    });    
});	