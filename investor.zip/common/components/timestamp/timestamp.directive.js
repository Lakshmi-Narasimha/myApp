'use strict';

var timestamp = function() {
	return {
            template: require('./timestamp.html'),
            restrict: 'E',
            replace: true,
            scope: {
              lable: "=lable",
              date: "=date",
              time: "=time"
            },
            controller: function($scope, $element, $attrs){                
            },
            link: function(scope, iElement, iAttrs, controller){
                // scope.formatDate = function(date) {
                //     var monthNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
                //       "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"
                //     ];
                //   var hours = date.getHours();
                //   var minutes = date.getMinutes();
                //   var seconds = date.getSeconds();
                //   var ampm = hours >= 12 ? 'PM' : 'AM';
                //   hours = hours % 12;
                //   hours = hours ? hours : 12; // the hour '0' should be '12'
                //   minutes = minutes < 10 ? '0'+minutes : minutes;
                //   var strTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
                //   return date.getDate() + " " +  monthNames[date.getMonth()] + " " + date.getFullYear() + "  |  " + strTime;
                // }
               
                // scope.date_Time = scope.formatDate(new Date());
            }
        };
};

timestamp.$inject = [];
module.exports = timestamp;