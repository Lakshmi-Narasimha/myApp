define([
    'jquery',
    'lodash',
    'bootstrap-dialog',
    'app/application/router',
    'app/common/shadowLayer',
    'app/common/views/AbstractView',
    'app/application/app',
    'text!app/application/templates/Header.html'
], function ($, _, BootstrapDialog, Router, shadow, AbstractView, app, HeaderTemplate) {

    return AbstractView.extend({
        el: '#sem-header',
        template: _.template(HeaderTemplate),
        events: {
            'click #cs-obo-list li': 'oboChanged',
            'click #redirectToHomePage': 'redirectToHomePage',
            'click #logOut': 'logoutModal'
        },
        oboChanged: function (event) {
            const oboId = $(event.currentTarget).attr('id');
            this.selObo = _.filter(app.oboAdvisorList, (advisor) => {
                return advisor.get('formattedFmid') === oboId;
            })[0];
            

            if (window.location.href.indexOf("clientView") > -1) {
                this.showErrorDialogMsg();
            } else {
                app.oboChanged = true;
                this.selObo = this.selObo ? this.selObo.toJSON() : null;
                app.userInformation = this.selObo || app.userInformation;
                this.$('#clsel-obo-name').text(app.userInformation.fullName);
                Backbone.publishSubscribeEvents.trigger('oboChanged');
                
            }
        },
        render: function () {
            const data = {
                userName: app.userInformation.fullName,
                oboUserList: app.oboAdvisorList || []
            }
            this.$el.html(this.template(data));

            $("#cs-obo-dropdown").on("hide.bs.dropdown", function () {
                shadow.hide({
                    parentElement: '#sem-app-primary-view',
                    zIndex: 1
                });
            });

            $("#cs-obo-dropdown").on("show.bs.dropdown", function (event) {
                shadow.show({
                    parentElement: '#sem-app-primary-view',
                    zIndex: 2
                });
            });
        },
        redirectToHomePage: function () {
            Router.routeTo('clientSearchView');
        },
        showErrorDialogMsg: function () {
            var self = this;
            BootstrapDialog.show({
                size: 'small',
                title: '<h4 class="modal-title">OBO disabled</h4>',
                closeByBackdrop: true,
                message: 'If you need to switch to another advisor return to Client search.',
                buttons: [
                    {
                        label: 'Cancel',
                        cssClass: 'btn btn-default',
                        action: function (dialog) {
                            dialog.close();
                        }
                    },
                    {
                        label: 'Continue client search',
                        cssClass: 'btn btn-primary',
                        action: function (dialog) {
                            self.selObo = self.selObo ? self.selObo.toJSON() : null;
                            app.userInformation = self.selObo || app.userInformation;
                            $('#clsel-obo-name').text(app.userInformation.fullName);
                            app.selClientId = null;
                            Backbone.history.navigate('clientSearchView', true);
                            Router.routeTo('clientSearchView');
                            dialog.close();
                        }
                    }
                ],
                onshown: this.modalDialogShown,
                onhidden: this.modalDialogHidden
            });
        },
        logoutModal: function () {

            BootstrapDialog.show({
                size: 'small',
                title: '<h4 class="modal-title preventBkspacePopup">Log out confirmation</h4>',
                closeByBackdrop: true,
                message: 'This will close your AdvisorCompass site window and may close other unsaved work you have in progress in Client Viewer, eForms - New Business or other tools.<br /><br />Click Cancel to go back and save your work or click OK to log out.<br /><br />To securely log out of all tools, close any remaining browser windows. Search "logout" on the AdvisorCompass site for more information.',
                buttons: [
            {
                label: 'Cancel',
                cssClass: 'btn btn-default form-control logout-btns',
                action: function (dialog) {
                    dialog.close();
                }
            },
            {
                label: 'OK',
                cssClass: 'btn btn-primary form-control logout-btns',
                action: function (dialog) {
                    dialog.close();
                    window.location.href = '/logout.html';
                }
            }
                ],
                onshow: function (reference) {
                    reference.getModalFooter().find('.bootstrap-dialog-footer-buttons').addClass('row').find('.logout-btns').wrap("<div class='col-xs-6 col-sm-6 col-md-6 col-lg-6'></div>");
                },
                onshown: this.modalDialogShown,
                onhidden: this.modalDialogHidden
            });
        }
    });

});
