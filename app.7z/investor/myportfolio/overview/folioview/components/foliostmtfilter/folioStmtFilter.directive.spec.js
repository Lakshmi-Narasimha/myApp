'use strict';

describe('Directive: Folio detail grid', function() {

    var rootScope, compile, scope, directiveEle, isolatedScope, timeout, $window, $filter, invFolioDetailsModel, dateFilter;
  var folioAccountData = {
    'accountDetails': {
            'panNo': 'CMLQR5320A',
            'panFolioAccounts': [{
                'folioId': '17877097',
                'latestFolio': 'N',
                'folioAccounts': [
                    '1349904865101',
                    '2389904865101',
                    '4379904865101'
                ]
            }, {
                'folioId': '27877097',
                'latestFolio': 'N',
                'folioAccounts': [
                    '1134990486511',
                    '11389904865101',
                    '11379904865101'
                ]
            }, {
                'folioId': '13592223',
                'latestFolio': 'N',
                'folioAccounts': [
                    '1549900759695'
                ]
            }, {
                'folioId': '13461754',
                'latestFolio': 'N',
                'folioAccounts': [
                    '0069900759695'
                ]
            }, {
                'folioId': '12413948',
                'latestFolio': 'N',
                'folioAccounts': [
                    '0019900759695'
                ]
            }, {
                'folioId': '13027781',
                'latestFolio': 'N',
                'folioAccounts': [
                    '0539900759695'
                ]
            }, {
                'folioId': '14503662',
                'latestFolio': 'Y',
                'folioAccounts': [
                    '0119900830298',
                    '0119901265437',
                    '0349900830474',
                    '0359900830474',
                    '0359901264215'
                ]
            }]
        }
    };
  var getCompiledElement = function() {
        var element = angular.element('<ftic-folio-stmt-filter></ftic-folio-stmt-filter>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.inject(function(_$filter_) {            
            $filter = _$filter_;
            var fromDate = $filter('date')(new Date(), 'dd/MM/yyyy');
            var toDate = $filter('date')(new Date(), 'dd/MM/yyyy');

            dateFilter = { 
                        folioPanAccNo: '14503662', 
                        dayFlag: 'AD', 
                        fromDate: fromDate, 
                        toDate: toDate 
                };
        });
    });
    beforeEach(function() {
        angular.mock.inject(function(_$rootScope_, _$compile_, _$timeout_, _$window_, _invFolioDetailsModel_) {            
            rootScope = _$rootScope_;
            scope = rootScope.$new();
            compile = _$compile_;
            timeout = _$timeout_;
            $window = _$window_;
            $window.ga = function() {};
            invFolioDetailsModel = _invFolioDetailsModel_;
        });

        invFolioDetailsModel.setFolioAccountData({
            'panFolioAccounts': folioAccountData.accountDetails.panFolioAccounts
        })

        directiveEle = getCompiledElement();
        isolatedScope = directiveEle.isolateScope();
        spyOn(scope, '$broadcast');
    });

    it('should be defined', function() {
        expect(directiveEle).toBeDefined();
    });

    it('should create separate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
        console.log(isolatedScope);
    });

    it('should have defined sectionOptions from isolated scope', function() {
        expect(isolatedScope.sectionOptions).toBeDefined();
        expect(isolatedScope.sectionOptions[0].folioNumber).toBe('17877097');
        expect(isolatedScope.sectionOptions[0].title).toBe('Folio No. 17877097');
    });

    it('should have defined selecteFolio from isolated scope', function() {
        expect(isolatedScope.selecteFolio).toBeDefined();
        expect(isolatedScope.selecteFolio.folioNumber).toBe('14503662');
        expect(isolatedScope.selecteFolio.title).toBe('Folio No. 14503662');
    });

    it('should have defined allowValidation from isolated scope', function() {
        expect(isolatedScope.allowValidation).toBeTruthy();
    });

    it('should have defined dateOptions from isolated scope', function() {
        expect(isolatedScope.dateOptions).toBeDefined();
        expect(isolatedScope.dateOptions[0].key).toBe('AD');
        expect(isolatedScope.dateOptions[0].label).toBe('As on Date');
        expect(isolatedScope.dateOptions[0].type).toBe('fulldate');
    });

    it('should have defined selectedObj from isolated scope', function() {
        expect(isolatedScope.selectedObj).toBeDefined();
        expect(isolatedScope.selectedObj.key).toBe('AD');
        expect(isolatedScope.selectedObj.label).toBe('As on Date');
        expect(isolatedScope.selectedObj.type).toBe('fulldate');
    });

    it('should populate error messages', function() {
        expect(isolatedScope.dateRangeErrorMsgs).toBeDefined();
        expect(isolatedScope.dateRangeErrorMsgs[0].expression).toBe('required');
        expect(isolatedScope.dateRangeErrorMsgs[0].description).toBe('The From Date or To Date is empty. Please try again.');
        expect(isolatedScope.dateRangeErrorMsgs[1].expression).toBe('date');
        expect(isolatedScope.dateRangeErrorMsgs[1].description).toBe('The As on Date is invalid. Please try again');
    });

    it('should have called emitApply from selectedValue', function() {
        var data = isolatedScope.selectedObj.key;
        spyOn(isolatedScope, 'emitApply').and.callThrough();
        scope.$broadcast('selectedValue', event, data);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedValue', event, data);   
        expect(isolatedScope.initFlag).toBeTruthy();
        timeout.flush();
        expect(isolatedScope.emitApply).toHaveBeenCalled();
    });

    it('should call selectedOption', function() {
        var data = isolatedScope.selecteFolio.folioNumber;
        scope.$broadcast('selectedOption', event, data);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedOption', event, data);  
    });

    it('should call getdaterange', function() {
        var date1 = dateFilter.fromDate;
        var date2 = dateFilter.toDate;
        scope.$broadcast('getdaterange', event, date1, date2);
        expect(scope.$broadcast).toHaveBeenCalledWith('getdaterange', event, date1, date2); 
    });

    it('should call getcurrentdate', function() {
        var date = dateFilter.fromDate;
        scope.$broadcast('getcurrentdate', event, date);
        expect(scope.$broadcast).toHaveBeenCalledWith('getcurrentdate', event, date); 
    });

    it('case-1 when dayFlag is AD on call of fticcmpFilterEvent', function() {
        var inputVal = dateFilter.fromDate;
        var inputType = '';
        scope.$broadcast('fticcmpFilterEvent', event, inputVal, inputType);
        expect(scope.$broadcast).toHaveBeenCalledWith('fticcmpFilterEvent', event, inputVal, inputType);
    });

    it('case-2 when dayFlag is DR on call of fticcmpFilterEvent', function() {
        var inputVal = dateFilter.fromDate;
        var inputType = 'dtr1';
        scope.$broadcast('fticcmpFilterEvent', event, inputVal, inputType);
        expect(scope.$broadcast).toHaveBeenCalledWith('fticcmpFilterEvent', event, inputVal, inputType);
        inputVal = dateFilter.toDate;
        inputType = 'dtr2';
        scope.$broadcast('fticcmpFilterEvent', event, inputVal, inputType);
        expect(scope.$broadcast).toHaveBeenCalledWith('fticcmpFilterEvent', event, inputVal, inputType);
    });

    it('should emit apply event', function() {   
        spyOn(isolatedScope, 'emitApply').and.callThrough();
        spyOn(isolatedScope, '$emit');
        isolatedScope.emitApply();
        expect(isolatedScope.emitApply).toHaveBeenCalled();
        expect(isolatedScope.$emit).toHaveBeenCalledWith('apply', dateFilter);
    });
});
