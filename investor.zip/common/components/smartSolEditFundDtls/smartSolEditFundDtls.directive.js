/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolEditFundDtls = function($state,buildPlanModelService,buildPlanInitialLoader,eventConstants) {
	return {
          template: require('./smartSolEditFundDtls.html'),
           restrict: 'E',
           replace: true,
           scope: {
                fundsData: "="
            },
            controller: function($scope, $element, $attrs){
              
              $scope.fundSelectionArr =[];
              for(var i=0; i<$scope.fundsData.length; i++)
              {
                $scope.fundSelectionArr[i]= $scope.fundsData[i].fundName;
              }
              //$scope.fundSelectionArr = ["Franklin Templeton Asian Equity Fund","Franklin India Corporate Bond Fund"];
              $scope.fundSelectionStyle = {
                          "border" : "1px solid grey",
                          "background-color" : "white",
                          "padding" : "10px 30px"
              };

              // TODO - Move this event to individual component
               $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event) {
                  console.log($event);
                   $scope.$emit("editFundBackState");
                  // $state.go("smartsolutions.planSmartSolution.recommendations.buildplan");
                 // $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan")
               
               });
             },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

smartSolEditFundDtls.$inject = ['$state','buildPlanModelService','buildPlanInitialLoader','eventConstants'];
module.exports = smartSolEditFundDtls;