'use strict';
describe('Controller: ReviewDTPCtrl', function() {
	var $controller,$scope,ReviewDTPCtrl,reviewDtpDetailsModel,eventConstants;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_reviewDtpDetailsModel_,_eventConstants_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();		
		
		eventConstants = _eventConstants_;
		reviewDtpDetailsModel = _reviewDtpDetailsModel_;		
		$scope.config = {};					
		loadController();			
	}));	

	function loadController(){
        ReviewDTPCtrl = $controller('ReviewDTPCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(ReviewDTPCtrl).toBeDefined();
    });

    it('should define the variables toTxnDetailsState,toState',function(){    	
    	expect($scope.config.toTxnDetailsState).toBe('invTransact.txnDetails');
    	expect($scope.config.toState).toBe("invTransact.base.dtp");    	
    });

    it('should listen the event eventConstants.ACTION_ICON_CLICKED when triggered',function(){
    	spyOn($scope,"$emit");
    	$scope.$broadcast(eventConstants.ACTION_ICON_CLICKED);
    	expect(reviewDtpDetailsModel.isSwitchEdited).toBe(true);    	
    	expect($scope.$emit).toHaveBeenCalledWith("NAVIGATE_TO_TRANSACT", {key: 'dtp'});
    });
});