/**
 * @ngdoc property
 * @name fticSipCalculatorForm Directive
 * @description
 *
 * fticSipCalculatorForm directive 
 *
 **/
 'use strict';

 var fticTaxCalculatorForm = function($state,$timeout,eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, taxCalculatorInitialService, taxCalculatorModel, calculatorsEventConstants) {
   return {
    template: require('./taxCalculatorsForm.html'),
    restrict: 'E',
    replace: true,
    scope:{
        inputObject:'=',
        selectOptions:'=',
        userInput:'=',
    },
    controller: function($scope, $element, $attrs){
        $scope.init = function() {
          
           $scope.calculatorReq={};
           $scope.fundName = [];
            $scope.formInvalid = true;
           $scope.$on('selectedFund', function(event, data){                    
            $scope.fundName.title = data.title;
            $scope.fundName.code = data.category;
        });


        $scope.onSubmit = function() {
            $scope.$emit(calculatorsEventConstants.RESET_DATA);
          if($scope.userInput.Amount.value < 500 || $scope.userInput.Amount.value > 999999999 || $scope.userInput.Tenure.value > 40 || $scope.userInput.Tenure.value < 1) {
                        return;
                    }
        else {
            $scope.calculatorReq = [{"investmentTenure" : $scope.userInput.Tenure.value,
            "investmentAmount" : $scope.userInput.Amount.value,
            "fundName" : $scope.fundName.code
            }];
               // $scope.calculatorReq.annualizedReturn= $scope.userInput.Annual.value;            
            $scope.$emit(calculatorsEventConstants.TAX_CALCULATE, $scope.calculatorReq);
        }
       };

       $scope.resetForm = function () {
        $scope.$emit(calculatorsEventConstants.RESET_DATA);
        $timeout(function () {
            $scope.calculatorReq = {};
            $scope.fundName.code = "";
            $scope.userInput.Tenure.value = "";
            $scope.userInput.Amount.value = "";
        }, 0)
    }         

};
$scope.init();
$scope.formInvalid = true;
},
link: function(scope, element, attrs, ctrl){
}
}
};

fticTaxCalculatorForm.$inject = ['$state','$timeout','eventConstants','fticLoggerMessage', 'loggerConstants', '$cookies','authenticationService','taxCalculatorInitialService','taxCalculatorModel', 'calculatorsEventConstants'];
module.exports = fticTaxCalculatorForm;