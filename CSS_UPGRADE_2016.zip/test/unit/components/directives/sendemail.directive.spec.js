'use strict';

/*Unit test case for send Email directive*/

    describe('directive: send Email', function() {

    var scope, compile, validHTML, timeout, $scope, $broadcast, data, rootScope, sendEmailVM;

    var paymentSuccessfullData = {
                    "accountStatus": "Active",
                    "agentOfRecord": "13053T",
                    "allowPayment": true,
                    "amountPayingNow": "23000.00",
                    "billingAccountNumber": "T718142962",
                    "billingScheduledMaintenance": "N",
                    "billingview": "confirm",
                    "city": "Princeton",
                    "confirmationNumber": "16589320",
                    "payingDateNow": "01/01/2016",
                    "paymentListNow": {
                        "cardDisplayType": null,
                        "creditCardCategoryDisplay": "Amex",
                        "digitsCardNum": "6171",
                        "isCard": true
                    }
        
                };

    validHTML = '<send-email-copy></send-email-copy>';

    beforeEach(module('CSS.billing'));
    beforeEach(module('CSS.common'));
    beforeEach(module('component.tile'));
    beforeEach(module('templates'));
    beforeEach(function() {
        module(function($provide) {
            $provide.constant('componentConstant', {
                'policy_status_constants': {
                    'active': 'A',
                    'cancelled': 'C',
                    'expired': 'E'
                }
            });
        });
    });
    beforeEach(inject(function($compile, $rootScope, $timeout) {
        rootScope = $rootScope;
        scope = $rootScope.$new();
        compile = $compile;
        timeout = $timeout;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();

        return compiledElem;
    }

   

    describe('when changing the scope values', function() {

        beforeEach(function() {    
            scope.paymentSuccessfullData =  paymentSuccessfullData;
            validHTML = '<send-email-copy payment-data="paymentSuccessfullData"></send-email-copy>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
           
        });
    });

    // TO DO

    describe('submit-email function to be defined', function() {

        // data = {
        //     "transactionCode": null,
        //     "transactionDescription": "Success",
        //     "transactionStatus": "S",
        //     "uiErrorDisplayMessage": null
        // }

        it('should call the submit-email event', function() {

            var el = create();
            var isolate = el.isolateScope();

             scope.$broadcast('submit-email', "transactionStatus");
        });
    });


    describe('submit-email function to be defined', function() {

        it('should define the submit function', function() {

            var el = create();
            var isolate = el.isolateScope();

            el.find(".btn-farmers-blue").trigger('click');
        });

        it('should define the submit function', function() {

            var el = create();
            var isolate = el.isolateScope();

            el.find(".form-control").val("abc@gmail.com");
            el.find(".btn-farmers-blue").trigger('click');

        });

        // TO DO above suite
    });
    describe('CloseModal function to be defined', function() {

        it('should define the CloseModal function', function() {

            var el = create();
            var isolate = el.isolateScope();

            el.find(".fa-close").trigger('click');
        });

    }); 
});
