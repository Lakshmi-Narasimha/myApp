define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailonefeaturesview.html'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetBrokerageOneFeatures(this.accountSummary.accountId)
                .then(function(oneFeaturesData) {
                    var unmaskedAccountNumber = self.formatProperty(oneFeaturesData.DDAacctId, function(acctNumber) {
                        return acctNumber;
                    });
                    self.renderSection(SectionTemplateHtml, {oneFeaturesData: oneFeaturesData, unmaskedAccountNumber: unmaskedAccountNumber});
                })
                .fail(this.handleServiceError);
        }
    });

    return SectionView;
});

