'use strict';

function myPortfolioRoutes($stateProvider, myportfolioConstants) {

    var overview = {
        parent: 'home',
        name: 'overview',
        url: 'myportfolio/overview',
        views: {
            'dashboard@home': {
                controller: 'OverviewController',
                template: require('./overview/overview.html')
            }
        }
    };

    var overviewPanView = {
        parent: 'overview',
        name: 'overview.panview',
        url: '/panview',
        views: {
            'overview': {
                template: require('./overview/panview/panview.html'),
                controller: 'PanViewController'
            }
        },
        data:{
            viewFlag: myportfolioConstants.flagOptions.PAN_FLAG
        }
    };

    var overviewFolioView = {
        parent: 'overview',
        name: 'overview.folioview',
        url: '/folioview',
        params: {
            'folioNumber': null
        },
        views: {
            'overview': {
                template: require('./overview/folioview/folioview.html'),
                controller: 'FolioViewController'
            }
        },
        data:{
            viewFlag: myportfolioConstants.flagOptions.FOLIO_FLAG
        }
    };

    var overviewAccView = {
        parent: 'overview',
        name: 'overview.accview',
        params: {
            'accontNumber': null,
            'folioNumber': null
        },
        url: '/accview',
        views: {
            'overview': {
                template: require('./overview/accview/accountView.html'),
                controller: 'accountViewController'
            }
        },
        data:{
            viewFlag: myportfolioConstants.flagOptions.ACCOUNT_FLAG
        }
    };

    var capitalgains = {
        parent: 'home',
        name: 'capitalgains',
        url: 'myportfolio/capitalgains',
        views: {
            'dashboard@home': {
                controller: 'CapitalGainsController',
                template: require('./capitalgains/capitalgains.html')
            }
        }
    };

    var capitalgainsFolioView = {
        parent: 'capitalgains',
        name: 'capitalgains.folioview',
        url: '/folioview',
        params: {
            'folioNumber': null
        },
        views: {
            'capitalgains': {
                template: require('./capitalgains/folioview/folioView.html'),
                controller: 'CGFolioViewCtrl'
            }
        },
        data:{
            viewFlag: myportfolioConstants.flagOptions.FOLIO_FLAG
        }
    };
    
    var capitalgainsAccountView = {
        parent: 'capitalgains',
        name: 'capitalgains.accountview',
        url: '/accountview',
        params: {
            'accontNumber': null,
            'folioNumber': null
        },
        views: {
            'capitalgains': {
                template: require('./capitalgains/accountview/accountView.html'),
                controller: 'CGAccountViewCtrl'
            }
        },
        data:{
            viewFlag: myportfolioConstants.flagOptions.ACCOUNT_FLAG
        }
    };

    var familyPortfolio = {
        parent: 'home',
        name: 'familyportfolio',
        url: 'myportfolio/familyportfolio',
        views: {
            'dashboard@home': {
                controller: 'FamilyPortfolioController',
                template: require('./familyportfolio/familyportfolio.html')
            }
        }
    };

    var casStatement = {
        parent: 'home',
        name: 'cas',
        url: 'myportfolio/cas',
        views: {
            'dashboard@home': {
                controller: 'CASController',
                template: require('./casstatement/casStatement.html')
            }
        }
    };

    $stateProvider
        .state(overview)
        .state(overviewPanView)
        .state(overviewFolioView)
        .state(overviewAccView)
        .state(capitalgains)
        .state(capitalgainsFolioView)
        .state(capitalgainsAccountView)
        .state(familyPortfolio)
        .state(casStatement)
        ;

}

myPortfolioRoutes.$inject = ['$stateProvider', 'myportfolioConstants'];
module.exports = myPortfolioRoutes;
