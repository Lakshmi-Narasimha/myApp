'use strict';

/*Unit test case for custom button*/

    describe('directive: custom carousel', function() {

    var scope, compile, validHTML, timeout;

    validHTML = '<carousel-customize></carousel-customize>';

    beforeEach(module('component.customcarousel'));
    beforeEach(module('CSS.billing'));
    beforeEach(module('CSS.common'));
    beforeEach(module('component.tile'));
    beforeEach(module('templates'));
    beforeEach(function() {
        module(function($provide) {
            $provide.constant('componentConstant', {
                'policy_status_constants': {
                    'active': 'A',
                    'cancelled': 'C',
                    'expired': 'E'
                }
            });
        });
    });
    beforeEach(inject(function($compile, $rootScope, $timeout) {
        scope = $rootScope.$new();
        compile = $compile;
        timeout = $timeout;
    }));

    function create() {
        var elem, compiledElem;/**/
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();

        return compiledElem;
    }

   

    describe('when changing the scope values', function() {

        beforeEach(function() {
            scope.carousellist = [1,2,3,4];           
            validHTML = '<carousel-customize carousellist=carousellist carouseltype="tilecarousel" detailtype="vehicledetails" visibleitems=3 idname="expandPolicyCarousel" navigationbars=false> </carousel-customize>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
            expect(isolate.carousellists.length).toEqual(scope.carousellist.length);
            isolate.initializeSlick();

           
        });
    });
    describe('when changing the scope values', function() {

        beforeEach(function() {
            scope.carousellist = ['a1','a2','a3','a4'];           
            validHTML = '<carousel-customize carousellist=carousellist carouseltype="tilecarousel" detailtype="policydetailtype" visibleitems=3 idname="expandPolicyCarousel" navigationbars=false> </carousel-customize>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
            expect(isolate.carousellists.length).toEqual(scope.carousellist.length);
            // isolate.clickEventSlick(); 
            angular.element(".policy-detail-head-carousel .slick-slide").trigger('click')
            isolate.unInitializeSlick();
            timeout.flush();
            angular.element(window).trigger('resize');
            isolate.checkIntializeSlick(); 
           
        });
    });
    
    describe('when changing the scope values', function() {

        beforeEach(function() {
            scope.carousellist = ['a1','a2','a3','a4'];           
            validHTML = '<carousel-customize carousellist=carousellist carouseltype="tilecarousel" detailtype="driverdata" visibleitems=3 idname="expandPolicyCarousel" navigationbars=false onlydesktop=true> </carousel-customize>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
            expect(isolate.carousellists.length).toEqual(scope.carousellist.length);
            isolate.initializeSlick();
            // isolate.clickEventSlick(); 
            angular.element(window).trigger('resize');
            isolate.checkIntializeSlick(234); 
           
        });
    });
    
    describe('when changing the scope values', function() {

        beforeEach(function() {
            scope.carousellist = ['a1','a2','a3','a4'];           
            validHTML = '<carousel-customize carousellist=carousellist carouseltype="tilecarousel" detailtype="coveragedriver" visibleitems=3 idname="expandPolicyCarousel" navigationbars=false onlymobile=true> </carousel-customize>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
            expect(isolate.carousellists.length).toEqual(scope.carousellist.length);
            isolate.initializeSlick();
            // isolate.clickEventSlick(); 
            isolate.initializeSlick();
            timeout.flush();
            angular.element(".policy-detail-head-carousel .slick-slide").trigger('click')
            isolate.unInitializeSlick();
            timeout.flush();
            isolate.checkIntializeSlick(123); 
           
        });
    });

    describe('when changing the scope values', function() {

        beforeEach(function() {
            scope.carousellist = ['a1','a2','a3','a4'];           
            validHTML = '<carousel-customize carousellist=carousellist carouseltype="tilecarousel" detailtype="driverdata" visibleitems=3 idname="expandPolicyCarousel" navigationbars=false onlydesktop=true> </carousel-customize>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
            expect(isolate.carousellists.length).toEqual(scope.carousellist.length);
            isolate.initializeSlick();
            timeout.flush();
            isolate.unInitializeSlick();
            timeout.flush();
           
        });
    });
    
    describe('when changing the scope values', function() {

        beforeEach(function() {
            scope.carousellist = ['a1','a2','a3','a4'];           
            validHTML = '<carousel-customize carousellist=carousellist carouseltype="tilecarousel" detailtype="coveragedriver" visibleitems=3 idname="expandPolicyCarousel" navigationbars=false onlymobile=true> </carousel-customize>';
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
            expect(isolate.carousellists.length).toEqual(scope.carousellist.length);
            window.innerWidth = 600;
            isolate.checkIntializeSlick(123); 
           
        });
    });


});
