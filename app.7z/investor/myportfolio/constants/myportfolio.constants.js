'use strict';

var myportfolioConstants = (function() {
    return {
        overview: {
            NAV_PILLS_OPTIONS: [{
                btnName: 'PAN View',
                uibValue: 'panview'
            }, {
                btnName: 'Folio View',
                uibValue: 'folioview'
            }, {
                btnName: 'Account View',
                uibValue: 'accview'
            }],
            FIRST_HOLDER: 'FIRST_HOLDER',
            SECOND_HOLDER: 'SECOND_HOLDER',
            THIRD_HOLDER: 'THIRD_HOLDER',
            FOURTH_HOLDER: 'FOURTH_HOLDER',
            FIFTH_HOLDER: 'FIFTH_HOLDER',
            STATUS: 'STATUS',
            MODE_OF_OPERATION: 'MODE_OF_OPERATION',
            BANK_DETAILS: 'BANK DETAILS',
            MODE_OF_PAYMENT: 'MODE OF PAYMENT',
            RETURNS_TOOLTIP_TEXT: 'Returns basis XIRR i.e., rate of return basis your investments at various time periods in this fund.',
            INV_APP_NAME:'Investor',
            optionCode:'VAS',
            DATEPICKER_VAL_MSGS: [{expression: 'required', description: 'The As on Date is empty. Please try again'}, {expression: 'date', description: 'The As on Date is invalid. Please try again'}],
            DATEPICKER_RANGE_VAL_MSGS: [{expression: 'required', description: 'The From Date or To Date is empty. Please try again.'}, {expression: 'date', description: 'The From Date or To Date is invalid. Please try again'}]
        },
        panView: {
            PAN_FILTER_OPT: [{
                title: 'PAN as Any holder',
                category: 'PA'
            }, {
                title: 'PAN as First holder',
                category: 'PF'
            }],
            DATE_FILTER_OPT: [{
                id: 1,
                key: 'AD',
                label: 'As on Date',
                type: 'fulldate'
            }, {
                id: 2,
                key: 'LF',
                label: 'Last financial year',
                type: 'defineddate'
            }, {
                id: 3,
                key: 'DR',
                label: 'Date Range',
                type: 'daterange'
            }, {
                id: 4,
                key: 'SI',
                label: 'Since Inception',
                type: 'defineddate'
            }],
        },
        capitalGains: {
            optionCode:'CGS',  
        },
        cas: {
            camsURL: "http://www.camsonline.com/InvestorServices/COL_ISAccountStatementCKF.aspx",
            karvyURL: "https://www.karvymfs.com/platformservice/"
        },
        flagOptions: {
            'ACCOUNT_FLAG': 'A',
            'PAN_FLAG': 'PA',
            'FOLIO_FLAG': 'F'
        }
    };
}());

myportfolioConstants.$inject = [];
module.exports = myportfolioConstants;