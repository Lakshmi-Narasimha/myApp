'use strict';

var timestamp = function() {
	return {
            template: require('./timestamp.html'),
            restrict: 'E',
            replace: true,
            scope: {
              lable: "=lable",
              date: "=date",
              time: "=time"
            }
        };
};

timestamp.$inject = [];
module.exports = timestamp;