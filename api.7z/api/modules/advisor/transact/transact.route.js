 var express = require('express'),
     router = express.Router(),
     selectFundData = require('./common/getRedeemSFDetails.model'),
     FundDetailsModel = require('./fundDetails/fundDetails.model'),
     RedeemModel = require('./redeem/redeem.model'),
     AmountModel = require('./redeem/getAmount.model'),
     UnitsModel = require('./redeem/getUnits.model'),
     RegisteredBankModel = require('./common/getRegisteredBank.model'),
     transactModel = require('./transact.model'),
     FundDtlsForNewFund = require('./common/getFundDtlsForNewFundSelection.model'),
     SwpModel = require('./swp/swp.model'),
     IfscSearch = require('./common/ifscSearch.model'),
     IfscGrid = require('./common/ifscSearchGrid.model'),
     InvestorDtlsModel = require('./investorDetails/investorDetails.model'),
     BuyBanksModel = require('./buy/getBanks.model'),
     NewFolioDtlsModel = require('./buy/newFolioDetails.model'),
     IfscGrid = require('./common/ifscSearchGrid.model'),
     CheckKycModel = require('./buy/checkKyc.model'),
     FolioValidationModel = require('./buy/folioValidation.model'),
     BuySIModel = require('./buy/buySI.model'),
     ModSIPModel = require('./modifysip/modSip.model'),
     EkycFormModel = require('./buy/ekycRegForm.model'),
     FrequencyModel = require('./common/frequency.model'),
     NewInvBanksModel = require('./buy/newInvBanks.model'),
     selectFundDetails = require('./common/selectFundData.model'),
     GetTxnStpModel = require('./txnDetailsStp.model'),
     GetTxnSwitchModel = require('./txnDetailsSwitch.model'),
     GetTxnSipModel = require('./txnDetailsSip.model'),
     GetTxnSwpModel = require('./txnDetailsSwp.model'),
     GetTxnBuyModel = require('./txnDetailsBuy.model'),
     GetTxnRedeemModel = require('./txnDetailsRedeem.model'),
     GetTxnModifySipModel = require('./txnDetailsModifySip.model'),
     GetGuestDetailsModel = require('./guestDetails.model'),
     CancelStpFundDetailsModel = require('./cancelStpDetails.model'),
     ValidateSwpModel = require('./swp/validateSwp.model');

 // api route

 var error = {
     status: 300,
     message: 'Something went wrong!!'
 }; /* Error messge object */

 //Select Fund Data
 router.route('/getSelectFundDtls')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         selectFundData.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute
             /*console.log(req.query);*/
             if (err) {
                 res.send(err);
             } else if (data[0].RedeemSFObject.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].RedeemSFObject);
                 //res.send(500, error);
             }

         });
     });

 //Select fund details       
 router.route('/transact/txnEligibleAccounts')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database        
         // Mandatary elements are present       
         selectFundDetails.find(function (err, data) {
             // if there is an error retrieving, send the error.         
             // nothing after res.send(err) will execute     
             /*console.log(req.query);*/
             if (err) {
                 res.send(err);
             } else if (data[0].SelectFundObject.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].SelectFundObject[0]);
                 //res.send(500, error);     
             }
         });
     });

 //Fund Details
 router.route('/fundDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         FundDetailsModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].FundDetailsResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].FundDetailsResp);
             }

         });
     });

 //Balance Units -  for Investor Flow

 router.route('/transact/balanceUnits')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         FundDetailsModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].FundDetailsResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].FundDetailsResp[0].fund);
             }

         });
     });

 //Redemption Details
 router.route('/getBankDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         RedeemModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].RedeemResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].RedeemResp);
             }

         });
     });

 router.route('/getAmountValue')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         AmountModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].AmountResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].AmountResp);
             }

         });
     });

 router.route('/getUnitsValue')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         UnitsModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].UnitsResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].UnitsResp);
             }

         });
     });

 //Registered Bank
 router.route('/getRegisteredBank')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         RegisteredBankModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].RegisteredBankResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].RegisteredBankResp);
             }

         });
     });

 //SWP Details
 router.route('/swp')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         SwpModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].SwpResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].SwpResp);
             }

         });
     });

 // Transaction Details
 router.route('/gettransactdetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         transactModel.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].transactResp);
             }

         });
     });

 //Fund details for new fund selection
 router.route('/transact/fundsList')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         FundDtlsForNewFund.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].FundDetails[0]);
             }

         });
     });

 //IFSC search response for selected city and branch
 router.route('/transact/ifscSearch')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present

         IfscSearch.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 if (req.query.type === 'BNK') {

                     res.json({
                         "cities": data[0].IfscSearchObject[0].cities
                     });
                 }
                 if (req.query.type === 'CTY') {
                     res.json({
                         "branches": data[0].IfscSearchObject[0].branches
                     });
                 }
                 if (req.query.type === 'BRN') {
                     res.json({
                         "bankDetails": data[0].IfscSearchObject[0].bankDetails
                     });
                 }
                 if (req.query.type === 'IFS') {
                     console.log(data);
                     res.json({
                         "bankDetails": data[0].IfscSearchObject[0].bankDetails
                     });
                 }
             }

         });
     });


 router.route('/clients/searchClient')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         InvestorDtlsModel.find(function (err, data) {
             /*console.log(req.query);*/
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].investorDtlsResp[0].result);
             }

         });
     });



 //IFSC search response for selected city and branch
 router.route('/ifscSearchGrid')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         IfscGrid.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].IfscSearchGridObject);
             }

         });
     });
 //Banks for Buy module
 router.route('/getBanks')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         BuyBanksModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].BankResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].BankResp);
             }

         });
     });

 // Banks for New Account
 router.route('/getNewInvBanks')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         NewInvBanksModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].NewInvBankResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].NewInvBankResp);
             }

         });
     });

 router.route('/getNewFolioDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         NewFolioDtlsModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute
             if (err) {
                 res.send(err);
             } else if (data[0].NewFolioDtlsResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].NewFolioDtlsResp);
                 //res.send(500, error);
             }

         });
     });
     //Select cancel Stp fund details       
router.route('/clients/stpSummary')       
    .get(function(req, res) {       
        // use mongoose to get all nerds in the database        
        // Mandatary elements are present       
        CancelStpFundDetailsModel.find(function (err, data) {       
            // if there is an error retrieving, send the error.         
            // nothing after res.send(err) will execute     
            /*console.log(req.query);*/   

            if (err) {      
                res.send(err);      
            } else if (data[0].cancelStpResp.length === 0) {     
                res.send(error);        
            } else {        
                res.json(data[0].cancelStpResp);      
                //res.send(500, error);     
            }      
        });     
});


 router.route('/ekycRegistrationForm')
     .post(function (req, res) {
         if (req.params[0]) {
             res.json(successObj);
         }
     });

 router.route('/checkKyc')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         CheckKycModel.find(function (err, data) {
             // if there is an error retrieving, send the error.
             // nothing after res.send(err) will execute
             if (err) {
                 res.send(err);
             } else if (data[0].CheckKycResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].CheckKycResp);
                 //res.send(500, error);
             }

         });
     });
 router.route('/folioValidation')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         FolioValidationModel.find(function (err, data) {
             // if there is an error retrieving, send the error.
             // nothing after res.send(err) will execute
             if (err) {
                 res.send(err);
             } else if (data[0].FolioValidationResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].FolioValidationResp);
                 //res.send(500, error);
             }

         });
     });



 router.route('/ekycDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         EkycFormModel.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].RegResp);
             }

         });
     });



 router.route('/getBuySIDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         BuySIModel.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].BuySIResp);
             }

         });
     });

 //Modify SIP

 router.route('/getModifySipDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         ModSIPModel.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].ModSipResp);
             }

         });
     });


 //Frequency
 //Modify SIP

 router.route('/getFrequencyOptions')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         FrequencyModel.find(function (err, data) {
             if (err) {
                 res.send(err);
             } else if (data[0].frequencyObject.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].frequencyObject);
             }

         });
     });

 // getNewInvBanks

 router.route('/getTxnDetailsStp')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnStpModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnStpResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnStpResp);
             }

         });
     });

 router.route('/getTxnDetailsSwitch')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnSwitchModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnSwitchResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnSwitchResp);
             }

         });
     });

 router.route('/getTxnDetailsSip')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnSipModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnSipResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnSipResp);
             }

         });
     });

 router.route('/getTxnDetailsSwp')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnSwpModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnSwpResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnSwpResp);
             }

         });
     });

 router.route('/getTxnDetailsBuy')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnBuyModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnBuyResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnBuyResp);
             }

         });
     });

 router.route('/getTxnDetailsRedeem')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnRedeemModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnRedeemResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnRedeemResp);
             }

         });
     });

 router.route('/getTxnDetailsModifySip')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetTxnModifySipModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].GetTxnModifySipResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].GetTxnModifySipResp);
             }

         });
     });

 router.route('/getGuestDetails')
     .get(function (req, res) {
         // use mongoose to get all nerds in the database
         // Mandatary elements are present
         GetGuestDetailsModel.find(function (err, data) {
             // if there is an error retrieving, send the error. 
             // nothing after res.send(err) will execute 
             if (err) {
                 res.send(err);
             } else if (data[0].guestDetailsResp.length === 0) {
                 res.send(error);
             } else {
                 res.json(data[0].guestDetailsResp);
             }

         });
     });

 //Validate SWP - Investor Transact Flow (Works for Advisor also)
 router.route('/transact/validateSwp')
     .post(function (req, res) {
         ValidateSwpModel.find(function (err, data) {
             res.send(data[0].validateSwpResp);
         });
     });





 module.exports = router;
