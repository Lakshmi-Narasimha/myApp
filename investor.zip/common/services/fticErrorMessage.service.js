/**
 * @ngdoc service
 * @name Common FTIC Broadcast
 * @description
 *
 * - Common method for broadcasting events for app level
 *
 */


'use strict';

var fticErrorMessage = function(eventConstants, toaster, errorConstants) {
	return {
		displayErrorMessage : function (errorCode, errMsg, modelService) {
			var errorMessage = null;
			console.log(modelService)
			if(modelService !== undefined && modelService[errorCode] !== undefined) {
				errorMessage = modelService[errorCode];
			}
			else if(errorConstants[errorCode] !== undefined) {
				errorMessage = errorConstants[errorCode]	
			}
			else {
				errorMessage = errMsg;
			}
			toaster.error(errorMessage);
		}
	};
	
};

fticErrorMessage.$inject = ['eventConstants', 'toaster', 'errorConstants'];
module.exports = fticErrorMessage;
