var config = require('/app/conf/properties/mfchatnode/config');

var sendMessageModelConfig = {
    response: {
        "sessionOver": false,
        "Page": {
            "pageType": "livechat",
            "parentPageType": "myData",
            "callType": "sendMessage",
            "showChatHistory": false,
            "agentBusy": false
        },
        "ResponseInfo": {
            "locale": "en",
            "requestId": "cd5894bc-7949-4c9f-b165-1d74359d0bfe",
            "buildNumber": "280",
            "code": "00000",
            "type": "Success"
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "requestId": "cd5894bc-7949-4c9f-b165-1d74359d0bfe",
                    "buildNumber": "280",
                    "code": "00000",
                    "type": "Success"
                }
            }
        }
    },
    createRequestUri: {
        host: config.TC_SERVER_NAME,
        path: config.TC_SEND_MSG_URI
    },

    lpReq: {
        "event": {
            "@type": "line",
            "text": ""
        }
    },

    lpEndChatReq:{
        "event": {
            "@type": "state",
            "state": "ended"
        }
    }
};

module.exports = sendMessageModelConfig;
//// added this thing to just check the git changes taking place or not////
