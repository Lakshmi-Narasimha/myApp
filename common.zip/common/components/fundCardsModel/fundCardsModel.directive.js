/**
 * @ngdoc property
 * @name Fund Card Directive
 * @requires $state
 * @description
 *
 *
 **/
'use strict';

var FundCardsModel = function() {
	return {
            template: require('./fundCardsModel.html'),
            restrict: 'E',
            replace: true
        };
};

FundCardsModel.$inject = [];
module.exports = FundCardsModel;