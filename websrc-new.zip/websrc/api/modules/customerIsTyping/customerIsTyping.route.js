var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var customerIsTypingModel = require('./customerIsTyping.model');
var proxy = require('../../../config/proxy');
var request = require('request');
// api route
router.route('/mfchatnode/rest/customerIsTyping')
    .post(function(req, res) {
        logger.general.info(logger.formatInBoundReqMsg(req));
        if(req.session.isTMP){
            var post_data = {};
            if(req.body.RequestParams.isTyping){
                customerIsTypingModel.lpReq.visitorTyping = 'typing';                
            }else{
                customerIsTypingModel.lpReq.visitorTyping = 'not-typing';                
            }
            post_data = customerIsTypingModel.lpReq; 
            var reqObj = {
                //method: 'PUT',
                url: req.session.location+'/info/visitorTyping?v=1' + config.LP_APP_KEY_PARAM,
                agent: proxy.agent,
                ca:proxy.ca,            
                headers: {                
                    'Content-Type' : 'application/json; charset=utf8',
                    //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                    'Accept' : 'application/json',
                    'X-HTTP-Method-Override': 'PUT'
                },                
                body: JSON.stringify(post_data)
            };
            logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            request.post(reqObj,function(err,response,body){
                if(err){ 
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                    res.send(customerIsTypingModel.response);
                }else if(response.statusCode !== 200){
                    logger.error.error(logger.formatResMsg(reqObj, post_data, req.session.id));
                    logger.error.error(logger.formatResMsg(reqObj, response, req.session.id));
                    res.send(customerIsTypingModel.response);                        
                }else {
                    logger.general.info(logger.formatInfoMsg(req.session.id, "LP vistor tpying response: "+ response));                
                    res.send(customerIsTypingModel.response);
                }               
            });      
        }else{
            req.uri = customerIsTypingModel.createRequestUri;
            var post_data = req.body.RequestParams || {};
            var postBody = querystring.stringify(post_data);
            var reqObj = {
                host: req.uri.host,
                method: 'POST',
                path: req.uri.path,
                agent: proxy.agent,
                ca:proxy.ca,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Cookie': req.session.sessionCookie,
                    'Content-Length': Buffer.byteLength(postBody)
                },
                rejectUnauthorized: true
            };

            logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            var proxyRequest = https.request(reqObj, function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                logger.general.info(logger.formatOutBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
                // if (proxyResponse.statusCode === 200) {
                //     logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
                //     res.send(customerIsTypingModel.response);
                // } else {
                //    var errObj = {
                //         message: proxyResponse.statusMessage,
                //         statusCode: proxyResponse.statusCode
                //     };
                //     logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                //     logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                //     res.send(errObj);
                // }
                logger.general.info(logger.formatInBoundResMsg(req, { statusCode: proxyResponse.statusCode }));
                res.send(customerIsTypingModel.response);

                proxyResponse.on('error', function(err) {
                    logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                    res.send(customerIsTypingModel.response);
                });
            });
            proxyRequest.write(postBody);
            proxyRequest.end();
        }
        
    });

module.exports = router;
