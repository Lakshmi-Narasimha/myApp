/**
 * @ngdoc service
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var familyPortfolioModel= function(Restangular, $q,   authenticationService) {
    var _familyPF = null,
    _fPfolioInvSum = null,
    familyPortfolioModel = {
        fetchFamilyPFList : function () {
            var params = {},
            deferred = $q.defer();
            params.guId = authenticationService.getUser().guId;
            Restangular.one('/profile/familyPortfolio').get(params).then(function (fPfolioList) {
                deferred.resolve(fPfolioList);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        acceptOrRejectOrRemoveFamilyPFReq : function (reqParams) {
            var deferred = $q.defer(),
            params = {
                'guId' : authenticationService.getUser().guId,
                'pan' : reqParams.pan,
                'userId' : reqParams.userId,
                'status' : reqParams.status
            };
            Restangular.one('/profile/accessFamilyPortfolio').get(params).then(function (fPfolioAccessReq) {
                deferred.resolve(fPfolioAccessReq);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setFamilyPFList : function (fPfolioList) {
            
            _familyPF = fPfolioList;
        },
        getFamilyPFList : function () {
            if (!angular.isDefined(_familyPF)) {
                return null;
            }
            return _familyPF;
        },
        setFamilyPFInvestmentSummary : function (fPfolioInvSum) {
            
            _fPfolioInvSum = fPfolioInvSum;
        },
        getFamilyPFInvestmentSummary : function () {
            if (!angular.isDefined(_fPfolioInvSum)) {
                return null;
            }
            return _fPfolioInvSum;
        },
        
    };
    return familyPortfolioModel;
};

familyPortfolioModel.$inject = ['Restangular', '$q', 'authenticationService'];
module.exports = familyPortfolioModel;
