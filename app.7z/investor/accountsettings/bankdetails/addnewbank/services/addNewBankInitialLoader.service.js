/**
 * @ngdoc service
 * @name FTI Dashboard Initial Load Service
 * @requires cgAccDetModel
 * @requires investorEvents
 * @requires eventConstants
 * @requires toaster
 * @requires $timeout
 * investorEventConstants
 * fticLoggerMessage
 * loggerConstants
 * toaster
 * $loader
 * @description
 *
 * - Handles the services and model for Advisor content details & widgets
 *
 */
'use strict';


var ftiAddNewBankInitialService = function(addNewBankModel, investorEvents, eventConstants, $timeout, investorEventConstants, fticLoggerMessage, loggerConstants, toaster, $loader) {
	var ftiAddNewBankInitialService = {
		_isServicesData: false,
		_isInitialLoad:false,
		loadAllServices : function (scope, addNewBankFolioObj) {
			addNewBankModel.getFolioAccountDetails() 
			.then(folioNumbersListSuccess, promiseFailure).finally(stopLoader);
			function folioNumbersListSuccess(data){
				addNewBankModel.setFolioNumbersList(data.panFolioAccounts);
				// investorEvents.myPortfolio.capitalGainsFolisNumberList(scope);
				investorEvents.accountSettings.loadFolioDetails(scope);
			};
			function promiseFailure (data) {
				ftiAddNewBankInitialService._isServicesData = false;
				ftiAddNewBankInitialService._isInitialLoad = false;
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			};
			 function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		},
		loadBanksList : function (scope, addNewBankFolioObj) {
			addNewBankModel.getBankDetails() 
			.then(BanksListSuccess, promiseFailure).finally(stopLoader);
			function BanksListSuccess(data){
				addNewBankModel.setBasisBankDetails(data);
				investorEvents.accountSettings.loadBankDetails(scope);
			};
			function promiseFailure (data) {
				ftiAddNewBankInitialService._isServicesData = false;
				ftiAddNewBankInitialService._isInitialLoad = false;
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			};
			 function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		}
	};
	return ftiAddNewBankInitialService;
};


ftiAddNewBankInitialService.$inject = ['addNewBankModel', 'investorEvents', 'eventConstants', '$timeout', 'investorEventConstants', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader'];

module.exports = ftiAddNewBankInitialService;
