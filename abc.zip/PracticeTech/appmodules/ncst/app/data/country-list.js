﻿
define([],function(){
	var dropdownList = {};
	dropdownList.ISOCountryList = [
	{
		"code": "004",
		"name": "AFGHANISTAN"
	},
	{
		"code": "008",
		"name": "ALBANIA"
	},
	{
		"code": "010",
		"name": "ANTARCTICA"
	},
	{
		"code": "012",
		"name": "ALGERIA"
	},
	{
		"code": "016",
		"name": "AMERICAN SAMOA"
	},
	{
		"code": "020",
		"name": "ANDORRA"
	},
	{
		"code": "024",
		"name": "ANGOLA"
	},
	{
		"code": "028",
		"name": "ANTIGUA AND BARBUDA"
	},
	{
		"code": "031",
		"name": "AZERBAIJAN"
	},
	{
		"code": "032",
		"name": "ARGENTINA"
	},
	{
		"code": "036",
		"name": "AUSTRALIA"
	},
	{
		"code": "040",
		"name": "AUSTRIA"
	},
	{
		"code": "044",
		"name": "BAHAMAS"
	},
	{
		"code": "048",
		"name": "BAHRAIN"
	},
	{
		"code": "050",
		"name": "BANGLADESH"
	},
	{
		"code": "051",
		"name": "ARMENIA"
	},
	{
		"code": "052",
		"name": "BARBADOS"
	},
	{
		"code": "056",
		"name": "BELGIUM"
	},
	{
		"code": "060",
		"name": "BERMUDA"
	},
	{
		"code": "064",
		"name": "BHUTAN"
	},
	{
		"code": "068",
		"name": "BOLIVIA (PLURINATIONAL STATE OF)"
	},
	{
		"code": "070",
		"name": "BOSNIA AND HERZEGOVINA"
	},
	{
		"code": "072",
		"name": "BOTSWANA"
	},
	{
		"code": "074",
		"name": "BOUVET ISLAND"
	},
	{
		"code": "076",
		"name": "BRAZIL"
	},
	{
		"code": "084",
		"name": "BELIZE"
	},
	{
		"code": "086",
		"name": "BRITISH INDIAN OCEAN TERRITORY"
	},
	{
		"code": "090",
		"name": "SOLOMON ISLANDS"
	},
	{
		"code": "092",
		"name": "VIRGIN ISLANDS (BRITISH)"
	},
	{
		"code": "096",
		"name": "BRUNEI DARUSSALAM"
	},
	{
		"code": "100",
		"name": "BULGARIA"
	},
	{
		"code": "104",
		"name": "MYANMAR"
	},
	{
		"code": "108",
		"name": "BURUNDI"
	},
	{
		"code": "112",
		"name": "BELARUS"
	},
	{
		"code": "116",
		"name": "CAMBODIA"
	},
	{
		"code": "120",
		"name": "CAMEROON"
	},
	{
		"code": "124",
		"name": "CANADA"
	},
	{
		"code": "132",
		"name": "CABO VERDE"
	},
	{
		"code": "136",
		"name": "CAYMAN ISLANDS"
	},
	{
		"code": "140",
		"name": "CENTRAL AFRICAN REPUBLIC"
	},
	{
		"code": "144",
		"name": "SRI LANKA"
	},
	{
		"code": "148",
		"name": "CHAD"
	},
	{
		"code": "152",
		"name": "CHILE"
	},
	{
		"code": "156",
		"name": "CHINA"
	},
	{
		"code": "158",
		"name": "TAIWAN"
	},
	{
		"code": "162",
		"name": "CHRISTMAS ISLAND"
	},
	{
		"code": "166",
		"name": "COCOS (KEELING) ISLANDS"
	},
	{
		"code": "170",
		"name": "COLOMBIA"
	},
	{
		"code": "174",
		"name": "COMOROS"
	},
	{
		"code": "175",
		"name": "MAYOTTE"
	},
	{
		"code": "178",
		"name": "CONGO"
	},
	{
		"code": "180",
		"name": "CONGO (DEMOCRATIC REPUBLIC OF THE)"
	},
	{
		"code": "184",
		"name": "COOK ISLANDS"
	},
	{
		"code": "188",
		"name": "COSTA RICA"
	},
	{
		"code": "191",
		"name": "CROATIA"
	},
	{
		"code": "192",
		"name": "CUBA"
	},
	{
		"code": "196",
		"name": "CYPRUS"
	},
	{
		"code": "203",
		"name": "CZECHIA"
	},
	{
		"code": "204",
		"name": "BENIN"
	},
	{
		"code": "208",
		"name": "DENMARK"
	},
	{
		"code": "212",
		"name": "DOMINICA"
	},
	{
		"code": "214",
		"name": "DOMINICAN REPUBLIC"
	},
	{
		"code": "218",
		"name": "ECUADOR"
	},
	{
		"code": "222",
		"name": "EL SALVADOR"
	},
	{
		"code": "226",
		"name": "EQUATORIAL GUINEA"
	},
	{
		"code": "231",
		"name": "ETHIOPIA"
	},
	{
		"code": "232",
		"name": "ERITREA"
	},
	{
		"code": "233",
		"name": "ESTONIA"
	},
	{
		"code": "234",
		"name": "FAROE ISLANDS"
	},
	{
		"code": "238",
		"name": "FALKLAND ISLANDS (MALVINAS)"
	},
	{
		"code": "239",
		"name": "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS"
	},
	{
		"code": "242",
		"name": "FIJI"
	},
	{
		"code": "246",
		"name": "FINLAND"
	},
	{
		"code": "248",
		"name": "ÅLAND ISLANDS"
	},
	{
		"code": "250",
		"name": "FRANCE"
	},
	{
		"code": "254",
		"name": "FRENCH GUIANA"
	},
	{
		"code": "258",
		"name": "FRENCH POLYNESIA"
	},
	{
		"code": "260",
		"name": "FRENCH SOUTHERN TERRITORIES"
	},
	{
		"code": "262",
		"name": "DJIBOUTI"
	},
	{
		"code": "266",
		"name": "GABON"
	},
	{
		"code": "268",
		"name": "GEORGIA"
	},
	{
		"code": "270",
		"name": "GAMBIA"
	},
	{
		"code": "275",
		"name": "PALESTINE"
	},
	{
		"code": "276",
		"name": "GERMANY"
	},
	{
		"code": "288",
		"name": "GHANA"
	},
	{
		"code": "292",
		"name": "GIBRALTAR"
	},
	{
		"code": "296",
		"name": "KIRIBATI"
	},
	{
		"code": "300",
		"name": "GREECE"
	},
	{
		"code": "304",
		"name": "GREENLAND"
	},
	{
		"code": "308",
		"name": "GRENADA"
	},
	{
		"code": "312",
		"name": "GUADELOUPE"
	},
	{
		"code": "316",
		"name": "GUAM"
	},
	{
		"code": "320",
		"name": "GUATEMALA"
	},
	{
		"code": "324",
		"name": "GUINEA"
	},
	{
		"code": "328",
		"name": "GUYANA"
	},
	{
		"code": "332",
		"name": "HAITI"
	},
	{
		"code": "334",
		"name": "HEARD ISLAND AND MCDONALD ISLANDS"
	},
	{
		"code": "336",
		"name": "HOLY SEE"
	},
	{
		"code": "340",
		"name": "HONDURAS"
	},
	{
		"code": "344",
		"name": "HONG KONG"
	},
	{
		"code": "348",
		"name": "HUNGARY"
	},
	{
		"code": "352",
		"name": "ICELAND"
	},
	{
		"code": "356",
		"name": "INDIA"
	},
	{
		"code": "360",
		"name": "INDONESIA"
	},
	{
		"code": "364",
		"name": "IRAN (ISLAMIC REPUBLIC OF)"
	},
	{
		"code": "368",
		"name": "IRAQ"
	},
	{
		"code": "372",
		"name": "IRELAND"
	},
	{
		"code": "376",
		"name": "ISRAEL"
	},
	{
		"code": "380",
		"name": "ITALY"
	},
	{
		"code": "384",
		"name": "CôTE D'IVOIRE"
	},
	{
		"code": "388",
		"name": "JAMAICA"
	},
	{
		"code": "392",
		"name": "JAPAN"
	},
	{
		"code": "398",
		"name": "KAZAKHSTAN"
	},
	{
		"code": "400",
		"name": "JORDAN"
	},
	{
		"code": "404",
		"name": "KENYA"
	},
	{
		"code": "408",
		"name": "KOREA (DEMOCRATIC PEOPLE'S REPUBLIC OF)"
	},
	{
		"code": "410",
		"name": "KOREA (REPUBLIC OF)"
	},
	{
		"code": "414",
		"name": "KUWAIT"
	},
	{
		"code": "417",
		"name": "KYRGYZSTAN"
	},
	{
		"code": "418",
		"name": "LAO PEOPLE'S DEMOCRATIC REPUBLIC"
	},
	{
		"code": "422",
		"name": "LEBANON"
	},
	{
		"code": "426",
		"name": "LESOTHO"
	},
	{
		"code": "428",
		"name": "LATVIA"
	},
	{
		"code": "430",
		"name": "LIBERIA"
	},
	{
		"code": "434",
		"name": "LIBYA"
	},
	{
		"code": "438",
		"name": "LIECHTENSTEIN"
	},
	{
		"code": "440",
		"name": "LITHUANIA"
	},
	{
		"code": "442",
		"name": "LUXEMBOURG"
	},
	{
		"code": "446",
		"name": "MACAO"
	},
	{
		"code": "450",
		"name": "MADAGASCAR"
	},
	{
		"code": "454",
		"name": "MALAWI"
	},
	{
		"code": "458",
		"name": "MALAYSIA"
	},
	{
		"code": "462",
		"name": "MALDIVES"
	},
	{
		"code": "466",
		"name": "MALI"
	},
	{
		"code": "470",
		"name": "MALTA"
	},
	{
		"code": "474",
		"name": "MARTINIQUE"
	},
	{
		"code": "478",
		"name": "MAURITANIA"
	},
	{
		"code": "480",
		"name": "MAURITIUS"
	},
	{
		"code": "484",
		"name": "MEXICO"
	},
	{
		"code": "492",
		"name": "MONACO"
	},
	{
		"code": "496",
		"name": "MONGOLIA"
	},
	{
		"code": "498",
		"name": "MOLDOVA (REPUBLIC OF)"
	},
	{
		"code": "499",
		"name": "MONTENEGRO"
	},
	{
		"code": "500",
		"name": "MONTSERRAT"
	},
	{
		"code": "504",
		"name": "MOROCCO"
	},
	{
		"code": "508",
		"name": "MOZAMBIQUE"
	},
	{
		"code": "512",
		"name": "OMAN"
	},
	{
		"code": "516",
		"name": "NAMIBIA"
	},
	{
		"code": "520",
		"name": "NAURU"
	},
	{
		"code": "524",
		"name": "NEPAL"
	},
	{
		"code": "528",
		"name": "NETHERLANDS"
	},
	{
		"code": "531",
		"name": "CURA«AO"
	},
	{
		"code": "533",
		"name": "ARUBA"
	},
	{
		"code": "534",
		"name": "SINT MAARTEN (DUTCH PART)"
	},
	{
		"code": "535",
		"name": "BONAIRE"
	},
	{
		"code": "540",
		"name": "NEW CALEDONIA"
	},
	{
		"code": "548",
		"name": "VANUATU"
	},
	{
		"code": "554",
		"name": "NEW ZEALAND"
	},
	{
		"code": "558",
		"name": "NICARAGUA"
	},
	{
		"code": "562",
		"name": "NIGER"
	},
	{
		"code": "566",
		"name": "NIGERIA"
	},
	{
		"code": "570",
		"name": "NIUE"
	},
	{
		"code": "574",
		"name": "NORFOLK ISLAND"
	},
	{
		"code": "578",
		"name": "NORWAY"
	},
	{
		"code": "580",
		"name": "NORTHERN MARIANA ISLANDS"
	},
	{
		"code": "581",
		"name": "UNITED STATES MINOR OUTLYING ISLANDS"
	},
	{
		"code": "583",
		"name": "MICRONESIA (FEDERATED STATES OF)"
	},
	{
		"code": "584",
		"name": "MARSHALL ISLANDS"
	},
	{
		"code": "585",
		"name": "PALAU"
	},
	{
		"code": "586",
		"name": "PAKISTAN"
	},
	{
		"code": "591",
		"name": "PANAMA"
	},
	{
		"code": "598",
		"name": "PAPUA NEW GUINEA"
	},
	{
		"code": "600",
		"name": "PARAGUAY"
	},
	{
		"code": "604",
		"name": "PERU"
	},
	{
		"code": "608",
		"name": "PHILIPPINES"
	},
	{
		"code": "612",
		"name": "PITCAIRN"
	},
	{
		"code": "616",
		"name": "POLAND"
	},
	{
		"code": "620",
		"name": "PORTUGAL"
	},
	{
		"code": "624",
		"name": "GUINEA-BISSAU"
	},
	{
		"code": "626",
		"name": "TIMOR-LESTE"
	},
	{
		"code": "630",
		"name": "PUERTO RICO"
	},
	{
		"code": "634",
		"name": "QATAR"
	},
	{
		"code": "638",
		"name": "RéUNION"
	},
	{
		"code": "642",
		"name": "ROMANIA"
	},
	{
		"code": "643",
		"name": "RUSSIAN FEDERATION"
	},
	{
		"code": "646",
		"name": "RWANDA"
	},
	{
		"code": "652",
		"name": "SAINT BARTHéLEMY"
	},
	{
		"code": "654",
		"name": "SAINT HELENA"
	},
	{
		"code": "659",
		"name": "SAINT KITTS AND NEVIS"
	},
	{
		"code": "660",
		"name": "ANGUILLA"
	},
	{
		"code": "662",
		"name": "SAINT LUCIA"
	},
	{
		"code": "663",
		"name": "SAINT MARTIN (FRENCH PART)"
	},
	{
		"code": "666",
		"name": "SAINT PIERRE AND MIQUELON"
	},
	{
		"code": "670",
		"name": "SAINT VINCENT AND THE GRENADINES"
	},
	{
		"code": "674",
		"name": "SAN MARINO"
	},
	{
		"code": "678",
		"name": "SAO TOME AND PRINCIPE"
	},
	{
		"code": "682",
		"name": "SAUDI ARABIA"
	},
	{
		"code": "686",
		"name": "SENEGAL"
	},
	{
		"code": "688",
		"name": "SERBIA"
	},
	{
		"code": "690",
		"name": "SEYCHELLES"
	},
	{
		"code": "694",
		"name": "SIERRA LEONE"
	},
	{
		"code": "702",
		"name": "SINGAPORE"
	},
	{
		"code": "703",
		"name": "SLOVAKIA"
	},
	{
		"code": "704",
		"name": "VIET NAM"
	},
	{
		"code": "705",
		"name": "SLOVENIA"
	},
	{
		"code": "706",
		"name": "SOMALIA"
	},
	{
		"code": "710",
		"name": "SOUTH AFRICA"
	},
	{
		"code": "716",
		"name": "ZIMBABWE"
	},
	{
		"code": "724",
		"name": "SPAIN"
	},
	{
		"code": "728",
		"name": "SOUTH SUDAN"
	},
	{
		"code": "729",
		"name": "SUDAN"
	},
	{
		"code": "732",
		"name": "WESTERN SAHARA"
	},
	{
		"code": "740",
		"name": "SURINAME"
	},
	{
		"code": "744",
		"name": "SVALBARD AND JAN MAYEN"
	},
	{
		"code": "748",
		"name": "SWAZILAND"
	},
	{
		"code": "752",
		"name": "SWEDEN"
	},
	{
		"code": "756",
		"name": "SWITZERLAND"
	},
	{
		"code": "760",
		"name": "SYRIAN ARAB REPUBLIC"
	},
	{
		"code": "762",
		"name": "TAJIKISTAN"
	},
	{
		"code": "764",
		"name": "THAILAND"
	},
	{
		"code": "768",
		"name": "TOGO"
	},
	{
		"code": "772",
		"name": "TOKELAU"
	},
	{
		"code": "776",
		"name": "TONGA"
	},
	{
		"code": "780",
		"name": "TRINIDAD AND TOBAGO"
	},
	{
		"code": "784",
		"name": "UNITED ARAB EMIRATES"
	},
	{
		"code": "788",
		"name": "TUNISIA"
	},
	{
		"code": "792",
		"name": "TURKEY"
	},
	{
		"code": "795",
		"name": "TURKMENISTAN"
	},
	{
		"code": "796",
		"name": "TURKS AND CAICOS ISLANDS"
	},
	{
		"code": "798",
		"name": "TUVALU"
	},
	{
		"code": "800",
		"name": "UGANDA"
	},
	{
		"code": "804",
		"name": "UKRAINE"
	},
	{
		"code": "807",
		"name": "MACEDONIA (THE FORMER YUGOSLAV REPUBLIC OF)"
	},
	{
		"code": "818",
		"name": "EGYPT"
	},
	{
		"code": "826",
		"name": "UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND"
	},
	{
		"code": "831",
		"name": "GUERNSEY"
	},
	{
		"code": "832",
		"name": "JERSEY"
	},
	{
		"code": "833",
		"name": "ISLE OF MAN"
	},
	{
		"code": "834",
		"name": "TANZANIA"
	},
	{
		"code": "840",
		"name": "UNITED STATES OF AMERICA"
	},
	{
		"code": "850",
		"name": "VIRGIN ISLANDS (U.S.)"
	},
	{
		"code": "854",
		"name": "BURKINA FASO"
	},
	{
		"code": "858",
		"name": "URUGUAY"
	},
	{
		"code": "860",
		"name": "UZBEKISTAN"
	},
	{
		"code": "862",
		"name": "VENEZUELA (BOLIVARIAN REPUBLIC OF)"
	},
	{
		"code": "876",
		"name": "WALLIS AND FUTUNA"
	},
	{
		"code": "882",
		"name": "SAMOA"
	},
	{
		"code": "887",
		"name": "YEMEN"
	},
	{
		"code": "894",
		"name": "ZAMBIA"
	}
	];
	dropdownList.countryList = 
	[
	{name:"AFGHANISTAN",code:"AF"},
	{name:"AKROTIRI",code:"AX"},
	{name:"ALBANIA",code:"AL"},
	{name:"ALGERIA",code:"AG"},
	{name:"AMERICAN SAMOA",code:"AQ"},
	{name:"ANDORRA",code:"AN"},
	{name:"ANGOLA",code:"AO"},
	{name:"ANGUILLA",code:"AV"},
	{name:"ANTARCTIC LANDS",code:"FS"},
	{name:"ANTARCTICA",code:"AY"},
	{name:"ANTIGUA",code:"AC"},
	{name:"ARGENTINA",code:"AR"},
	{name:"ARMENIA",code:"AM"},
	{name:"ARUBA",code:"AA"},
	{name:"ASHMORE ISLAND",code:"AT"},
	{name:"AUSTRALIA",code:"AS"},
	{name:"AUSTRIA",code:"AU"},
	{name:"AZERBAIJAN",code:"AJ"},
	{name:"AZORES",code:"PO"},
	/*{name:"BAHAMAS",code:"BF"},*/
	{name:"BAHAMAS, THE",code:"BF"},
	{name:"BAHRAIN",code:"BA"},
	{name:"BAKER ISLAND",code:"FQ"},
	{name:"BANGLADESH",code:"BG"}, 
	{name:"BARBADOS",code:"BB"},
	{name:"BARBUDA",code:"AC"},
	{name:"BASSAS DA INDIA",code:"BS"},
	{name:"BELARUS",code:"BO"},
	{name:"BELGIUM",code:"BE"},
	{name:"BELIZE",code:"BH"},
	{name:"BENIN",code:"BN"},
	{name:"BERMUDA",code:"BD"},
	{name:"BHUTAN",code:"BT"},
	{name:"BOLIVIA",code:"BL"},
	/*{name:"BOSNIA-HERCEGOVINA",code:"BK"},*/
	{name:"BOSNIA-HERZEGOVINA",code:"BK"},
	{name:"BOTSWANA",code:"BC"},
	{name:"BOUVET ISLAND",code:"BV"},
	{name:"BR INDIAN OCEAN TERR",code:"IO"},
	{name:"BR VIRGIN ISLANDS",code:"VI"},
	{name:"BRAZIL",code:"BR"},
	/*{name:"BRITISH VIRGIN ISLAN",code:"VI"},*/
	{name:"BRUNEI",code:"BX"},
	{name:"BULGARIA",code:"BU"},
	/*{name:"BURKINA",code:"UV"},*/
	{name:"BURKINA FASO",code:"UV"},
	/*{name:"BURMA",code:"BM"},*/
	{name:"BURUNDI",code:"BY"},
	{name:"CAICOS ISLANDS",code:"TK"},
	{name:"CAMBODIA",code:"CB"},
	{name:"CAMEROON",code:"CM"},
	{name:"CANADA",code:"CA"},
	{name:"CANARY ISLANDS",code:"SP"},
	{name:"CANTON ISLANDS",code:"KR"},
	{name:"CAPE VERDE",code:"CV"},
	{name:"CARTIER ISLAND",code:"AT"},
	{name:"CAYMAN ISLANDS",code:"CJ"},
	{name:"CENT AFRICAN REPUBL",code:"CT"},
	{name:"CHAD",code:"CD"},
	{name:"CHANNEL ISLANDS",code:"IM"},
	{name:"CHILE",code:"CI"},
	{name:"CHINA",code:"CH"},
	{name:"CHRISTMAS ISLAND",code:"KT"},
	{name:"CLIPPERTON ISLAND",code:"IP"},
	{name:"COCOS ISLANDS",code:"CK"},
	{name:"COLOMBIA",code:"CO"},
	{name:"COMOROS",code:"CN"},
	{name:"CONGO",code:"CF"},
	{name:"COOK ISLANDS",code:"CW"},
	{name:"CORAL SEA ISLANDS",code:"CR"},
	{name:"CORSICA",code:"VP"},
	{name:"COSTA RICA",code:"CS"},
	{name:"COTE D'IVOIRE",code:"IV"},
	{name:"CROATIA",code:"HR"},
	{name:"CUBA",code:"CU"},
	{name:"CYPRUS",code:"CY" },
	{name:"CZECH REPUBLIC",code:"EZ"},
	/*{name:"CZECHOSLOVAKIA",code:"EZ"},*/
	{name:"DENMARK",code:"DA"},
	{name:"DHEKELIA",code:"DX"},
	{name:"DJIBOUTI",code:"DJ"},
	{name:"DOMINICA",code:"DO"},
	{name:"DOMINICAN REPUBLIC",code:"DR"},
	/*{name:"EAST GERMANY",code:"GM"},*/
	{name:"EAST TIMOR",code:"TT"},
	{name:"ECUADOR",code:"EC"},
	{name:"EGYPT",code:"EG"},
	{name:"EL SALVADOR",code:"ES"},
	{name:"ELLICE ISLANDS",code:"TV"},
	/*{name:"ENGLAND",code:"UK"},*/
	{name:"EQUATORIAL GUINEA",code:"EK"},
	{name:"ERITREA",code:"ER"},
	{name:"ESTONIA",code:"EN"},
	{name:"ETHIOPIA",code:"ET"},
	{name:"EUROPA ISLAND",code:"EU"},
	{name:"EUROPEAN UNION",code:"EU"},
	{name:"FALKLAND ISLANDS",code:"FK"},
	{name:"FAROE ISLANDS",code:"FO"},
	{name:"FIJI",code:"FJ"},
	{name:"FINLAND",code:"FI"},
	{name:"FRANCE",code:"FR"},
	{name:"FRENCH GUIANA",code:"FG"},
	{name:"FRENCH POLYNESIA",code:"FP"},
	{name:"FRENCH SOUTHERN",code:"FS"},
	{name:"FUTUNA",code:"WF"},
	{name:"GABON",code:"GB"},
	{name:"GAMBIA",code:"GA"},
	{name:"GAMBIA, THE",code:"GA"},
	/*{name:"GAZA",code:"GZ"},*/
	{name:"GAZA STRIP",code:"GZ"},
	{name:"GEORGIA",code:"GG"},
	{name:"GERMANY",code:"GM"},
	{name:"GHANA",code:"GH"},
	{name:"GIBRALTAR",code:"GI"},
	{name:"GILBERT ISLANDS",code:"KR"},
	{name:"GLORIOSO ISLANDS",code:"GO"},
	/*{name:"GREAT BRITAIN",code:"UK"},*/
	{name:"GREECE",code:"GR"},
	{name:"GREENLAND",code:"GL"},
	{name:"GRENADA",code:"GJ"},
	{name:"GRENADINES",code:"VC"},
	{name:"GUADELOUPE",code:"GP"},
	{name:"GUAM",code:"GQ"},
	{name:"GUATEMALA",code:"GT"},
	{name:"GUERNSEY",code:"GK"},
	{name:"GUINEA",code:"GV"},
	{name:"GUINEA-BISSAU",code:"PU"},
	{name:"GUYANA",code:"GY"},
	{name:"HAITI",code:"HA"},
	{name:"HEARD ISLAND",code:"HM"},
	/*{name:"HOLLAND",code:"NL"},*/
	{name:"HOLY SEE",code:"VT"},
	{name:"HONDURAS",code:"HO"},
	{name:"HONG KONG",code:"HK"},
	/*{name:"HONGKONG",code:"HK"},*/
	{name:"HOWLAND ISLAND",code:"HQ"},
	{name:"HUNGARY",code:"HU"},
	{name:"ICELAND",code:"IC"},
	{name:"INDIA",code:"IN"},
	{name:"INDONESIA",code:"ID"},
	{name:"IRAN",code:"IR"},
	{name:"IRAQ",code:"IZ"},
	{name:"IRAQ-SAUDI ARABIA NZ",code:"IY"},
	{name:"IRELAND",code:"EI"},
	{name:"ISLE OF MAN",code:"IM"},
	{name:"ISRAEL",code:"IS"},
	{name:"ITALY",code:"IT"},
	{name:"IVORY COAST",code:"IV"},
	{name:"JAMAICA",code:"JM"},
	/*{name:"JAN MAYEN",code:"JN"},*/
	{name:"JAN MAYEN ISLAND",code:"JN"},
	{name:"JAPAN",code:"JA"},
	{name:"JERSEY",code:"JE"},
	{name:"JOHNSTON ATOLL",code:"JQ"},
	{name:"JORDAN",code:"JO"},
	{name:"JUAN DE NOVA",code:"JU"},
	/*{name:"KAMPUCHEA",code:"CB"},*/
	{name:"KAZAKHSTAN",code:"KZ"},
	{name:"KENYA",code:"KE"},
	{name:"KINGMAN REEF",code:"KQ"},
	{name:"KIRIBATI",code:"KR"},
	{name:"KOSOVO",code:"KV"},
	{name:"KUWAIT",code:"KU"},
	{name:"KYRGYZSTAN",code:"KG"},
	{name:"LAOS",code:"LA"},
	{name:"LATVIA",code:"LG"}, 
	{name:"LEBANON",code:"LE"},
	{name:"LESOTHO",code:"LT"},
	{name:"LIBERIA",code:"LI"},
	{name:"LIBYA",code:"LY"},
	{name:"LIECHTENSTEIN",code:"LS"},
	{name:"LITHUANIA",code:"LH"},
	{name:"LUXEMBOURG",code:"LU"},
	{name:"MACAO",code:"MC"},
	/*{name:"MACAU",code:"MC"},*/
	{name:"MACEDONIA",code:"MK"},
	{name:"MADAGASCAR",code:"MA"},
	{name:"MALAWI",code:"MI"},
	{name:"MALAYSIA",code:"MY"},
	{name:"MALDIVES",code:"MV"},
	{name:"MALI",code:"ML"},
	{name:"MALTA",code:"MT"},
	{name:"MARIANA ISLANDS",code:"CQ"},
	{name:"MARSHALL ISLANDS",code:"RM"},
	{name:"MARTINIQUE",code:"MB"},
	{name:"MAURITANIA",code:"MR"},
	{name:"MAURITIUS",code:"MP"},
	{name:"MAYOTTE",code:"MF"},
	{name:"MCDONALD ISLAND",code:"HM"},
	{name:"MEXICO",code:"MX"},
	{name:"MICRONESIA",code:"FM"},
	{name:"MIDWAY ISLANDS",code:"MQ"},
	{name:"MIQUELON",code:"SB"},
	{name:"MOLDOVA",code:"MD"},
	{name:"MONACO",code:"MN"},
	{name:"MONGOLIA",code:"MG"},
	{name:"MONTENEGRO",code:"MJ"},
	{name:"MONTSERRAT",code:"MH"},
	{name:"MOROCCO",code:"MO" },
	{name:"MOZAMBIQUE",code:"MZ"},
	{name:"NAMIBIA",code:"WA"},
	{name:"NAURU",code:"NR"},
	{name:"NAVASSA ISLAND",code:"BQ"},
	{name:"NEPAL",code:"NP"},
	{name:"NETHERLANDS",code:"NL"},
	{name:"NETHERLANDS ANTILLES",code:"NT"},
	{name:"NEVIS",code:"SC"},
	{name:"NEW CALEDONIA",code:"NC"},
	{name:"NEW HEBRIDES",code:"NH"},
	{name:"NEW ZEALAND",code:"NZ"},
	{name:"NICARAGUA",code:"NU"},
	{name:"NIGER",code:"NG"},
	{name:"NIGERIA",code:"NI"},
	{name:"NIUE",code:"NE"},
	{name:"NORFOLK ISLAND",code:"NF"},
	{name:"NORTH KOREA",code:"KN"},
	/*{name:"NORTH YEMEN",code:"YM"},*/
	/*{name:"NORTHERN IRELAND",code:"UK"}, */
	{name:"NORTHERN MARIANA",code:"CQ"},
	{name:"NORWAY",code:"NO"},
	{name:"OKINAWA",code:"JA"},
	{name:"OMAN",code:"MU"},
	{name:"OTHER",code:"OC"},
	/*{name:"OTHER COUNTRIES",code:"OC"},*/
	{name:"PAKISTAN",code:"PK"},
	{name:"PALAU",code:"PS"},
	{name:"PALMYRA ATOL",code:"LQ"},
	{name:"PANAMA",code:"PM"},
	{name:"PAPUA-NEW GUINEA",code:"PP"},
	{name:"PARACEL ISLANDS",code:"PF"},
	{name:"PARAGUAY",code:"PA"},
	{name:"PERU",code:"PE"},
	{name:"PHILIPPINES",code:"RP"},
	/*{name:"PITCAIRN",code:"PC"},*/
	{name:"PITCAIRN ISLAND",code:"PC"},
	{name:"POLAND",code:"PL"},
	{name:"PORTUGAL",code:"PO"},
	{name:"PORTUGUESE TIMOR",code:"ID"},
	{name:"PRINCIPE",code:"TP"},
	{name:"PUERTO RICO",code:"RQ"},
	{name:"QATAR",code:"QA"},
	/*{name:"REUNION",code:"RE"},*/
	{name:"REUNION ISLANDS",code:"RE"},
	/*{name:"RHODESIA",code:"ZI"},*/
	{name:"ROMANIA",code:"RO" },
	{name:"RUSSIA",code:"RS"},
	{name:"RWANDA",code:"RW"},
	{name:"SAMOA",code:"WS"},
	{name:"SAN MARINO",code:"SM"},
	{name:"SAO TOME",code:"TP"},
	{name:"SAUDI ARABIA",code:"SA"},
	/*{name:"SCOTLAND",code:"UK"},*/
	{name:"SENEGAL",code:"SG"},
	{name:"SERBIA",code:"RB"},
	{name:"SEYCHELLES",code:"SE"},
	{name:"SIERRA LEONE",code:"SL"},
	{name:"SINGAPORE",code:"SN"},
	{name:"SLOVAK REPUBLIC",code:"LO"},
	/*{name:"SLOVAKIA",code:"LO" },*/
	{name:"SLOVENIA",code:"SI"},
	{name:"SOLOMON ISLANDS",code:"BP"},
	{name:"SOMALIA",code:"SO"},
	{name:"SOUTH AFRICA",code:"SF"},
	{name:"SOUTH GEORGIA",code:"SX"},
	{name:"SOUTH KOREA",code:"KS"}, 
	/*{name:"SOUTH YEMEN",code:"YM"},*/
	/*{name:"SOUTHERN RHODESIA",code:"ZI"},*/
	{name:"SPAIN",code:"SP"},
	{name:"SPRATLY ISLANDS",code:"PG"},
	{name:"SRI LANKA",code:"CE"},
	{name:"ST BARTHELEMY",code:"TB"},
	{name:"ST CHRISTOPHER",code:"SC"},
	{name:"ST HELENA",code:"SH"},
	{name:"ST KITTS",code:"SC"},
	{name:"ST LUCIA",code:"ST"},
	{name:"ST MARTIN",code:"RN"},
	{name:"ST PIERRE",code:"SB"},
	{name:"ST THOMAS",code:"VQ"},
	{name:"ST VINCENT",code:"VC"},
	{name:"SUDAN",code:"SU"},
	{name:"SURINAME",code:"NS"},
	{name:"SVALBARD",code:"SV"},
	{name:"SWAZILAND",code:"WZ"},
	{name:"SWEDEN",code:"SW"},
	{name:"SWITZERLAND",code:"SZ"},
	{name:"SYRIA",code:"SY"},
	{name:"TAIWAN",code:"TW"},
	{name:"TAJIKISTAN",code:"TI"},
	{name:"TANZANIA",code:"TZ"},
	{name:"THAILAND",code:"TH"},
	{name:"TIMOR-LESTE",code:"TT"},
	{name:"TOBAGO",code:"TD"},
	{name:"TOGO",code:"TO"},
	{name:"TOKELAU",code:"TL"},
	{name:"TONGA",code:"TN"},
	{name:"TRINIDAD",code:"TD"},
	{name:"TROMELIN ISLAND",code:"TE"},
	{name:"TRUST TERR-PACIFIC",code:"PS"},
	{name:"TUNISIA",code:"TS"},
	{name:"TURKEY",code:"TU"},
	{name:"TURKMENISTAN",code:"TX"},
	{name:"TURKS ISLAND",code:"TK"},
	{name:"TUVALU",code:"TV"},
	{name:"UGANDA",code:"UG"},
	/*{name:"UK",code:"UK" },*/
	{name:"UKRAINE",code:"UP"},
	{name:"UNITED ARAB EMIRATES",code:"AE"},
	{name:"UNITED KINGDOM",code:"UK"},
	/*{name:"UNITED STATES",code:"US"},*/
	{name:"UPPER VOLTA ",code:"UV"},
	{name:"URUGUAY",code:"UY"},
	{name:"US VIRGIN ISLANDS",code:"VQ"},
	/*{name:"USSR",code:"RS"},*/
	{name:"UZBEKISTAN",code:"UZ"},
	{name:"VANUATU",code:"NH"},
	{name:"VATICAN CITY",code:"VT"},
	{name:"VENEZUELA",code:"VE"},
	{name:"VIETNAM",code:"VM"},
	{name:"WAKE ISLAND",code:"WQ"},
	{name:"WAES",code:"UK" },
	{name:"WALIS",code:"WF"},
	{name:"WEST BANK",code:"WE"},
	/*{name:"WEST GERMANY",code:"GM"},*/
	{name:"WESTERN SAHARA",code:"WI"},
	{name:"WESTERN SAMOA",code:"WS"},
	{name:"YEMEN",code:"YM"},
	{name:"ZAIRE",code:"CG"},
	{name:"ZAMBIA",code:"ZA"},
	{name:"ZIMBABWE",code:"ZI"}];
	dropdownList.USStateslist = [{"name":"Alabama","code":"AL"},
	                     {"name":"Alaska","code":"AK"},
	                     {"name":"Arizona","code":"AZ"},
	                     {"name":"Arkansas","code":"AR"},
	                     {"name":"California","code":"CA"},
	                     {"name":"Colorado","code":"CO"},
	                     {"name":"Connecticut","code":"CT"},
	                     {"name":"Delaware","code":"DE"},
	                     {"name":"Florida","code":"FL"},
	                     {"name":"Georgia","code":"GA"},
	                     {"name":"Hawaii","code":"HI"},
	                     {"name":"Idaho","code":"ID"},
	                     {"name":"Illinois","code":"IL"},
	                     {"name":"Indiana","code":"IN"},
	                     {"name":"Iowa","code":"IA"},
	                     {"name":"Kansas","code":"KS"},
	                     {"name":"Kentucky","code":"KY"},
	                     {"name":"Louisiana","code":"LA"},
	                     {"name":"Maine","code":"ME"},
	                     {"name":"Maryland","code":"MD"},
	                     {"name":"Massachusetts","code":"MA"},
	                     {"name":"Michigan","code":"MI"},
	                     {"name":"Minnesota","code":"MN"},
	                     {"name":"Mississippi","code":"MS"},
	                     {"name":"Missouri","code":"MO"},
	                     {"name":"Montana","code":"MT"},
	                     {"name":"Nebraska","code":"NE"},
	                     {"name":"Nevada","code":"NV"},
	                     {"name":"New Hampshire","code":"NH"},
	                     {"name":"New Jersey","code":"NJ"},
	                     {"name":"New Mexico","code":"NM"},
	                     {"name":"New York","code":"NY"},
	                     {"name":"North Carolina","code":"NC"},
	                     {"name":"North Dakota","code":"ND"},
	                     {"name":"Ohio","code":"OH"},
	                     {"name":"Oklahoma","code":"OK"},
	                     {"name":"Oregon","code":"OR"},
	                     {"name":"Pennsylvania","code":"PA"},
	                     {"name":"Rhode Island","code":"RI"},
	                     {"name":"South Carolina","code":"SC"},
	                     {"name":"South Dakota","code":"SD"},
	                     {"name":"Tennessee","code":"TN"},
	                     {"name":"Texas","code":"TX"},
	                     {"name":"Utah","code":"UT"},
	                     {"name":"Vermont","code":"VT"},
	                     {"name":"Virginia","code":"VA"},
	                     {"name":"Washington","code":"WA"},
	                     {"name":"West Virginia","code":"WV"},
	                     {"name":"Wisconsin","code":"WI"},
	                     {"name":"Wyoming","code":"WY"},
	                     
	                     
	                     {"name":"Washington, D.C.","code":"DC"},
	                     {"name":"American Samoa","code":"AS"},
	                     {"name":"Guam","code":"GU"},
	                     {"name":"Northern Mariana Islands","code":"MP"},
	                     {"name":"Puerto Rico","code":"PR"},
	                     {"name":"U.S. Virgin Islands","code":"VI"},
	                     {"name":"APO/FPO Military In Americas","code":"AA"},
	                     {"name":"APO/FPO Military In Europe","code":"AE"},
	                     {"name":"APO/FPO Military In Pacific","code":"AP"}
	                    ];
	dropdownList.canadaStateslist =[{"name":"ALBERTA","code":"AB"},{"name":"BRITISH COLUMBIA","code":"BC"},{"name":"MANITOBA","code":"MB"},{"name":"NEW BRUNSWICK","code":"NB"},{"name":"NEWFOUNDLAND AND LABRADOR","code":"NL"},{"name":"NOVA SCOTIA","code":"NS"},{"name":"ONTARIO","code":"ON"},{"name":"PRINCE EDWARD ISLAND","code":"PE"},{"name":"QUEBEC","code":"QC"},{"name":"SASKATCHEWAN","code":"SK"},{"name":"NORTHWEST TERRITORIES","code":"NT"},{"name":"NUNAVUT","code":"NU"},{"name":"YUKON","code":"YT"}];
	dropdownList.employerCountryList = [{ "name": "AFGHANISTAN", "code": "AF" }, { "name": "ALBANIA", "code": "AL" }, { "name": "ALGERIA", "code": "DZ" }, { "name": "AMERICAN SAMOA", "code": "AS" }, { "name": "ANDORRA", "code": "AD" }, { "name": "ANGOLA", "code": "AO" }, { "name": "ANGUILLA", "code": "AI" }, { "name": "ANTARCTICA", "code": "AQ" }, { "name": "ANTIGUA", "code": "AG" }, { "name": "ARGENTINA", "code": "AR" }, { "name": "ARMENIA", "code": "AM" }, { "name": "ARUBA", "code": "AW" }, { "name": "AUSTRALIA", "code": "AU" }, { "name": "AUSTRIA", "code": "AT" }, { "name": "AZERBAIJAN", "code": "AZ" }, { "name": "BAHAMAS, THE", "code": "BS" }, { "name": "BAHRAIN", "code": "BH" }, { "name": "BANGLADESH", "code": "BD" }, { "name": "BARBADOS", "code": "BB" }, { "name": "BELARUS", "code": "BY" }, { "name": "BELGIUM", "code": "BE" }, { "name": "BELIZE", "code": "BZ" }, { "name": "BENIN", "code": "BJ" }, { "name": "BERMUDA", "code": "BM" }, { "name": "BHUTAN", "code": "BT" }, { "name": "BOLIVIA", "code": "BO" }, { "name": "BOSNIA-HERZEGOVINA", "code": "BA" }, { "name": "BOTSWANA", "code": "BW" }, { "name": "BOUVET ISLAND", "code": "BV" }, { "name": "BR INDIAN OCEAN TERR", "code": "IO" }, { "name": "BRAZIL", "code": "BR" }, { "name": "BRUNEI", "code": "BN" }, { "name": "BULGARIA", "code": "BG" }, { "name": "BURKINA FASO", "code": "BF" }, { "name": "BURUNDI", "code": "BI" }, { "name": "CAMBODIA", "code": "KH" }, { "name": "CAMEROON", "code": "CM" }, { "name": "CANADA", "code": "CA" }, { "name": "CAPE VERDE", "code": "CV" }, { "name": "CAYMAN ISLANDS", "code": "KY" }, { "name": "CENT AFRICAN REPUBL", "code": "CF" }, { "name": "CHAD", "code": "TD" }, { "name": "CHILE", "code": "CL" }, { "name": "CHINA", "code": "CN" }, { "name": "CHRISTMAS ISLAND", "code": "CX" }, { "name": "COLOMBIA", "code": "CO" }, { "name": "COMOROS", "code": "KM" }, { "name": "CONGO", "code": "CG" }, { "name": "COOK ISLANDS", "code": "CK" }, { "name": "COSTA RICA", "code": "CR" }, { "name": "COTE DIVOIRE", "code": "CI" }, { "name": "CROATIA", "code": "HR" }, { "name": "CUBA", "code": "CU" }, { "name": "CYPRUS", "code": "CY" }, { "name": "CZECH REPUBLIC", "code": "CZ" }, { "name": "DENMARK", "code": "DK" }, { "name": "DJIBOUTI", "code": "DJ" }, { "name": "DOMINICA", "code": "DM" }, { "name": "DOMINICAN REPUBLIC", "code": "DO" }, { "name": "EAST TIMOR", "code": "TL" }, { "name": "ECUADOR", "code": "EC" }, { "name": "EGYPT", "code": "EG" }, { "name": "EL SALVADOR", "code": "SV" }, { "name": "EQUATORIAL GUINEA", "code": "GQ" }, { "name": "ERITREA", "code": "ER" }, { "name": "ESTONIA", "code": "EE" }, { "name": "ETHIOPIA", "code": "ET" }, { "name": "FALKLAND ISLANDS", "code": "FK" }, { "name": "FAROE ISLANDS", "code": "FO" }, { "name": "FIJI", "code": "FJ" }, { "name": "FINLAND", "code": "FI" }, { "name": "FRANCE", "code": "FR" }, { "name": "FRENCH GUIANA", "code": "GF" }, { "name": "FRENCH POLYNESIA", "code": "PF" }, { "name": "FRENCH SOUTHERN", "code": "TF" }, { "name": "GABON", "code": "GA" }, { "name": "GAMBIA", "code": "GM" }, { "name": "GEORGIA", "code": "GE" }, { "name": "GERMANY", "code": "DE" }, { "name": "GHANA", "code": "GH" }, { "name": "GIBRALTAR", "code": "GI" }, { "name": "GREECE", "code": "GR" }, { "name": "GREENLAND", "code": "GL" }, { "name": "GRENADA", "code": "GD" }, { "name": "GUADELOUPE", "code": "GP" }, { "name": "GUAM", "code": "GU" }, { "name": "GUATEMALA", "code": "GT" }, { "name": "GUINEA", "code": "GN" }, { "name": "GUINEA-BISSAU", "code": "GW" }, { "name": "GUYANA", "code": "GY" }, { "name": "HAITI", "code": "HT" }, { "name": "HEARD ISLAND", "code": "HM" }, { "name": "HONDURAS", "code": "HN" }, { "name": "HONG KONG", "code": "HK" }, { "name": "HUNGARY", "code": "HU" }, { "name": "ICELAND", "code": "IS" }, { "name": "INDIA", "code": "IN" }, { "name": "INDONESIA", "code": "ID" }, { "name": "IRAN", "code": "IR" }, { "name": "IRAQ", "code": "IQ" }, { "name": "IRELAND", "code": "IE" }, { "name": "ISRAEL", "code": "IL" }, { "name": "ITALY", "code": "IT" }, { "name": "JAMAICA", "code": "JM" }, { "name": "JAPAN", "code": "JP" }, { "name": "JORDAN", "code": "JO" }, { "name": "KAZAKHSTAN", "code": "KZ" }, { "name": "KENYA", "code": "KE" }, { "name": "KIRIBATI", "code": "KI" }, { "name": "KOREA", "code": "KP" }, { "name": "KUWAIT", "code": "KW" }, { "name": "KYRGYZSTAN", "code": "KG" }, { "name": "LAOS", "code": "LA" }, { "name": "LATVIA", "code": "LV" }, { "name": "LEBANON", "code": "LB" }, { "name": "LESOTHO", "code": "LS" }, { "name": "LIBERIA", "code": "LR" }, { "name": "LIBYA", "code": "LY" }, { "name": "LIECHTENSTEIN", "code": "LI" }, { "name": "LITHUANIA", "code": "LT" }, { "name": "LUXEMBOURG", "code": "LU" }, { "name": "MACEDONIA", "code": "MK" }, { "name": "MADAGASCAR", "code": "MG" }, { "name": "MALAWI", "code": "MW" }, { "name": "MALAYSIA", "code": "MY" }, { "name": "MALDIVES", "code": "MV" }, { "name": "MALI", "code": "ML" }, { "name": "MALTA", "code": "MT" }, { "name": "MARIANA ISLANDS", "code": "MP" }, { "name": "MARSHALL ISLANDS", "code": "MH" }, { "name": "MARTINIQUE", "code": "MQ" }, { "name": "MAURITANIA", "code": "MR" }, { "name": "MAURITIUS", "code": "MU" }, { "name": "MAYOTTE", "code": "YT" }, { "name": "MEXICO", "code": "MX" }, { "name": "MICRONESIA", "code": "FM" }, { "name": "MOLDOVA", "code": "MD" }, { "name": "MONACO", "code": "MC" }, { "name": "MONGOLIA", "code": "MN" }, { "name": "MONTSERRAT", "code": "MS" }, { "name": "MOROCCO", "code": "MA" }, { "name": "MOZAMBIQUE", "code": "MZ" }, { "name": "NAMIBIA", "code": "NA" }, { "name": "NAURU", "code": "NR" }, { "name": "NEPAL", "code": "NP" }, { "name": "NETHERLANDS", "code": "NL" }, { "name": "NETHERLANDS ANTILLES", "code": "AN" }, { "name": "NEW CALEDONIA", "code": "NC" }, { "name": "NEW ZEALAND", "code": "NZ" }, { "name": "NICARAGUA", "code": "NI" }, { "name": "NIGER", "code": "NE" }, { "name": "NIGERIA", "code": "NG" }, { "name": "NIUE", "code": "NU" }, { "name": "NORFOLK ISLAND", "code": "NF" }, { "name": "NORWAY", "code": "NO" }, { "name": "OMAN", "code": "OM" }, { "name": "PAKISTAN", "code": "PK" }, { "name": "PALAU", "code": "PW" }, { "name": "PANAMA", "code": "PA" }, { "name": "PAPUA-NEW GUINEA", "code": "PG" }, { "name": "PARAGUAY", "code": "PY" }, { "name": "PERU", "code": "PE" }, { "name": "PHILIPPINES", "code": "PH" }, { "name": "PITCAIRN", "code": "PC" }, { "name": "POLAND", "code": "PL" }, { "name": "PORTUGAL", "code": "PT" }, { "name": "PUERTO RICO", "code": "PR" }, { "name": "QATAR", "code": "QA" }, { "name": "REUNION", "code": "RE" }, { "name": "ROMANIA", "code": "RO" }, { "name": "RUSSIA", "code": "RU" }, { "name": "RWANDA", "code": "RW" }, { "name": "SAN MARINO", "code": "SM" }, { "name": "SAO TOME", "code": "ST" }, { "name": "SAUDI ARABIA", "code": "SA" }, { "name": "SENEGAL", "code": "SN" }, { "name": "SEYCHELLES", "code": "SC" }, { "name": "SIERRA LEONE", "code": "SL" }, { "name": "SINGAPORE", "code": "SG" }, { "name": "SLOVAKIA", "code": "SK" }, { "name": "SLOVENIA", "code": "SI" }, { "name": "SOLOMON ISLANDS", "code": "SB" }, { "name": "SOMALIA", "code": "SO" }, { "name": "SOUTH AFRICA", "code": "ZA" }, { "name": "SOUTH GEORGIA", "code": "GS" }, { "name": "SOUTH KOREA", "code": "KR" }, { "name": "SPAIN", "code": "ES" }, { "name": "SRI LANKA", "code": "LK" }, { "name": "ST HELENA", "code": "SH" }, { "name": "ST KITTS", "code": "KN" }, { "name": "ST LUCIA", "code": "LC" }, { "name": "ST PIERRE", "code": "PM" }, { "name": "ST VINCENT", "code": "VC" }, { "name": "SUDAN", "code": "SD" }, { "name": "SURINAME", "code": "SR" }, { "name": "SVALBARD", "code": "SJ" }, { "name": "SWAZILAND", "code": "SZ" }, { "name": "SWEDEN", "code": "SE" }, { "name": "SWITZERLAND", "code": "CH" }, { "name": "SYRIA", "code": "SY" }, { "name": "TAIWAN", "code": "TW" }, { "name": "TAJIKISTAN", "code": "TJ" }, { "name": "TANZANIA", "code": "TZ" }, { "name": "THAILAND", "code": "TH" }, { "name": "TOGO", "code": "TG" }, { "name": "TOKELAU", "code": "TK" }, { "name": "TONGA", "code": "TO" }, { "name": "TRINIDAD AND TOBAGO", "code": "TT" }, { "name": "TUNISIA", "code": "TN" }, { "name": "TURKEY", "code": "TR" }, { "name": "TURKMENISTAN", "code": "TM" }, { "name": "TURKS ISLAND", "code": "TC" }, { "name": "TUVALU", "code": "TV" }, { "name": "UGANDA", "code": "UG" }, { "name": "UKRAINE", "code": "UA" }, { "name": "UNITED ARAB EMIRATES", "code": "AE" }, { "name": "UNITED KINGDOM", "code": "GB" }, { "name": "URUGUAY", "code": "UY" }, { "name": "US VIRGIN ISLANDS", "code": "VI" }, { "name": "USA", "code": "US" }, { "name": "UZBEKISTAN", "code": "UZ" }, { "name": "VANUATU", "code": "VU" }, { "name": "VATICAN CITY", "code": "VA" }, { "name": "VENEZUELA", "code": "VE" }, { "name": "VIETNAM", "code": "VN" }, { "name": "WALLIS", "code": "WF" }, { "name": "WESTERN SAHARA", "code": "EH" }, { "name": "YEMEN", "code": "YE" }, { "name": "YUGOSLAVIA", "code": "YU" }, { "name": "ZAIRE", "code": "CD" }, { "name": "ZAMBIA", "code": "ZM" }, { "name": "ZIMBABWE", "code": "ZW" }];
	dropdownList.timeList = [{ "Alpha Time Zone": "A", "Australian Central Daylight Time": "ACDT", "Australian Central Standard Time": "ACST", "Atlantic Daylight Time": "ADT", "Australian Eastern Daylight Time": "AEDT", "Australian Eastern Standard Time": "AEST", "Afghanistan Time": "AFT", "Alaska Daylight Time": "AKDT", "Alaska Standard Time": "AKST", "Alma-Ata Time": "ALMT", "Armenia Summer Time": "AMST", "Amazon Summer Time": "AMST", "Armenia Time": "AMT", "Amazon Time": "AMT", "Anadyr Summer Time": "ANAST", "Anadyr Time": "ANAT", "Aqtobe Time": "AQTT", "Argentina Time": "ART", "Arabia Standard Time": "AST", "Atlantic Standard Time": "AST", "Australian Western Daylight Time": "AWDT", "Australian Western Standard Time": "AWST", "Azores Summer Time": "AZOST", "Azores Time": "AZOT", "Azerbaijan Summer Time": "AZST", "Azerbaijan Time": "AZT", "Bravo Time Zone": "B", "Brunei Darussalam Time": "BNT", "Bolivia Time": "BOT", "Brasilia Summer Time": "BRST", "Brasília time": "BRT", "Bangladesh Standard Time": "BST", "British Summer Time": "BST", "Bhutan Time": "BTT", "Charlie Time Zone": "C", "Casey Time": "CAST", "Central Africa Time": "CAT", "Cocos Islands Time": "CCT", "Cuba Daylight Time": "CDT", "Central Daylight Time": "CDT", "Central European Summer Time": "CEST", "Central European Time": "CET", "Chatham Island Daylight Time": "CHADT", "Chatham Island Standard Time": "CHAST", "Cook Island Time": "CKT", "Chile Summer Time": "CLST", "Chile Standard Time": "CLT", "Colombia Time": "COT", "China Standard Time": "CST", "Central Standard Time": "CST", "Cuba Standard Time": "CST", "Cape Verde Time": "CVT", "Christmas Island Time": "CXT", "Chamorro Standard Time": "ChST", "Delta Time Zone": "D", "Davis Time": "DAVT", "Echo Time Zone": "E", "Easter Island Summer Time": "EASST", "Easter Island Standard Time": "EAST", "Eastern Africa Time": "EAT", "East Africa Time": "EAT", "Ecuador Time": "ECT", "Eastern Daylight Time": "EDT", "Eastern European Summer Time": "EEST", "Eastern European Time": "EET", "Eastern Greenland Summer Time": "EGST", "East Greenland Time": "EGT", "Eastern Standard Time": "EST", "Tiempo del Este": "ET", "Tiempo Del Este ": "ET", "Foxtrot Time Zone": "F", "Fiji Summer Time": "FJST", "Fiji Time": "FJT", "Falkland Islands Summer Time": "FKST", "Falkland Island Time": "FKT", "Fernando de Noronha Time": "FNT", "Golf Time Zone": "G", "Galapagos Time": "GALT", "Gambier Time": "GAMT", "Georgia Standard Time": "GET", "French Guiana Time": "GFT", "Gilbert Island Time": "GILT", "Greenwich Mean Time": "GMT", "Gulf Standard Time": "GST", "Guyana Time": "GYT", "Hotel Time Zone": "H", "Heure Avancée de l'Atlantique": "HAA", "Heure Avancée du Centre": "HAC", "Hawaii-Aleutian Daylight Time": "HADT", "Heure Avancée de l'Est ": "HAE", "Heure Avancée du Pacifique": "HAP", "Heure Avancée des Rocheuses": "HAR", "Hawaii-Aleutian Standard Time": "HAST", "Heure Avancée de Terre-Neuve": "HAT", "Heure Avancée du Yukon": "HAY", "Hong Kong Time": "HKT", "Hora Legal de Venezuela": "HLV", "Heure Normale de l'Atlantique": "HNA", "Heure Normale du Centre": "HNC", "Heure Normale de l'Est": "HNE", "Heure Normale du Pacifique": "HNP", "Heure Normale des Rocheuses": "HNR", "Heure Normale de Terre-Neuve": "HNT", "Heure Normale du Yukon": "HNY", "Hovd Time": "HOVT", "India Time Zone": "I", "Indochina Time": "ICT", "Israel Daylight Time": "IDT", "Indian Chagos Time": "IOT", "Iran Daylight Time": "IRDT", "Irkutsk Summer Time": "IRKST", "Irkutsk Time": "IRKT", "Iran Standard Time": "IRST", "Israel Standard Time": "IST", "India Standard Time": "IST", "Irish Standard Time": "IST", "Japan Standard Time": "JST", "Kilo Time Zone": "K", "Kyrgyzstan Time": "KGT", "Krasnoyarsk Summer Time": "KRAST", "Krasnoyarsk Time": "KRAT", "Korea Standard Time": "KST", "Kuybyshev Time": "KUYT", "Lima Time Zone": "L", "Lord Howe Daylight Time": "LHDT", "Lord Howe Standard Time": "LHST", "Line Islands Time": "LINT", "Mike Time Zone": "M", "Magadan Summer Time": "MAGST", "Magadan Time": "MAGT", "Marquesas Time": "MART", "Mawson Time": "MAWT", "Mountain Daylight Time": "MDT", "Mitteleuropäische Sommerzeit": "MESZ", "Mitteleuropäische Zeit": "MEZ", "Marshall Islands Time": "MHT", "Myanmar Time": "MMT", "Moscow Daylight Time": "MSD", "Moscow Standard Time": "MSK", "Mountain Standard Time": "MST", "Mauritius Time": "MUT", "Maldives Time": "MVT", "Malaysia Time": "MYT", "November Time Zone": "N", "New Caledonia Time": "NCT", "Newfoundland Daylight Time": "NDT", "Norfolk Time": "NFT", "Novosibirsk Summer Time": "NOVST", "Novosibirsk Time": "NOVT", "Nepal Time ": "NPT", "Newfoundland Standard Time": "NST", "Niue Time": "NUT", "New Zealand Daylight Time": "NZDT", "New Zealand Standard Time": "NZST", "Oscar Time Zone": "O", "Omsk Summer Time": "OMSST", "Omsk Standard Time": "OMST", "Papa Time Zone": "P", "Pacific Daylight Time": "PDT", "Peru Time": "PET", "Kamchatka Summer Time": "PETST", "Kamchatka Time": "PETT", "Papua New Guinea Time": "PGT", "Phoenix Island Time": "PHOT", "Philippine Time": "PHT", "Pakistan Standard Time": "PKT", "Pierre &amp; Miquelon Daylight Time": "PMDT", "Pierre &amp; Miquelon Standard Time": "PMST", "Pohnpei Standard Time": "PONT", "Pacific Standard Time": "PST", "Pitcairn Standard Time": "PST", "Tiempo del Pacífico": "PT", "Palau Time": "PWT", "Paraguay Summer Time": "PYST", "Paraguay Time": "PYT", "Quebec Time Zone": "Q", "Romeo Time Zone": "R", "Reunion Time": "RET", "Sierra Time Zone": "S", "Samara Time": "SAMT", "South Africa Standard Time": "SAST", "Solomon IslandsTime": "SBT", "Seychelles Time": "SCT", "Singapore Time": "SGT", "Suriname Time": "SRT", "Samoa Standard Time": "SST", "Tango Time Zone": "T", "Tahiti Time": "TAHT", "French Southern and Antarctic Time": "TFT", "Tajikistan Time": "TJT", "Tokelau Time": "TKT", "East Timor Time": "TLT", "Turkmenistan Time": "TMT", "Tuvalu Time": "TVT", "Uniform Time Zone": "U", "Ulaanbaatar Time": "ULAT", "Coordinated Universal Time": "UTC", "Uruguay Summer Time": "UYST", "Uruguay Time": "UYT", "Uzbekistan Time": "UZT", "Victor Time Zone": "V", "Venezuelan Standard Time": "VET", "Vladivostok Summer Time": "VLAST", "Vladivostok Time": "VLAT", "Vanuatu Time": "VUT", "Whiskey Time Zone": "W", "West Africa Summer Time": "WAST", "West Africa Time": "WAT", "Western European Summer Time": "WEST", "Westeuropäische Sommerzeit": "WESZ", "Western European Time": "WET", "Westeuropäische Zeit": "WEZ", "Wallis and Futuna Time": "WFT", "Western Greenland Summer Time": "WGST", "West Greenland Time": "WGT", "Western Indonesian Time": "WIB", "Eastern Indonesian Time": "WIT", "Central Indonesian Time": "WITA", "Western Sahara Summer Time": "WST", "West Samoa Time": "WST", "Western Sahara Standard Time": "WT", "X-ray Time Zone": "X", "Yankee Time Zone": "Y", "Yakutsk Summer Time": "YAKST", "Yakutsk Time": "YAKT", "Yap Time": "YAPT", "Yekaterinburg Summer Time": "YEKST", " Yekaterinburg Time": "YEKT", "Local Standard Time": "LST", "Zulu Time Zone": "Z" }];

	return dropdownList;
});
