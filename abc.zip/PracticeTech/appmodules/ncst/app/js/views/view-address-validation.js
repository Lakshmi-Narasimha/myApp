
define(
		[ 'text!appmodules/ncst/app/templates/addressValidation.html','appmodules/ncst/app/js/lib/validate-4.2' ,'appmodules/ncst/app/js/utils','appmodules/ncst/app/js/models/model-address-entry','appmodules/ncst/app/js/models/model-client', 'appcommon/analytics'],
		function(Template,Validator,Utils,AddressModel,ClientModel, Analytics ) {
			var ClientInfoModel = 	ClientModel.get('clientInfo');
			var viewAddressValidation = Backbone.View
					.extend({
						el : '#ncst-app',
						statsTemplate : _.template(Template),
						initialize : function() {
							this.$main = this.$('#client-info');
						},
						events : {
							'click #back-to-step2,#m-back-to-step2' : 'navigateToStep2',
							'click #step3-next-button,#m-step3-next-button': 'navigateToStep4',
							'change #validate-address-confirm-check' : 'displayAddrCheckResponse',
							'change #mail-validate-address-confirm-check' : 'mailDisplayAddrCheckResponse',
							'keypress #address-entry input':'changeAddressEntries',
							"click .sad-text.sad-step3":"handleSAD"
						},
					handleSAD:function(){
						Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
						Utils.lockForm();
						ClientModel.createDraft().done(function(response){
							Utils.unlockForm();
							ClientModel.showDraftSaveSuccesMessage(response);
						}).fail(function(error){
							Utils.unlockForm();
							Utils.showDraftSaveErrorMessage();
							console.log(error,"error");
						});
					},
						render : function() {
							//console.log(AddressModel);
							var _data = AddressModel.toJSON();
							_data.client = ClientModel;
							this.$main.html(this.statsTemplate(_data));
							
						},
						clearView : function(){
							this.undelegateEvents();// Unbind all local event bindings
							this.model.unbind( 'change', this.render, this ); // Unbind reference to the model
						},
						afterRender : function() {
							var _pChkBx=$('#validate-address-confirm-check').is(':visible');
							var _mChkBx=$('#mail-validate-address-confirm-check').is(':visible');
							AddressModel.set('pChkBx',_pChkBx);
							AddressModel.set('mChkBx',_mChkBx);
							//console.log('view address validattion');
							//console.log("after render");
							//console.log(AddressModel);
							var clientType = ClientInfoModel.get('clientType');
							// Deciding if Person or entity
							if (clientType == "P") {
								$('.entity-field').addClass('hidden');
								$('.person-field').removeClass('hidden');
							} else {
								$('.entity-field').removeClass('hidden');
								$('.person-field').addClass('hidden');
							}
							if(AddressModel.get('clientAddressCheck')){
								$('#validate-display').show();
							}
							else{
								$('#validate-display').hide();	
							}
							if(AddressModel.get('mailClientAddressCheck')){
								$('#mail-validate-display').show();
							}
							else{
								$('#mail-validate-display').hide();	
							}

							if (ClientModel.get('clientCreated') == 'failed') {
								this.validateStep3Form();
							}
						},
						navigateToStep2 : function() {
							$('.ncst-step.step2').find('.step-nav-links').click();
						},
						navigateToStep4 : function() {
							var _checkChkBoxes = true;
							var _pBx=true;
							var _mBx=true;
							var _pChkBx=$('#validate-address-confirm-check').is(':visible');
							var _mChkBx=$('#mail-validate-address-confirm-check').is(':visible');
								// validation for check box selection of client address when address is invalid
									if(_pChkBx){
										if ($('#validate-address-confirm-check').prop('checked') == true) {
											_pBx=true;
											$("#error-msg-address-chk").addClass("hidden");
											$("#client-addr-verification-check").removeClass("error");
										}
									else{
										_pBx=false;
	                                         $("#client-addr-verification-check").addClass("error");//to show error div in light red color
	                                         $("#error-msg-address-chk").removeClass("hidden");//to show error message in red letters
	                                               }
									}
									if(_mChkBx){
										if ($('#mail-validate-address-confirm-check').prop('checked') == true) {
											_mBx=true;
											$("#mail-error-msg-address-chk").addClass("hidden");
											$("#mail-client-addr-verification-check").removeClass("error");
										}
										else{
											_mBx=false;
		                                         $("#mail-client-addr-verification-check").addClass("error");//to show error div in light red color
		                                         $("#mail-error-msg-address-chk").removeClass("hidden");//to show error message in red letters
		                                               }
									}
									_checkChkBoxes=(_pBx && _mBx);
									if(_checkChkBoxes){
										console.log(_checkChkBoxes+"chk bx final");
										$('.ncst-step.step4').find('.step-nav-links').click();
										}
									this.sendEventsToAnalytics(_pBx);
						},
						sendEventsToAnalytics : function(correctClientAddressChecked) {
							if (correctClientAddressChecked) {
								Analytics.analytics.recordSharedSuiteAction('ncstClientAddressValidationCorrectClientAddressChecked:' + correctClientAddressChecked);
							}						
						},
						validateStep3Form:function(){
							var _checkChkBoxes = true;
							var _pBx=true;
							var _mBx=true;
							var _pChkBx=$('#validate-address-confirm-check').is(':visible');
							var _mChkBx=$('#mail-validate-address-confirm-check').is(':visible');
							if(_pChkBx){
								if ($('#validate-address-confirm-check').prop('checked') == true) {
									_pBx=true;
									$("#error-msg-address-chk").addClass("hidden");
									$("#client-addr-verification-check").removeClass("error");
								}
							else{
								_pBx=false;
                                $("#client-addr-verification-check").addClass("error");//to show error div in light red color
                                $("#error-msg-address-chk").removeClass("hidden");//to show error message in red letters
                                           }
							}
							if(_mChkBx){
								if ($('#mail-validate-address-confirm-check').prop('checked') == true) {
									_mBx=true;
									$("#mail-error-msg-address-chk").addClass("hidden");
									$("#mail-client-addr-verification-check").removeClass("error");
								}
							else{
								_mBx=false;
                                $("#mail-client-addr-verification-check").addClass("error");//to show error div in light red color
                                $("#mail-error-msg-address-chk").removeClass("hidden");//to show error message in red letters
                                           }
							}
						},
						handlerForCancel : function() {
							BootstrapDialog
									.confirm(
											"Cancel",
											"All your work will be lost.  Are you sure you want to cancel?",
											function(confirm) {
												if (confirm) {
													window.open('', '_self');
													window.close();
												}
											});

						},
						displayAddrCheckResponse:function(){
                            if ($('#validate-address-confirm-check').prop('checked') == true) {
                                               this.model.set('clientAddressCheck', true);
                                         	  $("#error-msg-address-chk").addClass("hidden");
                                               $("#client-addr-verification-check").removeClass("error");
                                               $('#validate-display').show();//This text is shown just after checkbox selection
                                              $(".ncst-valid-label-value-check").removeClass("error");
                            				}							
                            	else {
                            		this.model.set('clientAddressCheck', false);
                            		  $('#validate-display').hide();
                            		}
                          },
                          mailDisplayAddrCheckResponse:function(){
                              if ($('#mail-validate-address-confirm-check').prop('checked') == true) {
                                                 this.model.set('mailClientAddressCheck', true);
                                           	  $("#mail-error-msg-address-chk").addClass("hidden");
                                                 $("#mail-client-addr-verification-check").removeClass("error");
                                                 $('#mail-validate-display').show();//This text is shown just after checkbox selection
                                                $(".mail-ncst-valid-label-value-check").removeClass("error");
                              				}							
                              	else {
                              		this.model.set('mailClientAddressCheck', false);
                              		  $('#mail-validate-display').hide();
                              		}
                            },
                          changeAddressEntries:function(){
                        	  ClientModel.set('stepsCompleted', Utils
  									.arraySplice(ClientModel
  											.get('stepsCompleted'), 'address-validation'));
  							$('.ncst-step.step3').removeClass(
  									'active  finished').addClass('pending');
                        	  this.model.set('clientAddressCheck', false);
                        	  this.model.set('mailClientAddressCheck', false);
                        	  $("#validate-address-confirm-check").prop('checked',false);
                        	  $("#mail-validate-address-confirm-check").prop('checked',false);
                          }
					});
			return viewAddressValidation;
		});