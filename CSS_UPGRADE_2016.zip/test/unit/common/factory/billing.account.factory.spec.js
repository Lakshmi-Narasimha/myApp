(function() {

    'use strict';

    describe('Billing account Factory', function() {
        var billingFactory, billingUtils, rootScope, $httpBackend;;

        beforeEach(module('CSS.billing'));

        beforeEach(inject(function(billingUtils, $rootScope, $injector) {
            billingFactory = billingUtils;
            rootScope = $rootScope;
            $httpBackend = $injector.get('$httpBackend');

        }));

        it('factory should be defined...', function() {
            expect(billingFactory).toBeDefined();
        });

        it('parseList should be defined...', function() {
            expect(billingFactory.setPaymentMethodDetails).toBeDefined();
        });

        it('get parse payment methods list...', function() {
            var dataObj = {"cardHolderNickName":null,"cardNumber":"370037786616171","creditOrDebit":null,"cardType":null,"expMonth":5,"expYear":2020,"cardHolderName":"aaa","zipCode":"12121","termscheck":null,"bankOrCard":"card","cardcategory":"AX","indicatorForAddOrEditPaymentMethod":"A","bankAccountHolderNickName":null,"bankAccountType":null,"routingnumber":null,"accountNumber":null,"accountHolderName":null};

            billingFactory.setPaymentMethodDetails(dataObj, function(data) {
                expect(data).toBeDefined();
                expect(data.isCard).tobeTruthy();
                expect(data.cardCategoryDisplay).toEqual("ax");
            });
        });

        it('get parse payment methods list...', function() {
            var dataObj = {
                "cardHolderNickName":null,
                "cardNumber":"370037786616171",
                "creditOrDebit":null,
                "cardType":null,
                "expMonth":5,
                "expYear":2020,
                "cardHolderName":"aaa",
                "zipCode":"12121",
                "termscheck":null,
                "bankOrCard":"card",
                "cardcategory":"AX",
                "indicatorForAddOrEditPaymentMethod":"A",
                "bankAccountHolderNickName":null,
                "bankAccountType":null,
                "routingnumber":null,
                "accountNumber":null,
                "accountHolderName":null
            };

            billingFactory.parseList(dataObj, function(data) {
                expect(data).toBeDefined();
                expect(data.cardCategoryDisplay).toEqual("ax");
            });
        });

        it('billingData should be defined and set billing data...', function() {
            var input = {'zipCode':'12121'};
            expect(billingFactory.setBillingData).toBeDefined();
            billingFactory.setBillingData(input);
            expect(billingFactory.getBillingData()).toEqual(input);
        });

        it('get parse payment methods list...', function() {
            var dataObj = {
                "cardHolderNickName":null,
                "cardNumber":"370037786616171",
                "creditOrDebit":null,
                "cardType":null,
                "expMonth":5,
                "expYear":2020,
                "cardHolderName":"aaa",
                "zipCode":"12121",
                "termscheck":null,
                "bankOrCard":"bank",
                "cardcategory":"AX",
                "indicatorForAddOrEditPaymentMethod":"A",
                "bankAccountHolderNickName":null,
                "bankAccountType":null,
                "routingnumber":null,
                "accountNumber":null,
                "accountHolderName":null
            };

            billingFactory.parseList(dataObj, function(data) {
                expect(data).toBeDefined();
                expect(data.cardCategoryDisplay).toBeNull();
            });
        });

        it('get parse payment methods list...', function() {
            var dataObj = {
                "cardHolderNickName":null,
                "cardNumber": null,
                "creditOrDebit":null,
                "cardType":null,
                "expMonth":5,
                "expYear":2020,
                "cardHolderName":"aaa",
                "zipCode":"12121",
                "termscheck":null,
                "bankOrCard":"bank",
                "cardcategory":"AX",
                "indicatorForAddOrEditPaymentMethod":"A",
                "bankAccountHolderNickName":"RAGHUREDDY",
                "bankAccountType":null,
                "routingnumber":null,
                "accountNumber":"AND12345",
                "accountHolderName":"RAM"
            };

            billingFactory.parseList(dataObj, function(data) {
                expect(data).toBeDefined();
                expect(data.cardCategoryDisplay).toBeNull();
            });
        });
    });

})();
