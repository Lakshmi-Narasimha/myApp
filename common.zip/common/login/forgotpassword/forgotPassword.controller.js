/**
 * @ngdoc property
 * @name Forgot Password controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Forgot password controller for guest module.
 *
 **/



'use strict';
function forgotPasswordController($scope, $state, constants, advisorRegistrationModelService, fticStateChange) {
    $scope.forgotType = 'password';
    advisorRegistrationModelService.setUserForgotTypeDetails($scope.forgotType);
    $scope.headingObj = {
        text: constants.login.FORGOTTEN_PASSWORD //'Forgotten Password'
    };
    $scope.$on('investorfpSelected', function() {
        fticStateChange.stateChange($state, 'loginmaster.forgotpassword.investor');
        //$state.go('loginmaster.forgotpassword.investor');

    });
    $scope.$on('distributorSelected', function() {
        fticStateChange.stateChange($state, 'loginmaster.forgotpassword.distributor');
        //$state.go('loginmaster.forgotpassword.distributor');
    });
    $scope.$emit('setBreadCrumb', {
        cat: 'forgotpwd',
        breadCrumb: {
            label: 'Forgot Password',
            state: ''
        }
    });

}

forgotPasswordController.$inject = ['$scope', '$state', 'constants', 'advisorRegistrationModelService', 'fticStateChange'];
module.exports = forgotPasswordController;
