/**
 * @ngdoc service
 * @name Common User
 * @requires $state
 * @requires $localStorage
 * @requires Restangular
 * @description
 *
 * - For Authentication calls, setting and getting the user session and details 
 *
 */
var authenticationService = function($q, $state, $localStorage, Restangular, $http, constants, appConfig, configUrlModel, $rootElement, $cookies) {
    
    var _user = {guId:'878',userType:'10'};
//     var _user = null;
    var _authenticated = false;
    var _deviceId = null;
    var _role = 0;
    var mine = {};
    var invDashboardDetails = null;
    mine = {
        isUserResolved: function () {
            return angular.isDefined(_user);
        },

        isAuthenticated: function () {
            // this.checkIsAlive();
            return _authenticated;
        },

        getUser: function () {
            if (!angular.isDefined(_user)) {
                return null;
            }
            return _user;
        },

        isInvestorLoggedIn: function() {
            var userType = this.getUser() && this.getUser().userType || null;
            return userType && (userType.toString() === '10');
        },

        setUser: function (user) {
            _user = user;
        },

        checkIsAlive: function () {

            _user = $localStorage.user || null;
            
            if(_user) {
                return true;
            }
            return false;


        },
        getAppName:function(){
            return $rootElement.attr('ng-app');
        },
        authenticate: function (username, password) {
            console.log('UserFactory');
            _user = null;
            _authenticated = false;

            var deferred = $q.defer();
            var creds = {'userId':username,'password':password};
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL]+'generateToken', creds).then( function (data) {
                deferred.resolve(data);
            }, function (data) {
                console.log('Login error', data);
                deferred.reject(data);
            });
            /*Restangular.one('login').post("", creds).then(function (data) {
                console.log(data);
                if(data.status==100) _authenticated = true;
                deferred.resolve(data);
            }, function (data) {
                console.log('error');
                deferred.reject(_user);
            });*/

            /*var promise = HttpsCall.process(ApiConstants.APIs.SampleInfo);

            promise.then(function (data) {
                console.log(data);
                var success = false; // ApiConstants.Functions.isValue(data);
                _user = data;
                if (!success) {
                    _authenticated = true;
                    //$localStorage.user = _user;
                }
                else {
                    
                }
                deferred.resolve(_user);
            }, function (data) {
                deferred.reject(_user);
            });*/

            return deferred.promise;
        },
        authorize: function () {
            //var deferred = $q.defer();
            //var promise = this.checkIsAlive()
            //    .then(function (data) {
            //        console.log(data);
            //        promise.resolve(data);
            //    });
            //return deferred.promise;
            return this.checkIsAlive();
        },
        logout : function (params) {
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('PROXY_URL');
            $http.post(appConfig[configURL]+'logOut', params).then( function (data) {
                console.log('Logout success', data)
                deferred.resolve(data);
            }, function (data) {
                console.log('Logout error', data);
                deferred.reject(data);
            });
            return deferred.promise;
        },

        removeUserCookies : function () {
            $cookies.remove('accessToken', {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove('guId', {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove('userType', {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove('userRedirectURI', {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove('userId', {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove("userFeedbackStatus", {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove("usersysId", {'domain': appConfig.DOMAIN_CONFIG});
            $cookies.remove("reloadFired", {'domain': appConfig.DOMAIN_CONFIG});
        },

        checkUserFeedback: function () {
            var deferred = $q.defer();
            var configURL = configUrlModel.getEnvUrl('AUTH_REST_ENDPOINT_BASEURL');
            var params = {"guId": $cookies.get("guId")};
            Restangular.one('services/checkUserFeedback').get(params).then(function (data) {
                deferred.resolve(data);
            }, function (data) {
                deferred.reject(data);
            });
            return deferred.promise;
        },
        clearAllCookies : function () {
            var cookies = ['guId', 'mobile', 'emailId', 'otpFlag', 'otpType', 'refNo', 'accessToken', 'panARN', 'distId', 'secretQtn', 'pan', 'userType', 'userId', 'kycStatus', 'name', 'userFeedbackStatus', 'usersysId', 'reloadFired', 'userRedirectURI'];//$cookies.getAll();
            angular.forEach(cookies, function (v, k) {
                $cookies.remove(k, {'domain': appConfig.DOMAIN_CONFIG});
            });
        },
        
        setCookies : function () {
            this.setUser({
                "accessToken": $cookies.get('accessToken'),
                "guId": $cookies.get('guId'),
                "userType": $cookies.get('userType'),
                "userRedirectURI": $cookies.get('userRedirectURI'),
                "userId": $cookies.get("userId"),
                "usersysId": $cookies.get("usersysId")
            });
        },

        setInvDashboardDetails: function(dashboardDetails) {
            invDashboardDetails = dashboardDetails && dashboardDetails.profileDetails ? dashboardDetails.profileDetails : null;
        },
        getInvDashboardDetails: function() {
            return invDashboardDetails;
        }   
    };

    return mine;
};

authenticationService.$inject = ['$q', '$state', '$localStorage', 'Restangular', '$http', 'constants', 'appConfig', 'configUrlModel', '$rootElement', '$cookies'];
module.exports = authenticationService;
