/**
*@ngdoc object
*@name common.module:login
*@description
* <p>
* It has the login authorization functionality
* </p> 
* @project FTIC 
* @Date
* @version 1
* @author Suresh P
*/



'use strict';
// Home View
module.exports = angular.module('common.login', [])
    // .directive('loginView', require('./login.directive'))
    .controller('loginCtrl', require('./login.controller'))
    .config(require('./login.routes'))
    .factory('authenticationService', require('./services/authentication.service'))
    .controller('loginMasterCtrl', require('./loginMaster.controller'))
    .controller('forgotPasswordCtrl', require('./forgotpassword/forgotPassword.controller'))
    .controller('forgotUsernameCtrl', require('./forgotusername/forgotUsername.controller'))
    .controller('usernameDistributorCtrl', require('./forgotusername/distributor/distributor.controller'))
    .controller('usernameInvestorCtrl', require('./forgotusername/investor/investor.controller'))
    .controller('registerUserCtrl', require('./registeruser/registerUser.controller'))

    .directive('fticLoginHeading', require('./components/loginheading/loginHeading.directive'))
    .controller('loginTermsAndConditionsCtrl', require('./components/termsandconditions/termsAndConditions.controller'))
    .controller('registerCtrl', require('./register/register.controller'))
    .controller('arnCtrl', require('./arndetails/arnDetails.controller'))
    .controller('otpCtrl', require('./otpdetails/otpDetails.controller'))
    .controller('distributorCtrl', require('./forgotpassword/distributor/distributor.controller'))
    .controller('investorCtrl', require('./forgotpassword/investor/investor.controller'))
    .controller('userVerificationCtrl', require('./userverification/userVerification.controller'))
    .controller('securityQuestionCtrl', require('./userverification/securityquestion/securityQuestion.controller'))
    .controller('otpVerificationCtrl', require('./userverification/otpVerification/otpVerification.controller'))
    .controller('createNewPasswordCtrl',require('./createnewpassword/createNewPassword.controller'))
    .controller('thankYouCtrl', require('./thankyou/thankyou.controller'))
    .factory('loginModelService', require('./services/login.service'))
    .factory('advisorRegistrationModelService', require('./services/advisorRegistrationModel.service'))
    .controller('resetPasswordCtrl',require('./resetpassword/resetPassword.controller'))
    .controller('panCtrl', require('./panDetails/panDetails.controller'))
    ;