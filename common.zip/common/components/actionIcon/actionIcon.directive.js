/**
 * @ngdoc directive
 * @name fticactionIcon
 * @requires $state
 * @requires $window
 * @description
 *
 * - fticactionIcon will be place icon to edit the field.
 * 
 *
 **/
 'use strict';

var actionIcon = function($state, $window, eventConstants) {
	return {
            template: require('./actionIcon.html'),
            restrict: 'E',
            replace: true,
            scope: {
                actionClass: '@'
            },
            controller:['$scope', '$element', function($scope, $element){ 
                $scope.isClickedOnce = false;
                $scope.onIconClick =  function($event){
                    $event.stopPropagation();
                    $scope.$emit(eventConstants.ACTION_ICON_CLICKED, $element);
                };
            }]
        };
};

actionIcon.$inject = ['$state', '$window', 'eventConstants'];
module.exports = actionIcon;