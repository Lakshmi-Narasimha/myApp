/**
 * @ngdoc property
 * @name Recommendations Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Recommendations for guest module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function recommendationsController($scope, $state, buildPlanModelService) {

    $scope.init = function () {
        $scope.config.stepsConfig.activeStep = 2;
        $scope.goalsheetBtn = function () {
            $state.go('ssmartSol.planSmartSolution.ssBase.goalSheetSummary');
        };

        $scope.tabObject = [{
                title: 'Recommended Plan',
                uiref: "smartSol.planSmartSolution.ssBase.recommendations.recommendedplan",
                tabViewName: "recommendedplan"
            },
            {
                title: 'Build my Plan',
                uiref: "smartSol.planSmartSolution.ssBase.recommendations.buildplan",
                tabViewName: "buildplan"
            }
        ];

        if (buildPlanModelService.tabname == 'buildplan') {
            $scope.tabNumber = 1;
            buildPlanModelService.isFromModify = true;
            //Navigating to build plan show details in case of coming back from Goal Sheet Summary
            $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan");
        }
        else {
            if(buildPlanModelService.isFromCustomize) {
                $state.go("smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rmycustomplan");
            } else {
                $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan');
            }
        }
    };

    $scope.init();

    $scope.recommendationsBackBtn = function () {
        $state.go('smartSol.planSmartSolution.ssBase.planInputDetails');
    };

    $scope.$on('customizeDetailsCancel', function () {
        if (buildPlanModelService.tabname == 'buildplan') {
            $scope.tabNumber = 1;
            buildPlanModelService.isFromModify = true;
            //Navigating to build plan show details in case of coming back from Goal Sheet Summary
            $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan.buildplanshowdtls");
        }
        else {
            $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan');
        }

    });

    // $scope.backBtnStyle = {"margin":"30px 0 0 20px"}

};

recommendationsController.$inject = ['$scope', '$state', 'buildPlanModelService'];
module.exports = recommendationsController;