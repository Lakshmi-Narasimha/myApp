
'use strict';
function smartSolsModifyGoalSheetCtrl($scope, $state,recommendedPlanInitialLoader,recommendedPlanModelService,advisorEventConstants, buildPlanModelService) {
  $scope.config.stepsConfig.activeStep = 2;
  $scope.keyValueList=[{key:"Goal Name",value:"Child's Education"},
                      {key:"Goal Deficit",value:"9,00,000"},
                      {key:"Balance Tenor",value:"15 Yrs."}
                      
                      ];


                      recommendedPlanInitialLoader.loadAllServices($scope);


   $scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function($event) {
       $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
       $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
       $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
       $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
       $scope.goalSummary = buildPlanModelService.getBuildPlanDtls().planSmartSolutionPostReq.goalSummary;
       //console.log($scope.goalChartData);
            
    });

  $scope.goBack=function(){
    $state.go("smartSol.investor.modifymain.modify");
  };

  $scope.TopupWithFtRecommendedFundsData = [];
  $scope.allocationArr = buildPlanModelService.getAllocationDetails();
  $scope.fundsData = buildPlanModelService.getFundDetails();
  console.log($scope.fundsData, $scope.allocationArr);
  $scope.total = null;
  for(var i=0, j=$scope.fundsData.length;i<j; i++) {
    var gridRow = {};
    gridRow.fundname = $scope.fundsData[i].fundName;
    gridRow.percent = Math.round(($scope.fundsData[i].monthly/buildPlanModelService.totalFundsvalue)*100) +"%";
    gridRow.monthly = $scope.fundsData[i].monthly;
    $scope.total += $scope.allocationArr[i];
    $scope.TopupWithFtRecommendedFundsData.push(gridRow);
  };
  $scope.TopupWithFtRecommendedFundsData.push({
    "fundname" : "Total",
    "percent" : "100%",
    "monthly"     : buildPlanModelService.totalFundsvalue

  });
  var statusTemplate ='<div uib-popover-template="\'viewCompostion.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'+
  '<script type="text/ng-template" id="viewCompostion.html">' +
  '<div><button type="button" ng-click="grid.appScope.$emit(\'showViewComposition\', COL_FIELD)" class="btn panel-orange-btn m0">View Composition</button></div></script>';


  $scope.TopupWithFtRecommendedFundsColumnDefs = [
  { field: 'fundname', displayName: 'Fund Name', width:'250', pinnedLeft: true},
  { field: 'percent', displayName: '%', width:'100'},
  { field: 'monthly', displayName: 'Monthly', width:'150',headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right'}
  ];
  $scope.savedSmartSolBtn = function(){
    $scope.$emit("smartSolSaveBtn");    
  }; 
  $scope.emailInvbtn = function(){
    $scope.$emit("smartSolEmailBtn");  
  };   
  
}

smartSolsModifyGoalSheetCtrl.$inject = ['$scope', '$state','recommendedPlanInitialLoader','recommendedPlanModelService','advisorEventConstants', 'buildPlanModelService'];
module.exports = smartSolsModifyGoalSheetCtrl;