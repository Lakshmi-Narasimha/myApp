'use strict';
describe('Service: dtpModel ', function() {
	var httpBackend,$window,dtpModel,transactModel,validateDTPPromise,fundDetailsModel;

    var ValidateDtpResp = {
        'accountNo': '0389906480558',
        'folioId': '18556824',
        'webRefNo': 'STP000693'
    };

    var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': 520965.095916
        }]
    };

    var existingFundSelectedObject = {
        "accNo": "0060007818365",
        "amount": "800",
        "direct": null,
        "dividendFlag": "R",
        "endDate": "4 aug 2020",
        "frequency": "monthly",
        "fundCategory": "EQUITY",
        "fundOptDesc": "Franklin India BLUECHIP FUND",
        "fundOption": "006",
        "fundType": "E",
        "minAddPurAmt": "1000",
        "minNewPurAmt": "5000",
        "minSipAmt": "1",
        "multiples": "1",
        "nfoFlag": "N",
        "payoutFlag": "N",
        "reinvestmentFlag": "N",
        "startDate": "12 apr 2014",
        "stepUpType": "",
        "nextInstlDate": "5 sep 2016",
        "nextAnnualDate": "12 apr 2017",
        "stepUpValue": "NA",
        "leadDays": "15",
        "paymentDet":{
        	"payModeEmand": "false",
	        "eMandateType":"",
	        "eMandateVal": "",
	        "eMandateExpiryDate": "" 
		}		       
	};

    var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

	var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var dtpObjectWithReInvestmentDividendType = {
		"destinationFund" : existingFundSelectedObject,
        "switchType" : "Re-Investment",
        "type": ""
	};

	var dtpModelObject = {
		"investorDetails" : investorDetails,
		"fundDetails" : selectedFundObject,
		"switchDetails" : dtpObjectWithReInvestmentDividendType
	};
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,_transactModel_,_dtpModel_,_fundDetailsModel_){	
		dtpModel = _dtpModel_;		
        httpBackend = $httpBackend;		        
        transactModel = _transactModel_;
        fundDetailsModel = _fundDetailsModel_;
        
        transactModel.setTransactDetails(dtpModelObject); 
        fundDetailsModel.setFundDetails(fundDetailsResponse);

		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the function validateDTP',function(){
		expect(dtpModel.validateDTP).toBeDefined();
	});	
	
	describe("validateDTP promise",function(){
		beforeEach(inject(function() {						
			validateDTPPromise = dtpModel.validateDTP();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectPOST('http://localhost:3030/transact/registerDtp?guId=878').respond(200,ValidateDtpResp);

			validateDTPPromise.then(function(response){										
				expect(response.accountNo).toBe('0389906480558');			
				done();
			});			

			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectPOST('http://localhost:3030/transact/registerDtp?guId=878').respond(400,failureResponse);
			validateDTPPromise.then(null,function(response){						
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});
});	
