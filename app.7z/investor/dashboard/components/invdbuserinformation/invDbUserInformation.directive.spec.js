'use strict';

describe('Directive: User Information Directive', function() {

	var compile, scope, directiveEle, isoScope, validHtml;
    validHtml = '<ftic-inv-db-user-information></ftic-inv-db-user-information> ';
     //load all modules, including the html template, needed to support the test

    var create = function(html) {
        var element = angular.element(html);
        var compiledElem = compile(element)(scope);
        //isoScope = directiveEle.isolateScope();
        scope.$digest();
        return compiledElem;
    };

    var mockDashboardDetailModel = {
        getDashboardData: function() {
            return {
                'profileDetails': {
                    'distId': '',
                    'subDistId': '',
                    'subArn': '',
                    'name': 'NILESH HIMMATLAL SHAH M BANSAL SANBUI',
                    'pan': 'DRCQR7575C',
                    'kycStatus': 'Yes',
                    'userType': '',
                    'userId': '',
                    'secretQtn': '',
                    'guId': '',
                    'mobile': '2706100644',
                    'emailId': 'Asa.Arigo@ApcoArgentinaInc.com',
                    'otpFlag': '',
                    'otpType': '',
                    'refNo': '',
                    'date': '31 May 2016',
                    'time': '12:00:00 PM'
                }
            };
        }
    };

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('investorDashboardDetailsModel', mockDashboardDetailModel);
        });
    });
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
          scope = $rootScope.$new();
          compile = $compile;
        });
        
    });

    it('Directive should be defined', function() {
        var directiveEle = create(validHtml);
        expect(directiveEle).toBeDefined();
    });

    it('directive should be created with scope:true',function(){
        var directiveEle = create(validHtml);
        expect(directiveEle.scope()).toBeDefined();
	});

    it('Case-1 When no data is available for userInformation',function(){
        var directiveEle = create(validHtml);
        var dirScope = directiveEle.scope();
        expect(dirScope).toBeDefined();
        expect(dirScope.isDataAvailable).toBeFalsy();
	});

    it('Case-2 When data is available for userInformation',function(){
        var directiveEle = create(validHtml);
        var dirScope = directiveEle.scope();
        expect(directiveEle.scope()).toBeDefined();
        scope.$broadcast('investorDashboardInformation');
        expect(dirScope.profileDetails).toBeDefined();
        expect(dirScope.profileDetails.name).toBe('NILESH HIMMATLAL SHAH M BANSAL SANBUI');
        expect(dirScope.isDataAvailable).toBeTruthy();
	});
});