'use strict';

describe('Directive : Investment Summary Grid Details', function() {

    var compile, scope, directiveEle, isoScope;

    //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-investment-summary-grids></ftic-investment-summary-grids> ');
        directiveEle = compile(element)(scope);

        isoScope = directiveEle.isolateScope();

        isoScope.investmentSummaryGridData = {
            'investmentSummary': [{
                'folioNumber': '789345',
                'rows': [{
                    'Account': '788876876534',
                    'Scheme': 'Freklin India Tax shield',
                    'TotalUnits': '545',
                    'CurrentCost': '2134',
                    'CurrentValue': '312.43',
                    'Return': '26%'
                }, {
                    'Account': '7567542342',
                    'Scheme': 'Freklin India Tax shield',
                    'TotalUnits': '454',
                    'CurrentCost': '2335',
                    'CurrentValue': '897.43',
                    'Return': '26%'
                }, {
                    'Account': '87686785252',
                    'Scheme': 'Freklin India Tax shield',
                    'TotalUnits': '424',
                    'CurrentCost': '787',
                    'CurrentValue': '312.43',
                    'Return': '26%'
                }],
                'modeofHolding': 'joint',
                'grandTotal': {
                    'Account': 'GRAND TOTAL',
                    'Scheme': '&nbsp;',
                    'TotalUnits': '276',
                    'CurrentCost': '16,789',
                    'CurrentValue': '1073.78',
                    'Return': '&nbsp;'
                }
            }]
        };
        scope.$digest();
        isoScope.$broadcast('pvDtls', isoScope.investmentSummaryGridData);
    });

    it('should define template element', function() {
        expect(directiveEle.html()).toBeDefined();

    });

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should have aCCOUNT and other details from isolated Scope', function() {

        var gridData = isoScope.gridData;
        expect(gridData[0].Account).toContain('788876876534');
        expect(gridData[0].Scheme).toContain('Freklin India Tax shield');
        expect(gridData[0].TotalUnits).toContain('545');
        expect(gridData[0].CurrentCost).toContain('2134');
        expect(gridData[0].CurrentValue).toContain('312.43');
        expect(gridData[0].Return).toContain('26%');

    });

    it('should have total details from isolated scope', function() {
        var gridData = isoScope.gridData;
        expect(gridData[3].Account).toContain('GRAND TOTAL');
        // expect(gridData[3].Scheme).toContain('Freklin India Tax shield');
        expect(gridData[3].TotalUnits).toContain('276');
        expect(gridData[3].CurrentCost).toContain('16,789');
        expect(gridData[3].CurrentValue).toContain('1073.78');
        // expect(gridData[3].Return).toContain('26%');
    });

});
