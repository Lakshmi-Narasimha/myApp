﻿define(['jquery', 'underscore', 'backbone',
'appcommon/commonutility'],
    function ($, _, Backbone, CommonUtils) {
        var self = this,
        uniqueId = 0;
        var EmpCompModel = Backbone.Model.extend({
            defaults: function () {
                uniqueId++;
                return {
                    compId: undefined,
                    compNm: undefined,
                    employerName: undefined,
                    addressType: undefined,
                    address1: undefined,
                    address2: undefined,
                    countryNm: undefined,
                    countryFullNm:undefined,
                    city: undefined,
                    state: undefined,
                    stateFullNm:undefined,
                    province: undefined,
                    provinceFullNm:undefined,
                    zipCode: undefined,
                    primaryOccupation: undefined,
                    priOccupationOther: undefined,
                    jobTitle: undefined,
                    tickerSymbol: undefined,
                    launchMode: undefined,
                    relatedModelRefId: undefined,
                    id: uniqueId
                };
            },
            setModel: function (modelObj) {
                this.set('compId', modelObj.compId);
                this.set('compNm', modelObj.compNm);
                this.set('employerName', modelObj.employerName);
                this.set('addressType', modelObj.addressType);
                this.set('address1', modelObj.address1);
                this.set('address2', modelObj.address2);
                this.set('countryNm', modelObj.countryNm);
                this.set('countryFullNm', modelObj.countryFullNm);
                this.set('city', modelObj.city);
                this.set('state', modelObj.state);
                this.set('stateFullNm', modelObj.stateFullNm);
                this.set('province', modelObj.province);
                this.set('provinceFullNm', modelObj.provinceFullNm);
                this.set('zipCode', modelObj.zipCode);
                this.set('primaryOccupation', modelObj.primaryOccupation);
                this.set('priOccupationOther', modelObj.priOccupationOther);
                this.set('jobTitle', modelObj.jobTitle);
                this.set('tickerSymbol', modelObj.tickerSymbol);
            },
            isTheAddressValid: function () {
                var employerCompanyInfo = this.toJSON();
                var isAddressValid = true,
                    self = this,
                    addressType = employerCompanyInfo.addressType,
                    ObjectKeys = ["employerName", "addressType", "address1", "city"],
                    addressModel;
                if (addressType == "Foreign") {
                    ObjectKeys.push("countryNm");
                    if (employerCompanyInfo.countryNm == "CA") {
                        ObjectKeys.push("province", "zipCode");
                    }
                } else {
                    ObjectKeys.push("state", "zipCode");
                }
                addressModel = _.pick(employerCompanyInfo, ObjectKeys);
                if (!addressModel.hasOwnProperty("employerName")) {
                    isAddressValid = false;
                }
                for (var key in addressModel) {
                    if (!CommonUtils.hasValue(addressModel[key])) {
                        isAddressValid = false;
                    }
                }
                return isAddressValid;
            }
        });

        return EmpCompModel;
    });
