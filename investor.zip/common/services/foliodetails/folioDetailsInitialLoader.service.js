'use strict';

var folioDetailsInitialLoader = function (folioDetailsModel, events, transactModel,toaster) {
    
    var folioDetailsInitialLoader = {
        _isServicesData: false,     
        loadAllServices : function (scope,params) {
                        
            function FolioDetailsSuccess(data) {
                folioDetailsModel.setFolioDetails(data);
                transactModel.setFolioDet(data.folioDetails);
                events.publishFolioDetails(scope, folioDetailsModel.getFolioDetails());

            }
            
            function handleFailure(data){
                toaster.error(data.data[0].errorDescription);
                folioDetailsInitialLoader._isServicesData = false;
            }

            folioDetailsModel.fetchFolioDetails(params)
                .then(FolioDetailsSuccess, handleFailure);
        }
        
    };
    return folioDetailsInitialLoader;
};

folioDetailsInitialLoader.$inject = ['folioDetailsModel', 'events', 'transactModel','toaster'];

module.exports = folioDetailsInitialLoader;	