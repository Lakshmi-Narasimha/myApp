define(['jquery', 'backbone', 'breeze',  'appmodules/accountviewer/avcommon', 'errorLog','moment'
], function ($, Backbone, Breeze, accountviewCommon, ErrorLog,Moment) {
	var DT = Breeze.DataType;
	var overviewAccountModel = Backbone.Model.extend({
        defaults: {
            id: null,
            ctx: null,            
            fmtId: null,
            statusCd: null,
            adminCd: null,
            productCd: null,
            subProductCd: null,
            taxQualCd: null,
            acctTypCd: null,
            iraTypeCd: null,
            accountPlan:null,
            iraStatCd: null,
            carrierNm: null,
            planId: null,
            setlCd: null,
            ownshpCd: null,
            ownshpDesc: null,
            oldOwnshpCd: null,
            openDt: null,
            closeDt: null,
            sortKey: undefined,
            accountProduct: undefined,
            accountRegistration: undefined,
            relatedAccounts: undefined,
            accountBalance: undefined,
            accountIdentifier:undefined,
            defaultIndex:null,
            accountHoldings:false
        }
    }); 
	var accountProductModel = Backbone.Model.extend({
        defaults: {
        	acctId: null,
        	acctCtx: null,            
        	longNm: null,
        	mediumNm: null,
        	shortNm: null,
        	strategyCd: null,
        	strategyNm: null,
        	invSecrLongDesc : null,
        	invSecrShrtDesc : null,
        	invSecrCusipNbrTxt : null,
        	brkgProdClsNm:null,
        	brkgProdClsCd:null
        }
    });
	var accountRegistrationModel = Backbone.Model.extend({
        defaults: {
        	acctId: null,
        	acctCtx: null,            
        	legalTitle1Txt: null,
        	legalTitle2Txt: null,
        	legalTitle3Txt: null,
        	legalTitle4Txt: null,
        	legalTitle5Txt: null,
        }
    });
	var relatedAccountsModel = Backbone.Model.extend({
        defaults: {
        	acctId: null,
        	acctCtx: null,            
        	relAcctId: null,
        	relAcctCtx: null,
        	typCd: null,
        	subTypCd: null,
        }
    });
	var accountBalanceModel = Backbone.Model.extend({
        defaults: {
        	id: null,
        	ctx: null,            
        	totAcctBal: null,
        	totAcctBalFmtd: null,
        	availCashForTran: null,
        	availCredForTran: null,
        	dthBenfAmt: null,
        	valueDt: null,
        }
    });
	var accountIdentifierModel = Backbone.Model.extend({
        defaults: {
        	altAcctId: null
        }
    });
	var getAccountPlan = function(groupId,taxQualCd,iraStatCd,iraTypeCd){
		var _taxQualType = {
    			000: 'NON-QUALIFIED',
    			001: 'IRA',
    			002: '403(b)TSA PUBLIC SCHOOL EMPLOYEES',
    			003: '403(b)TSA 501(c)(3) ORG. EMPLOYEES',
    			004: '403(b)TSCA',
    			005: 'PRIVATE DEFERRED COMP'
    	};
		
		var _iraTypes = {
    			001: 'INDIVIDUAL',
    			003: 'SEP',
    			004: 'SRA',
    			005: 'ROTH',
    			006: 'ROTH CONVERSION',
    			007: 'COVERDELL ESA'
    	};
		
		var _iraStatus = {
    			001: 'Active',
    			002: 'Rollover',
    			003: 'Beneficial'
    	};
		try{
			if(groupId.substr(0,3) == "002"){
				return "Not Available";
			}
			else{
				
				if(taxQualCd == "001"){
					if(taxQualCd && iraTypeCd){
			    		var plan = _iraTypes[parseInt(iraTypeCd)]+" "+_taxQualType[parseInt(taxQualCd)];
			    		return plan.replace('undefined',' ');
					}
				}else{
					var plan = _taxQualType[parseInt(taxQualCd)];
					if(plan == undefined){
						return " ";
					}
		    		return plan;
				}
			}
			return null;
		}catch(err){
    		ErrorLog.ErrorUtils.myError(err);
    	}
		
    	
	}; 
	var getPensionAccountPlan = function(qualifiedPlan){
		var _pensionPlans = {
				00: 'NOT APPLICABLE',
				01: 'DEFINED BENEFIT',
				02: '401(K)',
				03 :'THRIFT PLAN', 
				04 :'ASSUMED/TARGET BENEFIT', 
				05 :'PROFIT SHARING', 
				06 :'MONEY PURCHASE',
				07 :'457 GOVT. PLAN',
				08 :'INCENTIVE & THRIFT', 
				09 :'DIV MGR RETIREMENT', 
				10 :'OTHER', 
				11 :'ROTH 401(K)'
		};
		if(qualifiedPlan.planTypCd.length !=0){
			return _pensionPlans[Number(qualifiedPlan.planTypCd)];
		}
		return '';
	};
	var getAltAcctId = function(accountIdentifier){
		var _altActIdntfrs = [],_altAcctId=false,_admsrvAcctId=null;
		if(accountIdentifier != null && accountIdentifier.alternateAccountIdentifiers != null){
			_altActIdntfrs  = accountIdentifier.alternateAccountIdentifiers.attributes.results;
			if(_altActIdntfrs.length > 0){
				for(var m=0;m<_altActIdntfrs.length;m++){
					var _act = _altActIdntfrs[m].toJSON();
					if(_act.altAcctCtx == "ADMSRV.ACCT" || _act.altAcctCtx == "NSSC.ACCT"){
						if(_act.altAcctCtx == "ADMSRV.ACCT"){
							_admsrvAcctId = _act.altAcctId;
						}
						_altAcctId = _act.altAcctId;
					}
				}
			}
			
		}
		return _admsrvAcctId || _altAcctId;
	};
	var isHodlingsApplicable = function(adminCd,productCd){
    	var productCdList = ["00912","00913","00914","00915","00916","00922","00923","00924","00925","00300","00310","00500","00501","00510","00511","00515","00516","00520","00521","00530","00512","00517"];

    	
    	if(adminCd == "133" || adminCd == "134"){
    		return true;
    	}
    	else if(adminCd == "004" || adminCd == "005"){
    		if(productCdList.indexOf(productCd) == -1){
    			return true;
    		}
    	}
    	return false;
    };
	var fillAccountListData = function(dataCollection,accountOverViewArray,groupId){
		try{
			if(dataCollection && dataCollection.length>0){
				var _results  = dataCollection;
				var totalInvstmntVal = null;
				var counter = 0;
				$.each(_results,function(key,row){
					row = row.toJSON();
					if(row.statusCd == "ACTIVE"){
						accountOverViewArray[counter] = new overviewAccountModel();
						
						//Account balance section
							accountOverViewArray[counter].attributes.accountBalance = new accountBalanceModel();
						if(row.accountBalance){
							row.accountBalance = row.accountBalance.toJSON();
							accountOverViewArray[counter].attributes.accountBalance.attributes.id = row.accountBalance.id;
							accountOverViewArray[counter].attributes.accountBalance.attributes.ctx = row.accountBalance.ctx;
							accountOverViewArray[counter].attributes.accountBalance.attributes.totAcctBal = "";
							accountOverViewArray[counter].attributes.accountBalance.attributes.totAcctBalFmtd = "Not available";
							if(row.accountBalance.totAcctBal != null && row.accountBalance.totAcctBal != undefined){
								accountOverViewArray[counter].attributes.accountBalance.attributes.totAcctBal = parseFloat(row.accountBalance.totAcctBal);
								accountOverViewArray[counter].attributes.accountBalance.attributes.totAcctBalFmtd = row.accountBalance.totAcctBal.toString().formatMoney();
							}
							accountOverViewArray[counter].attributes.accountBalance.attributes.availCashForTran = row.accountBalance.availCashForTran;
							accountOverViewArray[counter].attributes.accountBalance.attributes.availCredForTran = row.accountBalance.availCredForTran;
							accountOverViewArray[counter].attributes.accountBalance.attributes.dthBenfAmt = row.accountBalance.dthBenfAmt;
							accountOverViewArray[counter].attributes.accountBalance.attributes.valueDt = Moment( row.accountBalance.valueDt).format('MM/DD/YYYY');;
							if(row.accountBalance.totAcctBal != null && row.accountBalance.totAcctBal != undefined){
								if(row.adminCd && row.adminCd != "134" && row.adminCd != "135"){
									totalInvstmntVal+= parseFloat(parseFloat(row.accountBalance.totAcctBal).toFixed(2));
								}
							}
						}else{
							accountOverViewArray[counter].attributes.accountBalance.attributes.totAcctBal = "";
							accountOverViewArray[counter].attributes.accountBalance.attributes.totAcctBalFmtd = "Not available";
						}
						
						//Account product section
							accountOverViewArray[counter].attributes.accountProduct = new accountProductModel();
						if(row.accountProduct){
							row.accountProduct = row.accountProduct.toJSON();
							accountOverViewArray[counter].attributes.accountProduct.attributes.acctId = row.accountProduct.acctId;
							accountOverViewArray[counter].attributes.accountProduct.attributes.acctCtx = row.accountProduct.acctCtx;
							accountOverViewArray[counter].attributes.accountProduct.attributes.longNm = row.accountProduct.longNm;
							var productCd = row.productCd;
							if(productCd == "00221" || productCd == "00222" || productCd == "00223" || productCd == "00225" || productCd == "00235" || productCd == "00238" || productCd == "00239"){
								accountOverViewArray[counter].attributes.accountProduct.attributes.mediumNm = row.accountProduct.mediumNm.substr(0,18)+" ("+row.accountProduct.shortNm+")";
							}else{								
								accountOverViewArray[counter].attributes.accountProduct.attributes.mediumNm = row.accountProduct.mediumNm;
							}							
							accountOverViewArray[counter].attributes.accountProduct.attributes.shortNm = row.accountProduct.shortNm;
							accountOverViewArray[counter].attributes.accountProduct.attributes.strategyCd = row.accountProduct.strategyCd;
							accountOverViewArray[counter].attributes.accountProduct.attributes.strategyNm = row.accountProduct.strategyNm;
							accountOverViewArray[counter].attributes.accountProduct.attributes.invSecrLongDesc = row.accountProduct.invSecrLongDesc;
							accountOverViewArray[counter].attributes.accountProduct.attributes.invSecrShrtDesc = row.accountProduct.invSecrShrtDesc;
							accountOverViewArray[counter].attributes.accountProduct.attributes.invSecrCusipNbrTxt = row.accountProduct.invSecrCusipNbrTxt;
							accountOverViewArray[counter].attributes.accountProduct.attributes.brkgProdClsNm = row.accountProduct.brkgProdClsNm;
							accountOverViewArray[counter].attributes.accountProduct.attributes.brkgProdClsCd = row.accountProduct.brkgProdClsCd;
							}
						
						//Account registration section
							accountOverViewArray[counter].attributes.accountRegistration = new accountRegistrationModel();
						if(row.accountRegistration){
							row.accountRegistration = row.accountRegistration.toJSON();
							accountOverViewArray[counter].attributes.accountRegistration.attributes.acctId = row.accountRegistration.acctId;
							accountOverViewArray[counter].attributes.accountRegistration.attributes.acctCtx = row.accountRegistration.acctCtx;
							accountOverViewArray[counter].attributes.accountRegistration.attributes.legalTitle1Txt = row.accountRegistration.legalTitle1Txt;
							accountOverViewArray[counter].attributes.accountRegistration.attributes.legalTitle2Txt = row.accountRegistration.legalTitle2Txt;
							accountOverViewArray[counter].attributes.accountRegistration.attributes.legalTitle3Txt = row.accountRegistration.legalTitle3Txt;
							accountOverViewArray[counter].attributes.accountRegistration.attributes.legalTitle4Txt = row.accountRegistration.legalTitle4Txt;
							accountOverViewArray[counter].attributes.accountRegistration.attributes.legalTitle5Txt = row.accountRegistration.legalTitle5Txt;
						}
						accountOverViewArray[counter].attributes.accountIdentifier = new accountIdentifierModel();
						//account Identifier section for carrier num
						if(row.accountIdentifier){
							row.accountIdentifier = row.accountIdentifier.toJSON();
							accountOverViewArray[counter].attributes.accountIdentifier.attributes.altAcctId = getAltAcctId(row.accountIdentifier);
						}
						//Related accounts						
						accountOverViewArray[counter].attributes.acctTypCd = row.acctTypCd;
						accountOverViewArray[counter].attributes.acctTypCd = row.acctTypCd;
						accountOverViewArray[counter].attributes.adminCd = row.adminCd;
						accountOverViewArray[counter].attributes.carrierNm = row.carrierNm;
						accountOverViewArray[counter].attributes.closeDt = row.closeDt;
						accountOverViewArray[counter].attributes.ctx = row.ctx;
						accountOverViewArray[counter].attributes.fmtId = row.fmtId;
						accountOverViewArray[counter].attributes.id = row.id;
						accountOverViewArray[counter].attributes.iraStatCd = row.iraStatCd;
						accountOverViewArray[counter].attributes.iraTypeCd = row.iraTypeCd;
						if(groupId.substr(0,3) == "002"){
							accountOverViewArray[counter].attributes.accountPlan = getPensionAccountPlan(row.qualifiedPlan.toJSON());
						}else{
							accountOverViewArray[counter].attributes.accountPlan = getAccountPlan(groupId, row.taxQualCd, row.iraStatCd, row.iraTypeCd);
						}
						accountOverViewArray[counter].attributes.oldOwnshpCd = row.oldOwnshpCd;
						accountOverViewArray[counter].attributes.openDt = row.openDt;
						accountOverViewArray[counter].attributes.ownshpCd = row.ownshpCd;
						accountOverViewArray[counter].attributes.ownshpDesc = row.ownshpDesc;
						accountOverViewArray[counter].attributes.planId = row.planId;
						accountOverViewArray[counter].attributes.productCd = row.productCd;
						accountOverViewArray[counter].attributes.setlCd = row.setlCd;
						accountOverViewArray[counter].attributes.sortKey = row.sortKey;
						accountOverViewArray[counter].attributes.statusCd = row.statusCd;
						accountOverViewArray[counter].attributes.subProductCd = row.subProductCd;
						accountOverViewArray[counter].attributes.taxQualCd = row.taxQualCd;
						accountOverViewArray[counter].attributes.defaultIndex = key;
						accountOverViewArray[counter].attributes.accountHoldings = isHodlingsApplicable(row.adminCd,row.productCd)
						counter++;
					}
				})
							
				
				return (totalInvstmntVal != null) ? totalInvstmntVal.toString().formatMoney() : totalInvstmntVal;
			}
			
		}catch(err){
    		ErrorLog.ErrorUtils.myError(err);
    	}
	};
	
	var applySortToAccountList = function(accountOverViewArray,sortField,sortOrder){
		if(sortField && sortOrder){
			if(sortField == "account-value"){
				if(sortOrder == "asc"){
					accountOverViewArray.sort(function (r1, r2) {
						
						  if(r1.attributes.accountBalance.attributes.totAcctBal === ""){
							return -1;
						  }
    					  if (r1.attributes.accountBalance.attributes.totAcctBal > r2.attributes.accountBalance.attributes.totAcctBal) { 
    					    return 1;
    					  }
    					  if (r1.attributes.accountBalance.attributes.totAcctBal < r2.attributes.accountBalance.attributes.totAcctBal) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}else if(sortOrder == "desc"){
					accountOverViewArray.sort(function (r1, r2) {
						  if(r2.attributes.accountBalance.attributes.totAcctBal === ""){
							return -1;
						  }
						  if (r1.attributes.accountBalance.attributes.totAcctBal < r2.attributes.accountBalance.attributes.totAcctBal) { 
    					    return 1;
    					  }
    					  if (r1.attributes.accountBalance.attributes.totAcctBal > r2.attributes.accountBalance.attributes.totAcctBal) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}
				
			}else if(sortField == "account-plan"){
				if(sortOrder == "asc"){
					accountOverViewArray.sort(function (r1, r2) {
    					  if (r1.attributes.accountPlan > r2.attributes.accountPlan) { 
    					    return 1;
    					  }
    					  if (r1.attributes.accountPlan < r2.attributes.accountPlan) {
    					    return -1;
    					  }
    					  // r1 must be equal to r2
    					  return 0;
    					});
				}else if(sortOrder == "desc"){
					accountOverViewArray.sort(function (r1, r2) {
    					  if (r1.attributes.accountPlan < r2.attributes.accountPlan) { 
    					    return 1;
    					  }
    					  if (r1.attributes.accountPlan > r2.attributes.accountPlan) {
    					    return -1;
    					  }
    					  return 0;
    					});
				}
				
			}
		}else{
			accountOverViewArray.sort(function (r1, r2) {
				  if (r1.attributes.defaultIndex > r2.attributes.defaultIndex) { 
				    return 1;
				  }
				  if (r1.attributes.defaultIndex < r2.attributes.defaultIndex) {
				    return -1;
				  }
				  return 0;
				});
		}
	};

    var accountViewModel = {
    	overviewAccountModel:overviewAccountModel,
    	fillAccountListData:fillAccountListData,
    	applySortToAccountList:applySortToAccountList,
    	isHodlingsApplicable:isHodlingsApplicable
    };
    return accountViewModel;
});
