define([
], function () {
    var config = {
        // E1
        //awmServicePath: 'https://eformsaar.dev.advisorcompass.com/ods.svc/',
        //oboServicePath: 'https://eformsaar.dev.advisorcompass.com/adv_capl/oboselector/',

        // LOCAL
		//awmServicePath: 'http://localhost:9040/simservice/',
		//oboServicePath: 'http://localhost:9040/simservice/',

        virtualizedServicePath: '',
        virtualizedServicePatterns: [],   // regexes for services that should be routed to virtualization
        //sendAnalyticsToOmniture: false,
        //enableAnalyticsConsoleLogging: false,
        //omnitureSAccount: "amppracviewerdev",
        //enableErrorLogging: false
    };

    return config;

});
