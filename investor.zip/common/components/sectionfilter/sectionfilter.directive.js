 /**
 * @ngdoc property
 * @name sectionFilter Directive
 * @description
 *
 * - Simple dropdown filter which has the flotable labels and emits the selected event
 *
 **/
'use strict';


var sectionFilter = function($timeout) {
    return {
        restrict: 'E',
        replace:true,
        template: require('./sectionfilter.directive.html'),
        scope: {
            inputObject: "=",
            sectionOptions: "=",
            eventName : '@',
            selected : '=?'
        },
        controller: function($scope, $element, $attrs){
            $scope.$input = $element[0].querySelector('select');
            $scope.toggleLabel = function($event){
                angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || ($scope.selected)));
            };

            $timeout(function(){
                angular.element($scope.$input).triggerHandler('blur');
            }, 0);

            $scope.eventName = $scope.eventName || 'selectedOption';

            if($scope.sectionOptions.length > 0)
            {
                $scope.selected = $scope.selected || $scope.sectionOptions[0];                 
                // $scope.selected = $scope.sectionOptions[0];                 
                $scope.$emit($scope.eventName, $scope.selected); //Will wmit for default selection
            }
            $scope.changed = function() {
                if ($scope.selected) 
                {
                    //console.log($scope.selected);
                    $scope.$emit($scope.eventName, $scope.selected);                   
                }
            }
        },
        link: function(scope, iElement, iAttrs, controller) {
        }       
    }
}    
    

sectionFilter.$inject = ['$timeout'];
module.exports = sectionFilter;