define([
    'jquery',
    'lodash',
], function ($, _){

    var Application = function () {
        this.appView = null;
        //this.userInformation = {};
        this.start = function () {
            var self = this;

            require(['app/application/views/AppView', 'app/application/router'], function (AppView, router) {
                self.appView = new AppView();
                self.appView.initiateAppRouter = function() {
                    router.start();
                };
                self.appView.render();
            });
        };
    };
    var app =  new Application();
    return app;
});
