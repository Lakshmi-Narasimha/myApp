define(['jquery', 'lodash', 'q', 'app/services/awmService', 'app/rest-client/restClient',
	'text!test/data/ssoInformationResponse.json',
	'text!test/data/oboInformationResponse.json',
], function ($, _, Q, originalService, originalRestClient,
			 ssoInformationResponse,
			 oboInformationResponse
        ) {
            mocha.ui('bdd');
            var assert = chai.assert;
            var expect = chai.expect;

            /* Tests */

            describe("AWMService", function () {

				describe("promiseToGetSignOnInformation", function () {
					var expectedJsonResponse = JSON.parse(ssoInformationResponse);
					var response = null;
					var restClientStub = null;
					var service = createAWMService();

					before(function (done) {
						restClientStub = sinon.stub(service.testAPI.getRestClient(), "promiseToFetch", function (params) {
							var defer = Q.defer();
							defer.resolve(expectedJsonResponse);
							return defer.promise;
						});
						service.promiseToGetSignOnInformation('')
							.then(function (data) {
								response = data;
								done();
							})
							.fail(function (error) {
								done();
							})
					});

					it("should return getSignOnInformation", function () {
						assert.isNotNull(response);
						expect(response.get('fmid')).equals('000030601');
						expect(response.get('guid')).equals('86cd65346099cef6d52c06d0241b6bd0');
						expect(response.get('ldapGroups')).deep.equals('Opportunity_Management_ERO,AFI_NPLegacy_Grp,aefa_all_field_users,Franchise_Consultants,AFI_Hearsay_User,DCM_A,aefa_field_p2_advisors,AFI_NPPremium_Grp,AFI_Naviplan_P2Subscribers,AFI_ContactService_Pilot,aefa_field_non_beta_users,aefa_field_goldfs_advisors,AFI_ContactService_Pilot_Static'.split(','));
						expect(response.get('peopleSoftId')).equals('2030601');
						expect(response.get('personType')).equals('02');

					});

				});

				describe("promiseToGetOBOInformation", function () {
					var expectedJsonResponse = JSON.parse(oboInformationResponse);
					var response = null;
					var restClientStub = null;
					var service = createAWMService();
					before(function (done) {
						restClientStub = sinon.stub(service.testAPI.getRestClient(), "promiseToFetch", function (params) {
							var defer = Q.defer();
							defer.resolve(expectedJsonResponse);
							return defer.promise;
						});

						service.promiseToGetOboAdvisors()
							.then(function (data) {
								response = data;
								done();
							})
							.fail(function (error) {
								done();
							})
					});

					it("should return OBO information", function () {
						assert.isNotNull(response);
						expect(response.length).equal(3);
						var advisor = response.at(0);
						assert.isNotNull(advisor);
						expect(advisor.get('firstName')).equals('THOMAS');
						expect(advisor.get('fmid')).equals('28156');
						expect(advisor.get('lastName')).equals('STORRIE');
						expect(advisor.get('middleName')).equals('');
						expect(advisor.get('fullName')).equals("THOMAS STORRIE");
						expect(advisor.get('userType')).equals("ADVISOR");
						advisor = response.at(1);
						assert.isNotNull(advisor);
						expect(advisor.get('fmid')).equals('116469');
					});
				});

            });

            /* Test Helper Functions */

            function createAWMService() {
                // create the service via this technique to allow for tests runnning parallel
                var awmServiceConstructor = Object.getPrototypeOf(originalService).constructor;
                serviceForTest = new awmServiceConstructor();
                var restClientConstructor = Object.getPrototypeOf(originalRestClient).constructor;
                var testRestClient = new restClientConstructor();
                serviceForTest.testAPI.setRestClient(testRestClient);
                return serviceForTest;
            }

            function assertAjaxParams(awmService, ajaxParams) {
                var sentHeaders = ajaxParams.headers;
                expect(sentHeaders).to.exist;
                for (headerName in awmService.testAPI.defaultRequestHeaders) {
                    expect(awmService.testAPI.defaultRequestHeaders.headerName).to.equal(sentHeaders.headerName);
                }
            }


        });
