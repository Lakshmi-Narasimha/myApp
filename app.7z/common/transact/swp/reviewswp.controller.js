/**
 * @ngdoc property
 * @name fticracDetails Directive
 * @description
 *
 * fticracDetails - Displays the Review & Confirm Detail
 *
 **/
'use strict';



function ReviewSwpCtrl($scope, fticLoggerMessage, loggerConstants, reviewSwpDetailsModel, eventConstants, $filter,$state, swpModel, authenticationService, swpReviewDetailsFactory) {

    var _userType = authenticationService.getUser().userType;
    //$scope.config.toTxnDetailsState = "transact.txnDetails.swp"; -- Commented as a part of Investor
    $scope.config.toTxnDetailsState = swpReviewDetailsFactory.getCurrentTxnToState(_userType);
    //$scope.config.toState = "transact.base.swp"; -- Commented as a part of Investor
    $scope.config.toState = swpReviewDetailsFactory.getCurrentToState(_userType);
    $scope.config.fromState = $state.current.name;
    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){
      reviewSwpDetailsModel.getReviewSwpObj().isEditSWP = true;
      $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'SWP'});
    });
    
    


  
}


ReviewSwpCtrl.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'reviewSwpDetailsModel', 'eventConstants', '$filter','$state','swpModel', 'authenticationService', 'swpReviewDetailsFactory'];
module.exports = ReviewSwpCtrl;