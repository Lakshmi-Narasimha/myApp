import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AIAssistCacheService } from '../_services/aiassistcache.service';

@Injectable()
export class AuthGuard implements CanActivate {

  activeUser: any;

    constructor(private router: Router, private aiAssistCacheService: AIAssistCacheService) {
      this.subscribeForServices();
    }

    subscribeForServices() {
      this.aiAssistCacheService.currentUserObservable.subscribe((data) => {
        if(data){this.activeUser=data;} else { this.activeUser = {};}
      });
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (localStorage.getItem('currentUser')) {
          let parsedUser = JSON.parse(localStorage.getItem('currentUser'));
          this.aiAssistCacheService.updateCurrentUser(parsedUser);
            return true;
        }

        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
        return false;
    }
}
