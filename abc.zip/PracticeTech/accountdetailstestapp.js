define([
  'jquery',
  'underscore',
  'config',
  'backbone',
  'spinner',
  'appmodules/accountviewer/app/views/accountdetailsview'
], function ($, _, config, Backbone, Spinner, AccountDetailsView) {
    var initialize = function () {

        $.ajaxPrefilter(function (options) {
            options.beforeSend = function (xhr) {
                xhr.setRequestHeader('consumer', config.consumerId);
            }
            options.timeout = 30000;
        });

        Backbone.View.prototype.close = function () {  //This is the method will cleanup the previous view whwnever the new view is created and so cleanup the memmory.
            //Flushing timelineInterval
            if (typeof (window.timelineInterval) != "undefined") window.clearInterval(timelineInterval);
            if (this.beforeClose) {
                this.beforeClose();
            }
            this.undelegateEvents();
            $(this).empty;
            this.unbind();
        };
        Spinner.hide();

        // BROKERAGE ACCOUNT: jspsad1/Skip Bayless:
        // var testClientId = '00100000000000070763554';
        // var testGroupId = '0010008097519';
        // var testAccountSummary =
        //   {
        //     accountId: '133000000000000000012122012',
        //     fmtId: '0000 1212 2012 3 133',
        //     productCd: '00007',
        //     longProdName:  'AT FUND 529 PLAN',
        //     mediumProdName: 'AT FUND 529 PLAN',
        //     fmtAccountBalance: '$585,302.70',
        //     statusCd: 'ACTIVE',
        //     openDt: "2012-12-12",
        //     ownershipNames: ["BIG 529 PLAN", "SKIP  BAYLESS", "FB0 ANITA OMNUBUS"],
        //     accountPlan: "INDIVIDUAL IRA",
        //     taxQualCd: "001",
        //     planId: "0004827771"
        //   };

        // BROKERAGE ACCOUNT: jspsad1/Skip Bayless:
        var testClientId = '00100000000000070763554';
        var testGroupId = '0010008097519';
        var testAccountSummary =
          {
            accountId: '133000000000000000046416213',
            fmtId: '0000 4641 6213 0 133',
            productCd: '00016',
            longProdName:  'STRATEGIC PORTFOLIO SERVICE ADVANTAGE WITH ONE FEATURES',
            mediumProdName: 'SPS ADVANTAGE W/ ONE',
            fmtAccountBalance: '$585,302.70',
            statusCd: 'ACTIVE',
            openDt: "2011-05-19", 
            ownershipNames: ["HEATHER I NELSEN"],
            accountPlan: "NON-QUALIFIED",
            taxQualCd: "000",
            planId: ""
          };

        // BROKERAGE ACCOUNT: jspsad1/Skip Bayless:
        // var testClientId = '00100000000000070763554';
        // var testGroupId = '0010008097519';
        // var testAccountSummary =
        //   {
        //     accountId: '133000000000000000012172012',
        //     fmtId: '0000 1217 2012 2 133',
        //     productCd: '00016',
        //     longProdName:  'AMERIPRISE BROKERAGE ACCOUNT',
        //     mediumProdName: 'AMERIPRISE BROKERAGE',
        //     fmtAccountBalance: '$69,413.87',
        //     statusCd: 'ACTIVE',
        //     openDt: "12/17/2012", 
        //     ownershipNames: ["SKIP BAYLESS","MOBILE BROKERAGE64 AND","MOBILE BROKERAGE134 ET AL JT"],
        //     accountPlan: "NON-QUALIFIED",
        //     taxQualCd: "000",
        //     planId: ""
        //   };

        // MUTUAL FUND ACCOUNT: jspsad1/Skip Bayless:
        // var testClientId = '00100000000000070763554';
        // var testGroupId = '0010008097519';
        // var testAccountSummary =
        //   {
        //     accountId: '002000000000000001010657353',
        //     fmtId: '0010 1065 7353 7 002',
        //     productCd: '00014',
        //     longProdName:  'COLUMBIA STRATEGIC MUNICIPAL INCOME FUND - A',
        //     mediumProdName: 'STR MUNI INC - A',
        //     fmtAccountBalance: '$69,415.55',
        //     statusCd: 'ACTIVE',
        //     openDt: "03/26/2004", 
        //     ownershipNames: ["SKIP BAYLESS"],
        //     accountPlan: "INDIVIDUAL IRA",
        //     taxQualCd: "001",
        //     planId: "0004801690"
        //   };


// NOTE!!!  Need group ID 
        // MUTUAL FUND ACCOUNT: csr eddew (Client with Mutual Funds: 70697218)
        // var testClientId = '00100000000000070697218';
        // var testAccountSummary =
        //   {
        //     accountId: '002000000000000001010044544',
        //     fmtId: '0010 1004 4544 3 002',
        //     productCd: '00022',
        //     longProdName:  'COLUMBIA GLOBAL BOND FUND - A',
        //     mediumProdName: 'GLOBAL BOND - A',
        //     fmtAccountBalance: '$17,869.58',
        //     statusCd: 'ACTIVE',
        //     openDt: "2003-06-06",
        //     ownershipNames: ["REV TRUST WITH SSN"],
        //     accountPlan: "INDIVIDUAL IRA",
        //     taxQualCd: "000",
        //     planId: ""
        //   };

        var errorHandler = function(error) {console.log(error); alert("Whoops:  " + error)}
        var accountDetailsView = new AccountDetailsView({clientId: testClientId, groupId: testGroupId, accountSummary: testAccountSummary, errorHandler: errorHandler});
        accountDetailsView.render();


    };
    return { initialize: initialize };
});
