coa = coa || {};
define([ 'jquery', 'underscore', 'backbone' ], function() {
	var Workspace = Backbone.Router.extend({
		routes : {
			'home' : 'showHome',
			'validation' : 'showValidation',
			'verify' : 'showVerify',
			'confirm' : 'showConfirm',
			'*path' : 'showHome'
		},

		defaultRoute : function(path) {},
		showLogin : function() {},
		showHome : function() {
			$('#user-home-view').removeClass('hidden');
			coa.initialServiceCounter = 3;
			coa.initialServiceErrorCounter = 0;
			if (coa.user.get('fromBackButton')) {
				coa.appView.render(coa.user);
				coa.appView.initCustom();
			} else {
				coa.utils.lockForm();
				if (!coa.appView) {
					coa.appView = new coa.views.AppView({
						model : coa.user
					});
				}
				coa.appView.callInitialServices();
			}
			$(window).scrollTop(0);
		},
		showValidation : function() {
			coa.user.set('fromBackButton', true);
			if (!coa.validationView) {
				coa.validationView = new coa.views.Validation({
					model : coa.user
				});
			}
			coa.validationView.render();
			$(window).scrollTop(0);
		},
		showVerify : function() {
			if (!coa.user.get('fromBackButton')) {
				coa.Router.navigate('confirm', {
					trigger : false
				});
				return;
			}
			if (!coa.verificationView) {
				coa.verificationView = new coa.views.Verification({
					model : coa.user
				});
			}
			coa.verificationView.render();

			$(window).scrollTop(0);
		},
		showConfirm : function() {
			coa.user.set('fromBackButton', false);
			if (!coa.confirmationView) {
				coa.confirmationView = new coa.views.Confirmation({
					model : coa.user
				});
			}
			coa.confirmationView.render();
			$(window).scrollTop(0);
		}
	});

	coa.initialiseRouter = function() {
		coa.Router = new Workspace();
		var _hash = window.location.hash;
		if (_hash == '#login' || _hash == '#home') {
		} else {
			window.location.hash = '#';
		}
		if (Backbone.history && !Backbone.History.started) {
			if (!(window.history && history.pushState)) {
				Backbone.history.start({
					pushState : false,
					silent : true
				});
				var fragment = window.location.pathname
						.substr(Backbone.history.options.root.length);
				Backbone.history.navigate(fragment, {
					trigger : true
				});
			} else {
				Backbone.history.start({
					pushState : false
				});
			}
		}
	}
});
