﻿// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
   'backbonesubroute',
  'appcommon/memmorymgr',
  'appcommon/commonutility',
  'appcommon/globalcontext',
  'appmodules/hoc/app/js/views/hocshellview',
  'appmodules/hoc/app/js/views/hocserviceview', 'appmodules/hoc/app/js/model/model-hoc', 'appmodules/hoc/app/data/hoc-matrix', 'appmodules/hoc/app/js/views/hocview',
  'appcommon/analytics'
], function ($, _, Backbone, backbonesubroute, MemmoryMgr, CommonUtil, GlobalContext, HOCShellView, HOCServiceView, HOCModel, HOCMatrix, HOCView, Analytics) {
    var hocRouter = Backbone.SubRoute.extend({
        routes: {
            // Default
        	"takeAction": "showTakeActionTab",
            "new-activity": "handleTheRequest",
            "serviceopportunities": "showHocServiceOpportunities",
            "dol":"showHocDOLTab",
            '*actions': 'defaultAction'
        },
        initialize : function(){
            this.hocshell = undefined;
        },
        defaultAction: function () {
            //if(!this.hocshell){
            //    this.hocshell = new HOCShellView();
            //}
            //this.hocshell.render(undefined);
            //Analytics.analytics.processHOCSubRouteChangeEvent('defaultAction'); // moved to hocshellview
            Backbone.history.navigate("hoc/takeAction", true);
            //this.showTakeActionTab();
            //Analytics.analytics.processHOCSubRouteChangeEvent('defaultAction');
        },
        showHocServiceOpportunities: function () {
            if (!this.hocshell) {
                this.hocshell = new HOCShellView();
            }
            this.hocshell.render(2);
            //Analytics.analytics.recordAction('ServiceOpportunitiesTabInsight:clicked');
            CommonUtil.sumoLog("sumo_page:ServiceOpportunitiesTabInsight:clicked");
        },
        showHocDOLTab: function () {
            if (!this.hocshell) {
                this.hocshell = new HOCShellView();
            }
            this.hocshell.render(3);
            //Analytics.analytics.recordAction('DOLTabInsight:clicked');
            CommonUtil.sumoLog("sumo_page:DOLTabInsight:clicked");
        },
        handleTheRequest: function (param) {
            this.defaultAction("newActivity");
        },
        showTakeActionTab: function () {
            if (!this.hocshell) {
                this.hocshell = new HOCShellView();
            }
            this.hocshell.render(1);
            //Analytics.analytics.recordAction('TakeActionTabInsight:clicked');
            CommonUtil.sumoLog("sumo_page:TakeActionTabInsight:clicked");
          },
    });
    return { hocRouter: hocRouter };
});
