var express = require('express');
var router = express.Router();
var searchModel = require('./search.model');

var error = {
    errorMessageCode: 500,
    errorDescription: 'Something went wrong...',
    uiErrorDisplayMessage: 'We weren\'t able to process your request. Please try again. If you still need help, contact at 1-999-999-9999',
    transactionStatus: 'E',
};

router.route('/ask-verizon-api/search')
    .post(function(req, res) {
        res.send(searchModel.response);
    });

module.exports = router;
