// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RedumptionDetailsModelSchema = new mongoose.Schema({
    RedumptionDetailsResp: {
        type: Array,
        "default": []
    }
});

var RedumptionDetailsModelLookUp = mongoose.model('RedumptionDetailsModelLookUp', RedumptionDetailsModelSchema);

var RedumptionDetailsModel = new RedumptionDetailsModelLookUp({
    RedumptionDetailsResp : {
        "redemption": {
            "fundWiseData": [
                {
                    "redemptionDate": "18 Feb 2016",
                    "redemptionAmount": "1200",
                    "nav": "120.52",
                    "units": "98.87",
                    "bankName": "ICICI Bank",
                    "bankAccountNo": "1000110191",
                    "payoutType": "Cheque"
                },
                {
                    "redemptionDate": "18 Feb 2016",
                    "redemptionAmount": "30,000",
                    "nav": "120.52",
                    "units": "98.87",
                    "bankName": "ICICI Bank",
                    "bankAccountNo": "1000110191",
                    "payoutType": "Cheque"
                }
            ],
            "fundInfo": {
                "fund": "Franklin India Prima plus",
                "folioNo": "124523",
                "accountNo": "000901524856",
                "modeOfHolding": "Joint",
                "goal": "Wealth creation",
                "goalDetails": "Buying a House"
            }
        }
     }
});

RedumptionDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating RedumptionDetailsModelLookUp table, please contact admin...');
    } else {
        RedumptionDetailsModelLookUp.remove({}, function(err) {
            console.log('RedumptionDetailsModelLookUp collection removed');
            RedumptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RedumptionDetailsModelLookUp table, please contact admin...');
                }
                console.log('RedumptionDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RedumptionDetailsModelLookUp;
