/**
 * @ngdoc property
 * @name selectCount Directive
 * @description
 *
 * - selectCount Directive will display the total count by default. And the count can change based on the no.of items selected. 
 *
 **/
'use strict';

var selectCount = function() {
	return {
            template: require('./selectCount.html'),
            restrict: 'E',
            replace: true,
            scope: {
              lable: "@",
              count: "="
            },
            controller: function($scope, $element, $attrs){  
                // $scope.showLabel = false;
                // $scope.$on(guestEventConstants.distributor.GUE_DZ_SEL_CNT, function(event, data){
                //     if(data){
                //         $scope.showLabel = true;
                //         $scope.count = data;
                //     }else{
                //         $scope.showLabel = false;
                //     }
                // });
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

selectCount.$inject = [];
module.exports = selectCount;