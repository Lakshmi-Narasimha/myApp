/**
 * - This directive is responsible for displaying the review switch advisor Form.
 *
 **/
 'use strict';

 var fticEkycReg = function (transactModel, transactEventConstants, buildPlanModelService) {
    return {
        template: require('./ekycRegistration.html'),
        restrict: 'E',
        controller: function ($scope, $element, $attrs,$state) { 
          console.info("EKyc directive Registration Controller!!");

            $scope.folioId =  buildPlanModelService.getInvestorSearch().folioId;
            $scope.inputObj = buildPlanModelService.getInvestorSearch().holders;
            // $scope.folioId =  buildPlanModelService.getInvestorSearch();
            console.log("folioId.....,", $scope.folioId);
            // $scope.inputObj =  transactModel.getInvestorDetails();
            console.log("inputObj....", $scope.inputObj);
            $scope.ekycMainObj = []; //investor main obj 
            $scope.closeFlow = false;
            $scope.openFlow = true;
            $scope.resultObj;
            var instantKycVals = [];

            angular.forEach($scope.inputObj, function(obj, key){
                $scope.ekycMainObj.push([
                {
                    key: $scope.inputObj[key].type=='Secondholder'?"Second Holder Name" :"Third holder name" && $scope.inputObj[key].type =='Firstholder'?"First Holder Name" :"Third holder name" ,
                    value: $scope.inputObj[key].name
                },
                {
                    key: "PAN/PEKRN/AADHAR",
                    value: $scope.inputObj[key].pan
                },
                {
                    key: "KYC Status",
                    value: $scope.inputObj[key].kycregistered==true?"Registered" :"Not Registered"
                }
                ]);
            });

            // $scope.folioIdheader = {
            //     heading : 'FolioId : '+$scope.folioId
            // };

            $scope.physicalKycValidation = function(){
                $scope.phyResult = false;
                angular.forEach($scope.resultObj, function(value, key){
                    if ($scope.resultObj[key].aadhar == "" || null || undefined) {
                        $scope.phyResult = true;
                    }
                });
                return $scope.phyResult;
            }

            $scope.continue = function(){
                if ($scope.ekycReg.$valid) {
                    $scope.$broadcast(transactEventConstants.transact.INSTANT_KYC);
                    $scope.resultObj = $scope.ekycReg.kycVal;
                    if ($scope.physicalKycValidation()) {
                        //transactModel.setInstantKyc = [];
                        $scope.closeFlow = true;
                        $scope.openFlow = false;
                    }
                    else{
                        instantKycVals = $scope.ekycReg.kycVal;
                        transactModel.setInstantKyc(instantKycVals);
                        console.log("Came back after setting");
                        $state.go("smartSol.ekyc");
                    }                    
                }
            }
        },
        link: function (scope, iElement, iAttrs, controller) {

        }      
    };
};

fticEkycReg.$inject = ['transactModel','transactEventConstants', 'buildPlanModelService'];
module.exports = fticEkycReg;