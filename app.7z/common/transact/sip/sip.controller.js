/**
 * @ngdoc property
 * @name SIP Controller
 * @requires $scope
 * @requires $filter
 * @requires TransactConstant
 * @description
 *
 * - Handles the basic variable settings needed for the SIP.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function sipController($scope, $filter, TransactConstant, transactModel, authenticationService) {  
    var translateFilter = $filter('translate'); 
    $scope.header.title = TransactConstant.sip.SIP_HEADING;  
    $scope.accordionData =  {title : translateFilter(TransactConstant.common.SELECT_FUND)};
    $scope.config.txnFormDetails.title = "Payment Details";
    if(!authenticationService.isInvestorLoggedIn()) {
	    $scope.reviewDetailsState = "transact.review.sip";
	}else {
		$scope.reviewDetailsState = "invTransact.review.sip";
	}

    $scope.isNewInvestor = transactModel.isNewInvestor;
    $scope.isNewCreateFolio = transactModel.getIsNewFolio();
}

sipController.$inject = ['$scope', '$filter', 'TransactConstant', 'transactModel', 'authenticationService'];
module.exports = sipController;