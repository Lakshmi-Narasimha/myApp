﻿/* iFrame resizing */
define([
  'jquery',
  'bootstrap'
], function ($, bootstrap) {
    var garabageCollection = {};
    var setcurrentview = function (view) {
        if ((garabageCollection.currentview != undefined || garabageCollection.currentview)) {
            garabageCollection.currentview.close();
        }
        garabageCollection.currentview = view;
    };
    function clearView(view){
    	if(view)
    		view.close();
    }
    var memmorymgr = {
        setcurrentview: setcurrentview,
        clearView: clearView
    };      
    return memmorymgr;
}); 