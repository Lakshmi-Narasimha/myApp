/**
 * @ngdoc service
 * @name Common CacheFactory
 * @requires $cacheFactory
 * @description
 *
 * - Setting the default $cacheFactory options for http call
 *
 */


'use strict';

var cacheFactory = function($cacheFactory) {

	$cacheFactory('fticCache', {
        capacity : 1000,
        maxAge : 900000,
        cacheFlushInterval : 6000000,
        deleteOnExpire : 'aggressive',
        storageMode : 'localStorage'
    });
};

cacheFactory.$inject = ['$cacheFactory'];
module.exports = cacheFactory;
