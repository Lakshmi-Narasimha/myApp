/* eslint-disable */
'use strict';

describe('Directive: Mailback', function() {

	var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('commmon.components'));

    
    beforeEach(function() {

 		angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
  			compile = $compile;
  		
        });

        var element = angular.element('<ftic-mailback></ftic-mailback>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope(); 
		scope.$digest();

    });

	it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should define recommendations data', function() {
        expect(directiveEle.html()).toBeDefined();
    });

});