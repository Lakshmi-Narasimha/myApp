'use strict';

var dtpModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, transactModel, authenticationService, fundDetailsModel, ifscModel, TransactConstant) {
    // var _swpDetails = null;
    var _selectedObj = null;
    var _detailsObj = null,
        _type = null;

    var _dividendOptn = null;
    var dtpModel = {

        /* fetchSwpDetails : function () {
             
             var deferred = $q.defer();
             Restangular.all('/swp').getList().then(function (swp) {
                 deferred.resolve(swp);
             }, function (resp) {
                 deferred.reject(resp);
                 console.log('error');
             });
             return deferred.promise;
         },

         // setReviewSwpDetails : function(selectedObj){
         //     _selectedObj = selectedObj;            
         // },

         // getReviewSwpDetails : function() {
         //     return _selectedObj;
         // },
         
         getSwpDetails: function() {
             return _swpDetails;
         },
         
         setSwpDetails: function(swpDetails) {
             _swpDetails = swpDetails;
         },*/


        validateDTP: function() {

            var deferred = $q.defer();
            var params = {};
            var body = {};
            body.folioId = transactModel.getTransactDetails().investorDetails.folioId || "";
            body.accountNo = transactModel.getTransactDetails().fundDetails.tschvalAccno || "";

            body.webRefNo = '',
            body.txnType = 'DTP',
            body.fundOption = transactModel.getTransactDetails().fundDetails.tschvalAccno.substring(0,3);
            if(transactModel.getTransactDetails().switchDetails.destinationFund.accNo){
                body.toAccount = transactModel.getTransactDetails().switchDetails.destinationFund.accNo;
            }else{
                body.toAccount = 'NEW';
            }
            body.toFundOption = transactModel.getTransactDetails().switchDetails.destinationFund.fundOption || "";
            //body.dividendOption = transactModel.getTransactDetails().switchDetails.destinationFund.dividendFlag;
            if(transactModel.getTransactDetails().switchDetails.destinationFund.fundOptDesc.indexOf('Taxshield') !== -1){
                body.dividendOption = transactModel.getTransactDetails().fundDetails.dividendType.substring(0,1);
            }else if(transactModel.getTransactDetails().switchDetails.destinationFund.fundOptDesc.indexOf('Growth') !== -1){
                body.dividendOption = transactModel.getTransactDetails().switchDetails.destinationFund.dividendFlag;
            }else{
                body.dividendOption = transactModel.getTransactDetails().fundDetails.dividendType.substring(0,1);
            }
            
            body.distId = "0000000000";
            body.subDist = "";
            body.subBrokerARN = "";
            body.userType = "10";
            body.euin = "";
            body.euinFlag = "N";
            body.markerId = "",
                body.validation = "Y"


            params.guId = authenticationService.getUser().guId;
            Restangular.one('transact/registerDtp').customPOST(body, "", params, {}).then(function(data) {
                deferred.resolve(data);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },

        getData: function() {
            return _detailsObj;
        },

        setDataObj: function(detailsObj) {
            _detailsObj = detailsObj;
        },
        getDataObj: function(detailsObj) {
            return _detailsObj;
        },
        setType: function(type) {
            _type = type;
        },
        getType: function() {
            return _type;
        }
    };
    return dtpModel;
};

dtpModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'transactModel', 'authenticationService', 'fundDetailsModel', 'ifscModel', 'TransactConstant'];

module.exports = dtpModel;
