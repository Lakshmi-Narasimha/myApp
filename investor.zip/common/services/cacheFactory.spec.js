/**
 * @ngdoc property
 * @name cacheFactory spec
 * @requires $scope
 * @requires constants
 * @description
 *
 * - Unit test suite for 'cacheFactory.spec.js'.
 *
 **/

 'use strict';

describe('#common->services->cacheFactory spec', function() {
	var $cacheFactory;    
    beforeEach(angular.mock.module('advisor'));

    beforeEach(function() {

        angular.mock.inject(function(_$cacheFactory_) {
        	$cacheFactory = _$cacheFactory_;
        });
    });

    it('should instantiate cacheFactory', function(){

        expect($cacheFactory).toBeDefined();
    });
});