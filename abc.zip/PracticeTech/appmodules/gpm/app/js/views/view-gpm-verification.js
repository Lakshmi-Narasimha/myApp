define(['jquery', 'underscore', 'backbone', 'spinner','appcommon/globalcontext', 'appcommon/analytics','appmodules/gpm/app/js/lib/validate.js','appcommon/commonutility',"services/dataservice", 'moment',
		'text!appmodules/gpm/app/templates/gpmcontainer.html','text!appmodules/gpm/app/templates/gpmcommonsectionstemplate.html','text!appmodules/gpm/app/templates/gpmadvsrclntinfotemplate.html','text!appmodules/gpm/app/templates/gpmverificationsections.html','appmodules/gpm/app/js/utils','appmodules/contactprofile/app/models/preferenceviewmodel',
		'text!appmodules/gpm/app/templates/gpmalertprefverif.html', 'errorLog', 'appmodules/contactprofile/app/models/cpviewmodel', 'text!appmodules/gpm/app/templates/gpmverificationcommunicationprefsections.html',
        'text!appmodules/gpm/app/templates/gpmdeathverify.html', 'text!appmodules/gpm/app/templates/gpmverificationsuitability.html',
        'appcommon/constants',
        'text!appmodules/gpm/app/templates/gpmverificationemployment.html'], function ($, _, Backbone, Spinner, GlobalContext, Analytics, Validator, CommonUtil, DataService, Moment,
            GPMContainerTemplate, CommonSectionTemplate, GPMAdvsrClientTemplate, VerificationSectionTemplate, Utils,
            PreferenceViewModel, AlertVerificationTemplate, ErrorLog, CPViewModel, CommunicationPrefVerificationtemplate,
            GPMDeathVerfiTemplate, GPMVerifySuitabilityTemplate, Constants, GPMVerifyEmploymentTemplate) {
	var _prefAlertPayload = {
			   "dlvAddrs": [],
			   "prfrs": [
			      {
			         "prfrTypCd": "S",
			         "prfrId": "7",
			         "prfrNm": "Alerts",
			         "prfrTitle": null,
			         "prfrReqInd": null,
			         "prfrChoPtrnCd": null,
			         "editRules": null,
			         "prfrChoGrps": null,
			         "dlvMchnsms": [],
			         "relPrfrs": []
			      }
			   ]
			},dlvMchnsms={
			 "dlvTypCd": "",
             "dlvReqInd": false,
             "dlvAlwMultSlctInd": false,
             "dlvChos": []
			},
			dlvChos = {
            "dlvDestId": "",
            "dlvDestCtx": "EMS.EML",
            "alwDestChgInd": false,
            "dlvChoSlctInd": false
			}
			,categoryRelPref= {
            "prfrTypCd": "",
            "prfrId": "",
            "prfrNm": "",
            "prfrTitle": null,
            "prfrReqInd": null,
            "prfrChoPtrnCd": null,
            "editRules": null,
            "prfrChoGrps": null,
            "dlvMchnsms": null,
            "relPrfrs": []
     		}
		              ,indvdlRelPref={
				        "prfrTypCd": "",
				        "prfrId": "",
				        "prfrNm": "",
				        "prfrTitle": "",
				        "prfrReqInd": true,
				        "prfrChoPtrnCd": "DeliveryChoice",
				        "editRules": [
				           {
				              "usrRole": "Client",
				              "editableInd": true
				           },
				           {
				              "usrRole": "Advisor",
				              "editableInd": true
				           }
				        ],
				        "prfrChoGrps": null,
				        "dlvMchnsms": [],
				        "relPrfrs": null
		     
			};
			var self = null;
			var _containerView = Backbone.View.extend({
			    el: $("#practicetech-subapp"),
			    id: 'practicetech-subapp',
			    events: {
			        'click #gpm-back-to-step1,#m-gpm-back-to-step1':'navigateToStep1',
			        'click #gpm-step2-next-button,#m-gpm-step2-next-button':'doPreSubmitProcessing',
			    },
			    initialize: function () {
			        self = this;
			    },
			    render: function (data,updateEgment) {
			        var _changedItems = this.model.get("items");
			        if(this.model.get('updateMode') == "phonenumbers" || this.model.get('updateMode') == "email"){
			            _changedItems = this.model.getChangedItems();
			        }
			        window.scrollTo(0,0);
			    	//var _sectionTemplate = Utils.getTemplateSection(UpdateSectionTemplate, 'section[data-section='+updateEgment+']');
			        var _commonTemplate = _.template(CommonSectionTemplate);
			        var _sectionName = { sectionName: updateEgment };
			        var _navSectionSubTemplate = Utils.getTemplateSection(_commonTemplate(_sectionName), '#nav-section-step2');
			        var _pageHeadingTemplate = Utils.getTemplateSection(_commonTemplate(_sectionName), '#pt-gpm-update-step2-page-title');
			        var _data = { items: _changedItems };
			        //load advsr/client info
			        var _advtmplt = _.template(GPMAdvsrClientTemplate);
			        var _advsrInfoCompiledTmplt = _advtmplt({ step: 2, data: this.model.toJSON(), sectionName: updateEgment });
			        this.$el.find('#gpm-advsr-client-info-container').html(_advsrInfoCompiledTmplt);
			        //load the page header template to container
			        $('#gpm-step-title-container').html(_pageHeadingTemplate);
			        //load the form fields to the container
			        //load the naviagtion container to the container
			        $('#gpm-step-navigation-button-container').html(_navSectionSubTemplate);
			        var _verifytempalte = VerificationSectionTemplate;
			        if(this.model.get('updateMode') == "alert"){
			            _verifytempalte=AlertVerificationTemplate
			        }else if(this.model.get('updateMode') == "communicationPreference"){
			            _verifytempalte= CommunicationPrefVerificationtemplate;
			            var _data ={data:this.model};
			        } else if (this.model.get('updateMode') == "reportclientsdivorce") {
			        	$('#gpm-step2-next-button, #m-gpm-step2-next-button').html('Report');
			        } else if (this.model.get('updateMode') == "reportclientsdeath") {
			        	$('#gpm-step2-next-button, #m-gpm-step2-next-button').html('Report');
			        	_verifytempalte = GPMDeathVerfiTemplate;
			        	var _data = { items: this.model.get('items') };
			        } else if (this.model.get('updateMode') == "suitability") {
			        	_verifytempalte = GPMVerifySuitabilityTemplate;
			        } else if (this.model.get('updateMode') == "employment") {
			            _data = { data: this.model.toJSON() };
			            _verifytempalte = GPMVerifyEmploymentTemplate;
			        }
			        var _tmplt = _.template(_verifytempalte);
			        var _compiledTemplate = _tmplt(_data);
			        $('#ensure-accuracy-section-holder').html(Utils.getTemplateSection(_commonTemplate(_sectionName), '#ensure-accuracy-text')).removeClass('hidden');
			        $('#gpm-form-update-field-container').html(_compiledTemplate);
		            $('#confirm-msg-section-holder').html('').addClass("hidden");
		            $('.gpm-step.step2').removeClass("finished pending").addClass("active");
		            Spinner.hide();
		        },
		        navigateToStep1:function(){
		        	//this.validateStepCompletion();
		        	$('.gpm-step.step1').removeClass("finished").addClass("active");
		        	$('.gpm-step.step2').removeClass("active");
		        	$('#ensure-accuracy-section-holder').addClass("hidden");
		        	Backbone.history.navigate('gpm/update/' + this.model.get('updateMode'), true);
		            //disable navigator
		        	$('#transparent-nav').show();
		        },
		        validateStepCompletion:function(){
		        	var _updateMode = this.model.get('updateMode');
		        	var _items = this.model.get('Items');
		        	var _stepCompleted  = true;
		        	
		        	var _completedSteps = this.model.get('completedSteps');
		        	if(_stepCompleted){
		        		//mark step as completed
						if(_completedSteps.indexOf(2) == -1){
							this.model.get('completedSteps').push(2);
						}
						$('.gpm-step.step2').addClass("finished");
		        	}else{
		        		$('.gpm-step.step2').removeClass("finished active").addClass("pending");
		        		_completedSteps.splice(_completedSteps.indexOf(2));
		        	}
		        	
		        },
		        doPreSubmitProcessing:function(){
		        	var _self = this;
		        	var _updateMode = this.model.get('updateMode');
		        	//call different service based on updateMode
		        	switch (_updateMode) {
		        	case "alert":
						_self.prepareAlertPayloadAndCallUpdate();
						break;
		        	case 'documentDelivery':
		        	    _self.getDocumentDeliveryUpdate();
		        	    break;
					case "gender":
						this.navigateToStep3();
						break;
		    	    case 'greeting':
		    	    	_self.prepareEbixPayloadAndCallUpdate();
		    	        break;
		    	    case 'remarks':
		    	    	_self.prepareEbixPayloadAndCallUpdate();
		    	        break;
		    	    case 'dependents':
		    	    	this.prepareColaPayloadAndCallUpdate(self.model.get('updateMode'));
		    	        break;
		    	    case 'honorific':
		    	    	this.prepareColaPayloadAndCallUpdate(self.model.get('updateMode'));
		    	        break;
		    	    case 'maritalstatus':
		    	    	this.prepareColaPayloadAndCallUpdate(self.model.get('updateMode'));
		    	        break;
		    	    case 'passport':
		    	    	this.prepareColaPayloadAndCallUpdate(self.model.get('updateMode'));
		    	        break;
		    	    case 'subtype':
		    	    	_self.prepareEbixPayloadAndCallUpdate();
		    	        break;
		    	    case 'employment':
		    	    	//this.navigateToStep3();
		    	    	this.prepareEmploymentPayloadAndCallUpdate();
		    	        break;
		    	    case 'suitability':
		    	    	this.getSuitabilityUpdatepayload();
		    	    	break;
		        	case 'reportclientsdeath':
		        	    this.reportClientsDeath();
		        	        break;
		    	    case 'driverslicense':
		    	    	this.prepareColaPayloadAndCallUpdate(self.model.get('updateMode'));
		    	    	  break;
		    	    case 'communicationPreference':
		    	    	this.prepareCommnctnPrefPayloadAndCallUpdate(self.model.get('updateMode'));
		    	    	break;
                    case 'reportclientsdivorce':
                        _self.prepareClientsDivorceAndCallUpdate();
		        	    break;
					default:
						break;
					}

		        	//call the service based on 
		        	
		        },
		        prepareColaPayloadAndCallUpdate: function(updateMode) {
		            var _self = this, _gpmModel = this.model;
		            var _items = this.model.get('items');
		            var _colaPayload = {
		                    "clientPersonal":[]   
		            }
		            var _personalItem = {
		            	"actnCd" : "",
		            	"propNm" : "",
		            	"propVal" : ""
		            	}

		            switch (updateMode) {
					case "maritalstatus":
						 var _maritalStatus = _items.find(function (row) { return row.get("itemType") == "maritalstatus" });
						 _personalItem = {
					            	"actnCd" : "update",
					            	"propNm" : "mrtlStatCd",
					            	"propVal" : _maritalStatus.get("changedItemValueId")
					            	}
						 _colaPayload.clientPersonal.push(_personalItem);
						break;
					case "honorific":
						 var _honorific = _items.find(function (row) { return row.get("itemType") == "honorific" });
						 _personalItem = {
			            	"actnCd" : "update",
			            	"propNm" : "clHnrfNm",
			            	"propVal" : _honorific.get("changedItemValueId") ==""?" ":_honorific.get("changedItemValueId")
			            	}
						 _colaPayload.clientPersonal.push(_personalItem);
						break;
					case "dependents":
						 var _dependents = _items.find(function (row) { return row.get("itemType") == "dependents" });
						 var _depCount = _dependents.get("changedItemValueId");
						 _depCount = _depCount.toString().lpad("0",3);
						 _personalItem = {
					            	"actnCd" : "update",
					            	"propNm" : "dpdtCnt",
					            	"propVal" : _depCount
					            	}
						 _colaPayload.clientPersonal.push(_personalItem);
						break;
					case "passport":
						 var _passportNumber =  _items.find(function (row) { return row.get("itemType") == "passport" }).get("changedItemValueId");
						 _passportNumber = _passportNumber.toString();
						 _passportNumber.trim();
						 var _updateCode = _passportNumber?"update":"remove";
						 _personalItem = {
			            	"actnCd" : _updateCode,//remove also
			            	"propNm" : "psprtNbr",
			            	"propVal" : _passportNumber
			            	}
						 _colaPayload.clientPersonal.push(_personalItem);
						break;
					case "driverslicense":
						 var _drvrLcns =  _items.find(function (row) { return row.get("itemType") == "driverslicense" }).get("changedItemValueId"),
						 	_state  = _items.find(function (row) { return row.get("itemType") == "stateid" }).get("changedItemValueId");
						 var _stateActnCd = "update",_drvrLcnsActnCd = "update";
						 _drvrLcns = _drvrLcns.toString();
						 if(_drvrLcns.length == 0){
							 _drvrLcns ="";
							 _state = "";
							 _stateActnCd = "remove";
							 _drvrLcnsActnCd = "remove";
						 }else{
							 _stateActnCd = "update";
							 _drvrLcnsActnCd = "update";
						 }
						 var _updateCode = _passportNumber?"update":"remove";
						var  _personalItemDL = {
			            	"actnCd" : _drvrLcnsActnCd,//remove also
			            	"propNm" : "drvLicNbr",
			            	"propVal" : _drvrLcns
			            	};
						var  _personalItemST = {
				            	"actnCd" : _stateActnCd,//remove also
				            	"propNm" : "drvLicStCd",
				            	"propVal" : _state
				            }
						 _colaPayload.clientPersonal.push(_personalItemDL);
						 _colaPayload.clientPersonal.push(_personalItemST);
						break;

					default:
						break;
					}
		            Spinner.show();
		           
		            DataService.updateClientPersonalInfo(_gpmModel.get('clientId'), _colaPayload).then(function (response,statusMessage,xhr) {
			            	if(!response){
			        			self.model.set('submitStatus',"success");
		        				self.navigateToStep3();
			            	}else{
			            			Spinner.hide();
									Utils.showServiceError(xhr);
			        		}})
			            	.fail(function (Error) {
			            		Spinner.hide();
								Utils.showServiceError(Error);
			            	});     
		           
		        },
		        prepareEbixPayloadAndCallUpdate:function(updateMode){
		        	
		        	var _self = this, _gpmModel = this.model;
		        	var _items = this.model.get('items');
		        	var _remarks = _items.find(function(row){return row.get("itemType") == "remarks"}),
					_clGreeting = _items.find(function(row){return row.get("itemType") == "clGreeting"}),
				    _clJobTitle = _items.find(function(row){return row.get("itemType") == "clJobTitle"}),
					_contactSubType = _items.find(function(row){return row.get("itemType") == "contactSubType"});
		        	var _ebixPayload = {
							"id" : _gpmModel.get('contactId'),
							"ctx" : "Ebix",
							"type" : "Contact",
							"contactType" : "Client",
							"remarks" : _remarks?_remarks.get('changedItemValueId'):"",
							"PersonContact" : {
							    "clGreeting": _clGreeting ? _clGreeting.get('changedItemValue') : "",							    
							    "clOccupation": "",
								"clJobTitle" :_clJobTitle?_clJobTitle.get('changedItemValueId'):"",
							},
							"TobeDeletedPhone" : "",
							"EditedPhone" : "",
							"TobeDeletedWebAddress" : "",
							"EditedWebAddress" : "",
							"TobeDeletedAddress" : "",
							"EditedAddress" : "",
							"BusinessContact" : {},
							"contactSubType" :_contactSubType?_contactSubType.get('changedItemValue'):"",
						}
		        	
		        	 Spinner.show();
		        	DataService.editContact(_gpmModel.get('submitterId'), _ebixPayload)
	            	.then(function (response,statusMessage,xhr) {
	            	    if(typeof(response) =="string" && response.indexOf("Success") > -1){
	            	    	_self.navigateToStep3();
	            	    }else{
	            	    	 Spinner.hide();
							Utils.showServiceError(xhr);
	            	    }
	            	    
	            	})
	            	.fail(function (xhr) {
	            		Spinner.hide();
						Utils.showServiceError(xhr);
	            		//ErrorLog.ErrorUtils.myError(Error);
	            	});
		        },
		        getDocumentDeliveryUpdate: function () {
		            var _docJSONRes = PreferenceViewModel.getData().documentDelivery;
		            var _self = this, _gpmModel = this.model;
		            var _modelData = this.model;
		            var _items = _modelData.get('items');

		            var _prfrdShareHolder = _items.find(function (row) { return row.get("itemType") == "prefrcShareHolder" }),
                       _prfrdAccount = _items.find(function (row) { return row.get("itemType") == "prefrcAccount" }),
                       _prfrdFinConfirm = _items.find(function (row) { return row.get("itemType") == "prefrcFinConfirm" }),
                       _prfrdDocType = _items.find(function (row) { return row.get("itemType") == "prefrcDocType" });

                    var _clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId; 
                    var _displayDocDeliContent = _items.find(function (row) { return row.get("itemType") == "displayDocDeliContent" });
		            
		            DataService.getClientOnlineAccessPreference(_clientId).then(function (result) {
					var collection = result[0].results;
						if (collection && collection.length > 0) {
							$.each(collection, function (key, row) {
								if (row.status == "Active" && row.rsrcCd == "MYFA") {
									_displayDocDeliContent.set('changedItemValue', "displayDocDeliContent");
				        			_displayDocDeliContent.set('changedItemValueId', "displayDocDeliContent");	        		
								}
							});
						}					
					}).fail(function (xhr) {
						Spinner.hide();
						ErrorLog.ErrorUtils.myError(xhr, true);
					});  	        		
	        		
		            var _docpayload = {
		                "preferences": []
		            }
		            var valueShareCdType = _prfrdShareHolder.get("changedItemValueId"), valueAccCdType = _prfrdAccount.get("changedItemValueId"),
		                valueFinCdType = _prfrdFinConfirm.get("changedItemValueId"), valueDocCdType = _prfrdDocType.get("changedItemValueId");

		            _shareHolderItem = {
		                "actnCd": "UPDATE",
		                "typCd": "Paper Suppression",
		                "subTypCd": "Shareholder Communication",
		                "choTypCd": "Not Applicable",
		                "valCd": (valueShareCdType.toLowerCase() === 'online') ? "Yes" : "No",
		                "srcCd": "OST",
		                "reasCd": "Customer Opted to Change the Preference",
		                "statCd": "Active",
		                "dlvModeCd": "Primary Email",
		            }
		            _docpayload.preferences.push(_shareHolderItem);

		            _accountItem = {
		                "actnCd": "UPDATE",
		                "typCd": "Paper Suppression",
		                "subTypCd": "Consolidated Statement",
		                "choTypCd": "Not Applicable",
		                "valCd": (valueAccCdType.toLowerCase() === 'online') ? "Yes" : "No",
		                "srcCd": "OST",
		                "reasCd": "Customer Opted to Change the Preference",
		                "statCd": "Active",
		                "dlvModeCd": "Primary Email",
		            }
		            _docpayload.preferences.push(_accountItem);

		            _finItem = {
		                "actnCd": "UPDATE",
		                "typCd": "Paper Suppression",
		                "subTypCd": "Financial Confirmations",
		                "choTypCd": "Not Applicable",
		                "valCd": (valueFinCdType.toLowerCase() === 'online') ? "Yes" : "No",
		                "srcCd": "OST",
		                "reasCd": "Customer Opted to Change the Preference",
		                "statCd": "Active",
		                "dlvModeCd": "Primary Email",
		            }
		            _docpayload.preferences.push(_finItem);

		            _docItem = {
		                "actnCd": "UPDATE",
		                "typCd": "Paper Suppression",
		                "subTypCd": "Other Documents",
		                "choTypCd": "Not Applicable",
		                "valCd": (valueDocCdType.toLowerCase() === 'online') ? "Yes" : "No",
		                "srcCd": "OST",
		                "reasCd": "Customer Opted to Change the Preference",
		                "statCd": "Active",
		                "dlvModeCd": "Primary Email",
		            }
		            _docpayload.preferences.push(_docItem);

		            Spinner.show();
		            DataService.updateDocumentDeliveryInfo(_gpmModel.get('clientId'), _docpayload)
	            	.then(function (response, statusMessage, xhr) {
	            	    if (response == "") {
	            	        _self.navigateToStep3();
	            	    } else {
	            	        Spinner.hide();
	            	        Utils.showServiceError(xhr);
	            	    }
	            	})
	            	.fail(function (xhr) {
	            	    Spinner.hide();
	            	    Utils.showServiceError(xhr);
	            	});

		        },
		        prepareAlertPayloadAndCallUpdate:function(){
		        	var _alertJsonRes = PreferenceViewModel.getData().alertsAndCommunication;
		        		_alertJsonresCopy = this.getObjectCopy(_alertJsonRes);
		        	var _self = this;
		        	var _modelData = this.model;
		        	var _items = _modelData.get('items');
		        	var _alertPayload =this.getObjectCopy(_prefAlertPayload);
		        	var _prfrdEmail = _items.find(function(row){return row.get("itemType") == "preferedEmail"}),
					_prfrdPhone = _items.find(function(row){return row.get("itemType") == "preferedPhone"}),
				    _myProfile = _items.find(function (row) { return row.get("itemType") == "myProfile" }),
					_accountMgmt = _items.find(function (row) { return row.get("itemType") == "accountManagement"}),
					_workWithAdvsr = _items.find(function(row){return row.get("itemType") == "workingWithAdvisor"});
		        	var _catgryrelPrfrs = [],_sectionDelvryMchnsm=[];
		        	//set prefrd email data
		        	var _emaildlvMchnsms= this.getObjectCopy(dlvMchnsms);
		        	_emaildlvMchnsms.dlvTypCd = "email";
		        	var _emails = _prfrdEmail.get('customValues').emails, _prfrdEmailType = "Primary"
		        	for(var i=0;i<_emails.length;i++){
		        		var _emailDevlChcs = this.getObjectCopy(dlvChos);
		        			_emailDevlChcs.dlvDestId = _emails[i].emlUseCd + " Email";
		        			if(_prfrdEmail.get('changedItemValue')[0] == _emails[i].emlUseCd){
		        				_prfrdEmailType = _emails[i].emlUseCd+ " Email";
		        				_emailDevlChcs.dlvChoSlctInd = true;
		        			}else{
		        				_emailDevlChcs.dlvChoSlctInd = false;
		        			}
		        			_emailDevlChcs.alwDestChgInd= true,
		        			_emailDevlChcs.dlvDestCtx = "EMS.EML";
		        			_emaildlvMchnsms.dlvChos.push(_emailDevlChcs);
		        	}
		        	_sectionDelvryMchnsm.push(_emaildlvMchnsms);
		        	//prefrd phone details
		        	if(_prfrdPhone.get('changedItemValue').length>0){
		        		var _phnvMchnsms= this.getObjectCopy(dlvMchnsms);
		        		_phnvMchnsms.dlvTypCd = "SMS";
		        		var _phnDevlChcs = this.getObjectCopy(dlvChos);
		        		_phnDevlChcs.dlvDestId = _prfrdPhone.get('customValues').dlvDestId;
		        		_phnDevlChcs.alwDestChgInd = false;
		        		_phnDevlChcs.dlvChoSlctInd = true;
		        		_phnDevlChcs.dlvDestCtx = "COLA.TELE";
		        		_phnvMchnsms.dlvChos = [_phnDevlChcs];
		        		_sectionDelvryMchnsm.push(_phnvMchnsms);
		        	}
		        	//catgry relPrfrs, MyProfiles
		        	//get Myprofiles data
		        	_catgryrelPrfrs.push(getCategoryDataInFormat(_myProfile));
		        	_catgryrelPrfrs.push(getCategoryDataInFormat(_accountMgmt));
		        	//get data for WOking with Advsr
		        	_catgryrelPrfrs.push(getCategoryDataInFormat(_workWithAdvsr));
		        	//get data for account management
		        	//_catgryrelPrfrs.push(getAccountManagementData(_alertJsonresCopy));
		        	_alertPayload.prfrs[0].dlvMchnsms = _sectionDelvryMchnsm;
		        	_alertPayload.prfrs[0].relPrfrs = _catgryrelPrfrs;
		        function getCategoryDataInFormat(categoryData){
		        	var _indvdlCatgryRelPrfrs = _self.getObjectCopy(categoryRelPref);
		        	var _indvdlCatgryServcPrpty = categoryData.get('customValues'), _indvdlCatgryIndividlvals = categoryData.get('changedItemValue');
	        		_indvdlCatgryRelPrfrs.prfrTypCd = _indvdlCatgryServcPrpty.prfrTypCd;
	        		_indvdlCatgryRelPrfrs.prfrId =  _indvdlCatgryServcPrpty.prfrId;
	        		_indvdlCatgryRelPrfrs.prfrNm =  _indvdlCatgryServcPrpty.prfrNm;
	        		for(var k=0; k<_indvdlCatgryIndividlvals.length;k++){
	        			var _indvdlPref = _self.getObjectCopy(indvdlRelPref),_indVdlServiceProperty = _indvdlCatgryIndividlvals[k]['customValues'];
	        			_indvdlPref.prfrTypCd = _indVdlServiceProperty.prfrTypCd;
	        			_indvdlPref.prfrId =  _indVdlServiceProperty.prfrId;
	        			_indvdlPref.prfrNm = _indVdlServiceProperty.prfrNm; 
	        			_indvdlPref.prfrTitle = _indVdlServiceProperty.prfrNm;
	        			_indvdlPref.dlvMchnsms = [];
	        			var _indvdldlvMchnsms = [],_indvdlCatgryEmalMchnsm = _self.getObjectCopy(dlvMchnsms);
	        					_indvdlCatgryEmalMchnsm.dlvTypCd = "email";
	        					_indvdlCatgryEmalMchnsm.dlvReqInd = _indvdlCatgryIndividlvals[k].values[0] =="Required" ?true:false;
	        					_indvdlCatgryEmalMchnsm.dlvAlwMultSlctInd = false;
	        					_indvdlCatgryEmalMchnsm.dlvChos = [];
	        				var _indvdlCatgryEmalDlvChcs = _self.getObjectCopy(dlvChos);
	        					_indvdlCatgryEmalDlvChcs.dlvDestId = _prfrdEmailType;
	        					_indvdlCatgryEmalDlvChcs.dlvDestCtx = "EMS.EML";
	        					_indvdlCatgryEmalDlvChcs.alwDestChgInd = false;
	        					_indvdlCatgryEmalDlvChcs.dlvChoSlctInd = _indvdlCatgryIndividlvals[k]['valueIds'][0] == "Required"? true : _indvdlCatgryIndividlvals[k]['valueIds'][0];
	        					_indvdlCatgryEmalMchnsm.dlvChos.push(_indvdlCatgryEmalDlvChcs);
	        					_indvdldlvMchnsms.push(_indvdlCatgryEmalMchnsm);
	        				//SMS choices	
	        				if(_prfrdPhone.get('changedItemValue').length > 0){
	        					var _indvdlCatgrySMSMchnsm = _self.getObjectCopy(dlvMchnsms);
	        					_indvdlCatgrySMSMchnsm.dlvTypCd = "SMS";
	        					_indvdlCatgrySMSMchnsm.dlvReqInd = true;
	        					_indvdlCatgrySMSMchnsm.dlvAlwMultSlctInd = false;
	        					_indvdlCatgrySMSMchnsm.dlvChos = [];
	        						var _indvdlCatgrySMSDlvChcs = _self.getObjectCopy(dlvChos);
	        						_indvdlCatgrySMSDlvChcs.dlvDestId = _prfrdPhone.get('customValues').dlvDestId;
	        						_indvdlCatgrySMSDlvChcs.dlvDestCtx = "COLA.TELE";
	        						_indvdlCatgrySMSDlvChcs.alwDestChgInd = false;
	        						_indvdlCatgrySMSDlvChcs.dlvChoSlctInd =  _indvdlCatgryIndividlvals[k]['valueIds'][1];
	        						_indvdlCatgrySMSMchnsm.dlvChos.push(_indvdlCatgrySMSDlvChcs);
	        						_indvdldlvMchnsms.push(_indvdlCatgrySMSMchnsm);
	        				}
	        				_indvdlPref.dlvMchnsms  = _indvdldlvMchnsms;
	        				_indvdlCatgryRelPrfrs.relPrfrs.push(_indvdlPref)
	        		}
	        		return _indvdlCatgryRelPrfrs;
		        }
		        function getAccountManagementData(alertJson){
		        	var _alertCategories = alertJson.clPrfrs.results,_catgryAlert = {},_accountManagement = {};
		        	for(var m=0; m<_alertCategories.length;m++){
		        		if(_alertCategories[m].prfrId == 7 || _alertCategories[m].prfrNm == "Alerts"){
		        			_catgryAlert = _alertCategories[m];
		        		}
		        	}
		        	var _alertSections = _catgryAlert.relPrfrs.results,_sectionAccountMangement={};
		        	for(var l=0; l<_alertSections.length; l++) {
		        		if (_alertSections[l].prfrId == 702 || _alertSections[l].prfrNm == "Account Management") {
		        			_sectionAccountMangement = _alertSections[l];
		        		}
		        	}
		        	_sectionAccountMangement.dlvMchnsms = null;
		        	_sectionAccountMangement.editRules = null;
		        	_sectionAccountMangement.prfrChoGrps = null;
		        	_sectionAccountMangement.relPrfrs = _sectionAccountMangement.relPrfrs.results;
		        	//_sectionAccountMangement.relPrfrs = _sectionAccountMangement.relPrfrs.results;
		        	for(var n=0; n<_sectionAccountMangement.relPrfrs.length;n++){
		        		var _delvMchnsm = _sectionAccountMangement.relPrfrs[n].dlvMchnsms =_sectionAccountMangement.relPrfrs[n].dlvMchnsms.results; 
		        		//loop through delivery mechanism
		        		for (var p=0; p<_delvMchnsm.length;p++){
		        			 _delvMchnsm[p].dlvChos = _delvMchnsm[p].dlvChos.results;
		        		}
		        		_sectionAccountMangement.relPrfrs[n].editRules = _sectionAccountMangement.relPrfrs[n].editRules.results;
		        		_sectionAccountMangement.relPrfrs[n].prfrChoGrps = null;
		        		_sectionAccountMangement.relPrfrs[n].relPrfrs = null;
		        	}
		        	return _sectionAccountMangement;
		        }
		        this.callAlertUpdateServie(_alertPayload);
		        },
		        prepareClientsDivorceAndCallUpdate: function () {
		            var _self = this;
		            var _items = _self.model.get('items'),
                        _changedItems = _self.model.getChangedItems(),
		                _divorceParty = _items.find(function (row) { return row.get("itemType") == "divorcingParty" }), //0 - Divorcing party, 1 - Other party
		                _divorceReqLetter = _items.find(function (row) { return row.get("itemType") == "divorceReqLetter" });
		                //_divorcePartyClientID = _items.find(function (row) { return row.get("itemType") == "divorcingPartyClientID" });

		            var _divorcePayload = {
		                "baseCase": {
		                    "commonInfo": {
		                        "eWorkflowReqId": "",
		                        "chnl": "AM",
		                        "caseOriginId": _self.model.get('submitterId'), //000033712
		                        "caseOriginRole": "Advisor",
		                        "function": "Life Events",
		                        "topic": "Divorce",
		                        "subTopic": "Notification of Divorce",
		                        "probCrrInd": [],
		                        "probCrrCaseId": [],
		                        "linkToCaseId": []
		                    },
		                    "busSpecificInfo": {
		                        "caseIdTyp": "Client",
		                        "alwDupInd": "Y",
		                        "clId": _self.model.get('clientId'), //pinned client id
		                        "clCtx": "COLA.CL",
		                        "advsId": _self.model.get('submitterId'), //000033712
		                        "advsCtx": "DMU.DIST",
		                        "taxpayerId": "",
		                        "linkToCaseId": "",
		                        "caseNotes": ["Divorcing party: " + _divorceParty.get('changedItemValue')[0] + "\n Other Party: " + _divorceParty.get('changedItemValue')[1] + "\n Who should receive the initial requirements letter(s): " + _divorceReqLetter.get('changedItemValue')]
		                    }
		                }
		            }
		            Spinner.show();
		            Analytics.analytics.recordAction('ClientDivorceReport:clicked');
		            DataService.giveDivorce(_divorcePayload)
                        .then(function (response, statusMessage, xhr) {
                            if (response && response.d && response.d.statDesc == "SUCCESS") {
                                    _self.navigateToStep3();
                                } else {
                                    Spinner.hide();
                                    Utils.showServiceError(xhr);
                                }
                            })
	            	    .fail(function (xhr) {
	            	        Spinner.hide();
	            	        Utils.showServiceError(xhr);
	            	    });
		        },
		        prepareCommnctnPrefPayloadAndCallUpdate:function(){
		        	var _communicationPrefJsonResp = PreferenceViewModel.getData().communication;
	        		_communicationPrefJsonRespCopy = this.getObjectCopy(_communicationPrefJsonResp);
	        		_communicationPrefJsonRespCopyClPrfrs = _communicationPrefJsonRespCopy.clPrfrs.results ;
	        		var _advsrEmailPrefResp = _communicationPrefJsonRespCopyClPrfrs.find(function(row){return row.prfrId == "200";}),
	        			_amerEmailPrefResp = _communicationPrefJsonRespCopyClPrfrs.find(function(row){return row.prfrId == "206";}),
	        			_commnctnItrstPrefResp = _communicationPrefJsonRespCopyClPrfrs.find(function(row){return row.prfrId == "4";});
	        			_advsrEmailPrefResp.editRules = null;_advsrEmailPrefResp.prfrChoGrps =null;
	        			var _communicationIntrstSectns = [];
	        		    $.each(_communicationPrefJsonRespCopyClPrfrs,function(h,respSectn){
	        		    	if(respSectn.prfrId == "4" || respSectn.prfrId == "200" ||respSectn.prfrId == "206" ){
	        		    		_communicationIntrstSectns.push(respSectn);
	        		    	}
	        		    });
	        			var _modelSections = this.model.get('itemSections');
	        			$.each(_communicationIntrstSectns,function(i,responseSectn){
	        				responseSectn.editRules = null;
	        				responseSectn.prfrChoGrps = null;
	        				responseSectn.prfrChoPtrnCd = null;
	        				responseSectn.dlvMchnsms = responseSectn.dlvMchnsms.results;
	        				responseSectn.relPrfrs = responseSectn.relPrfrs.results;
	        				//responseSectn.dlvMchnsms= responseSectn.dlvMchnsms.results;
	        				var _sectinId = responseSectn.prfrId;
	        				var _section = _modelSections.find(function(section){return section.sectionId == _sectinId;});
	        				var _sectionItems = _section.items;
	        				if(_sectinId == "200" || _sectinId == "206"){
	        					var _delvryEmailType = _sectionItems.find(function(modelItem){return modelItem.get('itemType') == "emailType";}).get("changedItemValue") + " Email";
	        					responseSectn.dlvMchnsms[0].dlvChos = responseSectn.dlvMchnsms[0].dlvChos.results;
		        				$.each(responseSectn.dlvMchnsms[0].dlvChos,function(dlvChsIndx,sectionDlvChs){
		        					if(sectionDlvChs.dlvDestId == _delvryEmailType){
		        						sectionDlvChs.dlvChoSlctInd = true;
		        					}else{
		        						sectionDlvChs.dlvChoSlctInd = false;
		        					}
		        					
		        				});
	        					$.each(responseSectn.relPrfrs,function(indx,item){
			        				item.dlvMchnsms = null;
			        				item.editRules= null;
			        				item.prfrChoGrps= null;
			        				item.relPrfrs = item.relPrfrs.results;
			        				$.each(item.relPrfrs,function(j,datum){
			        				        datum.dlvMchnsms= datum.dlvMchnsms.results;
			        				        datum.editRules= datum.editRules.results;
			        				        datum.prfrChoGrps = null;
			        				        datum.relPrfrs = null;
			        				        $.each(datum.dlvMchnsms,function(k,dlvrMchnsm){
			        				           dlvrMchnsm.dlvChos = dlvrMchnsm.dlvChos.results;
			        				           if(item.prfrNm == "Advisor Informational"){
			        				        	   dlvrMchnsm.dlvChos[0].dlvDestId = _delvryEmailType;
			        				        	   dlvrMchnsm.dlvChos[0].dlvChoSlctInd = _sectionItems.find(function(modelItem){return modelItem.get('itemType') == datum.prfrId}).get("changedItemValueId");
			        				           }
			        				         
			        				       });

			        				         
			        				     });
			        				});
	        				}else{
	        					responseSectn.dlvMchnsms = null;
	        					if(_sectionItems.length>0){
	        						responseSectn.relPrfrs[0].relPrfrs = responseSectn.relPrfrs[0].relPrfrs.results;
	        						responseSectn.relPrfrs[0].dlvMchnsms = null;
	        						responseSectn.relPrfrs[0].editRules = null;
	        						responseSectn.relPrfrs[0].prfrChoGrps    = null;
	        						responseSectn.relPrfrs[0].relPrfrs[0].editRules = responseSectn.relPrfrs[0].relPrfrs[0].editRules.results;
	        						responseSectn.relPrfrs[0].relPrfrs[0].dlvMchnsms = null;
	        						responseSectn.relPrfrs[0].relPrfrs[0].relPrfrs = null;
	        						var _prefChsGrps = responseSectn.relPrfrs[0].relPrfrs[0].prfrChoGrps = responseSectn.relPrfrs[0].relPrfrs[0].prfrChoGrps.results;
	        						var _retirementType = _sectionItems.find(function(row){return row.get("itemType") == "Retirement stage"});
	        						$.each(_prefChsGrps,function(i,prefChsGrp){
	        							prefChsGrp.prfrChos = prefChsGrp.prfrChos.results;
	        							prefChsGrp.prfrChos[0].subPrfrs = prefChsGrp.prfrChos[0].subPrfrs.results;
	        							if(_retirementType.get('changedItemValueId') == prefChsGrp.prfrChos[0].prfrChoVal){
	        								prefChsGrp.prfrChos[0].prfrChoValSlctInd = true;
	        							}else{
	        								prefChsGrp.prfrChos[0].prfrChoValSlctInd = false;
	        							}
	        							$.each(prefChsGrp.prfrChos[0].subPrfrs,function(j,subPref){
	        								subPref.dlvMchnsms =  null;
	        								subPref.editRules = null;
	        								subPref.prfrChoGrps =  null;
	        								subPref.relPrfrs =  subPref.relPrfrs.results;
	        								$.each(subPref.relPrfrs,function(k,subPrefRelPref){
	        									subPrefRelPref.dlvMchnsms = null;
	        									subPrefRelPref.relPrfrs = null;
	        									subPrefRelPref.editRules = subPrefRelPref.editRules.results;
	        									subPrefRelPref.prfrChoGrps = subPrefRelPref.prfrChoGrps.results;
	        									$.each(subPrefRelPref.prfrChoGrps,function(l,subPrefPrefChosGrp){
	        										subPrefPrefChosGrp.prfrChos = subPrefPrefChosGrp.prfrChos.results;
	        										subPrefPrefChosGrp.prfrChos[0].subPrfrs = null;
	        										if(_retirementType.get('changedItemValueId') == subPref.prfrId){
	        											var _selectedVal = _sectionItems.find(function(modelItem){return modelItem.get('itemType') == subPrefRelPref.prfrId;});
		        										if(subPrefPrefChosGrp.prfrChos[0].prfrChoVal == _selectedVal.get("changedItemValueId")){
		        											subPrefPrefChosGrp.prfrChos[0].prfrChoValSlctInd = true;
		        										}else{
		        											subPrefPrefChosGrp.prfrChos[0].prfrChoValSlctInd = false;
		        										}
	        										}
	        										
	        										
	        									})
	        								});
		        						});
	        						});
	        					}
	        					
	        					
	        				}
	        				
	        			});
	        			this.callAlertUpdateServie({"dlvAddrs":null,"prfrs":_communicationIntrstSectns});
	        			
	        			
		        },
		        getObjectCopy:function(data){
		        	return JSON.parse(JSON.stringify(data));
		        },
		        getDriversLicensePayload:function(){
		        	return;
		        	var items = this.model.get('items');
		        	var _payload = {"clientPersonal":[]};
		        	var _clPersonal = [];
		        	var _datum={};
		        	for(var i=0;i<_items.length;i++){
		        		var _propNm = "";
						if(_items.itemType =="drvLicNbr"){
							_propNm = "drvLicNbr";
						}else if(_items.itemType =="drvLicStCd"){
							_propNm = "drvLicStCd";
						}
						if(_propNm !=""){
							_datum = {"propNm": "drvLicNbr","propVal":_items[i].changedItemValue,"actnCd":"update"};
							_clPersonal.push(_datum);
						}
					}
		        	_payload.clientPersonal = _clPersonal;
		        	this.callPersonalInfoUpdateServie(_payload);
		        },
		        getEmploymentUpdatepayload:function(){
		        	//for tmprry purpose keeping separate method to generate the payload, based on  requirement it may merge into single method at later point
		        	var _payload = {"action":"update"};
		        	for(var i=0;i<_items.length;i++){
		        		/*_propNm = "";
		        		switch (_items[i].itemType) {
		        		case "finInstnEmplCd":
						case "ownrOfcrCd":
						case "emplStatCd":
						case "occpDescTxt":
						case "clJobTitle":
						case "emprNm":
						case "emprAddrLn1":
						case "emprAddrLn2":
						case "emprCityNm":
						case "emprStCd":
						case "emprPostlCd":
						default:
							break;
						
					}*/
		        		_payload[_items[i].itemType] = _items[i].changedItemValueId;
		        	}
		        return _payload;
		        },
		        reportClientsDeath: function () {
		            var _self = this;
		            var _items = _self.model.get('items');
		            var nzro = this.model.get('clientId');
		            //var nzo = nzro.substring(15, 23);
		            var _cntcDetails = [];
		            var dateOfDeath = null;
		            var additionalInfoStr = "";
		            var _changedItems = this.model.getChangedItems();

		            $.each(_changedItems, function (i, item) {
		                var tempObj = item.get('changedItemValue');
		                if (!(tempObj instanceof Object)) {
		                    var temp = new Date(tempObj);
		                    if (temp instanceof Date)
		                        dateOfDeath = tempObj;
		                }
		                if (tempObj !== 'Unknown' && (tempObj instanceof Object)) {
		                    $.each(tempObj, function (key, value) {

		                        //var additionalInfoTxt = value.additionalInfo.replace(/<div.*?>|<p.*?>|<br>|<br\/>/ig, ", ").replace(/<\/div>|<\/p>/ig, '');
		                        var phnum = "";
		                        var orgNm = "";
		                        var firstNm = "";
		                        var lastNm = "";
		                        if (value.phoneNumber == "Unknown" || value.phoneNumber == "") {
                                var phnum = "";
                            } else if (value.phoneNumber !== "Unknown") {
                                var phnum =  value.phoneNumber;
                            }
		                        if (value.contactType == "Individual" && value.contactFirstName != "undefined" &&  value.contactLastName !="undefined") {
		                            firstNm = value.contactFirstName == undefined ? " " : value.contactFirstName;
		                            lastNm = value.contactLastName   == undefined ? " " : value.contactLastName;
		                        } else if (value.contactType == "Organization") {
		                            orgNm = value.contactName;
		                        }
		                        var _contact= {
		                            "cntcTyp": value.contactType,
		                            "firstNm": firstNm,
		                            "lastNm": lastNm,
		                            "orgNm": orgNm,
		                            "addrLn1": value.addrLine1 == "undefined" ? " " : value.addrLine1,
		                            "addrLn2": value.addrLine2 == "undefined" ? " " : value.addrLine2,
		                            "addrLn3": value.addrLine3 == "undefined" ? " " : value.addrLine3,
		                            "city": value.contactCity == "undefined" ? " " : value.contactCity,
		                            "state": value.contactState == "undefined" ? " " : value.contactState,
		                            "zip": value.contactZip == "undefined" ? " " : value.contactZip,
		                            "phn": phnum,
		                            "relToDecsd": value.relationType,
		                            "attnLn": ""
		                        }
		                       
		                     
		                       
		                        if (value.clientId !== undefined && value.clientId !== "") {
		                            var nll = value.clientId.substring(15, 23);
		                        } else if (value.clientId == undefined || value.clientId == "") {
		                            var nll = "";
		                        }
		                         
		                        _cntcDetails.push(_contact);
		                       
		                       
		                    value.clientId=(typeof value.clientId !== "undefined") ? value.clientId : " ";
		                    if (key !== 0) {
		                        additionalInfoStr += "";
		                    }
		                    additionalInfoStr += "contact" + (key + 1) + ":" + " " + value.contactName + ","+ " client id = " + nll + ", ";
		                });
		                }
		            });
		            var _payload = {
		                "estateSettlementCase": {
		                    "commonInfo": {
		                        "eWorkflowReqId": "",
		                        "chnl": "AM",
		                        "caseOriginId": _self.model.get('advisorId'),
		                        "caseOriginRole": "Advisor",
		                        "caseTyp": "EstateSettlement",
		                        "interactionTyp": "AdvisorMobile",
		                        "interactionSubTyp": "DeceaseClientNotification"
		                    },
		                    "busSpecificInfo": {
		                        "decsdClId": nzro,
		                        "decsdClCtx": "COLA.CL",
		                        "decsdClNm": "",
		                        "dthDt": (dateOfDeath === "Unknown") ? "" : dateOfDeath,
		                        "callerInfo": "",
		                        "caseNotes": additionalInfoStr,
		                        "cntcDetails": _cntcDetails
		                    }
		                }
		            };
            
		            Spinner.show();
		            Analytics.analytics.recordAction('ReportClientDeath:clicked');
		                //var _self = this;
		                //var _gpmModel = _self.model;
		            DataService.updateDeathInfo(_payload).done(function (response, statusMessage, xhr) {
		                    if (response && response.d) {
		                    if (response.d.statDesc == "SUCCESS" && typeof response.d.caseInfo !== "undefined" && typeof response.d.caseInfo.caseId !== "undefined" && response.d.caseInfo.caseId !== "") {
		                        
		                        Spinner.hide();
		                        _self.navigateToStep3();
		                    } else if (response.d.explanations.results != ""  && response.d.explanations.results[0].faultString == "ClientIDExist") {
		                        Spinner.hide();
                                BootstrapDialog.show({
                                        title: 'Duplicate Notification',
                                        message: "A notification of death has already been submitted for this client.<br>Review in <a href='https://statusmanager.advisorcompass.com/sm/home.jsp'target='_blank'>Status Manager.</a>",
                                        closeByBackdrop: true,
                                        cssClass: 'ncst-dialog',
                                        buttons: [{
                                            label: 'OK',
                                            cssClass: 'btn btn-primary pt-btn-yes',
                                            action: function (dialog) { dialog.close(); }
                                        }]
                                });
		                    } else {
		                        Spinner.hide();
		                        Utils.showServiceError(xhr);
		                    }
		                        
		                 }else {
		                     Spinner.hide();
		                     Utils.showServiceError(xhr);
		                 }
		              }).fail(function(xhr){
		                   Spinner.hide();
		                   Utils.showServiceError(xhr);
		              });
		            },

		        
		        getSuitabilityUpdatepayload: function () {
		        	var self = this,serviceCounter = 0,errorCounter=0,totalServiceCount=0,failedResponses=[];
		        	var _items = this.model.get('items');
		        	//Suitability Finance section
		        	var _collectionFinace = _.filter(_items,function(row){ return (row.get('customValues')['infotype'] == 'finance' /*&& row.get('changedItemValueId') != row.get('currentItemValueId')*/)});
		        	var _payloadFinace = {"actnCd":"update"};
		        	if(_collectionFinace && _collectionFinace.length>0){
		        		for(var i=0;i<_collectionFinace.length;i++){		        			
		        		    if (_collectionFinace[i].get('itemType') == "sourceOfIncome") {
		        		        var cnt = 0;		        		      
		        		        _.each(_collectionFinace[i].get('changedItemValue'), function (cItem) {
		        		            if (cnt == 0) {
		        		                _payloadFinace["firstSrcOfIncmCd"] = cItem.mapCode;
		        		            }
		        		            else if (cnt == 1) {
		        		                _payloadFinace["scndSrcOfIncmCd"] = cItem.mapCode;
		        		            }
		        		            else if (cnt == 2) {
		        		                _payloadFinace["thirdSrcOfIncmCd"] = cItem.mapCode;
		        		            }
		        		            cnt++;
		        		        });
		        			}else{
		        				_payloadFinace[_collectionFinace[i].get('itemType')] = _collectionFinace[i].get('changedItemValueId');
		        			}		        				        			
			        	}
		        	}

		            //Suitability Investment section
		        	var _collectionInvestment = _.filter(_items, function (row) { return (row.get('customValues')['infotype'] == 'investment') /*&& row.get('changedItemValueId') != row.get('currentItemValueId')*/ })
		        	var _payloadInvestment = { "actnCd": "update" };

		            //Default value for Years of experience is "0" and for #Transactions is "null"
		        	var _investExpCollectionAll = [];
		        	_.each(Constants.sortedInvestmentExpList, function (invExpList, index) {
		        	    _investExpCollectionAll.push([{
		        	        "mapCode": invExpList.mapCode,
		        	        "years": {
		        	            "mapCode": "A"
		        	        },
		        	        "transaction": {
		        	            "mapCode": " "
		        	        }
		        	    }]);		        	   
		        	});
		        	_investExpCollectionAll = _.flatten(_investExpCollectionAll);

		        	var _doesClientHaveInvst;
		        	var _prodExpFormated = [];
		        	for (var i = 0; i < _collectionInvestment.length; i++) {
		        	    if (_collectionInvestment[i].get('itemType') == "doesClientHaveInvestment") {
		        	        _doesClientHaveInvst = _collectionInvestment[i].get('changedItemValueId');
		        	    }
		        	}

                    //Update if user selects "yes" to the question "Does client have investmetns"?
		        	if (_doesClientHaveInvst == "Yes") {
		        	    //Update selected values in the above investment collection		        	    
		        	    if (_collectionInvestment && _collectionInvestment.length > 0) {
		        	        for (var i = 0; i < _collectionInvestment.length; i++) {
		        	            if (_collectionInvestment[i].get('itemType') == "clientProductExpes") {
		        	                var _prodExp = _collectionInvestment[i].get('changedItemValueId');

		        	                var _yearTypCd, _allTranCd;
		        	                if (_prodExp && _prodExp.length > 0) {
		        	                    _prodExp.forEach(function (row) {
		        	                        if (row.mapCode !== "") {
		        	                            var invExpItem = _.find(_investExpCollectionAll, function (invExpListItem) {
		        	                                return (invExpListItem.mapCode == row.mapCode);
		        	                            });
		        	                            if (row.years && row.years.mapCode !== "") {
		        	                                invExpItem.years.mapCode = row.years.mapCode;
		        	                            }
		        	                            if (row.transaction && row.transaction.mapCode !== "") {
		        	                                invExpItem.transaction.mapCode = row.transaction.mapCode;
		        	                            }
		        	                        }
		        	                    });
		        	                }
		        	            } 
		        	        }
		        	    }
		        	}

		        	for (var i = 0; i < _investExpCollectionAll.length; i++) {
		        	    _prodExpFormated.push(
                            {
                                "prodExpeTypCd": _investExpCollectionAll[i].mapCode,
                                "invExpeYrCd": _investExpCollectionAll[i].years.mapCode,
                                "annlTransCd": _investExpCollectionAll[i].transaction.mapCode
                            });		        	    
		        	}
		        	_payloadInvestment['prodExperiences'] = _prodExpFormated;

		        	//Suitability heldAwayAssets section
		        	var _collectionHeldAwayAssets = _.filter(_items, function (row) { return (row.get('customValues')['infotype'] == 'heldAwayAssets') })		            
		        	var _payloadHeldAwayAssets = {};
		        	
		        	var heldAwayAssetCd;
		        	if (_collectionHeldAwayAssets && _collectionHeldAwayAssets.length > 0) {

		        	    for (var i = 0; i < _collectionHeldAwayAssets.length; i++) {
		        	        if (_collectionHeldAwayAssets[i].get('itemType') == "doesClientHaveAssets") {
		        	            heldAwayAssetCd = _collectionHeldAwayAssets[i].get('changedItemValueId');		        	            
		        	        }
		        	    }

		        	    for (var i = 0; i < _collectionHeldAwayAssets.length; i++) {
		        	        if (_collectionHeldAwayAssets[i].get('itemType') == "heldAwayAssets") {
		        	            var _heldAwayAssets = _collectionHeldAwayAssets[i].get('changedItemValueId');
		        	            var _heldAwayAssetsFormated = [];	
		        	            var _heldAwayDetails = {};
		        	            var assetTypeConstItems = Constants.sortedAssetTypeHeldList;

		        	            if (heldAwayAssetCd == "C") {
                                    //When code is 'C', send Zero value.
		        	                var _heldAwayAmountPadded = CommonUtil.padZeros(15, "0");
		        	                
		        	                _.each(assetTypeConstItems, function (assetTypeList, index) {
		        	                    var assetTypeItem = _.find(assetTypeConstItems, function (assetTypeList1) {
		        	                        return (assetTypeList1.servName == assetTypeList.servName);
		        	                    });
		        	                    _heldAwayDetails[assetTypeItem.servName] = _heldAwayAmountPadded;
		        	                });		        	                       	                	             
		        	            } else {
		        	                //Default value is null.
		        	                _.each(assetTypeConstItems, function (assetTypeList, index) {
                                        var assetTypeItem = _.find(assetTypeConstItems, function (assetTypeList1) {
                                            return (assetTypeList1.servName == assetTypeList.servName);
                                        });
                                        _heldAwayDetails[assetTypeItem.servName] = null;
		        	                });     	                	              
		        	            }

		        	            if (_heldAwayAssets && _heldAwayAssets.length > 0) {
		        	                _heldAwayAssets.forEach(function (row) {
		        	                    if (heldAwayAssetCd == 'A' || heldAwayAssetCd == 'B') {
		        	                        if (row.assetVal.enteredValue != "") {
		        	                            var assetTypeItem = _.find(assetTypeConstItems, function (assetTypeList, index) {
		        	                                return assetTypeList.servName == row.servName;
		        	                            });
		        	                            _heldAwayDetails[assetTypeItem.servName] = CommonUtil.padZeros(15, row.assetVal.enteredValue.replace(/\,/g, ''));
		        	                        }
		        	                    }
		        	                });
		        	            }
		        	            var tempHeldAwayAssets = {};
		        	            tempHeldAwayAssets["heldAwayInfoCd"] = heldAwayAssetCd;
		        	            tempHeldAwayAssets["detail"] = _heldAwayDetails;		        	            
		        	            _payloadHeldAwayAssets = tempHeldAwayAssets;
		        	        } 
		        	    }
		        	}
		        	
		        	function updateSuitabilityFinanceStatus (status){
		        		if(_collectionFinace && _collectionFinace.length>0){
			        		for(var i=0;i<_collectionFinace.length;i++){
			        			var row = _collectionFinace[i];
			        			if(row.get('changedItemValueId') != row.get('currentItemValueId'))
			        			row.get('customValues')['updateStatus'] = status;
				        	}
			        	}
		        		if(serviceCounter == 0){
		        			if(errorCounter == totalServiceCount){
		        				//all services failed
		        				//show error
		        				Spinner.hide();
								Utils.showServiceError(failedResponses[0]);
		        			}else{
		        				if(errorCounter>0){
				        			self.model.set('submitStatus',"partial");
				        		}
		        				self.navigateToStep3();
		        			}
		        			
		        			
		        		}
		        	}
		        	function updateSuitabilityInvestmentStatus (status){
		        		if(_collectionInvestment && _collectionInvestment.length>0){
			        		for(var i=0;i<_collectionInvestment.length;i++){
			        			var row = _collectionInvestment[i];
			        			//Special condition for client products since it is array
			        			if(row.get('itemType') == "clientProductExpes"){
			        				var currentProducts = row.get('currentItemValueId').sort();
			        				var changedProducts = row.get('changedItemValueId').sort();
			        				if(!_.isEqual(currentProducts, changedProducts)){
			        					row.get('customValues')['updateStatus'] = status;
			        				}
			        			}else{
			        				if(row.get('changedItemValueId') != row.get('currentItemValueId'))
					        			row.get('customValues')['updateStatus'] = status;
			        			}       				
			        			
				        	}
			        	}
		        		
		        		if(serviceCounter == 0){
	        			if(errorCounter == totalServiceCount){
	        				//all services failed
	        				//show error
	        				Spinner.hide();
							Utils.showServiceError(failedResponses[0]);
	        			}else{
	        				if(errorCounter>0){
			        			self.model.set('submitStatus',"partial");
			        		}
	        				self.navigateToStep3();
	        			}
	        			}
		        	}

		        	function updateSuitabilityHeldAwayStatus(status) {
		        	    if (_collectionHeldAwayAssets && _collectionHeldAwayAssets.length > 0) {
		        	        for (var i = 0; i < _collectionHeldAwayAssets.length; i++) {
		        	            var row = _collectionHeldAwayAssets[i];
		        	            if (row.get('itemType') == "heldAwayAssets") {
		        	                var currentProducts = row.get('currentItemValueId').sort();
		        	                var changedProducts = row.get('changedItemValueId').sort();
		        	                if (!_.isEqual(currentProducts, changedProducts)) {
		        	                    row.get('customValues')['updateStatus'] = status;
		        	                }
		        	            } else {
		        	                if (row.get('changedItemValueId') != row.get('currentItemValueId'))
		        	                    row.get('customValues')['updateStatus'] = status;
		        	            }
		        	        }
		        	    }

		        	    if (serviceCounter == 0) {
		        	        if (errorCounter == totalServiceCount) {
		        	            //all services failed
		        	            //show error
		        	            Spinner.hide();
		        	            Utils.showServiceError(failedResponses[0]);
		        	        } else {
		        	            if (errorCounter > 0) {
		        	                self.model.set('submitStatus', "partial");
		        	            }
		        	            self.navigateToStep3();
		        	        }
		        	    }
		        	}
		        	
		        	var _changedItems = self.model.getChangedItems();
		        	if(_changedItems && _changedItems.length>0){
		        		
			        	
			        	Spinner.show();
			        	if(_.filter(_changedItems,function(row){ return (row.get('customValues')['infotype'] == 'finance')}).length>0){
			        		//Update Finance data
			        		serviceCounter++,totalServiceCount++;
			        		DataService.updateSuitabilityFinancial(this.model.get('clientId'),_payloadFinace)
				        	.done(function(response,statusMessage,xhr){
				        		serviceCounter--;
				        		if(!response){
				        			updateSuitabilityFinanceStatus("success");
				        		}else{
				        			failedResponses.push(xhr);
				        			errorCounter++;
				        			updateSuitabilityFinanceStatus("failed");
				        		}
				        	})
				        	.fail(function(error){
				        		failedResponses.push(error);
				        		serviceCounter--;
				        		errorCounter++;
				        		updateSuitabilityFinanceStatus("failed");
				        	});
				        	
			        	}
			        	
			        	if(_.filter(_changedItems,function(row){ return (row.get('customValues')['infotype'] == 'investment')}).length>0){
			        		//Update Investment data
				        	serviceCounter++,totalServiceCount++;
				        	DataService.updateSuitabilityInvestment(this.model.get('clientId'),_payloadInvestment)
				        	.done(function(response,statusMessage,xhr){
				        		serviceCounter--;
				        		if(!response){
				        			updateSuitabilityInvestmentStatus("success");
				        		}else{
				        			failedResponses.push(xhr);
				        			errorCounter++;
				        			updateSuitabilityInvestmentStatus("failed");
				        		}
				        	})
				        	.fail(function(error){
				        		failedResponses.push(error);
				        		errorCounter++;
				        		serviceCounter--;
				        		updateSuitabilityInvestmentStatus("failed");
				        	});
			        	}

			        	if (_.filter(_changedItems, function (row) { return (row.get('customValues')['infotype'] == 'heldAwayAssets') }).length > 0) {
			        	    //Update HeldAwayAsset data
			        	    serviceCounter++, totalServiceCount++;
			        	    DataService.updateSuitabilityHeldAwayAssets(this.model.get('clientId'), _payloadHeldAwayAssets)
				        	.done(function (response, statusMessage, xhr) {
				        	    serviceCounter--;				        	  
				        	    if (response && response.d && response.d.statCd == "0000") {
				        	        updateSuitabilityHeldAwayStatus("success");
				        	    } else {
				        	        failedResponses.push(xhr);
				        	        errorCounter++;
				        	        updateSuitabilityHeldAwayStatus("failed");
				        	    }
				        	})
				        	.fail(function (error) {
				        	    failedResponses.push(error);
				        	    errorCounter++;
				        	    serviceCounter--;
				        	    updateSuitabilityHeldAwayStatus("failed");
				        	});
			        	}
			        	
		        	}
		        	
		        	
		        	
		        },
		        getPersonalUpdatePayload:function(updateMode){
		        	var _updateMode = updateMode,_propNm="";
		        	//call different service based on updateMode
		        	switch (_updateMode) {
					case "gender":
						_propNm = "";
						break;
		    	    case 'dependents':
		    	    	_propNm = "dpdtCnt";
		    	        break;
		    	    case 'honorific':
		    	    	_propNm = "clHnrfNm";
		    	        break;
		    	    case 'maritalstatus':
		    	    	_propNm = "mrtlStatCd";
		    	        break;
		    	    case 'passport':
		    	    	_propNm = "psprtNbr";
		    	        break;
					default:
						break;
					}
		        	var _payload = {"clientPersonal":[]};
		        	var _clPersonal = [];
		        	var _datum={};
		        	_datum = {"propNm": _propNm,"propVal":_items[0].changedItemValueId,"actnCd":"update"};
					_clPersonal.push(_datum);
		        	_payload.clientPersonal = _clPersonal;
		        	return _payload;
		        },
		        callPersonalInfoUpdateServie:function(_payload){
		        	Spinner.show();
		        	var _self = this;
		        	var _gpmModel = _self.model;
		        	DataService.updateClientPersonalInfo(_gpmModel.get('clientId'),_payload).done(function(response){
						 Spinner.hide();
						_self.navigateToStep3();
					}).fail(function(error){
						Spinner.hide();
						alert("Failed to update.");
					});
		        },
		        callAlertUpdateServie:function(_payload){
		        	Spinner.show();
		        	var _self = this;
		        	var _gpmModel = _self.model;
		        	DataService.updateAlertPrefernces(_gpmModel.get('clientId'),_payload).done(function(response,statusMessage,xhr){
						 if(response && response.d && response.d.statCd == "0000"){
							 _self.navigateToStep3();
						 }else{
							 Spinner.hide();
							 Utils.showServiceError(xhr);
						 }
					}).fail(function(xhr){
						Spinner.hide();
						Utils.showServiceError(xhr);
					});
		        },
		        prepareEmploymentPayloadAndCallUpdate:function(){
		            var _items = self.model.get('items'),
                        _isEbixDatachanged = false,
                        _isColaDataChanged = false,
                        companyInfoChanged = false,
                        _totalServiceCounter = 0,
                        _successServices = 0,
                        _failedResponses = [],
                        _colaPayload = {},
                        riskProfilePayload = {
                            indsClsCd: null,
                            indsClsTxt: null,
                            nonOperEntyCd: null

                        },
		                companyInfoPaylod = { 
		                    details: []
		                },
                        clJobTitle = _.find(_items, function (item) {
                            return item.get('itemType') == "clJobTitle";
                        }),
		                employmentstatus = _items.find(function (row) { return row.get("itemType") == "emplStatCd" }),
                        indstryClassftcn,
		                industryFreeFormText,
		                employerAddrsColl = _items.find(function (row) { return row.get("itemType") == "employerAddressCollection" }),
                        finraAddrsColl = _items.find(function (row) { return row.get("itemType") == "finraAddressCollection" }),
                        shareholderAddrsColl = _items.find(function (row) { return row.get("itemType") == "shareholderAddressCollection" });
		            if (employerAddrsColl.get("changedItemValue").length > 0 ||
                        employerAddrsColl.get("changedItemValue").length != employerAddrsColl.get("currentItemValue").length) {
		                companyInfoChanged = true;
		                _.each(employerAddrsColl.get("changedItemValue"), function (employerAddrs) {
		                    companyInfoPaylod.details.push(createCompanyPayload(employerAddrs, "A" /*relTypCd*/));
		                });
		                _.each(employerAddrsColl.get("currentItemValue"), function (curreAddrs) {
		                    var isAddressExists = _.find(employerAddrsColl.get("changedItemValue"), function (employerAddrs) {
		                        return curreAddrs.relSeqNbr == employerAddrs.relSeqNbr;
		                        });
		                    if(!isAddressExists) {
		                        companyInfoPaylod.details.push(createCompanyPayload(curreAddrs, "A", "R"));
		                    }
		                });
		            }
		            if (finraAddrsColl.get("changedItemValue").length > 0 ||
                        finraAddrsColl.get("changedItemValue").length != finraAddrsColl.get("currentItemValue").length) {
		                companyInfoChanged = true;
		                _.each(finraAddrsColl.get("changedItemValue"), function (finraAddrs) {
		                    companyInfoPaylod.details.push(createCompanyPayload(finraAddrs, "C" /*relTypCd*/));
		                });
		                _.each(finraAddrsColl.get("currentItemValue"), function (curreAddrs) {
		                    var isAddressExists = _.find(finraAddrsColl.get("changedItemValue"), function(finraAddrs) {
		                        return curreAddrs.relSeqNbr == finraAddrs.relSeqNbr;
		                    });
		                    if (!isAddressExists) {
		                        companyInfoPaylod.details.push(createCompanyPayload(curreAddrs, "C", "R"));
		                    }
		                });
		            }
		            if (shareholderAddrsColl.get("changedItemValue").length > 0 ||
                        shareholderAddrsColl.get("changedItemValue").length != shareholderAddrsColl.get("currentItemValue").length) {
		                companyInfoChanged = true;
		                _.each(shareholderAddrsColl.get("changedItemValue"), function (shareholderAddrs) {
		                    companyInfoPaylod.details.push(createCompanyPayload(shareholderAddrs, "B" /*relTypCd*/));
		                });
		                _.each(shareholderAddrsColl.get("currentItemValue"), function (curreAddrs) {
		                    var isAddressExists = _.find(shareholderAddrsColl.get("changedItemValue"), function (shareholderAddrs) {
		                        return curreAddrs.relSeqNbr == shareholderAddrs.relSeqNbr;
		                        });
		                    if(!isAddressExists) {
		                        companyInfoPaylod.details.push(createCompanyPayload(curreAddrs, "B", "R"));
		                    }
		                });
		            }
		            if (clJobTitle.get("changedItemValue")) {
		                _isEbixDatachanged = clJobTitle.get("changedItemValue") != clJobTitle.get("currentItemValue");
		            } else {
		                _isEbixDatachanged = !!clJobTitle.get("currentItemValue");
		        }
		            _isColaDataChanged = true,
		            isRiskProfileChanged = false;
		            if (employmentstatus.get("changedItemValueId") == "B") {
		                indstryClassftcn = _items.find(function (row) { return row.get("itemType") == "industryClassifyType" });
		                riskProfilePayload.indsClsCd = indstryClassftcn.get("changedItemValueId");
		                if (indstryClassftcn.get("changedItemValueId") != indstryClassftcn.get("currentItemValueId")) {
		                    isRiskProfileChanged = true;
		            } 
		                if (indstryClassftcn.get("changedItemValueId") == "IC031") {
		                    industryFreeFormText = _items.find(function (row) { return row.get("itemType") == "industryFreeFormText" });
		                    riskProfilePayload.indsClsTxt = industryFreeFormText.get("changedItemValueId");
		                    if (industryFreeFormText.get("changedItemValueId") != industryFreeFormText.get("currentItemValueId")) {
		                        isRiskProfileChanged = true;
		                }
		            }
		                
		        }
		            _isEbixDatachanged && _isColaDataChanged ? _totalServiceCounter = 2 : _totalServiceCounter = 1;
		            if (isRiskProfileChanged) {
		                _totalServiceCounter++;
		            }
		            if (companyInfoChanged) {
                        _totalServiceCounter++;
		            }
		        	 Spinner.show();
		        	if(_isEbixDatachanged == true){
		        	    //call ebix service
		        		var _gpmModel = this.model;
			        	var _items = _gpmModel.get('items');
			        	var _ebixData = CPViewModel.getInstance().getData().ebix || {};
			        	var _ebixPayload = {
			        			"id" : _gpmModel.get('contactId'),
								"ctx" : "Ebix",
								"type" : "Contact",
								"contactType" : "Client",
								"remarks" : _ebixData.remarks,
								"PersonContact" : {
									"clGreeting" : _ebixData.PersonContact.get("clGreeting"),
									"clFirstNm" : _ebixData.PersonContact.get("clFirstNm"),
									"clMidNm" : _ebixData.PersonContact.get("clMidNm"),
									"clLastNm" : _ebixData.PersonContact.get("clLastNm"),
									"clLastNm" : _ebixData.PersonContact.get("clLastNm"),
									"clOccupation" : _ebixData.PersonContact.get("clOccupation"),
									"clJobTitle": clJobTitle.get("changedItemValueId"),
			        	},
								"employerName" : _ebixData.employerName,
								"TobeDeletedPhone" : "",
								"EditedPhone" : "",
								"TobeDeletedWebAddress" : "",
								"EditedWebAddress" : "",
								"TobeDeletedAddress" : "",
								"EditedAddress" : "",
								"BusinessContact" : {},
								"contactSubType" :_ebixData.contactSubType,
			        			
		        	}
			        	DataService.editContact(_gpmModel.get('submitterId'), _ebixPayload)
		            	.then(function (response,statusMessage,xhr) {
		            	    //Spinner.hide();
		            	    if(typeof(response) =="string" && response.indexOf("Success") > -1){
		            	    	_successServices++;
		        				updateEmploymentFieldStatus("success");
		            	    }else{
		            	    	_failedResponses.push(xhr);
		        				updateEmploymentFieldStatus("failed");
		            	}
		            	    
			        	})
		            	.fail(function (Error) {
		            		_failedResponses.push(Error);
		            		updateEmploymentFieldStatus("failed");
		        	});
			        	
		        }
		        	if(_isColaDataChanged == true){
		        		var _empStat = _items.find(function (row) { return row.get("itemType") == "emplStatCd" });
		        		_colaPayload = {
		        		    "actnCd": "update",
		        		    "emplStatCd": _items.find(function (row) { return row.get("itemType") == "emplStatCd" }).get('changedItemValueId'),
		        		    "finInstnEmplCd": _items.find(function (row) { return row.get("itemType") == "finInstnEmplCd" }).get('changedItemValueId'),
		        		    "ownrOfcrCd": _items.find(function (row) { return row.get("itemType") == "ownrOfcrCd" }).get('changedItemValueId'),
		        		    "occpDescTxt": _items.find(function (row) { return row.get("itemType") == "occpDescTxt" }).get('changedItemValueId')
		        	};
		        		
		        	    //call cola service
		        		DataService.updateClientEmploymentInfo(self.model.get('clientId'),_colaPayload).then(function (response,statusMessage,xhr) {
		        			if(!response){
		        			    //if success response is empty
		        				_successServices++;
		        				updateEmploymentFieldStatus("success",true);
		        			}else{
		        				_failedResponses.push(xhr);
			            		updateEmploymentFieldStatus("failed",true);
		        		}
		            	    
		        		})
		            	.fail(function (Error) {
		            		_failedResponses.push(Error);
		            		updateEmploymentFieldStatus("failed",true);
		        	});
		            }
		        	if (isRiskProfileChanged) {
		        	    //call cola service
		        	    DataService.maintainClientRiskProfile(self.model.get('clientId'), riskProfilePayload).then(function (response, statusMessage, xhr) {
		        	        _successServices++;
		        			updateEmploymentFieldStatus("success", true);
		            	    
		        	    })
		            	.fail(function (Error) {
		            		_failedResponses.push(Error);
		            		updateEmploymentFieldStatus("failed",true);
		        	    });
		            }
                    if(companyInfoChanged) {
		            //call cola service
                        DataService.maintainClientCompanyInformation(self.model.get('clientId'),companyInfoPaylod).then(function (response, statusMessage, xhr) {
                            _successServices++;
                            updateEmploymentFieldStatus("success", true);

		                })
                        .fail(function (Error) {
                            _failedResponses.push(Error);
                            updateEmploymentFieldStatus("failed", true);
		        	    });
                    }
		            function updateEmploymentFieldStatus(status,isCola){
		        		_totalServiceCounter--;
		        		if(_totalServiceCounter == 0){
		        			if(_successServices == 0){
		        			    //all services failed show error
		        				Spinner.hide();
								Utils.showServiceError(_failedResponses[0]);
		        			}else{
		        				if(_failedResponses.length != 0){
		        					self.model.set('submitStatus',"partial");
		        				}else{
		        					self.model.set('submitStatus',"");
		        			}
		        				self.navigateToStep3();
		        		}
		            }
		            }
		            function createCompanyPayload(companyInfo, relTypCd, actnCd) {
                        var companyDetails = {
                            "actnCd": actnCd ? actnCd : (companyInfo.relSeqNbr ? "U" : "A"),
                            "relTypCd": companyInfo.relTypCd ? companyInfo.relTypCd: relTypCd,
                            "relSeqNbr": companyInfo.relSeqNbr?companyInfo.relSeqNbr: "",
		                    "symbol": companyInfo.tickerSymbol,
		                    "coNm": companyInfo.employerName,
		                    "addrLn1Txt": companyInfo.address1,
		                    "addrLn2Txt": companyInfo.address2,
		                    "cityNm": companyInfo.city,
		                    "stCd": companyInfo.addressType == "U.S" ? companyInfo.state: (companyInfo.countryNm == "CA" ? companyInfo.province: ""),
		                    "postlCd": (companyInfo.addressType == "U.S" || companyInfo.countryNm == "CA") ? companyInfo.zipCode : "",
		                    "cntryNm": companyInfo.countryNm ? companyInfo.countryNm: "US"
		                };
                        return companyDetails;
		            }
		        },
		        navigateToStep3:function(){
		        	var _gpmModel = this.model;
		        	_gpmModel.set('submittedTime',moment(new Date()).format('MM/DD/YYYY hh:mm a'));
		        	var _completedSteps = _gpmModel.get('completedSteps');
		        	_gpmModel.set('updateCompleted',true);
		        	$('.gpm-step.step1,.gpm-step.step2').addClass("finished").removeClass("active");
		        	$('.gpm-step.step3').addClass("active");
		        	if(_completedSteps.indexOf(2) == -1){
		        		_gpmModel.get('completedSteps').push(2);
					}
		        	Backbone.history.navigate('gpm/confirm/'+_gpmModel.get('updateMode'), true);
		        }
		        
		    });
		    return _containerView;
		});