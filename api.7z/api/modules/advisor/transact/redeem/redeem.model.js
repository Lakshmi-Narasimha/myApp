// redeemDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RedeemModelSchema = new mongoose.Schema({
    RedeemResp: {
        type: Array,
        "default": []
    }
});

var RedeemModelLookUp = mongoose.model('RedeemModelLookUp', RedeemModelSchema);

var RedeemModel = new RedeemModelLookUp({
    RedeemResp : {
        'redeem' : {
            'bankDetails': [
                {
                    'bankName' :'ICICI',
                    'accountNo' : '1151234567890'
                },
                {
                    'bankName' :'HDFC',
                    'accountNo' : '256234567890'
                },
                {
                    'bankName' :'Dena Bank',
                    'accountNo' : '001234567890'
                },
                {
                    'bankName' :'Axis Bank',
                    'accountNo' : '789234567890'
                }
            ]
        }
    }
});

RedeemModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating RedeemModelLookUp table, please contact admin...');
    } else {
        RedeemModelLookUp.remove({}, function(err) {
            console.log('RedeemModelLookUp collection removed');
            RedeemModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RedeemModelLookUp table, please contact admin...');
                }
                console.log('RedeemModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RedeemModelLookUp;