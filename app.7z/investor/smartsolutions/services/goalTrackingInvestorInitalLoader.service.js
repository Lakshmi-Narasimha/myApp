'use strict';

var goalTrackingInitialLoaderService = function (investorGoalModelService, advisorEvents, advisorEventConstants) {
    var goalTrackingInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope) {

            investorGoalModelService.fetchGoalTrackingDtls()
                .then(goalInvestorSuccess, handleFailure);

            function goalInvestorSuccess(data) {
                console.log(data);
                investorGoalModelService.setGoalInvestorData(data[0].goalInvestorObject);
                advisorEvents.smartSolutions.publishGoalInvestorData(scope,investorGoalModelService.getGoalInvestorData());

            }

            function handleFailure(data){
                console.error('handleFailure');
                goalTrackingInitialLoader._isServicesData = false;
            }
        }

    };
    return goalTrackingInitialLoader;
};

goalTrackingInitialLoaderService.$inject = ['investorGoalModelService', 'advisorEvents', 'advisorEventConstants'];

module.exports = goalTrackingInitialLoaderService;