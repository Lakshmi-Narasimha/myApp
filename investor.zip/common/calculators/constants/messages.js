
'use strict';

function messages ($translateProvider) {
    $translateProvider.translations('en_US',{
        "SIP_CALC" : "SIP Calculator",
        "LUMPSUM_CALC" : "Lumpsum Calculator",
        "TAX_ADV_CALC" : "Tax Advantage Calculator",
        "COMMISSION_TITLE" : "COMMISSION CALCULATOR",
        "COMPARISSION_CALC" : "SIP VS LUMPSUM CALCULATOR",
        "INVESTMENT_TYPE"    : 'Investment Type',
        "SIP_CAL" : "SIP", 
        "LUMP_CAL" : "Lumpsum",
        "COMPARISSION_DESC" : "Enter SIP or Lumpsum Details, to view the comparison",
        "TAX_ADVANTAGE_MSG" : "*Assuming Tax bracket as 30%",

        //Calculators Disclaimer 

        DISCLAIMER_TITLE : 'Disclaimer' ,

        DISCLAIMER_MESSAGE : 'Since Inception return of the benchmark is calculated from the scheme inception date. Past performance may or may not be sustained in the future and should not be used as a basis for comparison with other investments. While comparing the performance of investments made through SIPs with the respective benchmark of the scheme, the value of the Index on the days when investment is made is assumed to be the price of one unit. The "since inception" returns signify returns realized since the launch of the scheme. The returns calculated do not take into account Entry Load/ Exit Load. Hence actual "Returns" may be lower. Franklin Templeton India./Trustees do not endorse the authenticity or accuracy of the figures based on which the returns are calculated; nor shall they be held responsible or liable for any error or inaccuracy or for any losses suffered by any investor as a direct or indirect consequence of relying upon the data displayed by the calculator.' , 
    });

    /* Determine automatically the preferred language based on users window.navigator object */
    $translateProvider.determinePreferredLanguage();

    /*If a translation id is not present in the particular language translation table, angular-translate
    will search for it in the registered fallback language i.e english translation table */
    $translateProvider.fallbackLanguage('en_US');

    $translateProvider.useSanitizeValueStrategy();
}

messages.$inject = ['$translateProvider'];
module.exports = messages;