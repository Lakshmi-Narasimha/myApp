/**
 * @ngdoc property
 * @name review lumpsum Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the review lumpsum controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewLumpsumController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout, bankDtlsModel, transactModel, $filter,planSmartSolution, fundDetails) 
{			

	$scope.accordionClicked = function(){			
		
		var reqParams = transactModel.getBuyReqParams(),
			paymentMethod = "",
			totalAmount = 0;

		angular.forEach(reqParams.fundOptions,function(obj,ind){
			totalAmount = totalAmount + parseInt(obj.amount)
		})

		// -------Review Details
		if(!$scope.showDtls.showLumpsumTransactionDtls)
		{
			fundDetails.removeFundDetails();
			angular.forEach(transactModel.getLumpsumFundDtls(),function(obj,ind){
				fundDetails.setFundDetails(obj)
			})

			$scope.showFundDtls = true;
						
			transactModel.setTransactType(TransactConstant.buy.BUY);
			$scope.setPaymentIntegration(transactModel.getBuyReqParams());						

			switch(reqParams.paymentMode) {
	            case TransactConstant.common.EMANDATE_CODE:
	                  paymentMethod = TransactConstant.transact.SETUP_NEW_MANDATE;
	                  break;
	            case TransactConstant.common.NET_BANKING_CODE:
	                  paymentMethod = TransactConstant.transact.NET_BANKING;
	                  break;
	            case TransactConstant.common.NEFT_CODE:
	                  paymentMethod = TransactConstant.transact.NEFT_RTGS;
	                  break; 
	            case TransactConstant.common.DEBIT_CARD_CODE:
	                  paymentMethod = TransactConstant.transact.DEBIT_CARD;
	                  break;
	            case TransactConstant.common.AUTO_DEBIT_CODE:
	                  paymentMethod = TransactConstant.transact.AUTO_DEBIT;
	                  break;
	            case TransactConstant.common.BILL_PAY_CODE:
	                  paymentMethod = TransactConstant.transact.BILL_PAY;
	                  break;
	        }

			$scope.keyValuePairs = [
		        {
		            text: TransactConstant.transact.BANK_DETAILS,
		            value: reqParams.bankName
		        },
		        {
		            text: TransactConstant.transact.MODE_OF_PAYMENT,
		            value: paymentMethod
		        },	        
		        {
		            text: TransactConstant.transact.TOTAL_INVSTMNT_AMT,
		            value: totalAmount
		        }
		    ];	
		}
		
	    // -------Transaction details
	    if($scope.showDtls.showLumpsumTransactionDtls)
	    {
	    	$scope.SIPkeyValueList = [
				{key:"Folio. No.",value:transactModel.getInvestorDetails().folioId},  
				{key:"First Holder",value:transactModel.getInvestorDetails().custName}		     
			];		

			$scope.infoObj=[];
			var lumpsumDtls = fundDetails.getFundDetails();
			angular.forEach(lumpsumDtls, function(obj){
				$scope.infoObj.push([
				{
					text: "Fund Name",
					value: obj.fundName
				},
				{
					text: "Amount",
					value: obj.amount
				},
				{
					text: "Dividend",
					value: obj.dividend
				}
				]);
			});
						
	        $scope.showDtls.keyValueList = [
	            {key:'Transaction Reference Number',value:transactModel.getLumpsumWebRefNo()},
	            {key:'Request Date and Time',value:$scope.showDtls.requestDateAndTime},
	            {key:'Total Invested Amount',value:totalAmount}
	        ];

	    }
		

	}
	                    	    
    $scope.postTransactDataLumpsum = function(advisorDetailsForm) {					
		$scope.postReviewDetails("lumpsum");						
	};
			
}

reviewLumpsumController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','$timeout','bankDtlsModel', 'transactModel', '$filter','planSmartSolution', 'fundDetails'];
module.exports = reviewLumpsumController;