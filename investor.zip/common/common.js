/**
*@ngdoc object
*@name FTIC.module:common
*@description
* <p>
* Defines an application module "app.common" at global namespace.commonModules are the logical
* it includes all the common services, constants, login modules
* </p>
* @requires ui.bootstrap
* @requires ui.rooter
* @requires restangular
* @requires ngIdle 
* @project FTIC 
* @Date
* @version 1
* @author Suresh P
*/


window.jQuery = window.$ = require('jquery/dist/jquery.js');
window._ = require('lodash');
// window.communicationWizard = require('./components/communication/communicationcapabilities.js');
require('angular-bootstrap');
require('bootstrap/dist/js/bootstrap.js');
require('angular-ui-router/release/angular-ui-router.js');
require('angular-animate');
require('angular-cookies');
require('angular-resource');
require('angular-sanitize');
require('angular-translate/angular-translate.js');
require('domready/ready');
require('lodash');
require('restangular');
require('ngstorage/ngStorage.min.js');
require('angularjs-toaster');
require('log4javascript');
require('angularytics/dist/angularytics.js');
require('ng-idle/angular-idle.js');
require('angular-ui-grid/ui-grid.min.js');
require('angularjs-slider/dist/rzslider.min.js');
require('file-saver/FileSaver.min.js');
require('angular-file-saver/dist/angular-file-saver.min.js');
window.ifvisible = require('ifvisible.js/src/ifvisible.min.js');
require('angular-messages');
// require('angular-ui-sortable');
// require('malhar-angular-dashboard');
require('highcharts');
require('angular-addthis/dist/angular-addthis.min.js');
module.exports = angular.module('common',
    [
        'ui.bootstrap',
        'ui.router',
        'ngAnimate',
        'ngCookies',
        'ngResource',
        'ngSanitize',
        'pascalprecht.translate',
        'restangular',
        'ngStorage',
        'toaster',
        'angularytics',
        'ngIdle',
        'ui.grid',
        'ui.grid.pinning',
        'ui.grid.pagination',
        'rzModule',
        'ngMessages',
        'sn.addthis',
        'ngFileSaver',
        // 'ui.sortable',
        // 'ui.dashboard',
        require('./components/header').name,
        require('./components/footer').name,
        require('./components').name,
        require('./transact').name,
        require('./transact/events').name,
        require('./transact/constants').name,
        require('./components/megamenu').name,
        require('./config').name,
        require('./interceptors').name,
        require('./filters').name,
        require('./services').name,
        require('./login').name,
        require('./calculators').name,
        require('./proceedtobuy').name
    ]);

navigator.userAgent.match(/iPhone|iPad|iPod/i);
var isMobile = /iPad|iPhone|iPod/.test(navigator.platform);
var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);
 
if(isMobile) {
    $('body').on('touchstart click', function (e) {
        if ($(e.target).data('toggle') !== 'popover' && $(e.target).parents('[data-toggle="popover"]').length === 0 && $(e.target).parents('.popover.in').length === 0 &&  $('div.popover:visible').length) {
                setTimeout(function(){
                    $('div.popover:visible').parents('.ftic-mailback').find('.btn-mailback').trigger("click");
                }, 1000);         
        }
    });
} 
