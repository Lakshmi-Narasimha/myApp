'use strict';

module.exports = angular.module('common.components.navbar', [])
    .directive('uicNavBar', require('./navbar.directive'))
    .service('uicNavBarService', require('./navbar.service'));