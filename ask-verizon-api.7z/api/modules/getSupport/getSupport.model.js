var getSupportModelConfig = {
    response: {
        "ResponseInfo": {
            "locale": "EN",
            "type": "Success",
            "server": "twswcmvmzad03.tdc.vzwcorp.com:srv03_nmobilefirst01",
            "buildNumber": "9063",
            "requestId": "98fea3f0-3f99-48cf-995c-4d3dd474cf32",
            "mdn": "2566105456",
            "code": "00000",
            "message": "0",
            "userMessage": "0"
        },
        "Page": {
            "pageType": "getSupport",
            "ButtonMap": {
                "callVerizonAfterAuthCheck": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "callVerizonAfterAuthCheck",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "getChatHistory": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "getChatHistory",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "title": "Sign in",
                    "isSelected": false,
                    "chatSignInMsg": "There's more perosnal info here. Want to see it?"
                },
                "getSupport": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "getSupport",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "callVerizonAfterAuthCancel": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "callVerizonAfterAuthCancel",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "callVerizonSelection": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "callVerizonSelection",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "getMessage": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "/rest/message",
                    "appContext": "mfchat",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "search": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "search",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "getEngagement": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "/rest/engagement",
                    "appContext": "mfchat",
                    "actionType": "openPage",
                    "isSelected": false,
                    "extraParameters": {
                        "nickName": "Lebowski",
                        "encryptedMdn": "3nrRfd7JNZfY8ZfbyuouyA==",
                        "InitialParams": {
                            "appName": "com.vzw.hss.myverizon",
                            "appVersion": "12.7.0",
                            "carrier": "verizon",
                            "model": "SM-G900V",
                            "osName": "Android",
                            "osVersion": "6.0.1",
                            "deviceName": "kltevzw",
                            "formFactor": "handset",
                            "sourceServer": "None",
                            "timeZone": "EST",
                            "wifi": true,
                            "uuid": "acfcf2f0-d7f7-4d67-9c78-9f84f989eb1c",
                            "searchSource": "API_AI",
                            "sourceID": "mvmrc",
                            "showFirstBillInterstitial": false,
                            "SSO": {
                                "ssoToken": "iIFu97qeLT1lDLGGbqz0IVlFAkgydummyssovalue=",
                                "mdn": "2566105456"
                            },
                            "sim_operator_code": "311480",
                            "countryName": "us"
                        },
                        "MDN": "2566105456",
                        "shopSessionInfo": null,
                        "accRole": "Account Owner"
                    }
                },
                "getCustomerTyping": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "/rest/customerIsTyping",
                    "appContext": "mfchat",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "logClickEvents": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "logClickEvents",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "getSurvey": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "/rest/survey",
                    "appContext": "mfchat",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "getTypeSearchSupport": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "getTypeSearchSupport",
                    "appContext": "mobileFirstSS",
                    "actionType": "openPage",
                    "isSelected": false
                },
                "getAgent": {
                    "presentationStyle": "push",
                    "tryToReplaceFirst": false,
                    "disableAction": false,
                    "selected": false,
                    "pageType": "/rest/agent",
                    "appContext": "mfchat",
                    "actionType": "openPage",
                    "isSelected": false
                }
            },
            "nextmsgId": 4010,
            "chatMenuStartID": 902,
            "userLoggedIn": false,
            "searchBarButtonTitle": "Menu",
            "chatBaseURL": "https://mobile-nqa.vzw.com/",
            "searchMessage": "Tell us what you need",
            "pageStatNames": [
                "/mf/intl/plan/current/features",
                "/mf/intl/plan/current/products",
                "/mf/support"
            ],
            "chatInitMessageID": 1001,
            "analyticsPageName": "/mf/support",
            "screenHeading": "Support"
        },
        "ModuleMap": {
            "Support": {
                "ResponseInfo": {
                    "locale": "EN",
                    "type": "Success",
                    "code": "00000",
                    "message": "0",
                    "userMessage": "0"
                },
                "msgList": [{
                    "type": "link",
                    "msgId": 3049,
                    "messageList": [{
                        "content": "Got it. You can talk to an expert for help. Head over to our site to <a>contact customer support</a>.",
                        "nextmsgId": 3050,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://www.verizonwireless.com/support/contact-us/",
                                "title": "contact customer support",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 3050,
                    "messageList": [{
                        "content": "For a quicker option, you can try one of these other ways to get help.",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Tweet us",
                        "nextmsgId": 3002,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Post on our Facebook page",
                        "nextmsgId": 3003,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 4020,
                    "messageList": [{
                        "content": "We would like to use your current location.",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Don’t allow",
                        "nextmsgId": 308,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Okay",
                        "nextmsgId": 302,
                        "animationDuration": 0,
                        "successMsgId": 302,
                        "failureMsgId": 4020,
                        "condition": "OPEN LOCATION",
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }],
                    "feedCard": false
                }, {
                    "type": "menu",
                    "msgId": 107,
                    "messageList": [{
                        "content": "View miniguides",
                        "nextmsgId": 200,
                        "animationDuration": 0,
                        "analyticsTagName": "View_the_miniguide",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowinitiated": "1",
                            "vzwi.mvmapp.flowType": "View miniguides",
                            "vzwi.mvmapp.flowName": "support"
                        }
                    }, {
                        "content": "Find a store",
                        "nextmsgId": 300,
                        "animationDuration": 0,
                        "analyticsTagName": "Find a store",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowinitiated": "1",
                            "vzwi.mvmapp.flowType": "Find a store",
                            "vzwi.mvmapp.flowName": "support"
                        }
                    }, {
                        "content": "See trending support topics",
                        "nextmsgId": 400,
                        "animationDuration": 0,
                        "analyticsTagName": "See trending topics",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowinitiated": "1",
                            "vzwi.mvmapp.flowType": "See trending support topics",
                            "vzwi.mvmapp.flowName": "support"
                        }
                    }, {
                        "content": "Visit community forums",
                        "nextmsgId": 500,
                        "animationDuration": 0,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowinitiated": "1",
                            "vzwi.mvmapp.flowType": "Visit community forums",
                            "vzwi.mvmapp.flowName": "support"
                        }
                    }, {
                        "content": "Contact us",
                        "nextmsgId": 600,
                        "animationDuration": 0,
                        "analyticsTagName": "contact us",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowinitiated": "1",
                            "vzwi.mvmapp.flowType": "Contact us",
                            "vzwi.mvmapp.flowName": "support"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 1001,
                    "messageList": [{
                        "content": "You got it. I’ll connect you.",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "condition": "STARTCHAT"
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 633,
                    "messageList": [{
                        "content": "Call a Tech Coach",
                        "nextmsgId": 634,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 634,
                    "messageList": [{
                        "content": "Okay, a personal tech coach will help you shortly. <a>Call now</a>.",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_CLICK_TO_CALL",
                        "ButtonMap": {
                            "FeedLink": {
                                "title": "Call now",
                                "callNumber": "18009220204",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "action": "18009220204",
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "StartCall",
                                "appContext": "mobileFirstSS",
                                "actionType": "call",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 3030,
                    "messageList": [{
                        "content": "Great. You can speak with someone on the phone as soon as the next expert is available.",
                        "nextmsgId": 3031,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 3031,
                    "messageList": [{
                        "content": "A quick heads up, you can't use data and talk with customer support at the same time.",
                        "nextmsgId": 3032,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 3032,
                    "messageList": [{
                        "content": "To use internet during your call, turn on wi-fi. <a> Call {1} </a>",
                        "nextmsgId": 3017,
                        "animationDuration": 800,
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_CLICK_TO_CALL",
                        "ButtonMap": {
                            "FeedLink": {
                                "title": " Call {1} ",
                                "callNumber": "18009220204",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "action": "18009220204",
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "StartCall",
                                "appContext": "mobileFirstSS",
                                "actionType": "call",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 655,
                    "messageList": [{
                        "content": "On September 2,2016 Samsung announced a voluntary recall of the Galaxy Note7 due to an issue with the device's battery. Because customer safety is our top priority, Verizon immediately stopped selling the Galaxy Note7. <a>Take me there</a>",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "http://www.verizonwireless.com/support/samsung-galaxy-note7/",
                                "title": "Take me there",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "recall",
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 100,
                    "messageList": [{
                        "content": "Hey, Lebowski.",
                        "nextmsgId": 101,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 101,
                    "messageList": [{
                        "content": "Have a question? This works a lot like chat. To start, simply type below.",
                        "nextmsgId": 4001,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 102,
                    "messageList": [{
                        "content": "Sounds good.",
                        "nextmsgId": 103,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 103,
                    "messageList": [{
                        "content": "Perfect. You can also type a topic into the search bar below at any time.",
                        "nextmsgId": 104,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 104,
                    "messageList": [{
                        "content": "Got it. Let’s go.",
                        "nextmsgId": 105,
                        "animationDuration": 2000,
                        "analyticsTagName": "Got_it_let’s_go",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 105,
                    "messageList": [{
                        "content": "Great, pick a topic or type your search below.",
                        "nextmsgId": 106,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "header",
                    "msgId": 106,
                    "messageList": [{
                        "content": "What are you trying to do?",
                        "nextmsgId": 107,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 200,
                    "messageList": [{
                        "content": "Show me some miniguides.",
                        "nextmsgId": 201,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 201,
                    "messageList": [{
                        "content": "Coming right up. By the way, you can always bring up the menu by tapping the button next to the search field below.",
                        "nextmsgId": 202,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "miniguide",
                    "msgId": 202,
                    "messageList": [{
                        "content": "It’s your data, keep it.",
                        "nextmsgId": 203,
                        "animationDuration": 800,
                        "hdgMsg": "It's your data, keep it.",
                        "subHdgMsg": "Get to know Carryover Data.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_CarryoverData_MF?fmt=png-alpha",
                        "headlineMsg": "Miniguide 1 Carryover Data",
                        "edwTagName": "#MF_SUPPORT_SELECT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "miniguide",
                    "msgId": 203,
                    "messageList": [{
                        "content": "No more surprise overages.",
                        "nextmsgId": 204,
                        "animationDuration": 800,
                        "hdgMsg": "No more surprise overages.",
                        "subHdgMsg": "Get to know Safety Mode.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_SafetyMode_MF?fmt=png-alpha",
                        "headlineMsg": "Miniguide 2 Safety Mode",
                        "edwTagName": "#MF_SUPPORT_SELECT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 204,
                    "messageList": [{
                        "content": "Do you want to see more helpful Miniguides?",
                        "nextmsgId": 205,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 205,
                    "messageList": [{
                        "content": "Yes.",
                        "nextmsgId": 207,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }, {
                        "content": "No, thanks.",
                        "nextmsgId": 206,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 206,
                    "messageList": [{
                        "content": "No problem, let’s figure out what you need.",
                        "nextmsgId": 106,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 207,
                    "messageList": [{
                        "content": "Cool, here you go!",
                        "nextmsgId": 208,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "miniguide",
                    "msgId": 208,
                    "messageList": [{
                        "content": "No surprises here.",
                        "nextmsgId": 220,
                        "animationDuration": 800,
                        "hdgMsg": "No surprises here.",
                        "subHdgMsg": "Get to know your first bill.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_FirstBill_MF?fmt=png-alpha",
                        "headlineMsg": "Miniguide 3 First Bill",
                        "edwTagName": "#MF_SUPPORT_SELECT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 209,
                    "messageList": [{
                        "content": "Do you still need help?",
                        "nextmsgId": 210,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 210,
                    "messageList": [{
                        "content": "No, thanks.",
                        "nextmsgId": 211,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }, {
                        "content": "Yes.",
                        "nextmsgId": 206,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 211,
                    "messageList": [{
                        "content": "We’re always here if you need any help.",
                        "nextmsgId": 213,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "miniguide",
                    "msgId": 220,
                    "messageList": [{
                        "content": "pop data",
                        "nextmsgId": 209,
                        "animationDuration": 800,
                        "hdgMsg": "Get to know PopData.",
                        "subHdgMsg": "All-you-can-stream 4G LTE data sessions.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_PopData_MF?fmt=png-alpha",
                        "imageName": "img_mgpopdata",
                        "headlineMsg": "Miniguide 4 PopData",
                        "edwTagName": "#MF_SUPPORT_SELECT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 300,
                    "messageList": [{
                        "content": "Find the closest Verizon store.",
                        "nextmsgId": 301,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "condition",
                    "msgId": 301,
                    "messageList": [{
                        "content": "Coming right up. By the way, you can always bring up the menu by tapping the button next to the search field below.",
                        "nextmsgId": 806,
                        "animationDuration": 800,
                        "successMsgId": 806,
                        "failureMsgId": 4020,
                        "condition": "LOCATION",
                        "denyMsgID": 308
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 302,
                    "messageList": [{
                        "content": "I found some info on our site.\n <a> Go take a look.  </a>",
                        "nextmsgId": 303,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "http://www.verizonwireless.com/stores/storesearchresults/?allow=1&&result=verizon",
                                "title": " Go take a look.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "findStores",
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false,
                                "condition": "ADD LOCATION"
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 304,
                    "messageList": [{
                        "content": "We would like to use your current location.",
                        "nextmsgId": 305,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 305,
                    "messageList": [{
                        "content": "Don’t allow",
                        "nextmsgId": 308,
                        "animationDuration": 800,
                        "analyticsTagName": "Location<Don’t Allow>",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }, {
                        "content": "Okay",
                        "nextmsgId": 302,
                        "animationDuration": 800,
                        "analyticsTagName": "Location<Okay>",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 308,
                    "messageList": [{
                        "content": "I found some info on our site.\n <a> Go take a look.  </a>",
                        "nextmsgId": 309,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "http://www.verizonwireless.com/vzw/storelocator/store-list-result.jsp",
                                "title": " Go take a look.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "findStores",
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 400,
                    "messageList": [{
                        "content": "Show me trending support topics.",
                        "nextmsgId": 401,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 401,
                    "messageList": [{
                        "content": "Coming right up. By the way, you can always bring up the menu by tapping the button next to the search field below.",
                        "nextmsgId": 402,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 402,
                    "messageList": [{
                        "content": "I found some info on our site. \n <a> Go take a look.  </a>",
                        "nextmsgId": 403,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "http://www.verizonwireless.com/support/trending-topics",
                                "title": " Go take a look.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "trendingTopics",
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 500,
                    "messageList": [{
                        "content": "Visit the community forums.",
                        "nextmsgId": 501,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 501,
                    "messageList": [{
                        "content": "Coming right up. By the way, you can always bring up the menu by tapping the button next to the search field below.",
                        "nextmsgId": 502,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 502,
                    "messageList": [{
                        "content": "I found some info on our site. \n <a> Go take a look.  </a>",
                        "nextmsgId": 503,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://community.verizonwireless.com/community/announcements",
                                "title": " Go take a look.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 600,
                    "messageList": [{
                        "content": "Show me how to contact Verizon.",
                        "nextmsgId": 601,
                        "animationDuration": 800,
                        "analyticsTagName": "Show_me_how_to _contact_Verizon"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 601,
                    "messageList": [{
                        "content": "Coming right up. By the way, you can always bring up the menu by tapping the button next to the search field below.",
                        "nextmsgId": 602,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 602,
                    "messageList": [{
                        "content": "You can tag us in a tweet with your question <a> @VZWSupport.  </a>",
                        "nextmsgId": 603,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://mobile.twitter.com/vzwsupport",
                                "title": " @VZWSupport.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false,
                                "appURL": "twitter://"
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 603,
                    "messageList": [{
                        "content": "Or post a question on our \n <a> Facebook page.  </a>",
                        "nextmsgId": 604,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://m.facebook.com/verizon",
                                "title": " Facebook page.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false,
                                "appURL": "fb://"
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 604,
                    "messageList": [{
                        "content": "Okay",
                        "nextmsgId": 612,
                        "animationDuration": 800
                    }, {
                        "content": "Any more options?",
                        "nextmsgId": 607,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowinitiated": "1",
                            "vzwi.mvmapp.flowType": "Contact Us",
                            "vzwi.mvmapp.flowName": "support"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 607,
                    "messageList": [{
                        "content": "You can get instant answers from a live chat agent on verizonwireless.com.",
                        "nextmsgId": 609,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 609,
                    "messageList": [{
                        "content": "Yes.",
                        "nextmsgId": 614,
                        "animationDuration": 800,
                        "analyticsTagName": "Contact us:More Options: Yes",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }, {
                        "content": "No, thanks.",
                        "nextmsgId": 612,
                        "animationDuration": 800,
                        "analyticsTagName": "Contact us:More Options: No",
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 612,
                    "messageList": [{
                        "content": "We’re always here if you need any help.",
                        "nextmsgId": 613,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 614,
                    "messageList": [{
                        "content": "Great, you’re all set to chat with a rep. Come back anytime. <a> Chat now </a>",
                        "nextmsgId": 615,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://tlogin.verizonwireless.com/octes/ocs2wamalias?target_url=https%3A%2F%2Fwww.verizonwireless.com%2Fsupport%2Fcontact-us%2F%23Chat&alias=east-YWZlNDE2YjUtZDMyYi00MTIxLThlMzUtMTg2ZGVhNjI3ZTE1fDE0ODg0MjcxNTQyOTQ",
                                "title": " Chat now ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 650,
                    "messageList": [{
                        "content": "Hmm. I’m not finding any info for that.",
                        "nextmsgId": 651,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 651,
                    "messageList": [{
                        "content": "Maybe there’s something else \n I can help you with.",
                        "nextmsgId": 4010,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 652,
                    "messageList": [{
                        "content": "I hear you. How can I help?",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }, {
                        "content": "I hear you. How can I help?",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 654,
                    "messageList": [{
                        "content": "Here’s pretty popular result I found for you: {1} {2} <a> Take me there.  </a>",
                        "nextmsgId": 656,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 656,
                    "messageList": [{
                        "content": "Or view all results on our site. \n <a> Go take a look.  </a>",
                        "nextmsgId": 6570,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 657,
                    "messageList": [{
                        "content": "There’s a section in the app that covers this. <a> Take me there.  </a>",
                        "nextmsgId": 658,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 658,
                    "messageList": [{
                        "content": "I also found some info on our site. \n <a> Go take a look.  </a>",
                        "nextmsgId": 659,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 661,
                    "messageList": [{
                        "content": "A Data Boost is the option to make a one-time purchase of 1 GB for $15. But you’ll need to adjust your plan for access.",
                        "nextmsgId": 670,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 662,
                    "messageList": [{
                        "content": "A Data Boost is the option to make a one-time purchase of 1 GB for $15. And good news, Data Boost is included as part of your plan.",
                        "nextmsgId": 670,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 670,
                    "messageList": [{
                        "content": "There’s a section in the app that covers this.<a> Take me there.  </a>",
                        "nextmsgId": 671,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 672,
                    "messageList": [{
                        "content": "Looks like we have a Miniguide for that.",
                        "nextmsgId": 673,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 673,
                    "messageList": [{
                        "content": "And there’s a section in the app that covers this.<a> Take me there.  </a>",
                        "nextmsgId": 658,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 677,
                    "messageList": [{
                        "content": "Are you trying to shop? If so, you can actually do it within the app. <a> Take me there.  </a>",
                        "nextmsgId": 658,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 678,
                    "messageList": [{
                        "content": "I found something about that in the app. Would you like to use that feature?",
                        "nextmsgId": 679,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 679,
                    "messageList": [{
                        "content": "Yes",
                        "nextmsgId": 680,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 680,
                    "messageList": [{
                        "content": "Great. You have {1} devices to pick from. Which one do you want manage?",
                        "nextmsgId": 681,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 681,
                    "messageList": [{
                        "content": "Great. You can manage that here. <a> Take me there.  </a>",
                        "nextmsgId": 682,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userOption",
                    "msgId": 683,
                    "messageList": [{
                        "content": "No, thanks.",
                        "nextmsgId": 684,
                        "animationDuration": 800,
                        "analyticalParams": {
                            "vzwi.mvmapp.flowcompleted": "1"
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 684,
                    "messageList": [{
                        "content": "I found some info on our site. <a> Go take a look.  </a>",
                        "nextmsgId": 685,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 685,
                    "messageList": [{
                        "content": "You can get instant answers from a live chat agent on verizonwireless.com.",
                        "nextmsgId": 609,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 686,
                    "messageList": [{
                        "content": "<a>Family Base is not currently available for this app but we are working on it and it will be available soon! </a>",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 700,
                    "messageList": [{
                        "content": "Welcome back, Lebowski. How can I help?",
                        "nextmsgId": 4010,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 1000,
                    "messageList": [{
                        "content": "Give me a second while I look.",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 2000,
                    "messageList": [{
                        "content": "Service is temporarily unavailable. Please try again later.",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "contentMenu",
                    "msgId": 4001,
                    "messageList": [{
                        "content": "What can I help you with?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU"
                    }, {
                        "content": "Miniguides",
                        "nextmsgId": 4002,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Finding a store",
                        "nextmsgId": 300,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Trending support topics",
                        "nextmsgId": 400,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Community forums",
                        "nextmsgId": 500,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Contacting Verizon",
                        "nextmsgId": 3000,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "search",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "edwTagName": "#MF_SUPPORT_DTREE_T1_ESCALATION_1",
                                    "searchTerm": "Contacting Verizon"
                                }
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 4002,
                    "messageList": [{
                        "content": "Show me some miniguides",
                        "nextmsgId": 4007,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3000,
                    "messageList": [{
                        "content": "Show me how to contact Verizon.",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 4007,
                    "messageList": [{
                        "content": "Coming right up. By the way, you can always bring up the menu by tapping the button in the field below.",
                        "nextmsgId": 4008,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3002,
                    "messageList": [{
                        "content": "Tweet us",
                        "nextmsgId": 3006,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3003,
                    "messageList": [{
                        "content": "Post on our Facebook page",
                        "nextmsgId": 3007,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3004,
                    "messageList": [{
                        "content": "Chat with us right here",
                        "nextmsgId": 3008,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 3006,
                    "messageList": [{
                        "content": "Use this tag to ask your question on Twitter <a> @VZWSupport.  </a>",
                        "nextmsgId": 3010,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://mobile.twitter.com/vzwsupport",
                                "title": " @VZWSupport.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false,
                                "appURL": "twitter://"
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 3007,
                    "messageList": [{
                        "content": "Ask your question on our <a> Facebook page.  </a>",
                        "nextmsgId": 3011,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://m.facebook.com/verizon",
                                "title": " Facebook page.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "appContext": "mobileFirstSS",
                                "actionType": "openURL",
                                "isSelected": false,
                                "appURL": "fb://"
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 3008,
                    "messageList": [{
                        "content": "Great. I’ll help you find the right person. Pick the topic you need help with.",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_"
                    }, {
                        "content": "Managing my account",
                        "nextmsgId": 3012,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "20"
                                }
                            }
                        }
                    }, {
                        "content": "Understanding my bill",
                        "nextmsgId": 3013,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "21"
                                }
                            }
                        }
                    }, {
                        "content": "Traveling abroad",
                        "nextmsgId": 3014,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "22"
                                }
                            }
                        }
                    }, {
                        "content": "Using my device",
                        "nextmsgId": 3015,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "23",
                                    "checkTotalMobileProtection": true
                                }
                            }
                        }
                    }, {
                        "content": "Shopping Verizon",
                        "nextmsgId": 3016,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "24"
                                }
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 3009,
                    "messageList": [{
                        "content": "Great. You can speak with someone on the phone as soon as the next expert is available.<a> Call {1} </a>",
                        "nextmsgId": 3017,
                        "animationDuration": 800,
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_CLICK_TO_CALL",
                        "ButtonMap": {
                            "FeedLink": {
                                "title": " Call {1} ",
                                "callNumber": "18009220204",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "action": "18009220204",
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "StartCall",
                                "appContext": "mobileFirstSS",
                                "actionType": "call",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3012,
                    "messageList": [{
                        "content": "Managing my account",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3013,
                    "messageList": [{
                        "content": "Understanding my bill",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3014,
                    "messageList": [{
                        "content": "Traveling abroad",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3015,
                    "messageList": [{
                        "content": "Using my device",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }, {
                        "content": "Using my device",
                        "nextmsgId": 631,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3016,
                    "messageList": [{
                        "content": "Shopping Verizon",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 20,
                    "messageList": [{
                        "content": "Thanks. What do you want to know about Managing your account?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "condition": "CHAT_INIT_MESSAGE",
                        "agentGroup": "MVTrans"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 21,
                    "messageList": [{
                        "content": "Thanks. What do you want to know about your bill?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "condition": "CHAT_INIT_MESSAGE",
                        "agentGroup": "Billing"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 22,
                    "messageList": [{
                        "content": "Thanks. What do you want to know about your international calling?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "condition": "CHAT_INIT_MESSAGE",
                        "agentGroup": "Global"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 23,
                    "messageList": [{
                        "content": "Thanks. What do you want to know about your device?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "condition": "CHAT_INIT_MESSAGE",
                        "agentGroup": "Device"
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 24,
                    "messageList": [{
                        "content": "Thanks. What do you want to know about your verizon shopping?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "condition": "CHAT_INIT_MESSAGE",
                        "agentGroup": "WirelessSales"
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 3018,
                    "messageList": [{
                        "content": "Before we move on, I want to make sure I’m talking to the right person. Let’s get you signed in.",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Enter password",
                        "nextmsgId": -5,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Cancel",
                        "nextmsgId": 3019,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }],
                    "feedCard": false
                }, {
                    "type": "contentChatMenu",
                    "msgId": 902,
                    "messageList": [{
                        "content": "Start with one of these popular topics:",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU"
                    }, {
                        "content": "Miniguides",
                        "nextmsgId": 903,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Finding a store",
                        "nextmsgId": 904,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Trending support topics",
                        "nextmsgId": 905,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Community forums",
                        "nextmsgId": 906,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Contacting Verizon",
                        "nextmsgId": 907,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }],
                    "feedCard": false
                }, {
                    "type": "userChat",
                    "msgId": 903,
                    "messageList": [{
                        "content": "View miniguides",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userChat",
                    "msgId": 904,
                    "messageList": [{
                        "content": "Find a store",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userChat",
                    "msgId": 905,
                    "messageList": [{
                        "content": "See trending support topics",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userChat",
                    "msgId": 906,
                    "messageList": [{
                        "content": "Visit community forums",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userChat",
                    "msgId": 907,
                    "messageList": [{
                        "content": "Contact us",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 1100,
                    "messageList": [{
                        "content": "Hey Lebowski, looks like you are shopping for something new.",
                        "nextmsgId": 1101,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 1101,
                    "messageList": [{
                        "content": "Do you want to chat with a sales expert?",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_"
                    }, {
                        "content": "Yes",
                        "nextmsgId": 1102,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "24"
                                }
                            }
                        }
                    }, {
                        "content": "No",
                        "nextmsgId": 1103,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 1102,
                    "messageList": [{
                        "content": "Yes",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 1103,
                    "messageList": [{
                        "content": "No",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 1111,
                    "messageList": [{
                        "content": "Hey Lebowski, do you want to chat with a sales expert about choosing a new phone/accessory.",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_"
                    }, {
                        "content": "Yes",
                        "nextmsgId": 1112,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "24"
                                }
                            }
                        }
                    }, {
                        "content": "No",
                        "nextmsgId": 1113,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 1112,
                    "messageList": [{
                        "content": "Yes",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 1113,
                    "messageList": [{
                        "content": "No",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 1121,
                    "messageList": [{
                        "content": "Hey Lebowski, do you want to chat with a sales expert about the product?.",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_"
                    }, {
                        "content": "Yes",
                        "nextmsgId": 1122,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "enterChatPassword",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "nxtMsgId": "24"
                                }
                            }
                        }
                    }, {
                        "content": "No",
                        "nextmsgId": 1123,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_SALES_CHAT_"
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 1122,
                    "messageList": [{
                        "content": "Yes",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 1123,
                    "messageList": [{
                        "content": "No",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 3020,
                    "messageList": [{
                        "content": "Heads up, you wont be able to use your data and talk with customer support at the same time.",
                        "nextmsgId": 3021,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 3021,
                    "messageList": [{
                        "content": "To use the internet during the call, turn on Wi-Fi. <a>Start call</a>.",
                        "nextmsgId": 3022,
                        "animationDuration": 0,
                        "ButtonMap": {
                            "FeedLink": {
                                "title": "Start call",
                                "callNumber": "1 (800) 888-8888",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "action": "1 (800) 888-8888",
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "StartCall",
                                "appContext": "mobileFirstSS",
                                "actionType": "call",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 632,
                    "messageList": [{
                        "content": "Not now",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "contentMenu",
                    "msgId": 4010,
                    "messageList": [{
                        "content": "You can chat or start with one of these topics.",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU"
                    }, {
                        "content": "Miniguides",
                        "nextmsgId": 4002,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Finding a store",
                        "nextmsgId": 300,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Trending support topics",
                        "nextmsgId": 400,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Community forums",
                        "nextmsgId": 500,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_"
                    }, {
                        "content": "Contacting Verizon",
                        "nextmsgId": 3000,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "search",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "edwTagName": "#MF_SUPPORT_DTREE_T1_ESCALATION_1",
                                    "searchTerm": "Contacting Verizon"
                                }
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 3001,
                    "messageList": [{
                        "content": "You have a few options to pick from. Which one do you want to do?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Tweet us",
                        "nextmsgId": 3002,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Post on our Facebook page",
                        "nextmsgId": 3003,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 631,
                    "messageList": [{
                        "content": "Great news, {1}. You have Total Mobile Protection. Would you like to talk with your personal Tech Coach?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_TMP_"
                    }, {
                        "content": "Call a Tech Coach",
                        "nextmsgId": 633,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_TMP_"
                    }, {
                        "content": "Not now",
                        "nextmsgId": 632,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_TMP_"
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 3017,
                    "messageList": [{
                        "content": "Or you can always pick another option to get help quickly.",
                        "nextmsgId": -1,
                        "animationDuration": 0,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Tweet us",
                        "nextmsgId": 3002,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }, {
                        "content": "Post on our Facebook page",
                        "nextmsgId": 3003,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_"
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 801,
                    "messageList": [{
                        "content": "For a limited time, get NBA League Pass for the 16-17 season included with a Large or higher data plan.<a> Take me there.  </a>",
                        "nextmsgId": 658,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 806,
                    "messageList": [{
                        "content": "There’s a section in the app that covers this. <a> Take me there.  </a>",
                        "nextmsgId": 302,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "title": " Take me there.  ",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "storeLocator",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 805,
                    "messageList": [{
                        "content": "If you need Employee Accounts assistance, please call 800.922.0204. Our hours are Monday - Friday, 8 AM - 8 PM Eastern.",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "miniguide",
                    "msgId": 4008,
                    "messageList": [{
                        "content": "phone to phone transfer",
                        "nextmsgId": -6,
                        "animationDuration": 0,
                        "hdgMsg": "Move everything in a few steps.",
                        "subHdgMsg": "Transfer things from your old phone to your new one.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_PhonetoPhoneTransfer_MF",
                        "headlineMsg": "Miniguide 5 Phone-to-phone transfer",
                        "edwTagName": "#MF_SUPPORT_SELECT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "modal",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "selected": false,
                                "pageType": "miniGuidePhoneToPhoneTransfer",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "title": "View Miniguide",
                                "isSelected": false,
                                "resultType": "MiniGuide",
                                "extraParameters": {
                                    "feedName": "PhoneToPhoneTransferFeed"
                                }
                            }
                        }
                    }, {
                        "content": "backup cloud",
                        "nextmsgId": -7,
                        "animationDuration": 0,
                        "hdgMsg": "Save everything to the cloud.",
                        "subHdgMsg": "Always know your things are safe and accessible.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_BackuptoCloud_MF",
                        "headlineMsg": "Miniguide 6 Backup to cloud",
                        "edwTagName": "#MF_SUPPORT_SELECT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "modal",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "selected": false,
                                "pageType": "miniGuideBackUpToCloud",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "title": "View Miniguide",
                                "isSelected": false,
                                "resultType": "MiniGuide",
                                "extraParameters": {
                                    "feedName": "BackupToCloudFeed"
                                }
                            }
                        }
                    }, {
                        "content": "killswitch",
                        "nextmsgId": -8,
                        "animationDuration": 0,
                        "hdgMsg": "An important step for trading in devices.",
                        "subHdgMsg": "Get to know the steps to turn it off.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/1.3_MF_Miniguide_FindmyiPhone_Image2",
                        "headlineMsg": "Miniguide 7 Turn off Find My iPhone",
                        "edwTagName": "#MF_SUPPORT_SELECT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "modal",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "selected": false,
                                "pageType": "miniGuideKillSwitch",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "title": "View Miniguide",
                                "isSelected": false,
                                "resultType": "MiniGuide",
                                "extraParameters": {
                                    "feedName": "TurnOffFindMyiPhoneFeed"
                                }
                            }
                        }
                    }, {
                        "content": "Overage",
                        "nextmsgId": -9,
                        "animationDuration": 0,
                        "hdgMsg": "Worry-free streaming.",
                        "subHdgMsg": "Find out how to avoid an overage.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/1.3_MF_Feed_Miniguide_Overages_Cropped_Imagery_MF",
                        "headlineMsg": "Miniguide 8 Avoiding overages",
                        "edwTagName": "#MF_SUPPORT_SELECT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "modal",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "selected": false,
                                "pageType": "miniGuideOverage",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "title": "View Miniguide",
                                "isSelected": false,
                                "feedName": "OverageMiniguideFeed",
                                "miniguide": "Overage",
                                "resultType": "MiniGuide",
                                "extraParameters": {
                                    "feedName": "OverageMiniguideFeed",
                                    "miniguide": "Overage"
                                }
                            }
                        }
                    }, {
                        "content": "Gifted data",
                        "nextmsgId": -10,
                        "animationDuration": 0,
                        "hdgMsg": "Surprise someone with a 1GB data gift.",
                        "subHdgMsg": "Learn all about sending and receiving data gifts.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/Miniguide_GiftedData_MF",
                        "headlineMsg": "Miniguide 9 Gifted Data",
                        "edwTagName": "#MF_SUPPORT_SELECT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "modal",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "selected": false,
                                "pageType": "miniGuideGiftedData",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "title": "View Miniguide",
                                "isSelected": false,
                                "feedName": "GiftedDataMiniguideFeed",
                                "miniguide": "GiftedData",
                                "resultType": "MiniGuide",
                                "extraParameters": {
                                    "feedName": "GiftedDataMiniguideFeed",
                                    "miniguide": "GiftedData"
                                }
                            }
                        }
                    }, {
                        "content": "Finding your way around",
                        "nextmsgId": -11,
                        "animationDuration": 0,
                        "hdgMsg": "Get to know the new My Verizon",
                        "subHdgMsg": "Get to know the new My Verizon app.",
                        "imageURL": "https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/1.4_Miniguide_FindWay_6",
                        "headlineMsg": "Miniguide 10 \nFinding your \nway around",
                        "edwTagName": "#MF_SUPPORT_SELECT_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "modal",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "selected": false,
                                "pageType": "miniGuideFindWay",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "title": "View Miniguide",
                                "isSelected": false,
                                "feedName": "MiniguideFindWayFeed",
                                "miniguide": "FindWay",
                                "resultType": "MiniGuide",
                                "extraParameters": {
                                    "feedName": "MiniguideFindWayFeed",
                                    "miniguide": "FindWay"
                                }
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3005,
                    "messageList": [{
                        "content": "Call customer support",
                        "nextmsgId": 5000,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5080,
                    "messageList": [{
                        "content": "Got it. You can give us a call right now, but the wait could be over 15 minutes. <a> Call {1} </a>",
                        "nextmsgId": 3017,
                        "animationDuration": 0,
                        "ButtonMap": {
                            "FeedLink": {
                                "title": " Call {1} ",
                                "callNumber": "611",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "action": "611",
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "StartCall",
                                "appContext": "mobileFirstSS",
                                "actionType": "call",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 5000,
                    "messageList": [{
                        "content": "Sure thing. Tell me what you'd like help with and I'll connect you with the right person.",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_"
                    }, {
                        "content": "Billing and payments",
                        "nextmsgId": 5001,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "isInSupportModule": true,
                                "selected": false,
                                "pageType": "callVerizonSelection",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "callReasonCode": "Billing and payments",
                                    "deviceMdn": "2566105456",
                                    "callVerizon": "true"
                                }
                            }
                        }
                    }, {
                        "content": "Questions about data",
                        "nextmsgId": 5002,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_"
                    }, {
                        "content": "Managing my account",
                        "nextmsgId": 5003,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "isInSupportModule": true,
                                "selected": false,
                                "pageType": "callVerizonSelection",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "callReasonCode": "Managing my account",
                                    "deviceMdn": "2566105456",
                                    "callVerizon": "true"
                                }
                            }
                        }
                    }, {
                        "content": "Shopping Verizon",
                        "nextmsgId": 5004,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "isInSupportModule": true,
                                "selected": false,
                                "pageType": "callVerizonSelection",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "callReasonCode": "Shopping Verizon",
                                    "deviceMdn": "2566105456",
                                    "callVerizon": "true"
                                }
                            }
                        }
                    }, {
                        "content": "Using my device",
                        "nextmsgId": 5005,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "optionType": "MENU",
                        "edwTagName": "#MF_SUPPORT_RESPONSE_LIVE_TOPIC_MENU_",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "isInSupportModule": true,
                                "selected": false,
                                "pageType": "callVerizonSelection",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "callReasonCode": "Using my device",
                                    "deviceMdn": "2566105456",
                                    "callVerizon": "true"
                                }
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5001,
                    "messageList": [{
                        "content": "Billing and payments",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5002,
                    "messageList": [{
                        "content": "Questions about data",
                        "nextmsgId": 5020,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5003,
                    "messageList": [{
                        "content": "Managing my account",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5004,
                    "messageList": [{
                        "content": "Shopping Verizon",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5005,
                    "messageList": [{
                        "content": "Using my device",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 5020,
                    "messageList": [{
                        "content": "Okay, how can I help you with that?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle"
                    }, {
                        "content": "Data Usage",
                        "nextmsgId": 5021,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "isInSupportModule": true,
                                "selected": false,
                                "pageType": "callVerizonSelection",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "callReasonCode": "Data Usage",
                                    "deviceMdn": "2566105456",
                                    "callVerizon": "true"
                                }
                            }
                        }
                    }, {
                        "content": "International data",
                        "nextmsgId": 5022,
                        "animationDuration": 0,
                        "childType": "contentOption",
                        "ButtonMap": {
                            "FeedLink": {
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "analyticsKey": null,
                                "resultType": null,
                                "isInSupportModule": true,
                                "selected": false,
                                "pageType": "callVerizonSelection",
                                "appContext": "mobileFirstSS",
                                "actionType": "openPage",
                                "isSelected": false,
                                "extraParameters": {
                                    "callReasonCode": "International data",
                                    "deviceMdn": "2566105456",
                                    "callVerizon": "true"
                                }
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5021,
                    "messageList": [{
                        "content": "Data Usage",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5022,
                    "messageList": [{
                        "content": "International data",
                        "nextmsgId": -1,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5100,
                    "messageList": [{
                        "content": "Our call center isn't open right now. But we open at 7am, if you'd like to give us a call at 611.",
                        "nextmsgId": 5101,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5101,
                    "messageList": [{
                        "content": "We're open during the week from 7am to 11pm and on the weekend from 8am to 9pm.",
                        "nextmsgId": 3017,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5200,
                    "messageList": [{
                        "content": "Our call center isn't open right now. But we open at 8am, if you'd like to give us a call at 800.256.4646.",
                        "nextmsgId": 5201,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5201,
                    "messageList": [{
                        "content": "We're open during the week from 8am to 11pm, on Saturday from 8am to 9pm and Sunday from 9am to 8pm.",
                        "nextmsgId": 3017,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5050,
                    "messageList": [{
                        "content": "No worries. You can still talk to an expert without signing in.<a> Call {1} </a>",
                        "nextmsgId": 3017,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 5060,
                    "messageList": [{
                        "content": "No worries. You can still talk to an expert without signing in.",
                        "nextmsgId": 3031,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 5250,
                    "messageList": [{
                        "content": "Great news, Lebowski. You have Total Mobile Protection. Would you like to chat with your personal Tech Coach?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle"
                    }, {
                        "content": "Start chat",
                        "nextmsgId": 5251,
                        "animationDuration": 0,
                        "childType": "contentOption"
                    }, {
                        "content": "Not now",
                        "nextmsgId": 5252,
                        "animationDuration": 0,
                        "childType": "contentOption"
                    }],
                    "feedCard": false
                }, {
                    "type": "content",
                    "msgId": 5300,
                    "messageList": [{
                        "content": "Can I help with anything else?",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "childType": "contentTitle"
                    }, {
                        "content": "Yes",
                        "nextmsgId": 5301,
                        "animationDuration": 0,
                        "childType": "contentOption"
                    }, {
                        "content": "No",
                        "nextmsgId": 5302,
                        "animationDuration": 0,
                        "childType": "contentOption"
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5251,
                    "messageList": [{
                        "content": "Start chat",
                        "nextmsgId": 23,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5252,
                    "messageList": [{
                        "content": "Not now",
                        "nextmsgId": 5300,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5301,
                    "messageList": [{
                        "content": "Yes",
                        "nextmsgId": 5303,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 5302,
                    "messageList": [{
                        "content": "No",
                        "nextmsgId": 5304,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 5303,
                    "messageList": [{
                        "content": "How can I help?",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 5304,
                    "messageList": [{
                        "content": "Okay, I’m here if anything comes up.",
                        "nextmsgId": -1,
                        "animationDuration": 800
                    }],
                    "feedCard": false
                }, {
                    "type": "bot",
                    "msgId": 5070,
                    "messageList": [{
                        "content": "A quick heads up, you can't use data and talk with your Tech Coach at the same time.",
                        "nextmsgId": 5071,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }, {
                    "type": "link",
                    "msgId": 5071,
                    "messageList": [{
                        "content": "To use internet during your call, turn on wi-fi. <a> Call {1} </a>",
                        "nextmsgId": -1,
                        "animationDuration": 800,
                        "ButtonMap": {
                            "FeedLink": {
                                "title": " Call {1} ",
                                "callNumber": "611",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false,
                                "action": "611",
                                "analyticsKey": null,
                                "resultType": null,
                                "selected": false,
                                "pageType": "StartCall",
                                "appContext": "mobileFirstSS",
                                "actionType": "call",
                                "isSelected": false
                            }
                        }
                    }],
                    "feedCard": false
                }, {
                    "type": "userMessage",
                    "msgId": 3019,
                    "messageList": [{
                        "content": "Cancel",
                        "nextmsgId": 5300,
                        "animationDuration": 0
                    }],
                    "feedCard": false
                }],
                "startMsgId": 700,
                "searchStartIndex": 0
            }
        }
    }
};

module.exports = getSupportModelConfig;
