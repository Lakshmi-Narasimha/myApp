// getRegForm.model.js
// grab the mongoose module
// define our occupations.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RegFormSchema = new mongoose.Schema({
    RegResp: {
        type: Array,
        "default": []
    }
});

var RegistrationFormLookUp = mongoose.model('RegistrationFormLookUp', RegFormSchema);

var FormModel = new RegistrationFormLookUp({
    "RegResp" : {
        'occupation' : {
            'occuDetails': [
                {
                    'name' : 'IT Professional' 
                },
                {
                    'name' : 'Business' 
                },
                {
                    'name' : 'Banker' 
                },
                {
                    'name' : 'Entrepreneur' 
                }
            ]
        },

        'grossIncome' : {
            'grossIncomeDetails' :[
                {
                    'range' : '2-3 lakhs'
                },
                {
                    'range' : '3-4 lakhs'
                },
                {
                    'range' : '4-5 lakhs'
                },
                {
                    'range' : '5-6 lakhs'
                }

            ]
        },

        'taxResidentCountry' : {
            'taxResidentCountryDetails' : [
                {
                    'country' : 'Canada'
                },
                {
                    'country' : 'USA'
                },
                {
                    'country' : 'Czech Republic'
                },
                {
                    'country' : 'China'
                }

            ]
        }
    }
});
RegistrationFormLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating RegistrationFormLookUp table, please contact admin...');
    } else {
        RegistrationFormLookUp.remove({}, function(err) {
            console.log('RegistrationFormLookUp collection removed');
            FormModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RegistrationFormLookUp table, please contact admin...');
                }
                console.log('RegistrationFormLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RegistrationFormLookUp;