// getBasisInvestorFinancial.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var BasisInvestorModelSchema = new mongoose.Schema({
    basisInvestorDetails: {
        type: Array,
        "default": []
    }
});

var BasisInvestorModelLookUp = mongoose.model('BasisInvestorModelLookUp', BasisInvestorModelSchema);

var BasisInvestorModel = new BasisInvestorModelLookUp({
    "basisInvestorDetails" : {
        "basisInvestorFinancialDetails": [{
                "transactionType": "Purchase",
                "source": "Webiste",
                "folioNo": 4563152,
                "accountNo": 1256789187,
                "fund": "Franklin India Prima Plus",
                "amount": 13.90,
                "reportedDate": "12 Apr 2016",
                "processedDate": "15 Apr 2016",
                "status": "Processed"
            }, {
                "transactionType": "Redemption",
                "source": "CAMS",
                "folioNo": 8761029,
                "accountNo": 80981716987,
                "fund": "Franklin India Taxshield",
                "amount": 34.90,
                "reportedDate": "19 Mar 2016",
                "processedDate": "22 Mar 2016",
                "status": "Rejected"
            }, {
                "transactionType": "Switch",
                "source": "Karvy",
                "folioNo": 1782716,
                "accountNo": 7615418276,
                "fund": "Franklin India Balanced Fund",
                "amount": 15.78,
                "reportedDate": "15 Feb 2016",
                "processedDate": "26 Feb 2016",
                "status": "Clarification"
            }, {
                "transactionType": "SWP Registration",
                "source": "Website",
                "folioNo": 1928716,
                "accountNo": 7625487191,
                "fund": "Franklin Dynamic Accrual Fund",
                "amount": 28.12,
                "reportedDate": "11 Jan 2016",
                "processedDate": "28 Jan 2016",
                "status": "Under Process"
            }],
        "basisInvestorNonFinancialDetails": [{
                "transactionType": "Change of Address",
                "reportedDate": "12 Apr 2016",
                "processedDate": "15 Apr 2016",
                "oldValue": "31, Prestige Downtown, Chennai",
                "newValue": "21, Wuthering Heights, Chennai",
                "impactedFolio": "12345678, 10987656",
                "status": "Under Process"
            }, {
                "transactionType": "Change of Name",
                "reportedDate": "19 Mar 2016",
                "processedDate": "",
                "oldValue": "Shankar",
                "newValue": "",
                "impactedFolio": "12345678, 10987656",
                "status": "Rejected"
            }, {
                "transactionType": "Change of Bank",
                "reportedDate": "15 Feb 2016",
                "processedDate": "26 Feb 2016",
                "oldValue": "HDFC Bank - SB - 123456",
                "newValue": "CITIBANK - SB - 123456",
                "impactedFolio": "201987654321",
                "status": "Processed"
            }]
    }
});

BasisInvestorModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating BasisInvestorModelLookUp table, please contact admin...');
    } else {
        BasisInvestorModelLookUp.remove({}, function(err) {
            console.log('BasisInvestorModelLookUp collection removed');
            BasisInvestorModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating BasisInvestorModelLookUp table, please contact admin...');
                }
                console.log('BasisInvestorModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = BasisInvestorModelLookUp;