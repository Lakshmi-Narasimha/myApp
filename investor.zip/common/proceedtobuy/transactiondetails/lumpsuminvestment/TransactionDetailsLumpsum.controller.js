/**
* @ngdoc property
* @name TransactionDetailsLumpsumController
* @requires $scope
* @requires fticLoggerMessage
* @requires loggerConstants
* @description
*
* - Display Transaction details for sip and lumpsum
*
**/


'use strict';
// Controller naming conventions should start with an uppercase letter
function TransactionDetailsLumpsumController($scope, $state,buildPlanModelService,buildPlanInitialLoader,fundDetailsModel) {
	console.log('TransactionDetailsSIPController');


//$scope.tileDetails = fundDetails.getFundDetails();

buildPlanInitialLoader.loadAllServices($scope); 
		$scope.SIPkeyValueList = [
		{key:"Folio. No.",value:buildPlanModelService.getInvestorSearch().folioId},  
		{key:"First Holder",value:buildPlanModelService.getInvestorSearch().custName}		     
		];

	// $scope.tileDetails = {};

	// $scope.tileDetails.fundDetailsLumpsum = fundDetailsModel.getFundDetails();

	$scope.tileDetails = {
		fundDetailsLumpsum :[
		{
			fundName: "Franklin India Bluechip Fund",
			amount : 800,
			dividend : "Re-Investment"
		},
		{
			fundName: "Franklin India Bluechip Fund",
			amount : 800,
			dividend : "Re-Investment"
		} ]

	};


	$scope.infoObj=[];
	angular.forEach($scope.tileDetails.fundDetailsLumpsum, function(obj, key){
		$scope.infoObj.push([
		{
			text: "Fund Name",
			value: $scope.tileDetails.fundDetailsLumpsum[key].fundName
		},
		{
			text: "Amount",
			value: $scope.tileDetails.fundDetailsLumpsum[key].amount
		},
		{
			text: "Dividend",
			value: $scope.tileDetails.fundDetailsLumpsum[key].dividend
		}
		]);
	});

// $scope.transactionDetails = {
// 	transactionRefNo : "FUL17077",
// 	reqDateTime : "30 April 2016, 11:08 AM",
// 	totalInvestedAmount: 1350
// };
$scope.keyValueList = [
{key:'Transaction Reference Number',value:"FUL17077"},
{key:'Request Date and Time',value:"30 April 2016, 11:08 AM"},
{key:'Total Invested Amount',value:1350}
];


$scope.continue = function(){
	$state.go('');
}

}

//TransactionDetailsController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','fundDetails'];
TransactionDetailsLumpsumController.$inject = ['$scope', '$state','buildPlanModelService','buildPlanInitialLoader','fundDetailsModel'];
module.exports = TransactionDetailsLumpsumController;