﻿/// <reference path="templates/homepage.html" />
// Filename: router.js
define([
  'jquery',
  'underscore',
  'backbone',
  'appcommon/globalcontext',
  'appmodules/nav/navsubrouter',
  'appmodules/contactprofile/cpsubrouter',
  'appmodules/accountviewer/avsubrouter',
  'appmodules/crm/crmsubrouter',
  'appmodules/hoc/hocsubrouter',
  'appmodules/eSig/esig-sub-router',
  'appmodules/coa/coa-sub-router',
  'services/dataservice',
  'appcommon/applauncher/handoff',
  'appcommon/commonutility',
  'appmodules/eSig/app/js/audit',
  'appcommon/analytics',
  'errorLog', 'spinner',
  'apipublic/navapi',
  'appcommon/constants',
  'appcommon/deeplinkcntrl',
  'appcommon/CPDataLoadModule',
  'appcommon/groupui/app/views/groupuiview'
], function ($, _, Backbone, GlobalContext, NavSubRoute, CpSubRoute, AvSubRoute, CrmSubRoute, HocSubRoute, EsigSubroute, CoaSubRoute, DataService, Handoff, Util, eSigAudit, Analytics, ErrorLog, Spinner, NavApi, Constants, DeeplinkCntrlr, CPDataModule, GroupUi) {
    var gContext = GlobalContext.getInstance(),
        mainRouteChangeTriggerRacker = {
            "invokeCPModule": false,
            "invokeCRMModule":false
        };
    var AppRouter = Backbone.Router.extend({
        routes: {
            'activity': 'showActivity',
            // Default
            'navigator/*subroute': 'invokeNavigatorModule',
            'contactprofile/*subroute': 'invokeCPModule',
            'accountviewer/*subroute': 'invokeAVModule',
            'crm/*subroute': 'invokeCRMModule',
            'ncst(/*subroute)': 'invokeNCSTModule',
            'eSig/*subroute': 'invokeEsigModule',
            'coa(/*subroute)': 'invokeCOAModule',
            'gpm(/*subroute)': 'invokeGPMModule',
            'hoc(/*subroute)': 'invokeHOCModule',
            'comp(/*subroute)': 'invokeCOMPModule',
            '*actions': 'defaultAction'
        },
    });

    var myAppRouter = new AppRouter();


    function setGlobalContext(context) {
        var _context = {
            advisorFMID: context.advisorFMID,
            isAdvisorOBO: context.isAdvisorOBO,
            contactId: context.contactId,
            contactType: context.contactType,
            contactSource: context.contactSource,
            groupId: context.groupId,
            isStandalone: context.isStandalone,
            queryString: context.queryString,
            contextId: context.contextId
        };
        gContext.setContext(_context.advisorFMID, _context.isAdvisorOBO, _context.contactId, _context.contactType,
    			_context.contactSource, _context.groupId, _context.isStandalone, _context.queryString, _context.contextId);

    }

    var initialize = function () {
        var currentview;
        var isNavLoaded = false;
        var userInEsig = false;
        var deepLinkUrl = null;
        var context = null;
        $(document).on("launchAction", launchApplication);
        $(document).on("refreshAction", refreshApplication);
        Handoff.Initialize();
        //Util.setQueryParams();
        var queryParams = Util.getQueryParams();
        function launchApplication(e) {
            var route = e.message;

            /*if(deepLinkUrl){
            	//Temporray settings until the exact deeplinking in place
            	$(".nav-mega-menu").hide();
            	$(".navbar-nav").hide();
            	$("#obo-drop-box").hide();
            	$(".desk-tab-client-name").remove();
            	$(".nav-mobile-search").remove();
            	Backbone.history.navigate(deepLinkUrl, true);
            	deepLinkUrl = null;
            	DeeplinkCntrlr.deeplinkIt(deepLinkUrl);
            }else{*/
            if (deepLinkUrl) {
                if (deepLinkUrl.indexOf("accountviewer") !== -1) {
                    new GroupUi({ el: $('#sharedgrpdiv') }).render(loadDeeplinkurl);
                } else {
                    loadDeeplinkurl();
                }
                function loadDeeplinkurl(isGroupCallSuccess) {
                    
                    if (GlobalContext.getInstance().getGlobalContext().Context.ContactType == Constants.contactType.NonClient) {                        
                        Backbone.history.navigate(deepLinkUrl, true);
                        deepLinkUrl = null;                        
                    }
                    else {
                        CPDataModule.getCPData(function () {
                            Backbone.history.navigate(deepLinkUrl, true);
                            deepLinkUrl = null;
                        }, function () {
                            //alert("error occured");
                        });
                    }
                }

            } else if (route) {
                Backbone.history.navigate(route, true);
            }
            //}

        };

        function refreshApplication(e) {
            if (deepLinkUrl) {
                DeeplinkCntrlr.deeplinkIt(deepLinkUrl);
                //deepLinkUrl = null;
            }
            else {
                var _route = e.message;
                if (_route.indexOf("accountviewer/") > -1) {
                    if (_route == "accountviewer/") {
                        Backbone.history.loadUrl(Backbone.history.fragment);
                    } else {
                        $.event.trigger({
                            type: "GroupChangedInAccountsSubTab",
                            message: _route,
                            time: new Date(),
                        });
                        $.event.trigger({
                            type: "GroupChangedEvent",
                            message: _route,
                            time: new Date(),
                        });
                        
                    }
                } else {
                    Backbone.history.loadUrl(Backbone.history.fragment);
                }
            }
        };

        function isClientSelected() {
            if (!GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                Backbone.history.navigate('crm/', true);
                return false;
            } else {
                return true;
            }
        }
        function isAdviserSelected(that, params) {
            params = params || {};
            if (!GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID) {
                var currentHash = location.hash;
                if (isNavLoaded == false) {
                    if (!that.routes.navSubroute) {
                        //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc.. 
                        that.routes.navSubroute = new NavSubRoute.navRouter("navigator/", params);
                    }
                    Backbone.history.navigate('navigator/', true);
                    isNavLoaded = true;
                }
                Backbone.history.navigate(currentHash, true);
                return false;
            } else {
                isNavLoaded = true;
                return true;
            }
        }
        function isMobileDevice() {
            var nVer = navigator.appVersion;
            var mobile = false;
            mobile = ($(document).width() <= 767) ? true : false;
            return mobile;
        }

        function initializeNavAndGotoCRM(that) {
            if (isNavLoaded == false) {
                if (!that.routes.navSubroute) {
                    //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc.. 
                    that.routes.navSubroute = new NavSubRoute.navRouter("navigator/", context);
                    that.routes.navSubroute.on('route', function (route, params) {
                        Analytics.analytics.processNavSubRouteChangeEvent(route, params);
                    });
                }

                DeeplinkCntrlr.deeplinkIt(deepLinkUrl);
                deepLinkUrl = null;
                //Backbone.history.navigate('navigator/', true); 
                isNavLoaded = true;
            }
            if (!deepLinkUrl) {
                var _isNonCmUser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
                if (_isNonCmUser) {
                    Backbone.history.navigate('navigator/contactlist', true);
                }
                else {
                    Backbone.history.navigate('crm/', true);
                }
            }
        }
        function setLoggingConfiguration(route, params) {

            ErrorLog.ErrorUtils.configLogging(Util.getUrlParams());
        };

        function toggleNavHeader(flag) {
            if (flag) {
                $('#afinav-navbar').hide();
            } else {
                $('#afinav-navbar').show();
            }
        }
        function deepLinkingHandler(urlParams, finalLandingUrl) {
            /*Spinner.show();
    		DataService.getContactDetailsbyContactId(Util.readCookie('FMID'),urlParams['ContactID'])
    		.then(function(response){
    			var _contactId = null,_contactType = null;
    			if(response[0] && response[0].get('clientId')){
    				_contactId = response[0].get('clientId');
    				_contactType = Constants.contactType.Client;
    			}else{
    				_contactId = urlParams['ContactID'];
    				_contactType = Constants.contactType.NonClient;
    			}
    			var _queryString = queryParams;
        		var _context = {
        				advisorFMID:Util.readCookie('FMID'),
        				contactType:_contactType,
        				queryString:_queryString,
        				contactId:_contactId
        		};
        		deepLinkUrl = finalLandingUrl;
        		window.location.hash = "";
        		context = _context;
    			Spinner.hide();
    		})
    		.fail(function(error){
    			Spinner.hide();
    		});*/

            var _context = {
                advisorFMID: Util.readCookie('FMID'),
                queryString: queryParams,
                isStandalone: false,
                contextId: urlParams['ContextId'] ? urlParams['ContextId'] : ""
            };
            deepLinkUrl = finalLandingUrl;
            //Backbone.history.navigate('navigator/', true); 
            window.location.hash = "#navigator/"
            setGlobalContext(_context);
        }
        //var app_router = new AppRouter;  

        //If coming from ClientViewer, set the cookie to be used to show popup to user.
        if (!Util.isEmpty(queryParams) && (queryParams.indexOf("srcSystem=CV") !== -1)) {
            var expiry = new Date();
            expiry.setTime(expiry.getTime() + (3650 * 1 * 24 * 60 * 60 * 1000));
            if (Util.readCookie('firstLaunch') != null) {
                Util.writeCookie("firstLaunch", "False", { expires: expiry.toUTCString() });
            }
            else {                               
                Util.writeCookie("firstLaunch", "True", { expires: expiry.toUTCString() });
            } 
        }
        var nonCMuserFirstLaunch;
        if (nonCMuserFirstLaunch == undefined) {
            Util.writeCookie("nonCMuserFirstLaunch", true);
        }
        app_router = myAppRouter;

        app_router.on('route:showActivity', function () {
            alert('root level route');
        });
        app_router.on('route:defaultAction', function (actions) {
            initializeNavAndGotoCRM(this);
        });

        app_router.on('route', function (route, params) {
            if (route == "invokeCPModule") {
                if (!mainRouteChangeTriggerRacker["invokeCPModule"]) {
                    mainRouteChangeTriggerRacker["invokeCPModule"] = true;
                } else {
                    return;
                }
            } else if (route == "invokeCRMModule") {
                if (!mainRouteChangeTriggerRacker["invokeCRMModule"]) {
                    mainRouteChangeTriggerRacker["invokeCRMModule"] = true;
                } else {
                    return;
                }
            }
            setLoggingConfiguration(route, params);
            Analytics.analytics.processAppRouterRouteChangeEvent(route, params);
        })

        app_router.on('route:invokeNavigatorModule', function (subroute) {
            if (!this.routes.navSubroute && isAdviserSelected(this)) {
                //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..                
                this.routes.navSubroute = new NavSubRoute.navRouter("navigator/");
                this.routes.navSubroute.on('route', function (route, params) {
                    setLoggingConfiguration(route, params);
                    Analytics.analytics.processNavSubRouteChangeEvent(route, subroute);
                });
            } else {
                if (subroute != "contactlist") {
                    initializeNavAndGotoCRM(this);
                }
            }
        });
        app_router.on('route:invokeCPModule', function (subroute) {
            subroute = subroute == null ? "" : subroute;
            var _self = this;
            var _urlParams = Util.getUrlParams();
            if (_urlParams['mode'] == "nav" && !GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                deepLinkingHandler(_urlParams, "#contactprofile/" + subroute);
            } else {
                if (!_self.routes.cpSubroute && isClientSelected()) {
                    //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                    _self.routes.cpSubroute = new CpSubRoute.cpRouter("contactprofile/");
                    _self.routes.cpSubroute.on('route', function (route, params) {
                        setLoggingConfiguration(route, params);
                        Analytics.analytics.processCpSubRouteChangeEvent(route, subroute, params);
                    });
                } else {
                    initializeNavAndGotoCRM(this);
                }
            }

        });
        app_router.on('route:invokeAVModule', function (subroute) {
            var _self = this;
            var _urlParams = Util.getUrlParams();
            if (_urlParams['mode'] == "nav" && !GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                deepLinkingHandler(_urlParams, "#accountviewer/");
            } else {
                if (!this.routes.AvSubRoute && isClientSelected()) {
                    //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                    // add the event for the first time into the account viewer
                    Analytics.analytics.processAvSubRouteChangeEvent('defaultAction');
                    this.routes.AvSubRoute = new AvSubRoute.avRouter("accountviewer/");
                    this.routes.AvSubRoute.on('route', function (route, params) {
                        setLoggingConfiguration(route, params);
                        Analytics.analytics.processAvSubRouteChangeEvent(route, subroute);
                    });
                } else {
                    initializeNavAndGotoCRM(this);
                }
            }
        });
        app_router.on('route:invokeCRMModule', function (subroute) {
            if (!this.routes.CrmSubRoute && isAdviserSelected(this)) {
                //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                var _isNonCmUser = GlobalContext.getInstance().getGlobalContext().Context.IsNonCMuser;
                if (_isNonCmUser) {
                    Backbone.history.navigate('navigator/contactlist', true);
                    return;
                }
                this.routes.CrmSubRoute = new CrmSubRoute.crmRouter("crm/");
                this.routes.CrmSubRoute.on('route', function (route, params) {
                    // console.log("Different crm subrouter page: " +  route + " and subroute: " + subroute);
                    setLoggingConfiguration(route, params);
                    Analytics.analytics.processCrmSubRouteChangeEvent(route, subroute);
                });
            }
        });

        app_router.on('route:invokeNCSTModule', function (subroute) {
            var _urlParams = Util.getUrlParams();
            var _self = this;
            Spinner.show();
            if (!_self.routes.ncstSubroute && !isNavLoaded && _urlParams['mode'] != "standalone") {
                location.hash = "crm";
                initializeNavAndGotoCRM(_self);
                return;
            }
            require(['appmodules/ncst/ncst-sub-router'], function (NcstSubRoute) {
                //Spinner.hide();
                if (_urlParams['mode'] == "standalone") {
                    toggleNavHeader(true);
                    $('body').addClass('standalone');
                    var _queryString = queryParams;
                    var _context = {
                        isStandalone: true,
                        advisorFMID: Util.readCookie('FMID'),
                        queryString: _queryString,
                        contactId: _urlParams['ProspectID']
                    };

                    setGlobalContext(_context);
                    if (!_self.routes.ncstSubroute) {
                        Backbone.history.navigate("ncst/" + _queryString, true);
                        //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                        _self.routes.ncstSubroute = new NcstSubRoute.ncstRouter('ncst/');
                        //NcstSubRoute.initialiseRouter(_self.routes.ncstSubroute);
                        _self.routes.ncstSubroute.on('route', function (route, params) {
                            setLoggingConfiguration(route, params);
                            Analytics.analytics.processNcstSubRouteChangeEvent(route, subroute);
                        });
                    }
                } else {
                    if (!_self.routes.ncstSubroute && isNavLoaded) {
                        //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                        _self.routes.ncstSubroute = new NcstSubRoute.ncstRouter('ncst/');
                        //NcstSubRoute.initialiseRouter(_self.routes.ncstSubroute);
                        _self.routes.ncstSubroute.on('route', function (route, params) {
                            setLoggingConfiguration(route, params);
                            Analytics.analytics.processNcstSubRouteChangeEvent(route, subroute);
                        });
                    } else {
                        location.hash = "crm";
                        initializeNavAndGotoCRM(_self);
                    }
                }
            });



        });

        app_router.on('route:invokeEsigModule', function (subroute) {
            if (!this.routes.EsigSubroute && isClientSelected()) {
                if (!this.routes.EsigSubroute) {
                    this.routes.EsigSubroute = new EsigSubroute.eSigRouter('eSig/');
                    this.routes.EsigSubroute.on('route', function (route, params) {
                        setLoggingConfiguration(route, params);
                        Analytics.analytics.processEsigSubRouteChangeEvent(route, subroute);
                    });
                }
            } else {
                initializeNavAndGotoCRM(this);
            }
        });

        app_router.on('route:invokeCOAModule', function (subroute) {
            var _urlParams = Util.getUrlParams();
            if (_urlParams['mode'] == "standalone") {
                toggleNavHeader(true);
                $('body').addClass('standalone');
                var _queryString = queryParams;
                var _context = {
                    isStandalone: true,
                    advisorFMID: Util.readCookie('FMID'),
                    queryString: _queryString,
                    contextId: _urlParams['ContextId'] ? _urlParams['ContextId'] : _urlParams['contextid']
                };

                setGlobalContext(_context);
                if (!this.routes.coaSubroute) {
                    if (subroute != null) {
                        Backbone.history.navigate("coa/" + _queryString, true);
                    }
                    //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                    this.routes.coaSubroute = new CoaSubRoute.coaRouter('coa/');
                    this.routes.coaSubroute.on('route', function (route, params) {
                        setLoggingConfiguration(route, params);
                        Analytics.analytics.processCoaSubRouteChangeEvent(route, subroute);
                    });
                }
            } else {
                if (!this.routes.coaSubroute && isClientSelected()) {
                    this.routes.coaSubroute = new CoaSubRoute.coaRouter('coa/');
                    this.routes.coaSubroute.on('route', function (route, params) {
                        setLoggingConfiguration(route, params);
                        Analytics.analytics.processCoaSubRouteChangeEvent(route, subroute);
                    });
                } else {
                    initializeNavAndGotoCRM(this);
                }
            }

        });
        app_router.on('route:invokeGPMModule', function (subroute) {
            var _urlParams = Util.getUrlParams();
            var _self = this;
            Spinner.show();
            //if(!_self.routes.gpmSubroute && !isNavLoaded && _urlParams['mode'] != "standalone"){
            //	location.hash ="crm";
            //	initializeNavAndGotoCRM(_self);
            //	return;
            //}
            require(['appmodules/gpm/gpmsubrouter'], function (GPMSubRoute) {
                //Spinner.hide();
                if (_urlParams['mode'] == "nav" && !GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                    deepLinkingHandler(_urlParams, "#gpm/" + subroute);
                } else if (!_self.routes.gpmSubroute && isClientSelected()) {
                    //Sub route call to activate the subapplication like navigator,contact profile,account viewer etc..
                    _self.routes.gpmSubroute = new GPMSubRoute.gpmRouter('gpm/');
                    //NcstSubRoute.initialiseRouter(_self.routes.ncstSubroute);
                    _self.routes.gpmSubroute.on('route', function (route, params) {
                        setLoggingConfiguration(route, params);
                    });
                } else {
                    location.hash = "crm";
                    initializeNavAndGotoCRM(_self);
                }
            });
        });

        /* HOC */
        app_router.on('route:invokeHOCModule', function (subroute) {

            var _self = this;
            var _urlParams = Util.getUrlParams();
            if (_urlParams['mode'] == "nav" && !GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                deepLinkingHandler(_urlParams, "#hoc/" + subroute);
            } else if (!this.routes.HocSubRoute && isClientSelected()) {
                this.routes.HocSubRoute = new HocSubRoute.hocRouter("hoc/");
                this.routes.HocSubRoute.on('route', function (route, params) {
                    setLoggingConfiguration(route, params);
                    //Analytics.analytics.processHOCSubRouteChangeEvent(route, subroute);
                });
            } else {
                initializeNavAndGotoCRM(this);
            }
        });
        /* HOC Close */ 

        /* COMPONENTS */
        app_router.on('route:invokeCOMPModule', function (subroute) {
            require(['components/compsubrouter'], function (CompSubRoute) {
                new CompSubRoute.compRouter('comp/', { createTrailingSlashRoutes: true });
            });
        });
        /* COMPONENTS Close */

        //Common function for catching all hash changes
        Backbone.history.on("all", function (route, router) {
            //Create list of previous loaded routes
            (typeof Backbone.history.list === 'undefined') ? Backbone.history.list = [] : "";
            Backbone.history.list.push(Backbone.history.fragment);
            (Backbone.history.list.length > 10) ? Backbone.history.list.splice(Backbone.history.list, 0) : "";
            //Hide footer for eSig sign page
            if (location.hash.indexOf("sign-document-view") > -1) {
                //$(".practicetech-footer").hide();
                if (!isMobileDevice()) {
                    $("meta[name='viewport']").attr("content", "width=device-width, initial-scale=1.0, maximum-scale=1.0");
                }
            } else {
                $(".practicetech-footer").show();
                $("meta[name='viewport']").attr("content", "width=device-width, initial-scale=1.0, maximum-scale=1.0");
            }

            //Triggering Audit for esig when user navigating away from esig
            if (location.hash.indexOf("eSig") > -1) {
                userInEsig = true;
            }
            else {
                if (userInEsig) {
                    eSigAudit.logBrowserClose(true, true);
                    userInEsig = false;
                }
            }

            //Triggering Audit for esig when user navigating away from esig
            if (location.hash.indexOf("gpm") > -1 && !(/gpm\/confirm/i.test(location.hash)) && !(/gpm\/update/i.test(location.hash))) {
                $('#transparent-nav').show();
            } else {
                $('#transparent-nav').hide();
            }

            //Loading practice-tech footer
            NavApi.renderPTFooter(true);
        });
        Backbone.history.start();
    };
    return { initialize: initialize, appRouter: myAppRouter };
});
