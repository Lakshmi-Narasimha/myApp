/**
 * @ngdoc service
 * @name invPanFolioKycModel service
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * -  
 *
 */

'use strict';

var invPanFolioKycModel = function (Restangular, $q, authenticationService, investorConstants, loggerConstants, fticLoggerMessage) {
    
    var _panFolioKycSummary = null;
    var params;
    var invPanFolioKycModel = {

        getPanFolioKycDetails: function(paramsObj) {
            // var message =  loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_EFORMS_MODULE + ' | ' + loggerConstants.INV_COMMON_FOLIO_DETAILS_MODEL + ' | getFolioAccountDetails' /* Function Name */;
            // fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var deferred = $q.defer();
            params = paramsObj || {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one(investorConstants.myprofile.INV_PAN_FOLIO_KYC_URL).get(params).then(function(response) {
                deferred.resolve(response);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setPanFolioKycData: function(data) {
            _panFolioKycSummary = data.panFolioKyc;
        },
        getPanFolioKycData: function() {
            return _panFolioKycSummary;
        }
    };
    return invPanFolioKycModel;
};

invPanFolioKycModel.$inject = ['Restangular', '$q', 'authenticationService', 'investorConstants', 'loggerConstants', 'fticLoggerMessage'];

module.exports = invPanFolioKycModel;
