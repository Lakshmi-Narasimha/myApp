define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appcommon/commonutility',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailpositionsview.html'
], function ($, _, Backbone, dataService, Utils, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView= AccountDetailSectionView.extend({
        events: { 
          'click [pt-position-expander-button]': 'handleExpandCollapseDetails',
        },
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetBrokeragePositions(this.accountSummary.accountId)
                .then(function(holdingsSummary) {
                  var holdings = _.map(holdingsSummary.holdingSummaries.results, function(holdingSummary) {
                    var holding = {};
                    holding.description = holdingSummary.secrShrtDesc;
                    holding.marketValue = self.formatMoney(holdingSummary.trdDtMktVal);
                    holding.symbol = holdingSummary.symbol;
                    holding.quantity = holdingSummary.trdDtQty;
                    holding.price = self.formatMoney(holdingSummary.mktPrc);
                    holding.priceDate = Utils.isEmpty(holding.price) || Utils.isEmpty(holdingSummary.mktPrcDt) ? '&ndash;' : self.viewFormatDateMMddYYYY(holdingSummary.mktPrcDt);
                    holding.hldCatgCd = holdingSummary.hldCatgCd;
                    return holding;
                  });
                  holdings = _.filter(holdings, function (row) { return (row.hldCatgCd != "002") });
                  self.renderSection(SectionTemplateHtml, {holdings: holdings});
                })
                .fail(this.handleServiceError);
        },
        handleExpandCollapseDetails: function (e) {      
          var $position = $(e.target).closest('[pt-position]');
          var $positionDetail = $position.find('[pt-position-detail]');
          var isCollapsed = $positionDetail.css('display') == 'none';
          this.toggleExpandCollapseIcon($position.find('[pt-position-expander-button]'), !isCollapsed);
          if (isCollapsed) {
            $positionDetail.slideDown();
          } else {
            $positionDetail.slideUp();
          }
        },
        toggleExpandCollapseIcon: function($expandCollapse, shouldBeCollapsed) {
          $expandCollapse.toggleClass("icon-plus", shouldBeCollapsed);
          $expandCollapse.toggleClass("icon-minus", !shouldBeCollapsed);
        },
    });

    return SectionView;
});
