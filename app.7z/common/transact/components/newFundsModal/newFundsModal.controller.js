/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function newFundModalController($scope, $uibModalStack, transactEventConstants, newFundDetailsModel, eventConstants) {

	$scope.sectionOptions = [];
    var keys = [];
    var fundDtls = newFundDetailsModel.getFundDetails();

    for(var k in fundDtls){ keys.push(k);}

    for(var i in keys){
        if(keys[i] === 'allFunds'){
            $scope.sectionOptions.push({title : 'All Funds', value : keys[i].toString()});
        }else{
            $scope.sectionOptions.push({title : keys[i].toString().toLowerCase(), value : keys[i].toString()});
        }
    }

    setOptions(fundDtls.allFunds);

    function setOptions(funds){

    	$scope.singleSelectOptions = []
	    angular.forEach(funds,function(lbl,key){

	    	var obj = {};
	    	obj = lbl;
	    	if(lbl.nfoFlag == 'Y'){
			obj.fundName = lbl.fundOptDesc + " - NFO";
	    	}else{
	    		obj.fundName = lbl.fundOptDesc;
	    	}
	    	
	    	if($scope.selectedFund && $scope.selectedFund.fundName == lbl.fundOptDesc ){

	    		obj.selected = true;	
	    	}else{
	    		obj.selected = false	
	    	}
	    	
	    	$scope.singleSelectOptions.push(obj)
	    })
    }

    $scope.$on('fundChanged',function(event,selectedObj){
    	setOptions(fundDtls[selectedObj.value]);
    });    
    

    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
    $scope.$on('singleSelectionDone',function(event,obj){
        $scope.destinationFund = obj.selectedOne; 
        $scope.$emit(transactEventConstants.transact.FUND_UPDATED); 
        $scope.selectedFund = obj.selectedOne;
        $uibModalStack.dismissAll();
    });

    $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function(event, data){
    	var searchArray = [];
    	for(var i in fundDtls.allFunds){
            if(fundDtls.allFunds[i].fundOptDesc.toString().toUpperCase().search(data.searchText.toString().toUpperCase()) != -1){
            	searchArray.push(fundDtls.allFunds[i])
            }
        }
        setOptions(searchArray);
    });

    $scope.$on("fundBasicFilter", function (event, data) {
        $scope.$broadcast("fundFilter", {"filterText": data.filterText});
    })
}


newFundModalController.$inject = ['$scope', '$uibModalStack', 'transactEventConstants', 'newFundDetailsModel', 'eventConstants'];

module.exports = newFundModalController;