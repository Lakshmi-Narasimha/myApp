/**
 * @ngdoc property
 * @name FundDetailsController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display fund details for sip and lumpsum
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function FundDetailsController($scope, $state, fticLoggerMessage, loggerConstants, transactModel, buildPlanInitialLoader, buildPlanModelService, transactEventConstants, planSmartSolution, $filter, eventConstants) {

    if (transactModel.getInvestorDetails()) {
        $scope.SIPholderInfoArray = [
            {key: "First Holder", value: transactModel.getInvestorDetails().custName},
            {
                key: "Second Holder",
                value: (transactModel.getInvestorDetails().holders.length > 1) ? transactModel.getInvestorDetails().holders[1].name : "NA"
            },
            {
                key: "Third Holder",
                value: (transactModel.getInvestorDetails().holders.length > 2) ? transactModel.getInvestorDetails().holders[2].name : "NA"
            },
            {key: "Folio. No.", value: transactModel.getInvestorDetails().folioId},
            {key: "Mode of Holding", value: transactModel.getInvestorDetails().holdingType}
        ];
    }
    $scope.showInTransactNow = true;
    $scope.isFromPaperLess = transactModel.isPaperLess;
    if ($state.current.name == "transactnow.baseNow.smartSolTransact") {
        $scope.showInTransactNow = false;
        $scope.showContinue = true;
        $scope.showBack = true;
    } else {
        $scope.showContinue = false;
        $scope.showBack = false;
    }

    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;
    $scope.sipInvestment = {};

    if (planSmartSolution.getTransactType() === "Lumpsum") {
        $scope.showLumpsum = true;
    }
    else if (planSmartSolution.getTransactType() === "SIP") {
        $scope.showSip = true;
    }
    else if (planSmartSolution.getTransactType() === "Combo") {
        $scope.showBoth = true;
    }

    // $state.go($scope.fundDtls.fundDtlsState);
    $state.go(planSmartSolution.getFundDetailsState());
    if ($state.current.name === "smartSol.planSmartSolution.fundDetailsSS") {
        $scope.showContinue = true;
        $scope.showBack = true;
    }

    $scope.fdCntnuBtn = function () {
        if($scope.showSip || $scope.showBoth) {
            addFutureInstallment();
        }
        if ($state.current.name == "transactnow.baseNow.smartSolTransact.investment") {
            $scope.$emit(transactEventConstants.transact.Show_Fund);
            $scope.$emit("paymntDtls");
        } else {
            $scope.paymentDtls.paymentDtlsState = "smartSol.planSmartSolution.paymentdetailsSS.investment";
            $state.go("smartSol.planSmartSolution.paymentdetailsSS");
        }
    };

    $scope.fdBackBtn = function () {
        $state.go("smartSol.planSmartSolution.ssBase.goalSheetSummary");
    };

    function addFutureInstallment () {
        var sipFunds = [],
            datefilter = $filter('date'),
            //futureInst = ,
            middleDate = datefilter(new Date($scope.sipInvestment.futureInstallmentMonth), 'MM')+'/'+$scope.sipInvestment.defaultDaySelected.title+'/'+datefilter(new Date($scope.sipInvestment.futureInstallmentMonth), 'yyyy'),
            futureDate = datefilter(new Date(middleDate), "dd/MM/yyyy");
        angular.forEach(planSmartSolution.getSIPFunds(), function (obj, ind) {
           var fundsParams = {};
            fundsParams = obj;
            fundsParams.firstInstallment = datefilter(new Date(), 'dd/MM/yyyy');
            fundsParams.futureDate = futureDate;
            sipFunds.push(fundsParams);
        });

        planSmartSolution.setSIPFunds(sipFunds)
    }
    $scope.$on(eventConstants.PAPERLESS_CONTINUE_CLICKED, function(){
            $scope.$emit(eventConstants.PAPERLESS_VALIDATED);

    });

}

FundDetailsController.$inject = ['$scope', '$state', 'fticLoggerMessage', 'loggerConstants', 'transactModel', 'buildPlanInitialLoader', 'buildPlanModelService', 'transactEventConstants', 'planSmartSolution', '$filter', 'eventConstants'];

module.exports = FundDetailsController;