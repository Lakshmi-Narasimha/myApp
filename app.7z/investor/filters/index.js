/**
*@ngdoc object
*@name investor.module:filters
*@description
* <p>
* In this we have the all common filters used by investor
* </p> 
*/

module.exports = angular.module('investor.filters', [])
    .filter('fticInvStringToNumber', require('./fticInvStringToNumber.filter'))
    ;