
var searchModelConfig = {
response: {
    "ResponseInfo": {
        "locale": "EN",
        "type": "Success",
        "server": "twswcmvmzad03.tdc.vzwcorp.com:srv03_nmobilefirst01",
        "buildNumber": "9063",
        "requestId": "d4133d6a-047e-4b54-9e74-322cd6325034",
        "mdn": "2566105456",
        "code": "00000",
        "message": "0",
        "userMessage": "0"
    },
    "Page": {
        "pageType": "search",
        "parentPageType": "myData",
        "pageStatNames": [
            "/mf/support/suggested/term/search"
        ]
    },
    "ModuleMap": {
        "Support": {
            "ResponseInfo": {
                "locale": "EN",
                "type": "Success",
                "code": "00000",
                "message": "0",
                "userMessage": "0"
            },
            "msgList": [
                {
                    "type": "content",
                    "msgId": 18981,
                    "messageList": [
                        {
                            "content": "You’ve got a few options. Which one would you like to do?",
                            "nextmsgId": -1,
                            "animationDuration": 800,
                            "childType": "contentTitle",
                            "dTreeTrackingValue": {
                                "vzwi.mvmapp.dTreeEngagement": "d.T1.Q6.You’ve got a few options. Which one would you like to do?",
                                "vzwi.mvmapp.escalationLevel": "1",
                                "vzwi.mvmapp.escalationTriggered": "1",
                                "vzwi.mvmapp.dTreePosition": "T1.Q6",
                                "vzwi.mvmapp.dTreeResponse": "You’ve got a few options. Which one would you like to do?"
                            }
                        },
                        {
                            "content": "Chat with us right here",
                            "nextmsgId": 19032,
                            "animationDuration": 800,
                            "childType": "contentOption",
                            "dTreeTrackingValue": {
                                "vzwi.mvmapp.dTreeEngagement": "d.T1.Q6.Chat with us right here",
                                "vzwi.mvmapp.escalationLevel": "1",
                                "vzwi.mvmapp.escalationTriggered": "1",
                                "vzwi.mvmapp.dTreePosition": "T1.Q6",
                                "vzwi.mvmapp.dTreeResponse": "Chat with us right here"
                            },
                            "edwTagName": "#MF_SUPPORT_DTREE_T1_Q6_MENU_SELECT",
                            "ButtonMap": {
                                "FeedLink": {
                                    "presentationStyle": "push",
                                    "tryToReplaceFirst": false,
                                    "disableAction": false,
                                    "analyticsKey": "2017-03-01 22:54:27:5427_77949",
                                    "resultType": "dTree",
                                    "selected": false,
                                    "pageType": "search",
                                    "appContext": "mobileFirstSS",
                                    "actionType": "openPage",
                                    "isSelected": false,
                                    "extraParameters": {
                                        "searchTerm": "Chat with us right here"
                                    }
                                }
                            }
                        },
                        {
                            "content": "Tweet us",
                            "nextmsgId": 19033,
                            "animationDuration": 800,
                            "childType": "contentOption",
                            "dTreeTrackingValue": {
                                "vzwi.mvmapp.dTreeEngagement": "d.T1.Q6.Tweet us",
                                "vzwi.mvmapp.escalationLevel": "1",
                                "vzwi.mvmapp.escalationTriggered": "1",
                                "vzwi.mvmapp.dTreePosition": "T1.Q6",
                                "vzwi.mvmapp.dTreeResponse": "Tweet us"
                            },
                            "edwTagName": "#MF_SUPPORT_DTREE_T1_Q6_MENU_SELECT",
                            "ButtonMap": {
                                "FeedLink": {
                                    "presentationStyle": "push",
                                    "tryToReplaceFirst": false,
                                    "disableAction": false,
                                    "analyticsKey": "2017-03-01 22:54:27:5427_77949",
                                    "resultType": "dTree",
                                    "selected": false,
                                    "pageType": "search",
                                    "appContext": "mobileFirstSS",
                                    "actionType": "openPage",
                                    "isSelected": false,
                                    "extraParameters": {
                                        "searchTerm": "Tweet us"
                                    }
                                }
                            }
                        },
                        {
                            "content": "Post on our Facebook page",
                            "nextmsgId": 19034,
                            "animationDuration": 800,
                            "childType": "contentOption",
                            "dTreeTrackingValue": {
                                "vzwi.mvmapp.dTreeEngagement": "d.T1.Q6.Post on our Facebook page",
                                "vzwi.mvmapp.escalationLevel": "1",
                                "vzwi.mvmapp.escalationTriggered": "1",
                                "vzwi.mvmapp.dTreePosition": "T1.Q6",
                                "vzwi.mvmapp.dTreeResponse": "Post on our Facebook page"
                            },
                            "edwTagName": "#MF_SUPPORT_DTREE_T1_Q6_MENU_SELECT",
                            "ButtonMap": {
                                "FeedLink": {
                                    "presentationStyle": "push",
                                    "tryToReplaceFirst": false,
                                    "disableAction": false,
                                    "analyticsKey": "2017-03-01 22:54:27:5427_77949",
                                    "resultType": "dTree",
                                    "selected": false,
                                    "pageType": "search",
                                    "appContext": "mobileFirstSS",
                                    "actionType": "openPage",
                                    "isSelected": false,
                                    "extraParameters": {
                                        "searchTerm": "Post on our Facebook page"
                                    }
                                }
                            }
                        },
                        {
                            "content": "Call customer support",
                            "nextmsgId": 19035,
                            "animationDuration": 800,
                            "childType": "contentOption",
                            "dTreeTrackingValue": {
                                "vzwi.mvmapp.dTreeEngagement": "d.T1.Q6.Call customer support",
                                "vzwi.mvmapp.escalationLevel": "1",
                                "vzwi.mvmapp.escalationTriggered": "1",
                                "vzwi.mvmapp.dTreePosition": "T1.Q6",
                                "vzwi.mvmapp.dTreeResponse": "Call customer support"
                            },
                            "edwTagName": "#MF_SUPPORT_DTREE_T1_Q6_MENU_SELECT",
                            "ButtonMap": {
                                "FeedLink": {
                                    "presentationStyle": "push",
                                    "tryToReplaceFirst": false,
                                   "disableAction": false,
                                    "analyticsKey": "2017-03-01 22:54:27:5427_77949",
                                    "resultType": "dTree",
                                    "selected": false,
                                    "pageType": "search",
                                    "appContext": "mobileFirstSS",
                                    "actionType": "openPage",
                                    "isSelected": false,
                                    "extraParameters": {
                                        "searchTerm": "Call customer support"
                                    }
                                }
                            }
                        }
                    ],
                    "waitingViewDuration": 3000,
                    "feedCard": false
                },
                {
                    "type": "userMessage",
                    "msgId": 19032,
                    "messageList": [
                        {
                            "content": "Chat with us right here",
                            "nextmsgId": -1,
                            "animationDuration": 0
                        }
                    ],
                    "feedCard": false
                },
                {
                    "type": "userMessage",
                    "msgId": 19033,
                    "messageList": [
                        {
                            "content": "Tweet us",
                            "nextmsgId": -1,
                            "animationDuration": 0
                        }
                    ],
                    "feedCard": false
                },
                {
                    "type": "userMessage",
                    "msgId": 19034,
                    "messageList": [
                        {
                            "content": "Post on our Facebook page",
                            "nextmsgId": -1,
                           "animationDuration": 0
                        }
                    ],
                    "feedCard": false
                },
                {
                    "type": "userMessage",
                    "msgId": 19035,
                    "messageList": [
                        {
                            "content": "Call customer support",
                            "nextmsgId": -1,
                            "animationDuration": 0
                        }
                    ],
                    "feedCard": false
                }
            ],
            "topLevelIntent": "CSR",
            "searchTerm": "contacting verizon",
            "startMsgId": 18981,
            "searchSource": "API_AI",
            "inConversationalFlow": true,
            "secondLevelIntent": "dtree.contacting_verizon",
            "searchStartIndex": 0
        }
    }
}
};

module.exports = searchModelConfig;
