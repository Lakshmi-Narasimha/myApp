/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details SIP controller for Advisor module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function fundDtlsSipCtrl($scope, $state, buildPlanModelService, planSmartSolution, $filter) {
    $scope.fundDetails = buildPlanModelService.getGoalPlanData();
    $scope.sipFundDetails = [];
    console.log(planSmartSolution.getSmartSolutionDetails());
    var startDate = null, endDate = null;
    startDate = $filter('date')(new Date(), 'd MMM yyyy');
    var endDateFormat = parseInt($filter('date')(new Date(), 'yyyy')) + parseInt(planSmartSolution.getSmartSolutionDetails().investmentTenure);
    endDate = $filter('date')(new Date(), 'd MMM') +' ' + endDateFormat;
    console.log(endDate);
    angular.forEach($scope.fundDetails, function (obj) {
        obj.sipstartdate = startDate;
        obj.sipenddate = endDate;
        if(buildPlanModelService.getInvestmentType() == "Monthly" || buildPlanModelService.getInvestmentType() == "Combo") {
            var gridRow = {};
            gridRow = planSmartSolution.returnMonthlyorAnnually("Monthly", obj, gridRow);
            $scope.sipFundDetails.push(gridRow);
        }
        if(buildPlanModelService.getInvestmentType() == "Annually" || buildPlanModelService.getInvestmentType() == "Combo") {
            var gridRow1 = {};
            gridRow1 = planSmartSolution.returnMonthlyorAnnually("Annually", obj, gridRow1);
            $scope.sipFundDetails.push(gridRow1);
        }
    });

    planSmartSolution.setSIPFunds($scope.sipFundDetails);
    $scope.sipColumnDefs = [
        {field: 'investInto', displayName: 'Invest Into', width: '200', pinnedLeft: true},
        {field: 'sipAmt',displayName: 'SIP Amount',width: '120',headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',cellClass: 'text-right'},
        {field: 'sipstartdate', displayName: 'SIP Start Date', width: '130'},
        {field: 'sipenddate', displayName: 'SIP End Date', width: '120'},
        {field: 'frequency', displayName: 'Frequency', width: '120'},
        {field: 'stepUpSip', displayName: 'Step Up SIP', width: '120'}
    ];


    //Future Installment Day option settings for section filter
    $scope.today = new Date();
    $scope.day = $scope.today.getDate();
    $scope.mm = $scope.today.getMonth()+1;
    $scope.days = [];
    $scope.endDateOptions = {
        yearRows: 3,
        yearColumns: 4,
        datepickerMode: 'day',
        minMode: 'day',
        fulldatepickerMode:'year',
        formatMonth: 'MMM',
        formatYear: 'yyyy',
        formatDayTitle: 'MMM yyyy',
        monthColumns: 4,
        showWeeks: false,
        minDate:new Date()
    };

    var currentmonth = new Date($scope.today.getFullYear(), $scope.today.getMonth() + 1, 0);
    var currentMonthArray = currentmonth.toString().split(" ");
    $scope.max = currentMonthArray[2];
    for(var i=$scope.day+1;i<=$scope.max;i++){
        $scope.days.push(i);
    }
    $scope.sipInvestment.futureInstallmentMonth = $scope.today;
    $scope.futureInstallmentDateChange = function(){
        var selectedmonth = $scope.sipInvestment.futureInstallmentMonth.getMonth()+1;

        if(selectedmonth == $scope.mm){
            $scope.startDay=$scope.day+1 ;
        }
        else{
            $scope.startDay=1;
        }
        $scope.days=[];
        var changedMonth = new Date($scope.sipInvestment.futureInstallmentMonth.getFullYear(), $scope.sipInvestment.futureInstallmentMonth.getMonth() + 1, 0);
        var changedMonthArray = changedMonth.toString().split(" ");
        $scope.max = changedMonthArray[2];
        $scope.days = [];
        for(var i=$scope.startDay;i<=$scope.max;i++){
            $scope.days.push(i);
        };
        $scope.futureInstDayOptions = {};
        $scope.futureInstDayOptions = $scope.days.map(function(e) {
            return { title: e };
        });
        if($scope.futureInstDayOptions){
            $scope.sipInvestment.defaultDaySelected = $scope.futureInstDayOptions[0];
        }
    };
    //$scope.days= [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
    $scope.futureInstDayOptions = $scope.days.map(function(e) {
        return { title: e };
    });
    if($scope.futureInstDayOptions){
        $scope.sipInvestment.defaultDaySelected = $scope.futureInstDayOptions[0];
    }
    $scope.futureInstDayInputObject = {
        label : 'DAY',
        name : "futureInstDay",
        required : true
    };

    //Assigning futureInstallmentDay to sipDetails object, if day changes
    $scope.$on('FutureInstallmentDayChange', function(event, selectedValue){
        $scope.futureInstallmentDay = selectedValue.title;
    });

    $scope.firstInstallment = "Current Business Day";


    ///* DatePicker Ends */
    //$scope.$emit('monthupdated', $scope.dt);
    //
    ///*Second Select Change events*/
    //$scope.inputChange = function(inputVal) {
    //   $scope.popup2.opened = false;
    //   $scope.$emit('initialmonthselected', inputVal);
    //};


}

fundDtlsSipCtrl.$inject = ['$scope', '$state', 'buildPlanModelService', 'planSmartSolution', '$filter'];
module.exports = fundDtlsSipCtrl;