/**
* @ngdoc property
* @name redeem_TransactionDetails spec
* @description
*
* - Unit test suite for 'redeem_TransactionDetails'.
*
**/

'use strict';

describe('Directive : redeem_TransactionDetails', function(){

	var compile, scope, directiveEle, isoScope;

	//load all modules, including the html template, needed to support the test
	beforeEach(angular.mock.module('advisor'));

	beforeEach(function(){

		angular.mock.inject(function($rootScope, $compile){
			scope = $rootScope.$new();
			compile = $compile;
			
			//assign the template to the expected url called by the directive and put it in the cache
		});

		var element = angular.element("<ftic-redeem-trans-details panel-list="transDetls"></ftic-redeem-trans-details>");
		directiveEle = compile(element)(scope);
		

		isoScope = directiveEle.isolateScope();
		scope.$digest();
		


	it('should define template element', function() {
        expect(directiveEle.html()).toBeDefined();
     });

	it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
        //console.log("isolated Scope.....\n", directiveEle.isolateScope());
    });

});