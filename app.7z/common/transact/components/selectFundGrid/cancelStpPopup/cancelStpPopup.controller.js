/**
 * @ngdoc property
 * @name RemMenConfPopupController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function cancelStpPopupController($scope, $uibModalStack,transactEventConstants) {
   // $scope.isOpenReviewDetails.open = false; 
    $scope.onCancel = function(){
        $uibModalStack.dismissAll();
    };
    $scope.onSubmit=function(){

        $uibModalStack.dismissAll();
        
       // $scope.$emit("Select_Fund_Continue");
       // $scope.isOpenReviewDetails.open = true; 

        $scope.$emit(transactEventConstants.transact.INV_TRANSACT_CSTP_REVIEW);
        
        // $scope.$emit("Select_Fund_Continue");
    };
}
cancelStpPopupController.$inject = ['$scope', '$uibModalStack','transactEventConstants'];
module.exports = cancelStpPopupController;