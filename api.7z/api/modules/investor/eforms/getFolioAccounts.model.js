// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var FolioAccountsSchema = new mongoose.Schema({
    'accountDetails': {
        'type': Object,
        'default': {}
    }
});

var FolioAccountsLookUp = mongoose.model('FolioAccountsLookUp', FolioAccountsSchema);

var FolioAccountsModel = new FolioAccountsLookUp({
    'accountDetails': {
        'panNo': 'CMLQR5320A',
        'panFolioAccounts': [{
            'folioId': '17877097',
            'latestFolio': 'N',
            'folioAccounts': [
                '1349904865101',
                '2389904865101',
                '4379904865101'
            ]
        }, {
            'folioId': '27877097',
            'latestFolio': 'N',
            'folioAccounts': [
                '1134990486511',
                '11389904865101',
                '11379904865101'
            ]
        }, {
            'folioId': '13592223',
            'latestFolio': 'N',
            'folioAccounts': [
                '1549900759695'
            ]
        }, {
            'folioId': '13461754',
            'latestFolio': 'N',
            'folioAccounts': [
                '0069900759695'
            ]
        }, {
            'folioId': '12413948',
            'latestFolio': 'N',
            'folioAccounts': [
                '0019900759695'
            ]
        }, {
            'folioId': '13027781',
            'latestFolio': 'N',
            'folioAccounts': [
                '0539900759695'
            ]
        }, {
            'folioId': '14503662',
            'latestFolio': 'Y',
            'folioAccounts': [
                '0119900830298',
                '0119901265437',
                '0349900830474',
                '0359900830474',
                '0359901264215'
            ]
        }]
    }
});

FolioAccountsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FolioAccountsLookUp table, please contact admin...' + err);
    } else {
        FolioAccountsLookUp.remove({}, function(err) {
            console.log('FolioAccountsLookUp collection removed' + err);
            FolioAccountsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FolioAccountsLookUp table, please contact admin...');
                }
                console.log('FolioAccountsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FolioAccountsLookUp;
