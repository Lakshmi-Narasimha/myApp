'use strict';

/*Unit test case for navbar*/

describe('directive: uicNavBar', function() {

    var scope, compile, validHTML;

    validHTML = '<uic-nav-bar></uic-nav-bar>';
    beforeEach(angular.mock.module('common','commmon.components.megamenu', 'common.constants'));

    beforeEach(angular.mock.inject(function($compile, $rootScope) {
        scope = $rootScope.$new();
        compile = $compile;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();
        return compiledElem;
    }

    it('should create seperate isolated scope', function() {
        var el = create(),
        isoScope = el.isolateScope();
        expect(isoScope).toBeDefined();
    });

    it('should define the menus in the isolate scope', function(){
        var el = create(),
        isoScope = el.isolateScope();
        expect(isoScope.menus).toBeDefined();
    });

    it('should return menu name when passed the menu object as argument for getMenuName()', function(){
        var object = {
            "Distributor Zone":[
               {
                  "text":null,
                  "twocolumn":"col-xs-12 col-sm-3",
                  "url":"#/smartsolutions",
                  "menuitem":"distributorzone",
                  "submenuitem":null,
                  "submenu":[
                     {
                        "text":"Become an Advisor",
                        "url":"",
                        "menuitem":"distributorzone"
                     },
                     {
                        "text":"Existing Advisor",
                        "url":"",
                        "menuitem":"distributorzone"
                     },
                     {
                        "text":"Subscribe for Updates",
                        "url":"",
                        "menuitem":"distributorzone"
                     }
                  ],
                  "helpsection":false
               }
            ]
         };
         var el = create(),
        isoScope = el.isolateScope();
         var menuName = isoScope.getMenuName(object);
         expect(menuName).toEqual("Distributor Zone");

    });


});
