// getRedeemSFDetails.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SelectFundDetailsSchema = new mongoose.Schema({
    SelectFundObject: {
        type: Array,
        "default": []
    }
});

var SelectFundDetailsLookUp = mongoose.model('SelectFundDetailsLookUp', SelectFundDetailsSchema);

var RedeemSFDetailsModel = new SelectFundDetailsLookUp({
	"SelectFundObject" : [{
				"folioId": "14597352",
				"distId": "ARN-0353",
				"eligibleAccounts": [{
					"tschvalScheme": "006",
					"fmDescription": "Franklin India Bluechip Fund - Dividend",
					"fundCategory": "EQUITY",
					"fundType": "EQUITY",
					"tschvalAccno": "0069901064910",
					"balUnits": "2463.841",
					"marketValue": "349183.18",
					"tschvalFsFlag": "N",
					"investmentGoal": ""
				}, {
					"tschvalScheme": "219",
					"fmDescription": "Franklin India Smaller Companies Fund - Growth",
					"fundCategory": "EQUITY",
					"fundType": "EQUITY",
					"tschvalAccno": "2199901064910",
					"balUnits": "2000.000",
					"marketValue": "293195.60",
					"tschvalFsFlag": "N",
					"investmentGoal": ""
				}]
			}
		]
});

SelectFundDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SelectFundDetailsLookUp table, please contact admin...');
    } else {
        SelectFundDetailsLookUp.remove({}, function(err) {
            console.log('SelectFundDetailsLookUp collection removed');
            RedeemSFDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating SelectFundDetailsLookUp table, please contact admin...');
                }
                console.log('SelectFundDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SelectFundDetailsLookUp;