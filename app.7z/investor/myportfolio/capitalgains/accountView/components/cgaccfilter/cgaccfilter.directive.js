/**
 * @ngdoc property
 * @name fticCapitalGainAcFilter Directive
 * @requires advisorConstants 
 * @requires advisorEventConstants 
 * @requires fticLoggerMessage 
 * @requires loggerConstants 
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Capital Gains Filter for selected Folio Number and Account Number
 *
 **/
'use strict';

var fticCapitalGainAcFilter = function($timeout, investorEventConstants, cgAccDetModel, fticgAccDetLoadInitialService, invInstantMailback, downloadService) {
    return {
        template: require('./cgaccfilter.html'),
        restrict: 'E',
        replace: true,
        scope: {
            cgAccountData:'='
        },
        controller: function ($scope) {
            var accFolioObj = {};
            $scope.hideSelect = true;
            $scope.dateOptions = [
                {
                    id: 1,
                    label: 'Current Financial Year',
                    type: 'definedate',
                    key:'CF'
                }, {
                    id: 2,
                    label: 'Last Financial Year',
                    type: 'definedate',
                    key:'LF'
                }
            ];

            $scope.sectionInvOptsfolio = [];
            $scope.$on(investorEventConstants.MyPortfolio.CG_FOLIO_NUMBER_LIST, function(event){
                $scope.accountViewFolioNumberList = cgAccDetModel.getFolioNumbersList().length;
                _.each(cgAccDetModel.getFolioNumbersList(), function(element, index, list){
                    var folioObj = null; 
                    folioObj = {
                        title : "Folio No. " + element.folioId,
                        folioNumber : element.folioId
                    };
                    if(element.latestFolio === 'Y'){
                        $scope.selectedInvFolioOpt = folioObj;                        
                    };
                    $scope.sectionInvOptsfolio.push(folioObj);
                });
                    if($scope.accountViewFolioNumberList){
                        $scope.$emit('cgfolio', $scope.selectedInvFolioOpt);
                    }
            });
            $scope.$emit('cgapplyac');
            $scope.$on('cgfolio', function(event, data){
                var cgfolioFilter = {};
                $scope.selectedFolioNumber = data.folioNumber;
                $scope.sectionInvOptsaccount = [];
                $scope.selectedInvAccOpt = null;
                $timeout(function(){
                    var accountList = [];
                    _.each(cgAccDetModel.getFolioNumbersList(), function(folioEle){
                        if($scope.selectedFolioNumber === folioEle.folioId){
                            _.each(folioEle.folioAccounts, function(accountEle, index){
                                var accountObj = null;
                                accountObj = {
                                    title : 'Account No. '+ accountEle,
                                    accontNumber : accountEle
                                };
                                if(index === 0){
                                    $scope.selectedInvAccOpt = accountObj;
                                    accFolioObj.folioPanAccNo = accountObj.accontNumber;
                                }
                                accountList.push(accountObj);
                            });
                        }
                    });
                    $scope.sectionInvOptsaccount = accountList;
                    if(!fticgAccDetLoadInitialService._isInitialLoad){
                        fticgAccDetLoadInitialService._isInitialLoad = true;
                        accFolioObj.folioPanAccNo = $scope.selectedInvAccOpt.accontNumber;
                        accFolioObj.dayFlag = 'CF';
                        fticgAccDetLoadInitialService.getcgaccountdetails($scope,accFolioObj);
                        //$scope.emitcgaApply();
                    }
                });
            });
            $scope.initApply = true;
            $scope.$on('cgac', function(event, data){
                accFolioObj.folioPanAccNo = data.accontNumber;
            });
            $scope.$on('selectedValue',function (event,data) {
                if(data.key != null) {
                    accFolioObj.dayFlag = data.key;
                }
            });
            $scope.emitcgaApply = function(){
                $scope.cgAccountData = false;
                invInstantMailback.setMailBackData({
                    folioPanAcc: accFolioObj.folioPanAccNo,
                    fromDate: '',
                    toDate: '',
                    periodType: accFolioObj.dayFlag
                });
                downloadService.setQueryparams({
                    strInputData: accFolioObj.folioPanAccNo,
                    inputFlag: 'A',
                    periodType: accFolioObj.dayFlag
                });
                fticgAccDetLoadInitialService.getcgaccountdetails($scope,accFolioObj);
            };
        }
    };
};
fticCapitalGainAcFilter.$inject = ['$timeout', 'investorEventConstants', 'cgAccDetModel','fticgAccDetLoadInitialService', 'invInstantMailback', 'downloadService'];
module.exports = fticCapitalGainAcFilter;