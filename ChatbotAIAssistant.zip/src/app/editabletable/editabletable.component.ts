import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editabletable',
  templateUrl: './editabletable.component.html',
  styleUrls: ['./editabletable.component.css']
})
export class EditabletableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
