'use strict';

var uicNavBarService = function() {

};

uicNavBarService.$inject = [];
module.exports = uicNavBarService;
