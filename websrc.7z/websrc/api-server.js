// npm modules
var express = require('express');
var https = require('https');
var bodyParser = require('body-parser');
var querystring = require('querystring');
var session = require('express-session');
var fs = require('fs');
var path = require('path');
var uuid = require('node-uuid');
var winston = require('winston');
var expressWinston = require('express-winston');
//url config file
var config = require('./config/config');
var cassandra = require('cassandra-driver');
var async = require('async');
var client = new cassandra.Client({contactPoints: ['127.0.0.1'], keyspace: 'emp'});

var app = express();

// set our port
var port = process.env.PORT || 9000;

// get all data/stuff of the body (POST) parameters
// parse application/json
app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: false
}));

// initialize the session
app.use(session({ secret: '123456ABCDEFG', saveUninitialized: true, resave: true }));

//app.UseCors(CorsOptions.AllowAll);
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// set the static files location
app.use(express.static(__dirname + '/'));

// logger
var logDirectory = path.join(__dirname, 'log');

// ensure log directory exists
var logDir = fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

function assignId(req, res, next) {
    req.id = uuid.v4();
    next();
}

app.use(assignId);
var now = new Date();
var month = now.getMonth() + 1;
month = (month < 10 ? "0" : "") + month;

var day  = now.getDate();
day = (day < 10 ? "0" : "") + day;
// setup the logger
app.use(expressWinston.logger({
    transports: [
        new winston.transports.File({
            level: 'info',
            name: 'info-file',
            filename: path.join(logDirectory, 'all-logs_'+ month + "-" + day + "-" + now.getFullYear() +'.log'),
            handleExceptions: true,
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: false
        }),
        new winston.transports.File({
            level: 'error',
            name: 'error-file',
            filename: path.join(logDirectory, 'err-logs_'+ month + "-" + day + "-" + now.getFullYear() +'.log'),
            handleExceptions: true,
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: false
         })
        //,
        // new winston.transports.Console({
        //   json: true,
        //   colorize: true
        // })
    ],
    msg: "HTTP {{req.method}} {{req.url}}",
    exitOnError: false
}));
// express-winston errorLogger makes sense AFTER the router.
app.use(expressWinston.errorLogger({
 transports: [
   new winston.transports.Console({
     json: true,
     colorize: true
   })
 ]
}));
expressWinston.requestWhitelist.push('session');
expressWinston.bodyBlacklist.push('secretid', 'secretproperty');
expressWinston.requestWhitelist.push('body');
expressWinston.responseWhitelist.push('body');

// authenticate touchcommerce
function authenticateTouchCommerce(req, res, next) {
    // authenticate
    var post_data = querystring.stringify({
        'j_username': 'VWMobApp',
        'j_password': 'x95VIFsC',
        'submit': 'login'
    });
    var proxyRequest = https.request({
            host: config.TC_SERVER_NAME,
            method: 'POST',
            path: config.TC_FORM_LOGIN_URI,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(post_data)
            },
            rejectUnauthorized: false
        },
        function(proxyResponse) {
            console.log(proxyResponse.headers);
            var sessionCookie = proxyResponse.headers["set-cookie"].toString().split(";");
            proxyResponse.setEncoding('utf8');

            proxyResponse.on('data', function(chunk) {
                if (sessionCookie) {
                    req.sessionCookie = req.session.sessionCookie = sessionCookie[0];
                    //res.send(chunk);
                    next();
                } else {
                    req.session.sessionCookie = null;
                    chunk.message = 'ERROR!!! failed to login into website';
                    res.send(chunk);
                }
            });
            proxyResponse.on('error', function(err) {
                req.session.sessionCookie = null;
                err.message = 'ERROR!!! failed to login into website';
                res.send(err);
            });
        });

    proxyRequest.write(post_data);
    proxyRequest.end();
}


// check authentication touchcommerce
function isAuthenticated(req, res, next) {
    if (req.session.sessionCookie) {
        console.log('authenicated');
        req.sessionCookie = req.session.sessionCookie;
        next();
    } else {
        console.log('not authenticated');
        authenticateTouchCommerce(req, res, next);
    }
}

// routes
var agentAvailabilityRoute = require('./api/modules/agentAvailability/agentAvailability.route');
var engagementRoute = require('./api/modules/engagement/engagement.route');
var getMessageRoute = require('./api/modules/getMessage/getMessage.route');
var customerIsTypingRoute = require('./api/modules/customerIsTyping/customerIsTyping.route');
var sendMessageRoute = require('./api/modules/sendMessage/sendMessage.route');
var dataPassRoute = require('./api/modules/dataPass/dataPass.route');
// api services
app.post('/mfchat/rest/agent', isAuthenticated, agentAvailabilityRoute);
app.post('/mfchat/rest/engagement', isAuthenticated, engagementRoute);
app.post('/mfchat/rest/message/:engagementID', isAuthenticated, getMessageRoute);
app.post('/mfchat/rest/message', isAuthenticated, sendMessageRoute);
app.post('/mfchat/rest/customerIsTyping', isAuthenticated, customerIsTypingRoute);
app.post('/mfchat/rest/dataPassForSales', isAuthenticated, dataPassRoute);

/*  ------ Cassandra imp --------*/
function GetRecordsFromDatabase(callback) {
    client.execute("select * from emp", function(err, result) {
        if (!err) {
            if (result.rows.length > 0) {
                var records = result.rows[0];
                callback(1, result.rows);
            } else {
                callback(1, {});
            }
        } else {
            callback(0, {});
        }

    });
}

function GetRecords(res) {
    var callback = function(status, recs) {
        if (status != 1) {
            res.json({ Error: "Error" });
        } else {
            var jsonToSend = { Results: recs };
            res.json(jsonToSend);
        }
    };

    GetRecordsFromDatabase(callback);
}

/* GET data. */
app.get('/empdata/', function(req, res, next) {
    GetRecords(res);
});

app.get('/empdata/:emp_id', function(req, res, next) {
    var jsonToSend = { Message: "Here is my resource from " + req.params.emp_id };
    res.json(jsonToSend);
});
/* -------------- Cassandra ----------*/

app.listen(port);
console.log('Application is running on this port http://localhost:' + port);
