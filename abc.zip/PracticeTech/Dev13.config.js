define([
], function () {

    //var odataServiceName = 'http://localhost:8080/ods.svc/';
    var ebixServiceName = 'http://dev13hq508.ampf.com/EbixWrapper/api/';
    var odataServiceName = 'http://dev13hq508.ampf.com/amp/ods.svc/';   
    var oboservlet = 'http://dev13hq508.ampf.com/amp/adv_capl/oboselector/OBOServlet';
    var contactProfileURL = 'http://dev13hq508.ampf.com/contactprofile/index.html#navlanding';
    //var contactProfileURL = 'http://localhost:55220/index.html#navlanding';
    var accountListURL = 'http://dev13hq508.ampf.com/accountlist/index.html#navlanding';
    //var accountListURL = 'http://dev13hq508.ampf.com/accountlist/index.html#navlanding';
    var calendarURL = 'http://dev13hq508.ampf.com/ContactManager/index.html#navlanding';
    var defaultNavURL = 'http://dev13hq508.ampf.com/navigator/index.html';
    var contactListURL = 'http://dev13hq508.ampf.com/navigator/index.html#contactlist';
    var ncstURL = 'http://dev13hq508.ampf.com/ncst/index.html#navlanding';
    var ACDeepContentURL = "https://www.advisorcompass.com/web/advisorcompass/displaycontent?contID=749750&contType=AC-DeepContent";
    var isDevEnv = true;
    //only messages from the below url's will be responded to
    var urlWhiteList = ['http://localhost:55220',
                         'http://dev13hq508.ampf.com',
                         'http://dev16hq508.ampf.com:443',
                         'https://practicetech.dev.advisorcompass.com',
                         'http://dev13hq508.ampf.com:443'];
    var eSigConfig = {
    			docId : "197865",
    		signImgType : "jpg",
    		serviceUrl:"http://dev13hq508.ampf.com/esig/service/"
    		
    };

    var config = {
        ebixServiceName:ebixServiceName,
        odataServiceName: odataServiceName,        
        oboservlet: oboservlet,
        contactProfileURL: contactProfileURL,
        accountListURL: accountListURL,
        calendarURL: calendarURL,
        ncstURL:ncstURL,
        urlWhiteList: urlWhiteList,
        isDevEnv: isDevEnv,
        eSigConfig: eSigConfig,
        ACDeepContentURL: ACDeepContentURL
    };
    return config;
});