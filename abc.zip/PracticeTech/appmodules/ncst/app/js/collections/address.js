
define(
		[ 'jquery', 'underscore', 'backbone','appmodules/ncst/app/js/models/model-address-entry' ],
		function($, _, Backbone, AddressModel) {
			 Backbone.Collection
					.extend({
						model : AddressModel,
						url :'',
						parse : function(response) {
							var _addressArray = [];
							return _addressArray;

						}
					});
		});