coa = coa || {};
define(
		[ 'jquery', 'underscore', 'backbone', ],
		function() {
			coa.collections.addressList = Backbone.Collection
					.extend({
						model : coa.models.Address,
						parse : function(response) {
							var _addressArray = [];
							var _address = response.d.results, _homeAddress = "";
							
							for ( var i = 0; i < _address.length; i++) {
								var _addrs = _address[i];
								 {
								     if (!_addrs.addrEndDt) {
								         _addrs.undeliverable = false;
								         if (_addrs.addrStatCd == "Undeliverable") {
								             _addrs.undeliverable = true;
								         } 
								         if (_addrs.addrUseCd.toLowerCase() == "home") {
								             _homeAddress = _addrs;
								         } else {
								             _addressArray.push(_addrs);
								         }
										
									}
								}
							}
							_addressArray.unshift(_homeAddress);
							coa.addressArray = _addressArray;
							if (_address) {
								var  _addressType = this.getAddressType(_addressArray[0]);
								coa.user.set('oldAddressType',
										_addressType);
								coa.user.set('addressType', _addressType);
							} else {
								coa.user.set('addressType', 'U.S');
								coa.user.set('oldAddressType',
										'U.S');
							}
							console.log(_addressArray, "_addressArray");
							return _addressArray;

						},getAddressType : function(address) {
							var _addressType = "U.S";
							var _canadaProvinces = [ 'AB', 'BC', 'MB', 'NB', 'NL', 'NS', 'ON',
									'PE', 'QC', 'SK', 'NT', 'NU', 'YT' ];
							var _stCd = address.stCd, _cntryCd = address.cntryCd;
							if (_cntryCd == null || _cntryCd == "" || _cntryCd == "USA" || _cntryCd == "US" || _cntryCd == "?") {
							    _addressType = "U.S";
							    return _addressType;
							} else {
							    _addressType = "Foreign";
							    return _addressType;
							}
							if (_stCd) {
								if (_stCd.length > 2) {
									_addressType = "Foreign";
								} else {
									if (_canadaProvinces.indexOf(_stCd) != -1) {
										_addressType = "Foreign";
									} else {
										_addressType = "U.S";
									}
								}

							} else {
								_addressType = "U.S";
							}
							return _addressType;
						}
					});
			coa.addressList = new coa.collections.addressList();
		});