/**
     * @ngdoc object
     * @name component.AddEditPayment
     * @description
     > AddEditPayment item is the Main level in One Time Payment module.
     * @requires detectCardCategoryFilter
     */

angular.module('CSS.billing').directive("addEditPaymentModal", ['detectCardCategoryFilter', '$state', '$rootScope', '$timeout', 'billingUtils', function(detectCardCategoryFilter, $state, $rootScope, $timeout, billingUtils) {
    return {
        restrict: 'EA',
        replace: true,
        templateUrl: window.UIC.sitePrefix + 'components/partials/addedit.payments.template.html',
        controller: addEditPaymentModalController,
        controllerAs: 'addEditPaymentVM',
        bindToController: true,
        scope: {
            systemDateTime: '='
        }
    };
}]);

function addEditPaymentModalController(detectCardCategoryFilter, $state, $rootScope, $timeout, billingUtils) {
    var addEditPaymentVM = this;
    addEditPaymentVM.throwUnAuthorizedPayError = false;
    addEditPaymentVM.paymentMthd = {};
    
    addEditPaymentVM.months = [];
    addEditPaymentVM.years = [];
    addEditPaymentVM.cardPayment = true;
    addEditPaymentVM.submitted = false;
    addEditPaymentVM.pastDate = false;
    addEditPaymentVM.errorFlag = false;
    addEditPaymentVM.sitePrefix = ((window.sitePrefix) ? window.sitePrefix : '') + 'assets/style/images/backgrounds/';
    addEditPaymentVM.closeModal = function(isCancelClicked) {
        addEditPaymentVM.submitted = false;
        addEditPaymentVM.errorFlag = false;
        angular.element('div').find("#addnewPaymentModal").modal('hide');
        if (!addEditPaymentVM.paymentMthd.editIndicator) {
            document.getElementById("addCreditForm").reset();
            document.getElementById("addBankForm").reset();
        }

        if (window.UIC.isChoosePayment) {
            $timeout(function() {
                angular.element('#savedPaymentModal').modal('show');
                window.UIC.isChoosePayment = false;
            }, 300);

            $timeout(function() {
                angular.element('body').addClass('modal-open');
            }, 400);
        }

        if (isCancelClicked) {
            addEditPaymentVM.user = {};
            $rootScope.$broadcast('cancelPaymentMethod');
        }

        //document.getElementById("addCreditForm").reset();
        //document.getElementById("addBankForm").reset();
    };
    angular.element('body').find("#addnewPaymentModal").on('show.bs.modal', function() {
        // addEditPaymentVM.throwUnAuthorizedPayError = false;
        addEditPaymentVM.user = {};
    });
    var targetElem = $('#addnewPaymentModal'),
        $doc = $(document);
    // function bind(){
    //     $(window).on('scroll.iOSKeyboardFix', react);
    //     react();
    // }

    // function react(){
    //     var offsetY = targetElem.offset().top,
    //         scrollY = $(window).scrollTop(),
    //         changeY = offsetY - scrollY;

    //     targetElem.css({'position':'absolute', 'top':'-'+changeY+'px', 'height': 'auto'});

    //     $doc.on('blur.iOSKeyboardFix', 'input, textarea, select, [contenteditable]', unbind);
    //     $doc.on('touchend.iOSKeyboardFix', unbind);
    // }

    // function unbind(){
    //      if( !targetElem.length)
    //          return;
    //     document.activeElement.blur();
    //     $(window).scrollTop(0);
    //     $(window).off('scroll.iOSKeyboardFix');
    //     $doc.off('touchend.iOSKeyboardFix blur.iOSKeyboardFix');
    // }
    // if( targetElem.length && navigator.userAgent.match(/iPhone|iPad|iPod/i) ){
    //     targetElem.on('focus.iOSKeyboardFix', 'input, textarea, select, [contenteditable]', bind);
    // }                 


    addEditPaymentVM.isPastDate = function() {
        if (parseInt(addEditPaymentVM.user.expYear, 10) === addEditPaymentVM.thisYear) {
            addEditPaymentVM.pastDate = (parseInt(addEditPaymentVM.user.expMonth, 10) === (addEditPaymentVM.thisMonth + 1) || parseInt(addEditPaymentVM.user.expMonth, 10) < (addEditPaymentVM.thisMonth + 1) ? true : false);
        } else {
            addEditPaymentVM.pastDate = false;
        }
        return addEditPaymentVM.pastDate;
    };

    addEditPaymentVM.populateDateDD = function() {
        addEditPaymentVM.months = [];
        addEditPaymentVM.years = [];
        var sysDate = new Date(addEditPaymentVM.systemDateTime);
        addEditPaymentVM.thisYear = sysDate.getFullYear();
        addEditPaymentVM.thisMonth = sysDate.getMonth();
        for (var i = addEditPaymentVM.thisYear; i < (addEditPaymentVM.thisYear + 10); i++) {
            addEditPaymentVM.years.push(i);
        }
        for (var j = 1; j <= 12; j++) {
            addEditPaymentVM.months.push(j);
        }
    };

    if (addEditPaymentVM.systemDateTime !== null && addEditPaymentVM.systemDateTime !== undefined) {
        addEditPaymentVM.populateDateDD();
    }


    addEditPaymentVM.cardTypes = [{
        "className": "visa",
        "typeName": "Visa"
    }, {
        "className": "mastro",
        "typeName": "Master Card"
    }, {
        "className": "amex",
        "typeName": "Amex"
    }, {
        "className": "discover",
        "typeName": "Discover"
    }];
    addEditPaymentVM.paymentMthd.editIndicator = false;
    //to do
    addEditPaymentVM.readableuser = false;

    addEditPaymentVM.submit = function(isValid) {
        addEditPaymentVM.submitted = true;
        // addEditPaymentVM.throwUnAuthorizedPayError = false;
        if (isValid && !addEditPaymentVM.isPastDate()) {
            addEditPaymentVM.user.bankOrCard = (addEditPaymentVM.cardPayment === true) ? "card" : "bank";
            if (addEditPaymentVM.cardPayment === true) {
                addEditPaymentVM.user.cardcategory = window.UIC.CARD_CODES[detectCardCategoryFilter(addEditPaymentVM.user.cardNumber)];
            } else {
                addEditPaymentVM.user.cardcategory = null;
            }
            addEditPaymentVM.user.indicatorForAddOrEditPaymentMethod = (addEditPaymentVM.paymentMthd.editIndicator === true) ? "E" : "A";
            $rootScope.$emit("submitted", addEditPaymentVM.user);
            addEditPaymentVM.closeModal();
            addEditPaymentVM.submitted = false;
            addEditPaymentVM.user = {};
            addEditPaymentVM.pastDate = false;
            /* $('#addCreditForm').reset();
             $('#addBankForm').reset();*/
        } else {
            //console.log(addEditPaymentVM.user);
        }
    };

    // addEditPaymentVM.$on("addMode", function() {
    //     addEditPaymentVM.throwUnAuthorizedPayError = false;
    //     addEditPaymentVM.paymentMthd.editIndicator = false;
    //     addEditPaymentVM.cardPayment = true;
    //     addEditPaymentVM.user = {};
    // });

    $rootScope.$on('methodSelected', function(event, methodType) {
        addEditPaymentVM.cardPayment = (methodType === 'Bank account' ? false : true);
    });

    addEditPaymentVM.checkCardCategory = function(card) {
        if (card) {
            var codes = window.UIC.CARD_CODES;

            angular.forEach(codes, function(obj, key) {
                if (key === card) {
                    card = obj.toLowerCase();
                }
            });

            return card;
        }
    };

    addEditPaymentVM.selectPaymentType = function(type) {
        addEditPaymentVM.user = {};
        // addEditPaymentVM.throwUnAuthorizedPayError = false;
        if (type === "Card") {
            if (!addEditPaymentVM.cardPayment) {
                addEditPaymentVM.submitted = false;
                addEditPaymentVM.pastDate = false;
            }
            addEditPaymentVM.cardPayment = true;
        } else if (type === "Account") {
            if (addEditPaymentVM.cardPayment) {
                addEditPaymentVM.submitted = false;
                addEditPaymentVM.pastDate = false;
            }
            addEditPaymentVM.cardPayment = false;
        }
    };
    addEditPaymentVM.user = {};
    addEditPaymentVM.path = window.sitePrefix + 'assets/style/images/backgrounds/';

    $(function() {
        $("[data-toggle=popover]").popover({
            html: true,
            content: function() {
                var content = $(this).attr("data-popover-content");
                return $(content).children(".popover-body").html();
            }
        });
    });
}
