var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var router = express.Router();
//var udmConnection = require('../udmConnection/udmConnection.model');

// api route
router.route('/mfchatnode/rest/udmConnection')
    .post(function(req, res) {
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        console.log("/mfchatnode/rest/udmConnection", req.session);
        console.log('**********');
        console.log(req.session.udm);
        console.log('**********');
        var resObj = null;
        if (req.body && req.body.RequestParams && req.body.RequestParams.isConnected) {
            console.log("req.session.chatSendMsgCounter", req.session.chatSendMsgCounter);
            console.log("req.session.chatGetMsgCounter", req.session.chatGetMsgCounter);
            req.session.udm = req.session.udm || {};
            if (req.session.udm.isConnected && req.session.udm.isConnected == 200) {
                console.log(req.session.udm.isConnected);
                console.log("Now the connection is existing between UDM and Node.js.");
                resObj = { "isConnected": true, "message": "Now the connection is existing between UDM and Node.js." };
            } else if (req.session.udm.isConnected && req.session.udm.isConnected != 200) {
                console.log("Now the connection is not existing between UDM and Node.js.", req.session.udm.isConnected);
                resObj = { "isConnected": false, "message": "Now the connection is not existing between UDM and Node.js." };
            }
            if (!req.session.udm.isConnected) {
                console.log("No Response from the agent yet.", req.session.udm.isConnected);
                resObj = { "isConnected": true, "message": "No Response from the agent yet." };
            }
            res.send(resObj);
            logger.outBoundData.info(logger.formatResMsg(req, resObj));
        } else {
            resObj = { "status": "error", "message": "Missing connection flag, Please send it." };
            res.send(resObj);
            logger.error.error(logger.formatResMsg(req, resObj));
        }
    });

module.exports = router;
