// getPlanSmartSolution.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PlanSmartSolutionSchema = new mongoose.Schema({
    planSmartSolutionResp: {
        type: Array,
        "default": []
    }
});

var PlanSmartSolutionLookUp = mongoose.model('PlanSmartSolutionLookUp', PlanSmartSolutionSchema);

var PlanSmartSolutionModel = new PlanSmartSolutionLookUp({
    planSmartSolutionResp: [
        {
            "age": "25",
            "investmentTenure": "4",
            "investmentAmount": "3000",
            "equityPerc": "0",
            "fundCode": "FICBOF",
            "fundName": "Franklin India Corporate Bond Opportunities Fund",
            "fundDetails": {
                "fundDesc":  "Franklin India Corporate Bond Opportunities Fund",
                "nfoFlag": "N",
                "fundType": "N",
                "stepUpFrequency": "",
                "stepUpValue": "",
                "stepUpType": ""
            },
            "allocPer": "100",
            "fundCategory": "INCOME",
            "rtCode": "406",
            "productType": "16084",
            "annualizedReturn": "9.71",
            "schemePortfolio": "4347",
            "monthlySIP": "39.15",
            "annualSIP": "591.72",
            "lumpsum": "2070.79",
            "revisedYears": "1.92"
        }
    ]
});

PlanSmartSolutionLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PlanSmartSolutionLookUp table, please contact admin...');
    } else {
        PlanSmartSolutionLookUp.remove({}, function (err) {
            console.log('PlanSmartSolutionLookUp collection removed');
            PlanSmartSolutionModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating PlanSmartSolutionLookUp table, please contact admin...');
                }
                console.log('PlanSmartSolutionLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PlanSmartSolutionLookUp;
