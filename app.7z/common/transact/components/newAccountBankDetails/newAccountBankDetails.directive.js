/**
 * @ngdoc property
 * @name fticPaymentForm Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Redemption Form.
 *
 **/
'use strict';

var fticNewAccountBankDetails = function (bankDtlsModel, transactModel, $state, ifscModel, $stateParams, authenticationService,TransactConstant, paperlessModel, $timeout, paymentDetailsUtility) {
    return {
        template: require('./newAccountBankDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
            parentForm: '='
        },
        controller:['$scope', function ($scope) {
            $scope.ifscRequired = true;
            $scope.showBranchDetails = false;
            $scope.showBankError = false;
            $scope.ifscTextField = "ifscTextField";
            $scope.branchName = null;
            $scope.branchAddress = null;
            $scope.ifscCode = null;
            $scope.method = {};
            $scope.method.newAccountSel = null;
            $scope.showAccTypeError = false; 
            $scope.type = {};
            $scope.type.accTypeSel = null;

            $scope.accNoObject = {
                key: 'accountNo', 
                text: TransactConstant.transact.ACCOUNT_NUMBER,
                value: '',
                name: 'accNo',
                type: 'number',
                isRequired : true
            };

            $scope.accTypeOptions = [
                {
                    title: TransactConstant.transact.ACCOUNT_TYPE, 
                    key : 'accountType',
                    value : TransactConstant.transact.ACCOUNT_TYPE
                },
                {
                    title: TransactConstant.transact.CURRENT, 
                    key : 'Current',
                    value : TransactConstant.transact.CURRENT
                },
                {
                    title: TransactConstant.transact.SAVINGS,
                    key : 'Savings',
                    value : TransactConstant.transact.SAVINGS
                }
            ];

            $scope.accTypeObject = {
                key: 'accType',                
                isRequired: true
            };

            $scope.newAccountOptions = [
                {
                    title: TransactConstant.transact.SELECT_BANK, 
                    key : 'select',
                    name: 'bankOpts'
                }
            ];
            $scope.ifsc = {
                ifscCode : ''
            };

            $scope.isNewInvestor = transactModel.isNewInvestor;
            $scope.isNewFolio = transactModel.getIsNewFolio();            
            var txnType = paymentDetailsUtility.getTxnType(); //"P"
            
            $scope.$on("ChangePaymentOnChange", function () {
                $scope.method.newAccountSel = $scope.newAccountOptions[0];
                resetNewAccountOptions();
            })

            function savePreviousSelBank() { //Save previous selected bank
                if(bankDtlsModel.getSelectedBank() !== null) {
                    var selectedBank = bankDtlsModel.getSelectedBank().split('-');

                    for(var i=0; i<$scope.newAccountOptions.length; i++) {
                        if($scope.newAccountOptions[i].title === selectedBank[0]) {
                            $scope.method.newAccountSel = $scope.newAccountOptions[i];
                        }
                    }
                    savePreviousSelBankIfsc();
                }
            };

            //Save previous selected bank
            function savePreviousSelBankNewAcnt() {
                if(bankDtlsModel.getSelectedBank() !== null) {
                    var selectedBank = bankDtlsModel.getSelectedBank().split('-');

                    for(var i=0; i<$scope.newAccountOptions.length; i++) {
                        if($scope.newAccountOptions[i].title === selectedBank[0]) {
                            $scope.method.newAccountSel = $scope.newAccountOptions[i];
                        }
                    }
                    savePreviousSelBankIfsc();
                }
            };
            
            if($scope.isNewInvestor || $scope.isNewFolio) { //If new investor, then get all FT banks                
                var pymntBnkLstParams={
                    "trxnType" : txnType,
                    "guId" : authenticationService.getUser() !== null ? authenticationService.getUser().guId : null  
                };

                bankDtlsModel.fetchNewInvBanks(pymntBnkLstParams).then(function (data) {
                    bankDtlsModel.setPreRegBanks(data.paymentBankList);
                    bankDtlsModel.setneftDetails(data.neftDetails);
                    
                    if(bankDtlsModel.getPreRegBanks() !== null) {
                        var bankDtls = bankDtlsModel.getPreRegBanks();
                        
                        for(var i=0; i<bankDtls.length; i++) {
                            $scope.newAccountOptions.push({title: bankDtls[i].bankName, key : bankDtls[i].bankName});
                        }
                        
                        // For Transact Module
                        if($stateParams.key === TransactConstant.transact.Payment_Key) {
                            savePreviousSelBank();
                        }

                        //For Paperless Module
                        if(paperlessModel.paymentDtls.hasData) {
                            savePreviousSelBank();
                        }

                    }
                }, function (data) {
                    console.log("Failure", data)
                });
            } else if(bankDtlsModel.getBankDetails() !== null) { // If existing investor, then this option is only limited to new mandate banks


                var bankDtls = bankDtlsModel.getBankDetails().newEmandates;
                if(bankDtls){
                       for(var i=0; i<bankDtls.length; i++) {
                    $scope.newAccountOptions.push({title: bankDtls[i].pbBankName, key : bankDtls[i].pbBankName, refNo : bankDtls[i].achRefNo});
                     } 
                }
                  // For Transact Module
                if($stateParams.key === TransactConstant.transact.Payment_Key) {
                    savePreviousSelBankNewAcnt();
                }
                //For Paperless Module
                if(paperlessModel.paymentDtls.hasData) {
                    savePreviousSelBankNewAcnt();
                }
             
            }
            function resetNewAccountOptions(){
                $scope.ifsc = "";
                $scope.showBranchDetails = false;
                $scope.accNoObject.value = "";
                $scope.type.accTypeSel = $scope.accTypeOptions[0];
            }
            $scope.$on('newAccountChanged', function(event, data){
                bankDtlsModel.setAchRefNo(data.refNo);
                if($stateParams.key !== TransactConstant.transact.Payment_Key) {
                    resetNewAccountOptions();
                }
                var bankDtls = $scope.isNewInvestor || $scope.isNewFolio ? bankDtlsModel.getPreRegBanks() : bankDtlsModel.getBankDetails(),
                    payMethod = bankDtlsModel.getPaymentMethod();

                if(bankDtls !== null && data.key !== 'select') {
                    $scope.showBankError = false;
                    bankDtlsModel.setBankName(data.title);
                    $scope.$emit('bankSelected', data);
                    $scope.$broadcast('bankSelected', data);
                } else {
                    $scope.$broadcast('disableIFSCLink', data);
                    if($scope.method.newAccountSel && $scope.method.newAccountSel.key === 'select') {
                        if($scope.isNewInvestor || $scope.isNewFolio) {
                           $scope.showBankError = true;
                        } else if(payMethod === TransactConstant.transact.SETUP_NEW_MANDATE) {
                            $scope.showBankError = true;
                        }
                    }
                }
                bankDtlsModel.setIsNewAccBankError($scope.showBankError);
            });

            $scope.$on('INPUT_CHANGED', function(event, data) {
                if(data.value) {
                    bankDtlsModel.setAccountNo(data.value);
                    //Set Bank Format
                    var bankName = bankDtlsModel.getBankName(),
                        accNo = bankDtlsModel.getAccountNo();

                    if(bankName !== null && accNo !== null) {
                        bankDtlsModel.setSelectedBank(bankName + '-' + accNo);
                    }
                }
            });

            $scope.$on('accTypeChanged', function(event, data) {
                $scope.showAccTypeError = false;
                if(data.key !== 'accountType') {
                    bankDtlsModel.setAccountType(data.value);
                } else {
                    $scope.showAccTypeError = true;
                }
            });

            $scope.ifscDetails = {};
            $scope.$on('ifscSrchRes', function(){
                $scope.showBranchDetails = false;
                $scope.ifscDetails = ifscModel.getIfscGridResDet();                
                $scope.branchName = $scope.ifscDetails.bankDetails;
                $scope.branchAddress = $scope.ifscDetails.bnkAdd;
                $scope.ifscCode = $scope.ifscDetails.ifscCode;

                bankDtlsModel.setIfscCode($scope.ifscCode);
                bankDtlsModel.setBranchName($scope.branchName);
                bankDtlsModel.setBranchAddress($scope.branchAddress);                
                if($scope.ifscCode) {
                    $scope.showBranchDetails = true;
                }
            });

            //Save previous selected ifsc, account number, account type
            function savePreviousSelBankIfsc() {
                $scope.accNoObject.value = angular.isNumber(bankDtlsModel.getAccountNo()) ? bankDtlsModel.getAccountNo() : parseInt(bankDtlsModel.getAccountNo());
                var accType = bankDtlsModel.getAccountType();
                for(var i=0; i<$scope.accTypeOptions.length; i++) {
                    if($scope.accTypeOptions[i].title === accType) {
                        $scope.type.accTypeSel = $scope.accTypeOptions[i];
                    }
                }
                $timeout(function(){
                    $scope.ifsc.ifscCode = bankDtlsModel.getIfscCode();
                    if($scope.ifsc.ifscCode) {
                        $scope.branchName = bankDtlsModel.getBranchName();
                        $scope.branchAddress = bankDtlsModel.getBranchAddress();
                        $scope.showBranchDetails = true;
                    }
                }, 0);
            }
            
            // For Transact Module
            if($stateParams.key === TransactConstant.transact.Payment_Key) {
                savePreviousSelBankIfsc();
            }
            //For Paperless Module
            if(paperlessModel.paymentDtls.hasData) {
                savePreviousSelBankIfsc();
            }

            $scope.$on('continueClicked', function(event) {
                $scope.showBankError = false;
                $scope.showAccTypeError = false;

                if($scope.method.newAccountSel && $scope.method.newAccountSel.key === 'select') {
                    $scope.showBankError = true;
                }
                if($scope.type.accTypeSel && $scope.type.accTypeSel.key === 'accountType') {
                    $scope.showAccTypeError = true;
                }
                bankDtlsModel.setIsNewAccBankError($scope.showBankError);
                bankDtlsModel.setIsAccTypeError($scope.showAccTypeError);
            }); 
        }]
    };
};

fticNewAccountBankDetails.$inject = ['bankDtlsModel', 'transactModel', '$state', 'ifscModel', '$stateParams', 'authenticationService','TransactConstant', 'paperlessModel', '$timeout', 'paymentDetailsUtility'];
module.exports = fticNewAccountBankDetails;