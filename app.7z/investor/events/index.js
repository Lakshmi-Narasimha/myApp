/**
 *@ngdoc object
 *@name advisor.module:Events
 *@description
 * <p>
 * Calling the services those are for showing the pages
 * </p>
 * @project FTIC
 * @Date
 * @version 1
 * @author DEP DEE
 */



'use strict';
// Home View
module.exports = angular.module('investor.events', [])
    
    .factory('investorEvents', require('./investorEvents.service'));