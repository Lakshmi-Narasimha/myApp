define([
    'jquery',
    'lodash',
    'bootstrap-dialog',
    'app/application/router',
    'app/common/shadowLayer',
    'app/common/views/AbstractView',
    'app/application/app',
    'text!app/application/templates/Header.html'
], function ($, _, BootstrapDialog, Router, shadow, AbstractView, app, HeaderTemplate) {

    return AbstractView.extend({
        el: '#sem-header',
        template: _.template(HeaderTemplate),
        events: {
            'click #cs-obo-list li' : 'oboChanged',
            'click #redirectToHomePage': 'redirectToHomePage'
        },
        oboChanged: function (event) {
            const oboId = $(event.currentTarget).attr('id');
            let selObo = _.filter(app.oboAdvisorList,  (advisor) => {
                return advisor.get('formattedFmid') === oboId;
            })[0];
            selObo = selObo ? selObo.toJSON() : null;
            app.userInformation = selObo || app.userInformation;
            this.$('#clsel-obo-name').text(app.userInformation.fullName);

            if(window.location.href.indexOf("clientView") > -1) {
                this.showErrorDialogMsg();
            }else{
                Backbone.publishSubscribeEvents.trigger('oboChanged');
            }
        },
        render: function () {
            const data = {
                userName:  app.userInformation.fullName,
                oboUserList: app.oboAdvisorList || []
            }
            this.$el.html(this.template(data));

            $("#cs-obo-dropdown").on("hide.bs.dropdown", function(){
                shadow.hide({
                    parentElement: '#sem-app-primary-view',
                    zIndex: 1
                });
            });

            $("#cs-obo-dropdown").on("show.bs.dropdown", function(event){
                shadow.show({
                    parentElement: '#sem-app-primary-view',
                    zIndex: 2
                });
            });
        },
        redirectToHomePage: function(){
            Router.routeTo('clientSearchView');
        },
        showErrorDialogMsg: function() {
            BootstrapDialog.show({
                size: 'small',
                title: '<h4 class="modal-title">OBO disabled</h4>',
                closeByBackdrop: true,
                message: 'If you need to switch to another advisor return to Client search.',
                buttons: [
                    {
                        label: 'Cancel',
                        cssClass: 'btn btn-default',
                        action: function(dialog){
                            dialog.close();
                        }
                    },
                    {
                        label: 'Continue client search',
                        cssClass: 'btn btn-primary',
                        action: function(dialog){
                            Backbone.history.navigate('clientSearchView',true);
                            Router.routeTo('clientSearchView');
                            dialog.close();
                        }
                    }
                ],
                onshown: this.modalDialogShown,
                onhidden: this.modalDialogHidden
            });
        }
    });

});
