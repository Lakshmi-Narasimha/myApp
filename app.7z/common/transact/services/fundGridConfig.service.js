/**
 * @ngdoc service
 * @name Key value Grid Config Model
 * @requires MyInvestorConstant
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var fundGridConfigModel = function (fticLoggerMessage, loggerConstants, TransactConstant) {

    var _fundGridConfigObj = {};

    var accno = "";
    var statusTemplateModify = '<input type="radio" name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'
    /*var statusTemplateRenew = '<input type="radio" name="selectedfundList" ng-click="grid.appScope.$emit(\'selectFund\', row.entity)" class="pull-left"/>'*/
   
     _fundGridConfigObj[TransactConstant.modifySip.MODIFYSIP]  = [{ field: 'fund', displayName: '', width:"48",cellTemplate: statusTemplateModify, pinnedLeft:true},
       { field: 'fundOptionDesc', displayName: 'Fund', width:"200", enableSorting:false, pinnedLeft:true},
        { field: 'accountNumber', displayName: 'Account No.', width:"150", enableSorting:false},
        { field: 'sipStartDate', displayName: 'SIP Start Date', width:"163", enableSorting:false},
        { field: 'sipEndDate', displayName: 'SIP End Date', width:"127", enableSorting:false},
        { field: 'amount', displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon',width:"127", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"127", enableSorting:false},
        { field: 'stepUpAmount', displayName: 'Step-up', headerCellClass: 'fti-grid-rupeeIcon',width:"127", enableSorting:false}
    ];

    _/*fundGridConfigObj[TransactConstant.renewSip.RENEWSIP]  = [{ field: 'fund', displayName: '', width:"48",cellTemplate: statusTemplateRenew, pinnedLeft:true},
       { field: 'fundOptionDesc', displayName: 'Fund', width:"200", enableSorting:false, pinnedLeft:true},
        { field: 'accountNumber', displayName: 'Account No.', width:"150", enableSorting:false},
        { field: 'sipStartDate', displayName: 'SIP Start Date', width:"163", enableSorting:false},
        { field: 'sipEndDate', displayName: 'SIP End Date', width:"127", enableSorting:false},
        { field: 'amount', displayName: 'SIP Amount', headerCellClass: 'fti-grid-rupeeIcon',width:"127", enableSorting:false},
        { field: 'frequency', displayName: 'Frequency', width:"127", enableSorting:false},
        { field: 'sipStatusDesc', displayName: 'Status',width:"127", enableSorting:false}
    ];*/
    
    var fundGridConfigModel = {
        fundGridConfigObj: _fundGridConfigObj
    };
    return fundGridConfigModel;
};

fundGridConfigModel.$inject = ['fticLoggerMessage', 'loggerConstants', 'TransactConstant'];

module.exports = fundGridConfigModel;