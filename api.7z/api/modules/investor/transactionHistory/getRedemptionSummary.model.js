// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TransRedumptionSummaryModelSchema = new mongoose.Schema({
    RedumptionSummaryResp: {
        type: Array,
        "default": []
    }
});

var TransRedumptionSummaryModelLookUp = mongoose.model('TransRedumptionSummaryModelLookUp', TransRedumptionSummaryModelSchema);

var TransRedumptionSummaryModel = new TransRedumptionSummaryModelLookUp({
    /*RedumptionSummaryResp: {
        "redemptionSummary": [{
                "folioNo": "1111111",
                "modeOfHolding": "Joint",
                "holderDetails": [{
                    "name": "Shankar S",
                    "type": "Firstholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }, {
                    "name": "Shankar Narayan",
                    "type": "Secondholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }],
                "fundDetails": [{
                    "fundName": "Franklin India Smaller Companies Fund",
                    "accountNo": "127891981",
                    "totalRedemptionAmount": "2,000.00"
                }, {
                    "fundName": "Franklin India Prima Plus Fund",
                    "accountNo": "127891981",
                    "totalRedemptionAmount": "1,000.00"
                }]
            }, {
                "folioNo": "2222222",
                "modeOfHolding": "Joint",
                "holderDetails": [{
                    "name": "Shankar S",
                    "type": "Firstholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }, {
                    "name": "Shankar Narayan",
                    "type": "Secondholder",
                    "kycStatus": "KYC - Registered",
                    "pan": "ELKI1234EF"
                }],
                "fundDetails": [{
                    "fundName": "Franklin India Smaller Companies Fund",
                    "accountNo": "127891981",
                    "totalRedemptionAmount": "2,000.00"
                }, {
                    "fundName": "Franklin India Prima Plus Fund",
                    "accountNo": "127891981",
                    "totalRedemptionAmount": "1,000.00"
                }]
            }]
        }*/

    RedumptionSummaryResp: {
  "invTrxnSummary": [
    {
      "folioId": "14504452",
      "modeofHolding": "joint",
      "holders": {
        "firstHoldersName": "MUNIRA ABDI HARARWALA D AVASHIA SURESH PANJWANI",
        "secondHoldersName": "Kishan ram kiran",
        "thirdHoldersName": "HARARWALA D AVASHIA"
      },
      "rows": [        
        {
          "accountNo": "4529900835384",
          "amount": "6,000.01",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Templeton India Growth Fund - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "3049900835384",
          "amount": "17,612.33",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin Asian Equity Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "3059900835384",
          "amount": "51,152.46",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Ultra Short Bond Fund - Retail Plan - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "4739900835384",
          "amount": "6,000.01",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Flexi Cap Fund - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "4969900835384",
          "amount": "4,000.00",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Feeder - Franklin U S Opportunities Fund - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "1049900835384",
          "amount": "532,551.45",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Short Term Income Plan -  Retail Plan - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "4189900835384",
          "amount": "8,000.04",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Prima Plus - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "0369900835384",
          "amount": "81,751.33",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Prima Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "3879900835384",
          "amount": "3,991.79",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin Build India Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "2739900835384",
          "amount": "75,188.02",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India High Growth Companies Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "0069900835384",
          "amount": "60,149.84",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Bluechip Fund - Dividend",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "1949900835384",
          "amount": "185,389.47",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Government Securities Fund - Long Term Plan - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "4859900835384",
          "amount": "2,096,417.22",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Ultra Short Bond Fund Super Institutional Plan - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "2259900835384",
          "amount": "44,440.08",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Templeton India Equity Income Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "2199900835384",
          "amount": "10,025.00",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Smaller Companies Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "1709900835384",
          "amount": "134,469.95",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Templeton India Growth Fund - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "4809900835384",
          "amount": "7,500.00",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Templeton India Equity Income Fund - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "0379900835384",
          "amount": "46,114.78",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India Prima Plus - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        },
        {
          "accountNo": "4829900835384",
          "amount": "4,500.00",
          "benfStatus": "",
          "currentUnits": "",
          "currentValue": "",
          "destacno": "",
          "destfundesc": "",
          "familySolution": "No",
          "fundDesc": "Franklin India High Growth Companies Fund - Direct - Growth",
          "leinUnits": "",
          "leinUnitsValue": "",
          "nominee": "",
          "nomineePercent": "",
          "paymentOption": "",
          "postalReturn": "",
          "remarks": "",
          "trxnType": "",
          "ucFundDesc": "",
          "ucUnits": ""
        }
      ]
    }
  ]
}
});

TransRedumptionSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating TransRedumptionSummaryModelLookUp table, please contact admin...');
    } else {
        TransRedumptionSummaryModelLookUp.remove({}, function(err) {
            console.log('RedumptionSummaryModelLookUp collection removed');
            TransRedumptionSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating TransRedumptionSummaryModelLookUp table, please contact admin...');
                }
                console.log('TransRedumptionSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TransRedumptionSummaryModelLookUp;
