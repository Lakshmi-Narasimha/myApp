/**
 * @ngdoc property
 * @name kycAdditionalDetailsCtrl
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter


function kycAdditionalDetailsCtrl($scope,$state, ifscModel, transactModel, $stateParams, TransactConstant, transactEventConstants, investorRegistrationModel, toaster, paperlessModel, authenticationService, proceedToBuyDataFactory) {

    $scope.isFirstAccordianOpened = {};
    $scope.isFirstAccordianOpened.open = true;    
    $scope.config.fromState = $state.current.name;
    $scope.config.toState = '';
    $scope.isSmartSol = transactModel.getIsSmartSol();
    $scope.header.title = "KYC Additional Details";
    $scope.isInvestorLogged=authenticationService.isInvestorLoggedIn();
    var fatcaDetailsObj = {}, requestObject = {}, folioId = "";
    if(authenticationService.isInvestorLoggedIn()) {
        if(transactModel.getTransactType() === TransactConstant.sip.SIP || transactModel.getTransactType() === TransactConstant.sip.FUNDSIP) {
            $scope.config.toState = 'invTransact.base.sip';
        }
    } else {
        if(transactModel.getTransactType() === TransactConstant.buy.BUY || transactModel.getTransactType() === TransactConstant.buy.BUYFUND) {
            $scope.config.toState = 'transact.base.buy';
        } else if(transactModel.getTransactType() === TransactConstant.sip.SIP || transactModel.getTransactType() === TransactConstant.sip.FUNDSIP) {
            $scope.config.toState = 'transact.base.sip';
        }
    }

    var _holders = transactModel.getInstantKyc() || (transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().holders : '');
    if($scope.isInvestorLogged) {
        $scope.holders = proceedToBuyDataFactory.filterFolioDetails(_holders);
    } else {
        $scope.holders = _holders;
    }
    if(transactModel.getInvestorDetails() && !transactModel.getInstantKyc()) {        
        for(var i=0; i<$scope.holders.length; i++) {
            $scope.holders[i].Title = (i === 0) ? 'First Holder Details' : (i === 1 ? 'Second Holder Details' : 'Third Holder Details');
        }
    }

    if($scope.isSmartSol && transactModel.isNewInvestor){
        $scope.holders = paperlessModel.invDetails.getFactaDetails();
    }
    angular.forEach($scope.holders,function(obj,k){        
        if(obj.name == null && obj.type == 'Firstholder') {
            var dtls = {
                custName: '',
                pan:'',
                emailId:'',
                mobile:'',
                holders : [{
                    name : ''
                },
                {
                    name : ''
                },
                {
                    name : ''
                }]
            };
            transactModel.setInvestorDetails(dtls);            
        }
    });


    function updateInvSuccess(data){

        $scope.$emit('payment_details');
        if(transactModel.getIsSmartSol()) {
            if($scope.isInvestorLogged) {
                $state.go('smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS');
            } else {
                $state.go('smartSol.planSmartSolution.paymentdetailsSS');
            }
        } else {
            $scope.$emit('NAVIGATE_TO_TRANSACT', {key: TransactConstant.transact.Payment_Key});
        }
    }
    function updateInvFailure(data){
        console.log('UpdateInvestorDetails Failed');
        var resetKYCDetailsArray = [];
        $scope.kycAdtnlDtlsForm.fatcaArray = resetKYCDetailsArray;
        transactModel.setKycAddnlDetails(resetKYCDetailsArray);
        toaster.error(data.data[0].errorDescription);
    }

    $scope.continue = function() {
        if($scope.kycAdtnlDtlsForm.$valid){ 
            $scope.$emit('kycAdntDtls');
            if(transactModel.isNewInvestor || transactModel.getIsNewFolio()){
                folioId = investorRegistrationModel.getNewInvestorFolioId();
            }else{
                folioId = transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().folioId : '';
            }
            requestObject = investorRegistrationModel.postKycAddtnlDetails(folioId);
            investorRegistrationModel.postUpdatedKycAddtnlDetails(requestObject).then(updateInvSuccess, updateInvFailure);                      
        }
    };

    $scope.cancel = function() {
        transactModel.openFundTab = false;
    	$stateParams.key = TransactConstant.transact.Fund_Key;        
    	$scope.$emit('NAVIGATE_TO_TRANSACT', {key: TransactConstant.transact.Fund_Key});
    };
}

kycAdditionalDetailsCtrl.$inject = ['$scope','$state', 'ifscModel', 'transactModel', '$stateParams', 'TransactConstant', 'transactEventConstants', 'investorRegistrationModel', 'toaster', 'paperlessModel', 'authenticationService', 'proceedToBuyDataFactory'];
module.exports = kycAdditionalDetailsCtrl;