define([
  'jquery',
  'underscore',
  'backbone',
  'appcommon/analytics',
  'text!appmodules/nav/app/templates/navcontainer.html'
], function ($, _, Backbone, Analytics, NavContainerTemplate) {
    var navcontview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        initialize: function () {
        },
        render: function () {
            var compiledTemplate = _.template(NavContainerTemplate);
            Analytics.analytics.processNavSubRouteChangeEvent('welcomeGetStarted');
            this.$el.html(compiledTemplate);
        }
    });
    return navcontview;
});