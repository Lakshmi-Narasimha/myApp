
define(
        ['text!appmodules/ncst/app/templates/incomeInvestment.html',
            'appmodules/ncst/app/js/lib/validate-4.2',
            'appmodules/ncst/app/js/utils', 'config', 'appmodules/ncst/app/js/models/model-new-client', 'appmodules/ncst/app/js/models/model-address-entry', 'appmodules/ncst/app/js/models/model-client', 'appmodules/ncst/app/data/country-list', 'appcommon/globalcontext', 'appcommon/analytics', 'components/js/views/CheckBoxView', 'components/js/views/RadioButtonView', 'appcommon/abstractview', 'appcommon/constants'],
        function (Template, Validator, Utils, Config, NewClientModel, AddressModel, ClientModel, DropdownOptions, GlobalContext, Analytics, CheckBoxView, RadioButtonView, AbstractView, constants) {
            var BASE_URL = Config.odataServiceName;
            var ClientDetailsModel = ClientModel.get('details'), EmploymentModel = ClientModel.get('employement'), IncomeModel = ClientModel.get('income'), ClientInfoModel = ClientModel.get('clientInfo');
           
	            var investExpCollection = [], preSelectedYear = null, preSelectedYearDesc = null, preSelectedTrans = null, preSelectedTransDesc = null, preSelectedYearMapCode = null, preSelectedTransMapCode = null, sourceIncomeCollection = [], assetTypesHeldCollection = [], doesClientHaveAssetsVal = null;
            var _validateClientDataMapping = {
                clientInfo: {
                    honorific: {
                        "Dr": "Dr",
                        "Hon": "Hon",
                        "Miss": "Miss",
                        "Mr": "Mr",
                        "Mrs": "Mrs",
                        "Ms": "Ms",
                        "Prof": "Prof",
                        "Rev": "Rev",
                        "Sir": "Sir"
                    },
                    suffix: {
                        "i": "I",
                        "ii": "II",
                        "iii": "III",
                        "iv": "IV",
                        "v": "V",
                        "Jr": "Jr",
                        "Sr": "Sr"
                    },
                    citizenship: {
                        'U.S.': 'U.S.',
                        'Resident Alien': 'Resident Alien',
                        'Non-Resident Alien': 'Non-Resident Alien'
                    },
                    entityRole: {
                        "Corporation - C-Corp": "1C",
                        "Corporation - S-Corp": "1S",
                        "Estate": "09",
                        "Government entity": "04",
                        "Irrevocable trust": "08",
                        "LLP": "10",
                        "LLC - C-Corp": "6C",
                        "LLC - S-Corp": "6S",
                        "Non-Profit": "05",
                        "Partnership": "02",
                        "Revocable trust": "07"
                    }
                },
                clientDetails: {
                    maritalStatus: {
                        'Divorced': 'D',
                        'Married': 'M',
                        'Single': 'S',
                        'Widowed': 'W'

                    }

                },
                clientEmplymnt: {},
                clientIncome: {
                    taxBracket: {
                        "0%": "00.00",
                        "10%": "10.00",
                        "15%": "15.00",
                        "25%": "25.00",
                        "28% and over": "28.00"
                    }
                }
            };
            // error handling based on codes and redirecting to corresponding error page
            var handleServerErrors = function(errorList) {
                var _serverErrCodes, _errorCodeList, _commonErrors, errMessage = "", _systemUnavailableErrorCodes = ["15829"], _isSytemUnavailableError = false;
                _serverErrCodes = ["15824", "15508", "15657", "15588", "15583", "15509", "15510", "15521", "9", "10", "21", "15666"];
                _errorCodeList = _.pluck(_.filter(errorList, function (obj) {
                    if (_systemUnavailableErrorCodes.indexOf(obj.explCd) > -1) {
                        _isSytemUnavailableError = true;
                    }
                    return _.contains(_serverErrCodes, obj.explCd);
                }), 'explCd');
                if (_isSytemUnavailableError) {
                    Utils.showSystemUnavailableMsg("6", "income", "200");
                    return
                }
                _commonErrors = _.reject(errorList, function (obj) {
                    return _.contains(_serverErrCodes, obj.explCd);
                });
                ClientModel.set('serverErrorCodes', _errorCodeList);
                var _errorCodeStepMap = {
                    15824:[1],
                    15508: [1],
                    15657: [1],
                    15666: [1],
                    15588: [2, 3],
                    15583: [2, 3],
                    15509:[4],
                    15510:[4],
                    15521:[4],
                    9:[4],
                    10:[4],
                    21:[4],
                };
                _.each(_errorCodeList, function(value) {
                    _.each(_errorCodeStepMap[value], function(stepNo) {
                        $("#ncst-header .step" + stepNo).removeClass("finished active").addClass("pending");
                    });
                });
                if (_commonErrors.length) {
                    errMessage = Validator.errorMsg.commonErrMsg200;
                    BootstrapDialog.alert(errMessage, function(result) {
                        $("#ncst-header .ncst-step.pending:first").trigger("click")
                    }, "Incomplete fields");
                } else {
                    $("#ncst-header .ncst-step.pending:first").trigger("click");
                }

            };
            var incomeView = AbstractView.extend({
            			el: '#ncst-app',	
            			investmentCheckboxViewName: 'investmentCheckboxViewName',
            			assetTypeCheckboxViewName: 'assetTypeCheckboxViewName',
            			doesClientHaveAssetsViewName: 'doesClientHaveAssetsViewName',
            			sourceOfIncomeCheckViewName: 'sourceOfIncomeCheckViewName',
                        txtVal: '',
                        statsTemplate: _.template(Template),
                        initialize: function () {
                        	AbstractView.prototype.initialize.apply(this, arguments);
                            this.$main = this.$('#client-info');
                        },
                        events: {
                            'click #back-to-step5,#m-back-to-step5': 'navigateToStep5',
                            'click #step6-next-button,#m-step6-next-button': 'navigateToStep7',
                            'keypress  #income-zipcode': 'validateZipCodeLength',
                            'change input[type="checkbox"]': 'toggleCheckboxClassActive',
                            'change input[name="empAddressType"]': 'handleEmpAddressTypeChange',
                            'change #income-country-list': 'empHandleProvinceForCanada',
                            'click #none-opt': 'handleNoneOptionClick',
                            'click .prod-opt': 'handleOtherOptionClick',
                            'keypress .us-zipcode, #income-indi-annual,#income-indi-net, #income-indi-liquid, .assetTypeHeldInput': 'numValidator',
                            'focus #income-indi-annual,#income-indi-net,#income-indi-liquid, .assetTypeHeldInput': 'formatCurrencyToNormal',
                            'blur #income-indi-annual, #income-indi-net, #income-indi-liquid, .assetTypeHeldInput': 'formatCurrency',
                            'blur .assetTypeHeldInput': 'storeValFrmAssetTypeHeldAwayInput',
                            "click .sad-text.sad-step6": "handleSAD",
							"click .has-invest-exp": "toggleInvestmentExp"
						},
					handleSAD:function(){
					    Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
					    this.storeValFrmAssetTypeHeldAwayInput();
						this.model.setModel(investExpCollection, sourceIncomeCollection, assetTypesHeldCollection, doesClientHaveAssetsVal);
						Utils.lockForm();
						ClientModel.createDraft().done(function(response){
							Utils.unlockForm();
							ClientModel.showDraftSaveSuccesMessage(response);
						}).fail(function(error){
							Utils.unlockForm();
							Utils.showDraftSaveErrorMessage();
						});
					},
					render: function () {
                        var _data = ClientModel.toJSON();
                        _data.client = ClientModel;
                        _data.isMobile = Utils.isMobile();
                        this.$main.html(this.statsTemplate(_data));
                        this.initializeElementVars();


						if (_data.income != null && _data.income.get('incomeSourcePrimary') != "") {
							this.renderSourceOfIncomeCheckbox(_data.income.get('incomeSourcePrimary'));
						} else {
							this.renderSourceOfIncomeCheckbox(null);
						}

                        if (_data.income != null && _data.income.get('investmentExpToggle') != "") {
                            if (_data.income.get('investmentExpToggle') == "Yes") {
                            	$('#invest-exp-container').removeClass('hidden');
                            	var investExpModelData = _data.income.attributes.productExperienceVal;
                            	this.renderInvestmentExpCheckbox(investExpModelData);
                            }
                        }

                        if (_data.income != null && _data.income.get('doesClientHaveAssets') != "") {
                        	var clientHaveAssetsRadioModelData = _data.income.attributes.doesClientHaveAssets, clientHaveAssetsRadioModelVal ="",
                        		clientHaveAssetsOptionModelData = _data.income.attributes.assetsTypeHeldVal;
                        	if (clientHaveAssetsRadioModelData == 'A') {
                        		clientHaveAssetsRadioModelVal = "Yes"
                        	} else if (clientHaveAssetsRadioModelData == 'B') {
                        		clientHaveAssetsRadioModelVal = "Client declines to disclose"
                        	} else if (clientHaveAssetsRadioModelData == 'C') {
                        		clientHaveAssetsRadioModelVal = "No"
                        	}
                        	this.renderDoesClientHaveAssetsRadioBtns(clientHaveAssetsRadioModelVal, clientHaveAssetsOptionModelData);
                        } else {
                            this.renderDoesClientHaveAssetsRadioBtns();
                        }

                        if (_data.income != null && _data.income.get('doesClientHaveAssets') != "") {
                            if (_data.income.get('doesClientHaveAssets') == "Yes") {
                                $('#asset-type-held').removeClass('hidden');
                                var assetTypeHeldModelData = _data.income.attributes.assetsTypeHeldVal;
                                this.renderAssetTypeHeldChkBoxes(assetTypeHeldModelData);
                            }
                        }
                    },
            		renderSourceOfIncomeCheckbox: function (incomeSourceData) {
            			var self = this, sourceOfIncomeCheckView, componentId = "source-of-income-checkbox", incomeConstList = constants.sortedSourceOfIncomeList;
            			sourceOfIncomeCheckView = new CheckBoxView({
							el: $('#' +componentId),
							items: incomeConstList,
							sideCompIndex: 0
	            		});
            			if (incomeSourceData && incomeSourceData != null) {
							sourceOfIncomeCheckView.selectedItems = incomeSourceData;
            			}
            			sourceOfIncomeCheckView.itemSelectionComplete = function (selectedItems, itemId) {
            				if (selectedItems.length > 0 && selectedItems.length < 4) {
            					if (selectedItems.length > 0 && selectedItems[0].displayOrder == '9' && selectedItems[0].description == "None") {
            						sourceIncomeCollection = selectedItems = _.without(selectedItems, selectedItems[0]);
            					} else {
            					_.filter(selectedItems, function (item) {
            						if(item.description == "None" && item.displayOrder == '9') {
            							sourceIncomeCollection = selectedItems =[item];
            						} else {
										sourceIncomeCollection = selectedItems;
            					}
            					});
								}
								sourceOfIncomeCheckView.selectedItems = selectedItems;
            					sourceOfIncomeCheckView.reRender();
            					sourceIncomeCollection = selectedItems;
            				}

            				if (selectedItems.length > 3) {
            					selectedItems = _.filter(selectedItems, function (item) {
            						return item.displayOrder != (itemId + 1);
            					});
            					sourceOfIncomeCheckView.selectedItems = selectedItems;
            					sourceOfIncomeCheckView.reRender();
            					sourceIncomeCollection = selectedItems;
            				} else { sourceIncomeCollection = selectedItems;
            				}
					    };
						this.addNestedView(this.sourceOfIncomeCheckViewName, sourceOfIncomeCheckView);
						sourceOfIncomeCheckView.render();                       
                        },
                    initializeElementVars: function () {
                        this.$assetTypeHeld = this.$('#asset-type-held');
                    },
						toggleInvestmentExp: function (obj) {
							var _$clickedButton = $(obj.currentTarget);
							investExpCollection = [];
            				if (_$clickedButton.hasClass('active')) {
            					return false;
            				} else {
            					$('.has-invest-exp').removeClass('active');
            					_$clickedButton.addClass('active');
            				}
            				if (_$clickedButton.val() == "Yes") {            					
            					$('#invest-exp-container').removeClass('hidden');            					
            					this.renderInvestmentExpCheckbox(investExpCollection);
            				} else {
            					$('#invest-exp-container').addClass('hidden');
            					var investConstItems = constants.sortedInvestmentExpList;
            					_.each(investConstItems, function (list, key) {
            						list["years"] = { defaultValue: "0 years", description: "", mapCode: "A" };
            						list["transaction"] = { defaultValue: "0 annual transactions", description: "", mapCode: " " };
            					});
            					investExpCollection = investConstItems;
            					preSelectedYear = null; preSelectedYearDesc = null; preSelectedTrans = null; preSelectedTransDesc = null, preSelectedYearMapCode = null, preSelectedTransMapCode = null;
							}
						},
						renderInvestmentExpCheckbox: function (investExpModelData) {
							var self = this, investmentCheckboxView, componentId = "investment-exp-checkbox", investConstItems = constants.sortedInvestmentExpList;
							investmentCheckboxView = new CheckBoxView({
								el: $('#' + componentId),
								items: investConstItems,
								sideCompIndex: 4
							});
							if (investExpModelData != "" && investExpModelData.length > 0) {
								var selectedList = [];
								_.each(investExpModelData, function (investList) {
									_.find(investConstItems, function (investConstList) {
										if (investList.years.mapCode == "A") {
										}else if (investConstList.code == investList.code) {
											selectedList.push(investConstList);
										}
									});
								});
								investmentCheckboxView.selectedItems = selectedList;
							}
							investmentCheckboxView.itemSelectionComplete = function (selectedItem, itemId) {
								self.captureInvestmentSelection(selectedItem, componentId, itemId, true);
            				};
							this.addNestedView(this.investmentCheckboxViewName, investmentCheckboxView);
							investmentCheckboxView.render();

							if (investExpModelData != null || investExpModelData.length > 0) {
								_.each(investExpModelData, function (list) {
									if (list.years.mapCode == "A") {
									} else {
									self.captureInvestmentSelection([list], componentId, (list.displayOrder - 1), false);
									}
								});
							}
            			},
            			captureInvestmentSelection: function (selectedItem, componentId, itemId, dataFromModelFlag) {
            				var activeComp = $('#' + itemId + '-' + componentId),
								activeParent = activeComp.parents().eq(1),
            					checkFlag = activeComp.is(":checked"),
								sideComp = componentId + '-sidecontainer-' + itemId,
							    transTitle = "Avg. number of buy and sell trades per year",
            			        investConstItems = constants.sortedInvestmentExpList;
							
            				if (investConstItems[itemId].mapCode == "D") {
            			        transTitle = transTitle + " (not including DRIP arrangements)";
            			    }
            			    else if (investConstItems[itemId].mapCode == "B") {
            			        transTitle = transTitle + " (not including systematic arrangements)";
            			    }

            				if (checkFlag || dataFromModelFlag == false) {
            					this.renderInvExpTitle(sideComp);
            					this.renderInvestYearRadio(itemId, componentId, selectedItem);
            					this.renderTransTitle(sideComp, transTitle);
            					this.renderTransYearRadio(itemId, componentId, selectedItem);
            					this.addCSSClasses(activeComp, activeParent);
            					if (dataFromModelFlag) {
            						this.appendSelectedInvestExp(selectedItem, componentId, itemId, dataFromModelFlag);
            					} else {
            						var componentYearName = 'select-choice-' + componentId + '-sidecontainer-' + itemId + '2';
            						preSelectedYearDescTemp = selectedItem[0].years.description;
            						$('input:radio[name="' + componentYearName + '"]').filter('[value="' + preSelectedYearDescTemp + '"]').attr('checked', true);
            						var componentTransName = 'select-choice-' + componentId + '-sidecontainer-' + itemId + '4';
            						preSelectedTransDescTemp = selectedItem[0].transaction.description;
            						$('input:radio[name="' + componentTransName + '"]').filter('[value="' + preSelectedTransDescTemp + '"]').attr('checked', true);
            					}
            				} else {
            					_.filter(investExpCollection, function (list, key) {
            						if (list.code == (itemId + 1)) { 
            							investExpCollection.splice(key, 1);
            						}
            					});
            					this.clearInvestExpModel(investExpCollection);
            					this.removeCSSClasses(activeComp, activeParent);
            					for (i = 1; i <= 4; i++) {
            						$('div[ampf-radio-buttons="' + sideComp + i + '"]').remove();
            					}
            				}            				
            			},
            			clearInvestExpModel: function (investExpCollection) {
            				if (investExpCollection.length == 0) {
								preSelectedYear = null; preSelectedYearDesc = null; preSelectedTrans = null; preSelectedTransDesc = null, preSelectedYearMapCode = null, preSelectedTransMapCode = null;
            				}
            			},
            			appendSelectedInvestExp: function (selectedItem, componentId, index, dataFromModelFlag) {
            				var items = [{
            					"code": "",
            					"displayOrder": "",
            					"description": "",
            					"mapCode": "",
            					"years": {
            						"defaultValue": "0 years",
            						"selectedValue": "",
            						"description": "",
            						"mapCode": ""
            					},
            					"transaction": {
            						"defaultValue": "0 annual transactions",
            						"selectedValue": "",
            						"description": "",
            						"mapCode": ""
            					}
            				}];

            				items[0].code = selectedItem[(selectedItem.length - 1)].code;
            				items[0].description = selectedItem[(selectedItem.length - 1)].description;
            				items[0].displayOrder = selectedItem[(selectedItem.length - 1)].displayOrder;
            				items[0].mapCode = selectedItem[(selectedItem.length - 1)].mapCode;

            				if ((preSelectedYear == null || preSelectedYear == "") && investExpCollection.length > 0) {
            					preSelectedYear = investExpCollection[0].years.selectedValue;
            					preSelectedYearDesc = investExpCollection[0].years.description;
								preSelectedYearMapCode = investExpCollection[0].years.mapCode;
            				}
            				if ((preSelectedYear != null || preSelectedYear != "") && investExpCollection.length > 0) {
            					var componentName = 'select-choice-' + componentId + '-sidecontainer-' + index + '2';
            					items[0].years.selectedValue = preSelectedYear;
            					items[0].years.description = preSelectedYearDesc;
								items[0].years.mapCode = preSelectedYearMapCode;
								$('input:radio[name="' + componentName + '"]').filter('[value="' + preSelectedYearDesc + '"]').attr('checked', true);

								for (var key in this.nestedViews) {
								    var _that = this;
								    var nestedViewId = this.nestedViews[key].el.id;
								    if (nestedViewId == componentId + '-sidecontainer-' + index + '2') {								        
								            $.each(constants.sortedInvExpYearRadioList, function (key1) {
								                if (constants.sortedInvExpYearRadioList[key1].description == preSelectedYearDesc) {
								                    _that.nestedViews[key].selectedItem = constants.sortedInvExpYearRadioList[key1];
								                }
								            });								        
								    }
								}
            				}

            				if ((preSelectedTrans == null || preSelectedTrans == "") && investExpCollection.length > 0) {
            					preSelectedTrans = investExpCollection[0].transaction.selectedValue;
            					preSelectedTransDesc = investExpCollection[0].transaction.description;
								preSelectedTransMapCode = investExpCollection[0].transaction.mapCode;
            				}
            				if ((preSelectedTrans != null || preSelectedTrans != "") && investExpCollection.length > 0) {
            					var componentName = 'select-choice-' + componentId + '-sidecontainer-' + index + '4';
            					items[0].transaction.selectedValue = preSelectedTrans;
            					items[0].transaction.description = preSelectedTransDesc;
								items[0].transaction.mapCode = preSelectedTransMapCode;
								$('input:radio[name="' + componentName + '"]').filter('[value="' + preSelectedTransDesc + '"]').attr('checked', true);

								for (var key in this.nestedViews) {
								    var _that = this;
								    var nestedViewId = this.nestedViews[key].el.id;
								    if (nestedViewId == componentId + '-sidecontainer-' + index + '4') {
								        $.each(constants.sortedNoOfTransRadioList, function (key1) {
								            if (constants.sortedNoOfTransRadioList[key1].description == preSelectedTransDesc) {
								                _that.nestedViews[key].selectedItem = constants.sortedNoOfTransRadioList[key1];
								            }
								        });
								    }
								}

            				}
            				var itemCode = items[0].code;
            				investExpCollection = _.filter(investExpCollection, function (obj) {
            					if (!(obj.code == itemCode)) return obj;
            				});
            					investExpCollection.push(items);
            					investExpCollection = _.flatten(investExpCollection);
            			},
            			addCSSClasses: function (activeComp, activeParent) {
            				activeParent.find('div.radio-group-conatiner').addClass('no-ui-bg');
            				activeComp.parent().addClass('custom-radio-labelUI');
            				activeParent.addClass('custom-chkbox-width');
            				activeParent.find('div.sideComp-container').addClass('sideComp-divUI');
            			},
            			removeCSSClasses: function (activeComp, activeParent) {
            				activeComp.parent().removeClass("custom-radio-labelUI");
            				activeParent.removeClass('custom-chkbox-width');
            				activeParent.find('div.sideComp-container').removeClass('sideComp-divUI');
            			},

            			//renderOpenDivTag: function (sideComp) {
            			//    var html = sideComp + '1';
            			//    $('#' + html).html('<div class="pt-pad-lt-2" ampf-radio-buttons-section="' + html + '">Investment experience</div>');
            			//},
            			//renderCloseDivTag: function (sideComp) {
            			//    var html = sideComp + '3';
            			//    $('#' + html).html('<div class="pt-pad-btm-5px pt-pad-top-10px" ampf-radio-buttons="' + html + '">Number of transactions per year</div>');
            			//},

            			renderInvExpTitle: function (sideComp) {
            				var html = sideComp + '1';
            				var investExpPop = "<i id='invest-exp-info-popup' class='icon-info info-popup' data-toggle='popover' title='Investment experience'" +
                                                " data-content=\"<p class='info-popup'> Investment experience is cumulative, not the number of years since the first purchase.</p> " +
                                                "<p>Ex: If client purchased options actively in 2007 and 2008 but hasn\'t since that time = 2 years.</p> " +
                                                "<p>If years of experience has not crossed the minimum of the range, select the lower range, with the exception of anything greater than none falling into 1-2 years.</p> " +
                                                "<p>Ex: 8 months = 1-2 years <br/> 2.5 years = 1-2 years <br/> 5.5 years = 3-5 years  </p> " +
                                                "\" > &nbsp; </i> ";
            			    $('#' + html).html('<div class="pt-pad-btm-5px" ampf-radio-buttons="' + html + '">Investment experience ' + investExpPop + ' </div>');            			   
            			    $("#ncst-user-home-view").invokeInfoPopup();            				
            			},
            			renderTransTitle: function (sideComp, transTitle) {
            				var html = sideComp + '3';
            				$('#' + html).html('<div class="pt-pad-btm-5px pt-pad-top-10px" ampf-radio-buttons="' + html + '">' + transTitle + '</div>');
            			},
            			renderInvestYearRadio: function (index, invComponentId, selectedInvExpItem) {
            			    var radioButtonsView, self = this;
            			    radioButtonsView = new RadioButtonView({
            			        el: self.$('#' + invComponentId + '-sidecontainer-' + index + '2'),
            			        items: constants.sortedInvExpYearRadioList
            			    });

            			    if (selectedInvExpItem && selectedInvExpItem.length > 0 && selectedInvExpItem[0].years) {
            			        $.each(constants.sortedInvExpYearRadioList, function (key) {
            			            if (constants.sortedInvExpYearRadioList[key].description == selectedInvExpItem[0].years.description) {
            			                radioButtonsView.selectedItem = constants.sortedInvExpYearRadioList[key];
            			            }
            			        });
            			}
            				radioButtonsView.itemSelectionComplete = function (selectedItem) {
            					self.captureInvestYearRadio(selectedItem, index);
            			};
            				testRadioBtnViewName = 'testRadioBtnViewName' + index + '1';
            				this.addNestedView(testRadioBtnViewName, radioButtonsView);
            				radioButtonsView.render();
            			},
            			captureInvestYearRadio: function (selectedItem, index) { 
            				_.filter(investExpCollection, function (list) {
            					if (list.code == (index + 1)) { 
            						list.years.selectedValue = selectedItem.code;
            						list.years.description = selectedItem.description;
									list.years.mapCode = selectedItem.mapCode;
            					}
            				});
            			},
            			renderTransYearRadio: function (index, invComponentId, selectedTransYrsItem) {
            				var radioButtonsView, self = this;
            				radioButtonsView = new RadioButtonView({
            					el: self.$('#' + invComponentId + '-sidecontainer-' + index + '4'),
            					items: constants.sortedNoOfTransRadioList
            				});

                            if (selectedTransYrsItem && selectedTransYrsItem.length > 0 && selectedTransYrsItem[0].transaction) {
                                $.each(constants.sortedNoOfTransRadioList, function (key) {
                                    if (constants.sortedNoOfTransRadioList[key].description == selectedTransYrsItem[0].transaction.description) {
                                        radioButtonsView.selectedItem = constants.sortedNoOfTransRadioList[key];
                                    }
                                });
            				}
            				radioButtonsView.itemSelectionComplete = function (selectedItem) {
            					self.captureTransYearRadio(selectedItem, index);
            				};
            				testRadioBtnViewName = 'testRadioBtnViewName' + index + '2';
            				this.addNestedView(testRadioBtnViewName, radioButtonsView);
            				radioButtonsView.render();
            			},
            			captureTransYearRadio: function (selectedItem, index) {
            				_.filter(investExpCollection, function (list) {
            					if (list.code == (index + 1)) { 
            						list.transaction.selectedValue = selectedItem.code;
            						list.transaction.description = selectedItem.description;
									list.transaction.mapCode = selectedItem.mapCode;
            					}
            				});
            			},
            			renderDoesClientHaveAssetsRadioBtns: function (clientHaveAssetsRadioModelData, clientHaveAssetsOptionModelData) {
            			    var self = this, componentId = "does-client-have-assets-radiobuttons", radioButtonsView, assetsConstItems = constants.sortedDoesClientHaveAssetsList;
            			    
            			    radioButtonsView = new RadioButtonView({
            			        el: self.$('#' + componentId),
            			        items: assetsConstItems
            			    });

            			    if (clientHaveAssetsRadioModelData != "") {
            			        _.find(assetsConstItems, function (assetsConstList) {
            			            if (assetsConstList.description == clientHaveAssetsRadioModelData) {
            			                radioButtonsView.selectedItem = assetsConstList;
            			            }
            			        });
            			    }

            			    radioButtonsView.itemSelectionComplete = function (selectedItem, index) {
            			    	self.captureDoesClientHasAssetsRadio(selectedItem, index, clientHaveAssetsOptionModelData);
            			    };

            			    this.addNestedView(this.doesClientHaveAssetsViewName, radioButtonsView);
            			    radioButtonsView.render();
            			},
            			captureDoesClientHasAssetsRadio: function (selectedItem, index, clientHaveAssetsOptionModelData) {
            				if (selectedItem.description == "Yes") {
            					doesClientHaveAssetsVal = 'A';
            				} else if (selectedItem.description == "No") {
								doesClientHaveAssetsVal = 'C';
            				} else {
								doesClientHaveAssetsVal = 'B';
            				}
            			    if (selectedItem.code == 'A') {
            			        this.$assetTypeHeld.removeClass('error hidden');
            			        this.renderAssetTypeHeldChkBoxes(clientHaveAssetsOptionModelData);
            			    } else {
            			        this.$assetTypeHeld.addClass('hidden');
            			        assetTypesHeldCollection.length = 0;
            			    }
            			},
            			renderAssetTypeHeldChkBoxes: function (assetTypeHeldModelData) {
            			    var self = this, assetTypeCheckboxView, componentId = "asset-type-held-chkboxes", assetTypeConstItems = constants.sortedAssetTypeHeldList;
            			    assetTypeCheckboxView = new CheckBoxView({
            			        el: $('#' + componentId),
            			        items: assetTypeConstItems,
            			        sideCompIndex: 1
            			    });
            			    if (assetTypeHeldModelData != "" && assetTypeHeldModelData.length > 0) {
            			        var selectedList = [];
            			        _.each(assetTypeHeldModelData, function (assetTypeList) {
            			            _.find(assetTypeConstItems, function (assetTypeConstList) {
            			            	if (assetTypeConstList.code == assetTypeList.code) {
            			            		if (assetTypeList.assetVal != "0") {
            			            			selectedList.push(assetTypeConstList);
            			            		}
            			                }
            			            });
            			        });
            			        assetTypeCheckboxView.selectedItems = selectedList;
            			    }
            			    assetTypeCheckboxView.itemSelectionComplete = function (selectedItem, itemId) {
            			        self.captureAssetTypeHeldSelection(selectedItem, componentId, itemId, true);
            			    };
            			    this.addNestedView(this.assetTypeCheckboxViewName, assetTypeCheckboxView);
            			    assetTypeCheckboxView.render();

            			    if (assetTypeHeldModelData != null || assetTypeHeldModelData.length > 0) {
            			    	_.each(assetTypeHeldModelData, function (list) {
            			    		if (list.assetVal != "0") {
            			    			self.captureAssetTypeHeldSelection([list], componentId, (list.displayOrder - 1), false);
            			    		}            			            
            			        });
            			    }
            			},
            			captureAssetTypeHeldSelection: function (selectedItem, componentId, itemId, dataFromModelFlag) {
            			    var activeComp = $('#' + itemId + '-' + componentId),
								activeParent = activeComp.parents().eq(1),
            					checkFlag = activeComp.is(":checked"),
								sideComp = componentId + '-sidecontainer-' + itemId;
            			    var id = componentId + '-input-' + itemId;

            			    if (checkFlag || dataFromModelFlag == false) {
            			        this.renderAssetTypeHeldInputBox(itemId, componentId);
            			        this.addCSSClasses(activeComp, activeParent);
            			        if (dataFromModelFlag) {
            			            this.appendSelectedAssetType(selectedItem, componentId, itemId, dataFromModelFlag);
            			        } else {
            			            $('input#' + id).val(selectedItem[0].assetVal);
            			        }
            			    } else {
            			        _.filter(assetTypesHeldCollection, function (list, key) {
            			            if (list.code == (itemId + 1)) {
            			                assetTypesHeldCollection.splice(key, 1);
            			            }
            			        });
            			        this.removeCSSClasses(activeComp, activeParent);
            			        $("#" + componentId + "-sidecontainer-" + itemId + "1").empty();
            			    }
            			},
            			renderAssetTypeHeldInputBox: function (index, componentId) {
            			    var radioButtonsView, self = this;
            			    var inputBoxViewId = self.$('#' + componentId + '-sidecontainer-' + index + '1');
            			    var txtornumber = Utils.isMobile() ? 'tel' : 'text';
            			    var inputBoxViewHTML = '<label class="error hidden margin-left-16">Incomplete required field.</label><div><label class="field-label float-left dollar-margin pt-h4 pt-pad-lt-zero">$</label><input type="' + txtornumber + '" id="' + componentId + '-input-' + index + '" maxlength="19" data-max-maxlength="19" data-min-maxlength="15" class="form-control comma-number width-195px maxlength pt-h5 needed required assetTypeHeldInput" value=""><span class="help-block inc-help-field pt-h7 clear-none">Whole numbers only.</span></div>';
            			    $('#' + componentId + '-sidecontainer-' + index + '1').html(inputBoxViewHTML);
            			},
            			appendSelectedAssetType: function (selectedItem, componentId, index, dataFromModelFlag) {
            			    var items = [{
            			        "code": "",
            			        "displayOrder": "",
            			        "description": "",
            			        "mapCode": "",
            			        "assetVal": ""
            			    }];

            			    items[0].code = selectedItem[(selectedItem.length - 1)].code;
            			    items[0].description = selectedItem[(selectedItem.length - 1)].description;
            			    items[0].displayOrder = selectedItem[(selectedItem.length - 1)].displayOrder;
            			    items[0].mapCode = selectedItem[(selectedItem.length - 1)].mapCode;

            			    if (assetTypesHeldCollection.length > 0) {
            			        items[0].assetVal = assetTypesHeldCollection[0].assetVal;
            			    }

            			    assetTypesHeldCollection.push(items);
            			    assetTypesHeldCollection = _.flatten(assetTypesHeldCollection);
            			},
            			formatCurrencyToNormal:function(evt){
                        	var _$el = $(evt.currentTarget);
                        	var _elVal = _$el.val();
                        	_$el.val(_elVal.toString().replace(/,/g, ''));
                        	_$el.attr('maxlength',_$el.attr('data-min-maxlength'));
                        },
            		    formatCurrency:function(evt){
                        	var _$el = $(evt.currentTarget);
                        	var _elVal = _$el.val();
                        	_$el.val(_elVal.formatCurrency());
                        	_$el.attr('maxlength',_$el.attr('data-max-maxlength'));
            					//formatCurrency()
                        },
            				clearView: function() {
                            this.undelegateEvents();// Unbind all local event
            					// bindings
                            this.model.unbind('change', this.render, this);
            					// Unbind refernce to model
                        },
            				afterRender: function() {

                            var clientType = ClientInfoModel.get('clientType');
            					// Deciding if Person or entity
                            if (clientType == "P") {
                            	/* Case when Client type=Individual */
                                $('.entity-field').addClass('hidden');
                                $('.person-field').removeClass('hidden');
                            	/*
                                 * Employment validation is only applicable to
                                 * individuals
                                 */
                                var empStatus = EmploymentModel
                                        .get('employmentStatus');
                                if (empStatus == 'Not employed') {
                                    $("#employment-div").addClass("hidden");
                                    $('select').val('').trigger('change');
                                    $('.emp-common input').val("").trigger(
                                            'change');/*
                                             * for fields common to
                                             * both US and foreign
                                             * address
                                             */
                                } else {
                                    $("#employment-div").removeClass("hidden");
                            }

                            } else {
                            	/* Case when Client type=entity */
                                EmploymentModel.set('employmentStatus', '');
                            	/*
                                 * Employment status is not applicable for
                                 * entity
                                 */
                                $('.entity-field').removeClass('hidden');
                                $('.person-field').addClass('hidden');
            				}
                            this.loadCountryList();
                            $('.custom-select').customizeSelect();

                            this.setSavedValues();
                            var _model = this.model;
                            if (ClientModel.get('clientCreated') == 'failed') {
                                Validator.validateInputs('client-income', true);
                                this.validateComponents();
            				}
                            _model.set('visited', true);
                        },
                        navigateToStep5: function() {
                            if (ClientInfoModel.get('clientType') == 'P')
                                $('.ncst-step.step5').find('.step-nav-links').click();
                            else
                                $('.ncst-step.step4').find('.step-nav-links').click();
                        },
                        storeValFrmAssetTypeHeldAwayInput: function () {
                            var assetTypeConstItems = constants.sortedAssetTypeHeldList;
                            _.each(assetTypeConstItems, function (assetTypeList, index) {
                                _.find(assetTypesHeldCollection, function (list) {
                                    if (list.code == assetTypeList.code) {
                                        list.assetVal = $('#asset-type-held-chkboxes-input-' + index).val();
                                    }
                                });
                            });

                            var assertArr = assetTypesHeldCollection;
                            var combineAssetList = _.filter(assetTypeConstItems, function(obj) {
                            	for (var i = 0; i < assertArr.length; i++) {
                            		if (obj.code == assertArr[i].code) return false
                            	} return obj
                            });
                            var sortAssetList = _.sortBy(assertArr.concat(combineAssetList), 'code');

                            if (doesClientHaveAssetsVal == "B") {
                            	_.each(sortAssetList, function(obj) {
                            		obj["assetVal"] = null;
                            });
                            } else if (doesClientHaveAssetsVal == "C") {
                            	_.each(sortAssetList, function(obj) {
                            		obj["assetVal"] = "0";
                            	});
                            } else if (doesClientHaveAssetsVal == "A") {
                            	_.each(sortAssetList, function(obj) {
                            		if (!obj.assetVal) {
                            			obj["assetVal"] = "0";
                            		}
                            	});
                            }
                            _.map(sortAssetList, function (list) {
                            	if (list.assetVal != null) {
									list.assetVal = parseInt(list.assetVal.toString().replace(/,/g, '')); return list;
								}							  
							  });
                            assetTypesHeldCollection = sortAssetList;
                        },
                        mappingInvestmentExperienceList: function(obj) {
                        	if ($('.has-invest-exp.active').val() == "Yes") {
                        		var investExpList = constants.sortedInvestmentExpList;
                        		var productExpArr = investExpCollection;

                        		var filteredInvestList = _.filter(investExpList, function(obj) {
                        			for (var i = 0; i < productExpArr.length; i++) {
                        				if (obj.code == productExpArr[i].code) return false}
                        			return obj;
                        		});
                        		investExpCollection = _.sortBy(productExpArr.concat(filteredInvestList), 'code');
                        		_.each(investExpCollection, function(obj) {
                        			if (!(obj.years)) { obj["years"] = { mapCode: "A" }; obj["transaction"] = { mapCode: " " }; }
                        		});
                        	}
                        },
                        navigateToStep7: function () {
                            //On Next Btn Clicked, Save the values
                            this.storeValFrmAssetTypeHeldAwayInput();
                        	this.mappingInvestmentExperienceList();
                            /* client side verification for incomplete steps*/
                            var _stepsToComplete = ClientInfoModel.get('clientType') == 'P' ? 6 : 5;                            
                            ClientModel.set('serverErrorCodes', '');
                            if (this.model.validate(true) || this.validateComponents()) { 
                                this.model.setModel(investExpCollection, sourceIncomeCollection, assetTypesHeldCollection, doesClientHaveAssetsVal);
                                if (ClientModel.get('stepsCompleted').indexOf('income') === -1) {
                                    ClientModel.get('stepsCompleted').push('income');
                                }
                                if (ClientModel.get('stepsCompleted').length != _stepsToComplete) {
                                    this.errorNotifier();
                        } else {
                                    this.validateNewClient();
                                }
                            } else {
                                this.errorNotifier();
            				}   
                        },
                        validateComponents: function () {
                            var nestedViewId = '';
                            var showErrFlag = false;
                            var radioErrFlag = false;
                            var hasErrorInAssetsInputBox = false;
                            for (var key in this.nestedViews) {
                                if (key.indexOf("doesClientHaveAssetsViewName") > -1) {
                                    if (this.nestedViews[key].selectedItem == null) {
                                        nestedViewId = this.nestedViews[key].el.id;
                                        showErrFlag = true;
                                    } else {
                                        showErrFlag = false;
                                    }
                                } else if (key.indexOf("sourceOfIncomeCheckViewName") > -1 || key.indexOf("investmentCheckboxView") > -1) {
                                    if (this.nestedViews[key].allSelectedItems.length == 0 ) {
                                        nestedViewId = this.nestedViews[key].el.id;
                                        showErrFlag = true;
                                    } else {
                                        showErrFlag = false;
                                    }

                                    if (key.indexOf("investmentCheckboxView") > -1) {
                                        var _that = this;
                                        nestedViewId = this.nestedViews[key].el.id;
                                        _.each(this.nestedViews[key].selectedIndexes, function (itemDesc, idx) {
                                            for (i = 1; i <= 2; i++) {
                                                var radioBtnViewName = "testRadioBtnViewName" + itemDesc + i;
                                                if (_that.nestedViews[radioBtnViewName]) {
                                                    var nestedRadioBtnId = _that.nestedViews[radioBtnViewName].el.id;
                                                    var nestedRadioDiv = $("div [ampf-radio-buttons=" + nestedRadioBtnId + "]");
                                                    if (_that.nestedViews[radioBtnViewName] && _that.nestedViews[radioBtnViewName].selectedItem == null) {
                                                        _that.nestedViews[radioBtnViewName].showError(true);
                                                        nestedRadioDiv.addClass('error');
                                                        radioErrFlag = true;
                                                    }
                                                    else {
                                                        _that.nestedViews[radioBtnViewName].showError(false);
                                                        nestedRadioDiv.removeClass('error');
                                                    }
                                                }
                                            }
                                        });
                                    }
                                } else if (key.indexOf("assetTypeCheckboxViewName") > -1) {
                                    var count = 0;

                                    $('input.assetTypeHeldInput').each(function () {
                                        if ($(this).val() == "") {
                                            hasErrorInAssetsInputBox = true;
                                            count++;
                                            return false;
                                        }
                                    });

                                    if (this.nestedViews[key].allSelectedItems.length == 0 || count > 0) {
                                        nestedViewId = this.nestedViews[key].el.id;
                                        showErrFlag = true;
                                    } else {
                                        showErrFlag = false;
                                    }
                                }

                                if (showErrFlag) {
                                    $("div [data-for=" + nestedViewId + "]").addClass('error');
                                    $("div [data-for=" + nestedViewId + "] .ncst-adjust-left").removeClass('hidden');
                                    this.nestedViews[key].showError(true);
                                }

                                if (hasErrorInAssetsInputBox) {
                                    $("div [ampf-checkbox-buttons=" + nestedViewId + "] > label").text('');
                                } else { hasErrorInAssetsInputBox = false; }
                            }
                            showErrFlag = showErrFlag || radioErrFlag;

                            return !(showErrFlag);
                        },
            				errorNotifier: function(){
                            var _clsnot2Chk = ['.finished', '.pending','.step7', '.step8'];
                            _clsnot2Chk.push(ClientInfoModel.get('clientType') == 'P' ? '.step6' : '.step5, .step6');
                            ClientModel.set('clientCreated', 'failed');
                            $('.ncst-step:not('+_clsnot2Chk.join()+')').addClass('pending');
                            BootstrapDialog.alert("You must complete all required fields.", function(result) {
                                $(window).scrollTop(0);
                            }, "Incomplete fields");
                        },
                        modelSaver: function () {
                            if (this.model.validate() || this.validateComponents()) {
                                this.model.setModel(investExpCollection, sourceIncomeCollection, assetTypesHeldCollection, doesClientHaveAssetsVal);
                                return true;
            				}
                        },
            				loadCountryList: function() {
                            var _countryList = DropdownOptions.countryList;
                            var _selectbox = "#income-country-list";
                            Utils.loadSelectbox(_selectbox, _countryList);
                            var _stateList = DropdownOptions.USStateslist;
                            var _selectbox = "#income-state-list-select";
                            Utils.loadSelectbox(_selectbox, _stateList);
                        },
            				setSavedValues: function() {
                            var _model = this.model;
                            $('#income-primary-source').val(
                                    _model.get('incomeSourcePrimary'));
                            $('#income-fed-tax')
                                    .val(_model.get('incomeFedTax'));
                            $('#income-indi-annual').val(
                                    _model.get('incomeIndiAnnualNum'));
                            $('#income-indi-net').val(
                                    _model.get('incomeIndiNetNum'));
                            $('#income-indi-liquid').val(
                                    _model.get('incomeIndiLiquidNetNum'));
                            if (_model.get('productExperienceVal').length) { 
                                $("#product-experience-options input").val(
                                        _model.get('productExperienceVal'));
            				}
                            var names = $(
                                    "#product-experience-options input:checkbox:checked")
                                    .map(
                                            function() {
                                                $(
                                                        'input[value="'
                                                        + this.value
                                                        + '"]').click();
                                                $(
                                                        'input[value="'
                                                        + this.value
                                                        + '"]').prop(
                                                        'checked', true)
                                                        .parent().parent()
                                                        .addClass('active');
                                                return this.value;
                            }).get();
                            $("#product-experience-options input").val(names);
                            $('#client-income select').trigger('change');
                        },
            				validateZipCodeLength: function(e) {
                            if ($('#emp-address-typ-us').prop('checked')) {
                                if ($('#income-zipcode').val().length >= 5) {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    return false;
                            }
                            } else if ($('#income-country-list').val() == "CA") {
                                if ($('#income-zipcode').val().length >= 6) {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    return false;
                            }
            				}

                        },
            				toggleCheckboxClassActive: function(event) {
                            var _checkbox = $(event.target);
                            if (_checkbox.is(':checked')) {
                                _checkbox.parents('div.radio-group-conatiner')
                                        .addClass('active');
                            } else {
                                _checkbox.parents('div.radio-group-conatiner')
                                        .removeClass('active');
            				}
                        },
            				handleEmpAddressTypeChange: function() {
            					/*
								 * To remove error message on from previously option
								 * selection
								 */
                            $("#client-income .emp-addrss-div label.error")
                                    .addClass("hidden");
                            $("#client-income .emp-addrss-div div")
                                    .removeClass("error");

                            $('.emp-adr input').val("").trigger('change');
                            var _checkedradio = $('input[name="empAddressType"]:checked');
                            var _$zipCodeRow = $('div[data-for=income-zipcode]');
                            var _$zipCode = $("#income-zipcode").val('');
                            _$zipCode.attr('type', 'text');
                            if (_checkedradio.val() == "U.S") {
                            	// change field type
                                if (Utils.isMobile()) {
                                    _$zipCode.attr('type', 'number');
                                } else {
                                    _$zipCode.attr('type', 'text');
                            }
                                _$zipCode.removeClass("canada-zipcode")
                                        .addClass("us-zipcode");
                                $("div[data-for=income-state-list-select]")
                                        .show();
                                $("div[data-for=income-country-list]").hide();
                                $("#income-country-list").val("").trigger(
                                        'change');
                                $("div[data-for=income-province-list-select]")
                                        .hide();
                                $("#income-province-list-select").val("")
                                        .trigger('change');
                                _$zipCodeRow.show();
                                $("div[data-for=income-zipcode]div").eq(0)
                                        .find("label").eq(0).text("Zip code");
                            	// change addresline1 validation
                                $('#income-address-line1').addClass(
                                        'us-address-1').removeClass('address');
                            } else {
                                $("div[data-for=income-state-list-select]")
                                        .hide();
                                $("#income-state-list-select").val("").trigger(
                                        'change');
                                $("div[data-for=income-country-list]").show();
                                $("div[data-for=income-zipcode]div").eq(0)
                                        .find("label").eq(0)
                                        .text("Postal code");
                                _$zipCodeRow.hide();
                                _$zipCodeRow.find('input').val('').removeClass(
                                        "required");
                                _$zipCode.removeClass("required");
                            	// change address validation for line1
                                $('#income-address-line1').addClass('address')
                                        .removeClass('us-address-1');
            				}

                        },
            				empHandleProvinceForCanada: function() {
                            var _model = this.model;
                            var _selectedCOuntry = $("#income-country-list")
                                    .val();
                            var _$zipCode = $("#income-zipcode");
                            if (_selectedCOuntry == "CA") {
                                $("div[data-for=income-state-list-select]")
                                        .hide();
                                $("#income-state-list-select").val("").trigger(
                                        'change');
                                $("div[data-for=income-province-list-select]")
                                        .show();
                                $("#income-province").val("").hide();
                                $("#income-province-list-select").show();
                                _$zipCode.parent().parent().show();
                                _$zipCode.removeClass('us-zipcode').addClass(
                                        "canada-zipcode");
                                _$zipCode.attr('type', 'text');
                            } else if ($('input[name=empAddressType]:checked')
                                    .val() == "Foreign") {
                                $("div[data-for=income-state-list-select]")
                                        .hide();
                                $("div[data-for=income-province-list-select]")
                                        .hide();
                                $("#income-province-list-select").val("")
                                        .trigger('change');
                                $("#income-province").val("").show();
                                $("#income-province-list-select").val("");
                                _$zipCode.parent().parent().hide();
                                _$zipCode.val('');
                                _$zipCode.removeClass("required");
                            } else {
                                $("div[data-for=income-province-list-select]")
                                        .hide();
                                $("#income-province-list-select").val("")
                                        .trigger('change');
                                $("div[data-for=income-state-list-select]")
                                        .show();
                                _$zipCode.parent().parent().show();
            				}
                        },
            				handleNoneOptionClick: function() {
                            if ($("#none-opt").is(':checked')) {
                                $('.prod-opt').prop('checked', false);
                                $('.other-opt-cls').removeClass('active');
            				}
                        },
            				handleOtherOptionClick: function() {
                            if ($(".prod-opt").is(':checked')) {
                                $('#none-opt').prop('checked', false);
                                $('.none-opt-cls').removeClass('active');
            				}
                        },
            				anIncomekeyPress: function(e) {
                            var annStr = $("#income-indi-annual").val().concat(
                                    String.fromCharCode(event.keyCode));
                            if (annStr.charAt(11) != ""
                                    && annStr.charAt(11) != ".") {
                                e.preventDefault();
            				}
                        },
            				anNetkeyPress: function(e) {
                            var netStr = $("#income-indi-net").val().concat(
                                    String.fromCharCode(event.keyCode));
                            if (netStr.charAt(15) != ""
                                    && netStr.charAt(15) != ".") {
                                e.preventDefault();
            				}
                        },
            				anliquidNetkeyPress: function(e) {
                            var liqStr = $("#income-indi-liquid").val().concat(
                                    String.fromCharCode(event.keyCode));
                            if (liqStr.charAt(15) != ""
                                    && liqStr.charAt(15) != ".") {
                                e.preventDefault();
            				}
                        },
            				numValidator: function(obj) {
                            var _regxNumOnly = /^\d*$/;
                            var _str = String.fromCharCode(event.keyCode);
                            var _maxlength = obj.currentTarget.maxLength;
                            var _value = obj.currentTarget.value;
                            if (!_regxNumOnly.test(_str)
                                    || _value.length >= _maxlength) {
                                obj.stopPropagation();
                                if (event.preventDefault)
                                    event.preventDefault();
                                return false;
            				}
                        },
            			validateNewClient: function() {
                            var _url1 = BASE_URL + 'validateNewClient?$format=json', _clientInfo = ClientModel.get('clientInfo').toJSON(), _clientDtails = ClientDetailsModel.toJSON(),
                            _empmntDtails = EmploymentModel.toJSON(), _incinvDtails = IncomeModel.toJSON(), _addrDtails = AddressModel.toJSON(),
                            _advNo = ClientModel.get('advisorNumber'), _servcAdvsNum = ClientModel.get('servicingAdvisorNumber'), _isAACuser = ClientModel.get('isUserAAC'), clientType = ClientInfoModel.get('clientType'), _pdtExp = [], personClient = null,
                            orgClient = null, clientObjType = '';
            			


                    if (_incinvDtails.productExperienceVal.length) {
                        $.each(_incinvDtails.productExperienceVal,
                            function (idx, pdtExpVal) {
								_pdtExp.push({
									"prodExpeTypCd": pdtExpVal.mapCode,
									"invExpeYrCd": pdtExpVal.years.mapCode, 
									"invExpeYrDesc": null, 
									"annlTransCd": pdtExpVal.transaction.mapCode,
									"annlTransDesc": null
                            });
						});
                    }
                    var addrKeyStrType = clientType == 'P' ? 'addressLine' : 'entAddressLine';
                    var _clCtx = null;
                    if(clientType =="P"){
                    	try {

                        	if(_clientInfo.prosId){
                        		if(_clientInfo.prosId.length>0){
                        			if(_clientInfo.prosCtx){
                        				_clCtx = _clientInfo.prosCtx;
                        			}else{
                        				_clCtx = "CM";
                        		}
                        	}
                    	}
                        
						} catch (e) {
							// TODO: handle exception
                    }
            				}
                    var _newClientDetls = {
                        "postalAddresses": [
                            {
                                "addrUseCd": "Primary",
                                "addrLn1": _addrDtails.primaryAddress[addrKeyStrType + '1'],
                                "addrLn2": _addrDtails.primaryAddress[addrKeyStrType + '2'] ? _addrDtails.primaryAddress[addrKeyStrType + '2'] : null,
                                "addrLn3": _addrDtails.primaryAddress[addrKeyStrType + '3'] ? _addrDtails.primaryAddress[addrKeyStrType + '3'] : null,
                                "ctyNm": _addrDtails.primaryAddress.city,
                                "ctryNm": _addrDtails.primaryAddress.countryTxt,
                                "stCd": _addrDtails.primaryAddress.state,
                                "postlCd": _addrDtails.primaryAddress.zip,
                                "vldAddrInd": AddressModel.get('validAddr') ? "" : 'Y'
                    }],
                        "emails": [{
                                "emlUseCd": "Primary",
                                "emlAddr": _clientDtails.clientprimaryEmail ? _clientDtails.clientprimaryEmail : null
                        }, {
                                "emlUseCd": "Secondary",
                                "emlAddr": _clientDtails.clientsecondaryEmail ? _clientDtails.clientsecondaryEmail : null
                    }],
                        "prospectInfo": {
                            "psptId": clientType =="P" ?(_clientInfo.prosId && _clientInfo.prosCtx ? _clientInfo.prosId : null):null,
                            "psptCtx":_clCtx,
                            "psptSrc": _clientDtails.clientprospectSource,
                            "acqTech": _clientDtails.clientacquisitionTech
                    },
                        "financialInfo": {
                            "txBrktInd": "Y",
                            "fedTxBrktPct": _validateClientDataMapping.clientIncome.taxBracket[_incinvDtails.incomeFedTax],
                            "fedTxBrktTxt": null,
                            "annlIncm": _incinvDtails.incomeIndiAnnualNum ? _incinvDtails.incomeIndiAnnualNum : null,
                            "netWorth": _incinvDtails.incomeIndiNetNum ? _incinvDtails.incomeIndiNetNum : null,
                            "netWorthInd": "Y",
                            "liqNetWorth": _incinvDtails.incomeIndiLiquidNetNum ? _incinvDtails.incomeIndiLiquidNetNum : null,
                            "liqNetWorthInd": "Y"
                    },
                        "associatedClient": {
                            "clId": _clientInfo.clientassocId ? _clientInfo.clientassocId : null,
                            "clCtx": _clientInfo.clientassocId ? "COLA.CL" : null,
                            "clRel": _clientInfo.clientassocId ? _clientInfo.clientassocReltn : null
                    },
					"heldAway": {
						"heldAwayInfoCd": _incinvDtails.doesClientHaveAssets,
								"heldAwayDetail": {
									"heldAwayAltInvAmt": _incinvDtails.assetsTypeHeldVal[0].assetVal ? _incinvDtails.assetsTypeHeldVal[0].assetVal : 0,
									"heldAwayAnntVarLifeAmt": _incinvDtails.assetsTypeHeldVal[1].assetVal ? _incinvDtails.assetsTypeHeldVal[1].assetVal : 0,
									"heldAwayCertOrCdAmt": _incinvDtails.assetsTypeHeldVal[2].assetVal ? _incinvDtails.assetsTypeHeldVal[2].assetVal : 0,
									"heldAwayCmdtyAmt": _incinvDtails.assetsTypeHeldVal[3].assetVal ? _incinvDtails.assetsTypeHeldVal[3].assetVal : 0,
									"heldAwayStkAmt": _incinvDtails.assetsTypeHeldVal[4].assetVal ? _incinvDtails.assetsTypeHeldVal[4].assetVal : 0,
									"heldAwayBndAmt": _incinvDtails.assetsTypeHeldVal[5].assetVal ? _incinvDtails.assetsTypeHeldVal[5].assetVal : 0,
									"heldAwayLtdPtnrAmt": _incinvDtails.assetsTypeHeldVal[6].assetVal ? _incinvDtails.assetsTypeHeldVal[6].assetVal : 0,
									"heldAwayMFAmt": _incinvDtails.assetsTypeHeldVal[7].assetVal ? _incinvDtails.assetsTypeHeldVal[7].assetVal : 0,
									"heldAwayNonTrdREITAmt": _incinvDtails.assetsTypeHeldVal[8].assetVal ? _incinvDtails.assetsTypeHeldVal[8].assetVal: 0,
									"heldAwayOptAmt": _incinvDtails.assetsTypeHeldVal[9].assetVal ? _incinvDtails.assetsTypeHeldVal[9].assetVal : 0,
									"heldAwayStrcProdAmt": _incinvDtails.assetsTypeHeldVal[10].assetVal ? _incinvDtails.assetsTypeHeldVal[10].assetVal : 0,
									"heldAwayOthAmt": _incinvDtails.assetsTypeHeldVal[11].assetVal ? _incinvDtails.assetsTypeHeldVal[11].assetVal : 0
									}
					}
            		};
            					// pushing mailing address to payload
                    if (_addrDtails.mailingAddress[addrKeyStrType + '1']) {
                        _newClientDetls.postalAddresses[1] = {
                            "addrUseCd": "Mailing",
                            "addrLn1": _addrDtails.mailingAddress[addrKeyStrType + '1'] ? _addrDtails.mailingAddress[addrKeyStrType + '1'] : null,
                            "addrLn2": _addrDtails.mailingAddress[addrKeyStrType + '2'] ? _addrDtails.mailingAddress[addrKeyStrType + '2'] : null,
                            "addrLn3": _addrDtails.mailingAddress[addrKeyStrType + '3'] ? _addrDtails.mailingAddress[addrKeyStrType + '3'] : null,
                            "ctyNm": _addrDtails.mailingAddress.city ? _addrDtails.mailingAddress.city : null,
                            "stCd": _addrDtails.mailingAddress.state ? _addrDtails.mailingAddress.state : null,
                            "postlCd": _addrDtails.mailingAddress.zip ? _addrDtails.mailingAddress.zip : null,
                            "vldAddrInd": AddressModel.get('mailValidAddr') ? "" : 'Y'
                    }
            				}
                    var _telePhones = _clientDtails['telephones'];
                    _telePhones = JSON.parse(JSON.stringify(_telePhones));
                    _telePhones = _telePhones.filter(function(phone){
                    	try {
                    		return phone.phnCtryCd.length > 1;
						} catch (e) {
							return false;
                    }
                    });
                    var companies = [], employerData = _empmntDtails.employmentAddrCollection, finraData = _empmntDtails.FINRAAddrCollection, shareholderData = _empmntDtails.shareHolderAddrCollection;
                    var empArray = [], finraArray = [], shareholderArray = [];
                    _.range(_.each(employerData, function (obj) {
                    	empArray.push({
                    		"relTypCd": "A",
                    		"coNm": obj.employerName,
                    		"addrLn1Txt": obj.address1,
                    		"addrLn2Txt": obj.address2,
                    		"cityNm": obj.city,
                    		"stCd": (obj.countryFullNm == "CANADA" ? obj.province : obj.state),
                    		"postlCd": obj.zipCode,
                    		"cntryNm": (obj.countryFullNm == "" ? 'US' : obj.countryFullNm),
                    		"symbol": ""
                    	});
                    }));
                    _.isEmpty(empArray) ? '' : companies.push(empArray);
                    _.range(_.each(finraData, function (obj) {
                    	finraArray.push({
                    		"relTypCd": "C",
                    		"coNm": obj.employerName,
                    		"addrLn1Txt": obj.address1,
                    		"addrLn2Txt": obj.address2,
                    		"cityNm": obj.city,
                    		"stCd": (obj.countryFullNm == "CANADA" ? obj.province : obj.state),
                    		"postlCd": obj.zipCode,
                    		"cntryNm": (obj.countryFullNm == "" ? 'US' : obj.countryFullNm)
                    	});
                    }));
                    _.isEmpty(finraArray) ? '' : companies.push(finraArray);
                    _.range(_.each(shareholderData, function (obj) {
                    	shareholderArray.push({
                    		"relTypCd": "B",
                    		"coNm": obj.employerName,
                    		"addrLn1Txt": obj.address1,
                    		"addrLn2Txt": obj.address2,
                    		"cityNm": obj.city,
                    		"stCd": (obj.countryFullNm == "CANADA" ? obj.province : obj.state),
                    		"postlCd": obj.zipCode,
                    		"cntryNm": (obj.countryFullNm == "" ? 'US' : obj.countryFullNm),
                    		"symbol": obj.tickerSymbol
                    	});
                    }));
                    _.isEmpty(shareholderArray) ? '' : companies.push(shareholderArray);
                    	
                    if (clientType == 'P') {
                        var _ssnNo = (_clientInfo.citizenship == 'Non-Resident Alien' && _clientInfo.ssn1 == '') ? '000000000' :
                                _clientInfo.ssn1 +_clientInfo.ssn2 +_clientInfo.ssn3;
                        var incomeSrcDetail = _incinvDtails.incomeSourcePrimary;
                        var _riskProfilePerson = {
                        	"indsClsCd": _empmntDtails.industryClassifyEmpCd ? _empmntDtails.industryClassifyEmpCd : "",
                        	"indsClsTxt": _empmntDtails.industryClassifyEmpOther ? _empmntDtails.industryClassifyEmpOther : "",
                        	"nonOperEntyCd": ""
                        };
                        personClient = {
                            "hrnfNm": _clientInfo.honorific ? _validateClientDataMapping.clientInfo.honorific[_clientInfo.honorific]
                                    : null,
                            "firstNm": _clientInfo.firstName,
                            "midNm": _clientInfo.middleName ? _clientInfo.middleName
                                    : null,
                            "lastNm": _clientInfo.lastName,
                            "sfxTxt": _clientInfo.suffix ? _validateClientDataMapping.clientInfo.suffix[_clientInfo.suffix]
                                    : null,
                            "persTypCd": _clientInfo.clientRole == "F" ? "AP" : "OC",
                            "taxPayerId": _ssnNo,
                            "genderCd": _clientInfo.clientSex,
                            "mrtlStatCd": _validateClientDataMapping.clientDetails.maritalStatus[_clientDtails.clientmaritalStatus],
                            "mrtlStatDesc": _clientDtails.clientmaritalStatus,
                            "bthDt": _clientDtails.clientbirthDay,
                            "dpdtCnt": _clientDtails.clientDependants,
                            "ctzp": _validateClientDataMapping.clientInfo.citizenship[_clientInfo.citizenship],
                            //"ctznCntryCd": _clientInfo.citizenshipCountry,
                            "drvLicNbr": _clientDtails.clientdriverLicense ? _clientDtails.clientdriverLicense : null,
                            "drvLicStCd": _clientDtails.clientState ? _clientDtails.clientState : null,
                            "drvLicStNm": _clientDtails.clientStateNm ? _clientDtails.clientStateNm : null,
                            "psprtNbr": _clientDtails.clientPassport ? _clientDtails.clientPassport : null,
                            "finInstnEmplCd": typeof _empmntDtails.isEmployed != 'undefined' ? _empmntDtails.isEmployed.substr(0, 1) : null,
                            "finInstnEmplDesc": null,
                            "ownrOfcrCd": typeof _empmntDtails.isClientODSP != 'undefined' ? _empmntDtails.isClientODSP.substr(0, 1) : null, 
                            "ownrOfcrDesc": null,
                            "emplStatCd": _empmntDtails.employmentStatusCode ? _empmntDtails.employmentStatusCode : null,
                            "emplStatDesc": _empmntDtails.employmentStatus ? _empmntDtails.employmentStatus : null,
                            "occpDescTxt": _empmntDtails.occupation ? _empmntDtails.occupation : null,
                            "firstSrcOfIncmCd": _incinvDtails.incomeSourcePrimary[0] != null ? _incinvDtails.incomeSourcePrimary[0].mapCode : "",
                            "firstSrcOfIncmDesc": _incinvDtails.incomeSourcePrimary[0] != null ? _incinvDtails.incomeSourcePrimary[0].description : "",
                            "scndSrcOfIncmCd": _incinvDtails.incomeSourcePrimary[1] != null ? _incinvDtails.incomeSourcePrimary[1].mapCode : "",
                            "scndSrcOfIncmDesc": _incinvDtails.incomeSourcePrimary[1] != null ? _incinvDtails.incomeSourcePrimary[1].description : "",
                            "thirdSrcOfIncmCd": _incinvDtails.incomeSourcePrimary[2] != null ? _incinvDtails.incomeSourcePrimary[2].mapCode : "",
                            "thirdSrcOfIncmDesc": _incinvDtails.incomeSourcePrimary[2] != null ? _incinvDtails.incomeSourcePrimary[2].description : "",
							"firstCtznCtryCd": _clientInfo.citizenshipCountry,
                            "firstCtznCtryNm": _clientInfo.citizenshipCountryName,
                            "scndCtznCtryCd": _clientInfo.secCitizenshipCountry,
                            "scndCtznCtryNm": _clientInfo.secCitizenshipCountryName,
							"telephones": _telePhones,
                            "productExpe": _pdtExp.length ? _pdtExp : null,
                            "companies": _.flatten(companies),                            
                            "riskProfile": _riskProfilePerson
                    };
                        clientObjType = personClient;

                    } else if (clientType == 'O') {
                    	var _riskProfileEntity = {
                    		"indsClsCd": _clientInfo.industryClassifyCd ? _clientInfo.industryClassifyCd : "",
                    		"indsClsTxt": _clientInfo.industryFreeFormText ? _clientInfo.industryFreeFormText : "",
                    		"nonOperEntyCd": _clientInfo.isThisOperatingEntity,
                    		"fincenExemCd": null
                    	};
                        orgClient = {
                            "orgNm": ClientModel.get('scrubEntityName')?ClientModel.get('scrubEntityName'):ClientInfoModel.get('entityName'),
                            "orgTypCd": _validateClientDataMapping.clientInfo.entityRole[_clientInfo.entityRole],
                            "orgTypDesc": null,
                            "taxPayerId": _clientInfo.ein1 + _clientInfo.ein2,
                            "stOfIncorpCd": _clientInfo.stOfIncorpCode ? _clientInfo.stOfIncorpCode : "",
                            "frgnOrgInd": _clientInfo.frgnOrgCheck ? _clientInfo.frgnOrgCheck : "",
                            "firstSrcOfIncmCd": _incinvDtails.incomeSourcePrimary[0] != null ? _incinvDtails.incomeSourcePrimary[0].mapCode : "",
                            "firstSrcOfIncmDesc": _incinvDtails.incomeSourcePrimary[0] != null ? _incinvDtails.incomeSourcePrimary[0].description : "",
                            "scndSrcOfIncmCd": _incinvDtails.incomeSourcePrimary[1] != null ? _incinvDtails.incomeSourcePrimary[1].mapCode : "",
                            "scndSrcOfIncmDesc": _incinvDtails.incomeSourcePrimary[1] != null ? _incinvDtails.incomeSourcePrimary[1].description : "",
                            "thirdSrcOfIncmCd": _incinvDtails.incomeSourcePrimary[2] != null ? _incinvDtails.incomeSourcePrimary[2].mapCode : "",
                            "thirdSrcOfIncmDesc": _incinvDtails.incomeSourcePrimary[2] != null ? _incinvDtails.incomeSourcePrimary[2].description : "",
							"orgSttDt": null,
							"telephones": _telePhones,
							"productExpe": _pdtExp.length ? _pdtExp : null,
                            "riskProfile": _riskProfileEntity
                        };
                        clientObjType = orgClient;
            		};
                    clientObjType.postalAddresses = _newClientDetls.postalAddresses;
                    clientObjType.emails = _newClientDetls.emails;
                    clientObjType.prospectInfo = _newClientDetls.prospectInfo;
                    clientObjType.financialInfo = _newClientDetls.financialInfo;
                    clientObjType.associatedClient = _newClientDetls.associatedClient;
                    clientObjType.heldAway = _newClientDetls.heldAway;

                    var _newClient = {
                        "customerTypeCd": _clientInfo.clientType,
                        "prmAdvsDstrId": _advNo,
                        "prmAdvsDstrCtx": "DMU.DIST",
                        "servAdvsDstrId": _isAACuser ? _advNo: _servcAdvsNum,
                        "servAdvsDstrCtx": "DMU.DIST",
                        "orgClient": orgClient,
                        "personClient": personClient
            				};
            				this.newClientValidationService(_newClient, _url1);

                },
            			newClientValidationService: function(dataString, url) {
                            Utils.lockForm();
                            var _data1 = dataString;
                            var _url1 = url;
                            var _self = this;
                            Utils.post(_url1, JSON.stringify(_data1),
                                    newClientValidationSucces, function(xhr) {
                                        Utils.showSystemUnavailableMsg("6", "income", xhr.status);
                                        Utils.logError(xhr);
                            }, {accept: "application/vnd.awm.ampf.com+json;"});

            				function newClientValidationSucces(resp,statusMessage,xhr) {
                                var _response = resp.d;
                                var obj = '';
                                Utils.unlockForm();
                                if (!_response.explanations.results.length) {
                                	// saving the response in client model for creating client
                                    ClientModel.set('clientValid', true);
                                    ClientModel.set('clientValidatedDtls', {});
                                    ClientModel.set('clientValidatedDtls', (JSON.stringify(_self.formatValidatedClientJson(_response, _response.customerTypeCd))));
                                    obj = _response.customerTypeCd == 'P' ? _response.personClient : _response.orgClient;
                                    obj['clientType'] = _response.customerTypeCd;
                                    obj['advId'] = _response.prmAdvsDstrId;
                                    obj['advisorNm'] = ClientModel.get("advisorNm");
                                    obj['servcAdvsrId'] = _response.servAdvsDstrId;
                                    obj['servcAdvsrNm'] = ClientModel.get("servicingAdvisorName");
                                    obj.Primary = '', obj.Mailing = '', obj.PrimaryMail = '', obj.SecondaryMail = '';
                                	// primary/mailing address
                                    var postalAddrArr = typeof obj.postalAddresses.results != 'undefined' ? obj.postalAddresses.results : obj.postalAddresses;
                                    if (postalAddrArr.length > 0) {
                                        $.each(postalAddrArr, function(indx, addr) {
                                            var addrDtls = {'addrLn1': addr.addrLn1, 'addrLn2': addr.addrLn2, 'addrLn3': addr.addrLn3, 'ctyNm': addr.ctyNm, 'stCd': addr.stCd, 'postlCd': addr.postlCd,ctryNm:addr.ctryNm};
                                            if (addr.addrUseCd == 'Primary') {
                                                obj['Primary'] = addrDtls;
                                            } else if (addr.addrUseCd == 'Mailing') {
                                                obj['Mailing'] = addrDtls;
                                        }
                                    });
                                    }else{
                                    	//log custom error
                                    	var _errorObj = {message:""};
                                    	var _messgae = {"description":"Postal Address Empty","responseData":obj.postalAddresses};
                                    	_errorObj.message = JSON.stringify(_messgae);
                                    	Utils.logError(_errorObj,true);
                                }
                                	// primary/secondary email
                                    var emailAddrArr = typeof obj.emails.results != 'undefined' ? obj.emails.results : obj.emails;
                                    if (emailAddrArr.length) {

                                        $.each(emailAddrArr, function(indx, mail) {
                                            var mailDtls = {'emlAddr': mail.emlAddr};
                                            if (mail.emlUseCd == 'Primary') {
                                                obj['PrimaryMail'] = mailDtls;
                                            } else if (mail.emlUseCd == 'Secondary') {
                                                obj['SecondaryMail'] = mailDtls;
                                        }
                                    });
                                }
                                	// homephone/work phone
                                    var telPhArr = typeof obj.telephones.results != 'undefined' ? obj.telephones.results : obj.telephones;
                                	/*if (telPhArr.length) {

                                        $.each(telPhArr, function(indx, tel) {
                                            tel.phnNbr = tel.phnNbr.replace(/-/g, '') ? tel.phnNbr : '';
                                            tel.teleExtnNbr = !(tel.phnNbr) ? '' : (tel.teleExtnNbr == 0 ? '' : tel.teleExtnNbr);
                                            var telDtls = {'phnNbr': tel.phnNbr, 'teleExtnNbr': tel.teleExtnNbr};
                                            if (tel.teleUseCd == 'Work') {
                                                obj['Work'] = telDtls;
                                            } else if (tel.teleUseCd == 'Home') {
                                                obj['Home'] = telDtls;
                                            }
                                        });
                                    }*/
                                	/*** Changes- new requirement in phone ***/
                                    obj['Home'] = null;
                                    obj['Business'] = null;
                                    obj['Mobile'] = null;
                                    obj['Other1'] = null;
                                    obj['Other2'] = null;
                                    var telPhArr = typeof obj.telephones.results != 'undefined' ? obj.telephones.results : obj.telephones;
                                    if(telPhArr.length){
                                    	$.each(telPhArr, function(indx, tel) {
                                		
                                    		switch (tel.phnLblTxt) {
    										case 'HOME':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Home'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr
    												};
    												}else{
    													obj['Home'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    												};
    										}
    												obj['Home'].phnPrfrCd = tel.phnPrfrCd;
    											
    											break;
    										case 'WORK':
    											
    											 tel.phnExtnNbr = (tel.phnExtnNbr == 0) ? '' : tel.phnExtnNbr;
    	                                        
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													// telDtls = {'phnNbr': tel.phnNbr, 'teleExtnNbr': tel.phnExtnNbr};
    													obj['Business'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    												}else{
    													obj['Business'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    										}
    												obj['Business'].phnPrfrCd = tel.phnPrfrCd;
    											
    											break;
    										case 'MOBILE':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Mobile'] ={
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr
    												};
    												}else{
    													obj['Mobile'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    												};
    										}
    												obj['Mobile'].phnPrfrCd = tel.phnPrfrCd;
    											
    											break;
    										case 'OTHER1':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Other1'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    												}else{
    													obj['Other1'] = {
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    										}
    												obj['Other1'].phnPrfrCd = tel.phnPrfrCd;
    											break;
    										case 'OTHER2':
    											
    												if(tel.nonNANPPhnNbr != undefined && tel.nonNANPPhnNbr != "" && tel.nonNANPPhnNbr != null){
    													obj['Other2'] = {
    															'phnNbr':tel.phnCtryCd+"-"+tel.nonNANPPhnNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												};
    												}else{
    													obj['Other2'] ={
    															'phnNbr':tel.NANPAreaCd+"-"+tel.NANPExchCd+"-"+tel.NANPSbscNbr,
    															'teleExtnNbr': tel.phnExtnNbr
    												}
    										}
    												obj['Other2'].phnPrfrCd = tel.phnPrfrCd;
    											break;
    										default:
    											break;
                                    	}
                                    	
                                    });
                                }
                                    
                                    
                                    if (_response.customerTypeCd == 'P') {

                                        if (obj.bthDt) {
                                            var dateStr = obj.bthDt;
                                            var match = dateStr.match(/(\d{4})(\d{2})(\d{2})/);
                                            var bthDt = match[2] + '/' + match[3] + '/' + match[1];
                                            obj['birthday'] = bthDt;
                                    }
                                    	//product experiences
										//var obj = personClient;
										if (obj.productExpe.length) {
                    						obj['pdtExperiences']= obj.productExpe;
										}
                                    } else if (_response.customerTypeCd == 'O') {
                                        var swapEntityRoleArr = _.invert(_validateClientDataMapping.clientInfo.entityRole);
                                        obj['orgType'] = swapEntityRoleArr[obj.orgTypCd];
                                }
                                    if(obj.associatedClient && obj.associatedClient.clId && obj.associatedClient.clId !=""){
                                        obj['asccoaitedClientName'] = ClientInfoModel.get('clientassocFmtNm');
                                }
                                    var _newClientReq = NewClientModel.get('newClientModel');
                                    var _fromBackButton = NewClientModel.get('fromBackbutton');
                                    NewClientModel.set(obj);
                                    NewClientModel.set('newClientModel', _newClientReq);
                                    NewClientModel.set('fromBackbutton', _fromBackButton);
                                    var _context = GlobalContext.getInstance().getGlobalContext().Context;
                                    var _qryStrng =  _context.QueryString ?_context.QueryString:'';
                                    Backbone.history.navigate('ncst/verification'+_qryStrng, {trigger: true});

                                } else {
                                    Utils.unlockForm();
                                    obj = {Primary: '', Mailing: '', PrimaryMail: '', SecondaryMail: '', prospectInfo: '', financialInfo: ''};
                                    obj['Home'] = null;
                                    obj['Business'] = null;
                                    obj['Mobile'] = null;
                                    obj['Other1'] = null;
                                    obj['Other2'] = null;
                                    ClientModel.set('clientValid', false);
                                    ClientModel.set('clientCreated', 'failed');
                                     resp = Utils.normalizeWS(JSON.stringify(resp));
                                     resp = JSON.parse(resp);
                                    try {
                                    	xhr.responseJSON.error = { message: { value: JSON.stringify(resp.d.explanations.results[0]) } };
                                    	Utils.logError(xhr);
									} catch (e) {
										Utils.logError(e);
                                }
                                    handleServerErrors(_response.explanations.results);
            					}
            				}
                        },
            				formatValidatedClientJson: function(resp, clientType) {
                            var _clientType = clientType == 'P' ? 'personClient' : 'orgClient';
                            var _responseObj = resp[_clientType];
                            resp[_clientType].postalAddresses = _responseObj.postalAddresses.results;
                            resp[_clientType].telephones = _responseObj.telephones.results;
                            resp[_clientType].emails = _responseObj.emails.results;
							if (_responseObj.companies) {
                            	resp[_clientType].companies = _responseObj.companies.results;
            				}
                            var _finClientIf= resp[_clientType].financialInfo;
                            if (typeof _responseObj.productExpe != 'undefined') {
                            	if (_responseObj.productExpe.results) {
                            		var prodExpList = _responseObj.productExpe.results;
                            		prodExpResult = _.map(prodExpList, function (obj) {
                            			obj.annlTransDesc = null; obj.invExpeYrDesc = null;
                            			if (obj.annlTransCd == "") obj.annlTransCd = " ";
                            			return obj;
                            		});
                            		resp[_clientType].productExpe = prodExpResult;
                            	}                            	
            				}
                            var _incinvDtails = IncomeModel.toJSON();
                            if(!_validateClientDataMapping.clientIncome.taxBracket[_incinvDtails.incomeFedTax]){
                            	_finClientIf.fedTxBrktPct = null;
                            	_finClientIf.fedTxBrktTxt = null;
            				}
                            if(!_incinvDtails.incomeIndiAnnualNum){
                            	_finClientIf.annlIncm = null;
            				}
                            if(!_incinvDtails.incomeIndiNetNum ){
                            	_finClientIf.netWorth = null;
            				}
                            if(!_incinvDtails.incomeIndiLiquidNetNum){
                            	_finClientIf.liqNetWorth = null;
            				}
                            
                            delete resp.vldNewClStatDesc;
                            delete resp.vldNewClStatCd;
                            delete resp.explanations;

                            return resp;
                        },
            				handlerForCancel: function() {
            			}
                    });
            return incomeView;

        });