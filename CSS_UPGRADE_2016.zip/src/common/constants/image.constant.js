/*global sitePrefix*/
var sp = (window.sitePrefix) ? window.sitePrefix : '';

angular.module('CSS.commonimgcontants', []).constant('imagesDefaultConstant', {
    imagepathPolicy: {
        "HOME": sp + "assets/style/images/defaultimages/home.png",
        "UMBRELLA": sp + "assets/style/images/defaultimages/umbrella.png",
        "LIFE": sp + "assets/style/images/defaultimages/life.png",
        "AUTO": sp + "assets/style/images/defaultimages/auto-policy.png",
        "RENT": sp + "assets/style/images/defaultimages/rent.png",
        "default": sp + "assets/style/images/defaultimages/key.png"
    },
    icons: {
        "billing": {
            "imgpath": sp + "assets/style/images/defaultimages/documents.png",
            "value": "Billing Account"
        }
    }
});
