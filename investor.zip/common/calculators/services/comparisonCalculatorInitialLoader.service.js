/**
 * @ngdoc service
 * @name Comparison Calculator Initial Loader
 * @description
 *
 * - Handles the services and model for calculators content details
 *
 */
 'use strict';

 var comparisonCalculatorInitialService = function(fticLoggerMessage, loggerConstants, $cookies, comparisonCalculatorModel, calculatorsEventConstants) {
    var comparisonCalculatorInitialService = {
        _isServicesData: false, 
        loadAllServices : function (scope) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.DASHBOARD_MODULE + ' | ' + loggerConstants.DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            var guid = '';
            if($cookies.get("guId")) {
                guid = $cookies.get("guId")
            }
            console.log(guid)
            comparisonCalculatorModel.callFundDetailsData(scope.isAdvisor)
            .then(fundDetailsSuccess, promiseFailure)
            
            function fundDetailsSuccess (data) {
             console.log("fund details",data);
             comparisonCalculatorModel.setFundDetails(data);

             scope.$broadcast(calculatorsEventConstants.COMPARISON_FUND_DETAILS);
         }

         function promiseFailure () {
            console.log('ERROR promiseFailure');
            scope.$broadcast(calculatorsEventConstants.COMPARISON_FUND_DETAILS);
        }
    }
}
return comparisonCalculatorInitialService;
};

comparisonCalculatorInitialService.$inject = ['fticLoggerMessage', 'loggerConstants', '$cookies', 'comparisonCalculatorModel','calculatorsEventConstants'];
module.exports = comparisonCalculatorInitialService;
