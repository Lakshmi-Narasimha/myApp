/**
 * @ngdoc directive
 * @name fticValidationMsg
 * @name ngMessages
 * @description
 *
 * - This directive is used to display validation messages for form elements.
 * 
 **/

'use strict';

var validationMsg = function() {
    return {
        restrict: 'E',
        replace: true,
        template: require('./validationMsg.html'),
        scope: {
            isSubmitted: '=',
            formName: '@',
            atr: '@',
            errorMsgs: '='
        }
    };
};

validationMsg.$inject = [];
module.exports = validationMsg;
