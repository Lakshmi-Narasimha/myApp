/**
 * @ngdoc property
 * @name CAS Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @requires $loader
 * @requires $filter
 * @requires investorConstants
 * @description
 *
 * - CASController shows the links to navigate user to respective sites to get their Consolidated Account Statement.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function CASController($scope, fticLoggerMessage, loggerConstants, $loader, $filter, myportfolioConstants) {
    $scope.camsURL = myportfolioConstants.cas.camsURL;
    $scope.karvyURL = myportfolioConstants.cas.karvyURL;
}


CASController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$loader', '$filter', 'myportfolioConstants'];
module.exports = CASController;