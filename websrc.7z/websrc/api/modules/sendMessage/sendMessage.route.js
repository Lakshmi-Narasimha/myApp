var express = require('express');
var https = require('https');
var querystring = require('querystring');

var router = express.Router();
var sendMessageModel = require('./sendMessage.model');
var apiUtils = require('../../common/apiUtils');

// api route
router.route('/mfchat/rest/message')
    .post(function(req, res) {
        req.uri = sendMessageModel.createRequestUri;
        var post_data = req.body.RequestParams;
        var postBody = querystring.stringify(post_data);
        console.log(postBody);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'POST',
                path: req.uri.path,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Cookie': req.sessionCookie,
                    'Content-Length': Buffer.byteLength(postBody)
                },
                rejectUnauthorized: false
            },

            function(proxyResponse) {

                //console.log("req:", req.body.RequestParams);
                proxyResponse.setEncoding('utf8');
                if (proxyResponse.statusCode === 200) {
                  console.log("SendMsgCounter:", apiUtils.customerInfo.chatSendMsgCounter++);
                    //apiUtils.customerInfo.chatSendMsgCounter++;
                    //sendMessageModel.response.Page.state = req.body.RequestParams.state;
                    //console.log("not closed", req.body.RequestParams);
                    //console.log("closed", sendMessageModel.response.Page.state);
                    console.log("SendMsgStatusCode:", res.statusCode);
                    res.send(sendMessageModel.response);
                    //res.status(200).end();
                } else {
                    res.send({
                        statusCode: proxyResponse.statusCode,
                        message: 'Something went wrong while retrieving data.'
                    });
                }
                proxyResponse.on('error', function(err) {

                });
            });
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
