export class Parameter {
  displayOrder : Number;
  fieldLabel : string;
  fieldName : string;
  fieldType : string;
  fieldValues : any;
  paramfieldId : Number;
  paramType : string;
  paramTypeId : Number;
  response : string;

  parsedFieldValues : Array<any>;


  public getParsedFieldValues() : Array<any> {
    if( this.parsedFieldValues == null || this.parsedFieldValues == undefined  ) {
      if(this.fieldType == "select") {
        this.parseSelectFieldValues();
      }
      if(this.fieldType == "radio") {
        this.parseRadioFieldValues();
      }
    }
      return this.parsedFieldValues;
  }

  private parseSelectFieldValues() {
    this.parsedFieldValues = [];
    var data = this.fieldValues.replace("[","").replace("]","");
    var arrData = data.split(",");
    for(var i =0; i < arrData.length; i++) {
      var keyvalue = arrData[i].split(":");
      this.parsedFieldValues.push({id:keyvalue[0], label:keyvalue[1]});
    }
    console.log(data);
  }

  private parseRadioFieldValues() {

  }

}
