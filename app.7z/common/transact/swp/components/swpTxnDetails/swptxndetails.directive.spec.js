'use strict';
describe('Directive: fticRedemptionReviewStatus', function() {
	var compile,scope,directiveElement,isolatedScope,$window,$filter,authenticationService,transactModel;

    var investorDetails =  {
        "custName": "Shankar Narayanan",                    
        "pan": "ABCD1234KL",
        "aadhar" : 123456789123,
        "folioId": 3456572,
        "holdingType": "Joint",
        "mobile": 9039758625,
        "emailId": "shankarnarayanan@gmail.com",
        "city":"P O BOX 170 170",
        "kycStatus":true,
        "holders": [
            {
            "name": "Shankar Narayanan",
            "type": "Firstholder",
            "kycregistered" : true,
            "pan": "ABCD1234KL",
            "aadhar" : 123456789123
            }, {
            "name": "JHON SMITH GOERGE",
            "type": "Secondholder",
            "kycregistered" : true,
            "pan": "ABCD1234KA",
            "aadhar" : 123456789120
            }, {
            "name": "KRISTIANA GOERGE",
            "type": "Thirdholder",
            "kycregistered" : true,
            "pan": "ABCD1234KB",
            "aadhar" : 123456789121
            }
        ]
    };

    var selectedFundObject = {
        "tschvalScheme": "006",
        "fmDescription": "Franklin India Bluechip Fund - Dividend",
        "fundCategory": "EQUITY",
        "fundType": "EQUITY",
        "tschvalAccno": "0069901064910",
        "balUnits": "2463.841",
        "marketValue": "349183.18",
        "tschvalFsFlag": "N",
        "investmentGoal": ""
    };

	var swpObject = { 
		selectedMode: 'cheque', 
		startDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
		endDate: "Mon Jan 09 2017 14:54:45 GMT+0530 (India Standard Time)", 
		noofInstallments: 6,
		frequency: 'Monthly', 
		selectedType: 'capital',
		swpAmtValue: 'Capital Appreciation',
		bankDetails: 'CITI BANK - 7335300411'  
	};

	var advisor = false;

	beforeEach(angular.mock.module('advisor'));	
   
	var getCompiledElement = function(){
		var element = angular.element('<ftic-swp-txn-details></ftic-swp-txn-details>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
	};

	beforeEach(function() {
        angular.mock.inject(function($rootScope,_$compile_,$window,_$filter_,_authenticationService_,_transactModel_) {            
            compile = _$compile_;
            scope = $rootScope.$new();    

            $window = $window;
            $window.ga = function() {};

            $filter = _$filter_;
            authenticationService = _authenticationService_;           
            transactModel = _transactModel_;

            transactModel.setFundDetails(selectedFundObject);
            transactModel.setInvestorDetails(investorDetails);
            transactModel.setTransactDetails({                
                "swpDetails" : swpObject
            }); 
            transactModel.setTransactConfirm({
                'accountNo': '0010008062712',                     
                'transactionRefNo': 'SWI001166',
                'transDateTime':'Oct 16,2016'
            });

            if(advisor){
            	authenticationService.setUser({                                        
        			"userId" : "test123"        
        		});	
            }

            directiveElement = getCompiledElement();            
            isolatedScope = directiveElement.isolateScope();                   
        });
    });

    it('should be defined', function() {    	        
        expect(directiveElement).toBeDefined();        
    });

    it('should create a seperate isolated scope',function(){
    	expect(isolatedScope).toBeDefined();
    });

    it('should define the variable keyValuePairs if investor logged in',function(){
    	expect(isolatedScope.keyValuePairs[0].text).toBe('Folio No.');
    	expect(isolatedScope.keyValuePairs[0].value).toBe(3456572);
    	expect(isolatedScope.keyValuePairs[1].text).toBe('Fund');
    	expect(isolatedScope.keyValuePairs[1].value).toBe('Franklin India Bluechip Fund - Dividend');
    	expect(isolatedScope.keyValuePairs[2].text).toBe('Account Number');
    	expect(isolatedScope.keyValuePairs[2].value).toBe('0069901064910');
    	expect(isolatedScope.keyValuePairs[3].text).toBe('Transaction Reference No.');
    	expect(isolatedScope.keyValuePairs[3].value).toBe('SWI001166');
    	expect(isolatedScope.keyValuePairs[4].text).toBe('Request Date and Time ');
    	expect(isolatedScope.keyValuePairs[4].value).toBe('Oct 16,2016');
    	expect(isolatedScope.keyValuePairs[5].text).toBe('Withdrawl Type');
    	expect(isolatedScope.keyValuePairs[5].value).toBe('Capital Appreciation');
    	expect(isolatedScope.keyValuePairs[6].text).toBe('Amount');
    	expect(isolatedScope.keyValuePairs[6].value).toBe('Capital Appreciation');
    	expect(isolatedScope.keyValuePairs[7].text).toBe('Frequency');
    	expect(isolatedScope.keyValuePairs[7].value).toBe('Monthly');
        expect(isolatedScope.keyValuePairs[8].text).toBe('SWP Start Date');
        expect(isolatedScope.keyValuePairs[8].value).toBe($filter('date')(swpObject.startDate, 'dd MMM yyyy'));
        expect(isolatedScope.keyValuePairs[9].text).toBe('SWP End Date');
        expect(isolatedScope.keyValuePairs[9].value).toBe($filter('date')(swpObject.endDate, 'dd MMM yyyy'));
    	advisor = true;
    });

	 it('should define the variable keyValuePairs if advisor logged in',function(){    	       
        expect(isolatedScope.keyValuePairs[0].text).toBe('Transaction Reference No.');
        expect(isolatedScope.keyValuePairs[0].value).toBe('SWI001166');
        expect(isolatedScope.keyValuePairs[1].text).toBe('Request Date and Time ');
        expect(isolatedScope.keyValuePairs[1].value).toBe('Oct 16,2016');
        expect(isolatedScope.keyValuePairs[2].text).toBe('Amount');
        expect(isolatedScope.keyValuePairs[2].value).toBe('Capital Appreciation');
        expect(isolatedScope.keyValuePairs[3].text).toBe('Frequency');
        expect(isolatedScope.keyValuePairs[3].value).toBe('Monthly');
        expect(isolatedScope.keyValuePairs[4].text).toBe('SWP Start Date');
        expect(isolatedScope.keyValuePairs[4].value).toBe($filter('date')(swpObject.startDate, 'dd MMM yyyy'));
        expect(isolatedScope.keyValuePairs[5].text).toBe('SWP End Date');
        expect(isolatedScope.keyValuePairs[5].value).toBe($filter('date')(swpObject.endDate, 'dd MMM yyyy'));        
        expect(isolatedScope.keyValuePairs[6].text).toBe('No of Installments');
        expect(isolatedScope.keyValuePairs[6].value).toBe(6);
    });      
});