define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'appmodules/ncst/app/data/country-list',
    'appmodules/contactprofile/app/models/cpviewmodel', 'text!appmodules/gpm/app/templates/gpmentity.html',
    'appcommon/commonutility', 'appcommon/constants', 'appcommon/data', 'components/js/views/RadioButtonView', 'appcommon/abstractview'
], function ($, _, Backbone, Utils, DropdownListData, CPViewModel, EntityTemplate, CommonUtility, Constants, AppData, RadioButtonView, AbstractView) {
    var entitytView = AbstractView.extend({
        el: "#gpm-form-update-field-container",
        id: 'gpm-form-update-field-container',
        entityLocation: 'entityLocation',
        operationalityViewName: 'operationalityViewName',
        events: {
            'click .is-operating-entity': 'toggleOperatingEntity',
            'change input[name="aeAddressType"]': 'toggleAddressType',
            'change input[type="radio"]': 'toggleRadioClassActive',
            'change select#pt-select-industry': 'handleEmpIndustryOptions',
            'change select#pt-select-entity-type': 'handleEntityTypeOptions',
        },
        template: _.template(EntityTemplate),
        initialize: function (data) {
            AbstractView.prototype.initialize.apply(this, arguments);
            this.data = data;
            this.isEntity = false;
            AbstractView.prototype.initialize.apply(this, arguments);            
        },
        render: function (updateMode) {
            var self = this;

            try {                
                if (!this.model.get('currentItemSet')) {
                    var CPData = CPViewModel.getInstance().getData();
                    this.data.fieldsInfo = this.getGPMData(CPData);                   
                    this.model.set('isNotInCM', this.data.fieldsInfo.isNotInCM);
                    this.model.setCurrentValue(updateMode, { data: this.data });
                }

                var _dataSet = this.model.get('items');
                var _isDevice = this.model.get('isDevice');

                var _compiledTemplate = this.template({ data: _dataSet, validEntityOptions: AppData.entityTypesViewOnly });
                $("#" + this.id).html(_compiledTemplate).promise().done(function () {
                    self.initializeVars();

                    $('.helper-text-container').hide();

                    //entity type
                    var entityType = _dataSet.find(function (row) { return row.get("itemType") == "entityType" });
                    $("#pt-select-entity-type").val(entityType.get("changedItemValue"));

                    self.loadEntityTypeList(entityType.get("changedItemValueId"));

                    //Industry type
                    var industryClassifyType = _dataSet.find(function (row) { return row.get("itemType") == "industryClassifyType" });
                    self.$industryClassfctn.val(industryClassifyType.get("changedItemValue"));
                    self.loadIndustryTypeList(industryClassifyType.get("changedItemValueId"));
                                       
                    //Industry type free form text
                    if (industryClassifyType.get("changedItemValue") == "Other") {
                        self.$otherIndustryTxtContainer.removeClass('hidden');
                        var industryFreeFormText = _dataSet.find(function (row) { return row.get("itemType") == "industryFreeFormText" });
                        self.$otherIndustryText.val(industryFreeFormText.get("changedItemValue"));
                    }
                    else {
                        self.$otherIndustryText.val('');
                        self.$otherIndustryTxtContainer.addClass('hidden');
                    }

                    //render Operationality Radios
                    var nonOperEntyCd = _dataSet.find(function (row) { return row.get("itemType") == "nonOperEntyCd" });
                    self.renderOperationalityRadios(nonOperEntyCd.get("changedItemValueId"));

                    //set the state/country field
                    var addressType = self.model.get('items').find(function (row) { return row.get("itemType") == "addressType" });                    
                    var stateName = self.model.get('items').find(function (row) { return row.get("itemType") == "stateCd" });
                    var countryName = self.model.get('items').find(function (row) { return row.get("itemType") == "frgnCtryCd" });
                    self.renderEntityEstablishedLocationRadioBtns(addressType.get('changedItemValue'));
                    self.loadEmploymentStateList(stateName.get('changedItemValue'));
                    self.loadEmploymentCntryList(countryName.get('changedItemValueId'));

                    self.conditionalDisplayByEntity(entityType.get("changedItemValue"));
                });                                      
            }
            catch (error) {
                console.log(error);
            }
            $("#gpm-form-update-field-container").invokeInfoPopup();
        },
        initializeVars: function () {
            this.$entityType = $("#pt-select-entity-type");
            this.$industryClassfctn = $("#pt-select-industry");
            this.$indtryClsContnr = $("#industry-classification");
            this.$otherIndustryTxtContainer = $("#pt-industry-other");
            this.$otherIndustryText = $("#pt-industry-other-input");
            this.$isOperationgEntity = $("#operationality-radio-container");            
            this.$stateList = $("#state-list-select");
            this.$countryList = $("#country-list-select");
        },
        getItemByCd: function (itemTypeCd, searchKey, possibleOptions, defaultVal) {
            var item = defaultVal || {
                name: "",
                code: "",
                serviceValue: ""
            };
            item = (_.find(possibleOptions, function (obj) {
                return obj[searchKey] == itemTypeCd;
            }) || item);
            return item;
        },

        handleEntityTypeOptions: function (event) {            
            $('.helper-text-container').hide();
            var selectedOption = $(event.target).val();

            //Conditional display of fields based on Entity type            
            var industryOptionCode = ['1C', '1S', '02', '05', '6C', '6S', '10'];
            var operatingEntityCode = ['1C', '1S', '02', '05', '6C', '6S', '10'];
            var entityLocationCode = ['1C', '1S', '02', '04', '05', '6C', '6S', '09', '10'];

            if (_.contains(industryOptionCode, selectedOption)) {
                $('#industry-classification, #operating-entity').removeClass('hidden');               
            } else {
                $('#industry-classification, #pt-industry-other, #operating-entity').addClass('hidden');
            }

            var entityEstblshdLocalityView = this.getNestedView(this.entityLocation);
            var entityEstablishedLocality = entityEstblshdLocalityView.selectedItem;

            //Conditional dispaly based on entity type
            if (_.contains(entityLocationCode, selectedOption)) {                
                $('#entity-established-location').removeClass('hidden');
                if (entityEstablishedLocality.id == "US") {
                    $('#entity-state-list-holder').removeClass('hidden');
                    $('#entity-country-list-holder').addClass('hidden');
                }
                else
                {
                    $('#entity-state-list-holder').addClass('hidden');
                    $('#entity-country-list-holder').removeClass('hidden');
                }
            } else {
                $('#entity-established-location').addClass('hidden');
                $('#entity-state-list-holder').addClass('hidden');
                $('#entity-country-list-holder').addClass('hidden');
            }                                                                   
        },
        conditionalDisplayByEntity: function (entityTypCd) {
            var _entityData = this.model.get('items');
            var _industryClassifyType = _entityData.find(function (row) { return row.get("itemType") == "industryClassifyType" });
            var _industryFreeFormText = _entityData.find(function (row) { return row.get("itemType") == "industryFreeFormText" });
            var _nonOperEntyCd = _entityData.find(function (row) { return row.get("itemType") == "nonOperEntyCd" });
            var _addressType = _entityData.find(function (row) { return row.get("itemType") == "addressType" });
            var _stateCd = _entityData.find(function (row) { return row.get("itemType") == "stateCd" });
            var _frgnCtryCd = _entityData.find(function (row) { return row.get("itemType") == "frgnCtryCd" });                                                            

            if (_industryClassifyType.get("customValues")["viewDisplay"]) {
                $('#industry-classification').removeClass('hidden');
            } else {
                $('#industry-classification').addClass('hidden');
            }

            if (_industryFreeFormText.get("customValues")["viewDisplay"]) {
                $('#pt-industry-other').removeClass('hidden');
            } else {
                $('#pt-industry-other').addClass('hidden');
            }

            if (_nonOperEntyCd.get("customValues")["viewDisplay"]) {
                $('#operating-entity').removeClass('hidden');
            } else {
                $('#operating-entity').addClass('hidden');
            }

            if (_addressType.get("customValues")["viewDisplay"]) {
                $('#entity-established-location').removeClass('hidden');
            } else {
                $('#entity-established-location').addClass('hidden');
            }

            if (_stateCd.get("customValues")["viewDisplay"]) {
                $('#entity-state-list-holder').removeClass('hidden');
            } else {
                $('#entity-state-list-holder').addClass('hidden');
            }

            if (_frgnCtryCd.get("customValues")["viewDisplay"]) {
                $('#entity-country-list-holder').removeClass('hidden');
            } else {
                $('#entity-country-list-holder').addClass('hidden');
            }          
        },     
        industryClassification: function (indsClsCd) {
            var mappingCode = Constants.industryClassifications;
            var indsName = "";
            _.each(mappingCode, function (list) {
                if (list.name == indsClsCd) {
                    indsName = list.code;
                }
            });
            return indsName;
        },
        renderOperationalityRadios: function (operationalityValue) {
            var operationalityView,
                selectedList = [];
            operationalityView = new RadioButtonView({
                el: this.$('#operationality-radio-container'),
                items: [{ description: 'Non-Operational', id: 'Y' },
                        { description: 'Operational', id: 'N' }]
            });
            if (operationalityValue != null && operationalityValue.length > 0) {
                if (operationalityValue.valueOf() == 'Y') {
                    selectedList = { description: 'Non-Operational', id: 'Y' };
                } else {
                    selectedList = { description: 'Operational', id: 'N' };
                }
                operationalityView.selectedItem = selectedList;
            }

            this.addNestedView(this.operationalityViewName, operationalityView);
            operationalityView.render();
        },

        loadEntityTypeList: function (selEntityType) {
            var _entityTypeList = AppData.entityTypesViewOnly;
            var _selectbox = "#pt-select-entity-type";
            var _options = {
                selectBox: _selectbox,
                optionsList: _entityTypeList,
                selectedVal: selEntityType,
                noEmptyOption: false,
            }
            Utils.loadSelectbox(_options);            
        },

        loadIndustryTypeList: function (selIndusType) {
            var _industryTypeList = Constants.industryClassifications;
            var _selectbox = "#pt-select-industry";
            var _options = {
                selectBox: _selectbox,
                optionsList: _industryTypeList,
                selectedVal: selIndusType,
                noEmptyOption: false,
            }
            Utils.loadSelectbox(_options);
        },
        
        toggleOperatingEntity: function (obj) {
            var _$clickedButton = $(obj.currentTarget);
            if (_$clickedButton.hasClass('active')) {
                return false;
            } else {
                this.$isOperationgEntity.find('.is-operating-entity').removeClass('active');
                _$clickedButton.addClass('active');
            }
        },
        loadEmploymentStateList: function (selectedValue) {
            var _stateList = DropdownListData.USStateslist;
            var _selectbox = "#state-list-select";            
            var _options = {
                selectBox: _selectbox,
                optionsList: _stateList,
                selectedVal: selectedValue,
                noEmptyOption: false,
                isOptional: false,
                noneOption: {
                    value: "",
                    label: "None"
                }
            }
            Utils.loadSelectbox(_options);
        },
        loadEmploymentCntryList: function (selectedValue) {
            var _stateList = DropdownListData.employerCountryList;
            var _selectbox = "#country-list-select";            
            var _options = {
                selectBox: _selectbox,
                optionsList: _stateList,
                selectedVal: selectedValue,
                noEmptyOption: false,
                isOptional: false
            }
            Utils.loadSelectbox(_options);
        },       

        validateAndNavigateFromStep1: function () {           
            if (this.model.validate('gpm-update-form', true)) {
                var fieldValues = this.getFieldValuesFromUI();                
                this.model.setChangedValue({ "entityDetails": fieldValues });                
                if (this.model.getChangedItems().length > 0) {                    
                    $('.gpm-step.step1').addClass("finished").removeClass("active");
                    $('.gpm-step.step2').addClass("active");
                    Backbone.history.navigate('gpm/verification/' + this.model.get('updateMode'), true);
                    return;
                } else {
                    Utils.showNoChangesMessageToUser();
                }
            }            

            if (!this.$otherIndustryTxtContainer.hasClass('hidden')) {
                var industryOtherInput = this.$otherIndustryText.val();
                if (industryOtherInput.length == 0) {
                    this.$indtryClsContnr.addClass('error');
                }
            }
            var showErrFlag;
            for (var key in this.nestedViews) {
                if (key.indexOf("entityLocation") > -1) {
                    if (this.nestedViews[key].selectedItem == null) {
                        nestedViewId = this.nestedViews[key].el.id;
                        showErrFlag = true;
                    } else {
                        showErrFlag = false;
                    }
                }

                if (key.indexOf("operationalityViewName") > -1) {
                    if (this.nestedViews[key].selectedItem == null) {
                        nestedViewId = this.nestedViews[key].el.id;
                        showErrFlag = true;
                    } else {
                        showErrFlag = false;
                    }
                }                

                if (showErrFlag) {
                    $("div [data-for=" + nestedViewId + "]").addClass('error');
                    $("div [data-for=" + nestedViewId + "] .ncst-adjust-left").removeClass('hidden');
                    this.nestedViews[key].showError(true);
                }
            }
        },           
       
        handleEmpIndustryOptions: function () {
            var selectedOption = this.$industryClassfctn.find("option:selected").text();
            if (selectedOption == "Other") {
                this.$otherIndustryTxtContainer.removeClass('hidden');
                this.$otherIndustryText.val("");
            } else {
                this.$otherIndustryTxtContainer.addClass('hidden');
            }
        },
        toggleAddressType: function () {
            this.hideRelatedFieldsBasedOnType();
        },
        hideRelatedFieldsBasedOnType: function (selectedItem) {
            var _$container = $('#gpm-form-update-field-container');            
            if (selectedItem.id == "US") {
                _$container.find('.address-type-foreign').addClass("hidden");
                _$container.find('.address-type-us').removeClass("hidden");                                
            } else {
                _$container.find('.address-type-foreign').removeClass("hidden");
                _$container.find('.address-type-us').addClass("hidden");                                
            }
        },
        toggleRadioClassActive: function (event) {
            var _radio = $(event.target);
            var _radioHolder = _radio.parents('div.radio-grp-holder');
            _radioHolder.find('div.radio-group-conatiner').removeClass('active');
            _radio.parents('div.radio-group-conatiner').addClass('active');
        },
        getGPMData: function (CPData) {
            var _ebixData = {}, _isNotInCM = false, _riskProfile = {}, _orgCLient,
                _clientPersonal;
            if (!(CPData.cola && CPData.cola && CPData.cola.orgClient)) {
                BootstrapDialog.alert("Failed to retrieve information. Please try again later.");
                return;
            }
            if (CPData.cola) {
                _orgCLient = CPData.cola.orgClient.attributes;
                _riskProfile = CPData.cola.riskProfile;
                _clientPersonal = CPData.cola.clientPersonal;

            }
            if (CPData.ebix) {
                _ebixData = CPData.ebix.PersonContact.attributes;
            } else {
                _isNotInCM = true;
            }
            //once Pooja fix UI issue use entityTypesViewOnly instead of entityTypes
            var _entityTypeCd = this.getItemByCd(_orgCLient.formOfBusOwnshpCd, "serviceValue", AppData.entityTypesViewOnly, { name: "", code: "", serviceValue: "" });
            var _indsClsCd = this.getItemByCd(_riskProfile.indsClsCd, "code", Constants.industryClassifications, { name: "", code: "" });

            var _indsClsTxt = _riskProfile.indsClsTxt != null ? _riskProfile.indsClsTxt : "";
                _indsClsTxt = _indsClsTxt.trim();
            var _nonOperEntyCd = _riskProfile.nonOperEntyCd ? _riskProfile.nonOperEntyCd : "";
                _nonOperEntyCd = _nonOperEntyCd.trim();
            var _isForeignEntity = CommonUtility.hasValue(_orgCLient.frgnOrgInd)?_orgCLient.frgnOrgInd:"" ;
            var _frgnCtryCd = CommonUtility.hasValue(_orgCLient.frgnCtryCd)? _orgCLient.frgnCtryCd: "";
            var _stOfIncorpCd = CommonUtility.hasValue(_orgCLient.stOfIncorpCd) ? _orgCLient.stOfIncorpCd: "";
            var _usResStatCd = CommonUtility.hasValue(_clientPersonal.get("usResStatCd"))  ?_clientPersonal.get("usResStatCd"): "";
            var _fieldsInfo = {
                entityType: _entityTypeCd,
                indsClsCd: _indsClsCd,
                indsFreeFormTxt: _indsClsTxt,
                nonOperEntyCd : _nonOperEntyCd,
                addressType: (_isForeignEntity == "US" || _isForeignEntity == "") ? "US" : "Foreign",
                stateCd: _stOfIncorpCd,
                frgnCtryCd: _frgnCtryCd,
                isNotInCM: _isNotInCM
            };
            console.log(_fieldsInfo, "_fieldsInfo");
            return _fieldsInfo;
        },

        renderEntityEstablishedLocationRadioBtns: function (locationCode) {
            var self = this, componentId = "entity-established-location-radiobuttons", radioButtonsView;            
            var locationList = [{ description: 'U.S.', id: 'US' }, { description: 'Foreign', id: 'Foreign' }];

            radioButtonsView = new RadioButtonView({
                el: self.$('#' + componentId),
                items: locationList
            });

            if (locationCode != "") {
                _.find(locationList, function (list) {
                    if (list.id == locationCode) {
                        radioButtonsView.selectedItem = list;
                    }
                });
            }
            radioButtonsView.itemSelectionComplete = function (selectedItem) {
                self.hideRelatedFieldsBasedOnType(selectedItem);
            };

            this.addNestedView(this.entityLocation, radioButtonsView);
            radioButtonsView.render();
        },

        clearEmployedRelatedData: function () {
            return;
            var _items = this.model.get('items');
            var _entityTypeCd = _items.find(function (row) { return row.get("itemType") == "entityTypeCd" }),
			_indsClsCd = _items.find(function (row) { return row.get("itemType") == "indsClsCd" }),
			_indsClsTxt = _items.find(function (row) { return row.get("itemType") == "indsClsTxt" }),
            _nonOperEntyCd = _items.find(function (row) { return row.get("itemType") == "nonOperEntyCd" }),
			_addressType = _items.find(function (row) { return row.get("itemType") == "addressType" }),
			_stateCd = _items.find(function (row) { return row.get("itemType") == "stateCd" }),
			_frgnCtryCd = _items.find(function (row) { return row.get("itemType") == "frgnCtryCd" });		
        },
        getFieldValuesFromUI: function () {            
            var $selectedCountryOptmn = this.$countryList.find("option:selected");
            var $stateofOperation = this.$stateList.find("option:selected");
            var entityEstblshdLocalityView = this.getNestedView(this.entityLocation);
            var entityType = this.getItemByCd(this.$entityType.find("option:selected").val(), "serviceValue", AppData.entityTypesViewOnly, { name: "", code: "", serviceValue: "" });                               
            var indsClsftcn = this.getItemByCd(this.$industryClassfctn.find("option:selected").val(), "code", Constants.industryClassifications, { name: "", code: "", serviceValue: "" });
            var indsClsTxt = indsClsftcn && indsClsftcn.name == "Other" ? this.$otherIndustryText.val() : "";                       
            var isOperatingEntity = (this.getNestedView(this.operationalityViewName)).selectedItem;
            var entityEstablishedLocality = entityEstblshdLocalityView.selectedItem;                                    
            var foreignCountryCd = entityEstablishedLocality.id !== "US" ? $selectedCountryOptmn.val() : "";
            var foreignCountryNm = foreignCountryCd? $selectedCountryOptmn.text() : "";
            var stateOfEntityOperationCd = entityEstablishedLocality.id == "US" ? $stateofOperation.val() : "";
            var fieldValues = {
                entityType: entityType,
                indsClsftcn: indsClsftcn,
                indsClsTxt: indsClsTxt,
                isOperatingEntity: isOperatingEntity,
                entityEstablishedLocalityType: entityEstablishedLocality.id,
                foreignCountryCd: foreignCountryCd,
                foreignCountryNm: foreignCountryNm,
                stateOfEntityOperationCd: stateOfEntityOperationCd
            };
            return fieldValues;
        }
    });
    return entitytView;
});

