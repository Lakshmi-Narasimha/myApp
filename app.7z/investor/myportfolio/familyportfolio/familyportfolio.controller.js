/**
 * @ngdoc property
 * @name  FamilyPortfolioController Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function FamilyPortfolioController($scope,myportfolioConstants,invInstantMailback,downloadService,familyPortfolioInitialLoader,familyPortfolioModel,investorEventConstants,investorEvents,investorConstants) {
    $scope.appName = myportfolioConstants.overview.INV_APP_NAME;
    
    invInstantMailback.setMailBackData({
        folioPanAcc: '',
        fromDate: '',
        toDate: '',
        periodType: ''
    });
    downloadService.setQueryparams({
        strInputData: '',
        inputFlag: 'FP',
        periodType: '',
    });
    $scope.$on(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_LIST,function(){
        var index = 0;
        familyPortfolioInitialLoader._isServicesData = true;
        $scope.userName = [];
        $scope.memberDetailsList = [];
        $scope.approvedList = [];
        $scope.primaryOwnerPan = familyPortfolioModel.getFamilyPFList().primaryPan;
        $scope.pendingList = familyPortfolioModel.getFamilyPFList().pending;
        _.each($scope.pendingList, function(){
            $scope.userName.push({
                text: 'Username',
                type:'text',
                value: '',
                isRequired: true,
                errorMessage:''
            });
        });
        //moving owner object to top of the approvedList
        _.each(familyPortfolioModel.getFamilyPFList().approved, function(element){
            if(element.pan === $scope.primaryOwnerPan ){
                $scope.approvedList[0] =  element;
            }else{
                ++index;
                $scope.approvedList[index] =  element;
            }
        });
    });
    if(!familyPortfolioInitialLoader._isServicesData){
        familyPortfolioInitialLoader.loadAllServices($scope);
    }else{
        investorEvents.myPortfolio.familyPortfolioList($scope);
    }
    $scope.isMobileDevice = true;
    $scope.status = {open: false};
    $scope.portfolioType = investorConstants.myportfolio.FAMILY_PORTFOLIO_TYPE;
    $scope.$on(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_PANVIEW_EVENT,function(event , data){
        $scope.$broadcast(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_PANVIEW,data);
    });
}
FamilyPortfolioController.$inject = ['$scope','myportfolioConstants','invInstantMailback','downloadService','familyPortfolioInitialLoader','familyPortfolioModel','investorEventConstants','investorEvents','investorConstants'];
module.exports = FamilyPortfolioController;

