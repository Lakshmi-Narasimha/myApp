
/**
 * @ngdoc property
 * @name fticAmntChangeSip Directive
 * 
 * @description
 *
 * - This directive is responsible for acquiring the Flexi SIP details.
 *
 **/
'use strict';


var fticAmntChangeSip = function (transactEventConstants,SipModifyDetailModel,$state,eventConstants,transactModel,$filter,fundDetails,TransactConstant) {

    return {
        template: require('./amtchangesip.html'),
        restrict: 'E',
        replace: true,
        scope: {
            sipType:"@"
        },
        controller:['$scope', function ($scope) {
            
            var datefilter = $filter('date');
            var susObj = transactModel.getFundDetails();
            var condCheck = false;
            $scope.sipAmtChange = {};
            $scope.EnableConfirm = false;
            $scope.strtDate = datefilter(susObj.nextTriggerDate, 'dd MMM yyyy'); 
            $scope.config = {};
            $scope.config.showNotification = false;
            $scope.getSelections = function(){
                if($scope.amtChnForm.$valid) {
                    $scope.sipAmtChange.sipModifyType = $scope.sipType;
                    $scope.sipAmtChange.txnSource = "SIPAMC";
                    $scope.sipAmtChange.sipOptionName = "SIP Amount Change";
                    $scope.sipAmtChange.newSipAmount = $scope.amntChange;
                    $scope.sipAmtChange.strtDate = $scope.strtDate;
                    SipModifyDetailModel.setModifySipDetails($scope.sipAmtChange);

                    if(susObj.paymentMode === TransactConstant.common.EMANDATE_CODE || susObj.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                        if (susObj.achDebitType == "F"){
                                condCheck = true;
                        } 
                        else {
                            if($scope.amntChange > parseInt(susObj.achAmount)){
                                condCheck = true;
                            }else{
                                condCheck = false;
                            }
                        }
                    }
                    if(condCheck){   
                        $scope.config.showNotification = true;
                    }else{
                        $scope.$emit(transactEventConstants.transact.Set_Modify_Sip_Details);
                    } 
                }; 
            };
            $scope.$on('yes', function(event, data){
                $scope.config.showNotification = false;
                $scope.$emit(transactEventConstants.transact.Set_Key_Value_Object);  
                $scope.$emit(transactEventConstants.transact.Payment_Detail);
            }); 
            $scope.$on('no', function(event, data){
                 $scope.config.showNotification = false;
            });

            $scope.$on(eventConstants.CHECKBOX_CHECKED, function($event, checkboxObject){
                if (checkboxObject.value) {
                    $scope.EnableConfirm = true;
                } else {
                    $scope.EnableConfirm = false;
                }
            });      
           
        }]
    };
};

fticAmntChangeSip.$inject = ['transactEventConstants','SipModifyDetailModel','$state','eventConstants','transactModel','$filter','fundDetails','TransactConstant'];

module.exports = fticAmntChangeSip;