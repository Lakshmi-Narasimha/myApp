// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var TaxAdvantageCalculatorSchema = new mongoose.Schema({
    taxAdvantageCalculatorObject: {
        type: Array,
        "default": []
    }
});

var TaxAdvantageCalculatorLookUp = mongoose.model('TaxAdvantageCalculatorLookup', TaxAdvantageCalculatorSchema);

var TaxAdvantageCalculatorModel = new TaxAdvantageCalculatorLookUp({

  "taxAdvantageCalculatorObject": [
    {
  "taxAdvantageCalculatorResp": [{
    "fundName": "Franklin India Prima Plus",
    "returnData": [
      {
        "year": 1,
        "amountInvested": "10,000",
        "valueOfAmount": "11,000",
        "capitalGain": "1,000",
        "taxImplication": "150",
        "fdTaxImplication": "300"
      },
      {
        "year": 2,
        "amountInvested": "20,000",
        "valueOfAmount": "22,000",
        "capitalGain": "2,000",
        "taxImplication": "Nil",
        "fdTaxImplication": "600"
      }
    ]
  }]
}
    ]

});

TaxAdvantageCalculatorLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating TaxAdvantageCalculatorLookUp table, please contact admin...');
    } else {
        TaxAdvantageCalculatorLookUp.remove({}, function(err) {
            console.log('AdvisorContentLookUp collection removed');
            TaxAdvantageCalculatorModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating TaxAdvantageCalculatorLookUp table, please contact admin...');
                }
                console.log('TaxAdvantageCalculatorLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = TaxAdvantageCalculatorLookUp;
