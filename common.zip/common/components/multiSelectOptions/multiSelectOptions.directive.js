/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var multiSelectOptions = function($state) {
  return {
            template: require('./multiSelectOptions.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              options: "=",
              maxSelection: "=",
              errorMessage: "="
            },
            controller:['$scope', function($scope){  
                
                //$scope.selectedFunds = $scope.options || [];
                $scope.selectedFunds = [];
                $scope.messageLabel = false;
                for(var i=0; i< $scope.options.length; i++){                                   
                    if($scope.options[i].selected == true){
                       $scope.messageLabel = false;
                      $scope.selectedFunds.push($scope.options[i]);
                    }                                       
                  }
                  $scope.$emit('RESET_MULTISELECT_OPTIONS');
                  $scope.$emit('SET_OPTIONS_LIST', $scope.selectedFunds);
                if($scope.popOut == true){
                  $scope.selectedFunds = $scope.options || [];  
                }

                //check for whether a fund already selected if so remove it, else add it.
                $scope.selectFund = function(fund){
                  var isDuplicate = false, duplicateIndex = undefined; 
                  for(var i=0; i < $scope.selectedFunds.length; i++){                 
                    if($scope.selectedFunds[i].lable == fund.lable){
                      isDuplicate = true;
                      duplicateIndex = i;
                      break;
                    } 
                        $scope.messageLabel = false;               
                  }
                
                  if(!isDuplicate){
                    $scope.selectedFunds.push(fund);          
                  }
                  else{
                    $scope.selectedFunds.splice(duplicateIndex, 1);                  
                  }
                  if($scope.maxSelection < $scope.selectedFunds.length){
                     $scope.messageLabel = true;
                  } else {
                    $scope.messageLabel = false;
                  }

                }

                $scope.doneSelection = function(){
                  $scope.$emit('multipleSelectionDone', {selections: $scope.selectedFunds, searchCategory : $scope.searchCategory});
                }

                $scope.resetSelection = function(){
                  // $scope.fundSelection = false;
                  $scope.messageLabel = false;
                  $scope.selectedFunds = [];

                  for(var i=0; i<$scope.options.length; i++){
                      $scope.options[i].selected = false;
                  }

                  $scope.$emit('RESET_MULTISELECT_OPTIONS');
                }
                $scope.$on("mFundFilter", function (event, data) {
                $scope.filterText = data.filterText;
                });
                $scope.$on('emittingChannelSearchOption', function (event, data) {
                  $scope.searchCategory = data;
                });
            }]
        };
};

multiSelectOptions.$inject = [];
module.exports = multiSelectOptions;