define(['jquery', 'lodash', 'backbone'
], function ($, _, Backbone) {

    var CompTeam = Backbone.Model.extend({
        defaults: function () {
            return {
                compTeamId: undefined, // String
                compTeamMembers: undefined, // [Advisor]
            };
        },
        populateFromDistributorResponse: function (responseEntity) {
            this.set('compTeamId', responseEntity.compTeamId);
            this.set('id', responseEntity.compTeamId);

            return this;
        },
        description: function () {
            return this.get("compTeamId");
        }
    });

    return CompTeam;
});
