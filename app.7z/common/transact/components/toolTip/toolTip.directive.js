/**
 * @ngdoc property
 * @namefticTtoolTip Directive
 * @description
 *
 *
 *
 **/
'use strict';

var tooltip = function() {
    return {
            template: require('./toolTip.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                tooltipTxt:"@"
            }
        };
};

tooltip.$inject = [];
module.exports = tooltip;