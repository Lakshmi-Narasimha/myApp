define([],function(){
    var honorific =
    [
	    { datavalue: "", value: "" },
        { datavalue: "Dr", value: "Dr" },
        { datavalue: "Hon", value: "Hon" },
        { datavalue: "Miss", value: "Miss" },
        { datavalue: "Mr", value: "Mr" },
        { datavalue: "Mrs", value: "Mrs" },
        { datavalue: "Ms", value: "Ms" },
        { datavalue: "Prof", value: "Prof" },
        { datavalue: "Rev", value: "Rev" },
        { datavalue: "Sir", value: "Sir" }
    ],
    confirmationPageActionMapping = {
        "gender": {
            "columnLayout": 1,
            "actions": []
        },
        "greeting": {
            "columnLayout": 1,
            "actions": []
        },
        "gender": {
            "columnLayout": 1,
            "actions": []
        },
        "remarks": {
            "columnLayout": 1,
            "actions": []
        },
        "dependents": {
            "columnLayout": 1,
            "actions": []
        },
        "honorific": {
            "columnLayout": 1,
            "actions": []
        },
        "maritalstatus": {
            "columnLayout": 2,
            "actions": [{
                "actionId": "gpmAction1",
                "orderIndex": 1
            }, {
                "actionId": "gpmAction2",
                "orderIndex": 2
            }, {
                "actionId": "gpmAction3",
                "orderIndex": 3
            }, {
            	"actionId": "gpmAction4",
            	"orderIndex": 4
            }]
        },
        "passport": {
            "columnLayout": 1,
            "actions": []
        },
        "subtype": {
            "columnLayout": 1,
            "actions": []
        },
        "employment": {
            "columnLayout": 1,
            "actions": []
        },
        "suitability": {
            "columnLayout": 1,
            "actions": []
        },
        "driverslicense": {
            "columnLayout": 1,
            "actions": []
        },
        "alert": {
            "columnLayout": 1,
            "actions": []
        },
        "communicationPreference": {
            "columnLayout": 1,
            "actions": []
        },
        "phonenumbers": {
            "columnLayout": 1,
            "actions": []
        },
        "email": {
            "columnLayout": 1,
            "actions": []
        },
        "documentDelivery": {
            "columnLayout": 1,
            "actions": []
        },
        "reportclientsdeath": {
            "columnLayout": 1,
            "actions": []
        },
        "reportclientsdivorce": {
            "columnLayout": 1,
            "actions": []
        }
    },
    actions = [
       {
           "actionId": "gpmAction1",
           "actionTitle": "Report pending divorce",
           "actionDesc": "",
           "actionType": "text",
           "external": false,
           "url": "gpm/reportclientsdivorce",
           "dropdownOptions": [],
           "cssClass": "upt-addrs pt-link-to-app-icon external",
       },
        {
            "actionId": "gpmAction2",
            "actionTitle": "Combine clients into a household group",
            "actionDesc": "household",
            "actionType": "url",
            "external": true,
            "url": "eformsUrl",
            "dropdownOptions": [],
            "cssClass": "upt-addrs pt-edit-svg-icon",
        }, {
        	"actionId": "gpmAction3",
        	"actionTitle": "Update address",
        	"actionDesc": "",
        	"actionType": "text",
        	"external": false,
        	"url": "coa/",
        	"dropdownOptions": [],
        	"cssClass": "upt-addrs pt-edit-svg-icon",
        }, {
        	"actionId": "gpmAction4",
        	"actionTitle": "Set up new client",
        	"actionDesc": "",
        	"actionType": "text",
        	"external": false,
        	"url": "ncst/",
        	"dropdownOptions": [],
        	"cssClass": "upt-addrs pt-setup-client-icon",
        }
    ];
    return { honorific: honorific, actionMapping: confirmationPageActionMapping, actions: actions };
});