/**
 * @ngdoc directive
 * @name fticInvDbParkMyMoney
 * @requires dashboardConstants
 * @requires investorConstants
 * @requires investorEventConstants
 * @requires investorDashboardDetailsModel
 * @description
 *
 * - It displays One Touch Investment Section.
 *
 **/

'use strict';

var oneTouchInvest = function (dashboardConstants, investorConstants, investorEventConstants, investorDashboardDetailsModel, loggerConstants, fticLoggerMessage) {
    return {
        template: require('./invDbOneTouchInvest.html'),
        restrict: 'E',
        replace: true,
        scope: true,
        link: function (scope) {
            scope.isDataAvailable = false;
            scope.info = { heading: investorConstants.dashboard.ONE_TOUCH_INVEST };
            scope.buttonLinks = dashboardConstants.dashboard.ONE_TOUCH_INVEST.BUTTON_LINKS;
            scope.$on(investorEventConstants.Dashboard.INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH, function () {
                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_ONE_TOUCH_INVEST_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_SMART_SAV_ACC_AND_ONE_TOUCH + ' event' /* Function Name */;
                fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
                if (investorDashboardDetailsModel.getSmartSaveAccAndOneTouchData().oneTouchInvest) {
                    scope.initData = investorDashboardDetailsModel.getSmartSaveAccAndOneTouchData().oneTouchInvest;
                    scope.isDataAvailable = true;
                    scope.isTransactionStarted = 'N';
                    if (scope.initData.isPurchaseSet === 'Y') {
                        scope.isTransactionStarted = 'Y';
                    }
                } else {
                    scope.isDataAvailable = false;
                }
            });
            scope.quickInvest = function () {
                investorDashboardInvestServices.getInvestDetails(scope);
                $timeout(function () {
                    var investValues = investorDashboardDetailsModel.getInvestData();
                    if (investValues) {
                        var confirmObj = {
                            'showConfirm': true,
                            'mainHeader': 'One Touch Invest',
                            'popUpBody': {
                                'fundName': investValues.getInvestDetails.Invest[0].InvestInfo,
                                'accountNo': investValues.getInvestDetails.Invest[0].AccountNo,
                                'labelText': 'Purchase',
                                'radioButtons': [
                                    {
                                        'labelText': investValues.getInvestDetails.Invest[0].InstructionAmount,
                                        'name': 'purchaseVal',
                                        'value': 'default'
                                    },
                                    {
                                        'labelText': 'input',
                                        'name': 'purchaseVal',
                                        'value': 'other',
                                        'minAmount': investValues.getInvestDetails.Invest[0].MinimunAmount
                                    }
                                ]
                            },
                            'yesText': 'Confirm',
                            'noText': 'Cancel',
                            'yesEventName': 'submitConfirm',
                            'noEventName': 'hideConfirm'
                        };
                        scope.$emit('showConfirm', confirmObj);
                    }
                }, 0);
            };
        }
    };
};

oneTouchInvest.$inject = ['dashboardConstants', 'investorConstants', 'investorEventConstants', 'investorDashboardDetailsModel', 'loggerConstants', 'fticLoggerMessage'];
module.exports = oneTouchInvest;