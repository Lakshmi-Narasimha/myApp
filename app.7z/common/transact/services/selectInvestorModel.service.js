/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';


var selectInvestorModel= function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, $state) {
    var _investors = null;  
    var _selectedInvestorDtls = null; 
    var _editInvIconChanged = false;
    var _database = null;
    var _selectedInstantInvDtls = null;
    
	var selectInvestorModel = {
        // fetchcgaccountdetails : function () {
        fetchInvestors : function (searchData, pageRange) {
            var searchQuery = {};
            if(searchData.searchOption === "Unit Holder Name"){
                searchQuery.searchType = "N";
            }else if(searchData.searchOption === "PAN"){
                searchQuery.searchType = "P";
            }else if(searchData.searchOption === "Folio No."){
                searchQuery.searchType = "F";
            }else if(searchData.searchOption === "Mobile No." || searchData.searchOption === "Mobile"){
                searchQuery.searchType = "M";
            }else if(searchData.searchOption === "Email ID" || searchData.searchOption === "Email"){
                searchQuery.searchType = "E";
            }else if(searchData.searchOption === "Aadhaar No." || searchData.searchOption === "Aadhaar"){
                searchQuery.searchType = "U";
            }else if(searchData.searchOption === "Account No."){
                searchQuery.searchType = "A";
            }else if(searchData.searchOption === "CAN"){
                searchQuery.searchType = "C";
            }else if(searchData.searchOption === "IIN"){
                searchQuery.searchType = "I";
            }
            searchQuery.guId = authenticationService.getUser() !== null ? authenticationService.getUser().guId : null;
            searchQuery.searchValue = searchData.searchText;
            // searchQuery.distId = "ARN-18734";
            searchQuery.active = "N";
            searchQuery.offset = pageRange.offset;
            searchQuery.limit = pageRange.limit;
            if($state.current.url === '/sip'){
                searchQuery.trxnType = 'SIP';
            }else if($state.current.url === '/buy'){
                searchQuery.trxnType = 'PUR';
            }
            if($state.current.name.indexOf("smartSol") !==-1) {
                searchQuery.fsFlag = "Y";
            }
            var deferred = $q.defer();
            // clients/searchClient --TODO- To update while deployment
            Restangular.one('clients/searchClient').get(searchQuery).then(function (investors) {
                deferred.resolve(investors);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
       
        
        getInvestors : function () {
            if (!angular.isDefined(_investors)) {
                return null;
            }
            return _investors;
        },

        setInvestors : function (investors) {
            _investors = investors;
        },

        setDatabase : function(database){
            _database = database; 
        },

        getDatabase : function(){
            if (!angular.isDefined(_database)) {
                return null;
            }
            return _database;
        },

        getSelectedInvestorDtls: function() {            
            return _selectedInvestorDtls;
        },
        setSelectedInvestorDtls: function(selectedInvestorDtls) {            
            _selectedInvestorDtls = selectedInvestorDtls;
        },
        getEditInvIconChanged: function() {            
            return _editInvIconChanged;
        },
        setEditInvIconChanged: function(editInvIconChanged) {            
            _editInvIconChanged = editInvIconChanged;
        },
        getSelectedInstantInvstrDtls: function() {            
            return _selectedInstantInvDtls;
        },
        setSelectedInstantInvstrDtls: function(selectedInstantInvDtls) {            
            _selectedInstantInvDtls = selectedInstantInvDtls;
        }

    };
    return selectInvestorModel;

};


selectInvestorModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', '$state'];

module.exports = selectInvestorModel;
