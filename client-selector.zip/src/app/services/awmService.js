define([
    'jquery', 'lodash', 'q', 'app/rest-client/restClient', 'config',
    'app/common/util',
    'app/common/constants',
    'app/application/app',
    'app/common/models/User',
    'app/common/models/Advisor',
    'app/common/models/AdvisorCollection',
], function ($, _, Q, defaultRestClient, config,
             util,
             constants,
             app,
             User,
             Advisor,
             AdvisorCollection
) {


    var DEFAULT_CACHE_SECONDS = 300;
    var REALTIME_EXPIRE_MINUTES = 5;
    var DRAFT_LIST_CACHE_TYPE = 'DraftList';
    var DRAFT_CACHE_TYPE = 'Draft';

    var AWMService = function () {

        var restClient = defaultRestClient;
        var defaultAjaxRequestHeaders = {
            'Cache-Control': 'max-age=300',
            'consumer': 'id=A0056064-E5A6EK2IG9557PO3;type=WEB',
            'Content-Type': 'application/json',
            'Accept': 'application/json;'
        };
        var realtimeUrls = {}; // associative array:  key = url, value = Date (when realtime should not be used)

        // PUBLIC

        // response: User
        this.promiseToGetSignOnInformation = function () {
            var servicePath = "ClientLists(id='000030601',ctx='DMU.DIST',type='CAPLIST')/clientRefs";
            return promiseToGet(servicePath, DEFAULT_CACHE_SECONDS, function (responseData) {
                //var signOnUser = new User();
                return responseData.d;
            });
        };

        this.promiseToSetupClientDistributorRelationship = function (clientDistributorRelationshipRequestData, networkRequestStartingFunction /* optional */) {
            var servicePath = "setupClientDistributorTransientRelationship";
            return promiseToPost(servicePath, 0, clientDistributorRelationshipRequestData, function (response) {
                if (response.d.statCd == "0000" &&  !_.isEmpty(response.d.clIdentifier.results)) {
                    var clIdentifier = response.d.clIdentifier.results, clientIds = [];
                    _.each(clIdentifier, (client) => {clientIds.push(client.clId);});
                    return clientIds;
                } else {
                    return {error: true};
                }
            });
        };

        // response: [AdvisorCollection]
        this.promiseToGetOboAdvisors = function () {
            var servicePath = "OBOServlet";
            return promiseToGet(servicePath, DEFAULT_CACHE_SECONDS, function (responseData) {
                var advisorCollection = new AdvisorCollection();
                return advisorCollection.populateFromOboListResponse(responseData);
            });
        };

        // response: [AdvisorCollection]
        this.promiseToGetTeamAdvisors = function () {
            var self = this, defer;
            defer = Q.defer();
            if(util.csrSelectedFmid) {
                self.promisetoGetAdvisorTeamMemberDetails(util.csrSelectedFmid).then(function (advisorCollection) {
                    var advisorsWithSellingAuthority = advisorCollection.getAdvisorsWithSellingAuthority();
                    advisorsWithSellingAuthority.comparator = function (advisor) {
                        return advisor.isCSRSelectedAdvisor() ? "_" : advisor.get('fullName');
                    };
                    advisorsWithSellingAuthority.sort();
                    defer.resolve(advisorsWithSellingAuthority);
                }).fail(function (error) {
                    defer.reject(error);
                });
            } else {
                self.promiseToGetOboAdvisors().then(function (advisorCollection) {
                    advisorCollection.removeNonAdvisorUser();
                    defer.resolve(advisorCollection.advisorsSortedByUserAndName());
                }).fail(function (error) {
                    defer.reject(error);
                });
            }
            return defer.promise;
        };

        // response: DistributorAssistantRelationship
        this.promiseToGetDistributorAssistantRelationship = function(fmid, networkRequestStartingFunction /* optional */) {
            var servicePath = "DistributorAssistantRelationship?$filter=assistantDstrId eq '" + util.formatWithZeros(fmid, 9) + "' and assistantDstrCtx eq 'DMU.DIST'&$format=json";
            return promiseToGet(servicePath, DEFAULT_CACHE_SECONDS, function(responseData) {
                return responseData ? true : false;
            });
        };

        // response: Advisor
        this.promiseToGetDistributorInfo = function(fmid, networkRequestStartingFunction /* optional */) {
            var servicePath = "Distributor(dstrId='" + util.formatWithZeros(fmid, 9) + "',dstrCtx='DMU.DIST')?$expand=dstrPrac,ids&$format=json";
            return promiseToGet(servicePath, DEFAULT_CACHE_SECONDS, function(responseData) {
                var advisor = new Advisor();
                return advisor.populateAdvisorInfo(responseData.d);
            });
        };


        // response: AdvisorCollection (a consolidated list of all advisors to whom the fmid has a team practice relationship)
        this.promisetoGetAdvisorTeamMemberDetails = function (fmid, networkRequestStartingFunction /* optional */) {
            var self = this;
            var defer = Q.defer();
            // Since an advisor can be in multiple practices is it necessary to first find all of the associated
            // practices and then find all of the members of each practice.
            self.promiseToGetDistributorInfo(fmid).then(function (advisor) {
                var practiceMemberPromises = _.map(advisor.get("practices"), function (practice) {
                    return self.promiseToGetPracticeMembers(practice.get("pracId"));
                });
                Q.all(practiceMemberPromises).then(function (advisorCollectionsForAllPractices) {
                    var consolidatedAdvisorCollection = new AdvisorCollection();
                    _.each(advisorCollectionsForAllPractices, function(practiceAdvisorCollection) {
                        consolidatedAdvisorCollection.add(practiceAdvisorCollection.models);
                    });
                    consolidatedAdvisorCollection.add(advisor, {merge: true});
                    defer.resolve(consolidatedAdvisorCollection);
                }).fail(function (error) {
                    defer.reject(error);
                });
            }).fail(function (error) {
                defer.reject(error);
            });
            return defer.promise;
        };

        // response: AdvisorCollection (a consolidated list of all advisors to whom the fmid has a team practice or OBO relationship)
        this.promisetoGetAdvisorTeamAndOboMembers = function (fmid, networkRequestStartingFunction /* optional */) {
            var self = this;
            var defer = Q.defer();
            self.promisetoGetAdvisorTeamMemberDetails(fmid)
                .then(function (advisorCollection) {
                    var teamMemberCollection = advisorCollection.getAdvisorsWithSellingAuthority().clone();
                    teamMemberCollection.add(app.oboAdvisorList);
                    teamMemberCollection.comparator = function (advisor) {
                        return advisor.isUser() ? "_" : advisor.get('fullName');
                    };
                    teamMemberCollection.sort();
                    defer.resolve(teamMemberCollection);
                }).fail(function (error) {
                defer.reject(error);
            });
            return defer.promise;
        };

        /* PRIVATE FUNCTIONS */

        function promiseToGet(servicePath, cacheSeconds, responseTransform, method, requestData, cacheType, networkRequestStartingFunction) {
            var defer = Q.defer();
            var ajaxParams = {url: fullUrl(servicePath), cacheSeconds: cacheSeconds, cacheType: cacheType};
            if (requestData) {
                ajaxParams.data = JSON.stringify(requestData);
            }
            addDefaultHeaders(ajaxParams);
            addCustomHeaders(ajaxParams, servicePath);
            ajaxParams.method = method;
            restClient.promiseToFetch(ajaxParams, networkRequestStartingFunction)
                .then(function (data) {
                    try {
                        var transformedData = (data == null ? null : responseTransform(data));
                        defer.resolve(transformedData);
                    } catch (transformError) {
                        defer.reject(transformError);
                    }
                })
                .fail(function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        }

        function promiseToPost(servicePath, cacheSeconds, requestData, responseTransform) {
            var defer = Q.defer();
            var ajaxParams = {url: fullUrl(servicePath), data: JSON.stringify(requestData)};
            addDefaultHeaders(ajaxParams);
            addCustomHeaders(ajaxParams, servicePath);
            restClient.promiseToPost(ajaxParams)
                .then(function (data) {
                    var transformedData = (data == null ? null : responseTransform(data));
                    defer.resolve(transformedData);
                })
                .fail(function (error) {
                    defer.reject(error);
                });
            return defer.promise;
        }

        function fullUrl(servicePath) {
            if (_.find(config.virtualizedServicePatterns, function(urlRegex) {
                    return servicePath.match(urlRegex);
                }) != null) {
                return config.virtualizedServicePath + servicePath;
            }
            if(servicePath === "OBOServlet") {
                return config.oboServicePath + servicePath;
            }
            return config.awmServicePath + servicePath;
        }

        function addDefaultHeaders(ajaxParams) {
            let headers = _.extend({}, defaultAjaxRequestHeaders);
            if (shouldMakeRealtimeServiceRequest(ajaxParams.url)) {
                headers = _.extend(headers, {'Cache-Control': 'max-age=0'});
            }
            ajaxParams.headers = _.extend(ajaxParams.headers, headers);
        }

        function shouldMakeRealtimeServiceRequest(url) {
            const realtimeExpire = realtimeUrls.url;
            return realtimeExpire ? realtimeExpire.getTime() > new Date().getTime() : false;
        }

        function addCustomHeaders(ajaxParams, servicePath) {
            if (_.includes(servicePath.toLowerCase(), 'draft/')) {
                var draftServiceHeaders = {

                };
                ajaxParams.headers = _.extend(ajaxParams.headers, draftServiceHeaders);
            }
        }

        function forceNearTermRealtimeFetch(url) {
            realtimeUrls.url = new Date(new Date().getTime() + REALTIME_EXPIRE_MINUTES * 60000);
        }

        // used for test mocking
        this.testAPI = {
            promiseToGet: promiseToGet,
            setRestClient: function (testRestClient) {
                restClient = testRestClient;
            },
            getRestClient: function () {
                return restClient;
            },
            defaultRequestHeaders: defaultAjaxRequestHeaders
        };
    };

    return new AWMService();


});
