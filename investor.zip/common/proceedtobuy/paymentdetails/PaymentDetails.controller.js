/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function PaymentDetailsController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout,transactModel, planSmartSolution, fundDetailsModel, fundDetails) {
	
	var cnt=0; 	
 	$scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;
    $scope.isFromPaperLess = transactModel.isPaperLess;

    if(planSmartSolution.getTransactType()==="Lumpsum")
    {
    	$scope.showLumpsum = true;
    }
    else if(planSmartSolution.getTransactType()==="SIP")
    {
    	$scope.showSip = true;
    }
    else if(planSmartSolution.getTransactType()==="Combo")
    {
    	$scope.showBoth = true;
    }

 	$state.go($scope.paymentDtls.paymentDtlsState); 	 	
       
    $scope.showInvDtls = false;
    $scope.showBack = false;
    $scope.showHeader = false;

    if($scope.paymentDtls.paymentDtlsState === "smartSol.planSmartSolution.paymentdetailsSS.investment"){
		$scope.showInvDtls = true;    	
		$scope.showBack = true;
		$scope.showHeader = true;
	    if(transactModel.getInvestorDetails()) {
			$scope.holderInfoArray = [

				{key:"First Holder",value:transactModel.getInvestorDetails().custName},
				{key:"Second Holder",value:(transactModel.getInvestorDetails().holders && transactModel.getInvestorDetails().holders.length>1)?transactModel.getInvestorDetails().holders[1].name : "NA"},
				{key:"Third Holder",value:(transactModel.getInvestorDetails().holders && transactModel.getInvestorDetails().holders.length>2)?transactModel.getInvestorDetails().holders[2].name : "NA"},
				{key:"Folio. No.",value:transactModel.getInvestorDetails().folioId},
				{key:"Mode of Holding",value:transactModel.getInvestorDetails().holdingType}
			];
		}

    }

	$scope.pdBackBtn = function(){		
		$state.go('smartSol.planSmartSolution.fundDetailsSS'); 
	};

	$scope.pdCntnuBtn = function(){
		cnt = 0;
		$scope.$broadcast("validateBuyForm");		
	};

	$scope.$on("validated",function(){
		cnt++;		
		if(cnt==2 || !$scope.showBoth)
		{
			if($state.current.url == "/smartSolTransactPayment"){
				transactModel.setTransactType('Smart Solutions');
				$state.go('transactnow.reviewNow.smartSol');
			}else{
				$scope.reviewDtls.reviewDtlsState = "smartSol.planSmartSolution.reviewnconfirm.investment";			
				$state.go('smartSol.planSmartSolution.reviewnconfirm');	
			}
		}		
	})

}

PaymentDetailsController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','$timeout','transactModel', 'planSmartSolution', 'fundDetailsModel', 'fundDetails'];
module.exports = PaymentDetailsController;