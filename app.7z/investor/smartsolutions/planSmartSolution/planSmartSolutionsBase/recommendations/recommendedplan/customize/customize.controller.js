/**
 * @ngdoc property
 * @name Customize Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Customize for Recommended module.
 *
 **/



'use strict';
function customizeController($scope, $state, recommendedPlanModelService, buildPlanModelService, fundDetailsModel, planSmartSolution, toaster, authenticationService) {

    $scope.tabName = $scope.$parent.tab.tabViewName;

    $scope.$on('customizeDetailsApply', function (event, data) {
        $scope.investmentType = data.investmentType;
        buildPlanModelService.setInvestmentType($scope.investmentType);
        recommendedPlanModelService.setCustomizePlanData(data);
        $scope.customizedData = recommendedPlanModelService.getCustomizePlanData();
        $scope.investmentType = $scope.customizedData.investmentType;
        $scope.funds = fundDetailsModel.getFundDetails();
        var planInputObj = {};
        planInputObj = angular.copy(recommendedPlanModelService.getPlanInputDtls());
        planInputObj.fundRecom = "O";
        planInputObj.investmentType = $scope.customizedData.investmentType;
        planInputObj.monthly = $scope.customizedData.monthly;
        planInputObj.annual = $scope.customizedData.annually;
        planInputObj.lumpsum = $scope.customizedData.onetime;
        planInputObj.annualizedReturn = $scope.customizedData.expectedReturns;
        planInputObj.annualStepUp = $scope.customizedData.stepUp;
        planInputObj.equityPerc = $scope.customizedData.equityExposure;
        var source = null;
        $scope.allocationArr = buildPlanModelService.getAllocationDetails();
        $scope.tabName = $scope.$parent.tab.tabViewName;
        $scope.tabName == "buildplan" ? source = "BP" : source = "RP";
        if(source == 'BP') {
            planInputObj.myFunds = [];
            angular.forEach($scope.funds, function (fund, ind) {
                var fundList = {};
                fundList.fundCode = fund.fundOption;
                fundList.allocPer = $scope.allocationArr[ind];
                planInputObj.myFunds.push(fundList);
            });
        }
        planSmartSolution.plainputObj = planInputObj;        
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, source, false).then(function (smartSolnDetails) {
            planSmartSolution.setSmartSolutionDetails(smartSolnDetails);
            if (data.currentState.indexOf("customizePlan") !== -1) {
                $state.go("smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rmycustomplan");
            }
            else {
                $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan.bmycustomizeplan");
            }
        }, function (data) {
            toaster.error("Records not found");
        });


    });
}

customizeController.$inject = ['$scope', '$state', 'recommendedPlanModelService', 'buildPlanModelService', 'fundDetailsModel', 'planSmartSolution', 'toaster', 'authenticationService'];
module.exports = customizeController;