// getPaymentDetails.model.js
// grab the mongoose module
// define our getPaymentDetails.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PaymentDetailsSchema = new mongoose.Schema({
    uiErrorDisplayMessage: String,
    transactionStatus: String,
    transactionDescription: String,
    transactionCode: String,
    region: String,
    postalCode: String,
    policies: {
        type: Array,
        "default": []
    },
    paymentPlanCode: String,
    paymentPlanCodeDesc: String,
    billingScheduledMaintenance: String,
    estimatedDowntime: String,
    systemDateTime: String,
    paymentDueDate: String,
    outStandingAmountCurrency: String,
    outStandingAmount: String,
    minPaymentDueAmountCurrency: String,
    minPaymentDueAmount: String,
    isMultiPolicyAccount: String,
    fullName: String,
    city: String,
    billingAccountNumber: String,
    agentOfRecord: String,
    addressLine1: String,
    accountStatus: String,
    loginURL: String,
    registerURL: String
});


var PaymentDetails = mongoose.model('PaymentDetails', PaymentDetailsSchema);


var paymentDetailsModel = new PaymentDetails({
    "uiErrorDisplayMessage": "",
    "transactionStatus": "S",
    "transactionDescription": "",
    "transactionCode": "",
    "region": "",
    "postalCode": "60606",
    "policies": [{
        "policyContractNumber": "900500520",
        "lineOfBusiness": "HOME"
    },{
        "policyContractNumber": "230500520",
        "lineOfBusiness": "AUTO"
    }, {
        "policyContractNumber": "560500520",
        "lineOfBusiness": "UMBRELLA"
    }, {
        "policyContractNumber": "140500520",
        "lineOfBusiness": "AUTO"
    }],
    "paymentPlanCode": "MT",
    "paymentPlanCodeDesc": "MONTHLY",
    "billingScheduledMaintenance": "N",
    "estimatedDowntime": "01:56:07",
    "systemDateTime": "2016-01-01T11:59:04.159Z",
    "paymentDueDate": "2016-01-03",
    "outStandingAmountCurrency": "USD",
    "outStandingAmount": "50000.00",
    "minPaymentDueAmountCurrency": "USD",
    "minPaymentDueAmount": "23000.00",
    "isMultiPolicyAccount": "N",
    "fullName": "GAYLE JOHNSON",
    "city": "Princeton",
    "billingAccountNumber": "T718142962",
    "agentOfRecord": "13053T",
    "addressLine1": "1119 Fairway Dr",
    "accountStatus": "Active",
    "loginURL": "https://csstw.farmers.com/",
    "registerURL": null
});




PaymentDetails.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PaymentDetails table,please contact admin...');
    } else {
        PaymentDetails.remove({}, function(err) {
            console.log('PaymentDetails collection removed');
            paymentDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating PaymentDetails table,please contact admin...');
                }
                console.log('PaymentDetails table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PaymentDetails;
