define(['jquery', 'lodash', 'backbone'], function ($, _, Backbone) {
    var PlanningGroup = Backbone.Model.extend({
        defaults: function () {
            return {
                "finPlnGrpId": undefined,
                "finPlnGrpCtx": undefined,
                "prmClId": undefined,
                "prmClCtx": undefined,
                "coClId": undefined,
                "coClCtx": undefined,
                "grpId": undefined,
                "grpCtx": undefined,
                "finPlnGrpStatCd": undefined,
                "finPlnGrpSttDt": undefined,
                "finPlnGrpEndDt": undefined,
                "plnSysCd": undefined
            };
        },
        populateFromServiceResponse: function (mgpGroupEntity) {
            const mgpGroup = {
                "finPlnGrpId": mgpGroupEntity.finPlnGrpId,
                "finPlnGrpCtx": mgpGroupEntity.finPlnGrpCtx,
                "prmClId": mgpGroupEntity.prmClId,
                "prmClCtx": mgpGroupEntity.prmClCtx,
                "coClId": mgpGroupEntity.coClId,
                "coClCtx": mgpGroupEntity.coClCtx,
                "grpId": mgpGroupEntity.grpId,
                "grpCtx": mgpGroupEntity.grpCtx,
                "finPlnGrpStatCd": mgpGroupEntity.finPlnGrpStatCd,
                "finPlnGrpSttDt": mgpGroupEntity.finPlnGrpSttDt,
                "finPlnGrpEndDt": mgpGroupEntity.finPlnGrpEndDt,
                "plnSysCd": mgpGroupEntity.plnSysCd
            }
            this.set(mgpGroup);
            return this;
        }
    });
    return PlanningGroup;
});