'use strict';
describe('Controller: invTransactionDetailsCtrl', function() {
	var $controller,$scope,invTransactionDetailsCtrl,invTransactionDetailsFactory,$stateParams,transactModel,$window,Restangular;

	var selectedInvestorDetailsObj = {
		custName:"RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI",
		email:"",
		firstHolderKyc:"KYC - Registered",
		firstHolderName:"RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI",
		folioId:"17023676",
		index:1,
		isFolioKYCReg:true,
		labelFolioId:"Folio 17023676",
		mobile:"",
		modeofHolding:"Single",
		pan:"",
		secondHolderKyc:"NA",
		secondHolderName:"NA",
		thirdHolderKyc:"NA",
		thirdHolderName:"NA",
		holders:[{
			aadharNo:"null",
			balAmount:"",
			kycSource:"CVLKRA",
			kycStatus:"KYC - Registered",
			modeOfKyc:"",
			name:"RASILA HASHMUKHBHAI SHINGALA MOID SURESH BACHWANI",
			pan:"CHDQR9223F",
			type:"Firstholder"	
		}]
	};

	var selectedFundDetailsObj = {balUnits:"2463.841",
		fmDescription:"Franklin India Bluechip Fund - Dividend",
		fundCategory:"EQUITY",
		fundType:"EQUITY",
		index:"1",
		investmentGoal:"",
		marketValue:"349183.18",
		tschvalAccno:"0069901064910",
		tschvalFsFlag:"N",
		tschvalScheme:"006"
	};

	var switchDetailsObj = {
		"switchType":"Full",
		"type":"Full",
		"units":8371.015,
		"destinationFund":{
		    "accNo": "0010008062712",
		    "amount": "1000",
		    "direct": null,
		    "dividendFlag": "R",
		    "endDate": "4 sep 2020",
		    "frequency": "monthly",
		    "fundCategory": "EQUITY",
		    "fundName":"Franklin India PRIMA FUND",
		    "fundOptDesc": "Franklin India PRIMA FUND",
		    "fundOption": "001",
		    "fundType": "E",
		    "minAddPurAmt": "1000",
		    "minNewPurAmt": "1000",
		    "minSipAmt": "500",
		    "multiples": "1",
		    "nfoFlag": "N",
		    "payoutFlag": "N",
		    "reinvestmentFlag": "N",
		    "startDate": "1 mar 2014",
		    "nextInstlDate": "10 aug 2016",
		    "nextAnnualDate": "1 mar 2017",
		    "stepUpType": "",
		    "stepUpValue": "2500",
		    "leadDays": "15",
		    "title":"0010008062712 - Franklin India PRIMA FUND",
		    "paymentDet":{
		    	"payModeEmand": "true",
		        "eMandateType":"maximum",
		        "eMandateVal": "3400",
		        "eMandateExpiryDate": "10 oct 2016" 
		    }
		}
	};

	var transactionConfirmObj = {transactionRefNo: "SWI001166", transDateTime: "14 December 2016, 08:18 PM"};
	
	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.transact'));	

	var transactModel = {		
		getTransactDetails: function() {			
            return {"switchDetails":switchDetailsObj};
        },
        getInvestorDetails : function(){
        	return selectedInvestorDetailsObj;
        },
        getFundDetails: function() {			
            return selectedFundDetailsObj;
        },
        getTransactConfirm : function(){
        	return transactionConfirmObj;
        },
        getAdvDetails : function(){
        	return {};
        },
        downloadTransactDetails : function(){        	
        	return {};
        }
	};

	beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('transactModel', transactModel);
        });
    });

	beforeEach(inject(function($rootScope,_$controller_,_invTransactionDetailsFactory_,_$stateParams_,_transactModel_,$window,$q,Restangular){				
		$controller = _$controller_;
		$scope = $rootScope.$new();
		$stateParams = _$stateParams_;		
		transactModel = _transactModel_;
		$window = $window;
		Restangular = Restangular;
		$q = $q;
		invTransactionDetailsFactory = _invTransactionDetailsFactory_;
		$stateParams.stateType = "switch";
		invTransactionDetailsCtrl = $controller('invTransactionDetailsCtrl', { $scope: $scope });        
		spyOn(invTransactionDetailsFactory.dataSetter,"call");
	}));	

	it('should be defined', function() {
        expect(invTransactionDetailsCtrl).toBeDefined();        
    });

	it('should set the title of the page to be "Transaction Details"', function() {
        expect($scope.transactHeading.heading).toBe('Transaction Details');                 
    });    

    it('should print the transaction details on click of print button',function(){
    	spyOn(window,"print").and.callFake(function(){});
    	$scope.windowPrint();    	
    	expect(window.print).toHaveBeenCalled();
    });

    it('should save the transaction details on click of save button',function(){
    	spyOn(invTransactionDetailsFactory,"callPDFService").and.callFake(function(){});
    	$scope.saveTransaction();
    	expect(invTransactionDetailsFactory.callPDFService).toHaveBeenCalledWith("switch");
    });

    // it('should save the transaction details on click of save button for dtp transaction',function(){
    // 	$stateParams.stateType = "dtp";
    // 	spyOn(invTransactionDetailsFactory,"callDtpPDFService").and.callFake(function(){});
    // 	$scope.saveTransaction();
    // 	expect(invTransactionDetailsFactory.callDtpPDFService).toHaveBeenCalledWith("dtp");
    // });
});
