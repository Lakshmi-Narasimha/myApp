// Karma configuration file
// See http://karma-runner.github.io/0.10/config/configuration-file.html
module.exports = function(config) {
    'use strict';
    config.set({
        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // base path, that will be used to resolve files and exclude
        basePath: '../',

        // testing framework to use (jasmine/mocha/qunit/...)
        frameworks: ['jasmine'],

        // list of files / patterns to load in the browser
        files: [

            'vendor/jquery/jquery.js',
            'vendor/bootstrap-sass-official/assets/javascripts/bootstrap.js',
            'vendor/angular/angular.js',
            'vendor/angular-mocks/angular-mocks.js',
            'vendor/angular-bootstrap/ui-bootstrap-tpls.js',
            'vendor/angular-ui-router/release/angular-ui-router.js',
            'vendor/angular-animate/angular-animate.js',
            'vendor/underscore/underscore.js',
            'vendor/slick-carousel/slick/slick.js',
            'vendor/angular-messages/angular-messages.js',

            'src/common/common.module.js',

            'src/fcss.module.js',
            'src/fcss.controller.js', 
            'src/fcss-states.js',


            /*Common-Constants*/

            'src/common/constants/image.constant.js',
            'src/common/constants/errorService.constant.js',
            'src/common/constants/UIC.constants.js',
            // 'src/common/constants/*.js',

            /*Common-Factories*/            

            // "src/common/factory/*.js",
            
            /*Common-Filters*/

            'src/common/filters/filter.js',

            /*Common-Services*/

            'src/common/services/getPaymentDetails.service.js',
            'src/common/services/submitPayment.service.js',
            'src/common/services/sendEmail.service.js',
            // 'src/common/services/*.js',

            /*Main Modules*/
            'src/modules/billing/billing.module.js',
            'src/modules/billing/billing.account.directive.js',
            'src/modules/billing/billing.account.factory.js',
            'src/modules/billing/billing.authenticationCtrl.js',
            'src/modules/billing/billing.makeapaymentCtrl.js',
            'src/modules/billing/billing.constant.js',
            'src/modules/billing/billing.controller.js',

            /*Components directives*/

            'src/components/components.module.js',
            'src/components/directives/validationutils.js',
            'src/components/directives/addedit.payments.directive.js',
            'src/components/directives/sendemail.directive.js',
            'src/components/directives/customcarosuel.js',
            'src/components/directives/customtile.js',
            'src/components/directives/loader.js',
            // 'src/components/directives/**/**/*.js',

            'src/components/partials/**/*.html',
            'src/modules/billing/partials/*.html',

           
            
            // 'src/modules/billing/**/*.js',

            // test specs here.
       
            'test/unit/**/*.js'
            
            // test specs here if needed.

        ],

        // list of files / patterns to exclude
        exclude: [
            // 'test/unit/components/directives/addedit.payments.directive.spec.js',
            // 'test/unit/components/directives/checknumbersonly.directive.spec.js',
        ],
        // Start these browsers, currently available:
        // - Chrome
        // - ChromeCanary
        // - Firefox
        // - Opera
        // - Safari (only Mac)
        // - PhantomJS
        // - IE (only Windows)
        browsers: [
            'Chrome'
        ],

        // Which plugins to enable
        /*
        'karma-jasmine',
        'karma-chrome-launcher',
        'karma-firefox-launcher',
        'karma-ie-launcher',
        'karma-safari-launcher',
        'karma-opera-launcher',
        'karma-phantomjs-launcher',
        'karma-detect-browsers',
        'karma-ng-html2js-preprocessor'
        */

        plugins: [
            'karma-chrome-launcher',
            'karma-phantomjs-launcher',
            'karma-jasmine',
            'karma-ng-html2js-preprocessor',
            'karma-coverage'
        ],

        // Continuous Integration mode
        // if true, it capture browsers, run tests and exit
        singleRun: false,

        colors: true,

        preprocessors: {

            'src/**/*.js': ['coverage'],
            'src/**/*.html': ['ng-html2js']
        },
        ngHtml2JsPreprocessor: {
            // setting this option will create only a single module that contains templates
            // from all the files, so you can load them all with module('templates')
            stripPrefix: 'src/',
            moduleName: 'templates'
        },
        coverageReporter: {
            type: 'html',
            dir: 'coverage'
        },
        // level of logging
        // possible values: DISABLE || ERROR || WARN || INFO || DEBUG
        logLevel: 'ERROR',
        reporters: ['progress', 'coverage'],
        browserNoActivity: 200000,
        port: 8080
    });
};
