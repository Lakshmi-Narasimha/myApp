'use strict';
function smartSolsTopupWithSameFundsCtrl($scope, $state, recommendedPlanModelService, overviewModel, $timeout, recommendedFundCardModelService, $uibModal, buildPlanModelService, planSmartSolution, sipCalculatorModel, investorGoalModelService,$window,appConfig,configUrlModel) {

    var planInputObj = null;
    $scope.init = function () {
        $scope.keyValueList = overviewModel.getHolderInformation();
        $scope.recommendationText = "Show another Recommendation";
        $scope.isToggle = false;
        $scope.recommendationDetails = {
            installmentDetails: [],
            details: {}
        };
        var goalSummary = angular.copy(investorGoalModelService.getSelectedGoalData());
        planInputObj = {
            "age": new Date().getFullYear() - new Date(goalSummary.birthDate).getFullYear(),
            "investmentTenure": 4,//goalSummary.pendingTimeFrame,
            "investmentAmount": goalSummary.targetAmount - ((goalSummary.achieved.split("%")[0] * goalSummary.targetAmount) /100),
            "equityPerc": 0
        };
        getSmartSolutionDetails(planInputObj);
    };

    $scope.init();

    /*$scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function ($event) {
        $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
        console.log($scope.recommendedPlanData);
        $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
        $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
        $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
        for (var fd = 0, len = $scope.fundDetails.length; fd < len; fd++) {
            if ($scope.fundDetails[fd].priority == 1) {
                $scope.fundName = $scope.fundDetails[fd].fundName;
                $scope.priority = $scope.fundDetails[fd].priority;
            }
        }
        ;
        //console.log($scope.goalChartData);

    });*/

    var modalInstance;
    $scope.$on('openFundCardModelPlan', function (event, fundCodes) {
        recommendedFundCardModelService.setFundCardId(fundCodes);
        // modalInstance = $uibModal.open({
        //     template: require('../../../../../common/components/smartSolFundCardModelDetails/smartSolFundCardModel.html'),
        //     scope: $scope
        // });
        $window.open(
          appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/funds-and-solutions/funds-explorer/fund-overview?FundID='+fundCodes,
          '_blank');
    });


    $scope.goBack = function () {
        $state.go("smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.or");
    };

    $scope.goalsheetBtn = function () {
        buildPlanModelService.setGoalPlanData($scope.goalDetails);
        buildPlanModelService.setGoalTotalPlanData($scope.totalGoalDetails);
        buildPlanModelService.setGoalSummaryFromState($state.current.name);
        $state.go('smartSol.trackmygoals.topupwithftrf.topupwithftrecommendedfundsgoalsheet');
    };

    $scope.toggleRecommendataions = function () {
        $scope.recommendationText == "Show another Recommendation" ? (planInputObj.fundRecom = "A", $scope.recommendationText = "Show Original Recommendation") : (planInputObj.fundRecom = "O", $scope.recommendationText = "Show another Recommendation");
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
            $scope.isToggle = true;
            planSmartSolution.setSmartSolutionDetails(data);
            loadRecommendedPlan();
        }, function (data) {
            console.log("Error")
        });
    };

    $scope.$on("investmentType", function ($event, data) {
        buildPlanModelService.setInvestmentType(data);
    });

    $scope.$on("investmentValue", function ($event, data) {
        $scope.radioSelectedData = buildPlanModelService.setInvestmentValue(data);
        $scope.fundDetails();
    });

    $scope.fundDetails = function () {
        $scope.investmentType = buildPlanModelService.getInvestmentType();
        $scope.investmentValue = buildPlanModelService.getInvestmentValue();

        if ($scope.investmentType == "Monthly" || $scope.investmentType == "Annually") {
            planSmartSolution.setTransactType("SIP");
        }
        else if ($scope.investmentType == "One time") {
            planSmartSolution.setTransactType("Lumpsum");
        }
        else {
            planSmartSolution.setTransactType("Combo");
        }

        $scope.goalDetails = [];
        $scope.totalGoalDetails = {};
        $scope.instalMentDtls = {
            monthly: "",
            annually: "",
            oneTime: ""
        };

        $scope.totalGoalDetails["allocation"] = "100%";
        if ($scope.investmentType == "Monthly") {
            $scope.instalMentDtls.monthly = $scope.investmentValue;
            $scope.totalGoalDetails["monthly"] = $scope.investmentValue;
        }
        if ($scope.investmentType == "Annually") {
            $scope.instalMentDtls.annually = $scope.investmentValue;
            $scope.totalGoalDetails["annually"] = $scope.investmentValue;
        }
        if ($scope.investmentType == "One time") {
            $scope.instalMentDtls.oneTime = $scope.investmentValue;
            $scope.totalGoalDetails["oneTime"] = $scope.investmentValue;
        }
        $scope.goalDetails.push({
            "fundName": $scope.smartSolnDetials.fundDetails.fundDesc,
            "allocation": $scope.smartSolnDetials.allocPer + "%",
            "installmentDetails": $scope.instalMentDtls,
            "dividendFlag" : 'G',//$scope.smartSolnDetials.dividendFlag,
            "fundOption" : $scope.smartSolnDetials.rtCode || 'NA',
            "nfoFlag" : $scope.smartSolnDetials.fundDetails.nfoFlag || 'NA',
            "fundType": $scope.smartSolnDetials.fundDetails.fundType || 'NA',
            "accNo" : $scope.smartSolnDetials.fundDetails.fundType == "N" ? "NEW" : 'NEW',
            "perpetualFlag" : 'N' || '',//$scope.smartSolnDetials.perpetualFlag
            "stepUpFrequency": $scope.smartSolnDetials.fundDetails.stepUpFrequency || 'NA',
            "stepUpType" : $scope.smartSolnDetials.fundDetails.stepUpType || 'NA',
            "stepUpValue" : $scope.smartSolnDetials.fundDetails.stepUpValue || 'NA',
            "stepUpSip" : 0
        });


    };

    function loadInvestmentSimulation () {

        var calculatorReq = [{
            "investmentTenure": planInputObj.investmentTenure,
            "annualizedReturn": null,
            "investmentAmount": planInputObj.investmentAmount,
            "fundName": $scope.smartSolnDetials.rtCode,
            "frequency" : "Monthly",
            "calculatorType": "SIP",
            "trxnType": "SIP"
        }];
        sipCalculatorModel.callSipCalculatorData({"calculatorReq": calculatorReq}, false).then(function (data) {
            var investMentSimulation = angular.copy(data.calculatorResp[0].returnData[0].periodicReturnData);
            $scope.goalChartData = {
                "data": [],
                "goalAmount": null
            };
            angular.forEach(investMentSimulation, function (value, key) {
                var chart = {};
                chart.years = value.duration;
                chart.amount = value.valueOfAmount;
                $scope.goalChartData.data.push(chart);
            });
            $scope.goalChartData.goalAmount = planInputObj.investmentAmount;
            planSmartSolution.setInvestmentSimulation($scope.goalChartData);
        }, function (data) {

        });
    };

    function loadRecommendedPlan () {
        $scope.smartSolnDetials = planSmartSolution.getSmartSolutionDetails();
        if (!$scope.isToggle) {
            loadInvestmentSimulation();
            $scope.recommendationDetails =
            {
                installmentDetails: [
                    {text: 'Monthly', value: parseInt($scope.smartSolnDetials.monthlySIP.replace(",", ""))},
                    {text: 'Annually', value: parseInt($scope.smartSolnDetials.annualSIP.replace(",", ""))},
                    {text: 'One time', value: parseInt($scope.smartSolnDetials.lumpsum.replace(",", ""))}],
                details: {
                    "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                    "investmentAmount": $scope.smartSolnDetials.investmentAmount
                }
            };
            planSmartSolution.setRecommendedDetails($scope.recommendationDetails);
        }
        else {
            $scope.recommendationDetails.installmentDetails = null;
            $timeout(function () {
                $scope.recommendationDetails =
                {
                    installmentDetails: [
                        {text: 'Monthly', value: parseInt($scope.smartSolnDetials.monthlySIP.replace(",", ""))},
                        {text: 'Annually', value: parseInt($scope.smartSolnDetials.annualSIP.replace(",", ""))},
                        {text: 'One time', value: parseInt($scope.smartSolnDetials.lumpsum.replace(",", ""))}],
                    details: {
                        "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                        "investmentAmount": $scope.smartSolnDetials.investmentAmount
                    }
                };
                console.log($scope.recommendationDetails);
                planSmartSolution.setRecommendedDetails($scope.recommendationDetails);
            }, 0);

        }

    };

    function getSmartSolutionDetails (planInputObj) {
        planInputObj.fundRecom = "O";
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, "RP", true).then(function (data) {
            planSmartSolution.setSmartSolutionDetails(data);
            loadRecommendedPlan();
        }, function (data) {
            console.log("Error")
        })
    };
}

smartSolsTopupWithSameFundsCtrl.$inject = ['$scope', '$state', 'recommendedPlanModelService', 'overviewModel', '$timeout', 'recommendedFundCardModelService', '$uibModal', 'buildPlanModelService', 'planSmartSolution', 'sipCalculatorModel', 'investorGoalModelService','$window','appConfig','configUrlModel'];
module.exports = smartSolsTopupWithSameFundsCtrl;