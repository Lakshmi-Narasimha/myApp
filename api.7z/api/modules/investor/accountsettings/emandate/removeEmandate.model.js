// getPersonalInfo.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called
var mongoose = require('mongoose');

var EmandateDetailsSchema = new mongoose.Schema({
    removeEmandate: {
        type: Object,
        "default": {}
    }
});

var RemoveEmandateLookUp = mongoose.model('RemoveEmandateLookUp', EmandateDetailsSchema);

var removeEmandateModel = new RemoveEmandateLookUp({
      removeEmandate: {
      "pan": "CNKQQ9569X",
      "status": "true",
      "webRefNo": "EM00001025"
    }
});

RemoveEmandateLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    'use strict';
    console.log(data);
    if (err) {
        console.log('Having toruble in creating RemoveEmandateLookUp table, please contact admin...');
    } else {
        RemoveEmandateLookUp.remove({}, function(err) {
            console.log('removeEmandateModel collection removed');
            removeEmandateModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RemoveEmandateLookUp table, please contact admin...');
                }
                console.log('RemoveEmandateLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RemoveEmandateLookUp;
