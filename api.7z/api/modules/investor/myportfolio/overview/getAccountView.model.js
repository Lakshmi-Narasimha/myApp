// getAccountView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var AccountViewSchema = new mongoose.Schema({
    viewData: {
        type: Array,
        'default': []
    }
});

var AccountViewLookUp = mongoose.model('InvAccountViewLookup', AccountViewSchema);

var AccountViewModel = new AccountViewLookUp({

    'viewData': [{
        'unitHolderDetails': {
            'invName': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
            'address': {
                'address1': 'BUDHA VILLAGE PO ASANSOL',
                'address2': 'OPP SITE SAMTHAR PETROL PUMP',
                'address3': 'MAYUR VIHAR PHASE III',
                'address4': 'HYDERABAD AP 500028',
                'city': 'DOMEIVALI',
                'pinCode': '400062',
                'line1': null,
                'line2': null,
                'line3': null
            },
            'holders': [{
                'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'status': 'Individual',
            'modeofOperation': 'Single',
            'bankDetails': '57523667318/STATE BANK OF INDIA/FORT MUMBAI',
            'allBankDetails': [{
                'bankCode': '635864358346/ Yes Bank',
                'bankAdd': 'Nunbakkam Chennai'

            }, {
                'bankCode': '635864358346/ HDFC Bank',
                'bankAdd': 'Nunbakkam Chennai'

            }, {
                'bankCode': '635864358346/ ICICI Bank',
                'bankAdd': 'Nunbakkam Chennai'

            }],
            'modeofpayment': 'Directly To Bank'
        },
        'accountDetails': {
            'accountName': 'Franklin India Bluechip Dividend Fund',
            'accountNumber': '0349904865101',
            'gridData': {
                'openingBalance': {
                    'totalUnits': '188.98'
                },
                'rows': [{
                    'txnDate': '15 Nov 2015',
                    'transaction': 'Opening Balance',
                    'amount': '6656',
                    'nav': '123.56',
                    'units': '34.9',
                    'totalUnits': '188.98',
                    'netAmount': '0'
                },
                {
                    'txnDate': '16 Nov 2015',
                    'transaction': 'Opening Balance',
                    'amount': '6657',
                    'nav': '124.56',
                    'units': '35.9',
                    'totalUnits': '189.98',
                    'netAmount': '0'
                },
                {
                    'txnDate': '17 Nov 2015',
                    'transaction': 'Opening Balance',
                    'amount': '6658',
                    'nav': '125.56',
                    'units': '36.9',
                    'totalUnits': '190.98',
                    'netAmount': '0'
                },
                {
                    'txnDate': '18 Nov 2015',
                    'transaction': 'Opening Balance',
                    'amount': '6659',
                    'nav': '126.56',
                    'units': '37.9',
                    'totalUnits': '191.98',
                    'netAmount': '0'
                }]
            }
        }
    }]

});

AccountViewLookUp.find(function(err) {
    if (err) {
        console.log('Having toruble in creating AccountViewLookUp table, please contact admin...');
    } else {
        AccountViewLookUp.remove({}, function(err) {
            console.log('AccountViewLookUp collection removed' + err);
            AccountViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AccountViewLookUp table, please contact admin...');
                }
                console.log('AccountViewLookUp table created in mongoose...');
            });
        });
    }
});

module.exports = AccountViewLookUp;
