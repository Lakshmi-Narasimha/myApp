define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'services/accountdetailservice',
  'appcommon/commonutility',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailownershipview.html'
], function ($, _, Backbone, Spinner, dataService, Utils, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView = AccountDetailSectionView.extend({
        taxPayerAge: '',
        retrieveAndRender: function() { 
          var self = this;
          dataService.promiseToGetClientAccountRoles(this.accountSummary.accountId)
            .then(function(clientAccountRoles){
              self.retrieveTaxPayerAgeAndRender(clientAccountRoles); 
          })
          .fail(this.handleServiceError);
        },
        retrieveTaxPayerAgeAndRender: function(clientAccountRoles) {
          var self = this;
          var taxPayerClientId = null;
          _.each(clientAccountRoles, function(role) {
              if(role.clRoleCd == "004" && role.client && role.client.personClient) { 
                taxPayerClientId = role.clId;
              }
          });
          if (taxPayerClientId) {
            dataService.promiseToGetClientAge(taxPayerClientId)
              .then(function(data) {
                self.taxPayerAge = data.clAge;
                self.renderOwnershipSection();
              })
              .fail(this.handleServiceError);
          } else {
            this.renderOwnershipSection();
          }
        },
        renderOwnershipSection: function() {
          var displayPlanId = this.accountSummary.taxQualCd != "000";
          this.renderSection(SectionTemplateHtml, {accountSummary: this.accountSummary, taxPayerAge: this.taxPayerAge, displayPlanId: displayPlanId});
        }

    });

    return SectionView;
});