// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var ValidateSwitchSchema = new mongoose.Schema({
    ValidateSwitchResponse: {
        type: Object,
        'default': {}
    }
});

var ValidateSwitchLookUp = mongoose.model('ValidateSwitchLookUp', ValidateSwitchSchema);

var ValidateSwitch = new ValidateSwitchLookUp({
    ValidateSwitchResponse: {
        'accountNo': '6019904934582',
        'folioId': '17919883',
        'transactionValidated': 'true',
        'webRefNo': 'SWI001166'
    }

});

ValidateSwitchLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidateSwitchLookUp table, please contact admin...');
    } else {
        ValidateSwitchLookUp.remove({}, function(err) {
            console.log('ValidateSwitchLookUp collection removed'+err);
            ValidateSwitch.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating ValidateSwitchLookUp table, please contact admin...');
                }
                console.log('ValidateSwitchLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ValidateSwitchLookUp;
