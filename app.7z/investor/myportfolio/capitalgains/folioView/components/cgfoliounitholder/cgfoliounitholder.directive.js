/**
 * @ngdoc property
 * @name fticCapitalGainFolioUnitDetails Directive
 * @requires cgAccDetModel  
 * @description
 *
 * - Displays the Capital Gains Folio Unit Holder details for selected Folio Number
 *
 **/
'use strict';

var fticCapitalGainFolioUnitDetails = function(cgAccDetModel) {
    return {
        template: require('./cgfoliounitholder.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {
            $scope.unitHolderDetails = cgAccDetModel.getCapitalGainsUnitHolder();
        }
    };
};

fticCapitalGainFolioUnitDetails.$inject = ['cgAccDetModel'];
module.exports = fticCapitalGainFolioUnitDetails;