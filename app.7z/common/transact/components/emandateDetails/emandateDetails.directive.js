/**
 * @ngdoc property
 * @name fticEmandateDetails Directive
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Redemption Form.
 *
 **/
'use strict';


var fticEmandateDetails = function (bankDtlsModel, TransactConstant, fundDetails, transactModel) {

    return {
        template: require('./emandateDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            $scope.isExhausted = false;

            var emandateDetails = bankDtlsModel.getEmandateDetails(),
                status = null,
                frequency = emandateDetails.frequency,
                amountType = emandateDetails.amountType,
                toDate = emandateDetails.toDate,
                fundDetailsObj = fundDetails.getFundDetails(),
                fundTotal = 0,
                i = 0;

            // Calculate total selected funds amount
            if(transactModel.getIsBuy()) {
                for(i=0; i<fundDetailsObj.length; i++) {
                    fundTotal += fundDetailsObj[i].amount;
                }
            } else if(transactModel.getIsSip()) {
                for(i=0; i<fundDetailsObj.length; i++) {
                    fundTotal += fundDetailsObj[i].sipAmount;
                }
            }
            
            // Set status based on fund amount and selected mandate amount
            if(emandateDetails.amount < fundTotal) {
                $scope.isExhausted = true;
                bankDtlsModel.setIsExhausted(true);
                status = TransactConstant.transact.UTILIZED;
            } else {
                $scope.isExhausted = false;
                bankDtlsModel.setIsExhausted(false);
                status = TransactConstant.transact.AVAILABLE;
            }

            // Set frequency values
            switch(frequency) {
                case 'M':
                    frequency = TransactConstant.transact.MNTHLY;
                    break;
                case 'Q':
                    frequency = TransactConstant.transact.QUATERLY;
                    break;
                case 'A':
                    frequency = TransactConstant.transact.AS_AND_WHEN;
            }

            // Set amount type values
            switch(amountType) {
                case 'U':
                    amountType = TransactConstant.transact.MAXIMUM;
                    break;
                case 'F':
                    amountType = TransactConstant.transact.FIXED;
            }

            // Set toDate to 'Until Cancelled' if service returns an empty value
            toDate = toDate ? toDate : TransactConstant.transact.UNTIL_CANCEL;
            if(toDate === TransactConstant.transact.UNTIL_CANCEL) {
                bankDtlsModel.setPeriod(TransactConstant.transact.UNTIL_CANCEL);
            } else {
                bankDtlsModel.setPeriod(TransactConstant.transact.DATE_RANGE);
            }

            $scope.keyValuePairs = [
                {
                    key : 'frequency',
                    text : TransactConstant.transact.FREQ,
                    value : frequency
                },
                                            {
                    key : 'status',
                    text : TransactConstant.transact.STATUS,
                    value : status
                },
                {
                    key : 'amount',
                    text : TransactConstant.transact.AMOUNT,
                    value : emandateDetails.amount
                },
                {
                    key : 'amountType',
                    text : TransactConstant.transact.AMOUNT_TYPE,
                    value : amountType
                },
                {
                    key : 'startDate',
                    text : TransactConstant.transact.FROM,
                    value : emandateDetails.fromDate
                },
                {
                    key : 'endDate',
                    text : TransactConstant.transact.TO,
                    value : toDate
                }
            ];            
            bankDtlsModel.setFrequency(frequency);
            bankDtlsModel.setTotalAmount(emandateDetails.amount);
            bankDtlsModel.setAmountType(amountType);
            bankDtlsModel.setStartDate(emandateDetails.fromDate);
            bankDtlsModel.setEndDate(toDate);
        }]
    };
};

fticEmandateDetails.$inject = ['bankDtlsModel', 'TransactConstant', 'fundDetails', 'transactModel'];
module.exports = fticEmandateDetails;