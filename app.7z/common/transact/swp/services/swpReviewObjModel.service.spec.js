'use strict';
describe('Service: reviewSwpDetailsModel ', function() {
	var reviewSwpDetailsModel,httpBackend,$window,fetchTxnDetailsSwpPromise;

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,_reviewSwpDetailsModel_){	
		reviewSwpDetailsModel = _reviewSwpDetailsModel_;		
        httpBackend = $httpBackend;		        
       
		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the functions fetchTxnDetailsSwp,getReviewSwpObj,setReviewSwpObj,resetReviewSwpObj,getFundEditIfscStatus,setFundEditIfscStatus',function(){
		expect(reviewSwpDetailsModel.fetchTxnDetailsSwp).toBeDefined();
		expect(reviewSwpDetailsModel.getReviewSwpObj).toBeDefined();
		expect(reviewSwpDetailsModel.setReviewSwpObj).toBeDefined();
		expect(reviewSwpDetailsModel.resetReviewSwpObj).toBeDefined();
		expect(reviewSwpDetailsModel.getFundEditIfscStatus).toBeDefined();		
		expect(reviewSwpDetailsModel.setFundEditIfscStatus).toBeDefined();
	});

	describe("fetchTxnDetailsSwp promise",function(){
		beforeEach(inject(function() {						
			fetchTxnDetailsSwpPromise = reviewSwpDetailsModel.fetchTxnDetailsSwp();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/getTxnDetailsSwp').respond(200,{"status":"success"});
			fetchTxnDetailsSwpPromise.then(function(response){														
				expect(response.status).toBe("success");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/getTxnDetailsSwp').respond(400,failureResponse);
			fetchTxnDetailsSwpPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});
});	
