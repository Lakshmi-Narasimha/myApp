'use strict';

var dashboardConstants = (function() {
    return {

        dashboard: {

            INVESTOR_DETAILS: 'INVESTOR_DETAILS',
            TRANSACTION_STATUS: 'TRANSACTION_STATUS',
            SIP_BOOK: 'SIP_BOOK',
            LEADS: 'LEADS',
            FUNDS_IN_FOCUS: 'FUNDS_IN_FOCUS',
            INVESTMENTS: 'INVESTMENTS',
            SMART_SOLUTIONS: 'SMART_SOLUTIONS',
            MY_LEARNING: 'MY_LEARNING',

            RECOMMENDATIONS: 'RECOMMENDATIONS',
            RECOMMENDATIONS_CLASS: 'icon-fti_advisorRecommendation',
            NOTIFICATIONS: 'NOTIFICATIONS',
            NOTIFICATIONS_CLASS: 'icon-fti_advisorNotification',

            FUND_MANAGER: 'FUND_MANAGER',
            NEW_FUND_OFFR: 'NEW_FUND_OFFR',

            SIPS_AS_ON_END: 'SIPs as on end of',
            SIPS_AS_OF_YTM: 'SIPs as of YTM',
            NEW_SIPS: 'New SIPs',
            SIPS_MATURED: 'SIPs Matured',
            SIPS_CANCELLED: 'SIPs Cancelled',
            ACTIVE_SIPS: 'Active SIPS',
            SIP_THROUGHPUT: 'SIP throughput',
            PERPETUAL_SIP: 'Perpetual SIP',
            AVG_TICKET_SIZE: 'Avg. ticket size',
            SIP_UNIQUE_INVESTOR: 'SIP unique investor',
            SIPS_DUE_FOR_RENEWAL: 'SIPs due for renewal',
            NEW_SIPS_ADDED: 'New SIPs added',
            SIPS_WITH_STEPUP: 'SIPs with stepup',
            SIPS_WITH_PAUSES: 'SIPs with pauses',
            SIP_INSTALLMENT: 'SIP installment',
            REJECTIONS: 'rejections',

            CT: 'CT',
            NCT: 'NCT',
            YTM: 'YTM',
            LAST_THREE_MONTHS: 'Last 3 Months',
            LAST_MONTH: 'Last Month',
            YTD: 'YTD',
            MTD: 'MTD',
            MY_INVESTMENTS: 'MY_INVESTMENTS',
            MY_SIPS: 'MY_SIPS',
            FOR_PAN: 'FOR_PAN',
            CURRENT_COST: 'CURRENT_COST',
            CURRENT_VALUE: 'CURRENT_VALUE',
            MONTHLY_INVESTMENTS: 'MONTHLY_INVESTMENTS',
            QUARTERLY_INVESTMENTS: 'QUARTERLY_INVESTMENTS',
            ANNUAL_INVESTMENTS: 'ANNUAL_INVESTMENTS',

            // SIP Book Messages
            OVER_VIEW: 'OVER_VIEW',
            DETAILED_VIEW: 'DETAILED_VIEW',
            MONTH_END: 'MONTH_END',
            LAST_BIZ_DAY: 'LAST_BIZ_DAY',

            //Smart Savings Account
            SMART_SAVINGS_ACCOUNT: {
                TITLE: 'Smart Savings Account',
                BUTTON_LINKS: {
                    TRANSACTION_TRUE: [{
                        icon: 'icon-fti_invest',
                        lable: 'Invest',
                        href: '/investor/#'
                    }, {
                        icon: 'icon-fti_redeem',
                        lable: 'Redeem',
                        href: '/investor/#'
                    }],
                    TRANSACTION_FALSE: [{
                        icon: 'icon-fti_setUpTransaction',
                        lable: 'Set-up Transaction',
                        href: '/investor/#/accountsettings/smartsavingsaccount'
                    }]
                }
            },

            //ONE TOUCH INVEST
            ONE_TOUCH_INVEST: {
                TITLE: 'One Touch Invest',
                BUTTON_LINKS:{
                    TRANSACTION_TRUE: {
                        icon: 'icon-fti_invest',
                        lable: 'Quick Invest',
                        href: '/investor/#'
                    },
                    TRANSACTION_FALSE: {
                        icon: 'icon-fti_getStarted',
                        lable: 'Get Started',
                        href: '/investor/#/accountsettings/onetouchinvest'
                    }
                }
            },

            //Quick Links References
            QUICK_LINKS: [{
                icon: 'icon-fti_accountStatement',
                lable: 'INV_ACCOUNT_STATEMENT',
                href: '/#/myportfolio/overview/panview'
            }, {
                icon: 'icon-fti_startLumpsum',
                lable: 'INV_BUY_LUMPSUM',
                href: '/#'
            }, {
                icon: 'icon-fti_startSIP',
                lable: 'INV_START_SIP',
                href: '#'
            }, {
                icon: 'icon-fti_pauseSIP',
                lable: 'INV_PAUSE_SIP',
                href: '#'
            }],


            INVEST_CHART_COLORS: ['#014982', '#82BC00', '#00A0DC', '#F7BC00', '#bbb', '#F59B00', '#A6D7F5', '#0098d4', '#7eb801', '#5cbbe7', '#ed9801']
        }
    };
}());

dashboardConstants.$inject = [];
module.exports = dashboardConstants;
