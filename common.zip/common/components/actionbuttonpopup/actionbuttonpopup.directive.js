/**
 * @ngdoc property
 * @name Action Button Popup Directive
 * @requires $state
 * @description
 *
 * - button popup directive will load the buttons with title specified and routes the page to the route specified to the directive.
 *
 **/

 'use strict';

var actionButtonPopup = function($templateCache){
	
	return {
		template : require('./actionbuttonpopup.html'),
		restrict : 'E',
		replace : true,
		scope : {
			buttonOptions : '=' 
		},
		compile: function(element, attributes){
			return {
				post: function(scope, element, attributes, controller, transcludeFn){
					angular.element(element).wrap('<script type="text/ng-template" id="myPopoverTemplate.html"></script>');
				}
			};
		}
	};

};


actionButtonPopup.$inject = ['$templateCache'];

module.exports = actionButtonPopup;