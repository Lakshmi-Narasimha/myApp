/**
 * @ngdoc property
 * @name soChart Directive
 * @requires advisorConstants
 * @requires advisorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Displays the Portfolio Composition bar graph with AUM displayed against the various asset categories.
 *
 **/
'use strict';


var smartSolsSelectGoal = function(advisorConstants, advisorEventConstants, fticLoggerMessage, loggerConstants,buildPlanModelService, investorGoalModelService) { 
return {
            template: require('./selectGoal.html'),
            restrict: 'E',
            replace: true,
            scope: {},
            controller: ['$scope', function($scope){
                // $scope.holderInfoArray = investorGoalModelService.getInvestorData(); 
                // console.log( $scope.investorDetails );
                $scope.smartSolnsSelectGoalData = [];
                $scope.enableContinue = false;
                var rows = investorGoalModelService.getGoalInvestorData();

                angular.forEach(rows,function(obj, ind){
                    var gridRow = {};
                    gridRow.index = ind;
                    gridRow.goal = obj.goal === "null" ? "NA" : obj.goal;
                    gridRow.goaldetails = obj.goalDetails === "null" ? "NA" : obj.goalDetails;
                    gridRow.tragetamount = obj.targetAmount === "null" ? "NA" : obj.targetAmount;
                    gridRow.futurecostofgoal = obj.futureReturn === "null" ? "NA" : obj.futureReturn;//futurecostofgoal;
                    gridRow.TenorinYrs = obj.timeFrame === "null" ? "NA" : obj.timeFrame;//TenorinYrs;
                    gridRow.goalachivedtilldate = (obj.achieved.split("%")[0] * obj.targetAmount) /100;//goalachivedtilldate;
                    gridRow.percentageachived = obj.achieved === "null" ? "NA" : obj.achieved;//percentageachived;
                    gridRow.NoofYrstogoal = obj.pendingTimeFrame === "null" ? "NA" : obj.pendingTimeFrame;//NoofYrstogoal;

                    $scope.smartSolnsSelectGoalData.push(gridRow);
                });

                // var statusTemplate = '<div uib-popover-template="" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'
              var statusTemplate ='<input type="radio" class="m" name="selectedInvestor" ng-click="grid.appScope.$emit(\'selectGoal\', row.entity.index)" />';


              $scope.smartSolnsSelectGoalColumnDefs = [
                  { field: 'goal', displayName: '', width:'50', cellTemplate: statusTemplate, pinnedLeft: true},
                  { field: 'goal', displayName: 'Goal', width:'150', pinnedLeft: true},
                  { field: 'goaldetails', displayName: 'Goal Details', width:'90'},
                  { field: 'tragetamount', displayName: 'Target Amount', width:'180', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right'},
                  { field: 'futurecostofgoal', displayName: 'Future Cost Of Goal', width:'200', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right'},
                  { field: 'TenorinYrs', displayName: 'Tenure in Yrs.', width:'150', headerCellClass: 'text-right', cellClass:'text-right'},
                  { field: 'goalachivedtilldate', displayName: 'Goal Achived Till Date', width:'200', headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right', cellClass:'text-right'},
                  { field: 'percentageachived', displayName: '% Achived', width:'100',headerCellClass: 'fti-grid-headercell text-right',cellClass:'text-right'},
                  { field: 'NoofYrstogoal', displayName: 'No. of Yrs. to goal', width:'150', headerCellClass: 'text-right', cellClass:'text-right'}
               ];

               $scope.$on('selectGoal', function(){
                  $scope.enableContinue = true;
               });
               $scope.SelectGoalCntnuBtn = function(){
                $scope.$emit('smartSolSelectGoal');
               }

               

            }]
        }
   };     


smartSolsSelectGoal.$inject = ['advisorConstants', 'advisorEventConstants', 'fticLoggerMessage', 'loggerConstants','buildPlanModelService','investorGoalModelService'];
module.exports = smartSolsSelectGoal;   
