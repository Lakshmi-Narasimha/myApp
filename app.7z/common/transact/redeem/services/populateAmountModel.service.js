/**
 * @ngdoc service
 * @name amountModel
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var amountModel = function (Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _amount = null;

    var amountModel = {
        fetchAmountValue : function () {
            
            var deferred = $q.defer();
            Restangular.all('/getAmountValue').getList().then(function (amount) {
                deferred.resolve(amount);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setAmount : function(amount) {
            _amount = amount;
        },

        getAmount : function() {
            return _amount;
        }
    };
    return amountModel;
};

amountModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];

module.exports = amountModel;