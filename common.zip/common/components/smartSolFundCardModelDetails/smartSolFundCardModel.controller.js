/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function smartSolFundCardModelController($scope, $uibModalStack, recommendedFundCardModelService, $timeout) {

    $scope.showReturns = false;
    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
    recommendedFundCardModelService.fetchRecommendedFundCard(recommendedFundCardModelService.getFundCardId()).then(function (data) {
        recommendedFundCardModelService.setFundCardModelDtls(data.fundDetails[0]);
        $timeout(function () {
          $scope.fundCardDetails = recommendedFundCardModelService.getFundCardModelDtls();
          $scope.showReturns = true;
      }, 0);
    }, function (data) {

    });
    /*function recommendedFundCardSuccess(data){
          recommendedFundCardModelService.setFundCardModelDtls(data.fundDetails[0]);
      }
      function handleFailure(data){
          
      }*/ 
      
    /*$scope.fundDetailsModel = recommendedFundCardModelService.getFundCardModelDtls().fundModalPlanResp.fundDetails;
    $scope.fundCardDetails = {};
    $.each($scope.fundDetailsModel, function(index, element) {
        if(element.fundId === recommendedFundCardModelService.getFundCardId()) {
            $scope.fundCardDetails = element;
        }
    });*/
    $scope.$on('slectedOptionValue', function(event, data) {
        $scope.percentage = data.value;
    });
}


smartSolFundCardModelController.$inject = ['$scope', '$uibModalStack', 'recommendedFundCardModelService', '$timeout'];

module.exports = smartSolFundCardModelController;