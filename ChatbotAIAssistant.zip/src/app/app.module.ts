import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ApplicationRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Ng2BootstrapModule, ButtonsModule } from 'ng2-bootstrap';
import { SelectModule } from 'ng2-select/ng2-select';
//import { Ng2SmartTableModule, LocalDataSource  } from 'ng2-smart-table';
import { TabsModule } from 'ng2-bootstrap/ng2-bootstrap';
import { ModalModule } from 'ng2-bootstrap';
import { PaginationModule } from 'ng2-bootstrap';

import { AppComponent } from './app.component';
import { NavcomponentComponent } from './navcomponent/navcomponent.component';
import { AgentcomponentComponent } from './agentcomponent/agentcomponent.component';
import { IntentgroupcomponentComponent } from './intentgroupcomponent/intentgroupcomponent.component';
import { IntentdatacomponentComponent } from './intentdatacomponent/intentdatacomponent.component';
import { IntentusersaysComponent } from './intentusersays/intentusersays.component';
import { IntentparameterComponent } from './intentparameter/intentparameter.component';
import { IntentresponseComponent } from './intentresponse/intentresponse.component';
import { EditabletableComponent } from './editabletable/editabletable.component';

import { AIAssistRestService, AIAssistCacheService  } from './_services/index';
//import { fakeBackendProvider } from './_helpers/fake-backend';
//import { MockBackend, MockConnection } from '@angular/http/testing';
import { BaseRequestOptions } from '@angular/http';

@NgModule({
  declarations: [
    AppComponent,
    NavcomponentComponent,
    AgentcomponentComponent,
    IntentgroupcomponentComponent,
    IntentdatacomponentComponent,
    IntentusersaysComponent,
    IntentparameterComponent,
    IntentresponseComponent,
    EditabletableComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpModule,
    Ng2BootstrapModule,
    SelectModule,
    ButtonsModule,
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot()
  ],
  providers: [
    AIAssistRestService,
    AIAssistCacheService,
    //fakeBackendProvider,
    //MockBackend,
    BaseRequestOptions],
  bootstrap: [AppComponent]
})
export class AppModule { }
