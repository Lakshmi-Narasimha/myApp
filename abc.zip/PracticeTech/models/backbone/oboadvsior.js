define(['jquery', 'backbone', 'config',
], function ($, Backbone, Config) {
    var oboAdvisorModel = Backbone.Model.extend({
        defaults: {
            fmid: undefined,
            name: undefined,
            logged:false
        }       
    });
	var oboAdvisorModalCollection = Backbone.Collection.extend({
	    model: oboAdvisorModel,	   
	});
    var oboAdvisors = {
        oboAdvisorModel: oboAdvisorModel,
        oboAdvisorModalCollection:oboAdvisorModalCollection
    };
    return oboAdvisors;
});
