var express = require('express');
var https = require('https');
var config = require('../../../config/config');

var router = express.Router();
var getMessageModel = require('./getMessage.model');
//var engagementModel = require('../engagement/engagement.model');
//var sendMessageModel = require('../sendMessage/sendMessage.model');
var apiUtils = require('../../common/apiUtils');

// api route
router.route('/mfchat/rest/message/:engagementID')
    .post(function(req, res) {
        console.log("Get Message API is trigerred");
        req.uri = getMessageModel.createRequestUri;
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + req.params.engagementID,
                headers: {
                    'Cookie': req.sessionCookie
                }
            },
            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                console.log(proxyResponse.statusCode);
                if (res.statusCode === 200) {
                    if (proxyResponse.statusCode === 200) {
                        proxyResponse.on('data', function(chunk) {
                            chunk = JSON.parse(chunk);

                            console.log("Get Message API Response:", chunk);

                            getMessageModel.response.Page.engagementID = req.params.engagementID;
                            //getMessageModel.response.Page.status = engagementModel.response.Page.status;


                            if (chunk.messages[0] && chunk.messages[0].state) {
                                getMessageModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['display.text'];
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                            } else if (chunk.messages[0]) {
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                getMessageModel.response.Page.agentID = chunk.messages[0]['user.id'];
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                            }
                            console.log(getMessageModel.response.ModuleMap.Support.msgList[0].messageType);
                            var counter = getMessageModel.response.ModuleMap.Support.msgList[0].messageType === 'chatLine' ? apiUtils.customerInfo.chatGetMsgCounter++ : apiUtils.customerInfo.chatGetMsgCounter;
                            console.log(apiUtils.customerInfo.chatGetMsgCounter);
                            console.log(apiUtils.customerInfo.chatSendMsgCounter);
                            if (chunk.messages[0] && chunk.messages[0].state === "closed") {
                                console.log("The chat state is now:", chunk.messages[0].state);

                                var timeDiff = apiUtils.checkSurveyStatus(apiUtils.customerInfo.pastChatEndTime, new Date());
                                var checkSurveyEligible = (apiUtils.customerInfo.chatGetMsgCounter > 2 && apiUtils.customerInfo.chatSendMsgCounter > 2);
                                if (checkSurveyEligible && (apiUtils.customerInfo.pastChatEndTime || (timeDiff > 86400000))) {
                                    console.log('Send survey url');
                                    var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                    var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                    
                                    getMessageModel.response.surveyResponse.Page.surveyUrl = surveyUrl;

                                    getMessageModel.response.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText.ButtonMap.FeedLink = surveyUrl;

                                    getMessageModel.response.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;


                                    apiUtils.customerInfo.pastChatEndTime = new Date();
                                    res.send(getMessageModel.response);
                                } else{
                                    res.send(getMessageModel.response);
                                }
                                
                            } else {
                                     res.send(getMessageModel.response);
                            }
                        });

                    } else {
                        res.send({
                            message: 'ERROR!!! Something went wrong while retrieving data.',
                            statusCode: res.statusCode
                        });
                    }
                } else {
                    res.send({
                        message: 'ERROR!!! Something went wrong while retrieving data.',
                        statusCode: res.statusCode
                    });

                }
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });
        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });
module.exports = router;
