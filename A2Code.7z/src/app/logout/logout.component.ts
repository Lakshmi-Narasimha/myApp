import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { AuthenticationService } from '../_services/authentication.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  returnUrl: string;
  logoutPageWait: any;

  constructor(private route: ActivatedRoute, private router: Router, private authenticationService:AuthenticationService) {
    this.logoutFromApp();
  }

  ngOnInit() {
  }

  logoutFromApp() {
    // reset login status
    this.authenticationService.logout().subscribe((data) => {
      this.logoutPageWait = setTimeout(() =>
      {
        this.redirectToLoginPage();
      }, 5 * 1000);
    });
  }

  redirectToLoginPage() {
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    this.router.navigate(["login"]);
    if (this.logoutPageWait) {
      clearTimeout(this.logoutPageWait);
    }
  }

}
