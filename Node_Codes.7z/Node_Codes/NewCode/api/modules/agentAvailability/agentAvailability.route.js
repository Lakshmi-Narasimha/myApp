var express = require('express');
var https = require('https');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var proxy = require('../../../config/proxy')
var router = express.Router();
var agentAvailabilityModel = require('./agentAvailability.model');

// api route
router.route('/mfchatnode/rest/agent')
    .post(function(req, res) {
        req.session.statusCounter = (req.session.statusCounter+1 || 1);
        logger.general.info(logger.formatInfoMsg(req.session.id, "Agent Call #"+ req.session.statusCounter));        
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.body.RequestParams = req.body.RequestParams || {};
        req.uri = agentAvailabilityModel.createRequestUri[req.body.RequestParams.agentGroupID];
        
        var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Cookie': req.session.sessionCookie
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            var resbody = [];
            proxyResponse.setEncoding('utf8');
            proxyResponse.on('data', function(chunk) {
               resbody.push(chunk);
            }).on('end', function(){
                logger.general.info(logger.formatOutBoundResMsg(reqObj, resbody, req.session.id));
                huge = JSON.parse({
  "countryData": [{
    "name": "Afghanistan",
    "urlParma": "afghanistan",
    "dialNumber": "011 + 93 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "AWCC",
        "dialNumberInstruction": "011 + 93 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 93 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN Afghanistan",
        "dialNumberInstruction": "011 + 93 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Aland Islands",
    "urlParma": "alandislands",
    "dialNumber": "011 + 358 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Albania",
    "urlParma": "albania",
    "dialNumber": "011 + 355 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.48"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.48"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Eagle Albania",
        "dialNumberInstruction": "011 + 355 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Plus Communication Sh.A.",
        "dialNumberInstruction": "011 + 355 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone Albania",
        "dialNumberInstruction": "011 + 355 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Algeria",
    "urlParma": "algeria",
    "dialNumber": "011 + 213 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.39",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.39",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Algerie Telecom Mobile (Mobilis)",
        "dialNumberInstruction": "011 + 213 + the local number",
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": "Djezzy Algeria",
        "dialNumberInstruction": "011 + 213 + the local number",
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": "Wataniya Telecom",
        "dialNumberInstruction": "011 + 213 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "American Samoa",
    "urlParma": "americansamoa",
    "dialNumber": "011 + 684 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.37",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.37",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Blue Sky",
        "dialNumberInstruction": "011 + 684 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Andorra",
    "urlParma": "andorra",
    "dialNumber": "011 + 376 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.69"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.47",
        "mobile": "$0.69"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Angola",
    "urlParma": "angola",
    "dialNumber": "011 + 244 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.41"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.41"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Movicel",
        "dialNumberInstruction": "011 + 244 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Unitel Angola",
        "dialNumberInstruction": "011 + 244 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Anguilla",
    "urlParma": "anguilla",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "LIME/Cable & Wireless",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel Anguilla",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Antarctica",
    "urlParma": "antarctica",
    "dialNumber": "011 + 672 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$2.85",
        "mobile": "$2.85"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$2.85",
        "mobile": "$2.85"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$3.99",
        "mobile": "$3.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Claro Argentina",
        "dialNumberInstruction": "011 + 54 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Antigua",
    "urlParma": "antigua",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "LIME / Cable &Wireless",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Argentina",
    "urlParma": "argentina",
    "dialNumber": "011 + 54 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.18",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro Argentina",
        "dialNumberInstruction": "011 + 54 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Movistar",
        "dialNumberInstruction": "011 + 54 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Personal (Telecom Argentina)",
        "dialNumberInstruction": "011 + 54 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Armenia",
    "urlParma": "armenia",
    "dialNumber": "011 + 374 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.59",
        "mobile": "$0.70"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.59",
        "mobile": "$0.70"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "VIMPELCOM (ArmenTel)/BEELINE",
        "dialNumberInstruction": "011 + 374 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Karabakh Telecom",
        "dialNumberInstruction": "011 + 374 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTS Armenia",
        "dialNumberInstruction": "011 + 374 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Armenia",
        "dialNumberInstruction": "011 + 374 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Aruba",
    "urlParma": "aruba",
    "dialNumber": "011 + 297 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel Aruba",
        "dialNumberInstruction": "011 + 297 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Setar GSM",
        "dialNumberInstruction": "011 + 297 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Ascension Island",
    "urlParma": "ascensionisland",
    "dialNumber": "011 + 247 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.16",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.16",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Sure (Guernsey) Limited",
        "dialNumberInstruction": "011 + 247 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Australia",
    "urlParma": "australia",
    "dialNumber": "011 + 61 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.23"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.23"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Telstra",
        "dialNumberInstruction": "011 + 61 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 61 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Yes Optus",
        "dialNumberInstruction": "011 + 61 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Austria",
    "urlParma": "austria",
    "dialNumber": "011 + 43 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "3 Hutchison (DREI) / Hutchison 3 Austria GmbH",
        "dialNumberInstruction": "011 + 43 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Azerbaijan",
    "urlParma": "azerbaijan",
    "dialNumber": "011 + 994 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.11",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.11",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Azercell (Teliasonera)",
        "dialNumberInstruction": "011 + 994 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Azerfon LLC (Nar Mobile)",
        "dialNumberInstruction": "011 + 994 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bahamas",
    "urlParma": "bahamas",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "The Bahamas Telecommunications Company Ltd",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bahrain",
    "urlParma": "bahrain",
    "dialNumber": "011 + 973 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Batelco - Bahrain",
        "dialNumberInstruction": "011 + 973 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "VIVA",
        "dialNumberInstruction": "011 + 973 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Zain BH",
        "dialNumberInstruction": "011 + 973 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bangladesh",
    "urlParma": "bangladesh",
    "dialNumber": "011 + 880 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.42"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "GrameenPhone (Telenor)",
        "dialNumberInstruction": "011 + 880 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Robi (Axiata)",
        "dialNumberInstruction": "011 + 880 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "VimpelCom (Banglalink)",
        "dialNumberInstruction": "011 + 880 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Barbados",
    "urlParma": "barbados",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "LIME / Cable & Wireless",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Barbuda",
    "urlParma": "barbuda",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel Antigua and Barbuda",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Belarus",
    "urlParma": "belarus",
    "dialNumber": "011 + 375 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.35",
        "mobile": "$0.38"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.35",
        "mobile": "$0.38"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MTS",
        "dialNumberInstruction": "011 + 375 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telekom Austria (FE VELCOM)",
        "dialNumberInstruction": "011 + 375 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Belgium",
    "urlParma": "belgium",
    "dialNumber": "011 + 32 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.28"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange Europe (Mobistar)",
        "dialNumberInstruction": "011 + 32 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Proximus",
        "dialNumberInstruction": "011 + 32 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Belize",
    "urlParma": "belize",
    "dialNumber": "011 + 501 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Belize Telemeida (BTL)",
        "dialNumberInstruction": "011 + 501 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Benin",
    "urlParma": "benin",
    "dialNumber": "011 + 229 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.66",
        "mobile": "$0.69"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.66",
        "mobile": "$0.69"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Glomobile Benin",
        "dialNumberInstruction": "011 + 229 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 229 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN",
        "dialNumberInstruction": "011 + 229 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bermuda",
    "urlParma": "bermuda",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "CellularOne - Bermuda",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel Bermuda",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bhutan",
    "urlParma": "bhutan",
    "dialNumber": "011 + 975 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.31",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "B-Mobile (Bhutan Telecom)",
        "dialNumberInstruction": "011 + 975 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TashiCell",
        "dialNumberInstruction": "011 + 975 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bolivia",
    "urlParma": "bolivia",
    "dialNumber": "011 + 591 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Entel Bolivia",
        "dialNumberInstruction": "011 + 591 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Nuevatel",
        "dialNumberInstruction": "011 + 591 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telecel Bolivia",
        "dialNumberInstruction": "011 + 591 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    }
  }, {
    "name": "Bonaire",
    "urlParma": "bonaire",
    "dialNumber": "011 + 599 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Bosnia Herzegovina",
    "urlParma": "bosniaherzegovina",
    "dialNumber": "011 + 387 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.47"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.47"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "BH Telecom",
        "dialNumberInstruction": "011 + 387 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Botswana",
    "urlParma": "botswana",
    "dialNumber": "011 + 267 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "BeMobile",
        "dialNumberInstruction": "011 + 267 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Botswana",
        "dialNumberInstruction": "011 + 267 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Brazil",
    "urlParma": "brazil",
    "dialNumber": "011 + 55 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.15",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vivo",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Oi TNL PCS S.A. (Telemar)",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Oi Brazil / OI TNL PCS S.A. (Telemar)",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TIM Brasil-Centro Sul",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TIM Brasil-Rio Norte",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TIM Brasil-Sao Paulo",
        "dialNumberInstruction": "011 + 55 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Brunei",
    "urlParma": "brunei",
    "dialNumber": "011 + 673 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.20",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "DST Communications",
        "dialNumberInstruction": "011 + 673 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Bulgaria",
    "urlParma": "bulgaria",
    "dialNumber": "011 + 359 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Mobitel / Telekom Austria",
        "dialNumberInstruction": "011 + 359 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telenor Bulgaria",
        "dialNumberInstruction": "011 + 359 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vivacom",
        "dialNumberInstruction": "011 + 359 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Burkina Faso",
    "urlParma": "burkinafaso",
    "dialNumber": "011 + 226 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$1.03"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$1.03"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Celtel Burkina Faso",
        "dialNumberInstruction": "011 + 226 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Onatel",
        "dialNumberInstruction": "011 + 226 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Burundi",
    "urlParma": "burundi",
    "dialNumber": "011 + 257 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.50"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.50"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Africell",
        "dialNumberInstruction": "011 + 257 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Econet Wireless Burundi",
        "dialNumberInstruction": "011 + 257 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "U-Com Burundi",
        "dialNumberInstruction": "011 + 257 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cabbage Beach",
    "urlParma": "cabbagebeach",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "The Bahamas Telecommunications Company Ltd",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cambodia",
    "urlParma": "cambodia",
    "dialNumber": "011 + 855 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.30",
        "mobile": "$0.30"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.30",
        "mobile": "$0.30"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Cellcard / MobiTel",
        "dialNumberInstruction": "011 + 855 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Sotelco",
        "dialNumberInstruction": "011 + 855 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Viettel (Cambodia) Pte.Ltd",
        "dialNumberInstruction": "011 + 855 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cameroon",
    "urlParma": "cameroon",
    "dialNumber": "011 + 237 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.50"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.50"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange Cameroon",
        "dialNumberInstruction": "011 + 237 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN Cameroon",
        "dialNumberInstruction": "011 + 237 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Viettel",
        "dialNumberInstruction": "011 + 237 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Canada",
    "urlParma": "canada",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.20",
          "multimedia": "$0.20"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Saskatel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Bell Mobility",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Rogers Wireless",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telus",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cape Verde",
    "urlParma": "capeverde",
    "dialNumber": "011 + 238 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.83",
        "mobile": "$0.89"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.83",
        "mobile": "$0.89"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "CVMovel (Cabo Verde Telecom)",
        "dialNumberInstruction": "011 + 238 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Unitel T+TELECOMUNICA•À_•À_ES",
        "dialNumberInstruction": "011 + 238 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cayman Islands",
    "urlParma": "caymanislands",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel Cayman",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Central African Republic",
    "urlParma": "centralafricanrepublic",
    "dialNumber": "011 + 236 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 236 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telecel Centrafrique",
        "dialNumberInstruction": "011 + 236 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Chad",
    "urlParma": "chad",
    "dialNumber": "011 + 235 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Millicom (Tigo)",
        "dialNumberInstruction": "011 + 235 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MILLICOM TCHAD",
        "dialNumberInstruction": "011 + 235 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Chatham Island",
    "urlParma": "chathamisland",
    "dialNumber": "011 + 64 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Chile",
    "urlParma": "chile",
    "dialNumber": "011 + 56 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 56 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Entel",
        "dialNumberInstruction": "011 + 56 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica Moviles",
        "dialNumberInstruction": "011 + 56 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "China",
    "urlParma": "china",
    "dialNumber": "011 + 86 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.13",
        "mobile": "$0.14"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "China Mobile",
        "dialNumberInstruction": "011 + 86 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "China Unicomm",
        "dialNumberInstruction": "011 + 86 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Christmas Island",
    "urlParma": "christmasisland",
    "dialNumber": "011 + 61 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.35",
        "mobile": "$1.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.35",
        "mobile": "$1.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Telstra",
        "dialNumberInstruction": "011 + 61 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 61 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cocos-Keeling Islands",
    "urlParma": "cocoskeelingislands",
    "dialNumber": "011 + 61 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.35",
        "mobile": "$1.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.35",
        "mobile": "$1.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Colombia",
    "urlParma": "colombia",
    "dialNumber": "011 + 57 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.17",
        "mobile": "$0.22"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 57 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica",
        "dialNumberInstruction": "011 + 57 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tigo Colombia",
        "dialNumberInstruction": "011 + 57 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Comoros",
    "urlParma": "comoros",
    "dialNumber": "011 + 269 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.07"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.07"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Congo, DemocraticRepublic",
    "urlParma": "congodemocracticrepublic",
    "dialNumber": "011 + 243 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.39",
        "mobile": "$1.39"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.39",
        "mobile": "$1.39"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel Congo (prev. Zain)",
        "dialNumberInstruction": "011 + 243 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "VODACOM CONGO",
        "dialNumberInstruction": "011 + 243 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Congo, Republic of",
    "urlParma": "congorepublic",
    "dialNumber": "011 + 242 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.78",
        "mobile": "$0.78"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.78",
        "mobile": "$0.78"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Equateur Telecom Congo",
        "dialNumberInstruction": "011 + 242 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN Congo",
        "dialNumberInstruction": "011 + 242 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SAIT Telecom (OASIS)",
        "dialNumberInstruction": "011 + 242 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Warid Telecom",
        "dialNumberInstruction": "011 + 242 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Zain",
        "dialNumberInstruction": "011 + 242 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cook Islands",
    "urlParma": "cookislands",
    "dialNumber": "011 + 682 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Costa Rica",
    "urlParma": "costarica",
    "dialNumber": "011 + 506 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "CLARO Costa Rica",
        "dialNumberInstruction": "011 + 506 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "ICS Wireless Inc.",
        "dialNumberInstruction": "011 + 506 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telefonica (Movistar)",
        "dialNumberInstruction": "011 + 506 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Croatia",
    "urlParma": "croatia",
    "dialNumber": "011 + 385 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.45"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.45"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Deustche Telekom (Croatian Telecom)",
        "dialNumberInstruction": "011 + 385 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tele2 D.O.O.",
        "dialNumberInstruction": "011 + 385 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cuba",
    "urlParma": "cuba",
    "dialNumber": "011 + 53 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.70",
        "mobile": "$0.70"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.19",
        "mobile": "$1.19"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Curacao",
    "urlParma": "curacao",
    "dialNumber": "011 + 599 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telcell N.V.",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Cyprus",
    "urlParma": "cyprus",
    "dialNumber": "011 + 357 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MTN (Areeba LTD)",
        "dialNumberInstruction": "011 + 357 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "PrimeTel",
        "dialNumberInstruction": "011 + 357 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Turk Cell",
        "dialNumberInstruction": "011 + 357 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Czech Republic",
    "urlParma": "czechrepublic",
    "dialNumber": "011 + 420 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "O2-CZ",
        "dialNumberInstruction": "011 + 420 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 420 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "T-Mobile (Deutsche)",
        "dialNumberInstruction": "011 + 420 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Denmark",
    "urlParma": "denmark",
    "dialNumber": "011 + 45 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.28"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Teliasonera",
        "dialNumberInstruction": "011 + 45 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telenor Nordic",
        "dialNumberInstruction": "011 + 45 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "TDC Group",
        "dialNumberInstruction": "011 + 45 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "3 Hutch (Hi3G Denmark)",
        "dialNumberInstruction": "011 + 45 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Diego Garcia",
    "urlParma": "diegogarcia",
    "dialNumber": "011 + 246 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Djibouti",
    "urlParma": "djibouti",
    "dialNumber": "011 + 253 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Evatis",
        "dialNumberInstruction": "011 + 253 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Dominica",
    "urlParma": "dominica",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Dominican Republic",
    "urlParma": "dominicanrepublic",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "CLARO DOMINICANA",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Trilogy",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "East Timor",
    "urlParma": "easttimor",
    "dialNumber": "011 + 670 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.38",
        "mobile": "$1.38"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.38",
        "mobile": "$1.38"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$3.99",
        "mobile": "$3.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Easter Island",
    "urlParma": "easterisland",
    "dialNumber": "011 + 56 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Ecuador",
    "urlParma": "ecuador",
    "dialNumber": "011 + 593 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.41"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.41"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 593 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica",
        "dialNumberInstruction": "011 + 593 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Egypt",
    "urlParma": "egypt",
    "dialNumber": "011 + 20 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 20 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "MobiNil",
        "dialNumberInstruction": "011 + 20 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 20 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "El Salvador",
    "urlParma": "elsalvador",
    "dialNumber": "011 + 503 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 503 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 503 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telefonica",
        "dialNumberInstruction": "011 + 503 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "England",
    "urlParma": "england",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Equatorial Guinea",
    "urlParma": "equatorialguinea",
    "dialNumber": "011 + 240 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Green Com",
        "dialNumberInstruction": "011 + 240 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 240 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Eritrea",
    "urlParma": "eritrea",
    "dialNumber": "011 + 291 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.89",
        "mobile": "$0.89"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.89",
        "mobile": "$0.89"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Estonia",
    "urlParma": "estonia",
    "dialNumber": "011 + 372 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.64"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.64"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Elisa Estonia",
        "dialNumberInstruction": "011 + 372 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "EMT / Teliasonera (Telia Eesti AS)",
        "dialNumberInstruction": "011 + 372 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tele2 Eesti",
        "dialNumberInstruction": "011 + 372 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Ethiopia",
    "urlParma": "ethiopia",
    "dialNumber": "011 + 251 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.02",
        "mobile": "$1.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.02",
        "mobile": "$1.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "ETMTN",
        "dialNumberInstruction": "011 + 251 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Falkland Islands",
    "urlParma": "falklandislands",
    "dialNumber": "011 + 500 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Cable & Wireless",
        "dialNumberInstruction": "011 + 500 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Faroe Islands",
    "urlParma": "faroeislands",
    "dialNumber": "011 + 298 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.53",
        "mobile": "$0.54"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.53",
        "mobile": "$0.54"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Faroese Telecom",
        "dialNumberInstruction": "011 + 298 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Fiji",
    "urlParma": "fiji",
    "dialNumber": "011 + 679 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.57"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.57"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 679 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone Fiji",
        "dialNumberInstruction": "011 + 679 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Finland",
    "urlParma": "finland",
    "dialNumber": "011 + 358 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Alands Mobiltelefon AB",
        "dialNumberInstruction": "011 + 358 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "DNA",
        "dialNumberInstruction": "011 + 358 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "France",
    "urlParma": "france",
    "dialNumber": "011 + 33 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.17"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Bouygues",
        "dialNumberInstruction": "011 + 33 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 33 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SFR",
        "dialNumberInstruction": "011 + 33 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "French Guiana",
    "urlParma": "frenchguiana",
    "dialNumber": "011 + 594 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel (French Guiana)",
        "dialNumberInstruction": "011 + 594 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Caraibe",
        "dialNumberInstruction": "011 + 594 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "French Polynesia",
    "urlParma": "frenchpolynesia",
    "dialNumber": "011 + 689 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "VINI",
        "dialNumberInstruction": "011 + 689 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone French Polynesia",
        "dialNumberInstruction": "011 + 689 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Gabon",
    "urlParma": "gabon",
    "dialNumber": "011 + 241 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.06",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.06",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Gambia",
    "urlParma": "gambia",
    "dialNumber": "011 + 220 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.59",
        "mobile": "$0.61"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.59",
        "mobile": "$0.61"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Africell",
        "dialNumberInstruction": "011 + 220 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Qcell",
        "dialNumberInstruction": "011 + 220 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Georgia",
    "urlParma": "georgia",
    "dialNumber": "011 + 995 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.78",
        "mobile": "$0.87"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.78",
        "mobile": "$0.87"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Geocell",
        "dialNumberInstruction": "011 + 995 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Magticom",
        "dialNumberInstruction": "011 + 995 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Mobitel / VIMPELCOM (Beeline)",
        "dialNumberInstruction": "011 + 995 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Megafon",
        "dialNumberInstruction": "011 + 995 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Germany",
    "urlParma": "germany",
    "dialNumber": "011 + 49 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.27"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "E+",
        "dialNumberInstruction": "011 + 49 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "O2",
        "dialNumberInstruction": "011 + 49 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica (O2)",
        "dialNumberInstruction": "011 + 49 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telekom Deutschland",
        "dialNumberInstruction": "011 + 49 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 49 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Ghana",
    "urlParma": "ghana",
    "dialNumber": "011 + 233 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.42"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.42"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel",
        "dialNumberInstruction": "011 + 233 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Glo",
        "dialNumberInstruction": "011 + 233 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN Ghana",
        "dialNumberInstruction": "011 + 233 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tigo",
        "dialNumberInstruction": "011 + 233 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone Ghana",
        "dialNumberInstruction": "011 + 233 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Gibraltar",
    "urlParma": "gibraltar",
    "dialNumber": "011 + 350 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.62"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.62"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Grand Bahamas",
    "urlParma": "grandbahamas",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Greece",
    "urlParma": "greece",
    "dialNumber": "011 + 30 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.23"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.23"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Cosmote",
        "dialNumberInstruction": "011 + 30 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone Greece",
        "dialNumberInstruction": "011 + 30 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "WIND",
        "dialNumberInstruction": "011 + 30 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Greenland",
    "urlParma": "greenland",
    "dialNumber": "011 + 299 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Grenada",
    "urlParma": "grenada",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guadeloupe",
    "urlParma": "guadeloupe",
    "dialNumber": "011 + 590 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Dauphin",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel F",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guam",
    "urlParma": "guam",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$0.20",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Docomo Pacific Inc.",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "IT&E",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guantanamo Bay",
    "urlParma": "guantanamobay",
    "dialNumber": "011 + 53 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.39",
        "mobile": "$1.39"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.39",
        "mobile": "$1.39"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guatemala",
    "urlParma": "guatemala",
    "dialNumber": "011 + 502 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 502 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Commcel",
        "dialNumberInstruction": "011 + 502 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telefonica",
        "dialNumberInstruction": "011 + 502 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guernsey",
    "urlParma": "guernsey",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel-Vodafone",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Jersey Telecom",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Sure",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guinea",
    "urlParma": "guinea",
    "dialNumber": "011 + 224 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.68",
        "mobile": "$1.85"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.68",
        "mobile": "$1.85"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MTN (Areeba)",
        "dialNumberInstruction": "011 + 224 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN (Bissau)",
        "dialNumberInstruction": "011 + 224 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guinea-Bissau",
    "urlParma": "guineabissau",
    "dialNumber": "011 + 245 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.68",
        "mobile": "$1.85"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.68",
        "mobile": "$1.85"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Spacetel(MTN) Guinee-Bissau SA",
        "dialNumberInstruction": "011 + 245 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Guyana",
    "urlParma": "guyana",
    "dialNumber": "011 + 592 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.86",
        "mobile": "$0.86"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Cellink Plus",
        "dialNumberInstruction": "011 + 592 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 592 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Digicel Guyana",
        "dialNumberInstruction": "011 + 592 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Haiti",
    "urlParma": "haiti",
    "dialNumber": "011 + 509 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 509 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Natcom (Viettel)",
        "dialNumberInstruction": "011 + 509 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Honduras",
    "urlParma": "honduras",
    "dialNumber": "011 + 504 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Celtel",
        "dialNumberInstruction": "011 + 504 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Hong Kong",
    "urlParma": "hongkong",
    "dialNumber": "011 + 852 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.09",
        "mobile": "$0.17"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "3HG SpA (3 Hutchison)",
        "dialNumberInstruction": "011 + 852 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "China Mobile",
        "dialNumberInstruction": "011 + 852 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "CSL",
        "dialNumberInstruction": "011 + 852 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "HKT",
        "dialNumberInstruction": "011 + 852 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "SmarTone",
        "dialNumberInstruction": "011 + 852 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Hungary",
    "urlParma": "hungary",
    "dialNumber": "011 + 36 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.26",
        "mobile": "$0.45"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Telenor",
        "dialNumberInstruction": "011 + 36 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 36 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Iceland",
    "urlParma": "iceland",
    "dialNumber": "011 + 354 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.67"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.67"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Nova",
        "dialNumberInstruction": "011 + 354 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone (Teymi)",
        "dialNumberInstruction": "011 + 354 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "India",
    "urlParma": "india",
    "dialNumber": "011 + 91 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.30"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Aircel Limited",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Aircel Limited Karnataka",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Cell One",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "IDEA Cellular",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Mahanagar Telephone Nigam Ltd",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Reliance Telecom Ltd",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TATA Docomo",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone - Delhi",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "IDEA Cellular - Andhra Pradesh",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone - Mumbai",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Loop Mobile (BPL)",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "IDEA CELLULAR",
        "dialNumberInstruction": "011 + 91 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Indonesia",
    "urlParma": "indonesia",
    "dialNumber": "011 + 62 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Axis",
        "dialNumberInstruction": "011 + 62 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Hutchison",
        "dialNumberInstruction": "011 + 62 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "INDOSAT",
        "dialNumberInstruction": "011 + 62 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telkomsel",
        "dialNumberInstruction": "011 + 62 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "XL",
        "dialNumberInstruction": "011 + 62 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Iran",
    "urlParma": "iran",
    "dialNumber": "011 + 98 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.38"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.38"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Iraq",
    "urlParma": "iraq",
    "dialNumber": "011 + 964 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.89",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.89",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Asian cell",
        "dialNumberInstruction": "011 + 964 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Korek Telecom",
        "dialNumberInstruction": "011 + 964 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Zain",
        "dialNumberInstruction": "011 + 964 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Ireland",
    "urlParma": "ireland",
    "dialNumber": "011 + 353 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.19"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.19"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "3G Hutch (H3G)",
        "dialNumberInstruction": "011 + 353 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "O2",
        "dialNumberInstruction": "011 + 353 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 353 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Isle of Man",
    "urlParma": "isleofman",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Manx Telecom",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Sure",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Israel",
    "urlParma": "israel",
    "dialNumber": "011 + 972 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.09",
        "mobile": "$0.15"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange / Partner Communications Company LTD.",
        "dialNumberInstruction": "011 + 972 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Cellcom",
        "dialNumberInstruction": "011 + 972 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Hot Mobile Israel",
        "dialNumberInstruction": "011 + 972 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Pelephone",
        "dialNumberInstruction": "011 + 972 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Italy",
    "urlParma": "italy",
    "dialNumber": "011 + 39 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Telecom Italia Mobile",
        "dialNumberInstruction": "011 + 39 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 39 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Wind",
        "dialNumberInstruction": "011 + 39 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Ivory Coast",
    "urlParma": "ivorycoast",
    "dialNumber": "011 + 225 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.69",
        "mobile": "$0.75"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.69",
        "mobile": "$0.75"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.56"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 225 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN Ivory Coast",
        "dialNumberInstruction": "011 + 225 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 225 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Jamaica",
    "urlParma": "jamaica",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Jan Mayen",
    "urlParma": "janmayen",
    "dialNumber": "011 + 47 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Japan",
    "urlParma": "japan",
    "dialNumber": "011 + 81 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.19"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.19"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "NTT DoCoMo, Inc",
        "dialNumberInstruction": "011 + 81 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Softbank",
        "dialNumberInstruction": "011 + 81 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Jarvis Island",
    "urlParma": "jarvisisland",
    "dialNumber": "011 + 119 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Jersey",
    "urlParma": "jersey",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel-Vodafone",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Jersey Telecom",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Sure",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Johnston Atoll",
    "urlParma": "johnstonatoll",
    "dialNumber": "011 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Jordan",
    "urlParma": "jordan",
    "dialNumber": "011 + 962 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.42"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.42"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange",
        "dialNumberInstruction": "011 + 962 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Umniah Jordan",
        "dialNumberInstruction": "011 + 962 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Jost Van Dyke",
    "urlParma": "jostvandyke",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Kazakhstan",
    "urlParma": "kazakhstan",
    "dialNumber": "011 + 7 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Altel JSC",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Beeline / VIMPELCOM (KAR-TEL)",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "GSM Kazakhstan / Kcell (Teliasonera Eurasia)",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Tele2 Kazahstan / Mobile Telecom Service LLP",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Kenya",
    "urlParma": "kenya",
    "dialNumber": "011 + 254 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.58"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.58"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel",
        "dialNumberInstruction": "011 + 254 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Econet Wireless",
        "dialNumberInstruction": "011 + 254 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Safaricom",
        "dialNumberInstruction": "011 + 254 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Kiribati",
    "urlParma": "kiribati",
    "dialNumber": "011 + 686 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Korea, Democratic People's Republic of",
    "urlParma": "northkorea",
    "dialNumber": "011 + 850 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "KT 3G",
        "dialNumberInstruction": "011 + 850 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SK Telecom",
        "dialNumberInstruction": "011 + 850 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Korea, Republic of",
    "urlParma": "southkorea",
    "dialNumber": "011 + 82 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.11"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Dacom/LG",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Jedison (KCT) (Korea",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Korea Telecom",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "KTF - Korea",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Onse Telecom",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SK Telecom/aka SureM",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SK Telink (Korean Gateway provider)",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SureM/aka MTC",
        "dialNumberInstruction": "011 + 82 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Kosovo",
    "urlParma": "kosovo",
    "dialNumber": "011 + 381 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.42",
        "mobile": "$0.63"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.42",
        "mobile": "$0.63"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Monaco Telecom / VALA",
        "dialNumberInstruction": "011 + 383 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Kuwait",
    "urlParma": "kuwait",
    "dialNumber": "011 + 965 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.46",
        "mobile": "$0.46"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.46",
        "mobile": "$0.46"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Viva-KTC",
        "dialNumberInstruction": "011 + 965 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Wataniya (Ooredoo)",
        "dialNumberInstruction": "011 + 965 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Zain",
        "dialNumberInstruction": "011 + 965 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Kyrgyzstan",
    "urlParma": "kyrgyzstan",
    "dialNumber": "011 + 996 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.33",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.33",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MegaCom / Alfa Telecom Joint Stock",
        "dialNumberInstruction": "011 + 996 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Megafon",
        "dialNumberInstruction": "011 + 996 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "NURTelecom LLC",
        "dialNumberInstruction": "011 + 996 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "VimpelCom (Sky Mobile L.L.C.) / Beeline",
        "dialNumberInstruction": "011 + 996 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Laos",
    "urlParma": "laos",
    "dialNumber": "011 + 856 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.38",
        "mobile": "$0.38"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.38",
        "mobile": "$0.38"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Beeline",
        "dialNumberInstruction": "011 + 856 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "STL Star Telecom comp. Ltd.",
        "dialNumberInstruction": "011 + 856 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Latvia",
    "urlParma": "latvia",
    "dialNumber": "011 + 371 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.41"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.41"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Bite Latvija",
        "dialNumberInstruction": "011 + 371 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Teliasonera (LAVTVIJAS Mobile)",
        "dialNumberInstruction": "011 + 371 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tele2 SIA",
        "dialNumberInstruction": "011 + 371 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Lebanon",
    "urlParma": "lebanon",
    "dialNumber": "011 + 961 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.44"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.44"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Touch",
        "dialNumberInstruction": "011 + 961 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Lesotho",
    "urlParma": "lesotho",
    "dialNumber": "011 + 266 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.85",
        "mobile": "$0.91"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.85",
        "mobile": "$0.91"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "VODACOM LESOTHO",
        "dialNumberInstruction": "011 + 266 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Liberia",
    "urlParma": "liberia",
    "dialNumber": "011 + 231 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.59",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.59",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Celcom Telecommunications",
        "dialNumberInstruction": "011 + 231 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Lonestar Cell",
        "dialNumberInstruction": "011 + 231 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Libya",
    "urlParma": "libya",
    "dialNumber": "011 + 218 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.98",
        "mobile": "$1.02"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.98",
        "mobile": "$1.02"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "El Madar",
        "dialNumberInstruction": "011 + 218 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Liechtenstein",
    "urlParma": "liechtenstein",
    "dialNumber": "011 + 423 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.10",
        "mobile": "$1.11"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.10",
        "mobile": "$1.11"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange FL",
        "dialNumberInstruction": "011 + 423 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Swisscom",
        "dialNumberInstruction": "011 + 423 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telekom Austria (MOBILKOM)",
        "dialNumberInstruction": "011 + 423 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Lithuania",
    "urlParma": "lithuania",
    "dialNumber": "011 + 370 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.40"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.40"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "UAB Omnitel / Teliasonera",
        "dialNumberInstruction": "011 + 370 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Bite Lithuania",
        "dialNumberInstruction": "011 + 370 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "TELE2 UAB",
        "dialNumberInstruction": "011 + 370 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Luxembourg",
    "urlParma": "luxembourg",
    "dialNumber": "011 + 352 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.10",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange (VOX Mobile)",
        "dialNumberInstruction": "011 + 352 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "POST Luxembourg",
        "dialNumberInstruction": "011 + 352 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tango",
        "dialNumberInstruction": "011 + 352 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Macao (Macau)",
    "urlParma": "macao",
    "dialNumber": "011 + 853 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.79",
        "mobile": "$0.79"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.79",
        "mobile": "$0.79"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "3 (Hutchison)",
        "dialNumberInstruction": "011 + 853 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "CTM",
        "dialNumberInstruction": "011 + 853 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "SmarTone",
        "dialNumberInstruction": "011 + 853 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Macedonia",
    "urlParma": "macedonia",
    "dialNumber": "011 + 389 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.56",
        "mobile": "$0.71"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.56",
        "mobile": "$0.71"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "COSMOFON / ONE (Telekom Slovenije)",
        "dialNumberInstruction": "011 + 389 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "VIP Mobile / Telekom Austria",
        "dialNumberInstruction": "011 + 389 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Madagascar",
    "urlParma": "madagascar",
    "dialNumber": "011 + 261 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$2.29",
        "mobile": "$2.38"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$2.29",
        "mobile": "$2.38"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel",
        "dialNumberInstruction": "011 + 261 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telma Mobile",
        "dialNumberInstruction": "011 + 261 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Madeira and Azores",
    "urlParma": "madeiraandazores",
    "dialNumber": "011 + 351 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.29"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.29"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Optimus",
        "dialNumberInstruction": "011 + 351 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TMN Portugal",
        "dialNumberInstruction": "011 + 351 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone Portugal",
        "dialNumberInstruction": "011 + 351 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Malawi",
    "urlParma": "malawi",
    "dialNumber": "011 + 265 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.51"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.51"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel Malawi",
        "dialNumberInstruction": "011 + 265 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TNM",
        "dialNumberInstruction": "011 + 265 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Malaysia",
    "urlParma": "malaysia",
    "dialNumber": "011 + 60 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.18",
        "mobile": "$0.21"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Celcom Axiata Berhad",
        "dialNumberInstruction": "011 + 60 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Digi Telecom",
        "dialNumberInstruction": "011 + 60 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Maxis Mobile",
        "dialNumberInstruction": "011 + 60 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "U Mobile Sdn Bhd",
        "dialNumberInstruction": "011 + 60 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Maldives",
    "urlParma": "maldives",
    "dialNumber": "011 + 960 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.48",
        "mobile": "$1.48"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.48",
        "mobile": "$1.48"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Dhiraguu",
        "dialNumberInstruction": "011 + 960 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Ooredoo Maldives",
        "dialNumberInstruction": "011 + 960 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mali",
    "urlParma": "mali",
    "dialNumber": "011 + 223 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.08",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.08",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Malitel",
        "dialNumberInstruction": "011 + 223 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange MALI",
        "dialNumberInstruction": "011 + 223 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Malta",
    "urlParma": "malta",
    "dialNumber": "011 + 356 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.39",
        "mobile": "$0.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Marie Galante",
    "urlParma": "mariegalante",
    "dialNumber": "011 + 590 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Digicel F",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Caraibe",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Marshall Islands",
    "urlParma": "marshallislands",
    "dialNumber": "011 + 692 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.79",
        "mobile": "$0.79"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.75",
        "mobile": "$0.75"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Martinique",
    "urlParma": "martinique",
    "dialNumber": "011 + 596 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel F",
        "dialNumberInstruction": "011 + 596 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Caraibe",
        "dialNumberInstruction": "011 + 596 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mauritania",
    "urlParma": "mauritania",
    "dialNumber": "011 + 222 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$0.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MATTEL",
        "dialNumberInstruction": "011 + 222 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MAURITEL",
        "dialNumberInstruction": "011 + 222 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mauritius",
    "urlParma": "mauritius",
    "dialNumber": "011 + 230 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.26",
        "mobile": "$1.26"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.26",
        "mobile": "$1.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange",
        "dialNumberInstruction": "011 + 230 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mayotte Island",
    "urlParma": "mayotteisland",
    "dialNumber": "011 + 269 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$1.16"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mexico",
    "urlParma": "mexico",
    "dialNumber": "011 + 52 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.65"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.20",
          "multimedia": "$0.20"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Movistar",
        "dialNumberInstruction": "011 + 52 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telcel",
        "dialNumberInstruction": "011 + 52 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Micronesia",
    "urlParma": "micronesia",
    "dialNumber": "011 + 691 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.78",
        "mobile": "$0.78"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.78",
        "mobile": "$0.78"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "FSM Telecommunications Corporation",
        "dialNumberInstruction": "011 + 691 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Midway Island",
    "urlParma": "midwayisland",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Moldova",
    "urlParma": "moldova",
    "dialNumber": "011 + 373 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.58"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.58"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Megafon",
        "dialNumberInstruction": "011 + 373 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Monaco",
    "urlParma": "monaco",
    "dialNumber": "011 + 377 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Bouygues",
        "dialNumberInstruction": "011 + 377 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 377 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SFR",
        "dialNumberInstruction": "011 + 377 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mongolia",
    "urlParma": "mongolia",
    "dialNumber": "011 + 976 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.39"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Unitel",
        "dialNumberInstruction": "011 + 976 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Montenegro",
    "urlParma": "montenegro",
    "dialNumber": "011 + 382 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.42",
        "mobile": "$0.63"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.42",
        "mobile": "$0.63"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Telenor (Promonte)",
        "dialNumberInstruction": "011 + 382 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Montserrat",
    "urlParma": "montserrat",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Lime / Cable & Wireless",
        "dialNumberInstruction": "011 + 382 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Morocco",
    "urlParma": "morocco",
    "dialNumber": "011 + 212 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.61"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.61"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "IAM",
        "dialNumberInstruction": "011 + 212 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Medi Telecom",
        "dialNumberInstruction": "011 + 212 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Mozambique",
    "urlParma": "mozambique",
    "dialNumber": "011 + 258 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$1.44"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.29",
        "mobile": "$1.44"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "mCel",
        "dialNumberInstruction": "011 + 258 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodacom Mozambique",
        "dialNumberInstruction": "011 + 258 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Myanmar - Burma",
    "urlParma": "myanmarburma",
    "dialNumber": "011 + 95 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.30",
        "mobile": "$1.50"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.50",
        "mobile": "$1.50"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$3.99",
        "mobile": "$3.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Namibia",
    "urlParma": "namibia",
    "dialNumber": "011 + 264 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.95"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.81",
        "mobile": "$0.95"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Nauru",
    "urlParma": "nauru",
    "dialNumber": "011 + 674 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 674 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Nepal",
    "urlParma": "nepal",
    "dialNumber": "011 + 977 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Ncell (Spice)",
        "dialNumberInstruction": "011 + 977 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "NTC",
        "dialNumberInstruction": "011 + 977 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Netherlands",
    "urlParma": "netherlands",
    "dialNumber": "011 + 31 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.28"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Deutsche Telekom (T-Mobile)",
        "dialNumberInstruction": "011 + 31 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Deutsche Telekom (T-Mobile) (Inbound Only)",
        "dialNumberInstruction": "011 + 31 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "KPN",
        "dialNumberInstruction": "011 + 31 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 31 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Netherlands Antilles",
    "urlParma": "netherlandantilles",
    "dialNumber": "011 + 599 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telcell N.V.",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "New Caledonia",
    "urlParma": "newcaledonia",
    "dialNumber": "011 + 687 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.46",
        "mobile": "$1.46"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.46",
        "mobile": "$1.46"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "New Providence (Nassau)",
    "urlParma": "newprovidence",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "The Bahamas Telecommunications Company Ltd",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "New Zealand",
    "urlParma": "newzealand",
    "dialNumber": "011 + 64 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.34"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "2degrees (Trilogy)",
        "dialNumberInstruction": "011 + 64 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telecom New Zealand",
        "dialNumberInstruction": "011 + 64 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 64 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Nicaragua",
    "urlParma": "nicaragua",
    "dialNumber": "011 + 505 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro",
        "dialNumberInstruction": "011 + 505 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telefonica",
        "dialNumberInstruction": "011 + 505 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Niger",
    "urlParma": "niger",
    "dialNumber": "011 + 227 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.94",
        "mobile": "$0.96"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.94",
        "mobile": "$0.96"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel",
        "dialNumberInstruction": "011 + 227 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Nigeria",
    "urlParma": "nigeria",
    "dialNumber": "011 + 234 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel Niger (celtel)",
        "dialNumberInstruction": "011 + 234 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Etilsat/aka EMTS",
        "dialNumberInstruction": "011 + 234 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Glo Mobile (Globacom Ltd)",
        "dialNumberInstruction": "011 + 234 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "MTN",
        "dialNumberInstruction": "011 + 234 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Niue",
    "urlParma": "niue",
    "dialNumber": "011 + 683 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Norfolk Island",
    "urlParma": "norfolkisland",
    "dialNumber": "011 + 672 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$3.35",
        "mobile": "$3.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$3.35",
        "mobile": "$3.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$3.99",
        "mobile": "$3.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Norfolk Telecom",
        "dialNumberInstruction": "011 + 672 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Northern Ireland",
    "urlParma": "irelandnorthern",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "EE Limited (T-Mobile)",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "O2",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Northern Mariana Islands",
    "urlParma": "northernmarianaislands",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$0.20",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Docomo Pacific Inc.",
        "dialNumberInstruction": "011 + 670 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "IT&E",
        "dialNumberInstruction": "011 + 670 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Norway",
    "urlParma": "norway",
    "dialNumber": "011 + 47 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Netcom",
        "dialNumberInstruction": "011 + 47 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telenor",
        "dialNumberInstruction": "011 + 47 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Oman",
    "urlParma": "oman",
    "dialNumber": "011 + 968 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.09",
        "mobile": "$1.10"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.09",
        "mobile": "$1.10"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Nawras",
        "dialNumberInstruction": "011 + 968 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Oman Mobile",
        "dialNumberInstruction": "011 + 968 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Pakistan",
    "urlParma": "pakistan",
    "dialNumber": "011 + 92 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.33",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Mobilink",
        "dialNumberInstruction": "011 + 92 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Ufone",
        "dialNumberInstruction": "011 + 92 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Warid Telecom (PVT) Ltd",
        "dialNumberInstruction": "011 + 92 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Palau",
    "urlParma": "palau",
    "dialNumber": "011 + 680 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.31",
        "mobile": "$1.31"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.31",
        "mobile": "$1.31"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "PNCC Palau",
        "dialNumberInstruction": "011 + 680 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Palestinian Authority",
    "urlParma": "palestinianauthority",
    "dialNumber": "011 + 970 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.25",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.25",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Cellcom",
        "dialNumberInstruction": "011 + 970 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Paltel",
        "dialNumberInstruction": "011 + 970 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Palmyra Atoll",
    "urlParma": "palmyraatoll",
    "dialNumber": "011 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Panama",
    "urlParma": "panama",
    "dialNumber": "011 + 507 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Cable & Wireless (Mas Movil)",
        "dialNumberInstruction": "011 + 507 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Claro Panama",
        "dialNumberInstruction": "011 + 507 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 507 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Movistar (Telefonica)",
        "dialNumberInstruction": "011 + 507 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Papua New Guinea",
    "urlParma": "papuanewguinea",
    "dialNumber": "011 + 675 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.07",
        "mobile": "$1.07"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.07",
        "mobile": "$1.07"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Bmobile Limited",
        "dialNumberInstruction": "011 + 675 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 675 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Paradise Island",
    "urlParma": "paradiseisland",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Paraguay",
    "urlParma": "paraguay",
    "dialNumber": "011 + 595 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.42"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro Paraguay",
        "dialNumberInstruction": "011 + 595 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Personal",
        "dialNumberInstruction": "011 + 595 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telecel Paraguay",
        "dialNumberInstruction": "011 + 595 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Peru",
    "urlParma": "peru",
    "dialNumber": "011 + 51 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.25",
        "mobile": "$0.45"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "America Movil",
        "dialNumberInstruction": "011 + 51 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Nextel Peru",
        "dialNumberInstruction": "011 + 51 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica (Claro)",
        "dialNumberInstruction": "011 + 51 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Philippines",
    "urlParma": "philippines",
    "dialNumber": "011 + 63 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.23"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.23"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digitel Mobile/Sun Cellular",
        "dialNumberInstruction": "011 + 63 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Globe Telecom",
        "dialNumberInstruction": "011 + 63 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "SMART Gold",
        "dialNumberInstruction": "011 + 63 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Poland",
    "urlParma": "poland",
    "dialNumber": "011 + 48 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.37"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange",
        "dialNumberInstruction": "011 + 48 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "P4",
        "dialNumberInstruction": "011 + 48 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Plus",
        "dialNumberInstruction": "011 + 48 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Deutsche Telekom (T-Mobile)",
        "dialNumberInstruction": "011 + 48 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Portugal",
    "urlParma": "portugal",
    "dialNumber": "011 + 351 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.29"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.29"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Optimus",
        "dialNumberInstruction": "011 + 351 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TMN (Portugal Telecom)",
        "dialNumberInstruction": "011 + 351 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 351 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Puerto Rico",
    "urlParma": "puertorico",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Qatar",
    "urlParma": "qatar",
    "dialNumber": "011 + 974 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.96",
        "mobile": "$0.98"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.96",
        "mobile": "$0.98"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Ooredoo (Q-Tel)",
        "dialNumberInstruction": "011 + 974 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone Qatar",
        "dialNumberInstruction": "011 + 974 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Reunion",
    "urlParma": "reunionisland",
    "dialNumber": "011 + 262 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Outremer Telcom",
        "dialNumberInstruction": "011 + 262 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Romania",
    "urlParma": "romania",
    "dialNumber": "011 + 40 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.02",
        "mobile": "$0.02"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Deutsche Telekom",
        "dialNumberInstruction": "011 + 40 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "DigiMobile",
        "dialNumberInstruction": "011 + 40 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 40 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Russia",
    "urlParma": "russia",
    "dialNumber": "011 + 7 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.22"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.20",
        "mobile": "$0.22"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Beeline",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "BWC",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Megafon",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Motiv",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTS",
        "dialNumberInstruction": "011 + 7 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Rwandese Republic",
    "urlParma": "rwanda",
    "dialNumber": "011 + 250 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.21",
        "mobile": "$1.21"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.21",
        "mobile": "$1.21"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MTN",
        "dialNumberInstruction": "011 + 250 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tigo (Millicom)",
        "dialNumberInstruction": "011 + 250 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Saba",
    "urlParma": "saba",
    "dialNumber": "011 + 599 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Saipan",
    "urlParma": "saipan",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$0.20",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Samoa",
    "urlParma": "samoa",
    "dialNumber": "011 + 685 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.19",
        "mobile": "$1.26"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.19",
        "mobile": "$1.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel Samoa",
        "dialNumberInstruction": "011 + 685 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "San Marino",
    "urlParma": "sanmarino",
    "dialNumber": "011 + 378 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.25",
        "mobile": "$1.44"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.25",
        "mobile": "$1.44"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Telecom Italia Mobile",
        "dialNumberInstruction": "011 + 378 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 378 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Wind",
        "dialNumberInstruction": "011 + 378 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Saotome Principe",
    "urlParma": "saotomeprincipe",
    "dialNumber": "011 + 239 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Saudi Arabia",
    "urlParma": "saudiarabia",
    "dialNumber": "011 + 966 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "ETISALAT (Mobily)",
        "dialNumberInstruction": "011 + 966 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "STC",
        "dialNumberInstruction": "011 + 966 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Zain KSA",
        "dialNumberInstruction": "011 + 966 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Scotland",
    "urlParma": "scotland",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "EE Limited (T-Mobile)",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "O2",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Senegal",
    "urlParma": "senegal",
    "dialNumber": "011 + 221 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.69",
        "mobile": "$0.76"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.69",
        "mobile": "$0.76"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange",
        "dialNumberInstruction": "011 + 221 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SENTEL",
        "dialNumberInstruction": "011 + 221 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Serbia",
    "urlParma": "serbia",
    "dialNumber": "011 + 381 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.42",
        "mobile": "$0.63"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.42",
        "mobile": "$0.63"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Telekom Austria (VIP Mobile)",
        "dialNumberInstruction": "011 + 381 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telenor",
        "dialNumberInstruction": "011 + 381 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Seychelles",
    "urlParma": "seychelles",
    "dialNumber": "011 + 248 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.32",
        "mobile": "$1.32"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.32",
        "mobile": "$1.32"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Cable & Wireless",
        "dialNumberInstruction": "011 + 248 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Sierra Leone",
    "urlParma": "sierraleone",
    "dialNumber": "011 + 232 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.60"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Africell",
        "dialNumberInstruction": "011 + 232 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Airtel Sierra Leone",
        "dialNumberInstruction": "011 + 232 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Singapore",
    "urlParma": "singapore",
    "dialNumber": "011 + 65 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.13",
        "mobile": "$0.13"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "M1",
        "dialNumberInstruction": "011 + 65 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "SingTel",
        "dialNumberInstruction": "011 + 65 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "StarHub",
        "dialNumberInstruction": "011 + 65 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Slovakia",
    "urlParma": "slovakia",
    "dialNumber": "011 + 421 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.19",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Slovak Telekom (T-Mobile)",
        "dialNumberInstruction": "011 + 421 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Slovenia",
    "urlParma": "slovenia",
    "dialNumber": "011 + 386 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.58",
        "mobile": "$0.81"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.58",
        "mobile": "$0.81"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Tusmobil",
        "dialNumberInstruction": "011 + 386 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Solomon Islands",
    "urlParma": "solomonislands",
    "dialNumber": "011 + 677 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "BeMobile",
        "dialNumberInstruction": "011 + 677 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Somalia",
    "urlParma": "somalia",
    "dialNumber": "011 + 252 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Golis Telecom (Somalia)",
        "dialNumberInstruction": "011 + 252 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Hormuud (Somalia)",
        "dialNumberInstruction": "011 + 252 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Nationlink (Somalia)",
        "dialNumberInstruction": "011 + 252 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Somtel Somalia (Somalia)",
        "dialNumberInstruction": "011 + 252 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telesom (Somalia)",
        "dialNumberInstruction": "011 + 252 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "South Africa",
    "urlParma": "southafrica",
    "dialNumber": "011 + 27 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.50"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.50"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Cell C",
        "dialNumberInstruction": "011 + 27 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "MTN",
        "dialNumberInstruction": "011 + 27 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodacom",
        "dialNumberInstruction": "011 + 27 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Spain",
    "urlParma": "spain",
    "dialNumber": "011 + 34 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.07",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange",
        "dialNumberInstruction": "011 + 34 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica/Movistar",
        "dialNumberInstruction": "011 + 34 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TeliaSonera",
        "dialNumberInstruction": "011 + 34 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 34 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Sri Lanka",
    "urlParma": "srilanka",
    "dialNumber": "011 + 94 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$1.02"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.99",
        "mobile": "$1.02"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Dialog Aixata PLC",
        "dialNumberInstruction": "011 + 94 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 94 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Hutchison Telecommunications Lanka (Pvt) Ltd",
        "dialNumberInstruction": "011 + 94 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Mobitel (PVT) LTD",
        "dialNumberInstruction": "011 + 94 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Barthelemy",
    "urlParma": "stbarthelemy",
    "dialNumber": "011 + 590 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Digicel F",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Caraibe",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Croix",
    "urlParma": "stcroix",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Eustatius",
    "urlParma": "steustatius",
    "dialNumber": "011 + 599 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 599 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Helena",
    "urlParma": "sthelena",
    "dialNumber": "011 + 290 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Cable & Wireless Guernsey",
        "dialNumberInstruction": "011 + 290 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. John",
    "urlParma": "stjohn",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Kitts and Nevis",
    "urlParma": "stkittsandnevis",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Lucia",
    "urlParma": "stlucia",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Maarten",
    "urlParma": "stmaarten",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Telcell N.V.",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Martin",
    "urlParma": "stmartin",
    "dialNumber": "011 + 590 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.52"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Digicel F",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Caraibe",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "UTS Setel (Chippie)",
        "dialNumberInstruction": "011 + 590 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Pierre & Miquelon",
    "urlParma": "stpierremiquelon",
    "dialNumber": "011 + 508 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Thomas",
    "urlParma": "stthomas",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "St. Vincent and Grenadines",
    "urlParma": "stvincentandthegrenadines",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Lime",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Sudan",
    "urlParma": "sudan",
    "dialNumber": "011 + 249 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.89",
        "mobile": "$0.91"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.89",
        "mobile": "$0.91"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Suriname",
    "urlParma": "suriname",
    "dialNumber": "011 + 597 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.27",
        "mobile": "$1.27"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.39",
        "mobile": "$0.69"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 597 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Intelsur (UNIQA)",
        "dialNumberInstruction": "011 + 597 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telesur",
        "dialNumberInstruction": "011 + 597 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Svalbard",
    "urlParma": "svalbard",
    "dialNumber": "011 + 47 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Telenor",
        "dialNumberInstruction": "011 + 47 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Swaziland",
    "urlParma": "swaziland",
    "dialNumber": "011 + 268 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.77",
        "mobile": "$0.89"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.77",
        "mobile": "$0.89"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Swazi MTN Limited",
        "dialNumberInstruction": "011 + 268 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Sweden",
    "urlParma": "sweden",
    "dialNumber": "011 + 46 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.35"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "3 Hutch (Hi3G Access)",
        "dialNumberInstruction": "011 + 46 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Tele 2 Sverige AB",
        "dialNumberInstruction": "011 + 46 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telenor",
        "dialNumberInstruction": "011 + 46 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "TeliaSonera",
        "dialNumberInstruction": "011 + 46 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Switzerland",
    "urlParma": "switzerland",
    "dialNumber": "011 + 41 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.08",
        "mobile": "$0.32"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange",
        "dialNumberInstruction": "011 + 41 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Sunrise",
        "dialNumberInstruction": "011 + 41 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Swisscom",
        "dialNumberInstruction": "011 + 41 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Syria",
    "urlParma": "syria",
    "dialNumber": "011 + 963 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.88",
        "mobile": "$0.94"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.88",
        "mobile": "$0.94"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MTN",
        "dialNumberInstruction": "011 + 963 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tahiti",
    "urlParma": "tahiti",
    "dialNumber": "011 + 689 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "VINI",
        "dialNumberInstruction": "011 + 689 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone French Polynesia",
        "dialNumberInstruction": "011 + 689 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Taiwan",
    "urlParma": "taiwan",
    "dialNumber": "011 + 886 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.12"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.12"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Chunghwa",
        "dialNumberInstruction": "011 + 886 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Far EasTone",
        "dialNumberInstruction": "011 + 886 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Taiwain Mobile",
        "dialNumberInstruction": "011 + 886 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tajikistan",
    "urlParma": "tajikistan",
    "dialNumber": "011 + 992 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.31",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.31",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Babilon-M",
        "dialNumberInstruction": "011 + 992 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Megafon",
        "dialNumberInstruction": "011 + 992 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "T-Cell",
        "dialNumberInstruction": "011 + 992 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "VimpelCom",
        "dialNumberInstruction": "011 + 992 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tanzania",
    "urlParma": "tanzania",
    "dialNumber": "011 + 255 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.54"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.54"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel Tanzania",
        "dialNumberInstruction": "011 + 255 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodacom Tanzania Limited",
        "dialNumberInstruction": "011 + 255 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "ZANTEL",
        "dialNumberInstruction": "011 + 255 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Thailand",
    "urlParma": "thailand",
    "dialNumber": "011 + 66 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.24",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "AIS",
        "dialNumberInstruction": "011 + 66 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "AWIN",
        "dialNumberInstruction": "011 + 66 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Real Future Company Ltd",
        "dialNumberInstruction": "011 + 66 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Telenor (DTAC) 2G Only",
        "dialNumberInstruction": "011 + 66 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "True Move",
        "dialNumberInstruction": "011 + 66 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "True Move (Real Future)",
        "dialNumberInstruction": "011 + 66 + the local number",
        "messaging": {
          "text": null,
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Togo",
    "urlParma": "togo",
    "dialNumber": "011 + 228 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.12",
        "mobile": "$1.19"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.12",
        "mobile": "$1.19"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Etisalat",
        "dialNumberInstruction": "011 + 228 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Togo Cellulaire",
        "dialNumberInstruction": "011 + 228 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tokelau",
    "urlParma": "tokelau",
    "dialNumber": "011 + 690 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$2.96",
        "mobile": "$2.96"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$2.96",
        "mobile": "$2.96"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$4.90",
        "mobile": "$4.90"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tonga Islands",
    "urlParma": "tongaisland",
    "dialNumber": "011 + 676 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 676 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "U-CALL",
        "dialNumberInstruction": "011 + 676 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tortola",
    "urlParma": "tortola",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Trinidad & Tobago",
    "urlParma": "trinidadandtobago",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "TSTT",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tunisia",
    "urlParma": "tunisia",
    "dialNumber": "011 + 216 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.58"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.58"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Orange Tunisie",
        "dialNumberInstruction": "011 + 216 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Tuntel",
        "dialNumberInstruction": "011 + 216 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Turkey",
    "urlParma": "turkey",
    "dialNumber": "011 + 90 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.46"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.46"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Avea (Turk Telekom)",
        "dialNumberInstruction": "011 + 90 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Avea Iletisim Hizmetleri A.S.",
        "dialNumberInstruction": "011 + 90 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Turkcell",
        "dialNumberInstruction": "011 + 90 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone Turkey",
        "dialNumberInstruction": "011 + 90 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Turkmenistan",
    "urlParma": "turkmenistan",
    "dialNumber": "011 + 993 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.45",
        "mobile": "$0.45"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.45",
        "mobile": "$0.45"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Turks and Caicos Islands",
    "urlParma": "turksandcaicosislands",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Lime GSM",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Islandcom",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Tuvalu",
    "urlParma": "tuvalu",
    "dialNumber": "011 + 688 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Tuvalu Telecom",
        "dialNumberInstruction": "011 + 688 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Uganda",
    "urlParma": "ugandaa",
    "dialNumber": "011 + 256 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.51"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.51"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel Uganda",
        "dialNumberInstruction": "011 + 256 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN",
        "dialNumberInstruction": "011 + 256 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange Uganda",
        "dialNumberInstruction": "011 + 256 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Ukraine",
    "urlParma": "ukraine",
    "dialNumber": "011 + 380 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.26",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.26",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Kyivstar (VIMPELCOM)",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Life (ASTELIT)",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "MTS",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Kyivstar - Ukraine",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Life - Ukraine",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTS",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTS - Ukraine",
        "dialNumberInstruction": "011 + 380 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "United Arab Emirates",
    "urlParma": "unitedarabemirates",
    "dialNumber": "011 + 971 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.38",
        "mobile": "$0.39"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.38",
        "mobile": "$0.39"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "DU (Emirates Integrated Telecom Company)",
        "dialNumberInstruction": "011 + 971 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "United Kingdom",
    "urlParma": "unitedkingdom",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "3 Hutch (H3G)",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "EE Limited (T-Mobile)",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "O2",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Uruguay",
    "urlParma": "uruguay",
    "dialNumber": "011 + 598 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.43"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Claro Uruguay",
        "dialNumberInstruction": "011 + 598 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Telefonica",
        "dialNumberInstruction": "011 + 598 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Uzbekistan",
    "urlParma": "uzbekistan",
    "dialNumber": "011 + 998 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.31"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Coscom Uzbekistan",
        "dialNumberInstruction": "011 + 998 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Vanuatu",
    "urlParma": "vanuatu",
    "dialNumber": "011 + 678 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.49"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Digicel Vanuatu",
        "dialNumberInstruction": "011 + 678 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Vatican City",
    "urlParma": "vaticancity",
    "dialNumber": "011 + 39 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.10",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.10",
        "mobile": "$0.20"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Telecom Italia Mobile",
        "dialNumberInstruction": "011 + 39 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 39 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Wind",
        "dialNumberInstruction": "011 + 39 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Venezuela",
    "urlParma": "venezuela",
    "dialNumber": "011 + 58 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.20",
        "mobile": "$0.36"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Movilnet",
        "dialNumberInstruction": "011 + 58 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Movistar",
        "dialNumberInstruction": "011 + 58 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Vietnam",
    "urlParma": "vietnam",
    "dialNumber": "011 + 84 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.54",
        "mobile": "$0.56"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.54",
        "mobile": "$0.56"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Gmobile",
        "dialNumberInstruction": "011 + 84 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vietnamobile",
        "dialNumberInstruction": "011 + 84 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Viettel",
        "dialNumberInstruction": "011 + 84 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": "Vinaphone",
        "dialNumberInstruction": "011 + 84 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Virgin Gorda",
    "urlParma": "virgingorda",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Virgin Islands, British",
    "urlParma": "virginislandsbritish",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.05",
        "mobile": "$0.05"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "C&W",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "CCT",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Digicel",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": "icon-checkmark"
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Virgin Islands, US",
    "urlParma": "virginislandsus",
    "dialNumber": "1 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "Per Your Price Plan",
        "mobile": "Per Your Price Plan"
      },
      "monthlyAccessCharge": "Per Your Price Plan"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.20",
          "multimedia": "$0.20"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "AT&T",
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": "011 + 1 + the local number",
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Wake Island",
    "urlParma": "wakeisland",
    "dialNumber": "011 + 808 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Wales",
    "urlParma": "wales",
    "dialNumber": "011 + 44 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0",
        "mobile": "$0"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.06",
        "mobile": "$0.26"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.69"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "EE Limited (T-Mobile)",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "O2",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Orange",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Vodafone",
        "dialNumberInstruction": "011 + 44 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Wallis and Futuna Islands",
    "urlParma": "wallisandfutunaislands",
    "dialNumber": "011 + 681 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$2.50",
        "mobile": "$2.50"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$2.50",
        "mobile": "$2.50"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.99",
        "mobile": "$2.99"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Western Sahara",
    "urlParma": "westernsahara",
    "dialNumber": "011 + 732 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "N/A",
        "mobile": "N/A"
      },
      "monthlyAccessCharge": "N/A"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Yemen",
    "urlParma": "yemen",
    "dialNumber": "011 + 967 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.98",
        "mobile": "$0.98"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.98",
        "mobile": "$0.98"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$2.49",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "MTN",
        "dialNumberInstruction": "011 + 967 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Zambia",
    "urlParma": "zambia",
    "dialNumber": "011 + 260 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.40"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.29",
        "mobile": "$0.40"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Airtel Zambia",
        "dialNumberInstruction": "011 + 260 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "MTN ZAMBIA",
        "dialNumberInstruction": "011 + 260 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": "Zamtel Zambia",
        "dialNumberInstruction": "011 + 260 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Zanzibar",
    "urlParma": "zanzibar",
    "dialNumber": "011 + 255 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.54"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.49",
        "mobile": "$0.54"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.49",
        "mobile": "$1.54"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": null,
          "multimedia": null
        },
        "messageRecieved": {
          "text": null,
          "multimedia": null
        }
      },
      "carriers": [{
        "name": "Airtel Tanzania",
        "dialNumberInstruction": null,
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }, {
    "name": "Zimbabwe",
    "urlParma": "zimbabwe",
    "dialNumber": "011 + 263 + the local number",
    "unlimitedWorldPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.59"
      },
      "monthlyAccessCharge": "$15.00"
    },
    "unlimitedNorthAmericaPlan": {
      "voiceRate": {
        "landline": "$0.34",
        "mobile": "$0.59"
      },
      "monthlyAccessCharge": "$5.00"
    },
    "internationalStandardPlan": {
      "voiceRate": {
        "landline": "$1.99",
        "mobile": "$2.49"
      },
      "monthlyAccessCharge": "None"
    },
    "messaging": {
      "standardRates": {
        "messageSent": {
          "text": "$0.25",
          "multimedia": "$0.50"
        },
        "messageRecieved": {
          "text": "$0.20",
          "multimedia": "$0.25"
        }
      },
      "carriers": [{
        "name": "Econet",
        "dialNumberInstruction": "011 + 263 + the local number",
        "messaging": {
          "text": "icon-checkmark",
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }, {
        "name": null,
        "dialNumberInstruction": null,
        "messaging": {
          "text": null,
          "multimedia": null
        }
      }]
    },
  }]
}
);
                chunk = JSON.parse(resbody);
                chunk = chunk || {};               
                if(chunk.availability && (chunk.availability === 'true')) {
                    agentAvailabilityModel.response.Page.availability = true;
                    agentAvailabilityModel.response.Page.inHOP = true;
                    agentAvailabilityModel.response.Page.status = "online";
                    agentAvailabilityModel.response.Page.agentBusy = false;
                    agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                } else {
                    agentAvailabilityModel.response.Page.availability = false;
                    agentAvailabilityModel.response.Page.inHOP = false;
                    agentAvailabilityModel.response.Page.status = "offline";
                    if(req.session.statusCounter >= 6){
                        req.session.statusCounter = 0;
                        agentAvailabilityModel.response.Page.agentBusy = true;
                        agentAvailabilityModel.response.ModuleMap.Support.msgList = agentAvailabilityModel.msgList;
                        logger.general.info(logger.formatInfoMsg(req.session.id, "Reached max retry times, all agents are still busy, stopped calling find agent API."));                      
                    }else{
                        agentAvailabilityModel.response.Page.agentBusy = false;
                        agentAvailabilityModel.response.ModuleMap.Support.msgList = [];
                    }
                }
                logger.general.info(logger.formatInBoundResMsg(req, agentAvailabilityModel.response));
                res.send(agentAvailabilityModel.response);
            });
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                res.send(err);

            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
