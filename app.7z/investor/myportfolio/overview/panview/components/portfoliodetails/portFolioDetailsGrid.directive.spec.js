'use strict';

describe('Directive : PortFolio Details Grid', function() {
    var rootScope, scope, compile, directiveElem, panView, panViewData, isolatedScope, portfolioDetailsModelDataObj;
    var panViewData ={
        'portfolioDetails': {
            'rows': [{
                    'folioId': '17877097',
                    'holidingType': 'Single',
                    'currentCost': '82498.74',
                    'currentValue': '122163.91',
                    'accessLevel': 'View',
                    'returns': '25%'
                }, {
                    'folioId': '27877097',
                    'holidingType': 'Single',
                    'currentCost': '82498.74',
                    'currentValue': '122163.91',
                    'accessLevel': 'View',
                    'returns': '25%'
                }],
                'grandTotal': {
                    'totalUnits': null,
                    'folioId': 'GRAND TOTAL',
                    'account': null,
                    'currentValue': '122163.91',
                    'currentCost': '82498.74'
                }
        },
        'investmentSummary': [{
            'folioId': '17877097',
            'rows': [{
                'accountNo': '1349904865101',
                'scheme': 'Franklin India Taxshield - Growth',
                'totalUnits': '219.347',
                'currentCost': '59998.89',
                'currentValue': '92755.57',
                'returns': '20.46%',
                'goal': null
            }, {
                'accountNo': '2389904865101',
                'scheme': 'Franklin India Bluechip Fund - Growth',
                'totalUnits': '0.000',
                'currentCost': '0.00',
                'currentValue': '0.00',
                'returns': '0%',
                'goal': null
            }, {
                'accountNo': '4379904865101',
                'scheme': 'Franklin India Prima Plus - Growth',
                'totalUnits': '66.411',
                'currentCost': '22499.85',
                'currentValue': '29408.34',
                'returns': '16.81%',
                'goal': null
            }],
            'modeofHolding': 'Single',
            'holders': [{
                'name': 'YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'grandTotal': {
                'totalUnits': '285.758',
                'folioId': null,
                'account': 'GRAND TOTAL',
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        },{
            'folioId': '27877097',
            'rows': [{
                'accountNo': '1134990486511',
                'scheme': 'Franklin India Taxshield - Growth',
                'totalUnits': '219.347',
                'currentCost': '59998.89',
                'currentValue': '92755.57',
                'returns': '20.46%',
                'goal': null
            }, {
                'accountNo': '11389904865101',
                'scheme': 'Franklin India Bluechip Fund - Growth',
                'totalUnits': '0.000',
                'currentCost': '0.00',
                'currentValue': '0.00',
                'returns': '0%',
                'goal': null
            }, {
                'accountNo': '11379904865101',
                'scheme': 'Franklin India Prima Plus - Growth',
                'totalUnits': '66.411',
                'currentCost': '22499.85',
                'currentValue': '29408.34',
                'returns': '16.81%',
                'goal': null
            }],
            'modeofHolding': 'Married',
            'holders': [{
                'name': 'JASMINE POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED',
                'pan': 'CNJQL2964N',
                'kycStatus': 'KYC - Registered',
                'kycSource': null,
                'modeOfKyc': null,
                'aadharNo': null,
                'balAmount': null,
                'type': 'Firstholder'
            }],
            'grandTotal': {
                'totalUnits': '285.758',
                'folioId': null,
                'account': 'GRAND TOTAL',
                'currentValue': '122163.91',
                'currentCost': '82498.74'
            }
        }]
    };
    var panNumber = 'CNJQL2964N';
    var statusTemplate = '<div uib-popover-template="\'folioViewTemplate.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
            '<script type="text/ng-template" id="folioViewTemplate.html">' +
            '<div><button type="button" ng-click="grid.appScope.$emit(\'showFolioView\', COL_FIELD)" class="btn panel-orange-btn m0">Account Statement</button></div></script>';
    var accessLevelTemplate = '<div class="fti-returns">Access Level<span uib-popover-template="\'accessLevelTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti_Info"></span></div>' +
            '<script type="text/ng-template" id="accessLevelTemplate.html">' +
            '<div class="overview-tool-tip">You can execute online transactions only if you have transact access in a given folio. ‘View’ access is provided for joint mode of investments or non-individual investments or for certain non-active folios. For queries, please email us at service@franklintempleton.com</div></script>';
    var returnsTemplate = '<div class="fti-returns">Returns<span uib-popover-template="\'returnsTemplate.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti_Info"></span></div>' +
            '<script type="text/ng-template" id="returnsTemplate.html">' +
            '<div class="overview-tool-tip">Returns basis XIRR i.e., rate of return basis your investments at various time periods in this fund.</div></script>';  
    
    var getCompiledElement = function() {
        var element = angular.element('<ftic-port-folio-details-grid></ftic-port-folio-details-grid>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };
    
    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.inject(function(_panViewModel_) {
            panView = _panViewModel_; 

            panView.setPanViewDtls({
                'portfolioDetails': panViewData.portfolioDetails,
                'investmentSummary': panViewData.investmentSummary
            })
        })

    });

    beforeEach(function() {
        angular.mock.inject(function(_$compile_, _$rootScope_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            scope = rootScope.$new();
        })

        directiveElem = getCompiledElement();
        isolatedScope = directiveElem.isolateScope();
    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should create a separate isolated scope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should have status and returns tempalte and accessLevelTemplate in columnDefs', function() {
        expect(isolatedScope.columnDefs).toBeDefined();
        expect(isolatedScope.columnDefs[0].cellTemplate).toBe(statusTemplate);
        expect(isolatedScope.columnDefs[5].headerCellTemplate).toBe(accessLevelTemplate);
        expect(isolatedScope.columnDefs[6].headerCellTemplate).toBe(returnsTemplate);
    });

    it('should be isolatedScope data rendered in template', function() {
        expect(isolatedScope.gridData).toBeDefined();
        expect(isolatedScope.gridData[0].folioNumber).toBeDefined();
        expect(isolatedScope.gridData[0].CurrentCost).toBeDefined();
        expect(isolatedScope.gridData[0].CurrentValue).toBeDefined();
    });

    it('should expect panNumber to be defined and have value', function() {
        expect(isolatedScope.panNumber).toBeDefined();
        expect(isolatedScope.panNumber).toEqual(panNumber);
    });
});