/**
*@ngdoc object
*@name common.module:interceptors
*@description
* <p>
* In this we have global configuaration of interceptors
* </p> 
*/

module.exports = angular.module('common.interceptors', [])
    .factory('errorInterceptor', require('./errorInterceptor'));