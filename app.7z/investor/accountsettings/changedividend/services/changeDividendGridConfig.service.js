/**
 * @ngdoc service
 * @name transactions Grid Config Model
 * @requires mytransactionsConstants
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';

var changeDividendGridConfigModel = function (investorEventConstants) {

    var _gridConfig = {};
    var options = [{title:'Payout'},{title:'Re-investment'}];
    var selectedValue = 'Payout';

   
   var changeDividendDropdown ="<div class='change-dividend-filter' ng-if='row.entity.dividendOption' ng-init='selectedOpt={title:row.entity.dividendOption, load: true}'><ftic-section-filter ng-if='selectedOpt.title'  selected='selectedOpt' section-options=[{title:'Payout',accountNo:row.entity.accountNo,folioNo:row.entity.folioNo},{title:'Reinvestment',accountNo:row.entity.accountNo,folioNo:row.entity.folioNo}] event-name='dividendChangeOptionEvent'></ftic-section-filter></div>";
   //var changeDividendDropdown ="<div class='change-dividend-grid-template' ng-init='selectedOpt={title:row.entity.dividendOption}'><select class='pull-left form-control' ng-if='selectedOpt.title' ng-modle='row.entity.dividendOption'><option value='payout'>payout</option><option value='reinvestment'>reinvestment</option></select></div>";
   
   

    _gridConfig.dividendDetails = function(){
        return [
            //{ field: 'dividendOption', displayName: '', cellTemplate: changeDividendDropdown, width: "250", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'dividendOption', displayName: 'dividend Option', cellTemplate: changeDividendDropdown, width: "200", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false, pinnedLeft:true},
            { field: 'fundName', displayName: 'Fund Name', width: "250", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'accountNo', displayName: 'Account No', width: "160", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'folioNo', displayName: 'Folio Number', width: "140", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false},
            { field: 'currentValue', displayName: 'Current Value', width: "150", headerCellClass: 'fti-grid-sortDisabledHeader', enableSorting:false}
        ]
    }
    
    var changeDividendGridConfigModel = {
        gridConfig: _gridConfig
    };
    return changeDividendGridConfigModel;
};

changeDividendGridConfigModel.$inject = ['investorEventConstants'];

module.exports = changeDividendGridConfigModel;