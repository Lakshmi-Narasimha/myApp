/**
 * @ngdoc property
 * @name SIP Calculator Controller
 * @requires $scope
 * @requires $state
 * @requires constants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function sipCalculatorController($scope, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel, calculatorsEventConstants, $state) {
    $scope.init = function () {
        $scope.$emit("setBreadCrumb",{
          cat : "funds",
          subcat : "tools",
          breadCrumb :{
            label:'SIP Calculator',
            state : ''
          }   
        });
        if($state.current && $state.current.data && $state.current.data.isAdvisor) {
          $scope.isAdvisor = $state.current.data.isAdvisor;
        };
        sipCalculatorInitialService.loadAllServices($scope);
    };

    $scope.init();

    $scope.selectOptions = {
      "Fund" : [],
      "Frequency" : []
    };

    $scope.$on(calculatorsEventConstants.FUND_DETAILS, function(event, data){
      $scope.selectOptions.Fund.push({"title":"Select Fund", "category" : ""});  
      var fundlist = sipCalculatorModel.getFundDetails().codeValueList;
      for(var fd=0, len=fundlist.length;fd<len;fd++) {
        $scope.selectOptions.Fund.push({
          "title" : fundlist[fd].value,
          "category" :  fundlist[fd].code
        })    
      }
    });
    $scope.selectOptions.Frequency = [
            {
              title:"Select Frequency"   
            },
            {
              title:"Monthly"   
            },
            {
              title: "Quarterly"
            }
          ]; 
    
    
    $scope.inputObject = {
    	Fund :{
	     	required:true,
	     	name : "fundSelection",
	     	label: "Select Fund",
        disable:false
     	},
     	Frequency :{
	     	required:true,
	     	name : "freqSelection",
	     	label: "Select Frequency"
     	}
     };


    $scope.userInput= { 
    	Amount: {
		    		key: "", 
		            text: "Investment Amount <span class='icon-fti_rupee'></span>",
		            value: "",
		            pattern:/^[0-9]*$/,
		            message: "",
		            isMasked: false,
		            isRequired: true,
                type: "number"
		    			},
    	Tenure : {
		    		key: "", 
		            text: "Investment Tenure",
		            value: "",
		            pattern:/^[0-9]*$/,
		            message: "",
		            isMasked: false,
		            isRequired: true ,
                type: "number"		              
    			},
    	Annual : {
					key: "", 
                  	text: "Enter Annualized Returns",
                  	value: "",
                  	pattern:/^[0-9]*$/,
                  	message: "",
                  	isMasked: false,
                  	isRequired: false,
                 	  maxlength: 6,
                    disable:true,
                    type: "number"
    	}
    };


    $scope.$on(calculatorsEventConstants.SIP_FUND_SUBMIT,function(event, calculatorReq) {
      console.log(calculatorReq);
      sipCalculatorModel.callSipCalculatorData({"calculatorReq" : calculatorReq},$scope.isAdvisor).then(function (data) {
        sipCalculatorModel.setSipCalculations(data.calculatorResp);
        $scope.$broadcast(calculatorsEventConstants.FUND_DETAILS_CHART);
      }, function (data) {
        console.log("ERROR")
      });
    });
   
   $scope.$on(calculatorsEventConstants.SIP_RESET_DATA, function(event) {
    $scope.$broadcast(calculatorsEventConstants.RESET_DATA);
  }); 
    
}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
sipCalculatorController.$inject = ['$scope', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsEventConstants', '$state'];
module.exports = sipCalculatorController;