'use strict';

function smartSolutionsRoutes($stateProvider) {

    var smartsolutions = {
        parent: 'home',
        name: 'smartSol', // state name
        url: 'smartsol', // url path that activates this state
        abstract: true,
        views: {
            'dashboard@home': {
                template: require('./smartsolutions.html'),
                controller: 'smartSolutionsCtrl'
            }
        }
    };

    // plan smart solution 
    var planSmartSolutions = {
        parent: 'smartSol',
        abstract: true,
        name: 'smartSol.planSmartSolution', // state name
        url: '/planSmartSolution', // url path that activates this state
        views: {
            'smartSolnView': {
                template: require('./planSmartSolution/planSmartSolution.html'),
                controller: 'planSmartSolutionController'
            }
        }
    };


    /**
     * Proceed to Buy Flow - Start
     */

    var invProceedToBuy = {
        parent: 'smartSol.planSmartSolution',
        name: 'smartSol.planSmartSolution.invProceedToBuy', // state name
        abstract: true,
        url: '/invProceedToBuy', // url path that activates this state
        views: {
            'planSmartSolnView': {
                template: require('./invproceedtobuy/invProceedToBuy.html'),
                controller: 'InvProceedToBuyController'
            }
        }
    };

    var invPBInvestmentPref = {
        parent: 'smartSol.planSmartSolution.invProceedToBuy',
        name: 'smartSol.planSmartSolution.invProceedToBuy.invPBInvestmentPref', // state name
        url: '/invProceedToBuy/investmentPref', // url path that activates this state
        views: {
            'ptb_main': {
                template: require('./invproceedtobuy/investmentpreference/investmentPreference.html'),
                controller: 'InvInvestmentPrefController'
            }
        }
    };

    var invPBFundDetails = {
        parent: 'smartSol.planSmartSolution.invProceedToBuy',
        name: 'smartSol.planSmartSolution.invProceedToBuy.invPBFundDetails', // state name
        url: '/invProceedToBuy/fundDetails', // url path that activates this state
        views: {
            'ptb_main': {
                template: require('./invproceedtobuy/invfunddetails/invFundDetails.html'),
                controller: 'InvFundDetailsController'
            },
            'lumpsumView@smartSol.planSmartSolution.invProceedToBuy.invPBFundDetails': {
                template: require('../../common/proceedtobuy/funddetails/lumpsuminvestment/lumpsuminvestment.html'),
                controller: 'FundDetailsLumpsumController'
            },
            'sipView@smartSol.planSmartSolution.invProceedToBuy.invPBFundDetails': {
                template: require('../../common/proceedtobuy/funddetails/sipinvestment/sipinvestment.html'),
                controller: 'FundDetailsSipController'
            }
        }
    };

    var invPBPaymentDetails = {
        parent: 'smartSol.planSmartSolution.invProceedToBuy',
        name: 'smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS', // state name
        url: '/paymentdetailsSS', // url path that activates this state
        params: {
            key: null
        },
        views: {
            'ptb_main': {
                template: require('./invproceedtobuy/invpaymentdetails/invPaymentDetails.html'),
                controller: 'InvPaymentDetailsController'
            },
            'lumpsumView@smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS': {
                template: require('../../common/proceedtobuy/paymentdetails/payment1/lumpsumInvestment.html'),
                controller: 'payment1Controller'
            },
            'sipView@smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS': {
                template: require('../../common/proceedtobuy/paymentdetails/payment2/sipInvestment.html'),
                controller: 'payment2Controller'
            }
        }
    };

    var invPBReviewConfirmDetails = {
        parent: 'smartSol.planSmartSolution.invProceedToBuy',
        name: 'smartSol.planSmartSolution.invProceedToBuy.reviewnconfirm', // state name
        url: '/reviewnconfirm', // url path that activates this state
        views: {
            'ptb_main': {
                template: require('./invproceedtobuy/invreviewnconfirm/invReviewNConfirm.html'),
                controller: 'InvReviewNConfirmController'
            },
            'lumpsumView@smartSol.planSmartSolution.invProceedToBuy.reviewnconfirm': {
                template: require('../../common/proceedtobuy/reviewnconfirm/lumpsum/reviewLumpsum.html'),
                controller: 'reviewLumpsumController'
            },
            'sipView@smartSol.planSmartSolution.invProceedToBuy.reviewnconfirm': {
                template: require('../../common/proceedtobuy/reviewnconfirm/sip/reviewSip.html'),
                controller: 'reviewSipController'
            }
        }
    };

    /**
     * Proceed to Buy Flow - End
     */
    // select smart solution 
    var selectSmartSolutions = {
        parent: 'smartSol.planSmartSolution',
        name: 'smartSol.planSmartSolution.selectSS', // state name
        url: '/selectSmartSolution', // url path that activates this state
        views: {
            'planSmartSolnView': {
                template: require('./planSmartSolution/selectSmartSolutions/selectSmartSolution.html'),
                controller: 'selectSmartSolutionController'
            }

        }
    };

    //smartSol.planSmartSolution.ssBase.planInputDetails
    var smartSolSelectFolio = {
        parent: 'smartSol.planSmartSolution',
        name: 'smartSol.planSmartSolution.selectFolio', // state name
        url: '/smartSolSelectFolio', // url path that activates this state
        views: {
            'planSmartSolnView': {
                template: require('./planSmartSolution/smartSolSelectFolio/smartSolSelectFolio.html'),
                controller: 'smartSolSelectFolio'
            }

        }
    };

    var planSmartSolutionsBase = {
        parent: 'smartSol.planSmartSolution',
        name: 'smartSol.planSmartSolution.ssBase', // state name
        url: '/planSmartSolBase', // url path that activates this state
        views: {
            'planSmartSolnView': {
                template: require('./planSmartSolution/planSmartSolutionsBase/planSmartSolutionBase.html'),
                controller: 'planSmartSolutionBaseController'
            }
        }
    };

    var planInputDetails = {
        parent: 'smartSol.planSmartSolution.ssBase',
        name: 'smartSol.planSmartSolution.ssBase.planInputDetails', // state name
        url: '/planInputDetails', // url path that activates this state
        views: {            
            'planSmartSolBaseView': {
                template: require('./planSmartSolution/planSmartSolutionsBase/planInputDetails/planInputDetails.html'),
                controller: 'planInputDetailsController'
            }
        }
    };

    // Recommendations
    var recommendationsState = {
        parent: 'smartSol.planSmartSolution.ssBase',
        name: 'smartSol.planSmartSolution.ssBase.recommendations', // state name
        url: '/recommendations', // url path that activates this state
        views: {
            'planSmartSolBaseView': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendations.html'),
                controller: 'recommendationsCntrl'
            }
        }
    };
     var recommendePlanState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.recommendedplan', // state name
        url: '/recommendedplan', // url path that activates this state
        views: {
            'recommendedplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendedplan/recommendedplan.html'),
                controller: 'recommendedplanCtrl'
            }
        }
    }; 
    var recommendePlanCustomizeState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rcustomizePlan', // state name
        url: '/rcustomizePlan', // url path that activates this state
        views: {
            'recommendedplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendedplan/customize/customize.html'),
                controller: 'customizeCtrl'
            }
        }
    };

    var recommendedPlanMyCustomState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.recommendedplan.rmycustomplan', // state name
        url: '/rmycustomplan', // url path that activates this state
        views: {
            'recommendedplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/customizedplan/customizedPlan.html'),
                controller: 'customizedPlanController'
            }
        }
    };

    var buildPlanMyCustomState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.buildplan.bmycustomizeplan', // state name
        url: '/bmycustomizeplan', // url path that activates this state
        views: {
            'buildplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/customizedplan/customizedPlan.html'),
                controller: 'customizedPlanController'
            }
        }
    };

    var buildPlanState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.buildplan', // state name
        url: '/buildplan', // url path that activates this state
        views: {
            'buildplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/buildmyplan/buidmyplan.html'),
                controller: 'buildmyplanCtrl'
            }
        }
    }; 

    var buildPlanCustomizeState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.buildplan.bcustomizeplan', // state name
        url: '/bcustomizeplan', // url path that activates this state
        views: {
            'buildplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendedplan/customize/customize.html'),
                controller: 'customizeCtrl'
            }
        }
    };

    var buildPlanShowDtlsState = {
        parent: 'smartSol.planSmartSolution.ssBase.recommendations',
        name: 'smartSol.planSmartSolution.ssBase.recommendations.buildplan.buildplanshowdtls', // state name
        url: '/buildplanshowdtls', // url path that activates this state
        views: {
            'buildplan': {
                template: require('./planSmartSolution/planSmartSolutionsBase/recommendations/buildmyplan/components/smartSolBuildPlanShowDtls/smartSolBuildPlanShowDtls.html'),
                controller: 'buildmyplanshowdtlsCtrl'
            }
        }
    };
      //  // GoalSheetSummary
    var goalSheetSummaryState = {
        parent: 'smartSol.planSmartSolution.ssBase',
        name: 'smartSol.planSmartSolution.ssBase.goalSheetSummary', // state name
        url: '/goalSheetSummary', // url path that activates this state
        views: {
            'planSmartSolBaseView': {
                template: require('./planSmartSolution/planSmartSolutionsBase/goalsheetsummary/goalSheetSummary.html'),
                controller: 'goalSheetSummaryController'
            }
        }
    }; 

    var smartsolsaved = {
        parent: 'smartSol',
        name: 'smartSol.saved', // state name
        url: '/saved', // url path that activates this state
        views: {
            'smartSolnView': {
                template: require('./savedSmartSolutions/savedSmartSolutions.html'),
                controller: 'savedSmartSolutionsController'
            }
        }
    };

    var smartSolNewFolio = {
        parent: 'smartSol.planSmartSolution',
        name: 'smartSol.planSmartSolution.newFolioNnewInvestor',
        url: '/newFolioNnewInvestor',
        views: {
            'planSmartSolnView': {
                template: require('../../common/transact/newFolioNNewInvestor/newFolioNnewInvestor.html'),
                controller: 'newFolioNnewInvestorCtrl'
            }
        }
    };


    var newFolioEkycForm = {
        parent: 'smartSol.planSmartSolution',
        name: 'smartSol.planSmartSolution.newFolioNnewInvestor.ekyc', // state name
        url: '/ssEkycForm', // url path that activates this state
        views: {
            'planSmartSolnView': {
                template: require('./planSmartSolution/ekycRegForm/ekycRegister.html'),
                controller: 'SsEkycRegstrController'
            }
        }
    };

    
    var trackmygoals = {
        parent: 'smartSol',
        name: 'smartSol.trackmygoals', // state name
        url: '/trackmygoals', // url path that activates this state
        views: {
            'dashboard@home': {
                controller: 'TrackMyGoalsController',
                template: require('./trackmygoals/trackmygoals.html')
            }
        }
    };
    // Investor Goal tracking views

   var smartsolinvestorcp = {
        parent: 'smartSol.trackmygoals',
        name: 'smartSol.trackmygoals.cp', // state name
        url: '/currentpd', // url path that activates this state
        views: {
            'investorGoalViews': {
                template: require('./trackmygoals/currentpd/currentPD.html'),
                controller: 'smartSolsCurrentPdCtrl'
            }
        }
    };



    var smartsolinvestortopupwithsf = {
        parent: 'smartSol.trackmygoals',
        name: 'smartSol.trackmygoals.topupwithsf', // state name
        url: '/topupwithsf', // url path that activates this state
        views: {
            'investorGoalViews': {
                template: require('./trackmygoals/topupwithsf/topupwithsf.html'),
                controller: 'smartSolsTopupWithSfCtrl'
            }
        }
    };
     
    var smartsolinvestortopupwithsamefunds = {
        parent: 'smartSol.trackmygoals.topupwithsf',
        name: 'smartSol.trackmygoals.topupwithsf.topupwithsamefunds', // state name
        url: '/topupwithsamefunds', // url path that activates this state
        views: {
            'topUpWithSameFundsView': {
                template: require('./trackmygoals/topupwithsf/topupwithsamefunds/topupWithSameFunds.html'),
                controller: 'smartSolsTopupWithSameFundsCtrl'
            }
        }
    };
    var smartsolinvestortopupwithsamefundsgoalsheet = {
        parent: 'smartSol.trackmygoals.topupwithsf',
        name: 'smartSol.trackmygoals.topupwithsf.topupwithsamefundsgoalsheet', // state name
        url: '/topupwithsamefundsgoalsheet', // url path that activates this state
        views: {
            'topUpWithSameFundsView': {
                template: require('./trackmygoals/topupwithsf/topupwithsamefundsgoalsheet/topupWithSameFundsGoalSheet.html'),
                controller: 'smartSolsTopupWithSameFundsGoalSheetCtrl'
            }
        }
    };

    var smartsolinvestortopupwithftrf = {
        parent: 'smartSol.trackmygoals',
        name: 'smartSol.trackmygoals.topupwithftrf', // state name
        url: '/topupwithftrf', // url path that activates this state
        views: {
            'investorGoalViews': {
                template: require('./trackmygoals/topupwithftrf/topupWithFtRF.html'),
                controller: 'smartSolsTopupWithFTRFCtrl'
            }
        }
    };

    
    var smartsolinvestortopupwithftrecommendedfunds = {
        parent: 'smartSol.trackmygoals.topupwithftrf',
        name: 'smartSol.trackmygoals.topupwithftrf.topupwithftrecommendedfunds', // state name
        url: '/topupwithftrecommendedfunds', // url path that activates this state
        views: {
            'topUpWithFtRecommendedFundsView': {
                template: require('./trackmygoals/topupwithftrf/topupwithftrecommendedfunds/topupWithFtRecommendedFunds.html'),
                controller: 'smartSolsTopupWithFtRecommendedFundsCtrl'
            }
        }
    };
    
    var smartsolinvestortopupwithftrecommendedfundsgoalsheet = {
        parent: 'smartSol.trackmygoals.topupwithftrf',
        name: 'smartSol.trackmygoals.topupwithftrf.topupwithftrecommendedfundsgoalsheet', // state name
        url: '/topupwithftrecommendedfundsgoalsheet', // url path that activates this state
        views: {
            'topUpWithFtRecommendedFundsView': {
                template: require('./trackmygoals/topupwithftrf/topupwithftrecommendedfundsgoalsheet/topupWithFtRecommendedFundsGoalSheet.html'),
                controller: 'smartSolsTopupWithFtRecommendedFundsGoalSheetCtrl'
            }
        }
    };

    var smartsolinvestortopupwithftrecommendedfundsor = {
        parent: 'smartSol.investor.topupwithftrf.topupwithftrecommendedfunds',
        name: 'smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.or', // state name
        url: '/topupwithftrecommendedfundsor', // url path that activates this state
        views: {
            'topUpWFTRFView': {
                template: require('./investorgoaltracking/topupwithftrf/topupwithftrecommendedfunds/originalrecommendation/originalRecommendation.html'),
                controller: 'smartSolsTopupWithFtRecommendedFundsORCtrl'
            }
        }
    };
    var smartsolinvestortopupwithftrecommendedfundsar = {
        parent: 'smartSol.investor.topupwithftrf.topupwithftrecommendedfunds',
        name: 'smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.ar', // state name
        url: '/topupwithftrecommendedfundsar', // url path that activates this state
        views: {
            'topUpWFTRFView': {
                template: require('./investorgoaltracking/topupwithftrf/topupwithftrecommendedfunds/anotherrecommendation/anotherRecommendation.html'),
                controller: 'smartSolsTopupWithFtRecommendedFundsARCtrl'
            }
        }
    };
    
    var smartsolinvestormodifymain = {
        parent: 'smartSol.trackmygoals',
        name: 'smartSol.trackmygoals.modifymain', // state name
        url: '/modifymain', // url path that activates this state
        views: {
            'investorGoalViews': {
                template: require('./trackmygoals/modifymain/modifyMain.html'),
                controller: 'smartSolsModifyMainCtrl'
            }
        }
    };
    var smartsolinvestormodify = {
        parent: 'smartSol.investor.modifymain',
        name: 'smartSol.investor.modifymain.modify', // state name
        url: '/modify', // url path that activates this state
        views: {
            'modifyView': {
                template: require('./investorgoaltracking/modifymain/modify/modify.html'),
                controller: 'smartSolsModifyCtrl'
            }
        }
    };
    var smartsolinvestormodifyapply = {
        parent: 'smartSol.investor.modifymain',
        name: 'smartSol.investor.modifymain.modifyapply', // state name
        url: '/modifyapply', // url path that activates this state
        views: {
            'modifyView': {
                template: require('./investorgoaltracking/modifymain/modifyapply/modifyApply.html'),
                controller: 'smartSolsModifyApplyCtrl'
            }
        }
    };
    var smartsolinvestormodifygoalsheet = {
        parent: 'smartSol.investor.modifymain',
        name: 'smartSol.investor.modifymain.modifygoalsheet', // state name
        url: '/modifygoalsheet', // url path that activates this state
        views: {
            'modifyView': {
                template: require('./investorgoaltracking/modifymain/modifygoalsheet/modifyGoalSheet.html'),
                controller: 'smartSolsModifyGoalSheetCtrl'
            }
        }
    };



    $stateProvider
        .state(smartsolutions)
        .state(planSmartSolutions)
        .state(selectSmartSolutions)
        .state(smartsolsaved)
        .state(smartSolSelectFolio)
        .state(planSmartSolutionsBase)
        .state(planInputDetails)
        .state(invProceedToBuy)
        .state(invPBInvestmentPref)
        .state(invPBFundDetails)
        .state(invPBPaymentDetails)
        .state(invPBReviewConfirmDetails)
        .state(recommendationsState)
        .state(recommendePlanState)
        .state(recommendePlanCustomizeState)
        .state(recommendedPlanMyCustomState)
        .state(buildPlanMyCustomState)
        .state(buildPlanState)
        .state(buildPlanCustomizeState)
        .state(buildPlanShowDtlsState)
        .state(goalSheetSummaryState)
        .state(smartSolNewFolio)
        .state(newFolioEkycForm)
        .state(trackmygoals)
        .state(smartsolinvestorcp)
        .state(smartsolinvestortopupwithsf)
        .state(smartsolinvestortopupwithsamefunds)
        .state(smartsolinvestortopupwithsamefundsgoalsheet)
        .state(smartsolinvestortopupwithftrf)
        .state(smartsolinvestortopupwithftrecommendedfunds)
        .state(smartsolinvestortopupwithftrecommendedfundsgoalsheet)

        ;
}

smartSolutionsRoutes.$inject = ['$stateProvider'];
module.exports = smartSolutionsRoutes;
