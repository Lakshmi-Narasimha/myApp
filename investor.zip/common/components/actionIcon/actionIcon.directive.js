/**
 * @ngdoc directive
 * @name fticactionIcon
 * @requires $state
 * @requires $window
 * @description
 *
 * - fticactionIcon will be place icon to edit the field.
 * 
 *
 **/
 'use strict';

var actionIcon = function($state, $window, eventConstants) {
	return {
            template: require('./actionIcon.html'),
            restrict: 'E',
            replace: true,
            scope: {
                actionClass: "@"
            },
            controller: function($scope, $element, $attrs){ 
                $scope.isClickedOnce = false;
                $scope.onIconClick =  function($event){
                    $scope.$emit(eventConstants.ACTION_ICON_CLICKED, $element);
                };
            },
            link: function(scope, iElement, iAttrs, controller){
            }
        };
};

actionIcon.$inject = ['$state', '$window', 'eventConstants'];
module.exports = actionIcon;