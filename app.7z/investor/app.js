/**
*@ngdoc object
*@name FTIC
*@description
*<p>
* Application entry point, organize, initialize, inject dependencies
* and coordinates the various pieces of application.Loads sub modules
* and wire them up into the main module. Act as container
* for all angular managed objects or modules
* It includes the modules like advisor, investor and guest.
* </p>
*/

'use strict';
// window.jQuery = window.$ = require('jquery');
// require('jquery-ui');
var angular = require('angular');
module.exports = angular.module('investor',
    [
        require('../common/common.js').name,
        require('./dashboard').name,
        require('./events').name,
        require('./constants').name,
        require('./components').name,
        require('./filters').name,
        require('./myportfolio').name,
        require('./eforms').name,
        require('./services').name,
        require('./myprofile').name,
        require('./transactionhistory').name,
        require('./accountsettings').name,
        require('./transact').name,
        require('./smartsolutions').name
        // require('./advisor').name,
        /*require('./investor').name,
        require('./guest').name*/

    ])
    // .provider('fticLogger', require('../common/services/fticLogger.js'))    
    .config(require('./appConfig'))
    // .constant('version', require('../../package.json').version)
    .run(require('../common/commonInit.js'))
    .controller('InvestorController', require('./investor.controller'));