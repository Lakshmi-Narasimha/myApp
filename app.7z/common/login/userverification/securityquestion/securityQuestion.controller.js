
 function securityQuestionController($scope,$state,advisorRegistrationModelService,toaster){
 	$scope.formData={};
  $scope.errorMessage = "";
  $scope.wrongAnswer = false;
  $scope.submitQuestion =  function (){
        $scope.$broadcast('submitSecurityQuestion');
       var postObj = { 
        guId : advisorRegistrationModelService.getUserData().guId,
        answer: advisorRegistrationModelService.getSecurityAnsData()
       }
       

        if($scope.secuirtySubmitForm.$valid){
              var postSuccess = function (data) {
                $scope.wrongAnswer = false;
                  if(advisorRegistrationModelService.getUserForgotTypeDetails() === 'password'){
                     $state.go('loginmaster.newpassword');
                  }else{
                    advisorRegistrationModelService.postAcknowledgeCall(advisorRegistrationModelService.getUserData().guId);
                    $state.go('loginmaster.thankyou');
                  }
               }; 
              var handleFailure = function (errorResp){ 
                $scope.wrongAnswer = true;
                 //toaster.error(errorResp.data[0].errorDescription);
                 $scope.errorMessage = "Sorry! Your Secret Answer is incorrect, Please try again";
                 //toaster.error("Sorry! Your Secret Answer is incorrect, Please try again");

               };
              advisorRegistrationModelService.postAnsForSecurityQn(postObj).then(postSuccess, handleFailure);
        }
  } 
}
securityQuestionController.$inject = ['$scope','$state','advisorRegistrationModelService','toaster'];
module.exports = securityQuestionController;