/**
 * @ngdoc service
 * @name SIP Calculator Initial Loader
 * @description
 *
 * - Handles the services and model for calculators content details
 *
 */
 'use strict';

 var taxCalculatorInitialService = function(fticLoggerMessage, loggerConstants, $cookies, taxCalculatorModel, sipCalculatorModel) {
    var taxCalculatorInitialService = {
        _isServicesData: false, 
        loadAllServices : function (scope) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.DASHBOARD_MODULE + ' | ' + loggerConstants.DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            sipCalculatorModel.callFundDetailsData(scope.isAdvisor)
            .then(fundDetailsSuccess, promiseFailure)

            function fundDetailsSuccess (data) {
                sipCalculatorModel.setFundDetails(data);
                scope.$broadcast("fundDetails");
            }
            
            function promiseFailure () {
                var fund = {"fundDetails": [{
                    "fundName": "Franklin India BlueChip Fund",
                    "fundId": "FT0001"
                }, {
                    "fundName": "Franklin India Prima Plus",
                    "fundId": "FT0002"
                }]};
                sipCalculatorModel.setFundDetails(fund);
                scope.$broadcast("fundDetails");
                console.log('ERROR promiseFailure')
            }
        }
    }
    return taxCalculatorInitialService;
};

taxCalculatorInitialService.$inject = ['fticLoggerMessage', 'loggerConstants', '$cookies', 'taxCalculatorModel', 'sipCalculatorModel'];
module.exports = taxCalculatorInitialService;
