(function() {
    'use strict';

    require('angular');
    require('angular-route');
    require('angular-animate');
    require('angular-ui-bootstrap');

    var mainCtrl = require('./controllers/mainctrl');
    var liveChatCtrl = require('./controllers/livechatctrl');
    var scrollDownDir = require('./directives/scrolldown.directive');
    var chatServices = require('./services/chatservices');
    var chatUtils = require('./services/chatutilsfactory');
    var compile = require('./directives/compile');

    angular.module('AskVerizonApp', ['ngRoute', 'ngAnimate', 'ui.bootstrap'])
        .config([
            '$locationProvider',
            '$routeProvider',
            function($locationProvider, $routeProvider) {
                $routeProvider
                    .when("/", {
                        templateUrl: "./partials/main.html",
                        controller: "mainCtrl"
                    })
                    .when("/livechat", {
                        templateUrl: "./partials/livechat.html",
                        controller: "liveChatCtrl"
                    })
                    .when("/endchat", {
                        templateUrl: "./partials/enddchat.html",
                    })
                    .otherwise({
                        redirectTo: '/'
                    });
            }
        ])
        //Load controllers
        .controller('mainCtrl', ['$scope', '$window', mainCtrl])
        .controller('liveChatCtrl', ['$scope', '$sce', '$window', '$timeout', 'chatServices', 'chatUtils', liveChatCtrl])

        //Load services
        .service('chatServices', ['$q', '$http', chatServices])
        .factory('chatUtils', ['chatServices', chatUtils])
        //Load directives
        .directive('schrollBottom', [scrollDownDir])
        .directive('compile', ['$compile', compile]);

}());
