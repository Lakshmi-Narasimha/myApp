var logger = require('../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var querystring = require('querystring');
var myCache = require('../../api-server');
var proxy = require('../../config/proxy');
var request = require('request');
var http = require('http');
var https = require('https');
var myCache = require('../../api-server');

var getMessageLPModel = require('../modules/getMessage/getMessageLP.model');
var engagementModel = require('../modules/engagement/engagement.model');

var apiLPUtils = {
    baseURLCall: function(req, res, callback) {        
        
        //var appKeyHeader = "LivePerson appKey=" + config.LP_APP_KEY;
        var reqObj = {
            method: 'GET',
            url: config.LP_SERVER_NAME + config.LP_BASE_URI,
            agent: proxy.agent,
            ca:proxy.ca,            
            headers: {                
                'Content-Type' : 'application/json',
                //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                'Accept' : 'application/json' 
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        request(reqObj,function(error, response, body){
            //logger.general.info(logger.formatInfoMsg(req.session.id, "LP baseUrlCall responsecode: "+ response.statusCode));
            if(error){
                logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));               
                callback();             

            }else if(response.statusCode !== 200){                 
                 logger.error.error(logger.formatResMsg(reqObj, response, req.session.id));
                 callback();
            }else {
                logger.general.info(logger.formatInfoMsg(req.session.id, "LP baseUrlCall response: "+ JSON.stringify(body)));                
                callback(body);
            }
        });
    },

    availabilityCall: function(req, res, callback) {        
        
        //var appKeyHeader = "LivePerson appKey=" + config.LP_APP_KEY;
        var reqObj = {
            method: 'GET',
            url: req.session.chat_availability + '&skill='+ config.LP_SKILL_NAME + config.LP_APP_KEY_PARAM,
            agent: proxy.agent,
            ca:proxy.ca,            
            headers: {                
                'Content-Type' : 'application/json',
                //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                'Accept' : 'application/json' 
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        request(reqObj,function(error, response, body){
            //logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat_availability responsecode: "+ response.statusCode));
            if(error){
                logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));               
                callback();             

            }else if(response.statusCode !== 200){
                 logger.error.error(logger.formatResMsg(reqObj, response, req.session.id));
                 callback();
            }else {
                logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat_availability response: "+ JSON.stringify(body)));                
                callback(body);
            }
        });
    },

     getVATranscript:function(VATranscript){
        var transcript = [];
        for(i=0;i<VATranscript.length;i++){
            transcript.push(VATranscript[i].type + ":" + VATranscript[i].message);
        }        
        return transcript;
    },

    engagementCall: function(req, res, callback) {  
          var post_data = {
                "request": {
                    "skill": config.LP_SKILL_NAME,
                    "preChatLines": {
                        "line" : apiLPUtils.getVATranscript(req.body.RequestParams.VATranscript)
                    },
                    "customVariables": {
                        "customVariable": [
                            {
                            "name": "InitialMessage",
                            "value": req.session.InitialMessage
                            },
                            {
                            "name": "Role: ",
                            "value": req.session.accRole
                            },
                            {
                            "name": "Mobile Number: ",
                            "value": req.session.MDN
                            },
                            {
                            "name": "Greeting Name: ",
                            "value": req.session.nickName
                            }
                        ]
                    }
                }
            }; 
            var reqObj = {
                //method: 'GET',
                url: req.session.chat_request + config.LP_APP_KEY_PARAM,
                agent: proxy.agent,
                ca:proxy.ca,            
                headers: {                
                    'Content-Type' : 'application/json; charset=utf8',
                    //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                    'Accept' : 'application/json' 
                },                
                body: JSON.stringify(post_data)
            };
            logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            request.post(reqObj,function(err,response,body){
                if(err){ 
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
                }else if(response.statusCode !== 201){                    
                    logger.error.error(logger.formatResMsg(reqObj, response, req.session.id));
                    callback();
                }else {
                    logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat_request response: "+ response.headers.location));                
                    callback(response.headers.location);
                }               
            });           
    },

    generateToken: function(req, res, callBackToken) {
        var postBody = { "deviceId": req.session.MDN};
        var reqObj = {
           // host: 'sclmdm03wsi.sdc.vzwcorp.com',
            host: config.UDM_SERVER_NAME,
            //port: '6001',
            port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/saveToken',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatInfoMsg(req.session.id, "generateToken Call Trigerred"));
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    //  logger.access.info(chunk);
                    callBackToken(chunk);
                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    sendCmd: function(req, res, callBackSendCmd, isPersistent) {
        //req.session.udm.isConnected = req.session.udm.isConnected;
        //console.log('UDM::',req.session.udm)
        let persistFlag = (typeof isPersistent  !== 'undefined') ?  isPersistent  : false;
        var postBody = {
            "castType": "multicast",
            "cmd": "DROP_MSG",
            "requestor": req.session.requestor,
            "deviceList": [{
                "deviceId": req.session.MDN
            }],
            "sessionId": req.session.engagementID,
            "data": req.session.getMsgRes,
            "isPersistent": persistFlag
        };
        var reqObj = {
            //host: 'sclmdm03wsi.sdc.vzwcorp.com',
            host: config.UDM_SERVER_NAME,
            //port: '6001',
            port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/sendCommand',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            //console.log("sendCmd:", proxyResponse.statusCode);
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    //console.log(req.session.getMsgRes);
                    //console.log("send commnad chunk", chunk);

                    res.status(200).end();
                    if(req.session.chatClosed){
                        //console.log("End msg", req.session.getMsgRes.ModuleMap.Support.msgList[0].messageList[0].messageText);
                        req.session.destroy(function(){
                            //console.log('SESSION DESTROYED!!!!!');
                        });
                    }

                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },

    formattedGetLPMsg:function(req,res, getMsgCallback){       
        var reqObj = {
            method: 'GET',
            url: '',
            agent: proxy.agent,
            ca:proxy.ca,            
            headers: {                
                'Content-Type' : 'application/json',
                //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                'Accept' : 'application/json' 
            }
        }        
        if(req.session.state !== "chatting"){            
           reqObj.url = req.session.location + '/info?v=1'+ config.LP_APP_KEY_PARAM;
        }else{           
           reqObj.url =  myCache.get(req.session.engagementID+".chatNextMessageUrl");
        }         
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));       
        request(reqObj,function(error, response, body){
             var isChatEnd = false;         
            if(error){ 
                logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
            }else if(response.statusCode !== 200){                
                logger.error.error(logger.formatResMsg(reqObj, response, req.session.id));
                if(response.statusCode === 404){
                    getMsgCallback(true);
                }else{
                    getMsgCallback();
                }
                
            }else {
                logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat response: "+ response.body));                
                //callback(response.headers.location);
                getMessageLPModel.response.ModuleMap.Support.msgList = [];
                req.session.getMsgRes = {};
                var chunk = JSON.parse(response.body);               
                if(chunk && chunk.info && chunk.info.state === 'chatting'){
                    req.session.state = chunk.info.state;                    
                    req.session.agentName = chunk.info.agentName;
                    req.session.agentId = chunk.info.agentId;
                    req.session.customerId = chunk.info.visitorId;                    
                    myCache.set(req.session.engagementID+".chatNextMessageUrl", req.session.location + '/events?v=1'+ config.LP_APP_KEY_PARAM);
                    engagementModel.response.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                    engagementModel.response.Page.customerID = chunk.info.visitorId ; /// storing customerID into the session
                    engagementModel.ResponseInfo.topMessage = "You're chatting with "+ chunk.info.agentName;
                    engagementModel.ResponseInfo.type = "Success";
                    engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                    engagementModel.msgList[0].messageList[0].messageText =  chunk.info.agentName + " joined the conversation";
                    // if(config.SEND_CHAT_HISTORY_FLAG){
                    //                 engagementModel.msgList[0].condition = "showTranscript";
                    //             }else{
                    //                 if((typeof engagementModel.msgList[0].condition)  !== 'undefined'){
                    //                     delete engagementModel.msgList[0].condition;
                    //                 }
                    //             }
                    engagementModel.response.ModuleMap.Support.startMsgId = 9999;
                    engagementModel.response.ModuleMap.Support.msgList = engagementModel.msgList;
                    engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                    req.session.getMsgRes = engagementModel.response;  
                    console.log(req.session.getMsgRes)                                      
                    apiLPUtils.sendCmd(req, res, function(response) {}, true);                                                
                    logger.general.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText + " with EngagementID:" + req.session.engagementID));
                    logger.conversation.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText + " with EngagementID:" + req.session.engagementID));                    
                }else{
                    if(chunk && chunk.events){
                        if(chunk.events.link){
                            let linkArray = chunk.events.link;
                             for(i=0;i<linkArray.length;i++){
                                 if(linkArray[i]['@rel'] === 'next'){
                                    myCache.set(req.session.engagementID+".chatNextMessageUrl", linkArray[i]['@href']+'&v=1'+ config.LP_APP_KEY_PARAM);                                                                      
                                    break;
                                 }
                             }
                        }
                        
                        if(chunk.events.event){
                            var eventArray = chunk.events.event;                            
                            if((Object.prototype.toString(eventArray) === '[object Object]' && eventArray['@type'] ==='state' && eventArray.state ==='ended') 
                                || myCache.get(req.session.engagementID+".closed") === true){
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "LPGet Message loop ended with EngagementID: "+ req.session.engagementID));
                                req.session.getMsgRes = getMessageLPModel.endResponse;
                                req.session.chatClosed = true;
                                apiLPUtils.cleanMFCCache(req.session.engagementID);
                                isChatEnd = true;                                
                            }else if(Object.prototype.toString(eventArray) === '[object Object]' && eventArray['@type'] ==='line' && eventArray.source ==='agent'){                               
                                var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                                getMessageLPModel.response.ModuleMap.Support.startMsgId = msgCount+10000;
                                myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1);
                                myCache.set(req.session.engagementID+".chatTimer", new Date().getTime());                                   
                                let msgText = apiLPUtils.getPlainText(eventArray.text);  
                                let msgObj = {};
                                let msgContent = {};
                                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.session.engagementID + ' LPGet Message: ' + msgText);
                                msgObj.type = 'chat',
                                msgObj.msgId = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10)+9999;//req.session.getMsgCount;
                                msgObj.messageType = 'chatLine',
                                msgObj.sequenceNumberInt = 20000,
                                msgObj.animationDuration = 800,
                                msgObj.messageList = [],
                                msgContent.content = msgText;
                                msgContent.nextmsgId = -1;
                                msgObj.messageList.push(msgContent);                                    
                                getMessageLPModel.response.ModuleMap.Support.msgList.push(msgObj);
                                req.session.getMsgRes = getMessageLPModel.response;
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.response)); 
                            }else{
                                getMessageLPModel.response.ModuleMap.Support.startMsgId = (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0)+10000;
                                let arraySize = 0;                                
                                for(i=0;i<eventArray.length;i++){
                                    if(eventArray[i]['@type']==='line' && eventArray[i].source === 'agent'){
                                        arraySize++; 
                                        var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                                        myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1);
                                        myCache.set(req.session.engagementID+".chatTimer", new Date().getTime());                                   
                                        let msgText = apiLPUtils.getPlainText(eventArray[i].text);  
                                        let msgObj = {};
                                        let msgContent = {};
                                        logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.session.engagementID + ' LPGet Message: ' + msgText);
                                        msgObj.type = 'chat',
                                        msgObj.msgId = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10)+9999;//req.session.getMsgCount;
                                        msgObj.messageType = 'chatLine',
                                        msgObj.sequenceNumberInt = 20000,
                                        msgObj.animationDuration = 800,
                                        msgObj.messageList = [],
                                        msgContent.content = msgText;
                                        msgContent.nextmsgId = msgObj.msgId + 1;
                                        msgObj.messageList.push(msgContent);                                    
                                        getMessageLPModel.response.ModuleMap.Support.msgList.push(msgObj);
                                        req.session.getMsgRes = getMessageLPModel.response;
                                        logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.response));                                    
                                    }else if(eventArray[i]['@type'] ==='state' && eventArray[i].state ==='ended'){
                                        req.session.getMsgRes = getMessageLPModel.endResponse;
                                        logger.conversation.info(logger.formatInfoMsg(req.session.id, "LPGet Message loop ended with EngagementID: "+ req.session.engagementID));
                                        req.session.chatClosed = true;
                                        apiLPUtils.cleanMFCCache(req.session.engagementID);
                                        isChatEnd = true;                                       
                                        break;
                                    }
                                }
                                if(arraySize>=1){
                                    getMessageLPModel.response.ModuleMap.Support.msgList[arraySize-1].messageList[0].nextmsgId = -1;
                                }                                
                            } 
                            if(Object.keys(req.session.getMsgRes).length){                                
                                apiLPUtils.sendCmd(req, res, function(response) {}, true); 
                            }                      
                        }else{
                            if(myCache.get(req.session.engagementID+".chatTimer")){
                                var lastMsg = myCache.get(req.session.engagementID+".chatTimer");
                                console.log("Timeout time: "+ (new Date().getTime()-lastMsg));
                                if((new Date().getTime()-lastMsg)>10*1000*60){
                                    //myCache.set(req.session.engagementID+".timeout", 'true');
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID due to timeout: "+ req.session.engagementID));
                                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID due to timeout: "+ req.session.engagementID));
                                    req.session.getMsgRes = getMessageLPModel.timeoutResponse;                                   
                                    apiLPUtils.sendCmd(req, res, function(response) {}, true);  
                                    apiLPUtils.cleanMFCCache(req.session.engagementID);
                                    logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.timeoutResponse));
                                    isChatEnd = true;
                                }else{
                                    logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.emptyResponse));
                                    isChatEnd = false;
                                }
                            }else{
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageLPModel.emptyResponse));
                                isChatEnd = false;
                            }
                        }
                    }
                }
                getMsgCallback(isChatEnd);
               
            }  
        }); 
        
    },

    getPlainText: function(htmlText){
        //console.log(htmlText);
        let plainText = "";
        let indexFront = htmlText.indexOf('>');
        let indexBack = htmlText.indexOf('</div>');
        if(indexBack==-1)
            return htmlText;
        else{
            plainText = htmlText.substring(indexFront+1, indexBack);        
            return plainText;
        }        
    },

    cleanMFCCache(engagementID){
        myCache.del(engagementID+".chatGetMsgCounter");  
        myCache.del(engagementID+".chatSendMsgCounter");      
        myCache.del(engagementID+".closed");
        myCache.del(engagementID+".isRecurEnabled");        
        myCache.del(engagementID+".chatTimer");        
        myCache.del(engagementID+".mqtt");
    },

    getLPMsg:function(req,res, getMsgCallback){       
        var reqObj = {
            method: 'GET',
            url: '',
            agent: proxy.agent,
            ca:proxy.ca,            
            headers: {                
                'Content-Type' : 'application/json',
                //'Authorization' : 'LivePerson appKey=f0dea91cd8974dcfbdb10cb4b29ac8b3',
                'Accept' : 'application/json' 
            }
        }        
        if(req.session.state !== "chatting"){            
           reqObj.url = req.session.location + '/info?v=1'+ config.LP_APP_KEY_PARAM;reqObj.url = req.session.location + '/info?v=1'+ config.LP_APP_KEY_PARAM;
        }else{           
           reqObj.url =  myCache.get(req.session.engagementID+".chatNextMessageUrl");
        }         
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));       
        request(reqObj,function(error, response, body){                    
            if(error){ 
                logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
                getMsgCallback();
            }else if(response.statusCode !== 200){                
                logger.error.error(logger.formatResMsg(reqObj, response, req.session.id));
                getMsgCallback();
            }else {
                logger.general.info(logger.formatInfoMsg(req.session.id, "LP chat response: "+ response.body));
                setTimeout(function () {
                     getMsgCallback(response.body);
                }, 5000);                
                             
            }  
        }); 
        
    }

};

module.exports = apiLPUtils;

