/**
 * @ngdoc factory
 * @name selectFundGrid factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var redeemReviewDetailsFactory = function(authenticationService) {

    var redeemReviewDetailsFactory = {
        getCurrentToState: function() {
            if (this.isLoggedInvestor()) {
                return 'invTransact.base.redeem';
            } else {
                return 'transact.base.redeem';
            }
        },
        getCurrentTxnToState: function() {
            if (this.isLoggedInvestor()) {
                return 'invTransact.txnDetails';
            } else {
                return 'transact.txnDetails.redeem';
            }
        },
        isLoggedInvestor: function() {
            var userType = (authenticationService.getUser() ? authenticationService.getUser().userType : null);
            return userType && (userType.toString() === '10');
        },
        getFormattedReviewDetails: function(redeemModel) {
            var reviewValuePairs = [];
            if (this.isLoggedInvestor()) {
                // redeemType = (redeemModel.getType() === 'Amount' || redeemModel.getType() === 'Units' ? 'Partial' : redeemModel.getType());

                reviewValuePairs = [{
                    text: 'Type',
                    value: (redeemModel.getType() ? redeemModel.getType() : 'NA')
                }, {
                    text: 'Amount',
                    value: (redeemModel.getAmount() ? '<span class="icon-fti_rupee"></span> '+redeemModel.getAmount(): 'NA')
                }, {
                    text: 'Units',
                    value: (redeemModel.getUnits() ? redeemModel.getUnits() : 'NA')
                }, {
                    text: 'Bank Details',
                    value: (redeemModel.getBank() ? redeemModel.getBank() : 'NA')
                }, {
                    text: 'Mode of Payment',
                    value: (redeemModel.getMode() ? redeemModel.getMode() : 'NA')
                }];
            }
            else {
                reviewValuePairs = [{
                    text: 'Type',
                    value: redeemModel.getType()
                }, {
                    text: 'Amount',
                    value: redeemModel.getAmount()
                }, {
                    text: 'Units',
                    value: redeemModel.getUnits()
                }, {
                    text: 'Bank Details',
                    value: redeemModel.getBank()
                }, {
                    text: 'Mode of Payment',
                    value: redeemModel.getMode()
                }];
            }

            return reviewValuePairs;
        }
    };
    return redeemReviewDetailsFactory;

};

redeemReviewDetailsFactory.$inject = ['authenticationService'];
module.exports = redeemReviewDetailsFactory;
