'use strict';
// Controller naming conventions should start with an uppercase letter

function newInvestorFatcaFormController($scope, $state, transactModel,transactEventConstants,buildPlanModelService,paperlessModel,$timeout,investorRegistrationModel,$filter,authenticationService,planSmartSolution) {
    console.info("newInvestorFatcaFormController");
    $scope.fatcaData = [];
     var requestObject = {}, fatcaDetailsArray = [], fatcaObj ={}, taxObject, taxCountryArr, taxIdArr;
    if (buildPlanModelService.getNewInvestorFirstHolderDtls()) {
        var firstHolder = buildPlanModelService.getNewInvestorFirstHolderDtls()

        $scope.fatcaData.push({
            name: firstHolder.fullName,
            pan: firstHolder.appPanNo,
            aadhar: firstHolder.aadhar==undefined?null:parseInt(firstHolder.aadhar),
            mobile: firstHolder.mobile==undefined?null:parseInt(firstHolder.mobile),
            email: firstHolder.email==undefined?null:firstHolder.email,
            type: firstHolder.type,
            Title: "First Holder"
        });
    }
    if (buildPlanModelService.getNewInvestorHolderDetails()) {
        angular.forEach(buildPlanModelService.getNewInvestorHolderDetails(), function(obj, key){
            $scope.fatcaData.push({
                name: obj.fullName,
                pan: obj.userEnteredPan,
                aadhar: obj.aadhar==undefined?null:parseInt(obj.aadhar),
                mobile: obj.mobile==undefined?null:parseInt(obj.mobile),
                email: obj.email==undefined?null:obj.email,
                type: obj.type,
                Title: obj.type=="Secondholder"?"Second Holder":"Third Holder"
            });
        })
    }
        var buildObject = {};
        buildObject.holders = [];

        console.log($scope.fatcaData);
      buildObject.custName = buildPlanModelService.getNewInvestorFirstHolderDtls().fullName;
            buildObject.folioId = "New";
            buildObject.holdingType = buildPlanModelService.modeOfHolding==undefined?"Not assigned":buildPlanModelService.modeOfHolding;
            buildObject.holders.push({name:null});
            var holderDtls = buildPlanModelService.getNewInvestorHolderDetails();
           if (holderDtls!=null && holderDtls.length==1) {
                buildObject.holders.push({name:buildPlanModelService.getNewInvestorHolderDetails()[0].fullName==undefined?"NA":buildPlanModelService.getNewInvestorHolderDetails()[0].fullName});
            }
            else if (holderDtls!=null && holderDtls.length==2) {
                buildObject.holders.push({name:buildPlanModelService.getNewInvestorHolderDetails()[1].fullName==undefined?"NA":buildPlanModelService.getNewInvestorHolderDetails()[1].fullName});
                buildObject.holders.push({name:buildPlanModelService.getNewInvestorHolderDetails()[2].fullName==undefined?"NA":buildPlanModelService.getNewInvestorHolderDetails()[2].fullName});
            }
            console.log(buildObject);
            planSmartSolution.setTransactType("Lumpsum");
            transactModel.setInvestorDetails(buildObject);
            transactModel.isNewInvestor = true;
      
    function invRegSuccess(data){
        console.log("fatca success",data);
        investorRegistrationModel.setinvestorRegDetails(data);
        transactModel.setWebRefNo(data.webRefNo); 
        investorRegistrationModel.setNewInvestorFolioId(data.folioId); //For new investor we will folio id from investorregistrtion service.
        $scope.$emit("validated");
    }
    function invRegFailure(err){
        console.log("Investro Registration Failure");
    }
     
    $scope.fatcaFund = function()
    {   
         $scope.$broadcast(transactEventConstants.transact.FATCA_DETAILS);
      $timeout(function(){
       
                    if (paperlessModel.isFatcaSuccess) {
                        console.log("smartsolfatcadeatils",paperlessModel.invDetails.getFactaDetails());
                       /* $scope.firstHolderDtls = paperlessModel.invDetails.getFirstHolderDetails();
                        $scope.firstHolderDtls.aadhar = paperlessModel.invDetails.getFactaDetails()[0].aadhar;
                        $scope.firstHolderDtls.mobile = paperlessModel.invDetails.getFactaDetails()[0].mobile;
                        $scope.firstHolderDtls.email = paperlessModel.invDetails.getFactaDetails()[0].email;
                        paperlessModel.invDetails.setFirstHolderDetails($scope.firstHolderDtls);*/
                        requestObject.paramObj = {"guId" : authenticationService.getUser().guId};
                        requestObject.bodyObj = {};
                        requestObject.bodyObj.fundHolders = [];
                        requestObject.bodyObj.status = "A";
                        fatcaDetailsArray = paperlessModel.invDetails.getFactaDetails();
                        
                        console.log("fatcaDetailsArray ",fatcaDetailsArray);
                        angular.forEach(fatcaDetailsArray, function(value, key) {
                            fatcaObj = {};
                            if(value.political){
                                fatcaObj.pepFlag = "P";
                            }else if(value.relatedPolitical){
                                fatcaObj.pepFlag = "R";
                            }else if(value.political && value.relatedPolitical){
                                fatcaObj.pepFlag = "PR";
                            }
                            if(value.type === "Firstholder"){
                                fatcaObj.applicantStatus = 'F';
                            }else if(value.type === "Secondholder"){
                                fatcaObj.applicantStatus = 'S';
                            }else if(value.type === "Thirdholder"){
                                fatcaObj.applicantStatus = 'T';
                            }
                            fatcaObj.customerName = value.name;
                            fatcaObj.panNo = value.pan;
                            fatcaObj.aadharNo = value.aadhar.toString();
                            fatcaObj.mobileNo = value.mobile.toString();
                            fatcaObj.dob = $filter('date')(value.dob, 'dd/MM/yyyy');
                            fatcaObj.emailId = value.email;
                            fatcaObj.countryOfBirth = value.country;
                            fatcaObj.placeOfBirth = value.birthPlace;
                            fatcaObj.occupation = value.occDetails;
                            fatcaObj.grossAnnualIncome = value.incDetails === "Gross Annual Income" ? "" : value.incDetails;
                            fatcaObj.netWorthAmount = value.netWorth;
                            fatcaObj.netWorthDate = $filter('date')(value.netWorthDate, 'dd/MM/yyyy');
                            fatcaObj.taxDetails = [];
                            if(value.residentRadios == 'yes'){
                                taxCountryArr = value.taxDetailsArr;
                                taxIdArr = value.taxIDNumArr;
                                angular.forEach(taxCountryArr, function(obj, key) {
                                    taxObject = {};
                                    taxObject.taxRefNo = taxIdArr[key].value;
                                    taxObject.country = obj.value;
                                    fatcaObj.taxDetails.push(taxObject);
                                });                              
                            }else if(value.residentRadios == 'no'){
                                fatcaObj.taxDetails = [];
                            }                            
                            fatcaObj.kycRegMode = (value.kycMode == "aadharNo" ? "instant" : (value.kycMode == "Physical" ? "physical" : null)) || "instant";
                            requestObject.bodyObj.fundHolders.push(fatcaObj);
                        });                        
                        investorRegistrationModel.fetchinvestorRegDetails(requestObject).then(invRegSuccess, invRegFailure);
                    }
                },1);      
       
          
         $scope.fundDtls.fundDtlsState = "smartSol.planSmartSolution.fundDetailsSS.investment";
         planSmartSolution.setFundDetailsState($scope.fundDtls.fundDtlsState);
         $state.go('smartSol.planSmartSolution.fundDetailsSS');
    }

}

newInvestorFatcaFormController.$inject = ['$scope', '$state', 'transactModel','transactEventConstants', 'buildPlanModelService','paperlessModel','$timeout','investorRegistrationModel','$filter','authenticationService','planSmartSolution'];
module.exports = newInvestorFatcaFormController;