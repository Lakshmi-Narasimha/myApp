/**
 * @ngdoc directive
 * @name fticKeyValueEditableTile
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticKeyValueEditableTile will display the kye value editable tiles for "My profile - Grant Access" .
 * 
 *
 **/
'use strict';

var keyValueEditableTile = function($timeout, eventConstants) {
    return {
            template: require('./keyValueEditableTile.html'),
            restrict: 'E',
            replace: true,           
            scope: {
                keyValueObject: '='
            },
            controller:['$scope', '$element', function($scope, $element){
                var focusInput = function() {
                    $scope.isFieldEditable = true;
                    $timeout(function(){
                        $scope.$digest();
                        $inputField.focus();
                    }, 0);
                };
                $scope.actionClass = 'icon-fti_inlineEdit';
                $scope.isChanged = false;
                var $inputField = $element[0].querySelector('input');
                $scope.isFieldEditable = false;
                $scope.$on(eventConstants.ACTION_ICON_CLICKED, function(){
                    focusInput();
                });

                $scope.handleInputBlur = function(){
                    $scope.isFieldEditable = false;
                    if($scope.isChanged){
                       $scope.$emit('FIELD_UPDATED', $scope.keyValueObject);
                       $scope.isChanged = false;
                    }
                    
                };

                $scope.$on(eventConstants.MyProfile.ADV_MP_FLD_FOCUS, function(){
                    focusInput();
                });
            }]
        };
};

keyValueEditableTile.$inject = ['$timeout', 'eventConstants'];
module.exports = keyValueEditableTile;