/**
 * @ngdoc property
 * @name investorDetailsVerticalTileList Directive
 * @description
 *
 * investorDetailsVerticalTileList - Displays List Item for the given User
 *
 **/
 
'use strict';

var investorDetailsVerticalTileList = function(selectInvestorModel,eventConstants,transactEventConstants) {
	return {
        template: require('./investorDet_VerticalTileList.html'),
        restrict: 'E',
        replace: true,
        scope:{
            
        },
        controller:['$scope', function($scope){
            $scope.$on(transactEventConstants.transact.Selected_Investor,function(event,data){
                var InvestorData = selectInvestorModel.getSelectedInvestorDtls();
                
                $scope.keyValueList = [
                    /*{key:'First Holder Name',value:InvestorData.custName},*/
                    {key:'First Holder Name',value:(InvestorData.holders.length>0)?(InvestorData.holders[0].name.trim() !==""?InvestorData.holders[0].name:'NA'):"NA"},
                    {key:'Second Holder Name',value:(InvestorData.holders.length>1)?(InvestorData.holders[1].name.trim() !==""?InvestorData.holders[1].name:'NA'):"NA"},
                    {key:'Third Holder Name',value:(InvestorData.holders.length>2)?(InvestorData.holders[2].name.trim() !==""?InvestorData.holders[2].name:'NA'):"NA"},
                    {key:'Folio No.',value:InvestorData.folioId},
                    {key:'Mode Of Holding',value:InvestorData.holdingType}
                ]
            });

            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function (event, args) {         
                 $scope.$emit(transactEventConstants.transact.Inv_Edit_Clicked);
            });
        }]
    }
};

investorDetailsVerticalTileList.$inject = ['selectInvestorModel','eventConstants','transactEventConstants'];
module.exports = investorDetailsVerticalTileList;