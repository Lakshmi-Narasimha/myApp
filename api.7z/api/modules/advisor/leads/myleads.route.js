var express = require('express'),
    router = express.Router(),
    leadsDetailsModel = require('./leadsdetails.model');

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */


router.route('/getLeadsDetailsData')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        leadsDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else {
                res.json(data[0].LeadsDetails);
            }

        });
    });

module.exports = router;
