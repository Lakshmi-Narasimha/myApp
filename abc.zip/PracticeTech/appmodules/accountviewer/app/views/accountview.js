define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appmodules/accountviewer/avcommon',
  'appcommon/globalcontext',
  'appcommon/constants',
  'services/dataservice',
  'appmodules/accountviewer/app/models/accountviewmodel',
  'appcommon/groupui/app/views/groupuiview',
  'appmodules/accountviewer/app/views/holdingsview',
  'text!appmodules/accountviewer/app/templates/accountshell.html',
  'text!appmodules/accountviewer/app/templates/accountview.html',
  'text!appmodules/accountviewer/app/templates/accounttotalvalue.html',
  'appcommon/analytics',
  'errorLog','config',
  'appcommon/commonutility',
  "appcommon/applauncher/device",
  'appmodules/accountviewer/app/data/accountviewdatamodule',
], function ($, _, Backbone, Spinner, accountviewCommon, GlobalContext, Constants, Dataservice, accountViewData, GroupUi, HoldingsView, AccountShell, AccountView, AccountTotalValue, Analytics, ErrorLog, Config, CommonUtility, Device, AccountViewDataModule) {
    var _Self = null, brkgProdClsCds = CommonUtility.getBrkgProdClsCds();
	var accountview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click .holdings": "showHoldings",
            "click .abp-mobile-link":"ABPMobileLinkClick"
        },
        template: _.template(AccountShell),
        initialize: function () {
            _Self = this;
            window.scroll(0, 0);
        	this.ABPMobileWindoweWindow = null;
        	this.accntDetails = {};
        	this.groupId = undefined;
            this.accountViewDataCollection = [];
            this.totalValue = "";
            this.partialOutput = false;
            this.acctDt = null;
            this.accountDetailServiceResponse = null;
            var _that = this;
            $(document).off("click",".account-details").on("click",".account-details",function(e){
            	_that.gotoAccountDetails(e);
            });
            $(document).off("click", "#create-new-business").on("click", "#create-new-business", function (e) {
                _that.goToNBST(e);
            });
            $(document).off("click", "#accountListCvLink").on("click", "#accountListCvLink", function (e) {
                _that.gotoCVlink(e);
            });
            $(document).off("click",".sorting").on("click",".sorting",function(e){
            	_that.sortAccountList(e);
            });
            if ($(".av-accounts-group-container").length < 1) {
            	_that.$el.html(_that.template());
            }
        	window.removeEventListener("message", _that.recievePostMessageFromT1, false);
        	window.addEventListener("message", _that.recievePostMessageFromT1, false);            
        },
        recievePostMessageFromT1:function(event){
        	var ABPMobileWindow  = CommonUtility.getABPMobileWindow();
        	var _domainName = Config.t1DomainName;
        	if(event.origin != _domainName){
        		return false;
        	}
        	var _acctDetails = {}, _contextData = {
        			contextDictionary:{}
        	};
        	_acctDetails["Number"] = _Self.accntDetails.accountId;
        	var _postMessage = event.data;
        	if(_postMessage.status == "READY"){
        		_contextData['contextDictionary']['ACCOUNT'] = _acctDetails;
        		ABPMobileWindow.postMessage(_contextData,_domainName);
        	}
        	
        },
        ABPMobileLinkClick: function (e) {
            _Self.accntDetails = {};
            Analytics.analytics.recordAction('AmeripriseBrokeragePlatformAccountList:Clicked');
        	var ABPMobileWindow  = CommonUtility.getABPMobileWindow();
        	var _$el = $(e.currentTarget);
        	this.accntDetails.accountId = _$el.data('account-id').substr(-8); 
            e.preventDefault();
            var that = this;
            var _url = Config.t1URL+"&contextId=external";
            var _options = {
                "strAccNum": that.accntDetails.accountId,
                "strTabId": "Positions",
                "strThomledId": 156,
                "strRefreshThomletId": 6764,
            }
            
            CommonUtility.launchThomsonSmart(_options, openT1Link);
            function openT1Link() {
            	if (ABPMobileWindow) { ABPMobileWindow.close(); }
            	setTimeout(function () { ABPMobileWindow = window.open(_url); CommonUtility.setABPMobileWindow(ABPMobileWindow); }, 200);
            }
        },
        sortAccountList:function(e){
            var $this = $(e.currentTarget);
            var $thisSpan = $this.find("span.sorticons");
            var sortOrder = "";
            var sortField = $this.attr('data-sort');
                if(!$this.hasClass("reset-sorting")){
                    if ($thisSpan.hasClass("desc-icon")) {
                        $thisSpan.removeClass("desc-icon").addClass("asc-icon").addClass("act");
                        sortOrder = "asc";
                        
                    }
                    else if ($thisSpan.hasClass("asc-icon")) {
                        $thisSpan.removeClass("asc-icon").addClass("desc-icon").addClass("act");
                        sortOrder = "desc";
                    }
		            else {
		                  $thisSpan.addClass("asc-icon").addClass("act");
		                  sortOrder = "asc";
		            } 
		        }       
                $(".sorting").each(function () {
                    var $innerThisSpan = $(this).find('span.sorticons');               
                    if (!$thisSpan.is($innerThisSpan) && $innerThisSpan.hasClass("act")) {
                        if ($innerThisSpan.hasClass("asc-icon")) {
                            $innerThisSpan.removeClass("asc-icon").removeClass("act");
                        }
                        if ($innerThisSpan.hasClass("desc-icon")) {
                            $innerThisSpan.removeClass("desc-icon").removeClass("act");
                        }
                    }
                });
                var options = {
                		groupId:GlobalContext.getInstance().getGlobalContext().Context.GroupId,
                		fmId:accountviewCommon.readCookie('FMID'),
                		sortField:sortField,
                		sortOrder:sortOrder
                };
                this.saveSortState(sortField, sortOrder);
                this.render(options);
                $(".sorting[data-sort='"+sortField+"']").find('span').addClass(sortOrder+"-icon").addClass("act");
        },
        scrollbuttonclick: function (e) {
            $('html, body').animate({ scrollTop: 0 }, 500);
            return false;
        },
        triggerCollapsables : function(){
        	$(".expand-collapse").off("click").on("click",function(){
        		var _uniqueId = $(this).attr("data-target");
        		var elmnt = this;
        		setTimeout(function(){
        		    if(!$(elmnt).hasClass('act')){
        			    $(_uniqueId).show('slow');
            		}
            		else{
        			    $(_uniqueId).hide('slow');
            		}
        		},100)
        	})
        },
        gotoAccountDetails : function(e){
        	var _target = e.target || e.currentTarget;
        	var _accountId = $(_target).data("account-id");
        	var _productCd = $(_target).data("productcd");
        	var _url = "accountviewer/accountdetails/"+_accountId+"/"+_productCd;
        	(typeof practicetech.modules.accounts === 'undefined') ? practicetech.modules.accounts = new practicetech.createNew.module() : "";
        	_Self.saveState(_accountId);
        	Backbone.history.navigate(_url, true);
        },
        saveState: function (accountId) {
            var _state = { "expand": [], "target": null, "scroll": null, "save": true, "sortOrder": "", "sortField": "" };
	        _state.scroll = $(window).scrollTop();
            $('.acct-hldngs-exp-collps-icn.collapse-icon:visible').each(function () {
                _state.expand.push('.acct-hldngs-exp-collps-icn[data-accont-id="' + $(this).data("accontId") + '"]:visible')
	        });
            _state.target = '.account-details[data-account-id="' + accountId + '"]';
            practicetech.modules.accounts.state
            if (practicetech.modules.accounts && practicetech.modules.accounts.state && practicetech.modules.accounts.state.sortField) {
                _state.sortField = practicetech.modules.accounts.state.sortField;
                _state.sortOrder = practicetech.modules.accounts.state.sortOrder;
            }
            practicetech.modules.accounts.state = _state;
            practicetech.modules.accounts.state
        },
        saveSortState: function (sortField, sortOrder) {
            (typeof practicetech.modules.accounts === 'undefined') ? practicetech.modules.accounts = new practicetech.createNew.module() : "";
            practicetech.modules.accounts.state = practicetech.modules.accounts.state ? practicetech.modules.accounts.state : {};
            practicetech.modules.accounts.state.sortField = sortField;
            practicetech.modules.accounts.state.sortOrder = sortOrder;
        },
	    loadFromSavedState: function () {
	        var _state = practicetech.modules.accounts ? practicetech.modules.accounts.state : {}, _historyFragment = Backbone.history.list.slice(-2)[0];
	        if ((_historyFragment == "accountviewer/" || _historyFragment && _historyFragment.indexOf("accountviewer/accountdetails") > -1) && _state) {
	            if (_state.save) {
	                for (var i = 0; i < _state.expand.length; i++) {
	                    $(_state.expand[i]).click();
	                }
	                setTimeout(function () {
	                    var _$target = $(_state.target);
	                    (_state.target && _$target.length > 0) ? $(window).scrollTop($(_state.target).offset().top - 50) : "";
	                    practicetech.modules.accounts.state.save = false;
	                }, 500);
	            } 
	        } else {
	            practicetech.modules.accounts = {};
	        }

	    },
        gotoCVlink: function (e) {
            Spinner.show();
            var self = this;
            var _url = Config.getConfigProperty("hocExtrnlActnLinks").acctsuitmisReviewInCV;
            var _contextId = null;
            var async = false;
            self.callPutContextServicespell(false).then(function (response) {
                Spinner.hide();
                if (response && response.d) {
                    _contextId = response.d.cntxId;
                    _url = _url + _contextId;
                    window.open(_url);
                } else {
                    ErrorLog.ErrorUtils.myError(response);
                }
            }).fail(function (error) {
                Spinner.hide();
                ErrorLog.ErrorUtils.prepareAndLogError(error);
            });
        },
        callPutContextServicespell: function (async, acc) {
            var _data = {
                putAdvsSessCntxAcctIds: null,
                putAdvsSessCntxClIds: null,
                putAdvsSessCntxDstrIds: null,
                putAdvsSessCntxGrpIds: null

            };

            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _clientId = _gContext.ContactId;
            _data.clCntxIdTypCd = "IDs";
            var _clientCtx = {
                clId: _clientId,
                clCtx: "COLA.CL",
                clRole: "PrimaryClient"
            };
            _data.putAdvsSessCntxClIds = [_clientCtx];
            var _dstrCtx = {
                dstrId: _gContext.AdvisorFMID,
                dstrCtx: "DMU.DIST"
            };
            _data.putAdvsSessCntxDstrIds = [_dstrCtx];
            return Dataservice.putAdvisorSessionContext(_data, (async != undefined) ? async : true);
        },

        renderGroupSelector : function(){
        	new GroupUi({ el: $('#av-group-selection'),NoCahe:true}).render();
        },
        showHoldings : function(e){
        	var target = e.target || e.currentTarget;
        	var accountId = $(target).data("accont-id");
        	var adminCd = $(target).data("admin-cd");
        	var productCd = $(target).data("productcd");
        	var targetContainer = $("#"+$(target).data("holdings-target"));
        	if(adminCd == "134"){
        		var altAcctId = null;
        		if($(target).data("target").match(/\d/i)[0]){
        			var selectedKey = $(target).data("target").match(/\d/i)[0];
        			if ($(target).hasClass('collapse-icon') == true) {
        				new HoldingsView({ type: "insurence" }).triggerCollapsables(target, targetContainer);
        			} else {
        				this.getaltAcctIdAndGotoHoldings(accountId, target, targetContainer, adminCd, productCd);
        			}
        		} else {
        			this.getaltAcctIdAndGotoHoldings(accountId, target, targetContainer, adminCd, productCd);
        		}
        	}
        	else if (adminCd == "133") {
        		new HoldingsView({ type: "brokerage" }).render(accountId, target, targetContainer, adminCd, productCd);
        	} else {
        		new HoldingsView({ type: "insurence" }).render(accountId, target, targetContainer, adminCd, productCd);
        	}
        	
        },
        getaltAcctIdAndGotoHoldings : function(accountId, target, targetContainer, adminCd, productCd){
        	var altAcctId = null,_self = this;
        	Spinner.show();
            Dataservice.promiseToGetAccountIdentifier(accountId, [401]).then(function (accountIdentifierResp) {
				
                if (accountIdentifierResp && accountIdentifierResp.jqXHR && accountIdentifierResp.jqXHR.status) {
                    if (accountIdentifierResp.jqXHR.status == 401) {
                        new HoldingsView({type:"insurence"}).render(accountId, target, targetContainer, adminCd, productCd, true, false);
                    } else {
                        _self.logError(accountIdentifierResp);
                    }
					
				}else{
                    if (accountIdentifierResp && accountIdentifierResp.d && accountIdentifierResp.d.alternateAccountIdentifiers && accountIdentifierResp.d.alternateAccountIdentifiers.length>0) {
                        $.each(accountIdentifierResp.d.alternateAccountIdentifiers, function (key, row) {
	    					if(row.altAcctCtx && row.altAcctCtx == "ADMSRV.ACCT"){
	    						altAcctId = row.altAcctId;
	    					}
	    				});
	    			}
	    			Spinner.hide();
	    			if(altAcctId){
	    				new HoldingsView({type:"insurence"}).render(altAcctId, target, targetContainer, adminCd, productCd, true);
	    			}else{
	    				new HoldingsView({type:"insurence"}).render(accountId, target, targetContainer, adminCd, productCd);
	    			}
				}
				Spinner.hide();
    		}).fail(function(err){
    		    Spinner.hide();
    		    ErrorLog.ErrorUtils.myError(err);
    		});
        },

        goToNBST: function (e) {
            Analytics.analytics.recordAction('Accounts:CreateNewBusinessLink:clicked');
            Device.operatingSystem();
            Device.physicalDevice();
            Device.browser();
            var _deviceInfo = Device.info;
            var _deviceType = _deviceInfo.hardware.make;
            if ((_deviceInfo.os.type.indexOf('windows') !== -1 && (_deviceType == "Desktop" || _deviceType == "Surface")) && (_deviceInfo.browser.name === 'ie')) {
                Spinner.show();
                var self = this;
                var _url = Config.newBusinessSetupURL;
                var _contextId = null;
                var _v2Compatible = true;
                var async = false;
                var contextResult = CommonUtility.preparePutAdvContextPayLoad(_v2Compatible, GlobalContext);
                Dataservice.putAdvisorSessionContext(contextResult, (async != undefined) ? async : true).then(function (response) {
                    Spinner.hide();
                    if (response && response.d) {
                        _contextId = response.d.cntxId;
                        _url = _url + _contextId;
                        window.open(_url);
                    } else {
                        ErrorLog.ErrorUtils.myError(response);
                    }
                }).fail(self.genericServiceErrorHandler);
                e.preventDefault();
            } else {
                BootstrapDialog.alert("This functionality is only available in Internet Explorer on Windows devices (desktop or Surface)", null, "Function unavailable");
                e.preventDefault();
                return;
            }
        },
      
	    updateDisplayName: function (arg) {
            var contactProfileID = $("#groupDivClientName");
            var arg = arg || null;
            if (arg == null) {
                return false;
            }
            contactProfileID.text(contactProfileID.text() + " " + arg);
        },
	    render: function (options) {
	        var _$acctListContainer = $(".acc-tmp-conatiner");
	        try {
	            if (!options.sortField && practicetech.modules.accounts && practicetech.modules.accounts.state && practicetech.modules.accounts.state.save && practicetech.modules.accounts.state.sortField) {
	                options.sortField = practicetech.modules.accounts.state.sortField;
	                options.sortOrder = practicetech.modules.accounts.state.sortOrder;
	            }
	            this.groupId = options.groupId;
	            var _that = this, generalTemplate = _.template(AccountView);
	            this.validateSavedStateAndRestore(_$acctListContainer);
	            if (this.groupId == null || this.groupId == undefined) {
	                _$acctListContainer.html(generalTemplate({ accountList: null }));
	            } else {
	                var accountvalTemplate = _.template(AccountTotalValue);
	                if (options.accounDetails) {
	                    renderAccountlist(options.accounDetails)
	                } else {
	                    Spinner.show();
	                    AccountViewDataModule.getAccountViewData(renderAccountlist);
	                }
	                function renderAccountlist(accounDetails) {
	                    _that.accountDetailServiceResponse = accounDetails;
	                    if (_that.acctDt) {
	                        renderAccountList();
	                    } else {
	                        getAccountingDate();
	                    }
	                    function getAccountingDate() {
	                        var _response = (_that.accountDetailServiceResponse && _that.accountDetailServiceResponse.accountingDateResp) ? _that.accountDetailServiceResponse.accountingDateResp : null;
	                        if (_response && _response.d && _response.d.acctDt) {
	                            _that.acctDt = _response.d.acctDt;
	                        }
	                        renderAccountList();
	                    }

	                    function renderAccountList() {
	                        if (_that.accountViewDataCollection.length > 0) {
	                            if (options.sortField && options.sortField == "account-value") {
	                                var tmpObjCollectionNotNull = sortAccountsWithNullValues(_that.accountViewDataCollection);
	                                $("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile").html(accountvalTemplate({ accountList: _that.accountViewDataCollection, accountTotal: _that.totalValue, partialOutput: _that.partialOutput, acctDt: _that.acctDt }))
	                                $(".acc-tmp-conatiner").html(generalTemplate({ "brkgProdClsCds": brkgProdClsCds, sortField: 'account-value', sortOrder: options.sortOrder, accountList: tmpObjCollectionNotNull, accountTotal: _that.totalValue, partialOutput: _that.partialOutput, acctDt: _that.acctDt }))
									.promise().done(function () {
									    _that.renderGroupSelector();
									});
	                                _that.triggerCollapsables();
	                            } else {
	                                accountViewData.applySortToAccountList(_that.accountViewDataCollection, options.sortField, options.sortOrder);
	                                $("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile").html(accountvalTemplate({ accountList: _that.accountViewDataCollection, accountTotal: _that.totalValue, partialOutput: _that.partialOutput, acctDt: _that.acctDt }))
	                                $(".acc-tmp-conatiner").html(generalTemplate({ "brkgProdClsCds": brkgProdClsCds, sortField: options.sortField, sortOrder: options.sortOrder, accountList: _that.accountViewDataCollection, accountTotal: _that.totalValue, partialOutput: _that.partialOutput, acctDt: _that.acctDt }))
									.promise().done(function () {
									    _that.renderGroupSelector();
									});
	                                _that.triggerCollapsables();
	                            }
	                        } else {
	                            var response = (_that.accountDetailServiceResponse && _that.accountDetailServiceResponse.accountViewResp) ? _that.accountDetailServiceResponse.accountViewResp : null,
        					        _sortField = '', _sortOrder = '', _sortedAccounts = _that.accountViewDataCollection;
	                            
	                            if (response && response[0]) {
	                                response = response[0]['attributes'];
	                            } else {
	                                response = response['results'][0]['attributes'];
	                            }
	                            if (response.dstrOverviewProcessingStatus.attributes.statCd && response.dstrOverviewProcessingStatus.attributes.statCd == "0001") {
	                                _that.partialOutput = true;
	                            }
	                            _that.totalValue = accountViewData.fillAccountListData(response.overviewAccount, _that.accountViewDataCollection, options.groupId);

	                            if (options.sortField) {
	                                _sortField = options.sortField;
	                                _sortOrder = options.sortOrder;
	                                
	                                if (_sortField == "account-value") {
	                                     _sortedAccounts = sortAccountsWithNullValues(_that.accountViewDataCollection);
	                                } else {
	                                    accountViewData.applySortToAccountList(_that.accountViewDataCollection, options.sortField, options.sortOrder);
                                    }
	                            }
                                	                            
	                            $("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile").html(accountvalTemplate({ accountList: _that.accountViewDataCollection, accountTotal: _that.totalValue, partialOutput: _that.partialOutput, acctDt: _that.acctDt }))
	                            $(".acc-tmp-conatiner").html(generalTemplate({ "brkgProdClsCds": brkgProdClsCds, sortField: _sortField, sortOrder: _sortOrder, accountList: _sortedAccounts, accountTotal: _that.totalValue, partialOutput: _that.partialOutput, acctDt: _that.acctDt }));
	                            _that.triggerCollapsables();
	                        }
	                        _that.loadFromSavedState();
	                    }
	                }
	            }
	            $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
	            $(".hdr-tab-buttons-wrap .av-accounts").addClass("hdr-tab-active");
	            Spinner.hide();
            } catch (err) {
                _$acctListContainer.css({ "opacity": 1 });
        	    ErrorLog.ErrorUtils.myError(err);
        	    
            }
	        function sortAccountsWithNullValues(accountViewDataCollection) {
	            try {
                     var tmpObjCollectionNotNull = [], tmpObjCollectionNull = [];
	                $.each(accountViewDataCollection, function (key, row) {
	                    if (row.attributes.accountBalance.attributes.totAcctBal === ""
                            || row.attributes.accountBalance.attributes.totAcctBal === null) {
	                        tmpObjCollectionNull.push(row);
	                    } else {
	                        tmpObjCollectionNotNull.push(row);
	                    }
	                });
	                accountViewData.applySortToAccountList(tmpObjCollectionNotNull, options.sortField, options.sortOrder);
	                tmpObjCollectionNotNull = tmpObjCollectionNotNull.concat(tmpObjCollectionNull);
	                return tmpObjCollectionNotNull
	            } catch (e) {
                    _$acctListContainer.css({ "opacity": 1 });
                    ErrorLog.ErrorUtils.myError(e);
	            }
	        }
	    },
	    validateSavedStateAndRestore: function ($acctListContainer) {
	        //make the opacity of list 0, untill the animation ddrawerc ompletes
	        var _state = practicetech.modules.accounts ? practicetech.modules.accounts.state : {}
	        if (_state && _state.expand && _state.expand.length > 0) {
	            $acctListContainer.css({ "opacity": 0 });
	            setTimeout(function () {
	                $acctListContainer.css({ "opacity": 1 });
	            }, 700);
	        }
	        
	    },
	    logError: function () {
	        Spinner.hide();
	        ErrorLog.ErrorUtils.myError(err);
	    }
    });
    return accountview;
});