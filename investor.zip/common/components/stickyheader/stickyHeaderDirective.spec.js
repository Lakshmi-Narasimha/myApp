'use strict';

describe('Directive: Sticky Header', function() {

	var compile, scope, compiledEle;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));
    
    beforeEach(function() {
 		angular.mock.inject(function($rootScope, $compile) {            
        scope = $rootScope.$new();
  			compile = $compile;
  			scope.recommendationsCount = 12;  			
  			scope.notificationsCount = 23;  			        	
        });

        var element = angular.element('<ftic-sticky-header></ftic-sticky-header>');
        compiledEle = compile(element)(scope);               
		    scope.$digest();
    });
	

    it('should be defined', function() {
        expect(compiledEle).toBeDefined();
    });

    it('should have the counts of recommendations and notifications', function() {
        expect(scope.recommendationsCount).toEqual(12);
        expect(scope.notificationsCount).toEqual(23);
    });

});