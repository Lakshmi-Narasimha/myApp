/**
 * @ngdoc property
 * @name swpTxnController Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/

'use strict';
// Controller naming conventions should start with an uppercase letter
function swpTxnController($scope, fticLoggerMessage, loggerConstants, $state, transactModel, authenticationService, $window) {

    var _userType = authenticationService.getUser().userType;
    $scope.isInvestorType = false;
    
    if (_userType && _userType.toString() === '10') {
        $scope.isInvestorType = true;
    }

    $scope.redirect = function () {

        transactModel.resetSetters();
        transactModel.isNewInvestor = false;
        $state.go('transact.base.swp');
    };

    $scope.windowPrint = function() {

        $window.print();
    };
}

swpTxnController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'transactModel', 'authenticationService', '$window'];
module.exports = swpTxnController;