define([
], function () {
    let config = {
        awmServicePath:'https://mgpclientselector.advisorcompass.com/ods.svc/',
        mgpServiceUrl:'https://mgpclientselector.advisorcompass.com/ResponseProviderService/svc/mgp/',
        mgpSubscriptionUrl: 'http://laa2app2527xrp:10108/fumigo.svc/',
        oboServicePath: 'https://mgpclientselector.advisorcompass.com/adv_capl/oboselector/',
        launchMgpUrl: 'pt-exit-mgp-scenario-1.html',
    };

    return config;

});