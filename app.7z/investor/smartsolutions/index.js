/**
 *@ngdoc object
 *@name investor.module:home
 *@description
 * <p>
 * Module declaration for my profile
 * </p>
 */

'use strict';
// Home View
module.exports = angular.module('investor.smartsolutions', [])
    .config(require('./smartsolutions.routes'))
    .controller('smartSolutionsCtrl', require('./smartsolutions.controller'))
	.controller('planSmartSolutionController', require('./planSmartSolution/planSmartSolution.controller'))
	.controller('selectSmartSolutionController', require('./planSmartSolution/selectSmartSolutions/selectSmartSolution.controller'))
	.factory('savedSmartSolutionsModel', require('./savedSmartSolutions/services/savedSmartSolutionsModel.service'))
	.factory('savedSmartSolutionsInitLoader', require('./savedSmartSolutions/services/savedSmartSolutionsInitLoader.service'))
	.controller('savedSmartSolutionsController', require('./savedSmartSolutions/savedSmartSolutions.controller'))
	.directive('fticSavedSmartSolutionsGrid', require('./savedSmartSolutions/savedSmartSolutionsGrid/savedSmartSolutionsGrid.directive'))
	.controller('smartSolSelectFolio', require('./planSmartSolution/smartSolSelectFolio/smartSolSelectFolio.controller'))
	.controller('planInputDetailsController', require('./planSmartSolution/planSmartSolutionsBase/planInputDetails/planInputDetails.controller'))
    .controller('planSmartSolutionBaseController', require('./planSmartSolution/planSmartSolutionsBase/planSmartSolutionBase.controller'))
    .factory('buildPlanModelService', require('./services/buildPlanModel.service'))
	.factory('buildPlanInitialLoader',require('./services/buildPlanInitialLoader.service'))
	.factory('recommendedPlanModelService', require('./services/recommendedPlanModel.service'))
	.factory('recommendedFundCardModelService', require('./services/recommendedFundCardModel.service'))
	.factory('recommendedPlanInitialLoader',require('./services/recommendedPlanInitialLoader.service'))
	.controller('recommendationsCntrl', require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendations.controller'))
    .controller('recommendedplanCtrl', require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendedplan/recommendedplan.controller'))
    .controller('buildmyplanCtrl', require('./planSmartSolution/planSmartSolutionsBase/recommendations/buildmyplan/buidmyplan.controller'))
    .controller('customizeCtrl', require('./planSmartSolution/planSmartSolutionsBase/recommendations/recommendedplan/customize/customize.controller'))
    .controller('buildmyplanshowdtlsCtrl', require('./planSmartSolution/planSmartSolutionsBase/recommendations/buildmyplan/components/smartSolBuildPlanShowDtls/smartSolBuildPlanShowDtls.controller'))
	.controller('goalSheetSummaryController', require('./planSmartSolution/planSmartSolutionsBase/goalsheetsummary/goalSheetSummary.controller'))
	.factory('recommendedFundsInitialLoader', require('./services/recommendedFundsInitialLoader.service'))
   	.factory('recommendedFundsModelService',require('./services/recommendedFundsModel.service'))
 	.factory('recommendedFundCardInitialLoader',require('./services/recommendedFundCardInitialLoader.service'))
	//Proceed To Buy Flow - Start  
	.controller('InvProceedToBuyController', require('./invproceedtobuy/invProceedToBuy.controller'))
	.controller('InvInvestmentPrefController', require('./invproceedtobuy/investmentpreference/investmentPreference.controller'))
	.directive('fticInvSmartSolHolderInfoTile', require('./components/invsmartsolholderinfo/invSmartSolHolderInfoTile.component'))
	.factory('invSmartSolHolderInfoFactory', require('./components/invsmartsolholderinfo/invSmartSolHolderInfo.factory'))
	.controller('InvFundDetailsController', require('./invproceedtobuy/invfunddetails/invFundDetails.controller'))
	.controller('InvPaymentDetailsController', require('./invproceedtobuy/invpaymentdetails/invPaymentDetails.controller'))
	.controller('InvReviewNConfirmController', require('./invproceedtobuy/invreviewnconfirm/invReviewNConfirm.controller'))
	//Proceed To Buy Flow - End
	.controller('TrackMyGoalsController', require('./trackmygoals/trackmygoals.controller'))
	.directive('fticSmartSolSelectGoalGrid', require('./trackmygoals/components/selectGoal/selectGoal.directive'))
	.factory('investorGoalModelService', require('./trackmygoals/services/investorGoalTracking.service'))

	.controller('SsEkycRegstrController', require('./planSmartSolution/ekycRegForm/ssekycRegister.controller'))
	
	.controller('smartSolsCurrentPdCtrl', require('./trackmygoals/currentpd/currentPD.controller'))
	.factory('currentPlanFundsInitalLoaderService', require('./services/currentPlanFundsInitialLoader.service'))
	.factory('currentPlanFundsService', require('./services/currentPlanFundsModel.service'))
	.directive('fticInvGoalCurrentPlansFunds', require('./trackmygoals/components/invGoalCurrentPlans/invGoalCurrentPlans.directive'))
	.controller('smartSolsTopupWithSfCtrl', require('./trackmygoals/topupwithsf/topupWithSf.controller'))
	.factory('overviewModel', require('./services/overviewModel.service'))
	.controller('smartSolsTopupWithSameFundsCtrl', require('./trackmygoals/topupwithsf/topupwithsamefunds/topupWithSameFunds.controller'))
	.controller('smartSolsTopupWithSameFundsGoalSheetCtrl', require('./trackmygoals/topupwithsf/topupwithsamefundsgoalsheet/topupWithSameFundsGoalSheet.controller'))
	.controller('smartSolsTopupWithFTRFCtrl', require('./trackmygoals/topupwithftrf/topupWithFtRF.controller'))
	.controller('smartSolsTopupWithFtRecommendedFundsCtrl', require('./trackmygoals/topupwithftrf/topupwithftrecommendedfunds/topupWithFtRecommendedFunds.controller'))
	.controller('smartSolsTopupWithFtRecommendedFundsGoalSheetCtrl', require('./trackmygoals/topupwithftrf/topupwithftrecommendedfundsgoalsheet/topupWithFtRecommendedFundsGoalSheet.controller'))
	.controller('panLevelInvModalController', require('./investorgoaltracking/components/panLevelInvModal/panLevelInvModal.controller'))
    .controller('panLevelInvModalController', require('./investorgoaltracking/components/panLevelInvModal/panLevelInvModal.controller'))
    .factory('recommendedFundsInitialLoader', require('./services/recommendedFundsInitialLoader.service'))
    .factory('recommendedFundsModelService',require('./services/recommendedFundsModel.service'))
    .controller('customizedPlanController', require('./planSmartSolution/planSmartSolutionsBase/recommendations/customizedplan/customizedPlan.controller'))
	
    ;
   

    

    