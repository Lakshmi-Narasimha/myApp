/**
 * @ngdoc directive
 * @name accountViewFilter
 * @requires $state  
 * @requires 
 * @description
 *
 * - It displays the filter section of the account view in account statements of Vslustions.
 * 
 *
 **/
/*global _ */
'use strict';

var accountViewFilter = function($state, $filter, $timeout, panViewModel, toaster, invFolioDetailsModel, investorConstants,myportfolioConstants,fticDateUtils) {
    return {
        template: require('./accountViewFilter.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope) {
            var dateHolder = {},
                accFolioObj = {};

            $scope.sectionOptionsFolio = [];
            /*  _.each(invFolioDetailsModel.getFolioAccountData(), function(element) {

                  var folioObj = null;
                  folioObj = {
                      title: $filter('translate')(investorConstants.myportfolio.FOLIO_NO) + '. ' + element.folioId,
                      folioNumber: element.folioId
                  };
                  if ($state.params.folioNumber === element.folioId) {
                      $scope.selectedFolioOpt = folioObj;
                  }
                  $scope.sectionOptionsFolio.push(folioObj);
              });*/


            var folioAccData = invFolioDetailsModel.getFolioAccountData();
            $scope.sectionOptionsFolio = _.map(folioAccData, function(folioObj) {
                return {
                    title: $filter('translate')(investorConstants.myportfolio.FOLIO_NO) + '. ' + folioObj.folioId,
                    folioNumber: folioObj.folioId,
                    folioAccList: folioObj.folioAccounts
                };
            });
            if ($state.params.folioNumber) {
                $scope.selectedFolioOpt = {
                    title: $filter('translate')(investorConstants.myportfolio.FOLIO_NO) + '. ' + $state.params.folioNumber,
                    folioNumber: $state.params.folioNumber,
                    folioAccList: _.find(folioAccData, { folioId: $state.params.folioNumber }).folioAccounts
                };
            } else {
                var latestFolio = _.find(folioAccData, { latestFolio: 'Y' });
                $scope.selectedFolioOpt = {
                    title: $filter('translate')(investorConstants.myportfolio.FOLIO_NO) + '. ' + latestFolio.folioId,
                    folioNumber: latestFolio.folioId,
                    folioAccList: latestFolio.folioAccounts
                };
            }

            $scope.dateOptions = investorConstants.myportfolio.DATE_OPTIONS;
            $scope.selectedObj = {};
            $scope.selectedObj.fullDate = fticDateUtils.getYesterday();
            $scope.hideSelect = true;
            $scope.allowValidation = true;
            $scope.errorMsgs = myportfolioConstants.overview.DATEPICKER_VAL_MSGS;
            $scope.dateRangeErrorMsgs = myportfolioConstants.overview.DATEPICKER_RANGE_VAL_MSGS;

            $scope.validationObj = {};
            $scope.validationObj.isApply = false;
            $scope.validationObj.isDateLess = false;
            $scope.validationObj.isFromDate = false;



            $scope.$on('selectedFolio', function(event, selFolioObj) {
                /* $scope.sectionOptionsAccount = null;
                 $scope.selectedAccOpt = null;
                 $timeout(function() {
                     var accountList = [];
                     _.each(invFolioDetailsModel.getFolioAccountData(), function(folioEle, index, list) {

                         if (data.folioNumber === folioEle.folioId) {
                             _.each(folioEle.folioAccounts, function(accountEle, index, list) {
                                 var accountObj = null;
                                 accountObj = {
                                     title: $filter('translate')(investorConstants.myportfolio.ACCOUNT_NO) + '. ' + folioEle.folioAccounts[index],
                                     accontNumber: folioEle.folioAccounts[index]
                                 };
                                 if ($state.params.accontNumber === folioEle.folioAccounts) {
                                     $scope.selectedAccOpt = accountObj;
                                 } else if (!$state.params.folioNumber && angular.lowercase(folioEle.latestFolio) === 'y') {
                                     $scope.selectedAccOpt = accountObj;
                                 }
                                 accountList.push(accountObj);
                             });
                         }
                     });
                     $scope.sectionOptionsAccount = accountList;
                 });*/
                $scope.sectionOptionsAccount = _.map(selFolioObj.folioAccList, function(acc) {
                    return {
                        title: $filter('translate')(investorConstants.myportfolio.ACCOUNT_NO) + '. ' + acc,
                        accontNumber: acc
                    };
                });
                if ($state.params.accontNumber) {
                    var selAcc = $scope.selectedFolioOpt.folioAccList[_.indexOf($scope.selectedFolioOpt.folioAccList, $state.params.accontNumber)];
                    $scope.selectedAccOpt = {
                        title: $filter('translate')(investorConstants.myportfolio.ACCOUNT_NO) + '. ' + selAcc,
                        accontNumber: selAcc
                    };
                } else {

                    $scope.selectedAccOpt = $scope.sectionOptionsAccount[0];
                    console.log($scope.selectedAccOpt)
                }

            });

            $scope.initFlag = true;
            $scope.$on('selectedAcc', function(event, data) {
                accFolioObj.folioPanAccNo = data.accontNumber;
                $scope.selectedAccOpt=data;
                if ($scope.initFlag) {
                    $timeout(function() {
                        $scope.emitApply();
                        $scope.initFlag = false;
                    });
                }
            });

            $scope.$on('selectedValue', function(event, data) {
                $scope.validationObj.isDateLess = false;
                dateHolder = {};
                if (data.key !== null) {
                    dateHolder.dayFlag = data.key;
                }
            });

            $scope.$on('getdaterange', function(event, date1, date2) {
                dateHolder.fromDate = $filter('date')(date1, 'dd/MM/yyyy');
                dateHolder.toDate = $filter('date')(date2, 'dd/MM/yyyy');
            });
            $scope.$on('fticcmpFilterEvent', function(event, inputVal, inputType) {
                if (dateHolder.dayFlag === 'AD') {
                    dateHolder.fromDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    dateHolder.toDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                } else if (dateHolder.dayFlag === 'DR') {
                    $scope.validationObj.isDateLess = false;
                    if (inputType === 'dtr1') {
                        dateHolder.fromDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    } else if (inputType === 'dtr2') {
                        dateHolder.toDate = $filter('date')(inputVal, 'dd/MM/yyyy');
                    }
                    $scope.both = dateHolder.fromDate;
                    $scope.validationObj.isDateLess = fticDateUtils.checkValidDateRange(dateHolder.toDate, dateHolder.fromDate);
                }
            });

            $scope.$on('getcurrentdate', function(event, date) {
                dateHolder.fromDate = $filter('date')(date, 'dd/MM/yyyy');
                dateHolder.toDate = $filter('date')(date, 'dd/MM/yyyy');
            });
            $scope.emitApply = function() {
                var acountFilter = angular.merge({}, accFolioObj, dateHolder);
                $scope.isDateValid = fticDateUtils.checkIsValidDate(dateHolder, $scope.validationObj.isDateLess);
                $scope.validationObj.isApply = true;
                if ($scope.isDateValid) {
                    $scope.validationObj.isApply = false;
                    $scope.$emit('apply', acountFilter);
                }

            };
        }
    };
};

accountViewFilter.$inject = ['$state', '$filter', '$timeout', 'panViewModel', 'toaster', 'invFolioDetailsModel', 'investorConstants', 'myportfolioConstants','fticDateUtils'];
module.exports = accountViewFilter;
