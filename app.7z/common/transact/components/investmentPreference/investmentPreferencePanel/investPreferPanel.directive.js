/**
 * @ngdoc property
 * @name fticModifySipForm Directive
 * @description
 *
 * - Form concludes sip effective date for specific actions
 *
 **/
'use strict';

var fticInvestPreferPanel = function(advisorSearchModel, transactModel, paperlessModel, transactNowModel, $state, $stateParams, $timeout, authenticationService, TransactConstant, transactEventConstants, fundDetails) {
    return {
        template: require('./investPreferPanel.html'),
        restrict: 'E',
        scope: {},
        controller: function($scope) {
            var existingAdvisors;
            
            function advisorNamesSuccess(data) {
                //console.log(data);
                advisorSearchModel.setAdvisorNameDetails(data);
                existingAdvisors = advisorSearchModel.getAdvisorNameDetails();
                if (($scope.presentState !== 'transactnow.reviewNow.renewSip' || 'invTransact.review.renewsip' ) && existingAdvisors !== null) {
                    angular.forEach(existingAdvisors.distName, function(value) {
                        $scope.selectOptions.push({ 'title': value });
                    });
                }
                $scope.onInitialLoad = true;
            }

            function handleFailure() {
                console.log('handleFailure');
                $scope.onInitialLoad = true;
            }
            $scope.$on('getInvestorPreferenceData', function(){
                var params = {
                    'guId': authenticationService.getUser().guId,
                    'userType': 'D',
                    'distValue': transactModel.getSelectedFolioDts().folioId,
                    'distFlag': 'F'
                };
                advisorSearchModel.fetchAdvisorNameDetails(params).then(advisorNamesSuccess, handleFailure);
            });
            
            $scope.configDataLost = {};
            $scope.configDataLost.showNotification = false;
            $scope.disableExistingAdv = false;
            // setting key value object
            var keyValueList = [];
            // advisor name and euin code
            var code = '';
            var euin = '';
            var codeId = '';
            var investPreferValue = {};
            var investPreferObject = null;
            var nullObj = {};
            $scope.selectOptions = [];
            $scope.referSelected = {};
            // setting toggle variables
            $scope.selectedAdvisorModeRenew = false;
            $scope.isDisableContinue = true;
            $scope.showContinue = true;
            // initializes radio buttons model variables
            $scope.radios = {};
            $scope.radios.selectedVal = '';
            $scope.radiosAdvisor = {};
            $scope.radiosAdvisor.selectedVal = '';
            // initializes radio objects
            $scope.preferences = [{
                label: 'Financial Adviser',
                value: 'financial',
                nameLbl: 'invPreference'
            }, {
                label: 'Direct',
                value: 'direct',
                nameLbl: 'invPreference'
            }];

            $scope.advisorTypeDetails = [{
                label: 'Existing Adviser',
                value: 'existing',
                nameLbl: 'advType'
            }, {
                label: 'New Adviser',
                value: 'new',
                nameLbl: 'advType'
            }];

            $scope.presentState = $state.current.name;
            if ($scope.presentState === 'transactnow.reviewNow.renewSip' || $scope.presentState === 'invTransact.review.renewsip') {
                $scope.showContinue = false;
            }
            // getting existing advisors list
	    existingAdvisors = advisorSearchModel.getAdvisorNameDetails();
            if (!authenticationService.getUser().distId) {
                $scope.distId = 'Direct ~ 0000000000';
                $scope.disableExistingAdv = true;
            } else {
                $scope.distId = authenticationService.getUser().distId;
            }

            var distIdCheck = $scope.distId.split('~');
            // get from service 
            var advisorArnCode = distIdCheck[1];

            if ($scope.presentState !== "transactnow.reviewNow.renewSip" && existingAdvisors !== null){
                    angular.forEach(existingAdvisors.distName,function(value,key){
                        $scope.selectOptions.push({"title": value});
                    });
                }
            //Function to find the given 'value' in a given object array
            $scope.findItemInFilter = function(objArr, value) {
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                    return x.title === value;
                }))[0];
                return obj;
            };

            $scope.$on('advisorOptioSelected', function(event, selectedOption) {
                code = selectedOption.title;
                codeId = code.split('~');
                advisorArnCode = codeId[1];
            });

            $scope.listenAdvisorChange = function(input) {
                $scope.radiosAdvisor.selectedVal = input;
                $scope.selectedAdvisorMode = input;
                if (input === 'new') {
                    $scope.isDisableContinue = true;
                } else {
                    //$scope.isDisableContinue = false;
                    if($scope.selectOptions.length > 0) {
                        $scope.isDisableContinue = false;
                    } else {
                        $scope.isDisableContinue = true;
                    }
                }
                if ($scope.presentState === 'transactnow.reviewNow.renewSip') {
                    $scope.selectedAdvisorModeRenew = true;
                    if ($scope.isEdit) {
                        nullObj = {};
                        transactModel.setAdvDetails(nullObj);
                        $scope.isEdit = false;
                    }
                } else {
                    if ($scope.selectedAdvisorMode === 'existing') {
                        //var existingAdvisors= advisorSearchModel.getAdvisorNameDetails();
                        nullObj = {};
                        transactModel.setAdvDetails(nullObj);
                    }
                }
                $timeout(function() {
                    $scope.investorPrefTransactForm.$setPristine();
                }, 0);
            };
            $scope.listenChange = function(input) {
                $scope.selectedMode = input;
                $scope.radios.selectedVal = input;
                paperlessModel.investorPreferenceOption = input;
                $scope.isDisableContinue = false;
                //$scope.selectedAdvisorMode = '';
                $timeout(function() {
                    $scope.investorPrefTransactForm.$setPristine();
                }, 0);
                if ($scope.selectedMode === 'financial') {
                    //$scope.adNames = advisorSearchModel.getAdvisorNameDetails();
                    if ($scope.selectOptions.length > 0) {
                        $scope.listenAdvisorChange($scope.advisorTypeDetails[0].value);
                    } else {
                        $scope.listenAdvisorChange($scope.advisorTypeDetails[1].value);
                    } 
                } else if ($scope.selectedMode === 'direct') {
                    var nullObj = {};
                    transactModel.setAdvDetails(nullObj);
                }
            };

            if (transactNowModel.isInvPreferHasInitialData === true) {
                if (distIdCheck[0].trim().toLowerCase() === 'direct') {
                    $scope.listenChange($scope.preferences[1].value);
                } else {
                    $scope.listenChange($scope.preferences[0].value);
                    if ($scope.selectOptions.length > 0) {
                        $scope.listenAdvisorChange($scope.advisorTypeDetails[0].value);
                    } else {
                        $scope.listenAdvisorChange($scope.advisorTypeDetails[1].value);
                    }
                }
            }

            if ($stateParams.key == 'investorPreference' || transactNowModel.hasInvPreferData == true) {
                investPreferObject = transactNowModel.getInvestPrefer();
                if (investPreferObject.investorMode == 'direct') {
                    $scope.listenChange($scope.preferences[1].value);
                } else {
                    var advisorMode = investPreferObject ? investPreferObject.advisorMode : 'existing';
                    $scope.listenChange($scope.preferences[0].value);
                    $scope.listenAdvisorChange(advisorMode);
                    $scope.isEdit = true;
                    $scope.referSelected.distId = $scope.findItemInFilter($scope.selectOptions, transactNowModel.getInvestPrefer().code);
                }
            } else {
                $scope.referSelected.distId = $scope.findItemInFilter($scope.selectOptions, $scope.distId);
            }

            // for renew sip review page only
            $scope.$on('continueInvestPrefer', function() {
                $scope.investorPrefTransactForm.$setSubmitted();
                $scope.getSelection();
            });

            //This is added to handle the POPUP functionality...
            function goNexttab() {
               
                transactNowModel.hasInvPreferData = true;
                transactNowModel.setInvestPrefer(investPreferValue);
                $scope.selectedAdvisorMode === 'existing' ? transactModel.setAdvDetails(investPreferValue) : null;
                //This is added to change the configuration of fund or sip Tile.
                if ($state.current.url === '/buyState' || $state.current.url === '/buy') {
                    transactModel.setTransactType(TransactConstant.buy.BUYFUND);
                } else if ($state.current.url === '/sipState') {
                    transactModel.setTransactType(TransactConstant.sip.FUNDSIP);
                }
                if ($scope.presentState !== 'transactnow.reviewNow.renewSip' && $scope.presentState !== 'invTransact.review.renewsip') {
                    //alert("in if loop");
                    if ($scope.selectedMode === 'financial') {
                        keyValueList = [
                            { key: 'Investment Preference', value: 'Financial Advisor' },
                            { key: 'Adviser Name', value: code },
                            { key: 'ARN Code', value: advisorArnCode }
                        ];
                    } else if ($scope.selectedMode === 'direct') {
                        keyValueList = [
                            { key: 'Investment Preference', value: 'Direct-ARN0000000000' }
                        ];
                    }
                    transactNowModel.setkeyValueInvPreferData(keyValueList);
                    $scope.$emit('setInvestorPreference', keyValueList);
                } else {
                    $scope.$emit('validated');
                }
            }

            //iF NEW Advisor selected from typeahead
            $scope.$on(transactEventConstants.transact.guest.invPref.NEW_ADVISOR_SELECTED, function() {
                $scope.isDisableContinue = false;
            });
            $scope.$on(transactEventConstants.transact.guest.invPref.ADVISOR_NAME_CHANGED, function() {
                $scope.isDisableContinue = true;
            });
            $scope.getSelection = function() {
                investPreferValue = {};
                if ($scope.investorPrefTransactForm.$valid) {
                    if ($scope.selectedAdvisorMode === 'new' || $scope.presentState === 'transactnow.reviewNow.renewSip') {
                        code = transactModel.getAdvDetails().code;

                        euin = transactModel.getAdvDetails().euin;
                    }
                    if ($scope.selectedAdvisorMode === 'new' && $scope.presentState !== 'transactnow.reviewNow.renewSip') {
                        if (code) {
                            codeId = code.split('~');
                            advisorArnCode = codeId[1];
                        }
                    }
                    // check only in renew sip investor preference only
                    if ($scope.presentState === 'transactnow.reviewNow.renewSip' || $scope.presentState === 'invTransact.review.renewsip') {
                        if (transactNowModel.getInvestPrefer().investorMode !== $scope.selectedMode) {
                            transactNowModel.isDataChanged = true;
                            transactNowModel.setPrevInvestorDetails(transactNowModel.getInvestPrefer());
                        }
                    }

                    investPreferValue.investorMode = $scope.selectedMode;
                    investPreferValue.advisorMode = $scope.selectedAdvisorMode;
                    investPreferValue.code = code;
                    investPreferValue.advisorArnCode = advisorArnCode;
                    investPreferValue.euin = euin;
                    transactNowModel.isInvPreferHasInitialData = false;

                    //This is added to handle the POPUP functionality...
                    if ($stateParams.key == 'investorPreference' || transactNowModel.invPreferEditClicked || transactNowModel.hasInvPreferData) {
                        transactNowModel.invPreferEditClicked = false;
                        var result = _.isEqual(transactNowModel.getInvestPrefer(), investPreferValue);
                        if (!result) {
                            $scope.configDataLost.showNotification = true;
                            var destroyHandler = $scope.$on('yes', function() {
                                //Remove fundDetails if the user clicks on YES.
                                fundDetails.removeFundDetails();
                                fundDetails.initialFundArr();
                                transactModel.showFundsOnNo = false;
                                goNexttab();
                                $scope.configDataLost.showNotification = false;
                                destroyHandler();
                                $scope.$emit('RESET_FORM_ON_CALL_PARENT'); //Event for resetting stp form
                            });

                            $scope.$on('no', function() {
                                $scope.configDataLost.showNotification = false;
                                investPreferObject = transactNowModel.getInvestPrefer();
                                if (investPreferObject.investorMode === 'direct') {
                                    $scope.listenChange($scope.preferences[1].value);
                                } else {
                                    var advisorMode = investPreferObject ? investPreferObject.advisorMode : 'existing';
                                    $scope.listenChange($scope.preferences[0].value);
                                    $scope.listenAdvisorChange(advisorMode);
                                    $scope.isEdit = true;
                                    $scope.referSelected.distId = $scope.findItemInFilter($scope.selectOptions, transactNowModel.getInvestPrefer().code);
                                }
                                transactModel.showFundsOnNo = true;
                                
                                
                            });
                        } else {
                            transactModel.showFundsOnNo = true;
                            goNexttab();
                        }
                    } else {
                        goNexttab();
                    }

                }

            };

        }
    };
};

fticInvestPreferPanel.$inject = ['advisorSearchModel', 'transactModel', 'paperlessModel', 'transactNowModel', '$state', '$stateParams', '$timeout', 'authenticationService', 'TransactConstant', 'transactEventConstants', 'fundDetails'];
module.exports = fticInvestPreferPanel;