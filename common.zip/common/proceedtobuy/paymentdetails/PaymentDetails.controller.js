/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function PaymentDetailsController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout,transactModel, planSmartSolution, fundDetailsModel, fundDetails, $stateParams, eventConstants, toaster, authenticationService, fticStateChange) {
        
    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;
    $scope.isFromPaperLess = transactModel.isPaperLess;
    transactModel.isLumpsumValidated = false;
    transactModel.isSipValidated = false;


    if (planSmartSolution.getTransactType() === 'Lumpsum') {
        $scope.showLumpsum = true;
    } else if (planSmartSolution.getTransactType() === 'SIP') {
        $scope.showSip = true;
    } else if (planSmartSolution.getTransactType() === 'Combo') {
        $scope.showBoth = true;
    }

    //Checking for state params in case of edit

    if($stateParams.key){

        if(authenticationService.isInvestorLoggedIn()) {

        } else {
            fticStateChange.stateChange($state, $scope.paymentDtls.paymentDtlsState, {
            key: $stateParams.key
        });         
        }
    }else{
        if(authenticationService.isInvestorLoggedIn()) {

        } else {
            fticStateChange.stateChange($state, $scope.paymentDtls.paymentDtlsState);       
        }
        
    }
       
    $scope.showInvDtls = false;
    $scope.showBack = false;
    $scope.showHeader = false;

    if ($scope.paymentDtls.paymentDtlsState === 'smartSol.planSmartSolution.paymentdetailsSS.investment') {
        $scope.showInvDtls = true;
        $scope.showBack = true;
        $scope.showHeader = true;
        if (transactModel.getInvestorDetails()) {
            $scope.holderInfoArray = [{
                key: 'First Holder',
                value: transactModel.getInvestorDetails().custName
            }, {
                key: 'Second Holder',
                value: (transactModel.getInvestorDetails().holders && transactModel.getInvestorDetails().holders.length > 1) ? transactModel.getInvestorDetails().holders[1].name : 'NA'
            }, {
                key: 'Third Holder',
                value: (transactModel.getInvestorDetails().holders && transactModel.getInvestorDetails().holders.length > 2) ? transactModel.getInvestorDetails().holders[2].name : 'NA'
            }, {
                key: 'Folio. No.',
                value: transactModel.getInvestorDetails().folioId
            }, {
                key: 'Mode of Holding',
                value: transactModel.getInvestorDetails().holdingType
            }];
        }

    }

    $scope.pdBackBtn = function() {
        fticStateChange.stateChange($state, 'smartSol.planSmartSolution.fundDetailsSS');
        //$state.go('smartSol.planSmartSolution.fundDetailsSS');
    };


    $scope.$on('validated', function(event, data) {
        if (!$scope.showBoth || ($scope.showBoth && data.isBothValidated)) {
            if ($scope.paymentDtls.paymentDtlsState === 'smartSol.planSmartSolution.paymentdetailsSS.investment') {
                $scope.reviewDtls.reviewDtlsState = 'smartSol.planSmartSolution.reviewnconfirm.investment';
                fticStateChange.stateChange($state, 'smartSol.planSmartSolution.reviewnconfirm');
                //$state.go('smartSol.planSmartSolution.reviewnconfirm');
            } else if ($scope.paymentDtls.paymentDtlsState === 'paperLess.transact.paymentDtls.smartPaymentDtls.investment') {
                $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
            } else if ($scope.paymentDtls.paymentDtlsState === 'transactnow.baseNow.smartSolTransact.paymentDetails') {
                transactModel.setInvestorDetails(transactModel.getSelectedFolioDts());
                fticStateChange.stateChange($state, 'transactnow.reviewNow.smartSol');
                //$state.go('transactnow.reviewNow.smartSol');
            }
        }

        if (data.transactType === 'BUY') {
            toaster.success('We have successfully validated your lumpsum details.');
            //$scope.$broadcast('openSipAccordion');
        } else if (data.transactType === 'SIP') {
            toaster.success('We have successfully validated your sip details.');
            //$scope.$broadcast('openLumpsumAccordion');
        }
    });

}

PaymentDetailsController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','$timeout','transactModel', 'planSmartSolution', 'fundDetailsModel', 'fundDetails', '$stateParams', 'eventConstants', 'toaster', 'authenticationService', 'fticStateChange'];
module.exports = PaymentDetailsController;