'use strict';

var smartSolCustomizeModel = function ($state, planSmartSolution) {
    return {
        template: require('./smartSolCustomizeModel.html'),
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: {
            formCustomized: "=",
            tabName: '='
        },
        controller: function ($scope, $element, $attrs) {
            /*$scope.status = $scope.allOpen;*/

            /*$scope.investmentDetails = [];
            planSmartSolution.callParamsCodes({'groupId': 'InvestmentType'}).then(function (data) {
                console.log('InvestmentType', data);
                angular.forEach(data.codeValueList, function (obj, ind){
                    var investment = {};
                    investment.title = obj.code;
                    $scope.investmentDetails.push(investment);
                })
            }, function (data) {

            });*/
            $scope.investmentDetails = [{
                title: "Monthly",
                message: "",
                value: "",
                name: "investmentDetails",
                selected: ""
                ,
                 isRequired : true
            }, {
                title: "Annually",
                message: "",
                value: "",
                name: "investmentDetails",
                selected: ""
                ,
                 isRequired : true
            },
                {
                    title: "One-time",
                    message: "",
                    value: "",
                    name: "investmentDetails",
                    selected: ""
                    ,
                     isRequired : true
                }, {
                    title: "Combo",
                    message: "",
                    value: "",
                    name: "investmentDetails",
                    selected: ""
                    ,
                     isRequired : true
                }];
            $scope.monthlyInputObject = {
                key: "monthly",
                text: "",
                name: "monthlyInput",
                type: "number",
                isEditable: true,
                maxlength: 6,
                min: "500",
                // isRequired:true,
                pattern: /^500$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$|^[5-9]{1}[0-9]{2}$/,
                value: ""
            };

            $scope.monthlyInputObject.value = parseInt(planSmartSolution.getSmartSolutionDetails().monthlySIP);
            $scope.annualInputObject = {
                key: "annually",
                text: "",
                name: "annualInput",
                type: "number",
                isEditable: true,
                maxlength: 6,
                // isRequired:true,
                pattern: /^500$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$|^[5-9]{1}[0-9]{2}$/,
                value: ""
            };
            $scope.oneTimeInvestmentObject = {
                key: "oneTime",
                text: "",
                name: "oneTimeInput",
                type: "number",
                isEditable: true,
                maxlength: 9,
                value: "",
                // isRequired:true,
                pattern: /^1000$|^[1-9]{1}[0-9]{8}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$/,
            };
            $scope.stepUpObject = {
                key: "stepUp",
                text: "",
                name: "stepUpInput",
                type: "number",
                isEditable: true,
                isRequired: true,
                maxlength: 2,
                pattern: /^05$|^[1-9]{1}[5-5]{1}$|^[1-9]{1}[0-0]{1}$/,
                value: ""
            };
            $scope.expectedReturnsObject = {
                key: "expectedReturns",
                text: "",
                name: "expectedReturnsInput",
                type: "number",
                isEditable: true,
                maxlength: 6,
                pattern: /^[0-9]/,
                isRequired: true,
                value: ""
            };
            $scope.withdrawalObject = {
                key: "withdrawal",
                text: "",
                name: "withdrawalAmount",
                type: "number",
                isEditable: false,
                maxlength: 9,
                pattern: /^1000$|^[1-9]{1}[0-9]{8}$|^[1-9]{1}[0-9]{7}$|^[1-9]{1}[0-9]{6}$|^[1-9]{1}[0-9]{5}$|^[1-9]{1}[0-9]{4}$|^[1-9]{1}[0-9]{3}$/,
                value: ""
            };
            // $scope.goBack=function(){
            //   $state.go('smartSol.planSmartSolution.ssBase.recommendations.recommendedplan');
            // }

            $scope.$on('investmentType', function (event, data) {
                $scope.investmentType = data.title;
                if ($scope.investmentType == 'Combo') {
                    $scope.monthlyInputObject.value = parseInt(planSmartSolution.getSmartSolutionDetails().monthlySIP);
                    $scope.annualInputObject.value = 0;
                    $scope.oneTimeInvestmentObject.value = 0;
                }
                else if($scope.investmentType == 'Annually'){
                    $scope.monthlyInputObject.value = "";
                }
                else if($scope.investmentType == 'One-time'){
                    $scope.monthlyInputObject.value = "";
                }
            });

            $scope.showTab = !($scope.tabName == "buildplan");
            //if ($scope.tabName == "buildplan") {
            //    $scope.showTab = false;
            //}
            //else
            //    $scope.showTab = true;


            $scope.apply = function () {
                if ($scope.formCustomized.$valid) {
                    if ($scope.tabName == "buildplan")
                        $scope.slider_floor_ceil.value = "";
                    $scope.customizationDetails = {
                        investmentType: $scope.investmentType,
                        monthly: $scope.monthlyInputObject.value,
                        annually: $scope.annualInputObject.value,
                        onetime: $scope.oneTimeInvestmentObject.value,
                        stepUp: $scope.stepUpObject.value,
                        expectedReturns: $scope.expectedReturnsObject.value,
                        withdrawl: $scope.withdrawalObject.value,
                        equityExposure: $scope.slider_floor_ceil.value,
                        currentState: $state.current.name
                    };
                    $scope.$emit("customizeDetailsApply", $scope.customizationDetails);

                }
            };

            $scope.cancel = function () {
                console.log('cancel');
                $scope.$emit("customizeDetailsCancel");
            }
        },
        link: function (scope, iElement, iAttrs, controller) {

        }
    };
};
smartSolCustomizeModel.$inject = ['$state', 'planSmartSolution'];
module.exports = smartSolCustomizeModel;