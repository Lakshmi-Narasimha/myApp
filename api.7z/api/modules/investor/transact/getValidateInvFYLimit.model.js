// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var ValidateInvFyLimitModelSchema = new mongoose.Schema({
    ValidateInvFyLimitResponse: {
        type: Object,
        'default': {}
    }
});

var ValidateInvFyLimitModelLookUp = mongoose.model('ValidateInvFyLimitModelLookUp', ValidateInvFyLimitModelSchema);

var ValidateInvFyLimitModel = new ValidateInvFyLimitModelLookUp({
    ValidateInvFyLimitResponse: {
        'statusFlag': 'W',
        'displayMessage': 'Your investor has exceed annual transaction limit of Rs 50,000 for this financial year, as he is KYC registered via AADHAR OTP. Please proceed to KYC registration via Physical verification to perform transaction online',
        'allowableTxnAmount': '0'
    }
});

ValidateInvFyLimitModelLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidateInvFyLimitModelLookUp table, please contact admin...');
    } else {
        ValidateInvFyLimitModelLookUp.remove({}, function (err) {
            console.log('ValidateInvFyLimitModelLookUp collection removed');
            ValidateInvFyLimitModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating ValidateInvFyLimitModelLookUp table, please contact admin...');
                }
                console.log('ValidateInvFyLimitModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ValidateInvFyLimitModelLookUp;