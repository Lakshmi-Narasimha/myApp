define([
  'jquery',
  'underscore',
  'backbone',
  'appcommon/applauncher/deviceWhitelist'
], function ($, _, Backbone, Whitelist) {

    var whitelist = Whitelist;

    var device = {
        type: null,
        make: null,
        model: null,
        formFactor: null,
        userAgent: navigator.userAgent,
        hardware: {
            make: null,
            model: null,
            type: null,
            formFactor: null

        },
        browser: {
            type: null,
            name: null,
            version: null,
            features: {},
        },
        os: {
            name: null,
            version: null,
            type: null,
            supported: null,
            featuires: {}
        }
    }


    function init(whitelist) {
        operatingSystem(whitelist);
        browser(whitelist);
        physicalDevice(whitelist);

        return true
    }
    function operatingSystem(whitelist) {

        var temp,
        os = navigator.platform,
        osType = null, osVersion = null;

       if (/win/i.test(os)) {
            osType = whichWindows();
            osName = osType.name;
            osType = osType.type;
        } else if (/Mac|OSX/i.test(os)) {
            osType = whichMacOs();
            osName = osType.name;
            osType = osType.type;
        } else if (/ipad/i.test(navigator.userAgent) || /iphone/i.test(navigator.userAgent)) {
            osType = whichIOS();
            osName = osType.name;
            osVersion = osType.version;
            osType = osType.type;

        } else if (/android/i.test(navigator.userAgent)) {
            osType = "android";

            osName = osType;
            osType = osType;
        } else {
            "unknown" //cannot query string
        }

        if (Whitelist.OSList.hasOwnProperty(osType) && Whitelist.OSList[osType].isSupported == true) {
            device.os.type = osType;
            device.os.name = osName;
            device.os.supported = true;
            if (osVersion !== null) { device.os.version = osVersion; }
            return osType;
        } else {
            device.os.type = 'Unknown';

            return 'unknown' // string
        }

        function  whichMacOs() {
            if (/Mac OS X 10_5/i.test(navigator.userAgent)) {
                return { type: 'macOSX', name: 'Mac OS 10.5' }
            } else if ( /Mac OS X 10_6/i.test(navigator.userAgent)) {
                return { type: 'macOSX', name: 'Mac OS 10.6' }
            } else if (/NT 6.1/i.test(navigator.userAgent)) {
                 return { type: 'macOSX', name: 'Mac OS 10.7' }
            } else if (/NT 6.2/i.test(navigator.userAgent)) {
                 return { type: 'macOSX', name: 'Mac OS 10.8' }
            } else if (/NT 6.3/i.test(navigator.userAgent)) {
                 return { type: 'macOSX', name: 'Mac OS 10.9' }
            }
        return {
                    type: 'macOSgeneric', name : 'Mac OS X'
                }
        }
    }

    function physicalDevice(whitelist) {
        var physDevice = "unknown";
        if (/ipad/i.test(navigator.userAgent)) {
            physDevice = 'iPad'
            formFactor = 'Medium';
            deviceType = "Tablet"
        } else if (/iphone/i.test(navigator.userAgent)) {
            physDevice = 'iPhone';
            physDeviceModel = whichIPhone();
            formFactor = 'Small';
            deviceType = "Phone"
        } else if (/iPod/i.test(navigator.userAgent)) {
            physDevice = 'iPod';
            formFactor = 'Small';
            deviceType = "Phone"
        }else if (/samsung/i.test(navigator.userAgent)) {
            physDevice = "Samsung";
            formFactor = 'Small';
            deviceType = "Phone"
        } else if (/android.+mobile/i.test(navigator.userAgent)) {
            physDevice = 'Android';
            formFactor = 'Small';
            deviceType = "Phone"
        } else if (/android.+tablet/i.test(navigator.userAgent)) {
            physDevice = 'Android';
            formFactor = 'Medium';
            deviceType = "Tablet"
        } else if (/blackberry/i.test(navigator.userAgent) || /bb10/i.test(navigator.userAgent)) {
            physDevice = 'BlackBerry';
            formFactor = 'Small';
            deviceType = "Phone"
        } else if (/windows phone|windows mobile|iemobile/i.test(navigator.userAgent)) {
            physDevice = 'Windows Phone';
            formFactor = 'Small';
            deviceType = "Phone"
        }  else if (/android/i.test(navigator.userAgent)) {
            physDevice = "Android";
            formFactor = 'Small';
            deviceType = "Tablet"
        } else if (/touch/i.test(navigator.userAgent)) {
            physDevice = "Surface";
            formFactor = 'Large';
            deviceType = "Desktop"
        } else if (/win/i.test(navigator.userAgent) || navigator.platform.indexOf('Mac') > -1) {//positiong in logic is important
            physDevice = "Desktop";
            formFactor = 'Large';
            deviceType = "Desktop"
        } else if (/Tablet/i.test(navigator.userAgent)) {
            if (/android/i.test(navigator.userAgent)) {
                physDevice = 'Android';
            } else {
                physDevice = 'Tablet';
            }
            formFactor = 'Medium';
            deviceType = "Tablet"
        } else {
            physDevice = "unknown" //cannot query string
            formFactor = 'Large';
            deviceType = "Desktop"
        }
       
        device.hardware.make = physDevice;
        device.hardware.type = deviceType;
        device.hardware.formFactor = formFactor;
        return physDevice;

        //if (Whitelist.Devices.hasOwnProperty(physDevice.toLowerCase()) && Whitelist.Devices[physDevice.toLowerCase()].isSupported == true) {
        //    device.hardware.make = physDevice;
        //    device.hardware.type = deviceType;
        //    device.hardware.formFactor = formFactor;
           
        //    return physDevice;
        //} else {
            
        //    device.hardware.make = "Desktop";
        //    device.hardware.model = "Desktop";
        //    device.hardware.type = "Desktop"
        //    device.hardware.formFactor = "Large";
        //    return 'unknown'
        //}

    }

    var deviceInfoView = Backbone.View.extend({

    });
    function whichIPhone() {

        if (window.screen.height == (960 / 2)) {
            return 'iphone4'
        } else if (window.screen.height == (1136 / 2)) {
            return 'iPhone5'
        }
        else if (window.screen.height == (1334 / 2)) {
            return 'iPhone6'
        }
        else if (window.screen.height == (2208 / 2)) {
            return 'iPhone6plus'
        }
        else {
             return {
                    type: 'windows', name: 'windows'
                }
        }
    }

    function whichWindows() {
        if (/NT 5.1/i.test(navigator.userAgent)) {
            return { type: 'windowsXP', name: 'Windows XP' }
        } else if (/NT 6.0/i.test(navigator.userAgent)) {
            return 'Windows Vista'
            return { type: 'windowsVista', name: 'Windows Vista' }
        } else if (/NT 6.1/i.test(navigator.userAgent)) {
            return { type: 'windows7', name: 'Windows 7' }
        } else if (/NT 6.2/i.test(navigator.userAgent)) {
            return { type: 'windows7', name: 'Windows 7' }
        } else if (/NT 6.3/i.test(navigator.userAgent)) {
            return { type: 'windows8', name: 'Windows 8' }
        }
            return { type: 'windowsGeneric', name: 'Windows'
        }
    }

    function whichIOS() {
        if (/(iphone|ipod|ipad).* os 8_/.test(navigator.userAgent)) {
            return { name: 'ios 8', type: 'ios', version: '8' }
        } else {
            return { name: 'ios', type: 'ios', version: 'unknown' }
        }

    }

    function WhichAndroidOS() {
         return  navigator.userAgent.match(Android ('\d+(?:\.\d)\i'))
    }


    function isSupported() {

    }

    function browser(whitelist) {

        var browserInfo = function () {
            var temp,
            bt = navigator.userAgent.match(/(chrome|firefox|safari|msie|opera|trident(?=\/))\/?\s*(\d+)/i) || [];
            if (bt[1] === 'Chrome') {
                temp = navigator.userAgent.match(/\bOPR\/(\d+)/);
                if (temp != null) return { name: 'opera', version: temp[1] }
            }
            if (/trident/i.test(bt[1])) {
                temp = /\brv[ :]+(\d+)/g.exec(navigator.userAgent) || [];
                return { name: 'ie', version: (temp[1] || '') }
            }
            bt = bt[2] ? [bt[1], bt[2]] : [navigator.appName, navigator.appVersion, '-?'];
            if ((temp = navigator.userAgent.match(/version\/(\d+)/i)) != null) {
                bt.splice(1, 1, temp[1]);
            }
            return {
                name: bt[0].toLowerCase(),
                version: bt[1].toLowerCase()
            }

        }

        if (Whitelist.Browsers.hasOwnProperty(browserInfo().name) && Whitelist.Browsers[browserInfo().name].isSupported == true) {
            device.browser.type = browserInfo().name;
            device.browser.name = browserInfo().name;
            device.browser.version = browserInfo().version;
            return browserInfo().name;
        } else {
            device.browser.type = "unknown";
            device.browser.name = "unknown";
            device.browser.version = "unknown";
            return "unknown"
        }
    }

    return deviceUtils = {
        physicalDevice: physicalDevice,
        operatingSystem: operatingSystem,
        browser: browser,
        load: init,
        info: device
    }

});

