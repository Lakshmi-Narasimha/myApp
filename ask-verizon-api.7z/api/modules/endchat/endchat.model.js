var endChatModelConfig = {
    response: {
        "sessionOver": false,
        "Page": {
            "pageType": "livechat",
            "parentPageType": "myData",
            "engagementID": "-2376958956590268469",
            "customerID": "-2376958956590543256",
            "surveyUrl": "https://app.keysurvey.com/f/1011097/56e5/?LQID=1&BRName=MobileApp-MVTrans&custID=-2376958956590543256&agentID=4594496532@verizon&chatID=-2376958956590268469&busUnitID=19000866&agentGroupID=10004687&clientID=10004593",
            "callType": "getMessage",
            "showChatHistory": false,
            "agentBusy": false
        },
        "ResponseInfo": {
            "locale": "en",
            "requestId": "8da766fd-e3c2-477b-989f-80d1802817fc",
            "buildNumber": "198",
            "code": "00000",
            "type": "Success"
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 20000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "requestId": "8da766fd-e3c2-477b-989f-80d1802817fc",
                    "buildNumber": "198",
                    "code": "00000",
                    "type": "Success"
                },
                "msgList": [{
                    "messageList": [{
                        "nextmsgId": 20001,
                        "loginReq": false,
                        "messageText": "Thank you for chatting with Verizon Wireless"
                    }],
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "type": "header",
                    "msgId": 20000,
                    "messageType": "stateChange",
                    "state": "closed"
                }, {
                    "sequenceNumberInt": 20000,
                    "msgId": 20001,
                    "animationDuration": 800,
                    "type": "bot",
                    "messageList": [{
                        "nextmsgId": 20002,
                        "loginReq": false,
                        "messageText": "Let me know if you need anything else. I'm always here for you."
                    }]
                }, {
                    "type": "link",
                    "msgId": 20002,
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "messageList": [{
                        "messageText": "Hey MzSherri, did Charlie help you out? <a> Take a survey </a>",
                        "nextmsgId": -1,
                        "loginReq": false,
                        "ButtonMap": {
                            "FeedLink": {
                                "browserUrl": "https://app.keysurvey.com/f/1011097/56e5/?LQID=1&BRName=MobileApp-MVTrans&custID=-2376958956590543256&agentID=4594496532@verizon&chatID=-2376958956590268469&busUnitID=19000866&agentGroupID=10004687&clientID=10004593",
                                "pageType": "Chat Survey",
                                "actionType": "openURL",
                                "presentationStyle": "push",
                                "tryToReplaceFirst": false,
                                "disableAction": false
                            }
                        }
                    }]
                }, {
                    "type": "bot",
                    "msgId": 20001,
                    "sequenceNumberInt": 20000,
                    "animationDuration": 800,
                    "messageList": [{
                        "messageText": "Let me know if you need anything else. I'm always here for you.",
                        "nextmsgId": 20002,
                        "loginReq": false
                    }]
                }]
            }
        }
    }
};

module.exports = endChatModelConfig;
