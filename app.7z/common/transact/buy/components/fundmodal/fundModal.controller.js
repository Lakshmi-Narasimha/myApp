/**
 * @ngdoc property
 * @name FundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function fundModalController($scope, $uibModalStack, eventConstants) {
    /*$scope.$on(eventConstants.SHOW_SEARCH_RESULT, function(event, data){

        $scope.searchOption = data.searchOption;
        $scope.data = subscriptionDetailsModel.getSubscriptionDetails();
        $scope.multiSelectOptions = [];
        if(data.searchOption === 'Folios'){
            
            for(var i in $scope.data.subscriptions.folioNumbers){
                if($scope.data.subscriptions.folioNumbers[i].toString().search(data.searchText.toString()) != -1){
                    var lable = {'lable' : $scope.data.subscriptions.folioNumbers[i]};
                    $scope.multiSelectOptions.push(lable);   
                }
            }
        }else if(data.searchOption === 'Accounts'){
            
            for(var i in $scope.data.subscriptions.accountNumbers){
                if($scope.data.subscriptions.accountNumbers[i].toString().search(data.searchText.toString()) != -1){
                    var lable = {'lable' : $scope.data.subscriptions.accountNumbers[i]};
                    $scope.multiSelectOptions.push(lable);
                }
            }
        }else if(data.searchOption === 'All Funds'){
            
            for(var i in $scope.data.subscriptions.allFunds){
                if($scope.data.subscriptions.allFunds[i].toString().toUpperCase().search(data.searchText.toString().toUpperCase()) != -1){
                    var lable = {'lable' : $scope.data.subscriptions.allFunds[i]};
                    $scope.multiSelectOptions.push(lable);
                }
            }
        }
        
        $scope.$broadcast('emittingChannelSearchOption',$scope.searchOption);
    });*/
    
    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
}


fundModalController.$inject = ['$scope', '$uibModalStack', 'eventConstants'];

module.exports = fundModalController;