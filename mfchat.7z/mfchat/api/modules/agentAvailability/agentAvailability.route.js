var express = require('express');
var https = require('https');

var router = express.Router();
var agentAvailabilityModel = require('./agentAvailability.model');

// api route
router.route('/mfchat/rest/agent')
    .post(function(req, res) {

        req.uri = agentAvailabilityModel.createRequestUri[req.body.RequestParams.agentGroupID];
        //req.uri = agentAvailabilityModel.createRequestUri.Billing;

        // if(req.body.RequestParams.agentGroupID === "Billing"){
        //   req.uri = agentAvailabilityModel.createRequestUri.Billing;
        // }else if(req.body.RequestParams.agentGroupID === "WirelessSales"){
        //     req.uri = agentAvailabilityModel.createRequestUri.WirelessSales;
        // }else if(req.body.RequestParams.agentGroupID === "Device"){
        //     req.uri = agentAvailabilityModel.createRequestUri.Device;
        // }else if(req.body.RequestParams.agentGroupID === "Global"){
        //     req.uri = agentAvailabilityModel.createRequestUri.Global;
        // }else if(req.body.RequestParams.agentGroupID === "MVTrans"){
        //     req.uri = agentAvailabilityModel.createRequestUri.MVTrans;
        // }

        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path,
                headers: {
                    'Cookie': req.sessionCookie
                }
            },

            function(proxyResponse) {
                console.log(req.uri.path);
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    chunk = JSON.parse(chunk);
                    agentAvailabilityModel.response.Page.availability = chunk.availability;
                    if (agentAvailabilityModel.response.Page.availability === true) {
                        agentAvailabilityModel.response.Page.inHOP = true;
                        agentAvailabilityModel.response.Page.status = "online";
                    } else {
                        agentAvailabilityModel.response.Page.inHOP = chunk.inHOP;
                        agentAvailabilityModel.response.Page.status = chunk.status;
                    }
                    res.send(agentAvailabilityModel.response);
                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
