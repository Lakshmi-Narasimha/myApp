﻿define([
        'jquery',
        'underscore',
        'backbone',
        'spinner',
        'services/dataservice',
        'appmodules/hoc/hoccommon',
        'appcommon/analytics',
        'errorLog',
        'appmodules/hoc/app/js/model/model-hoc',
        'appmodules/hoc/app/data/hoc-matrix',
        'appcommon/globalcontext',
        'text!appmodules/hoc/app/templates/hocgeneral.html'
], function ($, _, Backbone, Spinner, DataService, hocCommon, Analytics, ErrorLog,HOCModel,HOCMatrix,GlobalContext, hocGeneralTemplate) {
    var hocServiceView = Backbone.View.extend({});
    return hocServiceView;
});