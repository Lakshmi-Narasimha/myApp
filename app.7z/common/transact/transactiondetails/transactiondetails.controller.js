/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function txnDetailsController($scope, fticLoggerMessage, loggerConstants, transactModel, $state) {
    console.info("txnDetails Controller!!");
    var invDetails = transactModel.getTransactDetails() ? transactModel.getTransactDetails().investorDetails : "";
    var fundDetails = transactModel.getTransactDetails() ? transactModel.getTransactDetails().fundDetails : "";
    $scope.fromBuy = transactModel.getIsBuy();
    $scope.fromSIP = transactModel.getIsSip();
    $scope.sipTransactionHeading = transactModel.getSipTransactionHeading();
    $scope.transDetls = [];
    $scope.transactHeading = {
        heading : 'Transaction Details'
    };
    if($scope.fromBuy){

         $scope.investorObj= [
          {
            text: "Folio No", 
            value : invDetails.folioId
          },
          {
            text: "First Holder Name",
            value: invDetails.custName
          },
          {
            text : "PAN/PEKRN",
            value: invDetails.pan
          }
        ];
    
    }else if($scope.fromSIP){
      $scope.investorObj= [
          {
            text: "Folio No", 
            value : invDetails.folioId
          },
          {
            text: "First Holder Name",
            value: invDetails.custName
          },
          {
            text : "PAN/PEKRN",
            value: invDetails.pan
          },                   
          {
              text: "E-Mail",
              value: invDetails.emailId
          },            
          {
              text: "Mobile",
              value: invDetails.mobile
          },            
          {
              text: "Second Holder Name",
              value: (invDetails.holders.length>1)?invDetails.holders[1].name : "NA" //invDetails.holders[1].name
          },            
          {
              text: "Third Holder name",
              value: (invDetails.holders.length>2)?invDetails.holders[2].name : "NA" //invDetails.holders[2].name
          }
        ];

    }
    else{
         $scope.investorObj= [
          {
            text: "First Holder Name",
            value: invDetails.custName
          }
        ];
    }
    /*$scope.investorObj= [
      {
        text: "First Holder Name",
        value: invDetails.custName
      }
    ];*/
    
    
    console.log("Current state is: ", $state);

    $scope.presentState = $state.current.name;

    $scope.isModifySipState = false;
    if($scope.presentState === 'transact.txnDetails.modifysip') {
        $scope.isModifySipState = true;
    } else{
        $scope.isModifySipState = false;
        $scope.advisorDetails = [
        {
            key: "advisorARN",
            text: "Advisor ARN",
            value: transactModel.getAdvDetails() ? transactModel.getAdvDetails().code : ""
        },
        {
            key: "transactionRefNo",
            text: "Transaction Reference No.",
            value: transactModel.getAdvDetails() ? transactModel.getAdvDetails().transactionRefNo : ""
        },
        {
            key: "requestDateTime",
            text: "Request Date and Time ",
            value: transactModel.getAdvDetails() ? transactModel.getAdvDetails().transDateTime : ""
        }
        
    ]
    }
    
    var stateUrl = $state.current.url;
    $scope.showGridFundDetails = true;

    if(stateUrl == "/buy" || stateUrl == "/sip" || stateUrl == "/modifySipState") {
        $scope.showGridFundDetails = false;
    };

    $scope.fundObj=[];
    $scope.fundObj = [
              {
                text: "Folio No.",
                value: invDetails.folioId
              },
              {
                text: "Account No.",
                value: fundDetails.tschvalAccno
              },            
              {
                text: "Source Fund",
                value: fundDetails.fmDescription
              }
        ];
    
    console.info("TXN Details...");
}

txnDetailsController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'transactModel', '$state'];
module.exports = txnDetailsController;