define([ 
         'jquery',
         'moment',
         'appcommon/commonutility',
         'appcommon/globalcontext',
         'config',
         'appmodules/eSig/app/js/utils'
         ],function($,Moment,Utility,GlobalContext, Config, eSigUtils){
	
	var AuditModule = (function(){
	    "use strict"
	    var auditInstance;
		function audit(){
			var _self = this,auditObj={};
			
			this.initialise = function(){
				auditObj.docid = null;
				auditObj.actorNm = $(".afinav-obo-user").text().trim();
				//auditObj.actorId = Utility.readCookie('FMID');
				auditObj.actorId = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID; // Updated for including both advisor & OBO Id
				auditObj.actorContextCd = "DMU";
				auditObj.eventId = null;
				auditObj.pageName = null;
				auditObj.signerId = null;
				auditObj.signerName = null;
				//auditObj.eventDescription = null;
				auditObj.time = null;
			};
			
			this.sendAudit = function (asynflag,navigatingAway) {
			    var data = {}, url, _contentType,urlLocation;
			    urlLocation = window.location.hash.match(/eSig/i); /*Only send this service when user is in esig page*/
			    if(!navigatingAway){
			    	if (urlLocation == null || !auditObj.docid || auditObj.docid == null) {
				        return;
				    }
			    }
			    url = Config.eSigConfig.serviceUrl + "EsigDoc(docid=" + auditObj.docid + ")/logAuditInfo";
				_contentType = "application/x-www-form-urlencoded";
				asynflag = (asynflag != undefined) ? asynflag : true;

				data.docid = auditObj.docid;
				data.actorNm = auditObj.actorNm;
				data.actorId = auditObj.actorId;
				data.actorContextCd = auditObj.actorContextCd;
				data.eventId = auditObj.eventId;
				data.time = Moment(new Date()).format("YYYY-MM-DD HH:mm:ss.SSS");
				if (auditObj.signerId && auditObj.signerId != null && auditObj.signerId != "") {
				    data.eventDescription = auditObj.signerId + "," + auditObj.signerName+","+auditObj.pageName;
				} else {
				    data.eventDescription = auditObj.pageName;
				}

				
			    //auditObj.eventDescription = null;
				

				//auditObj.docid = params.docid;
				//auditObj.eventId = params.eventId;
				//auditObj.eventDescription = params.eventDescription;
				//auditObj.time = Moment(new Date()).format("YYYY-MM-DD HH:mm:ss.SSS");
				eSigUtils.post(url, data, auditSuccess, auditFailed, null, null, _contentType,asynflag);
				
			};

			this.setAuditLogParams = function (params) {
			    if (params instanceof Object) {
			        var keys = Object.keys(params),i;
			        for (i = 0; i < keys.length; i++) {
			            if (auditObj.hasOwnProperty([keys[i]])) {
			                auditObj[keys[i]] = params[keys[i]];
			            }
			        }
			    }
			};

			this.logBrowserClose = function(isAsync,navigatingAway) {
			    var _self = this;
			    _self.setAuditLogParams({
			        "eventId": 105,
			        "signerId":null,
			        "signerName":null
			    });
			    isAsync = (isAsync != undefined) ? isAsync : true;
			    navigatingAway = (navigatingAway != undefined) ? navigatingAway : false;
			    _self.sendAudit(isAsync,navigatingAway);
			
			};

			this.initialiseBrowserClose = function () {
			    var _self = this;
			    //$(window).off("unload", test).on("unload", test);
			    $(window).on('beforeunload', function () {
			    	_self.logBrowserClose.call(_self); /*need to make a synchronous call here*/
			        /* Without this return the ajax call is not hitting the server */
			        //return "";
			    });
			};


			function auditSuccess(response){
				console.log("audit service successful");
			};
			
			function auditFailed(response){
				console.log("audit service failed");
			};
		};
		if (!auditInstance) {
		    auditInstance = new audit();
		}
		return auditInstance;
	})();
	
	return AuditModule;
})