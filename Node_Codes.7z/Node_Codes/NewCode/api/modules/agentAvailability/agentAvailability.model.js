var config = require('/app/conf/properties/mfchatnode/config');

var agentAvailabilityModelConfig = {
    response: {
        "ModuleMap": {
            "Support": {
                "msgList": [

                ],
                "startMsgId": 20000,
                "searchStartIndex": 20000,
                "ResponseInfo": {
                    "locale": "en",
                    "userMessage": "An expert will join you shortly",
                    "code": "00000",
                    "messageStyle": "TopPersistent",
                    "message": "Waiting for live chat",
                    "topMessage": "Your live chat will start soon",
                    "buildNumber": "207",
                    "type": "ChatTop",
                    "requestId": "f01926d1-db5f-4035-84d7-2c7eeb4ecd0f",
                    "buttonTitle": "View"
                }
            }
        },
        "Page": {
            "status": "online",
            "pageType": "livechat",
            "parentPageType": "myData",
            "availability": "true",
            "inHOP": "true",
            "callType": "agent",
            "timeToWait": "5",
            "showChatHistory": false,
            "agentBusy": false
        },
        "sessionOver": false,
        "ResponseInfo": {
            "locale": "en",
            "buildNumber": "207",
            "code": "00000",
            "requestId": "9afe0b3f-a232-47df-80bf-b9f8e68de25e",
            "type": "Success"
        }
    },
    msgList: [
        {
          "type": "bot",
          "msgId": 20000,
          "sequenceNumberInt": 20000,
          "animationDuration": 800,
          "messageList": [
            {
              "messageText": "All agents are busy now, please try again later.",
              "nextmsgId": -1,
              "loginReq": false
            }
          ]
        }
      ],     
    createRequestUri: {
        Billing: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Billing,
        },
        WirelessSales: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessSales + '&agentGroupID=' + config.AG_WirelessSales,
        },
        Device: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Device,
        },
        Global: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Global,
        },
        MVTrans: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_MVTrans,
        },
        Billing_EMP: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_Billing_EMP,
        },        
        Device_EMP: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_Device_EMP,
        },
        Global_EMP: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_Global_EMP,
        },
        MVTrans_EMP: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare_EMP + '&agentGroupID=' + config.AG_MVTrans_EMP,
        },
        Test: {
            host: config.TC_SERVER_NAME,
            path: config.TC_AGENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Test,
        },
    }
};

module.exports = agentAvailabilityModelConfig;
