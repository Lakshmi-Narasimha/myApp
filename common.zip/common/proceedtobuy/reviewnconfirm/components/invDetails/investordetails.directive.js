/**
 * @ngdoc property
 * @name investordetails Directive
 * @description
 *
 * investordetails - Displays the Review & Confirm - Select Investor Details
 *
 **/
'use strict';

var investordetails = function(transactModel, eventConstants, paperlessModel, fticPBInvestorDetailsFactory, $cookies) {    
	return {
        template: require('./investordetails.html'),
        restrict: 'EA',
        replace: true,
        scope:{

        },
        controller:['$scope', function($scope){            

            var invDetails = transactModel.getInvestorDetails();
            var _userType = $cookies.get('userType');
            var secondHolderDetail = (invDetails.holders.length>1)?invDetails.holders[1].name : 'NA'; 
            var thirdHolderDetail =  (invDetails.holders.length>2)?invDetails.holders[2].name : 'NA';
            if(transactModel.isPaperless){
                var jointHolderDetails = paperlessModel.invDetails.getHolderDetails();
                secondHolderDetail = (jointHolderDetails && jointHolderDetails.length>0)?jointHolderDetails[0].fullName:'NA';
                thirdHolderDetail =  (jointHolderDetails && jointHolderDetails.length>1)?jointHolderDetails[1].fullName:'NA';
            }

            $scope.investorObj = fticPBInvestorDetailsFactory.getFormattedInvestorDetails(_userType, invDetails, secondHolderDetail, thirdHolderDetail);
            
        }]
    };
};

investordetails.$inject = ['transactModel', 'eventConstants','paperlessModel', 'fticPBInvestorDetailsFactory', '$cookies'];
module.exports = investordetails;