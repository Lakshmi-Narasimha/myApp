/**
 * @ngdoc directive
 * @name fticCustomNgChange
 * @requires $scope
 * @description
 *
 * - fticCustomNgChange will fire the change event in case of invalid forms as well.
 * 
 *
 **/
'use strict';

var customNgChange = function() {
	return {            
            restrict: 'A',
            replace: true,
            scope: {
                onchange:'&customNgChange'    
            },
            link:function(scope, element, attrs){
                element.on('input',function(){
                    scope.onchange();
                });
            }
        };
};

customNgChange.$inject = ['$timeout', 'eventConstants'];
module.exports = customNgChange;