import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import 'rxjs/add/operator/map'

import { AIAssistCacheService } from './aiassistcache.service';
import { User } from '../_models/user';

@Injectable()
export class AuthenticationService {

    activeUser: User;

    activeUserObserver: Observer<any>;
    activerUserObservable: Observable<any>;
    rootPath: string;

    constructor(private http: Http, private aiAssistCacheService: AIAssistCacheService) {
      this.subscribeForServices();
    }

    subscribeForServices() {
      this.aiAssistCacheService.rootPathObservable.subscribe((data) => {
        this.rootPath = data;
      });
    }

    login(userName: string, password: string, client: string) {
      this.activeUser = new User();
      this.activeUser.userName = userName;
      this.aiAssistCacheService.currentUser = this.activeUser;

      if (!this.rootPath)
        this.rootPath = this.aiAssistCacheService.getRootPath();
      if (localStorage.getItem('currentUser')) {
        this.logout();
      }

        return this.http.post(this.rootPath + 'config/login', JSON.stringify({ userName: userName, secretKey: password, client: client }), { withCredentials: true })
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                 let serverResponse = response.json();
                if (serverResponse && serverResponse.statusCode == 0) {
                  this.activeUser.isAdmin = serverResponse.isAdmin == 'Y' ? true:false;
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(this.activeUser));

                    this.aiAssistCacheService.updateCurrentUser(this.activeUser);
                } else {
                  throw new Error(serverResponse.statusMessage);
                }
            });
    }

    logout() {

      if (!this.rootPath)
        this.rootPath = this.aiAssistCacheService.getRootPath();

        return this.http.post(this.rootPath + 'config/logout',"{}")
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                 let serverResponse = response.json();
                if (serverResponse && serverResponse.statusCode == 0) {
                  // remove user from local storage to log user out
                  localStorage.removeItem('currentUser');
                  this.aiAssistCacheService.updateCurrentUser(null);
                  //this.aiAssistCacheService.currentUser = null;
                  this.activeUser = null;
                } else if(serverResponse && serverResponse.statusMessage == 'Authentication required.') {
                  // remove user from local storage to log user out
                  localStorage.removeItem('currentUser');
                  this.aiAssistCacheService.updateCurrentUser(null);
                  //this.aiAssistCacheService.currentUser = null;
                  this.activeUser = null;
                  this.aiAssistCacheService.navigateToLoginPage();
                } else {
                  throw new Error(serverResponse.statusMessage);
                }
            });

        // remove user from local storage to log user out
        // localStorage.removeItem('currentUser');
        // this.aiAssistCacheService.updateCurrentUser(null);
        // //this.aiAssistCacheService.currentUser = null;
        // this.activeUser = null;
    }
}
