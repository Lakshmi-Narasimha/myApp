/**
 * @ngdoc directive
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires investorEventConstants
 * @requires investorDashboardDetailsModel
 * @requires dashboardConstants
 * @requires $filter
 * @description
 *
 * - It displays active sips and investments once user has invested.
 * 
 **/
'use strict';

var invDbMySips = function(investorEventConstants, investorDashboardDetailsModel, dashboardConstants, $filter, loggerConstants, fticLoggerMessage) {
    return {
        restrict: 'AEC',
        template: require('./invDbMySips.html'),
        replace: true,
        scope: true,
        controller: function($scope) {
            $scope.mySipsConfig = {
                heading: dashboardConstants.dashboard.MY_SIPS,
                investmentsData: [],
                hasInvested: false,
                widgetClose: false,
                sipsBadge: false,
                description: null,
                sipsObj: {}
            };

            $scope.$on(investorEventConstants.Dashboard.INV_DB_INFO, function() {
                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_MY_SIPS_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_INFO + ' event' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
                $scope.isDataAvaiable = investorDashboardDetailsModel.getDashboardData() ? investorDashboardDetailsModel.getDashboardData().mySips : false;

                if ($scope.isDataAvaiable) {
                    var sipsObject = investorDashboardDetailsModel.getDashboardData().mySips;
                    angular.merge($scope.mySipsConfig, sipsObject);
                    $scope.mySipsConfig.hasInvested = sipsObject && sipsObject.hasInvested && angular.lowercase(sipsObject.hasInvested) === 'y';

                    $scope.mySipsConfig.hasInvested = !$scope.mySipsConfig.hasInvested ? sipsObject && sipsObject.totalActiveSips && (sipsObject.totalActiveSips > 0) : $scope.mySipsConfig.hasInvested;

                    $scope.mySipsConfig.investmentsData = [
                        { value: sipsObject.monthlyInvestments, key: dashboardConstants.dashboard.MONTHLY_INVESTMENTS },
                        { value: sipsObject.quarterlyInvestments, key: dashboardConstants.dashboard.QUARTERLY_INVESTMENTS },
                        { value: sipsObject.annualInvestments, key: dashboardConstants.dashboard.ANNUAL_INVESTMENTS }
                    ];

                    $scope.mySipsConfig.sipsObj.prop1 = $filter('fticInvFormatTwoDigitNum')(sipsObject.totalActiveSips);
                    $scope.mySipsConfig.sipsObj.colorClass = 'tile-white';
                    $scope.mySipsConfig.sipsObj.lable = dashboardConstants.dashboard.ACTIVE_SIPS;
                }
            });
        }
    };

};

invDbMySips.$inject = ['investorEventConstants', 'investorDashboardDetailsModel', 'dashboardConstants', '$filter', 'loggerConstants', 'fticLoggerMessage'];
module.exports = invDbMySips;
