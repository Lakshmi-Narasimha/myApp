define(
        ['jquery', 'underscore', 'backbone', 'backbonesubroute', 'backboneRelational',
            'appcommon/memmorymgr', 'appcommon/globalcontext',
            'appmodules/ncst/app/js/views/view-ncst-container',
            'appmodules/ncst/app/js/ncst-main',
            'appmodules/ncst/app/js/lib/validate-4.2',
            'appmodules/ncst/app/js/utils', 'config',
            'services/dataservice', 'appmodules/ncst/app/js/models/model-new-client', 'appmodules/ncst/app/js/models/model-address-entry',
            'appmodules/ncst/app/js/models/model-client-details', 'appcommon/commonutility', 'appmodules/ncst/app/js/views/view-initial-draft-list', 'services/dataservice', 'errorLog'],
        function ($, _, Backbone, backbonesubroute, backboneRelational, MemmoryMgr, GlobalContext,
                NcstContainerView, NcstMain, Validator, Utils, Config,
                Dataservice, NewClientModel, AddressModel, ClientDetailsModel, CommonUtilis, DraftListView, DataService, ErrorLog) {
            var history = [], ebixBaseUrl = Config.ebixServiceName, awmsUrl = Config.odataServiceName, queryString = GlobalContext
                    .getInstance().getGlobalContext().Context.QueryString, firstLoad = true, serverDown = false;
            var ViewClientInfo, ViewAddressEntry, ViewAddressValidation, ViewClientDetails, ViewEmployment, ViewIncome, ViewVerification, ViewConfirmation;
            var self = undefined, _lastLaunchTime = undefined, _currentLaunchTime = undefined, draftListView = null, advisorID = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID;
            var ncstRouter = Backbone.SubRoute
                    .extend({
                        routes: {
                            'client-info': 'showClientInfoScreen',
                            'address-entry': 'showAddressEntryScreen',
                            'address-validation': 'showValidationScreen',
                            'client-details': 'showClientDetailsScreen',
                            'employment': 'showEmploymentScreen',
                            'income': 'showIncomeScreen',
                            'verification': 'showVerificationScreen',
                            'confirmation': 'showConfirmationScreen',
                            //'navlanding' : 'getContextfromNav',
                            '*path': 'defaultACtion'
                        },
                        initialize: function () {
                        	//initialize the currency formatter
                            String.prototype.formatCurrency = function (n, x) {
                        	    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
                        	    return this.replace(new RegExp(re, 'g'), '$&,');
                        	};
                            Number.prototype.formatCurrency = function (n, x) {
                        	    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
                        	    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
                        	};
                        	self = this;
                            this.on("route", handleRouteNavigation);
                            // $('.ncst-header').addClass('external-launch').removeClass('initial-hidden');
                            $('.initial-hidden').removeClass(
                                    'hidden initial-hidden');
                            // function launchApplication(e) {
                            // }
                        },
                        getUrlContext: function (_url) {
                            var regex = /[?&]([^=#]+)=([^&#]*)/g, url = window.location.href, params = {}, match;
                            if (_url) {
                            	url = _url;
                            }
                            while (match = regex.exec(url)) {
                                params[match[1]] = match[2];
                            }
                            return params;
                        },
                        defaultACtion: function (route, route1) {
                            var _self= this, _loggedInUserFMID = CommonUtilis.readCookie("FMID"), _advisorId = GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID,
                                _oboSellInd = null, _loggedInUserSellInd = null, _isOBOUser = _loggedInUserFMID != _advisorId, _afaPstnCD = "76";
                            if (_currentLaunchTime != undefined) {
                        		_lastLaunchTime = _currentLaunchTime;
                        	}
                        	_currentLaunchTime = new Date().getTime();
                            setTimeout(function () {
                        		_lastLaunchTime = undefined, _currentLaunchTime = undefined;
                        	}, 1000);
                            if (_currentLaunchTime - _lastLaunchTime > 0) {
                        		return;
                        	}
                        	
                            var API_COMMON_DATA_BODY = Utils.getConfigProperty('API_COMMON_DATA_BODY');
                            var _ebixresp = null;
                            firstLoad = true;
                            var _id = null, _fmId = null;
                            var _serviceCounter = 0, _errorCounter = 0, _advisorName = "";
                            var _urlContext = this.getUrlContext();
                            var _globalContxt = GlobalContext.getInstance();
                            Utils.lockForm();
                            var _context = _globalContxt.getGlobalContext().Context;
                            requirejs(['appmodules/ncst/app/js/models/model-client-info',
                                'appmodules/ncst/app/js/models/model-address-entry',
                                'appmodules/ncst/app/js/models/model-details',
                                'appmodules/ncst/app/js/models/model-emloyment',
                                'appmodules/ncst/app/js/models/model-income-investment',
                                'appmodules/ncst/app/js/models/model-client-details',
                                'components/js/model/EmpCompModel',], function (
                                    ClientInfoModel,
                                    AddressModel,
                                    DetailsModel, 
                                    employmentModel,
                                    incomeModel,
                                    clientDetailsModel,
                                    EmpCompModel
                                    ) {

                                    requirejs(["appmodules/ncst/app/js/models/model-client"], function (ClientModel) {
                                        requirejs(
                                                ['appmodules/ncst/app/js/views/view-client-info',
                                                    'appmodules/ncst/app/js/views/view-address-entry', 'appmodules/ncst/app/js/views/view-address-validation', 'appmodules/ncst/app/js/views/view-client-details',
                                                    'appmodules/ncst/app/js/views/view-employment', 'appmodules/ncst/app/js/views/view-income-investment', 'appmodules/ncst/app/js/views/view-verification', 'appmodules/ncst/app/js/views/view-confirmation'],
                                                function (viewClientInfo, viewAddressEntry, viewAddressvalidation, viewClientDetails, viewEmployment, viewIncome, viewVerification, viewConfirmation) {
                                                	ViewClientInfo = viewClientInfo;
                                                    ViewAddressEntry = viewAddressEntry;
                                                    ViewAddressValidation = viewAddressvalidation;
                                                    ViewClientDetails = viewClientDetails;
                                                    ViewEmployment = viewEmployment;
                                                    ViewIncome = viewIncome;
                                                    ViewVerification = viewVerification;
                                                    ViewConfirmation = viewConfirmation;
                                                    var ncstContainerView = undefined;
                                                    Utils.lockForm();
                                                    loadContainerView();
                                                    getAdvisorDetails();
                                                    ClientModel.set({
                                                        'advisorNumber': null,
                                                        'prePopulatedAdvisorNumber': null,
                                                        'servicingAdvisorNumber': null,
                                                        'prepopulatedSA': null,
                                                        'isAACUser': false,
                                                        'isAFAuser': false,
                                                        'sellInd': "No",
                                                        "isUserAAC":false
                                                    });
                                                    function getAdvisorDetails() {
                                                    	 // if the mode is stand alone get the advisor name
                                                        if (_context.IsStandalone == true) {
                                                            var asyncCalls = [];
                                                            asyncCalls[0] = Dataservice.getAdvisorInfo();
                                                            Utils.lockForm();
                                                            Q.allSettled(asyncCalls).then(function (response) {
                                                                        if (response[0]['value']) {
                                                                            var _oboModel = response[0]['value'].toJSON();
                                                                            if (_oboModel.length > 0) {
                                                                                _advisorName = _oboModel[0].name;
                                                                                $('#advisor-name').text(_advisorName);
                                                                            }
                                                                        }
                                                                        checkAdvisorEligibity();
                                                                    }).fail(function () {
                                                                      //continue with the applciation 
                                                                        checkAdvisorEligibity();
                                                                    });
                                                        } else {
                                                            Utils.lockForm();
                                                            checkAdvisorEligibity();
                                                        }
                                                    }
                                                    function doInitialCheck() {
                                                    	 try {
                                                             // check the launch point if the url has context
                                                             // id add a CSS class to container to
                                                             // differentiate from normal launch
                                                             //Code for passthrough NCST for testing
                                             			   var _options = {};
                                             			   _options.decode = true;
                                                             var _queryParams = Utils.getUrlParams();
                                                             if (_queryParams && _queryParams['override'] && _queryParams['override'] == "downtime") {
                                                             	checkAndLoadDrafts();
                                                             }
                                                            else {
                                                             	/************** SERVER OUTAGE CHECK **********/
                                                                var _url, _dummyPayLoad;
                                                                 _url = awmsUrl + 'validateEmailAddress?$format=json';
                                                                 _dummyPayLoad = "Test123@domain.com"
                                                                 Utils.lockForm();
                                                                 Utils.post(_url, JSON.stringify({ "emlAddr": _dummyPayLoad }),
                                                                        checkServerTime, function (request, textStatus, errorThrown) {
                                                                             checkServerTime(errorThrown, textStatus, request);
                                                                         }, 0);

                                                                 function checkServerTime(resp, status, request) {
                                                                     var _servertime;
                                                                     _servertime = request.getResponseHeader("date");
                                                                     serverDown = Utils.checkServerOutage(_servertime);
                                                                     if (serverDown) {
                                                                         console.log("server down");
                                                                         loadClinetInfo();//pass some server outage time
                                                                     } else {
                                                                         console.log("server up");
                                                                         checkAndLoadDrafts();
                                                                     }
                                                                 }

                                                                 /************** SERVER OUTAGE CHECK END**********/
                                                             }
                                                         } catch (e) {
                                                             loadClinetInfo();
                                                         }
                                                    }
                                                    function checkAndLoadDrafts() {
                                                    	var _prospctId = null;
                                                        var _sadConfig = Utils.getConfigProperty('SAD_CONFIG');
                                                        var _header = {
                                               					//fmid: Utils.readCookie('FMID'),
                                               					//ldapGroups: 'CSR,CRS',
                                               					appId: _sadConfig['appId'],
                                               					//guid:1234
                                               			};
                                                    	//call the drafts list service by advisorid if no prospect pinned
                                                    	if (_context.ContactId) {
                                                    		_prospctId = _context.ContactId;
                                                        }
                                                        var _noContextLaunch = CommonUtilis.readCookie('nocontextlaunch');
                                                        if (_noContextLaunch == "true") {
                                                    	   _prospctId = null;
                                                       }
                                                        if (_urlContext['draftID']) {
                                                    	  retrieveDraft(_urlContext['draftID'])
                                                        } else {
                                                    	   fetchDarftList();
                                                       }
                                                      
                                                        function fetchDarftList() {
                                                            var _sadQueryParams = "", _isProspect = false, _queryAdvsr = _context.AdvisorFMID;
                                                            _sadQueryParams = "advisorId=" + _queryAdvsr + "&appName=" + _sadConfig['appName'];
                                                            if (_prospctId) {
                                               				//if prospect retreive draft based on prospectID
                                               				_isProspect = true;
                                                                _sadQueryParams += "&contactId=" + _prospctId;
                                               			}
                                                            DataService.getNCSTDraftsList(_header, _sadQueryParams).done(function (response) {
                                                        	   //prepare list object to render the drafts list
                                                        	   var _drafts = [];
                                                        	   var _templateData = {
                                                                    drafts: [],
                                                                    draftId: null
                                                        	   };
                                                                if (response && response.drafts && response.drafts.length > 0) {
                                                        		   _drafts = response.drafts;
                                                                    if (_isProspect) {
                                                            		 _templateData.draftId = _drafts[0].requestId
                                                                    } else {
                                                            		 _templateData.drafts = _drafts;
                                                            	 }
                                                            	 showDraftsList(_templateData);
                                                                } else {
                                                        		  callServiceAndLoadData();
                                                        	   }
                                                        	   
                                                            }).fail(function () {
                                                           	callServiceAndLoadData();
                                                           });
                                           			
                                                      }
                                                        function showDraftsList(templateData) {
                                                    	   Utils.unlockForm();
                                                    	   MemmoryMgr.clearView(draftListView);
                                                            draftListView = new DraftListView();
                                                            draftListView.renderDraftList(templateData, retrieveDraft, callServiceAndLoadData, draftCancelButtonClickHandler);
                                                       }
                                                        function retrieveDraft(draftID) {
                                                      		Utils.lockForm();
                                                            ClientModel.set('draftID', draftID);
                                                            DataService.retrieveNCSTDraft(_header, draftID).done(loadDraftData).fail(function () {
                                                                  loadClinetInfo();
                                                      		});
                                              		
                                                       }
                                                      
                                                    }
                                                    function loadDraftData(response) {
                                                        var _draftData = response;
                                                    	if (response && typeof response == "string") {
                                                    		_draftData = JSON.parse(response);
                                                    	}
                                                        if (_draftData && _draftData.response) {
                                                    		var _sadData = _draftData.response;
                                                            if (_sadData.clientInfo) {
                                                    			ClientModel.get('clientInfo').set(_sadData.clientInfo);
                                                                if (_sadData.clientInfo.prosId) {
                                                    				_id = _sadData.clientInfo.prosId;
                                                    			}
                                                    		}
                                                            if (_sadData.clientAddress) {
                                                                ClientModel.get('addressEntry').set(_sadData.clientAddress);
                                                            }
                                                            if (_sadData.clientDetails) {
                                                                ClientModel.get('details').set(_sadData.clientDetails);
                                                            }
                                                            if (typeof _sadData.version == "undefined") {
                                                                retreiveEmploymentIncomeInfoFromDraftV1(_sadData);
                                                            } else {
                                                                if (_sadData.clientEmployment) {
                                                                    ClientModel.get('employement').set(_sadData.clientEmployment);
                                                                }
                                                                if (_sadData.clientIncome) {
                                                                    ClientModel.get('income').set(_sadData.clientIncome);
                                                                }
                                                            }
                                                            
                                                            ClientModel.get('clientInfo').set('advisorNumber', _sadData.advisorID ? _sadData.advisorID : '');
                                                            ClientModel.set('advisorNumber', _sadData.advisorID ? _sadData.advisorID : '');
                                                    	}
                                                       
                                                        NewClientModel.set('fromBackbutton', true);
                                                        loadClinetInfo();
                                                    
                                                    }
                                                    function retreiveEmploymentIncomeInfoFromDraftV1(draftData) {
                                                        var clientInfoModel = draftData.clientInfo,
                                                            v1EmpModel = draftData.clientEmployment,
                                                            v1IncomModel = draftData.clientIncome,
                                                            clType = clientInfoModel.clientType;
                                                        converV1ModelToV2Model(v1EmpModel, v1IncomModel, clType);
                                                    }
                                                    function converV1ModelToV2Model(empModelV1, incomeModelV1, clType) {
                                                        var emplymntStatus,
                                                            isEmployed,
                                                            isOfficer,
                                                            v2IncmModel = ClientModel.get('income'),
                                                            v1IncomRequiredFields = _.pick(incomeModelV1, ["incomeFedTax",
                                                                "incomeIndiAnnualNum",
                                                                "incomeIndiLiquidNetNum",
                                                                "incomeIndiNetNum"
                                                            ]),
                                                            v2EmpModel = ClientModel.get('employement'),
                                                            empCompModel;
                                                        v2IncmModel.set(v1IncomRequiredFields);
                                                        if (ClientModel.get("details").get("clientmaritalStatus") == "Unknown") {
                                                            ClientModel.get("details").set("clientmaritalStatus", "");
                                                        }
                                                        if (clType == "P") {
                                                            emplymntStatus = empModelV1.employmentStatusCode;
                                                            isEmployed = empModelV1.isEmployed;
                                                            isOfficer = empModelV1.isClientODSP;
                                                            empCompModel = new EmpCompModel();
                                                            if (emplymntStatus == "A" || emplymntStatus == "B") {
                                                                empCompModel.set({
                                                                    compId: 1,
                                                                    compNm: "employer",
                                                                    employerName: incomeModelV1.employer,
                                                                    addressType: incomeModelV1.empAddressType,
                                                                    address1: incomeModelV1.empAddrLine1,
                                                                    address2: incomeModelV1.empAddrLine2,
                                                                    countryNm: incomeModelV1.IncomeCountryList,
                                                                    countryFullNm: incomeModelV1.IncomeCountryName,
                                                                    city: incomeModelV1.empCity,
                                                                    state: incomeModelV1.IncomeCountryList != "CA" ? incomeModelV1.IncomeStateList : "",
                                                                    stateFullNm: incomeModelV1.IncomeCountryList != "CA" ? incomeModelV1.IncomeStateName : "",
                                                                    province: incomeModelV1.IncomeCountryList == "CA" ? incomeModelV1.IncomeProvinceList : "",
                                                                    provinceFullNm: incomeModelV1.IncomeCountryList == "CA" ? incomeModelV1.IncomeProvinceList : "",
                                                                    zipCode: incomeModelV1.incomeZipCode,
                                                                    primaryOccupation: "",
                                                                    priOccupationOther: "",
                                                                    jobTitle: "",
                                                                    tickerSymbol: "",
                                                                    launchModel: "edit",
                                                                    relatedModelRefId: undefined
                                                                });
                                                            } else {
                                                                empModelV1.employmentStatusCode = "";
                                                                empModelV1.employmentStatus = "";
                                                                if (empModelV1.isEmployed == "Yes") {
                                                                    empModelV1.isEmployed = "";
                                                                }
                                                            }
                                                            v2EmpModel.set("employmentAddrCollection", [empCompModel.toJSON()]);
                                                            v2EmpModel.set(_.pick(empModelV1, ["employmentStatus",
                                                                "employmentStatusCode",
                                                                "isEmployed",
                                                                "isClientODSP"
                                                            ]));
                                                        }
                                                    }
                                                    function callServiceAndLoadData() {
                                                    	 Utils.lockForm();
                                                        // if any id call the ebix service, so increment
                                                        // the service counter by 1
                                                        if (_context.ContactId) {
                                                            _id = _context.ContactId;
                                                            _serviceCounter++;
                                                        }
                                                        var _noContextLaunch = CommonUtilis.readCookie('nocontextlaunch');
                                                        if (_noContextLaunch == "true") {
                                                    	   _id = null;
                                                            if (_context.ContactId) {
                                                    		   _serviceCounter--;
                                                    	   }
                                                       }
                                                        _fmId = Utils.readCookie('FMID');
                                                        //if contact id is there call the ebix service to get the prospect details
                                                        if (_id) {
                                                            var _url = ebixBaseUrl + 'Contact?fmId=' + _fmId + '&contactId=' + _id;
                                                            var _data = $.extend(API_COMMON_DATA_BODY, {});
                                                            Utils.get(_url, decodeURIComponent($.param(_data)), function (response) {
	                                                                        _ebixresp = response;
	                                                                        loadClinetInfo(_ebixresp);
                                                                    	}, 
                                                                    	function (response) { loadClinetInfo(); }
                                                                 , 0);
                                                        } else {
                                                        	loadClinetInfo();
                                                        }
                                                    }
                                                    function finalServiceSuccessHandler() {
                                                        _serviceCounter--;
                                                        //decrement service counter by 1
                                                        //if service counter become 0 load the container view
                                                        if (_serviceCounter == 0) {
                                                            Utils.unlockForm();
                                                            
                                                        }

                                                    }
                                                    function loadClinetInfo(response) {
                                                        CommonUtilis.writeCookie('nocontextlaunch', "false");
                                                    	 Utils.unlockForm();
                                                         //save the Ebix data to model
                                                         if (response) {
                                                             saveProspectDetails(response);
                                                         }
                                                        ClientModel.get('clientInfo').set('prosId', _id);
                                                         ncstContainerView.afterRender();
                                                    }
                                                    function loadContainerView(response) {
                                                    	if (ClientModel.get('newClient')) {
                                                            ClientModel.erase('all');
                                                        } else if (ClientModel.get('newClientWithAddress')) {
                                                            ClientModel.erase('all!address');
                                                        } else {
                                                            ClientModel.erase();
                                                        }
                                                        ncstContainerView = new NcstContainerView();
                                                        Memmorymgr.setcurrentview(ncstContainerView);
                                                        ncstContainerView.render();
                                                    }
                                                    function checkAdvisorEligibity() {
                                                        var _aacPlfmCd = "04", _plfmCd = null;
                                                        Dataservice.getDistributorInfo(_loggedInUserFMID, [401, 404, 500]).then(function(response) {
                                                            var _loggedInUserDistInfo = response[0];
                                                            if (_loggedInUserDistInfo !== undefined && _loggedInUserDistInfo !== null) {
                                                                _loggedInUserSellInd = _loggedInUserDistInfo.sellInd;
                                                                _plfmCd = _loggedInUserDistInfo.plfmCd;
                                                                if (_plfmCd != _aacPlfmCd) {
                                                                    ClientModel.set('isUserAAC', false);
                                                                    Dataservice.getPrimaryAdvisorEligibility(_advisorId).then(function (resp) {
                                                                        var _advsrEligbltyInfo = resp && resp.d?resp.d:null;
                                                                        if (_advsrEligbltyInfo !== null && _advsrEligbltyInfo.primaryAdvisorEligibility && _advsrEligbltyInfo.primaryAdvisorEligibility.isPrmAdvsEligInd === true) {
                                                                            ClientModel.get('clientInfo').set({ 'advisorNumber': _advisorId ,'prePopulatedAdvisorNumber': _advisorId});
                                                                            ClientModel.set({
                                                                                'advisorNumber': _advisorId,
                                                                                'prePopulatedAdvisorNumber': _advisorId,
                                                                                'servicingAdvisorNumber': _advisorId,
                                                                                'prepopulatedSA': _advisorId,
                                                                            });
                                                                            doInitialCheck();
                                                                        } else {
                                                                            if (_isOBOUser) {
                                                                                Dataservice.getDistributorInfo(_advisorId, [401, 404, 500]).then(function(oboDistInfoResp) {
                                                                                    var _oboDistInfo = oboDistInfoResp[0];
                                                                                    if (_oboDistInfo !== undefined && _oboDistInfo !== null) {
                                                                                        _oboSellInd = _oboDistInfo.sellInd;
                                                                                    }
                                                                                    if (_oboSellInd == "Yes") {
                                                                                        ClientModel.set('servicingAdvisorNumber', _advisorId);
                                                                                        ClientModel.set('prepopulatedSA', _advisorId);
                                                                                        doAFACheck(_oboDistInfo.position.pstnCd, _advisorId);
                                                                                    } else {
                                                                                        doInitialCheck();
                                                                                    }
                                                                                }).fail(function (xhr) {
                                                                                    ErrorLog.ErrorUtils.myError(xhr);
                                                                                    doInitialCheck();
                                                                                });
                                                                            } else {
                                                                                if (_loggedInUserSellInd == "Yes") {
                                                                                    ClientModel.set('servicingAdvisorNumber', _loggedInUserFMID);
                                                                                    ClientModel.set('prepopulatedSA', _loggedInUserFMID);
                                                                                    doAFACheck(_loggedInUserDistInfo.position.pstnCd, _loggedInUserFMID);
                                                                                } else {
                                                                                    doInitialCheck();
                                                                                }
                                                                            }
                                                                        }

                                                                    })
                                                                    .fail(function (error) {
                                                                        doInitialCheck();
                                                                    });
                                                                } else {
                                                                    ClientModel.set('isUserAAC', true);
                                                                    checkAACEligibity()
                                                                }
                                                            } else {
                                                                doInitialCheck();
                                                            }
                                                        })
                                                       //continue with the applciation flow
                                                    	.fail(function (error) { doInitialCheck(); });
                                                    }
                                                    function doAFACheck(pstnCd, distId) {
                                                        if (pstnCd == _afaPstnCD) {
                                                            ClientModel.set('isAFAuser', true);
                                                            Dataservice.getAdminMangerInfo(distId, [401, 404, 500]).then(function (response) {
                                                                var _mgrInfo = response[0],_mgrId,_mgrDistId;
                                                                if (_mgrInfo !== null && _mgrInfo !== undefined) {
                                                                    _mgrId = Utils.zeropad(_mgrInfo.dstrId, 9);
                                                                    Dataservice.getAdmnMgrFMID(_mgrId).done(function (admMgrIdsResp) {
                                                                        if (admMgrIdsResp && admMgrIdsResp.d && admMgrIdsResp.d.results) {
                                                                            var _mgrAltCtxIdArray = admMgrIdsResp.d.results;
                                                                            $.each(_mgrAltCtxIdArray, function (idIndx, _mgrAltCtxId) {
                                                                                if (_mgrAltCtxId.altIdCtx == "DMU.DIST") {
                                                                                    _mgrDistId = _mgrAltCtxId.altIdVal;
                                                                                }
                                                                            });
                                                                            if (_mgrDistId) {
                                                                                doAFAPAEligibilityCheck(Utils.zeropad(_mgrDistId, 9));
                                                                            } else {
                                                                                doInitialCheck();
                                                                            }
                                                                        } else {
                                                                            doInitialCheck();
                                                                        }

                                                                    }).fail(function (xhr) {
                                                                        doInitialCheck();
                                                                    });
                                                                    
                                                                } else {
                                                                    doInitialCheck();
                                                                }
                                                            }).fail(function (xhr) {
                                                                doInitialCheck();
                                                            });
                                                        } else {
                                                            doInitialCheck();
                                                        }
                                                    }
                                                    function doAFAPAEligibilityCheck(mgrDistId) {
                                                        Dataservice.getPrimaryAdvisorEligibility(mgrDistId).then(function (resp) {
                                                            var _mgrPAEligInfo = resp && resp.d ? resp.d : null;
                                                            if (_mgrPAEligInfo !== null && _mgrPAEligInfo.primaryAdvisorEligibility && _mgrPAEligInfo.primaryAdvisorEligibility.isPrmAdvsEligInd === true) {
                                                                ClientModel.get('clientInfo').set('advisorNumber', mgrDistId);
                                                                ClientModel.set('advisorNumber', mgrDistId);
                                                                ClientModel.get('clientInfo').set('prePopulatedAdvisorNumber', mgrDistId);
                                                                ClientModel.set('prePopulatedAdvisorNumber', mgrDistId);
                                                            }
                                                            doInitialCheck();
                                                        }).fail(function (xhr) {
                                                            doInitialCheck();
                                                        });
                                                    }
                                                    function getAFAContractingAdvsrId() {

                                                    }
                                                    function checkAACEligibity() {
                                                        Dataservice.getDistributorPractice(_advisorId).then(function (resp) {
                                                            if (resp && resp.d && resp.d.results && resp.d.results.length > 0) {
                                                                var _prscticeInfo = resp.d.results[0];
                                                                getpracticeMembers(_prscticeInfo.pracId);
                                                            } else {
                                                                doInitialCheck();
                                                            }
                                                            
                                                        }).fail(function (error) {
                                                            doInitialCheck();
                                                    });
                                                        function getpracticeMembers(pracId) {
                                                            Dataservice.getpracticeMembers(pracId).then(function (resp) {
                                                                if (resp && resp.d && resp.d.pracMbrs && resp.d.pracMbrs.results && resp.d.pracMbrs.results.length > 0) {
                                                                    var _prscticeMmbrInfo = resp.d.pracMbrs.results[0];
                                                                    var _dstrId = Utils.zeropad(_prscticeMmbrInfo.dstrId, 9);
                                                                    ClientModel.get('clientInfo').set('advisorNumber', _dstrId);
                                                                    ClientModel.set('advisorNumber', _dstrId);
                                                                    ClientModel.get('clientInfo').set('prePopulatedAdvisorNumber', _dstrId);
                                                                    ClientModel.set('prePopulatedAdvisorNumber', _dstrId);
                                                                    ClientModel.set('isAACUser', true);
                                                                    doInitialCheck();
                                                            } else {
                                                                doInitialCheck();
                                                            }
                                                            
                                                            }).fail(function (error) {
                                                                doInitialCheck();
                                                            });
                                                        }
                                                    }
                                                });
                                    })
                                });
                            function draftCancelButtonClickHandler() {
                                CommonUtilis.writeCookie('nocontextlaunch', false);
								var _context = GlobalContext.getInstance().getGlobalContext().Context;
								//if standalone mode close the window
								if (_context.IsStandalone == true) {
                                    if (Utils.iOSversion() > 7 || window.chrome) {
										 var _cancelMsg = '<div class="container" align="center"><div  class="row cancld-txn-msg">This transaction has been cancelled. You may now close the window.</div>';
										 var _cntnr = $('#ncst-user-home-view');
										 _cntnr.html(_cancelMsg);
										 } else {
                                        window.open('', '_self');
										 window.close();
										 }
                                } else {
                                    location.hash = "contactprofile/";
								}
								
							
							
                            }

                        },
                        getContextfromNav: function () {
                            $('.ncst-header').addClass('external-launch');
                        },
                        showClientInfoScreen: function (status) {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            requirejs(['appmodules/ncst/app/js/models/model-client-info',
                                'appmodules/ncst/app/js/models/model-address-entry',
                                'appmodules/ncst/app/js/models/model-details',
                                'appmodules/ncst/app/js/models/model-emloyment',
                                'appmodules/ncst/app/js/models/model-income-investment',
                                'appmodules/ncst/app/js/models/model-client-details'], function (ClientInfoModel, AddressModel) {

                                    requirejs(["appmodules/ncst/app/js/models/model-client"], function (ClientModel) {
                                        requirejs(
                                                ['appmodules/ncst/app/js/views/view-client-info'],
                                                function () {
                                                    //$('.popover.info-popup').remove();
                                                    $('.ncst-step.step1').removeClass('finished');
                                                    $('.ncst-step.step1').addClass('active');
                                                    var _clientInfoView = Utils.getView('clientInfo');
                                                    if (_clientInfoView) {
                                                        _clientInfoView.clearView();
                                                    }
                                                    if (ClientModel.get('newClient')) {
                                                        ClientModel.erase('all');
                                                        $('.ncst-step').removeClass('finished');
                                                    } else if (ClientModel.get('newClientWithAddress')) {
                                                        ClientModel.erase('all!address');
                                                        $('.ncst-step').removeClass('finished');
                                                    }
                                                    _clientInfoView = new ViewClientInfo({ model: ClientInfoModel });
                                                    Utils.addView('clientInfo', _clientInfoView);
                                                    _clientInfoView.render(serverDown);
                                                    _clientInfoView.afterRender(status, serverDown);
                                                    //window.scrollTo(0, 0);
                                                });
                                    });
                                })




                            // }, 25);

                        },
                        showAddressEntryScreen: function () {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            var _addressEntryView = Utils.getView('addressEntry');
                            if (_addressEntryView) {
                                _addressEntryView.clearView();

                            }
                            _addressEntryView = new ViewAddressEntry(
                                    {
                                        model: AddressModel
                                    });
                            Utils.addView('addressEntry', _addressEntryView);
                            _addressEntryView.render();
                            _addressEntryView.afterRender();
                            NewClientModel.set('fromBackbutton', true);
                            window.scrollTo(0, 0);
                        },
                        showValidationScreen: function () {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            $('#seprt-ma-popover').popover('destroy');
                            var _validationView = Utils.getView('addressValidation');
                            if (_validationView) {
                                _validationView.clearView();
                            }
                            _validationView = new ViewAddressValidation(
                                    {
                                        model: AddressModel
                                    });
                            Utils.addView('addressValidation', _validationView);
                            _validationView.render();
                            _validationView.afterRender();
                            NewClientModel.set('fromBackbutton', true);
                            $(window).scrollTop(0);
                        },
                        showClientDetailsScreen: function () {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            $('#seprt-ma-popover').popover('destroy');
                            var _clientDetailsView = Utils.getView('clientDetails');
                            if (_clientDetailsView) {
                                _clientDetailsView.clearView();
                            }
                            _clientDetailsView = new ViewClientDetails({ model: ClientDetailsModel });
                            Utils.addView('clientDetails', _clientDetailsView);
                            _clientDetailsView.render();
                            _clientDetailsView.afterRender();
                            NewClientModel.set('fromBackbutton', true);
                            $(window).scrollTop(0);

                        },
                        showEmploymentScreen: function () {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            requirejs(["appmodules/ncst/app/js/models/model-emloyment"], function (EmploymentModel) {
                                $('#seprt-ma-popover').popover('destroy');
                                var _employmentView = Utils.getView('employment');
                                if (_employmentView) {
                                    _employmentView.clearView();
                                }
                                _employmentView = new ViewEmployment({ model: EmploymentModel });
                                Utils.addView('employment', _employmentView);
                                _employmentView.render();
                                _employmentView.afterRender();
                                NewClientModel.set('fromBackbutton', true);
                                $(window).scrollTop(0);


                            });

                        },
                        showIncomeScreen: function () {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            requirejs(["appmodules/ncst/app/js/models/model-income-investment"], function (IncomeModel) {
                                $('#seprt-ma-popover').popover('destroy');
                                var _incomeView = Utils.getView('income');
                                if (_incomeView) {
                                    _incomeView.clearView();
                                }

                                _incomeView = new ViewIncome({ model: IncomeModel });
                                Utils.addView('income', _incomeView);
                                _incomeView.render();
                                _incomeView.afterRender();
                                NewClientModel.set('fromBackbutton', true);
                                $(window).scrollTop(0);

                            });

                        },
                        showVerificationScreen: function () {
                        	queryString = GlobalContext.getInstance().getGlobalContext().Context.QueryString;
                            queryString = queryString ? queryString : '';
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            // check if user hits the browser back button
                            if (isConfirmed()) {
                                Backbone.history.navigate('ncst/confirmation' + queryString, { trigger: false });
                                return;
                            }
                            $('#seprt-ma-popover').popover('destroy');
                            var _verificationView = Utils.getView('verification');
                            if (_verificationView) {
                                _verificationView.clearView();

                            }
                            _verificationView = new ViewVerification();
                            _verificationView.render(NewClientModel.toJSON());
                            Utils.addView('verification', _verificationView);
                            NewClientModel.set('fromBackbutton', true);
                            $(window).scrollTop(0);


                        },
                        showConfirmationScreen: function () {
                            if (!this.validateUserModel()) {
                        		return;
                        	}
                            var _confirmView = Utils.getView('confrimation');
                            if (_confirmView) {
                                _confirmView.clearView();
                            }
                            _confirmView = new ViewConfirmation();
                            _confirmView.render(NewClientModel.toJSON());
                            Utils.addView('confrimation', _confirmView);
                            $(window).scrollTop(0);
                        }
                        ,
                        validateUserModel: function () {
                			queryString = GlobalContext.getInstance().getGlobalContext().Context.QueryString;
                            queryString = queryString ? queryString : '';
                            if (!ViewClientInfo) {
                                Backbone.history.navigate("ncst/" + queryString, true);
                				//this.defaultACtion();
                				return false;
                			}
                			return true;
                		}
                        ,
                        
                        current: function (route) {
                            if (route && Backbone.History.started) {
                                var Router = this,
                                        // Get current fragment from Backbone.History
                                        fragment = Backbone.history.fragment,
                                        // Get current object of routes and convert to
                                        // array-pairs
                                        routes = _.pairs(Router.routes);
                                // Loop through array pairs and return
                                // array on first truthful match.
                                var matched = _.find(routes, function (handler) {
                                    var route = handler[0];
                                    // Convert the route to RegExp using the
                                    // Backbone Router's internal convert
                                    // function (if it already isn't a RegExp)
                                    route = _.isRegExp(route) ? route : Router
                                            ._routeToRegExp(route);
                                    // Test the regexp against the current
                                    // fragment
                                    return route.test(fragment);
                                });
                                // Returns callback name or false if
                                // no matches are found
                                return matched ? matched[1] : false;
                            } else {
                                // Just return current hash fragment in History
                                return Backbone.history.fragment;
                            }
                        },
                        routeFragment: function () {
                            var _self = this;
                            // return the current hash fragment and also
                            // checking for the default route
                            return _
                                    .has(
                                            _self.routes,
                                            _self.routes[Backbone.history.fragment]) ? Backbone.history.fragment
                                    : (_.invert(_.omit(_self.routes,
                                            '*path')))[_self.routes['*path']];
                        }

                    });
            function saveProspectDetails(response) {

                requirejs(["appmodules/ncst/app/js/models/model-client"], function (ClientModel) {
                    var IncomeModel = ClientModel.get('income'), ClientInfoModel = ClientModel.get('clientInfo');
                    var _prospctMapping = {
                        "1": "Corporate Lead",
                        "2": "Advisor Locator",
                        "3": "Client Referral",
                        "4": "Prospect Referral",
                        "5": "Natural Market",
                        "6": "Center of Influence",
                        "7": "Client from Existing Group",
                        "8": "Professional Networking",
                        "9": "External Practice Purchase",
                        "10": "Reassignment/ Internal Purchase",
                        "11": "Local Advertising",
                        "12": "Sponsorship",
                        "13": "Prospect Mailing",
                        "14": "Container",
                        "15": "Tradeshow",
                        "16": "Strategic Alliance",
                        "17": "Community Connection/ Informal Alliance",
                        "18": "National Workplace",
                        "19": "Local Workplace/ Informal Workplace",
                        "20": "H&R Block Tax Referral"
                    }
                    var _resp = response;
                    var _contactType = _resp.PersonContact !== null ? _resp.PersonContact
                            : (_resp.BusinessContact ? _resp.BusinessContact : '');
                    var _addrLine1 = 'uAddressLine1';
                    var _addrLine2 = 'uAddressLine2';
                    NewClientModel.set('fromBackbutton', false);
                    // setting the values for person contact
                    var clientDetls = {}, incomeDetls = {}, infoDetls = {};
                    if (_resp.PersonContact != null) {

                        ClientInfoModel.set('clientType', 'P');
                        // step1 client name
                        infoDetls = {
                            firstName: _contactType.clFirstNm,
                            middleName: _contactType.clMidNm,
                            lastName: _contactType.clLastNm,
                            honorific: _contactType.clTitle,
                            suffix: _contactType.clSfxTxt
                        };
                        // set the ssn
                        if (_contactType.clTaxId) {
                            var _ssn = _contactType.clTaxId.split('-');
                            infoDetls.ssn1 = _ssn[0];
                            infoDetls.ssn2 = _ssn[1];
                            infoDetls.ssn3 = _ssn[2];
                        }
                        // step 4
                        clientDetls = {
                            clientbDay: _contactType.clDob,
                            clientdriverLicense: _resp.DriverLicence ? _resp.DriverLicence.driverLicNo : '',
                            clientState: _resp.DriverLicence ? _resp.DriverLicence.driverLicState : ''
                        };

                        // step 6
                        incomeDetls = {
                            occupation: _contactType.clOccupation,
                            employer: _resp.employerName
                        };
                        // save anunali ncome and networth
                        if (_contactType.clTotalIncome) {
                            IncomeModel.set('incomeIndiAnnualNum',
                                    _contactType.clTotalIncome);
                        }
                        if (_contactType.clNetWorth) {
                            IncomeModel.set('incomeIndiNetNum',
                                    _contactType.clNetWorth);
                        }

                    } else if (_resp.BusinessContact != null) {

                        _addrLine1 = 'uEntAddressLine1';
                        _addrLine2 = 'uEntAddressLine2';
                        ClientInfoModel.set('clientType', 'O');
                        infoDetls = {
                            entityName: _contactType.orgNm,
                            //clientworkPhone1: _resp.Phones[0].AreaCode
                        };
                        if (_contactType.clTaxId) {

                            if (_contactType.clTaxId.indexOf('-') != -1) {
                                var _ein = _contactType.clTaxId.split('-');
                                infoDetls.ein1 = _ein[0];
                                infoDetls.ein2 = _ein[1];
                            }

                        }
                    }

                    // step2
                    var _initialAddressDefault = {};
                    var _homeAddress = null;
                    if (_resp.Addresses != null) {
                        if (_resp.Addresses.length > 0) {
                            var _addressTyepe = "Home";
                            if (_resp.BusinessContact !== null) {
                                _addressTyepe = 'Business';
                            }
                            // get the home address and save it to
                            // model
                            $(_resp.Addresses).each(function (index, address) {

                                if (address.AddressTypeDesc == _addressTyepe) {
                                    _homeAddress = address;
                                }
                            });
                        }
                    }

                    if (_homeAddress) {
                        _initialAddressDefault = {
                            'uCity': _homeAddress.City,
                            'uState': _homeAddress.State,
                            'uZip': _homeAddress.Postal,
                        }
                        _initialAddressDefault[_addrLine1] = _homeAddress.Line1;
                        _initialAddressDefault[_addrLine2] = _homeAddress.Line2;
                    }
                    // step4
                    // phone numbers hydra changes
                    clientDetls['telephones'] = [];
                    var _phoneNumObj = {
                        "phnLblTxt": "",
                        "NANPAreaCd": "",
                        "NANPExchCd": "",
                        "NANPSbscNbr": "",
                        "nonNANPPhnNbr": "",
                        "phnExtnNbr": "",
                        "phnSubLblTxt": "",
                        "phnCtryCd": "",
                        "phnPrfrCd": ""
                        };
                    var _telephones = [{
                        "phnLblTxt": "HOME",
                        "NANPAreaCd": "",
                        "NANPExchCd": "",
                        "NANPSbscNbr": "",
                        "nonNANPPhnNbr": "",
                        "phnExtnNbr": "",
                        "phnSubLblTxt": "",
                        "phnCtryCd": "",
                        "phnPrfrCd": ""
                    }, {
                        "phnLblTxt": "WORK",
                        "NANPAreaCd": "",
                        "NANPExchCd": "",
                        "NANPSbscNbr": "",
                        "nonNANPPhnNbr": "",
                        "phnExtnNbr": "",
                        "phnSubLblTxt": "",
                        "phnCtryCd": "",
                        "phnPrfrCd": ""
                    }, {
                        "phnLblTxt": "MOBILE",
                        "NANPAreaCd": "",
                        "NANPExchCd": "",
                        "NANPSbscNbr": "",
                        "nonNANPPhnNbr": "",
                        "phnExtnNbr": "",
                        "phnSubLblTxt": "",
                        "phnCtryCd": "",
                        "phnPrfrCd": ""
                    }, {
                        "phnLblTxt": "OTHER1",
                        "NANPAreaCd": "",
                        "NANPExchCd": "",
                        "NANPSbscNbr": "",
                        "nonNANPPhnNbr": "",
                        "phnExtnNbr": "",
                        "phnSubLblTxt": "",
                        "phnCtryCd": "",
                        "phnPrfrCd": ""
                    }, {
                        "phnLblTxt": "OTHER2",
                        "NANPAreaCd": "",
                        "NANPExchCd": "",
                        "NANPSbscNbr": "",
                        "nonNANPPhnNbr": "",
                        "phnExtnNbr": "",
                        "phnSubLblTxt": "",
                        "phnCtryCd": "",
                        "phnPrfrCd": ""
                    }];
                    if (_resp.Phones != null)
                        if (_resp.Phones.length) {
                            $(_resp.Phones)
                                    .each(
                                            function (index, phone) {
                                                var _phoneType = "", _phone = {}, _phnOb = JSON.parse(JSON.stringify(_phoneNumObj));;
                                            	switch (phone.PhoneTypeDesc) {
												case "Home":
													_telephones[0] = _phnOb;
													_telephones[0].phnLblTxt = "HOME";
													_phone = _telephones[0];
													_phoneType = "HOME";
													break;
												case "Business":
													_telephones[1] = _phnOb;
													_telephones[1].phnLblTxt = "BUSINESS";
													_phone = _telephones[1];
													_phoneType = "BUSINESS";
													break;
												case "Mobile":
													_telephones[2] = _phnOb;
													_telephones[2].phnLblTxt = "MOBILE";
													_phone = _telephones[2];
													_phoneType = "MOBILE";
													break;
												case "Other 1":
													_telephones[3] = _phnOb;
													_telephones[3].phnLblTxt = "OTHER1";
													_phone = _telephones[3];
													_phoneType = "OTHER1";
													break;
												case "Other 2":
													_telephones[4] = _phnOb;
													_telephones[4].phnLblTxt = "OTHER2";
													_phone = _telephones[4];
													_phoneType = "OTHER2";
													break;
												default:
													_phoneType = "";
                                                        _phone = {};
													break;
												}
                                                if (_phoneType != "") {
                                                    var _phoneNum = phone.Number, _isBadPhone = false;
                                                    _phoneNum = _phoneNum.replace('-', '');
                                            			_phone['phnPrfrCd'] = '02';
                                                    if (phone.CountryCode == 1 || phone.CountryCode == '' || phone.CountryCode == '+1') {
                                            			//US number
                                                        if (phone.AreaCode.length != 3 || _phoneNum.length != 7) {
                                            				_isBadPhone = true;
                                                        } else {
                                            				_phone['NANPAreaCd'] = phone.AreaCode;
                                                            _phone['NANPExchCd'] = _phoneNum.substr(0, 3);
                                                            _phone['NANPSbscNbr'] = _phoneNum.substr(3, 4);
        												 	_phone['phnCtryCd'] = '+1';
                                            			}
                                            			
                                                    } else {
                                            			//international number
                                                        _phoneNum = phone.AreaCode + '' + phone.Number;
                                                        if (_phoneNum.length > 15) {
                                            				_isBadPhone = true;
                                                        } else {
                                                            _phoneNum = _phoneNum.replace('-', '');
                                                            _phone['nonNANPPhnNbr'] = _phoneNum.substr(0, 15);
                                                			_phone['phnCtryCd'] = phone.CountryCode;
                                            			}
                                                		
                                            		}
                                                    if (!_isBadPhone) {
                                                        if (_phoneType != "HOME" && _phoneType != "MOBILE") {
                                                            _phone['phnExtnNbr'] = phone.Extension.substr(0, 6);
                                                		}
                                                        if (phone.Preferred == 1) {
                                                			_phone['phnPrfrCd'] = '01';
                                                		}
                                            		}
                                            		
                                            	}
                                            	
                                            });
                            clientDetls['telephones'] = _telephones;

                        }
                    clientDetls['fromBack'] = true;
                    if (_resp.marketSource) {
                        clientDetls['clientprospectSource'] = _prospctMapping[_resp.marketSource];
                    }
                    // primary email address, 'Preffered = 1'
                    var _prmryEmailAddrs = null;
                    if (_resp.WebAddresses != null)
                        if (_resp.WebAddresses.length > 0) {
                            $(_resp.WebAddresses).each(function (index, email) {
                                if (email.Preferred == "1") {
                                    _prmryEmailAddrs = email.Address;
                                }
                            });
                        }
                    clientDetls['clientprimaryEmail'] = _prmryEmailAddrs;
                    // setting up models
                    ClientInfoModel.set(infoDetls);
                    AddressModel.set('primaryAddress', _initialAddressDefault);
                    ClientDetailsModel.set(clientDetls);
                    IncomeModel.set(incomeDetls);
                    var _urlContext = self.getUrlContext(GlobalContext
                            .getInstance().getGlobalContext().Context.QueryString);
                    var _ctx = _urlContext['ProspectSource'] ? _urlContext['ProspectSource'] : null;
                    ClientInfoModel.set('prosCtx', _ctx);
                    if (!_ctx && GlobalContext.getInstance().getGlobalContext().Context.ContactId) {
                    	ClientInfoModel.set('prosCtx', "CM");
                    }


                })
            }
            function initialiseRouter(router) {

            }
            function isConfirmed() {
                var _historyLen = history.length;
                var previousPage = history[(_historyLen - 1)];
                if (previousPage.fragment.search('confirmation') >= 0) {
                    return true;
                } else {
                    return false;
                }
            }
            function handleRouteNavigation(route, params) {
                requirejs(["appmodules/ncst/app/js/models/model-client"], function (ClientModel) {
                    var IncomeModel = ClientModel.get('income'), ClientInfoModel = ClientModel.get('clientInfo');
                    if (route == "defaultACtion") {
                        return false;
                    }
                    var _stpsCmpltd = [];
                    try {
                        _stpsCmpltd = ClientModel.get('stepsCompleted');
                    } catch (e) {
                        // TODO: handle exception
                    }

                    if (!history.length || firstLoad) {
                        history.push({
                            route: 'showClientInfoScreen',
                            fragment: 'client-info'
                        });
                    }

                    firstLoad = false;
                    history.push({
                        route: route,
                        fragment: Backbone.history.fragment
                    });
                    var _historyLen = history.length;
                    var previousPage = history[(_historyLen - 2)];
                    var currentPage = Backbone.history.fragment;
                    // currentPage=
                    // currentPage.match(/^(.*)\/[^/]*$/)[1];
                    if (currentPage.indexOf('/') > 0) {
                        currentPage = (currentPage.substring((currentPage
                                .indexOf('/') + 1), currentPage.length));
                        currentPage = currentPage ? currentPage : 'client-info';
                    }
                    currentPage = currentPage.substring(0, currentPage.indexOf('?') != -1 ? currentPage.indexOf('?') : currentPage.length);
                    // settting current page to active and
                    // removing any completed or not completed
                    // flags
                    switch (currentPage) {

                        case 'client-info':
                            $('.ncst-step.step1').addClass('active').removeClass(
                                    'finished pending');
                            break;

                        case 'address-entry':
                            $('.ncst-step.step2').addClass('active').removeClass(
                                    'finished pending');
                            if (!AddressModel.get('firstTime')) {
                                $('.ncst-step.step3').addClass('pending').removeClass(
                                        'active finished');
                                AddressModel.set('firstTime', false);
                            }

                            break;
                        case 'address-validation':
                            $('.ncst-step.step3').addClass('active').removeClass(
                                    'finished pending');
                            break;
                        case 'client-details':
                            $('.ncst-step.step4').addClass('active').removeClass(
                                    'finished pending');
                            break;
                        case 'employment':
                            $('.ncst-step.step5').addClass('active').removeClass(
                                    'finished pending');
                            break;
                        case 'income':
                            $('.ncst-step.step6').addClass('active').removeClass(
                                    'finished pending');
                            break;
                        case 'verification':
                            $('.ncst-step.step7').addClass('active').removeClass(
                                    'finished pending');
                            break;
                        case 'confirmation':
                            $('.ncst-step.step8').addClass('active');

                            if ($('.ncst-step.step8').hasClass('active')) {
                                $("#client-info").css('border', 'none');
                            }

                            break;
                    }
                    // removing the item from stepsCompleted
                    // array
                    /*
                     * ClientModel.set('stepsCompleted', Utils.arraySplice(
                     * ClientModel.get('stepsCompleted'), previousPage.fragment));
                     */
                    var _prevFragmnt = previousPage ? previousPage.fragment : '';
                    _prevFragmnt = _prevFragmnt.substring(0, _prevFragmnt.indexOf('?') != -1 ? _prevFragmnt.indexOf('?') : _prevFragmnt.length);
                    if ((_prevFragmnt).indexOf('/') > 0) {
                        _prevFragmnt = (_prevFragmnt.substring(
                                (previousPage.fragment.indexOf('/') + 1),
                                _prevFragmnt.length));
                    }
                    switch (_prevFragmnt) {
                        case 'ncst_develop':
                            // case '':
                        case 'client-info':
                            if (ClientInfoModel.get('clientInfoValid') && currentPage != "client-info") {
                                // calling scrubClientName functionality for entity type
                                $('.ncst-step.step1').addClass('finished').removeClass(
                                        'active pending');
                                if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                    _stpsCmpltd.push(_prevFragmnt);
                                }

                            } else {
                                $('.ncst-step.step1').removeClass('active finished');
                            }
                            if (currentPage == "client-info") {
                                $('.ncst-step.step1').addClass('active');
                            }
                            break;
                        case 'address-entry':
                            if (currentPage == "address-validation") {
                                $('.ncst-step.step2').addClass('finished').removeClass(
                                        'active pending');
                                if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                    _stpsCmpltd.push(_prevFragmnt);
                                }
                                if (AddressModel.get('addressValChange')) {
                                    // change the addressCheck variables to false
                                    AddressModel.set('mailClientAddressCheck', false);
                                    AddressModel.set('clientAddressCheck', false);
                                }
                                ClientModel.set('stepsCompleted', Utils.arraySplice(
                                        ClientModel.get('stepsCompleted'),
                                        'address-validation'));
                            } else {
                                // AddressModel.setModel();
                                // check if the step2 and step3 is already completed and
                                // if there any change happen
                                var _completedSteps = ClientModel.get('stepsCompleted');
                                if (AddressModel.get('addressValChange')) {
                                    // change the addressCheck variables to false
                                    AddressModel.set('mailClientAddressCheck', false);
                                    AddressModel.set('clientAddressCheck', false);
                                    // remove step2 and step3 from completed steps
                                    ClientModel.set('stepsCompleted', Utils
                                            .arraySplice(_completedSteps,
                                                    'address-entry'));
                                    ClientModel.set('stepsCompleted', Utils
                                            .arraySplice(_completedSteps,
                                                    'address-validation'));
                                }
                                if (_completedSteps.indexOf('address-entry') != -1) {
                                    $('.ncst-step.step2').addClass('finished')
                                            .removeClass('active pending');
                                    if (_completedSteps.indexOf('address-validation') != -1) {
                                        $('.ncst-step.step3').addClass('finished')
                                                .removeClass('active pending');
                                    }
                                } else {
                                    $('.ncst-step.step2,.ncst-step.step3').addClass(
                                            'pending').removeClass('active finished');
                                }

                            }
                            // checking if user has selected US
                            // option by navigating back to step2
                            // and if state combo hasn't been filled
                            // in step4
                            if (AddressModel.get('primaryAddress').addressType == "U.S"
                                    && typeof (ClientDetailsModel
                                            .get('clientdriverLicence')) != 'undefined'
                                    && ClientDetailsModel.get('clientdriverLicense').length) {
                                if (!ClientDetailsModel.get('clientState')
                                        && currentPage != 'client-details') {
                                    $('.ncst-step.step4').addClass('pending')
                                            .removeClass('active finished');
                                    ClientModel.set('stepsCompleted', Utils
                                            .arraySplice(ClientModel
                                                    .get('stepsCompleted'),
                                                    'client-details'));
                                }
                            }
                            break;
                        case 'address-validation':
                            var _isFinished = true;

                            if (ClientDetailsModel.get('addrEntryValid')) {
                                /*
                                 * After validating input entries,service call for
                                 * address validation happens
                                 */
                                if (!AddressModel.get('validAddr')) {
                                    //	
                                    /*
                                     * If address is invalid,yellow box and checkbox
                                     * shows up
                                     */
                                    // && AddressModel.get('mailClientAddressCheck')
                                    if (!AddressModel.get('clientAddressCheck')
                                            && AddressModel.get('primaryAddress').addressType != "Foreign") {
                                        _isFinished = false;
                                        /*
                                         * The check box need to be selected inorder to
                                         * give completion status to address validation
                                         * step
                                         */

                                    }
                                } else {
                                    /*
                                     * If address is valid,completion status can be
                                     * given to step3
                                     */
                                    $('.ncst-step.step3').addClass('finished')
                                            .removeClass('active pending');
                                    if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                        _stpsCmpltd.push(_prevFragmnt);
                                    }
                                }

                                if (AddressModel.get('seperateMailingAddress')
                                        && !AddressModel.get('mailValidAddr')) {
                                    if (!AddressModel.get('mailClientAddressCheck')) {
                                        _isFinished = false;
                                    }
                                }
                                if (AddressModel.get('primaryAddress').addressType == "Foreign"
                                        && !AddressModel.get('mailValidAddr')) {
                                    if (!AddressModel.get('mailClientAddressCheck')) {
                                        _isFinished = false;

                                    }
                                }
                                if (_isFinished == true) {
                                    $('.ncst-step.step3').addClass('finished')
                                            .removeClass('active pending');
                                    if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                        _stpsCmpltd.push(_prevFragmnt);
                                    }
                                } else {
                                    $('.ncst-step.step3').addClass('pending')
                                            .removeClass('active finished');
                                }
                            } else {
                                $('.ncst-step.step3').addClass('pending').removeClass(
                                        'active finished');
                            }
                            break;
                        case 'client-details':
                            if (ClientDetailsModel.get('clientDetlsValid')) {
                                $('.ncst-step.step4').addClass('finished').removeClass(
                                        'active pending');
                                if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                    _stpsCmpltd.push(_prevFragmnt);
                                }
                            } else {
                                $('.ncst-step.step4').addClass('pending').removeClass(
                                        'active finished');
                                ClientModel.set('stepsCompleted', Utils
                                        .arraySplice(ClientModel
                                                .get('stepsCompleted'),
                                                'client-details'));
                            }
                            break;
                        case 'employement':
                            if (ClientDetailsModel.get('clientEmploymentValid')) {
                                $('.ncst-step.step5').addClass('finished').removeClass(
                                        'active pending');
                                if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                    _stpsCmpltd.push(_prevFragmnt);
                                }
                            } else {
                                $('.ncst-step.step5').addClass('pending').removeClass(
                                        'active finished');
                                ClientModel.set('stepsCompleted',Utils
                                        .arraySplice(ClientModel
                                                .get('stepsCompleted'),
                                                'employement'));
                            }
                            break;
                        case 'income':
                            if (IncomeModel.get('clientIncomeValid')) {
                                $('.ncst-step.step6').addClass('finished').removeClass(
                                        'active pending');
                                if (_stpsCmpltd.indexOf(_prevFragmnt) === -1) {
                                    _stpsCmpltd.push(_prevFragmnt);
                                }
                            } else {
                                $('.ncst-step.step6').addClass('pending').removeClass(
                                        'active finished');
                                ClientModel.set('stepsCompleted', Utils
                                        .arraySplice(ClientModel
                                                .get('stepsCompleted'),
                                                'income'));
                            }
                            break;
                        case 'verification':
                            var stepsToComplete = ClientInfoModel.get('clientType') == 'P' ? 6
                                    : 5;
                            if (ClientModel.get('clientValid') && ClientModel.get('stepsCompleted').length == stepsToComplete) {
                                $('.ncst-step.step7').addClass('finished').removeClass(
                                        'active pending');
                            } else {
                                $('.ncst-step.step7').addClass('pending').removeClass(
                                        'active finished');
                            }
                           break;
                        case 'confirmation':
                            // var stepsToComplete =
                            // ClientInfoModel.get('clientType') ==
                            // 'P' ? 6 : 5;

                            $('.ncst-step.step8').removeClass('active');

                            break;
                    }
                    // remove "finished" class from verification step if it was the previous step
                    if (_prevFragmnt == "verification" && currentPage !== "confirmation") {
                        $('.ncst-step.step7').removeClass('finished');
                    }
                });

            }
            return {
                ncstRouter: ncstRouter,
                ncstRouter: initialiseRouter

            };

});
