define(['jquery', 'lodash', 'backbone', 'app/common/models/Client'
], function ($, _, Backbone, Client) {
    var ClientCollection = Backbone.Collection.extend({
        model: Client,
        populateFromClientListResponse: function (clientListRes) {
            const clientList = clientListRes.results;
            if (clientList && clientList.length > 0) {
                var self = this;
                _.each(clientList, function (client) {
                    self.add(new Client().populateFromServiceResponse(client));
                });
            }
            return this;
        }
    });
    return ClientCollection;
});