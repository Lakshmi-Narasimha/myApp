/*<summary>Common library for showing different spinners when ajax calls are in progress and other required areas</summary>*/

define(["jquery"],function ($) {

    function spinner(){

        this.defaultOptions = {
            msg : "Loading...",//@Param default message
            inline:false,//@Param Whether the spinner is page level or section level
            parentElement:undefined,//@Param Parent element Id which the spinner is append to
            serachBox:false
        };

        this.show = function(options){
            if(!options) options = {};
            options = this.extend(this.defaultOptions, options);
            if(options.inline){
                $("#spinner-inline-container").remove();
                var parent = $("#"+options.parentElement);
                var _inlineSPinner = "<p id='spinner-inline-container'><span class='spinner-inline scraper-msg'></span></p>";
                if(options.serachBox){
                    parent.prepend(_inlineSPinner);
                }else{
                    parent.append(_inlineSPinner);
                }

            }else{

                if ($("#spinner-overlay").is(":visible")) {
                    return;
                }
                $("#spinner-overlay").height($(document).height());
                $('#spinner-overlay').show();
            }
            $(".scraper-msg").text(options.msg);

            //Condition for serachbox
            if(options.serachBox){
                $(".spinner-inline").addClass("search-box");
            }

        };
        this.hide = function(options){
            if(!options) options = {};
            options = this.extend(this.defaultOptions, options);
            if(options.inline){
                $("#spinner-inline-container").fadeOut(300,function(){
                    $(this).remove();
                });
            }else{
                if ($("#spinner-overlay").is(":visible")) {

                    $('#spinner-overlay').fadeOut(300, function() {
                        $('#spinner-overlay').hide();
                    });
                }
            }

        };
        //Extend an object
        this.extend = function(parentObj, chileObj) {
            if(typeof parentObj != "object" && typeof parentObj != "object"){
                return {};
            }
            var _tmpObj = {};
            for(var key in parentObj)_tmpObj[key] = (chileObj[key] == null) ? parentObj[key] : chileObj[key];
            return _tmpObj;
        };
    }

    return new spinner();
});