define(['jquery', 'lodash', '../app/common/util', 'ampfComponents'],
  function($, _, util, ampfComponents) {

	var assert = chai.assert;
	var expect = chai.expect;

    class TestHelper {

        triggerRadioButtonSelection(radioButtonView, itemIndex) {
			var $inputs = radioButtonView.$el.find('input[ampf-radio-button-id]');
			$inputs.prop('checked', false);
			var $input = radioButtonView.$el.find('input[ampf-radio-button-id=' + itemIndex + "-" + radioButtonView.componentId() + ']');
			$input.trigger('click');
			var $rbGroup = $input.closest('[ampf-radio-button]');
			$rbGroup.trigger('change');
        }

		triggerDropDownSelection(dropDownView, itemIndex) {
			dropDownView.$el.find('[ampf-dropdown-select]').val('' + itemIndex).change();
		}

		triggerMultiSelectSelection(multiSelectView, itemIndex) {
			var $li = multiSelectView.$el.find('[ltr-multiselect-list-item-div] [ltr-multiselect-index="' + itemIndex + '"]');
			$li.trigger('click');
		}

		triggerCheckBoxSelection(checkBoxView, itemIndex) {
			var $in = checkBoxView.$('[ampf-checkbox-button-id="' + itemIndex + '"]');
			$in.trigger('click');
			$in.trigger('change');
		}

		triggerSwichSelection(swithchView, value){
			var $switchEl;
			if(value){
				$switchEl = swithchView.$el.find('[ampf-toggle-button-value="yes"]');
			}else{
				$switchEl = swithchView.$el.find('[ampf-toggle-button-value="no"]');
			}
			$switchEl.trigger('click');
	    }

	    expectOneElement($element) {
			expect($element.length).to.equal(1);
		}

		expectZeroElement($element) {
			expect($element.length).to.equal(0);
		}

		expectHidden($element) {
			expect(this.isHidden($element)).to.be.true;
		}

		expectVisible($element) {
			expect(this.isHidden($element)).to.be.false;
		}

		// will consider ancestors
		// $element must have one and only one element
		isHidden($el) {
			if (this.isHiddenElement($el)) {
				return true;
			}
			const parents = $el.parents();
			for (var i = 0; i < parents.length; i++) {
				if (this.isHiddenElement($el)) {
					return true;
				}
			}
			return false;
		}

		// $element must have one and only one element
		isHiddenElement($el) {
			if ($el.length != 1) {
				throw "must have 1 element to use isHidden()...this $el has " + $el.length + " element(s)";
			}
			if ($el.hasClass('hidden')) {
				return true;
			}
			const display = $el.css('display');
			if (display != null && display == 'none') {
				return true;
			}
			return false;
		}

		expectHiddenViaClass($element) {
			expect($element.hasClass('hidden')).to.be.true;
		}

		expectVisibleViaClass($element) {
			expect($element.hasClass('hidden')).to.be.false;
		}

		expectHiddenViaStyle($element) {
			expect($element.css('display')).to.equal('none');
		}

		expectVisibleViaStyle($element) {
			expect($element.css('display')).to.not.equal('none');
		}

		expectRadioButtonSelection(radioButtonView, item) {
			expect(radioButtonView.selectedItem).to.deep.equal(item)
		}

		expectDropDownSelection(radioButtonView, item) {
			expect(radioButtonView.selectedItem).to.deep.equal(item)
		}

		expectCheckBoxSelections(checkBoxView, items) {
			expect(checkBoxView.selectedItems).to.deep.equal(items);
		}

		removeAnimations(testView) {
			if (testView.animateShow) {
				testView.animateShow = function ($view, show, afterCompletion) {
					show ? $view.show(afterCompletion) : $view.hide(afterCompletion);
				};
			}
		}

		createMockModalConstructor($testEl) {
			const MockModalView = ampfComponents.AggregateView.extend({
				initialize: function (options) {
					this.result = null;
					ampfComponents.AggregateView.prototype.initialize.apply(this, arguments);
				},
				renderModal(closeCallback) {
					if (closeCallback && typeof closeCallback == 'function') {
						this.complete = closeCallback;
					}
					this.setElement($testEl);
					this.render();
				},
				closeDialog() {
					this.complete(this.result);
				},
				simulateCancel() {
					this.result = null;
					this.complete(this.result);
				}
			});

			return MockModalView;
		}
    }

    return new TestHelper();

});