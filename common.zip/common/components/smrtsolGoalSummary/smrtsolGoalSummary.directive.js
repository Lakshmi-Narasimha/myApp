'use strict';

var smrtsolGoalSummaryVerticalTileList = function(buildPlanModelService) {
	return {
        template: require('./smrtsolGoalSummary.html'),
        restrict: 'E',
        replace: true,
        scope:{
             goalSummary :'=',
             title : "="
        },
        controller:['$scope', function($scope){
            
            var returnsTemplate = '<div class="fti-returns">Annual Withdrawals<span uib-popover-template="\'returnTemp.html\'"  popover-is-open="popoverIsOpen" ng-click="popoverIsOpen = !popoverIsOpen"  popover-placement="left" popover-trigger="outsideClick" class="icon-fti-Info-blue"></span></div>'+
                '<script type="text/ng-template" id="returnTemp.html">' +
                '<div><button type="button" class="btn panel-orange-btn m0">Annual Withdrawals calculation will be displayed</button></div></script>';
            if(buildPlanModelService.tabname !== "IGT") {
                $scope.columnDefs = [
                    {field: 'GoalName', displayName: 'Goal Name', width: "170"},
                    {field: 'GoalAmount', displayName: 'Goal Amount', width: "200", headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon fti-grid-sortDisabledHeader text-right', cellClass:'text-right'},
                    {field: 'AnnualWithdrawals', displayName: 'Annual Withdrawals', width: "200", headerCellTemplate:returnsTemplate, headerCellClass:'fti-grid-headercell media-vtop fti-grid-rupeeIcon fti-grid-rupeeIcon1 pt- pr+ text-right', cellClass:'text-right'},
                    {field: 'AnnualStep', displayName: 'Annual Step-up %', width: "200",  headerCellClass: 'text-right fti-grid-headercell  fti-grid-sortDisabledHeader', cellClass:'text-right'},
                    {field: 'GoalTenor', displayName: 'Goal Tenure', width: "110", headerCellClass: 'text-center', cellClass:'text-right'}
                ];
            }
            else {
                $scope.columnDefs = [
                    {field: 'GoalName', displayName: 'Goal Name', width: "180"},
                    {field: 'GoalDeficit', displayName: 'Goal Deficit', width: "170", headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon fti-grid-sortDisabledHeader text-right', cellClass:'text-right'},
                    {field: 'BalanceTenure', displayName: 'Balance Tenure', width: "170", headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader'}
                ];
            }


        }]
    }
};

smrtsolGoalSummaryVerticalTileList.$inject = ['buildPlanModelService'];
module.exports = smrtsolGoalSummaryVerticalTileList;