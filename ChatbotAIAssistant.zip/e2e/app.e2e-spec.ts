import { ChatbotAIAssistantPage } from './app.po';

describe('chatbot-aiassistant App', function() {
  let page: ChatbotAIAssistantPage;

  beforeEach(() => {
    page = new ChatbotAIAssistantPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
