/**
 * @ngdoc property
 * @name Investor Controller
 * @requires $rootScope
 * @requires $scope
 * @requires $state
 * @requires $window
 * @requires Idle
 * @requires popupSrvc
 * @description 
 *
 * - It is the main controller for investor module. It handles the Idle timeout and logout functionalities.
 *
 **/



'use strict';
// Controller naming conventions should start with an uppercase letter

function investorController($rootScope, $scope, $state, $window, Idle, popupSrvc, $localStorage, investorEventConstants, eventConstants, $cookies, $http, authenticationService, constants, toaster, investorDashboardInitialServices, fticRecommAndNotifiModel, globalMenuInitLoader, events, $loader, appConfig, configUrlModel, $interval, transactModel, tcAndSTPopupModel) {

    /* DO NOT DELETE THIS BELOW COMMENTED CHUNK*/

    /*if($localStorage.user) {
        (function(d, s, id, o) {
          var fs = d.getElementsByTagName(s)[0], e;
          if (d.getElementById(id)) return;
          e = d.createElement(s); e.id = id; e.src = o.src;
          e.setAttribute('data-gcb-url', o.cbUrl);
          fs.parentNode.insertBefore(e, fs);
      })(document, 'script', 'genesys-js', {

        src: 'https://ft.karvy.com/aspx_app/common/js/gcb.min.js',
                  cbUrl: 'http://stovlnx3053:8700/cobrowse'

          // src: 'http://10.232.198.236:8700/cobrowse/js/gcb.min.js',
          // cbUrl: 'http://10.232.198.236:8700/cobrowse'
      });
    }*/

    $scope.app = 'investor';

    /* DO NOT DELETE THE ABOVE COMMENTED CHUNK*/

    if (globalMenuInitLoader._isServicesData) {
        // $timeout(function() {
        events.publishMenuDetails($scope);
        // },0);
    } else {
        globalMenuInitLoader.loadAllServices($scope);
        globalMenuInitLoader._isServicesData = true;
    }

    if ($cookies.get('guId') !== undefined && $cookies.get('guId') !== 'undefined' && $cookies.get('guId') !== 'null') {
        authenticationService.setCookies();
        // console.log('Settting User Details form Cookies');
        // authenticationService.setUser({
        //   'accessToken': $cookies.get('accessToken'), 
        //   'guId': $cookies.get('guId'),
        //   'userType': $cookies.get('userType'), 
        //   'userRedirectURI': $cookies.get('userRedirectURI')
        // });

        // Calling refresh token service after 20 mins to enable user session with out logging him out -- Suresh P
        $interval(function () {
            callRefreshToken();
        }, 1200000); //1200000 --  20 mins
    } else {
        // For Development Need to comment this line -- Suresh P

        //$window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
    }

    $scope.isLoggedIn = $cookies.get('guId') ? true : false;
    $scope.$on(eventConstants.LoginSuccess, function () {
        $scope.isLoggedIn = true;
    });

    $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_RESET, function () {
        console.log('reset in advisorController');
        $scope.$broadcast(eventConstants.RESET_CHANNEL_AUTO_SEARCH_OPTION);
    });

    $scope.login = function () {
        console.log('login');
        $scope.isLoggedIn = false;
        $state.go('login');
    };
    $scope.logout = function () {
        $window.localStorage.clear();
        $window.sessionStorage.clear();
        authenticationService.logout({
                'guId': $cookies.get('guId')
            })
            .then(function (data) {
                //$scope.isLoggedIn =false;
                investorDashboardInitialServices._isServicesData = false;
                authenticationService.removeUserCookies();
                authenticationService.clearAllCookies();
                toaster.success('Successfully Logged out, Thank you');
                $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                //$state.go('dashboard', {}, {reload: true});
                //$window.location.reload();
                // delete $localStorage.user;
                authenticationService.setUser(null);
            }, function (data) {
                //console.log('Logout Fail', data);
                //$scope.isLoggedIn =false;          
                investorDashboardInitialServices._isServicesData = false;
                authenticationService.removeUserCookies();
                toaster.success('Successfully Logged out, Thank you');
                $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
                //$state.go('dashboard', {}, {reload: true});
                //$window.location.reload();
            });
        // $window.location.href = 'index.html';
    };

    $scope.$on('IdleStart', function () {
        console.log('Started');
        // popupSrvc.notifyError('Your Session is about to expire');
    });
    $scope.$on('IdleEnd', function () {
        console.log('Idle End');
    });
    $scope.$on('IdleTimeout', function () {
        console.log('timeout');
        console.log($cookies.get('guId'));

        // $scope.logout();
    });
    $scope.idleStart = function () {
        Idle.watch();
    };

    $scope.idleStop = function () {
        Idle.unwatch();
    };

    $scope.callRefreshToken = function () {
        var creds = {
            'guId': $cookies.get('guId')
        };
        console.log(creds);
        $http.post(constants.PROXY_URL + 'refreshToken', creds).then(function (data) {
            console.log(data);
            $cookies.put('accessToken', data.data.accessToken);
            $cookies.put('guId', data.data.guId);
            $cookies.put('userType', data.data.userType);
            $cookies.put('userRedirectURI', data.data.userRedirectURI);
        }, function (data) {
            console.log(data);
            toaster.error(data.data[0].errorDescription);
        });
    };

    $scope.$on(eventConstants.Dashboard.ADV_DB_SIDE_NAV_TOGGLE, function () {
        $scope.toggleSideNav = !$scope.toggleSideNav;
    });
    $loader.start();
    fticRecommAndNotifiModel.fetchRecommAndNotifiReport().then(function (data) {

        $loader.stop();
        fticRecommAndNotifiModel.setRecommAndNotifiReport(data);
        $scope.$broadcast(investorEventConstants.Dashboard.RECOMM_AND_NOTIFI_DATA, data);
    }, function (error) {

        $loader.stop();
        toaster.error(error.data[0].errorDescription);
    });
    $scope.showNotification = false;
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

        $scope.yesChange = true;
        $scope.fromstate = fromState.name;
        $scope.tostate = toState.name;
        var fromStClip = $scope.fromStClip = $scope.fromstate.split('.');
        var toStateClip = $scope.toStateClip = $scope.tostate.split('.');
        if ($scope.fromstate) {
            if (($scope.fromstate !== $scope.tostate) && (fromStClip[0] === 'invTransact' && transactModel.isTransactionStarted) && (((fromStClip[2] !== toStateClip[2]) || $scope.fromstate === 'invTransact.txnDetails') && toState.name !== 'invTransact.txnDetails')) {

                $scope.showNotification = true;
                if (!transactModel.navigationfromPopup) {
                    event.preventDefault();
                }
            }
        }
    });

    $scope.$on('redirectInvTransact', function () {

        if ($scope.toStateClip[0] !== 'invTransact') {

            transactModel.isTransactionStarted = false;
        }
        transactModel.isStateChangedTransact = true;
        transactModel.navigationfromPopup = true;
        $state.go($scope.tostate);
        $scope.showNotification = false;
    });
    $scope.$on('stopRedirectInvTransact', function () {
        transactModel.isStateChangedTransact = false;
        $scope.showNotification = false;
    });

    $scope.callTCSSService = function () {

        var paramsForPopupContent = {};
        paramsForPopupContent.appId = 'en-in-accounts';
        paramsForPopupContent.template = 'tc-investor-online';

        tcAndSTPopupModel.fetchPopUpContent(paramsForPopupContent).then(function (data) {

            tcAndSTPopupModel.setPopUpContent(data);
        }, function (error) {

            console.log(error);
        });
        var paramsForSTPopupContent = {};
        paramsForSTPopupContent.appId = 'en-in-accounts';
        paramsForSTPopupContent.template = 'tc-online-service-standards';

        tcAndSTPopupModel.fetchPopUpContent(paramsForSTPopupContent).then(function (data) {

            tcAndSTPopupModel.setPopUpContentForST(data);
        }, function (error) {

            console.log(error);
        });

    };

    $scope.callTCSSService();



}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.



// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.

investorController.$inject = ['$rootScope', '$scope', '$state', '$window', 'Idle', 'popupSrvc', '$localStorage', 'investorEventConstants', 'eventConstants', '$cookies', '$http', 'authenticationService', 'constants', 'toaster', 'investorDashboardInitialServices', 'fticRecommAndNotifiModel', 'globalMenuInitLoader', 'events', '$loader', 'appConfig', 'configUrlModel', '$interval', 'transactModel', 'tcAndSTPopupModel'];
module.exports = investorController;