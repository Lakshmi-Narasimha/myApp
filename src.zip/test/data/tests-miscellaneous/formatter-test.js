define(['jquery', 'lodash', 'app/common/formatter'],
  function($, _, formatter) {
  mocha.ui('bdd');
  var assert = chai.assert;
  var expect = chai.expect;

  /* Tests */

  describe('Formatter', function() {
      // this.timeout(0);  // only uncomment if you are debugging the test!!!!

      describe("formatAsEIN", function() {

          it("should format properly", function(){
              expect(formatter.formatAsEIN('000123456789')).to.equal('12-3456789');
          });

      });

      describe("formatAsEIN - empty", function() {

          it("should format properly", function(){
              expect(formatter.formatAsEIN(null, '-')).to.equal('-');
          });

      });

      describe("formatAsSSN", function() {

          it("should format properly", function(){
              expect(formatter.formatAsSSN('0000123456789')).to.equal('123-45-6789');
          });

      });

      describe("formatAsSSN - empty", function() {

          it("should format properly", function(){
              expect(formatter.formatAsSSN(null, '-')).to.equal('-');
          });

      });

      describe("formatYMDasMDY", function() {

          it("should format properly", function(){
              expect(formatter.formatYMDasMDY('2001-12-4')).to.equal('12/4/2001');
          });

      });

      describe("formatYMDasMDY - empty", function() {

          it("should format properly", function(){
              expect(formatter.formatYMDasMDY(null, '-')).to.equal('-');
          });

      });

      describe("formatAsPercent", function() {

          it("should format properly", function(){
              expect(formatter.formatAsPercent('0012')).to.equal('12%');
          });

      });

      describe("formatAsPercent - empty", function() {

          it("should format properly", function(){
              expect(formatter.formatAsPercent(null, '-')).to.equal('-');
          });

      });

      describe("formatAsDollars", function() {

          it("should format properly", function(){
              expect(formatter.formatAsDollars('001234')).to.equal('$1,234');
          });

      });

      describe("formatAsDollars - empty", function() {

          it("should format properly", function(){
              expect(formatter.formatAsDollars(null, '-')).to.equal('-');
          });

      });

      describe("maritalStatus", function() {

          it("should format properly", function(){
              expect(formatter.maritalStatus('', '-')).to.equal('Unknown');
          });
          it("should format properly", function(){
              expect(formatter.maritalStatus('D', '-')).to.equal('Divorced');
          });
          it("should format properly", function(){
              expect(formatter.maritalStatus('M', '-')).to.equal('Married');
          });
          it("should format properly", function(){
              expect(formatter.maritalStatus('P', '-')).to.equal('Parted or separated');
          });
          it("should format properly", function(){
              expect(formatter.maritalStatus('S', '-')).to.equal('Single');
          });
          it("should format properly", function(){
              expect(formatter.maritalStatus('W', '-')).to.equal('Widowed');
          });
          it("should format properly", function(){
              expect(formatter.maritalStatus('other', '-')).to.equal('other');
          });

      });

      describe("maritalStatus - empty", function() {

          it("should format properly", function(){
              expect(formatter.maritalStatus(null, '-')).to.equal('-');
          });

      });

      describe("gender", function() {

          it("should format properly", function(){
              expect(formatter.gender('', '-')).to.equal('Unknown');
          });
          it("should format properly", function(){
              expect(formatter.gender('F', '-')).to.equal('Female');
          });
          it("should format properly", function(){
              expect(formatter.gender('M', '-')).to.equal('Male');
          });
          it("should format properly", function(){
              expect(formatter.gender('other', '-')).to.equal('other');
          });

      });

      describe("gender - empty", function() {

          it("should format properly", function(){
              expect(formatter.gender(null, '-')).to.equal('-');
          });

      });

      describe("removeLeadingZeros", function() {

          it("should format properly", function(){
              expect(formatter.removeLeadingZeros('001234')).to.equal('1234');
          });

      });

      describe("removeLeadingZeros - empty", function() {

          it("should format properly", function(){
              expect(formatter.removeLeadingZeros(null, '-')).to.equal('-');
          });

      });

      describe("yesNoString", function() {

          it("should format properly", function(){
              expect(formatter.yesNoString(true)).to.equal('Yes');
              expect(formatter.yesNoString(false)).to.equal('No');
          });

      });

      describe("yesNoString - empty", function() {

          it("should format properly", function(){
              expect(formatter.removeLeadingZeros(null, '-')).to.equal('-');
          });

      });

  });




});
