'use strict';

/* jasmine specs for filter go here */

describe('validateCreditCardFilter', function() {

	var validateCreditCardFilter;
	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    validateCreditCardFilter = $injector.get('$filter')('isValidCreditCard');
	}));

	//--- Test for definition

	it('should expect validateCreditCardFilter to be defined...', function(){
		expect(validateCreditCardFilter).toBeDefined();
	});

	//--- Test validatecreditcard filter

	it('should return proper card category for given card number', function(){
		expect(validateCreditCardFilter('4012888888881881')).toBeTruthy();
	});

	it('should return proper card category for given card number', function(){
		expect(validateCreditCardFilter('5412888888888918')).toBeFalsy();
	});

	it('should return proper card category for given card number', function(){
		expect(validateCreditCardFilter('7434584784')).toBeFalsy();
	});

});