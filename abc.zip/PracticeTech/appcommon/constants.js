﻿define(['jquery', 'underscore'
  ], function ($, _) {
	var Constants = function () {
		this.contactType = {
        Client: 'client',
        Other: 'other',
        NonClient: 'nonclient'
    };
        this.subAppName = {
        Navigator: 'Navigator',
        AccountViewer:'AccountViewer',
        ContactProfile:'ContactProfile'
    };
		this.clientPersonalMaxAgeVal = 120;
		this.clientMaxAgeVal = 120;

		this.investmentExpList = {
		    ALTERNATE_INV: { code: '01', mapCode: 'K', description: 'Alternative investments (includes Managed Futures and hedge fund offerings)', servName: 'heldAwayAltInvAmt', displayOrder: 1 },
		    ANNUITIES_VAR: { code: '02', mapCode: 'C', description: 'Annuities/Variable Life', servName: 'heldAwayAnntVarLifeAmt', displayOrder: 2 },
			CERTI_CDS: { code: '03', mapCode: 'A', description: 'Certificates/CDs', servName: 'heldAwayCertOrCdAmt', displayOrder: 3 },
			COMMODITIES: { code: '04', mapCode: 'G', description: 'Commodities', servName: 'heldAwayCmdtyAmt', displayOrder: 4 },
			EQUITIES: { code: '05', mapCode: 'D', description: 'Equities (includes ETFs)', servName: 'heldAwayStkAmt', displayOrder: 5 },
			FIXED_INCOME: { code: '06', mapCode: 'E', description: 'Fixed income (includes UITs)', servName: 'heldAwayBndAmt', displayOrder: 6 },
			LIMITED_PARTNERSHIP: { code: '07', mapCode: 'H', description: 'Limited Partnerships', servName: 'heldAwayLtdPtnrAmt', displayOrder: 7 },
			MUTUALFUNDS: { code: '08', mapCode: 'B', description: 'Mutual Funds/529\'s', servName: 'heldAwayMFAmt', displayOrder: 8 },
			REITS: { code: '09', mapCode: 'L', description: 'Non-traded REITs/BDC\'s and non-traded closed-end funds', servName: 'heldAwayNonTrdREITAmt', displayOrder: 9 },
			OPTIONS: { code: '10', mapCode: 'F', description: 'Options', servName: 'heldAwayOptAmt', displayOrder: 10 },
			STRUC_PROD: { code: '11', mapCode: 'J', description: 'Structured products', servName: 'heldAwayStrcProdAmt', displayOrder: 11 },
			OTHER: { code: '12', mapCode: 'M', description: 'Other', servName: 'heldAwayOthAmt', displayOrder: 12 }
		};
		this.sortedInvestmentExpList = _.sortBy(_.first(_.values(this.investmentExpList), 11), function (o) { return o.displayOrder; });
		this.sortedAssetTypeHeldList = _.sortBy(_.values(this.investmentExpList), function (o) { return o.displayOrder; });

		this.invExpYearRadioList = {
			ALTERNATE_INV: { code: 'onetwoyears', mapCode: 'B', description: '1-2 years', displayOrder: 1 },
			ANNUITIES_VAR: { code: 'threefouryears', mapCode: 'C', description: '3-5 years', displayOrder: 2 },
			CERTI_CDS: { code: 'sixplusyears', mapCode: 'D', description: '6+ years', displayOrder: 3 }
		};
		this.sortedInvExpYearRadioList = _.sortBy(_.values(this.invExpYearRadioList), function (o) { return o.displayOrder; });

		this.noOfTransRadioList = {
			ALTERNATE_INV: { code: 'zerofivetrans', mapCode: 'A', description: '0-5', displayOrder: 1 },
			ANNUITIES_VAR: { code: 'sixfifteentrans', mapCode: 'B', description: '6-15', displayOrder: 2 },
			CERTI_CDS: { code: 'sixteenplustrans', mapCode: 'C', description: '16+', displayOrder: 3 }
		};
		this.sortedNoOfTransRadioList = _.sortBy(_.values(this.noOfTransRadioList), function (o) { return o.displayOrder; });

		this.sourceOfIncomeList = {
			EMPLOYMENT: { mapCode: 'A', description: 'Employment', displayOrder: 3 },
			SECURITY_PENSION: { mapCode: 'B', description: 'Social Security/Pension', displayOrder: 8},
			DISABILITY: { mapCode: 'C', description: 'Disability', displayOrder: 2 },
			INHERITANCE_TRUST: { mapCode: 'D', description: 'Inheritance/Trust', displayOrder: 4 },
			INVESTMENT: { mapCode: 'E', description: 'Investment', displayOrder: 5 },
			LOTTERY_GAMBLING: { mapCode: 'F', description: 'Lottery/Gambling', displayOrder: 6 },
			RENTS_ROYALTIES: { mapCode: 'G', description: 'Rents/Royalties', displayOrder: 7 },
			BUSINESS: { mapCode: 'H', description: 'Business', displayOrder: 1 },
			OTHER: { mapCode: 'I', description: 'Other', displayOrder: 10 },
			NONE: { mapCode: 'J', description: 'None', displayOrder : 9 }
		};
		this.sortedSourceOfIncomeList = _.sortBy(_.values(this.sourceOfIncomeList), function (o) { return o.displayOrder; });

		this.doesClientHaveAssetsList = {
		    HAS_ASSETS: { code: 'A', description: 'Yes', displayOrder: 1 },
		    NO_ASSETS: { code: 'C', description: 'No', displayOrder: 2 },
		    DECLINE_TO_DISCLOSE: { code: 'B', description: 'Client declines to disclose', displayOrder: 3 }
		};
		this.sortedDoesClientHaveAssetsList = _.sortBy(_.values(this.doesClientHaveAssetsList), function (o) { return o.displayOrder; });

		this.employerPriOccupationList = [
		    { "name": 'Administrative Services', "code": 'Administrative Services' },
		    { "name": 'Agriculture- Farmer', "code": 'Agriculture- Farmer' },
		    { "name": 'Agriculture- Non-farmer', "code": 'Agriculture- Non-farmer' },
		    { "name": 'Aviation (Pilot/Flight Attendant)', "code": 'Aviation (Pilot/Flight Attendant)' },
		    { "name": 'Casino Operator/Employee', "code": 'Casino Operator/Employee' },
		    { "name": 'Construction/Maintenance', "code": 'Construction/Maintenance' },
		    { "name": 'Customer Service', "code": 'Customer Service' },
		    { "name": 'Education', "code": 'Education' },
		    { "name": 'Entertainment', "code": 'Entertainment' },
		    { "name": 'Executive', "code": 'Executive' },
		    { "name": 'Financial Services Professional', "code": 'Financial Services Professional' },
		    { "name": 'Fisherman', "code": 'Fisherman' },
		    { "name": 'Food Service', "code": 'Food Service' },
		    { "name": 'Gem Stone/Precious Metal Dealer', "code": 'Gem Stone/Precious Metal Dealer' },
		    { "name": 'Government Employee', "code": 'Government Employee' },
		    { "name": 'Healthcare (doctor, nurse, dentist, etc)', "code": 'Healthcare' },
		    { "name": 'Import/Exporter', "code": 'Import/Exporter' },
		    { "name": 'Laborer', "code": 'Laborer' },
		    { "name": 'Law Enforcement', "code": 'Law Enforcement' },
		    { "name": 'Legal Services (judge, lawyer, etc)', "code": 'Legal Services' },
		    { "name": 'Manufacturing', "code": 'Manufacturing' },
		    { "name": 'Money Service Business Owner/Operator', "code": 'Money Service Business Owner/Operator' },
		    { "name": 'Non-profit', "code": 'Non-profit' },
		    { "name": 'Politician', "code": 'Politician' },
		    { "name": 'Professional Services', "code": 'Professional Services' },
		    { "name": 'Rancher', "code": 'Rancher' },
		    { "name": 'Real Estate', "code": 'Real Estate' },
		    { "name": 'Retail', "code": 'Retail' },
		    { "name": 'Sales', "code": 'Sales' },
		    { "name": 'Technology', "code": 'Technology' },
		    { "name": 'Transportation/Logistics', "code": 'Transportation/Logistics' },
		    { "name": 'Other', "code": 'Other' }
		];
		this.industryClassifications = [
		    { "name": 'U.S.-regulated bank', "code": 'IC001' },
			{ "name": 'Foreign Financial Institutional', "code": 'IC002' },
			{ "name": 'Broker Dealer', "code": 'IC003' },
			{ "name": 'U.S. regulated insurance or reinsurance company', "code": 'IC004' },
			{ "name": 'Foreign or non-US regulated insurance or reinsurance company', "code": 'IC005' },
			{ "name": 'US registered Investment Advisor', "code": 'IC006' },
			{ "name": 'Futures Commission Merchant', "code": 'IC007' },
			{ "name": 'Mutual Fund', "code": 'IC008' },
			{ "name": 'Hedge Fund or pooled investment vehicle', "code": 'IC009' },
			{ "name": 'Personal Investment Company or Personal Holding Company', "code": 'IC010' },
			{ "name": 'Municipal, County, State or Federal Government Entity', "code": 'IC011' },
			{ "name": 'Retail', "code": 'IC012' },
			{ "name": 'Casino/Gaming', "code": 'IC013' },
			{ "name": 'Agriculture', "code": 'IC014' },
			{ "name": 'Marijuana-related Industry', "code": 'IC015' },
			{ "name": 'Real Estate', "code": 'IC016' },
			{ "name": 'Manufacturing', "code": 'IC017' },
			{ "name": 'Educational Services', "code": 'IC018' },
			{ "name": 'Construction', "code": 'IC019' },
			{ "name": 'Trade - Import/Export', "code": 'IC020' },
			{ "name": 'Trade - Retail', "code": 'IC021' },
			{ "name": 'Trade - Wholesale', "code": 'IC022' },
			{ "name": 'Professional/Technical Services', "code": 'IC023' },
			{ "name": 'Transportation', "code": 'IC024' },
			{ "name": 'Entertainment', "code": 'IC025' },
			{ "name": 'Mining', "code": 'IC026' },
			{ "name": 'Utilities', "code": 'IC027' },
			{ "name": 'Health Care', "code": 'IC028' },
			{ "name": 'Non-profit', "code": 'IC029' },
			{ "name": 'Management/Consulting', "code": 'IC030' },
			{ "name": 'Other', "code": 'IC031' }
		];
		this.employmentStatusOptions = [
                { "description": "Employed", "value": "Employed", "serviceVal": "A" },
                { "description": "Self-employed", "value": "Self employed", "serviceVal": "B" },
                { "description": "Not employed", "value": "Not employed", "serviceVal": "C" },
                { "description": "Retired", "value": "Retired", "serviceVal": "D" },
                { "description": "Other (Ex. Homemaker, minor, student)", "value": "Other", "serviceVal": "E" }
		];
	    //Used in CP page for Missing Suitability Indicator
		this.missingFieldIndicator = '<div class="pt-alert-container pt-red-warning pl-pad-5px pt-margin-top-zero disp-inln-blk pl-txt-transform-none">Missing Know Your Client field</div>';
	}      
	return new Constants();
});