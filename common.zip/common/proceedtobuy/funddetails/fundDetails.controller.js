/**
 * @ngdoc property
 * @name FundDetailsController
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Display fund details for sip and lumpsum
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter

function FundDetailsController($scope, $state, fticLoggerMessage, loggerConstants, transactModel, buildPlanInitialLoader, buildPlanModelService, transactEventConstants, planSmartSolution, $filter, eventConstants, TransactConstant, configUrlModel, appConfig, fundDetailsModel, fundDetails, toaster, $window, fticStateChange) {

    var futureYear, futureMonth, futuredate, futureInstallmentDate;

    //Date variables setting - Needed to enable step up option and to validate no.of installments
    $scope.startDate = new Date();
    var startDateMonth = $scope.startDate.getMonth();
    var startDateYear = $scope.startDate.getFullYear();
    var startDateDay = $scope.startDate.getDate();

    $scope.showInfoAbtKYC = false;

     /*It includes day also*/
    $scope.oneYearDayFromToday = new Date(startDateYear + 1, startDateMonth, startDateDay);
    $scope.oneYearDayFromToday = new Date($scope.oneYearDayFromToday.toDateString());

    $scope.thirtyDaysFromToday = new Date(startDateYear, startDateMonth, startDateDay + 30);
    $scope.thirtyDaysFromToday = new Date($scope.thirtyDaysFromToday.toDateString());

    if (transactModel.getInvestorDetails()) {
        $scope.SIPholderInfoArray = [
            {key: 'First Holder', value: transactModel.getInvestorDetails().custName},
            {
                key: 'Second Holder',
                value: (transactModel.getInvestorDetails().holders.length > 1) ? transactModel.getInvestorDetails().holders[1].name : 'NA'
            },
            {
                key: 'Third Holder',
                value: (transactModel.getInvestorDetails().holders.length > 2) ? transactModel.getInvestorDetails().holders[2].name : 'NA'
            },
            {key: 'Folio. No.', value: transactModel.getInvestorDetails().folioId},
            {key: 'Mode of Holding', value: transactModel.getInvestorDetails().holdingType}
        ];
    }
    $scope.isPaperLess = false;
    $scope.isTransactNow = false;
    if(transactModel.getFlowType()==='paperless'){
        $scope.isPaperLess = true;
    }else if(transactModel.getFlowType()==='transactnow'){
        $scope.isTransactNow = true;
    }

    // data setting for the Popup
    $scope.popUpHeader= $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_LIMIT);
    $scope.popUpText= $filter('translate')(TransactConstant.buy.ANNUAL_TRANS_Desc);
    $scope.btnNo= $filter('translate')(TransactConstant.buy.CANCEL_BUTTON);
    $scope.btnYes= $filter('translate')(TransactConstant.buy.DOWNLOAD_KYC_FORM);
    $scope.noEventName = 'FundLimitCancel';

    // KYC Information Notification popup        
    $scope.kycInfoText = $filter('translate')(TransactConstant.common.SIP_KYC_INFO);
    $scope.kycInfoBtnYes = $filter('translate')(TransactConstant.common.OK);
    $scope.kycInfoYesEventName = $filter('translate')(transactEventConstants.transact.SIP_KYC_INFO_YES);

    // KYC Additional Details Notification popup        
    $scope.kycDtlsText= $filter('translate')(TransactConstant.common.KYC_ADDITIONAL_DETAILS);
    $scope.kycDtlsBtnYes= $filter('translate')(TransactConstant.common.CONTINUE);
    $scope.kycDtlsNoEventName = 'kycDetailsCancel';

    //If user selects "Download E-KYC" in download kyc notification popup
    var configURL = configUrlModel.getEnvUrl('MARKETING_URL'),  
        transactNowUrl = appConfig[configURL]+'/#tab_tab2',
        pdfUrl = appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL; 

    $scope.$on('downloadKyc', function () {
        $scope.showNotification = false;
        $window.open(pdfUrl, '_blank');
        if ($scope.isPaperLess || $scope.isTransactNow) {
            location.href = transactNowUrl;
        }else {
            fticStateChange.stateChange($state, 'smartSol.planSmartSolution.selectSS');
            //$state.go('smartSol.planSmartSolution.selectSS');
        }
    });

    //If user selects "Cancel" in download kyc notification popup
    $scope.$on('FundLimitCancel', function(){
        $scope.showNotification = false;
        if ($scope.isPaperLess || $scope.isTransactNow) {   
            location.href = transactNowUrl;         
        } else {
            fticStateChange.stateChange($state, 'smartSol.planSmartSolution.selectSS');
            //$state.go('smartSol.planSmartSolution.selectSS');
        }
    });

    /*If user seletcs "Ok" in KYC Information Popup*/
    $scope.$on(transactEventConstants.transact.SIP_KYC_INFO_YES, function() {
        $scope.showInfoAbtKYC = false;
        $scope.showKycDtlsNotif = true;
    });

    /* If user selects "Continue" in KYC Additional details popup */
    $scope.$on('showKycDtlsForm', function() {
        $scope.showKycDtlsNotif = false;
        if(transactModel.isTransactNowModule) {
            fticStateChange.stateChange($state, 'transactnow.baseNow.kycForm');
            //$state.go('transactnow.baseNow.kycForm');
        } else if(transactModel.isPaperless) {
            fticStateChange.stateChange($state, 'paperLess.kycAdditionalDtls');
            //$state.go('paperLess.kycAdditionalDtls');
        } else {
            fticStateChange.stateChange($state, 'transact.base.kycForm');
            //$state.go('transact.base.kycForm');
        }                   
    });

    /*Service Integration For InvestmentAmount - Starts*/
    var requestObject = {},returnedObj = {};
    requestObject.bodyObj = {};
    requestObject.bodyObj.fundOptions = [];

    function setRequestObject() {
        requestObject = {};
        requestObject.bodyObj = {};
        requestObject.bodyObj.fundOptions = [];
        returnedObj = fundDetailsModel.setCommonInvProperties();
        requestObject.bodyObj.folioId = returnedObj.folioId;
        requestObject.bodyObj.panNo = returnedObj.panNo;
        requestObject.bodyObj.webRefNo = returnedObj.webRefNo;

        if(planSmartSolution.getLumpsumFunds() || planSmartSolution.getSIPFunds()){
            if($scope.showLumpsum){
                setLumpsumFundOptions(planSmartSolution.getLumpsumFunds());
            }else if($scope.showSip){
                setSIPFundOptions(planSmartSolution.getSIPFunds());
            }else if($scope.showBoth){
                setLumpsumFundOptions(planSmartSolution.getLumpsumFunds());
                setSIPFundOptions(planSmartSolution.getSIPFunds());
            }
        } else {
            requestObject.bodyObj.fundOptions = [];
        }

        //Calling service with requestObject
        if (requestObject.bodyObj.panNo && requestObject.bodyObj.folioId) {
            fundDetails.fetchRvalidateInvFYLimit(requestObject).then(transactionLimitSuccess, transactionLimitFailure);
        }
    }
    var regex = new RegExp(',', 'g');

    function setSIPFundOptions(fundDetailsArray) {
        angular.forEach(fundDetailsArray, function(value) {
            var fundObj = {};
            fundObj.amount = angular.isNumber(value.sipAmount) ? value.sipAmount.toString() : value.sipAmount.replace(regex, '');
            fundObj.txnType = 'SIP';
            fundObj.startDate = value.startDate;
            fundObj.endDate = value.endDate;
            fundObj.frequency = value.frequency === TransactConstant.transact.MNTHLY ? 'M' :(value.frequency === TransactConstant.transact.FREQ_ANNUALLY ? 'A' : (value.frequency === TransactConstant.transact.QUATERLY ? 'Q' : ''));
            requestObject.bodyObj.fundOptions.push(fundObj);
        });
    }

    function setLumpsumFundOptions(fundDetailsArray) {
        angular.forEach(fundDetailsArray, function(value) {
            var fundObj = {};
            fundObj.amount = angular.isNumber(value.amount) ? value.amount.toString() : value.amount.replace(regex, '');
            fundObj.txnType = 'P';
            fundObj.startDate = '';
            fundObj.endDate = '';
            fundObj.frequency = '';
            requestObject.bodyObj.fundOptions.push(fundObj);
        });
    }

    function transactionLimitSuccess(data) {
        $scope.showNotification = false;
        $scope.showKycDtlsNotif = false;
        $scope.showInfoAbtKYC = false;
        if(!$scope.transactionLimit){
            transactModel.setKycTransactionLimit(data.allowableTxnAmount);
            $scope.transactionLimit = transactModel.getKycTransactionLimit(); 
        }

        if (!$scope.onFundLoad) {
            if (data.statusFlag === TransactConstant.transact.INVESTMENT_REJECTED_CODE) {
                $scope.showNotification = true;
            } else if (data.statusFlag === TransactConstant.transact.INVESTMENT_WARNING_CODE && ($scope.showSip || $scope.showBoth) && $scope.isKycRegAadhar) {
                $scope.showInfoAbtKYC = true;
            } else if (data.statusFlag === TransactConstant.transact.INVESTMENT_WARNING_CODE) {
                $scope.showKycDtlsNotif = true;
            } else {
                paymentDetailsRedirection();
            }
        }
    }

    function transactionLimitFailure(data) {
        toaster.error(data.data[0].errorDescription);
    }
    /*Service Integration For InvestmentAmount - Ends*/

    //For Transaction limit validation, if user is KYC-reg through Aadhar 
    transactModel.ekycJointHolderValidation();
    $scope.isKycRegAadhar = transactModel.getKYCMode();           
    $scope.$on('checkKycMode', function() {
        transactModel.ekycJointHolderValidation();
        $scope.isKycRegAadhar = transactModel.getKYCMode();
        // Fetch transaction limit from service
        if($scope.isKycRegAadhar){
            setRequestObject();
        }
    });

    //On SIPForm load
    function checkKycModeOnLoad() {
        $scope.onFundLoad = true;
        setRequestObject();
    }
    if($scope.isKycRegAadhar){
        checkKycModeOnLoad();
    }
    fticStateChange.stateChange($state, planSmartSolution.getFundDetailsState());
    //$state.go(planSmartSolution.getFundDetailsState());

    var currentState = planSmartSolution.getFundDetailsState();
    $scope.showInTransactNow = true;
    $scope.isFromPaperLess = transactModel.isPaperLess;    
    if (currentState === 'transactnow.baseNow.smartSolTransact.investment') {    
        $scope.showInTransactNow = false;
        $scope.showContinue = true;        
    } else if($scope.isPaperLess){
        $scope.showInTransactNow = false;
        $scope.showContinue = false;
        $scope.showBack = false;
    }else {
        $scope.showContinue = false;
        $scope.showBack = false;
    }

    if (transactModel.getInvestorDetails() && ($scope.showInTransactNow || $scope.isFromPaperLess)) {
        $scope.SIPholderInfoArray = [
            {key: 'First Holder', value: transactModel.getInvestorDetails().custName},
            {
                key: 'Second Holder',
                value: (transactModel.getInvestorDetails().holders.length > 1) ? transactModel.getInvestorDetails().holders[1].name : 'NA'
            },
            {
                key: 'Third Holder',
                value: (transactModel.getInvestorDetails().holders.length > 2) ? transactModel.getInvestorDetails().holders[2].name : 'NA'
            },
            {key: 'Folio. No.', value: transactModel.getInvestorDetails().folioId},
            {key: 'Mode of Holding', value: transactModel.getInvestorDetails().holdingType}
        ];
    }


    $scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;
    $scope.sipInvestment = {};
    $scope.sipInvestment.isFutureDateWithinRange = true;
    $scope.sipInvestment.isInvalidFutureDate = true;
    if (planSmartSolution.getTransactType() === 'Lumpsum') {
        $scope.showLumpsum = true;
    }
    else if (planSmartSolution.getTransactType() === 'SIP') {
        $scope.showSip = true;
    }
    else if (planSmartSolution.getTransactType() === 'Combo') {
        $scope.showBoth = true;
    }
        
    if(currentState === 'smartSol.planSmartSolution.fundDetailsSS.investment')
    {
        $scope.showContinue = true;
        $scope.showBack = true;
    }

    $scope.fdCntnuBtn = function () {
        if($scope.showSip || $scope.showBoth) {
            // var datefilter = $filter('date');
            /*Future installment Validation*/
            // futureInstallmentDate = $scope.sipInvestment.futureInstallmentDay  + ' day - '+ datefilter($scope.sipInvestment.futureInstallmentMonth, 'MMM yyyy');
            futureMonth = $scope.sipInvestment.futureInstallmentMonth.getMonth();
            futureYear = $scope.sipInvestment.futureInstallmentMonth.getFullYear();
            futuredate = new Date(futureYear, futureMonth, $scope.sipInvestment.futureInstallmentDay);
            if(futuredate < $scope.thirtyDaysFromToday || futuredate > $scope.oneYearDayFromToday){
                $scope.sipInvestment.isFutureDateWithinRange = false;
                $scope.$broadcast(eventConstants.SIP_VALIDATION_FAILED);
                return;
            }            
            else {
                $scope.sipInvestment.isFutureDateWithinRange = true;
                planSmartSolution.setFutureDate(futuredate);
                addFutureInstallment();
            }
        }
        if($scope.isKycRegAadhar || transactModel.isNewInvestor || transactModel.getIsNewFolio()){
            $scope.showNotification = false;
            $scope.showKycDtlsNotif = false;
            $scope.onFundLoad = false;
            setRequestObject();
        }else{
            paymentDetailsRedirection();
        }
    };

    function paymentDetailsRedirection(){
        // addFutureInstallment();
        if(currentState === 'transactnow.baseNow.smartSolTransact.investment') {
            $scope.$emit(transactEventConstants.transact.Show_Fund);
            $scope.$emit('paymntDtls');
        } else if(currentState === 'smartSol.planSmartSolution.fundDetailsSS.investment'){
            // $scope.paymentDtls.paymentDtlsState = "smartSol.planSmartSolution.paymentdetailsSS.investment";
            fticStateChange.stateChange($state, 'smartSol.planSmartSolution.paymentdetailsSS');
            //$state.go('smartSol.planSmartSolution.paymentdetailsSS');
        } else if(currentState === 'paperLess.transact.fundDtls.smartSol.investment'){
            $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
        }
    }

    $scope.fdBackBtn = function () {
        if(planSmartSolution.getGoalSheetState()) {
            fticStateChange.stateChange($state, planSmartSolution.getGoalSheetState());
        } else {
            fticStateChange.stateChange($state, 'smartSol.planSmartSolution.ssBase.goalSheetSummary');
        }

        //$state.go('smartSol.planSmartSolution.ssBase.goalSheetSummary');
    };

    function addFutureInstallment () {
        var sipFunds = [],
            datefilter = $filter('date'),       
            //futureInst = ,
            middleDate = datefilter(new Date($scope.sipInvestment.futureInstallmentMonth), 'MM')+'/'+$scope.sipInvestment.defaultDaySelected.title+'/'+datefilter(new Date($scope.sipInvestment.futureInstallmentMonth), 'yyyy'),
            futureDate = datefilter(new Date(middleDate), 'dd/MM/yyyy');
        angular.forEach(planSmartSolution.getSIPFunds(), function (obj) {
           var fundsParams = {};
            fundsParams = obj;
            fundsParams.firstInstallment = datefilter(new Date(), 'dd/MM/yyyy');
            fundsParams.futureDate = futureDate;
            fundsParams.futureInstallment = futureDate;
            fundsParams.startDateSS = futureDate;
            sipFunds.push(fundsParams);
        });
        planSmartSolution.setSIPFunds(sipFunds);
    }

    $scope.$on(eventConstants.PAPERLESS_CONTINUE_CLICKED, function(){            
        /*if($scope.showSip || $scope.showBoth) {
            addFutureInstallment();
        }
        $scope.$emit(eventConstants.PAPERLESS_VALIDATED);*/
        $scope.fdCntnuBtn();
    });

}

FundDetailsController.$inject = ['$scope', '$state', 'fticLoggerMessage', 'loggerConstants', 'transactModel', 'buildPlanInitialLoader', 'buildPlanModelService', 'transactEventConstants', 'planSmartSolution', '$filter', 'eventConstants', 'TransactConstant', 'configUrlModel', 'appConfig', 'fundDetailsModel', 'fundDetails', 'toaster', '$window', 'fticStateChange'];

module.exports = FundDetailsController;