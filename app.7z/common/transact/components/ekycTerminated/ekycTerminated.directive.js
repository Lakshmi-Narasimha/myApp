/**
 * @ngdoc property
 * @name Destination Fund Directive
 * @requires newFundDetailsModel
 * @requires $uibModal
 * @requires selectFundModel
 * @description
 *
 * - Destination Fund directive represents the existing funds of investor along with a chance to create a new fund. 
 *
 **/
'use strict';

var fundInfoTile = function($state, transactModel) {
	return {
            template: require('./ekycTerminated.html'),
            restrict: 'E',
            replace: true,
            controller:['$scope', function($scope){ 
                $scope.showBuy = false; 
                 $scope.isTransactNow = false;
                if ($state.current.name == 'transactnow.ekycRegistration' || $state.current.name == 'transactnow.newFolioNnewInvestor') {
                    $scope.isTransactNow = true;
                }

                if (transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") 
                $scope.showBuy = true;                    
            	
            	$scope.continue = function(stateVal){
                    //Resetting all the values
                    transactModel.resetSetters();
                    transactModel.isNewInvestor = false;
                    transactModel.setTransactType({key:null})
            		
            		if($scope.isTransactNow){
						$state.go("transactnow.baseNow."+stateVal);
            		}else{
            			
            			$state.go("transact.base."+stateVal);
            		}
            		
            	}
            }]
        };

};

fundInfoTile.$inject = ['$state','transactModel'];
module.exports = fundInfoTile;