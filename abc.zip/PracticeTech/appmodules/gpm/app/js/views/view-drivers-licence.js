define(['jquery', 'underscore', 'backbone', 'appmodules/gpm/app/js/utils', 'appmodules/ncst/app/js/models/model-address-entry', 'appmodules/ncst/app/data/country-list', 'appmodules/contactprofile/app/models/cpviewmodel', 'text!appmodules/gpm/app/templates/gpmdriverslicense.html',
], function ($, _, Backbone, Utils, AddressModel, StateList, CPViewModel, DriversLicenceTemplate) {
			var self;
		    var driversLicenceView = Backbone.View.extend({
		        el: "#gpm-form-update-field-container",
		        id: 'gpm-form-update-field-container',
		        events: {

		        },
		        template: _.template (DriversLicenceTemplate),
		        initialize: function (data) {
		            self = this;
		            this.data = data;
		            $(document).off('keyup', '#cd-driver-license').on('keyup', '#cd-driver-license', self.showStates);
		        },
		        render: function (updateMode) {
		        	try{
		        		var self = this;
		        		if(!self.model.get('currentItemSet')){
		        			var CPData = CPViewModel.getInstance().getData();
				        	var state = (_.find(StateList.USStateslist,function(obj){return obj.code == CPData.cola.clientPersonal.get('drvLicStCd')}) || {name:"",code:""});
				        	this.data.fieldsInfo = {drvLicNbr: (CPData.cola.clientPersonal.get('drvLicNbr') || ""), drvLicStCd: (CPData.cola.clientPersonal.get('drvLicStCd') || ""), drvLicSt:(state.name || "")};
				        	this.model.setCurrentValue(updateMode,{data:this.data});
		        		}
		        		var _dataSet = this.model.get('items');
		        		var _stateid = _dataSet.find(function(row){return row.get("itemType") == "stateid"}).get("changedItemValueId");
		        		$("#"+this.id).html(this.template({data:_dataSet})).promise().done(function(){
		        		    self.loadStateList(_stateid);
		        		    self.showStates();
			        	});
		        		
		        	}
		        	catch(error){
		        		console.log(error);
		        	}
		        	
		        },
		        loadStateList: function(selStateCd) {
	                var _stateList = StateList.USStateslist;
	                var _selectbox = "#us-states-list-details-page";
	                //Utils.loadSelectbox(_selectbox, _stateList, selStateCd, false);

	                var _options = {
	                    selectBox: _selectbox,
	                    optionsList: _stateList,
	                    selectedVal: selStateCd,
	                    noEmptyOption: false,
	                    isOptional: false,
	                    //noneOption: {
	                    //    value: "",
	                    //    label: "None"
	                    //}
	                }
	                Utils.loadSelectbox(_options);

		        },
		        showStates: function () {
		            if ($('#cd-driver-license').val().length && AddressModel.get('primaryAddress').addressType != 'Foreign') {
		                $('#cd-us-states-list').show();
		            } else {
		        		var _stateid = self.model.get('items').find(function(row){return row.get("itemType") == "stateid"});
		        		_stateid.set("changedItemValue",_stateid.get("currentItemValue"));
		        		_stateid.set("changedItemValueId",_stateid.get("currentItemValueId"));
		        		$("#us-states-list-details-page").val(_stateid.get("currentItemValueId"));
		                $('#cd-us-states-list').hide();
		            }
		        },
		        validateAndNavigateFromStep1:function(){
		        	if(this.model.validate('gpm-update-form',true)){
		        		this.model.setChangedValue();
		        		if(this.model.getChangedItems().length>0){
		        			$('.gpm-step.step1').addClass("finished").removeClass("active");
				        	$('.gpm-step.step2').addClass("active");
				        	Backbone.history.navigate('gpm/verification/'+this.model.get('updateMode'), true);
		        		}else{
		        			Utils.showNoChangesMessageToUser();
		        		}
			        	
		        	}
		        }
		        
		    });
		    return driversLicenceView;
		});