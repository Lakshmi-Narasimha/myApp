/**
 * @ngdoc filter
 * @name Filter FormatTwoDigitNum
 * @description
 *
 * - Filter method to format number to 2 digits.
 *
 */


'use strict';

var fticInvFormatTwoDigitNum = function() {

	return function(value) {
		if(!value) {
            return 0;
        } else {
            return (value < 10 ? '0'+value : value);
        }
	};
};

fticInvFormatTwoDigitNum.$inject = [];
module.exports = fticInvFormatTwoDigitNum;
