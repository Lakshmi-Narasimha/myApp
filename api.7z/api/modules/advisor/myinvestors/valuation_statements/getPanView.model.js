// getPanView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var PanViewSchema = new mongoose.Schema({
    PanViewObject: {
        type: Array,
        "default": []
    }
});

var PanViewLookUp = mongoose.model('PanViewLookup', PanViewSchema);

var PanViewModel = new PanViewLookUp({
	"PanViewObject" : [{
		"AumSplitDetails" : {
			"chartData" : {
				"equity" : "5.47L",
	            "fixedincome" : "5.25L",
	            "balanced" : "4.1L",
	            "elss" : "3.6L",
	            "fof" : "0.6L",
	            "feeder" : "0.6L",
	            "liquid" : "0.2L"
			},
			"totalAum" : "32,34,355"
		},
		"unitHolderdetails" : {
			"name" : "Shankar",
			"address" : {
              "line1":"B-34 Acrot Street No 161 Yerapalli street",
              "line2":"Vadapallani",
              "line3":"Chennai 763001"
            }
		},
		"portfolioDetails" : {
			"rows" : [
				{
					"folioNumber":"789145",
					"ModeofHolding":"Joint",
					"CurrentCost":"333",
					"CurrentValue":"6767"
				},
				{
					"folioNumber":"789245",
					"ModeofHolding":"Joint",
					"CurrentCost":"333",
					"CurrentValue":"6767"
				},
				{
					"folioNumber":"789345",
					"ModeofHolding":"Joint",
					"CurrentCost":"333",
					"CurrentValue":"6767"
				}
			],
			"grandTotal" : {
				"folioNumber":"GRAND TOTAL",
				// "ModeofHolding":"&nbsp;",
				"CurrentCost" : "222",
				"CurrentValue" : "333"
			}
		},
		"investmentSummary" : [
			{
				"folioNumber" : "789345",
				"rows" : [
					{
						"Account":"788876876534",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"545",
						"CurrentCost":"2134",
						"CurrentValue":"312.43",
						"Return":"26%"
					},
					{
						"Account":"7567542342",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"454",
						"CurrentCost":"2335",
						"CurrentValue":"897.43",
						"Return":"26%"
					},
					{
						"Account":"87686785252",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"424",
						"CurrentCost":"787",
						"CurrentValue":"312.43",
						"Return":"26%"
					}
				],
				"modeofHolding" : "joint",
				"holders": {
					"firstHoldersName": "Suresh",
					"secondHoldersName": "Meenakshi",
					"minorGuardian": "Srinari"
				},
				"grandTotal" : {
					"Account":"GRAND TOTAL",
					"Scheme":"&nbsp;",
					"TotalUnits" : "276",
					"CurrentCost" : "16,789",
					"CurrentValue" : "1073.78",
					"Return":"&nbsp;"
				}
			},
			{
				"folioNumber" : "789345",
				"rows" : [
					{
						"Account":"788876876534",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"545",
						"CurrentCost":"2134",
						"CurrentValue":"312.43",
						"Return":"26%"
					},
					{
						"Account":"7567542342",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"454",
						"CurrentCost":"2335",
						"CurrentValue":"897.43",
						"Return":"26%"
					},
					{
						"Account":"87686785252",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"424",
						"CurrentCost":"787",
						"CurrentValue":"312.43",
						"Return":"26%"
					}
				],
				"modeofHolding" : "joint",
				"holders": {
					"firstHoldersName": "Ramesh",
					"secondHoldersName": "Meenakshi",
					"minorGuardian": "Akhila"
				},
				"grandTotal" : {
					"Account":"GRAND TOTAL",
					"Scheme":"&nbsp;",
					"TotalUnits" : "276",
					"CurrentCost" : "16,789",
					"CurrentValue" : "1073.78",
					"Return":"&nbsp;"
				}
			},
			{
				"folioNumber" : "789345",
				"rows" : [
					{
						"Account":"788876876534",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"545",
						"CurrentCost":"2134",
						"CurrentValue":"312.43",
						"Return":"26%"
					},
					{
						"Account":"7567542342",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"454",
						"CurrentCost":"2335",
						"CurrentValue":"897.43",
						"Return":"26%"
					},
					{
						"Account":"87686785252",
						"Scheme":"Freklin India Tax shield",
						"TotalUnits":"424",
						"CurrentCost":"787",
						"CurrentValue":"312.43",
						"Return":"26%"
					}
				],
				"modeofHolding" : "joint",
				"holders": {
					"firstHoldersName": "Shankar Narayan",
					"secondHoldersName": "Meenakshi",
					"minorGuardian": "Archana"
				},
				"grandTotal" : {
					"Account":"GRAND TOTAL",
					"Scheme":"&nbsp;",
					"TotalUnits" : "276",
					"CurrentCost" : "16,789",
					"CurrentValue" : "1073.78",
					"Return":"&nbsp;"
				}
			}
		]
	}]
});

PanViewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating PanViewLookUp table, please contact admin...');
    } else {
        PanViewLookUp.remove({}, function(err) {
            console.log('PanViewLookUp collection removed');
            PanViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating PanViewLookUp table, please contact admin...');
                }
                console.log('PanViewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PanViewLookUp;
