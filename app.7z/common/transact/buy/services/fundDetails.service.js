/**
 * @ngdoc service
 * @name fundDetails
 * @description
 *
 * - It will hit the restangular(network service) call and resolve the data to wrapper.
 * Also works like model with setters and getters.
 *
 */

'use strict';
 
var fundDetails = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
 
        var _selectedFund = null, 
            _fundType = null,
            _totalAmount = null,
            _amountType = null,
            _selectedFundArr = [],
            _fundDetailArr = [],
            _buyTotalAmount = null,
            _fundOption = null,
            _nfoFlag = null,
            _direct = null,
            _accNo = null,
            _dividendFlag = null,
            _txnType = null;
         
    var fundDetails = {

        fetchTxnDetailsBuy : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('getTxnDetailsBuy').get(params).then(function (buyDetails) {
                deferred.resolve(buyDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        fetchRvalidateInvFYLimit : function(reqObj){         
            reqObj.paramObj = {"guId" : authenticationService.getUser().guId}; 
            var deferred = $q.defer();
            Restangular.one('transact/validateInvFYLimit').customPOST(reqObj.bodyObj, "", reqObj.paramObj, {}).then(function (success) {
                deferred.resolve(success);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        setFundDetails : function(obj) {
            _fundDetailArr.push(obj);
        },

        getFundDetails : function() {
            return angular.copy(_fundDetailArr);
        },

        setFundArr : function(obj) {
            _selectedFundArr.push(obj);
        },

        getFundArr : function() {
            return _selectedFundArr;
        },

        setFundType : function(fundType) {
            _fundType = fundType;
        },

        getFundType : function() {
            return _fundType;
        },

        getSelectedFund : function() {
            return _selectedFund;
        },

        setSelectedFund : function(selectedFund) {
            _selectedFund = selectedFund;
        },

        getTotalAmount : function() {
            return _totalAmount;
        },

        setTotalAmount : function(totalAmount) {
            _totalAmount = totalAmount;
        },
        getAmountType : function() {
            return _amountType;
        },

        setAmountType : function(amountType) {
            _amountType = amountType;
        },

        removeTile : function(index){
             _fundDetailArr.splice(index,1);
        },
        removeFundArr : function(index){
             _selectedFundArr.splice(index,1);
        },

        removeObj : function() {
            _selectedFund = null;
            _fundType = null;
            _totalAmount = null;
            _amountType = null;
            _fundOption = null;
            _nfoFlag = null;
        },

        removeFundDetails : function () {
            _fundDetailArr = [];
        },
        initialFundArr : function () {
            _selectedFundArr = [];
            return _selectedFundArr;
        },

        getBuyTotalAmount : function() {
            return _buyTotalAmount;
        },

        setBuyTotalAmount : function(buyTotalAmount) {
            _buyTotalAmount = buyTotalAmount;
        },

        getFundOption : function() {
            return _fundOption;
        },

        setFundOption : function(fundOption) {
            _fundOption = fundOption;
        },

        getNfoFlag : function() {
            return _nfoFlag;
        },

        setNfoFlag : function(nfoFlag) {
            _nfoFlag = nfoFlag;
        },

        getDirectFlag : function() {
            return _direct;
        },

        setDirectFlag : function(direct) {
            _direct = direct;
        },

        getAccNo : function() {
            return _accNo;
        },

        setAccNo: function(accNo) {
            _accNo = accNo;
        },

        getDividendFlag: function() {
            return _dividendFlag;
        },

        setDividendFlag: function(dividendFlag) {
            _dividendFlag = dividendFlag;
        },

        getTxnType: function() {
            return _txnType;
        },

        setTxnType: function(txnType) {
            _txnType = txnType;
        }
    };
    
    return fundDetails;
};

fundDetails.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];

module.exports = fundDetails;