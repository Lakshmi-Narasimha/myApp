define([], function () {

    var instance = null;
    function init() {
       var data = {
            cola: undefined,
            ebix: undefined,
            scheduledAddress: undefined
        };
        return {
            setData: function (_data) {
                if (_data.cola) {
                    data.cola = _data.cola;
                }
                if (_data.ebix) {
                    data.ebix = _data.ebix;
                }
                if (_data.scheduledAddress) {
                    data.scheduledAddress = _data.scheduledAddress;
                }
            },
            getData: function () {
                return data;
            },
            clearData: function () {
                data.cola = undefined;
                data.ebix = undefined;
                data.scheduledAddress = undefined;
            }
        };
    };
    return {
        getInstance: function () {
            if (!instance) {
                instance = init();
            }
            return instance;
        }
    }
});