var express = require('express'),
    router = express.Router(),
    Advisordashboard = require('./getAdvisorDashboard.model'),
    SipDetails = require('./getAdvisorSipDetailsView.model'),
    AdvisorRecommendations = require('./getAdvisorRecommendations.model'),
    AdvisorPreferences = require('./getAdvisorPreferences.model'),
    AdvisorNotifications = require('./getAdvisorNotifications.model'),
    AdvisorContent = require('./getAdvisorContent.model'),
    UserWidgets = require('./getUserWidgets.model');

// api route

var error = [
    {
        errorCode: "A0003",
        errorMessage: "Something went wrong"
    }
]


router.route('/dashboard/advisorDashboard')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        Advisordashboard.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].advisorDashboardObject.length === 0) {
                res.send(error);
            } else {
                res.send(data[0].advisorDashboardObject[0]);
                //res.send(500, error);

            }

        });
    });

router.route('/getAdvisorSipDetails')
    .get(function (req, res) {
        SipDetails.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].advisorSipDetailsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].advisorSipDetailsObject);
            }

        });
    });
router.route('/getAdvisorRecommendations')
    .get(function (req, res) {
        AdvisorRecommendations.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].advisorRecommendationsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].advisorRecommendationsObject);
            }

        });
    });

    router.route('/getAdvisorNotifications')
    .get(function (req, res) {
        AdvisorNotifications.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].advisorNotificationsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].advisorNotificationsObject);
            }

        });
    });
    router.route('/getAdvisorContent')
    .get(function (req, res) {
        AdvisorContent.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].advisorContentObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].advisorContentObject);
            }

        });
    });
   
router.route('/userWidgets')
    .get(function (req, res) {
        AdvisorPreferences.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].advisorPreferencesObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].advisorPreferencesObject[0]);
            }

        });
    });

    router.route('/getUserWidgets')
    .get(function (req, res) {
        UserWidgets.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].userWidgetsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].userWidgetsObject);
            }

        });
    });
   

module.exports = router;
