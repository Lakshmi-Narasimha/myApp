// getinvestorfoliodetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InvestorFolioDetailsSchema = new mongoose.Schema({
    investorFolioDetailsObject: {
        type: Array,
        "default": []
    }
});

var InvestorFolioDetailsLookUp = mongoose.model('InvestorFolioDetailsLookUp', InvestorFolioDetailsSchema);
/*json order: investor book-*/
var InvestorFolioDetailsModel = new InvestorFolioDetailsLookUp({
    "investorFolioDetailsObject": [
    {
       "inverstorFoliosShares": [
    {
      "range": "Below 1L",
      "folioShares": "77.61%"
    },
    {
      "range": "1L to 5L",
      "folioShares": "18.76%"
    },
    {
      "range": "5L to 50L",
      "folioShares": "03.36%"
    },
    {
      "range": "Above 50L",
      "folioShares": "0.27%"
    }
  ]

      }
    ]

});

InvestorFolioDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorFolioDetailsLookUp table, please contact admin...');
    } else {
        InvestorFolioDetailsLookUp.remove({}, function(err) {
            console.log('InvestorFolioDetailsLookUp collection removed');
           InvestorFolioDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InvestorFolioDetailsLookUp table, please contact admin...');
                }
                console.log('InvestorFolioDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorFolioDetailsLookUp;
