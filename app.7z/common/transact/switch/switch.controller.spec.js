'use strict';
describe('Controller: switchController', function() {
	var $controller,$scope,switchController,TransactConstant,$filter;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_TransactConstant_,_$filter_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();
		
		TransactConstant = _TransactConstant_;
		$filter = _$filter_;		

		$scope.config = {"txnFormDetails":{}};	
		$scope.header = {"title": ""};
		loadController();			
	}));	

	function loadController(){
        switchController = $controller('SwitchCtrl', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(switchController).toBeDefined();
    });

    it('should define the variables config,header',function(){
    	expect($scope.config.txnFormDetails.title).toBe($filter('translate')(TransactConstant.transact.SWITCH_DTLS));
    	expect($scope.header.title).toBe(TransactConstant.switch.SWITCH_HEADING);
    })
});