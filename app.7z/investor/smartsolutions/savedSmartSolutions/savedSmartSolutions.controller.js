/**
 * @ngdoc property
 * @name Saved Smart Solutions Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Saved Smart Solutions controller for smartSolutions module.
 *
 **/

'use strict';

function savedSmartSolutionsController($scope, $state, savedSmartSolutionsInitLoader, savedSmartSolutionsModel, investorEventConstants) {
    console.log('savedSmartSolutionsController');
    $scope.viewObj = {};
    $scope.header.title = 'Saved Smart Solutions';
    $scope.text = 'hey this is savedSmartSolutionsController';
  $scope.viewObj.loadsmartSolutionsGrid = false;
    $scope.$on(investorEventConstants.smartSolutions.SAVED_SMART, function(event, data) {
    	console.log('investorEventConstants')
        $scope.viewObj.loadsmartSolutionsGrid = true;

    });

    savedSmartSolutionsInitLoader.loadAllServices($scope);
    

}

savedSmartSolutionsController.$inject = ['$scope', '$state', 'savedSmartSolutionsInitLoader', 'savedSmartSolutionsModel', 'investorEventConstants'];
module.exports = savedSmartSolutionsController;
