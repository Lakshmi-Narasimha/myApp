// swp.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ValidateRedeemModelSchema = new mongoose.Schema({
    validateRedeemResp: {
        type: Object,
        'default': {}
    }
});

var ValidateRedeemModelLookUp = mongoose.model('ValidateRedeemModelLookUp', ValidateRedeemModelSchema);

var ValidateRedeemModel = new ValidateRedeemModelLookUp({
    validateRedeemResp: {
        'accountNo': '0380000217154',
        'folioId': '13884342',
        'transactionValidated': 'true',
        'webRefNo': 'SWD000893'
    }
});

ValidateRedeemModelLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ValidateRedeemModelLookUp table, please contact admin...');
    } else {

        ValidateRedeemModelLookUp.remove({}, function () {
            console.log('ValidateRedeemModelLookUp collection removed');
            ValidateRedeemModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating ValidateRedeemModelLookUp table, please contact admin...');
                }
                console.log('ValidateRedeemModelLookUp table created in mongoose...');
            });
        });
    }
});

module.exports = ValidateRedeemModelLookUp;