/**
 * @ngdoc property
 * @name fticracDetails Directive
 * @description
 *
 * fticracDetails - Displays the Review & Confirm Detail
 *
 **/
'use strict';



function ReviewDTPCtrl($scope, fticLoggerMessage, loggerConstants, reviewDtpDetailsModel, eventConstants, $filter,$state, swpModel) {

    $scope.config.toTxnDetailsState = "invTransact.txnDetails";
    $scope.config.toState = "invTransact.base.dtp"; 
    $scope.config.fromState = $state.current.name;
    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){
   		reviewDtpDetailsModel.isSwitchEdited= true; 
      $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'dtp'});
    });
    
    


  
}


ReviewDTPCtrl.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', 'reviewDtpDetailsModel', 'eventConstants', '$filter','$state','swpModel'];
module.exports = ReviewDTPCtrl;