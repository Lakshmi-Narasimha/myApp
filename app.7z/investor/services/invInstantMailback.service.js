/**
 * @ngdoc property
 * @name changePasswordModel
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - instantmailbackModel is a service for requesting mailback.
 *
 **/
'use strict';


var invInstantMailback = function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var mailbackQuery = {};
    var instantMailbackModel = {
        postInstantMailBackDetails: function(body) {
            var deferred = $q.defer();
            var params = {};
            params.guId = authenticationService.getUser().guId;
            Restangular.one('services/instantMailback').customPOST(body, '', params).then(function(transactDetails) {
                console.log(transactDetails);
                deferred.resolve(transactDetails);
            }, function(resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setMailBackData: function(queryObject) {
            mailbackQuery = {
                'emailId': '',
                'userId': '',
                'userType': '',
                'folioPanAcc': queryObject.folioPanAcc || '',
                'flag': '',
                'options': ['VAS'],
                'fromDate': queryObject.fromDate || '',
                'toDate': queryObject.toDate || '',
                'formats': [],
                'periodType': queryObject.periodType || ''
            };

        },
        getMailBackData: function() {
            return mailbackQuery;
        },
        getDateRangeFromCurrentData: function() {
            var _fdate = mailbackQuery.fromDate;
            var _tdate = mailbackQuery.toDate;
            var _drange = [];
            if (_fdate && _tdate) {
                if (_fdate === _tdate) {
                    _drange.push(_fdate);
                } else {
                    _drange.push(_fdate + ':' + _tdate);
                }
            }
            return _drange;
        },
        getDateRangeForCurrentCapitalGain: function() {
            var _drange = [];
            if (mailbackQuery.periodType && mailbackQuery.periodType.toUpperCase() === 'CY') {
                _drange = ['CFY'];
            } else if (mailbackQuery.periodType && mailbackQuery.periodType.toUpperCase() === 'LF') {
                _drange = ['LFY'];
            }
            return _drange;
        }
    };
    return instantMailbackModel;
};

invInstantMailback.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = invInstantMailback;
