// getIfscSearch.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var IfscSearchSchema = new mongoose.Schema({
    IfscSearchObject: {
        type: Array,
        "default": []
    }
});

var IfscSearchLookUp = mongoose.model('IfscSearchLookUp', IfscSearchSchema);

var IfscSearchDetailsModel = new IfscSearchLookUp({
	"IfscSearchObject" : [{
		"cities": [
				    "Mumbai",
				    "Hyderabad",
				    "Chennai"
				  ],
		"branches": ["SERVICE BRANCH, CHANDIGARH", "SERVICE BRANCH22, CHANDIGARH"],
		"bankDetails":[
			{"ifscCode":"HDFC0000835",
			"bankName":"HDFC BANK LTD",
			"branchName":"BANDRA EAST - KALANAGAR",
			"city":"022-61606161"},
            {"ifscCode":"HDFC0000894",
			"bankName":"HDFCsdf BANK LTD",
			"branchName":"BANDRA EASsdfT - KALANAGAR",
			"city":"022-61sdf606161"}
		]
	}]
});

IfscSearchLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating IfscSearchLookUp table, please contact admin...');
    } else {
        IfscSearchLookUp.remove({}, function(err) {
            console.log('IfscSearchLookUp collection removed');
            IfscSearchDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating IfscSearchLookUp table, please contact admin...');
                }
                console.log('IfscSearchLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = IfscSearchLookUp;
