// getAdvisorRecommendations.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AdvisorRecommendationsSchema = new mongoose.Schema({
    advisorRecommendationsObject: {
        type: Array,
        "default": []
    }
});

var AdvisorRecommendationsLookUp = mongoose.model('AdvisorRecommendationsLookup', AdvisorRecommendationsSchema);

var AdvisorRecommendationsModel = new AdvisorRecommendationsLookUp({

  "advisorRecommendationsObject": [
    {
       "recommendations":{
          "count":12,
          "items":[
             {
                "title":"bold text",
                "text":"275 SIPs out of your SIP book with us due for renewal in the next month",
                "linkTitle":"View SIP Details",
                "linkURL":""
             },
             {
                "title":"bold text",
                "text":"73% of investors have no exposure to overseas fund",
                "linkTitle":"View Inventor List",
                "linkURL":""
             },
             {
                "title":"bold text",
                "text":"Last few weeks left to help clients save tax. Check-out the names of the clients who need tax saver fund.",
                "linkTitle":"View Inventor List",
                "linkURL":""
             }
          ]
       }
    }  
  ]

});

AdvisorRecommendationsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AdvisorRecommendationsLookUp table, please contact admin...');
    } else {
        AdvisorRecommendationsLookUp.remove({}, function(err) {
            console.log('AdvisorRecommendationsLookUp collection removed');
            AdvisorRecommendationsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AdvisorRecommendationsLookUp table, please contact admin...');
                }
                console.log('AdvisorRecommendationsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AdvisorRecommendationsLookUp;
