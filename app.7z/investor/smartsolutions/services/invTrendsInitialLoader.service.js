'use strict';

var invTrendsInitialLoaderService = function (invTrendsModel, advisorEvents, advisorEventConstants) {

    var invTrendsInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope) {

            invTrendsModel.fetchInvTrendsDtls()
                .then(invTrendsSuccess, handleFailure);

            function invTrendsSuccess(data) {
                // console.log(data);
                invTrendsModel.setInvTrendsDtls(data);
                advisorEvents.smartSolutions.publishInvTrends(scope,invTrendsModel.getInvTrendsDtls());

            }

            function handleFailure(data){
                console.error('handleFailure');
                invTrendsInitialLoader._isServicesData = false;
            }
        }

    };
    return invTrendsInitialLoader;
};

invTrendsInitialLoaderService.$inject = ['invTrendsModel', 'advisorEvents', 'advisorEventConstants'];

module.exports = invTrendsInitialLoaderService;