/**
 * @ngdoc property
 * @name bankNamesModel
 * @requires Restangular
 * @requires $q
 * @description
 * 
 *
 **/
'use strict';


var bankNamesModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _invBankNameList = null;    
    var bankNameDetails = {
        getBankNamesList: function() {
            /*invBankAccDetails.guId = authenticationService.getUser().guId;*/
            var deferred = $q.defer(); 
            Restangular.one('/accountSettings/basisBankListDetails').get().then(function(BankListDetails) {
                deferred.resolve(BankListDetails);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        setBasisBankNames: function(bankNamedetails){
            console.log(bankNamedetails)
            _invBankNameList = bankNamedetails; 
        },
        getBasisBankNames: function(){
            return _invBankNameList;
        }       
    };

    return bankNameDetails;

};

bankNamesModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = bankNamesModel;
