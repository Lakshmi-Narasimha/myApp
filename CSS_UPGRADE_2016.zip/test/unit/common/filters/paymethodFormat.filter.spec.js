'use strict';

/* jasmine specs for filter go here */

describe('payMethodFormatFilter', function() {

	var payMethodFormatFilter,
		payMethodDottedFormatFilter,
        paymentMethodDefaultFilter,
        paymentTypeFilter,
        paymentHolderNameFilter,
        autoPayMethodDottedFormatFilter,
        formattedPaymentMethodFilter,
	payMethodCard = {
    'systemGeneratedEncryptedNumberForBank': null,
    'statusOnBillingAccountNumber': 'N',
    'scheduleFlagForCreditCard': 'N',
    'scheduleFlagForBankDetails': null,
    'paymentDivision': '0000029121,2043123652',
    'paymentCardsValidTo': '2015-12',
    'paymentCardsValidFrom': '2010-12',
    'paymentCardID': '2002',
    'cardCategory': 'VI',
    'maskedValueForCreditCard': '****1234',
    'maskedValueForEncryptedValueForCreditCard': '************2668',
    'encryptedNumberForCreditCard': 'safsaftysrzxxvsgydfxgytwdysi',
    'descriptionOfStatus': '',
    'defaultOrLastPaymentMethodType': 'Y',
    'cityPostalCode': '12345',
    'cardType': 'CR',
    'bankNickName': null,
    'cardNickName': 'VISA_CC',
    'cardIdNumber': ':uUEpHt6UbUGH7oTCOguo8/vtl3ASO7Ba:',
    'cardHolderName': 'Card User',
    'bankKeysRoutingNumber': '101000187',
    'bankAccountType': null,
    'bankAccountHolderNickName': null,
    'automaticSetupFlagForCreditCard': 'N',
    'automaticSetupFlagForBankDetails': null,
    'accountIdNumber': null,
    'accountHolderName': null
  	},
  	payMethodBank = {
    'systemGeneratedEncryptedNumberForBank': 'pXcMJAHMy+mx6GJm/vG44w==',
    'statusOnBillingAccountNumber': 'S',
    'scheduleFlagForCreditCard': null,
    'scheduleFlagForBankDetails': 'N',
    'paymentDivision': '0000029121,2043123652',
    'paymentCardsValidTo': null,
    'paymentCardsValidFrom': null,
    'paymentCardID': null,
    'cardCategory': null,
    'maskedValueForValueForBank': '**********7890',
    'maskedValueForEncryptedValueForCreditCard': null,
    'encryptedNumberForCreditCard': null,
    'descriptionOfStatus': '',
    'defaultOrLastPaymentMethodType': 'N',
    'creditCardType': null,
    'cityPostalCode': null,
    'cardType': null,
    'cardIdNumber': null,
    'cardHolderName': null,
    'bankKeysRoutingNumber': '101000187',
    'bankNickName': 'My Savings account',
    'cardNickName': null,
    'bankAccountType': 'SAV',
    'bankAccountHolderNickName': 'EFT',
    'automaticSetupFlagForCreditCard': null,
    'automaticSetupFlagForBankDetails': 'Y',
    'accountIdNumber': '2001',
    'accountHolderName': 'Account User'
  };
  window.PAYMENT_METHOD_CODES = {
        'VI': 'Visa',
        'MC': 'MasterCard',
        'CR': 'Credit',
        'DB': 'Debit',
        'CHK': 'Checking',
        'SAV': 'Savings',
        'DS': 'Discover',
        'AX': 'Amex'
    };

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    payMethodFormatFilter = $injector.get('$filter')('payMethodFormat');
	    payMethodDottedFormatFilter = $injector.get('$filter')('payMethodDottedFormat');
        paymentMethodDefaultFilter = $injector.get('$filter')('paymentMethodDefault');
        paymentTypeFilter = $injector.get('$filter')('paymentType');
        paymentHolderNameFilter = $injector.get('$filter')('paymentHolderName');
        autoPayMethodDottedFormatFilter = $injector.get('$filter')('autoPayMethodDottedFormat');
        formattedPaymentMethodFilter = $injector.get('$filter')('formattedPaymentMethod');
	}));

	//--- Test for definition

	it('should expect payMethodFormatFilter to be defined...', function(){
		expect(payMethodFormatFilter).toBeDefined();
        expect(payMethodDottedFormatFilter).toBeDefined();
        expect(paymentMethodDefaultFilter).toBeDefined();
        expect(paymentTypeFilter).toBeDefined();
        expect(paymentHolderNameFilter).toBeDefined();
	});

	//--- Test paymethodformat filter

	it('should format the given paymentMethod with proper description for credit card...', function(){
		expect(payMethodFormatFilter(payMethodCard)).toEqual('VISA_CC ending 2668');
	});

	it('should format the given paymentMethod with proper description for bank...', function(){
		expect(payMethodFormatFilter(payMethodBank)).toEqual('EFT ending 7890');
	});

    //--- Test paymethoddottedformat filter

    it('should return blank when paymethod is null...', function(){
        expect(payMethodDottedFormatFilter(undefined)).toEqual('');
    });

	it('should format the given payMethod with proper description for credit card...', function(){
		expect(payMethodDottedFormatFilter(payMethodCard)).toEqual('VISA_CC (...2668)');
	});



	it('should format the given payMethod with proper description for bank...', function(){
		expect(payMethodDottedFormatFilter(payMethodBank)).toEqual('EFT (...7890)');
	});

    //Test for paymentmethoddefault filter

    it('should return string for given paymentMethod with default flag...', function(){
        expect(paymentMethodDefaultFilter(payMethodCard)).toEqual(' - Default');
    });

    it('should return string for given paymentMethod with default flag...', function(){
        expect(paymentMethodDefaultFilter(payMethodBank)).toEqual('');
    });

    //Test for paymentType filter

    it('should return paymenttype for given paymentMethod...', function(){
        expect(paymentTypeFilter(payMethodCard)).toEqual('Credit');
    });

    it('should return paymenttype for given paymentMethod...', function(){
        expect(paymentTypeFilter(payMethodBank)).toEqual('Savings');
    });

    //Test for card/bank holder name filter

    it('should return account/card holder name for given paymentMethod...', function(){
        expect(paymentHolderNameFilter(payMethodCard)).toEqual('Card User');
    });

    it('should return account/card holder name for given paymentMethod...', function(){
        expect(paymentHolderNameFilter(payMethodBank)).toEqual('Account User');
    });

    it('should return blank for given invalid paymentMethod...', function(){
        expect(paymentHolderNameFilter(undefined)).toEqual('');
    });

    it('should return blank for given invalid paymentMethod...', function(){
        payMethodBank.bankAccountHolderNickName = null;
        expect(payMethodFormatFilter(undefined)).toEqual('');
    });

    it('should return paymentMethod even the bankAccountHolderNickName is null...', function(){
        payMethodBank.bankAccountHolderNickName = null;
        expect(payMethodFormatFilter(payMethodBank)).toEqual('Account User ending 7890');
    });

    it('should return paymentMethod even the bankAccountHolderNickName is null...', function(){
        payMethodBank.bankAccountHolderNickName = null;
        expect(payMethodFormatFilter(payMethodBank)).toEqual('Account User ending 7890');
    });

    it('should format the given payMethod with proper description for bank type when bankAccountHolderNickName is null...', function(){
        payMethodBank.bankAccountHolderNickName = null;
        expect(payMethodDottedFormatFilter(payMethodBank)).toEqual('Savings (...7890)');
    });

    it('should return paymentMethod even the accountHolderName is null...', function(){
        payMethodBank.accountHolderName = null;
        expect(payMethodFormatFilter(payMethodBank)).toEqual('SAV ending 7890');
    });

    it('should format the given payMethod with proper description for bank type when accountHolderName is null...', function(){
        payMethodBank.accountHolderName = null;
        expect(payMethodDottedFormatFilter(payMethodBank)).toEqual('Savings (...7890)');
    });

    it('should return paymentMethod even the cardNickName is null...', function(){
        payMethodCard.cardNickName = null;
        expect(payMethodFormatFilter(payMethodCard)).toEqual('VI ending 2668');
    });

    it('should format the given payMethod with proper description for credit card when cardNickName is null...', function(){
        payMethodCard.cardNickName = null;
        expect(payMethodDottedFormatFilter(payMethodCard)).toEqual('Credit (...2668)');
    });

    it('should return paymentMethod even the bankAccountHolderNickName is null...', function(){
        payMethodCard.cardCategory = null;
        expect(payMethodFormatFilter(payMethodCard)).toEqual('CR ending 2668');
    });

    it('should format the given payMethod with proper description for credit card when cardCategory is null...', function(){
        payMethodCard.cardCategory = null;
        //console.log(payMethodDottedFormatFilter(payMethodCard));
        expect(payMethodDottedFormatFilter(payMethodCard)).toEqual('Credit (...2668)');
    });

    it('should return paymentMethod even the maskedValueForValueForBank  is null...', function(){
        payMethodBank.maskedValueForValueForBank  = null;
        expect(payMethodFormatFilter(payMethodBank)).toEqual('SAV ending ');
    });

    it('should format the given payMethod with proper description for bank type when maskedValueForValueForBank  is null...', function(){
        payMethodBank.maskedValueForValueForBank  = null;
        expect(payMethodDottedFormatFilter(payMethodBank)).toEqual('Savings (...XXXX)');
    });

    it('should return paymentMethod even the maskedValueForEncryptedValueForCreditCard   is null...', function(){
        payMethodCard.maskedValueForEncryptedValueForCreditCard   = null;
        expect(payMethodFormatFilter(payMethodCard)).toEqual('CR ending ');
    });

    it('should format the given payMethod with proper description for credit card type when maskedValueForEncryptedValueForCreditCard   is null...', function(){
        payMethodCard.maskedValueForEncryptedValueForCreditCard   = null;
        expect(payMethodDottedFormatFilter(payMethodCard)).toEqual('Credit (...XXXX)');
    });

    /**autoPayMethodDottedFormatFilter test cases**/

    it('should return blank for given invalid paymentMethod...', function(){
        expect(autoPayMethodDottedFormatFilter(undefined)).toEqual('');
    });

    it('should format the given payMethod with proper description for credit card when maskedValueForEncryptedValueForCreditCard is null...', function(){
        expect(autoPayMethodDottedFormatFilter(payMethodCard)).toEqual('Credit (...XXXX)');
    });

    it('should format the given payMethod with proper description for credit card when cardCategory is null...', function(){
        payMethodCard.cardCategory = null;
        payMethodCard.maskedValueForEncryptedValueForCreditCard = '************2668';
        expect(autoPayMethodDottedFormatFilter(payMethodCard)).toEqual('Credit (...2668)');
    });

    it('should format the given payMethod with proper description for credit card when cardNickName is null...', function(){
        payMethodCard.cardNickName = null;
        payMethodCard.cardCategory = 'VI';
        expect(autoPayMethodDottedFormatFilter(payMethodCard)).toEqual('Credit (...2668)');
    });

    it('should format the given payMethod with proper description for credit card...', function(){
        payMethodCard.cardNickName = 'VISA_CC';
        expect(autoPayMethodDottedFormatFilter(payMethodCard)).toEqual('VISA_CC (...2668)');
    });

    it('should format the given payMethod with proper description for bank type when maskedValueForValueForBank...', function(){
        expect(autoPayMethodDottedFormatFilter(payMethodBank)).toEqual('Savings (...XXXX)');
    });

    it('should format the given payMethod with proper description for bank type when bankAccountType is null ...', function(){
        payMethodBank.maskedValueForValueForBank = '**********7890';
        expect(autoPayMethodDottedFormatFilter(payMethodBank)).toEqual('Savings (...7890)');
    });

    it('should format the given payMethod with proper description for bank type...', function(){
        payMethodBank.bankAccountHolderNickName = 'EFT';
        expect(autoPayMethodDottedFormatFilter(payMethodBank)).toEqual('EFT (...7890)');
    });

    /**Test formattedPaymentMethod filter**/

    it('should return blank for given invalid paymentMethod...', function(){
        expect(formattedPaymentMethodFilter(undefined)).toEqual('');
    });    

    it('should return proper format string for given paymentMethod of bank type...', function(){
        expect(formattedPaymentMethodFilter(payMethodBank)).toEqual('EFT*7890');
    });

    it('should return proper format string for given paymentMethod of credit card type...', function(){
        expect(formattedPaymentMethodFilter(payMethodCard)).toEqual('VISA_CC*2668');
    });

    it('should return proper format string for given paymentMethod of bank type...', function(){
        payMethodBank.bankAccountHolderNickName = null;
        expect(formattedPaymentMethodFilter(payMethodBank)).toEqual('**********7890');
    });

    it('should return proper format string for given paymentMethod of credit card type...', function(){
        payMethodCard.cardNickName = null;
        expect(formattedPaymentMethodFilter(payMethodCard)).toEqual('************2668');
    });

});