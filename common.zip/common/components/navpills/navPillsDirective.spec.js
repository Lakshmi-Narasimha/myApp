/* eslint-disable */
/**
 * @ngdoc directive
 * @name Nav Pills Directive
 * @description
 *
 * - It defines the nav pills test cases  
 *
**/

'use strict';

describe('Directive: Nav Pills', function() {

	var compile, scope, directiveEle;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

 		angular.mock.inject(function($rootScope, $compile, $httpBackend) {
            scope = $rootScope.$new();
  			compile = $compile;
            scope.pilloptions = [
                {
                    btnName : "YTM",
                    uibValue : 'ytm'
                }, 
                {
                    btnName : "Last Three Months",
                    uibValue : 'lastThreeMonths'
                },
                {
                    btnName : "Last Month",
                    uibValue : 'lastMonth'
                }
            ];
            scope.btnColor = 'btn-group-sm green-btn-group pull-left mb-';
            scope.pillModel = 'ytm';
        	//assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-nav-pills ng-if="pilloptions" btn-color="btnColor" model-val="pillModel" options="pilloptions" pill-select="changePill(param)"></ftic-nav-pills>');
        directiveEle = compile(element)(scope);
        scope.$digest();

    });

    it('should be defined',function(){
		expect(directiveEle).toBeDefined();
	})


});