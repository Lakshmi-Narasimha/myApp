define(['jquery', 'underscore'],
    function($, _) {

/*

	Rest Client 

	- RestClient is optimized for caching
	- Requests to the same URL will be serviced from cache if available.
	- Requests cache expires (see code for timeout value)
	- Requests arriving while a request's HTTP request is in progress are queued and get the same response
		(data or error) from the previous request.
	- Errors are not cached. The next request will cause a new http request.

	To use: see promiseToFetch/Post/Put/Delete

	ajaxParams: String | Object
        This can be a URL (String) OR an object which is any settings properties accepted 
        by the jquery ajax() function (The url property is required)
		DO NOT set error and success properties...they will be ignored.

*/

   var RestClient = function() {
        var defaultCacheSeconds = 60; // when exceeded the cached value will be discarded
        var requestCaches = {}; // associative array of <url, requestcache>
        var ajaxHandler = new AjaxHandler();

        // public functions

        this.promiseToFetch = function(ajaxParamsOrUrl /* required */, networkRequestStarting /* optional */) {
            clearStaleRequests();
            var requestCache = getRequestCache(toAjaxParams(ajaxParamsOrUrl));
            return requestCache.promiseToFetch(toAjaxParams(ajaxParamsOrUrl), networkRequestStarting);
        }

        this.promiseToPost = function(ajaxParamsOrUrl /* required */) {
        	params.method = "POST";
        	return promiseToSend(toAjaxParams(ajaxParamsOrUrl));
        }

        this.promiseToPut = function(ajaxParamsOrUrl /* required */) {
        	params.method = "PUT";
        	return promiseToSend(toAjaxParams(ajaxParamsOrUrl));
        }

        this.promiseToDelete = function(ajaxParamsOrUrl /* required */) {
        	params.method = "DELETE";
        	return promiseToSend(toAjaxParams(ajaxParamsOrUrl));
        }

        this.clearCacheForTypes = function(types) {
       	    for (var prop in requestCaches) {
                var requestCache = requestCaches[prop];
                if (requestCache) {
                	_.each(types, function(type) {
                		if (requestCache.isCacheType(type)) {
                    		requestCaches[prop] = undefined;
                		}
                	});
                }
            }
        }

        // private functions

        var getRequestCache = function(ajaxParams) {
            var requestKey = requestCacheKey(ajaxParams);
            var requestCache = requestCaches[requestKey];
            if (!requestCache) {
                var cacheSeconds = ajaxParams.cacheSeconds ? ajaxParams.cacheSeconds : defaultCacheSeconds;
                requestCache = new RequestCache(ajaxHandler, cacheSeconds, ajaxParams.cacheType);
                requestCaches[requestKey] = requestCache;
            }
            return requestCache;
        }

        var requestCacheKey = function(ajaxParams) {
        	return ajaxParams.url ? ajaxParams.url : '';
        }

        var clearStaleRequests = function() {
            for (var prop in requestCaches) {
                var requestCache = requestCaches[prop];
                if (requestCache && requestCache.isStale()) {
                    requestCaches[prop] = undefined;
                }
            }
        }

		var promiseToSend = function(params) {
            var defer = Q.defer();
        	params.success = function (responseData) {
                defer.resolve(responseData);
            };
            params.error = function (jqXHR, textStatus, errorThrown) {
            	ajaxHandler.logRestError(jqXHR, textStatus, errorThrown);
            	var errorObj = {jqXHR:jqXHR, textStatus:textStatus, errorThrown:errorThrown}
                defer.reject(errorObj);
            };
            ajaxHandler.sendRequest(params);
            return defer.promise;
        }

        var toAjaxParams = function(paramsOrUrl) {
            return _.isString(paramsOrUrl) ? {url: paramsOrUrl} : _.clone(paramsOrUrl);
        }
    }


    /* RequestCache manages one unique URL.  It is discarded when the request expires */
    var RequestCache = function(ajaxHandler /* required */, cacheSeconds /* required */, cacheType /* optional */) {

        // private instvars

        var cacheType = cacheType; // optional...if set can be used to clear cached requests explicitly
        var requesters = [];
        var result = undefined;  // fetched object OR error object
        var resultIsSuccess = false;
        var lastRequestTime = 0; // when did we get the results
        var ajaxHandler = ajaxHandler;
        var cacheSeconds = cacheSeconds;

        // public functions

        // networkRequestStarting: this function will be call IF a request is NOT serviced from the cache
        // (use this to start a spinner)
        this.promiseToFetch = function(ajaxParams /* required */, networkRequestStarting /* optional */) {
            var inProgress = requesters.length != 0;
            var defer = Q.defer();
            requesters.push(defer);
            if (result !== undefined) {
                flush();
            } else if (!inProgress) {
            	if (networkRequestStarting) {
            		networkRequestStarting();
            	}
                beginFetch(ajaxParams);
            }
            return defer.promise;
        };

        this.isStale = function() {
        	if (lastRequestTime > 0) {
            	var now = new Date().getTime();
            	return lastRequestTime + (cacheSeconds * 1000) < now;
        	} else {
        		return false;
        	}
        };

        this.isCacheType = function(type) {
        	return type == cacheType;
        };

        // private functions

        function flush() {
            lastRequestTime = new Date().getTime();
            _.each(requesters, function(deferredRequest) {
                if (resultIsSuccess) {
                    deferredRequest.resolve(result);
                } else {
                    deferredRequest.reject(result);
                }
            });
            requesters = [];
            // if the current result is an error, clear it after the flush so we will retry on next request
            if (!resultIsSuccess) {
                result = undefined;
            }
        }

        function beginFetch(ajaxParams) {
        	var params = _.clone(ajaxParams);
        	params.success = function (responseData, textStatus, jqXHR) {
                checkSSOExpire(jqXHR);
                result = responseData;
                resultIsSuccess = true;
                flush();
            };
            params.error = function (jqXHR, textStatus, errorThrown) {
            	ajaxHandler.logRestError(jqXHR, textStatus, errorThrown);
                checkSSOExpire(jqXHR);
            	var errorObj = {jqXHR:jqXHR, textStatus:textStatus, errorThrown:errorThrown}
                result = errorObj;
                resultIsSuccess = false;
                flush();
            };
        	ajaxHandler.sendRequest(params);
        }

        function checkSSOExpire(jqXHR) {
            if (isSSOExpireResponse(jqXHR)) {
                console.log('Apparent SSO session expire: status= ' + jqXHR.status + ', statusText = ' + jqXHR.statusText + ', response = ' + jqXHR.responseText);
                window.location.reload();
            } 
        }

        function isSSOExpireResponse(jqXHR) {
            var responseContentType = jqXHR.getResponseHeader('Content-Type');
            if (responseContentType && responseContentType.indexOf('text/html') > -1) {
                return true; 
            } 
            if (jqXHR.status === 0 && jqXHR.responseText == 'SSO idle timeout') {
                return true;
            }
            return false;
        }

    };

    var AjaxHandler = function() {

    	this.sendRequest = function(ajaxParams) {
            ajaxParams.xhrFields = {
                withCredentials: true
            };
            ajaxParams.timeout = 30000;
    		$.ajax(ajaxParams);
    	}

    	this.logRestError = function(jqXHR, textStatus, errorThrown) {
        	console.log("REST error: " + jqXHR + " " + textStatus + " " + errorThrown);
        }

    }	

    // returning a singleton instance

    return new RestClient();

});
