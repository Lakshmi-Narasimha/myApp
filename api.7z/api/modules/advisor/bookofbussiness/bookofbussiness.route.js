var express = require('express'),
    router = express.Router(),
    SalesoverviewChart = require('./salesoverview/getsalesoverviewchart.model'),
    SalesoverviewTable = require('./salesoverview/getsalesoverviewtable.model'),
    MonthlyBussinessOverview = require('./portfoliosnapshot/getmonthlybussinessoverview.model'),
    FundCompositionModel = require('./salesoverview/getFundComposition.model'),
    SipBookFullView = require('./portfoliosnapshot/getSipBookFullView.model'),
    MbFundCompositionModel = require('./portfoliosnapshot/getmonthlyfundcomposition.model'),
    LumpsumBookModel = require('./portfoliosnapshot/lumpsumbook.model'),
    InvestorDetailsModel = require('./portfoliosnapshot/getinvestordetails.model'),
    InvestorFolioDetailsModel = require('./portfoliosnapshot/getinvestorfoliodetails.model'),
    InvestorDetailsAumGrowthModel = require('./portfoliosnapshot/getInvestorDetails_AUMGrowth.model'),
    SipBookModel = require('./portfoliosnapshot/sipbook.model'),
    AttritionAnalysisModel = require('./portfoliosnapshot/attritionanalysis.model');
    

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */


router.route('/bob/salesOverview')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SalesoverviewChart.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].salesOverviewChartObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].salesOverviewChartObject);
            }

        });
    });

router.route('/getsalesoverviewtable')
    .get(function (req, res) {
        SalesoverviewTable.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].salesoverviewTableObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].salesoverviewTableObject);
            }

        });

});

router.route('/getFundCompositionDetails/*')
    .get(function (req, res) {
        console.log(req.body);
        console.log(req.params, req.query);
        FundCompositionModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].fundsCompostionResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].fundsCompostionResp);
            }

        });

    });
   
router.route('/bob/monthlySnapshot')
    .get(function (req, res) {
        MonthlyBussinessOverview.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].monthlyBussinessOverviewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].monthlyBussinessOverviewObject[0]);
            }

        });

});

router.route('/getMbFundComposition')
    .get(function (req, res) {
        MbFundCompositionModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].mbFundsCompostionResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].mbFundsCompostionResp[0]);
            }

        });

});

router.route('/bob/lumpsumBook')
    .get(function (req, res) {
        LumpsumBookModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].lumpsumBookResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].lumpsumBookResp[0]);
            }

        });

});


router.route('/bob/investorDetails')
    .get(function (req, res) {
        InvestorDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].investorDetailsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].investorDetailsObject[0]);
            }

        });

});

router.route('/getInvFolio')
    .get(function (req, res) {
        InvestorFolioDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].investorFolioDetailsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].investorFolioDetailsObject);
            }

        });

});
router.route('/getInvAumGrowth')
    .get(function (req, res) {
        InvestorDetailsAumGrowthModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].investorDetailsAumGrowthObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].investorDetailsAumGrowthObject);
            }

        });

});


router.route('/getSipBookFullView')
    .get(function (req, res) {
        SipBookFullView.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].SipBookFullViewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].SipBookFullViewObject);
            }                
        });  
});                      

router.route('/bob/sIPBook')
    .get(function (req, res) {
        SipBookModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].sipBookResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].sipBookResp[0]);
            }

        });
});    

router.route('/getAttrDtls')
    .get(function (req, res) {
        AttritionAnalysisModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].attritionAnalysisObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].attritionAnalysisObject);
            }

        });

});

   
module.exports = router;
