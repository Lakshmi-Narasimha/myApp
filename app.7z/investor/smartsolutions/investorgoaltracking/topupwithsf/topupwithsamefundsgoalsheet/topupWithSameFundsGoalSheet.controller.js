'use strict';
function smartSolsTopupWithFtRecommendedFundsCtrl($scope, $state, recommendedPlanModelService, advisorEventConstants, planSmartSolution, buildPlanModelService, investorGoalModelService) {
    $scope.config.stepsConfig.activeStep = 2;

    $scope.init = function () {
        var planSmartSolutionDetails = planSmartSolution.getSmartSolutionDetails();
        var goalSummary = angular.copy(investorGoalModelService.getSelectedGoalData());
        $scope.keyValueList = [{
            "GoalName": goalSummary.goal,
            "GoalDeficit": goalSummary.targetAmount - ((goalSummary.achieved.split("%")[0] * goalSummary.targetAmount) /100),
            "BalanceTenure": goalSummary.pendingTimeFrame
        }];

           /* [
            {key: "Goal Name", value: goalSummary.goal},
            {key: "Goal Deficit", value: goalSummary.targetAmount - ((goalSummary.achieved.split("%")[0] * goalSummary.targetAmount) /100)},//goalSummary.goal
            {key: "Balance Tenure", value: goalSummary.pendingTimeFrame}
        ];*/

        planSmartSolution.setGoalSummaryData($scope.keyValueList);

        $scope.investmentSummary = {
            "fundDetails": buildPlanModelService.getGoalPlanData(),
            "total": buildPlanModelService.getGoalTotalPlanData()
        };
        $scope.goalChartData = planSmartSolution.getInvestmentSimulation();
    };

    $scope.init();

    /*$scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function ($event) {
        $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
        $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
        $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
        $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
        //console.log($scope.goalChartData);

    });*/

    $scope.goBack = function () {
        $state.go("smartSol.investor.topupwithsf.topupwithsamefunds");
    };

    $scope.proceedGoalSheet = function () {
        $scope.fundDtls= "smartSol.planSmartSolution.fundDetailsSS.investment";
        planSmartSolution.setFundDetailsState($scope.fundDtls);
        $state.go('smartSol.planSmartSolution.fundDetailsSS');
    };
    /*$scope.TopupWithFtRecommendedFundsData = [];
    var rows = [
        {
            "fundname": "Franklin India Blue-chip Fund",
            "percent": "25%",
            "monthly": "250"

        },
        {
            "fundname": "Franklin Corporate Bond Fund",
            "percent": "75%",
            "monthly": "750"

        },
        {
            "fundname": "Total",
            "percent": "100%",
            "monthly": "1000"

        }
    ];

    angular.forEach(rows, function (obj) {
        var gridRow = {};
        gridRow.fundname = obj.fundname;
        gridRow.percent = obj.percent;
        gridRow.monthly = obj.monthly;

        $scope.TopupWithFtRecommendedFundsData.push(gridRow);
    });

    // var statusTemplate = '<div uib-popover-template="" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>'
    var statusTemplate = '<div uib-popover-template="\'viewCompostion.html\'" popover-is-open="closePop" popover-placement="bottom-left" popover-trigger="outsideClick" class="fti-view-composition icon-fti_plusSign"></div>' +
        '<script type="text/ng-template" id="viewCompostion.html">' +
        '<div><button type="button" ng-click="grid.appScope.$emit(\'showViewComposition\', COL_FIELD)" class="btn panel-orange-btn m0">View Composition</button></div></script>';


    $scope.TopupWithFtRecommendedFundsColumnDefs = [
        {field: 'fundname', displayName: 'Fund Name', width: '250', pinnedLeft: true},
        {field: 'percent', displayName: '%', width: '100'},
        {
            field: 'monthly',
            displayName: 'Monthly',
            width: '150',
            headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
            cellClass: 'text-right'
        }
    ];*/

    $scope.savedSmartSolBtn = function () {
        $scope.$emit("smartSolSaveBtn");
    };
    $scope.emailInvbtn = function () {
        $scope.$emit("smartSolEmailBtn");
    };
}

smartSolsTopupWithFtRecommendedFundsCtrl.$inject = ['$scope', '$state', 'recommendedPlanModelService', 'advisorEventConstants', 'planSmartSolution', 'buildPlanModelService', 'investorGoalModelService'];
module.exports = smartSolsTopupWithFtRecommendedFundsCtrl;