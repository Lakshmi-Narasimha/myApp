
'use strict';
function smartSolsAnotherRecommendationsCtrl($scope, $state,recommendedPlanInitialLoader,recommendedPlanModelService,advisorEventConstants) {
  $scope.keyValueList=[{key:"First Holder",value:"Shankar Narayanan"},
                      {key:"Second Holder",value:"Shyama Shankar"},
                      {key:"Third Holder",value:"Anil Narayanan"},
                      {key:"Folio.No.",value:"4563152-FS"},
                      {key:"Mode Of Holding",value:"Joint"}
                      ];


                      recommendedPlanInitialLoader.loadAllServices($scope);


   $scope.$on(advisorEventConstants.smartSolutions.RECOMMENDED_PLAN, function($event) {
       $scope.recommendedPlanData = recommendedPlanModelService.getRecommendedPlanDtls();
       $scope.installmentDetails = $scope.recommendedPlanData.recomendedPlanResp.installmentDetails;
       $scope.fundDetails = $scope.recommendedPlanData.recomendedPlanResp.fundDetails;
       $scope.goalChartData = $scope.recommendedPlanData.recomendedPlanResp.goalForeCast;
       //console.log($scope.goalChartData);
            
    });
  $scope.goBack=function(){
    $state.go('smartSol.investor.currentPlan');
  }
  $scope.goalsheetBtn=function(){
    $state.go('smartSol.investor.topupwithftrf.topupwithftrecommendedfundsgoalsheet');
  }
  $scope.showOriginalRecommendation=function(){
    $state.go('smartSol.investor.topupwithftrf.topupwithftrecommendedfunds.or');
  }
}

smartSolsAnotherRecommendationsCtrl.$inject = ['$scope', '$state','recommendedPlanInitialLoader','recommendedPlanModelService','advisorEventConstants'];
module.exports = smartSolsAnotherRecommendationsCtrl;