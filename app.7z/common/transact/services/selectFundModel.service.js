//getSelectFundDtls
'use strict';

var selectFundModel = function (Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService, $state) {
	 var _sfDtls = null;
	 var _selectedFundDtls = null;
	 var selectFundModel = {
		fetchSelectFundDetails : function (selectedInv) {
			var params = {};
			params.folioId = selectedInv.folioId;
			var currentStateName = $state.current.name;
			if(currentStateName === 'transact.base.switch' || currentStateName === 'invTransact.base.switch'){
				params.type = "S";
			}else if(currentStateName === 'transact.base.redeem' || currentStateName === 'invTransact.base.redeem'){
				params.type = "R";
			}else if(currentStateName === 'transact.base.stp' || currentStateName === 'invTransact.base.stp'){
				params.type = "STP";
			}else if(currentStateName === 'transact.base.swp' || currentStateName === 'invTransact.base.swp'){
				params.type = "SWP";
			}else if(currentStateName === 'transact.base.dtp' || currentStateName === 'invTransact.base.dtp'){
				params.type = "DTP";
			}else if(currentStateName === 'invTransact.base.sip') {
				params.type = "SIP";
			}
			/*else if($state.current.name === 'invTransact.base.cancelStp'){
				params.type = "cancelStp";
			}
*/
			
			params.guId = authenticationService.getUser().guId;
		    	           
		    var deferred = $q.defer();
		     Restangular.one('transact/txnEligibleAccounts').get(params).then(function (sfdetails) {		     
		        deferred.resolve(sfdetails);
		    }, function (resp) {
		        deferred.reject(resp);
		        console.log('error');
		    });
		    return deferred.promise;
		},

		getSelectFundGridDtls: function() {
			return _sfDtls;
		},
		setSelectFundGridDtls: function(sfdetails) {
			if(sfdetails.eligibleAccounts[0] != undefined){
				_sfDtls = sfdetails.eligibleAccounts;
			}else{
				_sfDtls = [];
				_sfDtls.push(sfdetails.eligibleAccounts);
			}
		},

		getSelectFundDtls: function() {            
			return _selectedFundDtls;
		},
		setSelectFundDtls: function(selectedFundDtls) {            
			_selectedFundDtls = selectedFundDtls;
		}

	  };
	  return selectFundModel;

};

selectFundModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService', '$state'];
module.exports = selectFundModel;