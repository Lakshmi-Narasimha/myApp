'use strict';

/* jasmine specs for controllers go here */

describe('monthDayFilter', function() {

	var monthDayFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    monthDayFilter = $injector.get('$filter')('monthDay');
	}));

	//--- Test for definition

	it('should expect monthDayFilter to be defined...', function(){
		expect(monthDayFilter).toBeDefined();
	});

	//--- Test monthDayFilter

	it('should format the given date to mm/dd/yyyy format...', function(){
		expect(monthDayFilter('2015-02-05')).toEqual('Feb 05, 2015');
	});


});