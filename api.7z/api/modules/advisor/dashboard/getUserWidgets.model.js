// getUserWidgets.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var UserWidgetsSchema = new mongoose.Schema({
    userWidgetsObject: {
        type: Array,
        "default": []
    }
});

var UserWidgetsLookUp = mongoose.model('UserWidgetsLookup', UserWidgetsSchema);

var UserWidgetsModel = new UserWidgetsLookUp({

  "userWidgetsObject": [
    {
        "sipBookOverview": {
            "date": "29-Feb-2016",
            "sipCount": "1",
            "sipYtmNew": "140",
            "sipYtmMatured": "0",
            "sipYtmCancelled": "0",
            "sipYtmActive": "5"
        },
        "transactionStatus": {
            "date": "17-Mar-2016",
            "ct": {
                "processed": "112",
                "clarification": "",
                "underProcessTxn": "20",
                "rejectedTxn": "10",
                "totalTxn": ""
            },
            "nct": {
                "processed": "112",
                "clarification": "",
                "underProcessTxn": "20",
                "rejectedTxn": "10",
                "totalTxn": ""
            }
        }        
    }
]

});

UserWidgetsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating UserWidgetsLookUp table, please contact admin...');
    } else {
        UserWidgetsLookUp.remove({}, function(err) {
            console.log('UserWidgetsLookUp collection removed');
            UserWidgetsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating UserWidgetsLookUp table, please contact admin...');
                }
                console.log('UserWidgetsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = UserWidgetsLookUp;
