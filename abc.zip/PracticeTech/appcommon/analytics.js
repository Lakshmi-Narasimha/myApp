define([ 
  'appcommon/analyticsScode',
  'appcommon/globalcontext',
  'appcommon/commonutility',
  'appcommon/nativeadaptor',
  'config'
], function(sCode, GlobalContext, Utility, NativeAdaptor, Config) {

	function createGuid() {
		var guid = Utility.readCookie('SM_UNIVERSALID');
		if (! guid || guid.length == 0) {
			guid = 'NoGuidFromSSO';
		}
		return guid;
	};
	
	var includeUserInAnalytics;
	var peopleSoftID;
	
	if (! includeUserInAnalytics ) {
		// include everyone except the ID used by Gomez
		includeUserInAnalytics = true;
		peopleSoftID = Utility.readCookie('PeopleSoftID');
		if (peopleSoftID && peopleSoftID == '9978900') {
			includeUserInAnalytics = false;
		};
	};

	var s_account = Config.omnitureSAccount;
	var shared_s_account = Config.omnitureSharedSAccount;
	

	var analytics = {
			
		sessionAnalytics : {
			sessionID : createGuid(),
			currentPage : '',
			previousPage : ''
		},
		
		LAST_USED_SUITE : null,
		CURRENT_S_CODE : null,
		
		// Suite Names
		SHARED_SUITE : 'SharedSuite',
		DEDICATED_SUITE : 'DedicatedSuite',
		
		 // Navigation names
		CALENDAR : 'Calendar',
		
		CRM_SMARTPAD : 'CrmSmartPad',
		CRM_ACTIVITY_LIST : 'CrmActivityList',
		CRM_ADD_SMARTPAD : 'CrmAddSmartPad',
		CRM_NOTE_DETAIL : 'CrmNoteDetail',
		CRM_TASK_LIST : 'crmTaskList',
		CRM_TASK_LIST_EDIT_TASK: 'showTaskEdit',
		
		NAV_SHOW_CONTACT_LIST : 'NavShowContactList',
		NAV_ADD_CONTACT : 'NavAddContact',
		NAV_WELCOME_GET_STARTED : 'NavWelcomeGetStarted',
		NAV_SHOW_EDIT_CONTACT : 'NavShowEditContact',
		NAV_SIGN_DOCUMENT : 'NavSignDocument',
		NAV_SHOW_PROSPECT_LIST : 'NavShowProspectList',
		
		CONTACT_PROFILE : 'ContactProfile',
		CP_PREFERENCES: 'CpPreferences',
		CP_BANK: 'CpBank',
		CP_AUTHORIZEDPERSON : 'CpAuthorizedPerson',
		CP_BENEFICIARY : 'CpBeneficiary',
		CP_SMARTPAD: 'CpSmartPad',
		CP_CONTRIBUTIONS: 'CpContributions',
		CP_DISTRIBUTIONS: 'CpDistributions',
		
	   	AV_ACCOUNT_LIST : 'AvAccountList',
	   	AV_RECENT_ACTIVITY : 'AvRecentActivity',
	   	AV_SHOW_PRODUCT: 'AvShowProduct',
	   	AV_SHOW_ACSTATEMENTS: 'AvShowStatements',
	   	AV_SHOW_FINANCIAL: 'AvShowFinancial',
	   	AV_SHOW_PORTFOLIO: 'AvShowPortfolio',
	   	AV_SHOW_ARRANGEMENT: 'AvShowArrangement',
	   	
	   	COA_SHOW_HOME : 'CoaShowHome',
	   	COA_SHOW_VALIDATION : 'CoaShowValidation',
	   	COA_SHOW_VERIFY : 'CoaShowVerify',
	   	COA_SHOW_CONFIRM : 'CoaShowConfirm',
	   	COA_DEFAULT_ACTION : 'CoaDefaultAction',
	   	
	   	ESIG_SHOW_CLIENT_LIST : 'eSigClientPicker',
	   	ESIG_SHOW_SIGN_SUBMITTED : 'showSignSubmitted',
	   	ESIG__SHOW_SIGN_DOCUMENT : 'showSignDocument',
	   	ESIG_SHOW_DOC_LIST : 'showDocList',
	   	
	   	NCST_SHOW_CLIENT_INFO_SCREEN : 'showClientInfoScreen',
	   	NCST_SHOW_ADDRESS_ENTRY_SCREEN : 'showAddressEntryScreen',
	   	NCST_SHOW_VALIDATION_SCREEN : 'showValidationScreen',
	   	NCST_SHOW_CLIENT_DETAILS_SCREEN : 'showClientDetailsScreen',
	   	NCST_SHOW_EMPLOYMENT_SCREEN : 'showEmploymentScreen',
	   	NCST_SHOW_INCOME_SCREEN : 'showIncomeScreen',
	   	NCST_SHOW_VERIFICATION_SCREEN : 'showVerificationScreen',
	   	NCST_SHOW_CONFIRMATION_SCREEN : 'showConfirmationScreen',
	   	NCST_GET_CONTEXT_FROM_NAV : 'getContextfromNav',
	   	NCST_DEFAULT_ACTION : 'defaultAction',
	   	
	   	GPM_EMAIL_UPDATE : 'updateGPMEmailAddressScreen',
	   	GPM_PHONE_NUMBER_UPDATE : 'updateGPMPhoneNumbersScreen',
	   	
	   	GPM_REMARKS_CLIENT_INFORMATION: 'gpmUpdateClientInformation',

	   	HOC_INSIGHT_PAGE: 'Insight',
        
	   	processHOCSubRouteChangeEvent: function (route, subroute) {

   	    if (route == 'defaultAction') {
   	        this.recordNavigation(this.HOC_INSIGHT_PAGE);
   	    } else {}

	   	},

	   	processGPMSubRouteChangeEvent: function	(route, subroute) {
	   		
	   		if (route == 'showUpdateView' && subroute == 'email' ) {
	   			this.recordNavigation(this.GPM_EMAIL_UPDATE);
	   		} else if (route == 'showUpdateView'  && subroute == 'phonenumbers') {
	   			this.recordNavigation(this.GPM_PHONE_NUMBER_UPDATE);
	   		} else if (route == 'defaultAction' && ! subroute[0] ) {
	   			// ignore this as it goes to a subrouter for the calendar where it gets logged.
	   		} else if (route == 'defaultAction' && subroute[0] == 'activitylist' ) {
	   			this.recordNavigation(this.CRM_ACTIVITY_LIST);
	   		} else if (route == 'defaultAction' && subroute[0] == 'newappointment' ) {
	   			this.recordNavigation(this.CP_NEW_APPOINTMENT);
	   		} else if (route == 'invokeGPMModule' && subroute[0] == 'remarks' ) {
	   			this.recordNavigation(this.GPM_REMARKS_CLIENT_INFORMATION, this.SHARED_SUITE);
	   		} else {};
	   	},
	   	
		processAppRouterRouteChangeEvent: function	(route, subroute) {
		    var _subRoute = subroute ? subroute[0] : "",
                _pageId;
	   		if (route == 'invokeCRMModule' ) {
	   		    this.recordNavigation(this.CALENDAR);
	   		    Utility.sumoLog("sumo_page:" + this.CALENDAR + "- entering");
	   		} else if (route == 'invokeCPModule' ) {
	   		    switch(_subRoute){
	   		        case "preferences":
	   		            _pageId = this.CP_PREFERENCES;
	   		            break;
	   		        case "bank":
	   		            _pageId = this.CP_BANK;
	   		            break;
	   		        case "beneficiary":
	   		            _pageId = this.CP_BENEFICIARY;
	   		            break;
	   		        case "fiduciary":
	   		            _pageId = this.CP_AUTHORIZEDPERSON;
	   		            break;
	   		        case "contributions":
	   		            _pageId = this.CP_CONTRIBUTIONS;
	   		            break;
	   		        case "distributions":
	   		            _pageId = this.CP_DISTRIBUTIONS;
	   		            break;
	   		        default:
	   		            _pageId = this.CONTACT_PROFILE;
	   		            break;
	   		    }
	   		    this.recordNavigation(_pageId);
	   		    Utility.sumoLog("sumo_page:" + _pageId + "- entering");
	   		} else if (route == 'defaultAction' && ! subroute[0] ) {
	   		} else if (route == 'defaultAction' && subroute[0] == 'activitylist' ) {
	   			this.recordNavigation(this.CRM_ACTIVITY_LIST);
	   		} else if (route == 'defaultAction' && subroute[0] == 'newappointment' ) {
	   			this.recordNavigation(this.CP_NEW_APPOINTMENT);
	   		} else if (route == 'invokeGPMModule' && subroute[0] == 'remarks' ) {
	   			this.recordNavigation(this.GPM_REMARKS_CLIENT_INFORMATION, this.SHARED_SUITE);
	   		} else {};
	   	},
	   	
	    processNavSubRouteChangeEvent: function (route, subroute) {
	   		
	   		if (route == 'defaultAction' && ! subroute ) {
	   			// ignore this as it goes to a subrouter for the calendar where it gets logged.
	   		} else if (route == 'showContactList') {
	   			this.recordNavigation(this.NAV_SHOW_CONTACT_LIST);
	   		} else if (route == 'addContact') {
	   			this.recordNavigation(this.NAV_ADD_CONTACT);
	   		} else if (route == 'welcomeGetStarted') {
	   			this.recordNavigation(this.NAV_WELCOME_GET_STARTED);
	   		} else if (route == 'showEditContact') {
	   			this.recordNavigation(this.NAV_SHOW_EDIT_CONTACT);
	   		} else if (route == 'showDraftsPage') {
	   			this.recordNavigation(this.NAV_SIGN_DOCUMENT);
	   		} else if (route == 'showProspectList') {
	   			this.recordNavigation(this.NAV_SHOW_PROSPECT_LIST);
	   		} else {}
	   	},
	   	
	    processCpSubRouteChangeEvent: function (route, subroute, params) {	  
	   		if (route == 'defaultAction' ) {
	   			this.recordNavigation(this.CONTACT_PROFILE);
	   			Utility.sumoLog("sumo_page:" + this.CONTACT_PROFILE + "- entering");
	   		} else if (route == 'showPreferences') {
	   			this.recordNavigation(this.CP_PREFERENCES);
	   			Utility.sumoLog("sumo_page:" + this.CP_PREFERENCES + "- entering");
	   		} else if (route == 'showBank') {
	   			this.recordNavigation(this.CP_BANK);
	   			Utility.sumoLog("sumo_page:" + this.CP_BANK + "- entering");
	   		} else if (route == 'showFiduciary') {
	   			this.recordNavigation(this.CP_AUTHORIZEDPERSON);
	   			Utility.sumoLog("sumo_page:" + this.CP_AUTHORIZEDPERSON + "- entering");
	   		} else if (route == 'showBeneficiary' ) {
	   			this.recordNavigation(this.CP_BENEFICIARY);
	   			Utility.sumoLog("sumo_page:" + this.CP_BENEFICIARY + "- entering");
	   		} else if (route == 'showContributions') {
	   			this.recordNavigation(this.CP_CONTRIBUTIONS);
	   			Utility.sumoLog("sumo_page:" + this.CP_CONTRIBUTIONS + "- entering");
	   		} else if (route == 'showDistributions') {
	   			this.recordNavigation(this.CP_DISTRIBUTIONS);
	   			Utility.sumoLog("sumo_page:" + this.CP_DISTRIBUTIONS + "- entering");
	   		} else if (route == 'showSmartPad' ) {
	   			this.recordNavigation(this.CP_SMARTPAD);
	   		} else {};
	   	},
	   	
	   	processAvSubRouteChangeEvent: function (route, subroute) {
	   	    if (route == 'defaultAction') {
	   	    	this.recordNavigation(this.AV_ACCOUNT_LIST);
	   	    	Utility.sumoLog("sumo_page:" + this.AV_ACCOUNT_LIST + "- entering");
	   	    }
	   	    else if (route == 'showactivitylist') {
	   			this.recordNavigation(this.AV_RECENT_ACTIVITY);
	   		} /*else if (route == 'showaccntlist' ) {
	   			this.recordNavigation(this.AV_ACCOUNT_LIST);
	   		} */else if (route == 'showproduct' ) {
	   			this.recordNavigation(this.AV_SHOW_PRODUCT);
	   		} else if (route == 'showaccountstatements') {
	   			this.recordNavigation(this.AV_SHOW_ACSTATEMENTS);
	   		} else if (route == 'showfinancial') {
	   			this.recordNavigation(this.AV_SHOW_FINANCIAL);
	   		} else if (route == 'showportfolio') {
	   			this.recordNavigation(this.AV_SHOW_PORTFOLIO);
	   		} else if (route == 'showarrangement') {
	   			this.recordNavigation(this.AV_SHOW_ARRANGEMENT);
	   		} else {};
	   	},
	   	
	   	processCrmSubRouteChangeEvent: function (route, subroute) {
	   		
	   		if (route == 'defaultAction' ) {
	   			this.recordNavigation(this.CALENDAR);
	   			Utility.sumoLog("sumo_page:" + this.CALENDAR + "- entering");
	   		} else if (route == 'showSmartpad' ) {
	   			this.recordNavigation(this.CRM_SMARTPAD);
	   		} else if (route == 'showaddSmartpad' ) {
	   			this.recordNavigation(this.CRM_ADD_SMARTPAD);
	   		} else if (route == 'showNoteDetail' ) {
	   			this.recordNavigation(this.CRM_NOTE_DETAIL);
	   		} else if(route == 'showTaskList') {
	   			this.recordNavigation(this.CRM_TASK_LIST);
	   		} else if (route == 'showTaskEdit'){
	   			this.recordNavigation(this.CRM_TASK_LIST_EDIT_TASK);
	   		} else {};
	   	},
	   	
	   	processNcstSubRouteChangeEvent: function (route, subroute) {
	   		
	   		if (route == 'defaultAction' ) {
	   			this.recordNavigation(this.NCST_DEFAULT_ACTION, this.SHARED_SUITE);
	   		} else if (route == 'showClientInfoScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_CLIENT_INFO_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showAddressEntryScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_ADDRESS_ENTRY_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showValidationScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_VALIDATION_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showClientDetailsScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_CLIENT_DETAILS_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showEmploymentScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_EMPLOYMENT_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showIncomeScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_INCOME_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showVerificationScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_VERIFICATION_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'showConfirmationScreen' ) {
	   			this.recordNavigation(this.NCST_SHOW_CONFIRMATION_SCREEN, this.SHARED_SUITE);
	   		} else if (route == 'getContextfromNav' ) {
	   			this.recordNavigation(this.NCST_GET_CONTEXT_FROM_NAV, this.SHARED_SUITE);
	   		} else {};
	   		
	   	},
	   	
	   	processEsigSubRouteChangeEvent: function (route, subroute) {
	   		
	   		if (route == 'defaultAction' ) {
	   			this.recordNavigation(this.ESIG_SHOW_DOC_LIST);
	   		} else if (route == 'showClientList' ) {
	   			this.recordNavigation(this.ESIG_SHOW_CLIENT_LIST);
	   		} else if (route == 'showSignSubmitted' ) {
	   			this.recordNavigation(this.ESIG_SHOW_SIGN_SUBMITTED);
	   		} else if (route == 'showSignDocument' ) {
	   			this.recordNavigation(this.ESIG__SHOW_SIGN_DOCUMENT);
	   		} else {};
	   	},
	   	
	   	processCoaSubRouteChangeEvent: function (route, subroute) {
	   		
	   		if (route == 'showHome' ) {
	   			this.recordNavigation(this.COA_SHOW_HOME, this.SHARED_SUITE);
	   		} else if (route == 'showValidation' ) {
	   			this.recordNavigation(this.COA_SHOW_VALIDATION, this.SHARED_SUITE);
	   		} else if (route == 'showVerify' ) {
	   			this.recordNavigation(this.COA_SHOW_VERIFY, this.SHARED_SUITE);
	   		} else if (route == 'showConfirm' ) {
	   			this.recordNavigation(this.COA_SHOW_CONFIRM, this.SHARED_SUITE);
	   		} else if (route == 'defaultAction' ) {
	   			this.recordNavigation(this.COA_DEFAULT_ACTION, this.SHARED_SUITE);
	   		} else {};
	   	},

	   	recordNavigation : function(destinationPage, reportingSuite) {
	   		
			this.sessionAnalytics.previousPage = this.sessionAnalytics.currentPage;
			this.sessionAnalytics.currentPage = this.contextualTargetName(destinationPage);

			var event = {
				TYPE : 'navigation',
				CURRENT_PAGE : this.sessionAnalytics.currentPage,
				PREVIOUS_PAGE : this.sessionAnalytics.previousPage,
				ACTION : 'entering'
				// entering current page and leaving the previous page
			};

			if (destinationPage == 'ContactProfile' || destinationPage == 'CpPreferences' || destinationPage == 'CpBank' || destinationPage == 'CpBeneficiary' || destinationPage == 'CpAuthorizedPerson' || destinationPage == 'CpContributions' || destinationPage == 'CpDistributions' || destinationPage == 'Insight' || destinationPage == 'Calendar' || destinationPage == 'AvAccountList') 
			{
			} 
            else {
				this.sendEvent(event, reportingSuite);
			}
			
	   	},
	   	
		recordAction : function(action, reportingSuite) {
			var event = {
				TYPE : 'action',
				CURRENT_PAGE : this.sessionAnalytics.currentPage,
				ACTION : this.contextualTargetName(action)
			};

			this.sendEvent(event, reportingSuite);
		},
		
		recordSharedSuiteAction : function(action) {
			var event = {
				TYPE : 'action',
				CURRENT_PAGE : this.sessionAnalytics.currentPage,
				ACTION : this.contextualTargetName(action)
			};

			this.sendEvent(event, this.SHARED_SUITE);
		},
		
		recordSearch : function(searchString, searchType, reportingSuite) {
			var event = {
				TYPE : 'search',
				CURRENT_PAGE : this.contextualTargetName(this.sessionAnalytics.currentPage),
				ACTION : 'search',
				SEARCH_STRING : searchString,
				SEARCH_TYPE : searchType
			};

			this.sendEvent(event, reportingSuite);
		},
	   	
		sendEvent : function(event, reportingSuite) {
			event.SESSION_ID = this.sessionAnalytics.sessionID;
			event.TIMESTAMP = new Date().toJSON();
			event.APPLICATION = 'web';  // other values can be 'ios', or 'android'

			this.sendToOmniture(event, reportingSuite);
		},

		contextualTargetName : function(eventName) {
			return NativeAdaptor.isEmbedded() ? eventName + '-embedded' : eventName;
		},
		
		logEventToConsole : function(suite, s_omniture, event) {
			
			if (Config.enableAnalyticsConsoleLogging) {
				
				var omnitureVariables = {
					pageName : s_omniture.pageName,
					prop1 : s_omniture.prop1,
					eVar1 : s_omniture.eVar1,
					prop14 : s_omniture.prop14,
					eVar14 : s_omniture.eVar14,
					prop21 : s_omniture.prop21,
					eVar21 : s_omniture.eVar21,
					prop23 : s_omniture.prop23,
					eVar23 : s_omniture.eVar23,
					currentPage : event.CURRENT_PAGE,
					action : event.ACTION,
					searchString : event.SEARCH_STRING,
					searchType : event.SEARCH_TYPE
				};
				
				console.log('Analytics Event Recorded to Suite: ' + suite + ', Type: ' + event.TYPE + ', User-PeopleSoftID: ' + peopleSoftID + ', Send-to-Omniture: ' + 
						     Config.sendAnalyticsToOmniture + ', Include-user-in-analytics: ' + includeUserInAnalytics);
				
				console.log('Analytics OmnitureVariables: ' + JSON.stringify(omnitureVariables));
			}
		},
		
		sendToOmniture : function(event, reportingSuite) {
			
			// the absence of 'reportingSuite' means use the dedicated one...
			if (! reportingSuite) {
				reportingSuite = this.DEDICATED_SUITE;
			}
			
			// configure the s_code to use the right suite.
			if (this.LAST_USED_SUITE) {
				if (this.LAST_USED_SUITE != reportingSuite) {
					if (reportingSuite == this.DEDICATED_SUITE) {
						CURRENT_S_CODE = sCode.configureOmnitureForAccountSuite(s_account);
						this.LAST_USED_SUITE = this.DEDICATED_SUITE;
					} else {
						CURRENT_S_CODE = sCode.configureOmnitureForAccountSuite(shared_s_account);
						this.LAST_USED_SUITE = this.SHARED_SUITE;
					}
				}
			} else {
				if (reportingSuite == this.DEDICATED_SUITE) {
					CURRENT_S_CODE = sCode.configureOmnitureForAccountSuite(s_account);
					this.LAST_USED_SUITE = this.DEDICATED_SUITE;
				} else {
					CURRENT_S_CODE = sCode.configureOmnitureForAccountSuite(shared_s_account);
					this.LAST_USED_SUITE = this.SHARED_SUITE;
				}
				
			}

			// evars are relatively consistent through several steps/actions and possibly the whole session.
			// props change much more frequently throughout the session
	
			CURRENT_S_CODE.eVar1 = event.SESSION_ID;
			CURRENT_S_CODE.prop1 = event.SESSION_ID;
			
			// t for tracking, tl for link tracking 
			if (Config.sendAnalyticsToOmniture && includeUserInAnalytics ) {
				if (event.TYPE == 'navigation') {
					CURRENT_S_CODE.pageName = event.CURRENT_PAGE;  // only for nav events else metrics get double counted.
					CURRENT_S_CODE.prop14 = event.CURRENT_PAGE;
					CURRENT_S_CODE.eVar14 = event.CURRENT_PAGE;
					CURRENT_S_CODE.t();  // t() sends all props and evars.
				} else if (event.TYPE == 'action') {
					CURRENT_S_CODE.prop14 = event.ACTION; 
					CURRENT_S_CODE.eVar14 = event.ACTION;
					CURRENT_S_CODE.linkTrackVars = 'eVar1,prop14,eVar14,prop1';
					CURRENT_S_CODE.tl(true, 'o', event.CURRENT_PAGE + ':'	+ event.ACTION) // tl() sends only the props in the linkTrackVars above
				} else { // must be a search
					CURRENT_S_CODE.prop14 = event.ACTION; 
					CURRENT_S_CODE.eVar14 = event.ACTION;
					CURRENT_S_CODE.prop21 = event.SEARCH_STRING;
					CURRENT_S_CODE.eVar21 = event.SEARCH_STRING;
					CURRENT_S_CODE.prop23 = event.SEARCH_TYPE;
					CURRENT_S_CODE.eVar23 = event.SEARCH_TYPE;
					CURRENT_S_CODE.linkTrackVars = 'eVar1, prop1, eVar14, prop14, eVar21, prop21, eVar23, prop23';
					CURRENT_S_CODE.tl(true, 'o', event.CURRENT_PAGE + ':'	+ event.SEARCH_TYPE) // tl() sends only the props in the linkTrackVars above
				}
			}
			this.logEventToConsole(this.LAST_USED_SUITE, CURRENT_S_CODE, event);
		}
	   	
	};
	
	 return { analytics: analytics };
	 
}); 
