/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accountSearch = function($state, eventConstants, accountStatementModel, $cookies, constants, validateUserModel, toaster) {
	return {
            template: require('./accountSearch.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              searchOptions: "="
            },
            controller: function($scope, $element, $attrs){
				      var statusTemplate = '<input type="checkbox" id="abc" ng-click="grid.appScope.$emit(\'showCheckSelect\', row.entity.folioId)" />';
               $scope.noSearchData = false;
               $scope.isValidKeyFormat = true;
               var keywordPattern;
               $scope.gridOptions = {};
               $scope.gridOptions.enableRowSelection= true,
    			     $scope.gridOptions.enableSelectAll= true,
               $scope.gridOptions.multiSelect = true;
              $scope.gridOptions.columnDefs = [
                { field: 'checkBox',displayName:'', width:"60", cellTemplate:statusTemplate , enableSorting:false, pinnedLeft:true},
                { field: 'custName', displayName: 'Name', width:"180", enableSorting:false, pinnedLeft:true},                        
                { field: 'folioId', displayName: 'Folio Number', width:"110", enableSorting:false},
                { field: 'emailId', displayName: 'Email ID', width:"214",  enableSorting:false},
                { field: 'mobile', displayName: 'Phone Number', width:"140", enableSorting:false},
                { field: 'pan', displayName: 'PAN Number', width:"140", enableSorting:false},
              ];

               
                $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) {  
                  $scope.isValidKeyFormat = true;
                  keywordPattern = "";
                  $scope.searchQuery = {};
                  switch(args.searchOption) {
                      case constants.accountStatements.ACC_NO:
                            $scope.searchQuery.searchType = "A";
                            keywordPattern = /(^\d{1,13}$)/;
                            break;
                      case constants.accountStatements.EMAIL:
                            $scope.searchQuery.searchType = "E";
                            keywordPattern = /(^[a-zA-Z0-9._]+[a-zA-Z0-9._]+@[a-zA-Z]+\.[a-zA-Z.]{2,5}$)/;
                            break;
                      case constants.accountStatements.FOLIO_NO:
                            $scope.searchQuery.searchType = "F";
                            keywordPattern = /(^\d{8}$)/;
                            break; 
                      case constants.accountStatements.MOBILE:
                            $scope.searchQuery.searchType = "M";
                            keywordPattern = /(^\d{10}$)/;
                            break;
                      case constants.accountStatements.PAN:
                            $scope.searchQuery.searchType = "P";
                            keywordPattern = /(^([a-zA-Z]{5})(\d{4})([a-zA-Z]{1})$)/;
                            break;
                  }
                  //if Keyword format is valid 
                  if(keywordPattern.test(args.searchText)){
                    $scope.searchQuery.searchValue = args.searchText;  
                    // $cookies.put('accessToken', 'jKagxFdbrfXMJVytrLCaloUta7WK');
                    $scope.searchQuery.active = "N";
                    $scope.searchQuery.distId = validateUserModel.getUserDetails().arnCode;
                    $scope.searchQuery.emailId = validateUserModel.getUserDetails().emailId;
                    $scope.searchQuery.userType = validateUserModel.getUserType();
                    accountStatementModel.fetchAccountStatement($scope.searchQuery).then (function (data) {
                      $scope.noSearchData = false;
                      $scope.searchResult=data;
                      $scope.showSearchResult = true;
                    }, function (data) {
                        var errortext = '';
                        switch(args.searchOption) {
                          case constants.accountStatements.ACC_NO:
                                errortext = "Account number";
                                break;
                          case constants.accountStatements.EMAIL:
                                errortext = "Email ID";
                                break;
                          case constants.accountStatements.FOLIO_NO:
                                errortext = "Folio number";
                                break; 
                          case constants.accountStatements.MOBILE:
                                errortext = "Phone number";
                                break;
                          case constants.accountStatements.PAN:
                                errortext = "PAN number";
                                break;
                        }
                        toaster.error("No Results were found, Please try again.");
                        $scope.searchResult = [];
                        if($scope.searchResult.length === 0) {
                          $scope.showSearchResult = true;
                        }
                        if(data.errorCode === 400){
                          $scope.noSearchData = true;
                        }
                    });
                  }else{
                    $scope.isValidKeyFormat = false;
                  }   
                }); 

                $scope.$on(eventConstants.HIDE_SEARCH_RESULT, function (event, args) {                 
                  $scope.showSearchResult = false;
                });

                $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, function (event, args) {                  
                  $scope.showSearchResult = false;
                });

            },
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

accountSearch.$inject = ['$state','eventConstants', 'accountStatementModel', '$cookies', 'constants', 'validateUserModel', 'toaster'];
module.exports = accountSearch;