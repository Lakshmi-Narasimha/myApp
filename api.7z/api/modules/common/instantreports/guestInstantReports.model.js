// instantReports.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var InstantReportsSchema = new mongoose.Schema({
    instantReportsObject: {
        type: Array,
        "default": []
    }
});

var InstantReportsLookUp = mongoose.model('InstantReportsLookUp', InstantReportsSchema);

var InstantReportsModel = new InstantReportsLookUp({

  "instantReportsObject": [
    {
        "instantReportsDetails": [
            {   
                "reportName":"Commission Details",
                "reportData": [{
                    "title": "Brokerage Details",
                    "report_id": 7894,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Distributor-Payment-Ledger-Commission-Type.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Jun 2016",
                        "oneMonth"  : "May 2016 to Jun 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["Text", "DBF"]
                }, {
                    "title": "First Year Trail Fee",
                    "report_id": 8956,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_wealthCreation_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 Jul 2016",
                        "oneMonth"  : "Jun 2016 to Jul 2016",
                        "threeMonths" : "Mar 2016 to Jul 2016",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "DBF", "Text"]
                }, {
                    "title": "Long Term Trail Fee",
                    "report_id": 1256,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Trail-Payable.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Feb 2016",
                        "oneMonth"  : "Jan 2016 to Feb 2016",
                        "threeMonths" : "Dec 2015 to Feb 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Payment Summary",
                    "report_id": 1122,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/First-Year-Trail.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Apr 2015",
                        "oneMonth"  : "Mar 2015 to Apr 2015",
                        "threeMonths" : "Feb 2015 to Apr 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["DBF", "Text"]
                }, {
                    "title": "Brokerage Snapshot",
                    "report_id": 2233,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_taxPlanning_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 May 2015",
                        "oneMonth"  : "Apr 2015 to May 2015",
                        "threeMonths" : "Mar 2015 to May 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Held Payments Due To Threshold",
                    "report_id": 1000,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/HELD-PAYMENTS.pdf",
                    "rangeType":[{
                        "AsonDate" : "17 May 2013",
                        "oneMonth"  : "Apr 2013 to May 2013",
                        "threeMonths" : "Mar 2013 to May 2013",
                        "oneYear"  : "2012",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Distributor Payment Ledger Commission Type",
                    "report_id": 1002,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_wealthCreation_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 May 2015",
                        "oneMonth"  : "Apr 2015 to May 2015",
                        "threeMonths" : "Mar 2015 to May 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Upfront and Current Month Trail",
                    "report_id": 1003,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Upfront.pdf",
                    "rangeType":[{
                        "AsonDate" : "19 May 2014",
                        "oneMonth"  : "Apr 2014 to May 2014",
                        "threeMonths" : "Mar 2014 to May 2014",
                        "oneYear"  : "2013",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "First Year Trail excluding current month",
                    "report_id": 1004,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_taxPlanning_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 May 2015",
                        "oneMonth"  : "Apr 2015 to May 2015",
                        "threeMonths" : "Mar 2015 to May 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Trail payable from Second Year of Assets",
                    "report_id": 1005,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Trail.pdf",
                    "rangeType":[{
                        "AsonDate" : "17 Oct 2015",
                        "oneMonth"  : "Sep 2015 to Oct 2015",
                        "threeMonths" : "Aug 2015 to Oct 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Clawback Report",
                    "report_id": 1006,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_retirement_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "19 Jun 2015",
                        "oneMonth"  : "May 2015 to Jun 2015",
                        "threeMonths" : "Apr 2015 to Jun 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Commission basis folio / account number",
                    "report_id": 1007,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_taxPlanning_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 May 2016",
                        "oneMonth"  : "Apr 2016 to May 2016",
                        "threeMonths" : "Mar 2016 to May 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }]
            },

            {   
                "reportName":"Investor Details",
                "reportData":[{
                    "title": "Clients Month-End Balances",
                    "report_id": 1234,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/ClientsMonth-EndBalances.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Aug 2015",
                        "oneMonth"  : "Jul 2015 to Aug 2015",
                        "threeMonths" : "Jun 2015 to Aug 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "DBF"]
                }, {
                    "title": "Client Wise AUM or Whose Balance Exceeds 'N'",
                    "report_id": 2345,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_cashManagement_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 Sep 2015",
                        "oneMonth"  : "Aug 2015 to Sep 2015",
                        "threeMonths" : "Jul 2015 to Sep 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "DBF", "Text"]
                }, {
                    "title": "No PAN Investors",
                    "report_id": 1254,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/No-PAN-Investors.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Oct 2016",
                        "oneMonth"  : "Sep 2016 to Oct 2016",
                        "threeMonths" : "Aug 2016 to Oct 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "DBF"]
                }, {
                    "title": "KYC Status Report",
                    "report_id": 4524,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/ClientsMonth-EndBalances.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Nov 2016",
                        "oneMonth"  : "Oct 2016 to Nov 2016",
                        "threeMonths" : "Sep 2016 to Nov 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["Text", "DBF"]
                }, {
                    "title": "Recently exited (zero balance) investors",
                    "report_id": 5875,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_holiday_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "15 Dec 2016",
                        "oneMonth"  : "Nov 2016 to Dec 2016",
                        "threeMonths" : "Oct 2016 to Dec 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["DBF", "Excel"]
                }, {
                    "title": "Client-wise RPO Report",
                    "report_id": 1245,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Client-wise-RPO-Report.pdf",
                    "rangeType":[{
                        "AsonDate" : "8 Dec 2015",
                        "oneMonth"  : "Nov 2015 to Dec 2015",
                        "threeMonths" : "Oct 2015 to Dec 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }, {
                    "title": "Top 200 Clients",
                    "report_id": 2576,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_quickAction_banner.jpg",
                    "rangeType":[{
                        "AsonDate" : "16 Nov 2015",
                        "oneMonth"  : "Oct 2015 to Nov 2015",
                        "threeMonths" : "Sep 2015 to Nov 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Text", "Excel"]
                }]
            },
            {
                "reportName":"Special Products",
                "reportData": [{
                    "title": "Product Investors",
                    "report_id": 3333,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_childEducation_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "2 Jun 2015",
                        "oneMonth"  : "May 2015 to Jun 2015",
                        "threeMonths" : "Apr 2015 to Jun 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Text", "Excel"]
                }, {
                    "title": "special products2",
                    "report_id": 2222,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/special-products2.pdf",
                    "rangeType":[{
                        "AsonDate" : "18 Sep 2016",
                        "oneMonth"  : "Aug 2016 to Sep 2016",
                        "threeMonths" : "Jul 2016 to Sep 2016",
                        "oneYear"  : "2015",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "DBF"]
                }, {
                    "title": "Recent Products",
                    "report_id": 7878,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_retirement_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "1 Apr 2015",
                        "oneMonth"  : "Mar 2015 to Apr 2015",
                        "threeMonths" : "Feb 2015 to Apr 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["DBF", "Excel"]
                }]
            },
            {
                "reportName":"Transaction Details",
                "reportData": [{
                    "title": "Transaction Details1",
                    "report_id": 5566,
                    "sampleType": "image",
                    "sampleSource": "./images/fti_dreamHome_thumb.jpg",
                    "rangeType":[{
                        "AsonDate" : "22 Aug 2015",
                        "oneMonth"  : "Jul 2015 to Aug 2015",
                        "threeMonths" : "Jun 2015 to Aug 2015",
                        "oneYear"  : "2014",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "DBF", "Text"]
                }, {
                    "title": "Transaction Details2",
                    "report_id": 2255,
                    "sampleType": "PDF",
                    "sampleSource": "https://online.franklintempletonindia.com/MailbackTemplates/Transaction-Details2.pdf",
                    "rangeType":[{
                        "AsonDate" : "15 Jun 2014",
                        "oneMonth"  : "May 2015 to Jun 2015",
                        "threeMonths" : "Apr 2015 to Jun 2015",
                        "oneYear"  : "2013",
                        "period" : true
                    }],
                    "availableFormat": ["Excel", "Text"]
                }]
            }
        ]
    }
]

});

InstantReportsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InstantReportsLookUp table, please contact admin...');
    } else {
        InstantReportsLookUp.remove({}, function(err) {
            console.log('InstantReportsLookUp collection removed');
            InstantReportsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InstantReportsLookUp table, please contact admin...');
                }
                console.log('InstantReportsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InstantReportsLookUp;
