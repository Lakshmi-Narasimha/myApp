/**
 * @ngdoc directive
 * @name ftickeyValueVerticalTileListScroll
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @requires advisorEventConstants
 * @requires unitHolderModel
 * @description
 *
 * - ftickeyValueVerticalTileListScroll will display the vertical tiles for "My profile - Grant Access" .
 * 
 *
 **/
'use strict';

var keyValueVerticalTileListScroll = function() {
	return {
            template: require('./keyValueVerticalTileListScroll.html'),
            restrict: 'E',
            replace: true,
            scope: {
                list: '='
            }
        };
};

keyValueVerticalTileListScroll.$inject = [];
module.exports = keyValueVerticalTileListScroll;