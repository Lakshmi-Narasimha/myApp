// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SipBookModelSchema = new mongoose.Schema({
    sipBookResp: {
        type: Array,
        "default": []
    }
});

var SipBookModelLookUp = mongoose.model('SipBookModelLookUp', SipBookModelSchema);

var SipBookModel = new SipBookModelLookUp({
    sipBookResp : {
  "AUMAgeing": {
    "fundWiseData_AUMAgeingResp": [{
      "assetCategory": "ELSS",
      "ltOneYr": "1019748.21",
      "oneToThreeYrs": "2947193.37",
      "threeToFiveYrs": "2108534.01",
      "gtFiveYrs": "7396994.04",
      "grandTotal": "13472469.63"
    }, {
      "assetCategory": "EQUITY",
      "ltOneYr": "25028771.62",
      "oneToThreeYrs": "31702497.62",
      "threeToFiveYrs": "18667454.11",
      "gtFiveYrs": "63645183.22",
      "grandTotal": "139043906.57"
    }, {
      "assetCategory": "FEEDER",
      "ltOneYr": "613676.63",
      "oneToThreeYrs": "904755.34",
      "threeToFiveYrs": "0",
      "gtFiveYrs": "0",
      "grandTotal": "1518431.97"
    }, {
      "assetCategory": "FIXED INCOME",
      "ltOneYr": "1328480.73",
      "oneToThreeYrs": "659567",
      "threeToFiveYrs": "345318.84",
      "gtFiveYrs": "1513028.47",
      "grandTotal": "3846395.04"
    }, {
      "assetCategory": "FOF",
      "ltOneYr": "348995.11",
      "oneToThreeYrs": "551783.06",
      "threeToFiveYrs": "167814.42",
      "gtFiveYrs": "537856.85",
      "grandTotal": "1606449.44"
    }, {
      "assetCategory": "BALANCED",
      "ltOneYr": "92834.49",
      "oneToThreeYrs": "12511.79",
      "threeToFiveYrs": "23094.63",
      "gtFiveYrs": "137366.77",
      "grandTotal": "265807.68"
    }],
    "total": {
      "assetCategory": "GRAND TOTAL",
      "ltOneYr": "28432506.79",
      "oneToThreeYrs": "36778308.18",
      "threeToFiveYrs": "21312216.01",
      "gtFiveYrs": "73230429.35",
      "grandTotal": "159753460.33"
    }
  },
  "overview": [{
    "type": "Total SIPs",
    "sips": "",
    "amt": ""
  }, {
    "type": "New SIPs",
    "sips": "",
    "amt": ""
  }, {
    "type": "SIPs Matured",
    "sips": "",
    "amt": ""
  }, {
    "type": "SIPs Cancelled",
    "sips": "",
    "amt": ""
  }, {
    "type": "Active SIPs",
    "sips": "",
    "amt": ""
  }],
  "fundsRedeemed": {
    "fundWiseData_fundsRedeemed": [{
      "name": "Franklin India Blue Chip Fund",
      "amount": "629413.39"
    }, {
      "name": "Franklin India Prima Fund",
      "amount": "224901.55"
    }, {
      "name": "Franklin India Flexi Cap Fund",
      "amount": "160546.07"
    }, {
      "name": "Franklin India High Growth Companies Fund",
      "amount": "83879.34"
    }, {
      "name": "Franklin India Smaller Companies Fund",
      "amount": "25416.03"
    }, {
      "name": "Franklin Build India Fund",
      "amount": "24197.81"
    }, {
      "name": "Franklin India Taxshield Openend",
      "amount": "21749.58"
    }, {
      "name": "Franklin India Prima Plus",
      "amount": "15008.01"
    }, {
      "name": "Franklin Asian Equity Fund",
      "amount": "619.76"
    }],
    "total": {
      "name": "Total",
      "amount": "934300.01"
    }
  },
  "fundsPurchased": {
    "fundWiseData_purchased": [{
      "name": "Franklin India High Growth Companies Fund",
      "amount": "1435000"
    }, {
      "name": "Franklin India Blue Chip Fund",
      "amount": "568073"
    }, {
      "name": "Franklin India Prima Plus",
      "amount": "273000"
    }, {
      "name": "Franklin India Flexi Cap Fund",
      "amount": "183746"
    }, {
      "name": "Franklin India Prima Fund",
      "amount": "123000"
    }, {
      "name": "Franklin India Low Duration Fund",
      "amount": "111500"
    }, {
      "name": "Franklin India Taxshield Openend",
      "amount": "107000"
    }, {
      "name": "Franklin India Smaller Companies Fund",
      "amount": "103000"
    }, {
      "name": "Franklin India Opportunities Fund",
      "amount": "74000"
    }, {
      "name": "Templeton India Growth Fund",
      "amount": "42500"
    }],
    "total": {
      "name": "Total",
      "amount": "3020819"
    }
  },
  "details": {
    "allFunds": [],
    "diversifiedEquity": [],
    "debtAndLiquid": [],
    "fundOfFunds": [],
    "balanced": [],
    "sectorEquity": []
  }
}
}
);

SipBookModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SipBookModelLookUp table, please contact admin...');
    } else {
        SipBookModelLookUp.remove({}, function(err) {
            console.log('SipBookModelLookUp collection removed');
            SipBookModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SipBookModelLookUp table, please contact admin...');
                }
                console.log('SipBookModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SipBookModelLookUp;
