'use strict';
var smrtsolInvstSummary = function () {
    return {
        template: require('./smrtsolInvstSummary.html'),
        restrict: 'E',
        replace: true,
        scope: {
            invstSummary: "="
        },

        controller: function ($scope, $element, $attrs, buildPlanInitialLoader, buildPlanModelService) {

            $scope.invType = buildPlanModelService.getInvestmentType();
            $scope.gridData = [];
            $scope.columnDefs = [];

            $scope.fundDetails = buildPlanModelService.getGoalPlanData();

            angular.forEach($scope.fundDetails, function (isDetails) {
                var gridRow = {};
                gridRow = investmentOptions($scope.invType, gridRow, isDetails.installmentDetails);
                gridRow.folioNumber = isDetails.fundName;
                gridRow.ModeofHolding = isDetails.allocation;
                $scope.gridData.push(gridRow);
            });
            $scope.totalDetails = buildPlanModelService.getGoalTotalPlanData();
            var myLastRow = {};
            myLastRow = investmentOptions($scope.invType, myLastRow, $scope.totalDetails);
            myLastRow.folioNumber = "Total";
            myLastRow.ModeofHolding = $scope.totalDetails.allocation;
            $scope.gridData.push(myLastRow);
            $scope.columnDefs = [
                {field: 'folioNumber', displayName: 'Fund Name', width: "250", pinnedLeft: true}];
            if (buildPlanModelService.tabname == "buildplan") {
                $scope.columnDefs.push({field: 'ModeofHolding', displayName: '%', width: "150"});
            }
            if ($scope.invType == "Monthly" || $scope.invType == "Combo") {
                $scope.columnDefs.push({
                    field: 'monthly',
                    displayName: 'Monthly',
                    width: "150",
                    headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
                    cellClass:'text-right'
                });
            }
            if ($scope.invType == "Annually" || $scope.invType == "Combo") {
                $scope.columnDefs.push({
                    field: 'annually',
                    displayName: 'Annually',
                    width: "150",
                    headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
                    cellClass:'text-right'
                });
            }
            if ($scope.invType == "One time" || $scope.invType == "Combo") {
                $scope.columnDefs.push({
                    field: 'oneTime',
                    displayName: 'One Time',
                    width: "150",
                    headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
                    cellClass:'text-right'
                });
            }

            function investmentOptions (invType , gridRow, isDetails) {
                if (invType == "Monthly" || invType == "Combo") {
                    gridRow.monthly = isDetails.monthly;
                }
                if (invType == "Annually" || invType == "Combo") {
                    gridRow.annually = isDetails.annually;
                }
                if (invType == "One time" || invType == "Combo") {
                    gridRow.oneTime = isDetails.oneTime;
                }
                return gridRow;
            };
        }

    };

};

smrtsolInvstSummary.$inject = ['buildPlanInitialLoader', 'buildPlanModelService'];
module.exports = smrtsolInvstSummary;