/**
 * @ngdoc property
 * @name fticStepUpSip Directive
 * 
 * @description
 *
 * - This directive is responsible for acquiring the Step Up details.
 *
 **/
'use strict';

var fticStepUpSip = function (transactEventConstants, eventConstants, transactModel, $filter,SipModifyDetailModel,TransactConstant,fundDetails) {
    return {
        template: require('./stepupsip.html'),
        restrict: 'E',
        replace: true,
        scope: {
            sipType:"@"
        },
        controller:['$scope', function ($scope) {
            console.log("Step Up Directive");
            var datefilter = $filter('date');
            $scope.cycle = {};
            $scope.stepUpObj = {};
            $scope.cycle.selectedVal = "";
            var susObj = transactModel.getFundDetails();
            var condCheck = false;
            $scope.EnableConfirm = false;
            $scope.config = {};
            $scope.config.showNotification = false;

            $scope.sipCycleActionsObj = [
                {
                    title:datefilter(susObj.nextTriggerDate, 'dd MMM yyyy'),
                    value:datefilter(susObj.nextTriggerDate, 'dd MMM yyyy'),
                    selected:false,
                    desc : $filter('translate')(TransactConstant.modifySip.Next_Instal_Date)
                },
                {
                    title:datefilter(susObj.sipAnnualCycle, 'dd MMM yyyy'),
                    value:datefilter(susObj.sipAnnualCycle, 'dd MMM yyyy'),
                    selected:false,
                    desc : $filter('translate')(TransactConstant.modifySip.Basis_SIP_Ann_Cyc)
                }
            ];

            $scope.listenCylChange = function(sipObject){
                console.log($scope.cycle.selectedVal);
                $scope.stepUpObj.stepUpDateDesc = sipObject.desc;
            };

            $scope.$on(eventConstants.CHECKBOX_CHECKED, function($event, checkboxObject){
                if (checkboxObject.value) {
                    $scope.EnableConfirm = true;
                } else {
                    $scope.EnableConfirm = false;
                }
                
            });
            
            $scope.getSelections = function(){
                var formValid = false;
                if($scope.stepUp.$valid){
                     formValid = true;
                    if($scope.stepUp.validPerc && $scope.stepUp.validAmount){
                            formValid = true;
                    } else{
                            formValid = false;
                    }
                }
                
                if(formValid) {
                if($scope.stepUpObj.setpUpOption){
                    $scope.stepUpObj.cycleDet = $scope.cycle.selectedVal;
                    if($scope.stepUpObj.setpUpOption == "other"){
                        $scope.stepUpObj.stepUpSip = $scope.stepUpObj.increaseByPerc ;
                        $scope.stepUpObj.stepUpVal = $scope.stepUpObj.increaseByPerc + "%";
                        $scope.stepUpObj.stepUpType = "P";
                        $scope.stepUpObj.stepUpValAmnt = $scope.stepUpObj.increaseByPerc * parseInt(susObj.amount) / 100 ;
                    }
                    else if($scope.stepUpObj.setpUpOption == "amount"){
                        $scope.stepUpObj.stepUpSip = $scope.stepUpObj.increaseByAmount;
                        $scope.stepUpObj.stepUpVal = "<i class='icon-fti_rupee'></i>" + $scope.stepUpObj.increaseByAmount;
                        $scope.stepUpObj.stepUpType = "A";
                        $scope.stepUpObj.stepUpValAmnt = $scope.stepUpObj.increaseByAmount;
                    }else{
                        $scope.stepUpObj.stepUpSip = $scope.stepUpObj.setpUpOption;
                        $scope.stepUpObj.stepUpVal = $scope.stepUpObj.setpUpOption + "%";
                        $scope.stepUpObj.stepUpType = "P";
                        $scope.stepUpObj.stepUpValAmnt = parseInt($scope.stepUpObj.setpUpOption) * parseInt(susObj.amount) / 100;
                    }
                        //$scope.stepUpObj.stepUpSip = $scope.stepUpObj.stepUpSip;
                        //console.log($scope.stepUpObj);
                        $scope.stepUpObj.sipModifyType = $scope.sipType;
                        $scope.stepUpObj.txnSource = "SIPSUP";
                        $scope.stepUpObj.sipOptionName = "Step Up SIP";
                        $scope.stepUpObj.strtDate =  $scope.stepUpObj.cycleDet;
                        $scope.stepUpObj.efctvMnth = datefilter(Date.parse($scope.cycle.selectedVal), 'MMM yyyy');
                        //$scope.stepUpObj.stepUpVal = $scope.stepUpObj.stepUpSip;

                        //console.log($scope.stepUpObj.efctvMnth);
                        SipModifyDetailModel.setModifySipDetails($scope.stepUpObj);

                        // setting step up values for validate sip
                        var fundDetailsObj = fundDetails.getFundDetails();
                        fundDetailsObj[0].stepUpSip = "A";
                        fundDetailsObj[0].stepUpType = $scope.stepUpObj.stepUpType;
                        fundDetailsObj[0].stepUpValue = $scope.stepUpObj.stepUpSip;
                        //fundDetails.setFundDetails(fundDetailsObj);

                        if(susObj.paymentMode === TransactConstant.common.EMANDATE_CODE || susObj.paymentMode === TransactConstant.common.AUTO_DEBIT_CODE){
                            if (susObj.achDebitType == "F")
                            {
                                condCheck = true;
                            } 
                            else {
                                $scope.sumTotal = parseInt($scope.stepUpObj.stepUpValAmnt);
                                if($scope.sumTotal > parseInt(susObj.achAmount)){
                                    condCheck = true;
                                }else{
                                    condCheck = false;
                                }
                            }
                        }
                        if(condCheck){   
                            $scope.config.showNotification = true;
                        }else{
                            $scope.$emit(transactEventConstants.transact.Set_Modify_Sip_Details);
                        } 
                    };
                };
            }
            $scope.$on('yes', function(event, data){
                $scope.config.showNotification = false;
                $scope.$emit(transactEventConstants.transact.Set_Key_Value_Object);  
                $scope.$emit(transactEventConstants.transact.Payment_Detail);

            }); 
            $scope.$on('no', function(event, data){
                 $scope.config.showNotification = false;
            }); 

            
           
        }]
    };
};

fticStepUpSip.$inject = ['transactEventConstants', 'eventConstants', 'transactModel', '$filter','SipModifyDetailModel','TransactConstant','fundDetails'];
module.exports = fticStepUpSip;