export { TypeaheadMatch } from './typeahead-match.class';
export { TypeaheadOptions } from './typeahead-options.class';
export { TypeaheadUtils } from './typeahead-utils';
export { TypeaheadContainerComponent } from './typeahead-container.component';
export { TypeaheadDirective } from './typeahead.directive';
export { TypeaheadModule } from './typeahead.module';
