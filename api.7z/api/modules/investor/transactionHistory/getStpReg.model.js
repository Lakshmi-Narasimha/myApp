// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var STPInvRegdModelSchema = new mongoose.Schema({
    stpRegdResp: {
        type: Array,
        "default": []
    }
});

var STPInvRegdModelLookUp = mongoose.model('STPInvRegdModelLookUp', STPInvRegdModelSchema
);

var STPRegdModel = new STPInvRegdModelLookUp({
    stpRegdResp : {
    "siSummarys":[  
      {  
         "folioId":"17024206",
         "modeofHolding":"Joint",
         "holders":{  
            "firstHoldersName":"AASHISH SADANAND NARKAR NARYAN SHANTA",
            "secondHoldersName":"Raghu krishan",
            "thirdHoldersName":"Shyam chander"
         },
         "rows":[  
            {  
              "status":"null",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend-Franklin India Taxshield - Dividend"
            },
            { "status":"",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            { "status":null,
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            { "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            { "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            {  "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            },
            { "status":"active",
               "accountNo":"0359903636631",
               "amount":"5,000.00",
               "familySolution":"Yes",
               "frequency":"Monthly",
               "fundOpt":"null",
              "txnNo":"PT13020197",
               "sourceFund":"Franklin India Taxshield - Dividend",
               "destFund":"Franklin India Taxshield - Dividend"
            }]
    }]

}
}
);

STPInvRegdModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating STPInvRegdModelLookUp table, please contact admin...');
    } else {
        STPInvRegdModelLookUp.remove({}, function(err) {
            console.log('STPInvRegdModelLookUp collection removed');
            STPRegdModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating STPInvRegdModelLookUp table, please contact admin...');
                }
                console.log('STPInvRegdModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = STPInvRegdModelLookUp;
