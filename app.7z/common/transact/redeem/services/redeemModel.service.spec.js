'use strict';
describe('Services: redeemModel', function() {
	var redeemModel,httpBackend,$window,transactModel,fundDetailsModel,selectInvestorModel,fetchTxnDetailsRedeemPromise,validateRedeemPromise,fetchBankDetailsPromise;

	var PaymentBanksByFolioResp = {
       "paymentBank": [{
            "accTypeDesc": "Savings Account",
            "achRefNo": "",
            "amount": "",
            "amountType": "",
            "defaultFlag": "Y",
            "fromDate": "",
            "ifscCode": "CITI0100000",
            "paymentType": "L",
            "payoutFlag": "N",
            "pbAccountType": "SA",
            "pbBankName": "CITI BANK",
            "pbMakerId": "",
            "pbPersonalAccountNumber": "7335300411",
            "regDate": "",
            "status": "",
            "toDate": ""
        }, {
            "accTypeDesc": "Savings Account",
            "achRefNo": "",
            "amount": "",
            "amountType": "",
            "defaultFlag": "Y",
            "fromDate": "",
            "ifscCode": "CITI0100000",
            "paymentType": "T",
            "payoutFlag": "N",
            "pbAccountType": "SA",
            "pbBankName": "CITI BANK",
            "pbMakerId": "",
            "pbPersonalAccountNumber": "7335300411",
            "regDate": "",
            "status": "",
            "toDate": ""
        }, {
            "accTypeDesc": "Savings Account",
            "achRefNo": "",
            "amount": "",
            "amountType": "",
            "defaultFlag": "Y",
            "fromDate": "",
            "ifscCode": "CITI0100000",
            "paymentType": "W",
            "payoutFlag": "N",
            "pbAccountType": "SA",
            "pbBankName": "CITI BANK",
            "pbMakerId": "",
            "pbPersonalAccountNumber": "7335300411",
            "regDate": "",
            "status": "",
            "toDate": ""
        }]
    };	

    var redeemObject = {
        'type': 'Full',
        'amount': '',
        'units': '8371.015',
        'mode': 'cheque',
        'bank': 'CITI BANK - 7335300411'
    };

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];

    var investorDetails =  {
		"custName": "Shankar Narayanan",                    
		"pan": "ABCD1234KL",
		"aadhar" : 123456789123,
		"folioId": 3456572,
		"holdingType": "Joint",
		"mobile": 9039758625,
		"emailId": "shankarnarayanan@gmail.com",
		"city":"P O BOX 170 170",
		"kycStatus":true,
		"holders": [
			{
			"name": "Shankar Narayanan",
			"type": "Firstholder",
			"kycregistered" : true,
			"pan": "ABCD1234KL",
			"aadhar" : 123456789123
			}, {
			"name": "JHON SMITH GOERGE",
			"type": "Secondholder",
			"kycregistered" : true,
			"pan": "ABCD1234KA",
			"aadhar" : 123456789120
			}, {
			"name": "KRISTIANA GOERGE",
			"type": "Thirdholder",
			"kycregistered" : true,
			"pan": "ABCD1234KB",
			"aadhar" : 123456789121
			}
		]
	};

	var fundDetailsResponse = {
        'fundDetails': [{
            'clearUnits': '8371.015',
            'lastestNav': '62.2344',
            'loadFreeUnits': '0',
            'navDate': '2017-01-16 00:00:00.0',
            'totalAvailableUnits': '8371.015',
            'unitDetails': {
                'lienUnits': '0',
                'unitsUnderProcess': '8371.015',
                'unitsUnderProvisionalStatus': '0'
            },
            'valueOfLoadFreeUnits': '0',
            'valueOfTotalAvailableUnits': '520965.095916'
        }]
    };

	var selectedFundObject = {
		"tschvalScheme": "006",
		"fmDescription": "Franklin India Bluechip Fund - Dividend",
		"fundCategory": "EQUITY",
		"fundType": "EQUITY",
		"tschvalAccno": "0069901064910",
		"balUnits": "2463.841",
		"marketValue": "349183.18",
		"tschvalFsFlag": "N",
		"investmentGoal": ""
	};

    beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function(_redeemModel_,_transactModel_,_selectInvestorModel_,$httpBackend,_$window_,_fundDetailsModel_){										
		redeemModel = _redeemModel_;
		transactModel = _transactModel_;
		fundDetailsModel = _fundDetailsModel_;
		selectInvestorModel = _selectInvestorModel_;
		httpBackend = $httpBackend;	
		
		transactModel.setTransactDetails({
			"investorDetails" : investorDetails,
			"fundDetails" : selectedFundObject,
			"transactDetails" : redeemObject
		});	

		selectInvestorModel.setSelectedInvestorDtls(investorDetails);
		fundDetailsModel.setFundDetails(fundDetailsResponse);            
		$window = _$window_;
        $window.ga = function() {};
	}));	

	it("fetchTxnDetailsRedeem should be defined",function(){
		expect(redeemModel.fetchTxnDetailsRedeem).toBeDefined();
	});

	it("validateRedeem should be defined",function(){
		expect(redeemModel.validateRedeem).toBeDefined();
	});

	describe("fetchTxnDetailsRedeem promise",function(){
		beforeEach(inject(function() {						
			fetchTxnDetailsRedeemPromise = redeemModel.fetchTxnDetailsRedeem();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/getTxnDetailsRedeem').respond(200,[{"status":"success"}]);
			fetchTxnDetailsRedeemPromise.then(function(response){										
				expect(response[0].status).toBe("success");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/getTxnDetailsRedeem').respond(400,failureResponse);
			fetchTxnDetailsRedeemPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	describe("validateRedeem promise",function(){
		beforeEach(inject(function() {
			redeemModel.setBankDetails(PaymentBanksByFolioResp);						
			validateRedeemPromise = redeemModel.validateRedeem();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectPOST('http://localhost:3030/transact/validateSell?guId=878').respond(200,[{"status":"success"}]);
			validateRedeemPromise.then(function(response){										
				expect(response[0].status).toBe("success");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectPOST('http://localhost:3030/transact/validateSell?guId=878').respond(400,failureResponse);
			validateRedeemPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});

	describe("fetchBankDetails promise",function(){
		beforeEach(inject(function() {			
			fetchBankDetailsPromise = redeemModel.fetchBankDetails();				
		}));
 
		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/transact/paymentBanksByFolio?folioId=3456572&guId=878&paymentMethod=N').respond(200,PaymentBanksByFolioResp);
			fetchBankDetailsPromise.then(function(response){										
				expect(response.paymentBank.length).toBe(3);							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/transact/paymentBanksByFolio?folioId=3456572&guId=878&paymentMethod=N').respond(400,failureResponse);
			fetchBankDetailsPromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});
});