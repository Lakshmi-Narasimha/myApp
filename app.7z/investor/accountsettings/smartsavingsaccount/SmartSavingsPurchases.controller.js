/**
 * @ngdoc property
 * @name Purchases Controller 
 * @requires $scope
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter


function PurchasesController($scope) {
    console.log('Purchases Controller called');
    $scope.instructionType = 'smartSavings';
}



PurchasesController.$inject = ['$scope'];
module.exports = PurchasesController;
