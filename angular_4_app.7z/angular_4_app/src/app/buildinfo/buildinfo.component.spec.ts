import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildinfoComponent } from './buildinfo.component';

describe('BuildinfoComponent', () => {
  let component: BuildinfoComponent;
  let fixture: ComponentFixture<BuildinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
