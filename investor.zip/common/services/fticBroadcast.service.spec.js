/**
 * @ngdoc property
 * @name fticBroadcast service spec
 * @requires $scope
 * @requires constants
 * @description
 *
 * - Unit test suite for 'fticBroadcast.service.spec.js'.
 *
 **/
'use strict';

describe('#common-> services-> popup -> fticBroadcast spec', function() {

    var fticBroadcast,
        scope = {},
        eventName = {},
        eventData = {},
        paramName = {};
	    
    beforeEach(angular.mock.module('advisor'));

    beforeEach(function() {

        angular.mock.inject(function(_fticBroadcast_) {
            fticBroadcast = _fticBroadcast_;
        });
        spyOn(fticBroadcast,'eventBroadcast').and.callThrough();
    });

    it('fticBroadcast should be defined', function(){
        expect(fticBroadcast).toBeDefined();
    });
    it('should call eventBroadcast function', function(){
        scope.$broadcast = function(){
            return true;
        };
        fticBroadcast.eventBroadcast(scope,eventName,eventData,paramName);
        expect(fticBroadcast.eventBroadcast).toHaveBeenCalled();
    });
});