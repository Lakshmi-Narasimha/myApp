define([
], function () {
    let config = {
        awmServicePath:'https://mgpclientselector.dev.advisorcompass.com/ods.svc/',
        mgpServiceUrl:'https://mgpclientselector.dev.advisorcompass.com/ResponseProviderService/svc/mgp/',
        oboServicePath: 'https://mgpclientselector.dev.advisorcompass.com/adv_capl/oboselector/',
        mgpSubscriptionUrl: 'http://laa2app2527xrp:18013/ods.svc/',
        launchMgpUrl: 'pt-exit-mgp-scenario-1.html',
    };

    return config;
    
});