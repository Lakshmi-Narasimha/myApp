/**
 * @ngdoc property
 * @name fticSipForm Directive
 * @requires TransactConstant
 * @requires TransactConstant
 * @requires $filter
 * @requires transactEventConstants
 * @requires frequencyOptionsModel
 * @requires loggerConstants
 * @requires transactEvents
 * @requires fticLoggerMessage
 * @requires frequencyOptionsInitalLoader
 * @requires $timeout
 * @requires sipDetailsModel
 * @requires transactModel
 * @requires fundDetails
 * @requires $uibModal
 * @requires $stateParams
 * @description
 *
 * - It handles all the functionality and validations related to the form present in the SIP Select fund. And stores the data in a TransactModel, sipDetailsModel and fundDetails model.
 *
 **/
'use strict';

var fticSipForm = function(TransactConstant, $filter, transactEventConstants, frequencyOptionsModel, loggerConstants, transactEvents, fticLoggerMessage, frequencyOptionsInitalLoader, $timeout, sipDetailsModel, transactModel, fundDetails, $uibModal, $stateParams, $state, paperlessModel, newFundDetailsModel, eventConstants, configUrlModel, $window, appConfig, toaster, fundDetailsModel, authenticationService) {
    return {
        template: require('./sipForm.html'),
        restrict: 'E',
        scope: {
            kycState: "=?"
        },
        controller:['$scope', function($scope) {
            $scope.configDataLost = {};
            $scope.configDataLost.showNotification = false;
            //Variable assignments and default settings
            $scope.isPaperLess = transactModel.isPaperless;
            var translateFilter = $filter('translate'),
                futureDay, futureYear, futureMonth, futuredate, futureInstallmentDate, 
                datefilter = $filter('date'), 
                isDataChanged = true;
            $scope.sipConfigObj = {};
            $scope.master = {};
            $scope.transactionLimit = 0;
            $scope.sipConfigObj.showKycDtlsNotif = false;
            $scope.showFundsTile = false;
            $scope.showAddMoreBtn = false;
            $scope.showContinueBtn = false;
            $scope.sipConfigObj.showTransactionAmtNotification = false;
            $scope.isEditTile = false;
            $scope.editIndex = null;
            $scope.noFundSelected = true;
            $scope.isDirectInv = false;
            $scope.isInvalidFutureDate = true;
            $scope.isFutureDateWithinRange = true;
            $scope.isComingFromEdit = false;
            $scope.untilCancelledInfo = translateFilter(TransactConstant.sip.UNTIL_CANCELLED_INFO);
            $scope.isKycRegAadhar = false;

            // Transaction limit Notification popup 
            $scope.popUpHeader = translateFilter(TransactConstant.common.TRANSACTION_LIMIT_EXCEEDED);
            $scope.popUpText = translateFilter(TransactConstant.common.TRANSACTION_LIMIT_ERR_MSG);
            $scope.btnNo = translateFilter(TransactConstant.common.CANCEL_LABEL);
            $scope.btnYes = translateFilter(TransactConstant.common.DOWNLOAD_KYC_LABEL);
            $scope.noEventName = "FundLimitCancel";

            // KYC Additional Details Notification popup        
            $scope.kycDtlsText = $filter('translate')(TransactConstant.common.KYC_ADDITIONAL_DETAILS);
            $scope.kycDtlsBtnNo = $filter('translate')(TransactConstant.common.CANCEL);
            $scope.kycDtlsBtnYes = $filter('translate')(TransactConstant.common.CONTINUE);
            $scope.kycDtlsNoEventName = "kycDetailsCancel";

            $scope.showSipForm = true;
            $scope.sipDetails = {};
            $scope.sipDetails.disableStepUp = false;
            $scope.disableEndDate = true;

            //Setting default values for sipDetails object 
            var defaultDetails = angular.copy(sipDetailsModel.getDefaultSipDetails());
            $scope.sipDetails = defaultDetails;

            //Date variables setting - Needed to enable step up option and to validate no.of installments
            $scope.startDate = new Date();
            var startDateMonth = $scope.startDate.getMonth();
            var startDateYear = $scope.startDate.getFullYear();
            var startDateDay = $scope.startDate.getDate();

            $scope.twoYearsFromToday = new Date(startDateYear + 2, startDateMonth);
            $scope.twoYearsFromToday = new Date($scope.twoYearsFromToday.toDateString());

            $scope.sixMonthsFromToday = new Date(startDateYear, startDateMonth + 6);
            $scope.sixMonthsFromToday = new Date($scope.sixMonthsFromToday.toDateString());

            $scope.eighteenMonthsFromToday = new Date(startDateYear, startDateMonth + 18);
            $scope.eighteenMonthsFromToday = new Date($scope.eighteenMonthsFromToday.toDateString());

            /*It will not include day*/
            $scope.oneYearFromToday = new Date(startDateYear + 1, startDateMonth);
            $scope.oneYearFromToday = new Date($scope.oneYearFromToday.toDateString());

            /*It includes day also*/
            $scope.oneYearDayFromToday = new Date(startDateYear + 1, startDateMonth, startDateDay);
            $scope.oneYearDayFromToday = new Date($scope.oneYearDayFromToday.toDateString());

            $scope.threeYearsFromToday = new Date(startDateYear + 3, startDateMonth);
            $scope.threeYearsFromToday = new Date($scope.threeYearsFromToday.toDateString());

            $scope.sixYearsFromToday = new Date(startDateYear + 6, startDateMonth);
            $scope.sixYearsFromToday = new Date($scope.sixYearsFromToday.toDateString());

            $scope.twelveYearsFromToday = new Date(startDateYear + 12, startDateMonth);
            $scope.twelveYearsFromToday = new Date($scope.twelveYearsFromToday.toDateString());

            $scope.thirtyDaysFromToday = new Date(startDateYear, startDateMonth, startDateDay + 30);
            $scope.thirtyDaysFromToday = new Date($scope.thirtyDaysFromToday.toDateString());

            $scope.sixtyDaysFromToday = new Date(startDateYear, startDateMonth, startDateDay + 60);
            $scope.sixtyDaysFromToday = new Date($scope.sixtyDaysFromToday.toDateString());

            //Datepicker options
            $scope.dateOptions = {
                yearRows: 3,
                yearColumns: 4,
                datepickerMode: 'month',
                minMode: 'month',
                fulldatepickerMode: 'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                maxDate: $scope.oneYearFromToday,
                minDate: $scope.thirtyDaysFromToday,
                monthColumns: 4,
                showWeeks: false

            };

            //Datepicker options
            $scope.endDateOptions = {
                yearRows: 3,
                yearColumns: 4,
                datepickerMode: 'month',
                minMode: 'month',
                fulldatepickerMode: 'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                minDate: new Date(),
                monthColumns: 4,
                showWeeks: false
            };

            //UserInputFld Options
            $scope.sipAmtInputObject = {
                key: "sipAmount",
                text: translateFilter(TransactConstant.common.AMT) + " <span class='icon-fti_rupee'></span>",
                value: "",
                name: "sipAmount",
                type: "number",
                min: "",
                message: "",
                isRequired: true,
                pattern: /^[0-9]*$/
            };

            //Dividend radio buttons options
            $scope.dividendOptions = [{
                label: translateFilter(TransactConstant.common.DIVIDEND_RE_INVESTMENT),
                value: 'Re-Investment',
                selected: true,
                disable: false
            }, {
                label: translateFilter(TransactConstant.common.DIVIDEND_PAYOUT),
                value: 'Payout',
                selected: true,
                disable: false
            }];

            //SIP End date radio buttons options
            $scope.sipEndDateOptions = [{
                label: translateFilter(TransactConstant.common.UNTIL_CANCELLED),
                type: 'untilCancelled',
                value: 'Until Cancelled',
                selected: true
            }, {
                label: "",
                type: 'endDate',
                value: "End Date",
                selected: false
            }];

            /*Service Integration For InvestmentAmount - Starts*/
            var requestObject = {},returnedObj = {};
            requestObject.bodyObj = {};
            requestObject.bodyObj.fundOptions = [];

            function setRequestObject() {
                requestObject = {};
                requestObject.bodyObj = {};
                requestObject.bodyObj.fundOptions = [];
                returnedObj = fundDetailsModel.setCommonInvProperties();
                requestObject.bodyObj.folioId = returnedObj.folioId;
                requestObject.bodyObj.panNo = returnedObj.panNo;
                requestObject.bodyObj.webRefNo = returnedObj.webRefNo;

                if ($scope.invocationPoint === 1) {
                    var funds = [];
                    funds = fundDetails.getFundDetails();
                    funds.push({
                        sipAmount : $scope.sipDetails.sipAmount,
                        endDate : $scope.sipDetails.endDateOption === 'Until Cancelled' ? $scope.sipDetails.endDateOption : $scope.sipDetails.endDate,
                        frequency : $scope.sipDetails.frequency
                    });
                    setFundOptions(funds);
                } else if($scope.invocationPoint === 2){
                    setFundOptions(fundDetails.getFundDetails());
                }else {
                    requestObject.bodyObj.fundOptions = [];
                }

                //Calling service with requestObject
                if (requestObject.bodyObj.panNo && requestObject.bodyObj.folioId) {
                    fundDetails.fetchRvalidateInvFYLimit(requestObject).then(transactionLimitSuccess, transactionLimitFailure);
                }
            }

            function setFundOptions(fundDetailsArray) {
                angular.forEach(fundDetailsArray, function(value, key) {
                    var fundObj = {};
                    fundObj.amount = value.sipAmount.toString();
                    fundObj.txnType = "SIP";
                    fundObj.startDate = datefilter(new Date(), 'dd/MM/yyyy');
                    fundObj.endDate = value.endDate === "Until Cancelled" ? "" : value.endDate;
                    fundObj.frequency = value.frequency === 'Monthly' ? "M" : (value.frequency === "Annually" ? "A" : (value.frequency === "Quaterly" ? "Q" : value.frequency || ""));
                    requestObject.bodyObj.fundOptions.push(fundObj);
                });
            }

            function transactionLimitSuccess(data) {
                $scope.sipConfigObj.showTransactionAmtNotification = false;
                $scope.sipConfigObj.showKycDtlsNotif = false;
                if(!$scope.transactionLimit){
                    transactModel.setKycTransactionLimit(data.allowableTxnAmount);
                    $scope.transactionLimit = transactModel.getKycTransactionLimit();
                }

                if ($scope.invocationPoint === 1 && !$scope.onFundLoad) {
                    if (data.statusFlag === TransactConstant.transact.INVESTMENT_REJECTED_CODE) {
                        $scope.sipConfigObj.showTransactionAmtNotification = true;
                    } else {
                        saveInvestmentDetails();
                    }
                } else if ($scope.invocationPoint === 2 && !$scope.onFundLoad) {
                    if (data.statusFlag === TransactConstant.transact.INVESTMENT_WARNING_CODE) {
                        $scope.sipConfigObj.showKycDtlsNotif = true;
                    } else {
                        $scope.$emit(transactEventConstants.transact.Show_Fund);
                        $scope.$emit("paymntDtls");
                        if ($scope.isPaperLess) {
                            redirectToPaymentDtls();
                        }
                    }
                }
            }

            function transactionLimitFailure(data) {
                toaster.error(data.data[0].errorDescription);
            }
            /*Service Integration For InvestmentAmount - Ends*/

            //For Transaction limit validation, if user is KYC-reg through Aadhar 
            $scope.isKycRegAadhar = transactModel.getKYCMode();           
            $scope.$on('checkKycMode', function() {
                $scope.isKycRegAadhar = transactModel.getKYCMode();
                // Fetch transaction limit from service
                if($scope.isKycRegAadhar){
                    $scope.invocationPoint = 0;
                    setRequestObject();
                }
            });

            //On SIPForm load
            function checkKycModeOnLoad() {
                $scope.onFundLoad = true;
                $scope.invocationPoint = 0;
                setRequestObject();
            }
            if($scope.isKycRegAadhar){
                checkKycModeOnLoad();
            }
            

            /*If user comes from Review edit, reseting select fund - START */
            $scope.fundLimit;
            $scope.resettingDataOnEdit = function() {
                $scope.previousData = angular.copy(transactModel.getFundDetails());
                $scope.showSipForm = false;
                $scope.showContinueBtn = true;
                var detailsArr = fundDetails.getFundDetails();
                $timeout(function() {
                    $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
                }, 0);
                $scope.fundLimit = parseInt(newFundDetailsModel.getMaxFundLimit());
                if (detailsArr.length < $scope.fundLimit) {
                    $scope.showAddMoreBtn = true;
                }
            };

            if (transactModel.showFundsOnNo) {
                $scope.isComingFromEdit = true;
                $scope.resettingDataOnEdit();
            }

            //For Paperless Module
            if (paperlessModel.fundDtls.hasData) {
                $scope.isComingFromEdit = true;
                $scope.resettingDataOnEdit();
            };

            //For Transact Module
            if (($stateParams.key === TransactConstant.transact.Fund_Key || $stateParams.key === TransactConstant.transact.Payment_Key) && !(transactModel.openFundTab)) {
                $scope.isComingFromEdit = true;
                $scope.resettingDataOnEdit();
            };
            /*If user comes from Review edit, reseting select fund - CLOSE*/

            /*If not edit, then resetting the funddetails to empty*/
            if (!$scope.isComingFromEdit) {
                fundDetails.removeFundDetails();
                var sipDetailsArr = fundDetails.getFundDetails();
                sipDetailsModel.setSipDetails(sipDetailsArr);
                transactModel.setFundDetails(sipDetailsArr);
            }

            //If user selects "Download E-KYC" in download kyc notification popup
            var configURL = configUrlModel.getEnvUrl('MARKETING_URL'),
                transactNowUrl = appConfig[configURL] + "/#tab_tab2",
                pdfUrl = appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL;
            $scope.$on('downloadKyc', function(event, resp) {
                $scope.sipConfigObj.showTransactionAmtNotification = false;
                $window.open(pdfUrl, "_blank");
                if ($scope.isPaperLess || transactModel.isTransactNowModule) {
                    location.href = transactNowUrl;
                }else {
                    $state.go("transact.base.terminateEkyc");
                }
            });

            //If user selects "Cancel" in download kyc notification popup
            $scope.$on('FundLimitCancel', function() {
                $scope.sipConfigObj.showTransactionAmtNotification = false;
            });

            /* If user selects "Continue" in KYC Additional details popup */
            $scope.$on('showKycDtlsForm', function(event, data) {
                $scope.sipConfigObj.showKycDtlsNotif = false;
                paperlessModel.fundDtls.hasData = true;
                $state.go($scope.kycState);
            });

            /*If user selects "Cancel" in KYC Additional details popup */
            $scope.$on('kycDetailsCancel', function(event, data) {
                $scope.sipConfigObj.showKycDtlsNotif = false;
            });

            //Dividend options flag setting based on the fund selected
            $scope.$on(transactEventConstants.transact.FUND_UPDATED, function(event) {
                if (!$scope.fundLimit) {
                    $scope.fundLimit = parseInt(newFundDetailsModel.getMaxFundLimit());
                }

                $scope.dividendOptions[0].disable = false;
                $scope.dividendOptions[1].disable = false;
                $timeout(function() {
                    $scope.sipConfigObj.showDividendOptions = true;
                    $scope.sipDetails.dividend = "";
                    console.log("object in sipformdirective");
                    console.log($scope.destinationFund);
                    if ($scope.destinationFund) {
                        if ($scope.destinationFund.fundType === 'E') {
                            if ($scope.destinationFund.payoutFlag == 'Y' && $scope.destinationFund.reinvestmentFlag == 'Y') {
                                if ($scope.destinationFund.dividendFlag == 'P') {
                                    $scope.sipDetails.dividend = 'Payout';
                                    $scope.dividendOptions[0].disable = true;
                                    $scope.dividendOptions[1].disable = true;
                                } else if ($scope.destinationFund.dividendFlag == 'R') {
                                    $scope.sipDetails.dividend = 'Re-Investment';
                                    $scope.dividendOptions[0].disable = true;
                                    $scope.dividendOptions[1].disable = true;
                                }
                            } else if ($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'N') {
                                $scope.sipDetails.dividend = 'NA';
                                $scope.sipConfigObj.showDividendOptions = false;
                            } else if ($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'Y') {
                                $scope.sipDetails.dividend = 'Re-Investment';
                                $scope.dividendOptions[0].disable = true;
                                $scope.dividendOptions[1].disable = true;
                            } else {
                                $scope.sipDetails.dividend = 'Payout';
                                $scope.dividendOptions[0].disable = true;
                                $scope.dividendOptions[1].disable = true;
                            }
                        } else if ($scope.destinationFund.fundType === 'N') {
                            if ($scope.destinationFund.payoutFlag == 'Y' && $scope.destinationFund.reinvestmentFlag == 'Y') {
                                if ($scope.destinationFund.dividendFlag == 'P') {
                                    $scope.sipDetails.dividend = 'Payout';
                                } else if ($scope.destinationFund.dividendFlag == 'R') {
                                    $scope.sipDetails.dividend = 'Re-Investment';
                                }
                            } else if ($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'N') {
                                $scope.sipDetails.dividend = 'NA';
                                $scope.sipConfigObj.showDividendOptions = false;
                            } else if ($scope.destinationFund.payoutFlag == 'N' && $scope.destinationFund.reinvestmentFlag == 'Y') {
                                $scope.sipDetails.dividend = 'Re-Investment';
                            } else {
                                $scope.sipDetails.dividend = 'Payout';
                                if ($scope.destinationFund.dividendFlag == 'P') {
                                    $scope.dividendOptions[0].disable = true;
                                    //$scope.dividendOptions[1].disable = true;
                                }
                            }                           
                        }
                        $scope.sipAmtInputObject.value ='';
                        $scope.sipAmtInputObject.min = parseInt($scope.destinationFund.minSipAmt);
                        $scope.sipAmtInputObject.message = translateFilter(TransactConstant.common.MINIMUM) + " <span class='icon-fti_rupee'></span>" + $scope.destinationFund.minSipAmt;
                    }
                }, 0);
            });

            // This is done to handle the reset fund in case of Direct.
            $scope.$on(transactEventConstants.transact.FUND_CHANGED, function(event) {
                $scope.isDirectInv = true;
            });

            //Assigning sipAmount to sipDetails object, if amount changes
            $scope.sipAmountChanged = function(sipAmount) {
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipDetails.sipAmount = sipAmount;
            };

            //Future Installment Day option settings for section filter
            $scope.sipDetails.futureInstallmentMonth = new Date();
            $scope.days = [];
            var maxDayInMonth;

            function futureDays(date) {
                $scope.days = [];
                maxDayInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
                for (var i = 1; i <= maxDayInMonth; i++) {
                    $scope.days.push(i);
                }
                $scope.futureInstDayOptions = $scope.days.map(function(e) {
                    return {
                        title: e
                    };
                });
                if ($scope.futureInstDayOptions) {
                    $scope.sipConfigObj.defaultDaySelected = $scope.futureInstDayOptions[0];
                }
            }
            futureDays(new Date());


            $scope.futureInstallmentDateChange = function(selectedFutureDate) {
                $scope.isInvalidFutureDate = true;
                $scope.isFutureDateWithinRange = true;
                futureDays(selectedFutureDate);
            };

            $scope.futureInstDayInputObject = {
                label: translateFilter(TransactConstant.sip.DAY),
                name: "futureInstDay",
                required: true
            };

            //Assigning futureInstallmentDay to sipDetails object, if day changes
            $scope.$on('FutureInstallmentDayChange', function(event, selectedValue) {
                $scope.isInvalidFutureDate = true;
                $scope.isFutureDateWithinRange = true;
                $scope.sipDetails.futureInstallmentDay = selectedValue.title;
            });


            //Function to find the given "value" in a given object array
            $scope.findItemInFilter = function(objArr, value) {
                var obj = null;
                obj = (_.filter(objArr, function(x) {
                    return x.title == value;
                }))[0];
                return obj;
            };

            $scope.frequencyOptions = [{
                title: TransactConstant.transact.MNTHLY
            }, {
                title: TransactConstant.transact.QUATERLY
            }, {
                title: TransactConstant.transact.FREQ_ANNUALLY
            }];

            $scope.sipConfigObj.defaultFrequencySelected = $scope.findItemInFilter($scope.frequencyOptions, TransactConstant.transact.MNTHLY);

            //Destroying frequency serviceHandler
            function destroyServiceHandler() {
                serviceEventHandler();
            }
            $scope.frequencyInputOptions = {
                required: true,
                name: "frequency"
            };

            //Assigning frequency to sipDetails object, if frequency changes
            $scope.$on('transactFrequency', function(event, selectedValue) {
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipConfigObj.invalidTwelveInstallments = false;
                $scope.sipDetails.frequency = selectedValue.title;
            });

            //Handles End-date radio button change
            $scope.listenEndDateChange = function(type) {
                $scope.disableEndDate = true;
                $scope.sipDetails.disableStepUp = false;
                $scope.sipDetails.sipDetailsEndDate = new Date();
                if (type == 'endDate') {
                    $scope.sipDetails.disableStepUp = true;
                    $scope.disableEndDate = false;
                }
            }

            //Enable/disable Step-up based on end-date entered
            $scope.sipEndDateChange = function(endDate) {
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipConfigObj.invalidTwelveInstallments = false;
                if ($scope.sipDetails.endDateOption == "End Date") {
                    $scope.sipDetails.disableStepUp = true;
                    if (endDate) {
                        $scope.finalDate = new Date(endDate.toDateString());
                        if ($scope.finalDate >= $scope.twoYearsFromToday) {
                            $scope.sipDetails.disableStepUp = false;
                        } else {
                            $scope.sipDetails.showStepUpSip = false;
                        }
                    }
                }
            };


            //Handles Add More Functionality
            $scope.addMoreFunds = function(sipForm) {
                $scope.resetSipDetails(sipForm);
                $scope.showSipForm = true;
                $scope.showAddMoreBtn = false;
                $scope.showContinueBtn = false;
            }


            function goNexttab() {
                $scope.sipConfigObj.showKycDtlsNotif = false;
                $scope.noFundSelected = true;
                var detailsArr = fundDetails.getFundDetails();
                if (detailsArr.length > 0) {
                    var totalSipAmt = $scope.totalInvestmentAmount();
                    sipDetailsModel.setSipTotalAmount(totalSipAmt);
                    transactModel.setTransactType(TransactConstant.sip.SIP);

                    if ($scope.isKycRegAadhar || transactModel.isNewInvestor || transactModel.getIsNewFolio()) {
                        $scope.onFundLoad = false;
                        $scope.invocationPoint = 2;
                        setRequestObject();
                    } else {
                        $scope.$emit(transactEventConstants.transact.Show_Fund);
                        $scope.$emit("paymntDtls");
                        if ($scope.isPaperLess) {
                            redirectToPaymentDtls();
                        }
                    }
                } else {
                    $scope.noFundSelected = false;
                }
            }

            if ($stateParams.key == "Folio" || $stateParams.key == "investorPreference") {
                $stateParams.key = TransactConstant.transact.Fund_Key;
            }

            //Handles Continue Functionality
            $scope.continue = function() {
                isDataChanged = true;
                if ($stateParams.key === TransactConstant.transact.Fund_Key || transactModel.sipDetailsEditClicked || paperlessModel.fundDtls.hasData) {
                    transactModel.sipDetailsEditClicked = false;
                    var result = _.isEqual(angular.copy(transactModel.getFundDetails()), $scope.previousData);
                    if (!result) {
                        $scope.configDataLost.showNotification = true;
                        var destroyHandler = $scope.$on('yes', function() {
                            $scope.configDataLost.showNotification = false;
                            transactModel.showPaymentDtlsOnNo = false;
                            goNexttab();
                            destroyHandler();
                        });

                        $scope.$on('no', function() {
                            isDataChanged = false;
                            $scope.configDataLost.showNotification = false;
                        });
                    } else {
                        transactModel.showPaymentDtlsOnNo = true;
                        isDataChanged = false;
                        goNexttab();
                    }
                } else {
                    goNexttab();
                }
            }

            if($stateParams.key == "Folio" || $stateParams.key == "investorPreference"){
                $stateParams.key = TransactConstant.transact.Fund_Key;
            }

            //Handles Continue Functionality
            $scope.isValid = false;
            $scope.continue = function() {
                $scope.isValid = false;
                $scope.shownPopup = false;
                paperlessModel.paymentDtls.hasData = false;
                if($stateParams.key === TransactConstant.transact.Fund_Key || transactModel.sipDetailsEditClicked || paperlessModel.fundDtls.hasData){
                transactModel.sipDetailsEditClicked = false;
                    var result = _.isEqual(angular.copy(transactModel.getFundDetails()), $scope.previousData);
                        if (!result) {
                            $scope.configDataLost.showNotification = true;
                            $scope.shownPopup = true;
                            $scope.isValid = false;
                            var destroyHandler =  $scope.$on('yes', function () {
                                $scope.shownPopup = false;
                                $scope.configDataLost.showNotification = false;
                                transactModel.showPaymentDtlsOnNo = false;
                                $scope.isValid = goNexttab();
                                redirectToPaymentDtls(!($scope.isValid));
                                destroyHandler();
                              });

                              $scope.$on('no', function () {
                                    $scope.isValid = true;
                                    $scope.shownPopup = false;
                                    $scope.configDataLost.showNotification = false;
                                    if(paperlessModel.fundDtls.hasData){
                                       paperlessModel.paymentDtls.hasData = true;
                                    }
                              });
                        }
                        else{
                                if(paperlessModel.fundDtls.hasData){
                                   paperlessModel.paymentDtls.hasData = true;
                                }
                                transactModel.showPaymentDtlsOnNo = true;
                                $scope.isValid = goNexttab();
                        }
                }else{
                       $scope.isValid = goNexttab();
                    }
                    if($scope.shownPopup){
                        return true;
                    }else{
                        return $scope.isValid;
                    }
                
            }

            //Paperless : SIP Continue clicked
            $scope.$on(eventConstants.PAPERLESS_CONTINUE_CLICKED, function(event) {
                $scope.continue();
            });

            //Paperless : If form  valid
            function redirectToPaymentDtls() {
                paperlessModel.fundDtls.hasData = true;
                if(!isDataChanged && paperlessModel.paymentDtls.hasData){
                    paperlessModel.paymentDtls.hasData = true;
                }else{
                    paperlessModel.paymentDtls.hasData = false;
                }
                $scope.$emit(eventConstants.PAPERLESS_VALIDATED);
            }

            //Listened when Edit icon clicked in the Fund details grid
            $scope.$on(transactEventConstants.transact.Edit_Fund_Button_Clicked, function(event) {
                $scope.previousData = angular.copy(transactModel.getFundDetails());
                transactModel.sipDetailsEditClicked = true;
                transactModel.setTransactType(TransactConstant.sip.FUNDSIP);
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            });

            //Handles edit functionality present within the "Select Fund" grid
            $scope.$on('editSipFund', function(event, resp) {
                $scope.isEditTile = true;
                transactModel.sipDetailsEditClicked = true;
                $scope.editIndex = resp.index;
                $scope.editingObj = resp.data;
                $scope.showAddMoreBtn = false;
                $scope.showContinueBtn = false;
                $scope.showSipForm = true;
                $scope.sipDetails = {};
                $timeout(function() {
                    $scope.sipDetails = angular.copy(resp.data);
                    var fundArr = fundDetails.getFundArr();
                    $scope.fundObj = fundArr[resp.index];
                    $scope.$broadcast(transactEventConstants.transact.EDIT_FUND, {
                        fundObj: $scope.fundObj
                    });
                    $scope.sipAmtInputObject.value = $scope.sipDetails.sipAmount;
                    if ($scope.sipDetails.endDateOption == 'End Date') {
                        $scope.disableEndDate = false;
                    } else if ($scope.sipDetails.endDateOption == 'Until Cancelled') {
                        $scope.disableEndDate = true;
                        $scope.sipDetails.sipDetailsEndDate = "";
                    }
                    $scope.sipConfigObj.defaultFrequencySelected = $scope.findItemInFilter($scope.frequencyOptions, $scope.sipDetails.frequency);
                    $scope.sipConfigObj.defaultDaySelected = $scope.findItemInFilter($scope.futureInstDayOptions, $scope.sipDetails.futureInstallmentDay);
                }, 0);
            });

            //Handles Remove functionality present within the "Select Fund" grid
            $scope.$on('RemoveFund', function(event, resp) {
                $scope.noFundSelected = true;
                fundDetails.removeTile(resp.index);
                fundDetails.removeFundArr(resp.index);
                var detailsArr = fundDetails.getFundDetails();
                if (detailsArr.length > 0 && detailsArr.length < $scope.fundLimit && !$scope.showSipForm) {
                    $scope.showAddMoreBtn = true;
                } else if (detailsArr.length <= 0) {
                    $scope.addMoreFunds();
                }
                sipDetailsModel.setSipDetails(detailsArr);
                transactModel.setFundDetails(detailsArr);
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            });

            //Handles Reset functionality on clicking "Cancel"
            $scope.resetSipDetails = function(sipForm) {
                $scope.noFundSelected = true;
                $scope.isEditTile = false;
                $scope.$broadcast(transactEventConstants.transact.RESET_FUND);
                $scope.sipDetails = {};
                var defaultDetails = angular.copy(sipDetailsModel.getDefaultSipDetails());
                $scope.sipDetails = defaultDetails;
                $scope.sipAmtInputObject.value = $scope.sipDetails.sipAmount;
                $scope.disableEndDate = true;
                $scope.sipConfigObj.defaultFrequencySelected = $scope.findItemInFilter($scope.frequencyOptions, $scope.sipDetails.frequency);
                $scope.sipConfigObj.defaultDaySelected = $scope.findItemInFilter($scope.futureInstDayOptions, $scope.sipDetails.futureInstallmentDay);
                $scope.sipForm.$setPristine();
                var detailsArr = fundDetails.getFundDetails();
                if (detailsArr.length > 0) {
                    if (detailsArr.length < parseInt($scope.fundLimit)) {
                        $scope.showAddMoreBtn = true;
                    }
                    $scope.showContinueBtn = true;
                    $scope.showSipForm = false;
                }
                $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
            }

            //Calculates total investment amount
            $scope.totalInvestmentAmount = function() {
                $scope.fundDetailsArr = fundDetails.getFundDetails();
                if ($scope.fundDetailsArr.length > 0) {
                    var sipAmountArr = $scope.fundDetailsArr.map(function(item) {
                        return item.sipAmount;
                    });
                    var totalInvestmentAmt = sipAmountArr.reduce(function(prev, curr) {
                        return prev + curr;
                    });
                    if ($scope.isEditTile) {
                        totalInvestmentAmt = totalInvestmentAmt - $scope.editingObj.sipAmount;
                    }
                    return totalInvestmentAmt;
                } else {
                    return 0;
                }
            }

            var formValid = false, sipDetailsObj = {};
            //Handles Save functionality on clicking "Save"

            $scope.saveSipDetails = function() {
                $scope.noFundSelected = true;
                sipDetailsObj = {};
                formValid = false;
                $scope.isFundSelected = false;
                $scope.sipConfigObj.invalidSixInstallments = false;
                $scope.sipConfigObj.invalidTwelveInstallments = false;
                $scope.sipConfigObj.isSixInstallments = false;
                $scope.sipConfigObj.isTwelveInstallments = false;
                $scope.isInvalidFutureDate = true;
                $scope.isFutureDateWithinRange = true;
                if (!$scope.sipDetails.showStepUpSip) {
                    $scope.sipDetails.setpUpOption = "";
                    $scope.sipDetails.increaseByPerc = "";
                    $scope.sipDetails.increaseByAmount = "";
                    $scope.sipDetails.stepUpSip = "NA";
                }

                //If sipForm valid and Invest into fund is selected
                if ($scope.sipForm.$valid && $scope.destinationFund) {
                    formValid = true;

                    //STEP-UP-SIP custom form validation, if step-up-sip is selected
                    if ($scope.sipDetails.showStepUpSip) {
                        formValid = false;
                        if ($scope.sipForm.validPerc && $scope.sipForm.validAmount) {
                            formValid = true;
                        }
                    }

                    /*
                        No.of installments validation based on the End-date entered
                        NO_OF_INSTALLMENTS_SIP_MIN : 500
                        NO_OF_INSTALLMENTS_SIP_MAX : 1000
                    */
                    $scope.validateNoofInstallments = function(annualDate, quaterlyDate, monthlyDate, frequency) {
                        $scope.isInvalidInsatllment = false;
                        $scope.sipConfigObj.invalidSixInstallments = false;
                        $scope.sipConfigObj.invalidTwelveInstallments = false;
                        switch (frequency) {
                            case TransactConstant.transact.FREQ_ANNUALLY:
                                if ($scope.finalInstallmentDate < annualDate) {
                                    $scope.isInvalidInsatllment = true;
                                    // formValid = false;
                                }
                                break;
                            case TransactConstant.transact.QUATERLY:
                                if ($scope.finalInstallmentDate < quaterlyDate) {
                                    $scope.isInvalidInsatllment = true;
                                    // formValid = false;
                                }
                                break;
                            case TransactConstant.transact.MNTHLY:

                                if ($scope.finalInstallmentDate < monthlyDate) {
                                    $scope.isInvalidInsatllment = true;
                                    // formValid = false;
                                }
                                break;
                            default:
                        }
                        if ($scope.isInvalidInsatllment) {
                            if ($scope.sipConfigObj.isTwelveInstallments) {
                                $scope.sipConfigObj.invalidSixInstallments = false;
                                $scope.sipConfigObj.invalidTwelveInstallments = true;
                                formValid = false;
                            } else if ($scope.sipConfigObj.isSixInstallments) {
                                $scope.sipConfigObj.invalidSixInstallments = true;
                                $scope.sipConfigObj.invalidTwelveInstallments = false;
                                formValid = false;
                            }
                        }
                    };
                    if ($scope.sipDetails.endDateOption == "End Date") {
                        $scope.finalInstallmentDate = new Date($scope.sipDetails.sipDetailsEndDate.toDateString());
                        var selectedFrequency = $scope.sipDetails.frequency;

                        if ($scope.sipDetails.sipAmount >= parseInt(TransactConstant.sip.NO_OF_INSTALLMENTS_SIP_MIN) && $scope.sipDetails.sipAmount < parseInt(TransactConstant.sip.NO_OF_INSTALLMENTS_SIP_MAX)) {
                            $scope.sipConfigObj.isTwelveInstallments = true;
                            $scope.validateNoofInstallments($scope.twelveYearsFromToday, $scope.threeYearsFromToday, $scope.oneYearFromToday, selectedFrequency);

                        } else if ($scope.sipDetails.sipAmount >= parseInt(TransactConstant.sip.NO_OF_INSTALLMENTS_SIP_MAX)) {
                            $scope.sipConfigObj.isSixInstallments = true;
                            $scope.validateNoofInstallments($scope.sixYearsFromToday, $scope.eighteenMonthsFromToday, $scope.sixMonthsFromToday, selectedFrequency);

                        }
                    }


                    //Validating if the same fund is selected
                    if (!($scope.isEditTile && angular.equals(fundDetails.getFundArr()[$scope.editIndex], $scope.destinationFund))) {
                        var fundDetailsArrObj = fundDetails.getFundArr();
                        if (fundDetailsArrObj.length > 0) {
                            angular.forEach(fundDetailsArrObj, function(value, key) {
                                if (angular.equals(fundDetailsArrObj[key], $scope.destinationFund)) {
                                    $scope.isFundSelected = true;
                                    formValid = false;
                                };
                            });
                        }
                    }


                    /*Future installment Validation*/
                    futureInstallmentDate = $scope.sipDetails.futureInstallmentDay + " day - " + datefilter($scope.sipDetails.futureInstallmentMonth, 'MMM yyyy');
                    futureMonth = $scope.sipDetails.futureInstallmentMonth.getMonth();
                    futureYear = $scope.sipDetails.futureInstallmentMonth.getFullYear();
                    futuredate = new Date(futureYear, futureMonth, $scope.sipDetails.futureInstallmentDay);
                    
                    if(authenticationService.isInvestorLoggedIn()) {
                        if (futuredate < $scope.thirtyDaysFromToday || futuredate > $scope.sixtyDaysFromToday) {
                            $scope.isFutureDateWithinRange = false;
                            formValid = false;
                        }
                    }else {
                        if (futuredate < $scope.thirtyDaysFromToday || futuredate > $scope.oneYearDayFromToday) {
                            $scope.isFutureDateWithinRange = false;
                            formValid = false;
                        }
                    }

                }

                //Assigning sipDetails data to the models, if all the above validations are valid
                if (formValid) {
                    $scope.sipConfigObj.showTransactionAmtNotification = false;
                    $scope.sipConfigObj.showKycDtlsNotif = false;
                    $scope.sipDetails.stepUpValue = "";
                    $scope.sipDetails.stepUpType = "";
                    $scope.sipDetails.fundName = $scope.destinationFund.fundName;
                    $scope.sipDetails.fundOption = $scope.destinationFund.fundOption;
                    $scope.sipDetails.fundCategory = $scope.destinationFund.fundCategory;
                    $scope.sipDetails.nfoFlag = $scope.destinationFund.nfoFlag;
                    $scope.sipDetails.txnType = $scope.destinationFund.txnType;
                    $scope.sipDetails.dividendFlag = $scope.destinationFund.dividendFlag;
                    $scope.sipDetails.fundType = $scope.destinationFund.fundType;

                    if($scope.sipDetails.dividend === 'Payout'){
                        $scope.sipDetails.dividendFlag = 'P';
                    }else if($scope.sipDetails.dividend === 'Re-Investment'){
                        $scope.sipDetails.dividendFlag = 'R';
                    }

                    // $scope.sipDetails.startDate = datefilter($scope.startDate, 'dd/MM/yyyy');
                    if ($scope.destinationFund.fundType == 'E') {
                        $scope.sipDetails.accNo = $scope.destinationFund.accNo;
                    } else if ($scope.destinationFund.fundType == 'N') {
                        $scope.sipDetails.accNo = "NEW";
                    }

                    $scope.sipDetails.startDate = datefilter(futuredate, 'dd/MM/yyyy');
                    $scope.sipDetails.futureInstallment = futureInstallmentDate;
                    $scope.sipDetails.firstInstallment = "Current Business Day";

                    if ($scope.sipDetails.setpUpOption) {
                        if ($scope.sipDetails.setpUpOption == "other") {
                            $scope.sipDetails.stepUpSip = $scope.sipDetails.increaseByPerc + "%";
                            $scope.sipDetails.stepUpValue = $scope.sipDetails.increaseByPerc;
                            $scope.sipDetails.stepUpType = "P";
                        } else if ($scope.sipDetails.setpUpOption == "amount") {
                            $scope.sipDetails.stepUpSip = "Rs." + $scope.sipDetails.increaseByAmount;
                            $scope.sipDetails.stepUpValue = $scope.sipDetails.increaseByAmount;
                            $scope.sipDetails.stepUpType = "A";
                        } else {
                            $scope.sipDetails.stepUpSip = $scope.sipDetails.setpUpOption + "%";
                            $scope.sipDetails.stepUpValue = $scope.sipDetails.setpUpOption;
                            $scope.sipDetails.stepUpType = "P";
                        }

                        $scope.sipDetails.stepUpSip = $scope.sipDetails.stepUpSip + " " + TransactConstant.transact.FREQ_ANNUALLY;

                    } else {
                        $scope.sipDetails.stepUpSip = "NA";
                    };

                    if ($scope.sipDetails.endDateOption == "Until Cancelled") {
                        $scope.sipDetails.endDate = "Until Cancelled";
                        $scope.sipDetails.endDateMonthYear = "Until Cancelled";
                        $scope.sipDetails.perpetualFlag = "Y";
                    } else if ($scope.sipDetails.endDateOption == "End Date") {
                        $scope.sipDetails.perpetualFlag = "N";
                        $scope.sipDetails.endDate = datefilter($scope.sipDetails.sipDetailsEndDate, 'dd/MM/yyyy');
                        $scope.sipDetails.endDateMonthYear = datefilter($scope.sipDetails.sipDetailsEndDate, 'MMM yyyy');
                    };
                    
                    if ($scope.isEditTile) {
                        fundDetails.removeTile($scope.editIndex);
                        fundDetails.removeFundArr($scope.editIndex);
                        $scope.isEditTile = false;
                        $scope.editIndex = null;
                    }

                    //Transaction limit validation, if any of the user is kyc-red through aadhar
                    if ($scope.isKycRegAadhar) {
                        $scope.onFundLoad = false;
                        $scope.sipConfigObj.showTransactionAmtNotification = false;
                        $scope.invocationPoint = 1;
                        setRequestObject();
                    } else {
                        saveInvestmentDetails();
                    }

                }
            }

            function saveInvestmentDetails(){
                sipDetailsObj = angular.copy($scope.sipDetails);
                fundDetails.setFundDetails(sipDetailsObj);
                fundDetails.setFundArr($scope.destinationFund);
                var sipDetailsArr = fundDetails.getFundDetails();
                sipDetailsModel.setSipDetails(sipDetailsArr);
                transactModel.setFundDetails(sipDetailsArr);
                if($state.current.url === '/sip') {
                    transactModel.setTransactType(TransactConstant.sip.SIP);
                }
                
                $scope.showFundsTile = true;
                $scope.showAddMoreBtn = true;
                $scope.showContinueBtn = true;
                $scope.showSipForm = false;
                if (sipDetailsArr.length == parseInt($scope.fundLimit)) {
                    $scope.showAddMoreBtn = false;
                }
                $scope.$emit(transactEventConstants.transact.SHOW_PAPERLESS_BTNS);
                $scope.$broadcast(transactEventConstants.transact.Show_Fund_Tile);
            }
        }]
    };
};

fticSipForm.$inject = ['TransactConstant', '$filter', 'transactEventConstants', 'frequencyOptionsModel', 'loggerConstants', 'transactEvents', 'fticLoggerMessage', 'frequencyOptionsInitalLoader', '$timeout', 'sipDetailsModel', 'transactModel', 'fundDetails', '$uibModal', '$stateParams', '$state', 'paperlessModel', 'newFundDetailsModel', 'eventConstants', 'configUrlModel', '$window', 'appConfig', 'toaster', 'fundDetailsModel', 'authenticationService'];
module.exports = fticSipForm;
