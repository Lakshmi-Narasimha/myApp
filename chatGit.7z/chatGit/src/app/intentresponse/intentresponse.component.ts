import { Component, OnInit } from '@angular/core';
//import { LocalDataSource  } from 'ng2-smart-table';

@Component({
  selector: 'intentresponse',
  templateUrl: './intentresponse.component.html',
  styleUrls: ['./intentresponse.component.css']
})
export class IntentresponseComponent implements OnInit {

constructor() {
}

response : string = null;

  ngOnInit() {
  }

}
