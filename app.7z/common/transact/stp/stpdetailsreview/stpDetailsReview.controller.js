/**
 * @ngdoc property
 * @name stp details review Controller
 * @requires $scope
 * @requires stpDetailsModel
 * @requires TransactConstant
 * @requires $filter
 * @requires eventConstants
 * @description
 *
 * - It gets the data from stpDetailsModel and binds the data. 
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function stpDetailsReviewController($scope, stpDetailsModel, TransactConstant, $filter, eventConstants, transactModel, toaster,$state,authenticationService) {
		var datefilter = $filter('date');
		$scope.stpDetails = stpDetailsModel.getStpDetails();
		var _isInvestor = authenticationService.isInvestorLoggedIn();
		 if (_isInvestor) {

                $scope.startMonth = datefilter($scope.stpDetails.startMonth, 'MMMM yyyy');
                $scope.endMonth = datefilter($scope.stpDetails.endMonth, 'MMMM yyyy');
                $scope.startDate = $scope.stpDetails.freqStartDaySelected.title + ' of ' + $scope.startMonth;
                $scope.endDate = $scope.stpDetails.freqEndDaySelected.title + ' of ' + $scope.endMonth;
            } else {
                $scope.startDate = datefilter($scope.stpDetails.startDate, 'dd MMM yyyy');
                $scope.endDate = datefilter($scope.stpDetails.endDate, 'dd MMM yyyy');
            }
		$scope.destinationFund = $scope.stpDetails.destinationFund.fundName;
		$scope.stpAmount = $scope.stpDetails.stpAmount.amount;
		$scope.frequency = $scope.stpDetails.frequency;
		// $scope.startDate = datefilter($scope.stpDetails.freqStartDaySelected, 'dd MMM yyyy');
		// $scope.endDate = datefilter($scope.stpDetails.freqEndDaySelected, 'dd MMM yyyy');
		$scope.noofInstallments = $scope.stpDetails.noofInstallments;
		var _userType = authenticationService.getUser().userType;
		console.log(_userType);
		$scope.config.toTxnDetailsState = "transact.txnDetails.stp";
		$scope.config.toState = "transact.base.stp";
		if($scope.stpDetails.stpAmount.type === "fixedAmount"){
			$scope.stpDetails.stpAmount.type = "Fixed Amount";
		}
		if($scope.stpDetails.stpAmount.type ==="capitalAppreciation"){
			$scope.stpDetails.stpAmount.type = "Capital Appreciation";
		}
		if(authenticationService.isInvestorLoggedIn()){
		$scope.config.toTxnDetailsState = "invTransact.txnDetails";
		$scope.config.toState = "invTransact.base.stp";
		}
		
    	$scope.config.fromState = $state.current.name;

		$scope.amountStatus = transactModel.getStpFixedAmtStatus();
		console.log("amountStatus....", $scope.amountStatus,$scope.stpDetails);


	    $scope.stpKeyValuePairs = [
	    {
	        text : $filter('translate')(TransactConstant.transact.DESTINATION_FUND),
	        value: $scope.destinationFund
	    },
	    {
	         key: 'dfaccountnumber',
            text: 'Account Number',
            value: $scope.stpDetails.destinationFund.accNo
	    },
	    {
	         key: 'stpType',
            text: $filter('translate')(TransactConstant.transact.STP_TYPE),
            value: $scope.stpDetails.stpAmount.type
	    },
	    {
	        text : 'STP Amount',
	        value: $scope.stpAmount
	    },
	    {
	        text: $filter('translate')(TransactConstant.transact.FREQUENCY),
	        value: $scope.frequency
	    },
	    {
	        text: $filter('translate')(TransactConstant.stp.STP_START_DATE),
	        value: $scope.startDate
	    },
	    {
	        text: $filter('translate')(TransactConstant.stp.STP_END_DATE),
	        value: $scope.endDate
	    },
	    {
	        text: $filter('translate')(TransactConstant.stp.NO_OF_INSTALLMENTS),
	        value: $scope.noofInstallments
	    }
	];

	$scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){
    	$scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'stp'});
  	});
  	/*if($scope.amountStatus){
  		toaster.error(TransactConstant.stp.STP_FIXED_AMT_MSG);  		
  	}*/
}
stpDetailsReviewController.$inject = ['$scope', 'stpDetailsModel', 'TransactConstant', '$filter', 'eventConstants', 'transactModel', 'toaster','$state','authenticationService'];
module.exports = stpDetailsReviewController;