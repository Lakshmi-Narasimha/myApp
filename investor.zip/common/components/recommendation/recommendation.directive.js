'use strict';

var recommendation = function($state,fticRecommAndNotifiModel,constants,$filter,$window,eventConstants, $cookies) {
	return {
            template: require('./recommendation.html'),
            restrict: 'E',
            replace: true,
            scope: {                
                
            },
            controller: ['$scope','$element','$attrs', function($scope, $element, $attrs){
                $scope.recommendationsToDisplay = [];
                $scope.$on(eventConstants.RECOMM_AND_NOTIFI_DATA,function(event,data){
                    
                    $scope.recommandNotifiData = fticRecommAndNotifiModel.getRecommAndNotifiReport();
                    $scope.recommendations = $scope.recommandNotifiData.recommendations;

                    if($scope.recommendations) {
                        $scope.recommendationCount = $scope.recommendations.length;
                    }

                });
                var redirectAdvisorApp = $cookies.get("userRedirectURI");
                $scope.allRecmmondations = function(){
                    // $state.go('recommendationsreport');
                    $window.location.href=redirectAdvisorApp+"/#/recommendationsreport";
                    $scope.closePop=false;
                }
                $scope.recommendationClick = function(index){
                    // $state.go('recommendationsreport');
                    $window.location.href=redirectAdvisorApp+"/#/recommendationsreport";
                    $scope.closePop=false;
                //$scope.$emit($filter('translate')(constants.RECOM_CLICKED_TEXT),$scope.recommendations[x]);
                }
                    
            }],
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

recommendation.$inject = ['$state','fticRecommAndNotifiModel','constants','$filter','$window','eventConstants', '$cookies'];
module.exports = recommendation;