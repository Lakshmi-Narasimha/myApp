'use strict';

describe('Directive: One Touch Invest', function() {

	var compile, scope, directiveEle, isoScope, validHtml;
    validHtml = '<ftic-inv-db-one-touch-invest></ftic-inv-db-one-touch-invest>';
     //load all modules, including the html template, needed to support the test

    var create = function(html) {
        var element = angular.element(html);
        var compiledElem = compile(element)(scope);
        //isoScope = directiveEle.isolateScope();
        scope.$digest();
        return compiledElem;
    };

    var mockDashboardDetailModel = {
        getSmartSaveAccAndOneTouchData: function() {
            return {
                oneTouchInvest: {
                    description:'<span></span>'
                }
            };
        }
    };

    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {
        angular.mock.module(function($provide) {
            $provide.value('investorDashboardDetailsModel', mockDashboardDetailModel);
        });
    });
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
          scope = $rootScope.$new();
          compile = $compile;
        });
        
    });

    

    it('Directive should be defined', function() {
        var directiveEle = create(validHtml);
        expect(directiveEle).toBeDefined();
    });

    it('directive should be created with scope:true',function(){
        var directiveEle = create(validHtml);
        expect(directiveEle.scope()).toBeDefined();
	});

    it('Case-1 When no data is available for oneTouchInvest',function(){
        var directiveEle = create(validHtml);
        expect(directiveEle.scope()).toBeDefined();
        expect(scope.isDataAvailable).toBeFalsy();
	});

    it('Case-2 When data is available for oneTouchInvest',function(){
        var directiveEle = create(validHtml);
        var dirScope = directiveEle.scope();
        expect(directiveEle.scope()).toBeDefined();
        scope.$broadcast('investorSmartSavAccAndOneTouch');
        expect(dirScope.initData.description).toBe('<span></span>');
        expect(dirScope.isDataAvailable).toBeTruthy();
	});
});