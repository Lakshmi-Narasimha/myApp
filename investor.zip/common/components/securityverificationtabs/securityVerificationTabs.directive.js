/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var securityVerificationTabs = function($timeout) {
	return {
            template: require('./securityVerificationTabs.html'),
            restrict: 'E',
            replace: true,
            scope: {
                
            },
            controller: function($scope, $element, $attrs){
 
                  $scope.securityQuestion = function($event){
                        $event.preventDefault();
                        $scope.$emit('securityQuestionSelected');
                  }

                  $scope.otpSelected = function($event){
                        $event.preventDefault();
                        $scope.$emit('otpSelected');
                  } 
            },
            link: function(scope, iElement, iAttrs, controller){

            }
        };
};

securityVerificationTabs.$inject = ['$timeout'];
module.exports = securityVerificationTabs;