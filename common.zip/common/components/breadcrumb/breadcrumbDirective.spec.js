'use strict';

describe('Directive: Bread Crumb', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('commmon.components'));

    
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;                
            //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-bread-crumb></ftic-bread-crumb>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should define bread crumb element', function() {
        expect(directiveEle.html()).toBeDefined();
    });

});    