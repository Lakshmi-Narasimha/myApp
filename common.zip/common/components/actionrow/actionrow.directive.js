/**
 * @ngdoc directive
 * @name fticactionrow
 * @description
 *
 * - It displays a array of buttons which need to be passed while declaring this directive.
 * 
**/

'use strict';

var buttonsList = function($compile){
	return {
		template : require('./actionrow.html'),
		restrict : 'E',
		replace :true,
		scope : {
			buttonsArray : '='
		},
		link: function(scope){
			scope.doSomething = function(){
				
			};
		}

	};
};

buttonsList.$inject = ['$compile'];
module.exports = buttonsList;


