'use strict';


var transactEvents = function(eventConstants, fticBroadcast, transactEventConstants, selectFundModel, selectInvestorModel, newFolioModelService, checkKycModelService, folioValidationModelService) {

	return {
        transact:{
            publishselectFundDetails : function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.TRSCT_RED_SF, selectFundModel.getSelectFundDtls(), 'sfDtls');
            },
            publishFundDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.FUND_DETAILS, data, 'fund');
            },
            publishRedeemDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.REDEMPTION_DETAILS, data, 'redeem');
            },
            publishSwpDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.SWP_DETAILS, data, 'swp');
            },
            publishNewFundDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.NEW_FUND_DETAILS);
            },
            publishInvFundGrid: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.INV_FUND_DETAILS);
            },
            publishRegisteredBank: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.REGISTERED_BANK, 'data', 'registeredBank');
            },
            publishUnitsDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.UNITS_VALUE, 'data', 'units');
            },
            publishAmountDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.AMOUNT_VALUE, 'data', 'amount');
            },
            publishIfscDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.IFSC_DETAILS, data, 'ifsc');
            },
            publishIfscGridDetails: function(scope, data) {
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.IFSC_GRID_DETAILS, data, 'ifscgrid');
            },
            publishinvestorDtls : function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.Select_Investor, selectInvestorModel.getInvestors(), 'sIDtls');
            },
            publishNewFolioDetails :function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.New_Folio, newFolioModelService.getNewFolioDtls(), 'NewFolioDtlsRes');
            },
            publishCheckKyc :function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.Check_Kyc, checkKycModelService.getCheckKycDtls(), 'CheckKycResp');
            },
            publishFolioValidation :function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.Folio_Validation, folioValidationModelService.getFolioValidationDtls(), 'FolioValidationResp');
            },
            publishBuySIDetails : function(scope, data){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.BUYSELECTEDINVESTOR_DETAILS,'buy');
            },
            publishSIPmodify : function(scope, data){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.MOD_SIP_AMT_CHNG,'sipamtchange');
            },
            publishFrequencyOptions : function(scope, data){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.FREQUENCY_OPTIONS);
            },
            publishEUINDetails : function(scope){
                fticBroadcast.eventBroadcast(scope,transactEventConstants.transact.EUIN_DTLS)
            },
            publishInstantKyc : function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.INSTANT_KYC)
            },
            publishAmountSelected : function(scope){
                fticBroadcast.eventBroadcast(scope, transactEventConstants.transact.AMOUNT_SELECTED);
            }
        }
	}
};


transactEvents.$inject = ['eventConstants', 'fticBroadcast', 'transactEventConstants','selectFundModel', 'selectInvestorModel','newFolioModelService','checkKycModelService', 'folioValidationModelService'];

module.exports = transactEvents;
