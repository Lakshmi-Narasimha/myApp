// getcgaccountdetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var CapitalGainsAccountSchema = new mongoose.Schema({
    capitalGainsAccountObject: {
        type: Array,
        "default": []
    }
});

var CapitalGainsAccountLookUp = mongoose.model('CapitalGainsAccountLookUp', CapitalGainsAccountSchema);
var CapitalGainsAccountModel = new CapitalGainsAccountLookUp({
    "capitalGainsAccountObject": [
    {
      "unitHolderDetails" : {
          "invname" : "Shankar",
          "sstatus" : "NRI",
          "address" : {
            "line1":"B-34 Acrot Street No 161 Yerapalli street",
            "line2":"Vadapallani",
            "line3":"Chennai 763001"
          }
        },
      
           "accdetails":{
    
          "fundName": "Franklin India BlueChip - Fund Dividend",
          "accountNo": 5675454568,
          "purchase": {
              "TxType": "Purchase",
              "TxDate": "10 Nov 2015",
              "IndexedVal": "1230,22"
          },
          "redemption": {
              "TxType":"Redemption",
              "TxDate": "10 Nov 2015",
              "Amount": "1230,22"
          },
          "capital": {
            "shorterm": 0.00,
            "longterm": "10,12,00"
          },
           "taxded": {
            "total": 0.00,
            "stt": 169.0
          }         
          
      }
    }
            
          ]
        

});

CapitalGainsAccountLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating CapitalGainsAccountLookUp table, please contact admin...');
    } else {
        CapitalGainsAccountLookUp.remove({}, function(err) {
            console.log('CapitalGainsAccountLookUp collection removed');
           CapitalGainsAccountModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating CapitalGainsAccountLookUp table, please contact admin...');
                }
                console.log('CapitalGainsAccountLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = CapitalGainsAccountLookUp;
