/**
 * @ngdoc service
 * @name SIP Calculator Initial Loader
 * @description
 *
 * - Handles the services and model for calculators content details
 *
 */
 'use strict';

 var sipCalculatorInitialService = function(fticLoggerMessage, loggerConstants, $cookies, sipCalculatorModel, calculatorsEventConstants) {
    var sipCalculatorInitialService = {
        _isServicesData: false, 
        loadAllServices : function (scope) {
            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.DASHBOARD_MODULE + ' | ' + loggerConstants.DASHBOARD_INITIAL_LOADER_SERVICE + ' | loadAllServices' /* Function Name */; 
            fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            sipCalculatorModel.callFundDetailsData(scope.isAdvisor)
            .then(fundDetailsSuccess, promiseFailure);
            function fundDetailsSuccess (data) {
                sipCalculatorModel.setFundDetails(data);
                scope.$broadcast(calculatorsEventConstants.FUND_DETAILS);
            }
            
            function promiseFailure () {
                var fund = {'allfunds': {
                    newFunds : [ {
                        'fundOptDesc': 'Franklin India BlueChip Fund',
                        'fundOption': 'FT0001'
                    }, {
                        'fundOptDesc': 'Franklin India Prima Plus',
                        'fundOption': 'FT0002'
                    }]
                }};
                sipCalculatorModel.setFundDetails(fund);
                scope.$broadcast(calculatorsEventConstants.FUND_DETAILS);
            }
        }
    };
    return sipCalculatorInitialService;
};

sipCalculatorInitialService.$inject = ['fticLoggerMessage', 'loggerConstants', '$cookies', 'sipCalculatorModel', 'calculatorsEventConstants'];
module.exports = sipCalculatorInitialService;
