define([
    'jquery',
    'underscore',
    'backbone',
    'spinner',
    'appmodules/contactprofile/cpcommon',
    'services/dataservice',
    'errorLog',
    'text!appmodules/contactprofile/app/templates/hocactionneede.html'
], function ($, _, Backbone, Spinner, cpCommon, Dataservice,ErrorLog, HOCtemplate) {
    var hocView = Backbone.View.extend({
        template: _.template(HOCtemplate),
        el: $("#cp-content-container"),
        id: 'cp-content-container',
        events : {
        },
        initialize: function () {
        	var that = this;
        	$(document).off("click", ".btn-task-action").on("click", ".btn-task-action", this.taskActionClick);
        	$(document).off("click", ".hoc-task-backto-cp").on("click", ".hoc-task-backto-cp", this.taskActionCancelBtnClick);
        },

        render: function (clId) {
                $('#cp-content-container').html(this.template());
                $(".hdr-tab-buttons-wrap div").removeClass("hdr-tab-active");
                $(".hdr-tab-buttons-wrap .bt-hoc").addClass("hdr-tab-active");
                    $(window).scrollTop(0);
                },
        taskActionClick:function(){
        	$(window).scrollTop(0);
        	var _$container = $('#practicetech-subapp');
        	_$container.find('>div:first').hide();
        	var _hocTaskDummyPage = "<div id='hoc-task-dummy-page-ctnr'><div id='hoc-task-bg-image'></div><div id='hoc-task-backto-cp'><button class='pull-right btn btn-primary pt-h6 hoc-task-backto-cp'>Save</button><div id='cancel-button-hoc-task' class='pull-right cancel-text hoc-task-backto-cp'>Cancel<i class='icon-arrow-right'></i></div></div></div>";
        	_$container.append(_hocTaskDummyPage);
        },
        taskActionCancelBtnClick:function(){
        	$('#hoc-task-dummy-page-ctnr').remove()
        	$('#practicetech-subapp').find('>div:first').show();
        }
    });
    return hocView;
});