define(['jquery', 'lodash', 'backbone', 'app/common/util',  'app/common/models/CompTeam'
], function ($, _, Backbone, util, CompTeam) {

    function normalizedFMID(fmid) {
        return '' + parseInt(fmid);
    }

    function formattedFMID(fmid) {
        return util.formatWithZeros(fmid, 9);
    }

    var Advisor = Backbone.Model.extend({
        defaults: {
            firstName: undefined, // String
            middleName: undefined, // String
            lastName: undefined, // String
            fullName: undefined, // String
            fmid: undefined, // String (no left 0-padding)
            hasSellingAuthority: undefined, // Boolean
            formattedFmid: undefined, // String (fmid left-0 padded to full 9 chars)
            //practices: undefined, // PracticeCollection
            compTeams: undefined,   // [CompTeam]
            positionCode: undefined, // String,
            compSharingPercent: undefined,   // String, will in decimal percentage
            compSharingPercentFormatted: undefined  // String, will be in terms of percentage for display
        },
        populateAdvisorInfo: function (responseEntity) {
            this.set('fmid', normalizedFMID(responseEntity.dstrId));
            this.set('formattedFmid', formattedFMID(responseEntity.dstrId));
            this.set('hasSellingAuthority', responseEntity.sellInd === "Yes" ? true : false);
            if (responseEntity.prefName) {
                this.set('firstName', responseEntity.prefName.firstNm);
                this.set('middleName', responseEntity.prefName.midNm);
                this.set('lastName', responseEntity.prefName.lastNm);
            }
            this.set('id', this.get('fmid'));
            this.populateFullName();

            return this;

            /* Sample:
                {  
                    "__metadata": {
                    "uri": "http://eforms.qa.advisorcompass.com/ods.svc/Distributor(dstrCtx='DMU.DIST',dstrId='000033712')",
                    "type": "com.ameriprise.awm.api.Distributor",
                    "version": "1.1"
                  },
                  "dfltFacePrflId": "31687",
                  "alwIndvWebPgInd": "True",
                  "dstrId": "000033712",
                  "dstrCtx": "DMU.DIST",
                  "profTtl": "Financial Advisor",
                  "franchiseTagLn": "A private wealth advisory practice of Ameriprise Financial Services, Inc.",
                  "franchiseNm": "Scioto Wealth Strategies",
                  "sellInd": "Yes",
                  "svcPrdNum": "1197",
                  "plfmCd": "02",
                  "chnlNm": "AFG",
                  "prfrFacePrflId": "29295",
                  "eTag": "29295",
                  "prefName": {
                    "nmTypCd": "PRF",
                    "nmTypDesc": "Preferred",
                    "firstNm": "FN3033712",
                    "midNm": " ",
                    "lastNm": "LN3033712",
                    "sfxTxt": " "
                  },
                  sellInd: "Yes"
                  ...
                }
             */
        },
        populateFromOboResponse: function (oboResponse) {
            var selectedAdvisorData= {
                "firstName": oboResponse.firstName,
                "middleName": oboResponse.middleName,
                "lastName": oboResponse.lastName,
                "userType": oboResponse.userType,
                "fmid": normalizedFMID(oboResponse.fmid),
                "formattedFmid": formattedFMID(oboResponse.fmid)
            };
            // userType possible values
            /*
             •         HO
             •         AFA
             •         ASSISTANT
             •         ADVISOR
             •         FSC
             */
            this.set(selectedAdvisorData);
            this.set('id', this.get('fmid'));
            this.populateFullName();
            return this;
        },
        populateFromDistributorResponseWithCompTeams: function (responseEntity) {
            var compTeam, compTeams = [];
            this.set('fmid', normalizedFMID(responseEntity.dstrId));
            this.set('formattedFmid', formattedFMID(responseEntity.dstrId));
            this.set('hasSellingAuthority', responseEntity.sellInd === "Yes" ? true : false);
            if (responseEntity.prefName) {
                this.set('firstName', responseEntity.prefName.firstNm);
                this.set('middleName', responseEntity.prefName.midNm);
                this.set('lastName', responseEntity.prefName.lastNm);
            }
            this.set('positionCode', responseEntity.position.pstnCd);
            if(responseEntity.dstrCompTeams && responseEntity.dstrCompTeams.results) {
                _.each(responseEntity.dstrCompTeams.results, function (compTeamResponse) {
                    compTeam = new CompTeam();
                    compTeams.push(compTeam.populateFromDistributorResponse(compTeamResponse));
                });
                this.set("compTeams", compTeams);
            }
            this.set('id', this.get('fmid'));
            this.populateFullName();

            return this;
        },
        populateFromCompTeamDetailsResponse: function (responseEntity) {
            this.set('fmid', normalizedFMID(responseEntity.dstrId));
            this.set('formattedFmid', formattedFMID(responseEntity.dstrId));
            this.set('compSharingPercent', responseEntity.compTeamMbrPct);
            this.set('compSharingPercentFormatted', responseEntity.compTeamMbrPct ? (responseEntity.compTeamMbrPct * 100) : "");
            if (responseEntity.compTeamDstrInfo && responseEntity.compTeamDstrInfo.prefName) {
                this.set('hasSellingAuthority', responseEntity.compTeamDstrInfo.sellInd === "Yes" ? true : false);
                this.set('firstName', responseEntity.compTeamDstrInfo.prefName.firstNm);
                this.set('middleName', responseEntity.compTeamDstrInfo.prefName.midNm);
                this.set('lastName', responseEntity.compTeamDstrInfo.prefName.lastNm);
            }
            this.set('id', this.get('fmid'));
            this.populateFullName();

            return this;
        },
        populateFullName: function () {
            this.set("fullName", $.trim((this.get("firstName") || "") + " " + (this.get("lastName") || "")));
        },
        description: function() {
            return this.get("firstName") == null ? this.get('fmid') : (this.get("firstName") + " " + this.get("lastName"));
        },
        isUser: function() {
            return this.get('fmid') == util.userFmid;
        },
        isCSRSelectedAdvisor: function() {
            return this.get('fmid') == util.csrSelectedFmid;
        },
        isAFA: function () {
            return this.get('positionCode') === Advisor.AFA_POSITION_CODE;
        }
    });

    Advisor.AFA_POSITION_CODE = "76";

    return Advisor;
});
