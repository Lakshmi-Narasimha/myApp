'use strict';
// Controller naming conventions should start with an uppercase letter

function buildmyPlanShowDtlsController($scope, $state, recommendedPlanInitialLoader, recommendedPlanModelService, buildPlanInitialLoader, buildPlanModelService, fundDetailsModel, transactModel, planSmartSolution, recommendedFundCardModelService, $uibModal,$window,appConfig,configUrlModel, sipCalculatorModel) {

    var planInputObj = {};
    $scope.init = function () {
        $scope.funds = fundDetailsModel.getFundDetails();
        $scope.allocationArr = buildPlanModelService.getAllocationDetails();
        var fundCardCodes = [];
        planInputObj = angular.copy(recommendedPlanModelService.getPlanInputDtls());
        planInputObj.investmentAmount = planSmartSolution.replaceComma(planInputObj.investmentAmount);
        //planInputObj.fundRecom = "O";
        planInputObj.myFunds = [];
        angular.forEach($scope.funds, function (fund, ind) {
            var fundList = {};
            fundList.fundCode = fund.fundOption;
            fundList.allocPer = $scope.allocationArr[ind];
            planInputObj.myFunds.push(fundList);
            fundCardCodes.push(fund.productCode);
        });
        getSmartSolutionDetails(planInputObj, "BP");
        fundCardModal(fundCardCodes.join(","));

    };

    $scope.init();

    function loadRecommendedPlan () {
        $scope.smartSolnDetials = angular.copy(planSmartSolution.getSmartSolutionDetails());
        $scope.recommendationDetails =
        {
            installmentDetails: [
                {text: 'Monthly', value: $scope.smartSolnDetials.monthlySIP},
                {text: 'Annually', value: $scope.smartSolnDetials.annualSIP},
                {text: 'One time', value: $scope.smartSolnDetials.lumpsum}],
            details: {
                "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                "investmentAmount": $scope.smartSolnDetials.investmentAmount
            }
        };
        //$scope.goalChartData = planSmartSolution.getInvestmentSimulation();
    }

    function loadInvestmentSimulation (calculatorReq) {

        /*var calculatorReq = [{
         "investmentTenure": $scope.smartSolnDetials.investmentTenure,
         "annualizedReturn": null,
         "investmentAmount": parseInt($scope.smartSolnDetials.monthlySIP.replace(",", "")),
         "fundName": "304",
         "frequency" : "Monthly",
         "calculatorType": "SIP",
         "trxnType": "SIP"
         }, {
         "investmentTenure": $scope.smartSolnDetials.investmentTenure,
         "annualizedReturn": null,
         "investmentAmount": parseInt($scope.smartSolnDetials.monthlySIP.replace(",", "")),
         "fundName": "387",
         "frequency" : "Monthly",
         "calculatorType": "SIP",
         "trxnType": "SIP"
         }];*/
        sipCalculatorModel.callSipCalculatorData({"calculatorReq": calculatorReq}, false, "PS").then(function (data) {
            var investMentSimulation = angular.copy(data.calculatorResp[0].returnData[0].periodicReturnData);
            $scope.goalChartData = {
                "data": [],
                "goalAmount": null
            };
            angular.forEach(investMentSimulation, function (value, key) {
                var chart = {};
                chart.years = value.duration;
                chart.amount = value.valueOfAmount;
                $scope.goalChartData.data.push(chart);
            });
            $scope.goalChartData.goalAmount = planInputObj.investmentAmount;
            planSmartSolution.setInvestmentSimulation($scope.goalChartData);
        }, function (data) {

        });
    };

    //$scope.recommendedPlanData = planSmartSolution.getSmartSolutionDetails();
    //if ($scope.recommendedPlanData) {
    //    $scope.recommendationDetails = planSmartSolution.getRecommendedDetails();
    //
    //}


    // setting data from build plan to the goal sheet

    $scope.fundSelectionArr = [];
    var dividend = [],
        fund = [];
    for (var i = 0; i < $scope.funds.length; i++) {
        if ($scope.funds[i].fundName) {
            $scope.fundSelectionArr[i] = $scope.funds[i].fundName;
            dividend[i] = $scope.funds[i].dividendFlag;
            fund[i] = $scope.funds[i];
        }

    }
    $scope.$on("investmentType", function ($event, data) {
        buildPlanModelService.setInvestmentType(data);
    });

    $scope.$on("investmentValue", function ($event, data) {
        $scope.radioSelectedData = buildPlanModelService.setInvestmentValue(data);
        $scope.fundDetails();
    });
    $scope.$on("editFundBackState", function ($event, data) {
        buildPlanModelService.isFromModify = true;
        $state.go("smartSol.planSmartSolution.ssBase.recommendations.buildplan");
    });

    var calculatorReq = [];
    $scope.fundDetails = function () {
        $scope.investmentType = buildPlanModelService.getInvestmentType();
        $scope.investmentValue = buildPlanModelService.getInvestmentValue();
        $scope.goalDetails = [];
        $scope.totalGoalDetails = {};
        $scope.instalMentDtls = {
            monthly: "",
            annually: "",
            oneTime: ""
        };

        if ($scope.investmentType == "Monthly" || $scope.investmentType == "Annually") {
            planSmartSolution.setTransactType("SIP");
        }
        else if ($scope.investmentType == "One time") {
            planSmartSolution.setTransactType("Lumpsum");
        }
        else {
            planSmartSolution.setTransactType("Combo");
        }


        $scope.totalAllocation = 0;
        $scope.totalMonthly = null;
        $scope.totalAnnually = null;
        $scope.totalOneTime = null;
        for (var i = 0; i < $scope.fundSelectionArr.length; i++) {

            if ($scope.investmentType == "Monthly") {
                $scope.instalMentDtls.monthly = Math.round((planSmartSolution.replaceComma($scope.investmentValue) * $scope.allocationArr[i])/100);
                $scope.totalMonthly += parseInt($scope.instalMentDtls.monthly);
            }

            calculatorReq.push({
                "investmentTenure": $scope.smartSolnDetials.investmentTenure,
                "annualizedReturn": null,
                "investmentAmount": $scope.instalMentDtls.monthly,
                "fundName": fund[i].fundOption,
                "frequency" : "Monthly",
                "calculatorType": "SIP",
                "trxnType": "SIP"
            });

            if ($scope.investmentType == "Annually") {
                $scope.instalMentDtls.annually = Math.round((planSmartSolution.replaceComma($scope.investmentValue) * $scope.allocationArr[i])/100);
                $scope.totalAnnually += parseInt($scope.instalMentDtls.annually);
            }
            if ($scope.investmentType == "One time") {
                $scope.instalMentDtls.oneTime = Math.round((planSmartSolution.replaceComma($scope.investmentValue) * $scope.allocationArr[i])/100);
                $scope.totalOneTime += parseInt($scope.instalMentDtls.oneTime);
            }

            $scope.goalDetails.push({
                "fundName": $scope.fundSelectionArr[i], 
                "allocation": $scope.allocationArr[i],
                "installmentDetails": angular.copy($scope.instalMentDtls),
                "dividendFlag": dividend[i],
                "fund" : fund[i],
                "nfoFlag" : fund[i].nfoFlag || '',
                "fundType": fund[i].fundType || '',
                "fundOption" : fund[i].fundOption || 'NA',
                "accNo" : fund[i].fundType == "N" ? "NEW" : 'NEW',
                "perpetualFlag" : 'N' || '',//fund[i].perpetualFlag
                "stepUpFrequency": fund[i].stepUpFrequency || '',
                "stepUpType" : fund[i].stepUpType || '',
                "stepUpValue" : fund[i].stepUpValue || '',
                "stepUpSip" : 0
            });

            $scope.totalAllocation += $scope.allocationArr[i];
        }
        loadInvestmentSimulation(calculatorReq);
        $scope.totalGoalDetails["allocation"] = $scope.totalAllocation;
        $scope.totalGoalDetails["monthly"] = $scope.totalMonthly;
        $scope.totalGoalDetails["annually"] = $scope.totalAnnually;
        $scope.totalGoalDetails["oneTime"] = $scope.totalOneTime;
    };

    $scope.goalsheetBtn = function () {
        buildPlanModelService.setGoalPlanData($scope.goalDetails);
        buildPlanModelService.setGoalTotalPlanData($scope.totalGoalDetails);
        $state.go('smartSol.planSmartSolution.ssBase.goalSheetSummary');
        buildPlanModelService.setGoalSummaryFromState($state.current.name);
    };

    $scope.customizeBtn = function () {
        $state.go('smartSol.planSmartSolution.ssBase.recommendations.buildplan.bcustomizeplan', {parentState: "smartsolutions.planSmartSolution.recommendations.buildplan.buildplanshowdtls"});
    };

    function getSmartSolutionDetails (planInputObj, source) {
        planSmartSolution.fetchPlanSmartSolutionDetails(planInputObj, source, true).then(function (data) {
            planSmartSolution.setSmartSolutionDetails(data);
            loadRecommendedPlan ();
        }, function (data) {
            console.log("Error")
        })
    };

    function fundCardModal(fundCode) {
        recommendedFundCardModelService.fetchRecommendedFundCard(fundCode).then(function (data) {
            $scope.fundCardDetails = data.fundDetails;
        }, function () {

        });
    };

    var modalInstance;
    $scope.$on('openFundCardModelPlan', function (event, fundCodes) {
        recommendedFundCardModelService.setFundCardId(fundCodes);
        // modalInstance = $uibModal.open({
        //     template: require('../../../../../../../../common/components/smartSolFundCardModelDetails/smartSolFundCardModel.html'),
        //     scope: $scope
        // });
        $window.open(
          appConfig[configUrlModel.getEnvUrl('MARKETING_URL')] + '/investor/funds-and-solutions/funds-explorer/fund-overview?FundID='+fundCodes,
          '_blank');
    });

}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
buildmyPlanShowDtlsController.$inject = ['$scope', '$state', 'recommendedPlanInitialLoader', 'recommendedPlanModelService', 'buildPlanInitialLoader', 'buildPlanModelService', 'fundDetailsModel', 'transactModel', 'planSmartSolution', 'recommendedFundCardModelService', '$uibModal','$window','appConfig','configUrlModel', 'sipCalculatorModel'];
module.exports = buildmyPlanShowDtlsController;