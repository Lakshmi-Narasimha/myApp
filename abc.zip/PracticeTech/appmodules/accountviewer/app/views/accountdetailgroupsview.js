define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailgroupsview.html'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetAccountGroups(this.accountSummary.accountId)
                .then(function(groupsData) {
                    var groups = _.sortBy(groupsData, 'id');
                    self.renderSection(SectionTemplateHtml, {groups: groups});
                })
                .fail(this.handleServiceError);
        }
    });

    return SectionView;
});