/**
*@ngdoc object
*@name common.module:services
*@description
* <p>
* In this we have the all global services like toasters, popups, exception handlers, 
* Cache factory configuaration and finally the loggers.
* </p> 
* @project FTIC 
* @Date
* @version 1
* @author DEE | Digital Engagement Practice @Cognizant.com
*/



'use strict';

// Services and Factories have their first letter capitalized like Controllers

module.exports = angular.module('common.services', [])
    .config(require('./exceptionService.js'))
    .run(require('./cacheFactory.js'))
    // .factory('apiConstants', require('./apiConstants.js')) // Contains all the apis
    .factory('userFactory', require('./user.js'))   // User Information
    // .factory('httpsCall', require('./httpsCall.js')) // Common for all modules to call the service
    .provider('fticLogger', require('./fticLogger.js')) // Common for all modules to log the errors, warnings
    .factory('popupSrvc', require('./popup/popup.service.js'))
    .controller('popupCtrl', require('./popup/popup.controller.js'))
    .factory('fticBroadcast', require('./fticBroadcast.service'))
    .factory('fticLoggerMessage', require('./fticLoggerMessage.service'))
    .factory('searchResultModel', require('./searchResultModel.service'))
    .factory('instantReportsDetailsInitialLoader', require('./instantReportsDetailsInitialLoader.service'))
    .factory('instantReportsDetailsModel', require('./instantReportsDetailsModel.service'))
    .factory('selectedInstantReportsModel', require('./selectedInstantReportsModel.service'))
    .factory('changeSecretQAModel', require('./changeSecretQAModel.service'))
    .factory('mailBackPostService', require('./mailBackPost.service'))
    .factory('downloadService', require('./downloadModel.service'))
    .factory('smartSolnFundDetailsModel',require('./smartsolfunddetails/newFundDetailsModel.service'))
    .factory('smartSolnFundDetailsInitialLoader',require('./smartsolfunddetails/newFundDetailsInitialLoader.service'))
    .factory('paperlessModel',require('./paperless/paperLessModel.service'))
    .factory('transactNowModel',require('./transactNow/transactNowModel.service'))
    .factory('advisorSearchModel',require('./advisorSearchModel.service'))
    .factory('fticMenuModel', require('./fticMenuModel.service'))
    .factory('globalMenuInitLoader', require('./fticMenuInitialLoader.service'))
    .factory('investorRegistrationModel', require('./investorRegistration.service'))
    .factory('fticRecommAndNotifiModel', require('./recommendationsAndNotificationsModel.service'))
    .factory('profileDetailsModel', require('./profileDetails.service'))
    .factory('$loader', require('./loader.service'))
    .factory('configUrlModel', require('./configUrlModel.service'))
    .factory('fticErrorMessage', require('./fticErrorMessage.service'))
    .factory('fticDateUtils', require('./dateUtils.service'))
    .factory('fticCommonUtils', require('./commonUtils.service'))
    .factory('planSmartSolution', require('./smartsolutions/planSmartSolutionModel.service'))
    .factory('recommendedFundCardModelService', require('./recommendedFundCardModel.service'))
    .factory('recommendedFundCardInitialLoader',require('./recommendedFundCardInitialLoader.service'))
    .factory('validateUserModel', require('./validateUserModel.service'))
    .factory('grantAccessRightsModel', require('./grantAccessRightsModel.service'))
    .factory('folioDetailsModel', require('./foliodetails/folioDetailsModel.service')) 
    .factory('folioDetailsInitialLoader', require('./foliodetails/folioDetailsInitialLoader.service')) 
    .factory('fticMailBackOption', require('./mailBackOption.service'))

;
