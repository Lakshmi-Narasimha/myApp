/**
 * @ngdoc service
 * @name user email ids service
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - 
 *
 */

'use strict';

var frequencyOptionsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _frequencyOptions = null,
        _amountFormType = null;
    var frequencyOptionsModel = {
        
        fetchFrequencyOptions : function (params) {

            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.TRANSACT_MODULE + ' | ' + loggerConstants.FREQUENCY_OPTIONS_MODEL + ' | fetchFrequencyOptions' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            
            var deferred = $q.defer();
            Restangular.one('services/paramCodes').get(params).then(function(response) {
                deferred.resolve(response);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        postFrequencyOptions : function (param) {

            var message =  loggerConstants.ADVISOR_APP + ' | ' + loggerConstants.REPORTS_MODULE + ' | ' + loggerConstants.FREQUENCY_OPTIONS_MODEL + ' | postFrequencyOptions' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            
            var deferred = $q.defer();
            Restangular.one('postFrequencyOptions').post("", param).then(function (frequencyOptions) {
                deferred.resolve(frequencyOptions);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        getFrequencyOptions: function() {
            return _frequencyOptions;
        },
        
        setFrequencyOptions: function(frequencyOptions) {
            var freqArr = [];
            for(var i in frequencyOptions){
                var obj = {};
                obj.category = frequencyOptions[i].code;
                obj.title = frequencyOptions[i].value;
                if(obj.category == 'M'){
                    obj.days = 30
                } else if(obj.category == 'D'){
                    obj.days = 1
                } else if(obj.category == 'W'){
                    obj.days = 7
                } else if(obj.category == 'Q'){
                    obj.days = 90
                } else if(obj.category == 'A'){
                    obj.days = 365
                };                
                freqArr.push(obj);
            }            
            _frequencyOptions = freqArr;
        },
        getAmountFormType : function () {
            return _amountFormType; 
        },
        setAmountFormType: function(amountType, formType) {
            var amountFormType = {};
            amountFormType.amountType = amountType;
            amountFormType.formType = formType;
            _amountFormType = amountFormType;
        }

    };
    return frequencyOptionsModel;
};

frequencyOptionsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];

module.exports = frequencyOptionsModel;