/**
 * @ngdoc property
 * @name fticNewEmandate Directive
 * @requires investorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Transaction Summary data in a ui-grid.
 *
 **/
'use strict';

var createnewEmandate = function(eMandateModel, investorEventConstants, fticLoggerMessage, loggerConstants, mytransactionsConstants, $timeout, $state, bankDtlsModel, invEformPaymentBanksUtility, TransactConstant, transactEventConstants, transactModel, toaster, eMandateIntialLoadService,authenticationService) {
    return {
        template: require('./newEmandate.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        link: function($scope) {

            var accordion = "",
                validateParams = {},
                params = {},
                custBankParams = {},
                txnType = "",
                bankOptions = null,
                folioOptions = null,
                isNewAct = false,
                isValidForm = false,
                payMethod = "",
                isEmpty = false,
                editIconChanged = false;
                $scope.showFolioError = false;
            init();
            initPayMethod();

            bankOptions = eMandateModel.getEMandateDetails();
            var folioOptions = eMandateModel.getFolioDetails();
            console.log('folioOptions folioOptions')
            console.log(folioOptions);
            angular.forEach(folioOptions, function(eachFoi){
                eachFoi.key = 'folioId';
                eachFoi.title = eachFoi.folioId;
            });
            $scope.folioOptions = folioOptions;
            //{title: bankOptions[i].pbBankName + '-' + bankOptions[i].pbPersonalAccountNumber, 
            //key : bankOptions[i].pbPersonalAccountNumber, refNo : bankOptions[i].achRefNo, bankName : bankOptions[i].pbBankName, webRefNo: bankOptions[i].emRefNo, folioId: bankOptions[i].folioId }
            $scope.folioOptions.unshift({key:'select', title: 'Select Folio'});
            $scope.folioOptionsFlag = $scope.folioOptions ? true : false;
            console.log(bankOptions);
            angular.forEach(bankOptions, function(eachEmandate){
                eachEmandate.pbPersonalAccountNumber = eachEmandate.bankAccno;
                eachEmandate.pbBankName = eachEmandate.bankName;
                eachEmandate.pbAccountType = eachEmandate.accountType;

                if(eachEmandate.pbAccountType && eachEmandate.pbAccountType === 'SA') {
                    eachEmandate.accTypeDesc = 'Savings Account';
                } else {
                    eachEmandate.accTypeDesc = 'Current Account';
                }
            });
            bankOptions.newEmandates = bankOptions;
            //bankOptions.getFolioDetails = getFolioDetails;
            setBankFilters(bankOptions.newEmandates);

            function setBankFilters(bankOptions) {
                if (bankOptions) {
                    //invEformPaymentBanksUtility.populateBanks('emandate', bankOptions.emandate, $scope.eMandateOptions); //E-Mandate Bank Options
                    //invEformPaymentBanksUtility.populateBanks('netBanking', bankOptions.netBanking, $scope.netBankOptions); //Net Banking Options
                    //invEformPaymentBanksUtility.populateBanks('debit', bankOptions.debit, $scope.debitBankOptions); //Debit Card Options
                    invEformPaymentBanksUtility.populateBanks('newEmandates', bankOptions.newEmandates, $scope.newMandateOptions); //New E-Mandate Options
                    //invEformPaymentBanksUtility.populateBanks('neftRtgs', bankOptions.neftRtgs, $scope.neftBankOptions); //NEFT / RTGS Options
                }
            }           

            $scope.$on('bankSelected', function(event, data) {
                console.log('bankChanged');
                $scope.$broadcast('bankChanged', data);
            });


            function init() {
                $scope.showContinue = true;
                $scope.method = {};
                $scope.method.eMandateSel = null;
                $scope.method.netBankSel = null;
                $scope.method.debitBankSel = null;
                $scope.method.newMandateSel = null;
                $scope.method.neftSel = null;
                $scope.mode = {};
                $scope.mode.selectedVal = null;
                $scope.methodRequired = true;
                $scope.showMandateDetails = false;
                $scope.showNewMandate = false;
                $scope.showPayeeDetails = false;
                $scope.showNewAccount = false;
                $scope.isNewAccount = false;
                $scope.isNewMandate = false;
                $scope.showMultiPayMode = false;
                $scope.showAutoDebit = false;
                $scope.showBankError = false;
                $scope.showNoBankError = false;
                $scope.continueButton = true;
                $scope.disableContinue = true;
                $scope.configDataLost = {};
                $scope.configDataLost.showNotification = false;
                $scope.eMandateOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.netBankOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.debitBankOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.newMandateOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.folioOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                $scope.neftBankOptions = [{ title: TransactConstant.transact.SELECT_BANK, key: 'select' }];
                disablePayOptsInit();

            }

            function initPayMethod() {
                $scope.showMandateDetails = false;
                $scope.showNewMandate = false;
                $scope.showPayeeDetails = false;
                $scope.showNewAccount = false;
                $scope.isNewMandate = false;
                $scope.isNewAccount = false;
                $scope.showMultiPayMode = false;
                $scope.showAutoDebit = false;
                $scope.showNoBankError = false;
                $scope.method.eMandateSel = $scope.eMandateOptions[0];
                $scope.method.netBankSel = $scope.netBankOptions[0];
                $scope.method.debitBankSel = $scope.debitBankOptions[0];
                $scope.method.newMandateSel = $scope.newMandateOptions[0];
                $scope.method.folioOptions = $scope.folioOptions[0];
                $scope.method.neftSel = $scope.neftBankOptions[0];
            }

            function disablePayOptsInit() {
                console.log('$scope.method');
                console.log($scope.method);
                $scope.newMandate = { disable: false, name: 'nMandate' };
                //$scope.existingMandate = { disable: true, name: 'eMandate' };
                //$scope.netBanking = { disable: true, name: 'netBank' };
                //$scope.debitCard = { disable: true, name: 'debit' };
                //$scope.newMandate = { disable: false, name: 'nMandate' };
                //$scope.neft = { disable: true, name: 'neftRtgs' };
            }

            $scope.$on(transactEventConstants.transact.EMANDATE_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if (bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.emandate;
                    if (bankDtls) {
                        // var selectedIdx = invEformPaymentBanksUtility.setPayment(bankDtls, data);
                        $scope.showMandateDetails = true;
                        bankDtlsModel.setEmandateDetails(bankDtls[selectedIdx]);
                    }
                } else if (data.key === 'select') {
                    $scope.showMandateDetails = false;
                }
            });

            $scope.cancelEmandate = function() {
                $state.go('emandate');
            }

            function goNextTab(){
                var payDetailsModel = {},
                    payDetails = invEformPaymentBanksUtility.getPayDetails($scope);
                bankDtlsModel.setPaymentDetails(payDetails);

                if(isNewAct) {
                    return;
                    //custBankParams = invEformPaymentBanksUtility.setCustBankParams(); // custormerBank service integration
                    //bankDtlsModel.postCustBankDtls(custBankParams).then(custBankSuccess, custBankFailure);
                }
                validateParams = invEformPaymentBanksUtility.setValidateParams('newEmandates'); // For /validateSIP and validateBuy services
                
                eMandateIntialLoadService.regEmandate({}, validateParams, false);
            }

            $scope.$on('bankSelected', function(event, data) {
                $scope.$broadcast('bankChanged', data);
            });

            $scope.$on('validateBuyForm', function(event, data){                
                $scope.paymentForm.$submitted = true;
                $scope.getSelections();
            });

            $scope.$on('validateSipForm', function(event, data){ //added for SIP
                $scope.paymentForm.$submitted = true;
                $scope.getSelections();
            });

            $scope.getSelections = function() {
                //$scope.$broadcast('continueClicked');
                bankDtlsModel.setPaymentMethod('Setup a new E-mandate');
                isValidForm = invEformPaymentBanksUtility.checkFormValidity($scope); //Check for form errors based on mandatory requirements
                isNewAct = bankDtlsModel.getIsNewAccount();
                if(isNewAct) {
                    return;
                }
                console.log(isNewAct);
                console.log($scope.paymentForm.$valid && isValidForm);
                if($scope.paymentForm.$valid && isValidForm) { 
                    $scope.showFolioError = false;                   
                    goNextTab();
                } else {
                    $scope.showFolioError = (bankDtlsModel.getSelectedfolioKey() === null || bankDtlsModel.getSelectedfolioKey() === 'select') ? true : false;
                }          
            } 


            $scope.$on(transactEventConstants.transact.NEWMANDATE_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo); 
                $scope.showNewAccount = false;
                $scope.isNewAccount = false;                
                $scope.isNewMandate = true;
                if(bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    if(data.key === 'newAccount') {
                        
                        $scope.isNewAccount = true;
                        bankDtlsModel.setIsNewAccount($scope.isNewAccount);
                        bankDtlsModel.setPaymentMode(TransactConstant.common.EMANDATE_CODE); //Set payment mode for Setup a new e-mandate - new account option

                        var params= {
                            "folioId" : bankDtlsModel.getSelectedfolioId() || '',// '16845442' transactModel.getInvestorDetails() ? transactModel.getInvestorDetails().folioId : "" || transactModel.getSelectedFolioDts() ? transactModel.getSelectedFolioDts().folioId : "",
                            "trxnType" : 'S',
                            "guId" : authenticationService.getUser().guId
                        };
                        if((bankDtlsModel.getSelectedfolioKey() === null || bankDtlsModel.getSelectedfolioKey() === 'select')){
                            $scope.showFolioError = true;
                        } else {
                             //Populate Banks
                            bankDtlsModel.fetchBankDetails(params).then(bankDtlsSuccess, bankDtlsFailure);
                        }
                        function bankDtlsSuccess(data) {
                            bankDtlsModel.setBankDetails(data);
                            $scope.showNewAccount = true;
                        }
                        function bankDtlsFailure(data) {
                            console.log('bankDtlsFailure');

                        }
                    } else if(data.key !== 'select') {
                        var bankDtls = bankOptions.newEmandates;
                        //invEformPaymentBanksUtility.setPayment(bankDtls, data);
                    }
                    
                    bankDtlsModel.setSelectedBank(data.bankName); 
                    bankDtlsModel.setPaymentBankAccNo(data.key);                   
                    $scope.$broadcast('bankChanged', data);
                }
            });

            $scope.$on('folioSelected', function(event, data){
                bankDtlsModel.setSelectedfoliotitle(data.title);
                bankDtlsModel.setSelectedfolioId(data.folioId); 
                bankDtlsModel.setSelectedfolioKey(data.key);              
                $scope.$broadcast('bankChanged', data);

            });

            $scope.$on(transactEventConstants.transact.NETBANK_CHANGED, function(event, data) {
                bankDtlsModel.setAchRefNo(data.refNo);
                if (bankOptions && (data.key !== 'select')) {
                    $scope.showBankError = false;
                    var bankDtls = bankOptions.netBanking;
                    // invEformPaymentBanksUtility.setPayment(bankDtls, data);
                }
            });


            function enableBankFilter(value) {
                var isEmpty = false;
                switch (value) {
                    case TransactConstant.transact.EXISTING_PAY_MANDATE:
                        if (bankOptions) {
                            isEmpty = isEmptyBankList(bankOptions.emandate);
                            if (!isEmpty) {
                                $scope.existingMandate.disable = false;

                            }
                        }
                        break;
                    case TransactConstant.transact.NET_BANKING:
                        if (bankOptions) {
                            isEmpty = isEmptyBankList(bankOptions.netBanking);
                            if (!isEmpty) {
                                $scope.netBanking.disable = false;

                            }
                        }
                        break;

                    case TransactConstant.transact.SETUP_NEW_MANDATE:
                        if (bankOptions) {
                            isEmpty = isEmptyBankList(bankOptions.newEmandates);
                            if (!isEmpty) {
                                $scope.newMandate.disable = false;

                                $scope.showNewMandate = true;
                            }
                        }
                        break;



                    case TransactConstant.transact.MULTIPLE_PAY_MODE:
                        isEmpty = false;
                        $scope.disableContinue = false; // Enable continue button
                        $scope.showMultiPayMode = true;
                        $scope.methodRequired = false;
                };
                if (isEmpty) {
                    $scope.showNoBankError = true;
                }
                bankDtlsModel.setIsNoBankError($scope.showNoBankError);
            }

            function isEmptyBankList(bankList) {
                var showNoBankError = false;
                if (bankList.length === 0) {
                    showNoBankError = true;
                }
                return showNoBankError;
            }

            $scope.payMethodChanged = function(value) {
                initPayMethod();
                disablePayOptsInit();
                bankDtlsModel.setIsNewAccount($scope.isNewAccount);
                bankDtlsModel.setPaymentMethod(value);
                //bankDtlsModel.setSelectedBank(null); //Clear any previous bank selections            
                enableBankFilter(value);


                if (TransactConstant.transact.SETUP_NEW_MANDATE !== value) {
                    bankDtlsModel.setIsNewAccBankError(false);
                }
                if (TransactConstant.transact.EXISTING_PAY_MANDATE !== value) {
                    bankDtlsModel.setIsExhausted(false);
                }
                bankDtlsModel.setIsMultiPayMode($scope.showMultiPayMode);
            };

        }
    };
};


createnewEmandate.$inject = ['eMandateModel', 'investorEventConstants', 'fticLoggerMessage', 'loggerConstants', 'mytransactionsConstants', '$timeout', '$state', 'bankDtlsModel', 'invEformPaymentBanksUtility', 'TransactConstant', 'transactEventConstants', 'transactModel', 'toaster', 'eMandateIntialLoadService','authenticationService'];
module.exports = createnewEmandate;
