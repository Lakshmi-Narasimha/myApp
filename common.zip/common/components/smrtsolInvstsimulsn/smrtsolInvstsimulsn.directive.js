'use strict';

var smrtsolInvSimulation = function (planSmartSolution, $filter) {
    return {
        template: require('./smrtsolInvstsimulsn.html'),
        restrict: 'E',
        replace: true,
        scope: {
            goalChart: "=",
            title: "=?",
            simulationText: '@?'

        },
        controller: ['$scope', function ($scope) {
            $scope.categories = [];
            $scope.simulation = $scope.simulationText === 'false' ? false : true;
            $scope.categoriesValues = [];

            var goalAmountLine = [];
            $scope.categoriesValues.investedAmount = [];
            for (var i = 0; i < $scope.goalChart.data.length; i++) {
                $scope.categories.push($scope.goalChart.data[i].years);
                if ($scope.goalChart.data[i].amount !== "NA") {
                    goalAmountLine.push(planSmartSolution.replaceComma($scope.goalChart.goalAmount));
                    $scope.categoriesValues.push(parseInt($scope.goalChart.data[i].amount.replace(/,/g, "")));
                    if($scope.goalChart.data[i].investment) {
                        $scope.categoriesValues.investedAmount.push($scope.goalChart.data[i].investment);
                    }
<<<<<<< HEAD
                    else {
                        $scope.categoriesValues.push(null);
                    }
                };
                $scope.goalAmount = $scope.goalChart.goalAmount;
                $scope.smrtSolChartSeriesConfig = {
                        chart: {
                            type: 'line',
                            width: 382,
                            height: 230
                        },
                        title: {
                            useHTML:true,
                            text: "<div class='mb+'>Your Goal<span class='text-red'>*</span> <i class='icon-fti_rupee'></i> "+$filter('currency')(planSmartSolution.replaceComma($scope.goalAmount), '', 0) + '</div>'
                            
                        },
                        subtitle: {
                            text: ''
                        },
                        xAxis: {
                           categories: $scope.categories,
                            tickmarkPlacement: 'on',
                            title: {
                                text: 'Time',
                                align: 'low',
                                offset: 0,
                                x: -30,
                                y: 12
                            },
                            labels: {
                                rotation: 0,
                                y: 25,
                                align: 'center',
                                step: 1,
                                formatter: function () {
                                    return this.value.replace(/ /g, '<br />');
                                },
                                useHTML:true,
                                style: {
                                    fontSize: '12px',
                                    textTransform: "camelcase"
                                }
                            }/*,
                            plotLines: [{
                                color: '#C0D0E0',
                                width: 1,
                                // value: Date.UTC(profileDetailsDate.getFullYear(),profileDetailsDate.getMonth(),profileDetailsDate.getDate()),
                                value: 3,
                                zIndex: 999
                            }]*/
                        },
                        yAxis: [{
                            lineWidth: 1,
                            title: {
                                text: "<span class='custom-bold'><i class='icon-fti_rupee'></i></span>",
                                align: 'high',
                                rotation: 0,
                                x : 25,
                                y : -15

                            },
                            labels: {
                                useHTML: true,
                                style: {
                                    color: "#96be8a"
                                }
                            }
                        }
                        ],
                        tooltip: {
                        // shared: true,
                        // crosshairs: true
                        useHTML: true,
                        formatter: function () {
                            var value;
                            for (var i = 0; i < this.series.userOptions.data.length; i++) {
                                if (this.y == this.series.userOptions.data[i]) {
                                    value = i;
                                    break;
                                }
                            }
                            if(this.series.userOptions.color == '#96be8a') {
                                return '<b> ' + this.x + ' since investment </b></br>' + 'Invested amount   :  <span class="icon-fti_rupee"></span>' + planSmartSolution.replaceComma($scope.goalChart.goalAmount) + ' </br> Value of Investment : <span class="icon-fti_rupee"></span>' + this.y;
                            } else {
                                return 'Goal amount   :  <span class="icon-fti_rupee">' + planSmartSolution.replaceComma($scope.goalChart.goalAmount);
                            }
=======
                }
                else {
                    $scope.categoriesValues.push(null);
                }
            }
            ;
            console.log($scope.categoriesValues);
            $scope.goalAmount = $scope.goalChart.goalAmount;
            $scope.smrtSolChartSeriesConfig = {
                chart: {
                    type: 'line',
                    height: 230
                },
                title: {
                    useHTML: true,
                    text: "<div class='mb+'>Your Goal<span class='text-red'>*</span> <i class='icon-fti_rupee'></i> " + $filter('currency')(planSmartSolution.replaceComma($scope.goalAmount), '', 0) + '</div>'
                },
                subtitle: {
                    text: ''
                },
                xAxis: {
                    categories: $scope.categories,
                    tickmarkPlacement: 'on',
                    title: {
                        text: 'Time',
                        align: 'low',
                        offset: 0,
                        x: -30,
                        y: 12
                    },
                    labels: {
                        rotation: 0,
                        y: 25,
                        align: 'center',
                        step: 1,
                        formatter: function () {
                            return this.value.replace(/ /g, '<br />');
                        },
                        useHTML: true,
                        style: {
                            fontSize: '12px',
                            textTransform: "camelcase"
>>>>>>> ftic-inv-sprint6
                        }
                    }/*,
                     plotLines: [{
                     color: '#C0D0E0',
                     width: 1,
                     // value: Date.UTC(profileDetailsDate.getFullYear(),profileDetailsDate.getMonth(),profileDetailsDate.getDate()),
                     value: 3,
                     zIndex: 999
                     }]*/
                },
                yAxis: [{
                    title: {
                        text: "<span class='custom-bold'><i class='icon-fti_rupee'></i></span>",
                        align: 'high',
                        rotation: 0,
                        x: 25,
                        y: -15

                    },
                    labels: {
                        useHTML: true,
                        style: {
                            color: "#96be8a"
                        }
                    }
                }
                ],
                tooltip: {
                    // shared: true,
                    // crosshairs: true
                    useHTML: true,
                    formatter: function () {
                        var value;
                        for (var i = 0; i < this.series.userOptions.data.length; i++) {
                            if (this.y == this.series.userOptions.data[i]) {
                                value = i;
                                break;
                            }
                        }
                        if (this.series.userOptions.color == '#96be8a') {
                            return '<b> ' + this.x + ' since investment </b></br>' + 'Invested amount   :  <span class="icon-fti_rupee">' + this.series.userOptions.data.investedAmount[value] + ' </br> Value of Investments : <span class="icon-fti_rupee">' + this.y;
                        } else {
                            return 'Goal amount   :  <span class="icon-fti_rupee">' + planSmartSolution.replaceComma($scope.goalChart.goalAmount);
                        }
                    }
                },
                plotOptions: {
                    area: {
                        stacking: 'normal',
                        lineWidth: 1,
                        fillColor: "#FFF",
                        marker: {
                            symbol: 'circle',
                            lineWidth: 0.5
                        }
                    }
                },
                series: [{
                    showInLegend: false,
                    data: $scope.categoriesValues,
                    color: "#96be8a"


                }, {
                    showInLegend: false,
                    data: goalAmountLine
                }],
                credits: {
                    enabled: false
                }
            };

        }]
    }
};

smrtsolInvSimulation.$inject = ['planSmartSolution', '$filter'];
module.exports = smrtsolInvSimulation;