'use strict';

module.exports = angular.module('common.elements.ftiHeader', [])
	.constant('headerConstants', require('./headerConstants'))
    .directive('fticHeader', require('./header.directive'))
    .controller('headerCtrl', require('./header.controller'))
    .directive('fticHeaderSearch', require('./headerSearch.directive'));