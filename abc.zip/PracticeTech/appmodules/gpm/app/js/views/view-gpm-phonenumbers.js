﻿define(['jquery', 'underscore', 'backbone', 'spinner', 'appcommon/globalcontext', 'appcommon/analytics', 'appmodules/gpm/app/js/lib/validate.js', 'appmodules/gpm/app/js/utils', 'moment', 'appcommon/data','appmodules/contactprofile/app/models/cpviewmodel', 'appmodules/gpm/app/js/views/view-gpm-phonenumbers',
		'text!appmodules/gpm/app/templates/gpmphonenumbers.html','text!appmodules/gpm/app/templates/gpmphonenumedittemplate.html','services/dataservice','appmodules/nav/app/models/editcontact','appcommon/commonutility','config','errorLog'], function ($, _, Backbone, Spinner, GlobalContext, Analytics, Validator, Utils, Moment,PTCommonData, CPViewModel, PhoneNumbersView, PhoneNumberTemplate,PhoneNumEditTemlate,DataService,CMEditContactModel,CommonUtils,Config,ErrorLog) {
	var ColaPhoneNumModel = Backbone.Model.extend({
		defaults : {
				NANPAreaCd: null,
				NANPExchCd: null,
				NANPSbscNbr:null,
				SMSEnrlStatCd: null,
				clTeleId: null,
				nonNANPPhnNbr:null,
				phnCtryCd: null,
				phnExtnNbr: null,
				phnLblTxt: null,
				phnPrfrCd:null,
				phnSubLblTxt:null,
				prefCode: "02",
				preferredPhone: false,
				textEnabled: false,
				phoneTypeCd:null,
				phnRemarks: "",
				onlyInCola: null
		}
	});	 
	var EbixPhoneNumModel = Backbone.Model.extend({
		defaults : {
				AreaCode: null,
				BadPhoneNumber: null,
				CountryCode: null,
				ElectronicDownload: null,
				Extension: "",
				FullPhoneNumber: null,
				Id: null,
				Number: null,
				PhoneType: null,
				PhoneTypeDesc: null,
				Preferred: "0",
				type: null,
				phoneTypeCd:null,
				phnRemarks: "",
				onlyInCola: null
		}
	});	 
	var newPhoneNumCount = 0,self = null;
	var _PhoneNumbersView = Backbone.View.extend({
		        el: $("#gpm-form-update-field-container"),
		        id: 'gpm-form-update-field-container',
		        events: {
		            /*"keypress .number-validate": "numValidator",
		            "keypress .countrycode-validate": "countryCodeValidator",
		            "keyup .jump": "autoJumpToFields",
		            "keypress #section-phone-numbers .number": "isNumber",
		            "click input[type='tel']": "highlightTheField"*/
		        },
		        initialize: function () {
		            this.data = {};
		            self = this;
		            newPhoneNumCount = 0;
		           
		        },
		        template: _.template(PhoneNumberTemplate), 
		        //template: _.template(DummyTemplate),
		        render: function (updateMode) {
		            var self = this;
		            try {
		                var _compiledTemplate = this.template({ data: this.model });
		                    $("#" + this.id).html(_compiledTemplate);
		                if (!this.model.get('currentItemSet')) {
		                    var CPData = CPViewModel.getInstance().getData();
		                    this.data = this.getGPMPhoneData(CPData);
		                    this.model.setCurrentValue(updateMode, { data: this.data });
		                    this.model.set('newPhoneNumCount',0);
		                }
		                var _compiledTemplate = this.template({ data: this.model });
		                $("#" + this.id).html(_compiledTemplate).promise().done(function () {
		                });
		            }
		            catch (error) {
		                console.log(error);
		                ErrorLog.ErrorUtils.myError(error);
		            }
		            this.bindEvents();
		        },
		        bindEvents:function(){
		        	var _self = this;
	        	 	$(document).off('keypress', '.number-validate').on('keypress', '.number-validate', self.numValidator);
		            $(document).off('keypress', '.countrycode-validate').on('keypress', '.countrycode-validate', self.countryCodeValidator);
		            $(document).off('keyup', '.jump').on('keyup', '.jump', self.autoJumpToFields);
		            $(document).off('keypress', '#section-phone-numbers .number').on('keypress', '#section-phone-numbers .number', self.isNumber);
		            $(document).off('click', 'input[type="tel"]').on('click', 'input[type="tel"]', self.highlightTheField);
		        	$(document).off("click", "#gpm-form-update-field-container .phone-num-edit-btn").on("click","#gpm-form-update-field-container .phone-num-edit-btn",_self.phoneNumEidtBtnHandler);
		        	$(document).off("click", "#add-another-ph").on("click", "#add-another-ph", _self.phoneNumAddBtnhandler);
		        	$(document).off("click", "#section-phone-numbers .gpm-ph-cancel-lbl").on("click", "#section-phone-numbers .gpm-ph-cancel-lbl", _self.cancelAddEditPhoneBtnHandler);
		        	$(document).off("change", "#section-phone-numbers .gpm-ph-intl-chkbox input[type=checkbox]").on("change", "#section-phone-numbers .gpm-ph-intl-chkbox input[type=checkbox]", _self.intlNumCheck);
		        	$(document).off("change", "#section-phone-numbers .gpm-preferred-chkbox-container input[type=checkbox]").on("change", "#section-phone-numbers .gpm-preferred-chkbox-container input[type=checkbox]", _self.preferredCheck);
		        	$(document).off("click", "#gpm-form-update-field-container .phone-num-delete-btn").on("click","#gpm-form-update-field-container .phone-num-delete-btn",_self.deleteButtonHandler);
		        },
		        deleteButtonHandler: function (e) {
		            $('#section-phone-numbers').removeClass('error');
		            $("#samefield-err").addClass('hidden');
		            $("#preferred-err").addClass('hidden');
		            var CPData = CPViewModel.getInstance().getData();
		            var _ebixData = {}, _isNotInCM = false;
		            if (CPData.ebix) {
		                _ebixData = CPData.ebix.PersonContact.attributes;
		            } else {
		                _isNotInCM = true;
		            }
		            if ((self.getColaPhonetypeCount() <= 5) && _isNotInCM === true) {
		                $("#add-another-ph-cntr").removeClass('hidden');
		            }
		        	var _$el = $(e.currentTarget);
		        	if(self.isColaType(_$el.data('phone-type')) && self.getColaPhonetypeCount() == 1 && _$el.data('source') =="COLA"){
		        		self.showMinimumOneColaTypeRequiredError();
		        		return;
		        	}
		        	var _target = e.target || e.currentTarget,_model =self.model;
		        	var _$el = $(_target);
		        	
			    	var _itemIdentifier = _$el.data('identifier');
			    	$(document.getElementById('phn-num-view-section-'+_itemIdentifier.replace(/\./g, "-"))).parent().remove()
			    	_item = _model.get('items').find(function(row){return row.get("itemType") == _itemIdentifier});
			    	_item.get('customValues').changed = true;
			    	_item.get('customValues').deleted = true;
			    	Analytics.analytics.recordAction('gpmPhoneNumberUpdateDelete:clicked');
			    
		        },
		        showMinimumOneColaTypeRequiredError:function(){
		        	var _htmlString = "<div class='pt-para-medium'>The client must have one phone number with any one of the following phone types:</div>";
		        	_htmlString += "<div><ul class='pt-para-medium have-list-style'>" +
		        			"<li>Home</li>" +
		        			"<li>Business</li>" +
		        			"<li>Mobile</li>" +
		        			"<li>Other 1</li>" +
		        			"<li>Other 2</li>" +
		        			"</ul></div>";
		        	BootstrapDialog.alert(_htmlString,"Phone required");
		        },
		        getColaPhonetypeCount:function(){
		        	var _nonEditModeColaNumbers = $('.cola-phn-type-label:visible').length,_totalColaNumbers =0,_editModeColaPhoneTypes = [];
		        	$('.phTypeDropDwn option:selected').each(function(){_editModeColaPhoneTypes.push($(this).text())});
		        	$.each(_editModeColaPhoneTypes,function(i,phoneType){
		        		if(self.isColaType(phoneType)){
		        			_totalColaNumbers++;
		        		}
		        	});
		        	_totalColaNumbers= _totalColaNumbers + _nonEditModeColaNumbers;
		        	return _totalColaNumbers;
		        	
		        },
	            // Check Preferred check box, toggle css class to display preferred icon based on selection
		        preferredCheck: function (e) {
		            var _$currTgt = $(e.currentTarget);
		            var _teleid = _$currTgt.data('identifier');
		            var _currSec = $(document.getElementById('phn-num-edit-section-'+_teleid.replace(/\./g, "-")));

		            if (_$currTgt.prop('checked')) {
                        $(document.getElementById('gpm-preferred-lbl-'+_teleid.replace(/\./g, "-"))).addClass("nav-preferred").removeClass("nav-preferred-gray");
		            } else { $(document.getElementById('gpm-preferred-lbl-'+_teleid.replace(/\./g, "-"))).addClass("nav-preferred-gray").removeClass("nav-preferred"); }
		        },
	            // for International phone no in edit contact profile
		        intlNumCheck: function (e) {
		            var _$currTgt = $(e.currentTarget);
		            var _teleid = _$currTgt.data('identifier');
		            var _fmtdTeleId =  _teleid.replace(/\./g, "-");
		            if (_$currTgt.prop('checked')) {
		                $(document.getElementById('gpm-home-intl-'+_fmtdTeleId)).removeClass('hidden');
		                $(document.getElementById('gpm-home-normal-'+_fmtdTeleId)).addClass('hidden');
		            } else {
		                $(document.getElementById('gpm-home-intl-'+_fmtdTeleId)).addClass('hidden');
		            	$(document.getElementById('gpm-home-normal-'+_fmtdTeleId)).removeClass('hidden');
		            }
		            $(document.getElementById('gpm-homephone-inputs-'+_fmtdTeleId)).find('input[type=tel]').val("");
		        },
	            //Function to handle country code  like +1,+91,etc
		        countryCodeValidator: function (obj) {
		            var _currTgt = $(obj.currentTarget);
		            var _maxLen = _currTgt.attr('maxlength');
		            var _regxNumOnly = /^[+]{0,1}?\d*$/;
		            var _str = _currTgt.val() + String.fromCharCode(event.keyCode);
		            var _keyCharacter = String.fromCharCode(event.keyCode);
		            if (_str.indexOf('+') == -1) {
		                _maxLen = _maxLen - 1;
		            }		            
		            if (!(_currTgt[0].selectionStart != _currTgt[0].selectionEnd && _regxNumOnly.test(_keyCharacter)) && (!_regxNumOnly.test(_str) || (_currTgt[0].selectionStart == _currTgt[0].selectionEnd && _currTgt.val().length >= _maxLen))) {
		                obj.stopPropagation();
		                if (event.preventDefault)
		                    event.preventDefault();		                
		                return false;
		            }
		        },
		        numValidator : function(obj) {
		            var _currTgt = $(obj.currentTarget);
		            var _maxLen = _currTgt.attr('maxlength');
		            var _regxNumOnly = /^\d*$/;
		            var _str = String.fromCharCode(event.keyCode);
		            if (!_regxNumOnly.test(_str)
                            || (_currTgt[0].selectionStart == _currTgt[0].selectionEnd && _currTgt.val().length >= _maxLen)) {
		                obj.stopPropagation();
		                if (event.preventDefault)
		                    event.preventDefault();
		                return false;
		            }
		        },
		        isNumber: function (evt) {
		            evt = (evt) ? evt : window.event;
		            var charCode = (evt.which) ? evt.which : evt.keyCode;
		            if (isNaN(String.fromCharCode(charCode))) {
		                return false;
		            }
		            return true;
		        },
		        autoJumpToFields: function (e) {
		            //block the jump if it is a tab or shift+tab
		            e.which = e.which || e.keyCode;
		            if(e.which == 9 || e.which == 16){
		                return;
		            }
		            var _target = e.currentTarget || e.target;
		            var _el = $(_target);
		            var _maxLength = _el.attr("maxlength");
		            var _nxtFld = _el.data("jumpto");
		            if (_el.val() && _el.val().length == _maxLength) {
		                $(document.getElementById(_nxtFld)).focus();
		            }
		        },
		        highlightTheField : function (e) {
		            var _target = e.currentTarget || e.target;
		            $(_target).select();
		            try {
		                _target.setSelectionRange(0,99);
		            } catch (error) {
		                ErrorLog.ErrorUtils.myError(error);
		            }
		        },
		        cancelAddEditPhoneBtnHandler: function (event) {
		            $('#section-phone-numbers').removeClass('error');
		            $("#samefield-err").addClass('hidden');
		            $("#preferred-err").addClass('hidden');
		            var CPData = CPViewModel.getInstance().getData();
		            var _ebixData = {}, _isNotInCM = false;
		            if (CPData.ebix) {
		                _ebixData = CPData.ebix.PersonContact.attributes;
		            } else {
		                _isNotInCM = true;
		            }
		            if ((self.getColaPhonetypeCount() == 5) && _isNotInCM === true) {
		                $("#add-another-ph-cntr").addClass('hidden');
		            }
		            if (((self.getColaPhonetypeCount() < 5) && _isNotInCM === true)) {
		                $("#add-another-ph-cntr").removeClass('hidden');
		            }
		            if ((self.getColaPhonetypeCount() > 5) && _isNotInCM === true) {
		                $("#add-another-ph-cntr").addClass('hidden');
		            }
		            var textLblCnt = ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden')").length);
		            var dropDownTextCnt = ($('.gpm-ph-edit-mode').length);
		            /*if(textLblCnt == 0 && dropDownTextCnt == 1) {
		            	self.showMinimumOneColaTypeRequiredError();
		            } else {*/
		            var _$el  = $(event.currentTarget),_items = self.model.get('items'),_currItemIndex=null;
		        	var _teleId = _$el.data('identifier');
		        	var _currtModel = _items.find(function(row,index){if(row.get("itemType") == _teleId){_currItemIndex = index;return true;}});
		        	 if(_$el.data('launch-mode') == "edit"){
		        		 _$el.parents('.phn-num-edit-section');
		        		 _$el.parents('.phn-num-edit-section').addClass("hidden").html("");
		        		 $(document.getElementById("phn-num-view-section-"+_teleId.replace(/\./g, "-"))).removeClass("hidden");
		        		 var _currItemVal = _currtModel.get('currentItemValue').toJSON();
		        		 if(_currtModel.get('customValues').dataSource == "EBIX"){
		        			 _currItemVal =  new ColaPhoneNumModel(_currItemVal);
		        		 }else{
		        			 _currItemVal =  new EbixPhoneNumModel(_currItemVal);
		        		 }
		        		 _currtModel.set('changedItemValue',_currItemVal);
		        		 _currtModel.set('changedItemValueId',_currItemVal);
		        		 _currtModel.get('customValues').changed = false;
		        	 }else{
		        		 if(_currItemIndex !=null  && _currItemIndex != undefined){
		        			 _items.splice(_currItemIndex,1);
		        		 }
		        		 $(document.getElementById("phn-add-edit-template-" + _teleId.replace(/\./g, "-"))).remove();
		        		 if ((self.getColaPhonetypeCount() == 4) && _isNotInCM === true) {
		        		     $("#add-another-ph-cntr").removeClass('hidden');
		        		 }
		        	 }
		        	 Analytics.analytics.recordAction('gpmPhoneNumberUpdateCancel:clicked');
		            //}		        	
		        },
		        phoneNumEidtBtnHandler:function(event){
		        	var _modelPhnNums = self.model.get('items'), _$el  = $(event.currentTarget);
		        	var _phNum = _modelPhnNums.find(function(row){return row.get("itemType") == _$el.data('identifier')});
		        	var _options = {
			        		teleId :_phNum.get("itemType"),
			        		elId:_phNum.get("itemType").replace(/\./g, "-"),
			        		edit:true,
			        		value:_phNum.get('changedItemValue'),
			        		customValues:_phNum.get('customValues')
			        	}
		        	var _$editCtnr = $(document.getElementById('phn-num-edit-section-'+_phNum.get("itemType").replace(/\./g, "-")));
		        	_$editCtnr.html();
		        	self.renderPhoneAddEditModeTemplate(_options,_$editCtnr);
		        	_$editCtnr.removeClass("hidden");
		        	_$editCtnr.parent().find('.phone-num-view-section').addClass("hidden");
		        	Analytics.analytics.recordAction('gpmPhoneNumberUpdateEdit:clicked');
		        	var dropdnId="" , textToFind="" ,dropDownId ="";
		        	dropdnId = "phTypeDropDwnId-"+_$el.attr('data-identifier').replace(/\./g, '-');
		        	textToFind = _phNum.get("itemLabel");
				    dropDownId = document.getElementById(dropdnId);
				    for (var i = 0; i < dropDownId.options.length; i++) {
				        if (dropDownId.options[i].text === textToFind) {
				            dropDownId.selectedIndex = i;
				            break;
				        }
				    }
		        },
		        phoneNumAddBtnhandler: function () {
		            $('#section-phone-numbers').removeClass('error');
		            $("#samefield-err").addClass('hidden');
		            $("#preferred-err").addClass('hidden');
		            var CPData = CPViewModel.getInstance().getData();
		            var _ebixData = {}, _isNotInCM = false;
		            if (CPData.ebix) {
		                _ebixData = CPData.ebix.PersonContact.attributes;
		            } else {
		                _isNotInCM = true;
		            }
		            if ((self.getColaPhonetypeCount() < 5) && _isNotInCM === true) {
		                $("#add-another-ph-cntr").removeClass('hidden');
		            }
		            if (((self.getColaPhonetypeCount() == 4) && _isNotInCM === true) || ((self.getColaPhonetypeCount() >= 5) && _isNotInCM === true)) {
		                $("#add-another-ph-cntr").addClass('hidden');
		            }
		        	newPhoneNumCount++;
		        	self.model.set('newPhoneNumCount',newPhoneNumCount);
		        	var _options = {
		        		teleId :'new-phone-id-'+newPhoneNumCount,
		        		elId:'new-phone-id-'+newPhoneNumCount,
		        		edit:false,
		        		value:null,
		        		customValues:{
		        			dataSource:"BOTH",
		        			viewDispaly:true
		        		}
		        	}
		        	Analytics.analytics.recordAction('gpmPhoneNumberUpdateAdd:clicked');
		        	self.renderPhoneAddEditModeTemplate(_options,$('#phone-edit-field-section-ctnr'));
		        },
		        launchPhoneAddEditMode:function(options){},
		        renderPhoneAddEditModeTemplate: function (data, $container) {
		            var CPData = CPViewModel.getInstance().getData();
		            var _ebixData = {}, _isNotInCM = false;
		            if (CPData.ebix) {
		                _ebixData = CPData.ebix.PersonContact.attributes;
		            } else {
		                _isNotInCM = true;
		            }
		            var _underScoreTmplt = _.template(PhoneNumEditTemlate);
		            if (data.value != null) {
		                var isIntrNatnl = false;
		                if (data.value.attributes.phnCtryCd != null && !data.value.attributes.phnCtryCd !== "" &&
                            !data.value.attributes.phnCtryCd !== "+1" && !data.value.attributes.phnCtryCd !== "1") {
		                    isIntrNatnl = true;
		                }
		                if (!isIntrNatnl) {
		                    data.value.attributes.FullPhoneNumber = data.value.attributes.FullPhoneNumber.replace(/[^a-z0-9]/gi, "");
		                    data.value.attributes.Number = data.value.attributes.Number.replace(/[^a-z0-9]/gi, "");
		                    if (data.value.attributes.AreaCode == null || data.value.attributes.AreaCode === "") {
		                        if (data.value.attributes.FullPhoneNumber.length > 7) {
		                            var size = data.value.attributes.FullPhoneNumber.length;
		                            var overflow = size - 7;
		                            data.value.attributes.AreaCode = data.value.attributes.FullPhoneNumber.substr(0, overflow);
		                            data.value.attributes.FullPhoneNumber = data.value.attributes.FullPhoneNumber.substr(overflow);
		                        }
		                    }
		                }
		            }
		        	var _compiledTemplate = _underScoreTmplt(data);
		        	$container.append(_compiledTemplate);
		        	var _selectedValue = "";
		        	if(data.edit){
		        		 _selectedValue = data.value.get('phoneTypeCd');
		        	}
		        	if (_isNotInCM == true) {
		        	    var _options = {
		        	        selectBox: document.getElementById('phTypeDropDwnId-' + data.teleId.replace(/\./g, "-")),
		        	        optionsList: PTCommonData.colaPhoneType,
		        	        selectedVal: _selectedValue,
		        	    }
		        	} else {
		        	    var _options = {
		        	        selectBox: document.getElementById('phTypeDropDwnId-' + data.teleId.replace(/\./g, "-")),
		        	        optionsList: PTCommonData.phoneType,
		        	        selectedVal: _selectedValue,
		        	    }
		        	}
		        	self.loadPhoneType(_options);
		        },
		        loadPhoneType:function(params){
		                var _options = {
								selectBox : params.selectBox,
								optionsList : params.optionsList,
								selectedVal : params.selectedVal,
								noEmptyOption : false,
								isOptional : false,
								noneOption:{}
		                }
		                Utils.loadSelectbox(_options);
		        },
		        validateAndNavigateFromStep1: function () {
		        	var CPData = CPViewModel.getInstance().getData();
		            var _ebixData = {}, _isNotInCM = false, lblType = [], duplicValue = "" , ddType =[], ddDuplicateType = false;
		            if (CPData.ebix) { _ebixData = CPData.ebix.PersonContact.attributes; } else { _isNotInCM = true; }
		            if (_isNotInCM == true) {
		            	var textLblCnt = ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden')").length);
		                var dropDownTextCnt = ($('.gpm-ph-edit-mode').length);
		                	if (textLblCnt > 0 && dropDownTextCnt > 0) {
			                	for (var i = 0, j = textLblCnt; i < j; i++) {
			                        if (typeof ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text()) !== 'undefined') {
			                            var txt = $("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text();
			                            lblType.push(txt);
			                        }
			                    }
			                    for (var l = 0, m = dropDownTextCnt; l < m; l++) {
			                        var ddTxt = "";
			                        ddTxt = ($(".gpm-ph-edit-mode select:eq(" + l + ") option:selected").text());
			                        ddType.push(ddTxt);
			                        if ($.inArray(ddTxt, lblType) > -1) {
			                            if (duplicValue !== "") {
			                                duplicValue = duplicValue + " , " + ddTxt;
			                            } else {
			                                duplicValue = ddTxt;			                                
			                            }
			                        }
			                    }
			                    if (duplicValue !== "") {
			                    	$('#section-phone-numbers').addClass('error');
			                        $("#samefield-err").removeClass('hidden');
			                        return;
			                        this.model.setChangedValue();
			                        this.formatPayloadAndCallService();
			                    } else {
			                    	var sorted_arr = ddType.sort();   
							        var results = [];  
							        for (var i = 0; i < ddType.length - 1; i++) {  
							            if (sorted_arr[i + 1] == sorted_arr[i]) {  
							                ddDuplicateType = true;
							            }  
							        }
							        if (ddDuplicateType == true) {
							        	$('#section-phone-numbers').addClass('error');
			                        	$("#samefield-err").removeClass('hidden');
			                        	return;
			                        	this.model.setChangedValue();
			                        	this.formatPayloadAndCallService();
							        } else {
							        	self.model.set('submitStatus', "success");
			                        	if (this.model.validate('gpm-update-form', true) && this.checkPreferredIconCount()) {
			                                if (self.getColaPhonetypeCount() == 0) {
				                            	self.showMinimumOneColaTypeRequiredError();
				                                return;
				                            }
				                            this.model.setChangedValue();
				                            this.formatPayloadAndCallService();
				                        }
							        }			                    	
			                    }
			                } else if (textLblCnt > 0 && dropDownTextCnt == 0) {
			                	for (var i = 0, j = textLblCnt; i < j; i++) {
			                        if (typeof ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text()) !== 'undefined') {
			                            var txt = $("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text();
			                            lblType.push(txt);
			                        }
			                    }
			                    for (var l = 0, m = dropDownTextCnt; l < m; l++) {
			                        var ddTxt = "";
			                        ddTxt = ($(".gpm-ph-edit-mode select:eq(" + l + ") option:selected").text());
			                        if ($.inArray(ddTxt, lblType) > -1) {
			                            if (duplicValue !== "") {
			                                duplicValue = duplicValue + " , " + ddTxt;
			                            } else {
			                                duplicValue = ddTxt;
			                            }
			                        }
			                    }
			                    if (duplicValue !== "") {
			                    	$('#section-phone-numbers').addClass('error');
			                        $("#samefield-err").removeClass('hidden');
			                        return;
			                        this.model.setChangedValue();
			                        this.formatPayloadAndCallService();
			                    } else {
			                    	self.model.set('submitStatus', "success");
		                        	if (this.model.validate('gpm-update-form', true) && this.checkPreferredIconCount()) {
		                                if (self.getColaPhonetypeCount() == 0) {
			                                self.showMinimumOneColaTypeRequiredError();
			                                return;
			                            }
		                            this.model.setChangedValue();
		                            this.formatPayloadAndCallService();
		                        	}
			                    }		                	
		                	} else if (dropDownTextCnt > 0 && textLblCnt == 0) {
		                		for (var i = 0, j = textLblCnt; i < j; i++) {
			                        if (typeof ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text()) !== 'undefined') {
			                            var txt = $("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text();
			                            lblType.push(txt);
			                        }
			                    }
			                    for (var l = 0, m = dropDownTextCnt; l < m; l++) {
			                        var ddTxt = "";
			                        ddTxt = ($(".gpm-ph-edit-mode select:eq(" + l + ") option:selected").text());
			                        ddType.push(ddTxt);
			                        if ($.inArray(ddTxt, lblType) > -1) {
			                            if (duplicValue !== "") {
			                                duplicValue = duplicValue + " , " + ddTxt;
			                            } else {
			                                duplicValue = ddTxt;
			                            }
			                        }
			                    }
			                    var sorted_arr = ddType.sort();   
						        var results = [];  
						        for (var i = 0; i < ddType.length - 1; i++) {  
						            if (sorted_arr[i + 1] == sorted_arr[i]) {  
						                ddDuplicateType = true;
						            }  
						        }
						        if (ddDuplicateType == true) {
						        	$('#section-phone-numbers').addClass('error');
		                        	$("#samefield-err").removeClass('hidden');
		                        	return;
		                        	this.model.setChangedValue();
		                        	this.formatPayloadAndCallService();
						        } 
			                    if (duplicValue !== "") {
			                    	$('#section-phone-numbers').addClass('error');
			                        $("#samefield-err").removeClass('hidden');
			                        return;
			                        this.model.setChangedValue();
			                        this.formatPayloadAndCallService();
			                    } else {
			                    	self.model.set('submitStatus', "success");
		                        	if (this.model.validate('gpm-update-form', true) && this.checkPreferredIconCount()) {
		                                if (self.getColaPhonetypeCount() == 0) {
			                                self.showMinimumOneColaTypeRequiredError();
			                                return;
			                            }
		                            this.model.setChangedValue();
		                            this.formatPayloadAndCallService();
		                        	}
			                    }
			           		}
		           } else {
		            	var textLblCnt = ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden')").length);
		                var dropDownTextCnt = ($('.gpm-ph-edit-mode').length);
	                	for (var i = 0, j = textLblCnt; i < j; i++) {
	                        if (typeof ($("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text()) !== 'undefined') {
	                            var txt = $("#section-phone-numbers .indvdl-phn-sectn-cntnr > .phone-num-view-section:not('.hidden') label:eq(" + i + ").field-label").text();
	                            var spanLbl = $("#section-phone-numbers .indvdl-phn-sectn-cntnr:eq(" + i + ") span.help-block").text();
	                            if (spanLbl!=="") { txt = txt + ' ' + spanLbl; }
	                            if (txt === 'Home' || txt === 'Business' || txt === 'Mobile' || txt === 'Other 1' || txt === 'Other 2') { lblType.push(txt);}			                            
	                        }
	                    }
	                    for (var l = 0, m = dropDownTextCnt; l < m; l++) {
	                        var ddTxt = "";
	                        ddTxt = ($(".gpm-ph-edit-mode select:eq(" + l + ") option:selected").text());	                        
	                       	if (ddTxt === 'Home' || ddTxt === 'Business' || ddTxt === 'Mobile' || ddTxt === 'Other 1' || ddTxt === 'Other 2') { 
	                        	if ( $.inArray(ddTxt, ddType) > -1 ) {
	                        		$('#section-phone-numbers').addClass('error');
			                        $("#samefield-err").removeClass('hidden');
			                        return;
			                        this.model.setChangedValue();
			                        this.formatPayloadAndCallService();
								}
	                        }
	                        ddType.push(ddTxt);		
	                        if ($.inArray(ddTxt, lblType) > -1) {
	                            if (duplicValue !== "") {
	                                duplicValue = duplicValue + " , " + ddTxt;
	                            } else {
	                                duplicValue = ddTxt;
	                            }
	                        }
	                    }
	                    if (duplicValue !== "") {
	                    	$('#section-phone-numbers').addClass('error');
	                        $("#samefield-err").removeClass('hidden');
	                        return;
	                        this.model.setChangedValue();
	                        this.formatPayloadAndCallService();
		            } else {
		            	self.model.set('submitStatus', "success");
		                if (this.model.validate('gpm-update-form', true) && this.checkPreferredIconCount()) {
		                    if (self.getColaPhonetypeCount() == 0) {
		                        self.showMinimumOneColaTypeRequiredError();
		                        return;
		                    }
		                    this.model.setChangedValue();
		                    this.formatPayloadAndCallService();
		                }
		            }
		            }
		        },

		        checkPreferredIconCount: function () {
		            var $editModeContainer = $('.gpm-ph-edit-mode');
		            var navPreferredCount = 0;
		            $('.phone-num-view-section, .phn-num-edit-section-holder').each(function () {
		                if (!$(this).hasClass('hidden') && $(this).find('.nav-preferred').length == 1) {
		                    navPreferredCount++;
		                }
		            });

		            if (navPreferredCount > 1) {
		                $("#section-phone-numbers").addClass('error'); $("label#preferred-err").removeClass("hidden").text("There should be only one preferred.");
		                /*if ($editModeContainer.is(':Visible') && $editModeContainer.find('.nav-preferred')) {
		                        $editModeContainer.css('background-color', '#F2D9Df');
		                } else { $editModeContainer.css('background-color', '#efefef'); }*/
		                return false;
		            }
		            return true;
		        },
		        navigateToStep2: function () {
		        	var _self = this, _gpmModel = this.model;
		        	_gpmModel.set('submittedTime',moment(new Date()).format('MM/DD/YYYY hh:mm a'));
		        	var _completedSteps = _gpmModel.get('completedSteps');
		        	_gpmModel.set('updateCompleted',true);
		        	$('.gpm-step.step1').addClass("finished").removeClass("active");
		        	$('.gpm-step.step2').addClass("active");
		        	if(_completedSteps.indexOf(1) == -1){
		        		_gpmModel.get('completedSteps').push(1);
					}
		        	Backbone.history.navigate('gpm/confirm/'+_gpmModel.get('updateMode'), true);
		        },
		        getGPMPhoneData:function(CPData){
		        	var _colaData = CPData.cola,_ebixData = CPData.ebix;
		        	var _colaPhones = (_colaData.telephones )?_colaData.telephones:[],_ebixPhones = _ebixData&&_ebixData.Phones?_ebixData.Phones:[];
		        	_ebixValidPhones = [], _colaValidPhones = [], _hasColaPreffered = false;
		        	var forClientCPData = CPViewModel.getInstance().getData();
		        	var _ebixData = {}, onlyInCola = true;
		        	if (forClientCPData.ebix) {
		        	    onlyInCola = false;
		        	}
		        	$(_colaPhones).each(function(j,colaNum){
		        		colaNum.phoneTypeCd = self.getPhoneTypeCode(colaNum.phnLblTxt);
		        		if((colaNum.phnCtryCd && colaNum.phnCtryCd != "" && colaNum.phnCtryCd !=null && colaNum.phnCtryCd != "+1" && colaNum.phnCtryCd != "1" && colaNum.nonNANPPhnNbr) || (colaNum.NANPAreaCd !="" && colaNum.NANPAreaCd !=undefined && colaNum.NANPAreaCd != null)){
		        			var _isPrefrd = false;
		        			if(colaNum.phnPrfrCd == "1" || colaNum.phnPrfrCd == "01"){
		        				_hasColaPreffered = true;
		        				_isPrefrd = true;
		        			}
		        			_colaValidPhones.push({ customValues: { preffered: _isPrefrd, prefferedNum: (_isPrefrd ? 1 : 2), viewDispaly: true, dataSource: "COLA", onlyInCola: onlyInCola }, value: new ColaPhoneNumModel().set(colaNum) });
                        }
		        	});
		        	$(_ebixPhones).each(function(index,ebixNum){
	        			ebixNum = ebixNum.toJSON();
	        			ebixNum.phoneTypeCd = self.getPhoneTypeCode(ebixNum.PhoneTypeDesc);
	        			if(ebixNum.BadPhoneNumber != 1){
	        				var _isColaNum = false,_colaIndex=null,_colaRefId=null,_donotUpdate = false,_isPreffered = false;
	        				$(_colaValidPhones).each(function(i,colaNum){
	    		        		//_colaValidPhones.push({viewDispaly:true,dataSource:"COLA",value:colaNum});
	        					ebixNum.PhoneTypeDesc = ebixNum.PhoneTypeDesc !=null ? ebixNum.PhoneTypeDesc:"";
	    		        		if((colaNum.value.get('phnLblTxt').toLowerCase()  == ebixNum.PhoneTypeDesc.toLowerCase()) && ebixNum.ElectronicDownload == "1"){
	    		        			_isColaNum = true;
	    		        			_colaIndex = i
	    		        			_colaRefId = colaNum.value.get('clTeleId')
			        			}else if(ebixNum.ElectronicDownload == "1"){
			        				//do not display and do not update
			        				_donotUpdate = true;
			        			}
	    		        	});
	        				if(_hasColaPreffered){
	        					_isPreffered = false;
	        				}else{
	        					_isPreffered = ebixNum.Preferred == 1?true:false;
	        				}
	        				if (_isColaNum) {
	        				    _ebixValidPhones.push({ customValues: { preffered: ebixNum.Preferred == 1, prefferedNum: (ebixNum.Preferred == 1 ? 1 : 2), colaPhoneRefIndex: _colaIndex, clTeleId: _colaRefId, viewDispaly: false, dataSource: "EBIX", onlyInCola: onlyInCola }, value: new EbixPhoneNumModel().set(ebixNum) });
	        				    var _colaPhn = _colaValidPhones.find(function (row) { return row.value.get('clTeleId') == _colaRefId; });
	        				    _colaPhn.customValues.ebixRefId = ebixNum.Id;
	        				} else {
	        				    if (!_donotUpdate && ebixNum.ElectronicDownload != "1") {
	        				        _ebixValidPhones.push({ customValues: { preffered: _isPreffered, prefferedNum: (_isPreffered ? 1 : 2), viewDispaly: true, dataSource: "EBIX", onlyInCola: onlyInCola }, value: new EbixPhoneNumModel().set(ebixNum) });
	        				    }
	        				}
                        }
		        	});
		        	
		        	return {
			        	colaPhones:_colaValidPhones,
			        	ebixPhones:_ebixValidPhones
				        }
		        },
		        getPhoneTypeCode:function(phoneType){
		        	var _phoneTypes = PTCommonData.phoneType,_phoneTypeCd='';
		        	$(_phoneTypes).each(function(index,data){
		        		if(data.serviceValue.indexOf(phoneType)>-1){
		        			_phoneTypeCd = data.code;
		        		}
		        	});
		        	return _phoneTypeCd;
		        },
		        formatPayloadAndCallService:function(){
		        	var _changedPhoneNums = this.model.getChangedItems();
		        	var _colaPayload =  this.getColaPayload(_changedPhoneNums);
		        	//var _ebixPayload =	this.getEbixPayload(_changedPhoneNums);
		        	this.callColaPhoneUpdateService(_colaPayload);
		        	
		        	
		        },
		        callColaPhoneUpdateService:function(UpdatePayload){
		        	var _items = self.model.get('items'),_servieUpdateSuccessCounter = 0 ;
		        	var colaPayload = UpdatePayload.cola,_ebixPayload = UpdatePayload.ebix;
		        	var _deletedNumberPayload = {"telephones":colaPayload.deletedNumbers},_updatedNumberPayload = {"telephones":colaPayload.updatedNumbers},_updateNumberIds = colaPayload.updatedNumberIds;
		        	//first call service delete payload then call the update 
		        	if(colaPayload.deletedNumbers.length > 0){
		        		callServiceWithDeletePayload(_deletedNumberPayload);
		        	}else if(colaPayload.updatedNumbers.length > 0){
		        		callServiceWithUpdatePayload(_updatedNumberPayload);
		        	}else if(_ebixPayload.EditedPhone.length > 0 || _ebixPayload.TobeDeletedPhone.length > 0){
		        		callCMPhoneUpdateService(_ebixPayload);
		        	}
		        	else{
		        		self.revertModelOnUpdateFailure();
		        		//no changes, show message to user
		        		Utils.showNoChangesMessageToUser();
		        	}
		        	function callServiceWithDeletePayload(deletePayload){
		        		Spinner.show();
		        		DataService.updateCOLAPhoneNumbers(self.model.get('clientId'),deletePayload).done(function(response,msg,xhr){
							 //Spinner.hide();
							 if(response && response.d && response.d.telephones){
								 _servieUpdateSuccessCounter++;
								 //mark all deleted item as serviceDeleted = true, so that even if other service call fails, next time payload format function won't add these items to the delete payload
								 //_self.navigateToStep3();
								 $.each(deletePayload.telephones,function(i,data){
									 var _clTeleId = data.clTeleId;
									 var _item = _items.find(function(row){return row.get("itemType") == _clTeleId});
									 _item.get('customValues').serviceDeleted = true;
								 });
								 if(colaPayload.updatedNumbers.length > 0){
									 callServiceWithUpdatePayload(_updatedNumberPayload);
								 }else{
									 if(_ebixPayload.EditedPhone.length > 0 || _ebixPayload.TobeDeletedPhone.length > 0){
							        		callCMPhoneUpdateService(_ebixPayload);
							        	}else{
							        		updateSuccess(); 
							        	} //alert("Success");
									
								 }
							 }else{
								 showServiceError(xhr);
							 }
						}).fail(showServiceError);
		        	
		        	}
		        	function callServiceWithUpdatePayload(updatePayload){
		        		Spinner.show();
		        		//self.model.get('clientId')
						 DataService.updateCOLAPhoneNumbers(self.model.get('clientId'),updatePayload).done(function(response,msg,xhr){
							 if(response && response.d && response.d.telephones){
								 _servieUpdateSuccessCounter++;
								 if(_ebixPayload.EditedPhone.length > 0 || _ebixPayload.TobeDeletedPhone.length > 0){
						        		callCMPhoneUpdateService(_ebixPayload);
						        	}else{
						        		updateSuccess();
						        	} //alert("Success");
								
							 }else{
								 self.model.set('submitStatus',"partial");
								 successCallCheck(xhr); 
							 }
						}).fail(function(err){self.model.set('submitStatus',"partial");successCallCheck(err);});
						 function successCallCheck(xhr){
	              	    		$.each(_updateNumberIds,function(index,itemType){
	              	    			var _item =  _items.find(function(row){return row.get("itemType") == itemType});
	        		        		var _custVal = _item.get('customValues');
	        		        		if(_custVal.changed == true){
	        		        			_custVal.updateStatus = "failed";
	        		        		}
	        		        	});
							 if(_servieUpdateSuccessCounter>0 && (_ebixPayload.EditedPhone.length > 0 || _ebixPayload.TobeDeletedPhone.length > 0)){
					        		callCMPhoneUpdateService(_ebixPayload);
					        	}else if(_servieUpdateSuccessCounter>0){
					        		updateSuccess();
					        	}else{
					        		/*if(err){*/
					        		showServiceError(xhr);
					        		/*}else{
					        			updateFailed();
					        		//}
*/					        		 
					        	}
						 }
					 
		        	}
		        	function callCMPhoneUpdateService(_ebixPayload){
		        		  Spinner.show();
		        		  //CommonUtils.readCookie('FMID')
		        		  DataService.editContact(CommonUtils.readCookie('FMID'), _ebixPayload).then(function (response,msg,xhr) {
		              	    //Spinner.hide();
		              	    if(!response.status && response.indexOf("Success") > -1){
		              	    	_servieUpdateSuccessCounter++;
		              	    	updateSuccess();
		              	    }else{
		              	    	self.model.set('submitStatus',"partial");
		              	    	successCallCheck(xhr);
		              	    	
		              	    }
		              	    
		              	})
		              	.fail(function(err){
		              		self.model.set('submitStatus',"partial");
		              		successCallCheck(err)
		              	});
		        		  function successCallCheck(xhr){
		        			//mark all chnaged ebix numbers updateStatus = failed
	              	    		var _changedPhoneNums = self.model.getChangedItems();
	              	    		$.each(_changedPhoneNums,function(index,data){
	        		        		var _custVal = data.get('customValues');
	        		        		if(_custVal.changed == true  && _custVal.dataSource=="EBIX"){
	        		        			_custVal.updateStatus = "failed";
	        		        		}
	        		        	});
	              	    		if(_servieUpdateSuccessCounter>0){
					        		updateSuccess();
					        	}else{
					        			showServiceError(xhr,true);
					        	}
						 }
		        	}
		        	function updateSuccess(){
		        		// Spinner.hide(); 
		        		 //self.revertModelOnUpdateFailure();
		        		self.navigateToStep2();
		        	}
		        	function updateFailed(){
		        		self.revertModelOnUpdateFailure();
		        		Spinner.hide();
		        		Utils.showServiceError();
		        	
		        	}
		        	function showServiceError(xhr,isEbix){
		        		self.revertModelOnUpdateFailure();
						Spinner.hide();
						if(!isEbix){
							var _repsJson =  xhr.responseJSON;
							//check for custom error code
							if(xhr.status == 500 && _repsJson  && _repsJson.error && _repsJson.error.errorCode == 9000){
								//add invalid country code error
								$('#section-phone-numbers').attr('data-error-code',"errorCode"+_repsJson.error.errorCode);
							}
						}
						Utils.showServiceError(xhr);
		        	}
		        },
		        revertModelOnUpdateFailure:function (){
		        	var _items = self.model.get('items');
		        	 self.model.set('submitStatus',"success");
		        	var _updatedItems = [];
		        	$.each(_items,function(i,data){
		        		var _custVal = data.get('customValues');
		        		if(_custVal.createMode != "new"){
		        			_updatedItems.push(data);
		        			if(_custVal.markAsUpdated == true){
		        				_custVal.markAsUpdated = false;
		        				_custVal.changed = true;
		        				_custVal.deleted = true;
		        				_custVal.updateStatus = "";
		        			}
		        		}else{
		        			var _refId = _custVal.clTeleId;
		        			if(_refId != undefined && _refId != "" && _refId != null){
		        				var _item = _items.find(function(row){return row.get("itemType") == _refId});
								 _item.get('customValues').changed = false;
								 _item.get('customValues').deleted = false;
								 _item.get('customValues').updateStatus = "";
								 
		        			}
		        		}
		        		
		        	});
		        	self.model.set('items',_updatedItems);
		        },
		        getColaPayload:function(changedItems){
		        	var _currentColaNumbers = [],_items = self.model.get('items'),_deletedNumbers=[];
		        	$.each(_items,function(index,data){
		        		var _custVal = data.get('customValues')
		        		if(_custVal.dataSource =="COLA" && _custVal.createMode != "new"){
		        			_currentColaNumbers.push(data);
		        		}
		        		if(_custVal.dataSource =="COLA" && _custVal.createMode != "new" && _custVal.deleted ==true){
		        			_deletedNumbers.push(data);
		        		}
		        	});
		        	var _phnNumbers = changedItems,_colaPhnNumbers=[],_ebixPhnNUmbers=[],_newPhoneNumbers=[],_colaModifiedNumbers = [],_modifiedDeleted;
		        	var _phnPayload = {},_colaRequestPayload = {"phoneNumberCount":0,"deletedNumbers":[],"updatedNumbers":[],"updatedNumberIds":[]	};
		        	$.each(_phnNumbers,function(index,data){
		        		var _custVal = data.get('customValues');
		        		if(_custVal.changed == true){
		        			switch (_custVal.dataSource) {
							case "EBIX":
								_custVal.updateStatus = "";
								_ebixPhnNUmbers.push(data);
								break;
							case "COLA":
								_custVal.updateStatus = "";
								_colaPhnNumbers.push(data);
								//if already deleted dpnt push it to payload
								if(!_custVal.serviceDeleted == true){
									_colaRequestPayload.phoneNumberCount++;
									var _numberPayload = getDataInColaPhnNumberPayloadFormat(data);
									_numberPayload.actnCd =="R"?_colaRequestPayload.deletedNumbers.push(_numberPayload):_colaRequestPayload.updatedNumbers.push(_numberPayload);
								}
								
								break;
							default:
								break;
							}
		        		}
		        	});
		        	if(_deletedNumbers.length>0 && _deletedNumbers.length == _currentColaNumbers.length){
		        		$.each(_colaRequestPayload.deletedNumbers,function(i,del){
		        			var _isDeletedNumberAddingAgain = false;
		        			$.each(_colaRequestPayload.updatedNumbers,function(j,upd){
			        			if(del.phnLblTxt == upd.phnLblTxt){
			        				//deleting one type and trying to add same type
			        				//so make it as update
			        				_isDeletedNumberAddingAgain = true;
			        				upd.clTeleId = del.clTeleId;
			        				upd.actnCd = "U";
			        				var _deletdItem = _items.find(function(row){return row.get("itemType") == del.clTeleId});
			        				//mark it as changed =false, and deleted equal to false
			        				_deletdItem.get('customValues').markAsUpdated= true;
			        				_deletdItem.get('customValues').changed= false;
			        				
			        			}
			        			
			        		});
		        			if(_isDeletedNumberAddingAgain == false){
		        				//push delete action to the last of update payload
		        				_colaRequestPayload.updatedNumbers.push(del);
		        			}
		        		});
		        		_colaRequestPayload.deletedNumbers = [];
		        	}else if(_deletedNumbers.length>0 && _deletedNumbers.length != _currentColaNumbers.length){
		        		var _markAsUpdatedIndex = [];
		        		$.each(_colaRequestPayload.deletedNumbers,function(i,del){
		        			var _isDeletedNumberAddingAgain = false;
		        			$.each(_colaRequestPayload.updatedNumbers,function(j,upd){
			        			if(del.phnLblTxt == upd.phnLblTxt){
			        				//deleting one type and trying to add same type
			        				//so make it as update
			        				_isDeletedNumberAddingAgain = true;
			        				upd.clTeleId = del.clTeleId;
			        				upd.actnCd = "U";
			        				var _deletdItem = _items.find(function(row){return row.get("itemType") == del.clTeleId});
			        				//mark it as changed =false, and deleted equal to false
			        				//_colaRequestPayload.updatedNumbers.push(del);
			        				_deletdItem.get('customValues').markAsUpdated= true;
			        				_deletdItem.get('customValues').changed= false;
			        				_markAsUpdatedIndex.push(i);
			        				
			        			}
			        			
			        		});
		        			
		        		});
		        		
					var _markAsUpdatedCount = 0;
		        		$.each(_markAsUpdatedIndex,function(k,dat){
		        			_colaRequestPayload.deletedNumbers.splice((dat-_markAsUpdatedCount),1);	
		        			_markAsUpdatedCount++;
		        		});
		        	}
		        	var _ebixPayload = self.getEbixPayloadFormat(_ebixPhnNUmbers);
		        	return {
		        		"cola":_colaRequestPayload,
		        		"ebix":_ebixPayload
		        	};
		        	function getDataInColaPhnNumberPayloadFormat(data){
		        		var _custVal = data.get('customValues'),_changedItemval = data.get('changedItemValue');
		        		var _phnType = _changedItemval.get('phnLblTxt').toUpperCase().replace(' ','');
		        		_phnType = _phnType =="BUSINESS"?"WORK":_phnType;
		        		var _phnCtryCd = _changedItemval.get('phnCtryCd');
		        		_phnCtryCd = _phnCtryCd.length==0?"+1":(_phnCtryCd.indexOf('+') !=0 ?("+"+_phnCtryCd):_phnCtryCd);
		        		if(_custVal.deleted != true){
		        			_colaRequestPayload.updatedNumberIds.push(data.get('itemType'));
		        		}
		        		var _phnPayload = {
		                    "actnCd": _custVal.createMode == "new"?"A":(_custVal.deleted == true?"R":"U"),
		                    "clTeleId": _custVal.createMode == "new"?null:  _changedItemval.get('clTeleId'),
		                    "phnLblTxt": _phnType,
		                    "phnSubLblTxt": "",
		                    "phnCtryCd": _phnCtryCd,
		                    "NANPAreaCd": _changedItemval.get('NANPAreaCd'),
		                    "NANPExchCd": _changedItemval.get('NANPExchCd'),
		                    "NANPSbscNbr": _changedItemval.get('NANPSbscNbr'),
		                    "nonNANPPhnNbr": _changedItemval.get('nonNANPPhnNbr'),
		                    "phnExtnNbr":_changedItemval.get('phnExtnNbr'),
		                    "phnPrfrCd":_changedItemval.get('phnPrfrCd')
		                }
		        		return _phnPayload;
		        	}
		        },
		        getEbixPayloadFormat:function(ebixPhnNUmbers){
		        	var _addPhones="",_editPhones="",_tobeDeletedPhone =[];
		        	$.each(ebixPhnNUmbers,function(i,PhoneModel){
		        		var _custVal = PhoneModel.get('customValues'),_changedItemval = PhoneModel.get('changedItemValue');
		        		var _cntryCode = _changedItemval.get('CountryCode');
		        		//Update existing phone
	            		if((_cntryCode == "" ||_cntryCode == undefined ||_cntryCode == null || _cntryCode == "+1" ||_cntryCode == "1") && _custVal.deleted != true){
	            			if(_custVal.createMode != "new"){
	                			var _tmptEditPhone = "PId="+_changedItemval.get('Id');
	                				_tmptEditPhone+= "|PType="+ (_changedItemval.get('phoneTypeCd') || '#$#');
	                				_tmptEditPhone+= "|PNo="+ (_changedItemval.get('Number').substr(0,3) || '#$#')+ (_changedItemval.get('Number').substr(3,4) || '#$#');
	                				_tmptEditPhone+= "|PAc="+ (_changedItemval.get('AreaCode') || '#$#');
	                				_tmptEditPhone += "|PEx=" + (_changedItemval.get('Extension') || '#$#');
	                				_tmptEditPhone += "|PPrf=" + (_changedItemval.get('Preferred') || '#$#');
	                				_tmptEditPhone += "|PCc=" + ('#$#');
	                				_tmptEditPhone += "~";
	                				_editPhones += _tmptEditPhone;
	                		}
	                		//Add new phone
	                		else if(_custVal.deleted != true){
	                			var _tmptAddPhone = "PId="
	                				_tmptAddPhone+= "|PType="+ (_changedItemval.get('phoneTypeCd') || '#$#');
		            				_tmptAddPhone+= "|PNo="+ (_changedItemval.get('Number').substr(0,3) || '#$#')+ (_changedItemval.get('Number').substr(3,4) || '#$#');
		            				_tmptAddPhone+= "|PAc="+ (_changedItemval.get('AreaCode') || '#$#');
		            				_tmptAddPhone += "|PEx=" + (_changedItemval.get('Extension') || '#$#');
		            				 _tmptAddPhone += "|PPrf=" + (_changedItemval.get('Preferred') || '#$#');
		            				_tmptAddPhone += "|PCc=" + ('#$#');
		                			_tmptAddPhone += "~";
		                			_addPhones += _tmptAddPhone;
	                		}
	            		}else if(_custVal.deleted != true)
	            	    //for international number
	            		  {
	            		    if (_custVal.createMode != "new") {
	            		        var _tmptEditPhone = "PId=" + _changedItemval.get('Id');
	            		        _tmptEditPhone += "|PType=" + (_changedItemval.get('phoneTypeCd') || '#$#');
	            		        _tmptEditPhone += "|PNo=" + (_changedItemval.get('AreaCode')+""+_changedItemval.get('Number'));
	            		        _tmptEditPhone += "|PAc=" + ('#$#');
	            		        _tmptEditPhone += "|PEx=" + (_changedItemval.get('Extension') || '#$#');
	            		        _tmptEditPhone += "|PPrf=" + (_changedItemval.get('Preferred') || '#$#');
	            		        _tmptEditPhone += "|PCc=" + (_changedItemval.get('CountryCode') || '#$#');
	            		        _tmptEditPhone += "~";
	            		        _editPhones += _tmptEditPhone;
	            		    }
	            		        //Add new phone
	            		    else if (_custVal.deleted != true) {
	            		        var _tmptAddPhone = "PId="
	            		        	_tmptAddPhone += "|PType=" + (_changedItemval.get('phoneTypeCd') || '#$#');
		            		        _tmptAddPhone += "|PNo=" + (_changedItemval.get('AreaCode')+""+_changedItemval.get('Number'));
		            		        _tmptAddPhone += "|PAc=" + ('#$#');
		            		        _tmptAddPhone += "|PEx=" + (_changedItemval.get('Extension') || '#$#');
		            		        _tmptAddPhone += "|PPrf=" + (_changedItemval.get('Preferred') || '#$#');
		            		        _tmptAddPhone += "|PCc=" + (_changedItemval.get('CountryCode') || '#$#');
		            		        _tmptAddPhone += "~";
	            		        _addPhones += _tmptAddPhone;
	            		    }
	            		}
	            		else if(_custVal.deleted == true){
                			_tobeDeletedPhone.push(_changedItemval.get('Id'))
                		}
		        	})
            		var _editedContactDetails = _addPhones+_editPhones, _ebixData = (CPViewModel.getInstance().getData()&&CPViewModel.getInstance().getData().ebix)?CPViewModel.getInstance().getData().ebix:{};
		        	_editedContactDetails = _editedContactDetails.split("#$#").join("");
		        	var _personContact = _ebixData.PersonContact?_ebixData.PersonContact:{get:function(){return "";}};
					var _ebixReqPayload = {
						"id" : _ebixData.id,
						"ctx" : _ebixData.ctx,
						"type" : _ebixData.type,
						"contactType" : _ebixData.contactType,//need to change once prospect edit is in place
						"remarks" : _ebixData.remarks,
						"PersonContact" : {
							"clGreeting" : _personContact.get('clGreeting'),
							"clMidNm" : _personContact.get('clMidNm'),
							"clSfxTxt" : _personContact.get('clSfxTxt')?_personContact.get('clSfxTxt'):"",
							"clOccupation" : _personContact.get('clOccupation'),
							"clJobTitle" : _personContact.get('clJobTitle')
						},
						"TobeDeletedPhone" : _tobeDeletedPhone.join("~"),
						"EditedPhone" : _editedContactDetails,
						"TobeDeletedWebAddress" : "",
						"EditedWebAddress" : "",
						"TobeDeletedAddress" : "",
						"EditedAddress" : "",
						"BusinessContact" : {},
						"contactSubType":_ebixData.contactSubType
					};
					return _ebixReqPayload;
		        },
		        isColaType:function (phoneType){
		    		var _colaPhoneTypes = ["home","business","mobile","other 1","other 2"];
		    		return phoneType && _colaPhoneTypes.indexOf(phoneType.toLowerCase())==-1?false:true;
		    	}
		        

		    });
	
		    return _PhoneNumbersView;
		});