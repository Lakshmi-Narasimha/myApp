 
 function loginMasterController($scope,$state,advisorRegistrationModelService,$cookies,appConfig){
        $scope.submitDistributor = function(){ 
        
        	if($scope.distributorForm.$valid){ 
        	     $scope.$broadcast('usrNamesubmitted');
               $scope.formData=advisorRegistrationModelService.getUNameData(); 
               $scope.formData.regType="Adviser";
               var postSuccess = function (response) {
                      advisorRegistrationModelService.setUserData(response.data);
                      $cookies.put('accessToken',response.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
                      $state.go('loginmaster.userverification.securityquestion'); 
               };
               
               var handleFailure = function (errorResp){
                  $scope.displayError = errorResp.data[0].errorDescription;
               };

               advisorRegistrationModelService.postUNAndDobFUNameDetails($scope.formData).then(postSuccess, handleFailure);
            
        	}
        	
        }
}
loginMasterController.$inject = ['$scope','$state','advisorRegistrationModelService','$cookies','appConfig'];
module.exports = loginMasterController;