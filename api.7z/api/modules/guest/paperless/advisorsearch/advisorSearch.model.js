// advisorSearch.model.js
// grab the mongoose module
// define our instantreports model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AdvisorSearchSchema = new mongoose.Schema({
	advisorSearchObject: {
		type: Array,
		"default": []
	}
});

var AdvisorSearchLookUp = mongoose.model('AdvisorSearchLookUp', AdvisorSearchSchema);

var AdvisorSearchModel = new AdvisorSearchLookUp({

	advisorSearchObject: {
		"adivisorSearchDetails": [

			{"name":"Alexander"},
			{"name":"Benjamin"},
			{"name":"Christopher"},
			{"name":"Daniel"},
			{"name":"Ethan"},
			{"name":"Fernando"},
			{"name":"Gabriel"},
			{"name":"Henry"},
			{"name":"Isaac"},
			{"name":"Jacob"},
			{"name":"Kevin"},
			{"name":"Liam"},
			{"name":"Mason"},
			{"name":"Noah"},
			{"name":"Owen"},
			{"name":"Parker"},
			{"name":"Quinn"},
			{"name":"Ryan"},
			{"name":"Samuel"},
			{"name":"Tyler"},
			{"name":"Uriel"},
			{"name":"Vincent"},
			{"name":"Willia"},
			{"name":"Xavier"},
			{"name":"Yahir"},
			{"name":"Zachary"},
			{"name":"Ava"},
			{"name":"Brooklyn"},
			{"name":"Chloe"},
			{"name":"Destiny"},
			{"name":"Emma"},
			{"name":"Faith"},
			{"name":"Grace"},
			{"name":"Hannah"},
			{"name":"Isabella"},
			{"name":"Julia"},
			{"name":"Kaylee"},
			{"name":"Lily"},
			{"name":"Madison"},
			{"name":"Natalie"},
			{"name":"Olivia"},
			{"name":"Peyton"},
			{"name":"Quinn"},
			{"name":"Riley"},
			{"name":"Sophia"},
			{"name":"Taylor"},
			{"name":"Victoria"},
			{"name":"Willow"},
			{"name":"Ximena"},
			{"name":"Yareli"},
			{"name":"Zoe"}
		]
	}
});

AdvisorSearchLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
    	console.log('Having toruble in creating AdvisorSearchLookUp table, please contact admin...');
    } else {
    	AdvisorSearchLookUp.remove({}, function(err) {
    		console.log('AdvisorSearchLookUp collection removed');
    		AdvisorSearchModel.save(function(err) {
    			if (err) {
    				console.log('Having toruble in creating AdvisorSearchLookUp table, please contact admin...');
    			}
    			console.log('AdvisorSearchLookUp table created in mongoose...');
    		});
    	});
    	console.log(data.length);
    }
});

module.exports = AdvisorSearchLookUp;
