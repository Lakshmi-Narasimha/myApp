/**
 * @ngdoc directive
 * @name firstHolderView
 * 
 * @description
 *
 * - It will display all the details of the user
 **/
var firstHolderView = function ($state, transactModel){
	return {
		template : require('./firstHolderView.html'),
		restrict : 'E',
		scope : {
      holderForm : '=',
      holderDetails : '=',
      firstHolderYes : '=?',
      innerHeadingInfo : '@?',
      headingInfo :'@?'
    },
		controller : function ($scope,$element,$attrs){
              // $scope.isPaperless = transactModel.isPaperless;
              $scope.headingStatus = true;
              if($scope.headingInfo == "false"){
                $scope.headingStatus = false;
              }
              $scope.verifyDetails = {
              	heading : "Verify Details"
              }
              $scope.addEmail = false;
              $scope.addMobile = false;
              if($scope.innerHeadingInfo){
                $scope.innerHeadingText = $scope.innerHeadingInfo;
              }else{
                $scope.innerHeadingText = "Your Aadhaar Details";
              }
              

              $scope.userDetails = {
                username : 'Shankar Narayanan',
                aadhar : '8877887788',
                dob : '02/10/1980',
                gender : 'Male',
                address:'A/203 Kalpataru towers, Somajiguda, Hyderabad 500082',
                mobile:'9556622312',
                email:'Shankar.narayanan@gmail.com',
                image:'images/person.jpg'
              }
              if($scope.holderDetails){
                $scope.userDetails = $scope.holderDetails;
              }
              $scope.mobileRegex = '((\\d{10}))';
              $scope.mobile = {
              	key :'mobile',
              	text:'Mobile',
              	value : '',
                type : 'number',
                pattern : $scope.mobileRegex,
                name : "mobile",
                isRequired : true
              }

              $scope.email = {
                key :'email',
                text:'Email',
                value : '',
                type : 'text',
                name : "email",
                pattern : /^[A-Za-z0-9._]+[A-Za-z0-9._]+@[A-Za-z]+\.[A-Za-z.]{2,5}$/,
                isRequired : true
              }

              $scope.showIPfieldEmail = function(){
                $scope.holderForm.$setPristine();
                $scope.addEmail = true;
              }
              $scope.showIPfieldMobile = function(){
                $scope.holderForm.$setPristine();
                $scope.addMobile = true;
              }
              $scope.hideIPfieldEmail = function(){
                $scope.addEmail = false;
              }
              $scope.hideIPfieldMobile = function(){
                $scope.addMobile = false;
              }


              // $scope.continueSubmission = function () {
              //   $state.go('reviewDetails');
              // }
		 }
	}
};
 firstHolderView.$inject = ['$state', 'transactModel'];
 module.exports = firstHolderView;