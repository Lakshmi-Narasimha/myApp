 function investerController($scope,$state,advisorRegistrationModelService,$cookies,appConfig){
      $scope.submitInvestor = function(){

      		//if($scope.investorForm.$valid){
            $scope.displayError = "";
         	  	$scope.$broadcast('usrNamesubmitted');
              var paramObj =advisorRegistrationModelService.getUNameData();
              paramObj.regType = 'Investor';
              if(!paramObj.userId){
                $scope.displayError = "Username field cannot be empty";
              }else if(!paramObj.dobOrRegDate){
                $scope.displayError = "Please select date of birth";
              }else{
               var postSuccess = function (response) {
                     //$state.go('loginmaster.otpdetails');
                    advisorRegistrationModelService.setUserData(response.data);
                    $cookies.put('accessToken',response.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
                    $state.go('loginmaster.userverification.securityquestion');
               };
               
              var handleFailure = function (errorResp){ 
                  $scope.displayError = errorResp.data[0].errorDescription;
               };
               advisorRegistrationModelService.postUNAndDobFUNameDetails(paramObj).then(postSuccess, handleFailure);
               
        	}
        	
        }
}
investerController.$inject = ['$scope','$state','advisorRegistrationModelService','$cookies','appConfig'];
module.exports = investerController;