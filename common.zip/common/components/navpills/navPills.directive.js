/**
 * @ngdoc directive
 * @name fticNavpills Directive
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - It is used to display the two group buttons 
 *
 **/

'use strict';

var fticNavPills = function() {
	return {
            template: require('./navpills.html'),
            restrict: 'E',
            replace: true,
            scope: {
                options : '=',
                modelVal : '=',
                pillSelect : '&',
                btnColor: '='
            }
        };
};

fticNavPills.$inject = [];
module.exports = fticNavPills;