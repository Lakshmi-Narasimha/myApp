'use strict';

describe('Directive: Image Text tile Directive', function() {

    var compile, scope, directiveElem, isoScope, validHtml;
    var getCompiledElement = function() {
        var element = angular.element('<ftic-inv-db-ss-tile></ftic-inv-db-ss-tile>');
        var compiledDirective = compile(element)(scope);
        scope.$digest();
        return compiledDirective;
    };

    //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('investor'));
    beforeEach(function() {

        angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;
            directiveElem = getCompiledElement();
        });

    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should be created with scope:true', function() {
        expect(directiveElem.scope()).toBeDefined();
    });

    it('should applied template and have image icon', function() {
        expect(directiveElem.html()).not.toEqual('');
        expect(directiveElem.find('i').length).toEqual(1);
    });

    it('should be scope data rendered in template', function() {
        scope.slide = {
            'link': {
                'external': 'no',
                'name': 'Amount you wish to save towards the end of goal',
                'href': '/dream-home.html',
                'type': 'default'
            },
            'description': 'Lorem Ipsum is simply dummy text of printing and typesetting?',
            'title': 'Wealth Creation',
            'background-image-mobile': '/images/fti_dreamHome_thumb.jpg',
            'background-image-tablet': '/images/fti_dreamHome_thumb.jpg',
            'background-image-desktop': '/images/fti_dreamHome_thumb.jpg'
        }
        scope.$digest();

        expect(scope.slide).toBeDefined();
        expect(scope.slide['background-image-desktop']).toBe('/images/fti_dreamHome_thumb.jpg');

        expect(directiveElem.find('h4').text()).toBe('Lorem Ipsum is simply dummy text of printing and typesetting?');
        expect(angular.element(directiveElem.find('p')[0]).text()).toBe('Wealth Creation');
        expect(angular.element(directiveElem.find('p')[1]).text().trim()).toBe('Amount you wish to save towards the end of goal');
        expect(directiveElem.find('button').text()).toContain("RECOMMEND A PLAN");

    });
});
