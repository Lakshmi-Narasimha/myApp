var express = require('express');
var https = require('https');

var router = express.Router();
var engagementModel = require('./engagement.model');

// api route
router.route('/mfchat/rest/engagement')
    .post(function(req, res) {
        req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID];
        var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
        var proxyRequest = https.request({
                host: req.uri.host,
                method: 'GET',
                path: req.uri.path + '&InitialMessage=' + initialMessage,
                headers: {
                    'Cookie': req.sessionCookie,
                    'Content-Type':'application/x-www-form-urlencoded'
                }
            },

            function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(chunk) {
                    chunk = JSON.parse(chunk);
                    engagementModel.response.Page.availability = chunk.availability;
                    if(engagementModel.response.Page.availability === true){
                      engagementModel.response.Page.inHOP = true;
                      engagementModel.response.Page.status === "online";
                    }else{
                      engagementModel.response.Page.inHOP = chunk.inHOP;
                      engagementModel.response.Page.status = chunk.status;
                    }
                    res.send(engagementModel.response);
                });
                proxyResponse.on('error', function(err) {
                    err.message = 'ERROR!!! Something went wrong while retrieving data.';
                    res.send(err);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
