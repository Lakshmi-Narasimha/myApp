/**
 * @ngdoc service
 * @name getPaymentDetailsSevice
 * @description
 *
 * - PaymentDetails JSON  / Method
 */
/*global Visualforce*/
(function() {
    'use strict';

    angular.module('CSS.common').service('getPaymentDetailsSevice', ['$http', '$q', function($http, $q) {

        this.getPaymentDetails = function(queryData) {
            var deferred = $q.defer();
            Visualforce.remoting.Manager.invokeAction('CSS_SelfRegController.getPaymentDetails', queryData,
                function(result, event) {
                    if (event.status) {
                        deferred.resolve(JSON.parse(result));
                    } else {
                        deferred.reject(event);
                    }
                }, {
                    escape: false
                });

            return deferred.promise;
        };        
        
    }]);

})();