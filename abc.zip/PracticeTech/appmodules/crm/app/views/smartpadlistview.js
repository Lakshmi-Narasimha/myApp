define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'moment',
  'jqueryui',
    'appcommon/constants',
  'services/dataservice',
  'appcommon/commonutility',
  'text!appmodules/crm/app/templates/smartpadlist.html',
  'text!appmodules/crm/app/templates/smartpadnotedetail.html',
  'text!appmodules/crm/app/templates/addsmartpad.html',
  'errorLog'
], function ($, _, Backbone, Spinner, Moment, JqueryUI,Constants, Dataservice, CommonUtilis, SmartpadListTemplate, SmartpadNoteDetailTemplate, AddSmartPadTemplate, ErrorLog) {
    var self, smartpadlist = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click .note-detail": "gotodetails",
            "click .household-grp-container .cm-grp-lnk": "handleCMGroupChange",
            "click #add-smartpad-note-link":"handleAddSmartpadNoteNavigation"
        },

        initialize: function (e) {
            self = this;
            this.pinnedContact = {
                pinnedContactId: undefined,
                pinnedClientId: undefined,
                pinnedContactType: undefined,
                pinnedContactFirstName: undefined,
                pinnedContactLastName: undefined
            };
            this.houseHoldGroups;
            this.selectedDropdownId;
            this.selectedDropdownType;
            this.contctDetails;
            this.options;
        },
        gotodetails :function(e){
            var _target = e.target || e.currentTarget,
                _padId = $(_target).data("pad-id"),
                _url = "crm/notedetail/" + _padId;
            this.createStateModuleIfNeeded();
            this.saveState(_padId);
        	window.scrollTo(0,0);
        	Backbone.history.navigate(_url,true);
        },
        createStateModuleIfNeeded: function () {
            (typeof practicetech.modules.smartpads === 'undefined') ? practicetech.modules.smartpads = new practicetech.createNew.module(): "";
        },
        render: function (options) {
            try {
                var that = this,
                    pinnedId,
                    fmid = CommonUtilis.readCookie('FMID'),
                    _savedState;
                this.fmId = options.fmId;
                this.options = options;
                this.pinnedContact.pinnedContactType = options.selectedContactType;                
                var tmpTemplate = _.template(SmartpadListTemplate);
                this.createStateModuleIfNeeded();
                _savedState = practicetech.modules.smartpads.state;
                that.$el.html("");
                if (self.contctDetails) {
                    gotoSmartPadList(self.contctDetails, options.houseHoldId);
                } else {
                    if (this.pinnedContact.pinnedContactType == Constants.contactType.NonClient) {
                        this.pinnedContact.pinnedContactId = options.selectedContactId;
                        Dataservice.getContactDetailsbyContactId(CommonUtilis.readCookie('FMID'), this.pinnedContact.pinnedContactId)
                            .then(function (resp) {
                                gotoSmartPadList(resp, options.houseHoldId);
                            })
                            .fail(gotoError);
                    }
                    else {
                        this.pinnedContact.pinnedClientId = options.selectedContactId;                    
                        if (this.pinnedContact.pinnedClientId!=undefined) {
                                Dataservice.getContactDetailsbyClientId(CommonUtilis.readCookie('FMID'), this.pinnedContact.pinnedClientId)
                                    .then(function (resp) {
                                        gotoSmartPadList(resp, options.houseHoldId);
                                    })
                                    .fail(gotoError);
                        }                    
                    }
                }
                     
                function gotoSmartPadList(contctDetails, householdId) {
                    self.contctDetails = contctDetails;
                    pinnedId = contctDetails[0].get("contactId");
                    var _opts,
                        _dropdownClientOptn = {
                            "type": "client",
                            "id": pinnedId,
                            "label": "Current client"
                        },
                        _grpMenuOptions = [_dropdownClientOptn];
                	Spinner.show();
                	_opts = {
                        "fmid": fmid,
                        "pinnedId": pinnedId,
                        "dropdownMenuOptions": _grpMenuOptions
                    }
                	if (pinnedId) {
                	    if (that.houseHoldGroups) {
                	        _opts.dropdownMenuOptions.push.apply(_opts.dropdownMenuOptions, self.getDropdownGroupOptions(self.houseHoldGroups));
                	        if (householdId) {
                	            _opts.householdId = householdId;
                	        }
                	        getSmartpadList(_opts);
                	    } else {
                	        Dataservice.getHouseHoldGroup(fmid, pinnedId).then(gotoHouseHoldGroupSuccess).fail(gotoError);
                	    }
                        
                    }else{
                	    var smartpadList = { "smartpadList": [] };
                	    that.$el.html(tmpTemplate(smartpadList));
                	    Spinner.hide();
                    }
                    
                    function gotoHouseHoldGroupSuccess(houseHoldGroups) {
                        var houseHoldGroupOptions = "", _dropOption;
                        if (houseHoldGroups[0] != null && houseHoldGroups[0].attributes.HouseHoldGroupList != undefined) {
                            var _houholdGrps = houseHoldGroups[0].get('HouseHoldGroupList'),_dropdowngrpOptions;
                            that.houseHoldGroups = _houholdGrps;
                            if (_houholdGrps.length > 0) {
                                _dropdowngrpOptions = self.getDropdownGroupOptions(_houholdGrps);
                                _opts.dropdownMenuOptions.push.apply(_opts.dropdownMenuOptions, _dropdowngrpOptions);
                                _opts.householdId = _houholdGrps[0].get('householdId');
                            }
                            if (_savedState && _savedState.remember && self.validateMemoryRestoreCondition()) {
                                if (_savedState.selectedDropdownType == "group" && _houholdGrps.length > 0) {
                                    _opts.householdId = _savedState.selectedDropdownId;
                                } else {
                                    _opts.householdId = null;
                                }
                            }
                            getSmartpadList(_opts);
                        }
                        else {
                            getSmartpadList(_opts);
                        }
                       
                        
                    }
                    function getSmartpadList(opts){
                        if (opts.householdId) {
                            self.selectedDropdownId = opts.householdId;
                            self.selectedDropdownType = "group";
                            Dataservice.getSmartPadListByGroup(opts.fmid, opts.pinnedId, opts.householdId).then(gotoSmartPadListSuccess).fail(gotoError);
                        } else {
                            self.selectedDropdownId = opts.pinnedId;
                             self.selectedDropdownType = "client";
                            Dataservice.getSmartPadList(opts.fmid, opts.pinnedId).then(gotoSmartPadListSuccess).fail(gotoError);
                        }
                    }
                    function gotoSmartPadListSuccess(smartpadList) {
                        var smartpadList = {
                                "smartpadList": smartpadList[0].get('SmartPadNoteList'),
                                dropdownMenuOptions: _opts.dropdownMenuOptions
                        };
                        that.$el.html(tmpTemplate(smartpadList));
                        highlightSelectedDropDownOption();
                        self.loadFromSavedState();
                        Spinner.hide();
                    }
                    function highlightSelectedDropDownOption() {
                        var _$dropdownSelectedLabel = $('#cm-group-dropdown'),
                            _$dropdownSlectedoption = $("a[data-id='" + self.selectedDropdownId + "']");
                        _$dropdownSelectedLabel.text(_$dropdownSlectedoption.find('span').text());
                    }
                };
                function gotoError(Error) {
                	Spinner.hide();
                	ErrorLog.ErrorUtils.myError(Error);
                };
                
               // var contactId = "Contact.300287.3406";

            }
            catch (error) {
                ErrorLog.ErrorUtils.myError(error);
            }
        },
        handleCMGroupChange: function (e) {
            e.preventDefault();
            var _$selectedOption = $(e.currentTarget),
                _slectedType = _$selectedOption.data("optionType"),
                _slectedId = _$selectedOption.data("id"),
                _houleholdId;
            if (this.selectedDropdownId == _slectedId) {
                return;
            }
            if (_slectedType == "group") {
                _houleholdId = _slectedId;
            }
            self.options.houseHoldId = _houleholdId;
            self.render(self.options);
        },
        getDropdownGroupOptions: function (hoseholdgrps) {
            var _dropdownOption, _dropdownOptions = [];
            $.each(hoseholdgrps, function (key, value) {
                _dropdownOption = {
                    "type": "group",
                    "id": value.get('householdId'),
                    "label": value.get('householdName')
                };
                _dropdownOptions.push(_dropdownOption);
            });
            return _dropdownOptions;
        },
        saveState: function (smartpadId) {
            var _state = {
                "selectedSmartpad": smartpadId,
                "selectedSmartpadContainer": "[data-scroll-id='" + smartpadId + "']",
                "selectedDropdownId":  this.selectedDropdownId,
                "selectedDropdownType": this.selectedDropdownType,
                "remember":true
            };
            practicetech.modules.smartpads.state = _state;
        },
        loadFromSavedState: function () {
            var _state = practicetech.modules.smartpads ? practicetech.modules.smartpads.state : { },
                _historyFragment = Backbone.history.list.slice(-2)[0], 
                _$selectedSmartpadContainer;
            if (_state && _state.remember && this.validateMemoryRestoreCondition()) {
                _$selectedSmartpadContainer = $(_state.selectedSmartpadContainer);
                try{
                    if (_$selectedSmartpadContainer.length > 0) {
                        $(window).scrollTop(_$selectedSmartpadContainer.offset().top);
                    }
                        
                } catch (e) {
                    ErrorLog.ErrorUtils.myError(Error);
                    practicetech.modules.smartpads.state = { };
                }
            }
            practicetech.modules.smartpads.state = {};
        },
        validateMemoryRestoreCondition: function () {
            var _historyFragment = Backbone.history.list.slice(-2)[0], 
                _restoreFlag = false;
            if (_historyFragment && (_historyFragment.indexOf("crm/addsmartpad") != -1 || _historyFragment.indexOf("crm/notedetail") != -1 || _historyFragment.indexOf("crm/editsmartpad") != -1)) {
                _restoreFlag =  true;
            }
            return _restoreFlag;
        },
        handleAddSmartpadNoteNavigation: function () {
            this.saveState();
            location.hash = 'crm/addsmartpad';
        }
    });
    return smartpadlist;
});
