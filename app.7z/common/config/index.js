'use strict';

// Filenames for Constants are always UPPERCASE
// You can have as many files for config as you require (ex: USER_ROLES, NOTIFICATIONS, etc)
// Constants are injected into controllers like any service or resource
module.exports = angular.module('common.constants', [])
	.config(require('./messages'))
    .constant('constants', require('./constants'))
    .constant('appConfig', require('./appConfig'))
    .constant('eventConstants', require('./eventConstants'))
    .constant('errorConstants', require('./errorConstants'))
    .constant('loggerConstants', require('./loggerConstants'))
    .factory('events', require('./events.service'))
;