/**
 * @ngdoc property
 * @name Fund Card Directive
 * @requires $state
 * @description
 *
 *
 **/
'use strict';

var FundCardsModel = function($state) {
	return {
            template: require('./fundCardsModel.html'),
            restrict: 'E',
            replace: true,
            link: function(scope, iElement, iAttrs, controller){
                
            }
        };
};

FundCardsModel.$inject = [];
module.exports = FundCardsModel;