// purchasesHistory.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called
'use strict';
var mongoose = require('mongoose');

var PurchasesHistorySchema = new mongoose.Schema({
    PurchasesHistoryDetails: {
        type: Array,
        'default': []
    }
});

var PurchasesHistoryLookUp = mongoose.model('PurchasesHistoryLookUp', PurchasesHistorySchema);

var PurchasesHistory = new PurchasesHistoryLookUp({
    'PurchasesHistoryDetails': [{
        'purchase': {
            'fundWiseData': [{
                'processDate': '03 Mar 2008',
                'processAmount': '5,000.00',
                'nav': '32.6798',
                'units': '153',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '04 Mar 2008',
                'processAmount': '5,000.00',
                'nav': '32.1494',
                'units': '155.524',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '07 Mar 2008',
                'processAmount': '5,000.00',
                'nav': '31.1717',
                'units': '160.402',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '13 Mar 2008',
                'processAmount': '5,000.00',
                'nav': '30.0679',
                'units': '166.29',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '17 Mar 2008',
                'processAmount': '5,000.00',
                'nav': '28.7254',
                'units': '174.062',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '26 Sep 2008',
                'processAmount': '5,000.00',
                'nav': '26.7389',
                'units': '186.993',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '29 Sep 2008',
                'processAmount': '5,000.00',
                'nav': '26.145',
                'units': '191.241',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }, {
                'processDate': '08 Oct 2008',
                'processAmount': '10,000.00',
                'nav': '24.1198',
                'units': '414.597',
                'status': 'Processed',
                'drAccNo': '0029902884303'
            }],
            'fundInfo': {
                'fund': 'Franklin India Prima Plus - Dividend',
                'accountNo': '0029902884303',
                'folioId': '16286393',
                'modeOfHolding': 'Anyone Or Survivor',
                'goal': '',
                'goalDetails': '',
                'distId': ''
            }
        }
    }]
});

PurchasesHistoryLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating PurchasesHistoryLookUp table, please contact admin...');
    } else {
        PurchasesHistoryLookUp.remove({}, function(err) {
            console.log('PurchasesHistoryLookUp collection removed' + err);
            PurchasesHistory.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating PurchasesHistoryLookUp table, please contact admin...');
                }
                console.log('PurchasesHistoryLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = PurchasesHistoryLookUp;
