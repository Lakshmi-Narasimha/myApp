
function commissionSipController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel,calculatorsEventConstants, calculatorsConstants) {
  $scope.selectOptions = {
      "Frequency" : []
  };
  $scope.calculatorReq = {};
  $scope.selectOptions.Frequency = [
  {
    title: "Select Frequency"
},
{
  title:"Monthly"   
},
{
  title: "Quarterly"
}
]; 
$scope.inputObject = {
    Frequency :{
        required:true,
        name : "freqSelection",
        label: "Select Frequency"
    }
};
$scope.userInput= { 
    Tenure : {
        key: "", 
        text: "Investment Tenure",
        value: "",
        pattern:/^[0-9]*$/,
        message: "",
        isMasked: false,
        isRequired: false ,
        type: "number"                     
    },
    InstallAmt : {
        key: "", 
        text: "Investment Amount <span class='icon-fti_rupee'></span>",
        value: "",
        pattern:/^[0-9]*$/,
        message: "",
        isMasked: false,
        isRequired: true ,
        // maxlength: 6 ,
        type: "number"                     
    }
};
$scope.$on('fundType', function(event, fundName) { 
    $scope.fundName = fundName;
});
$scope.$on('selectedFrequency', function(event, data){
    $scope.fundFrequency = data.title;
});
$scope.onSubmit = function() {
   $scope.$emit(calculatorsEventConstants.RESET_CHART);
   if($scope.userInput.InstallAmt.value < 500 || $scope.userInput.InstallAmt.value >999999 || $scope.userInput.Tenure.value >40|| ($scope.userInput.Tenure.value != null && $scope.userInput.Tenure.value < 1)) {
    return;
}
else {
    $scope.calculatorReq = [{
        "trxnType" : "SIP & Lumpsum",
        "fundCode" : $scope.fundCode,
        "invstTenure" : $scope.userInput.Tenure.value,
        "grossSales" :$scope.userInput.InstallAmt.value,
        "fundFrequency" :$scope.fundFrequency,
    }];
    $scope.$emit(calculatorsEventConstants.COMMISSION_CALCULATE_SUBMIT,$scope.calculatorReq);
}
};
$scope.resetForm = function () {
   $scope.tab = "sip";
   $scope.$emit(calculatorsEventConstants.RESET_DATA, $scope.tab);
   $scope.userInput.Tenure.value = "";
   $scope.userInput.InstallAmt.value = "";
   $scope.calculatorReq = {};

}        
}
commissionSipController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsEventConstants', 'calculatorsConstants'];
module.exports = commissionSipController;