    /**
 * @ngdoc property
 * @name ModifySipTxnDetController
 * @requires $scope
 * @requires TransactConstant
 * @description
 *
 * - modifysipTxnDetails
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function ModifySipTxnDetController($scope, $timeout, TransactConstant, ftiModifySipInitialLoader, transactEventConstants,transactModel,$state,$filter) {    
	
    var invDetails = transactModel.getTransactDetails().investorDetails;
    var fundDetails = transactModel.getTransactDetails().fundDetails;
    var transactionreferenceDetails = transactModel.getTransactConfirm(); 
    var sipDetails = transactModel.getTransactDetails().modifySipDetail;
    $scope.sipModifyDetailsObject= [];
  	$scope.transactHeading = {
        heading : 'Transaction Details'
    };
    var stepUpPerc = " ";
    
    if (sipDetails.sipModifyType == "Sip_Amt_Change"){
        $scope.modifiedSipvalue = "<span class='icon-fti_rupee'></span>" + " " + sipDetails.newSipAmount + " " + $filter('translate')(TransactConstant.modifySip.EFF_FOR_INST_FROM) + " " + sipDetails.strtDate;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.New_SIP_Amount);
    }else if(sipDetails.sipModifyType == "Step_Up_Sip"){
        $scope.modifiedSipvalue = sipDetails.strtDate +  " -" + sipDetails.stepUpDateDesc;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.EFF_FROM);
        if(sipDetails.stepUpType === "P"){
            stepUpPerc = "(<span class='icon-fti_rupee'></span> " + sipDetails.stepUpValAmnt + " )";
        }
        $timeout(function(){
            $scope.sipModifyDetailsObject.push({
                text: "Step-up SIP by",
                value: sipDetails.stepUpVal + " Annually " + stepUpPerc
            })
        },0)        
    }else if(sipDetails.sipModifyType == "Flexi_Sip"){
        $scope.modifiedSipvalue = "<span class='icon-fti_rupee'></span>" + sipDetails.newSipAmount + " " + $filter('translate')(TransactConstant.modifySip.EFF_ONLY_FOR_INST) +" " + sipDetails.strtDate;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.New_SIP_Amount);
    } else if(sipDetails.sipModifyType == "Sip_Date_Change"){
        $scope.modifiedSipvalue = sipDetails.strtDate;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.New_SIP_Date);
    } else if(sipDetails.sipModifyType == "Sip_Pause"){
        $scope.modifiedSipvalue = sipDetails.strtDate;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.SIP_Pause_Date);
    } else if(sipDetails.sipModifyType == "Sip_Cancel"){
        $scope.modifiedSipvalue = sipDetails.strtDate;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.SIP_Cancel_Eff_Date);
    } else if(sipDetails.sipModifyType == "Step_Up_Cancel"){
        $scope.modifiedSipvalue = sipDetails.strtDate;
        $scope.modifiedSipLabel = $filter('translate')(TransactConstant.modifySip.Step_Up_Cancel_Eff_Date);
    }

    $scope.sipModifyDetailsObject= [
        {
            text: "Folio No.",
            value: invDetails.folioId
        },
        {  
            text: "First Holder Name",
            value: invDetails.custName
        },
        {
            text: "Account No.",
            value: fundDetails.accountNumber
        },
        {
            text: "Fund",
            value: fundDetails.fundOptionDesc
        },
        {
            text: "Transaction Reference Number",
            value: transactionreferenceDetails.transactionRefNo
        },
        {
            text: "Request Date and Time",
            value: transactionreferenceDetails.transDateTime
        },
        {
            text: $scope.modifiedSipLabel,
            value: $scope.modifiedSipvalue
        }
    ];

    $scope.redirect = function () {
        transactModel.resetSetters(); 
        transactModel.isNewInvestor = false;
        $state.go("transact.base.modifysip");
    }
}

ModifySipTxnDetController.$inject = ['$scope', '$timeout', 'TransactConstant', 'ftiModifySipInitialLoader', 'transactEventConstants','transactModel','$state','$filter'];
module.exports = ModifySipTxnDetController;