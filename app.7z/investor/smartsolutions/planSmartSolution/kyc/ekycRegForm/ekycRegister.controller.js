'use strict';
// Controller naming conventions should start with an uppercase letter

function ekycRegstrController($scope, $state, transactModel) {
    console.info("Ekyc Register Controller!!");
    $scope.isFirstAccordianOpened = {};
    $scope.isFirstAccordianOpened.open = true;
    $scope.header.title = "E-KYC";
    $scope.showError = false;
    $scope.holderData = [];
    $scope.fromStateVariable = transactModel.getTransactType();
    console.log("$scope.fromStateVariable....", $scope.fromStateVariable);
    // $scope.formMaha = formEkyc.cntryObject.value;
    // console.log("formMaha....", $scope.formMaha);
    
    $scope.holderData = transactModel.getInstantKyc();
    angular.forEach($scope.holderData,function(obj,k){        
        if(obj.name == null && obj.type == "Firstholder")
        {
            var dtls = {
                custName: "",
                pan:"",
                emailId:"",
                mobile:"",
                holders : [
                    {
                        name : ""
                    },
                    {
                        name : ""
                    },
                    {
                        name : ""
                    }
                ]
            }
            transactModel.setInvestorDetails(dtls);            
        }

    })
    $scope.formDataObject=[];
    console.log("holderDataTitle....", $scope.holderData[0].Title);
    console.log("holderData.....", $scope.holderData);
    $scope.checkEkyc = function(){
  	  // $scope.$broadcast('goEkycDirec');
      /*angular.forEach($scope.holderData, function(arg, key){

      });*/
      if($scope.kycForm.$valid){
        // if($scope.fromStateVariable == "BUYFUND"){
        //     $state.go('transact.base.buy', {key:"Fund"});
        // }
        // else{
        //     $state.go('transact.base.sip', {key: "Fund"});
        // }
        // $state.go("smartSol.planSmartSolution.ssBase");
         $state.go("smartSol.planSmartSolution.ssBase.planInputDetails");
      }
      else{
        
      }
	    console.log("validations");
    }
  
}

ekycRegstrController.$inject = ['$scope', '$state', 'transactModel'];
module.exports = ekycRegstrController;