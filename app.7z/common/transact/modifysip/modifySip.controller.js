/**
 * @ngdoc property
 * @name modifySip Controller
 * @requires $scope
 * @requires TransactConstant
 * @description
 *
 * -
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function modifySipController($scope, bankDtlsModel, TransactConstant, ftiModifySipInitialLoader, transactEventConstants,SipModifyDetailModel,transactModel,$filter,$state,toaster,authenticationService) {
    
    transactModel.isModifySip = true;
    $scope.header.title = TransactConstant.modifySip.MODIFY_SIP_HEADING;
    $scope.config.txnFormDetails.title = "SIP Modification Details";
    $scope.config.toTxnDetailsState = "transact.txnDetails.modifysip";
    $scope.$on(transactEventConstants.transact.Set_Modify_Sip_Details,function(event,data){
        var datefilter = $filter('date');
        var modifySipDetailModel = {};
        modifySipDetailModel.investorDetails = transactModel.getInvestorDetails();
        modifySipDetailModel.fundDetails = transactModel.getFundDetails();
        modifySipDetailModel.modifySipDetail = SipModifyDetailModel.getModifySipDetails();
        var bankDetail = modifySipDetailModel.fundDetails.bankDetails;
        var bankDetailsArray = bankDetail.split("/");
        transactModel.setTransactDetails(modifySipDetailModel);
        var transactionDetails = {
            "refTxn":modifySipDetailModel.fundDetails.transactionNum,
            "folioId":modifySipDetailModel.investorDetails.folioId || "",
            "startDate":datefilter(Date.parse(modifySipDetailModel.fundDetails.sipStartDate), 'dd/MM/yyyy') || "",
            "endDate":datefilter(Date.parse(modifySipDetailModel.fundDetails.sipEndDate), 'dd/MM/yyyy') || "",
            "frequency":modifySipDetailModel.fundDetails.frequency ==='Monthly' ? "M" :(modifySipDetailModel.fundDetails.frequency === "Annually" ? "A" : (modifySipDetailModel.fundDetails.frequency === "Quaterly" ? "Q" : modifySipDetailModel.fundDetails.frequency)),
            "units":modifySipDetailModel.fundDetails.amount || "",
            "batchCode":TransactConstant.common.BATCH_CODE,
            "accountNo":modifySipDetailModel.fundDetails.accountNumber || "",
            "fundOption":modifySipDetailModel.fundDetails.fundOption || "",
            "effectiveDate": datefilter(Date.parse(modifySipDetailModel.modifySipDetail.strtDate),'dd/MM/yyyy'),
            "stepUpType": modifySipDetailModel.modifySipDetail.stepUpType || "",
            "stepUpValue": modifySipDetailModel.modifySipDetail.stepUpSip || "",
            "amount": modifySipDetailModel.modifySipDetail.newSipAmount ? modifySipDetailModel.modifySipDetail.newSipAmount.toString() : "0",
            "txnSource": modifySipDetailModel.modifySipDetail.txnSource,
            "source": TransactConstant.common.USER_TYPE_ADVISOR,
            "paymentMode": modifySipDetailModel.fundDetails.paymentMode || "",
            "emFrequency": modifySipDetailModel.fundDetails.achFrequency || "",
            "emAmount": modifySipDetailModel.fundDetails.achAmount || "",
            "bankAccountNumber": bankDetailsArray[1],
            "bankName": bankDetailsArray[0],
            "emFromDate": modifySipDetailModel.fundDetails.achFromDate || "",
            "emToDate": modifySipDetailModel.fundDetails.achToDate || "",
            "dayFlag" : modifySipDetailModel.modifySipDetail.dayFlag ? modifySipDetailModel.modifySipDetail.dayFlag.toString() : "", 
            "webRefNo" : "",
            "dividendOption" : modifySipDetailModel.fundDetails.dividendFlag || "",
            "perpetualFlag" : modifySipDetailModel.fundDetails.perpetualFlag || ""
        };

        var datefilter = $filter('date');
        var today = new Date();
        $scope.requestDateAndTime = datefilter(today, 'dd MMMM yyyy, hh:mm a');
        console.log(transactionDetails);
        SipModifyDetailModel.postModifyTransactDetails(transactionDetails).then(postSuccess, handleFailure);

        function postSuccess(data) {
            var transConfirm = {
                "transactionRefNo" : data.Reference_Number,
                "transDateTime" : $scope.requestDateAndTime
            };
            transactModel.setTransactConfirm(transConfirm);
            if(authenticationService.isInvestorLoggedIn()){
                $state.go('invTransact.txnDetails',{stateType: $state.current.url.toString().substring(1, $state.current.url.toString().length)}); 
            }else{
                $state.go($scope.config.toTxnDetailsState);
            }
            
        }
        function handleFailure(data) {
            /*toaster.error(data.data[0].errorDescription)*/
        }

    })
    $scope.$on(transactEventConstants.transact.Payment_Detail,function(event,data){
        $scope.isPaymentDetails = true;
        $scope.$emit("paymntDtls");
    })
   
    
}

modifySipController.$inject = ['$scope','bankDtlsModel', 'TransactConstant', 'ftiModifySipInitialLoader', 'transactEventConstants','SipModifyDetailModel','transactModel','$filter','$state','toaster','authenticationService'];
module.exports = modifySipController;