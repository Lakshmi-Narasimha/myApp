/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function InvPaymentDetailsController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout,transactModel, planSmartSolution, fundDetailsModel, fundDetails, $stateParams, eventConstants, toaster, authenticationService) {
		
 	$scope.showBoth = false;
    $scope.showLumpsum = false;
    $scope.showSip = false;
    $scope.isFromPaperLess = transactModel.isPaperLess;
    transactModel.isLumpsumValidated = false;
    transactModel.isSipValidated = false;

    if(planSmartSolution.getTransactType()==='Lumpsum')
    {
    	$scope.showLumpsum = true;
    }
    else if(planSmartSolution.getTransactType()==='SIP')
    {
    	$scope.showSip = true;
    }
    else if(planSmartSolution.getTransactType()==='Combo')
    {
    	$scope.showBoth = true;
    }

    //Checking for state params in case of edit

    if($stateParams.key){

		
    }else{

    }
       
    $scope.showInvDtls = false;
    $scope.showBack = false;
    $scope.showHeader = false;
    $scope._currentState = $state.current.name;
    if($scope._currentState === 'smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS'){
		$scope.showInvDtls = true;    	
		$scope.showBack = true;
		$scope.showHeader = true;
    }

	$scope.pdBackBtn = function(){		
		$state.go('smartSol.planSmartSolution.fundDetailsSS'); 
	};


	$scope.$on('validated',function(event,data){		
		if(!$scope.showBoth || ($scope.showBoth&&data.isBothValidated))
		{
			if($scope._currentState === 'smartSol.planSmartSolution.invProceedToBuy.paymentdetailsSS'){
				//$scope.reviewDtls.reviewDtlsState = 'smartSol.planSmartSolution.reviewnconfirm.investment';			
				$state.go('smartSol.planSmartSolution.invProceedToBuy.reviewnconfirm');
            }
			// }else if($scope.paymentDtls.paymentDtlsState === 'paperLess.transact.paymentDtls.smartPaymentDtls.investment'){
			// 	$scope.$emit(eventConstants.PAPERLESS_VALIDATED);			
			// }else if($scope.paymentDtls.paymentDtlsState === 'transactnow.baseNow.smartSolTransact.paymentDetails'){
			// 	transactModel.setInvestorDetails(transactModel.getSelectedFolioDts());				
			// 	$state.go('transactnow.reviewNow.smartSol');
			// }
		}		

		if(data.transactType === 'BUY')
		{			
			toaster.success('We have successfully validated your lumpsum details.');
			$scope.$broadcast('openSipAccordion');					
		}
		else if(data.transactType === 'SIP')
		{			
			toaster.success('We have successfully validated your sip details.');
			$scope.$broadcast('openLumpsumAccordion');			
		}
	});

}

InvPaymentDetailsController.$inject = ['$scope', '$state', 'keyValueGridConfig','TransactConstant', 'buildPlanModelService','$timeout','transactModel', 'planSmartSolution', 'fundDetailsModel', 'fundDetails', '$stateParams', 'eventConstants', 'toaster', 'authenticationService'];
module.exports = InvPaymentDetailsController;