// productDetails.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ProductDetailsSchema = new mongoose.Schema({
    ProductDetails: {
        type: Array,
        "default": []
    }
});

var ProductDetailsLookUp = mongoose.model('ProductDetailsLookUp', ProductDetailsSchema);
/*json order: investor book-*/
var productDetailsModel = new ProductDetailsLookUp({
  "ProductDetails": [
  {
    "label": "Time value of money & when to start investement",
    "id": 1,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 2,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 3,
    "data":"https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 4,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "investing in equalites",
    "id": 5,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 6,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 7,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 8,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 9,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 10,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "investing in equalites",
    "id": 11,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 12,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 13,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 14,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 15,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 16,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 17,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "investing in equalites",
    "id": 18,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 19,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 20,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 21,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 22,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 23,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 24,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "investing in equalites",
    "id": 25,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 26,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 27,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 28,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 29,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 30,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 31,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "investing in equalites",
    "id": 32,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 33,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 34,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 35,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 36,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 37,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 38,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "investing in equalites",
    "id": 39,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "Tax saving funds & their benefits",
    "id": 40,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 41,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "Time value of money & when to start investement",
    "id": 42,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  },
  {
    "label": "Are you saving or are you investing",
    "id": 43,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"brochures"
  },
  {
    "label": "How to select a mutual fund?",
    "id": 44,
    "data" : "aGkgbXkgbmFtZSBpcyBhbmluZA==",
    "type":"presentation"
  },
  {
    "label": "benifits of invetsing in mutual funds",
    "id": 45,
    "data" : "https://www.youtube.com/embed/0kmdjqgO9IY",
    "type":"video"
  }
]
});

ProductDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ProductDetailsLookUp table, please contact admin...');
    } else {
        ProductDetailsLookUp.remove({}, function(err) {
            console.log('ProductDetailsLookUp collection removed');
           productDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ProductDetailsLookUp table, please contact admin...');
                }
                console.log('ProductDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ProductDetailsLookUp;
