/* eslint-disable */
'use strict';

/*Unit test case for fticFooter*/

describe('directive: fticHeader', function() {

    var scope, compile, validHTML, httpBackend, timeout,
    utilityNav = {
   "utilityNav":[
      {
         "AboutUs":[
            {
               "text":"About Us",
               "menuitem":"aboutus",
               "submenu":[
                  {
                     "text":"The Franklin Templeton Story",
                     "url":""
                  },
                  {
                     "text":"Franklin Templeton India",
                     "url":""
                  },
                  {
                     "text":"Global Office",
                     "url":""
                  },
                  {
                     "text":"CSR Initiatives India",
                     "url":""
                  }
               ]
            }
         ],
         "Resources":[
            {
               "text":"Resources",
               "menuitem":"resources",
               "submenu":[
                  {
                     "text":"Fund Documents",
                     "url":""
                  },
                  {
                     "text":"Fund Literature",
                     "url":""
                  },
                  {
                     "text":"Forms &amp; Instructions",
                     "url":""
                  },
                  {
                     "text":"Updates",
                     "url":""
                  }
               ]
            }
         ],
         "country":[
            {
               "text":"",
               "image":"images/fti_country_india.png",
               "menuitem":"country",
               "submenu":[
                  {
                     "text":"India",
                     "url":""
                  }
               ]
            }
         ]
      }
   ],
   "header":[
     {
       "header_logo": "images/fti_logo.png",
       "alt": "Franklin Templeton Investments"
     }
   ]
};

    validHTML = '<ftic-header></ftic-header>';
    beforeEach(angular.mock.module('common','common.elements.ftiHeader'));

    beforeEach(angular.mock.inject(function($compile, $rootScope, $httpBackend, $timeout) {
        httpBackend = $httpBackend;
        timeout = $timeout;
        scope = $rootScope.$new();
        compile = $compile;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();
        return compiledElem;
    }

    it('should not create seperate isolated scope', function() {
        httpBackend.expectGET('jsonservices/utilityNav.json').respond(200, utilityNav);
        var el = create(),
        isoScope = el.isolateScope();
        timeout.flush();
        httpBackend.flush();
        expect(isoScope).toBeUndefined();
    });


});
