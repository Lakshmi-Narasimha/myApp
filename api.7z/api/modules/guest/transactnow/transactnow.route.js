var express = require('express'),
    router = express.Router(),
    UnitHolderDetailsModel = require('./unitHolderDetail/unitHolderDetails.model'),
    FolioDetailsModel = require('./folioDetails/folioDetails.model'),
    RenewSip = require('./renewSip/renewSip.model');
    nachFormModel = require('./nachForm/nachForm.model');
    
    

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */

router.route('/getUnitHolderDetails')
.get(function (req, res) {
    UnitHolderDetailsModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].unitHolderDetailsObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].unitHolderDetailsObject);
        }
    });

});

router.route('/getNachFormPDF')
.get(function (req, res) {
    nachFormModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].nachFormObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].nachFormObject);
        }
    });

});

router.route('/getSipDetails')
.get(function (req, res) {
    RenewSip.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].renewSipDetailsObject.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].renewSipDetailsObject);
        }
    });

});

router.route('/getFolioDetail')
.get(function (req, res) {
    FolioDetailsModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].folioDetailsResp.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].folioDetailsResp);
        }
    });

});

//Adding this route for Investor
router.route('/transact/fetchPanFolios')
.get(function (req, res) {
    FolioDetailsModel.find(function (err, data) {
        // if there is an error retrieving, send the error. 
        // nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        } else if (data[0].folioDetailsResp.length === 0) {
            res.send(error);
        } else {
            res.json(data[0].folioDetailsResp.result);
        }
    });

});
   
module.exports = router;
