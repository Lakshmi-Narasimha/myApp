'use strict';

module.exports = angular.module('common.elements.ftiFooter', [])
    .directive('fticFooter', require('./footer.directive'))
    .controller('footerCtrl', require('./footer.controller'))
    ;