/**
 * @ngdoc directive
 * @name  fticInvDbSmartSolutions 
 * @requires fticCarousel
 * @requires fticInvDbSsTile
 * @requires investorEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * -  fticInvDbSmartSolutions will display smart solutions and goals for "Investor Smart Solutions".
 *
 **/

'use strict';

var invDbSmartSolutions = function(dashboardConstants, investorEventConstants, investorDashboardDetailsModel, loggerConstants, fticLoggerMessage) {
    return {
        template: require('./invDbSmartSolutions.html'),
        restrict: 'E',
        replace: true,
        scope: true,
        link: function(scope) {
            scope.smartSol = {
                dataAvailable: false,
                goals: [],
                showGrid: false,
                hasInvestedInGoal: false,
                headerConfig: {
                    heading: dashboardConstants.dashboard.SMART_SOLUTIONS,
                },
            };
            var destroySmartSolEvent;
            var smartSolEvent = scope.$on(investorEventConstants.Dashboard.INV_DB_SMART_SOLUTIONS, function() {

                var message = loggerConstants.INVESTOR_APP + ' | ' + loggerConstants.INV_DASHBOARD_MODULE + ' | ' + loggerConstants.INV_SMART_SOLUTIONS_DIRECTIVE + ' | on ' + investorEventConstants.Dashboard.INV_DB_SMART_SOLUTIONS + ' event' /* Function Name */ ;
                fticLoggerMessage.displayLoggerMessage({ level: 'info', 'message': message });
               
                var response = investorDashboardDetailsModel.getSmartSolutions() || {};
                scope.smartSol.dataAvailable = (response.smartSolutionGoals && response.smartSolutionGoals.length) ? true : false;
                scope.smartSol.showGrid = response.hasGoals === 'Y' ? true : false;
                scope.smartSol.goals = response.hasGoals ? (response.smartSolutionGoals) : [];

                destroySmartSolEvent();
            });
            destroySmartSolEvent = function() {
                smartSolEvent();
            };
        }
    };
};

invDbSmartSolutions.$inject = ['dashboardConstants', 'investorEventConstants', 'investorDashboardDetailsModel', 'loggerConstants', 'fticLoggerMessage'];
module.exports = invDbSmartSolutions;
