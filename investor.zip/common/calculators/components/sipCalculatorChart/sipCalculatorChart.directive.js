/**
 * @ngdoc property
 * @name fticSipCalculatorForm Directive
 * @description
 *
 * fticSipCalculatorChart directive 
 *
 **/
 'use strict';

 var fticSipCalculatorChart = function($state, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel, calculatorsEventConstants) {
  return {
    template: require('./sipCalculatorChart.html'),
    restrict: 'E',
    replace: true,
    scope: {},
    controller: function($scope, $element, $attrs) {
      $scope.init = function() {
        $scope.mailbackOptions = {
          text: ""
        }
      }
      $scope.init();

      $scope.$on(calculatorsEventConstants.FUND_DETAILS_CHART, function(event) {
        var sipcal = sipCalculatorModel.getSipCalculations()[0];
        $scope.sipCalculatorChartSeries = null;
        // $scope.sipcal = getSipCalculations();
        // $scope.test ="main";
        $scope.investedAmount = sipcal.investedAmount;
        $scope.investedTenure = sipcal.investedAmountAtTenure;

        $scope.data = sipcal.returnData;
        $scope.setData = function() {
          $scope.seriesNames = [];
          $scope.periodicData = [];
          $scope.seriesData = [];
          $scope.category =[];
          for (var i = 0; i < $scope.data.length; i++) {
            $scope.seriesNames.push($scope.data[i].returnType);
            $scope.periodicData.push($scope.data[i].periodicReturnData);
          }
          $scope.dataSeries = [];
          $scope.investedAmountSeries = [];
          for (var i = 0; i < $scope.periodicData.length; i++) {
            $scope.seriesData[i] = $scope.periodicData[i];
            $scope.dataSeries[i] = [];
            $scope.dataSeries[i].investedAmount =[];
            for (var j = 0; j < $scope.seriesData[i].length; j++) {
              var seriesdata = $scope.seriesData[i];

              $scope.dataSeries[i].push(parseFloat(seriesdata[j].valueOfAmount));
              $scope.dataSeries[i].investedAmount.push(seriesdata[j].investedAmount);
            }
          }

          for (var j = 0; j < $scope.seriesData[0].length; j++) {
            var seriesValues = $scope.seriesData[0];

            $scope.category.push(parseFloat(seriesValues[j].duration));
          }

          $scope.finalDataSeries = [];
          for (var i = 0; i < $scope.dataSeries.length; i++) {

            $scope.finalDataSeries.push({
              name: $scope.seriesNames[i],
              data: $scope.dataSeries[i],
              marker: {
                symbol: 'square',
                radius: 5
              }
            });

          }

        }
        $scope.setData();

        $scope.sipCalculatorChartSeries = {
          chart: {
            type: 'line',
            backgroundColor: '#fff',
            renderTo: 'container'
          },
          title: {
            text: ''
          },
          legend: {
            layout: 'horizontal',
            floating: false,
            symbolHeight: 25,
            itemDistance: 25,
            itemMarginTop: 13
          },
          xAxis: {
            categories: $scope.category,
            labels: {
              format: '{value} years',

            },
            title: {
              text: 'Investment Period',
              align: 'middle',
              style: {
                "fontSize": "15px",
                "font-family": "Trade Gothic W01 Roman",
                "color" : "#333"
              }
            }
          },
          yAxis: [{
            title: {
              text: 'Value of Investment'
            }
          }],
          tooltip: {
            // shared: true,
            // crosshairs: true
            useHTML: true,
            formatter: function() {
              var value;
              for(var i=0;i<this.series.userOptions.data.length;i++) {
                if(this.y == this.series.userOptions.data[i]) {
                  value= i;
                  break;
                }
              }
              return '<b> ' + this.x + 'years since your investment </b></br>' + 'Invested amount   :  <span class="icon-fti_rupee">' + this.series.userOptions.data.investedAmount[value] + ' </br> Value of Investments : <span class="icon-fti_rupee">' + this.y;
            }
          },
          plotOptions: {

          },

          series: $scope.finalDataSeries


        }
      });

      $scope.$on(calculatorsEventConstants.RESET_DATA, function(event) {
        $scope.sipCalculatorChartSeries = false;
        $scope.investedAmount = "";
        $scope.investedTenure = "";
      });
    },
    link: function(scope, element, attrs, ctrl) {}

  };

};
fticSipCalculatorChart.$inject = ['$state', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsEventConstants'];
module.exports = fticSipCalculatorChart;