// Filename: app.js
define([
  'jquery',
  'underscore',
  'backbone',
  'router', // Request router.js 
  'commonjqueryplugins'
], function ($, _, Backbone, Router, CommonJqueryPlugins) {
    var initialize = function () {
        // Pass in our Router module and call it's initialize function
        Backbone.View.prototype.close = function () {  //This is the method will cleanup the previous view whwnever the new view is created and so cleanup the memmory.
            //Flushing timelineInterval
            if (typeof (window.timelineInterval) != "undefined") window.clearInterval(timelineInterval);
            if (this.beforeClose) {
                this.beforeClose();
            }
            this.undelegateEvents();
            $(this).empty;
            this.unbind();
        };
        Router.initialize();  //This will initialize the Parent router
    };
    return { initialize: initialize };
});
