'use strict';
describe('Controller: stpController', function() {
	var $controller,$scope,stpController,TransactConstant;

	beforeEach(angular.mock.module('advisor'));				

	beforeEach(inject(function($rootScope,_$controller_,_TransactConstant_){	
		$controller = _$controller_;
		$scope = $rootScope.$new();
		
		TransactConstant = _TransactConstant_;

		$scope.config = {"txnFormDetails":{}};	
		$scope.header = {"title": ""};
		loadController();			
	}));	

	function loadController(){
        stpController = $controller('StpController', { $scope: $scope });
    }

    it('should be defined',function(){
    	expect(stpController).toBeDefined();
    });

    it('should define the variables config,header',function(){
    	expect($scope.config.txnFormDetails.title).toBe('STP Details');
    	expect($scope.header.title).toBe(TransactConstant.stp.STP_HEADING);
    })
});