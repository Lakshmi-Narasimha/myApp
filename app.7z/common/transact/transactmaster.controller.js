/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


 'use strict';
// Controller naming conventions should start with an uppercase letter
function transactMasterController($scope, fticLoggerMessage, loggerConstants, $state,transactModel, $timeout, $location, transactEventConstants) {
    console.info("transactMaster Controller!!");
    $scope.header = {};
    $scope.header.title = "Transaction";
    $scope.config = {};
    $scope.config.showNotification = false;
    $scope.config.statename = "";
    $scope.config.toState = "";
    $scope.config.toTxnDetailsState = "";

    /*$scope.open = function() {
        $scope.config.showNotification = true;
    };*/

    

    $scope.$on("NAVIGATE_TO_TRANSACT", function($event,value){      
        $scope.config.param = null;      
        $scope.config.param = value;  
        if($scope.config.fromState === $state.current.name){
            transactModel.setStateValue($scope.config.param);
            $state.go($scope.config.toState, $scope.config.param);
            $timeout(function(){
                if($scope.config.param.key == "PaymentDetails"){
                    $scope.$emit("Go_To_Payment_Dtls"); 
                }    
            });
        }
    });

    $scope.$on('kycAdntDtls', function() {
        $scope.$broadcast(transactEventConstants.transact.KYC_ADTNL_DETAILS);
    });

    $scope.$on('payment_details', function() {
        $timeout(function(){
            $scope.$broadcast("paymntDtls");
        });
    });

    $scope.$on('kycMode', function() {
        $scope.$broadcast('checkKycMode');
    });

   /* $scope.$on('yes', function () {
        $scope.config.showNotification = false;
        if($scope.config.fromState === $state.current.name){
            transactModel.setStateValue($scope.config.param);
            $state.go($scope.config.toState, $scope.config.param);
            $timeout(function(){
                if($scope.config.param.key == "PaymentDetails"){
                    $scope.$broadcast("Go_To_Payment_Dtls"); 
                } 
            }); 
                     
        }
    });
     $scope.$on('no', function () {
        $scope.config.showNotification = false;
    });*/
    /*$scope.$on("myYesEvent", function(){
       $state.go(toState.name);
    });
    
    $scope.$on("myNoEvent", function(){
        $state.go($scope.fromstate);
    });*/
   /**/

    $scope.redirectToForm = function(){
        $state.go("transact.ekyc");
    }
    /*$scope.$watch(function(){
        console.log("heyyy.......", $location.path())
        return $location.path();
    }, function(newPath, oldPath){
        console.info("New Path>> "+newPath);
        console.info("Old Path>> "+oldPath);
    })*/
    
   /* $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
        var answer = confirm("Are you sure you want to leave this page?")
        if (!answer) {
            event.preventDefault();
        }
        console.log("xxxx", fromState);
        $scope.fromstate = fromState.name;
        $scope.tostate = toState.name;
        $scope.config.showNotification = true;
    });
  
    window.onbeforeunload = function() {
        console.info("xxxxxxxxxxxxxx >>>>> ");
    }
    */
}

transactMasterController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state','transactModel', '$timeout', '$location', 'transactEventConstants'];
module.exports = transactMasterController;