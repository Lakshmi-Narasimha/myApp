define([
  'jquery',
  'underscore',
  'backbone',
  'services/accountdetailservice',
  'appmodules/accountviewer/app/views/accountdetailsectionview',
  'text!appmodules/accountviewer/app/templates/accountdetailconvertedview.html',
  'appcommon/commonutility'
], function ($, _, Backbone, dataService, AccountDetailSectionView, SectionTemplateHtml, Utils) {

    var SectionView = AccountDetailSectionView.extend({
        retrieveAndRender: function() {
            var self = this;
            dataService.promiseToGetConvertedAccount(this.accountSummary.accountId)
                .then(function(accountConversions) {
                    _.each(accountConversions, function(accountConversion) {
                      accountConversion.formattedConversionDate = Utils.isEmpty(accountConversion.finConvDt) ?
                        "" : accountConversion.finConvDt.formatDateMMddYYYY();
                    });
                    self.renderSection(SectionTemplateHtml, {accountConversions: accountConversions});
                })
                .fail(this.handleServiceError);
        }
    });

    return SectionView;
});