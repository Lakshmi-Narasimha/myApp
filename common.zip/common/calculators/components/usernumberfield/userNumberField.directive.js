/**
 * @ngdoc directive
 * @name fticUserInputFld
 * @requires $scope
 * @requires $element
 * @requires $attrs
 * @description
 *
 * - fticUserInputFld will display floatable input control.
 * 
 *
 **/
'use strict';

var userNumberFld = function($timeout, eventConstants) {
	return {
            template: require('./userNumberField.html'),
            restrict: 'E',
            replace: true,
            scope: {
                inputObject: "=",
                inputChanged: "&?"
            },
            controller: ['$scope', '$element', function($scope, $element){
                $scope.$input = $element[0].querySelector('input');
                $scope.isChanged = false;
                $scope.toggleLabel = function($event){
                    if($event.type ==='blur'){
                        $scope.$emit("INPUT_BLUR", {event:$event, inpObj:$scope.inputObject});
                    }else if($event.type === 'keydown'){
                       $scope.$emit("INPUT_KEYDOWN", $scope.inputObject);
                    }
                    angular.element($element[0].querySelector('.form-group')).toggleClass('focused', ($event.type === 'focus' || $scope.$input.value.length > 0));
                    $scope.$emit("INPUT_TOGGLE",{event:$event,inpObj:$scope.inputObject});
                    $scope.updateParent();

                // $timeout(function(){
                //     angular.element($scope.$input).triggerHandler('blur');
                // }, 0);
                };

                $timeout(function(){
                    $scope.isChanged = true;
                    angular.element($scope.$input).triggerHandler('blur');
                }, 0);

                $scope.updateParent = function(){
                    if(!$scope.isChanged) {
                        return;
                    } else {
                        $scope.$emit("INPUT_CHANGED", $scope.inputObject);
                    }
                }

                $scope.$on(eventConstants.REMOVE_FOCUS_CLASS,function(event){
                    $timeout(function(){
                        angular.element($scope.$input).triggerHandler('blur');
                    }, 0);
                });

                $scope.ownChanged = function () {
                    if ($element[0].querySelector('input').value) {
                        $timeout(function () {
                            $scope.inputValue = true;
                            $scope.inputObject._isViewValue = true; //Added to check whether viewValue exists or not - QC Defect #4647 - Investor
                            $scope.inputObject.viewValue = $element[0].querySelector('input').value;
                        });
                    } else {
                        $timeout(function () {
                            $scope.inputValue = false;
                            $scope.inputObject._isViewValue = false; //Added to check whether viewValue exists or not - QC Defect #4647 - Investor
                            $scope.inputObject.viewValue = $element[0].querySelector('input').value;
                        });
                    }
                }

            }]
        };
};

userNumberFld.$inject = ['$timeout', 'eventConstants'];
module.exports = userNumberFld;