 /**
 * @ngdoc property
 * @name secuirityQuestion Directive
 * @description
 *
 * - Simple dropdown filter which has the flotable labels and emits the selected event
 *
 **/
'use strict';


var userSecurityQuestion = function($timeout,constants,advisorRegistrationModelService) {
    return {
        restrict: 'E',
        template: require('./userSecurityQuestion.html'),
        replace:true,
        scope: {
            formObj:'='
        },
        controller: function($scope, $element, $attrs){
             $scope.formData={};
             $scope.securityQuestionObject = {
                key :'securitryquestion',
                text:advisorRegistrationModelService.getUserData().secretQtn,//'what is your school name ?',
                value:'',
                isRequired : true,
                type:'text',
                name:'securityQuestion'
             },

              $scope.$on('submitSecurityQuestion', function(){
                $scope.$submitted = true;
                advisorRegistrationModelService.setSecurityAnsData($scope.securityQuestionObject.value);
                 
              })
              
        },
        link: function(scope, iElement, iAttrs, controller) {
        }       
    }
}    
    
userSecurityQuestion.$inject = ['$timeout','constants','advisorRegistrationModelService']
module.exports = userSecurityQuestion;