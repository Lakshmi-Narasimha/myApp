// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SubscriptionDetailsModelSchema = new mongoose.Schema({
    subscriptionDetails: {
        type: Array,
        "default": []
    }
});

var SubscriptionDetailsModelLookUp = mongoose.model('SubscriptionDetailsModelLookUp', SubscriptionDetailsModelSchema);

var SubscriptionDetailsModel = new SubscriptionDetailsModelLookUp({
    subscriptionDetails : {
        "subscriptions": {
          "valuationSubscriptions": [{
            "subscriptionID": 1234,
            "folios": [34567812, 45674812],
            "accounts": [1124597960],
            "subscriptionDetails": "Weekly",
            "subscriptionBySms": true,
            "subscriptionByEmail": false
          }, {
            "subscriptionID": 123,
            "folios": [34567212],
            "accounts": [1124597960, 3456389456],
            "subscriptionDetails": "Monthly",
            "subscriptionBySms": true,
            "subscriptionByEmail": true
          }, {
            "subscriptionID": 14,
            "folios": [34567812, 45674812, 56827348],
            "accounts": [1124597960, 49876],
            "subscriptionDetails": "Daily",
            "subscriptionBySms": false,
            "subscriptionByEmail": true
          }],
          "navSubscriptions": [{
            "subscriptionID": 3345,
            "subscriptionDetails": "Weekly",
            "subscriptionByEmail": false,
            "subscriptionBySms": true,
            "subscriptionBySmsFunds": ["FT BuleChip - Growth", "FT BuleChip - Dividend"]
          }, {
            "subscriptionID": 13432,
            "subscriptionDetails": "Monthly",
            "subscriptionByEmail": true,
            "subscriptionBySms": true,
            "subscriptionBySmsFunds": ["FT Prima - Growth", "FT BuleChip - Dividend"]
          }, {
            "subscriptionID": 232472,
            "subscriptionDetails": "Quarterly",
            "subscriptionByEmail": true,
            "subscriptionBySms": true,
            "subscriptionBySmsFunds": ["FT Prima - Growth", "FT BuleChip - Dividend", "FT BuleChip - Growth"]
          }, {
            "subscriptionID": 42372,
            "subscriptionDetails": "Quarterly",
            "subscriptionByEmail": true,
            "subscriptionBySms": false,
            "subscriptionBySmsFunds": []
          }],
          "folioNumbers" : [34567812, 45674812, 56827348, 34567212],
          "accountNumbers" : [1124597960, 49876, 3456389456],
          "allFunds" : ["FT Prima - Growth", "FT BuleChip - Dividend", "FT BuleChip - Growth"]
        }
      }
    }
);

SubscriptionDetailsModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SubscriptionDetailsModelLookUp table, please contact admin...');
    } else {
        SubscriptionDetailsModelLookUp.remove({}, function(err) {
            console.log('SubscriptionDetailsModelLookUp collection removed');
            SubscriptionDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating SubscriptionDetailsModelLookUp table, please contact admin...');
                }
                console.log('SubscriptionDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SubscriptionDetailsModelLookUp;
