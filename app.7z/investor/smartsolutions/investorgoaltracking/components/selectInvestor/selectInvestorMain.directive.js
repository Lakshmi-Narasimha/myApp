'use strict';


var smartSolsSelectInvestor = function(advisorConstants, advisorEventConstants, fticLoggerMessage, loggerConstants,buildPlanModelService, investorGoalModelService) { 
return {
            template: require('./selectInvestorMain.html'),
            restrict: 'E',
            replace: true,
            scope: true,
            controller: ['$scope', function($scope){
                $scope.holderInfoArray = [];
                $scope.continueCheck = true;
                $scope.$on("investorSearch", function () {  
                     $scope.holderInfo = true;
                     $scope.continueCheck = false;
                     // $scope.holderInfoArray = null;
                     $scope.investorDetails =  buildPlanModelService.getInvestorSearch();
                    //  $scope.holderInfoArray = [
                    //       {key:"First Holder",value:buildPlanModelService.getInvestorSearch().custName},
                    //       {key:"Second Holder",value:buildPlanModelService.getInvestorSearch().holders[1].name},
                    //       {key:"Third Holder",value:buildPlanModelService.getInvestorSearch().holders[2].name},
                    //       {key:"Folio. No.",value:buildPlanModelService.getInvestorSearch().folioId},
                    //       {key:"Mode of Holding",value:buildPlanModelService.getInvestorSearch().holdingType}
                    // ];
                });

                $scope.selectInvContnuBtn = function(){
                  investorGoalModelService.setInvestorData($scope.holderInfoArray);
                  console.log(investorGoalModelService.getInvestorData());
                  $scope.$emit('smartSolSelectInvestor');
                  // $state.go("smartSol.investor.selectGoal");
                }

            }]
        }
   };     


smartSolsSelectInvestor.$inject = ['advisorConstants', 'advisorEventConstants', 'fticLoggerMessage', 'loggerConstants','buildPlanModelService','investorGoalModelService'];
module.exports = smartSolsSelectInvestor;  