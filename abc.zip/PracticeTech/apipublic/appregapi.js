﻿define([
  'jquery',
  'underscore',
  'config',
  'appcommon/applauncher/appregistration',
  'appcommon/applauncher/device'

], function ($, _, Config, AppRegistration, Device) {

    routeIsAllowed = function ( route ) {
        if (appRegistrationHasEntry(route) && deviceSupported(route)) {
            return true;
        }
        return false;
    }

    appRegistrationHasEntry = function (route) {
        //ensures that appRegistration has an entry for this item
        if (AppRegistration.GetAppInfoByRouteName(route)) {
            return true;
        } else {
            return false;
        }
    }

    deviceSupported = function (route) {
        var deviceList = getDeviceListbyRoute(route);

        if (Device.info.hardware.make === null ) { Device.load()}
        if ($.inArray(Device.info.hardware.make, deviceList) !== -1) {
            return true;
        } else if ($.inArray(Device.info.hardware.type, deviceList) !== -1) {
            return true;
        } else {
            return false
        }

        function getDeviceListbyRoute(route) {
            var appInfo = AppRegistration.GetAppInfoByRouteName(route),
                deviceProfile;
           appInfo.LaunchTarget.forEach(function (target, index) {
                if (target.Route == route && typeof target.DeviceProfile !== 'undefined') {
                    deviceList = target.DeviceProfile;
                } 
            });
           
           return deviceList;
        }

    }


    AppRegistrationApi = {
        routeIsAllowed: routeIsAllowed
    }

    return AppRegistrationApi
});
