/**
 * @ngdoc filter
 * @name Filter ConvertStringToNumber
 * @description
 *
 * - Filter method to convert string to number.
 *
 */

'use strict';

var fticStringToNumber = function() {

	return function(value) {
		if(!value) {
            return 0;
        }else {
            return Number(value.split(',').join(''));
        }
	};
};

fticStringToNumber.$inject = [];
module.exports = fticStringToNumber;
