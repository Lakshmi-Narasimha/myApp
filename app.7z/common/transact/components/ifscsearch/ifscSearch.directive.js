/**
 * @ngdoc property
 * @name fticIfscSearch Directive
 * @requires uibModal
 * @description
 *
 * - This directive is responsible for displaying IFSC Search Window.
 *
 **/
'use strict';


var fticIfscSearch = function($uibModal,$q,transactEvents, ifscInitialLoader,transactModel,bankDtlsModel, ifscModel, transactEventConstants, $timeout, paperlessModel, $stateParams, TransactConstant, RegisteredBankModel,reviewSwpDetailsModel) {
    return {
        template: require('./ifscSearch.html'),
        restrict: 'E',
        replace: true,
        scope: {
            placeHolder: "=?",
            isRequired: "=?",
            ifscTextField: "=?",
            ifsc: "=?"
        },
        controller:['$scope', function($scope) {
            var params = {};

            $scope.isFormInValid = false;
            $scope.noBranchReq = false;
            $scope.selectedCity = "";
            $scope.selectedBranch = "";
            $scope.ifscGrid = {};
            $scope.brnchArr = [];
            $scope.cityArr = [];
            $scope.cityNames = {
                name: 'cityName',
                required: true,
                label: 'Select City'
            };
            $scope.brnNames = {
                name: 'brnNames',
                required: true,
                label: 'Select Branch'
            };
            if (transactModel.isSWP) {
                params.bankName = RegisteredBankModel.getDefaultBankDetails().pbBankName;
                $scope.bnkName = RegisteredBankModel.getDefaultBankDetails().pbBankName;
                ifscModel.setIfscBank($scope.bnkName);
                params.type = 'BNK';
                $scope.noMatchFoundErrMsg = "";
                ifscInitialLoader.loadAllServices($scope, params);
            }

            function ifscOnBankSelection(value) {
                if (value) {
                    $scope.brnchArr = [];
                    $scope.cityArr = [];
                    params.bankName = value;
                    $scope.bnkName = value;
                    ifscModel.setIfscBank($scope.bnkName);
                    params.type = 'BNK';
                    $scope.noMatchFoundErrMsg = "";
                    ifscInitialLoader.loadAllServices($scope, params);
                }
            }
            $scope.$on('bankSelected', function(event, data){
                params = {};
                if(data.bankName) {
                    ifscOnBankSelection(data.bankName);
                } else {
                    ifscOnBankSelection(data.title);
                }
            });

            $scope.$on('disableIFSCLink', function(event, data) {
                $scope.bnkName = null;
            });

            //This if condition is for edit/back functionality
            if ($stateParams.key === TransactConstant.transact.Payment_Key || paperlessModel.paymentDtls.hasData) {
                ifscOnBankSelection(ifscModel.getIfscBank());
            }

            $scope.sectionOptions = [];
            // $scope.bnkName = bankDtlsModel.getSelectedBank();

            var statusTemplate = '<input type="radio" class="fti_grid_checkbox" name="ifscSelect" ng-click="grid.appScope.$emit(\'checkIfcsSelect\', row.entity)" />'
            $scope.columnDefs = [{
                field: 'checkBox',
                displayName: '',
                width: 45,
                pinnedLeft: true,
                cellTemplate: statusTemplate,
                enableSorting: false
            }, {
                field: 'ifscCode',
                displayName: 'IFSC Code',
                headerCellClass: 'fti-grid-sortDisabledHeader',
                width: '130',
                pinnedLeft: true,
                enableSorting: false
            }, {
                field: 'branchName',
                displayName: 'Branch Name',
                headerCellClass: 'fti-grid-sortDisabledHeader',
                width: '180',
                enableSorting: false
            }, {
                field: 'city',
                displayName: 'City',
                headerCellClass: 'fti-grid-sortDisabledHeader',
                enableSorting: false,
                width: '180',
            }, {
                field: 'bankName',
                displayName: 'Bank Name',
                headerCellClass: 'fti-grid-sortDisabledHeader',
                enableSorting: false,
                width: '180',
            }];

            $scope.noMatchFoundErrMsg = "";
            $scope.$on(transactEventConstants.transact.IFSC_SEARCH_FAIL, function (event, resp) {
                $scope.ifscSearchDataShow = false;
                $scope.ifscGrid.ifscSearchData = [];
                if (resp.data[0].errorCode === TransactConstant.transact.IFSC_NO_MATCH_ERR_CODE) {
                    $scope.noMatchFoundErrMsg = resp.data[0].errorDescription;
                }
            });
            $scope.searchIFSC = function () {
                $scope.ifscSearchDataShow = false;
                $scope.ifscGrid.ifscSearchData = [];
                $scope.isFormInValid = false;
                if ($scope.ifsc.ifscCode || ($scope.selectedCity && $scope.selectedBranch)) {
                    $scope.ifscSearchDataShow = true;
                    $scope.ifscCode = "";
                    $scope.noMatchFoundErrMsg = "";
                    ifscInitialLoader.loadAllServices($scope, params);
                } else {
                    $scope.isFormInValid = true;
                }
            };
            var editReviewSWPDetails = reviewSwpDetailsModel.getReviewSwpObj();
            if(editReviewSWPDetails){
                if(editReviewSWPDetails.isEditSWP || $stateParams.key == 'SWP' || reviewSwpDetailsModel.getFundEditIfscStatus()){
                    $scope.ifsc = ifscModel.getIfscGridResDet() || {};
                    reviewSwpDetailsModel.setFundEditIfscStatus(false);
                }else{
                    $scope.ifsc = {};
                }  
            }else{
                $scope.ifsc = {};
            }
            
            $scope.$on('checkIfcsSelect', function(event, data) {
                $scope.ifsc.ifscCode = data.ifscCode;
                $scope.ifsc.bankDetails = data.branchName;
                $scope.ifsc.bnkAdd = data.city;
                ifscModel.setIfscGridResDet($scope.ifsc);
            });


            var modalInstance;
            $scope.openIfsc = function () {
                $scope.ifsc = {};
                $scope.ifscSearchDataShow = false;
                ifscModel.setIfscBankDetails(null);
                $scope.ifscGrid.ifscSearchData = [];
                modalInstance = $uibModal.open({
                    template: require('./ifscSearchModal.html'),
                    controller: 'IfscSearchModalController',
                    scope: $scope
                });
            };

            var ifscInitialHandler = $scope.$on(transactEventConstants.transact.IFSC_DETAILS, function (event, data) {
                $scope.ifscGrid.ifscSearchData = null;
                $scope.sectOptArr = function (sectArray) {
                    var sectOptObj = [];
                    /*sectOptObj.push({
                                title: '',
                                value: ''
                            });*/
                    angular.forEach(sectArray, function(data, element) {
                            sectOptObj.push({
                                title: data,
                                value: data
                            });

                        }

                    )
                    return sectOptObj;
                };
                if (ifscModel.getIfscCityDetails()) {
                    var cityData = ifscModel.getIfscCityDetails();
                }
                if ($scope.cityArr.length <= 0) {
                    $scope.cityArr = $scope.cityArr.concat($scope.sectOptArr(cityData));
                    $scope._citySelected = $scope.cityArr[0];
                }


                if (ifscModel.getIfscBrnDetails()) {
                    var brnData = ifscModel.getIfscBrnDetails();
                }
                if ($scope.brnchArr.length <= 0) {

                    $scope.brnchArr = $scope.brnchArr.concat($scope.sectOptArr(brnData));
                    $scope.onBranchSelected($scope.brnchArr[0]);
                }

                if (ifscModel.getIfscBankDetails()) {
                    $timeout(function () {
                        $scope.ifscGrid.ifscSearchData = ifscModel.getIfscBankDetails();
                    }, 0);
                }
                // ifscInitialHandler();
            });

            $scope.onCitySelected = function (data) {

                if (!$scope.ifsc.ifscCode) {
                    $scope.selectedCity = data.title;
                    $scope._branchSelected = null;
                    $scope.brnchArr = [];
                    params.type = 'CTY';
                    params.city = data.title;
                    $scope._citySelected = data;
                    if ($scope.cityArr.length > 0 && data.title) {
                        $scope.noMatchFoundErrMsg = "";
                        ifscInitialLoader.loadAllServices($scope, params);
                    }
                }
            };

            /**
             * Code commented due to requirement conflicts
             */
            /*
            $scope.validateCitySelection = function (data) {

                if (data.value === 'SELECT_CITY') {
                    $scope.selectedCity = null;
                    $scope._citySelected = data;
               } else {
                    $scope.onCitySelected(data);
                }
                ifscSearchUtilitesFactory.manageLabel($scope.cityNames, data, constants.IFSC_CONSTANTS.CITY_TEXT);
            };
            */

            $scope.$on('cityArry', function (event, data) {
                $scope.onCitySelected(data);
            });

            $scope.onBranchSelected = function (data) {

                $scope._branchSelected = data;
                if (data && !$scope.ifsc.ifscCode) {
                    $scope.selectedBranch = data.title;
                    params.type = 'BRN';
                    params.branchName = data.title;
                }
            };
            /**
             * Code commented due to requirement conflicts
             */
            /*
            $scope.validateBranchSelection = function (data) {
                if (data.value === 'SELECT_BRANCH') {
                    $scope.selectedBranch = null;
                    $scope._branchSelected = data;
                } else {
                    $scope.onBranchSelected(data);
                }
                ifscSearchUtilitesFactory.manageLabel($scope.brnNames, data, constants.IFSC_CONSTANTS.BRANCH_TEXT);
            };
            */

            $scope.$on('brnchArry', function (event, data) {

                $scope.onBranchSelected(data);
            });

            $scope.ifscCodeChange = function (ifscCode) {
                if (ifscCode) {
                    params.type = 'IFS';
                    params.ifscCode = ifscCode;
                }
            };
        }]
    };
};

fticIfscSearch.$inject = ['$uibModal','$q','transactEvents', 'ifscInitialLoader','transactModel','bankDtlsModel', 'ifscModel', 'transactEventConstants', '$timeout', 'paperlessModel', '$stateParams', 'TransactConstant', 'RegisteredBankModel','reviewSwpDetailsModel'];
module.exports = fticIfscSearch;