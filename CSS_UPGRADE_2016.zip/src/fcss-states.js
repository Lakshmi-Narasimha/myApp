
// var policyStates = {
// 	policy:{
// 			name: 'policysummary', 	
// 			url: '/policysummary',
// 			views: {
//                 "main": {
//                     controller: 'policysummaryController',
//                     templateUrl: window.UIC.sitePrefix + 'modules/policy/summary/policysummary.html'
//                 }
//             }
// 		},
// 	policyEdit : {
// 			name: 'policysummary.editpolicy',
// 			url: '/editpolicy',
// 			parent: this.policy,
// 			templateUrl: window.UIC.sitePrefix + 'modules/policy/edit/policy.edit.html'			
// 		}
// 	};	