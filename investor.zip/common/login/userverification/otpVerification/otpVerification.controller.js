 
'use strict';
// Controller naming conventions should start with an uppercase letter
function otpVerificationController ($scope, $state,$filter,constants,advisorRegistrationModelService,toaster) {
     $scope.formData={}; 
     $scope.otpObject = {
                    key : 'otp',
                    text : 'OTP',
                    value : '',
                    name : 'otp',
                    isRequired: true 
                };
      $scope.otpMessageText = {
            text:$filter('translate')(constants.login.OTP_TEXT),
            image:"../images/OTP_Tick.svg"
      };
      

      $scope.submitOTP = function(){
        	$scope.$submitted = true;
          $scope.formData.OTP=$scope.otpObject.value;
          $scope.formData.guId=advisorRegistrationModelService.getUserData().guId;
          if($scope.otpVerificationForm.$valid){
               var postSuccess= function (data) {
                   if(advisorRegistrationModelService.getUserForgotTypeDetails() === 'username'){
                        advisorRegistrationModelService.postAcknowledgeCall($scope.formData.guId);
                        $state.go('loginmaster.thankyou');
                    }else{
                        $state.go('loginmaster.newpassword');
                    }
                 } 
                var handleFailure = function (errorResp){
                      toaster.error(errorResp.data[0].errorDescription);
                 }
                 //advisorRegistrationModelService.postOtpDetails($scope.formData).then(postSuccess, handleFailure);
                 advisorRegistrationModelService.postAnsForSecurityQn($scope.formData).then(postSuccess, handleFailure);
                
           }
       }
       $scope.resendOtp = function($event){
            $event.preventDefault();
            var otpObj= {};
            var userData = advisorRegistrationModelService.getUserData();
            otpObj.mobileNo=userData.mobile;//"9440415681";
            otpObj.emailId=userData.emailId; 
            otpObj.type = userData.userType;
            otpObj.guId=userData.guId;
             var postSuccess = function(data){
                
             };
             
             var handleFailure = function(data){
                

             };
            advisorRegistrationModelService.postRequestForOtpDetails(otpObj).then(postSuccess, handleFailure);
            
    }

}

// $inject is necessary for minification. See http://bit.ly/1lNICde for explanation.
otpVerificationController.$inject = ['$scope', '$state','$filter','constants','advisorRegistrationModelService','toaster'];
module.exports = otpVerificationController;