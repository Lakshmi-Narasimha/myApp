/**
 * @ngdoc service
 * @name FTI Dashboard Initial Load Service
 * @requires cgAccDetModel
 * @requires investorEvents
 * @requires eventConstants
 * @requires toaster
 * @requires $timeout
 * investorEventConstants
 * fticLoggerMessage
 * loggerConstants
 * toaster
 * $loader
 * @description
 *
 * - Handles the services and model for Advisor content details & widgets
 *
 */
'use strict';


var basisFolioInitialLoader = function(basisFolioModel, investorEvents, eventConstants, $timeout, investorEventConstants, fticLoggerMessage, loggerConstants, toaster, $loader) {
    var basisFolioInitialLoader = {
        // _isServicesData: false,
        // _isInitialLoad:false,
        loadAllServices : function (scope, params) {
            basisFolioModel.fetchbasisfoliodetails(params) 
            .then(basisFolioDetailsSuccess, promiseFailure).finally(stopLoader());
            function basisFolioDetailsSuccess(data){
                basisFolioModel.setbasisfoliodetails(data);
                investorEvents.accountSettings.basisFolioDetails(scope);
            };
            function promiseFailure (data) {
                toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
            };
             function stopLoader() {
                $loader.stop();
            };

            $loader.start();
        }
    };
    return basisFolioInitialLoader;
};


basisFolioInitialLoader.$inject = ['basisFolioModel', 'investorEvents', 'eventConstants', '$timeout', 'investorEventConstants', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader'];

module.exports = basisFolioInitialLoader;
