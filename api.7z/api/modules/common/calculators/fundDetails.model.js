// getAdvisorContent.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FundDetailsSchema = new mongoose.Schema({
    fundDetailsObject: {
        type: Array,
        "default": []
    }
});

var FundDetailsLookUp = mongoose.model('FundDetailsLookup', FundDetailsSchema);

var FundDetailsModel = new FundDetailsLookUp({

  "fundDetailsObject": [
    {
    "fundDetails": [{
        "fundName": "Franklin India BlueChip Fund",
        "fundId": "FT0001"
    }, {
        "fundName": "Franklin India Prima Plus",
        "fundId": "FT0002"
    }]
}
    ]

});

FundDetailsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FundDetailsLookUp table, please contact admin...');
    } else {
        FundDetailsLookUp.remove({}, function(err) {
            console.log('AdvisorContentLookUp collection removed');
            FundDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating FundDetailsLookUp table, please contact admin...');
                }
                console.log('FundDetailsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FundDetailsLookUp;
