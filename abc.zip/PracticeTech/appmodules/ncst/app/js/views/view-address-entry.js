
var _response;
define(
		[ 'text!appmodules/ncst/app/templates/addressEntry.html',
				'appmodules/ncst/app/js/lib/validate-4.2', 'config',
				'appmodules/ncst/app/js/utils', 'appmodules/ncst/app/js/models/model-address-entry', 'appmodules/ncst/app/js/models/model-client', 'appmodules/ncst/app/js/models/model-new-client', 'appmodules/ncst/app/data/country-list', 'appcommon/globalcontext', 'appcommon/analytics', 'appcommon/abstractview', 'components/js/views/RadioButtonView'],
		function (Template, Validator, Config, Utils, AddressModel, ClientModel, newClientModel, DropdownOptions, GlobalContext, Analytics, AbstractView, RadioButtonView) {
			ClientInfoModel = ClientModel.get('clientInfo');
			var self, BASE_URL = Config.odataServiceName;
			var addressEntryView = AbstractView.extend({
						el : '#ncst-app',
						statsTemplate: _.template(Template),
						clientEntityViewName:'clientEntityViewName',
						initialize: function () {
							AbstractView.prototype.initialize.apply(this, arguments);
							this.firstLoad = true;
							self = this;
							this.$main = this.$('#client-info');
						},
						events : {
							'change input[name="aeAddressType"]' : 'handleAddressTypeChange',
							'change #reqrd-mailing-addrs' : 'handleMailingAddressCheckSelection',
							'change #country-list-select' : 'handleProvinceForCanada',
							'keypress #zipcode' : 'validateZipCodeLength',
							'keypress #ma-zipcode' : 'validateZipCodeLengthMa',
							'click #back-to-step1,#m-back-to-step1' : 'navigateToStep1',
							'click #step2-next-button,#m-step2-next-button' : 'navigateToStep3',
							'keypress .us-zipcode' : 'numValidator',
							// bind events to catch the changes in address
							// fields
							'change #address-entry input[type="tel"], #address-entry input[type="number"],#address-entry input[type="text"],#address-entry input[type="radio"],#address-entry select' : 'trackChanges',
							'keyup #address-entry input[type="tel"], #address-entry input[type="number"],#address-entry input[type="text"],#address-entry input[type="radio"],#address-entry select' : 'trackChanges',
							"click .sad-text.sad-step2":"handleSAD"
							},
						handleSAD:function(){
							Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
							this.model.setModel();
							Utils.lockForm();
							ClientModel.createDraft().done(function(response){
								Utils.unlockForm();
								ClientModel.showDraftSaveSuccesMessage(response);
							}).fail(function(error){
								Utils.unlockForm();
								Utils.showDraftSaveErrorMessage();
								console.log(error,"error");
							});
						},
						render : function() {
							var _data = this.model.toJSON();
							_data.isMobile = Utils.isMobile()							
							_data.Client = ClientModel;
							var clientInfoData = ClientModel.get('clientInfo');
							var addressEntryData = ClientModel.get('addressEntry');
							AddressModel.set('firstTime', true);
							this.$main.html(this.statsTemplate(_data));
						},
						clearView : function() {
							this.undelegateEvents();// Unbind all local event
							// bindings
							this.model.unbind('change', this.render, this); // Unbind
						},
						trackChanges : function() {
							self.model.set('addressValChange', true);
						},
						afterRender : function() {
                                                        var _errorCodes = ClientModel.get('serverErrorCodes');
                                                        Utils.setServerErrValidations("2", _errorCodes);
                                                        ClientModel.set('serverErrorCodes', _.without(_errorCodes, '15588', '15583'));
							this.loadCountryList();
							this.loadUSStatesList();
							$('.custom-select').customizeSelect();
							var _model = this.model;
							$('#state-list-select').val(
									_model.get('primaryAddress').uState)
									.trigger('change');
							$('#ma-state-list-select').val(
									_model.get('mailingAddress').uState)
									.trigger('change');
							// setting initial load
							if (_model.get('primaryAddress').uAddressLine1
									&& this.firstLoad) {
								this.trackChanges();
							}

							var clientType = ClientInfoModel.get('clientType');
							// Deciding if Person or entity
							if (clientType == "P") {
								$('.entity-field').addClass('hidden');
								$('.person-field').removeClass('hidden');
							} else {
								$('.entity-field').removeClass('hidden');
								$('.person-field').addClass('hidden');
							}
							if (this.model.get('fromBack')) {
								this.setSavedValues();
							}

							// add active class to the selected addrs type
							var _radio = $('input[name=aeAddressType]:checked');
							var _radioHolder = _radio
									.parents('div.radio-grp-holder');
							_radioHolder.find('div.radio-group-conatiner')
									.removeClass('active');
							_radio.parents('div.radio-group-conatiner')
									.addClass('active');
							// if address type is foreign disable mailing chkbox
							if (_model.get('primaryAddress').addressType == "Foreign"
									|| ClientModel.get('clientInfo').get(
											'citizenship') == "Non-Resident Alien") {
								$('#ae-address-type-foreign').click();
								var _$reqdMailingAddrsChk = $('#reqrd-mailing-addrs');
								var _$disabledSpan = _$reqdMailingAddrsChk
										.parent().find('.disabled-checkbox');
								_$reqdMailingAddrsChk.attr('disabled', 'true');
								_$disabledSpan.removeClass('hidden');
								$('#province-list-select').val(
										_model.get('primaryAddress').province)
										.trigger('change');
								$('#country-list-select').val(
										_model.get('primaryAddress').uCountry)
										.trigger('change');
							}
							if (ClientModel.get('clientInfo')
									.get('citizenship') == "Non-Resident Alien") {
								$('#ae-address-typ-us')
										.attr('disabled', 'true');
							} else {
								$('#ae-address-typ-us').attr('disabled');
							}
							if (ClientModel.get('clientCreated') == 'failed') {
								Validator.validateInputs('address-entry', true);
								this.validateComponents();
							}
							// init info popover
							//this.initInfoPopup();
							$("#ncst-user-home-view").invokeInfoPopup();
							// reset the addressChange variable
							if (this.firstLoad) {
								this.firstLoad = false;
							}
							self.model.set('addressValChange', false);
						},
						/*initInfoPopup : function() {
							Utils.initInfoPopup();
						},*/
						handleProvinceForCanada : function() {
							var _model = this.model;
							var _selectedCOuntry = $("#country-list-select")
									.val();
							var _$zipCode = $("#zipcode");
							if (_selectedCOuntry == "CA") {
								$("div[data-for=state-list-select]").hide();
								$("div[data-for=province-list-select]").show();
								$("#province").val("").hide();
								$("#province-list-select").show();
								_$zipCode.parent().parent().show();
								_$zipCode.removeClass('us-zipcode').addClass(
										"canada-zipcode");
								_$zipCode.attr('type', 'text');
							} else if ($('input[name=aeAddressType]:checked')
									.val() == "Foreign") {
								$("div[data-for=state-list-select]").hide();
								$("div[data-for=province-list-select]").hide();
								$("#province").val("").show();
								$("#province-list-select").val("");
								_$zipCode.parent().parent().hide();
								_$zipCode.val('');
								_$zipCode.removeClass("required");
							} else {
								$("div[data-for=province-list-select]").hide();
								$("#province-list-select").val("");
								$("div[data-for=state-list-select]").show();
								_$zipCode.parent().parent().show();
							}
						},
						navigateToStep1 : function() {
                                                        $('#address-entry .inconsistent').removeClass('inconsistent');
							$('.ncst-step.step1').find('.step-nav-links')
									.click();
						},
						validateComponents: function () {
							var nestedViewId = '';
							var showErrFlag = false;
							for (var key in this.nestedViews) {
								if (key.indexOf("clientEntityViewName") > -1) {
									if (this.nestedViews[key].selectedItem == null) {
										nestedViewId = this.nestedViews[key].el.id;
										showErrFlag = true;
									} else {
										showErrFlag = false;
									}
								}
								if (showErrFlag) {
									$("div [data-for=" + nestedViewId + "]").addClass('error');
									$("div [data-for=" + nestedViewId + "] .ncst-adjust-left").removeClass('hidden');
									this.nestedViews[key].showError(true);
								}
							}
							return !(showErrFlag);
						},
						navigateToStep3 : function() {
							$('#address-entry .inconsistent').removeClass('inconsistent');
							if (this.model.validate() || this.validateComponents()) {
								this.model.setModel();
								if (Validator.checkforMandatoryFields('address-entry')) {
									// AddressModel.set('mailValidAddr', false);
									// AddressModel.set('mailClientAddressCheck',true);
									Utils.lockForm();
									this.callScrubValdnSrvc();
								} else {
									$('.ncst-step.step4').find(
											'.step-nav-links').click();
									ClientModel.set('stepsCompleted', Utils
											.arraySplice(ClientModel
													.get('stepsCompleted'),
													'address-validation'));
									$('.ncst-step.step3').removeClass(
											'active  finished').addClass(
											'pending');
								}
								Analytics.analytics.recordSharedSuiteAction('ncstAddressEntryAddressType:' + this.model.get('primaryAddress').addressType);
								Analytics.analytics.recordSharedSuiteAction('ncstAddressEntrySeperateMailingAddress:' + this.model.get('seperateMailingAddress'));
							}
						},
						callScrubValdnSrvc : function() {
							this.scrubServiceCounter = 0;
							var _url = BASE_URL + 'scrubAddress?$format=json';
							// var _url = 'data/dummyscrub.json';
							var _data = {
								"addrCarrRteNbr" : null,
								"addrDlvPntBarCd" : null,
								"addrLn1Txt" : "",
								"addrLn2Txt" : null,
								"addrLn3Txt" : null,
								"addrLn4Txt" : null,
								"addrLn5Txt" : null,
								"AddrStandardizedCd" : null,
								"addrSubTypCd" : null,
								"addrTypCd" : "Postal Address",
								"addrVldCkDt" : null,
								"AddrVldCkRsltCd" : null,
								"addrVldCkStatCd" : null,
								"communeNbr" : null,
								"ctryCd" : null,
								"dwellingTypCd" : null,
								"localityNm" : null,
								"mailboxTxt" : null,
								"origAddrMchCd" : null,
								"poCdTxt" : "",
								"postTownNm" : "",
								"premiseNm" : null,
								"PrisionAddrCd" : null,
								"RegnAreaCd" : "",
								"standardizationvndrCd" : null,
								"StrNbr" : null,
								"StrNm" : null,
								"SubPremiseDescTxt" : null,
								"superiorLocalityNm" : null,
								"superiorStrNm" : null,
								"tmZoneCd" : null,
								"usCarrRteSeqNbr" : null,
								"vndrSuppldAddrCd" : null
							};
							if (AddressModel.get('primaryAddress').addressType != "Foreign") {
								// console.log("pserv call");
								this.scrubServiceCounter++;
								if ($('#reqrd-mailing-addrs').prop('checked')) {
									this.scrubServiceCounter++;
								}
								this.permanentAddrService(
										JSON.stringify(_data), _url);
							} else {
								AddressModel.set('validAddr', false);
								// save foreign address
								this.saveUsrEntdPermAddrsAsVAddrs();
							}
							if ($('#reqrd-mailing-addrs').prop('checked')) {
								if (AddressModel.get('primaryAddress').addressType == "Foreign") {
									this.scrubServiceCounter++;
								}
								this.mailingAddrService(JSON.stringify(_data),
										_url);
							} else {
								AddressModel.set('mailValidAddr', false);
							}

						},
						permanentAddrService : function(dataString, url) {
							var _data = JSON.parse(dataString), _url = url;
							// mandatory fields
							var clientType = ClientInfoModel.get('clientType');
							var _primaryAddress = AddressModel
									.get('primaryAddress');
							if (clientType == "P") {
								_data.addrLn1Txt = _primaryAddress.uAddressLine1;
							} else {
								_data.addrLn1Txt = _primaryAddress.uEntAddressLine1;
							}
							_data.postTownNm = _primaryAddress.uCity;
							_data.RegnAreaCd = _primaryAddress.uState;
							_data.poCdTxt = _primaryAddress.uZip;
							// non-mandatory fields
							if (clientType == "P") {
								_data.addrLn2Txt = _primaryAddress.uAddressLine2 ? _primaryAddress.uAddressLine2
										: null;
								_data.addrLn3Txt = _primaryAddress.uAddressLine3 ? _primaryAddress.uAddressLine3
										: null;
							} else {
								// Entity address lines 2 and 3
								_data.addrLn2Txt = _primaryAddress.uEntAddressLine2 ? _primaryAddress.uEntAddressLine2
										: null;
								_data.addrLn3Txt = _primaryAddress.uEntAddressLine3 ? _primaryAddress.uEntAddressLine3
										: null;
							}
							// console.log(_data);
							var _self = this;
							 this.model.set('clientAddressCheck', false);
							Utils
									.post(
											_url,
											JSON.stringify(_data),
											function(resp) {
												_response = resp.d;
												if (_response.status.statCd == "0000") {
													_self
															.svaeValdtdPAddressToModel(_response.postalAddress);
												} else {
													// console.log("case3");
													// scrub service failed save
													// the data userEntered data
													// as validated data
													_self
															.saveUsrEntdPermAddrsAsVAddrs();
													AddressModel.set(
															'validAddr', false);

												}
												_self.scrubServiceCounter--;
												_self
														.finalScrubServiceSuccesHandler();
											},
											function() {
												// scrub service failed save the
												// data userEntered data as
												// validated data
												_self
														.saveUsrEntdPermAddrsAsVAddrs();
												AddressModel.set('validAddr',
														false);
												_self.scrubServiceCounter--;
												_self
														.finalScrubServiceSuccesHandler();
											}, 0);
						},
						mailingAddrService : function(dataString, url) {
							var _data = JSON.parse(dataString), _url = url;
							// mandatory fields
							var clientType = ClientInfoModel.get('clientType');
							var _mailingAddrs = AddressModel
									.get('mailingAddress');
							if (clientType == "P") {
								_data.addrLn1Txt = _mailingAddrs.uAddressLine1;
							} else {
								_data.addrLn1Txt = _mailingAddrs.uEntAddressLine1;
							}
							_data.postTownNm = _mailingAddrs.uCity;
							_data.RegnAreaCd = _mailingAddrs.uState;
							_data.poCdTxt = _mailingAddrs.uZip;
							// non-mandatory fields
							if (clientType == "P") {
								_data.addrLn2Txt = _mailingAddrs.uAddressLine2 ? _mailingAddrs.uAddressLine2
										: null;
								_data.addrLn3Txt = _mailingAddrs.uAddressLine3 ? _mailingAddrs.uAddressLine3
										: null;
							} else {
								// Entity address lines 2 and 3
								_data.addrLn2Txt = _mailingAddrs.uEntAddressLine2 ? _mailingAddrs.uEntAddressLine2
										: null;
								_data.addrLn3Txt = _mailingAddrs.uEntAddressLine3 ? _mailingAddrs.uEntAddressLine3
										: null;
							}
							// console.log(_data, 'Mailing.....');
							var _self = this;
							this.model.set('mailClientAddressCheck', false);
							Utils
									.post(
											_url,
											JSON.stringify(_data),
											function(resp) {
												var _response = resp.d;
												if (_response.status.statCd == "0000") {
													_self
															.svaeValdtdMAddressToModel(_response.postalAddress);
												} else {
													// console.log("m case3");
													// scrub validation failed
													// save user entered address
													// as validated address
													_self
															.saveUsrEntsMailAddrsAsVAddrs();
													AddressModel.set(
															'mailValidAddr',
															false);
												}
												_self.scrubServiceCounter--;
												_self
														.finalScrubServiceSuccesHandler();
											},
											function() {
												// scrub validation failed save
												// user entered address as
												// validated address
												_self
														.saveUsrEntsMailAddrsAsVAddrs();
												AddressModel.set(
														'mailValidAddr', false);
												_self.scrubServiceCounter--;
												_self
														.finalScrubServiceSuccesHandler();
											}, 0);
						},
						svaeValdtdMAddressToModel : function(postalAddress) {
							var _postalAddress = postalAddress;
							AddressModel.set('mStdAddressLine1',
									_postalAddress.addrLn1Txt);

							AddressModel.set('mStdAddressLine2',
									_postalAddress.addrLn2Txt);

							AddressModel.set('mStdAddressLine3',
									_postalAddress.addrLn3Txt);

							AddressModel.set('mStdCity',
									_postalAddress.postTownNm);

							AddressModel.set('mStdState',
									_postalAddress.RegnAreaCd);
							AddressModel.set('mStdZip', _postalAddress.poCdTxt);
							AddressModel.set('mailValidAddr', true);
							// AddressModel.set('mailClientAddressCheck', true);

							// updating values for verification page
							var _mailAddrs = AddressModel.get('mailingAddress');
							_mailAddrs.addressLine1 = _postalAddress.addrLn1Txt;
							_mailAddrs.addressLine2 = _postalAddress.addrLn2Txt;

							_mailAddrs.addressLine3 = _postalAddress.addrLn3Txt;
							_mailAddrs.entAddressLine1 = _postalAddress.addrLn1Txt;
							_mailAddrs.entAddressLine2 = _postalAddress.addrLn2Txt;
							_mailAddrs.entAddressLine3 = _postalAddress.addrLn3Txt;

							_mailAddrs.city = _postalAddress.postTownNm;
							_mailAddrs.state = _postalAddress.RegnAreaCd;
							_mailAddrs.zip = _postalAddress.poCdTxt;
							AddressModel.set({
								mailingAddress : _mailAddrs
							});
							// updt clnt mail adrs vth validatd address
							var _newClientReqModel = newClientModel
									.get('newClientModel');
							var _client = {}, _mailAdd = {};
							if (_newClientReqModel['customerTypeCd'] == "P") {
								_client = _newClientReqModel['personClient'];
							} else {
								_client = _newClientReqModel['orgClient'];

							}
							_mailAdd = {
								addrLn1 : _postalAddress.addrLn1Txt,
								addrLn2 : _postalAddress.addrLn2Txt,
								addrLn3 : _postalAddress.addrLn3Txt,
								addrUseCd : "Mailing",
								ctyNm : _postalAddress.postTownNm,
								postlCd : _postalAddress.poCdTxt,
								stCd : _postalAddress.RegnAreaCd
							};
							// mail addrs is always saved at 1st index
							_client['postalAddresses'][1] = _mailAdd;
						},
						saveUsrEntdPermAddrsAsVAddrs : function() {
							var _savedPrimaryAddrs = AddressModel
									.get('primaryAddress');
							var _primaryAddress = {
								'addressLine1' : _savedPrimaryAddrs.uAddressLine1,
								'addressLine2' : _savedPrimaryAddrs.uAddressLine2,
								'addressLine3' : _savedPrimaryAddrs.uAddressLine3,
								'entAddressLine1' : _savedPrimaryAddrs.uEntAddressLine1,
								'entAddressLine2' : _savedPrimaryAddrs.uEntAddressLine2,
								'entAddressLine3' : _savedPrimaryAddrs.uEntAddressLine3,
								'city' : _savedPrimaryAddrs.uCity,
								'state' : _savedPrimaryAddrs.uState,
								'zip' : _savedPrimaryAddrs.uZip,
								'country' : _savedPrimaryAddrs.uCountry,
								'province' : _savedPrimaryAddrs.uProvince,
							};
							_primaryAddress = $.extend(_savedPrimaryAddrs,
									_primaryAddress);
							AddressModel.set('primaryAddress', _primaryAddress);

						},
						saveUsrEntsMailAddrsAsVAddrs : function() {
							var _savedMailingAddrs = AddressModel
									.get('mailingAddress');
							var _mailingAddress = {
								'addressLine1' : _savedMailingAddrs.uAddressLine1,
								'addressLine2' : _savedMailingAddrs.uAddressLine2,
								'addressLine3' : _savedMailingAddrs.uAddressLine3,
								'entAddressLine1' : _savedMailingAddrs.uEntAddressLine1,
								'entAddressLine2' : _savedMailingAddrs.uEntAddressLine2,
								'entAddressLine3' : _savedMailingAddrs.uEntAddressLine3,
								'city' : _savedMailingAddrs.uCity,
								'state' : _savedMailingAddrs.uState,
								'zip' : _savedMailingAddrs.uZip
							};
							_mailingAddress = $.extend(_savedMailingAddrs,
									_mailingAddress);
							AddressModel.set('mailingAddress', _mailingAddress);
						},
						svaeValdtdPAddressToModel : function(postalAddress) {
							var _postalAddress = postalAddress;
							AddressModel.set('stdAddressLine1',
									_postalAddress.addrLn1Txt);

							AddressModel.set('stdAddressLine2',
									_postalAddress.addrLn2Txt);

							AddressModel.set('stdAddressLine3',
									_postalAddress.addrLn3Txt);
							AddressModel.set('stdCity',
									_postalAddress.postTownNm);

							AddressModel.set('stdState',
									_postalAddress.RegnAreaCd);
							AddressModel.set('stdZip', _postalAddress.poCdTxt);
							AddressModel.set('validAddr', true);

							// Updating values for verification page

							_prmAddrs = AddressModel.get('primaryAddress');
							_prmAddrs.addressLine1 = _postalAddress.addrLn1Txt;
							_prmAddrs.addressLine2 = _postalAddress.addrLn2Txt;

							_prmAddrs.addressLine3 = _postalAddress.addrLn3Txt;
							_prmAddrs.entAddressLine1 = _postalAddress.addrLn1Txt;
							_prmAddrs.entAddressLine2 = _postalAddress.addrLn2Txt;
							_prmAddrs.entAddressLine3 = _postalAddress.addrLn3Txt;

							_prmAddrs.city = _postalAddress.postTownNm;
							_prmAddrs.state = _postalAddress.RegnAreaCd;
							_prmAddrs.zip = _postalAddress.poCdTxt;

							AddressModel.set({
								primaryAddress : _prmAddrs

							});
							// updt clnt prim adrs vth validatd address
							var _newClientReqModel = newClientModel
									.get('newClientModel');
							var _client = {}, _primAdd = {};
							if (_newClientReqModel['customerTypeCd'] == "P") {
								_client = _newClientReqModel['personClient'];
							} else {
								_client = _newClientReqModel['orgClient'];

							}
							_primAdd = {
								addrLn1 : _postalAddress.addrLn1Txt,
								addrLn2 : _postalAddress.addrLn2Txt,
								addrLn3 : _postalAddress.addrLn3Txt,
								addrUseCd : "Primary",
								ctyNm : _postalAddress.postTownNm,
								postlCd : _postalAddress.poCdTxt,
								stCd : _postalAddress.RegnAreaCd
							};
							// prim addrs is always saved at 0th index
							_client['postalAddresses'][0] = _primAdd;

						},
						finalScrubServiceSuccesHandler : function() {
							if (this.scrubServiceCounter == 0) {
								Utils.unlockForm();
								/*
								 * $('.ncst-step.step3').find('.step-nav-links')
								 * .click();
								 */
								 var _context = GlobalContext.getInstance().getGlobalContext().Context;
								 var _qryStrng =  _context.QueryString ?_context.QueryString:'';
								Backbone.history.navigate(
										'ncst/address-validation'+_qryStrng, {
											trigger : true
										});
							}

						},
						modelSaver : function(validateReqrd) {
							if (this.model.validate(validateReqrd) || this.validateComponents()) {
								this.model.setModel();
								return true;
							} else {
								return false;
							}
						},
						loadCountryList : function() {
							var _countryList = DropdownOptions.countryList;
							var _selectbox1 = "#ma-country-list-select", _selectbox2 = "#country-list-select";
							Utils.loadSelectbox([ _selectbox1, _selectbox2 ],
									_countryList);
						},
						loadUSStatesList : function() {
							var _stateList = DropdownOptions.USStateslist;
							var _selectbox1 = "#ma-state-list-select", _selectbox2 = "#state-list-select";
							Utils.loadSelectbox([ _selectbox1, _selectbox2 ],
									_stateList);
						},
						loadCanadaStatesList : function() {
							var _stateList = DropdownOptions.canadaStateslist;
							var _selectbox1 = "#ma-state-list-select", _selectbox2 = "#state-list-select";
							Utils.loadSelectbox([ _selectbox1, _selectbox2 ],
									_stateList);
						},
						setSavedValues : function() {
							// console.log(_prmAddrs);
							var _model = this.model;
							var _primAddrs = _model.get('primaryAddress');

							$('#zipcode').val(_primAddrs.uZip);
						},
						handleAddressTypeChange : function() {
							/*
							 * To remove error message on from previously option
							 * selection
							 */
							$("#address-entry label.error").addClass("hidden");
							$("#address-entry div").removeClass("error");
							var _$reqdMailingAddrsChk = $('#reqrd-mailing-addrs');
							var _$disabledSpan = _$reqdMailingAddrsChk.parent()
									.find('.disabled-checkbox');
							var _checkedradio = $('input[name="aeAddressType"]:checked');
							var _$zipCodeRow = $('div[data-for=zipcode]');
							var _$zipCode = $("#zipcode").val('');
							$('#country-list-select').val('').trigger('change');
							if (_checkedradio.val() == "U.S") {
								$('#citizenship-rule-help').hide();
								$('input:text').val('');
								$('select').val('').trigger('change');
								// enable mailing address check box
								_$reqdMailingAddrsChk.removeAttr('disabled');
								/*
								 * Mailing address need not be preselected when
								 * US is selected
								 */
								if (_$reqdMailingAddrsChk.prop('checked')) {
									_$reqdMailingAddrsChk.click();
								}
								_$disabledSpan.addClass('hidden');
								_$zipCode.removeClass("canada-zipcode")
										.addClass("us-zipcode");
								// change field type
								if (Utils.isMobile()) {
									_$zipCode.attr('type', 'number');
								} else {
									_$zipCode.attr('type', 'text');
								}
								$("div[data-for=state-list-select]").show();
								$("div[data-for=country-list-select]").hide();
								$("div[data-for=province]").hide();
								_$zipCodeRow.show();
								$("div[data-for=zipcode]div").eq(0).find(
										"label").eq(0).text("Zip code");
                                                                $(".person-address input,.entity-address input").addClass('address').removeClass('foreign-address');         
								// change addresline1 validation
								$('#address-line1,#ent-address-line1,#address-line2,#ent-address-line2,#address-line3,#ent-address-line3')
										.addClass('us-address-1').removeClass('address');
                                                                                        
							} else {
								$('#citizenship-rule-help').show();
								if (!_$reqdMailingAddrsChk.prop('checked')) {
									_$reqdMailingAddrsChk.click();
								}
								$('input:text').val('');
								$('select').val('').trigger('change');
								// for foreign us mailing is mandatory so
								// disable the mailing address checkbox
								_$reqdMailingAddrsChk.attr('disabled', 'true');
								_$disabledSpan.removeClass('hidden');
								$("div[data-for=state-list-select]").hide();
								$("div[data-for=country-list-select]").show();
								$("div[data-for=zipcode]div").eq(0).find(
										"label").eq(0).text("Postal code");
								_$zipCodeRow.hide();
								_$zipCodeRow.find('input').val('').removeClass(
										"required");
								_$zipCode.removeClass("required");
								// change address validation for line1
								$('#address-line1,#ent-address-line1,#address-line2,#ent-address-line2,#address-line3,#ent-address-line3')
										.addClass('address').removeClass('us-address-1');
                                                                $(".person-address input,.entity-address input").addClass('foreign-address').removeClass('address');                        
							}
						},
						handleMailingAddressCheckSelection : function() {
							var _check = $('#reqrd-mailing-addrs');
							if (_check.prop('checked')) {
                                                                this.trackChanges();
								this.model.set('seperateMailingAddress', true);
								$('#ae-ma-mailing-address-container')
										.removeClass('hidden');
							} else {
								this.model.set('seperateMailingAddress', false);
								$('#ae-ma-mailing-address-container').addClass(
										'hidden');
                                                                $('#ae-ma-mailing-address-container input:text').val('');
                                                                $('#ae-ma-mailing-address-container select').val('').trigger('change'); 
        
							}

						},
						validateZipCodeLength : function(e) {
							var _el = e.target;
							try {
								if ($('#ae-address-typ-us').prop('checked')) {
									
									if ($('#zipcode').val().length >= 5
											&& _el.selectionStart == _el.selectionEnd) {
										e.stopPropagation();
										e.preventDefault();
										return false;
									}
								} else if ($('#country-list-select').val() == "CA") {
									if ($('#zipcode').val().length >= 6) {
										e.stopPropagation();
										e.preventDefault();
										return false;
									}
								}
							} catch (e) {
								console.log('no support to selection start property.');
							}
							

						},
						validateZipCodeLengthMa : function(e) {
							var _el = e.target;
							try {
								if ($('#ma-zipcode').val().length >= 5
										&& _el.selectionStart == _el.selectionEnd) {
									e.stopPropagation();
									e.preventDefault();
									return false;
								}
							} catch (e) {
								console.log('no support to selection start property.');
							}
						},
						numValidator : function(obj) {
							var _regxNumOnly = /^\d*$/;
							var _str = String.fromCharCode(event.keyCode);
							if (!_regxNumOnly.test(_str)) {
								obj.stopPropagation();
								if (event.preventDefault)
									event.preventDefault();
								return false;
							}
						},
						handlerForCancel : function() {
							BootstrapDialog
									.confirm(
											"Cancel",
											"All your work will be lost.  Are you sure you want to cancel?",
											function(confirm) {
												if (confirm) {
													window.open('', '_self');
													window.close();
												}
											});

						}
					});
			return addressEntryView;
		});
