// FundDetailsModel.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FundDetailsModelSchema = new mongoose.Schema({
    fundDetails: {
        type: Array,
        "default": []
    }
});

var FundModelLookUp = mongoose.model('FundModelLookUp', FundDetailsModelSchema);

var FundDetailsModel = new FundModelLookUp({
    "fundDetails" : [{
        "reportCategories": {
            "fundOptions": [{
                "category": "all",
                "title": "All"
            }, {
                "category": "fund1",
                "title": "Franklin India Prima Plus"
            }, {
                "category": "fund2",
                "title": "Franklin India Taxshield"
            }, {
                "category": "fund3",
                "title": "Franklin India Balanced Fund"
            }, {
                "category": "fund4",
                "title": "Franklin Dynamic Accrual Fund"
            }, {
                "category": "fund5",
                "title": "Franklin India Prima Plus"
            }]
        }
    }]    
});

FundModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FundDetailsModelLookUp table, please contact admin...');
    } else {
        FundModelLookUp.remove({}, function(err) {
            console.log('FundDetailsModelLookUp collection removed');
            FundDetailsModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating FundDetailsModelLookUp table, please contact admin...');
                }
                console.log('FundDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FundModelLookUp;