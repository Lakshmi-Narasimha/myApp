define(['jquery',
    'lodash',
    'backbone',
    'app/common/util',
], function ($, _, Backbone, utils) {

    var ClientHouseholdModel = Backbone.Model.extend({
        defaults: {
            householdGroupsData: [],
        },
        initialize: function () {
            self = this;
        },
        setHouseholdGroups: function (list) {
            self.set('householdGroupsData', list);
            return self;
        },
        getHouseholdGroups:function () {
            return self.get('householdGroupsData');
        },
        filterByFmtId: function (fmtId) {
            const result = _.filter(self.get('householdGroupsData'), (group) => {
                return group.value.fmtId == fmtId;
            })[0];
            return result;
        },
        formatHouseholdGroupClients: function (groupId) {
            const selHousehold = _.filter(self.get('householdGroupsData'), (group) => {
                return group.groupId == groupId;
            })[0];
            return selHousehold.value.activeClients.results;
        },
        planningGroupDetails: function (householdGroupData, priClName, planningGroupData) {
            let data = [];
            let group = householdGroupData.value;
            let activeClients = group.activeClients || [];
            if(group && activeClients){
                _.each(group.activeClients.results, (client) => {
                    let person =  client.personClient;
                    if(person){
                        let coClientName = person.clFirstNm +' '+ person.clLastNm;
                        coClientName = _.startCase(_.toLower(coClientName));
                        priClName = _.startCase(_.toLower(priClName));
                        let fmtName = (priClName === coClientName) ? priClName : (priClName + ', ' + coClientName);
                        let temp = {
                            groupMemNames: fmtName
                        };
                        let mgpGroup = _.filter(planningGroupData, (mgpGroup) => {
                            return mgpGroup.coClId == client.id;
                        })[0];
                        temp.plnSysName = (mgpGroup && mgpGroup.plnSysCd === 'MGP') ? 'MoneyGuidePro Group' : 'Create MoneyGuidePro Group';
                        fmtName.indexOf(',') === -1 ?  data.unshift(temp) : data.push(temp);
                    }
                });
            }
            return data;
        }
    });
    return ClientHouseholdModel;
});