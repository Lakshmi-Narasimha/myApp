/**
 * @ngdoc property
 * @name Destination Fund Directive
 * @requires newFundDetailsModel
 * @requires $uibModal
 * @requires selectFundModel
 * @description
 *
 * - Destination Fund directive represents the existing funds of investor along with a chance to create a new fund. 
 *
 **/
'use strict';

var fundInfoTile = function() {
	return {
            template: require('./fundInfoTile.html'),
            restrict: 'E',
            replace: true,            
            scope: {
                fundInfoObj : '='
            },
            controller:['$scope','$state', function($scope,$state){  
                if($state.current.url === '/renewsip'){
                    $scope.showRenesipTem =  true;
                }
                else{
                     $scope.showRenesipTem =  false;
                }
                $scope.fundInfoPairs = $scope.fundInfoObj;
            }]
        };

};

fundInfoTile.$inject = [];
module.exports = fundInfoTile;