'use strict';
var smrtsolInvstSummary = function (buildPlanInitialLoader, buildPlanModelService, authenticationService,truncateTextService) {
    return {
        template: require('./smrtsolInvstSummary.html'),
        restrict: 'E',
        replace: true,
        scope: {
            invstSummary: "=",
            investmentSummaryTitle: "=?"
        },

        controller:['$scope', function ($scope) {

            $scope.invType = buildPlanModelService.getInvestmentType();
            $scope.gridData = [];
            $scope.columnDefs = [];
            $scope.fundDetails = buildPlanModelService.getGoalPlanData();
            var width = authenticationService.getAppName()==='advisor' ? (($scope.invType === "Combo") ? 120 : 200) : ($scope.invType === "Combo") ? 120 : 292;
            angular.forEach($scope.fundDetails, function (isDetails) {
                var gridRow = {};
                gridRow = investmentOptions($scope.invType, gridRow, isDetails.installmentDetails);
                gridRow.folioNumber = isDetails.fundName;
                gridRow.allocation = isDetails.allocation;
                $scope.gridData.push(gridRow);
            });
            $scope.totalDetails = buildPlanModelService.getGoalTotalPlanData();
            var myLastRow = {};
            myLastRow = investmentOptions($scope.invType, myLastRow, $scope.totalDetails);
            myLastRow.folioNumber = "Total";
            myLastRow.allocation = $scope.totalDetails.allocation;
            $scope.gridData.push(myLastRow);
            var celltemp = '<div class="ui-grid-cell-contents" title="{{col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)].folioNumber_orignal}}">{{COL_FIELD}}</div>';
            $scope.gridData = truncateTextService.updateLabel($scope.gridData, 'folioNumber', 30);
            $scope.columnDefs = [
<<<<<<< HEAD
                {field: 'folioNumber', displayName: 'Fund Name', width: "210"}];
=======
                {field: 'folioNumber',data: $scope.gridData, cellTemplate: celltemp, displayName: 'Fund Name', width: "210", pinnedLeft: true}];
>>>>>>> ftic-inv-sprint6
            if (buildPlanModelService.tabname == "buildplan" || buildPlanModelService.tabname == "IGT" || buildPlanModelService.tabname === 'recommendedplan') {
                $scope.columnDefs.push({field: 'allocation', displayName: 'Allocation %', width: "105"});
            }
            if ($scope.invType == "Monthly" || $scope.invType == "Combo") {
                $scope.columnDefs.push({
                    field: 'monthly',
                    displayName: 'Monthly',
                    width: 300,
                    headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
                    cellClass:'text-right'
                });
            }
            if ($scope.invType == "Annually" || $scope.invType == "Combo") {
                $scope.columnDefs.push({
                    field: 'annually',
                    displayName: 'Annually',
                    width: 300,
                    headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
                    cellClass:'text-right'
                });
            }
            if ($scope.invType == "One time" || $scope.invType == "Combo") {
                $scope.columnDefs.push({
                    field: 'oneTime',
                    displayName: 'One Time',
                    width: 300,
                    headerCellClass: 'fti-grid-headercell fti-grid-rupeeIcon text-right',
                    cellClass:'text-right'
                });
            }

            function investmentOptions (invType , gridRow, isDetails) {
                if (invType == "Monthly" || invType == "Combo") {
                    gridRow.monthly = isDetails.monthly;
                }
                if (invType == "Annually" || invType == "Combo") {
                    gridRow.annually = isDetails.annually;
                }
                if (invType == "One time" || invType == "Combo") {
                    gridRow.oneTime = isDetails.oneTime;
                }
                return gridRow;
            };
        }]

    };

};

smrtsolInvstSummary.$inject = ['buildPlanInitialLoader', 'buildPlanModelService', 'authenticationService','truncateTextService'];
module.exports = smrtsolInvstSummary;