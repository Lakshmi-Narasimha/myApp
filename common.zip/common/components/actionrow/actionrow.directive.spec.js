/* eslint-disable */
describe('Directive: Action Row', function() {

    var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

           angular.mock.inject(function($rootScope, $compile) {
            scope = $rootScope.$new();
            compile = $compile;            
                //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-action-row></ftic-action-row>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

    // it('span label should be "back", if label is not defined', function(){
    //     var spanText = directiveEle.find('span').text();
    //     expect(spanText).toEqual("Back");
    // });

    it('should compiled element to be defined', function(){
        expect(directiveEle).toBeDefined();
        expect(scope).toBeDefined();
        
    });

    it('should have isolated scope', function(){
        expect(directiveEle.isolateScope()).toBeDefined();
    });

});
