'use strict';

var fundDetailsInitialLoader = function (fundDetailsModel, transactEventConstants, transactEvents, $loader) {

    var fundDetailsInitialLoader = {
        loadAllServices: function (scope) {

            function fundDetailsSuccess(data) {
                fundDetailsModel.setFundDetails(data);
                transactEvents.transact.publishFundDetails(scope);
            }

            function handleFailure() {
                console.log('handleFailure');
            }

            $loader.start();
            fundDetailsModel.fetchFundDetails()
                .then(fundDetailsSuccess, handleFailure)
                .finally(function () {
                    $loader.stop();
                });


        }
    };
    return fundDetailsInitialLoader;
};

fundDetailsInitialLoader.$inject = ['fundDetailsModel', 'transactEventConstants', 'transactEvents', '$loader'];
module.exports = fundDetailsInitialLoader;