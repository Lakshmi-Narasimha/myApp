
function commissionLumpsumController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, sipCalculatorInitialService, sipCalculatorModel,calculatorsEventConstants, calculatorsConstants) {
 $scope.calculatorReq = [];
 $scope.fundName = null;
 $scope.userInput= { 
  Tenure : {
    key: "", 
    text: "Investment Tenure",
    value: "",
    pattern:/^[0-9]*$/,
    message: "",
    isMasked: false,
    isRequired: false ,
    type: "number"                    
  },
  GrossSale : {
    key: "", 
    text: "Gross Sales <span class='icon-fti_rupee'></span>",
    value: "",
    pattern:/^[0-9]*$/,
    message: "",
    isMasked: false,
    isRequired: true ,
    // maxlength: 9 ,
    type: "number"                  
  }
};
$scope.$on('fundType', function(event, fundName) { 
  $scope.fundName = fundName;
});
$scope.onSubmit = function() {
  if($scope.userInput.GrossSale.value < 500 || $scope.userInput.GrossSale.value > 999999999 || $scope.userInput.Tenure.value >40 || ($scope.userInput.Tenure.value != null && $scope.userInput.Tenure.value < 1)) {
    return;
  }
  else {
    $scope.calculatorReq = [{
      "trxnType" : "SIP &Lumpsum",
        "fundCode" :  $scope.fundCode,//Fund Code needs to be dynamic
        "invstTenure" : $scope.userInput.Tenure.value,
        "grossSales" :$scope.userInput.GrossSale.value
      }];
      $scope.$emit(calculatorsEventConstants.RESET_CHART);
      $scope.$emit(calculatorsEventConstants.COMMISSION_CALCULATE_SUBMIT,$scope.calculatorReq);
    }
  };

  $scope.resetForm = function () {
   $scope.$emit(calculatorsEventConstants.RESET_DATA, "lumpsum");
   $scope.userInput.Tenure.value = "";
   $scope.userInput.InstallAmt.value = "";
   $scope.calculatorReq = {};
   $scope.fundCode = '';

 }        
}
commissionLumpsumController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'sipCalculatorInitialService', 'sipCalculatorModel', 'calculatorsEventConstants', 'calculatorsConstants'];
module.exports = commissionLumpsumController;