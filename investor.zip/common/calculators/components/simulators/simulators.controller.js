/**
 * @ngdoc property
 * @name Sales Overview Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function simulatorsController($scope, fticLoggerMessage, loggerConstants) {
  console.log('simulatorsController');
}

simulatorsController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants'];
module.exports = simulatorsController;