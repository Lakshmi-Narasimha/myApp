// fundDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var FundDetailsModelSchema = new mongoose.Schema({
    FundDetailsResp: {
        type: Array,
        'default': []
    }
});

var FundDetailsModelLookUp = mongoose.model('FundDetailsModelLookUp', FundDetailsModelSchema);

var FundDetailsModel = new FundDetailsModelLookUp({
    FundDetailsResp: {
        'fund': {
            'fundDetails': [{
                'clearUnits': '8371.015',
                'lastestNav': '62.2344',
                'loadFreeUnits': '0',
                'navDate': '2017-01-16 00:00:00.0',
                'totalAvailableUnits': '8371.015',
                'unitDetails': {
                    'lienUnits': '0',
                    'unitsUnderProcess': '8371.015',
                    'unitsUnderProvisionalStatus': '0'
                },
                'valueOfLoadFreeUnits': '0',
                'valueOfTotalAvailableUnits': '520965.095916'
            }]
        }
    }
});

FundDetailsModelLookUp.find(function (err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating FundDetailsModelLookUp table, please contact admin...');
    } else {
        FundDetailsModelLookUp.remove({}, function (err) {
            console.log('FundDetailsModelLookUp collection removed');
            FundDetailsModel.save(function (err) {
                if (err) {
                    console.log('Having trouble in creating FundDetailsModelLookUp table, please contact admin...');
                }
                console.log('FundDetailsModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = FundDetailsModelLookUp;