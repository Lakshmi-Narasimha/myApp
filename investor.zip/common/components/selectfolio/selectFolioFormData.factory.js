/**
 * @ngdoc factory
 * @name Investor Dashboard chart factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var invSelectFolioFormDataFactory = function (TransactConstant, investorConstants) {

    var _selectedFolioFormattedData = {};

    var invSelectFolioFormDataFactory = {
        setFormattedCurrentFolio: function (selectedFolio) {
            var _formattedList = {};
            _formattedList.folioId = selectedFolio.folioId;
            _formattedList.index = selectedFolio.index;
            _formattedList.holdingType = selectedFolio.modeofHolding;
            _formattedList.holders = [{
                name: selectedFolio.firstHolderName
            }, {
                name: selectedFolio.secondHolderName
            }, {
                name: selectedFolio.thirdHolderName
            }];
            _selectedFolioFormattedData[selectedFolio.folioId] = _formattedList;
        },
        getCurrentSelectedFolioData: function (folioId) {
            return _selectedFolioFormattedData[folioId];
        },
        getFormattedHolderDetails: function (data) {
            var _holderDetails = [];
            if (data !== null) {
                for (var i = 0; i < data.length; i++) {
                    var folioObj = {
                        folioId: '',
                        labelFolioId: '',
                        firstHolderName: 'NA',
                        firstHolderKyc: 'NA',
                        secondHolderName: 'NA',
                        secondHolderKyc: 'NA',
                        thirdHolderName: 'NA',
                        thirdHolderKyc: 'NA',
                        modeofHolding: '',
                        isFolioKYCReg: false
                    };
                    folioObj.labelFolioId = 'Folio ' + data[i].folioId;
                    folioObj.folioId = data[i].folioId;
                    folioObj.modeofHolding = data[i].holdingType;
                    for (var j = 0; j < data[i].holders.length; j++) {
                        var kycRegCount = 0;
                        if (data[i].holders[j].type === TransactConstant.common.FIRST_HOLDER) {
                            folioObj.firstHolderName = data[i].holders[j].name;
                            folioObj.firstHolderKyc = data[i].holders[j].kycStatus;
                            if(folioObj.firstHolderKyc === investorConstants.accountsettings.KYC_STS_REG){
                                kycRegCount++;
                            }
                        }
                        if (data[i].holders[j].type === TransactConstant.common.SECOND_HOLDER) {
                            folioObj.secondHolderName = data[i].holders[j].name;
                            folioObj.secondHolderKyc = data[i].holders[j].kycStatus;
                            if(folioObj.secondHolderKyc === investorConstants.accountsettings.KYC_STS_REG){
                                kycRegCount++;
                            }
                        }
                        if (data[i].holders[j].type === TransactConstant.common.THIRD_HOLDER) {
                            folioObj.thirdHolderName = data[i].holders[j].name;
                            folioObj.thirdHolderKyc = data[i].holders[j].kycStatus;
                            if(folioObj.thirdHolderKyc === investorConstants.accountsettings.KYC_STS_REG){
                                kycRegCount++;
                            }
                        }
                    }
                    if(kycRegCount === data[i].holders.length){
                        folioObj.isFolioKYCReg = true;
                    }
                    //$scope.holderDtls.push(folioObj);
                    folioObj.custName = folioObj.firstHolderName;
                    folioObj.pan = data.pan ? data.pan : '';
                    folioObj.email = data.emailId ? data.emailId: '';
                    folioObj.mobile = data.mobile ? data.mobile: '';
                    folioObj.holders = data[i].holders;
                    _holderDetails.push(folioObj);
                }
                return _holderDetails;
            }else {
                return _holderDetails;
            }
        }
    };
    return invSelectFolioFormDataFactory;

};

invSelectFolioFormDataFactory.$inject = ['TransactConstant', 'investorConstants'];
module.exports = invSelectFolioFormDataFactory;
