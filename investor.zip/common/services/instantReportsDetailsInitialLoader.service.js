/**
 * @ngdoc service
 * @name instant reports inital loader service
 * @requires instantReportsDetailsModel
 * @requires guestEvents
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Instant reports inital loader will set the data and braodcast an event on success and consoles error on failure.
 *
 */
'use strict';

var instantReportsDetailsInitLoader = function (instantReportsDetailsModel, events, fticLoggerMessage, loggerConstants) {
    
    var instantReportsDetailsInitLoader = {
        _isServicesData: false,    
        getInstantReportsService : function (scope, userType) {

            var message =  loggerConstants.COMMON_COMPONENTS_MODULE + ' | ' + loggerConstants.REPORTS_DETAILS + ' | ' + loggerConstants.INSTANT_REPORTS_DETAILS_INITIAL_LOADER_SERVICE + ' | getInstantReportsService' /* Function Name */; 
                    fticLoggerMessage.displayLoggerMessage({level:'info', 'message': message});
            
            instantReportsDetailsModel.fetchInstantReportsDetails(userType)
                .then(instantReportsDetailsSuccess, handleFailure);

            function instantReportsDetailsSuccess(data) {
                instantReportsDetailsModel.setInstantRepsDtls(data);
                events.publishInstantReportsDetails(scope);

            };

            function handleFailure (data) {
                console.error('handleFailure');
                instantReportsDetailsInitLoader._isServicesData = false;

            };
        }
        
    };
    return instantReportsDetailsInitLoader;
};

instantReportsDetailsInitLoader.$inject = ['instantReportsDetailsModel', 'events', 'fticLoggerMessage', 'loggerConstants'];

module.exports = instantReportsDetailsInitLoader;