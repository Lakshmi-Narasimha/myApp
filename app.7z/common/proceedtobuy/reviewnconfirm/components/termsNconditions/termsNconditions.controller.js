/**
 * @ngdoc property
 * @name newFundModalController Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function reviewTermsAndConditionsController($scope, $uibModalStack,loginModelService,constants,tcAndSTPopupModel, authenticationService) { 


   
    
    console.log($scope.chkTnCs+'checkvalueinmodel');
    $scope.accpted=false;
    $scope.accept=function(){
    	
    	//loginModelService.setChoosenOptionData($scope.accpted);
    	$scope.$emit('accptedTermsAndConditions');
    	console.log($scope.chkTnCs+'checkvalueinmodelafterclick');
    	$scope.closeModal();
    };
    $scope.doNotAccept=function(){
$scope.$emit('rejectedTermsAndConditions');
    	$scope.closeModal();
    };
     $scope.closeModal = function(){
        
        $uibModalStack.dismissAll();
    };

    if(authenticationService.isInvestorLoggedIn()) {
        $scope.contentForTC = tcAndSTPopupModel.getPopUpContent()['accounts-content']['tc-investor-online'].content;
    } else {
        $scope.contentForTC = tcAndSTPopupModel.getPopUpContent()['accounts-content']['tc-advisor-online'].content;        
    }
    
}


reviewTermsAndConditionsController.$inject = ['$scope', '$uibModalStack','loginModelService','constants','tcAndSTPopupModel', 'authenticationService'];

module.exports = reviewTermsAndConditionsController;