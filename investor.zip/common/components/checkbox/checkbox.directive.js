/**
 * @ngdoc property
 * @name Checkbox directive
 * @requires $state
 * @description
 *
 * - Checkbox is a component directive which can be resused across different forms in the application.
 *
 **/
'use strict';

var checkBox = function($state, eventConstants) {
	return {
            template: require('./checkbox.html'),
            restrict: 'E',
            replace: true,
            scope: {
              checkboxObject: '=',
              showActionIcon: '@',
              actionClass: '@',
              disable: '='
            },
            controller: function($scope, $element, $attrs){  
            },
            link: function(scope, iElement, iAttrs, controller){
                scope.updateParent = function($event){
                    $event.stopPropagation();
                    scope.$emit(eventConstants.CHECKBOX_CHECKED, scope.checkboxObject);
                };
                if(scope.showActionIcon) {
                    scope.$on(eventConstants.ACTION_ICON_CLICKED, function(){
                        scope.$emit(eventConstants.CHK_ACTION_CLICKED, scope.checkboxObject);
                    });
                }

            }
        };
};

checkBox.$inject = ["$state", 'eventConstants'];
module.exports = checkBox;