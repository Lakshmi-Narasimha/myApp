'use strict';

/*Unit test case for cancelPayment*/

    describe('directive: cancelPayment', function() {

    var scope, compile, validHTML, timeout;

    validHTML = '<cancel-payment></cancel-payment>';

    beforeEach(module('component.validationutils'));
    beforeEach(module('CSS.billing'));
    beforeEach(module('CSS.common'));
    beforeEach(module('component.tile'));
    beforeEach(module('templates'));
    beforeEach(function() {
        module(function($provide) {
            $provide.constant('componentConstant', {
                'policy_status_constants': {
                    'active': 'A',
                    'cancelled': 'C',
                    'expired': 'E'
                }
            });
        });
    });
    beforeEach(inject(function($compile, $rootScope, $timeout) {
        scope = $rootScope.$new();
        compile = $compile;
        timeout = $timeout;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();

        return compiledElem;
    }

   

    describe('when changing the scope values', function() {

        beforeEach(function() {    
            validHTML = "<cancel-payment></cancel-payment>";
            scope.$digest();
        });

        it('should have a populated scope', function() {
            var el = create();
            var isolate = el.isolateScope();
        });
    });

    // TO DO

});
