/* 

	Static file server for doing server-side includes

	To Install:
		1.) Put the package.json (with dependencies for express and connect-ssi) in the root folder of your project 
		2.) npm install 
		3.) node server.js (this file name) 

	Supported include directives:
	
		<!--# include file="path" -->

*/
var express = require('express');
var connectSSI = require('connect-ssi');
var app = express();
var staticRoot = __dirname + '/src';

app.use(connectSSI({
    baseDir: staticRoot,
    ext: '.html'
}));
app.use(express.static(staticRoot));

var server = app.listen(9035, function() {
	var port = server.address().port;
	console.log("Brokerage app starting at " + port + " serving static files from " + staticRoot);
});