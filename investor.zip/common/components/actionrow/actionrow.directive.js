/**
 * @ngdoc directive
 * @name fticactionrow
 * @description
 *
 * - It displays a array of buttons which need to be passed while declaring this directive.
 * 
**/

'use strict';

var buttonsList = function($compile){
	return {
		template : require('./actionrow.html'),
		restrict : 'E',
		replace :true,
		scope : {
			buttonsArray : '='
		},
		controller: function($scope, $element, $attrs){
		},
		link: function(scope, iElement, iAttrs, controller){
			scope.doSomething = function(){
				console.log(1234);
			};
		},

	};
};

buttonsList.$inject = ['$compile'];
module.exports = buttonsList;


