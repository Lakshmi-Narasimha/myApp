/**
 * @ngdoc property
 * @name fticRedemptionForm Directive
 * @requires MyInvestorConstant
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Redemption Form.
 *
 **/
'use strict';


var InvRedeemDetails = function(transactModel, invEformPaymentBanksUtility, authenticationService, smartSavingsAccountModel, invSmartSavingsModel, redeemModel, ifscModel, transactEventConstants, transactEvents, selectFundModel, $state, TransactConstant, toaster, fundDetailsModel, $stateParams, $timeout, bankDtlsModel, $loader) {
    return {
        template: require('./invRedeemDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller: function($scope, $element, $attrs, $state) {
            var bankOptions = [];
            $scope.paymentBankOptions = [];
            $scope.bankName = '';
            $scope.required = true;
            $scope.isIfscVisble = false;
            $scope.isBranchVisble = false;
            $scope.config = {};
            $scope.$amountInput = $element[0].querySelector('.amountInput input');
            $scope.config.showNotification = false;
            $scope.modeSelectedVal = 'Cheque';
            redeemModel.setMode('Cheque');
            $scope.amountObject = {
                key: 'Fixed Amount',
                text: 'Fixed Amount $',
                value: '',
                type: 'number'
            };
            //$scope.selected =[{ title:'select', key: 'select' }];
            $scope.bankEventName = 'bankEventTriggered';

            $scope.bankOptionValues = {
                name: 'bankDetails',
                required: true
            };

            function displayBankDetails() {
                var bankDtls = bankDtlsModel.getBankDetails().paymentBank;
                var bankArr = [{ title: 'select Bank', key: 'select' }];
                for (var i = 0; i < bankDtls.length; i++) {
                    var bank = { title: bankDtls[i].pbBankName + ' - ' + bankDtls[i].pbPersonalAccountNumber };
                    bankArr.push(bank);
                }
                $scope.bankOptions = null;
                $scope.bankOptions = bankArr;
                $scope.selected = $scope.bankOptions[0];
                $scope.bankName = $scope.bankOptions[0].title;
            }

            if (bankDtlsModel.getBankDetails() !== null) {
                displayBankDetails();
            }

            $scope.$on('RedeemDetails', function() {
                $scope.getPaymentBank();
                $timeout(function() {
                    displayBankDetails();
                });
                $scope.modeSelectedVal = 'Cheque';
                $scope.amountObject.value = '';

            });

            $scope.skipAndProceed = function() {
                $state.transitionTo('dashboard');
            };



            $scope.$on('bankEventTriggered', function(event, data) {
                $scope.isBranchVisble = false;
                $scope.ifsc.ifscCode ='';
                $scope.bankName = data.title;
                if ($scope.modeSelectedVal === 'Direct Credit') {
                    $scope.loadIFSCDetails($scope.bankName);
                }
                redeemModel.setBank(data.title);
            });

            $scope.getPaymentBank = function() {
                var params = {};
                params.folioId = '122334';
                params.trxnType = 'P';
                params.guId = authenticationService.getUser().guId;
                bankDtlsModel.fetchBankDetails(params).then(function(data) { //Populate PaymentBanks

                    bankDtlsModel.setBankDetails(data);
                    bankOptions = bankDtlsModel.getBankDetails();
                    setBankFilters(bankOptions);

                }, function(error) {
                    if (error.data && error.data.length > 0) {
                        toaster.error(error.data[0].errorDescription);
                    }
                }).finally(stopLoader);

            };

            var stopLoader = function() {
                $loader.stop();
            };

            $scope.loadIFSCDetails = function(bankName) {
                if (!bankName) {
                    $scope.isIfscVisible = false;
                } else {
                    $scope.isIfscVisible = true;
                    $scope.$broadcast('bankSelected', { title: bankName });
                }
            };

            $scope.$on('ifscSrchRes', function(event, data) {
                $scope.isBranchVisble = true;
                $scope.branch = data.bankDetails;
                $scope.address = data.bnkAdd;
            });

            $scope.modeChanged = function(val) {
                redeemModel.setMode(val);
                if (val === 'Direct Credit') {
                    $scope.loadIFSCDetails($scope.bankName);
                }
            };

            $scope.errors = {};

            $scope.saveRedeemInstruction = function() {

                $scope.errors = {};
                if (invSmartSavingsModel.getPurchaseDtls()) {
                    $scope.purchaseAmount = invSmartSavingsModel.getPurchaseDtls().amount;
                } else if (invSmartSavingsModel.getSmartSavingsData()) {
                    $scope.purchaseAmount = invSmartSavingsModel.getSmartSavingsData().instructionAmount;
                }
                if (!$scope.amountObject.value) {
                    $scope.errors.amount = 'Please enter Other Amount to proceed further.';
                } else if ($scope.amountObject.value && ($scope.amountObject.value > $scope.purchaseAmount)) {
                    $scope.errors.amount = 'The Other Amount entered should be less than or equal to the Available Amount for the Fund.';
                } else if ($scope.amountObject.value.toString().indexOf('.') > -1) {
                    $scope.errors.amount = 'The Other Amount(Redeem) field should not contain decimals.';
                }
                if ($scope.bankName === 'select Bank') {
                    $scope.errors.bank = 'Please select bank name and account number in Bank details to proceed.';
                }
                if ($scope.modeSelectedVal === 'Direct Credit' && $scope.ifsc.ifscCode === undefined) {
                    $scope.errors.ifsc = 'Please enter an IFSC code in ‘Direct Credit’ to proceed further';
                }
                if (angular.equals($scope.errors, {})) {
                    redeemModel.setAmount($scope.amountObject.value);
                    var redeemDetails = {
                        'amount': redeemModel.getAmount(),
                        'modeOfPayment': redeemModel.getMode(),
                        'bankDetails': redeemModel.getBank(),
                        'IFSCCode': $scope.ifsc.ifscCode,
                        'branch': $scope.branch,
                        'address': $scope.address
                    };
                    redeemModel.setRedeemDetails(redeemDetails);
                    smartSavingsAccountModel.transactDetails = redeemModel.getRedeemDetails();
                    makeServiceCall();
                }
            };

            function makeServiceCall() {
                var validateParams = {};
                var params = {};
                validateParams.amount = smartSavingsAccountModel.transactDetails.amount;
                validateParams.txnType = 'R';
                validateParams.batchCode = TransactConstant.common.BATCH_CODE;
                validateParams.paymentBankAccNo = smartSavingsAccountModel.transactDetails.bankDetails.split('-')[1].trim();
                validateParams.paymentBankName = smartSavingsAccountModel.transactDetails.bankDetails.split('-')[0].trim();
                validateParams.bankAccountNumber = smartSavingsAccountModel.transactDetails.bankDetails.split('-')[1].trim();
                validateParams.bankName = smartSavingsAccountModel.transactDetails.bankDetails.split('-')[0].trim();
                validateParams.ifscCode = smartSavingsAccountModel.transactDetails.ifscCode;
                validateParams.branch = smartSavingsAccountModel.transactDetails.branch;
                validateParams.address = smartSavingsAccountModel.transactDetails.address;
                validateParams.modeOfPayment = smartSavingsAccountModel.transactDetails.modeOfPayment;
                validateParams.amountUnitFlag = 'A';
                validateParams.webRefNo = '';
                var bankDtls = bankOptions.paymentBank;
                for (var i = 0; i < bankDtls.length; i++) {
                    if (bankDtls[i].pbPersonalAccountNumber === validateParams.paymentBankAccNo) {
                        validateParams.paymentMode = bankDtls[i].paymentType;
                    }
                }
                validateParams.source = authenticationService.getUser().userType;
                params.guId = authenticationService.getUser().guId;
                invSmartSavingsModel.postValidateRedeemDtls(validateParams).then(validateSuccess, handleFailure);
            }

            function validateSuccess() {
                $scope.$emit('redeemDetailsSaveInstruction');
            }

            function handleFailure(errorResp) {
                console.log('validate redeem error');
                toaster.error(errorResp.data[0].errorDescription);
            }

            function setBankFilters(bankOptions) {
                if (bankOptions) {
                    invEformPaymentBanksUtility.populateBanks('paymentBank', bankOptions.paymentBank, $scope.paymentBankOptions); //Payment Methods
                }
            }


            $scope.$on('redeemGetDetails', function(data) {
                if (!redeemModel.getRedeemDetails()) {
                    $scope.getPaymentBank();
                    displayBankDetails();
                    $scope.amountObject.value = data.targetScope.invRedeemData.amount;
                    $scope.modeSelectedVal = data.targetScope.invRedeemData.modeOfPayment;
                    $scope.selected = data.targetScope.invRedeemData.bankDetails;
                    if ($scope.modeSelectedVal === 'Direct Credit') {
                        $scope.isBranchVisble = true;
                        $scope.branch = data.targetScope.invRedeemData.branch;
                        $scope.address = data.targetScope.invRedeemData.address;
                        $scope.ifsc.ifscCode = data.targetScope.invRedeemData.IFSCCode;
                    }
                } else {
                    $scope.selectedReedeem = redeemModel.getRedeemDetails();
                    $scope.amountObject.value = $scope.selectedReedeem.amount;
                    $scope.modeSelectedVal = $scope.selectedReedeem.modeOfPayment;
                    $scope.selected = $scope.selectedReedeem.bankDetails;
                    if ($scope.modeSelectedVal === 'Direct Credit') {
                        $scope.isBranchVisble = true;
                        $scope.branch = $scope.branch;
                        $scope.address = $scope.address;
                        $scope.ifsc.ifscCode = $scope.ifsc.ifscCode;
                    }
                }
            });
        }
    };
};

InvRedeemDetails.$inject = ['transactModel', 'invEformPaymentBanksUtility', 'authenticationService', 'smartSavingsAccountModel', 'invSmartSavingsModel', 'redeemModel', 'ifscModel', 'transactEventConstants', 'transactEvents', 'selectFundModel', '$state', 'TransactConstant', 'toaster', 'fundDetailsModel', '$stateParams', '$timeout', 'bankDtlsModel', '$loader'];
module.exports = InvRedeemDetails;
