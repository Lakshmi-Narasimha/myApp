 
 function loginMasterController($scope,$state,advisorRegistrationModelService,$cookies,constants,appConfig){
        $scope.submitDistributor = function(){ 
        	//if($scope.distributorForm.$valid){
              $scope.displayError = "";
         	    $scope.$broadcast('arnsubmitted');
              $scope.formData=advisorRegistrationModelService.getArnData();
              $scope.formData.regType="Adviser";
              if(!$scope.formData.panARN){
                $scope.displayError = "ARN field cannot be empty";
              }else if(!$scope.formData.dobOrRegDate){
                $scope.displayError = "Please enter ARN registration date";
              }else{
              var postSuccess = function (response) {
                      advisorRegistrationModelService.setUserData(response.data);
                      $cookies.put('accessToken',response.data.accessToken, {'domain': appConfig.DOMAIN_CONFIG});
                      $state.go('loginmaster.userverification.securityquestion'); 
               };
               
               var handleFailure = function (errorResp){ 
                  //$scope.displayError = errorResp.data[0].errorDescription;
                  $scope.displayError = constants.login.FU_WARNING_TEXT;
               };
               
               advisorRegistrationModelService.postArnOrDobForFUNameDetails($scope.formData).then(postSuccess, handleFailure);
                
               // $state.go('loginmaster.userverification.securityquestion');
        	}
        	
        }
}
loginMasterController.$inject = ['$scope','$state','advisorRegistrationModelService','$cookies','constants','appConfig'];
module.exports = loginMasterController;