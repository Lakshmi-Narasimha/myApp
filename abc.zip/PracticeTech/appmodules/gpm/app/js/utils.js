define(
        ['jquery','errorLog','appcommon/commonutility'],
        function ($,ErrorLog,CommonUtils) {
            var _ = {
            		loadSelectbox: function (options) {
                        var _optionsData = options.optionsList;
                        var _options = '';
                        if (!options.noEmptyOption ) {
                    		var _isSelected ="";
                    		if(options.selectedVal == "" || options.selectedVal == null || options.selectedVal == undefined){
                    			_isSelected = "selected";
                    		}
                    		_options += '<option '+_isSelected+' disabled value= "" >Choose one</option>';
                        }
                        
                        $.each(_optionsData, function (key, row) {
                        	var _val = row.code || row.value
                        	if(options.selectedVal == _val){
                        		 _options += '<option selected name="' + row.name + '" value="'
                                 + _val + '" >' + row.name + '</option>';
                        	}else{
                        		 _options += '<option name="' + row.name + '" value="'
                                 + _val + '" >' + row.name + '</option>';
                        	}
                           
                        });
                        if(options.isOptional){
                        	var _noneOption = options.noneOption?options.noneOption:{val:"",label:"None"};
                        	var _slectedAttr = ""
                        	if(options.selectedVal == _noneOption.value && options.selectedVal !=""){
                        		_slectedAttr = "selected"
                        	}
                       	 _options += '<option value="'+_noneOption.value+'" '+_slectedAttr+'>'+_noneOption.label+'</option>';
                       }
                        if (Array.isArray(options.selectBox)) {
                            $(options.selectBox.join(',')).html(_options);
                        } else {
                            $(options.selectBox).html(_options);
                        }

                    },
                    getTemplateSection:function(template,dataSection){
    		        	var _templt = $(template).find(dataSection).html();
    		        	return _templt;
    		        
                    },
                    isMobile: function () {
                        var _regxMob = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
                        return _regxMob.test(navigator.userAgent);
                    },
                    showNoChangesMessageToUser: function () {
                        BootstrapDialog.alert("You have not made any changes on this Step. Before you proceed, you must update at least one field.", "", "Field(s) not changed");
                    },
                    logError : function(error,customMessage,showPopup) {
                    	if(error.responseJSON){
                    		error.responseJSON = JSON.parse(CommonUtils.normalizeWS(JSON.stringify(error.responseJSON)));
                    	}
    					if(customMessage){
    					ErrorLog.ErrorUtils.myError(error,true);
    						//this.logError(error.message, error.url, error.lineNum);
    					}else{
    						var _hidePopup = showPopup?false:true;
    						ErrorLog.ErrorUtils.prepareAndLogError(error,_hidePopup);
    					}
    				
    				},
    				showServiceError:function(response,isEbix){
    					var _errMsg="System unavailable", _errDes="The system is currently unavailable. Please try again later.",_showRedErrorBox = true,_isInlineError = false,_errorCode="";
    					var _errorCodemapping  = {
    							"errorCode9000":{
    								errorMessage:"Invalid country code entered."
    							},
    							"innererror1017":{
    								errorMessage:"Invalid email address."
    							}
    					}
    					if(response.status != null || response.status != undefined){
    						var _httpStatCd = response.status;
    						switch (_httpStatCd) {
    							case 200: 
    								_showRedErrorBox = false;
    								break;
    						 	case 401: 
    	                            _errMsg = "Unauthorized access";
    	                            _errDes = "You are not authorized to use this application.";
    	                            break;
    	                        case 500: 
    	                        	if(response.responseJSON){
    	                        		_showRedErrorBox = false;
    	                        		_errorCode = getErrorCode(_httpStatCd,response.responseJSON);
    	                        		if(_errorCode.length > 0 ){
    	                        			_isInlineError = true;
    	                        		}
    	                        	}else if(response.responseText){
    	                        		_showRedErrorBox = false;
    	                        		try {
    	                        			_errorCode = getErrorCode(_httpStatCd,JSON.parse(response.responseText));
										} catch (e) {
											//invalid response format 
										}
    	                        		
    	                        		if(_errorCode.length > 0 ){
    	                        			_isInlineError = true;
    	                        		}
    	                        	}
    	                            break;
    	                        default: 
    	                            _errMsg = "System unavailable";
    	                            _errDes = "The system is currently unavailable. Please try again later.";
    	                            break;
							}
    						if(_isInlineError == false){
    							if(_showRedErrorBox == false){
        							//do not show red error box 
        							_.logError(response,false,true);
        						}else{
        							_.logError(response);
        							var _$errCtnr  =$('.gpm-alert-row').removeClass("hidden");
        							_$errCtnr.find('.service-error-title').html(_errMsg);
        							_$errCtnr.find('.service-error-desc').html(_errDes);
        							$(window).scrollTop(0);
        						}	
    						}else{
    							var _errMsg = _errorCodemapping[_errorCode].errorMessage;
    							var _$errCtnr = $('[data-error-code="'+_errorCode+'"]');
    								_$errCtnr.addClass("error");
    								_$errCtnr.find('label.error:first').removeClass("hidden").text(_errMsg);
    								_$errCtnr[0].scrollIntoView(true);
    						}
    						
    						
    					}
    					function getErrorCode(_httpStatCd,resp){
    						var _errCd = "";
    						switch (_httpStatCd) {
							case 200:
								
								break;
							case 500:
								if(resp.error && resp.error.errorCode){
									_errCd = "errorCode"+resp.error.errorCode;
								}else if(resp.error && resp.error.innererror){
									_errCd = "innererror"+resp.error.innererror;
								}
								break;
							default:
								break;
    						}
    						if (typeof _errorCodemapping[_errorCode] != "undefined") {
    						    return _errCd;
    						} else {
                                return "";
                            }
    						
    					}
    				}
            };
            return _;

        });
