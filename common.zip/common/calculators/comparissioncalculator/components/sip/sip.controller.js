
function siptabController($scope, $state, toaster, $timeout, eventConstants, fticLoggerMessage, loggerConstants, $cookies, authenticationService, comparisonCalculatorInitialService, comparisonCalculatorModel,calculatorsEventConstants) {


  $scope.init();

  $scope.selectOptions = {
    'Fund' : [],
    'Frequency' : []
};


  $scope.$on(calculatorsEventConstants.COMPARISON_FUND_DETAILS, function(){
    
    if($scope.radios.selectedVal === $state.current.parent +'.sip') {
      $scope.selectOptions.Fund.push({'title':'Select Fund', 'category' : '', 'minSipAmount': 500});
      var fundlist = comparisonCalculatorModel.getFundDetails().allfunds.newFunds;
      for(var fd=0, len=fundlist.length;fd<len;fd++) {
        $scope.selectOptions.Fund.push({
          'title' : fundlist[fd].fundDesc,
          'category' :  fundlist[fd].fundOption,
          'minSipAmount' : fundlist[fd].minSipAmt,
      });    
    }
}
});

$scope.selectOptions.Frequency = [
{
    title: 'Select Frequency'
},
{
    title:'Monthly'   
},
{
    title: 'Quarterly'
}
]; 

$scope.selectedType = 'fundType';

$scope.inputObject = {
 Fund :{
   required:true,
   name : 'fundSelection',
   label: 'Select Fund'
},
Frequency :{
   required:true,
   name : 'freqSelection',
   label: 'Select Frequency'
}
};


$scope.userInput= { 
 Amount: {
    key: '', 
    text: 'Investment Amount',
    value: '',
    pattern:/^[0-9]*$/,
    message: '',
    isMasked: false,
    isRequired: true,
    type: 'text',
    name: 'amount'
},
Tenure : {
    key: '', 
    text: 'Investment Tenure',
    value: '',
    pattern:/^[0-9]*$/,
    message: '',
    isMasked: false,
    isRequired: true ,
    type: 'text',
    name: 'tenure'              
},
Annual : {
 key: '', 
   text: 'Enter Expected Rate of Return',
   value: '',
 // pattern:/^[0-9]*$/,
 message: '',
 isMasked: false,
 isRequired: false,
 maxlength: 6,
 disable:true,
 type: 'text',
 name: 'annual'
}
};

$scope.reload = true;
$scope.reloadFrequency = true;
$scope.listenChange = function() {
  $scope.TypeSelected = $scope.selectedType;
  if($scope.selectedType === 'fundType')
  {
    $scope.userInput.Annual.disable = true;
    $scope.userInput.Annual.isRequired = false;
    $scope.inputObject.Fund.disable = false;
    $scope.inputObject.Fund.required = true;
    $scope.userInput.Annual.value = '';
    $scope.reload = true;
}
else
{
    $scope.userInput.Annual.disable = false;
    $scope.userInput.Annual.isRequired = true;
    $scope.inputObject.Fund.disable = true;
    $scope.inputObject.Fund.required = false;
    $scope.fundType.fundCode ='';
    $scope.reload = false;
    $timeout(function () {
      $scope.reload = true;
  },0);
} 
};

$scope.formInvalid = true;
$scope.calculatorReq=[];
$scope.fundType = [];
$scope.fundType.fundCode ='';
$timeout(function () {
  $scope.$on('selectedFund', function(event, data){ 
   $scope.sipcalculatorform.$submitted = false;                
   $scope.fundType.fundName = data.title;
   $scope.fundType.fundCode = data.category;
   $scope.fundType.minSipAmount = data.minSipAmount;
 });
},0);
$scope.$on('selectedFrequency', function(event, data){  
 $scope.sipcalculatorform.$submitted = false; 
 $scope.fundType.frequency = data.title; 
});

$scope.resetForm = function () {
  $scope.selectedType = null;
  $scope.reload = false;
  $scope.reloadFrequency = false;
  $scope.$broadcast(calculatorsEventConstants.COMPARISON_RESET_DATA);
  $timeout(function () {
    $scope.selectedType= 'fundType';
    $scope.reload = true;
    $scope.reloadFrequency = true;
    $scope.userInput.Tenure.value = '';
    $scope.userInput.Amount.value = '';
    $scope.fundType.fundCode = '';
    $scope.userInput.Annual.value = '';
    $scope.inputObject.Fund.disable = false;
    $scope.inputObject.Fund.required = true;
    $scope.userInput.Annual.disable = true;
    $scope.userInput.Annual.isRequired = false;
    $scope.calculatorReq = {};
    $scope.tenureErrorvalue = $scope.userInput.Tenure.value;
  }, 0);
};
$scope.onSubmit = function() {
 $scope.$broadcast(calculatorsEventConstants.COMPARISON_RESET_DATA);
 $scope.tenureErrorvalue = parseInt($scope.userInput.Tenure.value);
 if($scope.userInput.Amount.value < $scope.fundType.minSipAmount || $scope.userInput.Amount.value > 999999 || $scope.userInput.Tenure.value > 40 ||
  $scope.userInput.Tenure.value < 1 || (($scope.userInput.Annual.value >99 || $scope.userInput.Annual.value < 1) && ($scope.userInput.Annual.isRequired))) {
  return;
}else if (!$scope.checkWholeNumPattern($scope.userInput.Tenure.value) || !$scope.checkWholeNumPattern($scope.userInput.Amount.value) ){
        return;
}else if($scope.userInput.Annual.isRequired && !$scope.checkWholeNumPattern($scope.userInput.Annual.value)) {
    return;
}else {

  $scope.calculatorReq = 
  [{
    'investmentTenure': $scope.userInput.Tenure.value,
    'annualizedReturn' : $scope.userInput.Annual.value,
    'investmentAmount' : $scope.userInput.Amount.value,
    'fundName' : $scope.fundType.fundCode,
    'frequency' : $scope.fundType.frequency,
    'trxnType' : 'SIP'
  }];

  $scope.$emit(calculatorsEventConstants.COMPARISON_FUND_SUBMIT, $scope.calculatorReq);
}
};
$scope.checkWholeNumPattern = function(field){
                var patt = /^[0-9]*$/;
                // var result = patt.test($scope.userInput.Tenure.value);
                var result = patt.test(field);                
                return result;
};
$scope.inputChanged = function(data){
  $scope.sipcalculatorform.$submitted = false;
  $scope.tenureErrorvalue = parseInt(data.value);
}; 
$scope.amountValue = function(){
    $scope.sipcalculatorform.$submitted = false;
}; 

}

siptabController.$inject = ['$scope', '$state', 'toaster', '$timeout', 'eventConstants', 'fticLoggerMessage', 'loggerConstants', '$cookies', 'authenticationService', 'comparisonCalculatorInitialService', 'comparisonCalculatorModel','calculatorsEventConstants'];
module.exports = siptabController;