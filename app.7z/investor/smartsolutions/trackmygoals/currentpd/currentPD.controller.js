
'use strict';
function smartSolsCurrentPdCtrl($scope, $state, authenticationService, investorDashboardDetailsModel, currentPlanFundsInitalLoaderService, currentPlanFundsService, recommendedPlanModelService, investorEventConstants) {
  $scope.topupOptions = [{
    "title": "Top-up with",
    "category" : "topup"
  }, {
    "title": "Same Funds",
    "category" : "samefunds"
  }, {
    "title": "FT Recommended Funds",
    "category" : "ftrecommended"
  }];

  $scope.$on("selectedTopup", function (event, data) {
    if(data.category=="samefunds"){
        console.log("current state for same funds",$state.current.name);
        recommendedPlanModelService.setRecommendedFromState($state.current.name);
        $state.go("smartSol.trackmygoals.topupwithsf.topupwithsamefunds");
    }
    else if(data.category=="ftrecommended"){
      recommendedPlanModelService.setRecommendedFromState($state.current.name);
      $state.go("smartSol.trackmygoals.topupwithftrf.topupwithftrecommendedfunds");
    }
  });

   var params = {
      "guId" : authenticationService.getUser() ? authenticationService.getUser().guId : null
    };
    var userDetails = investorDashboardDetailsModel.getDashboardData();
      if(userDetails) {
          params.folioPanNo = (userDetails && userDetails.profileDetails && userDetails.profileDetails.pan ) ? userDetails.profileDetails.pan : '';
      }


  currentPlanFundsInitalLoaderService.loadAllServices($scope, params);
  $scope.goalChartData = {
    data : [],
    goalAmount : null
  };
  $scope.$on(investorEventConstants.smartSolutions.CURR_GOAL_DATA, function($event){
    $scope.goalChartData.data = currentPlanFundsService.getGoalChartDetails().data.reverse();
    $scope.goalChartData.goalAmount = currentPlanFundsService.getGoalChartDetails().goalAmount;
  });
  
 
        $scope.modify=function(){
          $state.go("smartSol.investor.modifymain.modify");
          recommendedPlanModelService.setRecommendedFromState($state.current.name)
        };
      
}

smartSolsCurrentPdCtrl.$inject = ['$scope', '$state', 'authenticationService', 'investorDashboardDetailsModel', 'currentPlanFundsInitalLoaderService', 'currentPlanFundsService','recommendedPlanModelService', 'investorEventConstants'];
module.exports = smartSolsCurrentPdCtrl;