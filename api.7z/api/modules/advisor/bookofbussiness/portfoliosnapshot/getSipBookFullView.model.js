// getSipBookFullView.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var SipBookFullViewSchema = new mongoose.Schema({
    SipBookFullViewObject: {
        type: Array,
        "default": []
    }
});

var SipBookFullViewLookUp = mongoose.model('SipBookFullViewLookup', SipBookFullViewSchema);

var SipBookFullViewModel = new SipBookFullViewLookUp({

	"SipBookFullViewObject": [{			
			"overview" : [
				{
					"type" : "Total SIPs",  						
					"sips" : 200,
					"amt" : 9.43
				},
				{
					"type" : "New SIPs", 
					"sips" : 20,
					"amt" : 8.36
				},
				{
					"type" :"SIPs Matured",
					"sips" : 10,
					"amt" : 2.98
				},
				{
					"type" : "SIPs Cancelled",
					"sips" : 12,
					"amt" : 6.78
				},
				{
					"type" : "Active SIPs",
					"sips" : 100,
					"amt" : 1.29
				}	
			],
			"details" :[{
				"allfunds":[
					{
						"type" :"PERPETUAL SIPs",
						"forthemonth" : {
							"count" : 15,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 15,
							"amt" : 5.00
						}	
					},
					{
						"type":"AVERAGE TICKET SIZE",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIP / UNIQUE INVESTOR",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs DUE FOR RENEWAL",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH STEPUP",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH PAUSES",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type" : "SIP INSTALLMENT REJECTIONS",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					}
				],
				"diversifiedEquity":[
					{
						"type" :"PERPETUAL SIPs",
						"forthemonth" : {
							"count" : 25,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 15,
							"amt" : 5.00
						}	
					},
					{
						"type":"AVERAGE TICKET SIZE",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIP / UNIQUE INVESTOR",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs DUE FOR RENEWAL",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH STEPUP",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH PAUSES",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type" : "SIP INSTALLMENT REJECTIONS",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					}
				],
				"debtAndLiquid":[
					{
						"type" :"PERPETUAL SIPs",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 15,
							"amt" : 5.00
						}	
					},
					{
						"type":"AVERAGE TICKET SIZE",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIP / UNIQUE INVESTOR",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs DUE FOR RENEWAL",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH STEPUP",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH PAUSES",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type" : "SIP INSTALLMENT REJECTIONS",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					}
				],
				"fundOfFunds":[
					{
						"type" :"PERPETUAL SIPs",
						"forthemonth" : {
							"count" : 45,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 15,
							"amt" : 5.00
						}	
					},
					{
						"type":"AVERAGE TICKET SIZE",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIP / UNIQUE INVESTOR",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs DUE FOR RENEWAL",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH STEPUP",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH PAUSES",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type" : "SIP INSTALLMENT REJECTIONS",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					}
				],
				"balanced":[
					{
						"type" :"PERPETUAL SIPs",
						"forthemonth" : {
							"count" : 55,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 15,
							"amt" : 5.00
						}	
					},
					{
						"type":"AVERAGE TICKET SIZE",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIP / UNIQUE INVESTOR",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs DUE FOR RENEWAL",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH STEPUP",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH PAUSES",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type" : "SIP INSTALLMENT REJECTIONS",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					}
				],
				"sectorEquity":[
					{
						"type" :"PERPETUAL SIPs",
						"forthemonth" : {
							"count" : 65,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 15,
							"amt" : 5.00
						}	
					},
					{
						"type":"AVERAGE TICKET SIZE",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIP / UNIQUE INVESTOR",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs DUE FOR RENEWAL",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH STEPUP",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type":"SIPs WITH PAUSES",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					},
					{
						"type" : "SIP INSTALLMENT REJECTIONS",
						"forthemonth" : {
							"count" : 35,
							"amt" : 5.00
						},
						"businesstomonth" : {
							"count" : 35,
							"amt" : 5.00
						}	
					}
				]			
			}]
	}]

});

SipBookFullViewLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating SipBookFullViewLookUp table, please contact admin...');
    } else {
        SipBookFullViewLookUp.remove({}, function(err) {
            console.log('SipBookFullViewLookUp collection removed');
            SipBookFullViewModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating SipBookFullViewLookUp table, please contact admin...');
                }
                console.log('SipBookFullViewLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = SipBookFullViewLookUp;
