/**
 * @ngdoc service
 * @name switchDtlsToReviewModel
 * @description
 *
 * - It will have the setter and getter components of switch details
 *
 */

'use strict';

var switchDtlsToReviewModel = function (Restangular, $q, authenticationService, transactModel,fundDetailsModel, TransactConstant) {
    var _detailsObj = null, _type = null;


    var switchDtlsToReviewModel = {

        fetchTxnDetailsSwitch : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('getTxnDetailsSwitch').get(params).then(function (switchDetails) {
                deferred.resolve(switchDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },

        validateSwitch: function(){
            var deferred = $q.defer();
            var params = {};
            var body = {};      
            body.folioId = transactModel.getTransactDetails().investorDetails.folioId;
            // body.amount = transactModel.getTransactDetails().transactDetails.type === 'Amount' ? parseFloat(transactModel.getTransactDetails().switchDetails.amount).toFixed(2).toString() : '';
            // body.units = transactModel.getTransactDetails().transactDetails.type === 'Units' ? parseFloat(transactModel.getTransactDetails().switchDetails.units).toFixed(2).toString() : '';
            body.amount = transactModel.getTransactDetails().switchDetails.amount ? parseFloat(transactModel.getTransactDetails().switchDetails.amount).toFixed(2).toString() : '';
            body.units = transactModel.getTransactDetails().switchDetails.units ? parseFloat(transactModel.getTransactDetails().switchDetails.units).toFixed(2).toString() : '';
            
            body.accountNo = transactModel.getTransactDetails().fundDetails.tschvalAccno;
            console.log('transactModel.getTransactDetails()', transactModel.getTransactDetails());
            // body.sbCode = 
            body.webRefNo = "";
            body.txnNo = '';
            body.txnType = "S";
            body.fundOption = transactModel.getTransactDetails().fundDetails.tschvalAccno.substring(0,3) || '';
            if(transactModel.getTransactDetails().switchDetails.destinationFund.accNo){
                body.toAccount = transactModel.getTransactDetails().switchDetails.destinationFund.accNo;
            }else{
                body.toAccount = 'NEW';
            }
            body.toFundOption = transactModel.getTransactDetails().switchDetails.destinationFund.fundOption;
            body.dividendOption = transactModel.getTransactDetails().switchDetails.destinationFund.dividendFlag;
            body.amountUnitFlag = body.amount ? "A" : "U";
            if(transactModel.getTransactDetails().switchDetails.switchType === 'Full') {
                body.amountUnitFlag = "U";
                body.units = parseFloat(fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits.replace(',','')).toFixed(2).toString();
                body.amount = parseFloat(fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.replace(',','')).toFixed(2).toString();
                // body.amount = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[1].substring(0, 2);
            } else {
                body.amountUnitFlag = body.amount ? "A" : "U";
            }

            //body.amountUnitFlag = transactModel.getTransactDetails().switchDetails.switchType === 'Full' ? "U" : body.amount ? "A" : "U";
            body.allUnitsFlag = ((transactModel.getTransactDetails().switchDetails.switchType.toLowerCase()) === 'partial') ? "N" : "Y";
            body.batchCode = TransactConstant.common.BATCH_CODE;
            body.subDist = "";
            body.subBrokerARN = "";
            body.source = authenticationService.getUser().userType;
            params.guId = authenticationService.getUser().guId;
            Restangular.one('transact/validateSwitch').customPOST(body, "", params, {}).then(function (data) {
                deferred.resolve(data);
            }, function (resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        
        getData: function() {
            return _detailsObj;
        },

        setDataObj: function(detailsObj) {            
            _detailsObj = detailsObj;
        },
        setType : function(type) {
            _type = type;
        },

        getType : function() {
            return _type;
        },
        isSwitchEdited:false
    };
    return switchDtlsToReviewModel;
};

switchDtlsToReviewModel.$inject = ['Restangular' ,'$q', 'authenticationService', 'transactModel','fundDetailsModel', 'TransactConstant'];
module.exports = switchDtlsToReviewModel;