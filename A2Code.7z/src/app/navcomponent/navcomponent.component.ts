import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef  } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalDirective } from 'ng2-bootstrap';
import { AIAssistCacheService } from '../_services/aiassistcache.service';
import { AuthenticationService } from '../_services/authentication.service';
@Component({
  selector: 'navcomponent',
  templateUrl: './navcomponent.component.html',
  styleUrls: ['./navcomponent.component.css']
})
export class NavcomponentComponent implements OnInit {
  @ViewChild('jsonModal') public jsonModal:ModalDirective
  returnUrl: string;
  userName: string = "";
  isAdminUser: boolean = false;
  viewModel: any = {};
  constructor(private route: ActivatedRoute, private router: Router,private aiAssistCacheService: AIAssistCacheService, private authenticationService:AuthenticationService) {
        this.subscribeForServices();
  }

  ngOnInit() {
  }

  PublishIntents() {
    this.aiAssistCacheService.navigatePublishIntents();
  }

  subscribeForServices() {
    this.aiAssistCacheService.currentUserObservable.subscribe((data) => {
      if (data) {
        this.userName=data.userName;
        if (data.isAdminUser) {
          this.isAdminUser = data.isAdmin;
        } else {
          this.isAdminUser = false;
        }
      } else {
        this.userName = "";
      }
    });
    if(!this.userName) {
      this.userName = this.aiAssistCacheService.currentUser.userName;
      this.isAdminUser = this.aiAssistCacheService.currentUser.isAdmin;
    }

  }

  logoutFromApp() {
    // reset login status
    this.authenticationService.logout();

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  public openSearch() : void {
    this.viewModel.openSearch = true;
  }
  public closeSearch() : void {
    this.viewModel.openSearch = false;
  }

  public openJsonModal(data) : void {
    console.log(data)
    this.jsonModal.show();
  }


}
