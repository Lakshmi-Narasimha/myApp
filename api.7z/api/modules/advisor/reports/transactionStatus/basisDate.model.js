// getBasisDateFinancial.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var BasisDateModelSchema = new mongoose.Schema({
    basisDateDetails: {
        type: Array,
        "default": []
    }
});

var BasisDateModelLookUp = mongoose.model('BasisDateModelLookUp', BasisDateModelSchema);

var BasisDateModel = new BasisDateModelLookUp({
    "basisDateDetails" : [{
        "basisDateFinancialTransactions" : {
            "statusDetails": [{
                "transactionType": "Purchase",
                "source": "Webiste",
                "firstHolderName": "Shankar Narayanan",
                "folioNo": 4563152,
                "accountNo": 1256789187,
                "fund": "Franklin India Prima Plus",
                "amount": 13.90,
                "reportedDate": "12 Apr 2016",
                "processedDate": "15 Apr 2016",
                "status": "Processed"
            }, {
                "transactionType": "Redemption",
                "source": "CAMS",
                "firstHolderName": "George Fernandez",
                "folioNo": 8761029,
                "accountNo": 981716987,
                "fund": "Franklin India Taxshield",
                "amount": 34.90,
                "reportedDate": "19 Mar 2016",
                "processedDate": "22 Mar 2016",
                "status": "Rejected"
            }, {
                "transactionType": "Switch",
                "source": "Karvy",
                "firstHolderName": "Gayatri Iyer",
                "folioNo": 1782716,
                "accountNo": 7615418276,
                "fund": "Franklin India Balanced Fund",
                "amount": 15.78,
                "reportedDate": "15 Feb 2016",
                "processedDate": "26 Feb 2016",
                "status": "Clarification"
            }, {
                "transactionType": "SWP Registration",
                "source": "Website",
                "firstHolderName": "Anu VS",
                "folioNo": 1928716,
                "accountNo": 7625487191,
                "fund": "Franklin Dynamic Accrual Fund",
                "amount": 28.12,
                "reportedDate": "11 Jan 2016",
                "processedDate": "28 Jan 2016",
                "status": "Under Process"
            }],
            "lastBussinessDay": "02 Feb 2016"
        },
        "basisDateNonFinancialTransactions" : {
            "statusDetails": [{
                "transactionType": "Change of Address",
                "firstHolderName": "Shankar Narayanan",
                "folioNo": 4563152,
                "accountNo": 1256789187,
                "fund": "Franklin India Prima Plus",
                "processedDate": "12 Apr 2016",
                "status": "Under Process"
            }, {
                "transactionType": "Change of Name",
                "firstHolderName": "George Fernandez",
                "folioNo": 8761029,
                "accountNo": 981716987,
                "fund": "Franklin India Taxshield",
                "processedDate": "12 Apr 2016",
                "status": "Rejected"
            }, {
                "transactionType": "Change of Bank",
                "firstHolderName": "Gayatri Iyer",
                "folioNo": 1782716,
                "accountNo": 7615418276,
                "fund": "Franklin India Balanced Fund",
                "processedDate": "15 Feb 2016",
                "status": "Processed"
            }],
            "lastBussinessDay": "02 Feb 2016"
        }
    }]
    
});

BasisDateModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating BasisDateModelLookUp table, please contact admin...');
    } else {
        BasisDateModelLookUp.remove({}, function(err) {
            console.log('BasisDateModelLookUp collection removed');
            BasisDateModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating BasisDateModelLookUp table, please contact admin...');
                }
                console.log('BasisDateModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = BasisDateModelLookUp;