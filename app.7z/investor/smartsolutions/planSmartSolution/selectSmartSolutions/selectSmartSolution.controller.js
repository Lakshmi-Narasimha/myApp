/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function selectSmartSolutionController($scope, $state, transactModel, eventConstants, buildPlanModelService, recommendedPlanModelService, $timeout) {
    $scope.holderInfo = false;
    $scope.goalDescEntered = false;
    $scope.holderInfoArray = [];
    $scope.selectedInvestorDtls = [];
    $scope.returnSlabs = ["Since Inception", "1 Year", "3 Years"];
    $scope.smartSolutionOptions = {};
    $scope.smartSolutionOptions.goalSelectionCheck = true;
    $scope.smartSolutionOptions.goalDescrition = true;
    buildPlanModelService.isNewInvestor = false;
    $scope.selFmlySolnErrorDis = false;
    $scope.netBankOptions = [
        {
            title: "Select",
            key: ''
        },
        {
            title: "Child\'s Education",
            key: 'child'
        },
        {
            title: 'Retirement',
            key: 'retirement'
        },
        {
            title: 'Holiday',
            key: 'holiday'
        },
        {
            title: 'Cash Management',
            key: 'cash'
        },
        {
            title: 'Dream Home',
            key: 'dream'
        },
        
        {
            title: 'Cash Management',
            key: 'cash'
        },
        {
            title: 'Dream House',
            key: 'dream'
        },
        
        {
            title: 'Wealth Creation',
            key: 'wealth'
        },
        {
            title: 'Tax Planning',
            key: 'tax'
        },
        {
            title: 'Customize your Plan',
            key: 'customize'
        }
    ];
    $scope.userInput = {
        GoalDesc: {
            key: "",
            text: "Goal Description",
            value: "",
            message: "",
            isMasked: false,
            isRequired: true,
            maxlength:20,
            ngfocus:'eventContinue()',
            pattern: /^[a-zA-Z0-9]{1,20}/
        }
    };
    /*$scope.$on("investorSearch", function () {
     $scope.holderInfo = true;
     $scope.holderInfoArray = null;
     $scope.investorDetails =  buildPlanModelService.getInvestorSearch();
     $scope.holderInfoArray = [
     {key:"First Holder",value:buildPlanModelService.getInvestorSearch().custName},
     {key:"Second Holder",value:buildPlanModelService.getInvestorSearch().holders[1].name},
     {key:"Third Holder",value:buildPlanModelService.getInvestorSearch().holders[2].name},
     {key:"Folio. No.",value:buildPlanModelService.getInvestorSearch().folioId},
     {key:"Mode of Holding",value:buildPlanModelService.getInvestorSearch().holdingType}
     // {key:$filter('translate')(advisorConstants.collaterals.CITY),value:eformModel.getSelectedUser().city},
     ];
     console.log($scope.holderInfoArray);
     });*/

    $scope.statusTypes = [
        {
            label: "Existing Investor",
            value: "Existing Investor",
            selected: false
        },
        {
            label: "New Investor",
            value: "New Investor",
            selected: false
        }
    ];
    $scope.setData = function () {
        console.log('setData');
        $state.go("smartSol.planSmartSolution.selectFolio");
        /*if ($scope.planInputDtlsForm.$valid) {
            $scope.selFmlySolnErrorDis = true;
            
        } else{
            $scope.selFmlySolnError = "Please Select Family Solution";
            $scope.goalChanged();
        }*/
    };
    /* $scope.setData = function($event){var holders = selectedInvestorDtls.holders,
     kycregistered = true;
     $scope.showPopup = false;

     // transactModel.setInvestorDetails(selectedInvestorDtls);
     // transactModel.setSearchOption(searchData.searchOption);
     // transactModel.setSearchText(searchData.searchText);
     // selectInvestorModel.setSelectedInvestorDtls(selectedInvestorDtls);

     angular.forEach(holders,function(obj,ind){
     if(!obj.kycStatus)
     {
     kycregistered = false
     }
     })

     if(!kycregistered)
     {
     $scope.popupText = "Please complete KYC registration of all holders to proceed with the transaction."
     $scope.yesText = "Continue with KYC";
     $scope.noText = "Cancel";
     $timeout(function(){$scope.showPopup = true;},0)
     $scope.$on("yes",function(){
     $scope.showPopup = false;
     $state.go("smartSol.planSmartSolution.kycPlanSS"); //has to go to "transact.base.ekycReg"
     return;
     });
     }
     else
     {
     $scope.$emit(transactEventConstants.transact.Investor_Details);
     }
     }*/
    $scope.radios = {selectedVal: "Existing Investor"};
    buildPlanModelService.setSelectInvType($scope.radios.selectedVal);

    $scope.listenChange = function () {

        $scope.showTab = null;
        if ($scope.radios.selectedVal === "Existing Investor") {
            buildPlanModelService.isNewInvestor = false;
            // $state.go('smartSol.planSmartSolution.selectSS.existingSS');
            //$timeout(function(){$scope.showTab = false;});
        }
        else if ($scope.radios.selectedVal === 'New Investor') {
            buildPlanModelService.isNewInvestor = true;
            $timeout(function () {
                $scope.showTab = true;
            });
        };

        buildPlanModelService.setSelectInvType($scope.radios.selectedVal);

    };   
    $scope.checkForm = function() {
        if($scope.goalDescEntered && $scope.selFmlySolnErrorDis) {
            return false;
        } else {
            return true;
        }
    }

    $scope.$on('INPUT_CHANGED', function(){
        if($scope.userInput.GoalDesc.value) {
            $scope.goalDescEntered = true;
        } else {
            $scope.goalDescEntered = false;
        }
        $scope.checkForm();
    });

    $scope.eventName = 'selectedFundOption';
    $scope.$on($scope.eventName, function (event, selectedOption) {
        if(selectedOption.title !== "Select") {
            $scope.selFmlySolnErrorDis = true;
            $scope.smartSolutionOptions.goalSelectionCheck = false;
            recommendedPlanModelService.setSelectedSmartSoln(selectedOption);
        }
        else {
            $scope.selFmlySolnErrorDis = false;
            $scope.smartSolutionOptions.goalSelectionCheck = true;
        }
        $scope.checkForm();
    });
    $scope.invAccordionClicked = function () {
        buildPlanModelService.setGoalDesc($scope.userInput.GoalDesc.value);
    };

    /*var destroyErrorMsg = $scope.$on('GoalDescDisplayError', function () {
        $timeout(function(){
            $scope.goalDescError = "Please enter goal description.";
        },0);
        destroyErrorMsg();
    });

    var destroyErrorMsglength = $scope.$on('GoalLengthDescDisplayError', function () {
        $timeout(function(){
            $scope.goalDescError = "Goal description should be less than 20 characters.";
        },0);
        destroyErrorMsglength();
    });*/

    $scope.goalChanged = function () {
        if($scope.userInput.GoalDesc.value === undefined || $scope.userInput.GoalDesc.value.length == 0) {
            $scope.goalDescError = "Please enter goal description.";
            $scope.smartSolutionOptions.goalDescrition = true;
        }else if($scope.userInput.GoalDesc.value.length > 20){
            $scope.goalDescError = "Goal description should be less than 20 characters.";
            $scope.smartSolutionOptions.goalDescrition = true;
        }
        else {
            $scope.goalDescError = null;
            $scope.smartSolutionOptions.goalDescrition = false;
        }
    };

}
selectSmartSolutionController.$inject = ['$scope', '$state', 'transactModel', 'eventConstants', 'buildPlanModelService', 'recommendedPlanModelService', '$timeout'];
module.exports = selectSmartSolutionController;