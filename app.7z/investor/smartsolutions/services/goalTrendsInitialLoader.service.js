'use strict';

var goalTrendsInitialLoaderService = function (goalTrendsModel, advisorEvents, advisorEventConstants) {

    var goalTrendsInitialLoader = {
        _isServicesData: false,
        loadAllServices : function (scope,params) {

            goalTrendsModel.fetchAttrAnalysisDtls(scope,params)
                .then(goalTrendsSuccess, handleFailure);

            function goalTrendsSuccess(data) {
                console.log(data)
                goalTrendsModel.setAttrAnalysisDtls(data);
                advisorEvents.smartSolutions.publishGoalTrends(scope);

            }

            function handleFailure(data){
                console.error('handleFailure');
                goalTrendsInitialLoader._isServicesData = false;
            }
        }

    };
    return goalTrendsInitialLoader;
};

goalTrendsInitialLoaderService.$inject = ['goalTrendsModel', 'advisorEvents', 'advisorEventConstants'];

module.exports = goalTrendsInitialLoaderService;