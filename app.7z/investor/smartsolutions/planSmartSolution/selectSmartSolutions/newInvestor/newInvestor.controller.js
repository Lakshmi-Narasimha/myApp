/**
 * @ngdoc property
 * @name Plan Input Details Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Plan Input Details controller for guest module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function newInvestorController($scope, $state,advisorConstants,transactModel,eventConstants,buildPlanModelService,advisorEventConstants,recommendedPlanModelService) {
 	console.log('newInvestorController');
   
 }
newInvestorController.$inject = ['$scope', '$state','advisorConstants','transactModel','eventConstants','buildPlanModelService','advisorEventConstants','recommendedPlanModelService'];
module.exports = newInvestorController;