/**
 * @ngdoc directive
 * @name fticPanDetails
 * @requires $scope
 * @description
 *
 * - fticPanDetails will display floatable input control.
 * 
 **/

'use strict';
var panDetails = function (constants, advisorRegistrationModelService, $filter, $timeout) {
    return {
        template: require('./panDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {
            formObj: '='
        },
        controller: ['$scope', function ($scope) {
            $scope.formData = {};
            $scope.panObject = {
                key: 'pan',
                text: 'PAN',
                value: '',
                name: 'pan',
                isRequired: true,
                type: 'text'
            };

            $scope.dateOptions = {
                yearRows: 4,
                yearColumns: 3,
                fulldatepickerMode: 'year',
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                formatDayTitle: 'MMM yyyy',
                datepickerMode: 'day',
                showWeeks: false,
                maxDate: new Date()
            };

            $scope.$on('INPUT_CHANGED', function () {
                $timeout(function () {
                    $scope.formData.panARN = $scope.panObject.value.trim();
                    advisorRegistrationModelService.setPanData($scope.formData);
                    $scope.$emit('panDetailsChange');
                });
            });

            $scope.dateChange = function () {
                $scope.formData.dobOrRegDate = $filter('date')($scope.startDate, 'dd/MM/yyyy');
                advisorRegistrationModelService.setPanData($scope.formData);
                $scope.$emit('panDetailsChange');
            };

            $scope.$on(constants.login.PAN_SUBMTTED_TEXT, function (event) {
                $scope.formData.panARN = $scope.panObject.value;
                $scope.formData.dobOrRegDate = $filter('date')($scope.startDate, 'dd/MM/yyyy');
                advisorRegistrationModelService.setPanData($scope.formData);
            });
        }]
    };
};

panDetails.$inject = ['constants', 'advisorRegistrationModelService', '$filter', '$timeout'];
module.exports = panDetails;