/**
 * @ngdoc factory
 * @name selectFundGrid factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var racFundDetailsFactory = function() {

    var racFundDetailsFactory = {
        getFormattedFundDetails: function(userType, invDetails, fundDetails, isSwitchFund) {
            var _fundDetails = [];
            if (userType && (userType.toString() === '10')) {
                _fundDetails = [{
                    text: isSwitchFund ? 'Source Fund' : 'Fund',
                    value: fundDetails.fmDescription
                }, {
                    text: 'Account Number',
                    value: fundDetails.tschvalAccno
                }];
            } else {

                _fundDetails = [{
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    text: 'Account No.',
                    value: fundDetails.tschvalAccno
                }, {
                    text: 'Fund',
                    value: fundDetails.fmDescription
                }];
            }
            return _fundDetails;
        },
         getFormattedRenewFundDetails: function(userType, invDetails, fundDetails, isSwitchFund) {
            var _fundDetails = [];
            if (userType && (userType.toString() === '10')) {
                _fundDetails = [{
                    text: isSwitchFund ? 'Source Fund' : 'Fund',
                    value: fundDetails.fundOptionDesc
                }, {
                    text: '',
                    value: fundDetails.existingAccNo
                }];
            } else {

                _fundDetails = [{
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    text: 'Account No.',
                    value: fundDetails.tschvalAccno
                }, {
                    text: 'Fund',
                    value: fundDetails.fmDescription
                }];
            }
            return _fundDetails;
        },
           getFormattedSTPFundDetails: function(userType, invDetails, fundDetails) {
            var _fundDetails = [];
            if (userType && (userType.toString() === '10')) {
                _fundDetails = [{
                    text: 'Source Fund',
                    value: fundDetails.fmDescription
                }, {
                    text: 'Account No.',
                    value: fundDetails.tschvalAccno
                }];
            } else {

                _fundDetails = [{
                    text: 'Folio No.',
                    value: invDetails.folioId
                }, {
                    text: 'Account No.',
                    value: fundDetails.tschvalAccno
                }, {
                    text: 'Fund',
                    value: fundDetails.fmDescription
                }];
            }
            return _fundDetails;
        },
        getFormattedCstpFundDetails: function (userType, invDetails, fundDetails) {
            var _fundDetails = [];  
                _fundDetails = [{
                    text: 'Source Fund',
                    value: fundDetails.sourceFundDesc
                }, {
                    text: 'Destination Fund',
                    value: fundDetails.destFundDesc
                }, {
                    text: 'STP Amount',
                    value: fundDetails.amount
                }, {
                    text: 'Frequency',
                    value: fundDetails.frequency
                }, {
                    text: 'STP Start Date',
                    value: fundDetails.startDate
                }, {
                    text: 'STP End Date',
                    value: fundDetails.endDate
                }];
        
            return _fundDetails;
        },
        getExactHeaderText: function(userType) {
            if (userType && (userType.toString() === '10')) {
                return 'FUND_DETAILS';
            } else {
                return 'FUND_DET';
            }

        },
        getFormattedDtpFundDetails: function (userType, invDetails, fundDetails) {
            var _fundDetails = [];  
                _fundDetails = [{
                    text: 'Source Fund',
                    value: fundDetails.fmDescription + ' ' + fundDetails.tschvalAccno
                }, {
                    text: 'Balance Units',
                    value: fundDetails.balUnits
                }, {
                    text: 'Current Value',
                    value: fundDetails.marketValue
                }];
            
            return _fundDetails;
        },
    };
    return racFundDetailsFactory;

};

racFundDetailsFactory.$inject = [];
module.exports = racFundDetailsFactory;
