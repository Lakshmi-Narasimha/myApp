/**
 * @ngdoc service
 * @name sendEmailService
 * @description
 *
 * - EmailService JSON  / Method
 */
/*global Visualforce*/
(function() {
    'use strict';

    angular.module('CSS.common').service('sendEmailService', ['$http', '$q', function($http, $q) {

        this.sendEmail = function(queryData) {
            var deferred = $q.defer();
            Visualforce.remoting.Manager.invokeAction('CSS_SelfRegController.sendEmailRest', queryData,
                function(result, event) {
                    if (event.status) {
                        deferred.resolve(JSON.parse(result));
                    } else {
                        deferred.reject(event);
                    }
                }, {
                    escape: false
                });

            return deferred.promise;
        };        
        
    }]);

})();