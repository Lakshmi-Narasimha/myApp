var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var sendMessageModel = require('./sendMessage.model');
var getMessageModel = require('../getMessage/getMessage.model');
var apiUtils = require('../../common/apiUtils');
var async = require("async");
var myCache = require('../../../api-server');
var proxy = require('../../../config/proxy');
var request = require('request');

// api route
router.route('/mfchatnode/rest/message')
    .post(function(req, res) {       
        logger.general.info(logger.formatInBoundReqMsg(req));
        req.uri = sendMessageModel.createRequestUri;
        req.body.RequestParams = req.body.RequestParams || {};
        if(req.body.RequestParams.mqtt && !myCache.get(req.session.engagementID+".isRecurEnabled")){
            myCache.set(req.session.engagementID+".mqtt",req.body.RequestParams.mqtt); 
            myCache.set(req.session.engagementID+".isRecurEnabled", true);
             logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop started with EngagementID: "+ req.session.engagementID)); 
            logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop started with EngagementID: "+req.session.engagementID)); 
            // polling started
            //apiUtils.getMsgRecursive(req, res, function(){});
            function getMsgReccursive(){                        
                    apiUtils.formattedGetMsg(req, res, function(chunk) {                       
                        res.status(200).end();
                        if(chunk){
                            return;
                        }else{
                            getMsgReccursive();
                        }                        
                    });

                }                     
                getMsgReccursive();
            res.send(sendMessageModel.response);
        }else{
            var msgCount = parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"),10) || 0;
            myCache.set(req.session.engagementID+".chatSendMsgCounter", msgCount+1);  
            if(req.body.RequestParams.state && req.body.RequestParams.state === 'closed'){
                myCache.set(req.session.engagementID+".closed", true);
                myCache.set(req.session.engagementID+".chatSendMsgCounter", msgCount-1);  
                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + "{'state': 'closed'}" + ' MQTT:' + myCache.get(req.session.engagementID+".mqtt"));
            }else{
                logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + req.body.RequestParams.messageText);
            }
            var post_data = req.body.RequestParams; 
            var reqObj = {
                url:'https://'+req.uri.host + req.uri.path,
                agent: proxy.agent,            
                ca:proxy.ca,            
                headers: {                
                    'Cookie': req.session.sessionCookie,
                    'Content-Type': 'application/json'
                    },
                form:post_data
            }            
            logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
            request.post(reqObj,function(err,response,body){
                if(err){ 
                        logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
                }else{                    
                        logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));                    
                }
                if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                    parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && 
                    parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 2) {
	                    myCache.set(req.session.engagementID+".isAssisted", true);
	                    apiUtils.assisted(req,res,function(response) {});
	                    apiUtils.saveMDN(req,res,function(response) {});
	            }
                res.send(sendMessageModel.response);
            });           
        }      
    });

module.exports = router;
