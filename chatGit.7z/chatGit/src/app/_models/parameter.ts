export class Parameter {

  displayOrder: Number;
  fieldLabel: string;
  fieldName: string;
  fieldType: string;
  fieldValues: any;
  paramFieldId: Number; 
  paramType: string;
  paramTypeId: Number;
  response: string;
  paramValue: any;
  intentId: string;

  textValue: string;
  selectValue: string;
  radioValue: string;
  checkValue: boolean;

  parsedFieldValues: Array<any>;

  isModified: boolean;

}
