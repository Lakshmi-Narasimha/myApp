'use strict';

var investorGoalModelService= function(Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _selectedInvestor = null,
        _goalInvestor = null,
        _selectedInvestorDetails = null,
        _selectedGoal = null;
    var selectedInvestorModel = {
        
        fetchGoalTrackingDtls : function (params) {

            var deferred = $q.defer();
            // getGoalInvestorData
            Restangular.one('smartsolution/fsGoalSummary').get(params).then(function (attrDetails) {
                deferred.resolve(attrDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setGoalInvestorData : function(data){
            _goalInvestor = data;
        },
        getGoalInvestorData : function(){
            return _goalInvestor;
        },

        getInvestorData : function () {
            return _selectedInvestor;
        },
        setInvestorData : function (data) {
            _selectedInvestor = data;
        },
        getSelectedInvestorDetails : function () {
            return _selectedInvestorDetails;
        },
        setSelectedInvestorDetails : function (data) {
            _selectedInvestorDetails = data;
        },
        setSelectedGoalData : function (selectedGoal) {
            _selectedGoal = selectedGoal;
        },
        getSelectedGoalData : function () {
            return _selectedGoal;
        }

    };
    return selectedInvestorModel;

};

investorGoalModelService.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];
module.exports = investorGoalModelService;
