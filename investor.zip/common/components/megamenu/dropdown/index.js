'use strict';

module.exports = angular.module('commmon.components.dropdown', [])
	.directive('fticUtilityDropdownMenu', require('./utilityDropdown.directive.js'))
;