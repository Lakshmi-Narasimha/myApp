import { Component, OnInit, ViewChild, NgModule } from '@angular/core';
import { Agent } from '../_models/agent';
import { ModalDirective } from 'ng2-bootstrap';
import { FormsModule } from '@angular/forms';

import { AIAssistCacheService } from '../_services/aiassistcache.service';

@Component({
  selector: 'agentcomponent',
  templateUrl: './agentcomponent.component.html',
  styleUrls: ['./agentcomponent.component.css']
})
export class AgentcomponentComponent implements OnInit {

  @ViewChild('newAgentModal') public newAgentModel:ModalDirective;
  @ViewChild('removeAgentModal') public removeAgentModel:ModalDirective;

  newAgentmodel: any = {};
  formErrors : any = {};
  agentsList : Array<Agent> = [];
  selectedAgent: Agent = null;
  oldAgent : Agent = null;
  showAgentDropdown: any = false;
  private agentDropdownList: Array < any > = [];


    constructor(private aiAssistCacheService : AIAssistCacheService) { this.subscribefordata();}
    public selected(value: any): void {
    }
    private subscribefordata() {
      this.aiAssistCacheService.agentListObservable.subscribe((data) => {
        this.agentsList = data || [];
        this.showAgentDropdown = true;
        this.agentsList.forEach((agent: {name: string,agentId: string}) => {
            this.agentDropdownList.push({
                id: agent.agentId,
                text: agent.name
            });
        });
        this.oldAgent =  this.agentsList[0];
        this.selectedAgent = this.oldAgent;
      });
      this.aiAssistCacheService.activeAgentObservable.subscribe( (data) => {
        this.oldAgent =  this.selectedAgent;
        this.selectedAgent = data;
        this.newAgentmodel = {};
        this.formErrors = {};
      });
    }

    public hideNewAgentModal():void {
    this.newAgentModel.hide();
    this.formErrors = {};
  }

  public hideRemoveAgentModal() : void {
    this.removeAgentModel.hide();
  }

  public createNewAgent(){
    if ( !this.newAgentmodel.name || ( this.newAgentmodel.name != null && this.newAgentmodel.name.trim() == "" ) ) {
      this.formErrors.name = "Agent name is mandatory";
      return;
    }
    var existingAgent = this.agentsList.filter((agent: Agent) => agent.name === this.newAgentmodel.name)
    if ( !existingAgent || ( existingAgent != null && existingAgent != undefined && existingAgent.length == 0 )) {
      this.aiAssistCacheService.createAgent(this.newAgentmodel);
      this.hideNewAgentModal();
    } else {
      this.formErrors.name = "Agent Name \"" + this.newAgentmodel.name + "\" already exists";
    }
  }

  public removeCurrentAgent() {
    this.aiAssistCacheService.removeActiveAgent();
    this.hideRemoveAgentModal();
  }
  private value:any = {};
  private _disabledV:string = '0';
  private disabled:boolean = false;

 private get disabledV():string {
   return this._disabledV;
 }

 private set disabledV(value:string) {
   this._disabledV = value;
   this.disabled = this._disabledV === '1';
 }

 public changeAgent( value:any):void {
   if (! this.aiAssistCacheService.isNavigable()) {
     if( !this.oldAgent ) {
       this.oldAgent = this.agentsList[0];
     }
     setTimeout(() => {
       this.selectedAgent = this.oldAgent;
     }, 1000);
   }
    this.aiAssistCacheService.navigateAgent(value);
 }

 public removed(value:any):void {
 }

 public typed(value:any):void {
 }

 public refreshValue(value:any):void {
   this.value = value;
 }

  ngOnInit() {
  }

  publishActiveAgent() {

  }

}
