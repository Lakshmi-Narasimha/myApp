define([
  'jquery',
  'underscore',
  'backbone',
  'spinner',
  'appcommon/constants',
  'services/dataservice',
  'appcommon/globalcontext',
  'appcommon/commonutility',
  'appmodules/crm/app/models/smarpadcollection',
    'moment','appmodules/crm/crmvalidate',
  'text!appmodules/crm/app/templates/addsmartpad.html',
  'appcommon/analytics',
  'appcommon/nativeadaptor',
  'appmodules/contactprofile/app/models/cpviewmodel',
  'errorLog',
  'apipublic/navapi'
], function ($, _, Backbone, Spinner, Constants, Dataservice, GlobalContext, CommonUtilis, SmartPadModel, Moment, Validator, AddSmartPadTemplate, Analytics, NativeAdaptor, CPViewModel, ErrorLog, NavApi) {
    var self, addsmartpadview = Backbone.View.extend({
        el: $("#practicetech-subapp"),
        id: 'practicetech-subapp',
        events: {
            "click #sm-add-button": "saveSmartpad",
            "click #cancel-button-address-entry": "handleCancel",
            "click #backto-smartpad-list": "handleBacktoSmartpadListClick",
        },

        initialize: function () {
            this.contactId = undefined;
            this.fmId = undefined;
            this.smartpadlistContextName = "SmartPad List";
            self = this;
            window.scroll(0, 0);
            $(window).on('resize orientationchange', this.datePickerPosition);
        },

        datePickerPosition: function (e) {
            if ($.datepicker._datepickerShowing) {
                var datepicker = $.datepicker._curInst;
                dpInput = datepicker.input;
                dpEle = datepicker.dpDiv;
                dpEle.position({ my: 'left top', of: dpInput, at: 'left bottom' });

            }
        },

        initDatePicker: function (e) {
            var view = this;
            var dt = new Date();
            var minutes = moment().minutes();
            var seconds = moment().seconds();
            var hrs = moment().hours();

            $("#addnote-date").datepicker({
                showOn: "button",
                buttonImage: "images/cal-icon.png",
                buttonImageOnly: true,
                buttonText: "Select date"
            });
            $("#addnote-date").datepicker("setDate", dt);
            $("#ui-datepicker-div").addClass("smartdatepicker");
            this.datePickerPosition();
            //$.extend($.datepicker, { _checkOffset: function (inst, offset, isFixed) { return offset } });
            //set Current Date and Time.
            var startEndTm = view.currentTime();
            $("#addnote-date").datepicker("setDate", dt);
            $("#addnote-hr option").find('option:selected').removeAttr("selected");
            $("#addnote-hr").val(startEndTm[0]);
            $("#addnote-min option").find('option:selected').removeAttr("selected");
            $("#addnote-min").val(startEndTm[1]);
            $("#addnote-ampm").find('option:selected').removeAttr("selected");
            $("#addnote-ampm").val(startEndTm[2]);

        },
        currentTime: function (e) {
            //Rounding start hour to next hour, End hour would be 1 above hr
            var stRemainder = (60 - moment().minute()) % 60;
            var roundToOneHr = moment(moment()).add("minutes", stRemainder);
            var startHr = roundToOneHr.format("hh");
            var startMm = roundToOneHr.format("mm");
            var startAMPM = roundToOneHr.format("A");

            currhr = moment().format("hh");
            currmin = moment().format("mm");
            currAMPM = moment().format("A");
            if (currmin <= 15 && currmin != 00) {
                currmin = "15";
            }
            else if (currmin > 15 && currmin <= 30) {
                currmin = "30";
            }
            else if (currmin > 30 && currmin <= 45) {
                currmin = "45";
            }
            else if (currmin > 45 && currmin < 60) {
                currmin = "00";
                currhr = startHr;
                var startAMPM = roundToOneHr.format("A");
                currAMPM = startAMPM;
            }

            result = [currhr, currmin, currAMPM];
            return (result);
        },

        lclSpinner: function () {

            var stack = 0, completed = 0, list = [];

            this.beginProcess = function (process) {
                stack++;
                //list.push(process,'started');
                Spinner.show();
            };
            this.finishProcess = function (process) {
                completed++;               
                if (completed >= stack ) {
                    this.closeProcess();
                } 
            };
            this.closeProcess = function () {
                Spinner.hide();
                return this;
            }
        },
        render: function (options) {
           
            var that = this;
            var spinMgr = new this.lclSpinner();
            this.fmId = options.fmId;
            var contactId = undefined;
            var pageHistory = Backbone.history.list.slice(-1)[0],
            _gContext = GlobalContext.getInstance().getGlobalContext().Context,
                   _pinnedContactId = _gContext.ContactId,
                   _pinnedContactDisplayInfo = NavApi.getPinnedContactNmIdInfo(_gContext.AdvisorFMID, _pinnedContactId);
            this.referer = pageHistory;
            if (pageHistory.indexOf("contactprofile/") !== -1) {
            	that.backContext = "Profile"
            }else { //defaults for sanity purposes
                that.backContext = that.smartpadlistContextName;
            }

            var compiledTemplate = _.template(AddSmartPadTemplate);
            this.$el.html(compiledTemplate({ backContext: that.backContext, pinnedContactDisplayInfo: _pinnedContactDisplayInfo }));
            this.initDatePicker();
            if (options.selectedContactType == Constants.contactType.NonClient) {
                this.contactId = options.selectedContactId;
                // Spinner.show();
                spinMgr.beginProcess();
                Dataservice.getContactDetailsbyContactId(CommonUtilis.readCookie('FMID'), options.selectedContactId)
                                      .then(gotoContactSuccessCall).fail(gotoError);
               //$('.sm-group-cont').hide();
            }
            else {
                contactId = options.selectedContactId;
                //Spinner.show();
                spinMgr.beginProcess();
                Dataservice.getContactDetailsbyClientId(CommonUtilis.readCookie('FMID'), options.selectedContactId)
                  .then(gotoContactSuccessCall).fail(gotoError);
            }
            function gotoContactSuccessCall(contctDetails) {

                if ((contctDetails != undefined) && (contctDetails.length > 0) && (contctDetails[0].status == undefined)) {
                    var pinnedId = contctDetails[0].get("contactId");
                    if (pinnedId != undefined) {
                        that.contactId = pinnedId;
                        var smartPad = new SmartPadModel.smartpad();
                        spinMgr.beginProcess();
                        Dataservice.getHouseHoldGroup(CommonUtilis.readCookie('FMID'), pinnedId).then(gotoHouseHoldGroupSuccess).fail(gotoError);
                        function gotoHouseHoldGroupSuccess(HouseHoldGroups) {
                            var houseHoldGroupOptions = "";
                            if (HouseHoldGroups[0] != null && HouseHoldGroups[0].attributes.HouseHoldGroupList != undefined) {
                                var _houholdGrps = HouseHoldGroups[0].get('HouseHoldGroupList');
                                if (_houholdGrps.length < 1) {
                                    $(".sm-group-cont").hide();
                                } else {
                                    var _$notePadgrpSelector = $('#addnote-group-val');
                                    $.each(_houholdGrps, function (key, value) {
                                        houseHoldGroupOptions += "<option value=" + value.get('householdId') + ">" + value.get('householdName') + "</option>";
                                    });
                                    _$notePadgrpSelector.empty().append(houseHoldGroupOptions);
                                    if (that.backContext == that.smartpadlistContextName && practicetech.modules && practicetech.modules.smartpads && practicetech.modules.smartpads.state) {
                                        var _state = practicetech.modules.smartpads.state;
                                        if (_state.selectedDropdownType == "group") {
                                            _$notePadgrpSelector.val(_state.selectedDropdownId);
                                        }
                                    }
                                    houseHoldGroupOptions = null;
                                }

                            }
                            else {
                                $(".sm-group-cont").hide();
                            }
                            spinMgr.finishProcess();
                        }
                    }
                    else {
                        // alert("Pinned contact doesn't exist in Ebix system")
                    }
                }
                //Spinner.hide();
                spinMgr.finishProcess();
            }
            function gotoError(Error) {
                //Spinner.hide();
                spinMgr.finishProcess();
                ErrorLog.ErrorUtils.myError(Error);
            };

        },
        saveSmartpad: function (e) {
            var that = this;
            if (Validator.validateInputs('add-smartpad-form')) {
                var smartPad = new SmartPadModel.smartpad();
                var smdate = moment($("#addnote-date").datepicker('getDate')).format('YYYY/MM/DD');
                var smtime = $("#addnote-hr option:selected").val() + ":" + $("#addnote-min option:selected").val() + " " + $("#addnote-ampm option:selected").val();
                smartPad.set({ "MemoDate": Moment.utc(smdate + " " + smtime).format('YYYY-MM-DD HH:mm:ss') }, { silent: true });
                smartPad.set({ "HouseholdId": $("#addnote-group-val option:selected").val() }, { silent: true });
                smartPad.set({ "Private": $("#addnote-private option:selected").val() }, { silent: true });
                smartPad.set({ "Note": $("#addnote-text").html() }, { silent: true });
                smartPad.set({ "ContactId": this.contactId }, { silent: true });
                Spinner.show();

                   Dataservice.postSmartPad(CommonUtilis.readCookie('FMID'), smartPad).then(gotoAddSmartPadSuccess).fail(gotoError);
                   function gotoAddSmartPadSuccess(smartpad) {
                       Analytics.analytics.recordAction('CrmAddSmartPadSave:clicked');
                       that.goToReferer();
                   };
                   function gotoError(Error) {
                       Spinner.hide();

                       ErrorLog.ErrorUtils.myError(Error);
                   };
               }
        },
        handleBacktoSmartpadListClick: function () {
        	this.handleSmartPadCancel(null);
        },
        handleCancel: function () {
        	this.handleSmartPadCancel(null);
        },
        handleSmartPadCancel: function (analyticAction) {
        	var self = this;
        	BootstrapDialog
                .confirm(
                "Cancel",
                "All your work will be lost.  Are you sure you want to continue?",
                function (confirm) {
                	if (confirm) {
                		self.goToReferer();
                	};
                });
        },
        goToReferer: function () {
            var _referer = self.referer;
        	switch (_referer) {
        		case 'contactprofile/':
        		case 'contactprofile/beneficiary':
        		case 'contactprofile/bank':
        		case 'contactprofile/ira':
        		case 'contactprofile/fiduciary':
        		case 'contactprofile/preferences':
        		case 'contactprofile/contributions':
        		case 'contactprofile/distributions':
        			location.hash = _referer;
        			break;
        		default:
        			location.hash = 'crm/smartpad';
        	}
        }
    });
    return addsmartpadview;
});