/**
 * @ngdoc filter
 * @name fticNullCheck
 * @description
 *
 * - This common filter is used to display empty string instead of null.
 *
 */

'use strict';

var fticNullCheck = function() {
    return function(str) {
        if (!str) {
            str = '';
        }
        return str;
    };
};

fticNullCheck.$inject = [];
module.exports = fticNullCheck;
