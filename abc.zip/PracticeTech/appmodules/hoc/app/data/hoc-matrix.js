define([], function() {
    var hoc_matrix = {
        "categories": [
            {
            "ctgCd" : "1",
            "ctgDesc":"Our records indicate the following issues with this client's information. Addressing them is critical for continuing to conduct business without interruption.",
            "sections": [
            {
                "viewDisplay":false,
                "sectionId" : "dna",
                "sectionDesc":"Data Not Available",
                "sectionColumns" : [],
                "items" : [ {
                    "itemTypCd" : "ppaconsent",
                    "itemTypDesc": "Positive consent to the Pension Protection Act fiduciary authorization",
                    "viewDisplay":true,
                    "orderIndex" : 1,
                    "actions" : []
                }, {
                    "itemTypCd" : "phyaddrundl",
                    "itemTypDesc": "Physical address(es)",
                    "viewDisplay":true,
                    "orderIndex" : 2,
                    "actions" : []
                }, {
                    "itemTypCd" : "nonfunceml",
                    "itemTypDesc": "Email address(es)",
                    "viewDisplay":true,
                    "orderIndex" : 3,
                    "actions" : []
                }, {
                    "itemTypCd" : "clisuitmis",
                    "itemTypDesc" : "Client suitability",
                    "viewDisplay":true,
                    "orderIndex" : 4,
                    "actions" : []
                }, 
				{
				    "itemTypCd" : "uncrttin",
				    "itemTypDesc" : "TIN/EIN corrections",
				    "orderIndex" : 6,
				    "viewDisplay":true,
				    "actions" : []
				},
				{
				    "itemTypCd" : "missacctbeneinfo",
				    "itemTypDesc": "Plan and account beneficiarie(s)",
				    "viewDisplay":true,
				    "orderIndex" : 7,
				    "actions" : []
				},
				{
				    "itemTypCd" : "nigoopn",
				    "itemTypDesc": "Open NIGO case(s)",
				    "viewDisplay":true,
				    "orderIndex" : 8,
				    "actions" : []
				},
				{
				    "itemTypCd" : "emplinfomis",
				    "itemTypDesc": "Employment",
				    "viewDisplay":true,
				    "orderIndex" : 9,
				    "actions" : []
				},{
				    "itemTypCd" : "rmdremain",
				    "itemTypDesc" : "RMD information",
				    "viewDisplay":true,
				    "orderIndex" : 10,
				    "actions" : []
				}, {
				    "itemTypCd": "rmdunkwn",
				    "itemTypDesc": "RMD information",
				    "viewDisplay": true,
				    "orderIndex": 11,
				    "actions": []
				}, {
				    "itemTypCd" : "Bank instructions on file",//need to get data
				    "itemTypDesc" : "Bank instructions",
				    "viewDisplay":false,
				    "orderIndex" : 12,
				    "actions" : []
				},{
				    "itemTypCd" : "Client bank instructions need reauthorization",//need to get data
				    "itemTypDesc" : "Bank instructions",
				    "orderIndex" : 13,
				    "viewDisplay":false,
				    "actions" : []
				}, {
				    "itemTypCd": "nobenecliovr",
				    "itemTypDesc": "Plan and account beneficiarie(s)",
				    "viewDisplay": true,
				    "orderIndex": 14,
				    "actions": []
				}, {
				    "itemTypCd": "bnkreauth",
				    "itemTypDesc": "Bank instructions",
				    "viewDisplay": true,
				    "orderIndex": 15,
				    "actions": []
				}, {
				    "itemTypCd": "fidrepapreq",
				    "itemTypDesc": "Client has no Authorized Person on file",
				    "viewDisplay": true,
				    "orderIndex": 16,
				    "actions": []
				},
                {
                    "itemTypCd": "ppaconsent",
                    "itemTypDesc": "Positive consent to the Pension Protection Act fiduciary authorization",
                    "viewDisplay": true,
                    "orderIndex": 1,
                    "actions": []
                }, {
                    "itemTypCd": "shrkarr",
                    "itemTypDesc": "Arrangement did not transfer to the new brokerage account during legacy Columbia mutual fund conversion",
                    "viewDisplay": true,
                    "orderIndex": 2,
                    "actions": []
                }, {
                    "itemTypCd": "mngChg",
                    "itemTypDesc": "Investment manager changing",
                    "viewDisplay": true,
                    "orderIndex": 3,
                    "actions": []
                }, {
                    "itemTypCd": "rmvNonBillPos",
                    "itemTypDesc": "Non-billable investments",
                    "viewDisplay": true,
                    "orderIndex": 4,
                    "actions": []
                }, {
                    "itemTypCd": "ctiPosUnwrp",
                    "itemTypDesc": "Columbia Threadneedle Investments in qualified SPS Advisor accounts",
                    "viewDisplay": true,
                    "orderIndex": 5,
                    "actions": []
                }, {
                    "itemTypCd": "sersClos",
                    "itemTypDesc": "Managed accounts closing",
                    "viewDisplay": true,
                    "orderIndex": 6,
                    "actions": []
                }, {
                    "itemTypCd": "admnFeeChg",
                    "itemTypDesc": "Administration fee changes",
                    "viewDisplay": false,
                    "orderIndex": 7,
                    "actions": []
                }, {
                    "itemTypCd": "brkgCliFee",
                    "itemTypDesc": "Custodial and maintenance fees",
                    "viewDisplay": true,
                    "orderIndex": 8,
                    "actions": []
                }, {
                    "itemTypCd": "febSpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in February",
                    "viewDisplay": true,
                    "orderIndex": 9,
                    "actions": []
                },
                {
                    "itemTypCd": "marSpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in March",
                    "viewDisplay": true,
                    "orderIndex": 10,
                    "actions": []
                },
                {
                    "itemTypCd": "convColumbiaAcct", // adding report to ni (action taken) section
                    "itemTypDesc": "Converted Columbia Account Consolidation",
                    "viewDisplay": true,
                    "orderIndex": 11,
                    "actions": []
                },
                {
                    "itemTypCd": "lgcyColMutFund2",
                    "itemTypDesc": "Arrangement will not transfer to the new brokerage account during legacy Columbia mutual fund conversion",
                    "viewDisplay": true,
                    "orderIndex": 12,
                    "actions": []
                },
                {
                    "itemTypCd": "maySpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in May",
                    "viewDisplay": false,
                    "orderIndex": 13,
                    "actions": []
                },
                {
                	"itemTypCd": "diligenceAdvAcct",
                	"itemTypDesc": "Enhanced Due Diligence and Hold and Service for Advisory Accounts",
                	"viewDisplay": true,
                	"orderIndex": 14,
                	"actions": []
                },
                {
                	"itemTypCd": "diligenceBrokerageAcct",
                	"itemTypDesc": "Enhanced Due Diligence for Brokerage Accounts",
                	"viewDisplay": true,
                	"orderIndex": 15,
                	"actions": []
                },
                {
                	"itemTypCd": "clientRetentionRisk",
                	"itemTypDesc": "Client Retention",
                	"viewDisplay": true,
                	"orderIndex": 16,
                	"actions": []
                }]

			
			
            },{
                "sectionId" : "opn",
                "viewDisplay":true,
                "sectionDesc":"Open actions",
                "sectionColumns" : [ {
                    "columnRefId" : "",
                    "columnTitle" : "Description",
                    "columnType" : "description",// this should be the key in
                    // item
                    "orderIndex" : 1
                }, {
                    "columnRefId" : "",
                    "columnTitle" : "Actions",
                    "columnType" : "actions",// this should be the key in
                    // item
                    "orderIndex" : 2
                } ],
                "items" : [ {
                    "itemTypCd" : "phyaddrundl",
                    "itemTypDesc" : "Client address is undeliverable",
                    "viewDisplay":true,
                    "orderIndex" : 1,
                    "actions" : [ {
                        "actionId" : "hocAction5",
                        "orderIndex" : 1
                    }, {
                        "actionId" : "hocAction1",
                        "orderIndex" : 2
                    } ]
                },

				{
				    "itemTypCd" : "nonfunceml",
				    "itemTypDesc" : "Client email address is undeliverable",
				    "viewDisplay":true,
				    "orderIndex" : 2,
				    "actions" : [ {
				        "actionId" : "hocAction4",
				        "orderIndex" : 1
				    }, {
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    } ]
				}, {
				    "itemTypCd" : "clisuitmis",
				    "itemTypDesc" : "Client suitability is incomplete",
				    "viewDisplay":true,
				    "orderIndex" : 3,
				    "actions" : [ {
				        "actionId" : "hocAction3",
				        "orderIndex" : 1
				    }, {
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    }]
				}, {
				    "itemTypCd" : "uncrttin",
				    "itemTypDesc" : "Client's TIN requires attention",
				    "orderIndex" : 5,
				    "viewDisplay":true,
				    "actions" : [{             
				        "actionId" : "hocAction8",//external link to Ask article
				        "orderIndex" : 1
				    }, {           
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    }]
				},
				{
				    "itemTypCd" : "missacctbeneinfo",
				    "itemTypDesc" : "Client has accounts with missing beneficiary information",
				    "viewDisplay":true,
				    "orderIndex" : 6,
				    "actions" : [{             //external CV link action need to add here
				        "actionId" : "hocAction17",
				        "orderIndex" : 1
				    }, {             
				        "actionId" : "hocAction18",
				        "orderIndex" : 2
				    }, {            
				        "actionId" : "hocAction1",
				        "orderIndex" : 3
				    }]
				},
				{
				    "itemTypCd" : "nigoopn",
				    "itemTypDesc" : "Client currently has open cases that are not in good order (NIGO)",
				    "viewDisplay":true,
				    "orderIndex" : 7,
				    "actions" : [{             
				        "actionId" : "hocAction11",//external link to Ask article
				        "orderIndex" : 1
				    }, {           
				        "actionId" : "hocAction1",
				        "orderIndex": 2
				    }, {
				        "actionId": "hocAction12",
				        "orderIndex": 3
				    }]
				},
				{
				    "itemTypCd" : "emplinfomis",
				    "itemTypDesc" : "Client has missing or incomplete employment information on file",
				    "viewDisplay":true,
				    "orderIndex" : 8,
				    "actions" : [ {
				        "actionId" : "hocAction2",
				        "orderIndex" : 1
				    }, {
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    } ]
				},{
				    "itemTypCd" : "rmdremain",
				    "itemTypDesc": "Client has not fulfilled RMD for current year with Ameriprise accounts",
				    "viewDisplay":true,
				    "orderIndex" : 9,
				    "actions" : [ {             //external CV link action need to add here
				        "actionId" : "hocAction16",
				        "orderIndex" : 1
				    },{
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    }, {
				        "actionId": "hocAction12",
				        "orderIndex": 3
				    }]
				}, {
				    "itemTypCd": "rmdunkwn",
				    "itemTypDesc": "Client has RMD requirement; amount needs to be calculated manually",
				    "viewDisplay": true,
				    "orderIndex": 10,
				    "actions": [{             //external CV link action need to add here
				        "actionId": "hocAction16",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 2
				    }, {
				        "actionId": "hocAction12",
				        "orderIndex": 3
				    }]
				}, {
				    "itemTypCd": "fidrepapreq",
				    "itemTypDesc": "Client has no Authorized Person on file",
				    "viewDisplay": true,
				    "orderIndex": 11,
				    "actions": [{             
				        "actionId": "hocAction26",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction18",
				        "orderIndex": 2
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 3
				    }]
				},{
				    "itemTypCd" : "Client has no active bank instructions on file",//need to get data
				    "itemTypDesc" : "Client address is undeliverable",
				    "viewDisplay":false,
				    "orderIndex" : 12,
				    "actions" : []
				},{
				    "itemTypCd" : "Client bank instructions need reauthorization",//need to get data
				    "itemTypDesc" : "Client address is undeliverable",
				    "orderIndex" : 13,
				    "viewDisplay":false,
				    "actions" : []
				}, {
				    "itemTypCd": "bnkreauth",
				    "itemTypDesc": "Client bank instructions need reauthorization",
				    "viewDisplay": true,
				    "orderIndex": 14,
				    "actions": [{
				        "actionId": "hocAction27",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 2,

				    }]
				}, {
				    "itemTypCd": "bnkrenw",
				    "itemTypDesc": "Client bank instructions need renewal",
				    "viewDisplay": true,
				    "orderIndex": 15,
				    "actions": [{
				        "actionId": "hocAction27",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 2,

				    }]
				}, {
				    "itemTypCd": "ppaconsent",
				    "itemTypDesc": "Positive consent to the Pension Protection Act fiduciary authorization has not been captured from this client",
				    "viewDisplay": true,
				    "orderIndex": 16,
				    "actions": [{
				        "actionId": "hocAction31",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction32",
				        "orderIndex": 2,
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 3,
				    }]
				},
                 {
                     "itemTypCd": "shrkarr",
                     "itemTypDesc": "Arrangement did not transfer to the new brokerage account during legacy Columbia mutual fund conversion",
                     "viewDisplay": true,
                     "orderIndex": 1,
                     "actions": [{
                         "actionId": "hocAction34",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction33",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 3
                     }]
                 }, {
                     "itemTypCd": "ppaconsent",
                     "itemTypDesc": "Positive consent to the Pension Protection Act fiduciary authorization has not been captured from this client",
                     "viewDisplay": true,
                     "orderIndex": 2,
                     "actions": [{
                         "actionId": "hocAction31",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction32",
                         "orderIndex": 2,
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 3,
                     }]
                 }, {
                     "itemTypCd": "ctiPosUnwrp",
                     "itemTypDesc": "Columbia Threadneedle Investments in qualified SPS Advisor accounts",
                     "viewDisplay": true,
                     "orderIndex": 5,
                     "actions": [{
                         "actionId": "hocAction35",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction43",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction39",
                         "orderIndex": 4
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 5
                     }]
                 }, {
                     "itemTypCd": "sersClos",
                     "itemTypDesc": "Managed accounts closing",
                     "viewDisplay": true,
                     "orderIndex": 6,
                     "actions": [{
                         "actionId": "hocAction35",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction44",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction40",
                         "orderIndex": 4
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 5
                     }]
                 }, {
                     "itemTypCd": "admnFeeChg",
                     "itemTypDesc": "Administration fee changes",
                     "viewDisplay": false,
                     "orderIndex": 7,
                     "actions": [{
                         "actionId": "hocAction35",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction41",
                         "orderIndex": 3
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 4
                     }]
                 }, {
                     "itemTypCd": "brkgCliFee",
                     "itemTypDesc": "Custodial and maintenance fees",
                     "viewDisplay": true,
                     "orderIndex": 8,
                     "actions": [{
                         "actionId": "hocAction35",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction45",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction7",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction42",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 3
                     }]
                 }, {
                     "itemTypCd": "marSpsAdvRpt",
                     "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in March",
                     "viewDisplay": true,
                     "orderIndex": 9,
                     "actions": [{
                         "actionId": "hocAction35",
                         "orderIndex": 2
                     }, {
                         "actionId": "hocAction43",
                         "orderIndex": 1
                     }, {
                         "actionId": "hocAction48",
                         "orderIndex": 3
                     }, {
                         "actionId": "hocAction1",
                         "orderIndex": 4
                     }]
                 },
                {
                    "itemTypCd": "maySpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in May",
                    "viewDisplay": false,
                    "orderIndex": 9,
                    "actions": [{
                        "actionId": "hocAction35",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction43",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction51",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 4
                    }]
                },
                {
                    "itemTypCd": "mngChg",
                    "itemTypDesc": "Investment manager changing",
                    "viewDisplay": true,
                    "orderIndex": 1,
                    "actions": [{
                        "actionId": "hocAction46",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction37",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }]
                }, {
                    "itemTypCd": "rmvNonBillPos",
                    "itemTypDesc": "Non-billable investments",
                    "viewDisplay": true,
                    "orderIndex": 2,
                    "actions": [{
                        "actionId": "hocAction46",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction43",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction38",
                        "orderIndex": 4
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 5
                    }]
                }, {
                    "itemTypCd": "febSpsAdvRpt",
                    "itemTypDesc": " Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in February",
                    "viewDisplay": true,
                    "orderIndex": 3,
                    "actions": [{
                        "actionId": "hocAction46",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction43",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction47",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 4
                    }]
                }, {
                    "itemTypCd": "convColumbiaAcct",
                    "itemTypDesc": " Converted Columbia Account Consolidation",
                    "viewDisplay": false,
                    "orderIndex": 3,
                    "actions": [{
                        "actionId": "hocAction46", //acknowledge
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction43", //review in ampf brok
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction7", //review in client viewer
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction49", //ssrs report link
                        "orderIndex": 4
                    }, {
                        "actionId": "hocAction1", //create task
                        "orderIndex": 5
                    }]
                }, {
                    "itemTypCd": "lgcyColMutFund2",
                    "itemTypDesc": "Arrangement will not transfer to the new brokerage account during legacy Columbia mutual fund conversion",
                    "viewDisplay": true,
                    "orderIndex": 3,
                    "actions": [{
                    	"actionId": "hocAction46", //acknowledge
                    	"orderIndex": 1
                    }, {
                    	"actionId": "hocAction7", //client viewer
                    	"orderIndex": 2
                    }, {
                        "actionId": "hocAction50", //ssrs report link
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction1", //create task
                        "orderIndex": 4
                    }]
                }, {
                	"itemTypCd": "diligenceAdvAcct",
                	"itemTypDesc": "Enhanced Due Diligence and Hold and Service for Advisory Accounts",
                	"viewDisplay": true,
                	"orderIndex": 3,
                	"actions": [{
                		"actionId": "hocAction35", //mark done 
                		"orderIndex": 1
                	}, {
                		"actionId": "hocAction54", //ameriprise brokerage platform with context
                		"orderIndex": 2
                	}, {
                		"actionId": "hocAction52", //diligence advisory accounts ssrs report link
                		"orderIndex": 3
                	}, {
                		"actionId": "hocAction1", 
                		"orderIndex": 4
                	}]
                }, {
                	"itemTypCd": "diligenceBrokerageAcct",
                	"itemTypDesc": "Enhanced Due Diligence for Brokerage Accounts",
                	"viewDisplay": true,
                	"orderIndex": 3,
                	"actions": [{
                		"actionId": "hocAction35", 
                		"orderIndex": 1
                	}, {
                		"actionId": "hocAction54",
                		"orderIndex": 2
                	}, {
                		"actionId": "hocAction53", //diligence brokerage accounts ssrs report link
                		"orderIndex": 3
                	}, {
                		"actionId": "hocAction1", 
                		"orderIndex": 4
                	}]
                },
                {
                    "itemTypCd": "clientRetentionRisk",
                    "itemTypDesc": "Deepen Client Relationship",
                    "viewDisplay": true,
                    "orderIndex": 3,
                    "actions": [{
                        "actionId": "hocAction56", //Take Action with unique id
                        "orderIndex": 1
                    },{
                    	"actionId": "hocAction35", //Mark Done
                    	"orderIndex": 2
                    },{
                    	"actionId": "hocAction57", //Select Another Action
                    	"orderIndex": 3
                    },{
                        "actionId": "hocAction55", //Client Retention Report
                        "orderIndex": 4
                    }, {
                        "actionId": "hocAction1",  //Create Task
                        "orderIndex": 5
                    }]
                }
                ]			
            },
            {
				
                "sectionId" : "psp",
                "viewDisplay":true,
                "sectionDesc":"Postponed issues",
                "sectionColumns" : [ {
                    "columnRefId" : "",
                    "columnTitle" : "Description",
                    "columnType" : "description",// this should be the key in
                    // item
                    "orderIndex" : 1
                }, {
                    "columnRefId" : "",
                    "columnTitle" : "Actions",
                    "columnType" : "actions",// this should be the key in
                    // item
                    "orderIndex" : 2
                } ],
                "items" : [ {
                    "itemTypCd" : "phyaddrundl",
                    "itemTypDesc" : "Client address is undeliverable",
                    "viewDisplay":true,
                    "orderIndex" : 1,
                    "actions" : [ {
                        "actionId" : "hocAction5",
                        "orderIndex" : 1
                    }, {
                        "actionId" : "hocAction1",
                        "orderIndex" : 2
                    } ]
                },

				{
				    "itemTypCd" : "nonfunceml",
				    "itemTypDesc" : "Client email address is undeliverable",
				    "viewDisplay":true,
				    "orderIndex" : 2,
				    "actions" : [ {
				        "actionId" : "hocAction4",
				        "orderIndex" : 1
				    }, {
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    } ]
				}, {
				    "itemTypCd" : "clisuitmis",
				    "itemTypDesc" : "Client suitability is incomplete",
				    "viewDisplay":true,
				    "orderIndex" : 3,
				    "actions" : [ {
				        "actionId" : "hocAction3",
				        "orderIndex" : 1
				    }, {
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    } ]
				}, {
				    "itemTypCd" : "uncrttin",
				    "itemTypDesc" : "Client's TIN requires attention",
				    "orderIndex" : 5,
				    "viewDisplay":true,
				    "actions" : [{             
				        "actionId" : "hocAction8",//external link to Ask article
				        "orderIndex" : 1
				    }, {           
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    }]
				},
				{
				    "itemTypCd" : "missacctbeneinfo",
				    "itemTypDesc" : "Client has accounts with missing beneficiary information",
				    "viewDisplay":true,
				    "orderIndex" : 6,
				    "actions" : [{             //external CV link action need to add here
				        "actionId" : "hocAction17",
				        "orderIndex" : 1
				    }, {            
				        "actionId" : "hocAction1",
				        "orderIndex" : 3
				    }]
				},
				{
				    "itemTypCd" : "nigoopn",
				    "itemTypDesc" : "Client currently has open cases that are not in good order (NIGO)",
				    "viewDisplay":true,
				    "orderIndex" : 7,
				    "actions" : [{             
				        "actionId" : "hocAction11",//external link to Ask article
				        "orderIndex" : 1
				    }, {           
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    }, {
				        "actionId": "hocAction12",
				        "orderIndex": 3
				    }]
				},
				{
				    "itemTypCd" : "emplinfomis",
				    "itemTypDesc" : "Client has missing or incomplete employment information on file",
				    "viewDisplay":true,
				    "orderIndex" : 8,
				    "actions" : [ {
				        "actionId" : "hocAction2",
				        "orderIndex" : 1
				    }, {
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    } ]
				},{
				    "itemTypCd" : "rmdremain",
				    "itemTypDesc" : "Client has not fulfilled RMD for current year",
				    "viewDisplay":true,
				    "orderIndex" : 9,
				    "actions" : [ {             //external CV link action need to add here
				        "actionId" : "hocAction16",
				        "orderIndex" : 1
				    },{
				        "actionId" : "hocAction1",
				        "orderIndex" : 2
				    }, {
				        "actionId": "hocAction12",
				        "orderIndex": 3
				    }]
				}, {
				    "itemTypCd": "rmdunkwn",
				    "itemTypDesc": "Client has RMD requirement; amount needs to be calculated manually",
				    "viewDisplay": true,
				    "orderIndex": 10,
				    "actions": [{             //external CV link action need to add here
				        "actionId": "hocAction16",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 2
				    }, {
				        "actionId": "hocAction12",
				        "orderIndex": 3
				    }]
				}, {
				    "itemTypCd" : "Client has no active bank instructions on file",//need to get data
				    "itemTypDesc" : "Client address is undeliverable",
				    "viewDisplay":false,
				    "orderIndex" : 11,
				    "actions" : []
				},{
				    "itemTypCd" : "Client bank instructions need reauthorization",//need to get data
				    "itemTypDesc" : "Client address is undeliverable",
				    "orderIndex" : 12,
				    "viewDisplay":false,
				    "actions" : []
				
				}, {
				    "itemTypCd": "bnkreauth",
				    "itemTypDesc": "Client bank instructions need reauthorization",
				    "viewDisplay": true,
				    "orderIndex": 13,
				    "actions": [{
				        "actionId": "hocAction27",
				        "orderIndex": 1},{
				            "actionId": "hocAction1",
				            "orderIndex": 2,

				        }]
				}, {
				    "itemTypCd": "bnkrenw",
				    "itemTypDesc": "Client bank instructions need renewal",
				    "viewDisplay": true,
				    "orderIndex": 14,
				    "actions": [{
				        "actionId": "hocAction27",
				        "orderIndex": 1
				    }, {
				        "actionId": "hocAction1",
				        "orderIndex": 2,

				    }]
				}
                ]

			
            },
            {
                "sectionId" : "ni",
                "viewDisplay":true,
                "sectionDesc":"Validated client information",
                "sectionColumns" : [ {
                    "columnRefId" : "",
                    "columnTitle" : "Description",
                    "columnType" : "description",// this should be the key in
                    // item
                    "orderIndex" : 1
                }],
                "items": [
                {
                    "itemTypCd" : "phyaddrundl",
                    "itemTypDesc" : "All client addresses are deliverable",
                    "viewDisplay":true,
                    "orderIndex" : 1,
                    "actions" : [ {
                        "actionId": "hocAction3",
                        "orderIndex" : 1
                    }]
                },

				{
				    "itemTypCd" : "nonfunceml",
				    "itemTypDesc" : "All client email addresses are deliverable",
				    "viewDisplay":true,
				    "orderIndex" : 2,
				    "actions": [{
				        "actionId": "hocAction3",
				        "orderIndex": 1
				    }]
				}, {
				    "itemTypCd" : "clisuitmis",
				    "itemTypDesc" : "Client suitability information is complete",
				    "viewDisplay":true,
				    "orderIndex" : 3,
				    "actions": [{
				        "actionId": "hocAction3",
				        "orderIndex": 1
				    }]
				}, {
				    "itemTypCd" : "acctsuitmis",
				    "itemTypDesc" : "Account suitability information is complete",
				    "viewDisplay":true,
				    "orderIndex" : 4,
				    "actions" : []
				},
				{
				    "itemTypCd" : "uncrttin",
				    "itemTypDesc" : "Client's TIN is certified",
				    "orderIndex" : 5,
				    "viewDisplay":true,
				    "actions": [{
				        "actionId": "hocAction3",
				        "orderIndex": 1
				    }]
				},
				{
				    "itemTypCd" : "missacctbeneinfo",
				    "itemTypDesc" : "Beneficiary information for this client is complete",
				    "viewDisplay":true,
				    "orderIndex" : 6,
				    "actions": [{
				        "actionId": "hocAction20",
				        "orderIndex": 1
				    }]
				},
				{
				    "itemTypCd" : "nigoopn",
				    "itemTypDesc" : "No NIGO cases open for this client",
				    "viewDisplay":true,
				    "orderIndex" : 7,
				    "actions": [{
				        "actionId": "hocAction11",
				        "orderIndex": 1
				    }]
				},
				{
				    "itemTypCd" : "emplinfomis",
				    "itemTypDesc" : "Client employment information is complete",
				    "viewDisplay":true,
				    "orderIndex" : 8,
				    "actions": [{
				        "actionId": "hocAction3",
				        "orderIndex": 1
				    }]
				},{
				    "itemTypCd" : "rmdremain",
				    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
				    "viewDisplay": true,
				    "orderIndex" : 9,
				    "actions" : [{
				        "actionId": "hocAction16",
				        "orderIndex": 1
				    }]
				}, {
				    "itemTypCd": "rmdunkwn",
				    "itemTypDesc": "There are no unknown RMD values",
				    "viewDisplay": true,
				    "orderIndex": 10,
				    "actions": [{
				        "actionId": "hocAction16",
				        "orderIndex": 1
				    }]
				}, {
				    "itemTypCd" : "Client has bank instructions on file",//need to get data
				    "itemTypDesc" : "Client address is undeliverable",
				    "viewDisplay":false,
				    "orderIndex" : 11,
				    "actions" : []
				},{
				    "itemTypCd" : "All client bank instructions are authorized",//need to get data
				    "itemTypDesc" : "Client address is undeliverable",
				    "orderIndex" : 12,
				    "viewDisplay":false,
				    "actions" : []
				}, {
				    "itemTypCd": "bnkreauth",
				    "itemTypDesc": "Client bank instructions need reauthorization",
				    "viewDisplay": true,
				    "orderIndex": 13,
				    "actions": []
				}, {
				    "itemTypCd": "bnkrenw",
				    "itemTypDesc": "All client bank instructions are authorized",
				    "viewDisplay": true,
				    "orderIndex": 14,
				    "actions": [{
				        "actionId": "hocAction30",
				        "orderIndex": 1
				    }]
				}, {
				    "itemTypCd": "ppaconsent",
				    "itemTypDesc": "Client consent of the Pension Protection Act fiduciary authorization has been captured",
				    "viewDisplay": false,
				    "orderIndex": 15,
				    "actions": [{
				        "actionId": "hocAction32",
				        "orderIndex": 1
				    }]
				},
                {
                    "itemTypCd": "shrkarr",
                    "itemTypDesc": "Columbia Fund Arrangement Conversion Request",
                    "viewDisplay": true,
                    "orderIndex": 1,
                    "actions": [{
                        "actionId": "hocAction33",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "ppaconsent",
                    "itemTypDesc": "SUBMITTED: Positive consent to the Pension Protection Act fiduciary authorization has been captured from this client",
                    "viewDisplay": true,
                    "orderIndex": 2,
                    "actions": [{
                        "actionId": "hocAction32",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "mngChg",
                    "itemTypDesc": "Investment manager changing",
                    "viewDisplay": true,
                    "orderIndex": 3,
                    "actions": [{
                        "actionId": "hocAction37",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "rmvNonBillPos",
                    "itemTypDesc": "Non-billable investments",
                    "viewDisplay": true,
                    "orderIndex": 4,
                    "actions": [{
                        "actionId": "hocAction38",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "ctiPosUnwrp",
                    "itemTypDesc": "Columbia Threadneedle Investments in qualified SPS Advisor accounts",
                    "viewDisplay": true,
                    "orderIndex": 5,
                    "actions": [{
                        "actionId": "hocAction39",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "sersClos",
                    "itemTypDesc": "Managed accounts closing",
                    "viewDisplay": true,
                    "orderIndex": 6,
                    "actions": [{
                        "actionId": "hocAction40",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "admnFeeChg",
                    "itemTypDesc": "Administration fee changes",
                    "viewDisplay": false,
                    "orderIndex": 7,
                    "actions": [{
                        "actionId": "hocAction41",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "brkgCliFee",
                    "itemTypDesc": "Custodial and maintenance fees",
                    "viewDisplay": true,
                    "orderIndex": 8,
                    "actions": [{
                        "actionId": "hocAction42",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "febSpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in February",
                    "viewDisplay": true,
                    "orderIndex": 9,
                    "actions": [{
                        "actionId": "hocAction47",
                        "orderIndex": 3
                    }]
                }, {
                    "itemTypCd": "marSpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in March",
                    "viewDisplay": true,
                    "orderIndex": 9,
                    "actions": [{
                        "actionId": "hocAction48",
                        "orderIndex": 3
                    }]
                }, {
                    "itemTypCd": "convColumbiaAcct", //add action taken for ssrs report link
                    "itemTypDesc": " Converted Columbia Account Consolidation",
                    "viewDisplay": true,
                    "orderIndex": 10,
                    "actions": [{
                        "actionId": "hocAction49",
                        "orderIndex": 1
                    }]
                },
                {
                    "itemTypCd": "maySpsAdvRpt",
                    "itemTypDesc": "Periodic Mutual Fund arrangement will not execute during the SPS <i>Advantage</i> share class conversion in May",
                    "viewDisplay": false,
                    "orderIndex": 9,
                    "actions": [
                        {
                            "actionId": "hocAction51",
                            "orderIndex": 1
                        }
                    ]
                }
                ]
            }]

        },
        {
            "ctgCd" : "2",
            "ctgDesc":"The following items are frequently discussed with clients to improve their experience.",
            "sections" :[{
                "sectionId" : "dna",
                "viewDisplay":false,
                "sectionDesc":"Open issues",
                "sectionColumns" : [],
                "items" : [ {
                    "itemTypCd": "nofidwthclnt",//need to get data
                    "itemTypDesc": "Client has no Authorized Person on file",
                    "viewDisplay": false,
                    "orderIndex": 12,
                    "actions": []
                }, {
                    "itemTypCd" : "emlmiss",
                    "itemTypDesc": "Email address(es)",
                    "viewDisplay":true,
                    "orderIndex" : 13,
                    "actions" : []
                },{
                    "itemTypCd" : "Client suitability has not been updated in at least 2 years",//need to get data
                    "itemTypDesc" : "Client suitability has not been updated in at least 2 years.",
                    "viewDisplay":false,
                    "orderIndex" : 14,
                    "actions" : []
                }, {
                    "itemTypCd": "lstbeneupdt",
                    "itemTypDesc": "Last beneficiary update date",
                    "viewDisplay": true,
                    "orderIndex": 15,
                    "actions": []
                }, {
                    "itemTypCd": "acctsuitmis",
                    "itemTypDesc": "Account suitability",
                    "viewDisplay": true,
                    "orderIndex": 5,
                    "actions": []
                },
                {
                    "itemTypCd" : "secsitreg",//need to get data
                    "itemTypDesc" : "Secure Site on ameriprise.com registration",
                    "viewDisplay":false,
                    "orderIndex" : 16,
                    "actions" : []
                },{
                    "itemTypCd" : "edelivpref",//need to get data
                    "itemTypDesc": "Document delivery preferences",
                    "viewDisplay":true,
                    "orderIndex" : 17,
                    "actions" : []
                },{
                    "itemTypCd" : "totlvwreg",//need to get data
                    "itemTypDesc": "Total View enrollment",
                    "viewDisplay":true,
                    "orderIndex" : 18,
                    "actions" : []
                },{
                    "itemTypCd" : "Not all account for this client have beneficiary information",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 19,
                    "actions" : []
                },{
                    "itemTypCd" : "ytd",//need to get data
                    "itemTypDesc" : "YTD contributions",
                    "viewDisplay":true,
                    "orderIndex" : 20,
                    "actions" : []
                },{
                    "itemTypCd": "nobenecliovr",//need to get data
                    "itemTypDesc": "Plan and account beneficiarie(s)",
                    "viewDisplay": true,
                    "orderIndex": 21,
                    "actions": []
                }, {
                    "itemTypCd": "myfareg",
                    "itemTypDesc": "Secure Site registration ",
                    "viewDisplay": true,
                    "orderIndex": 16,
                    "actions": []

                }, {
                    "itemTypCd": "nobnkinst",
                    "itemTypDesc": "Bank ",
                    "viewDisplay": true,
                    "orderIndex": 22,
                    "actions": []

                }, {
                	"itemTypCd": "unclaimedProperty",
                	"itemTypDesc": "Unclaimed Property",
                	"viewDisplay": true,
                	"orderIndex": 23,
                	"actions": []

                }]

			
			
            },{
                "sectionId" : "opn",
                "viewDisplay":true,
                "sectionDesc":"Open issues",
                "sectionColumns" : [ {
                    "columnRefId" : "",
                    "columnTitle" : "Description",
                    "columnType" : "description",// this should be the key in
                    // item
                    "orderIndex" : 1
                }, {
                    "columnRefId" : "",
                    "columnTitle" : "Actions",
                    "columnType" : "actions",// this should be the key in
                    // item
                    "orderIndex" : 2
                } ],
                "items" : [ {
                    "itemTypCd" : "emlmiss",
                    "itemTypDesc" : "Client has no email on file",
                    "viewDisplay":true,
                    "orderIndex" : 13,
                    "actions" : [ {
                        "actionId" : "hocAction4",
                        "orderIndex" : 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId" : "hocAction12",
                        "orderIndex" : 3
                    } ]
                },{
                    "itemTypCd" : "Client suitability has not been updated in at least 2 years",//need to get data
                    "itemTypDesc" : "Client suitability has not been updated in at least 2 years.",
                    "viewDisplay":false,
                    "orderIndex" : 14,
                    "actions" : []
                }, {
                    "itemTypCd": "lstbeneupdt",
                    "itemTypDesc": "Client beneficiary information has not been updated in at least 5 years",
                    "viewDisplay": true,
                    "orderIndex": 12,
                    "actions": [{
                        "actionId": "hocAction17",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction18",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 4
                    }]
                }, {
                    "itemTypCd" : "secsitreg",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 16,
                    "actions" : []
                },{
                    "itemTypCd" : "edelivpref",//need to get data
                    "itemTypDesc" : "Client has not set any online document delivery preferences",
                    "viewDisplay":true,
                    "orderIndex" : 17,
                    "actions" : [{           
                        "actionId" : "hocAction14",
                        "orderIndex" : 1
                    },{           
                        "actionId" : "hocAction15",
                        "orderIndex" : 2
                    },{
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }, {
                        "actionId" : "hocAction12",
                        "orderIndex" : 4
                    }]
                },{
                    "itemTypCd" : "totlvwreg",//need to get data
                    "itemTypDesc" : "Client has not enrolled for Total View",
                    "viewDisplay":true,
                    "orderIndex" : 18,
                    "actions" : [ {           
                        "actionId" : "hocAction13",
                        "orderIndex" : 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId" : "hocAction12",
                        "orderIndex" : 3
                    }]
                }, {
                    "itemTypCd": "acctsuitmis",
                    "itemTypDesc": "Account suitability is incomplete",
                    "viewDisplay": true,
                    "orderIndex": 4,
                    "actions": [{
                        "actionId": "hocAction24",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]
                }, {
                    "itemTypCd" : "Not all account for this client have beneficiary information",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 19,
                    "actions" : []
                },{
                    "itemTypCd" : "ytd",//need to get data
                    "itemTypDesc" : "Client's YTD contributions for all applicable plan types",
                    "viewDisplay":true,
                    "orderIndex" : 20,
                    "actions" : [{           
                        "actionId" : "hocAction6",
                        "orderIndex" : 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    },{           
                        "actionId" : "hocAction12",
                        "orderIndex" : 3
                    }]
                },{
                    "itemTypCd": "nobenecliovr",
                    "itemTypDesc": "Not all eligible accounts for this client have a designated beneficiary",
                    "viewDisplay": true,
                    "orderIndex": 16,
                    "actions": [{
                        "actionId": "hocAction17",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction18",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 4
                    }]
                }, {
                    "itemTypCd": "clisuitupdt",
                    "itemTypDesc": "Client suitability has not been updated in at least 2 years",
                    "viewDisplay": true,
                    "orderIndex": 12,
                    "actions": [{
                        "actionId": "hocAction3",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]
                }, {
                    "itemTypCd": "myfareg",
                    "itemTypDesc": "Client is not registered for the Secure Site on ameriprise.com",
                    "viewDisplay": true,
                    "orderIndex": 19,
                    "actions": [{
                        "actionId": "hocAction28",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }
                    ]
                }, {
                    "itemTypCd": "nobnkinst",
                    "itemTypDesc": "Client has no active bank instructions on file",
                    "viewDisplay": true,
                    "orderIndex": 21,
                    "actions": [{
                        "actionId": "hocAction29",
                        "orderIndex": 1
                    },{
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]

                },
				{
					"itemTypCd": "unclaimedProperty",
					"itemTypDesc": "Unclaimed Property Report",
					"viewDisplay": true,
					"orderIndex": 22,
					"actions": [{
						"actionId": "hocAction58", //Update Contact Details with unique id
						"orderIndex": 1
					}, {
						"actionId": "hocAction35",
						"orderIndex": 2
					}, {
						"actionId": "hocAction59", //Unclaimed Property Report link
						"orderIndex": 3
					}, {
						"actionId": "hocAction12", //postpone
						"orderIndex": 3
					}, {
						"actionId": "hocAction1",
						"orderIndex": 5
					}]
				}]
            },{
				
                "sectionId" : "psp",
                "viewDisplay":true,
                "sectionDesc":"Postponed issues",
                "sectionColumns" : [ {
                    "columnRefId" : "",
                    "columnTitle" : "Description",
                    "columnType" : "description",// this should be the key in
                    // item
                    "orderIndex" : 1
                }, {
                    "columnRefId" : "",
                    "columnTitle" : "Actions",
                    "columnType" : "actions",// this should be the key in
                    // item
                    "orderIndex" : 2
                } ],
                "items": [{
                    "itemTypCd": "nofidwthclnt",//need to get data
                    "itemTypDesc": "Client has no Authorized Person on file",
                    "viewDisplay": false,
                    "orderIndex": 12,
                    "actions": [{
                        "actionId": "hocAction22",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]
                }, {
                    "itemTypCd" : "emlmiss",
                    "itemTypDesc" : "Client has no email on file",
                    "viewDisplay":true,
                    "orderIndex" : 13,
                    "actions" : [ {
                        "actionId" : "hocAction4",
                        "orderIndex" : 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId" : "hocAction12",
                        "orderIndex" : 3
                    } ]
                }, {
                    "itemTypCd": "acctsuitmis",
                    "itemTypDesc": "Account suitability is incomplete",
                    "viewDisplay": true,
                    "orderIndex": 4,
                    "actions": [{
                        "actionId": "hocAction24",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]
                },

                {
                    "itemTypCd" : "Client suitability has not been updated in at least 2 years",//need to get data
                    "itemTypDesc" : "Client suitability has not been updated in at least 2 years.",
                    "viewDisplay":false,
                    "orderIndex" : 14,
                    "actions" : []
                }, {
                    "itemTypCd": "lstbeneupdt",
                    "itemTypDesc": "Client beneficiary information has not been updated in at least 5 years",
                    "viewDisplay": true,
                    "orderIndex": 13,
                    "actions": [{
                        "actionId": "hocAction17",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction18",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 4
                    }]
                },{
                    "itemTypCd" : "secsitreg",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 16,
                    "actions" : []
                }, {
                    "itemTypCd": "clisuitupdt",
                    "itemTypDesc": "Client suitability has not been updated in at least 2 years",
                    "viewDisplay": true,
                    "orderIndex": 12,
                    "actions": [{
                        "actionId": "hocAction3",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]
                },{
                    "itemTypCd" : "edelivpref",//need to get data
                    "itemTypDesc" : " Client has not set any online document delivery preferences",
                    "viewDisplay":true,
                    "orderIndex" : 17,
                    "actions": [{
                        "actionId": "hocAction14",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction15",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 4
                    }]
                },{
                    "itemTypCd" : "totlvwreg",//need to get data
                    "itemTypDesc" : "Client has not enrolled for Total View",
                    "viewDisplay":true,
                    "orderIndex" : 18,
                    "actions": [
                        {           
                            "actionId" : "hocAction13",
                            "orderIndex" : 1
                        }, {
                            "actionId": "hocAction1",
                            "orderIndex": 2
                        }, {
                            "actionId" : "hocAction12",
                            "orderIndex" : 3
                        }]
                        
                },{
                    "itemTypCd" : "Not all account for this client have beneficiary information",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 19,
                    "actions" : []
                }, {
                    "itemTypCd": "nobenecliovr",
                    "itemTypDesc": "Not all eligible accounts for this client have a designated beneficiary",
                    "viewDisplay": true,
                    "orderIndex": 21,
                    "actions": [{
                        "actionId": "hocAction17",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction18",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 3
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 4
                    }]
                },{
                    "itemTypCd" : "ytd",//need to get data
                    "itemTypDesc" : "Client's YTD contributions for all applicable plan types",
                    "viewDisplay":true,
                    "orderIndex" : 20,
                    "actions" : [{           
                        "actionId" : "hocAction6",
                        "orderIndex" : 1
                    },{
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId" : "hocAction12",
                        "orderIndex" : 3
                    }]
                }, {
                    "itemTypCd": "myfareg",
                    "itemTypDesc": "Client is not registered for the Secure Site on ameriprise.com",
                    "viewDisplay": true,
                    "orderIndex": 19,
                    "actions": [{
                        "actionId": "hocAction28",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }
                    ]
                }, {
                    "itemTypCd": "nobnkinst",
                    "itemTypDesc": "Client has no active bank instructions on file",
                    "viewDisplay": true,
                    "orderIndex": 21,
                    "actions": [{
                        "actionId": "hocAction29",
                        "orderIndex": 1
                    }, {
                        "actionId": "hocAction1",
                        "orderIndex": 2
                    }, {
                        "actionId": "hocAction12",
                        "orderIndex": 3
                    }]

                },
				{
					"itemTypCd": "unclaimedProperty",
					"itemTypDesc": "Unclaimed Property Report",
					"viewDisplay": true,
					"orderIndex": 22,
					"actions": [{
						"actionId": "hocAction58", 
						"orderIndex": 1
					}, {
						"actionId": "hocAction35",
						"orderIndex": 2
					}, {
						"actionId": "hocAction59", 
						"orderIndex": 3
					}, {
						"actionId": "hocAction12", 
						"orderIndex": 3
					}, {
						"actionId": "hocAction1",
						"orderIndex": 5
					}]
				}]			
            },{
                "sectionId" : "ni",
                "viewDisplay":true,
                "sectionDesc":"Validated client information",
                "sectionColumns" : [ {
                    "columnRefId" : "",
                    "columnTitle" : "Description",
                    "columnType" : "description",// this should be the key in
                    // item
                    "orderIndex" : 1
                }],
                "items": [{
                    "itemTypCd": "nofidwthclnt",//need to get data
                    "itemTypDesc": "Client has Authorized Person(s) on file",
                    "viewDisplay": false,
                    "orderIndex": 12,
                    "actions": [{
                        "actionId": "hocAction23",
                        "orderIndex": 1
                    }, ]
                }, {
                    "itemTypCd" : "emlmiss",
                    "itemTypDesc" : "Client has email on file",
                    "viewDisplay":true,
                    "orderIndex" : 13,
                    "actions": [{
                        "actionId": "hocAction3",
                        "orderIndex": 1
                    }]
                },{
                    "itemTypCd" : "Client suitability has not been updated in at least 2 years",//need to get data
                    "itemTypDesc" : "Client suitability has not been updated in at least 2 years.",
                    "viewDisplay":false,
                    "orderIndex" : 14,
                    "actions" : []
                }, {
                    "itemTypCd": "Client beneficiary information has not been updated in at least 5 years",//need to get data
                    "itemTypDesc" : "Client beneficiary information has not been updated in at least 5 years",
                    "viewDisplay":false,
                    "orderIndex" : 15,
                    "actions" : []
                },{
                    "itemTypCd" : "secsitreg",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 16,
                    "actions" : []
                },{
                    "itemTypCd" : "edelivpref",//need to get data
                    "itemTypDesc": "Client has set online document delivery preferences",
                    "viewDisplay":true,
                    "orderIndex" : 17,
                    "actions":[{
                        "actionId": "hocAction25",
                        "orderIndex": 1
                    }]
                },{
                    "itemTypCd" : "totlvwreg",//need to get data
                    "itemTypDesc": "Client is enrolled in Total View",
                    "viewDisplay":true,
                    "orderIndex" : 18,
                    "actions": [{
                        "actionId": "hocAction25",
                        "orderIndex": 1
                    }]
                },{
                    "itemTypCd" : "Not all account for this client have beneficiary information",//need to get data
                    "itemTypDesc" : "RMD is not required or distributions are complete for the year",
                    "viewDisplay":false,
                    "orderIndex" : 19,
                    "actions" : []

                }, {
                    "itemTypCd": "myfareg",
                    "itemTypDesc": "Client is registered for the Secure Site on ameriprise.com",
                    "viewDisplay": true,
                    "orderIndex": 19,
                    "actions": [{
                        "actionId": "hocAction25",
                        "orderIndex": 1
                    }]

                }, {
                    "itemTypCd" : "ytd",//need to get data
                    "itemTypDesc" : "Client's YTD contributions for all applicable plan types",
                    "viewDisplay":false,
                    "orderIndex" : 20,
                    "actions" : []
                }, {
                    "itemTypCd": "nobenecliovr",//need to get data
                    "itemTypDesc": "All eligible accounts for this client have a designated beneficiary",
                    "viewDisplay": true,
                    "orderIndex": 21,
                    "actions": [{
                        "actionId": "hocAction20",
                        "orderIndex": 1
                    }]
                }, {
                    "itemTypCd": "nobnkinst",
                    "itemTypDesc": "Client has bank instructions on file",
                    "viewDisplay": true,
                    "orderIndex": 21,
                    "actions": [ {
                        "actionId": "hocAction27",
                        "orderIndex": 2
                    }]

                }, {
                    "itemTypCd": "clisuitupdt",
                    "itemTypDesc": "Client suitability has been updated in the last 2 years",
                    "viewDisplay": true,
                    "orderIndex": 22,
                    "actions": [{
                        "actionId": "hocAction3",
                        "orderIndex": 1
                    }]
                },  {
                    "itemTypCd": "lstbeneupdt",//need to get data
                    "itemTypDesc" : "Client beneficiary information has been updated in the last 5 years",
                    "viewDisplay":true,
                    "orderIndex" : 23,
                    "actions": [{
                        "actionId": "hocAction20",
                        "orderIndex": 1
                    }]
                }]

            }]

        },
        ],
		"actions" : [ {
			"actionId" : "hocAction1",
			"actionTitle" : "Create Task",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "crm/addtask",
			"dropdownOptions" : [],
			"cssClass" : "create-tsk pt-create-task-icon",
		}, {
			"actionId" : "hocAction2",
			"actionTitle" : "Update Employment Information",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "gpm/employment",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-edit-svg-icon"// may not need this attribute(can handle in UI)

		},

		{
			"actionId" : "hocAction3",
			"actionTitle" : "Review in Client Profile",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "contactprofile/",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",

		}, {
			"actionId" : "hocAction4",
			"actionTitle" : "Update Email Address",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "gpm/email",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-edit-svg-icon",

		}, {
			"actionId" : "hocAction5",
			"actionTitle" : "Update Address",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "coa/",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-edit-svg-icon",
		},{
			"actionId" : "hocAction6",
			"actionTitle" : "Review Contributions",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "contactprofile/contributions",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",

		},{
			"actionId" : "hocAction7",
			"actionTitle": "Review in Client Viewer",
			"actionDesc" : "",
			"actionType": "link",
			"external": true,
			"url": "clientViewer",
			"dropdownOptions" : [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		},{
			"actionId" : "hocAction8",
			"actionTitle" : "Review Requirements",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : true,
			"url" : "uncrttinReviewReqrmnts",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",
		},{
			"actionId" : "hocAction9",
			"actionTitle" : "Update Beneficiary Information",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : true,
			"url" : "",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-edit-svg-icon",
		},{
			"actionId" : "hocAction10",
			"actionTitle" : "OFM",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : true,
			"url" : "",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",
		},{
			"actionId" : "hocAction11",
			"actionTitle" : "Review in Status Manager",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : true,
			"url" : "nigoopnReviewInSM",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",

		},{

			"actionId" : "hocAction12",
			"actionTitle" : "Postpone",
			"actionDesc" : "",
			"actionType" : "postpone",
			"external" : false,
			"url" : "",
			"dropdownOptions": [{ "propName": "oneMonth", "propVal": "1 month" }, { "propName": "threeMonth", "propVal": "3 months" }, { "propName": "sixMonth", "propVal": "6 months" }, { "propName": "oneYear", "propVal": "1 year"
			}],
			"cssClass" : "upt-addrs pt-link-to-app-icon",

		},{
			"actionId" : "hocAction13",
			"actionTitle": "Send client an invitation email to enroll in Total View",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : true,
			"url" : "totlvwregNotifyClinet",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",
		},{
			"actionId" : "hocAction14",
			"actionTitle" : "Send client a link to change preferences",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : true,
			"url" : "edelivprefChangePref",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",
		},{
			"actionId" : "hocAction15",
			"actionTitle": "Update document delivery preferences",
			"actionDesc" : "",
			"actionType" : "link",
			"external" : false,
			"url" : "gpm/documentDelivery",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-edit-svg-icon",
		},{

			"actionId" : "hocAction16",
			"actionTitle" : "Review Distributions",
			"actionDesc" : "Review Distributions",
			"actionType" : "link",
			"external" : false,
			"url" : "contactprofile/distributions",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon",

		}, {

		    "actionId": "hocAction17",
		    "actionTitle": "Update Beneficiary Information",
		    "actionDesc": "ebene link out",
		    "actionType": "link",
		    "external": true,
		    "url": "ebeneUrl",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-edit-svg-icon",

		}, {
		    "actionId": "hocAction18",
		    "actionTitle": "Review in Online File Manager",
		    "actionDesc": "beneficiary ofm link out",
		    "actionType": "link",
		    "external": true,
		    "url": "beneOFMLink",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",

		}, {
		    "actionId": "hocAction19",
		    "actionTitle": "Go to Online File Manager to review",
		    "actionDesc": "beneficiary ofm link out",
		    "actionType": "text",
		    "external": false,
		    "url": "",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-para-medium pt-pad-lt-zero no-cursor"
		}, {
		     "actionId": "hocAction20",
		     "actionTitle": "Link to client Beneficiary page",
              "actionDesc": "Link to client Beneficiary page",
               "actionType": "link",
		         "external": false,
		         "url": "contactprofile/beneficiary",
			      "dropdownOptions": [],
			  "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
		    "actionId": "hocAction21",
		    "actionTitle": "Go to eForms Manager to update",
		    "actionDesc": "",
		    "actionType": "text",
		    "external": false,
		    "url": "",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-para-medium pt-pad-lt-zero no-cursor",
		}, {
		    "actionId": "hocAction22",
		    "actionTitle": "Update Authorization",
		    "actionDesc": "Links out to Auth. Person workflow",
		    "actionType": "link",
		    "external": true,
		    "url": "authPersonUpdateLink",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
		    "actionId": "hocAction23",
		    "actionTitle": "Link to client Authorized Persons page",
		    "actionDesc": "Link to Authorized Persons page",
		    "actionType": "link",
		    "external": false,
		    "url": "contactprofile/fiduciary",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
		    "actionId": "hocAction24",
		    "actionTitle": "Update Account Suitability",
		    "actionDesc": "Update Account Suitability",
		    "actionType": "link",
		    "external": true,
		    "url": "updateAccountSuitability",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
		    "actionId": "hocAction25",
		    "actionTitle": "Link to CP prefrences",
		    "actionDesc": "Link to prefrences page",
		    "actionType": "link",
		    "external": false,
		    "url": "contactprofile/preferences",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		},{
		    "actionId": "hocAction26",
			"actionTitle": "Update Authorization",
			"actionDesc": "Links out to Auth. Person workflow",
			"actionType": "link",
			"external": true,
			"url": "authPersonUpdateLink",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-edit-svg-icon",
		}, {
		    "actionId": "hocAction27",
		    "actionTitle": "Review Bank Instructions",
		    "actionDesc": "Review Bank Instructions",
		    "actionType": "link",
		    "external": false,
		    "url": "contactprofile/bank",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
		    "actionId": "hocAction28",
		    "actionTitle": "Send client link to register for Secure Site on ameriprise.com",
		    "actionDesc": "Send client link to register for Secure Site on ameriprise.com",
		    "actionType": "link",
		    "external": true,
		    "url": "secureSite",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		},{
		    "actionId": "hocAction29",
		    "actionTitle": "Set up Bank Instructions",
		    "actionDesc": "Set up Bank Instructions",
		    "actionType": "link",
		    "external": true,
		    "url": "mmsLink",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
		    "actionId": "hocAction30",
		    "actionTitle": "All client bank instructions are authorized",
		    "actionDesc": "All client bank instructions are authorized",
		    "actionType": "link",
		    "external": false,
		    "url": "contactprofile/bank",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
			"actionId" : "hocAction31",
			"actionTitle" : "Capture Consent",
			"actionDesc" : "Capture Consent",
			"actionType" : "link",
			"external" : true,
			"url" : "ppaEformsLink",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon"
		}, {
			"actionId" : "hocAction32",
			"actionTitle" : "Review the Positive Consent Report",
			"actionDesc" : "Review the Positive Consent Report",
			"actionType" : "link",
			"external" : true,
			"url" : "ppaReportLink",
			"dropdownOptions" : [],
			"cssClass" : "upt-addrs pt-link-to-app-icon"
		},{
			"actionId": "hocAction33",
			"actionTitle": "Review the Legacy Columbia Mutual Fund Conversion Report",
			"actionDesc": "Review the Legacy Columbia Mutual Fund Conversion Report",
			"actionType": "link",
			"external": true,
			"url": "columbiaMutualFundReport",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
			"actionId": "hocAction34",
			"actionTitle": "Take Action",
			"actionDesc": "Take Action",
			"actionType": "link",
			"external": true,
			"url": "eformsUniqueID",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
		    "actionId": "hocAction35",
		    "actionTitle": "Mark Done",
		    "actionDesc": "Mark Done",
		    "actionType": "link",
		    "external": true,
		    "url": "markdone",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-checkmark-icon internalpopup"
		}, {
		    "actionId": "hocAction36",
		    "actionTitle": "Disregard",
		    "actionDesc": "Disregard",
		    "actionType": "link",
		    "external": true,
		    "url": "acknowledge",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-checkmark-icon internalpopup"
		}, {
			"actionId": "hocAction37",
			"actionTitle": "Review the Investment Manager Changing Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsMngChg",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction38",
			"actionTitle": "Review the Non-billable Investments Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsRmvNonBillPos",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction39",
			"actionTitle": "Review the Columbia Threadneedle Investments in Qualified SPS Advisor Accounts Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsCtiPosUnwrp",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction40",
			"actionTitle": "Review the Managed Accounts Closing Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsSersClos",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		},{
			"actionId": "hocAction41",
			"actionTitle": "Administration Fee Changes Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsAdmnFeeChg",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction42",
			"actionTitle": "Review the Custodial and Maintenance Fee Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsBrkgCliFee",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction43",
			"actionTitle": "Review in Ameriprise Brokerage Platform",
			"actionDesc": "Ameriprise Brokerage Platform link",
			"actionType": "link",
			"external": true,
			"url": "t1Anywhere",
			"dropdownOptions": [],
			    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction44",
			"actionTitle": "Create New Account",
			"actionDesc": "NBST",
			"actionType": "link",
			"external": true,
			"url": "NBSTUrl",
			"dropdownOptions": [],
			    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
			"actionId": "hocAction45",
			"actionTitle": "Review in Client Fee Reimbursement Tool",
			"actionDesc": "Client Fee Reimbursement Tool",
			"actionType": "link",
			"external": true,
			"url": "cfr",
			"dropdownOptions": [],
			    "cssClass": "upt-addrs pt-link-to-app-icon",
		}, {
		    "actionId": "hocAction46",
		    "actionTitle": "Acknowledge",
		    "actionDesc": "Acknowledge",
		    "actionType": "link",
		    "external": true,
		    "url": "acknowledge",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-checkmark-icon internalpopup"
		}, {
		    "actionId": "hocAction47",
		    "actionTitle": "Review the February SPS <i>Advantage</i> Impacted Mutual Fund Periodic Arrangements Report",
		    "actionDesc": "SSRS Report Link",
		    "actionType": "link",
		    "external": true,
		    "url": "ssrsFebSpsAdvRpt",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
		    "actionId": "hocAction48",
		    "actionTitle": "Review the March SPS <i>Advantage</i> Impacted Mutual Fund Periodic Arrangements Report",
		    "actionDesc": "SSRS Report Link",
		    "actionType": "link",
		    "external": true,
		    "url": "ssrsMarSpsAdvRpt",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
		    "actionId": "hocAction49",
		    "actionTitle": "Review the Converted Columbia Account Consolidation Report",
		    "actionDesc": "SSRS Report Link",
		    "actionType": "link",
		    "external": true,
		    "url": "ssrsConvColumbiaAcct",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
		    "actionId": "hocAction50",
		    "actionTitle": "Legacy Columbia Mutual Fund (002) - Final Conversion Report",
		    "actionDesc": "SSRS Report Link",
		    "actionType": "link",
		    "external": true,
		    "url": "ssrsLgcyColMutFund2",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
            "actionId": "hocAction51",
            "actionTitle": "Review the May SPS <i>Advantage</i> Impacted Mutual Fund Periodic Arrangements Report",
            "actionDesc": "SSRS Report Link",
            "actionType": "link",
            "external": true,
            "url": "ssrsMaySpsAdvRpt",
            "dropdownOptions": [],
            "cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
			"actionId": "hocAction52",
			"actionTitle": "Enhanced Due Diligence and Hold and Service for Advisory Accounts Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsDiligenceAdvisoryAcc",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
			"actionId": "hocAction53",
			"actionTitle": "Review Enhanced Due Diligence for Brokerage Accounts Report",
			"actionDesc": "SSRS Report Link",
			"actionType": "link",
			"external": true,
			"url": "ssrsDiligenceBrokerageAcc",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon"
		}, {
			"actionId": "hocAction54",
			"actionTitle": "Review in Ameriprise Brokerage Platform",
			"actionDesc": "Ameriprise Brokerage Platform link",
			"actionType": "link",
			"external": true,
			"url": "t1AnywhereWithContext",
			"dropdownOptions": [],
			"cssClass": "upt-addrs pt-link-to-app-icon",
		}, {

		    "actionId": "hocAction55",
		    "actionTitle": "Client Retention Report",
		    "actionDesc": "SSRS Report link",
		    "actionType": "link",
		    "external": true,
		    "url": "ssrsClientAttritionRpt",
		    "dropdownOptions": [],
		    "cssClass": "upt-addrs pt-link-to-app-icon",
		},
         {
             "actionId": "hocAction56",
             "actionTitle": "Take Action",
             "actionDesc": "Take Action",
             "actionType": "link",
             "external": true,
             "url": "clientAttritionUniqueID",
             "dropdownOptions": [],
             "cssClass": "upt-addrs pt-link-to-app-icon"
         },
         {
             "actionId": "hocAction57",
             "actionTitle": "Select Another Action",
             "actionDesc": "Select Another Action",
             "actionType": "link",
             "external": true,
             "url": "clientAttritionUniqueID",
             "dropdownOptions": [],
             "cssClass": "upt-addrs pt-link-to-app-icon"
         },
         {
         	"actionId": "hocAction58",
         	"actionTitle": "Update Contact Details",
         	"actionDesc": "Update Contact Details",
         	"actionType": "link",
         	"external": true,
         	"url": "updateContactDetails",
         	"dropdownOptions": [],
         	"cssClass": "upt-addrs pt-link-to-app-icon"
         },
         {
         	"actionId": "hocAction59",
         	"actionTitle": "Unclaimed Property Report",
         	"actionDesc": "SSRS Report link",
         	"actionType": "link",
         	"external": true,
         	"url": "unclaimedPropertyRpt",
         	"dropdownOptions": [],
         	"cssClass": "upt-addrs pt-link-to-app-icon"
         }
		],
		"secondaryItems":{
		    "clisuitmis": {
                "dpdtCnt":"Total dependents",
				"fedTxBrktPct" : "Federal tax bracket",
				"annlIncm" : "Individual annual income",
				"netWorth" : "Individual net worth",
				"liqNetWorth" : "Individual liquid net worth",
				"invExpeYrCd" : "Investment experience",
				"phoneNm": "Phone",
		        "bthDt": "Birthdate",
				"emplStatCd" : "Employment status",
				"emprNm" : "Employer",
				"emprAddrLn1" : "Employer address",
				"emprCityNm" : "Employer city",
				"emprStdCd" : "Employer state",
				"emprPostlCd" : "Employer zip code",
				"occpDescTxt" : "Occupation",
				"employerAddress":"Employer address",//custom code
				"finInstnEmplCd":"Associated person question",
				"ownrOfcrCd": "Director, Officer, etc. question",
				"Data not Available":"Data not Available",

			},
			"emplinfomis":{
				"emplStatCd" : "Employment status",
				"occpDescTxt" : "Occupation",
				"emprNm" : "Employer",
				"emprAddrLn1" : "Employer address",
				"emprCityNm" : "Employer city",
				"emprStdCd" : "Employer state",
				"emprPostlCd" : "Employer zip code",
			},
			"uncrttin":{
				"Uncertified":"Not certified",
				"Mis-matched":"TIN/Name mismatch",
				"Withhold/IRS (incorrect TIN)":"Incorrect TIN - IRS reported",
				"Withhold/IRS (underpaid taxes)":"Delinquent/Underpaid taxes",
				
			},
			"ytd":{
				"CU" : "CURRENT YEAR CONTRIBUTION",
				"CV" : "ROTH IRA CONVERSION",
				"ET" : "EXTERNAL TRANSFER",
				"IT" : "INTERNAL TRANSFER",
				"PR" : "PRIOR YEAR CONTRIBUTION",
				"RE" : "RECHARACTERIZATION",
				"RO" : "ROLLOVER CONTRIBUTION",
				"SC" : "SEP CONTRIBUTION",
				"SD" : "SIDE FUND CONTRIBUTION",
				"SP" : "SEP CONTRIBUTION"
			}
		}

	};
           

	return hoc_matrix;
});
