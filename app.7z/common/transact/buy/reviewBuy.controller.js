/**
 * @ngdoc property
 * @name Review Buy Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewBuyController($scope, fticLoggerMessage, loggerConstants, $state, eventConstants, TransactConstant,  authenticationService) {
    console.info("review buy Controller!!");
    if(authenticationService.isInvestorLoggedIn()){  //added investor code
		$scope.config.toTxnDetailsState = "invTransact.txnDetails";
		$scope.config.toState = "invTransact.base.buy";
		}
		else{
			 $scope.config.toTxnDetailsState = "transact.txnDetails.buy";
    		$scope.config.toState = "transact.base.buy";
		}
    $scope.config.fromState = $state.current.name;
    $scope.$on(eventConstants.ACTION_ICON_CLICKED, function($event, ele){
    	// $scope.$emit("NAVIGATE_TO_TRANSACT", {key: 'Buy'});
    	$scope.$emit("NAVIGATE_TO_TRANSACT", {key: TransactConstant.transact.Payment_Key});
  	});
}

reviewBuyController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'eventConstants', 'TransactConstant', 'authenticationService'];
module.exports = reviewBuyController;