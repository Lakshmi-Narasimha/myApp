/**
 * @ngdoc property
 * @name smart saving account Controller
 * @requires $scope
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter


function SmartSavingsAccountController($scope, $state, $timeout, $loader, $filter, toaster, eventConstants, invSmartSavingsModel, transactModel, invEformPaymentBanksUtility, smartSavingsAccountModel, redeemModel, investorDashboardDetailsModel, invSmartSavingsInitialLoader, purchasesDetailsFactory) {

    $scope.smartSavingVM = {
        pageTitle: 'SMART SAVINGS ACCOUNT',
        proceedButtonTxt: 'Proceed to Smart Savings Account'
    };

    $scope.purchaseLabel = {
        heading: 'Smart Saving Purchases Details',
        buttonLabel: 'Remove Purchase Instructions',
        source: 'smartSaving'
    };
    $scope.redeemLabel = {
        heading: 'Smart Saving Redeem Details',
        buttonLabel: 'Remove Redeem Instructions',
        source: 'redeem'
    };

    $scope.isOpenPurchaseGrid = {};
    $scope.isOpenRedeemGrid = {};
    $scope.warningObj = {
        'showWarning': false,
        'mainHeader': 'Remove Instructions',
        'popupText': 'Are you sure you want to remove the instructions ?',
        'yesText': 'Remove',
        'noText': 'Cancel',
        'yesEventName': 'detailsRemoved',
        'noEventName': 'NoAction'
    };

    $scope.videoUrl = 'https://www.youtube.com/embed/ZJZfIw3P8No?wmode=opaque&autohide=1&autoplay=1';

    function setInitialValues() {
        $scope.isPurchasesEditable = true;
        $scope.isDisableRedeemGrid = true;
        $scope.isOpenPurchaseGrid.open = true;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isRedeemEditable = true;
        $scope.editShowButton = false;
        $scope.isCurrentValue = false;
    }

    function setRedeemIntialValues() {
        $scope.$broadcast("RedeemDetails");
        $scope.isPurchasesEditable = false;
        $scope.isDisableRedeemGrid = false;
        $scope.isOpenPurchaseGrid.open = false;
        $scope.isOpenRedeemGrid.open = true;
        $scope.isRedeemEditable = true;
    }

    $scope.initValue = investorDashboardDetailsModel.getSmartSaveAccAndOneTouchData().smartSavingsAccount || {};
    //$scope.initValue.currentValue = "5";
    $scope.initValue.isPurchaseSet = 'N';
    $scope.initValue.isRedeemSet = 'N';
    if ($filter('fticInvStringToNumber')($scope.initValue.currentValue) > 0) {
        invSmartSavingsModel.getSmartSavingsDetails().then(function(data) {
            $scope.isOpenPurchaseGrid.open = false;
            $scope.isOpenRedeemGrid.open = false;
            $scope.isCurrentValue = true;
            invSmartSavingsModel.setSmartSavingsData(data);
            $scope.invPurchaseData = data.purchaseInstructions;
            $scope.keyValueList = purchasesDetailsFactory.getPurchaseGetValues($scope.invPurchaseData);
            if (data.redeemInstructions) {
                $scope.invRedeemData = data.redeemInstructions;
                $scope.keyRedeemList = purchasesDetailsFactory.getRedeemValues($scope.invRedeemData);
            } else {
                setRedeemIntialValues();
            }
        });
    } else {
        setInitialValues();
    }

    $scope.$on(eventConstants.ACTION_BUTTON_CLICKED, function(event, data) {
        $scope.buttonLabel = data;
        $scope.warningObj.showWarning = true;
    });

    $scope.$on($scope.warningObj.yesEventName, function() {
        $scope.warningObj.showWarning = false;
        $scope.isPurchasesEditable = true;
        if ($scope.buttonLabel === $scope.purchaseLabel.source) {
            $scope.$broadcast('removePurchase');
            setInitialValues();
        } else if ($scope.buttonLabel === $scope.redeemLabel.source) {
            removeRedeem();
        }
    });

    $scope.$on('cancelEditPurchase', function(event, isEdit) {
        if(isEdit){
            if (((invSmartSavingsModel.getPurchaseDtls() !== null) && (redeemModel.getRedeemDetails() !== null) && $scope.initValue.isPurchaseSet ==='N') || (($scope.invPurchaseData !== null) && ($scope.invRedeemData !== null) && $scope.initValue.isPurchaseSet ==='Y')) {
                $scope.isPurchasesEditable = false;
            } else if (invSmartSavingsModel.getPurchaseDtls() || $scope.invPurchaseData) {
                setRedeemIntialValues();
            }
        } else {
            setInitialValues();
        }
    });

    function removeRedeem() {
        var removeParams = {};
        invSmartSavingsModel.postRemoveRedeemDtls(removeParams).then(removeRedeemSuccess);
    }

    function removeRedeemSuccess(data) {
        var nullObj = {};
        redeemModel.getRedeemDetails(nullObj);
        setRedeemIntialValues();
    }

    $scope.$on($scope.warningObj.noEventName, function() {
        $scope.warningObj.showWarning = false;
    });

    $scope.$on('editPurchases', function(event, data) {
        $scope.isPurchasesEditable = true;
        $scope.isDisableRedeemGrid = true;
        $scope.isOpenPurchaseGrid.open = true;
        $scope.isOpenRedeemGrid.open = false;
        $scope.$broadcast('purchaseGetDetails', $scope.invPurchaseData);
    });

    $scope.$on('editRedeem', function(event, data) {
        $scope.isPurchasesEditable = false;
        $scope.isDisableRedeemGrid = false;
        $scope.isOpenPurchaseGrid.open = false;
        $scope.isOpenRedeemGrid.open = true;
        $scope.isRedeemEditable = true;
        $scope.editShowButton = false;
        $scope.$broadcast("redeemGetDetails", $scope.invRedeemData);
    });

    $scope.proceedToSmartSavings = function() {
        $state.transitionTo('dashboard');
    };

    $scope.proceedToAccountView = function() {
        $state.transitionTo('overview.accview');
    };

    $scope.$on("saveInstruction", function() {
        selectSmartSavingsRedeemTile();
    });

    $scope.$on('redeemDetailsSaveInstruction', function() {
        savingDetailsTile();
        $scope.editShowButton = true;
    });

    function savingDetailsTile() {
        $scope.isPurchasesEditable = false;
        $scope.isDisableRedeemGrid = false;
        $scope.isOpenPurchaseGrid.open = false;
        $scope.isOpenRedeemGrid.open = false;
        $scope.isRedeemEditable = false;
        var investorRedeemData = redeemModel.getRedeemDetails();
        $scope.keyRedeemList = purchasesDetailsFactory.getRedeemValues(investorRedeemData);
    }

    function selectSmartSavingsRedeemTile() {
        setRedeemIntialValues();
        var investorData = invSmartSavingsModel.getPurchaseDtls();
        $scope.keyValueList = purchasesDetailsFactory.getPurchaseValues(investorData);
    }
}



SmartSavingsAccountController.$inject = ['$scope', '$state', '$timeout', '$loader', '$filter', 'toaster', 'eventConstants', 'invSmartSavingsModel', 'transactModel', 'invEformPaymentBanksUtility', 'smartSavingsAccountModel', 'redeemModel', 'investorDashboardDetailsModel', 'invSmartSavingsInitialLoader', 'purchasesDetailsFactory'];
module.exports = SmartSavingsAccountController;
