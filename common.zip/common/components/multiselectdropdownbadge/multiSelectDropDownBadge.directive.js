/**
 * @ngdoc property
 * @name multiSelectDropDown directive
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var multiSelectDropDownBadge = function(smsNavModel, $stateParams) {
	return {
            template: require('./multiSelectDropDownBadge.html'),
            restrict: 'E',
            replace: true,
            scope: {
              header : '=',
              list : '=',
              selectedCount : '=',
              showBadge : '=?'
            },
            controller:['$scope', function($scope){
                $scope.selectionStatus = false;
                $scope.selectedCount = $scope.selectedCount || 'Select'; 
                $scope.selection = [];   
                  
                //$scope.$on('fundSelectionDetails', function(event){   
                //debugger  
                //alert('ojjj')              
                    /*for(var i in data){
                        $scope.toggleSelection(i.fundDescription);
                    }*/
                 //});
                

                 $scope.changed = function(){
                    $scope.selectedCount = 'Select Funds';
                 }
                $scope.toggleSelection = function(option) {
                        var idx = $scope.selection.indexOf(option);
                        $scope.selectionStatus = false;
                        // is currently selected
                        if (idx > -1) {
                          $scope.selection.splice(idx, 1);
                        }
                        // is newly selected
                        else {     
                            if($scope.selection.length < 3){                   
                                $scope.selection.push(option);    
                            }                                                                     
                        }

                        if($scope.selection.length === 3){
                            $scope.selectionStatus = true;        
                        }else{
                            $scope.selectionStatus = false;
                        }

                        $scope.$emit('multiSelectDropdownOptions',{'header' : $scope.header, 'selection' : $scope.selection});                    
                };

                if ($stateParams.key === 'UNSUBSCRIBE') {
                    var selectedFunds = smsNavModel.getSubscriptionDetails()[0].subscriptionBySmsFunds;
                    if(selectedFunds.length>0){
                    for(var j=0;j<selectedFunds.length;j++){
                        var temp = selectedFunds[j].fundDescription;
                        $scope.toggleSelection(temp);
                    }    
                }
                }
                 $scope.$on('resetClicked',function(){
                    $scope.selection = [];
                    if(selectedFunds.length>0){
                    for(var j=0;j<selectedFunds.length;j++){
                        var temp = selectedFunds[j].fundDescription;
                        $scope.toggleSelection(temp);
                    }    
                }
                 })                                            
                $scope.$on('fundSelectionDetails', function(event, data){   
                                
                    for(var i=0;i<data.length;i++){
                        $scope.toggleSelection(data[i].fundDescription);
                    }
                 });
                $scope.$on('clearSelection', function(event, data){
                $scope.selectedCount = 'Select Funds' ;               
                    for(var i in data){
                        $scope.removeBadge(i);
                    }
                $scope.selectionStatus = false;
                 });
                $scope.removeBadge = function(option){                    
                    var idx = $scope.selection.indexOf(option);
                    $scope.selection.splice(idx, 1);
                    $scope.$emit('badgeRemove', {'selection' : $scope.selection}); 
                    if($scope.selection.length === 3){
                        $scope.selectionStatus = true;        
                    }else{
                        $scope.selectionStatus = false;
                    }                 
                };

                
            }]
        };
};

multiSelectDropDownBadge.$inject = ['smsNavModel','$stateParams'];
module.exports = multiSelectDropDownBadge;