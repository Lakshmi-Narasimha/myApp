import { Intent } from './intent';


export class Agent {

    agentId : string;
    name : string;
    description : string;
    intentList : Array<Intent> = [];

}
