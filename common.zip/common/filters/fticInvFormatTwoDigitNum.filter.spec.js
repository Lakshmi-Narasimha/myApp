'use strict';
describe('Filter: Format Two Digit Num', function() {

    var $filter, output;
    beforeEach(angular.mock.module('common'));
    beforeEach(function() {
        angular.mock.inject(function(_$filter_) {
            $filter = _$filter_;
        });
    });

    it('should Format a Two Digit Num - When input is valid single digit number', function() {

        output = $filter('fticInvFormatTwoDigitNum')(1);
        expect(output).toEqual('01');
    });

    it('should format a number when input is valid double digit number', function() {

        output = $filter('fticInvFormatTwoDigitNum')(10);
        expect(output).toEqual(10);
    });

    it('should format a number when input is null', function() {
        output = $filter('fticInvFormatTwoDigitNum')(null);
        expect(output).toEqual(0);
    });
});
