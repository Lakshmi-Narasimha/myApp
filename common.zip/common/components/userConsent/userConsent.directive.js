 /**
 * @ngdoc property
 * @name fticUserConsent Directive
 * @requires transactModel
 * @requires transactEventConstants
 * @description
 *
 * - It will done validation for the adavisor details form fields and bonds the data to a advisorDetails object.
 *
 **/
'use strict';

var fticUserConsent = function () {
    return {
        template: require('./userConsent.html'),
        restrict: 'E',
        scope: {
            userConsentForm : "=",
            tnc : '=?'
        }   
    };
};

fticUserConsent.$inject = [];
module.exports = fticUserConsent;