export class ParamField {

  paramFieldRelId: string;
  paramTypeId: string;
  paramType: string;
  response: string;
  paramFieldId: number;
  intentId : string;
  fieldName: string;
  fieldLabel: string;
  fieldType: string;
  displayOrder: number;
  fieldValues: string;
  paramName: string;
  paramValue : string;
  fieldText : string;
  displayImage: boolean;
  clientName: string;
  isRequired: string;

  textValue : string;
  selectValue : string;
  radioValue : string;
  checkValue : boolean;

  isModified : boolean;

  parsedFieldValues : Array<any>;

  validationMessage : string;

}
