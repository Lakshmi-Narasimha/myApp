define([
    'jquery',
    'lodash',
    'backbone',
    'q',
    'app/common/spinner',
    'app/common/util',
    'app/common/views/AbstractView',
    'app/application/app',
    'app/services/awmService',
    'app/application/views/HeaderSubView',
    'app/application/views/FooterSubView',
    'text!app/application/templates/AppViewTemplate.html',
    'app/common/constants',
], function ($, _, Backbone, Q, Spinner, util, AbstractView, app, awmService, HeaderSubView, FooterSubView, AppViewTemplate, constants) {

    //var APP_STEP  = constants.APP_STEP;

    return AbstractView.extend({
        el: '#appview',
        render: function () {
            var self = this;
            Spinner.show({
                parentElement: "appview",
            });
            Spinner.hide();
           var promises = [ awmService.promiseToGetOboAdvisors()];
            Q.all((promises)).then(function(results)  {
                [oboAdvisorCollection] = results;
                //util.userFmid = '' + parseInt(user.get('fmid'));
                //util.isCSR = user.isCSR();
                util.userFmid = '' + parseInt(oboAdvisorCollection.models[0].attributes.formattedFmid);
                signedOnAdvisor = oboAdvisorCollection.getSignedOnAdvisor();
                oboAdvisorCollection.removeNonAdvisorUser();
                app.userInformation = $.extend({}, (signedOnAdvisor ? signedOnAdvisor.attributes : {}));  // merge in order to get user's name from OBO response
                app.oboAdvisorList = util.isCSR ? [] : oboAdvisorCollection.models;
                if(app.selOboId){
                    let selObo = _.filter(app.oboAdvisorList,  (advisor) => {
                        return advisor.get('formattedFmid') === app.selOboId;
                    })[0];
                    selObo = selObo ? selObo.toJSON() : null;
                    app.userInformation = selObo || app.userInformation;
                    app.selOboId = null;
                }
                
                self.populateUI();
                Spinner.hide();
            }).fail(this.handleServiceError);
        },
        populateUI: function () {
            this.$el.html(AppViewTemplate);

            var headerSubView = new HeaderSubView();
            this.addNestedView('headerSubView', headerSubView);
            headerSubView.render();

            var footerSubView = new FooterSubView();
            this.addNestedView('footerSubView', footerSubView);
            footerSubView.render();

            this.initiateAppRouter();

        },
        setPrimaryView: function (view) {
            this.addNestedView('primary', view);
        },

    });

});
