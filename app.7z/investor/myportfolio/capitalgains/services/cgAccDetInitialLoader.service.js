/**
 * @ngdoc service
 * @name FTI Dashboard Initial Load Service
 * @requires cgAccDetModel
 * @requires investorEvents
 * @requires eventConstants
 * @requires toaster
 * @requires $timeout
 * investorEventConstants
 * fticLoggerMessage
 * loggerConstants
 * toaster
 * $loader
 * @description
 *
 * - Handles the services and model for Advisor content details & widgets
 *
 */
'use strict';


var fticgAccDetLoadInitialService = function(cgAccDetModel, investorEvents, eventConstants, $timeout, investorEventConstants, fticLoggerMessage, loggerConstants, toaster, $loader) {
	var fticgAccDetLoadInitialService = {
		_isServicesData: false,
		_isInitialLoad:false,
		loadAllServices : function (scope,cgfolioFilter) {
			cgAccDetModel.getFolioAccountDetails() 
			.then(folioNumbersListSuccess, promiseFailure).finally(stopLoader);
			function folioNumbersListSuccess(data){
				cgAccDetModel.setFolioNumbersList(data.panFolioAccounts);
				investorEvents.myPortfolio.capitalGainsFolisNumberList(scope);
			};
			function promiseFailure (data) {
				fticgAccDetLoadInitialService._isServicesData = false;
				fticgAccDetLoadInitialService._isInitialLoad = false;
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			};
			 function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		},
		getcgaccountdetails: function(scope, cgacfilter){
		 	cgAccDetModel.fetchcgaccountdetails(cgacfilter)
			.then(cgaccountdetailsSuccess, promiseFailure).finally(stopLoader);

			function cgaccountdetailsSuccess(data){
				// Setting the data for account view and its unitholder details
				cgAccDetModel.setcgaccountdetails(data.accdetails);
				cgAccDetModel.setcgaccountdetunitholder(data);
				investorEvents.myPortfolio.capitalgaingsaccountdetails(scope);
			}

			function promiseFailure (data) {
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
				
			}
			function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		},
		getCgFolioDetails: function(scope, cgFolioFilter){
		 	cgAccDetModel.fetchCgFolioDetails(cgFolioFilter)
			.then(cgFolioDetailsSuccess, promiseFailure).finally(stopLoader);

			function cgFolioDetailsSuccess(data){
				// Setting the data for account view and its unitholder details
				
				cgAccDetModel.setCgFoliodetails(data.foliodet);
				cgAccDetModel.setCapitalGainsUnitHolder(data);
				investorEvents.myPortfolio.capitalGaingsFoliodetails(scope);
			}
			function promiseFailure (data) {
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			}
			function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		},


	};
	return fticgAccDetLoadInitialService;
};


fticgAccDetLoadInitialService.$inject = ['cgAccDetModel', 'investorEvents', 'eventConstants', '$timeout', 'investorEventConstants', 'fticLoggerMessage', 'loggerConstants', 'toaster', '$loader'];

module.exports = fticgAccDetLoadInitialService;
