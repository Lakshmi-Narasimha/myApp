/**
 * @ngdoc property
 * @name accountStmtModel
 * @requires Restangular
 * @requires $q
 * @description
 *
 * - accountStmeModel is a service model which consists the list of services required for Account statements in 
 *   Statements tab of my investors page.
 *
 **/
'use strict';


var folioViewModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _folioViewObj = null;

    var folioViewDetails = {

        getFolioViewDetails: function(folioFilter) {
            folioFilter.flag = 'F';
            folioFilter.guId = authenticationService.getUser().guId;

            var deferred = $q.defer();
            Restangular.one('clients/clientStatement').get(folioFilter).then(function(FolioViewDetails) {
                deferred.resolve(FolioViewDetails);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        getFolioViewObj: function() {
            if (!angular.isDefined(_folioViewObj)) {
                return null;
            }
            return _folioViewObj;
        },
        setFolioViewObj: function(folioViewObj) {
            _folioViewObj = folioViewObj;
        }
    };

    return folioViewDetails;

};

folioViewModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = folioViewModel;
