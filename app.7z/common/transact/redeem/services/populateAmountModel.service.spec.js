'use strict';
describe('Service: amountModel ', function() {
	var amountModel,httpBackend,$window,fetchAmountValuePromise;

	var AmountResp = {
        'amount' : {
            'value': '550.12'
        }
    };

	var failureResponse =  [{
        'errorCode': 'E123',
        'errorDescription': 'Something went wrong...'
    }];
    
	beforeEach(angular.mock.module('advisor'));	

	beforeEach(inject(function($httpBackend,$window,populateAmountModel){	
		amountModel = populateAmountModel;		
        httpBackend = $httpBackend;		        
       
		$window = $window;
		$window.ga = function(){};
	}));
	
	it('should define the functions fetchAmountValue,setAmount',function(){
		expect(amountModel.fetchAmountValue).toBeDefined();
		expect(amountModel.setAmount).toBeDefined();
		expect(amountModel.getAmount).toBeDefined();
	});

	describe("fetchAmountValue promise",function(){
		beforeEach(inject(function() {						
			fetchAmountValuePromise = amountModel.fetchAmountValue();				
		}));

		it("should resolve promise when success",function(done){					
			httpBackend.expectGET('http://localhost:3030/getAmountValue').respond(200,[AmountResp]);
			fetchAmountValuePromise.then(function(response){														
				expect(response[0].amount.value).toBe("550.12");							 
				done();
			});
			
			httpBackend.flush();
		});

		it("should reject promise when failure",function(done){
			httpBackend.expectGET('http://localhost:3030/getAmountValue').respond(400,failureResponse);
			fetchAmountValuePromise.then(null,function(response){					
				expect(response.data[0].errorCode).toContain("E123");			
				done();
			});
			
			httpBackend.flush();
		});
	});
});	
