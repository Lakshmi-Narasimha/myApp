// getAdvisorNotifications.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var AdvisorNotificationsSchema = new mongoose.Schema({
    advisorNotificationsObject: {
        type: Array,
        "default": []
    }
});

var AdvisorNotificationsLookUp = mongoose.model('AdvisorNotificationsLookup', AdvisorNotificationsSchema);

var AdvisorNotificationsModel = new AdvisorNotificationsLookUp({

  "advisorNotificationsObject": [
    {
        "notifications": {
            "count": 23,
            "items": [{
                "title": "bold text",
                "text": "Brokerage paid out report for Jan 2016",
                "timeOccured": "text"
            }, {
                "title": "Addendum",
                "text": "Shifting of CAMS branch office",
                "timeOccured": "text"
            }, {
                "title": "bold text",
                "text": "Shifting of CAMS branch office",
                "timeOccured": "text"
            },
            {
                "title": "bold text",
                "text": "Shifting of CAMS branch office",
                "timeOccured": "text"
            },
            {
                "title": "bold text",
                "text": "Shifting of CAMS branch office",
                "timeOccured": "text"
            }]
        }
    }
    ]

});

AdvisorNotificationsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating AdvisorNotificationsLookUp table, please contact admin...');
    } else {
        AdvisorNotificationsLookUp.remove({}, function(err) {
            console.log('AdvisorNotificationsLookUp collection removed');
            AdvisorNotificationsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating AdvisorNotificationsLookUp table, please contact admin...');
                }
                console.log('AdvisorNotificationsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = AdvisorNotificationsLookUp;
