/* eslint-disable */
'use strict';

describe('Directive: CMP filter', function() {

  var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('commmon.components'));

    
    beforeEach(function() {

    angular.mock.inject(function($rootScope, $compile) {
        scope = $rootScope.$new();
        compile = $compile;
        $scope.cmpoptions = [{
                    id: 1,
                    label: 'Month',
                    type: 'date'
                  },
                  {
                    id: 2,
                    label: 'Fund Name',
                    type: 'text'
                  },
                  {
                    id: 3,
                    label: 'Aum Size',
                    type: 'number'
                  }
                ];
        

        
        //assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-cmp-filter filter-options="cmpoptions"></ftic-cmp-filter>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

  it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should define ftic-section-filter element', function() {
        expect(directiveEle.html()).toBeDefined();
        
    });

    /*it('should define ftic-section-filter element', function() {
        expect(directiveEle.scope.selected).toBeDefined(scope.selected);
        
    });*/
    it('should define objectProperty title to given value', function() {  
        
        expect(isoScope.cmpoptions[0].type).toEqual('date');
    });

});