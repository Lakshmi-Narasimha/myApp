var config = require('../../../config/config');

var engagementModelConfig = {
    response: {
        "sessionOver": false,
        "Page": {
            "pageType": "livechat",
            "parentPageType": "myData",
            "status": "accepted",
            "customerID": "-1196452978310233060",
            "engagementID": "-1196452978309958273",
            "callType": "engagement",
            "timeToWait": "5",
            "showChatHistory": true,
            "agentBusy": false
        },
        "ResponseInfo": {
            "locale": "en",
            "requestId": "a19cc1d0-0c38-4abb-b648-e94a99bc95c8",
            "code": "00000",
            "type": "Success"
        },
        "ModuleMap": {
            "Support": {
                "startMsgId": 10000,
                "searchStartIndex": 10000,
                "ResponseInfo": {
                    "locale": "en",
                    "requestId": "810fbde5-cc9e-48e8-af51-fd9d9484756b",
                    "code": "00000",
                    "type": "ChatTop",
                    "messageStyle": "TopPersistent",
                    "message": "Waiting for live chat",
                    "topMessage": "Your live chat will start soon",
                    "userMessage": "An expert will join you shortly",
                    "buttonTitle": "View"
                },
                "msgList": []
            }
        }
    },
    createRequestUri: {
        Billing: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Billing,
        },
        WirelessSales: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessSales + '&agentGroupID=' + config.AG_WirelessSales,
        },
        Device: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Device,
        },
        Global: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_Global,
        },
        MVTrans: {
            host: config.TC_SERVER_NAME,
            path: config.TC_ENGAGEMENT_URI + '&siteID=' + config.TC_SITE_ID + '&businessUnitID=' + config.BU_WirelessCare + '&agentGroupID=' + config.AG_MVTrans,
        }
    }
};

module.exports = engagementModelConfig;
