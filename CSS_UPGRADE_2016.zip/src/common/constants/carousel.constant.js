/**
 * @ngdoc property
 * @name common
 * @requires $scope
 * @description
 *
 * -This is a sample comment for ngdoc
 *
 */
(function() {
    angular.module('PayOutsideLogin.common').constant('carouselConstant', {
        default_carousel_constants: [
        // {
        //     "header1": "SCHEDULE YOUR FREE",
        //     "header2": "FARMERS FRIENDLY REVIEW",
        //     "imageBackground": window.sitePrefix + "assets/style/images/backgrounds/carosel-hero-img.jpg",

        //     "content": "Review your policies and discuss coverage options with a personalized Farmers Friendly Review.",
        //     "linkText": "Learn More",
        //     "linkHref": "http://www.farmers.com/farmers-friendly-review/",
        //     "cardIndex": 0
        // }, {
        //     "header1": "",
        //     "header2": "EARN 3X POINTS",
        //     "imageBackground": window.sitePrefix + "assets/style/images/backgrounds/carosel-cc-img1.png",

        //     "content": "on Farmers Products, Home Improvement, and Gas with the Farmers® Rewards Visa®.",
        //     "linkText": "Learn More",
        //     "linkHref": "https://www.farmers.com/rewardsvisa/?utm_campaign=FarmersCreditCard_banner&utm_content=rewarscardCSS",
        //     "cardIndex": 1
        // }
        ],

        additonalServicesConstants: [
        // {
        //     "header1": "Save on ",
        //     "header2": "life insurance",
        //     "imageBackground": "",
        //     "content": "Know that no matter what tomorrow may bring, your family's financial future is ensured.",
        //     "linkText": "Get A Quote",
        //     "additionalTile": true
        // }, {
        //     "header1": "Save on ",
        //     "header2": "life insurance",
        //     "imageBackground": "",
        //     "content": "Know that no matter what tomorrow may bring, your family's financial future is ensured.",
        //     "linkText": "Get A Quote",
        //     "linkHref": "https://www.farmers.com/quote/ffq4/life/lifeComparison.jsf",
        //     "additionalTile": true
        // }, {
        //     "header1": "Save on ",
        //     "header2": "life insurance",
        //     "imageBackground": "",
        //     "content": "Know that no matter what tomorrow may bring, your family's financial future is ensured.",
        //     "linkText": "Get A Quote",
        //     "linkHref": "https://www.farmers.com/quote/ffq4/life/lifeComparison.jsf",
        //     "additionalTile": true
        // }
        ]

    });
})();
