/* eslint-disable */
'use strict';

/*Unit test case for uicUtilityDropdownMenu*/

describe('directive: uicUtilityDropdownMenu', function() {

    var scope, compile, validHTML, httpBackend, timeout,
    menu = [
            {
               "text":"About Us",
               "menuitem":"aboutus",
               "submenu":[
                  {
                     "text":"The Franklin Templeton Story",
                     "url":""
                  },
                  {
                     "text":"Franklin Templeton India",
                     "url":""
                  },
                  {
                     "text":"Global Office",
                     "url":""
                  },
                  {
                     "text":"CSR Initiatives India",
                     "url":""
                  }
               ]
            }
         ];

    validHTML = '<uic-utility-dropdown-menu></uic-utility-dropdown-menu>';
    beforeEach(angular.mock.module('common','commmon.components.dropdown'));

    beforeEach(angular.mock.inject(function($compile, $rootScope, $httpBackend, $timeout) {
        scope = $rootScope.$new();
        scope.menu = menu;
        httpBackend = $httpBackend;
        timeout = $timeout;
        compile = $compile;
    }));

    function create() {
        var elem, compiledElem;
        elem = angular.element(validHTML);
        compiledElem = compile(elem)(scope);
        scope.$digest();
        return compiledElem;
    }

    it('should create seperate isolated scope', function() {
        var el = create(),
        isoScope = el.isolateScope();
        expect(isoScope).toBeDefined();
    });

    it('should have defined attributes for displaying the dropdown menu', function(){
        var el = create(),
        isoScope = el.isolateScope();
        expect(isoScope.dropdownMTitle).toEqual('About Us');
        expect(isoScope.dropdownTitle).toEqual('About Us');
        expect(isoScope.menuItems).toEqual(menu[0].submenu);
    }); 


});
