define([
], function () {
    let config = {
        awmServicePath:'https://mgpclientselector.qa.advisorcompass.com/ods.svc/',
        mgpServiceUrl:'https://mgpclientselector.qa.advisorcompass.com/ResponseProviderService/svc/mgp/',
        oboServicePath: 'https://mgpclientselector.qa.advisorcompass.com/adv_capl/oboselector/',
        launchMgpUrl: 'pt-exit-mgp-scenario-1.html',
        mgpSubscriptionUrl: 'http://laa2app2527xrp:10108/fumigo.svc/',
    };

    return config;

});