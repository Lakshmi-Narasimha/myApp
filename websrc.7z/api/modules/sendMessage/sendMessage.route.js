var express = require('express');
var https = require('https');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var router = express.Router();
var sendMessageModel = require('./sendMessage.model');
var apiUtils = require('../../common/apiUtils');

// api route
router.route('/mfchat/rest/message')
    .post(function(req, res) {
        logger.outBoundData.info(logger.formatReqMsg(req, res));
        req.uri = sendMessageModel.createRequestUri;
        req.session.mqtt = req.body.RequestParams.mqtt;
        delete req.body.RequestParams.mqtt;
        var post_data = req.body.RequestParams;
        var postBody = querystring.stringify(post_data);
        console.log("send message api url:", postBody);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: false
        };
        logger.inBoundData.info(logger.formatInBoundReqMsg(reqObj, res, post_data));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, proxyResponse));
            console.log("proxyResponse.statusCode:", proxyResponse.statusCode);
            req.session.chatSendMsgCounter = (req.session.chatSendMsgCounter || 0);
            //console.log("req:", req.body.RequestParams);
            proxyResponse.setEncoding('utf8');
            logger.inBoundData.info(logger.formatInBoundResMsg(reqObj, proxyResponse));
            if (proxyResponse.statusCode === 200) {

                console.log("SendMsgCounter:", req.session.chatSendMsgCounter++);
                req.session.chatSendMsgCounter++;
                //sendMessageModel.response.Page.state = req.body.RequestParams.state;
                //console.log("not closed", req.body.RequestParams);
                //console.log("closed", sendMessageModel.response.Page.state);
                console.log("SendMsgStatusPostBody:", post_data);
                /* After three times GET Call */
                //req.session.mqtt = post_data.mqtt;
                if (req.session.mqtt) {
                    var isNewReq = true;

                    function getMsgReccursive() {
                        if (req.session) {
                            apiUtils.formattedGetMsg(req, res, function(chunk) {
                                //res.send(chunk);
                                console.log("formattedGetMsg");
                                //console.log(chunk.ModuleMap.Support.msgList[0].messageList[0]);
                                req.session.getMsgRes = chunk;
                                if (chunk.ModuleMap && chunk.ModuleMap.Support.msgList[0].messageList[0].messageText) {
                                    apiUtils.sendCmd(req, res, function(response) {
                                        console.log("send Command api trigerred:", response);
                                        if (isNewReq) {
                                            logger.outBoundData.info(logger.formatResMsg(req, response));
                                            res.send(response);
                                            isNewReq = false;
                                        } else {
                                            res.status(200).end();
                                        }
                                        getMsgReccursive();
                                    }, true);

                                } else {
                                    if (isNewReq) {
                                        logger.outBoundData.info(logger.formatResMsg(req, chunk));
                                        res.send(chunk);
                                        isNewReq = false;
                                    } else {
                                        res.status(200).end();
                                    }
                                    getMsgReccursive();
                                }
                            });

                        }

                    }
                    getMsgReccursive();
                } else {
                    logger.outBoundData.info(logger.formatResMsg(req, sendMessageModel.response));
                    res.send(sendMessageModel.response);
                }
                //res.send(sendMessageModel.response);
                //res.status(200).end();
            } else {
                var errObj = {
                    statusCode: proxyResponse.statusCode,
                    message: 'Something went wrong while retrieving data.'
                };
                res.send(errObj);
                logger.error.error(logger.formatResMsg(req, errObj));
            }
            proxyResponse.on('error', function(err) {
                err.message = 'ERROR!!! Something went wrong while retrieving data.';
                res.send(err);
                logger.error.error(logger.formatResMsg(req, err));
            });
        });
        proxyRequest.write(postBody);
        proxyRequest.end();
    });

module.exports = router;
