/**
 * @ngdoc factory
 * @name Investor Dashboard chart factory
 * @requires loggerConstants
 * @description
 *
 * - Handles config of the investment charts
 *
 */
'use strict';

var invSelectFolioFormDataFactory = function (TransactConstant, investorConstants, $state, proceedToBuyDataFactory, kycRegisterStatusModel) {

    var _selectedFolioFormattedData = {};

    var invSelectFolioFormDataFactory = {
        setFormattedCurrentFolio: function (selectedFolio) {
            var _formattedList = {};
            _formattedList.folioId = selectedFolio.folioId;
            _formattedList.index = selectedFolio.index;
            _formattedList.holdingType = selectedFolio.modeofHolding;
            _formattedList.holders = [{
                name: selectedFolio.firstHolderName
            }, {
                name: selectedFolio.secondHolderName
            }, {
                name: selectedFolio.thirdHolderName
            }];
            _selectedFolioFormattedData[selectedFolio.folioId] = _formattedList;
        },
        getCurrentSelectedFolioData: function (folioId) {
            return _selectedFolioFormattedData[folioId];
        },
        getFormattedHolderDetails: function (data, userProfileData, smartsolFolio) {
            var _holderDetails = [];
            if (data !== null) {
                for (var i = 0; i < data.length; i++) {
                    var folioObj = {
                        folioId: '',
                        labelFolioId: '',
                        firstHolderName: 'NA',
                        firstHolderKyc: 'NA',
                        secondHolderName: 'NA',
                        secondHolderKyc: 'NA',
                        thirdHolderName: 'NA',
                        thirdHolderKyc: 'NA',
                        modeofHolding: '',
                        isFolioKYCReg: false
                    };
                    if(data[i].fsFlag === 'Y' && smartsolFolio === 'smartSolFolio') {
                        folioObj.labelFolioId = 'Folio ' + data[i].folioDisplay;
                    } else {
                        folioObj.labelFolioId = 'Folio ' + data[i].folioId;
                    }                    
                    folioObj.folioId = data[i].folioId;
                    folioObj.modeofHolding = data[i].holdingType;
                    var kycRegCount = 0;
                    var holderCount = 0;
                    for (var j = 0; j < data[i].holders.length; j++) {
                        if (data[i].holders[j].type === TransactConstant.common.FIRST_HOLDER) {
                            folioObj.firstHolderName = data[i].holders[j].name.trim();
                            folioObj.firstHolderPan = data[i].holders[j].pan.trim();
                            folioObj.firstHolderEmail = data[i].holders[j].emailId.trim();
                            folioObj.firstHolderMobile = data[i].holders[j].mobileNo.trim();
                            /**
                             * Code Below Added for Defect 4024 - Start
                             */
                            if(folioObj.firstHolderName || folioObj.firstHolderPan) {
                                folioObj.firstHolderKyc = kycRegisterStatusModel.checkKycStatus(data[i].holders[j].kycStatus.trim());
                            }
                            /**
                             * Code Below Added for Defect 4024 - End
                             */
                            if (folioObj.firstHolderName && folioObj.firstHolderPan) {
                                holderCount++;
                                if (folioObj.firstHolderKyc) {
                                    kycRegCount++;                                    
                                }
                            }
                        }
                        if (data[i].holders[j].type === TransactConstant.common.SECOND_HOLDER) {
                            folioObj.secondHolderName = data[i].holders[j].name.trim();
                            folioObj.secondHolderPan = data[i].holders[j].pan.trim();
                            /**
                             * Code Below Added for Defect 4024 - Start
                             */
                            if(folioObj.secondHolderName || folioObj.secondHolderPan) {
                                folioObj.secondHolderKyc = kycRegisterStatusModel.checkKycStatus(data[i].holders[j].kycStatus.trim());
                            }
                            /**
                             * Code Below Added for Defect 4024 - End
                             */
                            if (folioObj.secondHolderName && folioObj.secondHolderPan) {
                                holderCount++;
                                if (folioObj.secondHolderKyc) {
                                    kycRegCount++;
                                }
                            }
                        }
                        if (data[i].holders[j].type === TransactConstant.common.THIRD_HOLDER) {
                            folioObj.thirdHolderName = data[i].holders[j].name.trim();
                            folioObj.thirdHolderPan = data[i].holders[j].pan.trim();
                            /**
                             * Code Below Added for Defect 4024 - Start
                             */
                            if(folioObj.thirdHolderName || folioObj.thirdHolderPan) {
                                folioObj.thirdHolderKyc = kycRegisterStatusModel.checkKycStatus(data[i].holders[j].kycStatus.trim());
                            }
                            /**
                             * Code Below Added for Defect 4024 - End
                             */
                            if (folioObj.thirdHolderName && folioObj.thirdHolderPan) {
                                holderCount++;
                                if (folioObj.thirdHolderKyc) {
                                    kycRegCount++;
                                }
                            }
                        }
                    }
                    folioObj.isFolioKYCReg = holderCount === kycRegCount;
                    folioObj.custName = folioObj.firstHolderName;
                    folioObj.pan = folioObj.firstHolderPan ? folioObj.firstHolderPan : 'NA';
                    folioObj.email = folioObj.firstHolderEmail ? folioObj.firstHolderEmail : 'NA';
                    folioObj.mobile = folioObj.firstHolderMobile ? folioObj.firstHolderMobile : 'NA';
                    folioObj.holders = data[i].holders;
                    _holderDetails.push(folioObj);
                }
                return _holderDetails;
            }else {
                return _holderDetails;
            }
        },
        filterFamilysmartdata: function(data) {
            
            var panFolioKycs = [];
            angular.forEach(data.panFolioKyc, function(eachfolio){
                if(eachfolio.fsFlag === 'Y') {
                    panFolioKycs.push(eachfolio);
                }
            });
            return panFolioKycs;
        },
        showKycPopup: function(folio){
            var route = $state.current.url;
            if (folio.folioId === 'New Folio') {
                return (route === '/buy' || route === '/sip' || route === '/smartSolSelectFolio') && !folio.firstHolderKyc;
            } else {
                var kyc = 'KYC - Registered', isKycReg = true;
                var _holders = proceedToBuyDataFactory.filterFolioDetails(folio.holders);
                _holders.every(function(element) {
                    if(element.kycStatus !== kyc) {
                        isKycReg = false;
                        return 0;
                    } else {
                        return 1;
                    }
                });
                return (route !=='/cancelStp' && route !== '/redeem' && route !== '/swp') && !isKycReg;
            }            
        },
        settingModeOfKycFlag : function(holders) {
            var settingModeOfKycFlag = false;
            angular.forEach(holders, function(eachHolder){
                if(eachHolder.type === 'Firstholder' || eachHolder.type === 'Secondholder' || eachHolder.type === 'Thirdholder'){
                    if(eachHolder.modeOfKyc === '0' && eachHolder.modeOfKyc !== '1' && eachHolder.modeOfKyc !== '2') {
                        settingModeOfKycFlag = true;
                    } else if(eachHolder.modeOfKyc === '2' && eachHolder.modeOfKyc !== '1' && eachHolder.modeOfKyc !== '0') {
                        settingModeOfKycFlag = true;
                    } else {
                        settingModeOfKycFlag = false;
                    }
                }
            });
            return settingModeOfKycFlag;
        }
    };
    return invSelectFolioFormDataFactory;

};

invSelectFolioFormDataFactory.$inject = ['TransactConstant', 'investorConstants', '$state', 'proceedToBuyDataFactory', 'kycRegisterStatusModel'];
module.exports = invSelectFolioFormDataFactory;
