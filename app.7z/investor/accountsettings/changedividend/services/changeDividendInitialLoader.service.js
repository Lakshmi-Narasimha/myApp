/**
 * @requires investorEvents
 * @requires eventConstants
 * investorEventConstants
 * fticLoggerMessage
 * loggerConstants
 * toaster
 * $loader
 * @description
**/

'use strict';

var changeDividendInitialLoadService = function(investorEvents, eventConstants, investorEventConstants, changeDividendModel, $loader, toaster) {
	var changeDividendInitialLoadService = {
		_isInitialLoadDone:false,
		getDividendDetails : function (scope,categoryParam) {
			changeDividendModel.getDividendDetailsFromApi(categoryParam) 
			.then(changeDividendPromiseSuccess, changeDividendPromiseFailure).finally(stopLoader);
			function changeDividendPromiseSuccess(data){
				changeDividendModel.setDividendDetailsData(data.dividendSchemes);
				investorEvents.accountSettings.broadcastDividendDetails(scope);
			};
			function changeDividendPromiseFailure (err) {
				toaster.error(err.data[0].errorDescription);
			};
			function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		},
		getAssetCategoryData : function (scope) {
				console.log('Iam in getAssetCategoryData');
			changeDividendModel.getAssetCategoryListFromApi() 
			.then(getAssetCategoryPromiseSuccess, getAssetCategoryPromiseFailure).finally(stopLoader);
			function getAssetCategoryPromiseSuccess(data){
					console.log('getAssetCategoryPromiseSuccess');
				changeDividendModel.setAssetCategoryList(data.codeValueList);
				investorEvents.accountSettings.broadcastDividendChangeAssetCategories(scope);
			};
			function getAssetCategoryPromiseFailure (err) {
				toaster.error(err.data[0].errorDescription);
			};
			function stopLoader() {
                $loader.stop();
            };

            $loader.start();
		}
	}
	return changeDividendInitialLoadService;
};
changeDividendInitialLoadService.$inject = ['investorEvents', 'eventConstants', 'investorEventConstants', 'changeDividendModel', '$loader', 'toaster'];

module.exports = changeDividendInitialLoadService;
