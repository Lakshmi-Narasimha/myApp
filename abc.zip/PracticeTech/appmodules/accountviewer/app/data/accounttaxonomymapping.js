define([
	'appmodules/accountviewer/app/views/accountdetailownershipview',
	'appmodules/accountviewer/app/views/accountdetailonefeaturesview',
	'appmodules/accountviewer/app/views/accountdetailaddressview',
	'appmodules/accountviewer/app/views/accountdetailgroupsview',
	'appmodules/accountviewer/app/views/accountdetailclientsview',
	'appmodules/accountviewer/app/views/accountdetailbeneficiariesview',
	'appmodules/accountviewer/app/views/accountdetailconvertedview',
	'appmodules/accountviewer/app/views/accountdetailbrokeragevalueview',
	'appmodules/accountviewer/app/views/accountdetailpositionsview',
	'appmodules/accountviewer/app/views/accountdetailmutualfundvalueview',
	'appmodules/accountviewer/app/views/accountdetailliquidationview',
	'appmodules/accountviewer/app/views/accountdetailcostbasisview',
	'appmodules/accountviewer/app/views/accountdetailinvestmentview'
	],
	function(
			AccountDetailOwnershipView,
			AccountDetailOneFeaturesView,
			AccountDetailAddressView,
			AccountDetailGroupsView,
			AccountDetailClientsView,
			AccountDetailBeneficiariesView,
			AccountDetailConversionView,
			AccountDetailBrokerageValueView,
			AccountDetailPositionsView,
			AccountDetailMutualFundValueView,
			AccountDetailLiquidationView,
			AccountDetailCostBasisView,
			AccountDetailInvestmentView
	) {
	
	var mappings = {
		"BROKERAGE/BETA/ACTIVE" : {
			sections: [
				{id: 'ownership', title: '', view: AccountDetailOwnershipView, isExpandable: false},
				{id: 'value', title: '', view: AccountDetailBrokerageValueView, isExpandable: false},
				{id: 'positions', title: 'Positions held', view: AccountDetailPositionsView, isExpandable: true},
				{id: 'beneficiaries', title: 'Beneficiaries', view: AccountDetailBeneficiariesView, isExpandable: true},
				{id: 'groups', title: 'Associated groups', view: AccountDetailGroupsView, isExpandable: true},
				{id: 'clients', title: 'Associated clients', view: AccountDetailClientsView, isExpandable: true},
				{id: 'address', title: 'Address', view: AccountDetailAddressView, isExpandable: true},
				{id: 'conversions', title: 'Converted account', view: AccountDetailConversionView, isExpandable: true}
			]
		},
		"BROKERAGE.ONE/BETA/ACTIVE" : {
			sections: [
				{id: 'ownership', title: '', view: AccountDetailOwnershipView, isExpandable: false},
				{id: 'value', title: '', view: AccountDetailBrokerageValueView, isExpandable: false},
				{id: 'positions', title: 'Positions held', view: AccountDetailPositionsView, isExpandable: true},
				{id: 'beneficiaries', title: 'Beneficiaries', view: AccountDetailBeneficiariesView, isExpandable: true},
				{id: 'groups', title: 'Associated groups', view: AccountDetailGroupsView, isExpandable: true},
				{id: 'clients', title: 'Associated clients', view: AccountDetailClientsView, isExpandable: true},
				{id: 'address', title: 'Address', view: AccountDetailAddressView, isExpandable: true},
				{id: 'onefeatures', title: 'ONE features', view: AccountDetailOneFeaturesView, isExpandable: true},
				{id: 'conversions', title: 'Converted account', view: AccountDetailConversionView, isExpandable: true}
			]
		},
		"MUTUALFUND/FUNDS/ACTIVE" : {
			sections: [
				{id: 'ownership', title: '', view: AccountDetailOwnershipView, isExpandable: false},
				{id: 'value', title: '', view: AccountDetailMutualFundValueView, isExpandable: false},
				{id: 'liquidation', title: 'Liquidation information', view: AccountDetailLiquidationView, isExpandable: true},
				{id: 'investment', title: 'Investment information', view: AccountDetailInvestmentView, isExpandable: true},
				{id: 'costbasis', title: 'Cost basis information', view: AccountDetailCostBasisView, isExpandable: true},
				{id: 'beneficiaries', title: 'Beneficiaries', view: AccountDetailBeneficiariesView, isExpandable: true},
				{id: 'groups', title: 'Associated groups', view: AccountDetailGroupsView, isExpandable: true},
				{id: 'clients', title: 'Associated clients', view: AccountDetailClientsView, isExpandable: true},
				{id: 'address', title: 'Address', view: AccountDetailAddressView, isExpandable: true}
			]
		}
	}

	return mappings;

});
