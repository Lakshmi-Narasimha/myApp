/**
 * @ngdoc property
 * @name investorDetailsVerticalTileList Directive
 * @description
 *
 * investorDetailsVerticalTileList - Displays List Item for the given User
 *
 **/
 
'use strict';

var sipVerticalTileList = function(eventConstants,transactEventConstants) {
	return {
        template: require('./sipVerticalTileList.html'),
        restrict: 'E',
        replace: true,
        scope:{
            eventName: "@",
            keyValueList: "="
        },
        controller:['$scope', function($scope){
            
            $scope.$on(eventConstants.ACTION_ICON_CLICKED, function (event, args) {         
                 $scope.$emit($scope.eventName);
            });
        }]
    }
};

sipVerticalTileList.$inject = ['eventConstants','transactEventConstants'];
module.exports = sipVerticalTileList;