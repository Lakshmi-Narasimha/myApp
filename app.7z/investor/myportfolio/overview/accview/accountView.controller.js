/**
 * @ngdoc controller
 * @name accountViewController
 * @requires $scope
 * @requires accountViewInitialLoader
 * @description
 *
 * - It represents controller function of the Account view 
 *
 **/

'use strict';

function accountViewController($scope, folioViewModel, folioViewInitialLoader, accountViewInitialLoader, $state, investorEventConstants, invInstantMailback, downloadService,accountViewModel,investorConstants) {


    $scope.$emit('changeNavPill', 'accview');
    $scope.viewObj = {};
    $scope.viewObj.isFolioDataAvailable = false;
    folioViewInitialLoader.loadFolioAccountDetails($scope);
    $scope.$on(investorEventConstants.MyPortfolio.OVERVIEW_FOLIO_ACCOUNTS, function() {
        $scope.viewObj.showFolioAccounts = true;
    });
    $scope.$on('apply', function(event, accountFilter) {
        invInstantMailback.setMailBackData({
            folioPanAcc: accountFilter.folioPanAccNo,
            fromDate: accountFilter.fromDate || null,
            toDate: accountFilter.toDate || null,
            periodType: accountFilter.dayFlag
        });
        downloadService.setQueryparams({
            strInputData: accountFilter.folioPanAccNo,
            inputFlag: 'A',
            periodType: accountFilter.dayFlag,
            dtFromDate: accountFilter.fromDate,
            dtToDate: (accountFilter.dayFlag === 'DR' ? accountFilter.toDate : null)
        });
        $scope.showActData = false;
        accountViewInitialLoader.loadAllServices($scope, accountFilter);
    });

    $scope.$on(investorEventConstants.MyPortfolio.ACCT_STMTS_ACCOUNT_VIEW, function() {
        $scope.showActData = false;
        $scope.viewObj.isFolioDataAvailable = (accountViewModel.getAccountViewObj() ? accountViewModel.getAccountViewObj()  : false);
        console.log('result', +$scope.viewObj.isFolioDataAvailable);
        if ($scope.viewObj.isFolioDataAvailable) {
            $scope.showActData  = true;
        } else {
            $scope.viewObj.isFolioDataAvailable = true;
            $scope.viewObj.folioViewErrorMsg = investorConstants.dashboard.DATA_CURRENTLY_UNAVAILABLE;
        }

    });
}

accountViewController.$inject = ['$scope', 'folioViewModel', 'folioViewInitialLoader', 'accountViewInitialLoader', '$state', 'investorEventConstants', 'invInstantMailback', 'downloadService', 'accountViewModel','investorConstants'];

module.exports = accountViewController;
