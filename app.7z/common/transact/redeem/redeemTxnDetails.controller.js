/**
 * @ngdoc property
 * @name Review Redeem Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewController($scope, fticLoggerMessage, loggerConstants, $state, transactModel, redeemReviewDetailsFactory) {
    console.info('redeem Txn Details Controller!!');

    $scope.isInvestorType = false;
    $scope.isInvestorType = redeemReviewDetailsFactory.isLoggedInvestor();

    $scope.redirect = function() {
        transactModel.resetSetters();
        // transactModel.setStateValue({key:'Fund'});
        transactModel.isNewInvestor = false;
        $state.go('transact.base.redeem', { key: null });
    };

   
}

reviewController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'transactModel', 'redeemReviewDetailsFactory'];
module.exports = reviewController;
