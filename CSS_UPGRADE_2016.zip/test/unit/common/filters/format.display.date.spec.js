'use strict';

/* jasmine specs for controllers go here */

describe('formatDisplayDate', function() {

	var formatDateFilter;

	beforeEach(module('CSS.commonfilter'));

	beforeEach(inject(function($injector) {
	    formatDateFilter = $injector.get('$filter')('formatDisplayDate');
	}));

	//--- Test for definition

	it('should expect formatDateFilter to be defined...', function(){
		expect(formatDateFilter).toBeDefined();
	});

	//--- Test formatDateFilter

	it('should format the given date to mm/dd/yyyy format when format is 2015-02-19T11:59:04...', function(){
		expect(formatDateFilter('2015-02-19T11:59:04.159Z')).toEqual('02/19/2015');
	});

	it('should format the given date to mm/dd/yyyy format when format is "2015-02-19"...', function(){
		expect(formatDateFilter('2015-02-19')).toEqual('2015/02/19');
	});
});