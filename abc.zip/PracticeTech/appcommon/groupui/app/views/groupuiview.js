define([
  'jquery',
  'underscore',
  'backbone',
  'appcommon/constants',
   'services/dataservice',
   'appcommon/groupui/app/models/groupcontext',
   'text!appcommon/groupui/app/templates/groupui.html',
   'text!appcommon/groupui/app/templates/clientsearchgrpshell.html',
   'text!appcommon/groupui/app/templates/clientsearchgroup.html',
   'appcommon/globalcontext',
   'appcommon/groupui/app/views/groupuiview',
   'appcommon/analytics',
   'apipublic/navapi',
   'appcommon/hocindicator',
   'appmodules/contactprofile/app/models/cpviewmodel'
], function ($, _, Backbone, Constants, DataService, GroupContext, GroupUI, ClientSearchgrpshell, ClientSearchgroup, GlobalContext, GroupUi, Analytics, NavApi, HOCIndicator, CPViewModel) {
    var Self = null, groupIdFromContext = undefined, plantypecodeval = [], groupuiview = Backbone.View.extend({
        events: {},
        initialize: function (options) {
            Self = this;
            this.pensionGrpArr = [];
            this.optionalCallback = null;
            this.localEvent = false;
            this.noCache = options.NoCahe;
            this.globalContext = GlobalContext.getInstance();
            this.isRefresh = false;
            this.currentFmId = undefined;
            this.currentContactId = undefined;
            this.currentGroupId = undefined;
            this.grpContext = new GroupContext.groupMemberModel();
            this.listenTo(this.grpContext, 'change:selectedcontact', this.eventTriggered);
            this.listenTo(this.grpContext, 'change:selectedgroup', this.eventTriggered);
            var that = this;
            $(document).off("click", ".afinav-grp-lnk").on("click", ".afinav-grp-lnk", function (e) {
                that.groupchangeevent(e);
            });
        },
        close: function () {
            if (this.beforeClose) {
                this.beforeClose();
            }
            this.undelegateEvents();
            $(this).empty;
            this.unbind();
        },
        template: _.template([
            "<li id='globalgrpholder'>",
               "<%= groupListTemplate %>",
            "</div>"
        ].join('')),
        render: function (optionalCallback) {
            this.isRefresh = false;
            this.optionalCallback = optionalCallback !== undefined ? optionalCallback : null;
            if (this.globalContext.getGlobalContext().Context.ContactId != undefined && this.globalContext.getGlobalContext().Context.GroupId != undefined) {
                this.grpContext.set({ selectedgroup: this.globalContext.getGlobalContext().Context.GroupId }, { "silent": true });
                this.grpContext.set({ selectedcontact: this.globalContext.getGlobalContext().Context.ContactId }, { "silent": true });
                this.repopulateGroupMenu(this.globalContext.getGlobalContext().Context.ContactId, this.globalContext.getGlobalContext().Context.GroupId);
            }
            else if (this.globalContext.getGlobalContext().Context.ContactId != undefined && this.globalContext.getGlobalContext().Context.GroupId == undefined) {
                this.grpContext.set({ selectedgroup: undefined }, { "silent": true });
                this.grpContext.set({ selectedcontact: this.globalContext.getGlobalContext().Context.ContactId, triggeredevent: GroupContext.eventNames.ContactChanged });
            }
            else {
                this.grpContext.set({ selectedgroup: undefined }, { silent: true });
                this.grpContext.set({ selectedcontact: this.currentContactId, triggeredevent: GroupContext.eventNames.ContactChanged });
            }
            groupIdFromContext = undefined;
            return this;
        },
        getPlanTypeCode: function (typeCd) {
            var planTypCdList = {
                "00": "Not Applicable",
                "01": "Defined Benefit",
                "02": "401(K)",
                "03": "Thrift Plan",
                "04": "Assumed/Target Benefit",
                "05": "Profit Sharing",
                "06": "Money Purchase",
                "07": "457 Govt. Plan",
                "08": "Incentive & Thrift",
                "09": "Div Mgr Retirement",
                "10": "Other",
                "11": "Roth 401(K)"
            };
            try {
                if (!typeCd) {
                    return "";
                } else {
                    return planTypCdList[typeCd];
                }
            } catch (err) {
                return null;
            }
        },
        populateClientGroup: function (clientid, grpId) {
            var that = this;
            DataService.getClientgroup(clientid).then(gotoclientGroupSelected);
            function gotoclientGroupSelected(clientGroups) {
                var modifgroup = [];
                var pensionGrp = [];
                if (clientGroups != undefined && clientGroups[0] != undefined && clientGroups[0].attributes.activeGroups[0] == undefined) {
                    var cpdata = CPViewModel.getInstance().getData(),
						clientInfo = NavApi.getSelecetdContactdetails(that.globalContext.getGlobalContext().Context.AdvisorFMID, that.globalContext.getGlobalContext().Context.ContactId);
                    var tmpUlTemplate = _.template(GroupUI);
                    var htmlUlTemplate = tmpUlTemplate({
                        clientInfo: clientInfo,
                        groupList: '',
                        cpdata: cpdata
                    });

                    var finalElRenderTemplate = that.template({
                        groupListTemplate: htmlUlTemplate
                    });
                    that.$el.html(finalElRenderTemplate);
                    $('.household-grp-container').hide();
                    $('#hocshell').addClass('nogroup-minheight');
                    that.renderHOCLaunchBtn(true);
                    $.event.trigger({
                        type: "groupComponentReady",
                        message: { 'status': "nogroups", "clId": clientid, "grpId": null }
                    });
                } else if (clientGroups != undefined && clientGroups[0] != undefined && clientGroups[0].attributes.activeGroups[0] != undefined) {
                    var asyncGrpMembCallList = [];
                    clientGroups[0].attributes.activeGroups.forEach(
                       function (srtGroup, i) {
                           srtGroup.attributes.sortSecondPriorId = srtGroup.get('fmtId').substr(10, 1).replace(/\s+/g, '');
                           srtGroup.attributes.sortFirstPriorId = srtGroup.get('fmtId').substr(0, 9).replace(/\s+/g, '');
                           srtGroup.attributes.adminCode = srtGroup.get('fmtId').slice(-3).replace(/\s+/g, '');
                           srtGroup.attributes.currClient = clientid;
                       });
                    pensionGrp = clientGroups[0].attributes.activeGroups;
                    pensionGrp.forEach(
                        function (groups, i) {
                            if (groups.get('adminCode') != '002') {
                                asyncGrpMembCallList[i] = DataService.getGroupActiveMembers(groups.id);
                            }
                        });
                    Q.allSettled(asyncGrpMembCallList).then(gotoclientGroupActiveMembers);
                    function gotoclientGroupActiveMembers(groupmem) {
                        for (var a = 0; a < groupmem.length; a++) {
                            if (groupmem[a] && groupmem[a].value == undefined) {
                                pensionGrp[a].attributes.activeClients = [];
                            }
                        }

                        clientGroups[0].attributes.activeGroups = _.reject(pensionGrp, function (gp) {
                            return gp.attributes.activeClients.length == undefined && gp.attributes.adminCode != '002';
                        });
                        var sortedGroup = that.sortClientGroup(clientGroups[0], grpId)/*Sort logic*/,_pinnedClId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
                        if (_pinnedClId == clientid || _pinnedClId == null || _pinnedClId == '' || _pinnedClId == undefined) {
                            $.event.trigger({
                                type: "groupComponentReady",
                                message: { 'status': "success", "clId": clientid, "grpId": grpId }
                            });
                            that.populateGroupMembers(sortedGroup);
                        } 
                    };

                    function gotoClientGroupActiveMemError(xhr) {

                    };

                } else {
                    $.event.trigger({
                        type: "groupComponentReady",
                        message: { 'status': "nogroups", "clId": clientid, "grpId": null }
                    });
                }
            };
            function gotoclientGroupFailed(error) {
                var s = error;
            };
        },
        sortClientGroup: function (clientgroups, pingrpid) {
            if (pingrpid == undefined) {
                return _(clientgroups.get('activeGroups')).sortBy(
                    function (group) {
                        return [group.get('adminCode'), group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
                    });
            }
            else {
                var sortedGrp = _(clientgroups.get('activeGroups')).sortBy(
                function (group) {
                    return [group.get('adminCode'), group.get('sortFirstPriorId')];
                });
                var movGrp = _.filter(sortedGrp, function (grp, index) {
                    return grp.get('id') == pingrpid;
                });
                if (movGrp.length > 0) {
                    var index = sortedGrp.indexOf(movGrp[0]);
                    sortedGrp.splice(index, 1);
                    sortedGrp.splice(0, 0, movGrp[0]);
                } else {
                    return _(clientgroups.get('activeGroups')).sortBy(
                                       function (group) {
                                           return [group.get('adminCode'), group.get('sortFirstPriorId'), group.get('sortSecondPriorId')];
                                       });
                }
                return sortedGrp;
            }
        },
        renderHOCLaunchBtn: function (applytopbtmmargin) {
            // To render HOC launch button on small form factor devices.
            var applyTopBtmMargin = '';
            if (applytopbtmmargin) { applyTopBtmMargin = 'pl-margin-top-10px-btm-7px' } else { applyTopBtmMargin = 'pl-margin-top-10px' }
            if (window.location.hash.match(/#contactprofile/i) && window.location.hash.match(/#contactprofile/i).length > 0) {
                var launchHOCDiv = "<div id='insightDiv' class='hidden-md hidden-lg col-xs-3 col-sm-3'><button data-ctgCd='1' id='launchHOCBtn' type='button' class='pull-right btn btn-red btn-red-font pt-h6 "+applyTopBtmMargin+" oulineNone hidden'>insights</button></div>";
                $('#globalgrpholder div.row').append(launchHOCDiv);
                $('#hocshell').addClass('col-xs-9 col-sm-9').addClass('zero-all-padding');
                $('#sharedgrpdiv').addClass('width-100-percent');
                HOCIndicator.showCount();
            }
        },
        populateGroupMembers: function (sortedGroup) {
            var that = this;
            var groupTemplate = '';
            var drdwnHousehldGrpLbl = '';
            var tmpTemplate = _.template(ClientSearchgroup);
            var tmpHouseHoldTemplate = _.template(ClientSearchgrpshell);
            var fmtIdVal = sortedGroup[0].get('fmtId');
            var fmtGroupId = fmtIdVal.substr(fmtIdVal.length - 3);
            var activeClientsCount = 0;

            this.grpContext.set({ selectedgroup: sortedGroup[0].get('id'), triggeredevent: GroupContext.eventNames.GroupChanged }, { "silent": false });

            sortedGroup.forEach(
            function (srtGroup, i) {
                var srtGrpId = srtGroup.get('fmtId');
                var srtGrpLblId = srtGrpId.substr(srtGrpId.length - 3);

                //Household Group Label For Dropdown List
                if (srtGrpLblId == '001') {
                    drdwnHousehldGrpLbl = " &ndash; Household";
                } else if (srtGrpLblId == '002') {
                    drdwnHousehldGrpLbl = " &ndash; Pension";
                } else if (srtGrpLblId == '003') {
                    drdwnHousehldGrpLbl = " &ndash; Statement";
                }

                if (srtGroup.get('activeClients').length != undefined) {
                    activeClientsCount = parseInt(srtGroup.get('activeClients').length) + parseInt(activeClientsCount);
                }
                if (srtGroup.get('activeClients').length > 0 && srtGroup.get('activeClients')[0] != undefined) {
                    groupTemplate = groupTemplate + tmpTemplate({ group: srtGroup, grplblfordropdwn: drdwnHousehldGrpLbl });
                }
                else if (srtGroup.get('adminCode') === '002') {
                    that.pensionGrpArr.push([srtGroup.get('id'), srtGroup.get('currClient')]);
                    groupTemplate = groupTemplate + tmpHouseHoldTemplate({ group: srtGroup, grplblfordropdwn: drdwnHousehldGrpLbl });
                }
            });

            var cpdata = CPViewModel.getInstance().getData(),
                clientInfo = NavApi.getSelecetdContactdetails(this.globalContext.getGlobalContext().Context.AdvisorFMID, this.globalContext.getGlobalContext().Context.ContactId);
            var tmpUlTemplate = _.template(GroupUI);
            var htmlUlTemplate = tmpUlTemplate({
                clientInfo: clientInfo,
                groupList: groupTemplate,
                cpdata: cpdata
            });

            var finalElRenderTemplate = this.template({
                groupListTemplate: htmlUlTemplate
            });
            this.$el.html(finalElRenderTemplate);

            var userRoles = GlobalContext.getInstance().getGlobalContext().Context.Roles;

            // To render HOC launch button on small form factor devices.
            /*if (window.location.hash.match(/#contactprofile/i) && window.location.hash.match(/#contactprofile/i).length > 0) {
                var launchHOCDiv = "<div id='insightDiv' class='hidden-md hidden-lg col-xs-3 col-sm-3'><button data-ctgCd='1' id='launchHOCBtn' type='button' class='pull-right btn btn-red btn-red-font pt-h6 margin-top-10 oulineNone hidden'>insights</button></div>";
                $('#globalgrpholder div.row').append(launchHOCDiv);
                $('#hocshell').addClass('col-xs-9 col-sm-9').addClass('zero-all-padding');
                $('#sharedgrpdiv').addClass('width-100-percent');
                HOCIndicator.showCount();
            }*/
            //Render HOC launch button on small form factor devices.
            that.renderHOCLaunchBtn(false);

            $('#afinav-household-btn, #afinav-household-lbl').text(sortedGroup[0].get('fmtId'));
            if (sortedGroup[0].attributes && sortedGroup[0].attributes.adminCode && sortedGroup[0].attributes.adminCode == "002" && sortedGroup.length == 1 && !(activeClientsCount >= 1)) {
                    $("#afinav-household-lbl").removeClass('hidden');
                    $('#afinav-household-btn').addClass('hidden');
            }
            else if (activeClientsCount == 1 && sortedGroup.length == 1) {
                $("#afinav-household-lbl").removeClass('hidden');
                $('#afinav-household-btn').addClass('hidden');
            } else {
                $("#afinav-household-lbl").addClass('hidden');
                $('#afinav-household-btn').removeClass('hidden');
            }

            if (fmtGroupId == '001') {
                $('#nav-househld-grp-label').html("Household group &ndash;");
            } else if (fmtGroupId == '002') {
                $('#nav-househld-grp-label').html("Pension group &ndash;");
            } else if (fmtGroupId == '003') {
                $('#nav-househld-grp-label').html("Consolidated statement group &ndash;");
            }

            practicetech.clientContext.getCaplistFullName();
            if (Self.optionalCallback) {
                Self.optionalCallback(true);
            }

            //Pension Group Array
            if (that.pensionGrpArr.length > 0) {
                that.pensionGrpArr.forEach(function (obj, i) {
                    that.populatePensionGrpPlanTypCd(obj[0], GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID, obj[1]);
                });
            }

            drdwnHousehldGrpLbl = "";
            that.pensionGrpArr = [];
        },
        groupchangeevent: function (e) {
            e.preventDefault();
            this.localEvent = true;
            var that = this;
            if (e.currentTarget.href == "") {
                var _target = e.target || e.currentTarget;
                var contactId = $(_target).attr("id");
                if (contactId.indexOf("Contact.") > -1) {
                    ContactType = Constants.contactType.NonClient;
                } else {
                    ContactType = Constants.contactType.Client;
                }
                Analytics.analytics.recordAction("ChangeHouseholdGroupClient:clicked");
                NavApi.changeContactAndLauchCP(contactId, ContactType);
            }
            else {
                this.grpContext.set({ selectedgroup: e.currentTarget.id, triggeredevent: GroupContext.eventNames.GroupChanged }, { "silent": false });
                Analytics.analytics.recordAction("ChangeHouseholdGroup:clicked");
                this.repopulateGroupMenu(this.grpContext.get('selectedcontact'), this.grpContext.get('selectedgroup'));
            }
        },
        repopulateGroupMenu: function (selContactId, selGroupId) {
            var that = this;

            DataService.getClientgroupLocal(selContactId).then(gotoResortGroups).fail(gotoResortGroupError);
            function gotoResortGroups(clientGroups) {
                var sortedGroup = that.sortClientGroup(clientGroups.results[0], selGroupId);//Sort logic
                $.event.trigger({
                    type: "groupComponentReady",
                    message: { 'status': "success", "clId": selContactId, "grpId": selGroupId }
                });
                that.populateGroupMembers(sortedGroup);
            };

            function gotoResortGroupError(error) {
                var s = error;
            };

        },
        populatePensionGrpPlanTypCd: function (grpId, advFMId, contactId) {
            var that = this;
            DataService.getAccountView(grpId, advFMId, contactId).then(function (response) {
                if (response.length > 0 && response != "undefined") {
                    response.forEach(function (obj, j) {
                        if (obj.attributes.overviewAccount.length > 0 && obj.attributes.overviewAccount != "undefined") {
                            obj.attributes.overviewAccount.forEach(function (objAcc, k) {
                                if (objAcc.attributes.statusCd == 'ACTIVE' || objAcc.attributes.statusCd == 'INACTIVE' || objAcc.attributes.statusCd == 'PENDING') {
                                    $('#planTypCd' + grpId).text(that.getPlanTypeCode(objAcc.attributes.qualifiedPlan.attributes.planTypCd));
                                    plantypecodeval.push([grpId, that.getPlanTypeCode(objAcc.attributes.qualifiedPlan.attributes.planTypCd)]);
                                }
                            })
                        }
                    })
                }

                if (plantypecodeval.length > 0) {
                    plantypecodeval.forEach(function (typCode) {
                        $('#planTypCd' + typCode[0]).text(typCode[1]);
                    });
                }

            }).fail(function (error) {
                ErrorLog.ErrorUtils.myError(error);
            });
        },
        eventTriggered: function (eventmodel) {
            switch (eventmodel.get('triggeredevent')) {
                case GroupContext.eventNames.ContactChanged:
                    if (this.localEvent == true) {
                        if (this.grpContext.get('selectedcontact').indexOf("Contact.") >= 0) {
                            {
                                this.globalContext.setContext(this.globalContext.getGlobalContext().Context.AdvisorFMID, undefined, this.grpContext.get('selectedcontact'), Constants.contactType.NonClient, undefined, undefined); //set Client context to the global context                    
                            }
                        }
                        else {
                            this.populateClientGroup(this.grpContext.get('selectedcontact'));
                        }
                    }
                    else {
                        var _grpId = GlobalContext.getInstance().getGlobalContext().Context.GroupId ? GlobalContext.getInstance().getGlobalContext().Context.GroupId : undefined;
                        this.populateClientGroup(this.grpContext.get('selectedcontact'), groupIdFromContext);
                    }
                    this.localEvent = false;
                    break;
                case GroupContext.eventNames.GroupChanged:
                    this.globalContext.setContext(this.globalContext.getGlobalContext().Context.AdvisorFMID, undefined, this.grpContext.get('selectedcontact'), Constants.contactType.Client, undefined, this.grpContext.get('selectedgroup')); //set Client context to the global context                    
                    if (this.noCache != true) {
                        this.cacheAccountView();
                    }
                    break;
            }
        },
        cacheAccountView: function () {
            DataService.getAccountView(GlobalContext.getInstance().getGlobalContext().Context.GroupId, GlobalContext.getInstance().getGlobalContext().Context.AdvisorFMID, GlobalContext.getInstance().getGlobalContext().Context.ContactId)
                        .fail(function (error) {
                        });
        },

    });
    $(document).on("groupidfromcontext", groupifFromContext);
    function groupifFromContext(event) {
        groupIdFromContext = event.message.grpId;
    }
    var instance;
    return function (options) {
        instance = new groupuiview(options);
        return instance;
    }
});
