/**
 * @ngdoc property
 * @name Review terms and conditions Controller
 * @requires $scope
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Pull the information while calling the services.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewController($scope, fticLoggerMessage, loggerConstants, $state, transactModel, eventConstants, $filter, fundDetails, transactEvents, bankDtlsModel, toaster, authenticationService, redeemModel, fundDetailsModel, TransactConstant, $uibModal, ifscModel, fticCancelStpFundDetailsModel, $loader, $window, swpReviewDetailsFactory, appConfig, configUrlModel) {
    console.info("review Controller!!" + transactModel.getFundDetails());
    var stateUrl = $state.current.url, 
        distId,
        modalInstance,
        postBuyParams={};
    $scope.isNewInvestor = transactModel.isNewInvestor;
    $scope.isNewFolio = transactModel.getIsNewFolio();
    $scope.isPaymentGateway = true;
    $scope.advisorDetails= {};
    var postBuyParams={};
    $scope.stateUrl=$state.current.url;
    $scope.reviewAndConfirmHeading = {
        heading : 'Review & Confirm'
    };
    $scope.paymentModeBuyNewFolio = null;
    $scope.paymentModeBuyMethod = null;
    /*$scope.$on("NAVIGATE_TO_TRANSACT", function($event,value){      
      $scope.config.param = null;      
      $scope.config.param = value;  
      $scope.config.showNotification = true;
    });*/
  
    $scope.reviewTermsNconditions=function(){
      modalInstance = $uibModal.open({
                    template : require('./components/termsNconditions/termsNconditions.html'),
                    scope : $scope,
                    size: 'lg'
                });
    }
    $scope.$on('TRANSACT_INV_DETAILS', function() {
      $state.go('transact.base.redeem');
    });    
     $scope.showTermsnCond=true;
    if(stateUrl=='/cancelStp' || stateUrl=='/redeem' || stateUrl=='/swp'){
      $scope.showTermsnCond=false;
    }
    if(stateUrl == "/stp" || stateUrl == "/switch" || stateUrl == "/buy" || stateUrl == "/sip"){
      
        $scope.showAdvisorDetails =true;
        // transactModel.fetchEUINDetails().then(function (data) {
        //   transactModel.setEUINDetails(data.euins)
        //   transactEvents.transact.publishEUINDetails($scope);                
        // }, function (data) {

        // });
    }
    $scope.disableEditIcon = false;
    if(authenticationService.isInvestorLoggedIn() && stateUrl == "/buy")
    {
      $scope.showTermsnCondInv = true;
    }
    $scope.showGridFundDetails = true;
     $scope.showGridFolioDetails = true;
    if(stateUrl == "/buy" || stateUrl == "/sip" || stateUrl == "/modifySipState" || stateUrl == '/renewsip') {
        $scope.showGridFundDetails = false;
    };
    $scope.isBuyNewFolioInv = (stateUrl === "/buy" && authenticationService.isInvestorLoggedIn());
    $scope.showInvestmentPref = authenticationService.isInvestorLoggedIn() &&(stateUrl === "/switch" || stateUrl === "/dtp" || stateUrl === "/stp"  || stateUrl === "/buy"  || stateUrl === "/sip");
    
    if (transactModel.isRetryPayment) {
        if (transactModel.getRetryCount() > 3) {
            toaster.error("You have exceeded the maximum number of payment attempts. You will now be redirected to FT India homepage");
            authenticationService.backButton = true;
            $window.location.href = appConfig[configUrlModel.getEnvUrl('MARKETING_URL')];
        } else {
            $scope.disableEditIcon = true;
            toaster.error("Your transaction could not be completed. Please try again with the same/different payment mode");
        }
    }


    var proxyIntegration = function() {         
        $scope.submitURL = transactModel.getPaymentURL();        
        // transactModel.setProxyRedirectURL(redirectURL);
        //transactModel.setProxyRedirectURL("http://accounts.ftindiadev1.corp.frk.com/investor/#/invTransact/txnDetails");
        var configURL = configUrlModel.getEnvUrl('INVESTOR_URL');
        transactModel.setProxyRedirectURL(appConfig[configURL] + "/#/invTransact/txnDetails");
        transactModel.setFlowIdForProxy("transactNow");
        $scope.proxyReqObj = transactModel.getPaymentProxyReqObj();
    };

    var isGoingToPaymentGateway = function() {
        if ($scope.paymentModeBuyNewFolio === TransactConstant.common.NET_BANKING_CODE || $scope.paymentModeBuyNewFolio === TransactConstant.common.DEBIT_CARD_CODE || $scope.paymentModeBuyNewFolio === TransactConstant.common.EMANDATE_CODE) {
            if ($scope.paymentModeBuyMethod !== TransactConstant.transact.EXISTING_PAY_MANDATE) {
                return true;
            }
        }
        return false;
    };

    $scope.paymentModeBuyNewFolio = bankDtlsModel.getPaymentMode();
    $scope.paymentModeBuyMethod = bankDtlsModel.getPaymentMethod();
    if (isGoingToPaymentGateway() && !transactModel.isRetryPayment && $scope.isBuyNewFolioInv) {
        proxyIntegration();
    }

    $scope.postTransactData = function() {

      /*if(stateUrl === '/buy' && $scope.isNewFolio) {
        proxyIntegration();
      }*/

      var advisorDetailsObj = null;
      var datefilter = $filter('date');
      var today = new Date();
      $scope.requestDateAndTime = datefilter(today, 'dd MMMM yyyy, hh:mm a');
      var valid = true;
      $scope.formSubmitted = true;
      var transactionDetails = transactModel.getTransactDetails();
      
      if(transactModel.isRetryPayment) {
        $scope.$broadcast("payment_form_submit");   
        valid = false; //need to check
      } 
            //Binding Advisor details object
      // if($scope.showAdvisorDetails) 
      // {
      //     valid = false;
      //     if(advisorDetailsForm.$valid){
      //         valid = true;
      //         $scope.advisorDetails = transactModel.getAdvDetails();
      //         advisorDetailsObj = $scope.advisorDetails;
      //         transactModel.setAdvisorDetails(advisorDetailsObj);
      //         transactionDetails.advisorDetails = advisorDetailsObj;
      //     } 
      // }

      if(valid){
        var body = {};
        var params = {};
        if($state.current.url === '/switch'){
          transactionDetails.subBrokerCode = $scope.advisorDetails.subBrokerCode;
          transactionDetails.subBrokerArn = $scope.advisorDetails.subBrokerArn;
          transactionDetails.euin = $scope.advisorDetails.euin;
          transactionDetails.type = "switch";
          body.folioId = transactionDetails.investorDetails.folioId;
          body.units = transactionDetails.switchDetails.units ? transactionDetails.switchDetails.units : '';
          body.amount = transactModel.getTransactDetails().switchDetails.amount ? transactModel.getTransactDetails().switchDetails.amount.toString() : '';
          body.accountNo = transactionDetails.fundDetails.tschvalAccno;
          body.txnType = "S";
          body.fundOption = transactionDetails.fundDetails.tschvalAccno.substring(0,3);
          if(transactionDetails.switchDetails.destinationFund.accNo){
              body.toAccount = transactionDetails.switchDetails.destinationFund.accNo;
          }else{
              body.toAccount = 'NEW';
          }
          body.toFundOption = transactionDetails.switchDetails.destinationFund.fundOption;
          body.dividendOption = transactionDetails.switchDetails.destinationFund.dividendFlag;
          body.subDist = transactionDetails.subBrokerCode || "";
          body.subBrokerARN = transactionDetails.subBrokerArn || "";
          body.euinFlag= transactionDetails.euin ? "Y" : "N";
          body.euin= transactionDetails.euin || "";
          body.amountUnitFlag = body.amount ? "A" : "U";
          if(transactModel.getTransactDetails().switchDetails.switchType === 'Full') {
              body.amountUnitFlag = "U";
              body.units = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits;
              body.amount = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[1].substring(0, 2);
          }
          else {
              body.amountUnitFlag = body.amount ? "A" : "U";
          }
          body.allUnitsFlag = transactionDetails.switchDetails.switchType === 'partial' ? "N" : "Y";
          body.webRefNo = transactModel.getWebRefNo();
          body.txnNo = transactModel.getWebRefNo();
          body.batchCode = TransactConstant.common.BATCH_CODE;
          body.source = authenticationService.getUser().userType;
          params.op = 'switch';
          transactModel.postTransactDetails(body,params).then(postSuccess, handleFailure);
        }else if($state.current.url === '/redeem'){
          params.op = 'sell';
          body.folioId = transactionDetails.investorDetails.folioId;
          body.units = transactionDetails.transactDetails.units ? transactModel.getTransactDetails().transactDetails.units : '';
          body.amount = transactionDetails.transactDetails.amount ? transactModel.getTransactDetails().transactDetails.amount : '';
          body.accountNo = transactionDetails.fundDetails.tschvalAccno;
          body.txnType = "R";
          body.txnNo = transactModel.getWebRefNo(); //check once
          body.batchCode = TransactConstant.common.BATCH_CODE;
          body.txnNo = transactModel.getWebRefNo();
          body.fundOption = transactionDetails.fundDetails.tschvalAccno.substring(0,3);
          body.paymentBankAccNo = transactionDetails.transactDetails.bank.split("-")[1].trim();
          body.paymentBankName = transactionDetails.transactDetails.bank.split("-")[0].trim();
          body.bankAccountNumber = transactionDetails.transactDetails.bank.split("-")[1].trim();
          body.bankName = transactionDetails.transactDetails.bank.split("-")[0].trim();
          body.allUnitsFlag = transactModel.getTransactDetails().transactDetails.type === 'Full' ? "Y" : "N";
          if(body.allUnitsFlag !== 'Y'){
            if(transactModel.getTransactDetails().transactDetails.type === 'Amount'){
                body.amountUnitFlag = "A";
            }else{
              body.amountUnitFlag = "U";
              body.units = transactModel.getTransactDetails().transactDetails.units;
            }
          }else{
            body.units = fundDetailsModel.getFundDetails().fundDetails[0].totalAvailableUnits;
            body.amountUnitFlag = body.amount ? "A" : "U";
          }
          body.webRefNo = transactModel.getWebRefNo();          
          body.paymentMode = redeemModel.getMode() === "Direct Credit" ? "DC" : "Q";
          body.source = authenticationService.getUser().userType;
          $loader.start();
          transactModel.postTransactDetails(body,params).then(postSuccess, handleFailure).finally(function() {
            $loader.stop();
          });
        }else if($state.current.url === '/renewsip'){
          var postBuyParams = transactModel.getSipReqParams();
          postBuyParams.webRefNo = transactModel.getWebRefNo(); //we can get this value from investor registration or validatebuy or validatesip
          postBuyParams.txnNo = transactModel.getWebRefNo();
          postBuyParams.fundOptions[0].txnType = "RNW";
          params.op = "confirmSip";
          transactModel.postTransactDetails(postBuyParams,params).then(postSuccess, handleFailure);

        }
        else if($state.current.url === '/stp'){
          params.op = 'registerStp';
          body.folioId =  transactionDetails.investorDetails.folioId;
          body.amount =  transactionDetails.stpDetails.stpAmount.amount.toString();
          if(body.amount === 'Capital Appreciation'){
              body.amount = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[1].substring(0, 2);
              body.amountUnitFlag =  "C";              
          }else{
              body.amountUnitFlag =  "A";
          }
          body.units =  "";
          body.txnSource =  'STP';
          body.txnType =  'STP';
          body.batchCode =  TransactConstant.common.BATCH_CODE;
          body.fundOption =  transactionDetails.fundDetails.tschvalAccno.substring(0,3);
          body.accountNo =  transactionDetails.fundDetails.tschvalAccno;
          var startDate = new Date(transactionDetails.stpDetails.startDate);
          var dd = startDate.getDate();
          var mm = startDate.getMonth()+1; //January is 0!
          var yyyy = startDate.getFullYear();
          if(dd<10){
            dd='0'+dd;
          } 
          if(mm<10){
            mm='0'+mm;
          } 
          var startDate = dd+'/'+mm+'/'+yyyy;
          body.startDate =  startDate;
          var endDate = new Date(transactionDetails.stpDetails.endDate);
          var dd = endDate.getDate();
          var mm = endDate.getMonth()+1; //January is 0!
          var yyyy = endDate.getFullYear();
          if(dd<10){
            dd='0'+dd;
          } 
          if(mm<10){
            mm='0'+mm;
          } 
          var endDate = dd+'/'+mm+'/'+yyyy;
          body.endDate =  endDate;
          if(transactionDetails.stpDetails.frequency === 'Weekly'){
              body.frequency =  'W';
          }else if(transactionDetails.stpDetails.frequency === 'Monthly'){
              body.frequency =  'M';
          }else if(transactionDetails.stpDetails.frequency === 'Daily'){
              body.frequency =  'D';
          }else if(transactionDetails.stpDetails.frequency === 'Quarterly'){
              body.frequency =  'Q';
          }
          //body.amountUnitFlag =  "A";
          body.investmentGoalFlag =  "";
          body.dividendOption = transactionDetails.stpDetails.destinationFund.dividendFlag;
          body.urnNo =  "";
          body.source = authenticationService.getUser().userType;
          body.umrnNo =  "";
          //body.subBrokerARN =  transactionDetails.advisorDetails.subBrokerArn;
          body.branchCode = "";
          body.toFundOption = transactionDetails.stpDetails.destinationFund.fundOption;
          if(transactionDetails.stpDetails.destinationFund.accNo){
              body.toAccount = transactionDetails.stpDetails.destinationFund.accNo;
          }else{
              body.toAccount = 'NEW';
              body.trxnType = 'NEW';
          }
          //body.euin = transactionDetails.advisorDetails.euin;
          body.dcLastX = "";
          body.dcName = "";
          //body.subDist = transactionDetails.advisorDetails.subBrokerCode;
          body.webRefNo = transactModel.getWebRefNo();
          body.txnNo = transactModel.getWebRefNo();
          body.installments = transactionDetails.stpDetails.noofInstallments;
          transactModel.postTransactDetails(body,params).then(postSuccess, handleFailure);
        } else if ($state.current.url === '/swp') {
            params.op = 'registerSwp';
            //var startDate = new Date(transactionDetails.swpDetails.startDate);
            var startDate;
            if (authenticationService.isInvestorLoggedIn()) {

                startDate = swpReviewDetailsFactory.getExactSelectedDate(transactionDetails.swpDetails.freqStartDaySelected, transactionDetails.swpDetails.startMonth, true);
            } else {
                startDate = new Date(transactionDetails.swpDetails.startDate);
            }
            var _isSLbd = startDate.toString().split('/')[0].toLowerCase() === 'lbd' ? true : false;
            if (!_isSLbd) {
                var dd = startDate.getDate();
                var mm = startDate.getMonth() + 1; //January is 0!
                var yyyy = startDate.getFullYear();
                var SWPselectedType = "";
                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }
                startDate = dd + '/' + mm + '/' + yyyy;
            }

            body.startDate = startDate;
            //var endDate = new Date(transactionDetails.swpDetails.endDate);
            var endDate;
            if (authenticationService.isInvestorLoggedIn()) {

                endDate = swpReviewDetailsFactory.getExactSelectedDate(transactionDetails.swpDetails.freqEndDaySelected, transactionDetails.swpDetails.endMonth, true);
            } else {
                endDate = new Date(transactionDetails.swpDetails.endDate);
            }
            var _isELbd = endDate.toString().split('/')[0].toLowerCase() === 'lbd' ? true : false;
            if (!_isELbd) {
                var dd = endDate.getDate();
                var mm = endDate.getMonth() + 1; //January is 0!
                var yyyy = endDate.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }
                endDate = dd + '/' + mm + '/' + yyyy;
            }
            body.endDate = endDate;
            if (transactionDetails.swpDetails.frequency === 'Weekly') {
                body.frequency = 'W';
            } else if (transactionDetails.swpDetails.frequency === 'Monthly') {
                body.frequency = 'M';
            } else if (transactionDetails.swpDetails.frequency === 'Daily') {
                body.frequency = 'D';
            } else if (transactionDetails.swpDetails.frequency === 'Quarterly') {
                body.frequency = 'Q';
            }
            body.source = authenticationService.getUser().userType;
            // body.subBrokerARN = $scope.advisorDetails.subBrokerArn;
            body.branchCode = "";
            //body.subDist =$scope.advisorDetails.subBrokerCode;
            body.folioId = transactionDetails.investorDetails.folioId;
            body.units = "";
            SWPselectedType = transactionDetails.swpDetails.selectedType.toString();
            //body.amount = transactionDetails.swpDetails.selectedType.toString() === 'fixed' ? transactionDetails.swpDetails.swpAmtValue.toString() : transactionDetails.swpDetails.selectedType.toString();
            // body.amount = transactionDetails.swpDetails.selectedType.toString();
            if (SWPselectedType === 'capital') {
                //body.amount = fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[0]+'.'+fundDetailsModel.getFundDetails().fundDetails[0].valueOfTotalAvailableUnits.split(".")[1].substring(0, 2);
                body.allUnitsFlag = 'Y';
                body.amountUnitFlag = "C";
                body.amount = "";
            } else {
                body.amount = transactionDetails.swpDetails.swpAmtValue.toString();
                body.allUnitsFlag = 'P';
                body.amountUnitFlag = "A";
            }
            if (transactionDetails.swpDetails.selectedMode === "cheque") {
                body.ifscCode = '';
                body.paymentMode = 'Q';
            } else if (transactionDetails.swpDetails.selectedMode === "direct-credit") {
                body.ifscCode = ifscModel.getIfscGridResDet().ifscCode;
                body.paymentMode = 'DC';
            }
            body.accountNo = transactionDetails.fundDetails.tschvalAccno;
            body.txnType = "SWP";
            body.txnSource = "SWP";
            body.fundOption = transactionDetails.fundDetails.tschvalAccno.substring(0, 3);
            body.webRefNo = transactModel.getWebRefNo();
            body.txnNo = transactModel.getWebRefNo();
            body.batchCode = TransactConstant.common.BATCH_CODE;
            body.investmentGoalFlag = "";
            body.urnNo = "";
            body.lbdFlag = _isELbd ? 'Y' : 'N';;
            body.installments = transactionDetails.swpDetails.noofInstallments;
            $loader.start();
            transactModel.postTransactDetails(body, params)
                .then(postSuccess, handleFailure)
                .finally(function () {
                    $loader.stop();
                });
        }
        else if($state.current.url === '/cancelStp' && authenticationService.isInvestorLoggedIn()){
            body.refTxn= transactModel.getFundDetails().trxnNo;
            //body.folioId =  "14512366";
             body.folioId =  fticCancelStpFundDetailsModel.getSelectFundDtls().folioId;
            body.accountNo =  transactModel.getFundDetails().sourceAccNo;
            body.effectiveDate = transactModel.getFundDetails().nextTiggerDate;
            body.userType =  "10";
            body.txnType =  'STPC';            
            body.batchCode = "FTIDE";
            body.webRefNo = fticCancelStpFundDetailsModel.getRefNum();
            body.makerId = "";
            body.validation = "N";
            $loader.start();
            fticCancelStpFundDetailsModel.validateCSTP(body).then(function(data){
            //fticCancelStpFundDetailsModel.setRefNum(data.Reference_Number); 
            var transConfirm = {
              "transactionRefNo" :data.webRefNo,
              "transDateTime" : $scope.requestDateAndTime
            };  
            fticCancelStpFundDetailsModel.setTransactConfirm(transConfirm);                                            
            //fticCancelStpFundDetailsModel.setCstpDetails(data);
             console.log("transConfdata");
            console.log(data);
           $state.go('invTransact.txnDetails',{
          stateType: $state.current.url.toString().substring(1, $state.current.url.toString().length)
            });
          },function(error){
                toaster.error(error.data[0].errorDescription);
            })
             .finally(function() {
            $loader.stop();
          });

          }

        else if($state.current.url === '/dtp'){
          // var deferred = $q.defer();
            var params = {};
            var body = {};
            body.folioId = transactModel.getTransactDetails().investorDetails.folioId || "";
            body.accountNo = transactModel.getTransactDetails().fundDetails.tschvalAccno || "";
            body.webRefNo = transactModel.getWebRefNo();
            body.txnType = "DTP";
            body.fundOption = transactModel.getTransactDetails().fundDetails.tschvalAccno.substring(0,3);
            if(transactModel.getTransactDetails().switchDetails.destinationFund.accNo){
                body.toAccount = transactModel.getTransactDetails().switchDetails.destinationFund.accNo;
            }else{
                body.toAccount = 'NEW';
            }
            body.toFundOption = transactModel.getTransactDetails().switchDetails.destinationFund.fundOption || "";
            
            if(transactModel.getTransactDetails().switchDetails.destinationFund.fundOptDesc.indexOf('Taxshield') !== -1){
                body.dividendOption = transactModel.getTransactDetails().fundDetails.dividendType.substring(0,1);
            }else if(transactModel.getTransactDetails().switchDetails.destinationFund.fundOptDesc.indexOf('Growth') !== -1){
                body.dividendOption = transactModel.getTransactDetails().switchDetails.destinationFund.dividendFlag;
            }else{
                body.dividendOption = transactModel.getTransactDetails().fundDetails.dividendType.substring(0,1);
            }
            //body.dividendOption = transactModel.getTransactDetails().fundDetails.dividendType;
  
            body.distId = transactionDetails.ArnCode || "" 
            body.subBrokerARN = transactionDetails.subBrokerArn || "";
            body.euinFlag= transactionDetails.euin ? "Y" : "N";
            body.euin= transactionDetails.euin || "";
            
           /* body.subDist = transactionDetails.subBrokerCode || "";*/
            /*body.distId = "0000000000";
            body.subBrokerARN = "";
            body.euin = "";
            body.euinFlag = "N";*/
            body.userType = "10";
            body.markerId = "",
            body.validation = "N"
            params.guId = authenticationService.getUser().guId;
            console.log("Body payload for DTP Transaction details"+body);
            transactModel.postDtpTransactDetails(body,params).then(postSuccess, handleFailure);
        }else{
          var transactType = transactModel.getTransactType();       
          if(transactType === TransactConstant.sip.FUNDSIP || transactType === TransactConstant.sip.SIP){
              postBuyParams = transactModel.getSipReqParams();
              postBuyParams.webRefNo = transactModel.getWebRefNo(); //we can get this value from investor registration or validatebuy or validatesip
              postBuyParams.txnNo = transactModel.getWebRefNo();            
              bankDtlsModel.postSysBuy(postBuyParams)
              .then(postSuccess, handleFailure);
          }else if(transactType === TransactConstant.buy.BUYFUND || transactType === TransactConstant.buy.BUY){
              postBuyParams = transactModel.getBuyReqParams();
              postBuyParams.webRefNo = transactModel.getWebRefNo(); //we can get this value from investor registration or validatebuy or validatesip
              postBuyParams.txnNo = transactModel.getWebRefNo();     
              postBuyParams.subBrokerCode = $scope.advisorDetails.subBrokerCode;
              postBuyParams.euin = $scope.advisorDetails.euin;
              bankDtlsModel.postBuyDtls(postBuyParams)
              .then(postSuccess, handleFailure);
          }
        }
      }
      function postSuccess(data) {
        var transConfirm = {
          "transactionRefNo" : transactModel.getWebRefNo(),
          "transDateTime" : $scope.requestDateAndTime
        };
        /*var data = {
               ValidateDtp: {
              'Date': '2016-10-25',
              'folioId': '18556824',
              'webRefNo': 'DTP000693'
          }
        };*/
        transactModel.setTransactConfirm(transConfirm);
        transactModel.isTransactionStarted = false;

        // var paymentMode = $scope.paymentModeBuyNewFolio; //paymentMode !== TransactConstant.transact.EXISTING_PAY_MANDATE &&
        var isPaymentRedirection = ( $scope.isBuyNewFolioInv && isGoingToPaymentGateway() ? true : false);
        if (isPaymentRedirection) {
            // fticBroadcast.fticLoader($scope, {"msg" : $scope.paymentLoadingMessage, "loaderFlag" : true});
            document.getElementById("prxoyForm").submit();
        } else if(stateUrl == "/renewsip"){
          $state.go('invTransact.txnDetails',{stateType: $state.current.url.toString().substring(1, $state.current.url.toString().length)});
        }else {
            // fticBroadcast.fticLoader($scope, {"msg" : $scope.paymentLoadingMessage, "loaderFlag" : false});
            $state.go($scope.config.toTxnDetailsState, {
                stateType: $state.current.url.toString().substring(1, $state.current.url.toString().length)
            });
        }
      }
      function handleFailure(data) {
        toaster.error(data.data[0].errorDescription);
        /*var transConfirm = {
          "transactionRefNo" : "FUL17007",
          "transDateTime" : $scope.requestDateAndTime

        };*/
        // transactModel.setTransactConfirm(transConfirm);
        console.log('error');
      }

    };
}

reviewController.$inject = ['$scope', 'fticLoggerMessage', 'loggerConstants', '$state', 'transactModel', 'eventConstants', '$filter', 'fundDetails', 'transactEvents', 'bankDtlsModel', 'toaster', 'authenticationService', 'redeemModel', 'fundDetailsModel', 'TransactConstant','$uibModal', 'ifscModel', 'fticCancelStpFundDetailsModel', '$loader', '$window', 'swpReviewDetailsFactory', 'appConfig', 'configUrlModel'];
module.exports = reviewController;