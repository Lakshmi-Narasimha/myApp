import { ElementRef } from '@angular/core';
export interface DropdownMenuInterface {
    el: ElementRef;
    templateUrl: string;
}
export interface DropdownToggleInterface {
    el: ElementRef;
}
