/**
 * @ngdoc property
 * @name fticreportDatePicker Directive
 * @description
 *
 * - Composite filter enables the input field according to type selection. UI Bootstrap datepicker integrated.
 *
 **/
'use strict';
var reportDatePicker = function ($window, toaster) {
    return {
        restrict: 'EA',
        replace: true,
        template: require('./reportDatePicker.html'),
        scope: {
            reportOptions: "=",
            disableFuture: '=?',
            onlyMonday: '=?'
        },
        link: function (scope) {
            /* DatePicker Code */
            scope.datePickerObject = {};
            scope.today = function () {
                scope.dt = new Date();
                scope.fdt = new Date();
                scope.dtr1 = new Date();
                scope.dtr1.setDate(scope.dtr1.getDate() - 1);
                scope.dtr2 = new Date();
                scope.dtrmonth1 = new Date();
                scope.dtrmonth2 = new Date();
                scope.initDate();
            };
            
            scope.clear = function () {
                scope.dt = null;
            };
            scope.inlineOptions = {
                customClass: getDayClass,
                minDate: new Date(),
                showWeeks: false
            };
            var maxDate = new Date();
            var yyyy = maxDate.getFullYear();
            var mm = maxDate.getMonth() - 12;
            var dd = maxDate.getDayInYear();
            scope.dateOptions = {
                yearRows: 4,
                yearColumns: 3,
                datepickerMode: 'month',
                fulldatepickerMode: 'year',
                minMode: 'month',
                dateDisabled: disabled,
                formatMonth: 'MMM',
                formatYear: 'yyyy',
                maxDate: maxDate,
                minDate: new Date(yyyy, mm, dd),
                startingDay: 1,
                showWeeks: false
                //yearRange: 20
            };
            scope.dateOptionsDisableWeek = {
                yearRows: 4,
                yearColumns: 3,
                dateDisabled: weekDisabled,
                fulldatepickerMode: 'year',
                datepickerMode: 'day',
                formatYear: 'yyyy',
                formatMonth: 'MMM',
                maxDate: maxDate,
                minDate: new Date(yyyy, mm, dd),
                startingDay: 1,
                showWeeks: false
            };
            // Disable weekend selection
            function disabled(data) {
                var date = data.date,
                    mode = data.mode;
                return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6 );
            }
            function weekDisabled(data) {

                var date = data.date,
                    mode = data.mode;
                    if(scope.onlyMonday){
                        return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6 || date.getDay() === 2 || date.getDay() === 3 || date.getDay() === 4 || date.getDay() === 5);
                    }else{
                        return false;
                    }
                
            }
            // scope.toggleMin = function() {
            //     scope.inlineOptions.minDate = scope.inlineOptions.minDate ? null : new Date();
            //     scope.dateOptions.minDate = scope.inlineOptions.minDate;
            // };
            // scope.toggleMin();
            scope.open1 = function () {
                scope.popup1.opened = true;
            };
            scope.open2 = function () {
                scope.popup2.opened = true;
            };
            scope.setDate = function (year, month, day) {
                scope.dt = new Date(year, month, day);
            };
            scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
            scope.format = scope.formats[0];
            scope.altInputFormats = ['M!/d!/yyyy'];
            scope.popup1 = {
                opened: false
            };
            scope.popup2 = {
                opened: false
            };
            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            var afterTomorrow = new Date();
            afterTomorrow.setDate(tomorrow.getDate() + 1);
            scope.events = [{
                date: tomorrow,
                status: 'full'
            }, {
                date: afterTomorrow,
                status: 'partially'
            }];

            function getDayClass(data) {
                var date = data.date,
                    mode = data.mode;
                if (mode === 'day') {
                    var dayToCheck = new Date(date).setHours(0, 0, 0, 0);
                    for (var i = 0; i < scope.events.length; i++) {
                        var currentDay = new Date(scope.events[i].date).setHours(0, 0, 0, 0);
                        if (dayToCheck === currentDay) {
                            return scope.events[i].status;
                        }
                    }
                }
                return '';
            }
            /* DatePicker Ends */
            /*Second Select Change events*/
            scope.inputChange = function (inputVal, inputType, reportOptions) {
                scope.rangeError = false;
                scope.popup2.opened = false;
                scope.popup1.opened = false;
                scope.datePickerObject.reportId = reportOptions.reportId;
                switch(inputType){
                    case 'dt':
                        scope.dt = inputVal;
                        scope.datePickerObject.fromDate = scope.dt;
                        scope.datePickerObject.toDate = scope.dt;
                        break;
                    case 'fdt':
                        scope.fdt = inputVal;
                        scope.datePickerObject.fromDate = scope.fdt;
                        scope.datePickerObject.toDate = scope.fdt;
                        break;
                    case 'dtr1':
                        scope.dtr1 = inputVal;
                        scope.datePickerObject.fromDate = scope.dtr1;
                        break;
                    case 'dtr2':
                        scope.dtr2 = inputVal;
                        scope.datePickerObject.toDate = scope.dtr2;
                        break;
                    case 'dtrm1':
                        scope.dtrmonth1 = inputVal;
                        scope.datePickerObject.fromDate = scope.dtrmonth1;
                        break;
                    case 'dtrm2':
                        scope.dtrmonth2 = inputVal;
                        scope.datePickerObject.toDate = scope.dtrmonth2;
                        break;

                }
                scope.$emit('fticReportDatePicker', scope.datePickerObject);
                console.log(scope.datePickerObject);
            };
            scope.initDate = function(){
                var period = scope.reportOptions.template.period;
                scope.datePickerObject.reportId = scope.reportOptions.reportId;
                switch(period){
                    case 'Date' :
                        scope.datePickerObject.fromDate = scope.fdt;
                        scope.datePickerObject.toDate = scope.fdt;
                        break;
                    case 'DateRange' :
                        scope.datePickerObject.fromDate = scope.dtr1;
                        scope.datePickerObject.toDate = scope.dtr2;
                        break;
                    case 'Month' :
                        scope.datePickerObject.fromDate = scope.dt;
                        scope.datePickerObject.toDate = scope.dt;
                        break;
                    case 'MonthRange' : 
                        scope.datePickerObject.fromDate = scope.dtrmonth1;
                        scope.datePickerObject.toDate = scope.dtrmonth2;
                        break;
                }
                scope.$emit('fticReportDatePicker', scope.datePickerObject);
            };
            scope.today();
            if (scope.hideSelect) {
                scope.hideSelectOption = false;
                scope.selected = scope.filterOptions[0];
                if (scope.selectedObj != null) {
                    scope.selected = scope.filterOptions[scope.selectedObj.sysFilter.filterOptionIndex];
                    scope.changed();
                } else {
                    scope.changed();
                }
            } else {
                scope.hideSelectOption = true;
            }
        }
    }
}
reportDatePicker.$inject = ["$window", "toaster"];
module.exports = reportDatePicker;