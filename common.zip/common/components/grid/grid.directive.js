'use strict';

var fticGrid = function($timeout) {
    return {
            template: require('./grid.html'),
            restrict: 'E',
            replace: true,
            scope: {
                gridData: '=',
                gridColumnDef: '=',
                gridOptionsHTemplate : '=',
                paginationEnable: '=?',
                recordsPerPage: '=?',
                gridOptions: '=?'
            },
            controller:['$scope', function($scope){
                 $scope.range = function(n) {
                     return new Array(n);
                };
            }],
            link: function(scope){
                scope.$on('gridPageChange', function(event, page){
                    scope.gridApi2.pagination.seek(page);
                });

                scope.goToNextPage = function(){
                    scope.currentPageNo ++;
                    
                    if(scope.currentPageNo -1 === scope.currentPageRange[4]+1){
                        scope.currentPageRange =  scope.totalPages.slice(scope.currentPageNo-1,scope.currentPageNo+4);
                        scope.gridApi2.pagination.seek(scope.currentPageNo);
                    }else{
                        scope.gridApi2.pagination.nextPage();
                    }
                }
                scope.gotoPreviousPage = function(){
                    scope.currentPageNo --;
                    if(scope.currentPageNo +1 === scope.currentPageRange[0]+1){
                        scope.currentPageRange =  scope.totalPages.slice(scope.currentPageNo-5,scope.currentPageNo);
                        scope.gridApi2.pagination.seek(scope.currentPageNo);
                    }else{
                        scope.gridApi2.pagination.previousPage();
                    }
                }
                scope.clilckOnPageNo = function(currentPageNo){
                    scope.currentPageNo = currentPageNo;
                    scope.gridApi2.pagination.seek(currentPageNo);
                }
                scope.setCurrentPagenationRange =function(start,end){
                    scope.currentPageRange = scope.totalPages.slice(start,end);
                }
                scope.loadPageNation = function(param){
                    scope.totalPages = [];
                    for(var i=0; i<param; i++){
                        scope.totalPages[i] = i;
                    }
                    scope.totalPagesLength = scope.totalPages.length;
                    scope.currentPageNo = 1;
                    scope.setCurrentPagenationRange(0,5);
                }

                if(scope.gridOptionsHTemplate !== undefined || scope.gridOptionsHTemplate) {
                    scope.gridOptions = scope.gridOptionsHTemplate;
                }
                else{
                    scope.gridOptions = scope.gridOptions || {};
                    scope.gridOptions = angular.merge({
                        enableSorting: false,
                        enableColumnMenus: false,
                        enableHorizontalScrollbar: 5,
                        enableVerticalScrollbar: 0,
                        virtualizationThreshold: (scope.gridData ? scope.gridData.length : 20)
                        // showColumnFooter: true
                    }, scope.gridOptions);
                }
                if(scope.paginationEnable){
                    scope.gridOptions.onRegisterApi = function (gridApi) {
                        scope.gridApi2 = gridApi;
                    };
                    // scope.gridOptions.paginationPageSizes = [25, 50, 75];

                    if(scope.gridData.length <10){
                        scope.isLessThenTen = scope.gridData.length;
                        scope.gridOptions.paginationPageSize = scope.gridData.length;
                    }else{
                        scope.isLessThenTen = scope.recordsPerPage;
                        scope.gridOptions.paginationPageSize = scope.recordsPerPage;
                    }
                    
                    
                    var pagingLenth = Math.ceil(scope.gridData.length/scope.recordsPerPage);
                    scope.loadPageNation(pagingLenth);
                }
                scope.gridOptions.enablePaginationControls = false;
                scope.gridOptions.data = scope.gridData;
                scope.gridOptions.columnDefs = scope.gridColumnDef;
                
                
            }
        };
};

fticGrid.$inject = ['$timeout'];
module.exports = fticGrid;
