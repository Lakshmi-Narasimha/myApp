// getUnitHolderDetails.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var UnitHolderSchema = new mongoose.Schema({
    UnitHolderObject: {
        type: Array,
        "default": []
    }
});

var UnitHolderLookUp = mongoose.model('UnitHolderLookup', UnitHolderSchema);

var UnitHolderModel = new UnitHolderLookUp({
	"UnitHolderObject" : [{
		"unitHolderName" : "Shankar",
		"pan" : "ABCD1234E",
		"folioNo" : "4563152",
		"modeOfHolding" : "Joint",
		"mobile" : "9999999999",
		"email" : "Shankar@abc.com",
		"city" : "Hyderabad"
	}]
});

UnitHolderLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating UnitHolderLookUp table, please contact admin...');
    } else {
        UnitHolderLookUp.remove({}, function(err) {
            console.log('UnitHolderLookUp collection removed');
            UnitHolderModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating UnitHolderLookUp table, please contact admin...');
                }
                console.log('UnitHolderLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = UnitHolderLookUp;
