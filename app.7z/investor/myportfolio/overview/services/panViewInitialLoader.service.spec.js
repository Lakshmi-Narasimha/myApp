'use strict';
describe('Services: pan view initial loader service', function() {

    var mockPanViewInitLoader, panViewModelData, httpBackend, Restangular, $window;
    var panDetails = {
             "investmentSummary":[{  
                   "grandTotal":{  
                      "currentCost":"82498.74",
                      "currentValue":"122163.91",
                      "account":"GRAND TOTAL",
                      "folioId":null,
                      "totalUnits":"285.758"
                   },
                   "holders":[  
                      {  
                         "type":"Firstholder",
                         "balAmount":null,
                         "aadharNo":null,
                         "modeOfKyc":null,
                         "kycSource":null,
                         "kycStatus":"KYC - Registered",
                         "pan":"CNJQL2964N",
                         "name":"YASMIN POLLY PATEL ALWYN MARTIS PREMISES LEASING PRIVATE LIMITED"
                      }
                   ],
                   "modeofHolding":"Single",
                   "rows":[  
                      {  
                         "goal":null,
                         "returns":"20.46%",
                         "currentValue":"92755.57",
                         "currentCost":"59998.89",
                         "totalUnits":"219.347",
                         "scheme":"Franklin India Taxshield - Growth",
                         "accountNo":"1349904865101"
                      }
                   ],
                   "folioId":"17877097"
             }],
             "portfolioDetails":{  
                "grandTotal":{  
                   "currentCost":"82498.74",
                   "currentValue":"122163.91",
                   "account":null,
                   "folioId":"GRAND TOTAL",
                   "totalUnits":null
                },
                "rows":[  
                   {  
                      "returns":"25%",
                      "accessLevel":"View",
                      "currentValue":"122163.91",
                      "currentCost":"82498.74",
                      "holidingType":"Single",
                      "folioId":"17877097"
                   }
                ]
             }
          };
    var accountFilter = {
            flag: 'P',
            guId: '878'
        }

    beforeEach(angular.mock.module('investor'));

    beforeEach(inject(function(_panViewInitialLoader_, _panViewModel_, $injector, _$httpBackend_, _Restangular_) {
        mockPanViewInitLoader = _panViewInitialLoader_;
        panViewModelData = _panViewModel_;
        var $q = $injector.get('$q');
        httpBackend = _$httpBackend_;
        Restangular = _Restangular_;
    }));

    it('should loadAllServices to be defined', function() {
        expect(mockPanViewInitLoader.loadAllServices).toBeDefined();
    });

    describe('Services: pan view initial loader service and check for success', function() {

        beforeEach(inject(function(_panViewInitialLoader_, _panViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
            mockPanViewInitLoader = _panViewInitialLoader_;
            panViewModelData = _panViewModel_;
            var $q = $injector.get('$q');
            httpBackend = _$httpBackend_;
            Restangular = _Restangular_;

            httpBackend.whenGET('http://localhost:3030/clients/clientStatement?guId=878').respond(panDetails);
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should loadAllServices to be defined and load Service getPanViewDtls to be success', function() {
            mockPanViewInitLoader.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            }, {});
            httpBackend.flush();
            expect(panViewModelData.getPanViewDtls().investmentSummary[0].folioId).toEqual('17877097');
        });
    });

    describe('Services: pan view initial loader service and check for failure', function() {
      
        beforeEach(inject(function(_panViewInitialLoader_, _panViewModel_, $injector, _$httpBackend_, _Restangular_, _$window_) {
            mockPanViewInitLoader = _panViewInitialLoader_;
            panViewModelData = _panViewModel_;
            var $q = $injector.get('$q');
            httpBackend = _$httpBackend_;
            Restangular = _Restangular_; 

            httpBackend.expectGET('http://localhost:3030/clients/clientStatement?guId=878').respond(panDetails);
            $window = _$window_;
            $window.ga = function() {};

        }));

        it('should loadAllServices to be defined and expect error Services', function() {
            mockPanViewInitLoader.loadAllServices({
                '$broadcast': function() {
                    return true;
                }
            }, {});
            expect(mockPanViewInitLoader._isServicesData).toEqual(false);
        });
    });

});
