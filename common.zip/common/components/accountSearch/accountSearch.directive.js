/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var accountSearch = function($state, eventConstants, accountStatementModel, $cookies, constants, validateUserModel, toaster, $timeout) {
	return {
            template: require('./accountSearch.html'),
            restrict: 'E',
            replace: true,
            transclude: true,
            scope: {
              searchOptions: "="
            },
            controller:['$scope', function($scope){
				      var statusTemplate = '<input type="checkbox" id="abc" ng-click="grid.appScope.$emit(\'showCheckSelect\', row.entity.folioId)" ng-if="row.entity.selected == false"/><input type="checkbox" id="abc" ng-click="grid.appScope.$emit(\'showCheckSelect\', row.entity.folioId)" ng-if="row.entity.selected == true" checked/>';
               $scope.noSearchData = false;
               $scope.isValidKeyFormat = true;
               var keywordPattern;
               $scope.gridOptions = {};
               $scope.gridOptions.enableRowSelection= true,
    			     $scope.gridOptions.enableSelectAll= true,
               $scope.gridOptions.multiSelect = true;
               $scope.arguments = {};
               $scope.table = [];
               var pageRange = {},
                    pageOffset = 1,
                    limit = 5,
                    previousPage = 0
                    ;
                    pageRange.limit = 5;
                    pageRange.offset = 1;
               $scope.paginationObject = {
                    currentPage : 1
                }
                $scope.pageChanged = function() {
                  
                    $scope.showSearchResult = false;
                    if($scope.paginationObject.currentPage === 1){
                        pageRange.offset = 1;
                    }else{
                        pageRange.offset = (pageRange.limit * ($scope.paginationObject.currentPage-1)) + 1;
                    }                    
                    //init(); 
                    $scope.searchResultWithPagelimit($scope.arguments);                   
                }; 
              $scope.gridOptions.columnDefs = [
                { field: 'checkBox',displayName:'', width:"60", cellTemplate:statusTemplate , enableSorting:false, pinnedLeft:true},
                { field: 'custName', displayName: 'Name', width:"180", enableSorting:false, pinnedLeft:true},                        
                { field: 'folioId', displayName: 'Folio Number', width:"110", enableSorting:false},
                { field: 'emailId', displayName: 'Email ID', width:"214",  enableSorting:false},
                { field: 'mobile', displayName: 'Mobile Number', width:"140", enableSorting:false},
                { field: 'pan', displayName: 'PAN Number', width:"200", enableSorting:false},
              ];
              $scope.$on('updatedTableFromParent', function(event, args){
              $scope.table = args;
               if($scope.table.length>0){
                for (var k = 0; k <$scope.table.length; k++) {
                      for (var i = 0; i <$scope.table[k].cols.length; i++) {
                              for(var j=0;j<$scope.searchResult.length;j++){
                                      if($scope.table[k].cols[i]){
                                          if(($scope.table[k].cols[i].folioNo == $scope.searchResult[j].folioId) && $scope.table[k].cols[i].selected == true){
                                            $scope.searchResult[j].selected = true;
                                            break;
                                          }
                                    }
                              }
                      }
            }
            }
            });
              $scope.$on('tableUpdatedFromParent', function(event, args){
                for (var i = 0; i <$scope.searchResult.length; i++) {
                 if($scope.searchResult[i].folioId == args){
                  $scope.searchResult[i].selected = false;
                  $scope.searchResultWithPagelimit($scope.arguments);
                  break;
                 }
                }
              });
              $scope.$on('resetFromParent', function(event, args){
                $scope.searchResultWithPagelimit($scope.arguments); 
              });
              $scope.$on('showCheckSelect', function(data) {
                  console.log(data);
              });
               $scope.searchResultWithPagelimit = function(args,abc){
                $scope.isValidKeyFormat = true;
                  keywordPattern = "";
                  $scope.searchQuery = {};
                  $scope.showSearchResult = false;
                  $scope.$emit('showSearchResultForFolio',$scope.showSearchResult);
                  switch(args.searchOption) {
                      case constants.accountStatements.ACC_NO:
                            $scope.searchQuery.searchType = "A";
                            keywordPattern = /(^\d{1,13}$)/;
                            break;
                      case constants.accountStatements.EMAIL:
                            $scope.searchQuery.searchType = "E";
                            keywordPattern = /(^[a-zA-Z0-9._]+[a-zA-Z0-9._]+@[a-zA-Z]+\.[a-zA-Z.]{2,5}$)/;
                            break;
                      case constants.accountStatements.FOLIO_NO:
                            $scope.searchQuery.searchType = "F";
                            keywordPattern = /(^\d{8}$)/;
                            break; 
                      case constants.accountStatements.MOBILE:
                            $scope.searchQuery.searchType = "M";
                            keywordPattern = /(^\d{10}$)/;
                            break;
                      case constants.accountStatements.PAN:
                            $scope.searchQuery.searchType = "P";
                            keywordPattern = /(^([a-zA-Z]{5})(\d{4})([a-zA-Z]{1})$)/;
                            break;
                  }
                  //if Keyword format is valid 
                  if(keywordPattern.test(args.searchText)){
                    $scope.searchQuery.searchValue = args.searchText;  
                    // $cookies.put('accessToken', 'jKagxFdbrfXMJVytrLCaloUta7WK');
                    $scope.searchQuery.active = "N";
                    $scope.searchQuery.distId = validateUserModel.getUserDetails().arnCode;
                    $scope.searchQuery.emailId = validateUserModel.getUserDetails().emailId;
                    $scope.searchQuery.userType = validateUserModel.getUserType();
                    if($scope.bySearchClick){
                      $scope.searchQuery.offset = 1;
                      $scope.paginationObject.currentPage = 1;
                    }
                    else{
                      $scope.searchQuery.offset = pageRange.offset;
                    }
                    $scope.bySearchClick = false;
                    
                    $scope.searchQuery.limit = pageRange.limit;
                    accountStatementModel.fetchAccountStatement($scope.searchQuery).then (function (data) {
                      $timeout(function(){
                        $scope.noSearchData = false;
                        $scope.searchResult=data;
                        angular.forEach($scope.searchResult,function(obj){
                          obj.selected = false;
                        });
                        // console.log("hello santhosh...",JSON.stringify(data));
                        $scope.showSearchResult = true;
                        $scope.$emit('showSearchResultForFolio',$scope.showSearchResult);
                      });
                      $scope.paginationObject.totalItems = Math.ceil(data[0].recordCount/pageRange.limit) || 1;
                      $scope.paginationObject.count = data[0].recordCount;
                    }, function (data) {
                        var errortext = '';
                        switch(args.searchOption) {
                          case constants.accountStatements.ACC_NO:
                                errortext = "Account number";
                                break;
                          case constants.accountStatements.EMAIL:
                                errortext = "Email ID";
                                break;
                          case constants.accountStatements.FOLIO_NO:
                                errortext = "Folio number";
                                break; 
                          case constants.accountStatements.MOBILE:
                                errortext = "Phone number";
                                break;
                          case constants.accountStatements.PAN:
                                errortext = "PAN number";
                                break;
                        }
                        $scope.noSearchData = true;
                        $scope.searchResult = [];
                        if($scope.searchResult.length === 0) {
                          $scope.showSearchResult = true;
                        }
                        if(data.errorCode === 400){
                          $scope.noSearchData = true;
                        }
                    });
                  }else{
                    $scope.isValidKeyFormat = false;
                  }
               }
                $scope.$on(eventConstants.SHOW_SEARCH_RESULT, function (event, args) {  
                   $scope.bySearchClick = true;
                  $scope.searchResultWithPagelimit(args);
                  $scope.arguments = args;
                  $scope.$emit('onSearchClick',$scope.showSearchResult);

                }); 

                $scope.$on(eventConstants.HIDE_SEARCH_RESULT, function (event, args) {                 
                  $scope.showSearchResult = false;
                });

                $scope.$on(eventConstants.CHANNEL_AUTO_SEARCH_OPTION_CHANGED, function (event, args) {                  
                  $scope.showSearchResult = false;
                  $scope.$emit('showSearchResultForFolio',$scope.showSearchResult);
                });
                

            }]
        };
};

accountSearch.$inject = ['$state','eventConstants', 'accountStatementModel', '$cookies', 'constants', 'validateUserModel', 'toaster', '$timeout'];
module.exports = accountSearch;