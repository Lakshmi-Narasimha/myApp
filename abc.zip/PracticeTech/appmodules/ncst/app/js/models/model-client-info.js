define(
		[ 'jquery', 'underscore', 'backbone','backboneRelational','appmodules/ncst/app/js/lib/validate-4.2','appmodules/ncst/app/js/models/model-new-client' ],
		function($, _, Backbone,backboneRelational, Validator,newClientModel) {
			var self = null;
			var modelClientInfo = Backbone.RelationalModel
					.extend({
						defaults : {
							advisorNumber : '',
                            prosId : null,
                            prosCtx : null,
							clientType : "P",
							clientRole : "",
							entityRole: "",
							entityRoleCode: "",
							industryClassifyCd: "",
							industryClassifyType: "",
							industryFreeFormText: "",
							addressType : "",
							number : 'number',
							text : "text",
							clientSex:null,
							firstName : '',
							middleName : '',
							lastName : '',
							suffix : '',
							honorific : '',
							ssn1 : '',
							ssn2 : '',
							ssn3 : '',
							fullName:'',
							entityName : '',
							uEntityName : '',
							ein1 : '',
							ein2 : '',
							citizenshipType : '',
							validEntityName : false,
							validClient : false,
							ssnChanged: false,
							clientAssociated: '',
							isThisOperatingEntity: '',
							frgnOrgCheck: '',
							stOfIncorpCode:'',
							clientassocName: '',
							clientassocId: '',
							clientassocReltn: '',
							clientNames: [],
							groupClients: [],
						    advisorNm:""
						},
						initialize:function(){
						    self = this;
						    //self.set('clientAssociated', "yes");

						    //self.set('clientType', "P");
						},
						clearClientAssociation: function () {
						    self.set('clientAssociated', '');
						    self.set('clientassocName', '');
						    self.set('clientassocReltn', '');
						    self.set('clientassocId', '');
						},
						validate : function(validateRequired) {
							var _proceed = true;
							if (!Validator.validateInputs('client-info-view',
									validateRequired)) {
								_proceed = false;
								self.set('clientInfoValid', false);
							} else {
								self.set('clientInfoValid', true);
							}
							if (_proceed) {
								this.setModel();
							}
							return _proceed;
						},
						setModel: function () {
						    var _clientInfoForm = $('#client-info-view');
						    var clientType = _clientInfoForm.find('input[name="clientType"]:checked').val();
							self.set('ssnChanged', false);
							var _prevSSN = "";
							var revocableFlag;
							var _clientInfoForm = $('#client-info');
							var _clientType = _clientInfoForm.find('input[name="clientType"]:checked').val();
							var $ciSecondCitizenshipCountry = $("#ci-second-citizenship-country");

							if (_clientType == "P") {
							    _prevSSN = self.get('ssn1') + self.get('ssn2') + self.get('ssn3');
							}else{
								_prevSSN = self.get('ein1')+self.get('ein2');
							}
							self.set('clientType', _clientType);
							self.set('clientRole', _clientInfoForm.find('input[name="clientRole"]:checked').val());
							self.set('honorific', $('#ci-client-honorific').val());
							self.set('firstName', $.trim($('#ci-first-name').val()));
							self.set('middleName', $.trim($('#ci-middle-name').val()));
							self.set('lastName', $.trim($('#ci-last-name').val()));
							self.set('suffix', $('#ci-client-suffix').val());
							self.set('ssn1', $('#ci-ssn-1').val());
							self.set('ssn2', $('#ci-ssn-2').val());
							self.set('ssn3', $('#ci-ssn-3').val());
							// self.set('revocableFlag',0);
							// for
							// setting
							// completed
							// status
							// in
							// navigation
							// menu
							// set the name for addressEntryModel
							var _fullName = (function() {
								var _honorific = self.get('honorific');
								var _middleName = self.get('middleName');
								// var _suffix = self.get('suffix');
								var _name = "";
								// _name += _honorific ? _honorific + ' ' : '';
								_name += self.get('firstName') + ' ';
								_name += _middleName ? _middleName + ' ' : '';
								_name += self.get('lastName');
								// _name += _suffix ? ' ' + _suffix : '';
								return _name;
							})();
							var _suffix = self.get('suffix');
							var _entityName = $.trim($('#ci-entity-name').val());
							var _industryCd = $('#pt-select-industry :selected').val();
							var _industryType = $('#pt-select-industry :selected').text();
							var _industryInputval = $('#pt-industry-other-input').val();
							// set entity name
							self.set('fullName', _fullName);
							// entity fields
							self.set('entityName', _entityName);
							self.set('uEntityName', _entityName);
							self.set('industryClassifyCd', _industryCd);
							self.set('industryClassifyType', _industryType);
							self.set('industryFreeFormText', (_industryType == "Other") ? _industryInputval: "");
							self.set('entityRole', $('#ci-entity-role').val());
							self.set('entityRoleCode', $('#ci-entity-role :selected ').attr('data-value'));
							self.set('ein1', $('#ci-ein-1').val());
							self.set('ein2', $('#ci-ein-2').val());
							self.set('clientType', clientType);
							if (clientType == 'P') {
								//set gender
								self.set('clientSex', _clientInfoForm.find('input[name="clientSex"]:checked').val());
								self.set('clientRole',_clientInfoForm.find('input[name="clientRole"]:checked').val());
								self.set('honorific', $('#ci-client-honorific').val());
								self.set('firstName', $.trim($('#ci-first-name').val()));
								self.set('middleName', $.trim($('#ci-middle-name').val()));
								self.set('lastName', $.trim($('#ci-last-name').val()));
								self.set('suffix', $('#ci-client-suffix').val());
								self.set('ssn1', $('#ci-ssn-1').val());
								self.set('ssn2', $('#ci-ssn-2').val());
								self.set('ssn3', $('#ci-ssn-3').val());
								var _citizenShip = _clientInfoForm.find('input[name="citizenShip"]:checked').val();
								self.set('citizenship', _citizenShip);
								self.set('citizenshipType', _clientInfoForm.find('input[name="citizenShip"]:checked').attr('data-value'));
								self.set('citizenshipCountry', _citizenShip == "U.S." ? null : $('#ci-citizenship-country').val());
								self.set('citizenshipCountryName', _citizenShip == "U.S." ? null : $('#ci-citizenship-country option:selected').text());
								self.set('secCitizenshipCountry', _citizenShip == "U.S." ? null : $ciSecondCitizenshipCountry.val());
								self.set('secCitizenshipCountryName', _citizenShip == "U.S." ? null : $ciSecondCitizenshipCountry.find('option:selected').text());
								self.set('clientInfoValid', true);
								// set the name for addressEntryModel
								var _fullName = (function() {
									var _honorific = self.get('honorific');
									var _middleName = self.get('middleName');
									// var _suffix =
									// self.get('suffix');
									var _name = "";
									_name += (_honorific && _honorific != "N.A") ? _honorific + ' ': '';
									_name += self.get('firstName') + ' ';
									_name += _middleName ? _middleName + ' ' : '';
									_name += self.get('lastName');
									/*
									 * _name += (_suffix && _suffix != "N.A") ? ' ' +
									 * _suffix : ''
									 */;
									return _name;
								})();
								self.set('fullName', _fullName);

								// save the data to new Client Data model
								var _newClientReqModel = newClientModel.get('newClientModel');
								_newClientReqModel['orgClient'] = null;
								_newClientReqModel['customerTypeCd'] = "P";
								if (_newClientReqModel['personClient'] == null) {
									_newClientReqModel['personClient'] = {
										"postalAddresses" : [],
										"emails" : [],
										"telephones" : [],
										"productExpe" : []
									};
								}

								var _persClnt = _newClientReqModel['personClient'];
								_persClnt['hrnfNm'] = self
										.get('honorific');
								_persClnt['firstNm'] = self
										.get('firstName');
								_persClnt['midNm'] = self
										.get('middleName');
								_persClnt['lastNm'] = self
										.get('lastName');
								_persClnt['sfxTxt'] = self
										.get('suffix');
								_persClnt['persTypCd'] = self
										.get('honorific');
								_persClnt['ctzp'] = self
										.get('citizenshipType');
								_persClnt['ctznCntryCd'] = self
										.get('citizenshipCountry');
								_persClnt['firstCtznCntryNm'] = self
										.get('citizenshipCountryName');
								_persClnt['secCtznCntryCd'] = self
										.get('secCitizenshipCountry');
								_persClnt['secCtznCntryNm'] = self
										.get('secCitizenshipCountryName');
								
								var _currSSN = self.get('ssn1')+self.get('ssn2')+self.get('ssn3');
								if(_currSSN != _prevSSN){
									self.set('ssnChanged', true);
								}

							} else {
								//reset gender
								self.set('clientSex', null);
								var _orgNm = $('#ci-entity-name').val();
								var _newClientReqModel = newClientModel
										.get('newClientModel');
								_newClientReqModel['personClient'] = null;
								_newClientReqModel['customerTypeCd'] = "O";
								if (_newClientReqModel['orgClient'] == null) {
									_newClientReqModel['orgClient'] = {
										"postalAddresses" : [],
										"emails" : [],
										"telephones" : []
									};
								}
								var _orgClnt = _newClientReqModel['orgClient'];
								_orgClnt['orgNm'] = _orgNm
								self.set('entityRole', $('#ci-entity-role').val());
								self.set('entityRoleCode', $('#ci-entity-role :selected ').attr('data-value'));
								self.set('industryClassifyCd', _industryCd);
								self.set('industryClassifyType', _industryType);
								self.set('industryFreeFormText', (_industryType == "Other") ? _industryInputval : "");
								if ($('#operating-entity').find('.active input').val() == 'Non-Operational') {
								    self.set('isThisOperatingEntity', 'Y');
								} else {
								    self.set('isThisOperatingEntity', 'N');
								}
								
								if ($('input[name="select-choice-entity-client-radiobuttons"]:checked').val() == "U.S. entity") {
									self.set('frgnOrgCheck', 'Y');
									self.set('stOfIncorpCode', $('#pt-us-state-drpdown option:selected').val());
								} else if ($('input[name="select-choice-entity-client-radiobuttons"]:checked').val() == "Foreign entity") {
									self.set('frgnOrgCheck', 'N');
									self.set('stOfIncorpCode','');
								}
								self.set('entityName', $.trim(_orgNm));
								self.set('uEntityName', $(
										'#ci-entity-name').val());
								self.set('entityEIN1',
										$('#ci-ein-1').val());
								self.set('entityEIN2',
										$('#ci-ein-2').val());
								var _currSSN = self.get('ein1')+self.get('ein2');
								if(_currSSN != _prevSSN){
									self.set('ssnChanged', true);
								}

							}
						    /*setting clicnt associated in info view*/
							function setAssocClientDetails() {

							}
							if (clientType == "P" || ((clientType == "O" && self.get('entityRole') == 'Revocable trust'))) {
							    self.set('clientAssociated', $('.assoc').filter('.active').val());
							    var _asocClId = $('#cd-assoc-name').data('value');
							    var clientassocId = _asocClId ? _asocClId : null;
							    var clientassocReltn = clientType == "P" ? $('#cd-assoc-reltn').val() : ((clientType == "O" && clientassocId && self.get('entityRole') == 'Revocable trust') ? self.toTitleCase(self.get('entityRole')) : '');
							    self.set('clientAssociated', $('.assoc').filter('.active').val());
							    var _assocClNm = $('#cd-assoc-name').val();
							    self.set('clientassocName', _assocClNm);
							    if (_assocClNm) {
							        _assocClNm = _assocClNm.substr(0, (_assocClNm.length - 11));
							    }
							    self.set('clientassocId', clientassocId);
							    var _fmtAssocClientNm = _assocClNm;
							    if (_fmtAssocClientNm) {
							        if (_newClientReqModel['customerTypeCd'] != "O") {
							            try {
							                var _splitedNm = _fmtAssocClientNm.split(',');
							                _fmtAssocClientNm = _splitedNm[1].trim() + " " + _splitedNm[0].trim();
							            } catch (e) {
							            }
							        }

							    }
							    self.set('clientassocFmtNm', _fmtAssocClientNm);
							    self.set('clientassocReltn', clientassocReltn);
							} else {
							    self.clearClientAssociation();
							}
						    /*assoc client details*/
						
						
						},
						clearClientAssociation: function () {
						    this.set('clientAssociated', '');
						    this.set('clientassocName', '');
						    this.set('clientassocReltn', '');
						    this.set('clientassocId', '');
						}, toTitleCase: function (str) {
						    return str.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
						},

					});
			return new modelClientInfo();
		});
