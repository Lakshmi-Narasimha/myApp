/**
 * @ngdoc property
 * @name saveNewInvestor Controller
 * @requires $scope
 * @description
 *
 * - Controller for pop over modal.
 *
 **/


'use strict';
// Controller naming conventions should start with an uppercase letter

function saveNewInvController($scope, $uibModalStack,constants,transactModel) {     
    console.log("saveNewInvController");
    $scope.newInvSaveTxtObj = {
        key: "",
        text: "Investor Name",
        type: "text",
        max: 20,
        isRequired: true,
        isMasked: false,
        pattern: /^[a-zA-Z0-9]{1,20}/,
        value: ""
    };
    $scope.okay = function(){
        if($scope.newInvSaveTxtObj.value.length !== 0 && $scope.newInvSaveTxtObj.value.length < 20) {    
        var object={};        
        object.holders = [
                {
                    "name" : $scope.newInvSaveTxtObj.value,
                    "type" : "First Holder"
                },
                {
                    "name" : "",
                    "type" : "Second Holder"
                },
                {
                    "name" : "",
                    "type" : "Third Holder"
                }
            ];
            object.folioId = "";
            object.holdingType = "";
            object.emailId = "";
            transactModel.setInvestorDetails(object);
            $scope.closeModal();
            $scope.$emit('saveNewInvSmartSol');
        }
        else{
            $scope.invNameError = "Investor Name should be 1-20 characters."
        }
    }

    $scope.closeModal = function(){
        $uibModalStack.dismissAll();
    }
    
}

saveNewInvController.$inject = ['$scope', '$uibModalStack','constants','transactModel'];
module.exports = saveNewInvController;