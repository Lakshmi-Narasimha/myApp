// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var MbFundCompositionModelSchema = new mongoose.Schema({
    mbFundsCompostionResp: {
        type: Array,
        "default": []
    }
});

var MbFundCompositionModelLookUp = mongoose.model('MbFundCompositionModelLookUp', MbFundCompositionModelSchema);

var MbFundCompositionModel = new MbFundCompositionModelLookUp({
  mbFundsCompostionResp: {
    "monthlyBusinessOverviewFundsCompostionResp": {
        "fundsType": "EQUITY",
        "data": [{
            "fundName": "Franklin Asian Equity Fund",
            "grossSales": "0",
            "upfrontAccured": "0",
            "upfrontReleased": "0",
            "AUM": "1357694.71",
            "trailAccured": "581.05",
            "redemption": "581.05",
            "netSales": "75449.60",
            "clawback": "-75449.60",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": ""
        }, {
            "fundName": "Franklin Build India Fund",
            "grossSales": "41000",
            "upfrontAccured": "735",
            "upfrontReleased": "700",
            "AUM": "6297194.77",
            "trailAccured": "3097.86",
            "redemption": "3087.16",
            "netSales": "100588.61",
            "clawback": "-59588.61",
            "prevCommReleased": "-416.82",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India Blue Chip Fund",
            "grossSales": "596319.05",
            "upfrontAccured": "12555.46",
            "upfrontReleased": "11882.96",
            "AUM": "147258301.24",
            "trailAccured": "61093.26",
            "redemption": "60799.14",
            "netSales": "1693881.41",
            "clawback": "-1097562.36",
            "prevCommReleased": "-1506.37",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India Flexi Cap Fund",
            "grossSales": "207086.95",
            "upfrontAccured": "3686.12",
            "upfrontReleased": "3598.62",
            "AUM": "112082290.10",
            "trailAccured": "48313.78",
            "redemption": "48251.43",
            "netSales": "739344.18",
            "clawback": "-532257.23",
            "prevCommReleased": "-68.97",
            "incentiveAccured": "7561.06",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India High Growth Companies Fund",
            "grossSales": "6195240.50",
            "upfrontAccured": "106493.20",
            "upfrontReleased": "105163.20",
            "AUM": "78567532.38",
            "trailAccured": "34537.08",
            "redemption": "33703.58",
            "netSales": "398063.55",
            "clawback": "5797176.95",
            "prevCommReleased": "-1797.68",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India Index Fund",
            "grossSales": "5000",
            "upfrontAccured": "0",
            "upfrontReleased": "0",
            "AUM": "15597948.11",
            "trailAccured": "5102.83",
            "redemption": "5102.83",
            "netSales": "50000.99",
            "clawback": "-45000.99",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": ""
        }, {
            "fundName": "Franklin India Opportunities Fund",
            "grossSales": "96500",
            "upfrontAccured": "1827.50",
            "upfrontReleased": "1687.50",
            "AUM": "28700869.75",
            "trailAccured": "8797.83",
            "redemption": "8739.99",
            "netSales": "0",
            "clawback": "96500",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India Prima Fund",
            "grossSales": "129000",
            "upfrontAccured": "2177.64",
            "upfrontReleased": "2107.64",
            "AUM": "84482250.15",
            "trailAccured": "35710.35",
            "redemption": "35694.33",
            "netSales": "234901.84",
            "clawback": "-105901.84",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India Prima Plus",
            "grossSales": "736137.48",
            "upfrontAccured": "12406",
            "upfrontReleased": "12126",
            "AUM": "117789078.25",
            "trailAccured": "48036.30",
            "redemption": "47801.81",
            "netSales": "975957.53",
            "clawback": "-239820.05",
            "prevCommReleased": "-470.87",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin India Smaller Companies Fund",
            "grossSales": "253000",
            "upfrontAccured": "4615",
            "upfrontReleased": "4077.50",
            "AUM": "33798061.66",
            "trailAccured": "14155.40",
            "redemption": "14123.55",
            "netSales": "244403.03",
            "clawback": "8596.97",
            "prevCommReleased": "-259.45",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Franklin Infotech Fund",
            "grossSales": "10000",
            "upfrontAccured": "250",
            "upfrontReleased": "250",
            "AUM": "10155443.15",
            "trailAccured": "3392.94",
            "redemption": "3392.94",
            "netSales": "26314.50",
            "clawback": "-16314.50",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": ""
        }, {
            "fundName": "Templeton India Equity Income Fund",
            "grossSales": "8000",
            "upfrontAccured": "170",
            "upfrontReleased": "170",
            "AUM": "17482812.42",
            "trailAccured": "7481.45",
            "redemption": "7466.52",
            "netSales": "247960.01",
            "clawback": "-239960.01",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": "0"
        }, {
            "fundName": "Templeton India Growth Fund",
            "grossSales": "42500",
            "upfrontAccured": "748.75",
            "upfrontReleased": "748.75",
            "AUM": "37616516.41",
            "trailAccured": "13888.47",
            "redemption": "13888.47",
            "netSales": "50001",
            "clawback": "-7501",
            "prevCommReleased": "0",
            "incentiveAccured": "0",
            "incentiveReleased": ""
        }]
    }
  }
});

MbFundCompositionModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating MbFundCompositionModelLookUp table, please contact admin...');
    } else {
        MbFundCompositionModelLookUp.remove({}, function(err) {
            console.log('MbFundCompositionModelLookUp collection removed');
            MbFundCompositionModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating MbFundCompositionModelLookUp table, please contact admin...');
                }
                console.log('MbFundCompositionModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = MbFundCompositionModelLookUp;
