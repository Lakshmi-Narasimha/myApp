// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var STPInstallmentModelSchema = new mongoose.Schema({
    stpInstallmentResp: {
        type: Array,
        "default": []
    }
});

var STPInstallmentModelLookUp = mongoose.model('STPInstallmentModelLookUp', STPInstallmentModelSchema);

var STPInstallmentModel = new STPInstallmentModelLookUp({
    stpInstallmentResp : {
      "stpInstallments": {
        "fundWiseData": [
          {
            "installmentDate": "19 Apr 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "111.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Mar 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "109.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Feb 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "120.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Jan 2016",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "107.21",
            "units": "15",
            "status": "Processed"
          },
          {
            "installmentDate": "19 Dec 2015",
            "destAccount": "0001918201",
            "destFund": "Franklin India Prima Plus - Growth",
            "amount": "100",
            "nav": "106.21",
            "units": "15",
            "status": "Processed"
          }
        ],
        "fundInfo": {
          "fundName": "Franklin India Equity Fund - Growth",
          "folioNo": "19950599",
          "accountNo": "000901524837",
          "goal": "Wealth Creation",
          "goalDetails": "Buying a House",
          "startDate": "13 Jan 2014",
          "endDate": "13 Jan 2016",
          "frequency": "Weekly",
          "type": "Fixed Amount",
          "modeOfHolding": "Joint",
          "holders": {
            "firstHoldersName": "Shankar Narayan",
            "secondHoldersName": "Meenakshi",
            "minorGuardian": "Archana"
          }
        }
      }
    }
}
);

STPInstallmentModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating STPInstallmentModelLookUp table, please contact admin...');
    } else {
        STPInstallmentModelLookUp.remove({}, function(err) {
            console.log('STPInstallmentModelLookUp collection removed');
            STPInstallmentModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating STPInstallmentModelLookUp table, please contact admin...');
                }
                console.log('STPInstallmentModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = STPInstallmentModelLookUp;
