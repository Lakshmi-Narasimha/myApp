/**
 * @ngdoc property
 * @name fticFundDetails Directive
 * @requires fundDetailsModel
 * @requires transactEventConstants
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - This directive is responsible for displaying the Fund Details.
 *
 **/
'use strict';

var fticFundDetails = function (fundDetailsModel, fundDetailsInitialLoader, transactEventConstants, transactEvents, authenticationService) {
    return {
        template: require('./fundDetails.html'),
        restrict: 'E',
        replace: true,
        scope: {},
        controller:['$scope', function ($scope) {
            $scope.popovercontent = null;

            $scope.$on('Call_Balance_Units', function(event,data){
                fundDetailsInitialLoader.loadAllServices($scope);
            });
            
            $scope.$on(transactEventConstants.transact.FUND_DETAILS, function(event) {
                var fundDtls = fundDetailsModel.getFundDetails().fundDetails[0];
                var unitDtls = fundDetailsModel.getFundDetails().fundDetails[0].unitDetails;
                var rupeeIcon = "<i class='icon-fti_rupee'></i>";
                var bulbIcon = '<i class="load-free-units icon-fti_advisorRecommendation"></i>';
                if(fundDetailsModel.getInvestorType()){
                    $scope.keyValueList = [
                    {key:'Locked Units '+  rupeeIcon ,value:fundDtls.unitDetails.lienUnits},
                    {key:'Clear Balance Units',value:fundDtls.totalAvailableUnits}
                ]; 
                }else{
                    
                    /**
                     * Changed as per requirement in Investor - Load free units need have bulb icon aside - Start
                     */
                    $scope.keyValueList = [
                        {key:'Value of Load Free Units '+  rupeeIcon ,value:fundDtls.valueOfLoadFreeUnits},
                        {key:'Total Available Units',value:fundDtls.totalAvailableUnits},
                        {key:'Value of Total Available Units '+  rupeeIcon ,value:fundDtls.valueOfTotalAvailableUnits}
                        ];
                    if(authenticationService.isInvestorLoggedIn()) {
                        $scope.keyValueList.unshift({key:'Load Free Units'+bulbIcon,value:fundDtls.loadFreeUnits});
                    }else {
                        $scope.keyValueList.unshift({key:'Load Free Units',value:fundDtls.loadFreeUnits});
                    }
                    /**
                     * Changed as per requirement in Investor - Load free units need have bulb icon aside - End
                     */
                }
                


                $scope.popovercontent = [
                    {key: 'lienUnits', text: 'Lien Units', value: unitDtls.lienUnits},
                    {key: 'unitsUnderProcess', text: 'Units already Under Process', value: unitDtls.unitsUnderProcess},
                    {key: 'unitsUnderProvisionalStatus', text: 'Units Under Provisional Status', value: unitDtls.unitsUnderProvisionalStatus}
                ];
            });
        }]
    };
};

fticFundDetails.$inject = ['fundDetailsModel', 'fundDetailsInitialLoader', 'transactEventConstants', 'transactEvents', 'authenticationService'];
module.exports = fticFundDetails;