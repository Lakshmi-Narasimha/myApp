/**
 * @ngdoc property
 * @name accountViewModel
 * @requires Restangular
 * @requires $q
 * @description
 *
 * - accountViewModel is a service model which consists the list of services required for account view of Account statements in 
 *   Statements tab of my investors page.
 *
 **/
'use strict';


var accountViewModel = function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    var _accountViewObj = null;

    var accountViewDetails = {

        getAccountViewDetails: function(accountFilter) {
            accountFilter.flag = 'A';
            accountFilter.guId = authenticationService.getUser().guId;
            var deferred = $q.defer();
            Restangular.one('clients/clientStatement').get(accountFilter).then(function(accountViewDetails) {
                deferred.resolve(accountViewDetails);
            }, function(resp) {
                deferred.reject(resp);
            });
            return deferred.promise;
        },
        getAccountViewObj: function() {
            if (!angular.isDefined(_accountViewObj)) {
                return null;
            }
            return _accountViewObj;
        },
        setAccountViewObj: function(accountViewObj) {
            _accountViewObj = accountViewObj;
        }
    };

    return accountViewDetails;

};

accountViewModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = accountViewModel;
